

# Generated at 2022-06-24 23:52:33.045638
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    assert date_time_fact_collector_0.collect()['date_time']['iso8601'] != ''

# Generated at 2022-06-24 23:52:42.814279
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    tc_0 = {}
    tc_0['function_name'] = 'test_case_0'
    tc_0['test_case'] = test_case_0
    date_time_fact_collector_0 = DateTimeFactCollector()
    collected_facts_0 = date_time_fact_collector_0.collect()
    tc_0['collected_facts'] = collected_facts_0

# Generated at 2022-06-24 23:52:44.380751
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Testing whether the result is not null
    assert DateTimeFactCollector().collect()

# Generated at 2022-06-24 23:52:48.633929
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Given
    date_time_fact_collector_1 = DateTimeFactCollector()
    # When
    actual_result = date_time_fact_collector_1.collect()

    # Then
    expected_result = {}
    assert actual_result == expected_result

# Generated at 2022-06-24 23:52:50.630147
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    assert 'date' in date_time_fact_collector.collect()['date_time']


# Generated at 2022-06-24 23:52:56.038509
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()

    # Test with one argument provided.
    # Test with two arguments provided.
    assert 'date_time' in date_time_fact_collector_0.collect(collected_facts={})
    # Test with three arguments provided.
    assert 'date_time' in date_time_fact_collector_0.collect(collected_facts={}, module=object())



# Generated at 2022-06-24 23:53:06.581314
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    now_0 = datetime.datetime.fromtimestamp(time.time())
    c_0 = DateTimeFactCollector()
    ansible_0 = c_0.collect()
    ansible_1 = ansible_0['date_time']
    # Test assertion statements found in collect method of class DateTimeFactCollector
    assert ansible_1['year'] == now_0.strftime('%Y')
    assert ansible_1['month'] == now_0.strftime('%m')
    assert ansible_1['weekday'] == now_0.strftime('%A')
    assert ansible_1['weekday_number'] == now_0.strftime('%w')
    assert ansible_1['weeknumber'] == now_0.strftime('%W')
    assert ansible_1['day'] == now

# Generated at 2022-06-24 23:53:10.377519
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:53:12.452264
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    print(date_time_fact_collector_1.collect())

# Generated at 2022-06-24 23:53:20.245959
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    assert 'date_time' in date_time_fact_collector.collect().keys()
    assert isinstance(date_time_fact_collector.collect(), dict)
    assert isinstance(date_time_fact_collector.collect()['date_time'], dict)
    assert 'epoch' in date_time_fact_collector.collect()['date_time'].keys()
    assert 'date' in date_time_fact_collector.collect()['date_time'].keys()
    assert 'time' in date_time_fact_collector.collect()['date_time'].keys()
    assert 'iso8601' in date_time_fact_collector.collect()['date_time'].keys()
    assert 'tz' in date_time

# Generated at 2022-06-24 23:53:32.942331
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collector = DateTimeFactCollector()
    result = collector.collect()

# Generated at 2022-06-24 23:53:44.763043
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    facts_dict = date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:53:46.105520
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()

# Generated at 2022-06-24 23:53:51.276378
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Get test object
    DateTimeFactCollector = DateTimeFactCollector()

    # Get facts
    facts_dict = DateTimeFactCollector.collect()

    # Assert that date_time exists in collected facts
    assert 'date_time' in facts_dict
    assert isinstance(facts_dict['date_time'], dict)

    # Assert that date_time dict has the following keys

# Generated at 2022-06-24 23:53:58.734170
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    result = date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:54:02.265484
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()

# Generated at 2022-06-24 23:54:06.044847
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    assert isinstance(date_time_fact_collector.collect(), dict)
    assert 'date_time' in date_time_fact_collector.collect()

# Generated at 2022-06-24 23:54:06.798305
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:54:16.020694
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()

# Generated at 2022-06-24 23:54:22.884998
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()
    fact_keys_0 = date_time_fact_collector_1.collect().keys()
    if fact_keys_0[0] == "date_time":
        print("Test case 0:\n\tDateTimeFactCollector_collect: PASS\n")
    else:
        print("Test case 0:\n\tDateTimeFactCollector_collect: FAIL\n")


# Generated at 2022-06-24 23:54:28.746282
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()


# Generated at 2022-06-24 23:54:30.470362
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()

# Generated at 2022-06-24 23:54:33.764357
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_collect = date_time_fact_collector_1.collect()
    assert date_time_fact_collector_collect is not None
    return 0


# Generated at 2022-06-24 23:54:38.333886
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector_return = date_time_fact_collector.collect()
    # This test doesn't validate the dictionary returned by the collect method.
    assert date_time_fact_collector_return is not None


# Generated at 2022-06-24 23:54:43.518057
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector.collect()
    if not ('date_time' in date_time_facts):
        raise Exception('date_time not in return value of collect')
    date_time = date_time_facts['date_time']
    if not ('year' in date_time):
        raise Exception('year not in return value of collect')
    if not ('month' in date_time):
        raise Exception('month not in return value of collect')
    if not ('weekday' in date_time):
        raise Exception('weekday not in return value of collect')
    if not ('weekday_number' in date_time):
        raise Exception('weekday_number not in return value of collect')

# Generated at 2022-06-24 23:54:44.323345
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:54:46.661351
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    result = date_time_fact_collector.collect()
    assert 'date_time' in result.keys()

# Generated at 2022-06-24 23:54:47.515451
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # test collect()
    test_case_0()

# Generated at 2022-06-24 23:54:53.989459
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector_output = date_time_fact_collector.collect()

    assert 'date_time' in date_time_fact_collector_output.keys()


# Generated at 2022-06-24 23:54:59.040176
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_2 = DateTimeFactCollector()
    date_time_fact_collector_2.collect()


# Generated at 2022-06-24 23:55:07.846245
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    facts_dict = date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:55:11.042311
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:55:13.199230
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.collect()["date_time"]["year"] == '2017'

# Generated at 2022-06-24 23:55:21.846828
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    result = date_time_fact_collector.collect()
    assert result['date_time'] is not None
    date_time_facts = result['date_time']
    assert date_time_facts['year'] is not None
    assert date_time_facts['month'] is not None
    assert date_time_facts['weekday'] is not None
    assert date_time_facts['weekday_number'] is not None
    assert date_time_facts['day'] is not None
    assert date_time_facts['hour'] is not None
    assert date_time_facts['minute'] is not None
    assert date_time_facts['second'] is not None
    assert date_time_facts['epoch'] is not None

# Generated at 2022-06-24 23:55:34.229214
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_facts_dict = date_time_fact_collector_0.collect()
    assert(date_time_facts_dict['date_time']['iso8601_basic'] == '20170613T171224.651566')
    assert(date_time_facts_dict['date_time']['iso8601_basic_short'] == '20170613T171224')
    assert(date_time_facts_dict['date_time']['iso8601_micro'] == '2017-06-13T17:12:24.651566Z')
    assert(date_time_facts_dict['date_time']['iso8601'] == '2017-06-13T17:12:24Z')

# Generated at 2022-06-24 23:55:37.793790
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    assert isinstance(date_time_fact_collector_0.collect(), dict)

# Generated at 2022-06-24 23:55:40.336774
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()

# Generated at 2022-06-24 23:55:42.985266
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # create instance of DateTimeFactCollector
    date_time_fact_collector_0 = DateTimeFactCollector()

    # call the collect method of DateTimeFactCollector
    date_time_fact_collector_0.collect()



# Generated at 2022-06-24 23:55:47.624749
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector_1.collect(None, None)
    date_time_fact_collector_1.collect_once(None, None)

# Generated at 2022-06-24 23:55:49.904991
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    result = date_time_fact_collector_1.collect()
    assert result


# Generated at 2022-06-24 23:56:13.623272
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    ansible_module_0, facts_dict_0 = date_time_fact_collector_0.collect()
    assert 'date_time' in facts_dict_0
    assert 'year' in facts_dict_0['date_time']
    assert 'month' in facts_dict_0['date_time']
    assert 'day' in facts_dict_0['date_time']
    assert 'hour' in facts_dict_0['date_time']
    assert 'minute' in facts_dict_0['date_time']
    assert 'second' in facts_dict_0['date_time']
    assert 'epoch' in facts_dict_0['date_time']

# Generated at 2022-06-24 23:56:20.034931
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()
    # Test that it returns a dict
    assert isinstance(date_time_fact_collector_1.collect(), dict)
    # Test that is contains a dict under the key 'date_time'
    assert 'date_time' in date_time_fact_collector_1.collect()


# Generated at 2022-06-24 23:56:23.501727
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Instantiate an instance of DateTimeFactCollector
    date_time_fact_collector_0 = DateTimeFactCollector()

    # Call method collect of DateTimeFactCollector instance
    date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:56:35.465154
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # noinspection PyUnresolvedReferences
    def mock_datetime_datetime_utcfromtimestamp(unix_epoch_time):
        return 'mock-utc-datetime'

    # noinspection PyUnresolvedReferences
    def mock_datetime_datetime_fromtimestamp(unix_epoch_time):
        return 'mock-datetime'

    # noinspection PyUnresolvedReferences
    def mock_time_time():
        return 1337.1337

    # noinspection PyUnresolvedReferences
    def mock_time_strftime(format):
        if format == '%Y-%m-%d':
            return 'mock-date'
        if format == '%H:%M:%S':
            return 'mock-time'

# Generated at 2022-06-24 23:56:38.788466
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:56:40.736009
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:56:42.576314
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    assert isinstance(date_time_fact_collector.collect(), dict)

# Generated at 2022-06-24 23:56:44.701065
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    assert isinstance(date_time_fact_collector_1.collect(), dict)


# Generated at 2022-06-24 23:56:52.957769
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    facts_dict = date_time_fact_collector.collect()
    assert 'date_time' in facts_dict
    assert isinstance(facts_dict['date_time'], dict)
    assert 'year' in facts_dict['date_time']
    assert isinstance(facts_dict['date_time']['year'], str)
    assert 'month' in facts_dict['date_time']
    assert isinstance(facts_dict['date_time']['month'], str)
    assert 'weekday' in facts_dict['date_time']
    assert isinstance(facts_dict['date_time']['weekday'], str)
    assert 'weekday_number' in facts_dict['date_time']

# Generated at 2022-06-24 23:56:57.759065
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    base_fact_collector_0 = BaseFactCollector()
    is_date_time_dict_0 = date_time_fact_collector_0.collect()
    assert isinstance(is_date_time_dict_0, dict)

# Generated at 2022-06-24 23:57:18.263163
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_0.name = "ansible"
    date_time_fact_collector_1.timestamp_start = "ansible"
    var_0 = date_time_fact_collector_0.collect()
    var_1 = date_time_fact_collector_1.collect()

# Generated at 2022-06-24 23:57:20.661733
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_collect_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_collect_0.collect()
    assert 'date_time' in var_0.keys()


# Generated at 2022-06-24 23:57:24.352248
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_case_0()

if __name__ == "__main__":
    test_DateTimeFactCollector_collect()

# Generated at 2022-06-24 23:57:33.108800
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_1 = date_time_fact_collector_0.collect()
    assert date_time_1 != {}
    assert type(date_time_1['date_time']) is dict
    assert date_time_1['date_time']['year'] != ''
    assert date_time_1['date_time']['month'] != ''
    assert date_time_1['date_time']['weekday_number'] != ''
    assert date_time_1['date_time']['weekday'] != ''
    assert date_time_1['date_time']['weeknumber'] != ''
    assert date_time_1['date_time']['day'] != ''

# Generated at 2022-06-24 23:57:43.845003
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    var_0 = DateTimeFactCollector()
    var_1 = var_0.collect()
    assert isinstance(var_1, dict)

# Generated at 2022-06-24 23:57:54.125317
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    # Testing if the 'date_time' key is present in the date_time dictionary
    assert 'date_time' in var_0
    # Testing if all the required keys are present in the date_time dictionary
    assert 'year' in var_0['date_time']
    assert 'month' in var_0['date_time']
    assert 'weekday' in var_0['date_time']
    assert 'weekday_number' in var_0['date_time']
    assert 'weeknumber' in var_0['date_time']
    assert 'day' in var_0['date_time']
    assert 'hour' in var_0['date_time']

# Generated at 2022-06-24 23:58:02.646076
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert var_0['date_time']['date'] == "2019-08-19"
    assert var_0['date_time']['day'] == "19"
    assert var_0['date_time']['epoch'] == "1566202951"
    assert var_0['date_time']['epoch_int'] == "1566202951"
    assert var_0['date_time']['hour'] == "15"
    assert var_0['date_time']['iso8601'] == "2019-08-19T15:55:51Z"
    assert var_0['date_time']['iso8601_basic']

# Generated at 2022-06-24 23:58:05.196289
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    data_time_fact_collector_0 = DateTimeFactCollector()
    data_time_fact_collector_0.collect()
    # no assertation check - just make sure no exception raised

# Generated at 2022-06-24 23:58:10.045745
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()
    if var_1['date_time']['day'] == '01':
        var_1['date_time']['day'] = '02'
    else:
        var_1['date_time']['day'] = '01'
    var_1['date_time']['tz'] = 'WST'
    var_1['date_time']['tz_dst'] = 'WST'
    var_1['date_time']['tz_offset'] = '+0800'


# Generated at 2022-06-24 23:58:13.579669
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    print(test_case_0.__doc__)
    test_case_0()


if __name__ == '__main__':
    print('\nStarting test cases...')
    test_DateTimeFactCollector_collect()
    print('\nTest cases complete.')

# Generated at 2022-06-24 23:58:46.968423
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:58:50.397145
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()

    var = date_time_fact_collector.collect()  # this will fail every second, so we can't really verify the value
    assert isinstance(var, dict)


# Generated at 2022-06-24 23:58:53.885087
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()

# Generated at 2022-06-24 23:59:02.771213
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()

    assert var_1['date_time']['time'] is not None, "Failed: 'time' not in date_time"
    assert var_1['date_time']['weekday'] is not None, "Failed: 'weekday' not in date_time"
    assert var_1['date_time']['epoch'] is not None, "Failed: 'epoch' not in date_time"
    assert var_1['date_time']['weekday_number'] is not None, "Failed: 'weekday_number' not in date_time"

# Generated at 2022-06-24 23:59:07.014443
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:59:07.957042
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    print(DateTimeFactCollector.collect())

# Generated at 2022-06-24 23:59:16.036698
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Define test input and expected result.
    args = {
        "module": None,
        "collected_facts": None,
    }

# Generated at 2022-06-24 23:59:18.137742
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()

    assert isinstance(date_time_fact_collector.collect(), dict)



# Generated at 2022-06-24 23:59:20.399743
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()

    assert var_0.keys() == {'date_time'}

# Generated at 2022-06-24 23:59:22.178885
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()


# Generated at 2022-06-25 00:00:31.092469
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    result = date_time_fact_collector.collect()
    assert result['date_time']['year'] == datetime.datetime.now().strftime('%Y')


# Generated at 2022-06-25 00:00:40.921291
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Test case with epoch, utcnow and now variables
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()
    var_2 = date_time_fact_collector_1.collect()
    assert var_1['date_time']['year'] == var_2['date_time']['year']
    assert var_1['date_time']['month'] == var_2['date_time']['month']
    assert var_1['date_time']['weekday'] == var_2['date_time']['weekday']
    assert var_1['date_time']['weekday_number'] == var_2['date_time']['weekday_number']

# Generated at 2022-06-25 00:00:44.067427
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()

# Generated at 2022-06-25 00:00:53.685573
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_0.collect()

# Generated at 2022-06-25 00:00:58.920656
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert date_time_fact_collector_0.name == 'date_time'
    assert date_time_fact_collector_0._fact_ids == set()
    assert isinstance(var_0, dict)



# Generated at 2022-06-25 00:01:07.779116
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()

    var_0 = date_time_fact_collector_0.collect()
    assert isinstance(var_0['date_time'], dict)
    assert var_0['date_time']['epoch_int'] == var_0['date_time']['epoch']
    assert len(var_0['date_time']['iso8601_basic']) == 19
    assert len(var_0['date_time']['iso8601_basic_short']) == 15
    assert len(var_0['date_time']['iso8601']) == 20
    assert len(var_0['date_time']['iso8601_micro']) == 24

# Generated at 2022-06-25 00:01:10.111026
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    dic_1 = date_time_fact_collector_1.collect()
    assert dic_1 is not None
    assert dic_1 == {}

# Generated at 2022-06-25 00:01:18.842168
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()
    var_2 = date_time_fact_collector_1.collect()
    var_3 = date_time_fact_collector_1.collect()
    assert var_1['date_time']['epoch'] == var_2['date_time']['epoch']
    assert var_1['date_time']['epoch'] == var_3['date_time']['epoch']

# Generated at 2022-06-25 00:01:21.029943
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    assert callable(getattr(DateTimeFactCollector(), "collect", None))


# Generated at 2022-06-25 00:01:31.031671
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # Imports
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collectors
    import ansible.module_utils.facts.collectors.datetime
    import ansible.module_utils.facts.collectors.date_time
    import datetime
    import time

    # StringVarPairs(['now', 'datetime.datetime'], ['utcnow', 'datetime.datetime'], ['date_time_facts', 'dict'], ['date_time_fact_collector_0', 'DateTimeFactCollector'], ['var_0', 'dict'])
    # Setup test case
    var_0 = ansible.module_utils.facts.collectors.date_time.DateTimeFactCollector()
    var_0.collect()

    # Assertions