

# Generated at 2022-06-24 23:52:32.387325
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    assert  date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:52:39.099604
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    fact_collected = date_time_fact_collector_0.collect(None, None)

    assert fact_collected['date_time']['month'] in ['01','02','03','04','05','06','07','08','09','10','11','12']

# Generated at 2022-06-24 23:52:47.067551
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector.collect()
    assert date_time_facts is not None
    assert 'date_time' in date_time_facts
    assert isinstance(date_time_facts['date_time'], dict)
    assert 'year' in date_time_facts['date_time']
    assert 'month' in date_time_facts['date_time']
    assert 'weekday' in date_time_facts['date_time']
    assert 'weekday_number' in date_time_facts['date_time']
    assert 'weeknumber' in date_time_facts['date_time']
    assert 'day' in date_time_facts['date_time']

# Generated at 2022-06-24 23:52:57.659835
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    collected_facts = {}
    collected_facts = date_time_fact_collector.collect(collected_facts=collected_facts)
    assert 'date_time' in collected_facts
    assert 'day' in collected_facts['date_time']
    assert 'year' in collected_facts['date_time']
    assert 'month' in collected_facts['date_time']
    assert 'weekday' in collected_facts['date_time']
    assert 'weekday_number' in collected_facts['date_time']
    assert 'weeknumber' in collected_facts['date_time']
    assert 'day' in collected_facts['date_time']
    assert 'hour' in collected_facts['date_time']

# Generated at 2022-06-24 23:53:01.798386
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()


# Generated at 2022-06-24 23:53:05.327134
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()


if __name__ == '__main__':
    test_case_0()
    test_DateTimeFactCollector_collect()

# Generated at 2022-06-24 23:53:13.596044
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector.collect()
    assert date_time_facts['date_time']['iso8601_micro'] == datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.%fZ")
    assert date_time_facts['date_time']['iso8601'] == datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
    assert date_time_facts['date_time']['iso8601_basic'] == datetime.datetime.now().strftime("%Y%m%dT%H%M%S%f")
    assert date_time

# Generated at 2022-06-24 23:53:15.176818
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()


# Generated at 2022-06-24 23:53:17.405681
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_collector_1 = DateTimeFactCollector()
    assert date_time_collector_1.collect() is not None


# Generated at 2022-06-24 23:53:19.946695
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    d = DateTimeFactCollector()
    d.collect()

# Generated at 2022-06-24 23:53:24.972383
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
   # Collect facts
   date_time_fact_collector_1 = Da

# Generated at 2022-06-24 23:53:26.491927
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.collect()

# Generated at 2022-06-24 23:53:28.442621
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    assert isinstance(date_time_fact_collector_1.collect(), dict)


# Generated at 2022-06-24 23:53:37.564201
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    facts_dict = date_time_fact_collector.collect()
    assert facts_dict['date_time']['year'] == datetime.datetime.today().strftime('%Y')
    assert facts_dict['date_time']['month'] == datetime.datetime.today().strftime('%m')
    assert facts_dict['date_time']['day'] == datetime.datetime.today().strftime('%d')
    assert facts_dict['date_time']['hour'] == datetime.datetime.today().strftime('%H')
    assert facts_dict['date_time']['minute'] == datetime.datetime.today().strftime('%M')

# Generated at 2022-06-24 23:53:38.135889
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    pass



# Generated at 2022-06-24 23:53:43.669966
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    collected_facts = {}

    # Does not throw exception.
    try:
        collected_facts = date_time_fact_collector_0.collect(collected_facts=collected_facts)
    except:
        # assert False, "Unexpected error during collect."
        pass

# Generated at 2022-06-24 23:53:48.024805
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector.collect()
    assert len(date_time_facts) == 1
    assert 'date_time' in date_time_facts


if __name__ == '__main__':
    test_case_0()
    test_DateTimeFactCollector_collect()

# Generated at 2022-06-24 23:53:50.416629
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()

# Generated at 2022-06-24 23:53:51.972165
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:53:55.835718
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_2 = DateTimeFactCollector()

    module_0 = None
    collected_facts_0 = None

    ret_val_0 = date_time_fact_collector_2.collect(module_0, collected_facts_0) # Collect facts from the platform and return collected facts to the results.
    assert isinstance(ret_val_0, dict)

# Generated at 2022-06-24 23:54:07.764760
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Setup
    date_time_fact_collector_0 = DateTimeFactCollector()
    collected_facts_0 = {}
    # Invocation
    var_0 = date_time_fact_collector_0.collect(
        module=None, collected_facts=collected_facts_0)
    # Verification
    assert str(var_0) is not None
    assert str(var_0) is not ""


# Generated at 2022-06-24 23:54:16.088074
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:54:25.471773
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect(module='ansible.module_utils.facts.system.date_time.DateTimeFactCollector', collected_facts={})

# Generated at 2022-06-24 23:54:29.361829
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible_collections.ansible.community.plugins.module_utils.facts.collectors.date_time.date_time import DateTimeFactCollector
    testobj = DateTimeFactCollector()
    testobj.collect()


if __name__ == '__main__':
    test_DateTimeFactCollector_collect()

# Generated at 2022-06-24 23:54:36.262810
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import pytest

    date_time_fact_collector_0 = DateTimeFactCollector()

    # Test cases derived from inspec test profile ansible-date_time-fact-plugin (controls/date_time_fact.rb)
    with pytest.raises(AnsibleConnectionFailure):
        date_time_fact_collector_0.collect()


if __name__ == '__main__':
    import pytest

    pytest.main(args=['-s', '--tb=native', '--pyargs', 'test_datetime_facts.py::test_case_0'])
    #pytest.main(args=['-s', '--tb=native', '--pyargs', 'test_datetime_facts.py'])

# Generated at 2022-06-24 23:54:46.334174
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    epoch_ts = time.time()
    now = datetime.datetime.fromtimestamp(epoch_ts)
    utcnow = datetime.datetime.utcfromtimestamp(epoch_ts)

    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact = date_time_fact_collector.collect()['date_time']

    assert(date_time_fact['year'] == now.strftime('%Y'))
    assert(date_time_fact['month'] == now.strftime('%m'))
    assert(date_time_fact['weekday'] == now.strftime('%A'))
    assert(date_time_fact['weekday_number'] == now.strftime('%w'))

# Generated at 2022-06-24 23:54:53.642650
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()

# Generated at 2022-06-24 23:54:58.996257
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import datetime
    import time
    # Setup test case
    # Setup test case
    test_case = DateTimeFactCollector()

    # Perform the test
    var = test_case.collect()

    # Make assertions
    assert datetime.datetime.fromtimestamp(time.time())

# Generated at 2022-06-24 23:55:01.556972
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # DateTimeFactCollector unit test stubs
    # Populates facts with the current time.
    # Raises:
    # An arbitrary exception
    # Return type: dict
    pass

# Generated at 2022-06-24 23:55:05.142070
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Tests the return type of the collect method.
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert isinstance(var_0, dict)

# Generated at 2022-06-24 23:55:21.402892
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    result = DateTimeFactCollector().collect()
    assert result.get('date_time') is not None
    assert result.get('date_time').get('year') is not None
    assert result.get('date_time').get('month') is not None
    assert result.get('date_time').get('weeknumber') is not None
    assert result.get('date_time').get('weekday') is not None
    assert result.get('date_time').get('weekday_number') is not None
    assert result.get('date_time').get('day') is not None
    assert result.get('date_time').get('hour') is not None
    assert result.get('date_time').get('minute') is not None
    assert result.get('date_time').get('second') is not None

# Generated at 2022-06-24 23:55:25.668334
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Setup
    date_time_fact_collector = DateTimeFactCollector()

    # Test
    var = date_time_fact_collector.collect()

    # Assertions
    assert isinstance(var, dict)



# Generated at 2022-06-24 23:55:29.645315
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    var = DateTimeFactCollector()

    # Test with no parameters
    var.collect()
    # Test with parameters: module=None, collected_facts=None
#     var.collect(module=None, collected_facts=None)
    pass

# Generated at 2022-06-24 23:55:34.502834
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()

    assert var_1['date_time']['day'] == time.strftime('%d')
# vim: expandtab filetype=python ts=4 sw=4

# Generated at 2022-06-24 23:55:40.807233
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_2 = DateTimeFactCollector()
    var_2 = date_time_fact_collector_2.collect()
    assert var_2["date_time"]["day"] is not None

# ------------ Testing complete --------------

if __name__ == '__main__':
    from test.lib.testing import run_tests

    run_tests(__name__, globals())

# Generated at 2022-06-24 23:55:48.599249
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Input parameters for the method collect
    # Module for the method collect
    module_0 = None
    # Dictionary with collected facts for the method collect
    collected_facts_0 = {}
    # Instance of class DateTimeFactCollector
    date_time_fact_collector_0 = DateTimeFactCollector()
    # Calling method collect of class DateTimeFactCollector with required parameters
    date_time_fact_collector_0.collect(module_0, collected_facts_0)

# Generated at 2022-06-24 23:55:52.242239
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert 1 == len(var_0['date_time'])

# Generated at 2022-06-24 23:56:01.054335
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:56:07.811375
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    var = date_time_fact_collector.collect()
    assert var is not None

# Generated at 2022-06-24 23:56:13.597765
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Instantiate the DateTimeFactCollector
    date_time_fact_collector_1 = DateTimeFactCollector()

    # Call the collect method with arguments:
    # module = None, collected_facts = None
    # Return type: dict
    date_time_fact_collector_1.collect()

    # This is the correct test case
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()



# Generated at 2022-06-24 23:56:39.760424
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert isinstance(var_0, dict) == True
    # Check the types of the var_0 elements
    assert isinstance(var_0['date_time'], dict) == True
    assert isinstance(var_0['date_time']['date'], str) == True
    assert isinstance(var_0['date_time']['time'], str) == True
    assert isinstance(var_0['date_time']['hour'], str) == True
    assert isinstance(var_0['date_time']['minute'], str) == True
    assert isinstance(var_0['date_time']['second'], str) == True
   

# Generated at 2022-06-24 23:56:43.464203
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_0.collect()
    var_1 = str(var_1)
    var_2 = 'date_time'
    var_3 = var_1.find(var_2)
    assert var_3 != -1

# Generated at 2022-06-24 23:56:45.235875
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    t_0 = DateTimeFactCollector()
    var_0 = t_0.collect()
    assert isinstance(var_0, dict)

# Generated at 2022-06-24 23:56:47.792148
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert var_0 is not None


# Generated at 2022-06-24 23:56:48.973521
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_DateTimeFactCollector_collect_0()


# Generated at 2022-06-24 23:56:51.448483
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_0.collect()
    assert var_1 is not None


# Generated at 2022-06-24 23:56:57.217736
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()

    # Verify that the 'facts_dict' variable is populated
    assert var_0 != None


# Generated at 2022-06-24 23:57:02.938050
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Test with no parameters
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:57:07.140903
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()

    date_time_fact_collector.collect()


if __name__ == '__main__':
    test_case_0()
    test_DateTimeFactCollector_collect()

# Generated at 2022-06-24 23:57:17.798394
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    label_0 = ('date_time', 'iso8601')
    label_1 = ('date_time', 'iso8601_basic')
    label_2 = ('date_time', 'iso8601_basic_short')
    label_3 = ('date_time', 'iso8601_micro')
    label_4 = ('date_time', 'weekday')
    label_5 = ('date_time', 'minute')
    label_6 = ('date_time', 'tz_offset')
    label_7 = ('date_time', 'date')
    label_8 = ('date_time', 'epoch_int')
    label_9 = ('date_time', 'weekday_number')
    label_10 = ('date_time', 'time')
    label_11 = ('date_time', 'second')

# Generated at 2022-06-24 23:57:55.083007
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert isinstance(var_0, dict), 'Returned value  is not the expected type'
    assert isinstance(var_0['date_time'], dict), 'Returned value  is not the expected type'
    assert 'weekday_number' in var_0['date_time'], 'Returned value  does not contain expected key'
    assert 'day' in var_0['date_time'], 'Returned value  does not contain expected key'
    assert 'iso8601_basic' in var_0['date_time'], 'Returned value  does not contain expected key'

# Generated at 2022-06-24 23:58:06.059992
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    #set up
    date_time_fact_collector_0 = DateTimeFactCollector()


    # invoke the method
    result_0 = date_time_fact_collector_0.collect()

    # assertion

# Generated at 2022-06-24 23:58:12.719824
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    dtfc.collect()
    assert isinstance(dtfc._fact_ids, set)
    assert dtfc.name == 'date_time'
    assert isinstance(dtfc.collect(), dict)

# Generated at 2022-06-24 23:58:15.059212
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector();
    var_1 = date_time_fact_collector_0.collect();


# Generated at 2022-06-24 23:58:17.308474
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:58:17.843914
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:58:22.681342
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:58:26.839437
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # setup for testing
    date_time_fact_collector_0 = DateTimeFactCollector()

    # testing method call
    var_0 = date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:58:33.850430
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()
    print("var_1 = " + str(var_1))
    assert var_1 != None, "'None' value returned by method 'collect' of object 'DateTimeFactCollector'"

# Generated at 2022-06-24 23:58:39.509448
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = DateTimeFactCollector()
    dt.collect()
    'assert'
    assert True

# Generated at 2022-06-24 23:59:44.386027
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()

if __name__ == '__main__':
    test_case_0()
    test_DateTimeFactCollector_collect()

# Generated at 2022-06-24 23:59:54.289117
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert var_0['date_time']['year'] == time.strftime("%Y")
    assert var_0['date_time']['hour'] == time.strftime("%H")
    assert var_0['date_time']['tz'] == time.strftime("%Z")
    assert var_0['date_time']['iso8601'] == datetime.datetime.utcfromtimestamp(time.time()).strftime("%Y-%m-%dT%H:%M:%SZ")
    assert var_0['date_time']['epoch'] == str(int(time.time()))

# Generated at 2022-06-25 00:00:05.095556
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()
    assert type(var_1) == dict
    assert var_1.get('date_time') is not None, 'Failed to get date_time fact!'
    assert type(var_1.get('date_time')) == dict
    assert var_1['date_time'].get('year') is not None
    assert var_1['date_time'].get('month') is not None
    assert var_1['date_time'].get('weekday') is not None
    assert var_1['date_time'].get('weekday_number') is not None
    assert var_1['date_time'].get('weeknumber') is not None
    assert var_1

# Generated at 2022-06-25 00:00:14.949135
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    var = date_time_fact_collector.collect()
    assert isinstance(var, dict)
    assert len(var) == 1
    assert isinstance(var['date_time'], dict)
    assert len(var['date_time']) == 20
    # year
    assert isinstance(var['date_time']['year'], str)
    assert len(var['date_time']['year']) == 4
    # month
    assert isinstance(var['date_time']['month'], str)
    assert len(var['date_time']['month']) == 2
    # weekday
    assert isinstance(var['date_time']['weekday'], str)

# Generated at 2022-06-25 00:00:22.736052
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    # We don't have any values to test, just make sure the method doesn't raise an exception
    try:
        date_time_fact_collector_1.collect()
    except Exception as exception_1:
        raise AssertionError(exception_1)

test_case_0()
test_DateTimeFactCollector_collect()

# Generated at 2022-06-25 00:00:26.734090
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    facts_dict_0 = date_time_fact_collector_0.collect()
    var_1 = facts_dict_0.keys()
    assert var_1 == ['date_time']


# Generated at 2022-06-25 00:00:38.591403
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()

# Generated at 2022-06-25 00:00:40.500907
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_0.collect()
    try:
        assert isinstance(var_1, dict)
    except AssertionError as e:
        raise(AssertionError(str(e)))


# Generated at 2022-06-25 00:00:49.718369
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    var_1 = date_time_fact_collector_0.collect()
    var_2 = date_time_fact_collector_0.collect()
    var_3 = date_time_fact_collector_0.collect()
    var_4 = date_time_fact_collector_0.collect()
    var_5 = date_time_fact_collector_0.collect()
    var_6 = date_time_fact_collector_0.collect()
    var_7 = date_time_fact_collector_0.collect()
    var_8 = date_time_fact_collector_0.collect()
    var_9 = date_time_

# Generated at 2022-06-25 00:00:58.588426
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    fact_collector_0 = FactCollector()
    var_0 = fact_collector_0.update_cache(disabled_collectors=['hardware'], refresh_internal=True)
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect(collected_facts=var_0[1])


if __name__ == '__main__':
    test_case_0()
    test_DateTimeFactCollector_collect()