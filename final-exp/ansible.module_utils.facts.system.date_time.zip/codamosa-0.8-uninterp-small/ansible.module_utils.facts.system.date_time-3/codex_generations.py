

# Generated at 2022-06-24 23:52:39.429655
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    assert (date_time_fact_collector.collect())



# Generated at 2022-06-24 23:52:47.400938
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    mod_0 = None
    col_facts_0 = None
    ret_0 = date_time_fact_collector_0.collect(mod_0, col_facts_0)
    assert ret_0['date_time']['epoch'].isdigit()
    assert ret_0['date_time']['epoch_int'].isdigit()
    assert ret_0['date_time']['iso8601_basic'].isdigit()
    assert ret_0['date_time']['iso8601_basic_short'].isdigit()
    assert ret_0['date_time']['hour'].isdigit()
    assert ret_0['date_time']['minute'].isdigit()
   

# Generated at 2022-06-24 23:52:55.817069
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    result = date_time_fact_collector.collect()
    assert 'date_time' in result
    assert 'year' in result['date_time']
    assert 'month' in result['date_time']
    assert 'weekday' in result['date_time']
    assert 'weekday_number' in result['date_time']
    assert 'weeknumber' in result['date_time']
    assert 'day' in result['date_time']
    assert 'hour' in result['date_time']
    assert 'minute' in result['date_time']
    assert 'second' in result['date_time']
    assert 'epoch' in result['date_time']
    assert 'date' in result['date_time']

# Generated at 2022-06-24 23:52:56.965659
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector.collect()

# Generated at 2022-06-24 23:52:58.379578
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector.collect()


# Generated at 2022-06-24 23:53:08.511619
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-24 23:53:17.669744
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    module_0 = None
    collected_facts_0 = None
    return_value = date_time_fact_collector_0.collect(module=module_0, collected_facts=collected_facts_0)

# Generated at 2022-06-24 23:53:27.659060
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    dict_0 = date_time_fact_collector.collect()
    # Check for date_time attribute in the returned dictionary
    assert 'date_time' in dict_0
    date_time_dict = dict_0['date_time']
    # Check for mandatory attributes
    assert 'date' in date_time_dict
    assert 'time' in date_time_dict
    assert 'tz' in date_time_dict
    assert 'hour' in date_time_dict
    assert 'minute' in date_time_dict
    assert 'second' in date_time_dict
    assert 'epoch' in date_time_dict
    assert 'epoch_int' in date_time_dict

    # Check if iso8601 is in the form of UTC time

# Generated at 2022-06-24 23:53:30.435928
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    assert 'date_time' in date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:53:32.160895
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_c = DateTimeFactCollector()
    #assert date_time_fact_collector_c.collect() is not None, "Error while collecting facts"

# Generated at 2022-06-24 23:53:46.847288
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_collect = DateTimeFactCollector()

    # Test when no module argument is passed
    assert('date_time' in date_time_fact_collector_collect.collect())
    assert('date_time' in date_time_fact_collector_collect.collect(collected_facts=None))

    # Test when an empty module argument is passed
    assert('date_time' in date_time_fact_collector_collect.collect(module=None))
    assert('date_time' in date_time_fact_collector_collect.collect(module=None, collected_facts=None))

    # Test when module argument is not empty but does not contain supported parameters
    assert('date_time' in date_time_fact_collector_collect.collect(module=dict()))

# Generated at 2022-06-24 23:53:58.353803
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()

    # Get the local and UTC times
    utcnow = datetime.datetime.utcnow()
    now = datetime.datetime.now()

    # Get timezone offset
    tz_offset = time.strftime("%z")

    # Call collect() method
    ansible_date_time = date_time_fact_collector_1.collect()

    # Check the results
    assert ansible_date_time['date_time']['date'] == now.strftime("%Y-%m-%d")
    assert ansible_date_time['date_time']['time'] == now.strftime("%H:%M:%S")

# Generated at 2022-06-24 23:54:01.600187
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:54:08.517083
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    collected_facts_dict_0 = {}
    collected_facts_dict_0['ansible_python_version'] = '2.7.5'
    collected_facts_dict_0['ansible_user_dir'] = '<some_directory>'
    date_time_fact_collector_0.collect(module=None, collected_facts=collected_facts_dict_0)

# Test case for the DateTimeFactCollector class

# Generated at 2022-06-24 23:54:16.125757
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector_dict = {}
    date_time_fact_collector_dict['date_time'] = {}
    date_time_fact_collector_dict['date_time']['date'] = '2017-02-24'
    date_time_fact_collector_dict['date_time']['day'] = '24'
    date_time_fact_collector_dict['date_time']['epoch'] = '1488015117'
    date_time_fact_collector_dict['date_time']['epoch_int'] = '1488015117'
    date_time_fact_collector_dict['date_time']['hour'] = '11'
    date_time_fact_collector_

# Generated at 2022-06-24 23:54:17.736487
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector.collect()

# Generated at 2022-06-24 23:54:19.765608
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:54:26.912652
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    data = '2018-02-23T17:41:38.843444Z'
    dt_fact_collector = DateTimeFactCollector()
    dt_fact_collector.collect()
    assert 'date_time' in dt_fact_collector._collected_facts
    date_time_facts = dt_fact_collector._collected_facts['date_time']
    assert isinstance(date_time_facts, dict)
    assert 'iso8601_micro' in date_time_facts
    assert date_time_facts['iso8601_micro'][:-3] == data[:-3]

# Generated at 2022-06-24 23:54:34.987497
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()

# Generated at 2022-06-24 23:54:45.006382
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    time_list = []
    time_list.append(time.time())
    time.sleep(1)
    time_list.append(time.time())
    time.sleep(1)
    answer_dict = {}
    answer_dict["date_time"] = {}
    answer_dict["date_time"]["weekday"] = ["Friday", "Friday"]
    answer_dict["date_time"]["weekday_number"] = ["5", "5"]
    answer_dict["date_time"]["weeknumber"] = ["", ""]
    answer_dict["date_time"]["date"] = ["2015-07-17", "2015-07-17"]
    answer_dict["date_time"]["tz"] = ["PDT", "PDT"]

# Generated at 2022-06-24 23:54:54.614390
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:54:59.480372
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    collected_facts = {}
    assert date_time_fact_collector_1.collect(collected_facts=collected_facts) is not None

# Generated at 2022-06-24 23:55:02.022475
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()
    return


# Generated at 2022-06-24 23:55:04.389393
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:55:15.884174
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()

# Generated at 2022-06-24 23:55:17.762392
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    test_case_0(date_time_fact_collector_0)

# Generated at 2022-06-24 23:55:24.378842
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import os
    import datetime
    class  module():
        def __init__(self, p):
            self.params = p
        def today(self):
            return datetime.datetime.today()
    date_time_fact_collector_0 = DateTimeFactCollector()
    module_0 = module(['test'])
    # Calling the function collect of DateTimeFactCollector class
    result = date_time_fact_collector_0.collect(module=module_0,collected_facts={})
    assert result['date_time']['year'] == '2019'
    assert result['date_time']['month'] == '01'
    assert result['date_time']['month'] == '01'
    assert len(result['date_time']['weekday']) == 6

# Generated at 2022-06-24 23:55:34.654827
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = DateTimeFactCollector().collect()
    assert dt['date_time']['year'] == str(datetime.datetime.now().year)
    assert (dt['date_time']['iso8601_micro'] ==
            datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.%fZ"))
    # Check that integer epoch_int is available and matches epoch
    assert dt['date_time']['epoch_int'] == dt['date_time']['epoch']
    # Check that epoch_int is integer
    assert isinstance(int(dt['date_time']['epoch_int']), int)

# Generated at 2022-06-24 23:55:44.549644
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    facts_dict = date_time_fact_collector_0.collect()

    # Check return type
    assert type(facts_dict) is dict

    # Check dict keys match our facts
    assert sorted(facts_dict.keys()) == ['date_time']

    # Check values
    date_time_facts = facts_dict['date_time']
    assert type(date_time_facts) is dict

# Generated at 2022-06-24 23:55:46.458435
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    assert DateTimeFactCollector().collect() is not None


# Generated at 2022-06-24 23:56:08.214154
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    results = date_time_fact_collector_0.collect()
    assert results['date_time']['weekday'] == datetime.datetime.now().strftime('%A')
    assert results['date_time']['time'] == datetime.datetime.now().strftime('%H:%M:%S')
    assert results['date_time']['date'] == datetime.datetime.now().strftime('%Y-%m-%d')
    assert results['date_time']['month'] == datetime.datetime.now().strftime('%m')
    assert results['date_time']['day'] == datetime.datetime.now().strftime('%d')

# Generated at 2022-06-24 23:56:19.880505
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector.collect()

    assert date_time_facts is not None
    assert date_time_facts['date_time']['year'] is not None
    assert date_time_facts['date_time']['month'] is not None
    assert date_time_facts['date_time']['weekday'] is not None
    assert date_time_facts['date_time']['weekday_number'] is not None
    assert date_time_facts['date_time']['weeknumber'] is not None
    assert date_time_facts['date_time']['day'] is not None
    assert date_time_facts['date_time']['hour'] is not None
    assert date_time_facts

# Generated at 2022-06-24 23:56:23.480000
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    result = date_time_fact_collector_1.collect(
        module = None,
        collected_facts = None
    )

    assert isinstance(result, dict)
    assert result
    assert 'date_time' in result


# Generated at 2022-06-24 23:56:35.464528
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector.collect()
    print("Date and Time facts collected")
    print("The current ISO 8601 micro is %s" %
          date_time_facts['date_time']['iso8601_micro'])
    print("The current ISO 8601 is %s" % date_time_facts['date_time']['iso8601'])
    print("The current ISO 8601 basic micro is %s" %
          date_time_facts['date_time']['iso8601_basic'])
    print("The current ISO 8601 basic is %s" %
          date_time_facts['date_time']['iso8601_basic_short'])


# Run the tests

# Generated at 2022-06-24 23:56:46.487300
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    facts_dict_0 = date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:56:54.448582
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_facts_dict_0 = {}
    date_time_facts_dict_0['epoch_int'] = '1383133467'
    date_time_facts_dict_0['second'] = '07'
    date_time_facts_dict_0['tz_offset'] = '-0400'
    date_time_facts_dict_0['day'] = '07'
    date_time_facts_dict_0['time'] = '17:04:27'
    date_time_facts_dict_0['weekday'] = 'Monday'
    date_time_facts_dict_0['weeknumber'] = '44'

# Generated at 2022-06-24 23:57:02.704686
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector_1.collect(None, {})
    assert 'date_time' in date_time_facts
    assert 'year' in date_time_facts['date_time']
    assert 'month' in date_time_facts['date_time']
    assert 'weekday' in date_time_facts['date_time']
    assert 'weekday_number' in date_time_facts['date_time']
    assert 'weeknumber' in date_time_facts['date_time']
    assert 'day' in date_time_facts['date_time']
    assert 'hour' in date_time_facts['date_time']
    assert 'minute' in date_time_facts['date_time']


# Generated at 2022-06-24 23:57:04.161432
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()


# Generated at 2022-06-24 23:57:15.055662
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector_collect_retval = \
        date_time_fact_collector.collect()
    assert isinstance(date_time_fact_collector_collect_retval, dict)
    assert 'date_time' in date_time_fact_collector_collect_retval
    assert 'epoch' in date_time_fact_collector_collect_retval['date_time']
    assert 'epoch_int' in date_time_fact_collector_collect_retval['date_time']
    assert 'iso8601' in date_time_fact_collector_collect_retval['date_time']

# Generated at 2022-06-24 23:57:25.521259
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-24 23:57:58.507250
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector.collect()


# Generated at 2022-06-24 23:58:05.427890
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-24 23:58:06.363717
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_case_0()

# vim: expandtab filetype=python

# Generated at 2022-06-24 23:58:11.613334
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()

# Generated at 2022-06-24 23:58:15.423892
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    collected_facts = dict()
    date_time_fact_collector.collect(collected_facts=collected_facts)
    assert len(collected_facts['date_time']) > 0


# Generated at 2022-06-24 23:58:17.345349
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:58:22.716172
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 23:58:31.687382
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # Test execution
    def test_case_helper():
        # Instantiation and execution of DateTimeFactCollector
        date_time_fact_collector_0 = DateTimeFactCollector()
        collected_facts = {}
        collected_facts.update(date_time_fact_collector_0.collect())

        # Verification of the data in the collected_facts
        assert isinstance(collected_facts, dict)
        assert isinstance(collected_facts["date_time"], dict)
        assert isinstance(collected_facts["date_time"]["date"], str)
        assert isinstance(collected_facts["date_time"]["epoch"], str)
        assert isinstance(collected_facts["date_time"]["epoch_int"], str)

# Generated at 2022-06-24 23:58:41.112103
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()

    # Call method collect of DateTimeFactCollector instance date_time_fact_collector_0
    return_value = date_time_fact_collector_0.collect()

    # Assert return_value of method collect of class DateTimeFactCollector
    assert return_value is not None
    assert isinstance(return_value, dict)

# Generated at 2022-06-24 23:58:47.638734
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    ansible_test_execution_date = datetime.datetime.fromtimestamp(time.time())

    # static parameters for DateTimeFactCollector.collect
    module_0 = None
    collected_facts_0 = None

    # call method DateTimeFactCollector.collect
    test_result_0 = DateTimeFactCollector().collect(module_0, collected_facts_0)

    # test if test_result_0 is a dict
    assert isinstance(test_result_0, dict)
    # test if test_result_0['date_time'] is a dict
    assert isinstance(test_result_0['date_time'], dict)
    # test if test_result_0['date_time']['year'] is string

# Generated at 2022-06-24 23:59:53.544486
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    fact_data_0 = date_time_fact_collector_0.collect();
    assert fact_data_0['date_time']['weekday'] != None

# Generated at 2022-06-25 00:00:02.218918
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Initialize the DateTimeFactCollector object
    date_time_fact_collector_1 = DateTimeFactCollector()

    # Call method collect of the DateTimeFactCollector object
    return_value = date_time_fact_collector_1.collect()

    # Check the type of return value
    assert isinstance(return_value, dict)

    # Check if the return value is empty
    assert return_value == {}

# Generated at 2022-06-25 00:00:12.610289
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    time_dict = fact_collector.collect()['date_time']
    assert time_dict['year'] == str(datetime.datetime.now().year)
    assert time_dict['month'] == str(datetime.datetime.now().month)
    assert time_dict['weekday'] == datetime.datetime.now().strftime('%A')
    assert time_dict['weekday_number'] == str(datetime.datetime.now().timetuple().tm_wday)
    assert time_dict['weeknumber'] == str(datetime.datetime.now().isocalendar()[1])
    assert time_dict['day'] == str(datetime.datetime.now().day)

# Generated at 2022-06-25 00:00:14.881814
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    result = date_time_fact_collector_0.collect()
    assert 'date_time' in result

# Generated at 2022-06-25 00:00:18.550077
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()

# Generated at 2022-06-25 00:00:23.429192
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()


if __name__ == "__main__":
    test_DateTimeFactCollector_collect()

# Generated at 2022-06-25 00:00:30.999315
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()

# Generated at 2022-06-25 00:00:32.928086
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector.collect()

# Generated at 2022-06-25 00:00:35.821439
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    date_time_fact_collector_0 = DateTimeFactCollector()

    date_time_fact_collector_0.collect()

# Generated at 2022-06-25 00:00:41.850946
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector

    date_time_fact_collector_1 = DateTimeFactCollector()

    # Case 1: No parameters
    # Expected result: Some facts about date and time