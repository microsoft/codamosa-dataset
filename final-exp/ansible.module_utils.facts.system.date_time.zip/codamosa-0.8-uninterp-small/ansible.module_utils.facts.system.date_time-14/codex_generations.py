

# Generated at 2022-06-24 23:52:39.300892
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    result = date_time_fact_collector_0.collect({}, {})
    assert result['date_time']['month'] == '06'
    assert result['date_time']['date'] == '2020-06-15'

# Generated at 2022-06-24 23:52:44.007374
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()



# Generated at 2022-06-24 23:52:54.352345
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    dict = date_time_fact_collector.collect()
    assert dict['date_time']['date']
    assert dict['date_time']['day']
    assert dict['date_time']['hour']
    assert dict['date_time']['minute']
    assert dict['date_time']['second']
    assert dict['date_time']['epoch_int']
    assert dict['date_time']['iso8601']
    assert dict['date_time']['month']
    assert dict['date_time']['time']
    assert dict['date_time']['weekday']
    assert dict['date_time']['weekday_number']
    assert dict['date_time']['weeknumber']
   

# Generated at 2022-06-24 23:53:03.852023
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from unit.module_utils.facts.collector.test_date_time_fact_collector import DateTimeFactCollector
    date_time_fact_collector_0 = DateTimeFactCollector()
    assert isinstance(date_time_fact_collector_0, DateTimeFactCollector)
    assert isinstance(date_time_fact_collector_0, BaseFactCollector)
    assert hasattr(date_time_fact_collector_0, 'collect')
    # Testing the return type of function collect
    assert isinstance(date_time_fact_collector_0.collect(), dict)

# Generated at 2022-06-24 23:53:11.157887
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    collected_facts_dict = {}
    returned_facts_dict = date_time_fact_collector_1.collect(collected_facts=collected_facts_dict)
    assert isinstance(returned_facts_dict, dict)
    assert 'date_time' in returned_facts_dict.keys()
    date_time_dict = returned_facts_dict['date_time']
    assert isinstance(date_time_dict, dict)
    assert len(date_time_dict.keys()) == 2

# Generated at 2022-06-24 23:53:18.402664
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    c0 = DateTimeFactCollector()
    # No KeyError should be raised because there is no 'date_time' key in the
    # collected_facts dict
    c0.collect(module=dict(), collected_facts=dict())
    # No TypeError should be raised because the datetime module is imported
    c0.collect(module=dict(), collected_facts=dict())
    # No AttributeError should be raised because the utcnow method is a built
    # in.
    c0.collect(module=dict(), collected_facts=dict())
    assert c0.collect()


# Generated at 2022-06-24 23:53:21.504618
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:53:26.139706
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Test with module_utils/facts/collector.py
    pass

# Generated at 2022-06-24 23:53:32.567826
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    # Test variables
    epoch_ts = time.time()
    now = datetime.datetime.fromtimestamp(epoch_ts)

    # Run code to be tested
    ansible_facts = date_time_fact_collector_0.collect()

    # Verify results
    assert 'date_time' in ansible_facts
    assert ansible_facts['date_time']['year'] == now.strftime('%Y')
    assert ansible_facts['date_time']['month'] == now.strftime('%m')
    assert ansible_facts['date_time']['weekday'] == now.strftime('%A')

# Generated at 2022-06-24 23:53:33.600587
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector.collect()


# Generated at 2022-06-24 23:53:38.312352
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_collector = DateTimeFactCollector()
    date_time_collector.collect()

# Generated at 2022-06-24 23:53:41.704318
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.collect() is not None


# Generated at 2022-06-24 23:53:45.715758
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()
    assert type(var_1) == dict
    assert 'date_time' in var_1.keys()
    assert type(var_1['date_time']) == dict

# Generated at 2022-06-24 23:53:52.757736
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Test with parameters
    # Returns: A dictionary containing a key “date_time” with a value which is a dictionary of the time of the ansible host
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()

# Generated at 2022-06-24 23:53:54.774435
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # AssertionError: Unable to collect date_time facts
    assert ('assert' not in DateTimeFactCollector.collect.__code__.co_code)


# Generated at 2022-06-24 23:53:57.238078
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector.collect()

# Generated at 2022-06-24 23:54:00.460284
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    assert callable(DateTimeFactCollector.collect)

# Generated at 2022-06-24 23:54:05.613584
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fac_col_0 = DateTimeFactCollector()
    var_0 = date_time_fac_col_0.collect()
    print(var_0)


# Generated at 2022-06-24 23:54:15.029938
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Default arguments
    default_args = {}

    # Test with default values for arguments
    date_time_fact_collector_0 = DateTimeFactCollector()
    assert date_time_fact_collector_0.collect() is not None
    # Test with mandatory argument(s)
    date_time_fact_collector_1 = DateTimeFactCollector()
    assert date_time_fact_collector_1.collect(module='module_0') is not None
    # Test with optional argument(s)
    date_time_fact_collector_2 = DateTimeFactCollector()
    assert date_time_fact_collector_2.collect() is not None
    # Test with a positional argument instead of the named one
    date_time_fact_collector_0 = DateTimeFactCollector()
    assert date_time_

# Generated at 2022-06-24 23:54:18.238491
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector.collect()
    assert date_time_fact_collector.name == 'date_time'
    assert date_time_fact_collector._fact_ids == set()

# Generated at 2022-06-24 23:54:22.838114
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:54:25.242503
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert isinstance(var_0, dict)

# Generated at 2022-06-24 23:54:27.874792
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert type(var_0) == dict


# Generated at 2022-06-24 23:54:28.708432
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    assert True


# Generated at 2022-06-24 23:54:31.051045
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()

    # Test cases
    assert isinstance(date_time_fact_collector_0.collect(), dict)


# Generated at 2022-06-24 23:54:34.587908
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    assert date_time_fact_collector_0.collect() is not None


# Test the type of return value of method collect of class DateTimeFactCollector

# Generated at 2022-06-24 23:54:36.574019
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:54:39.680038
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()



# Generated at 2022-06-24 23:54:43.261850
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    print(date_time_fact_collector_0.collect())

if __name__ == "__main__":
    test_DateTimeFactCollector_collect()

# Generated at 2022-06-24 23:54:51.190886
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_0.collect()
    assert type(var_1) is dict
    assert set(var_1) == set(['date_time'])
    assert var_1['date_time'].has_key('date')
    assert var_1['date_time'].has_key('day')
    assert var_1['date_time'].has_key('epoch')
    assert var_1['date_time'].has_key('epoch_int')
    assert var_1['date_time'].has_key('hour')
    assert var_1['date_time'].has_key('iso8601')

# Generated at 2022-06-24 23:55:06.553409
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()

# Generated at 2022-06-24 23:55:12.664151
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_2 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_2.collect()
    assert 'date_time' in var_1
    assert 'iso8601' in var_1['date_time']
    assert 'date' in var_1['date_time']


# Generated at 2022-06-24 23:55:21.324348
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    now = datetime.datetime.now()
    epoch_ts = int(time.time())

    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()

    assert var_0['date_time']['tz'] != '', "date_time.tz cannot be empty"
    assert var_0['date_time']['tz_dst'] != '', "date_time.tz_dst cannot be empty"
    assert var_0['date_time']['tz_offset'] != '', "date_time.tz_offset cannot be empty"

    # year

# Generated at 2022-06-24 23:55:27.586474
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()

# Generated at 2022-06-24 23:55:33.042688
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector.collect()
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()

# Generated at 2022-06-24 23:55:44.285043
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert 'date_time' in var_0
    assert var_0['date_time']['tz_offset'] == ''
    assert var_0['date_time']['weeknumber'] == ''
    assert var_0['date_time']['minute'] == ''
    assert var_0['date_time']['tz_dst'] == ''
    assert var_0['date_time']['iso8601_basic_short'] == ''
    assert var_0['date_time']['iso8601_micro'] == ''
    assert var_0['date_time']['second'] == ''

# Generated at 2022-06-24 23:55:49.826738
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()


if __name__ == "__main__":
    test_case_0()
    # Unit test for method collect of class DateTimeFactCollector
    test_DateTimeFactCollector_collect()

# Generated at 2022-06-24 23:55:51.199161
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    var_0 = DateTimeFactCollector()
    return var_0.collect()


# Generated at 2022-06-24 23:55:54.820222
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts.collector import ModuleCollector

    module_collector_0 = ModuleCollector()
    date_time_fact_collector_0 = DateTimeFactCollector()
    module_collector_0._collectors.append(date_time_fact_collector_0)
    date_time_fact_collector_0.collect(module_collector_0)

# Generated at 2022-06-24 23:55:55.913647
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    assert False

test_DateTimeFactCollector_collect.unit = True


# Generated at 2022-06-24 23:56:11.205967
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    assert isinstance(date_time_fact_collector_1.collect(), dict)


# Generated at 2022-06-24 23:56:22.320653
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert var_0.get('date_time').get('year') == datetime.date.today().strftime('%Y')
    assert var_0.get('date_time').get('month') == datetime.date.today().strftime('%m')
    assert var_0.get('date_time').get('weekday') == datetime.date.today().strftime('%A')
    assert var_0.get('date_time').get('weekday_number') == datetime.date.today().strftime('%w')
    assert var_0.get('date_time').get('weeknumber') == datetime.date.today().strftime('%W')
   

# Generated at 2022-06-24 23:56:24.500235
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    # Call collect()
    date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:56:34.446433
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect(module=None, collected_facts=None)

# Generated at 2022-06-24 23:56:41.293579
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()
    assert 'date_time' in var_1
    assert var_1.get('date_time')['time'] != ''
    assert var_1.get('date_time')['tz'] != ''
    assert var_1.get('date_time')['iso8601'] != ''

# Generated at 2022-06-24 23:56:49.622884
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()
    assert isinstance(var_1, dict)

# Generated at 2022-06-24 23:56:53.760552
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()
    assert isinstance(var_1, dict)

# Generated at 2022-06-24 23:56:58.092458
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    try:
        test_case_0()
    except Exception as Exception_instance:
        print('Exception: ' + str(Exception_instance))
    else:
        print('date_time fact collector runs successfully.')


if __name__ == '__main__':
    test_DateTimeFactCollector_collect()

# Generated at 2022-06-24 23:57:06.991092
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()

# Generated at 2022-06-24 23:57:17.690669
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Setup
    date_time_fact_collector = DateTimeFactCollector()
    # Setup

# Generated at 2022-06-24 23:57:49.197979
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    var = date_time_fact_collector.collect()

# vim: set filetype=python:

# Generated at 2022-06-24 23:57:53.943850
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()



# Generated at 2022-06-24 23:57:54.995578
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # No test necessary because all the data is static
    pass

# Generated at 2022-06-24 23:57:58.271908
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    # The var_0 is a dict
    # The var_0 is a dict



# Generated at 2022-06-24 23:58:05.257138
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    var_0 = DateTimeFactCollector()

# Generated at 2022-06-24 23:58:08.610452
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()

    assert var_1['date_time']['epoch_int'] == str(int(time.time()))
    assert var_1['date_time']['iso8601_basic_short'] == time.strftime("%Y%m%dT%H%M%S")



# Generated at 2022-06-24 23:58:18.027813
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()

# Generated at 2022-06-24 23:58:26.247270
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    facts_dict_0 = date_time_fact_collector_0.collect()
    var_0 = date_time_fact_collector_0.name
    # Can't test this method without running the collection.

if __name__ == "__main__":
    import inspect
    import pytest
    funcs = inspect.getmembers(sys.modules[__name__], inspect.isfunction)
    for func in funcs:
        if func[0].startswith("test_"):
            func[1]()

# Generated at 2022-06-24 23:58:33.817524
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Create an instance of DateTimeFactCollector
    # Assign the created instance to var_1
    var_1 = DateTimeFactCollector()
    # Act on the instance via method collect
    var_1 = var_1.collect()
    # Assert that the return value is a dict
    assert isinstance(var_1, dict)

# Generated at 2022-06-24 23:58:45.742195
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect(module=None, collected_facts=None)
    assert isinstance(var_0, dict) == True
    assert var_0['date_time']['iso8601'] == datetime.datetime.utcfromtimestamp(time.time()).strftime("%Y-%m-%dT%H:%M:%SZ")
    assert var_0['date_time']['tz_offset'] == time.strftime("%z")
    assert var_0['date_time']['month'] == datetime.datetime.fromtimestamp(time.time()).strftime('%m')
    assert var_0['date_time']['tz_dst']

# Generated at 2022-06-24 23:59:44.522849
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    print(var_0)


# Generated at 2022-06-24 23:59:53.047003
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # No need to test in Python 2.6 because the test cases are already
    # tested in Python 2.7 and 3.6
    if (2, 7, 0) < sys.version_info < (3, 0, 0):
        # Setup mock inputs
        date_time_fact_collector = DateTimeFactCollector()
        date_time_fact_collector.collect()
        # Verify the results
        assert date_time_fact_collector.collect() is not None

# Generated at 2022-06-24 23:59:55.296180
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()
    assert(True == True)



# Generated at 2022-06-25 00:00:01.888278
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # run the test for all the modes
    for mode in ("gather_subset", "gather_network_resources"):
        date_time_fact_collector_1 = DateTimeFactCollector()
        date_time_fact_collector_1.mode = mode
        date_time_fact_collector_1.collect()

# Generated at 2022-06-25 00:00:05.891682
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert var_0 is not False


# Generated at 2022-06-25 00:00:07.964523
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()

# Generated at 2022-06-25 00:00:17.122558
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    var = date_time_fact_collector.collect()
    assert 'epoch' in var['date_time']
    assert 'epoch_int' in var['date_time']
    assert 'time' in var['date_time']
    assert 'timezone' in var['date_time']
    assert 'tz' in var['date_time']
    assert 'tz_dst' in var['date_time']
    assert 'tz_offset' in var['date_time']
    assert 'weekday' in var['date_time']
    assert 'weekday_number' in var['date_time']
    assert 'weeknumber' in var['date_time']
    assert 'year' in var['date_time']

# Generated at 2022-06-25 00:00:27.169235
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()

# Generated at 2022-06-25 00:00:38.642047
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert 'date_time' in var_0
    assert 'day' in var_0['date_time']
    assert 'iso8601_basic' in var_0['date_time']
    assert 'iso8601_basic_short' in var_0['date_time']
    assert 'iso8601' in var_0['date_time']
    assert 'hour' in var_0['date_time']
    assert 'weekday' in var_0['date_time']
    assert 'weeknumber' in var_0['date_time']
    assert 'epoch_int' in var_0['date_time']

# Generated at 2022-06-25 00:00:48.266201
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    # Test case for Exception
    #raised: if date_time -> year cannot be found
    with pytest.raises(Exception) as e_2:
        date_time_fact_collector_0.collect()
        assert "Error while trying to retrieve the date_time -> year fact" in e_2.value
    # Test case for Exception
    #raised: if date_time -> month cannot be found
    with pytest.raises(Exception) as e_3:
        date_time_fact_collector_0.collect()
        assert "Error while trying to retrieve the date_time -> month fact" in e_3.value
    # Test case for Exception
    #raised: if date_time -> weekday cannot be found