

# Generated at 2022-06-24 23:52:33.359359
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()



# Generated at 2022-06-24 23:52:34.311741
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:52:39.397247
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    assert None is not date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:52:47.360369
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-24 23:52:55.793767
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Py 2.6 doesn't have assertIn()
    assert 'date_time' in DateTimeFactCollector().collect()
    assert 'year' in DateTimeFactCollector().collect()['date_time']
    assert 'month' in DateTimeFactCollector().collect()['date_time']
    assert 'weekday' in DateTimeFactCollector().collect()['date_time']
    assert 'weekday_number' in DateTimeFactCollector().collect()['date_time']
    assert 'weeknumber' in DateTimeFactCollector().collect()['date_time']
    assert 'day' in DateTimeFactCollector().collect()['date_time']
    assert 'hour' in DateTimeFactCollector().collect()['date_time']
    assert 'minute' in DateTimeFactCollector().collect()['date_time']

# Generated at 2022-06-24 23:52:59.360157
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Setup
    date_time_fact_collector = DateTimeFactCollector()
    module = None
    collected_facts = None

    # Test
    assert not date_time_fact_collector.collect(module, collected_facts)


# Generated at 2022-06-24 23:53:07.505670
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Set up a test object
    date_time_fact_collector = DateTimeFactCollector()

    # Call the method
    collected_facts = date_time_fact_collector.collect()

    # Check the results
    assert type(collected_facts) is dict, \
      'Expected dict but got %s' % type(collected_facts)
    assert 'date_time' in collected_facts, \
      'Expected \'date_time\' to be in collected facts but got %s' % collected_facts.keys()
    assert type(collected_facts['date_time']) is dict, \
      'Expected dict but got %s' % type(collected_facts['date_time'])

# Generated at 2022-06-24 23:53:17.590969
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    ret = date_time_fact_collector_1.collect()
    assert ret is not None
    assert 'date_time' in ret
    assert ret['date_time'] is not None
    assert 'second' in ret['date_time']
    assert ret['date_time']['second'] is not None
    assert 'time' in ret['date_time']
    assert ret['date_time']['time'] is not None
    assert 'weekday' in ret['date_time']
    assert ret['date_time']['weekday'] is not None
    assert 'iso8601' in ret['date_time']
    assert ret['date_time']['iso8601'] is not None
    assert 'year' in ret['date_time']

# Generated at 2022-06-24 23:53:21.734017
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    collected_facts = dict()
    result = date_time_fact_collector_0.collect()
    assert 'date_time' in result, \
        "Result did not have 'date_time' key"


# Generated at 2022-06-24 23:53:30.274400
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # Test no.0 - initial execution of method collect
    date_time_fact_collector_0 = DateTimeFactCollector()
    result = date_time_fact_collector_0.collect()
    assert result['date_time']['year'] == '2017'
    assert result['date_time']['month'] == '03'
    assert result['date_time']['hour'] == '13'
    assert result['date_time']['minute'] == '07'

# Generated at 2022-06-24 23:53:39.702898
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    output = date_time_fact_collector_1.collect()
    output_length = len(output)
    assert output_length > 0

# Generated at 2022-06-24 23:53:42.756919
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:53:51.705260
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    collected_facts_1 = dict()
    collected_facts_1['ansible_all_ipv4_addresses'] = ['192.168.1.16', '192.168.1.16', 'fe80::250:56ff:fe8e:1f27']
    collected_facts_1['ansible_all_ipv6_addresses'] = ['fe80::250:56ff:fe8e:1f27', 'fe80::250:56ff:fe8e:1f27', 'fe80::250:56ff:fe8e:1f27', 'fe80::250:56ff:fe8e:1f27']
    collected_facts_1['ansible_architecture'] = 'x86_64'
    collected_

# Generated at 2022-06-24 23:53:58.973943
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    fact_result_1 = date_time_fact_collector_1.collect()
    assert fact_result_1['date_time']['year'] == time.strftime('%Y')
    assert fact_result_1['date_time']['month'] == time.strftime('%m')
    assert fact_result_1['date_time']['weekday'] == time.strftime('%A')
    assert fact_result_1['date_time']['weekday_number'] == time.strftime('%w')
    assert fact_result_1['date_time']['weeknumber'] == time.strftime('%W')

# Generated at 2022-06-24 23:54:01.054042
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()



# Generated at 2022-06-24 23:54:10.493961
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_1 = DateTimeFactCollector()

    # Initialize facts
    facts = {}

    # Collect date_time facts from current module
    date_time_fact_collector_0.collect(module=None, collected_facts=facts)

    # Extract date_time facts
    date_time_facts = facts['date_time']
    if (date_time_fact_collector_0._fact_ids !=
            date_time_fact_collector_1._fact_ids):
        raise Exception("Fact IDs do not match")

if __name__ == "__main__":
    test_case_0()
    test_DateTimeFactCollector_collect()

# Generated at 2022-06-24 23:54:16.528211
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    result = dict()

    result['date_time'] = dict()

    current_time = datetime.datetime.now()

    result['date_time']['date'] = current_time.strftime('%Y-%m-%d')
    result['date_time']['hour'] = current_time.strftime('%H')
    result['date_time']['weekday'] = current_time.strftime('%A')
    result['date_time']['minute'] = current_time.strftime('%M')
    result['date_time']['time'] = current_time.strftime('%H:%M:%S')
    result['date_time']['day'] = current_time.strftime('%d')
    result['date_time']['iso8601'] = current_time

# Generated at 2022-06-24 23:54:19.617108
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector.collect()
    assert date_time_facts['date_time']['year']



# Generated at 2022-06-24 23:54:22.929449
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Make sure collect returns a dict
    date_time_fact_collector_1 = DateTimeFactCollector()
    assert(isinstance(date_time_fact_collector_1.collect(), dict))


# Generated at 2022-06-24 23:54:31.167712
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    ansible_facts_0 = dict()
    ansible_facts_0['ansible_system_vendor'] = 'VMware, Inc.'
    ansible_facts_0['ansible_processor_cores'] = 1
    ansible_facts_0['ansible_machine_id'] = 'uuid'
    ansible_facts_0['ansible_machine_id_short'] = 'uuid'
    ansible_facts_0['ansible_system'] = 'Linux'
    ansible_facts_0['ansible_processor_count'] = 1
    ansible_facts_0['ansible_processor_threads_per_core'] = 1
    ansible_facts_0['ansible_processor_vcpus'] = 1
    ansible

# Generated at 2022-06-24 23:54:44.968983
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Create an instance of class DateTimeFactCollector with default arguments
    date_time_fact_collector_0 = DateTimeFactCollector()

    # Check instance created successfully
    assert date_time_fact_collector_0 is not None

    # Invoke method collect on it
    date_time_fact_collector_0.collect()


#######
# Main
#######

# Unit test execution
if __name__ == '__main__':
    test_DateTimeFactCollector_collect()

# Generated at 2022-06-24 23:54:47.275490
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    assert date_time_fact_collector_1.collect() != None


# Generated at 2022-06-24 23:54:53.316249
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    # No parameters are required to invoke collect()
    date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:55:04.809127
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    test_case_0()

# Generated at 2022-06-24 23:55:16.501890
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    collected_facts = date_time_fact_collector.collect()
    assert 'date_time' in collected_facts
    assert 'year' in collected_facts['date_time']
    assert 'month' in collected_facts['date_time']
    assert 'weekday' in collected_facts['date_time']
    assert 'weekday_number' in collected_facts['date_time']
    assert 'weeknumber' in collected_facts['date_time']
    assert 'day' in collected_facts['date_time']
    assert 'hour' in collected_facts['date_time']
    assert 'minute' in collected_facts['date_time']
    assert 'second' in collected_facts['date_time']

# Generated at 2022-06-24 23:55:23.281973
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # Initialize the instance
    date_time_fact_collector_0 = DateTimeFactCollector()

    # Check if it return the expected facts
    assert date_time_fact_collector_0.collect() == filter(lambda x: x in date_time_fact_collector_0._fact_ids, date_time_fact_collector_0.collect())

# Generated at 2022-06-24 23:55:34.800870
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    facts_dict = date_time_fact_collector_0.collect()
    date_time = facts_dict['date_time']
    assert date_time['year'] == '2018'
    assert date_time['month'] == '07'
    assert date_time['weekday'] == 'Friday'
    assert date_time['weekday_number'] == '5'
    assert date_time['weeknumber'] == '28'
    assert date_time['day'] == '27'
    assert date_time['hour'] == '11'
    assert date_time['minute'] == '06'
    assert date_time['second'] == '50'
    assert date_time['epoch'] == '1532700210'

# Generated at 2022-06-24 23:55:44.549404
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Test DateTimeFactCollector collect"""
    # Setup the DateTimeFactCollector for the test.
    date_time_fact_collector_0 = DateTimeFactCollector()

    # Create empty dict for the return value of the collect method.
    collected_facts = {}

    # Call the collect method with empty dict.
    date_time_fact_collector_0.collect(collected_facts=collected_facts)

    # Check the output of the collect method matches the test case expectation(s).
    assert set(collected_facts.keys()) == set(['date_time'])
    assert 'date_time' in collected_facts

# Generated at 2022-06-24 23:55:47.008943
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collector = DateTimeFactCollector()
    collected_facts = collector.collect()
    assert 'date_time' in collected_facts

# Generated at 2022-06-24 23:55:52.338511
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # first test with a valid result from the module
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()
    # then test that the correct exception is raised if date cannot be
    # determined
    #date_time_fact_collector_0 = DateTimeFactCollector()
    #date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:56:19.818148
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector.collect()
    assert 'date_time' in date_time_facts
    assert 'year' in date_time_facts['date_time']
    assert 'month' in date_time_facts['date_time']
    assert 'weekday' in date_time_facts['date_time']
    assert 'weekday_number' in date_time_facts['date_time']
    assert 'weeknumber' in date_time_facts['date_time']
    assert 'day' in date_time_facts['date_time']
    assert 'hour' in date_time_facts['date_time']
    assert 'minute' in date_time_facts['date_time']
    assert 'second' in date_

# Generated at 2022-06-24 23:56:26.513303
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()

# Generated at 2022-06-24 23:56:36.047278
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_collect = DateTimeFactCollector()

# Generated at 2022-06-24 23:56:38.825080
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()


# Generated at 2022-06-24 23:56:44.238071
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    facts = date_time_fact_collector.collect()
    assert facts['date_time']['iso8601'] is not None
    assert facts['date_time']['tz_dst'] is not None
    assert facts['date_time']['weekday'] is not None
    assert facts['date_time']['year'] is not None
    assert facts['date_time']['weekday_number'] is not None

# Generated at 2022-06-24 23:56:52.572638
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    now = datetime.datetime.now()

# Generated at 2022-06-24 23:56:58.093408
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    result = date_time_fact_collector.collect()
    assert isinstance(result, dict)
    assert result['date_time']['year'] == '2018'
    assert result['date_time']['minute'] == '01'


# Generated at 2022-06-24 23:57:04.422289
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    collected_facts = {}
    collected_facts['default_date_time_formats'] = {}
    collected_facts['default_date_time_formats']['epoch'] = 1556221388
    date_time_fact_collector_0.collect(None, collected_facts)

# Generated at 2022-06-24 23:57:13.393809
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Get the object
    date_time_fact_collector_1 = DateTimeFactCollector()

    return_dict = {}
    return_dict = date_time_fact_collector_1.collect()

    if type(return_dict) != dict:
        raise AssertionError("The returned datatype is not a dictionary")
    elif len(return_dict) > 0:
        print(return_dict)
    else:
        raise AssertionError("The return dictionary is empty")

if __name__ == '__main__':
    test_case_0()
    test_DateTimeFactCollector_collect()

# Generated at 2022-06-24 23:57:16.661420
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    assert isinstance(date_time_fact_collector.collect(), dict)


# Generated at 2022-06-24 23:57:50.637759
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    result = date_time_fact_collector_0.collect()
    assert isinstance(result, dict)




# Generated at 2022-06-24 23:58:01.312020
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    date_time_fact_collector = DateTimeFactCollector()
    collected_facts = {}

# Generated at 2022-06-24 23:58:10.149969
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    assert isinstance(date_time_fact_collector_0.collect(), dict), 'Failed to create dict'
    assert isinstance(date_time_fact_collector_0.collect()['date_time'], dict), 'Failed to create dict'
    assert isinstance(date_time_fact_collector_0.collect()['date_time']['year'], str), 'Failed to create str'
    assert isinstance(date_time_fact_collector_0.collect()['date_time']['month'], str), 'Failed to create str'
    assert isinstance(date_time_fact_collector_0.collect()['date_time']['weekday'], str), 'Failed to create str'

# Generated at 2022-06-24 23:58:14.534021
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    result_dict_0 = date_time_fact_collector_0.collect()
    assert result_dict_0.get('date_time', [])
    assert result_dict_0['date_time'].get('hour', [])


# Generated at 2022-06-24 23:58:25.053005
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()

# Generated at 2022-06-24 23:58:25.484046
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    pass



# Generated at 2022-06-24 23:58:31.095826
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    facts_dict = date_time_fact_collector.collect()
    # Test that facts_dict['date_time']['iso8601_basic_short'] is not None
    assert facts_dict['date_time']['iso8601_basic_short'] is not None
    # Test that facts_dict['date_time']['iso8601_basic_short'] is a string
    assert isinstance(facts_dict['date_time']['iso8601_basic_short'], str)
    # Test that facts_dict['date_time']['iso8601_basic_short'] has a length other than zero
    assert len(facts_dict['date_time']['iso8601_basic_short']) > 0
    # Test that facts_dict

# Generated at 2022-06-24 23:58:34.952930
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()

# Generated at 2022-06-24 23:58:43.436465
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    epoch_ts = time.time()
    now = datetime.datetime.fromtimestamp(epoch_ts)
    utcnow = datetime.datetime.utcfromtimestamp(epoch_ts)

    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector_0.collect()

    assert date_time_facts.get('date_time').get('year') == now.strftime('%Y')


# Generated at 2022-06-24 23:58:50.524090
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector_0.collect()

    assert date_time_facts['date_time']['hour'] == time.strftime("%H")
    assert date_time_facts['date_time']['iso8601_micro'][:19] == time.strftime("%Y-%m-%dT%H:%M:%S")

# Generated at 2022-06-24 23:59:24.222934
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    f_0 = DateTimeFactCollector()
    f_0.collect()


# Generated at 2022-06-24 23:59:30.424806
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:59:34.411879
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert var_0['date_time']
    assert var_0 is not None


# Generated at 2022-06-24 23:59:41.579464
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # Setup
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_1 = DateTimeFactCollector()
    var_1.name = 'date_time'
    var_2 = None

    # Invocation
    var_3 = date_time_fact_collector_0.collect(module=var_1, collected_facts=var_2)

    # Checks

# Generated at 2022-06-24 23:59:43.627143
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:59:48.972557
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()

test_case_0()
test_DateTimeFactCollector_collect()

# Generated at 2022-06-24 23:59:49.793566
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # hmmm, no test case yet
    pass

# Generated at 2022-06-24 23:59:55.508131
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    time.strftime("%Z")
    time.tzname[1]
    time.strftime("%z")
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    var_1 = date_time_fact_collector_0.collect()
    assert var_0 == var_1


# Generated at 2022-06-24 23:59:57.159875
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible_collections.ansible.community.tests.unit.modules.network.nxos.facts.test_date_time_facts import test_case_0

    test_case_0()

# Generated at 2022-06-25 00:00:03.461247
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()

# Generated at 2022-06-25 00:01:25.835110
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()

# Generated at 2022-06-25 00:01:33.922049
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert var_0['date_time']['month'] == str(datetime.datetime.fromtimestamp(time.time()).strftime('%m'))
    assert var_0['date_time']['day'] == str(datetime.datetime.fromtimestamp(time.time()).strftime('%d'))
    assert var_0['date_time']['weekday_number'] == str(datetime.datetime.fromtimestamp(time.time()).strftime('%w'))

# Generated at 2022-06-25 00:01:40.238395
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()


# Generated at 2022-06-25 00:01:51.289748
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    epoch_ts_0 = float()
    now_0 = datetime.datetime(placeholder, placeholder, placeholder, placeholder, placeholder, placeholder, placeholder)
    utcnow_0 = datetime.datetime(placeholder, placeholder, placeholder, placeholder, placeholder, placeholder, placeholder)
    date_time_facts_0 = dict(placeholder=placeholder, placeholder=placeholder, placeholder=placeholder, placeholder=placeholder, placeholder=placeholder, placeholder=placeholder, placeholder=placeholder, placeholder=placeholder, placeholder=placeholder, placeholder=placeholder, placeholder=placeholder, placeholder=placeholder, placeholder=placeholder, placeholder=placeholder, placeholder=placeholder, placeholder=placeholder, placeholder=placeholder, placeholder=placeholder, placeholder=placeholder, placeholder=placeholder, placeholder=placeholder, placeholder=placeholder, placeholder=placeholder)
    facts_dict_

# Generated at 2022-06-25 00:01:57.251880
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    var_1 = date_time_fact_collector_0.collection_type
    assert var_1 == 'command'
    var_2 = date_time_fact_collector_0.name
    assert var_2 == 'date_time'
    var_3 = date_time_fact_collector_0.fact_ids
    assert var_3 == {'date_time'}
    var_4 = len(var_0)
    assert var_4 == 1
    var_5 = var_0.keys()
    assert 'date_time' in var_5

# Generated at 2022-06-25 00:01:58.688334
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    var_1 = DateTimeFactCollector.collect(DateTimeFactCollector())
    print(var_1)

# Generated at 2022-06-25 00:02:03.755564
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    assert callable(DateTimeFactCollector.collect)

# test of type DateTimeFactCollector

# Generated at 2022-06-25 00:02:11.060078
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    epoch_ts = time.time()

    date_time_fact_collector_obj = DateTimeFactCollector()
    date_time_fact_collector_obj.collect()
    assert date_time_fact_collector_obj._fact_ids == set(['date_time'])

    now = datetime.datetime.fromtimestamp(epoch_ts)
    utcnow = datetime.datetime.utcfromtimestamp(epoch_ts)
    # Asserting year
    assert str(date_time_fact_collector_obj.facts_dict['date_time']['year']).strip() == now.strftime('%Y').strip()
    # Asserting month

# Generated at 2022-06-25 00:02:12.978780
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()

# Generated at 2022-06-25 00:02:23.315158
# Unit test for method collect of class DateTimeFactCollector