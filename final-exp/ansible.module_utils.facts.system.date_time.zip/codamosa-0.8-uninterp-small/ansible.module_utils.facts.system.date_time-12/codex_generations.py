

# Generated at 2022-06-24 23:52:39.334752
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()

    results = date_time_fact_collector.collect()

# Generated at 2022-06-24 23:52:43.731597
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.collect() is not None


# Generated at 2022-06-24 23:52:54.140767
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()

    # Call the collect method of DateTimeFactCollector
    result_dict = date_time_fact_collector.collect()
    assert 'date_time' in result_dict
    assert result_dict['date_time']['year'] == datetime.datetime.now().strftime('%Y')
    assert result_dict['date_time']['month'] == datetime.datetime.now().strftime('%m')
    assert result_dict['date_time']['weekday'] == datetime.datetime.now().strftime('%A')
    assert result_dict['date_time']['weekday_number'] == datetime.datetime.now().strftime('%w')

# Generated at 2022-06-24 23:52:56.002157
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.collect() is not None

# Generated at 2022-06-24 23:52:57.337234
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:52:58.744998
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()

    date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:53:03.556966
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_collect = DateTimeFactCollector()
    date_time_fact_collector_config_dict = {}
    date_time_fact_collector_collect.collect(date_time_fact_collector_config_dict)

# Generated at 2022-06-24 23:53:06.173256
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    try:
        assert isinstance(DateTimeFactCollector().collect(), dict)
    except:
        assert False, 'DateTimeFactCollector collect test failed.'
    else:
        assert True, 'DateTimeFactCollector collect test passed.'

# Generated at 2022-06-24 23:53:17.508634
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector.collect()
    assert 'date_time' in date_time_facts
    assert 'year' in date_time_facts['date_time']
    assert 'month' in date_time_facts['date_time']
    assert 'weekday' in date_time_facts['date_time']
    assert 'weekday_number' in date_time_facts['date_time']
    assert 'weeknumber' in date_time_facts['date_time']
    assert 'day' in date_time_facts['date_time']
    assert 'hour' in date_time_facts['date_time']
    assert 'minute' in date_time_facts['date_time']
    assert 'second' in date_

# Generated at 2022-06-24 23:53:23.260648
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-24 23:53:32.233517
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # no argument supplied
    ansible_module = AnsibleModule(argument_spec={})
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.collect(module=ansible_module, collected_facts={}, **{}) is not None

    # argument supplied
    ansible_module = AnsibleModule(argument_spec={})
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.collect(
        module=ansible_module, collected_facts={}, **{'a': 1}) is not None

    # test if the facts match the values set in the date_time_fact_collector
    ansible_module = AnsibleModule(argument_spec={})
    date_time_fact_collector = DateTimeFactCollector

# Generated at 2022-06-24 23:53:38.020139
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fd_datetime = datetime.datetime.utcnow()
    fd_datetime_plus10 = fd_datetime + datetime.timedelta(minutes=10)
    fd_datetime_minus10 = fd_datetime - datetime.timedelta(minutes=10)
    fd_datetime_plus30 = fd_datetime + datetime.timedelta(minutes=30)

    DateTimeFactCollector().collect()
    assert DateTimeFactCollector().get_epoch() == str(int(time.time()))

    assert fd_datetime_plus10 > DateTimeFactCollector().get_iso8601()
    assert fd_datetime_minus10 < DateTimeFactCollector().get_iso8601()

    assert fd_datetime_plus30 > Date

# Generated at 2022-06-24 23:53:48.333188
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()

# Generated at 2022-06-24 23:53:58.229478
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    current_timestamp = time.time()
    date_time_collector = DateTimeFactCollector()
    date_time_facts = date_time_collector.collect()
    assert date_time_facts.get('date_time', None), "Invalid date_time facts"
    assert len(date_time_facts.get('date_time', None)) != 0, "Date_time facts len is zero"
    assert date_time_facts.get('date_time').get('hour', None), "Invalid hour in date_time facts"
    assert date_time_facts.get('date_time').get('minute', None), "Invalid minute in date_time facts"
    assert date_time_facts.get('date_time').get('tz', None), "Invalid time zone in date_time facts"

# Generated at 2022-06-24 23:54:06.478294
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_facts_dictionary = date_time_fact_collector_0.collect()
    assert 'date_time' in date_time_facts_dictionary.keys()
    assert 'date' in date_time_facts_dictionary['date_time'].keys()
    assert 'time' in date_time_facts_dictionary['date_time'].keys()
    assert 'year' in date_time_facts_dictionary['date_time'].keys()
    assert 'month' in date_time_facts_dictionary['date_time'].keys()
    assert 'day' in date_time_facts_dictionary['date_time'].keys()
    assert 'hour' in date_time_facts_dictionary['date_time'].keys

# Generated at 2022-06-24 23:54:09.927542
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    assert isinstance(date_time_fact_collector_0.collect(), dict) == True

# Generated at 2022-06-24 23:54:12.705678
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    collected_facts = {}
    date_time_fact_collector_1.collect(collected_facts=collected_facts)
    return collected_facts

# Generated at 2022-06-24 23:54:16.207839
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:54:18.115401
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    assert type(date_time_fact_collector.collect()) == dict

# Generated at 2022-06-24 23:54:27.541324
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    epoch_ts_0 = time.time()
    now_0 = datetime.datetime.fromtimestamp(epoch_ts_0)
    utcnow_0 = datetime.datetime.utcfromtimestamp(epoch_ts_0)
    date_time_facts_0 = {}
    date_time_facts_0['year'] = now_0.strftime('%Y')
    date_time_facts_0['month'] = now_0.strftime('%m')
    date_time_facts_0['weekday'] = now_0.strftime('%A')
    date_time_facts_0['weekday_number'] = now_0.strftime('%w')

# Generated at 2022-06-24 23:54:38.501337
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:54:41.276699
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    assert date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:54:51.093279
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()

    #Test with no valid inputs
    collected_facts_0 = {}
    #Call the method
    actual_results_0 = date_time_fact_collector_0.collect(collected_facts_0)
    #Check results
    assert actual_results_0['date_time']['hour'] == '19'
    assert actual_results_0['date_time']['day'] == '04'
    assert actual_results_0['date_time']['time'] == '19:46:14'
    assert actual_results_0['date_time']['iso8601_micro'] == '2017-05-04T19:46:14.444501Z'

# Generated at 2022-06-24 23:54:58.040541
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Instantiate a DateTimeFactCollector object
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector_result = date_time_fact_collector.collect()
    # Check that the resulting facts_dict contains the date_time key
    assert 'date_time' in date_time_fact_collector_result

# Generated at 2022-06-24 23:55:06.649281
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-24 23:55:12.283920
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector_collect = date_time_fact_collector.collect()

    assert date_time_fact_collector_collect['date_time']['year'].__class__.__name__ == 'str', \
        "date_time_fact_collector_collect['date_time']['year'] is not of type 'str'"

    assert date_time_fact_collector_collect['date_time']['month'].__class__.__name__ == 'str', \
        "date_time_fact_collector_collect['date_time']['month'] is not of type 'str'"

    assert date_time_fact_collector_collect['date_time']['weekday'].__class__.__name__

# Generated at 2022-06-24 23:55:14.630780
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()

# Unit test For method get_fact_names of class DateTimeFactCollector

# Generated at 2022-06-24 23:55:23.045280
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector_result = date_time_fact_collector.collect()

    assert type(date_time_fact_collector_result) == dict
    assert type(date_time_fact_collector_result['date_time']) == dict
    assert type(date_time_fact_collector_result['date_time']['year']) == str
    assert type(date_time_fact_collector_result['date_time']['month']) == str
    assert type(date_time_fact_collector_result['date_time']['weekday']) == str
    assert type(date_time_fact_collector_result['date_time']['weekday_number']) == str

# Generated at 2022-06-24 23:55:28.991858
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_facts_0 = date_time_fact_collector_0.collect()
    assert 'date_time' in date_time_facts_0
    assert 'year' in date_time_facts_0['date_time']
    assert 'month' in date_time_facts_0['date_time']
    assert 'weekday' in date_time_facts_0['date_time']
    assert 'weekday_number' in date_time_facts_0['date_time']
    assert 'weeknumber' in date_time_facts_0['date_time']
    assert 'day' in date_time_facts_0['date_time']
    assert 'hour' in date_time_facts_0['date_time']

# Generated at 2022-06-24 23:55:36.445185
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()

    date_time_facts = date_time_fact_collector.collect()

    # Check the facts collected are in-fact of type dict
    assert isinstance(date_time_facts, dict)

    # Check the facts collected are not empty
    assert bool(date_time_facts) is True

    # Check the facts collected are not empty
    assert bool(date_time_facts) is True

    # Check the facts collected are not empty
    assert bool(date_time_facts) is True

# Generated at 2022-06-24 23:55:55.202850
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:56:02.185568
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()

    collected_facts_0 = date_time_fact_collector_0.collect()
    assert date_time_fact_collector_0._fact_ids == set([])
    assert collected_facts_0['date_time'] == {}

# Generated at 2022-06-24 23:56:04.135741
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    result = date_time_fact_collector.collect()
    assert isinstance(result, dict)

# Generated at 2022-06-24 23:56:08.122240
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector.collect()


# Generated at 2022-06-24 23:56:14.586952
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    collected_facts_1 = date_time_fact_collector_1.collect(collected_facts={})
    assert collected_facts_1.get('date_time')


# Note: This unit test is for module import code path only,
#       it does not actually test the fact module.

# Generated at 2022-06-24 23:56:25.060407
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    facts_dict = date_time_fact_collector_0.collect()
    assert "date_time" in facts_dict
    assert "epoch_int" in facts_dict["date_time"]
    assert "time" in facts_dict["date_time"]
    assert "weekday_number" in facts_dict["date_time"]
    assert "hour" in facts_dict["date_time"]
    assert "iso8601_basic" in facts_dict["date_time"]
    assert "date" in facts_dict["date_time"]
    assert "year" in facts_dict["date_time"]
    assert "second" in facts_dict["date_time"]
    assert "weekday" in facts_dict["date_time"]

# Generated at 2022-06-24 23:56:28.312694
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()

    collected_facts_1 = {}

    collected_facts_1 = date_time_fact_collector_1.collect(None, collected_facts_1)

    assert collected_facts_1.get("date_time", None) is not None

# Generated at 2022-06-24 23:56:39.734481
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    facts = DateTimeFactCollector().collect()
    assert facts['date_time']['year'] == time.strftime("%Y")
    assert facts['date_time']['month'] == time.strftime("%m")
    assert facts['date_time']['weekday'] == time.strftime("%A")
    assert facts['date_time']['weekday_number'] == time.strftime("%w")
    assert facts['date_time']['weeknumber'] == time.strftime("%W")
    assert facts['date_time']['day'] == time.strftime("%d")
    assert facts['date_time']['hour'] == time.strftime("%H")
    assert facts['date_time']['minute'] == time.strftime("%M")

# Generated at 2022-06-24 23:56:47.994993
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    output = date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:56:55.506456
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_2 = DateTimeFactCollector()
    collected_facts_2 = dict()
    collected_facts_2['ansible_date_time'] = dict()
    collected_facts_2['ansible_date_time']['tz'] = 'CEST'
    collected_facts_2['ansible_date_time']['weekday_number'] = '6'
    collected_facts_2['ansible_date_time']['day'] = '29'
    collected_facts_2['ansible_date_time']['hour'] = '21'
    collected_facts_2['ansible_date_time']['iso8601_basic'] = '20170929T213406363065'

# Generated at 2022-06-24 23:57:30.490316
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:57:37.064672
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_facts_dict_1 = {}
    date_time_facts_dict_1 = date_time_fact_collector_1.collect()
    assert type(date_time_facts_dict_1) is dict
    assert 'date_time' in date_time_facts_dict_1
    assert type(date_time_facts_dict_1['date_time']) is dict
    assert 'year' in date_time_facts_dict_1['date_time']
    assert type(date_time_facts_dict_1['date_time']['year']) is str
    assert 'month' in date_time_facts_dict_1['date_time']

# Generated at 2022-06-24 23:57:41.962470
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector.collect()
    assert date_time_facts['date_time']['date'] == time.strftime("%Y-%m-%d")

# Generated at 2022-06-24 23:57:43.453004
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()

# Generated at 2022-06-24 23:57:49.789778
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()

# Generated at 2022-06-24 23:57:54.193965
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector.collect()


# Generated at 2022-06-24 23:58:02.718911
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    ap = DateTimeFactCollector()

# Generated at 2022-06-24 23:58:03.645169
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    dtfc.collect()

# Generated at 2022-06-24 23:58:05.259598
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import inspect
    method = inspect.getmember(DateTimeFactCollector, 'collect')
    assert len(inspect.getargspec(method).args) == 2

# Generated at 2022-06-24 23:58:06.647322
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:59:16.370868
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    result = date_time_fact_collector.collect(module=None, collected_facts=None)
    assert result is not None

# Generated at 2022-06-24 23:59:24.945921
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    collected_facts = {}
    collected_facts = date_time_fact_collector_1.collect(collected_facts=collected_facts)
    collected_date_time_facts = collected_facts['date_time']
    assert(collected_date_time_facts.get('year') is not None)
    assert(collected_date_time_facts.get('month') is not None)
    assert(collected_date_time_facts.get('weekday') is not None)
    assert(collected_date_time_facts.get('weekday_number') is not None)
    assert(collected_date_time_facts.get('weeknumber') is not None)

# Generated at 2022-06-24 23:59:27.212905
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    collected_facts = dict()
    date_time_fact_collector_1.collect(collected_facts=collected_facts)


# Generated at 2022-06-24 23:59:31.074336
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector.collect()
    assert date_time_fact_collector is not None


# Generated at 2022-06-24 23:59:33.849834
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    assert 0 == 0

if __name__ == '__main__':
    pytest.main([__file__])

# Generated at 2022-06-24 23:59:41.180623
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    return_data = date_time_fact_collector.collect()
    assert return_data['date_time']['month'] == datetime.datetime.today().strftime("%m")
    assert return_data['date_time']['weekday'] == datetime.datetime.today().strftime("%A")
    assert return_data['date_time']['tz'] == datetime.datetime.today().strftime("%Z")

# Generated at 2022-06-24 23:59:44.104149
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector.collect()
    assert len(date_time_facts) == 1
    assert type(date_time_facts['date_time']) == dict

# Generated at 2022-06-24 23:59:48.073687
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    cc = DateTimeFactCollector()
    assert cc.collect()

# Generated at 2022-06-24 23:59:54.904788
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()

    list_0 = []

    dict_0 = dict()
    dict_0['date_time'] = dict()
    dict0_0 = dict()
    dict0_1 = dict()
    dict0_2 = dict()
    dict0_3 = dict()
    dict0_4 = dict()
    dict0_5 = dict()
    dict0_6 = dict()
    dict0_7 = dict()
    dict0_8 = dict()
    dict0_9 = dict()
    dict0_10 = dict()
    dict0_11 = dict()
    dict0_12 = dict()
    dict0_13 = dict()
    dict0_14 = dict()
    dict0_15 = dict()
    dict0_16 = dict()

# Generated at 2022-06-25 00:00:00.609359
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    result = date_time_fact_collector_0.collect()
    assert result != {}

# Generated at 2022-06-25 00:01:31.653258
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()

    assert var_0['date_time']['day'] == '01'
    assert var_0['date_time']['date'] == '2018-02-01'
    assert var_0['date_time']['time'] == '00:00:00'
    assert var_0['date_time']['weekday'] == 'Thursday'
    assert var_0['date_time']['epoch'] == str(int(time.time()))
    assert var_0['date_time']['epoch_int'] == str(int(time.time()))
    assert var_0['date_time']['weeknumber'] == '05'

# Generated at 2022-06-25 00:01:40.192394
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert var_0['date_time']['day'] is not None
    assert var_0['date_time']['iso8601'] is not None
    assert var_0['date_time']['tz_offset'] is not None
    assert var_0['date_time']['time'] is not None
    assert var_0['date_time']['iso8601_micro'] is not None
    assert var_0['date_time']['epoch'] is not None
    assert var_0['date_time']['iso8601_basic_short'] is not None
    assert var_0['date_time']['epoch_int'] is not None

# Generated at 2022-06-25 00:01:41.393717
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    assert isinstance(DateTimeFactCollector().collect(), dict)

# Generated at 2022-06-25 00:01:46.379653
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    assert date_time_fact_collector_0.collect() is not None



# Generated at 2022-06-25 00:01:48.326232
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_1.collect()

# Generated at 2022-06-25 00:01:56.743858
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()

# Generated at 2022-06-25 00:02:07.377658
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    print('')
    print('Test DateTimeFactCollector::collect')
    import datetime
    import time
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import DateTimeFactCollector

    # Test with default data
    # Test with None as argument
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    # Test with normal data
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()

if __name__ == "__main__":
    test_case_0()
    # test_DateTimeFactCollector_collect()

# Generated at 2022-06-25 00:02:10.760109
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    var = date_time_fact_collector.collect()

# Generated at 2022-06-25 00:02:13.478898
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    some_instance_of_DateTimeFactCollector = DateTimeFactCollector()
    # call the method under test
    some_instance_of_DateTimeFactCollector.collect()



# Generated at 2022-06-25 00:02:18.030854
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # SystemUnderTest - type: DateTimeFactCollector
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()
    # AssertionError: <KeyError: 'date_time'>
