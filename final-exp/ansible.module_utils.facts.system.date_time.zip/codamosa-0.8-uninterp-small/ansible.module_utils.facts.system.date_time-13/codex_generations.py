

# Generated at 2022-06-24 23:52:39.307629
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    ret = date_time_fact_collector_1.collect()

# Generated at 2022-06-24 23:52:44.627467
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    module_1 = None
    collected_facts_1 = None
    try:
        assert isinstance(date_time_fact_collector_1.collect(module_1, collected_facts_1), dict)
    except AssertionError:
        raise



# Generated at 2022-06-24 23:52:54.836746
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1_collect = date_time_fact_collector_1.collect()
    assert date_time_fact_collector_1_collect.keys() == ['date_time']
    assert date_time_fact_collector_1_collect['date_time'].keys() == ['year', 'month', 'weekday', 'weekday_number', 'weeknumber', 'day', 'hour', 'minute', 'second', 'epoch', 'epoch_int', 'date', 'time', 'iso8601_micro', 'iso8601', 'iso8601_basic', 'iso8601_basic_short', 'tz', 'tz_dst', 'tz_offset']
    # assert date_time_fact_collector_1_

# Generated at 2022-06-24 23:53:05.566798
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()

# Generated at 2022-06-24 23:53:17.452219
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_dict_0 = date_time_fact_collector_0.collect()
    assert 'date_time' in date_time_fact_dict_0.keys()
    date_time_fact_dict_1 = date_time_fact_dict_0['date_time']
    assert 'year' in date_time_fact_dict_1.keys()
    assert 'month' in date_time_fact_dict_1.keys()
    assert 'weekday' in date_time_fact_dict_1.keys()
    assert 'weekday_number' in date_time_fact_dict_1.keys()
    assert 'weeknumber' in date_time_fact_dict_1.keys()
    assert 'day' in date_

# Generated at 2022-06-24 23:53:27.980825
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    ntp_server_0 = {'peer_resolution_status': 'unsynchronized', 'synchronized': False, 'root_delay': 0.0, 'root_dispersion': 0.0, 'offset': 0.0, 'stratum': '0', 'reference_id': '', 'type': '', 'precision': 0, 'max_error': 0.0, 'state': 'unsynchronized', 'poll': 0, 'reach': 0, 'last_update': 0.0, 'leap': 'notinuse', 'offset_precision': 0.0}
    # Call method collect of date_time_fact_collector_0

# Generated at 2022-06-24 23:53:37.534371
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    facts_dict_1 = {}
    date_time_fact_collector_1.collect(None, facts_dict_1)
    assert 'date_time' in facts_dict_1.keys()
    date_time_facts_1 = facts_dict_1['date_time']
    assert 'year' in date_time_facts_1.keys()
    assert 'month' in date_time_facts_1.keys()
    assert 'weekday' in date_time_facts_1.keys()
    assert 'weekday_number' in date_time_facts_1.keys()
    assert 'weeknumber' in date_time_facts_1.keys()
    assert 'day' in date_time_facts_1.keys()

# Generated at 2022-06-24 23:53:47.910102
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()

# Generated at 2022-06-24 23:53:51.981099
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector.collect()

# Generated at 2022-06-24 23:53:53.992696
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector.collect()



# Generated at 2022-06-24 23:54:00.198159
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector_1.collect()
    print(date_time_facts)


# Generated at 2022-06-24 23:54:10.647107
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()

# Generated at 2022-06-24 23:54:12.500908
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:54:23.834895
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    assert date_time_fact_collector_1.collect(None, None)['date_time']['epoch'] == str(int(time.time()))
    assert date_time_fact_collector_1.collect(None, None)['date_time']['epoch_int'] == str(int(time.time()))
    assert date_time_fact_collector_1.collect(None, None)['date_time']['date'] == datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d')

# Generated at 2022-06-24 23:54:25.852723
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    result = date_time_fact_collector.collect()
    assert type(result) == dict


# Generated at 2022-06-24 23:54:26.751962
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # No code for this method yet
    return

# Generated at 2022-06-24 23:54:34.957030
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    assert(date_time_fact_collector_1 is not None)
    epoch_ts = time.time()
    now = datetime.datetime.fromtimestamp(epoch_ts)
    utcnow = datetime.datetime.utcfromtimestamp(epoch_ts)

    # is_valid should be set as None if there is no error in collect method
    is_valid = None

# Generated at 2022-06-24 23:54:41.276227
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0_collect = date_time_fact_collector_0.collect()
    print(date_time_fact_collector_0_collect)
    assert True


if __name__ == '__main__':
    test_case_0()
    test_DateTimeFactCollector_collect()

# Generated at 2022-06-24 23:54:51.092554
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    result_dict = date_time_fact_collector_0.collect()
    assert result_dict['date_time']['iso8601_basic'] is not None
    assert result_dict['date_time']['tz'] is not None
    assert result_dict['date_time']['date'] is not None
    assert result_dict['date_time']['iso8601_basic_short'] is not None
    assert result_dict['date_time']['iso8601_micro'] is not None
    assert result_dict['date_time']['time'] is not None
    assert result_dict['date_time']['iso8601'] is not None
    assert result_dict['date_time']['month'] is not None
   

# Generated at 2022-06-24 23:54:55.419808
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    output = date_time_fact_collector.collect()
    result = type(output)
    assert result is dict, "Expected:<class 'dict'> but got:<%s>" % result
    result = len(output.keys())
    assert result == 1, "Expected:<1> but got:<%s>" % result
    result = output['date_time']
    assert result is not None, "Expected:<NOT_NONE> but got:<%s>" % result

# Generated at 2022-06-24 23:55:04.431319
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert isinstance(var_0, dict)
    var_1 = date_time_fact_collector_0.collect()
    assert var_1['date_time']['month'] == '06'


# Generated at 2022-06-24 23:55:06.637313
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    assert True

# Create instance of class DateTimeFactCollector
date_time_fact_collector_fixture = DateTimeFactCollector()




# Generated at 2022-06-24 23:55:08.684414
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # No test implemented for version 1.9
    return

# Generated at 2022-06-24 23:55:11.857212
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()



# Generated at 2022-06-24 23:55:20.368526
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:55:23.581655
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:55:26.374174
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Invoke method
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:55:38.585522
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible_collections.ansible.community.plugins.module_utils.facts.collectors.date_time.date_time_collector import DateTimeFactCollector
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert isinstance(var_0, dict)
    assert 'date_time' in var_0
    assert isinstance(var_0['date_time'], dict)
    assert 'second' in var_0['date_time']
    assert isinstance(var_0['date_time']['second'], str)
    assert len(var_0['date_time']['second']) == 2
    assert 'month' in var_0['date_time']

# Generated at 2022-06-24 23:55:40.960545
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:55:47.689543
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()
    assert var_1['date_time']['tz'] == 'IST'
    assert var_1['date_time']['weeknumber'] == '20'
    assert var_1['date_time']['tz_offset'] == '+0530'
    assert var_1['date_time']['weekday'] == 'Wednesday'
    assert var_1['date_time']['second'] == '35'
    assert var_1['date_time']['iso8601_micro'] == '2020-05-20T12:35:35.986654Z'
    assert var_1['date_time']['day'] == '20'
    assert var

# Generated at 2022-06-24 23:55:52.653570
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    assert True


# Generated at 2022-06-24 23:56:01.240869
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:56:07.942418
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    epoch_ts = time.time()
    now = datetime.datetime.fromtimestamp(epoch_ts)
    utcnow = datetime.datetime.utcfromtimestamp(epoch_ts)
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert var_0['date_time']['year'] == now.strftime('%Y')
    assert var_0['date_time']['month'] == now.strftime('%m')
    assert var_0['date_time']['weekday'] == now.strftime('%A')
    assert var_0['date_time']['weekday_number'] == now.strftime('%w')

# Generated at 2022-06-24 23:56:19.536828
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-24 23:56:26.476014
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert(var_0['date_time']['iso8601'] != '')
    assert(var_0['date_time']['iso8601_micro'] != '')
    assert(var_0['date_time']['iso8601_basic'] != '')
    assert(var_0['date_time']['iso8601_basic_short'] != '')
    assert(var_0['date_time']['tz_dst'] != '')
    assert(var_0['date_time']['year'] != '')
    assert(var_0['date_time']['time'] != '')

# Generated at 2022-06-24 23:56:28.847159
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert var_0 is not None


# Generated at 2022-06-24 23:56:30.300811
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_0.collect()
    # var_1 is a dict
    assert type(var_1) == dict



# Generated at 2022-06-24 23:56:31.990700
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert var_0 != None


# Test case for DateTimeFactCollector

# Generated at 2022-06-24 23:56:32.791879
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    assert True

# Generated at 2022-06-24 23:56:35.053441
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    var = date_time_fact_collector.collect()
    assert isinstance(var, dict)

# Generated at 2022-06-24 23:56:45.653173
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    # date_time = date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:56:47.912141
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    # TODO: add test case for method collect
    #date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:56:55.450185
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    result = date_time_fact_collector_0.collect()
    assert result is not None
    assert len(result['date_time']) > 0
    assert result['date_time']['year'] is not None
    assert result['date_time']['month'] is not None
    assert result['date_time']['day'] is not None
    assert result['date_time']['weekday'] is not None
    assert result['date_time']['weekday_number'] is not None
    assert result['date_time']['weeknumber'] is not None
    assert result['date_time']['date'] is not None
    assert result['date_time']['hour'] is not None

# Generated at 2022-06-24 23:56:56.696216
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:56:58.270556
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert var_0['date_time']['tz_offset'] == '+0000'

# Generated at 2022-06-24 23:57:00.314487
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:57:02.368907
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    assert date_time_fact_collector_1.collect(), "Fun fact: it fails"

# Generated at 2022-06-24 23:57:06.564884
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    var = date_time_fact_collector.collect()
    assert(type(var) == type({'date_time': {}}))


# Generated at 2022-06-24 23:57:17.281991
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts.collector import DateTimeFactCollector
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_0.collect()
    assert var_1[u'date_time'][u'weeknumber'] == '02'
    assert var_1[u'date_time'][u'weekday_number'] == '0'
    assert var_1[u'date_time'][u'day'] == '08'
    assert var_1[u'date_time'][u'year'] == '2018'
    assert var_1[u'date_time'][u'time'] == '22:01:46'

# Generated at 2022-06-24 23:57:19.328749
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:57:37.346397
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:57:45.625128
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_facts_0 = DateTimeFactCollector().collect()
    assert date_time_facts_0['date_time']['year'] == '2018'
    assert date_time_facts_0['date_time']['month'] == '11'
    assert date_time_facts_0['date_time']['weekday'] == 'Wednesday'
    assert date_time_facts_0['date_time']['weekday_number'] == '3'
    assert date_time_facts_0['date_time']['day'] == '07'
    assert date_time_facts_0['date_time']['hour'] == '16'
    assert date_time_facts_0['date_time']['second'] == '46'

# Generated at 2022-06-24 23:57:54.460153
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert var_0 is not None
    assert type(var_0) is dict

# Generated at 2022-06-24 23:57:56.259764
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # all cases
    test_case_0()


test_DateTimeFactCollector_collect()

# Generated at 2022-06-24 23:58:04.020695
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Parameters
    date_time_fact_collector = DateTimeFactCollector()
    var = date_time_fact_collector.collect()

# Generated at 2022-06-24 23:58:08.508644
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:58:11.862594
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_case_0()


if __name__ == '__main__':
    test_DateTimeFactCollector_collect()

# Generated at 2022-06-24 23:58:15.343019
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    var = DateTimeFactCollector()
    var.collect()


if __name__ == "__main__":
    test_case_0()
    # Unit test for method collect of class DateTimeFactCollector
    test_DateTimeFactCollector_collect()

# Generated at 2022-06-24 23:58:25.104658
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    datetimestamp_var = datetime.datetime.now()
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:58:30.776021
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.name = 'date_time'
    date_time_fact_collector_1._fact_ids = set()
    var_1 = date_time_fact_collector_1.collect()

    assert var_1['date_time']['year'] == datetime.datetime.utcnow().strftime('%Y')
    assert var_1['date_time']['month'] == datetime.datetime.utcnow().strftime('%m')
    assert var_1['date_time']['weekday'] == datetime.datetime.utcnow().strftime('%A')
    assert var_1['date_time']['weekday_number'] == datetime.datetime.ut

# Generated at 2022-06-24 23:59:06.517654
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()


# Generated at 2022-06-24 23:59:09.466043
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_0.collect()
    assert 'date_time' in var_1

# Generated at 2022-06-24 23:59:17.148720
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    # check if the result is well formatted
    if len(date_time_fact_collector.collect()) != 1:
        return False
    # check key name
    if not date_time_fact_collector.collect().has_key('date_time'):
        return False

    return True

# Generated at 2022-06-24 23:59:25.538326
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # A few test cases
    # We should capture all assertions in these, but not other operations.
    var = DateTimeFactCollector()

# Generated at 2022-06-24 23:59:29.741282
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # initialize the object
    test_obj = DateTimeFactCollector()
    # execute method collect of the object
    ret_val = test_obj.collect()
    assert ret_val is not None

# Generated at 2022-06-24 23:59:32.407483
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:59:35.598961
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()

    assert isinstance(var_1, dict)

# Generated at 2022-06-24 23:59:43.569918
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert type(var_0) == dict
    assert var_0.get('date_time')['.version'] == '1.0'
    assert type(var_0.get('date_time')['date']) == str
    assert type(var_0.get('date_time')['day']) == str
    assert type(var_0.get('date_time')['epoch']) == str
    assert var_0.get('date_time')['epoch'].isdigit() == True
    assert type(var_0.get('date_time')['epoch_int']) == str

# Generated at 2022-06-24 23:59:48.295967
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()
    assert True

# Generated at 2022-06-24 23:59:49.729051
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collector = DateTimeFactCollector()
    assert 'epoch_int' in collector.collect()['date_time']

# Generated at 2022-06-25 00:01:09.164851
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    var = date_time_fact_collector.collect()
    assert isinstance(var, dict)


# Generated at 2022-06-25 00:01:20.106647
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()

    from datetime import datetime
    from datetime import timedelta
    # import pytz

    if date_time_fact_collector_0.is_old_facts_format(collected_facts=dict(ansible_local=dict(date_time=datetime.now()))):
        date_time_fact_collector_0.collect(collected_facts=dict(ansible_local=dict(date_time=datetime.now())))
    else:
        date_time_fact_collector_0.collect(collected_facts=dict(date_time=dict(facts=datetime.now())))


# Generated at 2022-06-25 00:01:22.482042
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()


# Generated at 2022-06-25 00:01:31.896097
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()

# Generated at 2022-06-25 00:01:40.421829
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert (var_0['date_time']['year'] == datetime.date.today().year)
    assert (var_0['date_time']['month'] == datetime.date.today().month)
    assert (var_0['date_time']['weekday'] == datetime.date.today().strftime('%A'))
    assert (var_0['date_time']['weekday_number'] == datetime.date.today().strftime('%w'))
    assert (var_0['date_time']['weeknumber'] == datetime.date.today().strftime('%W'))

# Generated at 2022-06-25 00:01:41.315712
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:01:46.379937
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()


# Generated at 2022-06-25 00:01:53.872999
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()

# Generated at 2022-06-25 00:02:04.815031
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    # var_0 = date_time_fact_collector_0.collect(module=None, collected_facts=None)

    assert 'date_time' in var_0
    assert 'year' in var_0['date_time']
    assert 'month' in var_0['date_time']
    assert 'weekday' in var_0['date_time']
    assert 'weekday_number' in var_0['date_time']
    assert 'weeknumber' in var_0['date_time']
    assert 'day' in var_0['date_time']
    assert 'hour' in var_0['date_time']
    assert 'minute' in var_0

# Generated at 2022-06-25 00:02:11.606475
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_0.collect()