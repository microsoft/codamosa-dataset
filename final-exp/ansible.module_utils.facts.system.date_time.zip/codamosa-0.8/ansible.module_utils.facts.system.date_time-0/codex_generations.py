

# Generated at 2022-06-11 04:28:24.807931
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    facts_dict = date_time_fact_collector.collect()
    assert facts_dict.get('date_time') is not None
    assert facts_dict['date_time'].get('year') is not None
    assert facts_dict['date_time'].get('weekday') is not None
    assert facts_dict['date_time'].get('epoch') is not None
    assert facts_dict['date_time'].get('epoch_int') is not None
    assert facts_dict['date_time'].get('date') is not None
    assert facts_dict['date_time'].get('time') is not None
    assert facts_dict['date_time'].get('iso8601_micro') is not None

# Generated at 2022-06-11 04:28:33.613192
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collector = DateTimeFactCollector()
    result = collector.collect()
    expected = ('2019', '12', 'Sunday', '0', '50', '01', '1577681384.92633',
                '1577681384', '1577681384', '2020-01-01', '21:23:04',
                '2020-01-01T21:23:04.926330Z', '2020-01-01T21:23:04Z',
                '20200101T212304926330', '20200101T212304926', 'Chile Standard Time',
                'Chile Summer Time', '-0300')
    assert result['date_time']['year'] == expected[0]
    assert result['date_time']['month'] == expected[1]

# Generated at 2022-06-11 04:28:45.142924
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    utcnow = datetime.datetime.utcnow()
    utc_ts = time.mktime(utcnow.timetuple())
    date_time_facts = DateTimeFactCollector().collect()['date_time']
    # Test epoch_int and epoch
    assert int(date_time_facts['epoch_int']) == int(date_time_facts['epoch'])
    assert int(date_time_facts['epoch_int']) == int(utc_ts)
    # Test iso8601, iso8601_micro
    datetime_formatted = utcnow.strftime("%Y-%m-%dT%H:%M:%S")

# Generated at 2022-06-11 04:28:47.712796
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Create an instance of DateTimeFactCollector
    dtfc = DateTimeFactCollector()

    # Call method collect of DateTimeFactCollector
    dtfc.collect()

# Generated at 2022-06-11 04:28:50.727869
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    collected_facts = fact_collector.collect(module=None, collected_facts={})
    assert collected_facts['date_time']['date']

# Generated at 2022-06-11 04:28:52.294959
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    c = DateTimeFactCollector()
    assert len(c.collect().keys()) == 1

# Generated at 2022-06-11 04:29:03.482754
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_object = DateTimeFactCollector()
    test_object._module = None
    test_object._collected_facts = {}

# Generated at 2022-06-11 04:29:12.185336
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    d = dict()
    # Variables needed for test
    d['epoch'] = str(int(time.time()))
    d['epoch_int'] = str(int(time.time()))
    d['date'] = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d')
    d['time'] = datetime.datetime.fromtimestamp(time.time()).strftime('%H:%M:%S')
    d['iso8601_micro'] = datetime.datetime.utcfromtimestamp(time.time()).strftime("%Y-%m-%dT%H:%M:%S.%fZ")

# Generated at 2022-06-11 04:29:22.967125
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dateFactCollector = DateTimeFactCollector()
    date_time_facts = dateFactCollector.collect()
    assert date_time_facts['date_time']['time'] == datetime.datetime.now().strftime("%H:%M:%S")
    assert date_time_facts['date_time']['date'] == datetime.datetime.now().strftime("%Y-%m-%d")
    assert date_time_facts['date_time']['tz'] == time.strftime("%Z")
    assert date_time_facts['date_time']['tz_dst'] == time.tzname[1]
    assert date_time_facts['date_time']['tz_offset'] == time.strftime("%z")

# Generated at 2022-06-11 04:29:28.790958
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    timestring = dtfc.collect()['date_time']['iso8601']
    assert(len(timestring) == 20)
    assert(timestring[-1] == 'Z')
    assert(timestring[-5] == ':')
    assert(timestring[-8] == ':')
    assert(timestring[-11] == 'T')

# Generated at 2022-06-11 04:29:43.334481
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    data_time_facts = dict()
    data_time_facts['epoch'] = str(int(time.time()))
    data_time_facts['epoch_int'] = str(int(time.time()))
    data_time_facts['date'] = time.strftime('%Y-%m-%d')
    data_time_facts['time'] = time.strftime('%H:%M:%S')
    data_time_facts['iso8601_micro'] = datetime.datetime.utcfromtimestamp(time.time()).strftime("%Y-%m-%dT%H:%M:%S.%fZ")

# Generated at 2022-06-11 04:29:46.244125
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dfc = DateTimeFactCollector()
    facts = dfc.collect()
    assert isinstance(facts, dict)
    assert 'date_time' in facts


# Generated at 2022-06-11 04:29:55.440686
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Return a dict with the date/time facts
    """
    collected_facts = {}
    fact_collector_obj = DateTimeFactCollector()
    module = None

# Generated at 2022-06-11 04:30:06.479965
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = DateTimeFactCollector()
    now = datetime.datetime.now()
    utcnow = datetime.datetime.utcnow()
    epoch_ts = time.time()

    def _assert(value, expected):
        assert value == expected, "%s is not equal to %s" % (value, expected)

    _assert(dt.collect()['date_time']['year'], now.strftime('%Y'))
    _assert(dt.collect()['date_time']['month'], now.strftime('%m'))
    _assert(dt.collect()['date_time']['weekday'], now.strftime('%A'))
    _assert(dt.collect()['date_time']['weekday_number'], now.strftime('%w'))
    _

# Generated at 2022-06-11 04:30:13.786021
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Initialise DateTimeFactCollector object
    date_time_fact_collector_obj = DateTimeFactCollector()
    # Call method collect of class DateTimeFactCollector
    date_time_fact_collector_obj.collect()
    # Assert that date_time key is in output of method collect
    assert 'date_time' in date_time_fact_collector_obj.collect()
    # Assert that keys year, month etc are in output of method collect
    assert 'year' in date_time_fact_collector_obj.collect()['date_time']

# Generated at 2022-06-11 04:30:20.088759
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fc = DateTimeFactCollector()
    facts = fc.collect()
    assert 'date_time' in facts
    assert type(facts['date_time']) is dict
    assert 'epoch_int' in facts['date_time']
    assert type(facts['date_time']['epoch_int']) is str
    assert 'epoch' in facts['date_time']
    assert type(facts['date_time']['epoch']) is str

# Generated at 2022-06-11 04:30:22.025608
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    f = DateTimeFactCollector()
    fact = f.collect()
    assert len(fact['date_time']) > 0

# Generated at 2022-06-11 04:30:27.467474
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Populate required arguments
    module = None
    collected_facts = None
    # Instantiate DateTimeFactCollector
    date_time_fact_collector = DateTimeFactCollector()
    # Run method collect on DateTimeFactCollector
    output_facts_dict = date_time_fact_collector.collect(module, collected_facts)
    assert output_facts_dict is not None

# Generated at 2022-06-11 04:30:31.915542
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    class MockModule():
        def __init__(self):
            self.params = {}

    class MockCollectedFacts():
        def __init__(self):
            self.date_time = {}

    dt = DateTimeFactCollector()
    dt.collect(MockModule(), MockCollectedFacts())
    assert isinstance(dt.collect(), dict)

# Generated at 2022-06-11 04:30:42.149501
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Validate the collect method of DateTimeFactCollector."""
    fake_module = None
    fake_collected_facts = None
    date_time_collector = DateTimeFactCollector()
    date_time_facts = date_time_collector.collect(fake_module, fake_collected_facts)['date_time']

    # Check that epoch_int and epoch return the same results
    assert date_time_facts['epoch_int'] == date_time_facts['epoch']

    # Check that epoch returns the same value as time.time
    assert int(date_time_facts['epoch']) == int(time.time())

    # Check that epoch_int returns the same value as time.time
    assert int(date_time_facts['epoch_int']) == int(time.time())

    # Check that

# Generated at 2022-06-11 04:30:59.397634
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Mock module input arguments
    module_args = {}
    # Instantiate DateTimeFactCollector class
    dt = DateTimeFactCollector(module_args, {})
    # Collect facts
    facts = dt.collect()
    # Assert facts
    assert isinstance(facts, dict), 'facts must be of type dict.'
    assert 'date_time' in facts, 'facts must have date_time key.'
    assert 'year' in facts['date_time'], 'date_time facts must have year key.'
    assert 'month' in facts['date_time'], 'date_time facts must have month key.'
    assert 'weekday' in facts['date_time'], 'date_time facts must have weekday key.'

# Generated at 2022-06-11 04:31:09.382182
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Initialize the DateTimeFactCollector object
    datetime_collector = DateTimeFactCollector()

    # Instantiate a AnsibleModule object
    # AnsibleModule is required to run collect method
    class AnsibleModule(object):
        def __init__(self):
            self.params = None
    my_ansible_module = AnsibleModule()

    # The collect method will return a datetime facts dict
    result = datetime_collector.collect(my_ansible_module)
    # assert that it will return a dict
    assert isinstance(result, dict)
    # assert that it has a key of date_time
    assert ('date_time' in result.keys())
    # assert that it returns a dict with multiple keys
    assert (len(result['date_time'].keys()) > 1)

# Generated at 2022-06-11 04:31:12.767574
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    now = datetime.datetime.now()
    facts = DateTimeFactCollector().collect()
    assert facts['date_time']['year'] == now.strftime('%Y')



# Generated at 2022-06-11 04:31:20.891468
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import json
    import os

    date_time_fact_collector = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector.collect()

    assert date_time_facts is not None
    assert isinstance(date_time_facts, dict)
    assert 'date_time' in date_time_facts
    assert isinstance(date_time_facts['date_time'], dict)

    print(json.dumps(date_time_facts))

if __name__ == '__main__':
    test_DateTimeFactCollector_collect()

# Generated at 2022-06-11 04:31:22.568792
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    dtfc.collect()

# Generated at 2022-06-11 04:31:29.372474
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collector = DateTimeFactCollector()
    facts = collector.collect()
    # Expected keys:
    # epoch, iso8601, iso8601_micro, iso8601_basic, iso8601_basic_short, day, hour, minute, month, second, time, tz, tz_dst, tz_offset, weekday, weekday_number, year, date, weeknumber, epoch_int
    assert len(facts['date_time']) > 0



# Generated at 2022-06-11 04:31:33.176811
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    dtfc.collect()

# for the purpose of unit testing this file, load the module and run the above defined method against the class instance.
if __name__ == '__main__':
    test_DateTimeFactCollector_collect()

# Generated at 2022-06-11 04:31:37.794925
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Test instance of DateTimeFactCollector
    test_instance = DateTimeFactCollector()

    # Call method with no arguments
    result = test_instance.collect()

    # Check if result has date_time as a member
    assert 'date_time' in result

    # Check that date_time has a member date
    date_time_facts = result['date_time']
    assert 'date' in date_time_facts

# Generated at 2022-06-11 04:31:48.473082
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Unit test for method collect of class DateTimeFactCollector"""

    # Arrange
    # If a file /etc/ansible/facts.d/date_time.fact exists, remove it
    file = '/etc/ansible/facts.d/date_time.fact'
    if os.path.isfile(file):
        os.remove(file)

    module = None
    collected_facts = {'timezone': None}

    dtfc = DateTimeFactCollector()

    # Act
    facts_dict = dtfc.collect(module, collected_facts)

    # Assert
    assert len(facts_dict) == 1
    assert 'date_time' in facts_dict
    assert 'date' in facts_dict['date_time']
    assert 'epoch' in facts_dict['date_time']

# Generated at 2022-06-11 04:31:51.877460
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Create an instance of the DateTimeFactCollector class
    dtf = DateTimeFactCollector()

    # Call method collect of the class
    dtf.collect()

    # Check the result
    assert isinstance(dtf.collect(), dict)

# Generated at 2022-06-11 04:32:09.773820
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    collected_facts = fact_collector.collect(None, None)
    assert collected_facts['date_time']['month'] != ""


# Generated at 2022-06-11 04:32:12.149578
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    '''
    Unit test for DateTimeFactCollector.collect
    '''
    dtfc = DateTimeFactCollector()
    dtfc.collect()

# Generated at 2022-06-11 04:32:15.670885
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts import ansible_local

    ansible_local.GATHERING_FAKE_DATA = True

    DateTimeFactCollector().collect(None, None)

    ansible_local.GATHERING_FAKE_DATA = False

# Generated at 2022-06-11 04:32:18.094150
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dc = DateTimeFactCollector()
    facts = dc.collect()
    assert isinstance(facts.get('date_time'), dict), 'Failed to collect date_time facts.'



# Generated at 2022-06-11 04:32:26.366678
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import base
    from ansible.module_utils._text import to_text

    date_time_fact_collector = DateTimeFactCollector()
    ansible_module = FactCollector._create_ansible_module()
    date_time_fact_collector.subset = base.subset
    date_time_fact_collector.exclusions = base.exclusions
    facts_dict = date_time_fact_collector.collect(module=ansible_module)
    b_fact_dict = to_text(facts_dict).encode('utf-8')
    # look for elements of the weekday key
    assert b'Mon' in b_fact_dict
    assert b'Tue' in b_fact_dict

# Generated at 2022-06-11 04:32:32.675678
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    tz = time.timezone

    # Now, we will move the year forward 1 year to test the date_time facts
    now = time.time()
    time.timezone = -3600
    time.time = lambda: now + 3600 * 24 * 365

    fact_collector = DateTimeFactCollector()
    assert fact_collector.collect()['date_time']['year'] == '2016'

    time.timezone = tz
    time.time = now

# Generated at 2022-06-11 04:32:34.539573
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time = DateTimeFactCollector()
    assert isinstance(date_time.collect(), dict)



# Generated at 2022-06-11 04:32:41.513688
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # Partial object creation to pass object validation
    date_time_collector = DateTimeFactCollector()
    date_time_collector.name = 'date_time'
    date_time_collector._fact_ids = set()

    # Creating a datetime object from current time
    now = datetime.datetime.now()

    # Expected facts dict
    exp_date_time_fact_dict = dict()
    exp_date_time_fact_dict['year'] = now.strftime('%Y')
    exp_date_time_fact_dict['month'] = now.strftime('%m')
    exp_date_time_fact_dict['weekday'] = now.strftime('%A')
    exp_date_time_fact_dict['weekday_number'] = now.strftime('%w')
    exp_

# Generated at 2022-06-11 04:32:52.142412
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import re
    import datetime
    import time

    year = datetime.datetime.now().strftime('%Y')
    month = datetime.datetime.now().strftime('%m')
    day = datetime.datetime.now().strftime('%d')
    hour = datetime.datetime.now().strftime('%H')
    minute = datetime.datetime.now().strftime('%M')
    second = datetime.datetime.now().strftime('%S')
    date_iso8601_basic_short = datetime.datetime.now().strftime("%Y%m%dT%H%M%S")

    d = datetime.datetime.now()
    epoch = int(time.mktime(d.timetuple()))

# Generated at 2022-06-11 04:33:02.504369
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    d = datetime.date(2001, 2, 3)
    t = datetime.time(4, 5, 6, 7)
    # datetime.datetime(year, month, day[, hour[, minute[, second[, microsecond[,tzinfo]]]]])
    dt = datetime.datetime(2001, 2, 3, 4, 5, 6, 7)
    # For testing we also need a naive datetime, which is just a datetime
    # without a time zone.
    dtn = datetime.datetime(2001, 2, 3, 4, 5, 6, 7)
    # We also need a time zone aware datetime, so we create one
    dta = datetime.datetime(2001, 2, 3, 4, 5, 6, 7, tzinfo=datetime.timezone.utc)
   

# Generated at 2022-06-11 04:33:40.496089
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Create instance of DateTimeFactCollector to test with
    dtfc = DateTimeFactCollector()

    # Do the collection
    collected_facts_dict = dtfc.collect()

    # Assert some facts were returned
    assert len(collected_facts_dict) == 1

    # Assert all expected facts are present in returned facts
    for factname in ('year', 'month', 'weekday', 'weekday_number', 'weeknumber', 'day', 'hour', 'minute', 'second', 'epoch', 'epoch_int', 'date', 'time', 'iso8601_micro', 'iso8601', 'iso8601_basic', 'iso8601_basic_short', 'tz', 'tz_dst', 'tz_offset'):
        assert factname in collected_facts_dict['date_time']

# Generated at 2022-06-11 04:33:45.309209
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    '''Unit test for method collect of class DateTimeFactCollector'''
    collector = DateTimeFactCollector({})
    date_time_facts = collector.collect()
    assert date_time_facts['date_time']
    assert date_time_facts['date_time']['epoch']
    assert date_time_facts['date_time']['tz']

# Generated at 2022-06-11 04:33:54.000946
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # return the epoch time
    def mock_time():
        return 1234

    # return the epoch in year 1970 date and time format
    def mock_datetime_fromtime():
        return datetime.datetime.fromtimestamp(1234)

    try:
        datetime.datetime.fromtimestamp = mock_datetime_fromtime
        time.time = mock_time
        ecc = DateTimeFactCollector()
        result = ecc.collect() # invoked the collect method and store the output in result
        assert result['date_time']['epoch_int'] == '1234' # check if the result epoch_int is 1234 or not

    finally:
        del datetime.datetime.fromtimestamp
        del time.time

# Generated at 2022-06-11 04:34:04.062096
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_collector_obj = DateTimeFactCollector()
    date_time_facts = date_time_collector_obj.collect()
    assert date_time_facts['date_time']['year'] == (datetime.datetime.utcnow()).strftime('%Y')
    assert date_time_facts['date_time']['month'] == (datetime.datetime.utcnow()).strftime('%m')
    assert date_time_facts['date_time']['weekday'] == (datetime.datetime.utcnow()).strftime('%A')
    assert date_time_facts['date_time']['weekday_number'] == (datetime.datetime.utcnow()).strftime('%w')

# Generated at 2022-06-11 04:34:13.909082
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-11 04:34:24.843992
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Returns a dictionary with the values of the DateTimeFactCollector class
    """
    datetime_facts = DateTimeFactCollector()
    current_datetime_facts = datetime_facts.collect()
    if 'date_time' not in current_datetime_facts:
        raise AssertionError('date_time fact is missing from facts')
    if 'year' not in current_datetime_facts['date_time']:
        raise AssertionError('year fact is missing from date time facts')
    if 'month' not in current_datetime_facts['date_time']:
        raise AssertionError('month fact is missing from date time facts')
    if 'weekday' not in current_datetime_facts['date_time']:
        raise AssertionError('weekday fact is missing from date time facts')
   

# Generated at 2022-06-11 04:34:34.880272
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    datetime_fact_collector = DateTimeFactCollector()
    res = datetime_fact_collector.collect()
    try:
        datetime_fact_collector.get_facts()
    except AttributeError:
        pass
    else:
        raise AssertionError("Old version of ansible")
    assert res['date_time']['year'] == datetime.datetime.now().strftime("%Y")
    assert res['date_time']['month'] == datetime.datetime.now().strftime("%m")
    assert res['date_time']['weekday'] == datetime.datetime.now().strftime("%A")
    assert res['date_time']['weekday_number'] == datetime.datetime.now().strftime("%w")

# Generated at 2022-06-11 04:34:42.077297
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Create test DateTimeFactCollector object
    fac = DateTimeFactCollector()

    # Get collected facts
    collected_facts = fac.collect()

    # Assert that collected_facts is a dictionary
    assert isinstance(collected_facts, dict)

    # Assert date_time fact is in collected facts
    assert 'date_time' in collected_facts

    # Assert date_time fact is a dictionary
    assert isinstance(collected_facts['date_time'], dict)

    # Assert date_time fact has all date/time related facts
    date_time_facts = collected_facts['date_time']
    assert 'year' in date_time_facts
    assert 'month' in date_time_facts
    assert 'weekday' in date_time_facts
    assert 'weekday_number' in date_time_

# Generated at 2022-06-11 04:34:51.756544
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-11 04:35:02.020496
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """ Unit test for method collect of class DateTimeFactCollector """
    import pytest

    collector = DateTimeFactCollector()
    facts_dict = collector.collect()
    assert isinstance(facts_dict, dict)
    assert 'date_time' in facts_dict
    assert isinstance(facts_dict['date_time'], dict)
    assert 'year' in facts_dict['date_time']
    assert 'month' in facts_dict['date_time']
    assert 'weekday' in facts_dict['date_time']
    assert 'weekday_number' in facts_dict['date_time']
    assert 'weeknumber' in facts_dict['date_time']
    assert 'day' in facts_dict['date_time']
    assert 'hour' in facts_dict['date_time']
    assert 'minute' in facts

# Generated at 2022-06-11 04:36:10.131839
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    facts_collector = DateTimeFactCollector()
    facts = facts_collector.collect()
    assert facts['date_time']['year'] == '2017'
    assert facts['date_time']['month'] == '05'
    assert facts['date_time']['weekday'] == 'Wednesday'
    assert facts['date_time']['weekday_number'] == '3'
    assert facts['date_time']['weeknumber'] == '19'
    assert facts['date_time']['day'] == '31'
    assert facts['date_time']['hour'] == '02'
    assert facts['date_time']['minute'] == '16'
    assert facts['date_time']['second'] == '18'

# Generated at 2022-06-11 04:36:17.467110
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()

    results = fact_collector.collect()

    assert(results['date_time']['year'] == datetime.datetime.now().strftime('%Y'))
    assert(results['date_time']['month'] == datetime.datetime.now().strftime('%m'))
    assert(results['date_time']['weekday'] == datetime.datetime.now().strftime('%A'))
    assert(results['date_time']['weekday_number'] == datetime.datetime.now().strftime('%w'))
    assert(results['date_time']['weeknumber'] == datetime.datetime.now().strftime('%W'))

# Generated at 2022-06-11 04:36:27.136684
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = DateTimeFactCollector()
    collected_facts = dt.collect()
    expected_keys = [
        'epoch',
        'epoch_int',
        'date',
        'hour',
        'iso8601',
        'iso8601_basic_short',
        'iso8601_basic',
        'iso8601_micro',
        'minute',
        'month',
        'second',
        'time',
        'tz',
        'tz_dst',
        'tz_offset',
        'weekday',
        'weekday_number',
        'weeknumber',
        'year'
    ]
    assert sorted(expected_keys) == sorted(collected_facts['date_time'].keys())
    assert collected_facts['date_time']['epoch'].isdig

# Generated at 2022-06-11 04:36:36.423782
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact = DateTimeFactCollector()

    date_time_fact_collected = date_time_fact.collect()

    date_time_fact_collected_dict = dict((k, v) for k, v in date_time_fact_collected['date_time'].items())
    assert ('year' in date_time_fact_collected_dict)
    assert ('month' in date_time_fact_collected_dict)
    assert ('weekday' in date_time_fact_collected_dict)
    assert ('weekday_number' in date_time_fact_collected_dict)
    assert ('weeknumber' in date_time_fact_collected_dict)
    assert ('day' in date_time_fact_collected_dict)

# Generated at 2022-06-11 04:36:38.897190
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_facts = DateTimeFactCollector().collect(module=None, collected_facts=None)
    assert len(date_time_facts['date_time']) == 16


# Generated at 2022-06-11 04:36:47.886792
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_facts = DateTimeFactCollector(None, None)
    result = date_time_facts.collect()
    assert isinstance(result, dict),\
        "Should have returned dictionary but returned '%s' instead"\
        % type(result)
    assert 'date_time' in result,\
        "Should have returned 'date_time' key in returned dictionary"\
        " but returned '%s' instead" % result.keys()
    assert isinstance(result['date_time'], dict),\
        "Should have returned dictionary for 'date_time' key but"\
        " returned '%s' instead" % type(result['date_time'])

# Generated at 2022-06-11 04:36:51.124081
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fc = DateTimeFactCollector()
    result = fc.collect()
    assert 'date_time' in result
    assert 'epoch' in result['date_time']
    assert 'iso8601' in result['date_time']

# Generated at 2022-06-11 04:37:00.603898
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    expected_date_time_facts = {'date': '2019-02-03', 'time': '02:26:31', 'hour': '02', 'tz_offset': '+0000', 'tz_dst': 'GMT'}
    expected_year = '2019'
    expected_month = '02'
    expected_weekday = 'Sunday'
    expected_weekday_number = '0'
    expected_weeknumber = '05'
    expected_day = '03'
    expected_minute = '26'
    expected_second = '31'
    expected_epoch = '1549222791'
    expected_epoch_int = '1549222791'
    expected_iso8601_micro = '2019-02-03T02:26:31.266070Z'

# Generated at 2022-06-11 04:37:01.959037
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    f = DateTimeFactCollector()
    assert f.collect() is not None

# Generated at 2022-06-11 04:37:07.382793
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    facts = fact_collector.collect()
    fact_keys = ['date_time']
    assert(sorted(fact_keys) == sorted(facts.keys()))
    date_time_keys = ['year', 'month', 'day', 'epoch']
    assert(sorted(date_time_keys) == sorted(facts['date_time'].keys()))