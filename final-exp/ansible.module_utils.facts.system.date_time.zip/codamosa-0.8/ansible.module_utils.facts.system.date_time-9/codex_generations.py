

# Generated at 2022-06-11 04:28:19.711328
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_collector = DateTimeFactCollector({})
    result = date_time_collector.collect()
    print(result)
    assert isinstance(result, dict)
    assert 'date_time' in result
    date_time = result.get('date_time')
    assert isinstance(date_time, dict)
    assert 'epoch' in date_time
    assert 'epoch_int' in date_time
    assert 'iso8601' in date_time


# Generated at 2022-06-11 04:28:28.840324
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # initialize
    DateTimeFactCollector.init('')
    DateTimeFactCollector._fact_ids = set()
    epoch_ts = time.time()
    now = datetime.datetime.fromtimestamp(epoch_ts)
    utcnow = datetime.datetime.utcfromtimestamp(epoch_ts)

# Generated at 2022-06-11 04:28:36.344247
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts import gather_subset as get_facts
    from ansible.module_utils.facts.collector import FactCache
    from ansible.module_utils._text import to_bytes
    import json

    # test the facts gathering is correct
    # call the collect function to return date_time
    date_time = DateTimeFactCollector().collect(module=None, collected_facts=None)
    fact_cache = FactCache()
    # collect the subset of facts containing date_time
    subset = get_facts(fact_cache, ['date_time'])
    # check the data returned by gather_subset is correct
    assert subset == {'date_time': date_time['date_time']}

    json_out = json.dumps(date_time)
    assert len(json_out) > 0

# Generated at 2022-06-11 04:28:47.193926
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    '''Unit test for method collect of class DateTimeFactCollector'''

    # test required function
    def execute_module():
        '''test function stub'''
        return

    def fail_json(*args, **kwargs):
        '''test function stub'''
        raise Exception("fail_json was called")

    # unit test the DateTimeFactCollector class
    if __name__ == '__main__':
        module = None
        setattr(module, 'exit_json', execute_module)
        setattr(module, 'fail_json', fail_json)
        date_time_fact_collector_instance = DateTimeFactCollector(module=module, collected_facts=None)
        date_time_facts = date_time_fact_collector_instance.collect(module=module)

# Generated at 2022-06-11 04:28:51.671340
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector._gather_platform_facts = date_time_fact_collector.collect()
    result = date_time_fact_collector.collect()
    assert len(result['date_time']) == 18

# Generated at 2022-06-11 04:28:54.920372
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """ Test method collect of class DateTimeFactCollector"""
    # Test with a DateTimeFactCollector instance
    dtfc = DateTimeFactCollector()
    assert isinstance(dtfc.collect(), dict)

# Generated at 2022-06-11 04:29:05.998278
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance


# Generated at 2022-06-11 04:29:07.376617
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector.collect()

# Generated at 2022-06-11 04:29:12.528386
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Parameters
    collected_facts = {'date_time': {}}
    dtf_obj = DateTimeFactCollector()

    # Run collect
    dtf_obj.collect(collected_facts=collected_facts)

    # Verify collected_facts
    return collected_facts['date_time']

# Generated at 2022-06-11 04:29:23.269210
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    dtf = DateTimeFactCollector()
    actual = dtf.collect()


# Generated at 2022-06-11 04:29:29.088614
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # create instance of DateTimeFactCollector class
    x = DateTimeFactCollector()
    # run collect method to get date/time facts
    res = x.collect()
    # verify results are correct
    assert res['date_time']['time'] is not ''
    assert res['date_time']['second'] == time.strftime('%S')
    assert res['date_time']['epoch'] == str(int(time.time()))

# Generated at 2022-06-11 04:29:33.071308
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt_collector = DateTimeFactCollector()

    # Returned datetime information is UTC, but actual timezone should be considered
    # when comparing it.
    # TODO: add assert check in the future.
    facts = dt_collector.collect()

# Generated at 2022-06-11 04:29:38.595163
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_collector = DateTimeFactCollector()
    date_time_facts = date_time_collector.collect()['date_time']
    assert date_time_facts['year'] == datetime.datetime.now().strftime('%Y')
    assert date_time_facts['month'] == datetime.datetime.now().strftime('%m')
    assert date_time_facts['weekday'] == datetime.datetime.now().strftime('%A')
    assert date_time_facts['weekday_number'] == datetime.datetime.now().strftime('%w')
    assert date_time_facts['weeknumber'] == datetime.datetime.now().strftime('%W')
    assert date_time_facts['day'] == datetime.datetime.now().strftime('%d')
   

# Generated at 2022-06-11 04:29:41.672253
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # fact_collector = DateTimeFactCollector(None)
    # fact_collector.collect()
    # assert fact_collector
    pass


# Generated at 2022-06-11 04:29:52.275214
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Check that DateTimeFactCollector can collect data.
    """
    fact_collector = DateTimeFactCollector()
    facts = fact_collector.collect()
    assert 'date_time' in facts,\
        "Expected date_time key in facts"
    date_time_facts = facts['date_time']
    assert type(date_time_facts['epoch']) is str,\
        "Expected epoch to be a string"
    assert type(date_time_facts['epoch_int']) is str,\
        "Expected epoch_int to be a string"

    # Check epoch vs epoch_int
    expected_epoch = int(float(date_time_facts['epoch']))
    actual_epoch = int(date_time_facts['epoch_int'])
    assert expected

# Generated at 2022-06-11 04:29:56.889803
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collectors = [DateTimeFactCollector()]
    collected_facts = {}

    for collector in collectors:
        try:
            facts = collector.collect(None, collected_facts)
        except Exception as e:
            continue

        for fact_name in sorted(facts):
            collected_facts[fact_name] = facts[fact_name]

    return collected_facts

# Generated at 2022-06-11 04:30:02.628124
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Test DateTimeFactCollector.collect
    """
    def mock_os_geteuid(self):
        """
        Mocking os.geteuid()
        """
        return 1000

    collector = DateTimeFactCollector()
    collector.get_file_content = mock_os_geteuid
    res = collector.collect()
    assert 'date_time' in res.keys()

# Generated at 2022-06-11 04:30:13.079890
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    DatetimeModule = type('DatetimeModule', (basic.AnsibleModule,), {})
    DatetimeModule.exit_json = lambda self, **kwargs: kwargs
    DatetimeModule.run_command = lambda self, **kwargs: (0, 'fake_stdout')
    DatetimeModule.fail_json = lambda self, **kwargs: kwargs

    module = DatetimeModule()

    facts = collector.collect(module, 'date_time')

    assert facts.get('date_time') is not None

    assert 'year' in facts['date_time']
    assert 'month' in facts['date_time']
    assert 'weekday' in facts['date_time']

# Generated at 2022-06-11 04:30:22.900974
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    datetime_facts = date_time_fact_collector.collect()
    assert datetime_facts['date_time']['year'] == datetime.datetime.now().strftime('%Y')
    assert datetime_facts['date_time']['month'] == datetime.datetime.now().strftime('%m')
    assert datetime_facts['date_time']['weekday'] == datetime.datetime.now().strftime('%A')
    assert datetime_facts['date_time']['weekday_number'] == datetime.datetime.now().strftime('%w')
    assert datetime_facts['date_time']['weeknumber'] == datetime.datetime.now().strftime('%W')
    assert datetime

# Generated at 2022-06-11 04:30:32.997370
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts import default_collectors

    # Setup default collectors to test against
    default_collectors['date_time'] = DateTimeFactCollector()

    # Create a new FactsCollector
    facts_collector = FactsCollector(module='setup',
                                     collectors=default_collectors)

    # Run the collection of facts
    facts_collector.collect()

    # Set date_time properties in module
    date_time_facts = facts_collector.get_facts()['date_time']
    ansible_date_time = facts_collector.module.params['ansible_date_time']
    ansible_date_time['epoch'] = date_time_facts['epoch']

# Generated at 2022-06-11 04:30:46.582052
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts import collector

    # First, create a cache that contains the "date_time" result.  This
    # simulates the cache being loaded from a cache file.

# Generated at 2022-06-11 04:30:53.610658
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.collectors import get_collector_instance

    dt = '2018-01-01'
    ti = '00:00:00'
    epoch = time.mktime(time.strptime('%s %s' % (dt, ti), '%Y-%m-%d %H:%M:%S'))

    # Create an instance of Facts to reuse some common attributes
    fact_instance = Facts()
    
    # Create an instance of DateTimeFactCollector
    datetime_inst = get_collector_instance(fact_instance, 'DateTimeFactCollector')

    # run datetime_inst.collect to set some attributes
    datetime_inst.collect()

    # Create a fake current_time from the attributes set

# Generated at 2022-06-11 04:30:54.422427
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    d = DateTimeFactCollector()
    d.collect()

# Generated at 2022-06-11 04:30:56.405481
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    result = dtfc.collect()
    
    assert 'date_time' in result
    assert 'month' in result['date_time']

# Generated at 2022-06-11 04:31:04.428187
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt_fact = DateTimeFactCollector()
    now = datetime.datetime.now()
    dt_fact_dict = dt_fact.collect()
    assert 'date_time' in dt_fact_dict
    assert 'year' in dt_fact_dict['date_time']
    assert 'month' in dt_fact_dict['date_time']
    assert 'weekday' in dt_fact_dict['date_time']
    assert 'weekday_number' in dt_fact_dict['date_time']
    assert 'weeknumber' in dt_fact_dict['date_time']
    assert 'day' in dt_fact_dict['date_time']
    assert 'hour' in dt_fact_dict['date_time']
    assert 'minute' in dt_fact_dict

# Generated at 2022-06-11 04:31:09.522119
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    facts_dict = fact_collector.collect()
    assert isinstance(facts_dict, dict)
    assert 'date_time' in facts_dict
    assert isinstance(facts_dict['date_time'], dict)
    assert len(facts_dict['date_time']) == 15



# Generated at 2022-06-11 04:31:20.833106
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Unit test for method collect of class DateTimeFactCollector"""
    collector = DateTimeFactCollector()
    fact_ans = collector.collect()
    assert 'date_time' in fact_ans

# Generated at 2022-06-11 04:31:32.050592
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Unit test for DateTimeFactCollector.collect
    """
    # Get collect method
    dtfc = DateTimeFactCollector()
    collect = dtfc.collect()

    # Get date_time dict from collect
    date_time_dict = collect['date_time']

    # Check if all keys are in the collect
    keys = ['year', 'month', 'weekday', 'weekday_number', 'weeknumber',
            'day', 'hour', 'minute', 'second', 'epoch', 'epoch_int', 'date',
            'time', 'iso8601_micro', 'iso8601', 'iso8601_basic',
            'iso8601_basic_short', 'tz', 'tz_dst', 'tz_offset']

# Generated at 2022-06-11 04:31:34.466841
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Arrange
    collection = DateTimeFactCollector()
    # Act
    result = collection.collect()
    # Assert
    assert result != None
    assert result['date_time'] != None

# Generated at 2022-06-11 04:31:35.411866
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    DateTimeFactCollector().collect()
    assert True

# Generated at 2022-06-11 04:31:48.675769
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    data_time_collector = DateTimeFactCollector()
    data_time_facts = data_time_collector.collect()
    assert ('date_time' in data_time_facts)
    assert ('year' in data_time_facts['date_time'])
    assert ('date' in data_time_facts['date_time'])
    assert ('time' in data_time_facts['date_time'])
    assert ('tz' in data_time_facts['date_time'])

# Generated at 2022-06-11 04:31:59.419806
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # Initialize the required classes
    dt_fc = DateTimeFactCollector()

    # Call the method collect with no parameters
    facts = dt_fc.collect()

    # Make sure the result is a dict
    assert isinstance(facts, dict)

    # Make sure the dict has an entry for the key 'date_time'
    assert 'date_time' in facts

    # Make sure the value for 'date_time' is a dict
    assert isinstance(facts['date_time'], dict)

    date_time_facts = facts['date_time']

    # Make sure we have all the keys we expect

# Generated at 2022-06-11 04:32:05.006529
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Unit test for method collect of class DateTimeFactCollector
    """
    date_time_facts = DateTimeFactCollector()
    result = date_time_facts.collect()
    assert result['date_time']['year'] == datetime.datetime.utcnow().strftime('%Y')
    assert not result['date_time']['minute'] == datetime.datetime.utcnow().strftime('%S')

# Generated at 2022-06-11 04:32:15.372392
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collect_obj = DateTimeFactCollector()
    result = collect_obj.collect()

# Generated at 2022-06-11 04:32:21.942439
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # instantiate class and test collect method
    dtf = DateTimeFactCollector()
    test_epoch_ts = 1459806901
    test_dict = dtf.collect(datetime.datetime.fromtimestamp(test_epoch_ts))
    # print("test_dict = {}".format(test_dict))
    assert test_dict['date_time']['epoch'] == '1459806901'
    assert test_dict['date_time']['time'] == '17:55:01'


# Generated at 2022-06-11 04:32:31.513029
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Mock the module
    module_mock = MagicMock()
    module_mock.params = {}

    # Get the datetime collector class
    dt_collector_class = DateTimeFactCollector()
    # Call collect method with mocked module
    dt_collector_dict = dt_collector_class.collect(module_mock)
    # Verify return code
    assert dict == type(dt_collector_dict)
    # Verify is it has a date_time key
    if "date_time" not in dt_collector_dict:
        fail("date_time not in dt_collector_dict")
    dt_dict = dt_collector_dict["date_time"]
    # Verify time zone and DST keys

# Generated at 2022-06-11 04:32:39.981710
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    time.sleep(1)
    now = datetime.datetime.now()
    utcnow = datetime.datetime.utcnow()
    epoch_ts = time.time()
    dtfc_dict = dtfc.collect()
    assert dtfc_dict['date_time']['year'] == now.strftime('%Y')
    assert dtfc_dict['date_time']['month'] == now.strftime('%m')
    assert dtfc_dict['date_time']['weekday'] == now.strftime('%A')
    assert dtfc_dict['date_time']['weekday_number'] == now.strftime('%w')
    assert dtfc_dict['date_time']['weeknumber'] == now

# Generated at 2022-06-11 04:32:43.954500
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    facts = dict()
    datetimefacts = DateTimeFactCollector()
    result = datetimefacts.collect(collected_facts=facts)
    assert(result['date_time']['year'] == time.strftime("%Y"))

# Generated at 2022-06-11 04:32:48.509133
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    a=DateTimeFactCollector()
    b=a.collect()
    assert type(b['date_time']) == dict
    assert type(b['date_time']['epoch']) == str
    assert type(b['date_time']['epoch_int']) == str


# Generated at 2022-06-11 04:32:56.984220
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
  # Create an object of class DateTimeFactCollector
  dt_collector = DateTimeFactCollector()
  # Call method collect of DateTimeFactCollector
  dt_dict = dt_collector.collect()
  # Assert method collect returns facts
  assert dt_dict is not None
  # Assert date_time is in the dt_dict
  assert 'date_time' in dt_dict
  # Assert date_time has expected keys

# Generated at 2022-06-11 04:33:20.929704
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = DateTimeFactCollector()

    actual = dt.collect()

# Generated at 2022-06-11 04:33:21.858412
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    DateTimeFactCollector().collect()

# Generated at 2022-06-11 04:33:31.365079
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import date_time

    # initialize the class
    date_time_facts = DateTimeFactCollector()

    # test the collect method
    result = date_time_facts.collect()
    assert result['date_time']['epoch'] == str(int(time.time()))
    assert 'date_time' in result

    # initialize the class with ansible module
    module = date_time.AnsibleModule(argument_spec=dict())
    date_time_facts = DateTimeFactCollector(module=module)

    # test the collect method
    result = date_time_facts.collect()
    assert result['date_time']['epoch'] == str(int(time.time()))
    assert 'date_time' in result

# Generated at 2022-06-11 04:33:41.213643
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    now = datetime.datetime.now()
    utcnow = datetime.datetime.utcnow()
    epoch_ts = time.time()


# Generated at 2022-06-11 04:33:46.705578
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    dtf = dtfc.collect()
    assert 0 != len(dtf.keys())
    for k,v in dtf.items():
        assert isinstance(k, str)
        assert isinstance(v, dict)
        for k2, v2 in v.items():
            assert isinstance(k2, str)
            assert isinstance(v2, str)
    return


# Generated at 2022-06-11 04:33:50.671717
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtFactsCollector = DateTimeFactCollector()
    ansible_collected_facts = {}
    ansible_collected_facts = dtFactsCollector.collect(collected_facts=ansible_collected_facts)
    assert ansible_collected_facts['date_time']

# Generated at 2022-06-11 04:34:00.163189
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    now = datetime.datetime.now()
    utcnow = datetime.datetime.utcnow()
    epoch_ts = time.time()

    dfc = DateTimeFactCollector()
    facts_dict = dfc.collect()['date_time']

    assert facts_dict['year'] == now.strftime('%Y')
    assert facts_dict['month'] == now.strftime('%m')
    assert facts_dict['weekday'] == now.strftime('%A')
    assert facts_dict['weekday_number'] == now.strftime('%w')
    assert facts_dict['weeknumber'] == now.strftime('%W')
    assert facts_dict['day'] == now.strftime('%d')
    assert facts_dict['hour'] == now.strftime('%H')
    assert facts

# Generated at 2022-06-11 04:34:10.394706
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Test if format and values are correct.
    """

    # Create instance
    dtf = DateTimeFactCollector()

    # Call method
    facts = dtf.collect()

    # Check what was returned
    assert type(facts) == dict
    assert 'date_time' in facts.keys()
    dt = facts['date_time']

    # Check date_time dict
    assert type(dt) == dict
    assert 'year' in dt.keys()
    assert type(dt['year']) == str
    assert 'month' in dt.keys()
    assert type(dt['month']) == str
    assert 'weekday' in dt.keys()
    assert type(dt['weekday']) == str
    assert 'weekday_number' in dt.keys()

# Generated at 2022-06-11 04:34:15.882839
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    datetime = DateTimeFactCollector()
    #  Mock module and collected_facts
    module = None
    collected_facts = None
    result = datetime.collect(module, collected_facts)
    assert 'date_time' in result
    assert 'date' in result['date_time']
    assert 'time' in result['date_time']
    assert 'hour' in result['date_time']

# Generated at 2022-06-11 04:34:26.620072
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Initialize a DateTimeFactCollector instance
    dt_fc = DateTimeFactCollector()
    # Create a test dict
    collected_facts = {}
    # Call method collect
    test_dict = dt_fc.collect(collected_facts)
    # Pull out the dict returned
    date_time_facts = test_dict['date_time']
    # Test to see if the dict returned is of the correct type
    assert isinstance(date_time_facts, dict)
    # Test to see if the date_time dict returned is non-empty
    assert date_time_facts
    # Test to see if the date_time dict returned has a particular fact
    assert 'weeknumber' in date_time_facts.keys()
    # Test to see if the date_time dict returned has a particular fact
    assert 'tz_dst'

# Generated at 2022-06-11 04:34:58.621711
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    host_name = {'localhost': '127.0.0.1',
                 'other_host': '0.0.0.0'}
    fact_collector = DateTimeFactCollector()

    # Test if method collect works correctly when calling DateTimeFactCollector.collect()
    assert(type(fact_collector.collect()) is dict)

# Generated at 2022-06-11 04:35:08.180633
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Test DateTimeFactCollector.collect()."""
    import ansible.module_utils.facts.collector
    import datetime
    import time

    module = object()
    collected_facts = object()
    # Create a DateTimeFactCollector object
    date_time_collector = ansible.module_utils.facts.collector.DateTimeFactCollector()

    # Store the timestamp once, then get the local time version from that
    epoch_ts = time.time()
    now = datetime.datetime.fromtimestamp(epoch_ts)
    # Store the timestamp once, then get the UTC time version from that
    epoch_ts = time.time()
    utcnow = datetime.datetime.utcfromtimestamp(epoch_ts)

    # Verify the values in the collect() output

# Generated at 2022-06-11 04:35:11.642874
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_collector = DateTimeFactCollector()
    facts_dict = date_time_collector.collect()
    assert 'date_time' in facts_dict
    assert int(facts_dict['date_time']['epoch']) == int(time.time())
    assert facts_dict['date_time']['epoch'] == facts_dict['date_time']['epoch_int']


# Generated at 2022-06-11 04:35:21.208565
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_facts = DateTimeFactCollector().collect().get('date_time', None)
    assert date_time_facts is not None
    assert date_time_facts['year'] != ''
    assert date_time_facts['month'] != ''
    assert date_time_facts['weekday'] != ''
    assert date_time_facts['weekday_number'] != ''
    assert date_time_facts['weeknumber'] != ''
    assert date_time_facts['day'] != ''
    assert date_time_facts['hour'] != ''
    assert date_time_facts['minute'] != ''
    assert date_time_facts['second'] != ''
    assert date_time_facts['epoch'] != ''
    assert date_time_facts['epoch_int'] != ''
    assert date_time_facts['date'] != ''

# Generated at 2022-06-11 04:35:23.897659
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    f = DateTimeFactCollector()
    result = f.collect()
    for item in f._fact_ids:
        assert result['date_time'][item]

# Generated at 2022-06-11 04:35:25.708980
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector.collect()

# Generated at 2022-06-11 04:35:28.577972
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_collector = DateTimeFactCollector()
    date_time = date_collector.collect()['date_time']
    assert date_time['iso8601']
    assert date_time['iso8601_micro']

# Generated at 2022-06-11 04:35:39.973112
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtf = DateTimeFactCollector()
    facts = dtf.collect()
    assert 'date_time' in facts
    assert 'minute' in facts['date_time']
    assert facts['date_time']['minute'] != ''
    assert 'hour' in facts['date_time']
    assert facts['date_time']['hour'] != ''
    assert 'day' in facts['date_time']
    assert facts['date_time']['day'] != ''
    assert 'weekday' in facts['date_time']
    assert facts['date_time']['weekday'] != ''
    assert 'weekday_number' in facts['date_time']
    assert facts['date_time']['weekday_number'] != ''
    assert 'weeknumber' in facts['date_time']

# Generated at 2022-06-11 04:35:41.797062
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtf = DateTimeFactCollector()
    assert dtf.collect().keys() == set(['date_time'])

# Generated at 2022-06-11 04:35:50.752283
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.collector.system import UptimeFactCollector
    from ansible.module_utils.facts.system.date_time import DateTimeFactCollector
    from ansible.module_utils.facts.system import DistributionFactCollector
    from ansible.module_utils.facts.system import HardwareFactCollector
    from ansible.module_utils.facts.system import PlatformFactCollector
    from ansible.module_utils.facts.system import VirtualFactCollector
    from ansible.module_utils.facts import gather_subset

    ansible_facts = default_collectors.populate()

    test_collectors = []

# Generated at 2022-06-11 04:37:03.549089
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts.collector import CollectedFact
    import ansible.module_utils.facts.system.date_time as date_time
    date_time_collector = date_time.DateTimeFactCollector()
    date_time_fact_id = date_time_collector.get_fact_id()
    date_time_name = date_time_collector.get_name()
    date_time_fact_id_list = date_time_collector.get_fact_ids()
    date_time_fact = CollectedFact(date_time_name, date_time_fact_id, date_time_collector)
    collected_facts = {date_time_fact_id: date_time_fact}

    # create facts_dict for return value of method collect
    date_time_facts_

# Generated at 2022-06-11 04:37:13.666850
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt_collector = DateTimeFactCollector()
    dt_facts = dt_collector.collect()['date_time']
    assert isinstance(dt_facts['year'], str)
    assert isinstance(dt_facts['month'], str)
    assert isinstance(dt_facts['weekday'], str)
    assert isinstance(dt_facts['weekday_number'], str)
    assert isinstance(dt_facts['weeknumber'], str)
    assert isinstance(dt_facts['day'], str)
    assert isinstance(dt_facts['hour'], str)
    assert isinstance(dt_facts['minute'], str)
    assert isinstance(dt_facts['second'], str)
    assert isinstance(dt_facts['epoch'], str)

# Generated at 2022-06-11 04:37:22.667043
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Create initialized instance of a DateTimeFactCollector
    DateTimeFactCollectorInstance = DateTimeFactCollector()

    # Create a dictionary (with 2 keys) of parameters used to initialize an instance of DateTimeFactCollector
    def init_parameters_dict(epoch_time_dummy):
        return {"epoch_time": epoch_time_dummy}
    # Import mocker class
    from ansible.module_utils.facts.collector import MockerCollector

    # Obtain a dictionary of results
    test_dict = MockerCollector.test_collector(DateTimeFactCollectorInstance, init_parameters_dict)

    # Test if expected results are returned
    assert test_dict['epoch'] != None

# Generated at 2022-06-11 04:37:32.007101
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtf = DateTimeFactCollector()
    facts = dtf.collect()
    assert isinstance(facts, dict)
    assert 'date_time' in facts
    assert 'epoch' in facts['date_time']
    assert 'epoch_int' in facts['date_time']
    assert 'iso8601' in facts['date_time']
    assert 'iso8601_basic' in facts['date_time']
    assert 'iso8601_basic_short' in facts['date_time']
    assert 'iso8601_micro' in facts['date_time']
    assert 'month' in facts['date_time']
    assert 'time' in facts['date_time']
    assert 'date' in facts['date_time']
    assert 'day' in facts['date_time']

# Generated at 2022-06-11 04:37:33.571447
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_collector = DateTimeFactCollector()
    assert date_time_collector.collect() is not {}

# Generated at 2022-06-11 04:37:44.184422
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    ret = dtfc.collect()
    assert isinstance(ret, dict)
    assert 'date_time' in ret

    date_time_facts = ret['date_time']
    assert isinstance(date_time_facts, dict)

    assert 'year' in date_time_facts
    assert 'month' in date_time_facts
    assert 'weekday' in date_time_facts
    assert 'weekday_number' in date_time_facts
    assert 'weeknumber' in date_time_facts
    assert 'day' in date_time_facts
    assert 'hour' in date_time_facts
    assert 'minute' in date_time_facts
    assert 'second' in date_time_facts
    assert 'epoch' in date_time_facts

# Generated at 2022-06-11 04:37:45.777002
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fc = DateTimeFactCollector()
    for key in fc.collect().keys():
        assert key

# Generated at 2022-06-11 04:37:56.206946
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    date_time_facts_dict = DateTimeFactCollector.collect()
    date_time_dict = date_time_facts_dict.get('date_time')

    # Check that all expected keys are in the dictionary
    assert set(date_time_dict.keys()) == {'year', 'month', 'weekday', 'weekday_number', 'weeknumber', 'day', 'hour',
                                          'minute', 'second', 'epoch', 'epoch_int', 'date', 'time', 'iso8601_micro',
                                          'iso8601', 'iso8601_basic', 'iso8601_basic_short', 'tz', 'tz_dst',
                                          'tz_offset'}

    local_time = time.localtime()

    # Check that keys have the expected values
    assert local_time.tm_

# Generated at 2022-06-11 04:37:59.646879
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = DateTimeFactCollector()
    facts = dt.collect()
    assert 'date_time' in facts
    assert isinstance(facts['date_time'], dict)
    assert 'epoch' in facts['date_time']

# Generated at 2022-06-11 04:38:00.985003
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    x = DateTimeFactCollector()
    x.collect()