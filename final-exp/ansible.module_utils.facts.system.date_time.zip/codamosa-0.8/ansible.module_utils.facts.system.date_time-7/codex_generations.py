

# Generated at 2022-06-11 04:28:17.587232
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dateTimeFactCollector = DateTimeFactCollector()
    dateTimeFactCollectorCollect = dateTimeFactCollector.collect()

    assert dateTimeFactCollectorCollect.get('date_time') is not None
    epoch = dateTimeFactCollectorCollect.get('date_time').get('epoch')
    assert isinstance(epoch, str) and epoch.isdigit()
    epoch = dateTimeFactCollectorCollect.get('date_time').get('epoch_int')
    assert isinstance(epoch, str) and epoch.isdigit()

# Generated at 2022-06-11 04:28:26.496537
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    (dtf, facts_dict) = DateTimeFactCollector().collect()

    try:
        int(facts_dict['date_time']['epoch'])
    except ValueError:
        assert False, "epoch must be a string or integer"

    try:
        int(facts_dict['date_time']['epoch_int'])
    except ValueError:
        assert False, "epoch_int must be a string or integer"

    assert type(facts_dict['date_time']['year']) is str, "year must be a string"
    assert type(facts_dict['date_time']['month']) is str, "month must be a string"
    assert type(facts_dict['date_time']['day']) is str, "day must be a string"

# Generated at 2022-06-11 04:28:31.038961
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_fact_collector = DateTimeFactCollector()
    date_facts = date_fact_collector.collect()
    assert date_facts['date_time']['year'] == "2018"
    assert date_facts['date_time']['time'] == "13:56:39"
    assert date_facts['date_time']['tz_dst'] == 'PDT'

# Generated at 2022-06-11 04:28:40.374151
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """ DateTimeFactCollector - Check if the generated facts are valid """
    from datetime import datetime, timedelta
    import time
    import pytz

    date_time_facts = DateTimeFactCollector().collect()['date_time']

    # Test Epoch
    epoch_ts = time.time()
    assert date_time_facts['epoch'] == str(int(epoch_ts))
    assert date_time_facts['epoch_int'] == str(int(epoch_ts))

    # Test Year
    now = datetime.now()
    date_time_facts['year'] == str(now.year)

    # Test Month
    date_time_facts['month'] == str("{0:02d}".format(now.month))

    # Test Day

# Generated at 2022-06-11 04:28:48.616177
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    facts = dtfc.collect()
    # method collect returns a dict of dict
    assert (isinstance(facts, dict))
    assert ('date_time' in facts)

    # make sure these keys exist in dict coming from DateTimeFactCollector
    for key in ('iso8601_micro', 'tz_offset', 'weekday_number', 'date', 'time', 'tz_dst', 'month', 'weekdegree',
                'year', 'hour', 'epoch', 'tz', 'minute', 'day', 'isoweekday', 'weekday', 'weeknumber', 'second'):
       assert (key in facts['date_time'])

# Generated at 2022-06-11 04:28:59.816122
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Initializing the DateTimeFactCollector object
    datetime_fact_collector = DateTimeFactCollector()
    # Using the following data for test
    now = datetime.datetime.fromtimestamp(time.time())
    utcnow = datetime.datetime.utcfromtimestamp(time.time())

# Generated at 2022-06-11 04:29:03.484675
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    return_value = fact_collector.collect()
    assert return_value['date_time']['year'] != 0

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-11 04:29:12.222729
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    d = DateTimeFactCollector()


# Generated at 2022-06-11 04:29:12.840494
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    pass

# Generated at 2022-06-11 04:29:14.883048
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    f = DateTimeFactCollector('date_time')
    assert isinstance(f.collect(), dict)

# Generated at 2022-06-11 04:29:27.081862
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = DateTimeFactCollector()
    ep_ts = time.time()
    nw = datetime.datetime.fromtimestamp(ep_ts)
    utc_nw = datetime.datetime.utcfromtimestamp(ep_ts)

    date_time_facts = {}
    date_time_facts['year'] = nw.strftime('%Y')
    date_time_facts['month'] = nw.strftime('%m')
    date_time_facts['weekday'] = nw.strftime('%A')
    date_time_facts['weekday_number'] = nw.strftime('%w')
    date_time_facts['weeknumber'] = nw.strftime('%W')
    date_time_facts['day'] = nw.strftime('%d')
    date

# Generated at 2022-06-11 04:29:37.829554
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt_collector = DateTimeFactCollector()
    import datetime
    import time
    epoch_ts = time.time()
    now = datetime.datetime.fromtimestamp(epoch_ts)
    utcnow = datetime.datetime.utcfromtimestamp(epoch_ts)

    ret = dt_collector.collect()

    assert ret['date_time']['date'] == now.strftime('%Y-%m-%d')
    assert ret['date_time']['time'] == now.strftime('%H:%M:%S')
    assert ret['date_time']['iso8601_micro'] == utcnow.strftime("%Y-%m-%dT%H:%M:%S.%fZ")

# Generated at 2022-06-11 04:29:45.155358
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # pylint: disable=unused-argument
    def mock_is_file(filename):
        return False

    collect_method = DateTimeFactCollector.collect
    dtfc = DateTimeFactCollector(mock_is_file)
    dtfc_collect = collect_method(dtfc)
    assert type(dtfc_collect) is dict
    assert type(dtfc_collect['date_time']) is dict
    assert type(dtfc_collect['date_time']['hour']) is str

# Generated at 2022-06-11 04:29:54.852827
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_facts = DateTimeFactCollector().collect()
    assert date_time_facts['date_time'] is not None
    assert date_time_facts['date_time']['year'] is not None
    assert date_time_facts['date_time']['month'] is not None
    assert date_time_facts['date_time']['weekday'] is not None
    assert date_time_facts['date_time']['weekday_number'] is not None
    assert date_time_facts['date_time']['weeknumber'] is not None
    assert date_time_facts['date_time']['day'] is not None
    assert date_time_facts['date_time']['hour'] is not None
    assert date_time_facts['date_time']['minute'] is not None

# Generated at 2022-06-11 04:30:05.782517
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact = DateTimeFactCollector()
    collected_facts = fact.collect()
    assert collected_facts is not None
    assert 'date_time' in collected_facts
    assert 'epoch' in collected_facts['date_time']
    assert 'epoch_int' in collected_facts['date_time']
    assert 'date' in collected_facts['date_time']
    assert 'time' in collected_facts['date_time']
    assert 'year' in collected_facts['date_time']
    assert 'month' in collected_facts['date_time']
    assert 'day' in collected_facts['date_time']
    assert 'weekday' in collected_facts['date_time']
    assert 'weekday_number' in collected_facts['date_time']
    assert 'weeknumber' in collected_facts['date_time']

# Generated at 2022-06-11 04:30:15.956627
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import platform

    local_data = DateTimeFactCollector.collect()

    # Skip the test if the platform is not Linux
    if str(platform.system()) != "Linux":
        return

    assert 'date_time' in local_data.keys()
    assert 'year' in local_data['date_time'].keys()
    assert 'month' in local_data['date_time'].keys()
    assert 'weekday' in local_data['date_time'].keys()
    assert 'weekday_number' in local_data['date_time'].keys()
    assert 'weeknumber' in local_data['date_time'].keys()
    assert 'day' in local_data['date_time'].keys()
    assert 'hour' in local_data['date_time'].keys()
    assert 'minute' in local

# Generated at 2022-06-11 04:30:19.510621
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dMock = DateTimeFactCollector(None)
    dMock.collect()
    assert dMock.name in BaseFactCollector()
    assert dMock.name in dMock._fact_ids


# Generated at 2022-06-11 04:30:29.451972
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    res = dtfc.collect()
    assert isinstance(res['date_time']['year'], basestring)
    assert isinstance(res['date_time']['month'], basestring)
    assert isinstance(res['date_time']['weekday'], basestring)
    assert isinstance(res['date_time']['weekday_number'], basestring)
    assert isinstance(res['date_time']['weeknumber'], basestring)
    assert isinstance(res['date_time']['day'], basestring)
    assert isinstance(res['date_time']['hour'], basestring)
    assert isinstance(res['date_time']['minute'], basestring)
    assert isinstance

# Generated at 2022-06-11 04:30:32.513309
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    collected_facts = fact_collector.collect()
    assert collected_facts['date_time']['month'] == datetime.datetime.now().strftime('%m')


# Generated at 2022-06-11 04:30:42.813233
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    datetime_facts = DateTimeFactCollector()
    collected_facts = dict()

# Generated at 2022-06-11 04:30:53.585706
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-11 04:31:01.215986
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Call collect for DateTimeFactCollector to create a dictionary
    # of date and time related facts
    date_time_facts = DateTimeFactCollector().collect()['date_time']
    # Assert expected date and time facts
    assert date_time_facts['date']
    assert date_time_facts['day']
    assert date_time_facts['epoch']
    assert date_time_facts['hour']
    assert date_time_facts['iso8601']
    assert date_time_facts['iso8601_basic']
    assert date_time_facts['iso8601_basic_short']
    assert date_time_facts['iso8601_micro']
    assert date_time_facts['minute']
    assert date_time_facts['month']
    assert date_time_facts['second']
    assert date_time_

# Generated at 2022-06-11 04:31:11.651558
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # set up instance of class DateTimeFactCollector
    dtfc = DateTimeFactCollector()
    dtfc.collect()

    # set up expected results
    now = datetime.datetime.now()
    unow = datetime.datetime.utcnow()
    year = now.strftime('%Y')
    month = now.strftime('%m')
    weekday = now.strftime('%A')
    weekday_number = now.strftime('%w')
    weeknumber = now.strftime('%W')
    day = now.strftime('%d')
    hour = now.strftime('%H')
    minute = now.strftime('%M')
    second = now.strftime('%S')
    epoch = int(time.time())

# Generated at 2022-06-11 04:31:23.097568
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collect_date_time_instance = DateTimeFactCollector()
    # create a datetime instance for today
    date_time_instance = datetime.datetime.now()
    # create a dictionary to hold the values of date_time
    date_time = {}
    date_time['year'] = date_time_instance.strftime("%Y")
    date_time['month'] = date_time_instance.strftime("%m")
    date_time['weekday'] = date_time_instance.strftime("%A")
    date_time['weekday_number'] = date_time_instance.strftime("%w")
    date_time['weeknumber'] = date_time_instance.strftime("%W")
    date_time['day'] = date_time_instance.strftime("%d")

# Generated at 2022-06-11 04:31:25.882525
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    target = DateTimeFactCollector()
    result = target.collect()
    assert result['date_time'] != ''
    assert len(result['date_time']) > 0

# Generated at 2022-06-11 04:31:36.067418
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Collect facts
    collector = DateTimeFactCollector()
    facts_dict = collector.collect()

    assert type(facts_dict) is dict
    assert 'date_time' in facts_dict

    date_time_dict = facts_dict['date_time']
    assert type(date_time_dict) is dict
    for key in ('year', 'month', 'weekday', 'weekday_number', 'weeknumber', 'day', 'hour', 'minute', 'second', 'epoch', 'date', 'time', 'iso8601_micro', 'iso8601', 'iso8601_basic', 'iso8601_basic_short', 'tz', 'tz_dst', 'tz_offset'):
        assert key in date_time_dict
        assert type(date_time_dict[key]) is str
        assert date_time_dict

# Generated at 2022-06-11 04:31:40.172928
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time = DateTimeFactCollector()
    date_time_result = date_time.collect()
    month = date_time_result['date_time']['month']
    
    assert month != None
    assert len(month) == 2
    assert int(month) > 0
    assert int(month) <= 12

# Generated at 2022-06-11 04:31:46.436489
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    ansible_facts = {'ansible_architecture': 'x86_64'}
    DateTimeFactCollector_obj = DateTimeFactCollector()
    collected_date_time_facts = DateTimeFactCollector_obj.collect(None, ansible_facts)
    assert collected_date_time_facts['date_time'] is not None
    assert collected_date_time_facts['date_time']['month'] is not None

# Generated at 2022-06-11 04:31:57.059717
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_instance = DateTimeFactCollector()

# Generated at 2022-06-11 04:32:07.752118
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    date = datetime.date.today()
    date_facts = fact_collector.collect()

# Generated at 2022-06-11 04:32:24.533897
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import datetime
    collector = DateTimeFactCollector()
    # Since we can't mock the current time, the best we can do is test
    # that the value of the 'date' fact complies with the expected format.
    now = datetime.datetime.today().strftime('%Y-%m-%d')

# Generated at 2022-06-11 04:32:34.695327
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    DTF = DateTimeFactCollector()
    output = DTF.collect()
    assert output.get('date_time').get('year') == datetime.datetime.now().strftime('%Y')
    assert output.get('date_time').get('month') == datetime.datetime.now().strftime('%m')
    assert output.get('date_time').get('weekday') in ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
    assert output.get('date_time').get('weekday_number') in ['0', '1', '2', '3', '4', '5', '6']
    assert int(output.get('date_time').get('weeknumber')) in range(0, 53)

# Generated at 2022-06-11 04:32:35.519926
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    DateTimeFactCollector().collect()

# Generated at 2022-06-11 04:32:46.244690
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    x = DateTimeFactCollector()
    assert type(x.collect()) is dict, 'The returned value from collect is not a dict'
    assert type(x.collect()['date_time']) is dict, 'The returned value from collect is not a dict'
    for key in ['year', 'month', 'weekday', 'weekday_number', 'weeknumber', 'day', 'hour', 'minute', 'second', 'epoch', 'date', 'time', 'iso8601_micro', 'iso8601', 'iso8601_basic', 'tz', 'tz_dst', 'tz_offset']:
        assert key in x.collect()['date_time'], 'The key <{0}> is missed in the returned dict of collect'.format(key)

# Generated at 2022-06-11 04:32:55.501348
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Unit test of method collect of class DateTimeFactCollector
    """
    #if __name__ == '__main__':
    test_collector = DateTimeFactCollector()
    test_collector_result = test_collector.collect()
    #test_collector_result_dict = dict(test_collector_result)
    #print(test_collector_result)
    assert('date_time' in test_collector_result)
    assert(test_collector_result['date_time']['year'] != '')
    assert(test_collector_result['date_time']['month'] != '')
    assert(test_collector_result['date_time']['weekday'] != '')

# Generated at 2022-06-11 04:32:58.216235
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = DateTimeFactCollector()
    dt.collect()
    assert isinstance(dt.collect(), dict)
    assert 'date_time' in dt.collect()

# Generated at 2022-06-11 04:33:08.857112
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = time.strftime('%Y-%m-%dT%H:%M:%S', time.gmtime())

# Generated at 2022-06-11 04:33:19.111961
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    df = DateTimeFactCollector()
    facts = df.collect(None, None)
    assert 'date_time' in facts
    assert type(facts['date_time']) is dict
    assert 'year' in facts['date_time']
    assert type(facts['date_time']['year']) is str
    assert 'month' in facts['date_time']
    assert type(facts['date_time']['month']) is str
    assert 'weekday' in facts['date_time']
    assert type(facts['date_time']['weekday']) is str
    assert 'weekday_number' in facts['date_time']
    assert type(facts['date_time']['weekday_number']) is str
    assert 'weeknumber' in facts['date_time']

# Generated at 2022-06-11 04:33:24.517950
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-11 04:33:34.770301
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = DateTimeFactCollector()
    result = dt.collect()

# Generated at 2022-06-11 04:33:58.885596
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collect_dt = DateTimeFactCollector()
    result = collect_dt.collect()
    assert result is not None

# Generated at 2022-06-11 04:34:02.882161
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    
    # Retrieve a DateTimeFactCollector instance
    collector = DateTimeFactCollector()
    
    # Collect ansible facts
    ansible_facts = collector.collect()
    
    # assert test
    assert 'date_time' in ansible_facts

# Generated at 2022-06-11 04:34:09.042414
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dh = DateTimeFactCollector()
    dt_facts = dh.collect()
    # test if the key is exist in dt_facts
    assert 'date_time' in dt_facts
    # test if the value type of 'date_time' is a dict
    assert isinstance(dt_facts['date_time'], dict)
    # test the length of 'date_time'
    assert len(dt_facts['date_time']) > 0


# Generated at 2022-06-11 04:34:12.126829
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Test the method DateTimeFactCollector.collect"""
    dtf = DateTimeFactCollector()
    facts = dtf.collect()
    assert facts['date_time']['year'] == datetime.datetime.now().strftime('%Y')

# Generated at 2022-06-11 04:34:22.884852
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    '''
    Fake datetime for testing
    '''
    class FakeDatetime(datetime.datetime):
        @classmethod
        def utcnow(cls):
            return cls(1970, 1, 1, 12, 0, 0)

        @classmethod
        def fromtimestamp(cls, timestamp):
            return cls(1970, 1, 1, 12, 0, 0)

        @classmethod
        def now(cls):
            return cls(1970, 1, 1, 12, 0, 0)

        @classmethod
        def strptime(cls, date_string, format):
            return cls(1970, 1, 1, 12, 0, 0)


# Generated at 2022-06-11 04:34:25.283788
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    obj = DateTimeFactCollector()
    kwargs = dict()
    res = obj.collect(**kwargs)
    assert res is not None

# Generated at 2022-06-11 04:34:35.211335
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    collected_facts = fact_collector.collect()
    assert 'date_time' in collected_facts
    assert 'date' in collected_facts['date_time']
    assert 'epoch' in collected_facts['date_time']
    assert 'iso8601_basic' in collected_facts['date_time']
    assert 'iso8601_basic_short' in collected_facts['date_time']
    assert 'iso8601_micro' in collected_facts['date_time']
    assert 'iso8601' in collected_facts['date_time']
    assert 'minute' in collected_facts['date_time']
    assert 'month' in collected_facts['date_time']
    assert 'second' in collected_facts['date_time']
    assert 'time' in collected_facts

# Generated at 2022-06-11 04:34:35.980247
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    assert DateTimeFactCollector().collect()

# Generated at 2022-06-11 04:34:44.598063
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact = DateTimeFactCollector()

    result = fact.collect()

# Generated at 2022-06-11 04:34:47.212364
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
  dt_col = DateTimeFactCollector()
  dt_facts = dt_col.collect()
  assert dt_facts['date_time'] is not None


# Generated at 2022-06-11 04:35:27.800292
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    DTFC = DateTimeFactCollector()
    # Start time
    t_start = time.time()

    # Create base time
    now = datetime.datetime.fromtimestamp(t_start)
    utcnow = datetime.datetime.utcfromtimestamp(t_start)

    # Run collect
    collected_facts = DTFC.collect()

    # End time
    t_end = time.time()

    # Check that the time has not changed
    assert t_start == t_end

    # Check every collected fact has a correct value
    assert collected_facts['date_time']['year'] == now.strftime('%Y')
    assert collected_facts['date_time']['month'] == now.strftime('%m')
    assert collected_facts['date_time']['weekday'] == now

# Generated at 2022-06-11 04:35:39.234632
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dc = DateTimeFactCollector()

# Generated at 2022-06-11 04:35:43.996470
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dateTimeFactCollector = DateTimeFactCollector()
    dateTimeFacts = dateTimeFactCollector.collect()
    assert dateTimeFacts['date_time']['date'] == time.strftime("%Y-%m-%d")
    assert dateTimeFacts['date_time']['time'] == time.strftime("%H:%M:%S")

# Generated at 2022-06-11 04:35:52.914440
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Unit test for method collect of class DateTimeFactCollector
    """

# Generated at 2022-06-11 04:35:59.239259
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    c = DateTimeFactCollector()
    result = c.collect()


# Generated at 2022-06-11 04:36:09.045922
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Unit test for method collect of class DateTimeFactCollector
    """
    dt_fact_collector = DateTimeFactCollector()
    # forcing methods to return known values
    dt_fact_collector.now = lambda: datetime.datetime(2015, 7, 4, 15, 20, 23)
    dt_fact_collector.epoch_ts = lambda: 1435974823.353668
    dt_fact_collector.utcfromtimestamp = datetime.datetime.utcfromtimestamp
    dt_fact_collector.strftime = datetime.datetime.strftime
    dt_fact_collector.tzname = lambda : ('US/Pacific', 'US/Pacific')
    dt_fact_collector.strftime = datetime.datetime.strftime
    #

# Generated at 2022-06-11 04:36:17.041370
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    
    # Inits
    date_time_facts_collector = DateTimeFactCollector()
    collected_facts = {}

# Generated at 2022-06-11 04:36:26.680450
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    testdict = DateTimeFactCollector().collect()
    assert 'date_time' in testdict
    assert 'epoch' in testdict['date_time']
    assert 'year' in testdict['date_time']
    assert 'month' in testdict['date_time']
    assert 'weekday' in testdict['date_time']
    assert 'weekday_number' in testdict['date_time']
    assert 'weeknumber' in testdict['date_time']
    assert 'day' in testdict['date_time']
    assert 'hour' in testdict['date_time']
    assert 'minute' in testdict['date_time']
    assert 'second' in testdict['date_time']
    assert 'date' in testdict['date_time']
    assert 'time' in testdict['date_time']
   

# Generated at 2022-06-11 04:36:35.962968
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Arrange
    dtfc = DateTimeFactCollector()

    # Act
    actual_facts = dtfc.collect()

    # Assert
    # Add your own assertions

# Generated at 2022-06-11 04:36:43.544950
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collectors.date_time.date_time import DateTimeFactCollector

    # obtain facts from DateTimeFactCollector
    facts = FactCollector(collectors=[DateTimeFactCollector],
                          namespace='test_date_time_collector').collect()

    assert 'date_time' in facts, 'no date_time facts in: {}'.format(facts)
    date_time_facts = facts['date_time']
    assert 'year' in date_time_facts, 'no year in date_time facts in: {}'.format(facts)
    assert 'month' in date_time_facts, 'no month in date_time facts in: {}'.format(facts)

# Generated at 2022-06-11 04:37:53.780106
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    datetimefact_collector = DateTimeFactCollector()
    facts = datetimefact_collector.collect()

    # Facts should be a dict
    assert isinstance(facts, dict)

    # Facts will have a key, 'date_time'
    assert 'date_time' in facts

    # Facts['date_time'] will be a dict
    assert isinstance(facts['date_time'], dict)

    # Facts['date_time'] will contain 'year'
    assert 'year' in facts['date_time']

    # Facts['date_time']['year'] will be a str
    assert isinstance(facts['date_time']['year'], str)

    # Facts['date_time'] will contain 'month'
    assert 'month' in facts['date_time']

    # Facts['date_time']['month

# Generated at 2022-06-11 04:38:03.846377
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # load data from the ansible module (which is the only source)
    from ansible.module_utils.facts.collector import BaseFileFactsCollector
    collected_facts = BaseFileFactsCollector.collect(None, None)

    # print("collected_facts=%s" % collected_facts)
    # we expect only one fact collection
    assert("date_time" in collected_facts.keys())
    assert("year" in collected_facts['date_time'].keys())
    assert("month" in collected_facts['date_time'].keys())
    assert("weekday" in collected_facts['date_time'].keys())
    assert("weekday_number" in collected_facts['date_time'].keys())
    assert("weeknumber" in collected_facts['date_time'].keys())

# Generated at 2022-06-11 04:38:04.630882
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    dtfc.collect()

# Generated at 2022-06-11 04:38:13.339767
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_collector = DateTimeFactCollector()
    date_time_facts = date_time_collector.collect()
    assert 'date_time' in date_time_facts
    assert 'year' in date_time_facts['date_time']
    assert 'month' in date_time_facts['date_time']
    assert 'weekday' in date_time_facts['date_time']
    assert 'weekday_number' in date_time_facts['date_time']
    assert 'weeknumber' in date_time_facts['date_time']
    assert 'day' in date_time_facts['date_time']
    assert 'hour' in date_time_facts['date_time']
    assert 'minute' in date_time_facts['date_time']