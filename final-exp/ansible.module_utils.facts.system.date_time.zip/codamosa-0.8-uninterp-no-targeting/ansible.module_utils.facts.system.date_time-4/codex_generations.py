

# Generated at 2022-06-20 19:11:53.339752
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    fake_fact_collector = DateTimeFactCollector(None)

    fake_fact_dict = {}

# Generated at 2022-06-20 19:11:54.781515
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    facts = DateTimeFactCollector()
    name = facts.name
    assert facts
    assert name == 'date_time'

# Generated at 2022-06-20 19:11:57.066395
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dateTimeFactCollector = DateTimeFactCollector()
    assert dateTimeFactCollector.name == 'date_time'
    assert dateTimeFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:12:02.837358
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dateTimeFactCollector = DateTimeFactCollector()
    result = dateTimeFactCollector.collect()
    assert(len(result) > 0)
    assert(result['date_time'])
    assert(result['date_time']['year'])
    assert(result['date_time']['month'])
    assert(result['date_time']['weekday'])
    assert(result['date_time']['weekday_number'])
    assert(result['date_time']['weeknumber'])
    assert(result['date_time']['day'])
    assert(result['date_time']['hour'])
    assert(result['date_time']['minute'])
    assert(result['date_time']['second'])

# Generated at 2022-06-20 19:12:08.035423
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_facts = DateTimeFactCollector()
    assert date_time_facts.name == 'date_time'
    assert len(date_time_facts._fact_ids) == 0


# Generated at 2022-06-20 19:12:18.190933
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # creating object of class DateTimeFactCollector
    dt = DateTimeFactCollector()
    datetime_facts = dt.collect()
    assert 'date_time' in datetime_facts, 'date_time is not in datetime_facts'
    assert 'year' in datetime_facts['date_time'], 'year is not in datetime_facts'
    assert 'month' in datetime_facts['date_time'], 'month is not in datetime_facts'
    assert 'weekday' in datetime_facts['date_time'], 'weekday is not in datetime_facts'
    assert 'weekday_number' in datetime_facts['date_time'], 'weekday_number is not in datetime_facts'

# Generated at 2022-06-20 19:12:21.307924
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'
    assert x._fact_ids == set()

# Generated at 2022-06-20 19:12:23.921273
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'
    assert isinstance(date_time_fact_collector.collect(), dict)

# Generated at 2022-06-20 19:12:27.734196
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'
    assert x.epoch

# Generated at 2022-06-20 19:12:37.982651
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts import FactsCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors import network

    # Create a network AddressResolver object
    resolver = network.AddressResolver()

    # Create a list of all the collectors
    collectors_list = [
        DateTimeFactCollector()
    ]

    # Pair the collectors with their resolver
    resolver_map = {
        DateTimeFactCollector.name: resolver
    }

    # Create a FactsCollector object with the collectors list
    collector = FactsCollector(collectors_list)

    assert(isinstance(collector, FactsCollector))
    assert(isinstance(collector, BaseFactCollector))

    # Make sure all the collectors are in their correct place

# Generated at 2022-06-20 19:12:47.206825
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """ Unit test for method collect of class DateTimeFactCollector """

    from ansible.module_utils.facts.collector import get_collector_instance

    dtCollector = get_collector_instance('DateTimeFactCollector')
    result = dtCollector.collect()

    assert isinstance(result, dict)
    assert 'date_time' in result
    assert isinstance(result['date_time'], dict)
    assert result['date_time'] != {}

# Generated at 2022-06-20 19:12:50.850478
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtf = DateTimeFactCollector()
    assert dtf.name == 'date_time'
    assert isinstance(dtf._fact_ids, set)


# Generated at 2022-06-20 19:13:01.425952
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Set up the test input and expected result
    module_name = 'date_time'
    collected_facts = None

# Generated at 2022-06-20 19:13:02.995820
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert isinstance(DateTimeFactCollector(), DateTimeFactCollector)

# Generated at 2022-06-20 19:13:04.223110
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert isinstance(DateTimeFactCollector, object)

# Generated at 2022-06-20 19:13:06.620736
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_collector = DateTimeFactCollector()
    assert date_time_collector.name == 'date_time'
    assert date_time_collector._fact_ids == set()


# Generated at 2022-06-20 19:13:09.336855
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    f = DateTimeFactCollector()
    assert f.name == 'date_time'

# Generated at 2022-06-20 19:13:21.331594
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    class MockModule:
        def __init__(self, params):
            self.params = params

    class MockCollector:
        def __init__(self):
            self.facts = {}

    class MockFacts:
        def __init__(self, facts):
            self.facts = facts

    # Run collect method
    collector = DateTimeFactCollector()
    facts = MockFacts({})
    module = MockModule({'gather_subset': ['all']})
    collector.collect(module=module, collected_facts=facts)

    # Check collected values
    assert facts.facts['date_time']['year'] is not None
    assert facts.facts['date_time']['month'] is not None
    assert facts.facts['date_time']['weekday'] is not None

# Generated at 2022-06-20 19:13:22.439509
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()


# Generated at 2022-06-20 19:13:25.094539
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj.name == 'date_time', \
     'Test Failed: Constructor of DateTimeFactCollector is broken'

# Generated at 2022-06-20 19:13:35.658034
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dc = DateTimeFactCollector()
    result = dc.collect()
    assert result == 'date_time'
    assert isinstance(result,dict)

# Generated at 2022-06-20 19:13:39.516869
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    datetime_fact_col = DateTimeFactCollector()
    assert datetime_fact_col.name == 'date_time'
    assert datetime_fact_col.collect() is not None

# Generated at 2022-06-20 19:13:43.012276
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Test date_time object creation
    x = DateTimeFactCollector()
    assert x.name == 'date_time'

# Generated at 2022-06-20 19:13:51.543603
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    # Test format of year, month, weekday, day, hour, minute and second.
    assert date_time_fact_collector.collect().get('date_time').get('year').isdigit()
    assert len(date_time_fact_collector.collect().get('date_time').get('year')) == 4
    assert date_time_fact_collector.collect().get('date_time').get('month').isdigit()
    assert len(date_time_fact_collector.collect().get('date_time').get('month')) == 2
    assert date_time_fact_collector.collect().get('date_time').get('weekday').isalpha()
    assert date_time_fact_collector.collect().get('date_time').get

# Generated at 2022-06-20 19:14:02.740776
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collector = DateTimeFactCollector()
    result = collector.collect()
    assert 'date_time' in result
    date_time = result['date_time']
    assert 'year' in date_time
    assert 'month' in date_time
    assert 'weekday' in date_time
    assert 'weekday_number' in date_time
    assert 'weeknumber' in date_time
    assert 'day' in date_time
    assert 'hour' in date_time
    assert 'minute' in date_time
    assert 'second' in date_time
    assert 'epoch' in date_time
    assert 'epoch_int' in date_time
    assert 'date' in date_time
    assert 'time' in date_time
    assert 'iso8601_micro' in date_time

# Generated at 2022-06-20 19:14:13.055239
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Initialize DateTimeFactCollector
    DateTimeFactCollector_test = DateTimeFactCollector()

    # Test collect method
    facts_dict = DateTimeFactCollector_test.collect()

# Generated at 2022-06-20 19:14:17.810547
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtFC = DateTimeFactCollector()

    # check if member variables has been set properly
    assert dtFC.name == 'date_time'
    assert dtFC._fact_ids == set()

    # check the collect function
    result = dtFC.collect()
    assert 'date_time' in result



# Generated at 2022-06-20 19:14:20.920668
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    _date_time_collector = DateTimeFactCollector(None)


if __name__ == '__main__':
    test_DateTimeFactCollector()

# Generated at 2022-06-20 19:14:23.763113
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt.name == 'date_time'
    assert dt._fact_ids == set()

# Generated at 2022-06-20 19:14:29.167980
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    result = fact_collector.collect()

    assert result.get('date_time')
    assert result['date_time']['weekday'] == 'Monday'

if __name__ == '__main__':
    test_DateTimeFactCollector_collect()

# Generated at 2022-06-20 19:14:48.523156
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_collector = DateTimeFactCollector()
    assert date_time_collector.name == 'date_time'
    assert len(date_time_collector._fact_ids) == 0

# Generated at 2022-06-20 19:14:51.809549
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Create instance of DateTimeFactCollector
    dt_fact_col = DateTimeFactCollector()
    # Check name
    assert dt_fact_col.name == "date_time"

# Generated at 2022-06-20 19:15:03.197554
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_collector = DateTimeFactCollector({})
    date_time_dict = date_time_collector.collect()
    assert date_time_dict['date_time']['year']
    assert date_time_dict['date_time']['month']
    assert date_time_dict['date_time']['weekday']
    assert date_time_dict['date_time']['weekday_number']
    assert date_time_dict['date_time']['weeknumber']
    assert date_time_dict['date_time']['day']
    assert date_time_dict['date_time']['hour']
    assert date_time_dict['date_time']['minute']
    assert date_time_dict['date_time']['second']

# Generated at 2022-06-20 19:15:12.142580
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    ''' Test instantiation of DateTimeFactCollector class '''
    datetime_fc = DateTimeFactCollector()
    assert datetime_fc.name == 'date_time'
    for method in datetime_fc._fact_ids:
        assert hasattr(datetime_fc, method)
    date_time_facts = datetime_fc.collect()
    assert date_time_facts['date_time']['weeknumber'] == datetime.datetime.now().strftime("%W")


# Generated at 2022-06-20 19:15:17.688347
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_facts_obj = DateTimeFactCollector(None)
    assert date_time_facts_obj.name == 'date_time'
    assert date_time_facts_obj._fact_ids == set()


# Generated at 2022-06-20 19:15:29.780461
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Collect the facts by calling the collect method of DateTimeFactCollector
    """
    # Collect the facts
    collector = DateTimeFactCollector()
    facts = collector.collect()
    assert 'date_time' in facts
    assert isinstance(facts['date_time'], dict)

    # Assert each fact returned is as expected
    assert 'year' in facts['date_time']
    assert 'month' in facts['date_time']
    assert 'weekday' in facts['date_time']
    assert 'weekday_number' in facts['date_time']
    assert 'day' in facts['date_time']
    assert 'hour' in facts['date_time']
    assert 'minute' in facts['date_time']
    assert 'second' in facts['date_time']

# Generated at 2022-06-20 19:15:31.842397
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    d = DateTimeFactCollector()
    d.collect()

# Generated at 2022-06-20 19:15:36.258253
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'
    assert DateTimeFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:15:47.184140
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    class MockModule:
        def __getattr__(self, name):
            return None
    x = DateTimeFactCollector()
    result = x.collect(MockModule())
    assert type(result) is dict
    assert 'date_time' in result
    y = result['date_time']
    assert type(y) is dict
    assert y['year']
    assert y['month']
    assert y['weekday']
    assert y['weekday_number']
    assert y['weeknumber']
    assert y['day']
    assert y['hour']
    assert y['minute']
    assert y['second']
    assert y['epoch']
    assert y['epoch_int']
    assert y['date']
    assert y['time']
    assert y['iso8601_micro']

# Generated at 2022-06-20 19:15:58.626324
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    '''
    Unit test for method collect of class DateTimeFactCollector
    '''

    # Test collecting facts with a known starting point
    mock_now = datetime.datetime(2016, 1, 1, 0, 0, 0)
    mock_now_epoch = 1451606400
    mock_utcnow = datetime.datetime(2015, 12, 31, 23, 0, 0)

    date_time_fact_collector = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector.collect({}, {'datetime': mock_now, 'datetime_epoch': mock_now_epoch})

    assert date_time_facts['date_time']['year'] == '2016'
    assert date_time_facts['date_time']['month'] == '01'
   

# Generated at 2022-06-20 19:16:34.323217
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector_obj = DateTimeFactCollector()
    assert date_time_fact_collector_obj.name == 'date_time'
    assert date_time_fact_collector_obj._fact_ids == set()


# Generated at 2022-06-20 19:16:36.724965
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_collector = DateTimeFactCollector()
    assert date_time_collector.name == 'date_time'
    assert date_time_collector._fact_ids == set()

# Generated at 2022-06-20 19:16:48.559632
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    testobj = DateTimeFactCollector()

    # This test is in place because due to an apparent bug in the
    # datetime library prior to CentOS7, datetime.datetime.strftime does
    # not properly deal with a formatter that includes a microsecond
    # component, for example %f. If %f happens to be the only format
    # string, the format string is not processed at all and the 1st
    # character from the input is returned.

    # Get the current year
    curr_year = datetime.datetime.now().year
    facts = testobj.collect()
    assert type(facts) is dict
    assert 'date_time' in facts.keys()
    assert type(facts['date_time']) is dict
    assert 'year' in facts['date_time'].keys()

# Generated at 2022-06-20 19:16:50.609363
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    d = DateTimeFactCollector()
    assert d.name == 'date_time'

# Generated at 2022-06-20 19:17:03.531696
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_facts = DateTimeFactCollector().collect()['date_time']
    assert date_time_facts['year'] == datetime.datetime.now().strftime('%Y')
    assert date_time_facts['month'] == datetime.datetime.now().strftime('%m')
    assert date_time_facts['weekday'] == datetime.datetime.now().strftime('%A')
    assert date_time_facts['weekday_number'] == datetime.datetime.now().strftime('%w')
    assert date_time_facts['weeknumber'] == datetime.datetime.now().strftime('%W')
    assert date_time_facts['day'] == datetime.datetime.now().strftime('%d')

# Generated at 2022-06-20 19:17:07.328129
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtf = DateTimeFactCollector()
    data = dtf.collect()
    assert data['date_time']['time'] == '18:10:23'
    assert data['date_time']['epoch'] == '1580351023'

# Generated at 2022-06-20 19:17:09.337541
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc is not None

# Generated at 2022-06-20 19:17:12.265926
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_facts_collector = DateTimeFactCollector()
    assert date_time_facts_collector is not None

# Generated at 2022-06-20 19:17:21.285029
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_facts = DateTimeFactCollector().collect()
    # check if date_time facts successfully collected
    assert date_time_facts['date_time'] != None
    # check if date_time facts successfully collected
    assert date_time_facts['date_time']['year'] != None
    assert date_time_facts['date_time']['month'] != None
    assert date_time_facts['date_time']['weekday'] != None
    assert date_time_facts['date_time']['weekday_number'] != None
    assert date_time_facts['date_time']['weeknumber'] != None
    assert date_time_facts['date_time']['day'] != None
    assert date_time_facts['date_time']['date'] != None

# Generated at 2022-06-20 19:17:25.223289
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    time_fact = DateTimeFactCollector()
    assert time_fact.name == 'date_time'
    assert time_fact._fact_ids == set()


# Generated at 2022-06-20 19:18:30.838952
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Constructor test
    obj_test = DateTimeFactCollector()
    assert obj_test
    assert obj_test.name == 'date_time'
    assert isinstance(obj_test._fact_ids, set)


# Generated at 2022-06-20 19:18:37.725569
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    The method collect should initialize the dictionary date_time_facts with
    the following keys
    """
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact = date_time_fact_collector.collect()['date_time']
    expected_keys = ("epoch", "epoch_int", "iso8601", "iso8601_basic", 
                     "iso8601_basic_short", "iso8601_micro", "date", "time", 
                     "month", "weekday", "weekday_number", "weeknumber", 
                     "day", "hour", "minute", "second", "tz_dst", "tz", "tz_offset")
    assert sorted(date_time_fact.keys()) == sorted(expected_keys)

# Generated at 2022-06-20 19:18:49.373656
# Unit test for constructor of class DateTimeFactCollector

# Generated at 2022-06-20 19:18:53.535465
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'

# Generated at 2022-06-20 19:18:57.054387
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collect = DateTimeFactCollector()
    collect.collect()

# Generated at 2022-06-20 19:19:00.833520
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'


# Generated at 2022-06-20 19:19:04.538523
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_facts = DateTimeFactCollector()
    assert date_time_facts.name == 'date_time'
    assert len(date_time_facts._fact_ids) == 0

# Generated at 2022-06-20 19:19:17.546503
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-20 19:19:22.773820
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()

    assert(dtfc.name == 'date_time')
    assert(isinstance(dtfc._fact_ids, set))
    assert(dtfc._fact_ids == set())

# Generated at 2022-06-20 19:19:31.730265
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from datetime import datetime

    mock_module = "module"
    mock_collected_facts = "collected_facts"

    dtf = DateTimeFactCollector()
    date_time_facts = dtf.collect(mock_module, mock_collected_facts)['date_time']

    # 'epoch_int' always returns a string representation of integer
    assert isinstance(date_time_facts['epoch_int'], str)
    assert (int(date_time_facts['epoch_int']) == int(date_time_facts['epoch']))
    assert (int(date_time_facts['epoch_int']) == int(time.time()))

    # 'epoch' returns a string
    assert isinstance(date_time_facts['epoch'], str)