

# Generated at 2022-06-20 19:11:48.924442
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_DateTime_fact = DateTimeFactCollector().collect()
    # The epoch value should be present
    assert test_DateTime_fact['date_time']['epoch'] is not None

# Generated at 2022-06-20 19:11:51.705995
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Create instance of class DateTimeFactCollector
    collector = DateTimeFactCollector()

    # Check that the dict returned by method collect has the required key-value pairs
    assert collector.collect().keys() == {'date_time'}

# Generated at 2022-06-20 19:11:59.000250
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert type(x) == DateTimeFactCollector
    assert x.name == 'date_time'
    assert x.fact_type == 'date_time'

# Generated at 2022-06-20 19:12:01.723414
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()
    assert not collector._fact_ids
    assert collector.name == 'date_time'


# Generated at 2022-06-20 19:12:09.016488
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = DateTimeFactCollector()
    result = dt.collect()

    assert isinstance(result, dict)
    for key in result:
        assert isinstance(result[key], dict)
        for k in result[key]:
            assert isinstance(result[key][k], str)

# Generated at 2022-06-20 19:12:13.585153
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    """Unit test for constructor of class DateTimeFactCollector"""

    # Create an instance of DateTimeFactCollector class
    ans_dt_ins = DateTimeFactCollector()
    assert ans_dt_ins.name == 'date_time'
    assert len(ans_dt_ins._fact_ids) == 0

# Generated at 2022-06-20 19:12:25.158375
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import pytest

    from ansible.module_utils.facts.collectors.date_time import DateTimeFactCollector
    # Create a DateTimeFactCollector object
    dtfc = DateTimeFactCollector()
    # Set values for fields of the object dtfc
    dtfc._fact_ids = set()
    dtfc.name = 'date_time'
    # Create a dict which will be passed as an argument to the method collect

# Generated at 2022-06-20 19:12:33.709014
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector.date_time import DateTimeFactCollector
    facts = get_collector_instance(DateTimeFactCollector).collect()
    assert len(facts) == 1
    assert 'date_time' in facts
    assert len(facts['date_time']) > 0
    assert 'date' in facts['date_time']

# Generated at 2022-06-20 19:12:36.051430
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt.name == 'date_time'
    assert dt._fact_ids == set()

# Generated at 2022-06-20 19:12:47.325284
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    from ansible.module_utils.facts import FactsCollection

    facts_collection = FactsCollection()
    fact_collector = DateTimeFactCollector(facts_collection)

# Generated at 2022-06-20 19:13:00.727366
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.utils.display import Display
    from ansible.module_utils.facts.facts import Facts, get_all_facts

    test_display = Display()
    test_collector = DateTimeFactCollector(test_display)
    test_facts = Facts(None, test_display)
    collected_facts = test_collector.collect(module=None, collected_facts=test_facts)
    all_facts_dict = get_all_facts(test_facts)

    # Assert that the test_collector.collect method produces a dict with
    # the key date_time
    assert 'date_time' in collected_facts.keys()

    # Assert that the date_time key has a dict of the collected facts
    assert isinstance(collected_facts['date_time'], dict)

    # Assert that the fact year

# Generated at 2022-06-20 19:13:03.216479
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector

# Generated at 2022-06-20 19:13:10.604124
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    f = DateTimeFactCollector()
    result = f.collect()
    assert type(result['date_time']) == dict
    assert len(result['date_time']) == 19
    assert type(result['date_time']['year']) == str
    assert type(result['date_time']['weeknumber']) == str
    assert type(result['date_time']['weekday_number']) == str
    assert type(result['date_time']['day']) == str
    assert type(result['date_time']['hour']) == str
    assert type(result['date_time']['minute']) == str
    assert type(result['date_time']['second']) == str
    assert type(result['date_time']['epoch']) == str

# Generated at 2022-06-20 19:13:12.408860
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    c = DateTimeFactCollector()
    assert c.name == "date_time"
    assert len(c._fact_ids) == 0

# Generated at 2022-06-20 19:13:18.122395
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_facts_collector = DateTimeFactCollector()
    facts = date_time_facts_collector.collect()
    assert facts != None
    assert 'date_time' in facts
    assert facts['date_time']['hour'] != None
    assert facts['date_time']['minute'] != None
    assert facts['date_time']['second'] != None


# Generated at 2022-06-20 19:13:26.893035
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    now = datetime.datetime.now()
    utcnow = datetime.datetime.utcnow()

    assert fact_collector.collect()['date_time']['year'] == now.strftime('%Y')
    assert fact_collector.collect()['date_time']['month'] == now.strftime('%m')
    assert fact_collector.collect()['date_time']['weekday'] == now.strftime('%A')
    assert fact_collector.collect()['date_time']['weekday_number'] == now.strftime('%w')
    assert fact_collector.collect()['date_time']['weeknumber'] == now.strftime('%W')

# Generated at 2022-06-20 19:13:39.704614
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    import socket
    import sys
    import platform
    import pkgutil
    import ansible.module_utils.facts.system.timezone
    import ansible.module_utils.facts.system.platform

    timezone_path = ansible.module_utils.facts.system.timezone.__file__
    platform_path = ansible.module_utils.facts.system.platform.__file__

    # The below filepaths will be used for the different operating systems.
    # Windows paths are not currently supported.
    if sys.platform.startswith('darwin'):
        timezone_filepath = '/usr/share/zoneinfo/US/Eastern'
        platform_filepath = '/usr/bin/sw_vers'

# Generated at 2022-06-20 19:13:45.444805
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt.name == "date_time"
    assert dt.collect()['date_time']['epoch_int'] >= dt.collect()['date_time']['epoch']

# Generated at 2022-06-20 19:13:47.464571
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector.name == 'date_time'
    assert DateTimeFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:13:59.802248
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_facts = DateTimeFactCollector().collect()
    # Assert that a dictionary is returned
    assert(type(date_time_facts) == dict)
    # Assert that the dictionary is not empty
    assert(date_time_facts)
    # Assert that the dictionary has key 'date_time'
    assert('date_time' in date_time_facts)
    # Assert that the 'date_time' datatype is a dictionary
    assert(type(date_time_facts['date_time']) == dict)
    # Assert that the 'date_time' dictionary is not empty
    assert(date_time_facts['date_time'])

# Generated at 2022-06-20 19:14:13.253469
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_obj = DateTimeFactCollector()
    facts = test_obj.collect()

# Generated at 2022-06-20 19:14:15.706304
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    d = DateTimeFactCollector()
    assert d is not None

# Generated at 2022-06-20 19:14:19.168330
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector.name == 'date_time'
    assert isinstance(DateTimeFactCollector._fact_ids, set)


# Generated at 2022-06-20 19:14:21.615030
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector().name == 'date_time'
    assert DateTimeFactCollector()._fact_ids == set()


# Generated at 2022-06-20 19:14:31.718697
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_collector = DateTimeFactCollector()
    # time.time() returns seconds since the epoch as a floating point number
    now = time.time()
    # datetime.datetime.fromtimestamp(timestamp) returns the local date and time
    date_time_facts = date_time_collector.collect()
    assert date_time_facts['date_time']['epoch'] == str(int(now))
    assert date_time_facts['date_time']['epoch_int'] == str(int(now))
    assert date_time_facts['date_time']['tz_dst'] == time.tzname[1]
    assert date_time_facts['date_time']['tz_offset'] == time.strftime("%z")

# Generated at 2022-06-20 19:14:37.032293
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt_fact_collector = DateTimeFactCollector()
    assert dt_fact_collector.name == 'date_time'
    assert dt_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:14:40.636972
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_facts = DateTimeFactCollector()
    assert date_time_facts.name == 'date_time'
    assert date_time_facts._fact_ids == set()

# Generated at 2022-06-20 19:14:53.957716
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact = DateTimeFactCollector()

    # Get epoch time
    ts = int(time.time())

    # Get the fact
    fact_dt = fact.collect()['date_time']

    # Compare to today's date
    t = datetime.datetime.fromtimestamp(ts)
    assert fact_dt['year'] == t.strftime('%Y')
    assert fact_dt['month'] == t.strftime('%m')
    assert fact_dt['weekday'] == t.strftime('%A')
    assert fact_dt['weekday_number'] == t.strftime('%w')
    assert fact_dt['weeknumber'] == t.strftime('%W')
    assert fact_dt['day'] == t.strftime('%d')

# Generated at 2022-06-20 19:14:57.414702
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtf = DateTimeFactCollector()
    assert 'date_time' == dtf.name
    # Test to make sure construction worked
    assert dtf.name in dtf._fact_ids
    # Test to make sure name is unique
    assert len(dtf._fact_ids) == 1


# Generated at 2022-06-20 19:14:58.448927
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()

# Generated at 2022-06-20 19:15:07.798009
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_DateTimeFactCollector = DateTimeFactCollector()
    result = test_DateTimeFactCollector.collect()
    assert result != None

# Generated at 2022-06-20 19:15:16.175992
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    facts_dict = {}
    date_time_facts = {}

    epoch_ts = time.time()
    now = datetime.datetime.fromtimestamp(epoch_ts)
    utcnow = datetime.datetime.utcfromtimestamp(epoch_ts)

    date_time_facts['year'] = now.strftime('%Y')
    date_time_facts['month'] = now.strftime('%m')
    date_time_facts['weekday'] = now.strftime('%A')
    date_time_facts['weekday_number'] = now.strftime('%w')
    date_time_facts['weeknumber'] = now.strftime('%W')
    date_time_facts['day'] = now.strftime('%d')

# Generated at 2022-06-20 19:15:19.597898
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj.name == "date_time"
    assert obj._fact_ids == set()

# Generated at 2022-06-20 19:15:22.044759
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'

# Generated at 2022-06-20 19:15:31.398366
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtf = DateTimeFactCollector()
    # Test all attributes were set correctly
    assert dtf.name == 'date_time'
    assert len(dtf._fact_ids) == 1
    assert dtf._fact_ids == set()

    # Test collection output
    date_time_facts = dtf.collect()['date_time']
    assert 'date' in date_time_facts
    assert 'time' in date_time_facts
    assert 'iso8601' in date_time_facts
    assert 'iso8601_basic' in date_time_facts
    assert 'iso8601_basic_short' in date_time_facts
    assert 'iso8601_micro' in date_time_facts
    assert 'tz' in date_time_facts
    assert 'tz_dst' in date_time_facts
   

# Generated at 2022-06-20 19:15:45.001065
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    def mock_time():
        return 1511472220.16

    def mock_time_strftime(s):
        return s

    def mock_strftime(s):
        return s

    import sys
    from ansible.module_utils.facts.collector import DateTimeFactCollector, BaseFactCollector

    if sys.version_info < (2, 7):
        # Test that DateTimeFactCollector is not used for python 2.6
        assert not isinstance(BaseFactCollector.classes_to_collect(), list) or \
            DateTimeFactCollector not in BaseFactCollector.classes_to_collect()

# Generated at 2022-06-20 19:15:49.285793
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector
    result = fact_collector.collect()
    assert result['date_time']['day'] == datetime.datetime.now().strftime('%d')

# Generated at 2022-06-20 19:15:52.906981
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()
    assert collector.name == 'date_time'
    assert collector.priority == 49
    assert collector._fact_ids == set()


# Generated at 2022-06-20 19:15:57.328431
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    try:
        DateTimeFactCollector()
    except:
        print('Failed to instantiate DateTimeFactCollector')


# Unit test to get all facts of class DateTimeFactCollector

# Generated at 2022-06-20 19:16:06.300034
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    datetime_fact_collector = DateTimeFactCollector()

    result = datetime_fact_collector.collect()
    assert result['date_time']['year'] == time.strftime("%Y")
    assert result['date_time']['month'] == time.strftime("%m")
    assert result['date_time']['weekday'] == time.strftime("%A")
    assert result['date_time']['weekday_number'] == time.strftime("%w")
    assert result['date_time']['weeknumber'] == time.strftime("%W")
    assert result['date_time']['day'] == time.strftime("%d")
    assert result['date_time']['hour'] == time.strftime("%H")

# Generated at 2022-06-20 19:16:28.769521
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # GIVEN
    dtf = DateTimeFactCollector()

    # WHEN
    collection = dtf.collect()

    # THEN
    assert collection['date_time']['epoch'] == str(int(time.time()))
    assert collection['date_time']['epoch_int'] == str(int(time.time()))
    assert collection['date_time']['iso8601'] == datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
    assert collection['date_time']['iso8601_micro'] == datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.%fZ")

# Generated at 2022-06-20 19:16:31.379969
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt.name == 'date_time'

# Generated at 2022-06-20 19:16:35.633749
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time = DateTimeFactCollector()
    assert date_time.name == 'date_time'
    assert date_time.priority == 80

# Generated at 2022-06-20 19:16:39.169187
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    # test for name
    assert dt.name == 'date_time'

# Generated at 2022-06-20 19:16:42.523933
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj.name == 'date_time'
    assert obj._fact_ids == set()


# Generated at 2022-06-20 19:16:45.751824
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time = DateTimeFactCollector()
    assert date_time.name == 'date_time'
    assert date_time._fact_ids == set()


# Generated at 2022-06-20 19:16:50.683920
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """ Test the output of the collect command"""
    collector = DateTimeFactCollector()
    # collect() should return a dict
    assert isinstance(collector.collect(), dict)

# Generated at 2022-06-20 19:17:02.480083
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # We can't do anything better than this, because Ansible tests are
    # run at the same time as release, which means we can't compare the
    # result to a fixed value or even a previous test run.
    date_time_fact_collector = DateTimeFactCollector()
    facts_dict = date_time_fact_collector.collect()
    date_facts = facts_dict['date_time']
    assert date_facts['day'].isdigit()
    assert date_facts['hour'].isdigit()
    assert date_facts['minute'].isdigit()
    assert date_facts['second'].isdigit()
    assert date_facts['month'].isdigit()
    assert date_facts['year'].isdigit()

# Generated at 2022-06-20 19:17:05.577818
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    module = None
    collected_facts = None

    dtfc = DateTimeFactCollector()
    dtfc.collect(module, collected_facts)

# Generated at 2022-06-20 19:17:08.208202
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt.name == 'date_time'
    assert dt._fact_ids == set([])

# Generated at 2022-06-20 19:17:42.589182
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    c = DateTimeFactCollector()
    assert c.name == 'date_time'

# Generated at 2022-06-20 19:17:44.763476
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert isinstance(DateTimeFactCollector(), DateTimeFactCollector)


# Generated at 2022-06-20 19:17:55.657347
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import os
    os.environ['TZ'] = 'EST+05EDT,M4.1.0,M10.5.0'
    time.tzset()
    epoch = time.time()
    now = datetime.datetime.fromtimestamp(epoch)
    utcnow = datetime.datetime.utcfromtimestamp(epoch)
    time.tzset() # rerun time.tzset() after setting TZ
    dt = DateTimeFactCollector()
    ansible_facts = dt.collect()
    assert ansible_facts['date_time']['year'] == now.strftime('%Y')
    assert ansible_facts['date_time']['month'] == now.strftime('%m')
    assert ansible_facts['date_time']['weekday'] == now

# Generated at 2022-06-20 19:18:00.534755
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_facts = DateTimeFactCollector()
    assert date_time_facts.name == 'date_time'
    assert not date_time_facts._fact_ids
    assert date_time_facts._cachefile_prefix == 'ansible_local.date_time'

# Generated at 2022-06-20 19:18:04.200603
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_facts = DateTimeFactCollector()
    assert date_time_facts.name == 'date_time'

# Generated at 2022-06-20 19:18:13.803443
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Arrange
    test_obj = DateTimeFactCollector()
    # Act
    result = test_obj.collect()
    # Assert
    assert result is not None
    assert len(result) == 1
    assert isinstance(result['date_time'], dict)
    assert len(result['date_time']) == 20
    assert(result['date_time']['year'] == str(datetime.datetime.now().year))
    assert(result['date_time']['month']) == str(datetime.datetime.now().month)
    assert(result['date_time']['weekday']) == str(datetime.datetime.now().strftime('%A'))

# Generated at 2022-06-20 19:18:16.032944
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    assert 'date_time' in DateTimeFactCollector().collect()

# Generated at 2022-06-20 19:18:24.012652
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Unit test for method collect of class DateTimeFactCollector
    """
    date_time_obj = DateTimeFactCollector()
    result = date_time_obj.collect()
    assert 'date_time' in result
    assert result['date_time']['date'] == datetime.datetime.now().strftime("%Y-%m-%d")
    assert result['date_time']['time'] == datetime.datetime.now().strftime("%H:%M:%S")

# Generated at 2022-06-20 19:18:31.141303
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # setup
    collector = DateTimeFactCollector(None)
    date_time_facts = collector.collect()

    assert date_time_facts['date_time']['year'] != None
    assert date_time_facts['date_time']['date'] != None
    assert date_time_facts['date_time']['time'] != None

# Generated at 2022-06-20 19:18:32.579043
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector.name == 'date_time'


# Generated at 2022-06-20 19:19:17.679688
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtf = DateTimeFactCollector()
    testdata = dtf.collect()
    assert 'date_time' in testdata
    assert 'iso8601_basic' in testdata['date_time']
    assert 'iso8601_basic_short' in testdata['date_time']
    assert 'iso8601' in testdata['date_time']
    assert 'iso8601_micro' in testdata['date_time']
    assert 'year' in testdata['date_time']
    assert 'month' in testdata['date_time']
    assert 'weekday' in testdata['date_time']
    assert 'weekday_number' in testdata['date_time']
    assert 'weeknumber' in testdata['date_time']
    assert 'day' in testdata['date_time']

# Generated at 2022-06-20 19:19:30.123042
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = DateTimeFactCollector()
    ans = dt.collect()
    
    assert type(ans) is dict
    assert 'date_time' in ans.keys()
    date_time_facts = ans['date_time']
   
    assert type(date_time_facts) is dict
    
    assert len(date_time_facts['year']) ==4
    assert len(date_time_facts['month']) ==2
    assert len(date_time_facts['weekday_number']) ==1
    assert len(date_time_facts['weeknumber']) ==2
    assert len(date_time_facts['day']) ==2
    assert len(date_time_facts['hour']) ==2
    assert len(date_time_facts['minute']) ==2

# Generated at 2022-06-20 19:19:36.452049
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # All facts read in should return unicode strings, not bytestrings.
    # That is, u'foo'  not  b'foo'.
    # This test makes sure that is the case.
    dt = DateTimeFactCollector()
    facts = dt.collect()['date_time']
    for fact in facts.keys():
        assert isinstance(facts[fact], str)

# Generated at 2022-06-20 19:19:40.898180
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    fact_collector = DateTimeFactCollector()
    assert fact_collector.name == 'date_time'



# Generated at 2022-06-20 19:19:50.520683
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    When the method collect is called, it should return the following.
    """
    # The time.time() function returns float value for seconds since epoch.
    # We need to take only integer value for epoch.
    epoch_int = int(time.time())
    now = datetime.datetime.fromtimestamp(epoch_int)
    utcnow = datetime.datetime.utcfromtimestamp(epoch_int)
    data = {}
    data['date_time'] = {}
    data['date_time']['year'] = now.strftime('%Y')
    data['date_time']['month'] = now.strftime('%m')
    data['date_time']['weekday'] = now.strftime('%A')

# Generated at 2022-06-20 19:19:54.876363
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_collected_facts = DateTimeFactCollector().collect()['date_time']
    assert date_time_collected_facts is not None

# Generated at 2022-06-20 19:19:58.785208
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'
    assert len(date_time_fact_collector._fact_ids) == 0


# Generated at 2022-06-20 19:20:12.050505
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_collector = DateTimeFactCollector()
    date_time_facts = date_time_collector.collect()
    assert date_time_facts['date_time']
    assert date_time_facts['date_time']['date']
    assert date_time_facts['date_time']['day']
    assert date_time_facts['date_time']['epoch']
    assert date_time_facts['date_time']['hour']
    assert date_time_facts['date_time']['iso8601']
    assert date_time_facts['date_time']['iso8601_basic']
    assert date_time_facts['date_time']['iso8601_basic_short']
    assert date_time_facts['date_time']['iso8601_micro']
   

# Generated at 2022-06-20 19:20:22.292811
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    import os
    import time

    class MockModule(object):
        def __init__(self, params):
            self.params = params

    test_module = MockModule(params={'gather_subset': ['date_time']})
    test_collector = DateTimeFactCollector()
    result = test_collector.collect(module=test_module)
    now = time.time() 
    now_check = time.time()

    assert(result['date_time']['year'] == time.strftime("%Y")) 
    assert(result['date_time']['month'] == time.strftime("%m")) 
    assert(result['date_time']['weekday'] == time.strftime("%A")) 

# Generated at 2022-06-20 19:20:26.289340
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    facts_collector = DateTimeFactCollector()
    assert facts_collector.name == 'date_time'
    assert facts_collector._fact_ids == set()


# Generated at 2022-06-20 19:21:35.146268
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    fact_collector = DateTimeFactCollector()
    # Test return values
    assert fact_collector.name == 'date_time'

# Generated at 2022-06-20 19:21:37.762005
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import datetime
    dc = DateTimeFactCollector()
    prev_date_time = dc.collect()
    time.sleep(1)

    new_date_time = dc.collect()
    assert(new_date_time['date_time']['iso8601_micro'] > prev_date_time['date_time']['iso8601_micro'])

# Generated at 2022-06-20 19:21:40.750207
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'
    assert x._fact_ids == set(['date_time'])

# Generated at 2022-06-20 19:21:44.097574
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    datetimefc = DateTimeFactCollector()
    assert datetimefc
    assert datetimefc.name == 'date_time'
    assert not datetimefc._fact_ids