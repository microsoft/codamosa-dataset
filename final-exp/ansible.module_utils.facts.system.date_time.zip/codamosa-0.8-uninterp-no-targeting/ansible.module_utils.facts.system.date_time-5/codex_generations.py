

# Generated at 2022-06-20 19:11:47.820887
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    datetime_fact_collector = DateTimeFactCollector()
    assert datetime_fact_collector.name == 'date_time'
    assert datetime_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:11:50.528440
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'
    assert dtfc._fact_ids == set()


# Generated at 2022-06-20 19:11:50.967595
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    pass

# Generated at 2022-06-20 19:11:58.400232
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    '''
    Unit tests for method DateTimeFactCollector.collect

    The following scenarios are tested:

    Return the current time in several formats.
    '''

    # define input parameters
    module = {}

    # define expected return values

# Generated at 2022-06-20 19:12:03.862785
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc_local = DateTimeFactCollector()
    dtfc_def = DateTimeFactCollector(None, None)
    assert dtfc_local.name == 'date_time'
    assert dtfc_def.name == 'date_time'
    assert dtfc_local._fact_ids == dtfc_def._fact_ids
    assert dtfc_local.collect() == dtfc_def.collect()

# Generated at 2022-06-20 19:12:07.464641
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    fc = DateTimeFactCollector()
    assert isinstance(fc, DateTimeFactCollector)


# Generated at 2022-06-20 19:12:16.990248
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import pprint

    dt = DateTimeFactCollector()
    assert dt.name == 'date_time'

    facts = dt.collect()

    # Verify keys
    pprint.pprint(facts)
    assert 'date_time' in facts
    for k in ('epoch', 'epoch_int', 'iso8601', 'iso8601_basic', 'iso8601_basic_short', 'iso8601_micro', 'time',
              'date', 'weekday_number', 'weeknumber', 'weekday', 'year', 'month', 'day', 'hour', 'minute', 'second',
              'tz', 'tz_offset', 'tz_dst'):
        assert k in facts['date_time']

# Generated at 2022-06-20 19:12:26.000380
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = DateTimeFactCollector()
    epoch = datetime.datetime.fromtimestamp(0)
    dt.collect()
    for key in dt.get_facts():
        assert key in ["date_time"]  # should return only one key
        assert isinstance(dt.get_facts()[key], dict)
        assert 'year' in dt.get_facts()[key]
        assert isinstance(int(dt.get_facts()[key]['year']), int)
        assert isinstance(float(dt.get_facts()[key]['epoch']), float)
        assert isinstance(float(dt.get_facts()[key]['epoch_int']), float)
        assert isinstance(int(dt.get_facts()[key]['epoch_int']), int)

# Generated at 2022-06-20 19:12:31.503158
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector_instance = DateTimeFactCollector()
    assert date_time_fact_collector_instance.name == 'date_time'
    assert len(date_time_fact_collector_instance._fact_ids) == 0


# Generated at 2022-06-20 19:12:37.859439
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Test DateTimeFactCollector.collect
    """
    collector = DateTimeFactCollector()
    result = collector.collect()

    assert 'date_time' in result.keys()
    assert 'year' in result['date_time'].keys()
    assert 'month' in result['date_time'].keys()
    assert 'weekday' in result['date_time'].keys()
    assert 'weekday_number' in result['date_time'].keys()
    assert 'weeknumber' in result['date_time'].keys()
    assert 'day' in result['date_time'].keys()
    assert 'hour' in result['date_time'].keys()
    assert 'minute' in result['date_time'].keys()
    assert 'second' in result['date_time'].keys()

# Generated at 2022-06-20 19:12:48.625043
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    now = datetime.datetime.now()
    epoch_ts = time.time()
    dt_facts = DateTimeFactCollector().collect()
    dt_facts = dt_facts['date_time']
    assert dt_facts['year'] == now.strftime('%Y')
    assert dt_facts['month'] == now.strftime('%m')
    assert dt_facts['weekday'] == now.strftime('%A')
    assert dt_facts['weekday_number'] == now.strftime('%w')
    assert dt_facts['weeknumber'] == now.strftime('%W')
    assert dt_facts['day'] == now.strftime('%d')
    assert dt_facts['hour'] == now.strftime('%H')

# Generated at 2022-06-20 19:12:50.568680
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    #
    #   This method is not testable.
    #
    pass

# Generated at 2022-06-20 19:13:01.307524
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    #arrange
    ansible_module = mock.Mock()

    #act
    the_class = DateTimeFactCollector()
    actual = the_class.collect(ansible_module, None)

    #assert
    assert actual is not None
    assert 'epoch' in actual['date_time']
    assert len(actual['date_time']['epoch']) > 0
    assert 'epoch_int' in actual['date_time']
    assert len(actual['date_time']['epoch_int']) > 0
    assert 'weekday' in actual['date_time']
    assert len(actual['date_time']['weekday']) > 0
    assert 'date' in actual['date_time']
    assert len(actual['date_time']['date']) > 0

# Generated at 2022-06-20 19:13:09.723274
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact = {}
    date_time_fact['date_time'] = {}
    date_time_fact['date_time']['year'] = '2015'
    date_time_fact['date_time']['month'] = '07'
    date_time_fact['date_time']['weekday'] = 'Wednesday'
    date_time_fact['date_time']['weekday_number'] = '3'
    date_time_fact['date_time']['weeknumber'] = '28'
    date_time_fact['date_time']['day'] = '01'
    date_time_fact['date_time']['hour'] = '07'
    date_time_fact['date_time']['minute'] = '30'

# Generated at 2022-06-20 19:13:15.717992
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_col = DateTimeFactCollector()
    assert date_time_fact_col
    assert date_time_fact_col.name == 'date_time'
    assert 'date_time' in date_time_fact_col._fact_ids

# Generated at 2022-06-20 19:13:26.128280
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    timestamp = 1437794326

# Generated at 2022-06-20 19:13:30.431876
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtf = DateTimeFactCollector()
    assert dtf.name == 'date_time'
    assert dtf._fact_ids == set()


# Generated at 2022-06-20 19:13:33.013260
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'
    assert date_time_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:13:35.472147
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector().name == 'date_time'


# Generated at 2022-06-20 19:13:42.186094
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_collector = DateTimeFactCollector()
    assert type(date_time_collector).__name__ == 'DateTimeFactCollector'
    assert date_time_collector.name == 'date_time'
    assert date_time_collector._fact_ids == set()


# Generated at 2022-06-20 19:14:00.948976
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    import datetime
    c = DateTimeFactCollector()
    utcnow = datetime.datetime.utcnow()
    now = datetime.datetime.now()
    result = c.collect()
    assert result['date_time']['tz'] == time.strftime("%Z")
    assert result['date_time']['tz_dst'] == time.tzname[1]
    assert result['date_time']['tz_offset'] == time.strftime("%z")
    assert result['date_time']['weekday'] == now.strftime('%A')
    assert result['date_time']['weekday_number'] == now.strftime('%w')
    assert result['date_time']['weeknumber'] == now.strftime('%W')

# Generated at 2022-06-20 19:14:08.748973
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    now = datetime.datetime.now()
    epoch = time.time()
    assert (now.strftime('%Y') in DateTimeFactCollector().collect()['date_time']['year'])
    assert (now.strftime('%m') in DateTimeFactCollector().collect()['date_time']['month'])
    assert (now.strftime('%A') in DateTimeFactCollector().collect()['date_time']['weekday'])
    assert (now.strftime('%w') in DateTimeFactCollector().collect()['date_time']['weekday_number'])
    assert (now.strftime('%W') in DateTimeFactCollector().collect()['date_time']['weeknumber'])

# Generated at 2022-06-20 19:14:11.698771
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Create a class object
    datetime_fc = DateTimeFactCollector()

    # Create variable to hold return of collect method.
    datetime_facts = {}
    datetime_facts = datetime_fc.collect()

    # Assert that the dictionary is not empty
    assert datetime_facts != {}

# Generated at 2022-06-20 19:14:17.405997
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtf = DateTimeFactCollector()
    facts_dict = dtf.collect()
    assert(facts_dict['date_time'])
    assert('date' in facts_dict['date_time'])
    assert('time' in facts_dict['date_time'])

# Generated at 2022-06-20 19:14:20.043851
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtf = DateTimeFactCollector()
    assert isinstance(dtf, DateTimeFactCollector)

# Generated at 2022-06-20 19:14:21.034804
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()

# Generated at 2022-06-20 19:14:24.984815
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_collector = DateTimeFactCollector()
    ansible_date_time_facts = date_time_collector.collect()
    assert ansible_date_time_facts.get('date_time')

# Generated at 2022-06-20 19:14:28.418515
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    c = DateTimeFactCollector({}, None)
    assert c._fact_ids == set()
    assert c.name == 'date_time'



# Generated at 2022-06-20 19:14:30.518711
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    """
    Unit test for constructor of class DateTimeFactCollector
    """
    r = DateTimeFactCollector()


# Generated at 2022-06-20 19:14:37.503820
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Test case for method collect of class DateTimeFactCollector"""
    fact_data = DateTimeFactCollector()
    facts_dict = fact_data.collect(module=None, collected_facts=None)
    assert facts_dict['date_time']['tz'] == time.strftime("%Z")

# Generated at 2022-06-20 19:14:47.173494
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt.name == 'date_time', dt.name

# Generated at 2022-06-20 19:14:50.815703
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'
    assert len(dtfc._fact_ids) == 0


# Generated at 2022-06-20 19:15:00.087181
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Test DateTimeFactCollector.collect()
    _dict = DateTimeFactCollector().collect()
    assert isinstance(_dict, dict)
    assert _dict['date_time']['epoch'] == _dict['date_time']['epoch_int']
    assert len(_dict['date_time']['iso8601_basic']) > len(_dict['date_time']['iso8601_basic_short'])


# Generated at 2022-06-20 19:15:07.481535
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():

    # Test that the constructor is executed
    dt = DateTimeFactCollector()
    assert dt is not None

    # Test the name property
    assert dt.name == 'date_time'

    # Test the _fact_ids property
    assert dt._fact_ids == set()

# Generated at 2022-06-20 19:15:11.164320
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()
    assert collector.name == 'date_time'
    assert 'date_time' in collector._fact_ids


# Generated at 2022-06-20 19:15:13.150947
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    """Test that DateTimeFactCollector has attribute 'fact_ids' with right value.
    """
    assert DateTimeFactCollector._fact_ids == set()



# Generated at 2022-06-20 19:15:16.679738
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()
    assert collector.name == 'date_time'
    assert collector._fact_ids is None

# Generated at 2022-06-20 19:15:29.213002
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collected_facts = DateTimeFactCollector().collect()
    assert isinstance(collected_facts['date_time'], dict)
    assert 'year' in collected_facts['date_time']
    assert 'month' in collected_facts['date_time']
    assert 'weekday' in collected_facts['date_time']
    assert 'weekday_number' in collected_facts['date_time']
    assert 'weeknumber' in collected_facts['date_time']
    assert 'day' in collected_facts['date_time']
    assert 'hour' in collected_facts['date_time']
    assert 'minute' in collected_facts['date_time']
    assert 'second' in collected_facts['date_time']
    assert 'epoch' in collected_facts['date_time']
    assert 'epoch_int' in collected_

# Generated at 2022-06-20 19:15:39.068615
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    module = None
    collected_facts = dict()
    date_time_fact_collector = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector.collect(module=module, collected_facts=collected_facts)
    assert date_time_facts['date_time']['year'] == date_time_facts['date_time']['time'][:4]
    assert date_time_facts['date_time']['month'][0] == '0' if len(date_time_facts['date_time']['month']) == 1 else True
    assert date_time_facts['date_time']['day'][0] == '0' if len(date_time_facts['date_time']['day']) == 1 else True

# Generated at 2022-06-20 19:15:41.091181
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj.name == 'date_time'

# Generated at 2022-06-20 19:16:00.940228
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    dtfc.collect()

    assert dtfc.collect()['date_time']['year'] != ''

# Generated at 2022-06-20 19:16:03.898669
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # Test with only one method
    test_obj = DateTimeFactCollector()
    results = test_obj.collect()

    assert 'date_time' in results
    assert results['date_time']['epoch_int'] == results['date_time']['epoch']

# Generated at 2022-06-20 19:16:16.662091
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    '''
    Test calling constructor of DateTimeFactCollector class
    '''
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'
    assert date_time_fact_collector._fact_ids == set()

    date_time_fact_collector.name = 'test'
    assert date_time_fact_collector.name == 'test'

    # since _fact_ids is a set, test that can assign to it
    date_time_fact_collector._fact_ids = {'test'}
    assert date_time_fact_collector._fact_ids == {'test'}


# Generated at 2022-06-20 19:16:19.569780
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    module = None
    collected_facts = None
    fc = DateTimeFactCollector()
    result = fc.collect(module, collected_facts)
    assert isinstance(result, dict)


# Generated at 2022-06-20 19:16:20.979050
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()

# Generated at 2022-06-20 19:16:28.430958
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Set up test class for DateTimeFactCollector
    test_instance = DateTimeFactCollector()

    date_time_method_facts = {}
    date_time_method_facts['year'] = datetime.datetime.now().strftime('%Y')
    date_time_method_facts['month'] = datetime.datetime.now().strftime('%m')
    date_time_method_facts['weekday'] = datetime.datetime.now().strftime('%A')
    date_time_method_facts['weekday_number'] = \
        datetime.datetime.now().strftime('%w')
    date_time_method_facts['weeknumber'] = \
        datetime.datetime.now().strftime('%W')
    date_time_method_facts['day'] = datetime.datetime

# Generated at 2022-06-20 19:16:39.070276
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts import collector
    dt_collector = collector.get_collector('date_time')()
    dt_collector.collect()
    assert dt_collector._fact_ids == set(['date_time'])
    dt_facts = dt_collector.get_facts()
    assert 'date_time' in dt_facts
    date_time = dt_facts['date_time']
    assert type(date_time) == dict
    assert 'year' in date_time
    assert 'month' in date_time
    assert 'weekday' in date_time
    assert 'weekday_number' in date_time
    assert 'weeknumber' in date_time
    assert 'day' in date_time
    assert 'hour' in date_time

# Generated at 2022-06-20 19:16:43.073302
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    '''Unit test for constructor of class DateTimeFactCollector'''
    
    t_dt = DateTimeFactCollector()
    assert 'date_time' in t_dt.collect()

# Generated at 2022-06-20 19:16:45.369107
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    ret = DateTimeFactCollector()
    assert(ret.name == 'date_time')



# Generated at 2022-06-20 19:16:49.764394
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector.name == 'date_time'
    assert DateTimeFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:17:27.189376
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'
    for key in dtfc._fact_ids:
        assert key in dtfc.collect()['date_time']

# Generated at 2022-06-20 19:17:28.509597
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector().name == 'date_time'


# Generated at 2022-06-20 19:17:29.979795
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dateTimeFactCollector = DateTimeFactCollector()
    assert dateTimeFactCollector is not None


# Generated at 2022-06-20 19:17:33.571032
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fake_module = None
    fake_collected_facts = {}
    fc = DateTimeFactCollector()
    result = fc.collect(fake_module, fake_collected_facts)
    assert result['date_time']['date'][:4] == '201'
    assert result['date_time']['time'][:2] == '11'

# Generated at 2022-06-20 19:17:37.037061
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == "date_time"
    assert len(date_time_fact_collector._fact_ids) == 0


# Generated at 2022-06-20 19:17:43.678794
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    dtf = DateTimeFactCollector()
    result = dtf.collect()
    if result['date_time']['year'] == '' or result['date_time']['year'][0] == '%':
        print("test failed!")
    if result['date_time']['month'] == '' or result['date_time']['month'][0] == '%':
        print("test failed!")
    if result['date_time']['day'] == '' or result['date_time']['day'][0] == '%':
        print("test failed!")
    if result['date_time']['hour'] == '' or result['date_time']['hour'][0] == '%':
        print("test failed!")

# Generated at 2022-06-20 19:17:49.515614
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'
    assert len(date_time_fact_collector._fact_ids) == 0

# Generated at 2022-06-20 19:17:55.910668
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    datetime_collector = DateTimeFactCollector()
    facts = datetime_collector.collect(module=None, collected_facts=None)
    assert facts['date_time']['month'] == datetime.datetime.now().strftime('%m')


# Generated at 2022-06-20 19:18:01.032603
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Create instance of DateTimeFactCollector
    dtf = DateTimeFactCollector()
    
    # Get the facts dict
    facts_dict = dtf.collect()
    assert type(facts_dict['date_time']) == type({})
    assert len(facts_dict['date_time']) == 17

# Generated at 2022-06-20 19:18:05.028275
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    # This is a very simplified test.
    assert fact_collector.collect()


# Generated at 2022-06-20 19:19:15.574316
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_facts = DateTimeFactCollector()
    assert date_time_facts.name == 'date_time'
    assert len(date_time_facts._fact_ids) == 0


# Generated at 2022-06-20 19:19:29.189578
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Create the object with no params
    instance = DateTimeFactCollector()

    # Call the method
    result = instance.collect()

    # Check the result
    assert(result is not None)

    # Check the collected fact names
    assert('date_time' in result)
    assert('date_time' in instance._fact_ids)
    date_time = result['date_time']
    assert(date_time is not None)

    assert('year' in date_time)
    assert('month' in date_time)
    assert('weekday' in date_time)
    assert('weekday_number' in date_time)
    assert('weeknumber' in date_time)
    assert('day' in date_time)
    assert('hour' in date_time)
    assert('minute' in date_time)
   

# Generated at 2022-06-20 19:19:38.887354
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    c = DateTimeFactCollector()
    result = c.collect()
    assert result['date_time']['year'] == time.strftime("%Y")
    assert result['date_time']['month'] == time.strftime("%m")
    assert result['date_time']['weekday'] == time.strftime("%A")
    assert result['date_time']['weekday_number'] == time.strftime("%w")
    assert result['date_time']['weeknumber'] == time.strftime("%W")
    assert result['date_time']['day'] == time.strftime("%d")
    assert result['date_time']['hour'] == time.strftime("%H")
    assert result['date_time']['minute'] == time.strftime("%M")


# Generated at 2022-06-20 19:19:42.215774
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # create instance of DateTimeFactCollector
    datetime_fact = DateTimeFactCollector()

    # run collect method
    datetime_facts = datetime_fact.collect()

    assert datetime_facts['date_time']['date'] == datetime.datetime.now().strftime('%Y-%m-%d')

# Generated at 2022-06-20 19:19:51.043186
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    class TestModule:
        def __init__(self):
            self.params = {}

    class TestAnsibleModule:
        def __init__(self, module):
            self.params = module.params

    result = DateTimeFactCollector().collect(module=TestModule())

    assert 'date_time' in result
    assert 'year' in result['date_time']
    assert 'month' in result['date_time']
    assert 'weekday' in result['date_time']
    assert 'weekday_number' in result['date_time']
    assert 'weeknumber' in result['date_time']
    assert 'day' in result['date_time']
    assert 'hour' in result['date_time']
    assert 'minute' in result['date_time']
    assert 'second' in result['date_time']

# Generated at 2022-06-20 19:19:54.544949
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj.name == 'date_time'
    assert obj.collect() is not None

# Generated at 2022-06-20 19:19:56.853120
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    a = DateTimeFactCollector()
    assert a.name == 'date_time'

# Generated at 2022-06-20 19:20:04.274410
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    from ansible.module_utils.facts import FactCollector
    import ansible.module_utils.facts.collectors
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.network

    # Create a FactCollector and inject the DateTimeFactCollector
    fact_collector = FactCollector()

    fake_module = {}
    fake_module['_ansible_options'] = {}
    fake_module['_ansible_options']['_ansible_verbosity'] = 3
    fake_module['_ansible_options']['_ansible_version'] = '3.0.0'

    fact_collector.collect(fake_module, {})

    facts = fact_collector.get_facts()

    # Check that the dates and times were collected

# Generated at 2022-06-20 19:20:05.439202
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_f

# Generated at 2022-06-20 19:20:08.324389
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj.name == 'date_time'
    assert obj._fact_ids == set()