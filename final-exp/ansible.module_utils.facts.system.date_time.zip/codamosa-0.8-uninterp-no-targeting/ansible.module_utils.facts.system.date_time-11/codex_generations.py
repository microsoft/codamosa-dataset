

# Generated at 2022-06-20 19:11:51.316083
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    practice_datetime_facts = DateTimeFactCollector()
    # Unit test for check class attributes
    assert practice_datetime_facts.name == 'date_time'
    assert practice_datetime_facts._fact_ids == set()
    assert isinstance(practice_datetime_facts._fact_ids, set)
    # Unit test for method collect()
    assert isinstance(practice_datetime_facts.collect(), dict)

# Generated at 2022-06-20 19:11:57.174742
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    """DateTimeFactCollector - Constructor Unit Test"""

    # Arrange
    date_time_fact_collector = DateTimeFactCollector()

    # Act
    # No action for act

    # Assert
    assert date_time_fact_collector.name == 'date_time'
    # The order of elements in set is not predictable.
    # Therefore check the size of the set and each element in the set separately.
    assert len(date_time_fact_collector._fact_ids) == 0
    assert 'date_time' in date_time_fact_collector._fact_ids


# Generated at 2022-06-20 19:12:01.062805
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfacts = DateTimeFactCollector()
    assert dtfacts.name == 'date_time'
    assert dtfacts._fact_ids == set()


# Generated at 2022-06-20 19:12:03.119073
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collect_obj = DateTimeFactCollector()
    print(collect_obj.collect())

if __name__ == '__main__':
    test_DateTimeFactCollector_collect()

# Generated at 2022-06-20 19:12:15.159181
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts.collector import Collectors
    from ansible.module_utils.facts.errors import UserDomainError

    # Set values for fields to be tested.

# Generated at 2022-06-20 19:12:17.588070
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    test_obj = DateTimeFactCollector()

    assert test_obj.name == 'date_time'

# Generated at 2022-06-20 19:12:21.880971
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    f = DateTimeFactCollector()
    print(f.name)
    print(f._fact_ids)
    assert f.name == 'date_time'
    assert f._fact_ids == set()

# Generated at 2022-06-20 19:12:31.609252
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts.collector import CollectedFacts
    collector = DateTimeFactCollector()
    test_args = {}
    test_facts = CollectedFacts(ansible_facts=dict(), ansible_module=test_args)
    result = collector.collect(collected_facts=test_facts)
    # Check we have results
    assert 'date_time' in result
    # Check all key are present in the expected result
    expected_keys = ['year', 'month', 'weekday', 'weekday_number', 'day', 'hour', 'minute', 'second', 'epoch', 'epoch_int', 'date', 'time', 'tz']
    for expected_key in expected_keys:
        assert expected_key in result['date_time']

# Generated at 2022-06-20 19:12:34.293310
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact = DateTimeFactCollector()
    print(fact.collect())

if __name__ == "__main__":
    test_DateTimeFactCollector_collect()

# Generated at 2022-06-20 19:12:39.111522
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    aDateTimeFactCollector = DateTimeFactCollector()
    assert aDateTimeFactCollector is not False
    assert aDateTimeFactCollector.name == 'date_time'

# Generated at 2022-06-20 19:12:43.082718
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt_fc = DateTimeFactCollector()
    dt_fc.collect()

# Generated at 2022-06-20 19:12:49.381232
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts.collector import Cache
    from ansible.module_utils.facts.collector import get_collector_names

    collector = DateTimeFactCollector(module=None, collected_facts=Cache())
    result = collector.collect()

    # Assert that fact_key is in result
    fact_key = 'date_time'
    assert fact_key in result

    # Assert that datetime facts are correct
    date_time_facts = result['date_time']

# Generated at 2022-06-20 19:13:00.793412
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    fact = date_time_fact_collector.collect()
    assert 'date_time' in fact
    assert 'year' in fact['date_time']
    assert 'month' in fact['date_time']
    assert 'weekday' in fact['date_time']
    assert 'weekday_number' in fact['date_time']
    assert 'weeknumber' in fact['date_time']
    assert 'day' in fact['date_time']
    assert 'hour' in fact['date_time']
    assert 'minute' in fact['date_time']
    assert 'second' in fact['date_time']
    assert 'epoch' in fact['date_time']
    assert 'epoch_int' in fact['date_time']
    assert 'date'

# Generated at 2022-06-20 19:13:02.797879
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj.name == 'date_time'

# Generated at 2022-06-20 19:13:03.729897
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    DateTimeFactCollector().collect()

# Generated at 2022-06-20 19:13:10.201784
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    facts_dict = DateTimeFactCollector().collect()
    assert 'date_time' in facts_dict
    assert 'day' in facts_dict['date_time']
    assert 'hour' in facts_dict['date_time']
    assert 'minute' in facts_dict['date_time']
    assert 'second' in facts_dict['date_time']
    assert 'epoch' in facts_dict['date_time']
    assert 'iso8601' in facts_dict['date_time']
    assert 'tz' in facts_dict['date_time']
    assert 'tz_dst' in facts_dict['date_time']
    assert 'tz_offset' in facts_dict['date_time']


# Generated at 2022-06-20 19:13:10.860406
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    t = DateTimeFactCollector()
    assert t.name == 'date_time'

# Generated at 2022-06-20 19:13:23.063506
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Fixture
    test_fact_collector = DateTimeFactCollector()

    # Test
    facts_dict = test_fact_collector.collect()

    # Assertions
    assert type(facts_dict) is dict
    assert 'date_time' in facts_dict
    assert type(facts_dict['date_time']) is dict
    assert 'epoch' in facts_dict['date_time']
    assert 'epoch_int' in facts_dict['date_time']
    assert 'tz' in facts_dict['date_time']
    assert 'tz_dst' in facts_dict['date_time']
    assert 'tz_offset' in facts_dict['date_time']
    assert 'date' in facts_dict['date_time']
    assert 'time' in facts_dict['date_time']
   

# Generated at 2022-06-20 19:13:27.059140
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Instantiate a DateTimeFactCollector object
    dtfc = DateTimeFactCollector()
    
    # Call collect using a mock module object
    dtfc.collect()

    # Assert some facts exist
    assert dtfc.collect().get('date_time', dict()).get('year') is not None

# Generated at 2022-06-20 19:13:31.296274
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt.name == 'date_time'
    assert dt._fact_ids == set()


# Generated at 2022-06-20 19:13:43.483499
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    tz_name_1 = "UTC"
    tz_name_2 = "UTC+00:00"
    tz_dst_1 = "None"
    tz_dst_2 = ""
    tz_offset_1 = "+00:00"
    tz_offset_2 = "-000"

    # check DateTimeFactCollector._fact_ids
    coll = DateTimeFactCollector()
    assert len(coll._fact_ids) == 0

    # check DateTimeFactCollector.collect()
    assert 'date_time' in coll.collect().keys()
    assert 'date' in coll.collect().values()[0].keys()
    assert 'time' in coll.collect().values()[0].keys()
    assert 'iso8601' in coll.collect().values()[0].keys()

# Generated at 2022-06-20 19:13:49.894047
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    result = {}
    # create a mocked module
    module = MockModule()
    # set a mocked ansible/module_utils/facts/collector.py BaseFactCollector
    # "collect" method to return a gathered fact
    BaseFactCollector.collect = Mock(return_value={})
    # create a DateTimeFactCollector object
    date_time_facts = DateTimeFactCollector(module)
    # process the method "collect"
    date_time_facts.collect(module)
    # check result
    assert result == {}


# Generated at 2022-06-20 19:14:02.250473
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    '''Unit test for method collect of class DateTimeFactCollector'''

    dt = DateTimeFactCollector()

    facts = dt.collect()

    assert type(facts['date_time']) == dict
    assert facts['date_time']['year'] != ''
    assert facts['date_time']['month'] != ''
    assert facts['date_time']['weekday'] != ''
    assert facts['date_time']['weekday_number'] != ''
    assert facts['date_time']['day'] != ''
    assert facts['date_time']['hour'] != ''
    assert facts['date_time']['minute'] != ''
    assert facts['date_time']['second'] != ''
    assert facts['date_time']['epoch_int'] != ''

# Generated at 2022-06-20 19:14:05.542494
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj.name == "date_time"

# Generated at 2022-06-20 19:14:13.786606
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact = date_time_fact_collector.collect()
    assert date_time_fact['date_time']['epoch_int'] is not None
    assert date_time_fact['date_time']['epoch'] is not None
    assert date_time_fact['date_time']['iso8601'] is not None
    assert date_time_fact['date_time']['iso8601_micro'] is not None
    assert date_time_fact['date_time']['iso8601_basic'] is not None
    assert date_time_fact['date_time']['iso8601_basic_short'] is not None
    assert date_time_fact['date_time']['month'] is not None
    assert date

# Generated at 2022-06-20 19:14:16.334012
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x is not None
    # check that the right methods are implemented
    assert x.collect() is not None

# Generated at 2022-06-20 19:14:27.037689
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # Unit test for collect method of class DateTimeFactCollector
    #
    # We are testing:
    #
    #    (1) if the type of the returned value is a dictionary.
    #
    #    (2) if the keys of the returned value are listed in the _fact_ids
    #        attribute of DateTimeFactCollector.
    #
    #    (3) if each value of the returned value is a dictionary.

    a_datetime_fact_collector = DateTimeFactCollector()
    date_time_facts = a_datetime_fact_collector.collect()

    assert type(date_time_facts) is dict

    assert a_datetime_fact_collector._fact_ids >= date_time_facts.keys()

    for fact in date_time_facts.values():
        assert type(fact)

# Generated at 2022-06-20 19:14:30.632000
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'
    assert type(date_time_fact_collector._fact_ids) == set


# Generated at 2022-06-20 19:14:44.445473
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    input_date = datetime.datetime.now()
    # Commented out because strftime doesn't work on all platforms
    # e.g. '%s' is not recognized by Ansible on Windows
    # input_date = datetime.datetime.strptime("2013-08-20T12:51:33.236596Z", "%Y-%m-%dT%H:%M:%S.%fZ")

# Generated at 2022-06-20 19:14:49.691810
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    factCollector = DateTimeFactCollector()
    result = factCollector.collect()

# Generated at 2022-06-20 19:15:05.841181
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Test DateTimeFactCollector.collect()"""
    # Initialize DateTimeFactCollector class instance
    date_time_fc = DateTimeFactCollector()
    # Collect date_time facts
    date_time_facts = date_time_fc.collect()['date_time']
    # Store current time
    now = datetime.datetime.now()
    # Check if the collected facts are the same as the current time
    assert now.year == int(date_time_facts['year'])
    assert now.month == int(date_time_facts['month'])
    assert now.strftime("%A") == date_time_facts['weekday']
    assert now.strftime("%w") == date_time_facts['weekday_number']

# Generated at 2022-06-20 19:15:07.835962
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_col = DateTimeFactCollector()
    assert date_time_col.name == 'date_time'
    assert date_time_col.skips_on_facts is False

# Generated at 2022-06-20 19:15:16.215082
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    '''
    Unit test for method collect of class DateTimeFactCollector
    '''
    facter = DateTimeFactCollector()

# Generated at 2022-06-20 19:15:25.394282
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Constructor test:
    #    Create a DateTimeFactCollector object
    #    Check the attributes of the object
    #    Check that collect() returns a dictionary
    #        Check that the resulting dictionary contains the expected keys
    #        Check that the values have the right types
    my_dt_obj = DateTimeFactCollector()
    assert my_dt_obj.name == 'date_time'
    assert my_dt_obj._fact_ids == set()
    assert type(my_dt_obj._fact_ids) == set
    dt_dict = my_dt_obj.collect()
    assert type(dt_dict) == dict
    assert sorted(list(dt_dict.keys())) == ['date_time']
    for attrname in dt_dict['date_time']:
        assert type(attrname) == str

# Generated at 2022-06-20 19:15:27.619100
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    DateTimeFactCollector = DateTimeFactCollector()
    DateTimeFactCollector.collect()


# Generated at 2022-06-20 19:15:35.388477
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    '''unit test for method collect of class DateTimeFactCollector'''

    class TestFactsModule(object):
        def __init__(self):
            self.ansible_module = None
            self.ansible_facts = {}

        def run(self):
            '''execute a test module'''

        def exit(self, rc, msg):
            '''exit with a return code and a message'''

        def fail_json(self, msg):
            '''fail the test with a message'''


# Generated at 2022-06-20 19:15:42.223179
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()


# Generated at 2022-06-20 19:15:44.773116
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc
    assert dtfc.name == 'date_time'
    assert dtfc._fact_ids == set()



# Generated at 2022-06-20 19:15:49.212674
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # pylint: disable=protected-access
    a_datetime_fact_collector = DateTimeFactCollector()
    assert a_datetime_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:15:59.931255
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    import types

    # Note: cannot use mock module due to missing patch.multiple
    #       method on Centos
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import DateTimeFactCollector

    def patch(name, new=None):
        if name == 'BaseFactCollector.collect':
            return types.MethodType(lambda self: {},
                                    DateTimeFactCollector(),
                                    DateTimeFactCollector)
        elif name == 'time.time':
            return lambda: 1492086486.0
        elif name == 'time.strftime':
            return lambda format: {
                '%Z': 'Mountain Daylight Time',
                '%z': '-0600'
            }[format]

# Generated at 2022-06-20 19:16:26.334529
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt_fc = DateTimeFactCollector()
    dt_fc.collect()
    date_time_facts = dt_fc.collect()['date_time']
    assert isinstance(date_time_facts['year'], str)
    assert isinstance(date_time_facts['month'], str)
    assert isinstance(date_time_facts['weekday'], str)
    assert isinstance(date_time_facts['weekday_number'], str)
    assert isinstance(date_time_facts['weeknumber'], str)
    assert isinstance(date_time_facts['day'], str)
    assert isinstance(date_time_facts['hour'], str)
    assert isinstance(date_time_facts['minute'], str)
    assert isinstance(date_time_facts['second'], str)

# Generated at 2022-06-20 19:16:34.384503
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-20 19:16:36.759336
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_facts = DateTimeFactCollector.collect()
    assert date_time_facts
    assert 'date_time' in date_time_facts
    assert date_time_facts['date_time']

# Generated at 2022-06-20 19:16:37.547075
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    pass

# Generated at 2022-06-20 19:16:40.347998
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    test_obj = DateTimeFactCollector()
    assert test_obj.name == 'date_time'



# Generated at 2022-06-20 19:16:41.575956
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    c = DateTimeFactCollector()
    result = c.collect()
    assert 'date_time' in result

# Generated at 2022-06-20 19:16:45.916842
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    res = fact_collector.collect()
    assert 'date_time' in res
    assert 'month' in res['date_time']
    assert 'iso8601' in res['date_time']

# Generated at 2022-06-20 19:16:48.869510
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'

# Generated at 2022-06-20 19:16:50.975130
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collect = DateTimeFactCollector()
    # Test method collect
    collect.collect()

# Generated at 2022-06-20 19:16:52.955962
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact = DateTimeFactCollector()
    assert date_time_fact.name == 'date_time'


# Generated at 2022-06-20 19:17:26.585811
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    date_time_fact_collector = DateTimeFactCollector()
    collected_facts = date_time_fact_collector.collect()
    assert len(collected_facts) == 1
    assert 'date_time' in collected_facts

# Generated at 2022-06-20 19:17:33.173498
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtf = DateTimeFactCollector()
    results = dtf.collect()
    assert isinstance(results['date_time']['year'], str)
    assert isinstance(results['date_time']['epoch'], str)
    assert isinstance(results['date_time']['epoch_int'], str)
    assert isinstance(results['date_time']['iso8601_micro'], str)
    assert isinstance(results['date_time']['iso8601_basic'], str)
    assert isinstance(results['date_time']['iso8601_basic_short'], str)

# Generated at 2022-06-20 19:17:41.514835
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    result = dtfc.collect()
    assert result is not None
    assert result['date_time'] is not None
    assert result['date_time']['epoch'] == '1456129614'
    assert result['date_time']['epoch_int'] == '1456129614'
    assert result['date_time']['iso8601_micro'] == '2016-02-20T22:20:14.230474Z'
    assert result['date_time']['iso8601'] == '2016-02-20T22:20:14Z'

# Generated at 2022-06-20 19:17:46.706651
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt_fc = DateTimeFactCollector()
    assert dt_fc
    assert dt_fc.name == 'date_time'
    assert dt_fc._fact_ids == set()


# Generated at 2022-06-20 19:17:49.605654
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    c = DateTimeFactCollector()
    assert c.name == 'date_time'

# Generated at 2022-06-20 19:18:03.018206
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Create the DateTimeFactCollector instance
    date_time_fact_collector = DateTimeFactCollector()

    # Define the expected result

# Generated at 2022-06-20 19:18:05.170379
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'

# Generated at 2022-06-20 19:18:14.816033
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    result = DateTimeFactCollector().collect()
    assert 'date_time' in result
    assert 'year' in result['date_time']
    assert 'month' in result['date_time']
    assert 'weekday' in result['date_time']
    assert 'weekday_number' in result['date_time']
    assert 'weeknumber' in result['date_time']
    assert 'day' in result['date_time']
    assert 'hour' in result['date_time']
    assert 'minute' in result['date_time']
    assert 'second' in result['date_time']
    assert 'epoch' in result['date_time']
    assert 'epoch_int' in result['date_time']
    assert 'date' in result['date_time']
    assert 'time' in result['date_time']

# Generated at 2022-06-20 19:18:17.694641
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'


# Generated at 2022-06-20 19:18:27.812021
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import datetime
    from ansible_collections.ansible.community.plugins.module_utils.facts.collectors.date_time import DateTimeFactCollector

# Generated at 2022-06-20 19:19:38.556419
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collectors import collector_module

    collector = DateTimeFactCollector()
    result = collector.collect()
    assert result is not None

    date_time = result.get('date_time')
    assert date_time is not None
    assert isinstance(date_time, dict)
    assert date_time.get('year') is not None
    assert date_time.get('month') is not None
    assert date_time.get('weekday') is not None
    assert date_time.get('weekday_number') is not None
    assert date_time.get('weeknumber') is not None
    assert date_time.get('day') is not None
    assert date_time.get('hour') is not None
    assert date

# Generated at 2022-06-20 19:19:41.801324
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj.name == 'date_time'

# Generated at 2022-06-20 19:19:50.901366
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    facts_dict = DateTimeFactCollector().collect()
    assert type(facts_dict) is dict
    assert 'date_time' in facts_dict
    assert type(facts_dict['date_time']) is dict
    assert 'iso8601_micro' in facts_dict['date_time']
    assert type(facts_dict['date_time']['iso8601_micro']) is not int
    assert 'epoch' in facts_dict['date_time']
    assert type(facts_dict['date_time']['epoch']) is str
    assert 'epoch_int' in facts_dict['date_time']
    assert type(facts_dict['date_time']['epoch_int']) is str
    assert 'tz_offset' in facts_dict['date_time']

# Generated at 2022-06-20 19:19:55.241828
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # test collect method
    date_time_fc = DateTimeFactCollector()
    date_time_fc.collect()
    assert date_time_fc.collect() is not None

# Generated at 2022-06-20 19:19:59.060910
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector.collect()
    assert 'date_time' in date_time_facts
    assert len(date_time_facts['date_time']) > 0

# Generated at 2022-06-20 19:20:02.675340
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'
    assert x._fact_ids == set()

# Generated at 2022-06-20 19:20:04.768360
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector().name == 'date_time'


# Generated at 2022-06-20 19:20:07.722404
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_obj = DateTimeFactCollector()
    assert date_time_obj.name == 'date_time'

# Generated at 2022-06-20 19:20:20.859930
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # Create a DateTimeFactCollector object
    obj = DateTimeFactCollector()

    # Run the collect method
    actual = obj.collect()

    # Check the result
    assert len(actual) > 0
    assert '{0}:'.format(obj.name) in actual
    assert 'year:' in actual
    assert 'month:' in actual
    assert 'weekday:' in actual
    assert 'weeknumber:' in actual
    assert 'day:' in actual
    assert 'hour:' in actual
    assert 'minute:' in actual
    assert 'second:' in actual
    assert 'epoch:' in actual
    assert 'date:' in actual
    assert 'time:' in actual
    assert 'iso8601_micro:' in actual
    assert 'iso8601:' in actual
    assert 'iso8601_basic:' in actual
    assert 'tz:' in actual

# Generated at 2022-06-20 19:20:29.937445
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # DateTimeFactCollector should return a dict
    # and the value of the dict should be a dict
    # and it should have at least one element
    assert isinstance(DateTimeFactCollector().collect(), dict)
    assert 'date_time' in DateTimeFactCollector().collect()
    assert isinstance(DateTimeFactCollector().collect().get('date_time'), dict)
    assert len(DateTimeFactCollector().collect().get('date_time')) >= 1