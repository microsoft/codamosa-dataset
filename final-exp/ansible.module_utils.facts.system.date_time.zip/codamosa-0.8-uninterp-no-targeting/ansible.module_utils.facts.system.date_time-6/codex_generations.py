

# Generated at 2022-06-20 19:11:52.351733
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Test if method collect returns correct date/time facts
    """
    date_time_collector = DateTimeFactCollector()
    date_time_facts = date_time_collector.collect().get('date_time')

    assert isinstance(date_time_facts.get('year'), str)
    assert isinstance(date_time_facts.get('month'), str)
    assert isinstance(date_time_facts.get('weekday'), str)
    assert isinstance(date_time_facts.get('weekday_number'), str)
    assert isinstance(date_time_facts.get('weeknumber'), str)
    assert isinstance(date_time_facts.get('day'), str)
    assert isinstance(date_time_facts.get('hour'), str)

# Generated at 2022-06-20 19:11:54.325576
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time = DateTimeFactCollector()
    assert date_time.name == 'date_time'
    assert date_time._fact_ids == set()


# Generated at 2022-06-20 19:12:01.059525
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_dtfc = DateTimeFactCollector()
    results = test_dtfc.collect()

    # Only basic testing here, since values are subject to change
    assert 'date_time' in results
    assert 'year' in results['date_time']
    assert 'month' in results['date_time']
    assert 'weekday' in results['date_time']
    assert 'weekday_number' in results['date_time']
    assert 'weeknumber' in results['date_time']
    assert 'day' in results['date_time']
    assert 'hour' in results['date_time']
    assert 'minute' in results['date_time']
    assert 'second' in results['date_time']
    assert 'epoch' in results['date_time']
    assert 'epoch_int' in results['date_time']

# Generated at 2022-06-20 19:12:03.360113
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fc = DateTimeFactCollector()
    date_time_fc.collect()
    assert date_time_fc.collect()
    assert 'date_time' in date_time_fc.collect()

# Generated at 2022-06-20 19:12:05.924794
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()

# Generated at 2022-06-20 19:12:15.155044
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
  # Tests if datetime returns data
  import time

  obj = DateTimeFactCollector()
  result = obj.collect()
  assert isinstance(result['date_time'], dict)
  assert result['date_time']['epoch'] != ''
  assert result['date_time']['iso8601_micro'] != ''
  assert result['date_time']['iso8601'] != ''
  assert result['date_time']['iso8601_basic'] != ''
  assert result['date_time']['tz'] != ''
  assert result['date_time']['tz_dst'] != ''
  assert result['date_time']['tz_offset'] != ''

# Generated at 2022-06-20 19:12:17.066013
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    assert DateTimeFactCollector().collect()


# Generated at 2022-06-20 19:12:20.770746
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    print(dtfc.collect())

if __name__ == "__main__":
    test_DateTimeFactCollector()

# Generated at 2022-06-20 19:12:23.693878
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    DateTimeFactCollector.collect() returns dict
    """
    dateTimeFactCollector = DateTimeFactCollector()

    assert isinstance(dateTimeFactCollector.collect(), dict)

# Generated at 2022-06-20 19:12:35.947834
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time = date_time_fact_collector.collect()['date_time']
    assert '2017' == date_time['year']
    assert '03' == date_time['month']
    assert 'Monday' == date_time['weekday']
    assert '1' == date_time['weekday_number']
    assert '09' == date_time['weeknumber']
    assert '13' == date_time['day']
    assert '18' == date_time['hour']
    assert '03' == date_time['minute']
    assert '31' == date_time['second']
    assert '1489404211' == date_time['epoch']
    assert '1489404211' == date_time['epoch_int']


# Generated at 2022-06-20 19:12:41.645713
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt_obj = DateTimeFactCollector()
    assert dt_obj

# Generated at 2022-06-20 19:12:48.998647
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # create dummy AnsibleModule to instantiate DateTimeFactCollector
    module = object()
    # create object to test method
    date_time_fact_collector = DateTimeFactCollector()

    expected_date_time_facts = date_time_fact_collector.collect()
    assert type(expected_date_time_facts) is dict
    assert type(expected_date_time_facts['date_time']) is dict
    assert type(expected_date_time_facts['date_time']['year']) is unicode
    assert type(expected_date_time_facts['date_time']['month']) is unicode
    assert type(expected_date_time_facts['date_time']['weekday']) is unicode

# Generated at 2022-06-20 19:12:54.753886
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector_obj = DateTimeFactCollector()
    assert date_time_fact_collector_obj.name == 'date_time'
    assert date_time_fact_collector_obj._fact_ids == set()

# Generated at 2022-06-20 19:12:58.046549
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    fact_collector = DateTimeFactCollector()
    result = fact_collector.collect()
    assert "date_time" in result
    assert "epoch" in result["date_time"]


# Generated at 2022-06-20 19:12:59.161851
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    c = DateTimeFactCollector()

# Generated at 2022-06-20 19:13:06.055336
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Create an instance of DateTimeFactCollector and run collect
    collector = DateTimeFactCollector()
    collected_facts = collector.collect(module=None, collected_facts={})
    # Validate facts returned
    assert 'date_time' in collected_facts
    assert 'date' in collected_facts['date_time']
    assert 'epoch' in collected_facts['date_time']
    assert 'epoch_int' in collected_facts['date_time']
    assert 'hour' in collected_facts['date_time']
    assert 'iso8601' in collected_facts['date_time']
    assert 'iso8601_basic' in collected_facts['date_time']
    assert 'iso8601_basic_short' in collected_facts['date_time']

# Generated at 2022-06-20 19:13:11.591496
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    result = fact_collector.collect()
    assert ('date_time' in result)
    assert ('year' in result['date_time'])

# Generated at 2022-06-20 19:13:18.332451
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time', 'Test Failed: Constructor has no name'
    assert date_time_fact_collector._fact_ids == set(), 'Test Failed: Constructor has no facts'

# Creates a DateTimeFactCollector object, collects the facts and then tests
# that the facts returned by the collect method.

# Generated at 2022-06-20 19:13:26.951091
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt_fc = DateTimeFactCollector()
    res = dt_fc.collect()
    assert "date_time" in res
    assert isinstance(res['date_time'], dict)
    assert 'year' in res['date_time'] and res['date_time']['year'].isdigit()
    assert 'month' in res['date_time'] and res['date_time']['month'].isdigit()
    assert 'weekday' in res['date_time']
    assert 'weekday_number' in res['date_time'] and res['date_time']['weekday_number'].isdigit()
    assert 'weeknumber' in res['date_time'] and res['date_time']['weeknumber'].isdigit()
    assert 'day' in res['date_time']

# Generated at 2022-06-20 19:13:32.623251
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_facts_collector = DateTimeFactCollector()
    assert date_time_facts_collector.name == 'date_time'
    assert len(date_time_facts_collector._fact_ids) == 0

# Generated at 2022-06-20 19:13:41.582710
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Unit test for method collect of class DateTimeFactCollector
    """
    obj = DateTimeFactCollector()
    obj.collect()

# Generated at 2022-06-20 19:13:51.173976
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_obj = DateTimeFactCollector()
    result = test_obj.collect()
    assert result['date_time'] is not None
    assert result['date_time']['year'] is not None
    assert result['date_time']['month'] is not None
    assert result['date_time']['day'] is not None
    assert result['date_time']['weekday'] is not None
    assert result['date_time']['weekday_number'] is not None
    assert result['date_time']['weeknumber'] is not None
    assert result['date_time']['hour'] is not None
    assert result['date_time']['minute'] is not None
    assert result['date_time']['second'] is not None
    assert result['date_time']['epoch'] is not None

# Generated at 2022-06-20 19:14:02.622646
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    now = datetime.datetime.now()
    utcnow = datetime.datetime.utcnow()
    epoch_int = str(int(now.strftime('%s')))
    epoch = str(int(time.time()))


# Generated at 2022-06-20 19:14:05.816787
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    DateTimeFactCollector = DateTimeFactCollector()
    DateTimeFactCollector.collect()

# Generated at 2022-06-20 19:14:13.851620
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_collector = DateTimeFactCollector()
    assert date_time_collector.name == 'date_time'
    assert date_time_collector._fact_ids == set()

    # Unit test for function collect of class DateTimeFactCollector

# Generated at 2022-06-20 19:14:20.613017
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_facts = {}
    date_time_facts['year'] = 2018
    date_time_facts['month'] = 7
    date_time_facts['weekday_number'] = 0
    date_time_facts['weekday'] = "Sunday"
    date_time_facts['weeknumber'] = 27
    date_time_facts['day'] = 15
    date_time_facts['hour'] = 20
    date_time_facts['minute'] = 35
    date_time_facts['second'] = 52
    date_time_facts['epoch'] = 1531646352
    date_time_facts['epoch_int'] = 1531646352
    date_time_facts['date'] = "2018-07-15"
    date_time_facts['time'] = "20:35:52"
    date_time_

# Generated at 2022-06-20 19:14:31.450757
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
  # given
  from ansible.module_utils.facts.collector import BaseFactCollector
  date_time_fact_collector = DateTimeFactCollector()

# Generated at 2022-06-20 19:14:44.940647
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    datetime_fact_collector = DateTimeFactCollector()
    result = datetime_fact_collector.collect()
    assert isinstance(result.get('date_time'), dict)
    assert result.get('date_time').get('year')
    assert result.get('date_time').get('month')
    assert result.get('date_time').get('weekday')
    assert result.get('date_time').get('weekday_number')
    assert result.get('date_time').get('weeknumber')
    assert result.get('date_time').get('day')
    assert result.get('date_time').get('hour')
    assert result.get('date_time').get('minute')
    assert result.get('date_time').get('second')

# Generated at 2022-06-20 19:14:49.991849
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector_object = DateTimeFactCollector()
    result = fact_collector_object.collect()
    assert result['date_time']['year'] == str(datetime.datetime.now().date().year)
    assert result['date_time']['month'] == str(datetime.datetime.now().date().month)
    assert result['date_time']['weekday'] == datetime.datetime.now().date().strftime("%A")
    assert result['date_time']['weekday_number'] == datetime.datetime.now().date().strftime("%w")
    assert result['date_time']['weeknumber'] == datetime.datetime.now().date().strftime("%W")
    assert result['date_time']['day'] == datetime.datetime.now

# Generated at 2022-06-20 19:14:54.672118
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt._fact_ids == set(['date_time'])
    assert dt.name == 'date_time'

# Generated at 2022-06-20 19:15:13.947845
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Test that the required fields are present in the results
    def check_dt_facts(dt_facts):
        dt_fact_keys = ['year', 'month', 'weekday', 
                        'weekday_number', 'weeknumber', 'day', 
                        'hour', 'minute', 'second', 'date', 
                        'time', 'epoch_int', 'epoch', 'iso8601_micro', 
                        'iso8601', 'iso8601_basic', 'iso8601_basic_short',
                        'tz', 'tz_dst', 'tz_offset']
        for fact in dt_fact_keys:
            assert fact in dt_facts, "Missing %s in date_time facts" % fact

    # Test that we can convert epoch_int and epoch to int

# Generated at 2022-06-20 19:15:18.004070
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'
    assert len(x._fact_ids) == 0

# Unit test of collect()

# Generated at 2022-06-20 19:15:21.047310
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt_facts = DateTimeFactCollector()
    assert dt_facts.name == 'date_time'
    assert dt_facts._fact_ids == set()


# Generated at 2022-06-20 19:15:24.763109
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'
    assert type(dtfc._fact_ids) == set

# Generated at 2022-06-20 19:15:26.890822
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert(DateTimeFactCollector.name == 'date_time')
    assert(len(DateTimeFactCollector._fact_ids) == 0)

# Generated at 2022-06-20 19:15:31.912509
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time', "DateTimeFactCollector name must be 'date_time'"
    assert len(dtfc._fact_ids) == 0, "DateTimeFactCollector must not have any fact_ids"


# Generated at 2022-06-20 19:15:45.515709
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Create instance of class DateTimeFactCollector
    test_DateTimeFactCollector = DateTimeFactCollector()

    # Try to collect facts
    collected_facts = test_DateTimeFactCollector.collect()

    # Check the returned value
    assert collected_facts['date_time']['year'] is not None
    assert collected_facts['date_time']['month'] is not None
    assert collected_facts['date_time']['weekday'] is not None
    assert collected_facts['date_time']['weekday_number'] is not None
    assert collected_facts['date_time']['weeknumber'] is not None
    assert collected_facts['date_time']['day'] is not None
    assert collected_facts['date_time']['hour'] is not None

# Generated at 2022-06-20 19:15:57.081851
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    date_time_fact = fact_collector.collect()['date_time']
    assert date_time_fact['year']
    assert date_time_fact['month']
    assert date_time_fact['day']
    assert date_time_fact['hour']
    assert date_time_fact['minute']
    assert date_time_fact['second']
    assert isinstance(int(date_time_fact['epoch']), int)
    assert isinstance(int(date_time_fact['epoch_int']), int)
    assert date_time_fact['date']
    assert date_time_fact['time']
    assert date_time_fact['iso8601_micro']
    assert date_time_fact['iso8601']

# Generated at 2022-06-20 19:16:04.783432
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Initialize fact collector
    fact_collector = DateTimeFactCollector()

    # Call the collect method
    fact_dict = fact_collector.collect()

    # Check if the result is of type dict
    assert isinstance(fact_dict, dict)

    # Check if the result contains key date_time
    assert 'date_time' in fact_dict
    assert isinstance(fact_dict['date_time'], dict)

    # Check if each of the facts returned is of type string
    for key, value in fact_dict['date_time'].items():
        assert isinstance(value, str)


# Generated at 2022-06-20 19:16:09.490928
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt_test = DateTimeFactCollector()
    assert dt_test.name == 'date_time'
    assert dt_test._fact_ids == set()


# Generated at 2022-06-20 19:16:24.154775
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Test collect method of DateTimeFactCollector
    # If test runs on a new day, checks will fail
    # If test runs on a new second, checks will fail
    # In case of doubt, use the log to re-check the values
    dt_fact_collector = DateTimeFactCollector()
    dt_facts=dt_fact_collector.collect()
    dt_facts_to_check=dt_facts['date_time']
    print("date_time facts to check :%s" %dt_facts_to_check)
    assert dt_facts_to_check['year']==time.strftime("%Y")
    assert dt_facts_to_check['month']==time.strftime("%m")

# Generated at 2022-06-20 19:16:37.944511
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    """Test DateTimeFactCollector"""
    dt = DateTimeFactCollector()
    assert dt.name == 'date_time'
    assert dt._fact_ids == set()
    # Test the _get_date_time_facts method
    date_time_facts = dt.collect()
    assert date_time_facts['date_time']['day'] != ''
    assert date_time_facts['date_time']['hour'] != ''
    assert date_time_facts['date_time']['minute'] != ''
    assert date_time_facts['date_time']['month'] != ''
    assert date_time_facts['date_time']['second'] != ''
    assert date_time_facts['date_time']['weekday'] != ''

# Generated at 2022-06-20 19:16:43.151539
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Run the DateTimeFactCollector constructor
    dt_facts = DateTimeFactCollector()

    # Assert that the result is an instance of DateTimeFactCollector
    assert isinstance(dt_facts, DateTimeFactCollector)


# Generated at 2022-06-20 19:16:50.603998
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dstc = DateTimeFactCollector()
    res = dstc.collect()
    assert 'epoch' in res['date_time']
    assert 'epoch_int' in res['date_time']
    assert 'date' in res['date_time']
    assert 'year' in res['date_time']
    assert 'month' in res['date_time']
    assert 'day' in res['date_time']
    assert 'hour' in res['date_time']
    assert 'minute' in res['date_time']
    assert 'second' in res['date_time']
    assert 'time' in res['date_time']
    assert 'iso8601' in res['date_time']
    assert 'iso8601_micro' in res['date_time']

# Generated at 2022-06-20 19:16:51.815412
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    d = DateTimeFactCollector()
    d.collect()

# Generated at 2022-06-20 19:17:01.436220
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt_collector = DateTimeFactCollector()
    assert dt_collector.name == 'date_time'
    assert dt_collector._fact_ids == set()

    # test the collect method
    facts_dict = dt_collector.collect()
    assert facts_dict['date_time']['hour'] == time.strftime('%H')
    assert facts_dict['date_time']['day'] == time.strftime('%d')
    assert facts_dict['date_time']['weekday_number'] == time.strftime('%w')

# Generated at 2022-06-20 19:17:12.459763
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_collector = DateTimeFactCollector()
    ansible_facts = date_time_collector.collect()

    assert(ansible_facts["date_time"]["weekday"])
    assert(ansible_facts["date_time"]["weeknumber"])
    assert(ansible_facts["date_time"]["day"])
    assert(ansible_facts["date_time"]["hour"])
    assert(ansible_facts["date_time"]["minute"])
    assert(ansible_facts["date_time"]["second"])
    assert(ansible_facts["date_time"]["epoch"])
    assert(ansible_facts["date_time"]["epoch_int"])
    assert(ansible_facts["date_time"]["date"])


# Generated at 2022-06-20 19:17:15.722788
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()
    assert collector.name == 'date_time'
    assert collector._fact_ids == set()


# Generated at 2022-06-20 19:17:17.444422
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    dtfc.collect()


# Generated at 2022-06-20 19:17:19.439924
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    pass

# Generated at 2022-06-20 19:17:42.318192
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Test the method collect"""
    # Fixture
    # Create a class instance
    date_time_fact_collector = DateTimeFactCollector()

    # Save the current utc and local time
    epoch_ts = time.time()
    now = datetime.datetime.fromtimestamp(epoch_ts)
    utcnow = datetime.datetime.utcfromtimestamp(epoch_ts)

    # Expected dates
    expected_year = now.strftime('%Y')
    expected_month = now.strftime('%m')
    expected_day = now.strftime('%d')
    expected_weekday = now.strftime('%A')
    expected_weekday_number = now.strftime('%w')
    expected_weeknumber = now.strftime('%W')
    expected_hour

# Generated at 2022-06-20 19:17:54.645389
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    d = DateTimeFactCollector()
    now = datetime.datetime.now()
    d.collect()

    assert d.data['date_time']['year'] == now.strftime('%Y')
    assert d.data['date_time']['month'] == now.strftime('%m')
    assert d.data['date_time']['weekday'] == now.strftime('%A')
    assert d.data['date_time']['weekday_number'] == now.strftime('%w')
    assert d.data['date_time']['weeknumber'] == now.strftime('%W')
    assert d.data['date_time']['day'] == now.strftime('%d')

# Generated at 2022-06-20 19:17:57.258154
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    result = DateTimeFactCollector().collect()
    assert result.get('date_time') is not None

# Generated at 2022-06-20 19:18:07.544403
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-20 19:18:10.105024
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    sut = DateTimeFactCollector()
    assert isinstance(sut.collect(), dict)

# Generated at 2022-06-20 19:18:17.241824
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_facts = DateTimeFactCollector()
    ret = date_time_facts.collect()

    assert isinstance(ret, dict)
    for key in ret.keys():
        assert isinstance(ret[key], dict)

    for key in ['year', 'month', 'weekday', 'weekday_number', 'weeknumber', 'day',
                'hour', 'minute', 'second', 'epoch', 'epoch_int']:
        assert isinstance(ret['date_time'][key], str)

    assert isinstance(ret['date_time']['date'], str)
    assert isinstance(ret['date_time']['time'], str)
    assert isinstance(ret['date_time']['tz'], str)

# Generated at 2022-06-20 19:18:20.066262
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    o = DateTimeFactCollector()
    assert o.name == 'date_time'


# Generated at 2022-06-20 19:18:22.554970
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    facts_dict = DateTimeFactCollector().collect()
    assert isinstance(facts_dict['date_time']['epoch'], str)

# Generated at 2022-06-20 19:18:29.119599
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collector = DateTimeFactCollector()
    response = collector.collect()
    assert 'date_time' in response
    assert 'month' in response['date_time']
    assert response['date_time']['month'].isdigit()
    assert len(response['date_time']['month']) == 2

# Generated at 2022-06-20 19:18:32.023502
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt.name == 'date_time'
    assert len(dt._fact_ids) == 0

# Generated at 2022-06-20 19:19:04.781885
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector.name == 'date_time'
    assert DateTimeFactCollector._fact_ids == set()

# Generated at 2022-06-20 19:19:07.772842
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    d = DateTimeFactCollector()
    assert d.name == 'date_time'

# Generated at 2022-06-20 19:19:09.154765
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()

# Generated at 2022-06-20 19:19:16.009269
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # test default
    dtfc = DateTimeFactCollector()
    assert 'date_time' == dtfc.name
    assert [] == dtfc._fact_ids
    # test with facts
    now = datetime.datetime.now()
    dtfc = DateTimeFactCollector(
        collected_facts={
            'date_time': {
                'weekday': now.strftime('%A'),
            }
        }
    )
    assert 'date_time' == dtfc.name
    assert ['date_time'] == dtfc._fact_ids

# Generated at 2022-06-20 19:19:20.655152
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtf = DateTimeFactCollector()
    assert dtf.name == 'date_time'
    assert dtf._fact_ids == set()


# Generated at 2022-06-20 19:19:31.106309
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Checks if DateTimeFactCollector.collect() method works as expected
    """

# Generated at 2022-06-20 19:19:33.497976
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """ Test collect method of DateTimeFactCollector """
    # Collect facts
    DateTimeFactCollector().collect()

# Generated at 2022-06-20 19:19:35.868185
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'
    assert x._fact_ids == set()


# Generated at 2022-06-20 19:19:43.052625
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    import time
    import datetime

    # Setup a fake current time of 24th December, 2015, 10:10:10 AM
    # To be used as return value of datetime.datetime.now()
    class FakeDateTime(datetime.datetime):
        @classmethod
        def now(cls):
            return cls(2015, 12, 24, 10, 10, 10)

    datetime.datetime = FakeDateTime
    time.strftime = lambda s: str(s)

    # Initialize DateTimeFactCollector class
    dtf = DateTimeFactCollector()

    # Run collect and get the resulting facts dict
    facts = dtf.collect()
    # Unset the module name
    dtf.name = None

    # The result should look like this

# Generated at 2022-06-20 19:19:45.826813
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_collector = DateTimeFactCollector()
    assert date_time_collector.name == 'date_time'
    assert isinstance(date_time_collector._fact_ids, set)


# Generated at 2022-06-20 19:20:54.962153
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_facts = DateTimeFactCollector().collect()
    assert len(date_time_facts) == 1

# Generated at 2022-06-20 19:20:59.343088
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    dtfc_facts = dtfc.collect()
    assert 'date_time' in dtfc_facts


# Generated at 2022-06-20 19:21:02.454322
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Unit test for method collect of class DateTimeFactCollector"""
    """
    This test does not test for return values of the DateTimeFactCollector
    because the DateTimeFactCollector's collect method calls datetime and
    time (which are platform dependent).

    This test, instead, test that the code runs without raising exceptions
    """
    DateTimeFactCollector().collect()

# Generated at 2022-06-20 19:21:07.299478
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    fact_collector = DateTimeFactCollector()
    assert fact_collector.name == 'date_time'
    assert 'date_time' in fact_collector._fact_ids

# Generated at 2022-06-20 19:21:12.324547
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector_class = DateTimeFactCollector()
    assert fact_collector_class is not None
    assert fact_collector_class.name == 'date_time'
    assert fact_collector_class._fact_ids is not None

# Generated at 2022-06-20 19:21:18.218615
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    o = DateTimeFactCollector()
    result = o.collect(module=None, collected_facts=None)
    assert 'date_time' in result
    assert 'day' in result['date_time']
    assert 'hour' in result['date_time']

# Generated at 2022-06-20 19:21:27.403848
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_object = DateTimeFactCollector()


# Generated at 2022-06-20 19:21:29.550208
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    fc = DateTimeFactCollector()
    assert fc.name == 'date_time'
    assert len(fc._fact_ids) == 0
    assert fc.collect()['date_time']['time'] == time.strftime('%H:%M:%S')

# Generated at 2022-06-20 19:21:41.751705
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    '''Unit test for method collect of class DateTimeFactCollector.'''

    # Create an empty instance of DateTimeFactCollector
    datetimefactcollector = DateTimeFactCollector()

    # For the test, just return the passed-in collected_facts,
    # because this method adds to the dictionary
    collected_facts = {}
    result_facts_dict = datetimefactcollector.collect(collected_facts=collected_facts)

    # Assert that the result was added to collected_facts
    assert 'date_time' in result_facts_dict
    assert isinstance(result_facts_dict['date_time'], dict)

    # Assert that the subkeys exist in the result
    assert 'year' in result_facts_dict['date_time']
    assert 'month' in result_facts_dict['date_time']
