

# Generated at 2022-06-20 19:11:48.972685
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector

# Generated at 2022-06-20 19:11:56.738538
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    dtfc_facts = dtfc.collect()
    date_time_facts = dtfc_facts.get('date_time')
    assert date_time_facts is not None    # should not be None
    assert isinstance(date_time_facts, dict)    # should be a dict

    # check a few known facts
    assert date_time_facts.get('iso8601') is not None and len(date_time_facts.get('iso8601')) > 0    # should be non-empty string
    assert date_time_facts.get('time') is not None and len(date_time_facts.get('time')) > 0    # should be non-empty string

# Generated at 2022-06-20 19:12:05.756358
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_facts = DateTimeFactCollector().collect()
    assert 'date_time' in date_time_facts
    assert isinstance(date_time_facts['date_time'],dict)
    assert 'year' in date_time_facts['date_time']
    assert 'month' in date_time_facts['date_time']
    assert 'weekday' in date_time_facts['date_time']
    assert 'weekday_number' in date_time_facts['date_time']
    assert 'weeknumber' in date_time_facts['date_time']
    assert 'day' in date_time_facts['date_time']
    assert 'hour' in date_time_facts['date_time']
    assert 'minute' in date_time_facts['date_time']
    assert 'second' in date_time

# Generated at 2022-06-20 19:12:09.782094
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    module = None
    collected_facts = None
    fact_collector = DateTimeFactCollector()
    fact_collector._collect(module, collected_facts)

# Generated at 2022-06-20 19:12:18.654211
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    fact_collector = DateTimeFactCollector()
    assert fact_collector.name == 'date_time'
    assert len(fact_collector._fact_ids) == 0

    fact_dict = fact_collector.collect()
    assert 'date_time' in fact_dict
    assert isinstance(fact_dict['date_time'], dict)

    for key in ('year', 'month', 'weekday', 'weekday_number', 'weeknumber',
                'day', 'hour', 'minute', 'second', 'date', 'time',
                'epoch', 'epoch_int', 'tz_dst', 'tz_offset'):
        assert key in fact_dict['date_time']
        assert isinstance(fact_dict['date_time'][key], str)

# Generated at 2022-06-20 19:12:20.509711
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector.name == 'date_time'
    assert DateTimeFactCollector._fact_ids == set()

# Generated at 2022-06-20 19:12:23.338547
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'
    assert dtfc._fact_ids == set()


# Generated at 2022-06-20 19:12:27.938005
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj.name == 'date_time'
    assert obj._fact_ids == set()


# Generated at 2022-06-20 19:12:38.227102
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = datetime.datetime.utcnow()
    date_time_facts = {}
    date_time_facts['year'] = dt.strftime('%Y')
    date_time_facts['month'] = dt.strftime('%m')
    date_time_facts['weekday'] = dt.strftime('%A')
    date_time_facts['weekday_number'] = dt.strftime('%w')
    date_time_facts['weeknumber'] = dt.strftime('%W')
    date_time_facts['day'] = dt.strftime('%d')
    date_time_facts['hour'] = dt.strftime('%H')
    date_time_facts['minute'] = dt.strftime('%M')

# Generated at 2022-06-20 19:12:42.079249
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    coll = DateTimeFactCollector()
    ret = coll.collect()
    assert('date_time' in ret, "The return dictionary should contain a date_time key")


# Generated at 2022-06-20 19:12:51.923706
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    """ This function performs unit test for constructor of class DateTimeFactCollector """
    # Checking if the facts returned from DateTimeFactCollector is not Empty.
    DateTimeFactCollectorObj = DateTimeFactCollector()
    facts = DateTimeFactCollectorObj.collect()
    assert facts != {}

# Generated at 2022-06-20 19:12:54.841658
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time = DateTimeFactCollector()
    assert date_time.collect()['date_time']['year'] == datetime.datetime.now().strftime('%Y')

# Generated at 2022-06-20 19:12:57.764843
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    datetime_fc = DateTimeFactCollector()
    assert datetime_fc.name == 'date_time'
    assert datetime_fc._fact_ids == set()


# Generated at 2022-06-20 19:13:07.313497
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # Unit test data structures. replace existing structures with actual data.
    class ModuleUtil:
        def __init__(self):
            pass
        def get_platform(self):
            return ''
    class CollectedFacts:
        def __init__(self):
            pass
    collected_facts = CollectedFacts()
    module = ModuleUtil()

    # Actual call to DateTimeFactCollector.collect method.
    datetimeFactCollector = DateTimeFactCollector()
    result = datetimeFactCollector.collect(module=module, collected_facts=collected_facts)

    # Verify that the required facts are returned.
    assert 'date_time' in result, "result['ansible_date_time'] not found"
    date_time_facts = result['date_time']
    assert 'epoch_int' in date

# Generated at 2022-06-20 19:13:10.871312
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'
    assert dtfc._fact_ids == set()

# Generated at 2022-06-20 19:13:21.785886
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Unit test for method collect of class DateTimeFactCollector
    """
    # create object of class DateTimeFactCollector
    dtfc = DateTimeFactCollector()
    # define test variables
    test_month = datetime.datetime.now().strftime('%m')
    test_year = datetime.datetime.now().strftime('%Y')
    test_weekday = datetime.datetime.now().strftime('%A')
    test_weekday_number = datetime.datetime.now().strftime('%w')
    test_weeknumber = datetime.datetime.now().strftime('%W')
    test_day = datetime.datetime.now().strftime('%d')
    test_hour = datetime.datetime.now().strftime('%H')
    test_minute

# Generated at 2022-06-20 19:13:27.283314
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # Generate data using the method we want to test
    collector = DateTimeFactCollector()
    ansible_facts = collector.collect(None)

    # Make sure the method generated a dictionary
    assert isinstance(ansible_facts, dict)

    # Make sure it added the key date_time to the result
    assert 'date_time' in ansible_facts
    assert ansible_facts['date_time'] is not None

    # Make sure it added some values for each fact
    for fact in ansible_facts['date_time']:
        assert ansible_facts['date_time'][fact] is not None
        assert ansible_facts['date_time'][fact] != ''

# Generated at 2022-06-20 19:13:34.806137
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Method to test collect method of class DateTimeFactCollector
    """
    collector = DateTimeFactCollector()
    # Ensure the collect method returns a dict
    assert isinstance(collector.collect(), dict)
    # Ensure the collect method stores results in a dict with 'date_time' key
    assert 'date_time' in collector.collect()

# Generated at 2022-06-20 19:13:37.948927
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector._fact_ids == set()
    assert date_time_fact_collector._name == "date_time"


# Generated at 2022-06-20 19:13:42.652595
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Test DateTimeFactCollector.collect()"""
    dtfc = DateTimeFactCollector()
    assert dtfc.collect() is not None


# Generated at 2022-06-20 19:13:54.594903
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector().name == 'date_time'
    assert DateTimeFactCollector()._fact_ids == set()


# Generated at 2022-06-20 19:13:58.316042
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'
    assert dtfc._fact_ids == set()


# Generated at 2022-06-20 19:14:11.457093
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    '''Unit test for method collect of class DateTimeFactCollector'''

    now = datetime.datetime.now()
    utcnow = datetime.datetime.utcnow()

    c = DateTimeFactCollector()
    d = c.collect()

    assert d['date_time']['year'] == now.strftime('%Y')
    assert d['date_time']['month'] == now.strftime('%m')
    assert d['date_time']['weekday'] == now.strftime('%A')
    assert d['date_time']['weekday_number'] == now.strftime('%w')
    assert d['date_time']['weeknumber'] == now.strftime('%W')

# Generated at 2022-06-20 19:14:12.315174
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    datetime_facts = DateTimeFactCollector()


# Generated at 2022-06-20 19:14:19.311230
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Check constructor in case no param is set
    DateTimeFactCollector()

    # Check constructor in case invalid param is set
    try:
        DateTimeFactCollector(None)
    except Exception as e:
        assert e.args[0] == "The param 'None' is not a valid param for the DateTimeFactCollector"

# Generated at 2022-06-20 19:14:21.365774
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt1 = DateTimeFactCollector()
    assert "date_time" in dt1._fact_ids

# Generated at 2022-06-20 19:14:31.806688
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    import copy
    from ansible.module_utils.facts.collector import (get_collector_instance,
                                                      CollectorException)

    # Check to see that we return an instance of BaseFactCollector
    try:
        instance = get_collector_instance('date_time')
    except CollectorException:
        instance = None
    assert isinstance(instance, DateTimeFactCollector)

    # Check that the name attribute is properly set
    assert instance.name == 'date_time'

    # Check that the _fact_ids attribute is properly set
    assert instance._fact_ids == set()

    # Make sure that a copy of the class object is not returned
    instance_copy = copy.deepcopy(instance)
    assert instance != instance_copy
    assert isinstance(instance_copy, DateTimeFactCollector)

# Generated at 2022-06-20 19:14:41.730554
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # create a DateTimeFactCollector
    dt_object = DateTimeFactCollector()
    # collect facts from DateTimeFactCollector
    ansible_facts = dt_object.collect()
    # check the type of collected facts
    assert type(ansible_facts) == dict
    # check if the length of collected facts is correct
    assert len(ansible_facts.keys()) == 1
    # check if the length of collected facts is correct
    assert len(ansible_facts['date_time'].keys()) == 18

# Generated at 2022-06-20 19:14:54.626102
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    #
    # DateTimeFactCollector.collect()
    #
    # This method should return a dictionary that contains the
    # date/time related facts.
    #
    import datetime, time

    epoch_ts = time.time()
    now = datetime.datetime.fromtimestamp(epoch_ts)
    utcnow = datetime.datetime.utcfromtimestamp(epoch_ts)

    date_time_facts = {}
    date_time_facts['year'] = now.strftime('%Y')
    date_time_facts['month'] = now.strftime('%m')
    date_time_facts['weekday'] = now.strftime('%A')
    date_time_facts['weekday_number'] = now.strftime('%w')
    date_time_facts['weeknumber']

# Generated at 2022-06-20 19:14:56.365533
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    result = DateTimeFactCollector()
    assert result is not None

if __name__ == '__main__':
    test_DateTimeFactCollector()

# Generated at 2022-06-20 19:15:19.519296
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    from ansible.module_utils.facts import collector

    datetime_factcollector = DateTimeFactCollector()
    assert datetime_factcollector.collector == collector
    assert datetime_factcollector.name == 'date_time'
    assert datetime_factcollector.fact_names == ['date_time']


# Generated at 2022-06-20 19:15:30.543972
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_facts = DateTimeFactCollector().collect()['date_time']

    # This test uses hard coded values for the UTC timezone and not the local timezone
    # In the future, UTC timezone offset could be retrieved from date_time_facts['tz_offset']
    utcnow = datetime.datetime.utcfromtimestamp(time.time())

    assert date_time_facts['year'] == utcnow.strftime('%Y')
    assert date_time_facts['month'] == utcnow.strftime('%m')
    assert date_time_facts['weekday'] == utcnow.strftime('%A')
    assert date_time_facts['weekday_number'] == utcnow.strftime('%w')

# Generated at 2022-06-20 19:15:34.295459
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    result = DateTimeFactCollector().collect()
    assert 'date_time' in result
    assert 'weekday' in result['date_time']
    assert 'iso8601' in result['date_time']
    assert len(result['date_time']) == 16

# Generated at 2022-06-20 19:15:46.322798
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    testobj = DateTimeFactCollector()
    result = testobj.collect()

    assert result is not None
    assert result.get('date_time') is not None
    assert result['date_time'].get('year') is not None
    assert result['date_time'].get('month') is not None
    assert result['date_time'].get('weekday') is not None
    assert result['date_time'].get('weekday_number') is not None
    assert result['date_time'].get('weeknumber') is not None
    assert result['date_time'].get('day') is not None
    assert result['date_time'].get('hour') is not None
    assert result['date_time'].get('minute') is not None
    assert result['date_time'].get('second') is not None


# Generated at 2022-06-20 19:15:57.191546
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import inspect
    from ansible.module_utils.facts import collector

    # Create a new instance of a fact collector
    fact_collector = None
    for name, obj in inspect.getmembers(collector):
        if inspect.isclass(obj) and name == "DateTimeFactCollector":
            fact_collector = obj()
            break

    assert fact_collector is not None, \
        "Expected to find 'DateTimeFactCollector' class. Found none."

    # Call 'collect' method
    collected_facts = fact_collector.collect()

    # Check that the collected facts are not null
    assert collected_facts is not None, \
        "Expected non-null 'collected_facts'."

    # Get the date_time facts and check that they are not null
    date_time_facts = collected_facts.get

# Generated at 2022-06-20 19:15:59.078728
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector.name == 'date_time'


# Generated at 2022-06-20 19:15:59.865718
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    pass

# Generated at 2022-06-20 19:16:08.011748
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # set up test
    test_DateTimeFactCollector = DateTimeFactCollector()

    # perform the test
    facts_dict = test_DateTimeFactCollector.collect()

    # verify the results
    assert 'date_time' in facts_dict
    date_time_facts = facts_dict['date_time']
    assert 'year' in date_time_facts
    assert 'month' in date_time_facts
    assert 'weekday' in date_time_facts
    assert 'weekday_number' in date_time_facts
    assert 'weeknumber' in date_time_facts
    assert 'day' in date_time_facts
    assert 'hour' in date_time_facts
    assert 'minute' in date_time_facts
    assert 'second' in date_time_facts
    assert 'epoch' in date

# Generated at 2022-06-20 19:16:09.340888
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    pass

# Generated at 2022-06-20 19:16:20.293219
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt_fc = DateTimeFactCollector()
    collected_facts = dt_fc.collect(collected_facts={})

# Generated at 2022-06-20 19:16:42.208306
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fc = DateTimeFactCollector()
    date_time_dict = date_time_fc.collect()
    date_time_facts = date_time_dict['date_time']
    for dtf in date_time_facts:
        assert date_time_facts[dtf] == date_time_facts[dtf]

# Generated at 2022-06-20 19:16:45.918827
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Test the constructor of DateTimeFactCollector
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'
    assert len(dtfc._fact_ids) == 0

# Generated at 2022-06-20 19:16:51.270174
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
  # create instance for the DateTimeFactCollector
  test_dt_fact_collector = DateTimeFactCollector()
  # create instance for the DateTimeFactCollector
  test_dt_fact_collector.collect()

# Generated at 2022-06-20 19:16:55.011258
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj.name == "date_time"
    assert obj._fact_ids == set()

# Generated at 2022-06-20 19:17:06.525645
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Unit tests the method collect of class DateTimeFactCollector
    """

    fact_collector = DateTimeFactCollector()
    date_time_facts = fact_collector.collect()['date_time']

    # date_time_facts is dictionary
    assert isinstance(date_time_facts, dict)

    # date_time_facts keys:
    # year, month, weekday, weekday_number, day, hour, minute, secon,
    # epoch, epoch_int, date, time, iso8601_micro, iso8601, iso8601_basic
    # iso8601_basic_short, tz, tz_dst, tz_offset

# Generated at 2022-06-20 19:17:19.224176
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # Create a DateTimeFactCollector object
    fact_collector_obj = DateTimeFactCollector()

    # Call method collect
    datetime_facts = fact_collector_obj.collect(module=None, collected_facts=None)

    # Assert that collect method should return a dictionary
    assert isinstance(datetime_facts, dict)

    # Assert that date_time key should be present in the returned dictionary
    assert 'date_time' in datetime_facts

    # Assert that date_time key should contain a dictionary value
    assert isinstance(datetime_facts['date_time'], dict)

    # Assert that all the facts present in date_time dictionary
    assert 'year' in datetime_facts['date_time']
    assert 'month' in datetime_facts['date_time']
    assert 'weekday'

# Generated at 2022-06-20 19:17:31.367663
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Make up the test data
    time_stamp_base = datetime.datetime(2020,8,12,3,21,1)
    time_stamp1 = time_stamp_base + datetime.timedelta(hours=5)
    time_stamp2 = time_stamp_base + datetime.timedelta(hours=-5)
    epoch_timestamp = int(time_stamp_base.timestamp())
    epoch_timestamp_int = int(time_stamp_base.strftime('%s'))

    # For the first test, set the current time to the base time
    # for all of the test cases
    time.time = lambda: time_stamp_base.timestamp()
    collector = DateTimeFactCollector()

# Generated at 2022-06-20 19:17:36.744869
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'
    assert dtfc._fact_ids == set()

    dtfc._fact_id = set()
    assert dtfc._fact_ids == set()


# Generated at 2022-06-20 19:17:39.518499
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    """Unit test for constructor of class DateTimeFactCollector"""

    collector = DateTimeFactCollector()
    assert collector.name == 'date_time'
    assert not collector._fact_ids

# Generated at 2022-06-20 19:17:42.066984
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dfc = DateTimeFactCollector()
    assert dfc
    assert dfc.name == 'date_time'

# Generated at 2022-06-20 19:18:18.741063
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()
    result = collector.collect(collected_facts=dict())
    assert result.keys()[0] == 'date_time'
    assert isinstance(result['date_time']['epoch'], str)

# Generated at 2022-06-20 19:18:28.453065
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Unit test for method collect of class DateTimeFactCollector"""
    my_collector = DateTimeFactCollector()
    time.tzset()

    collected_facts = my_collector.collect()
    my_date_time_facts = collected_facts['date_time']
    # Check the full datetime string (iso8601) is not empty
    assert my_date_time_facts['iso8601'] != ''

    # Get the epoch seconds as an integer, and convert it to an epoch timestamp
    my_epoch = int(my_date_time_facts['epoch_int'])
    my_epoch_timestamp = datetime.datetime.utcfromtimestamp(my_epoch)
    # Compare epoch (in integer format) and iso8601 to ensure consistency

# Generated at 2022-06-20 19:18:36.548747
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    fc = DateTimeFactCollector()
    fc_dict = fc.collect()
    assert isinstance(fc_dict, dict)
    assert 'date_time' in fc_dict
    assert fc_dict['date_time']['year']
    assert fc_dict['date_time']['month']
    assert fc_dict['date_time']['weekday']
    assert fc_dict['date_time']['weekday_number']
    assert fc_dict['date_time']['weeknumber']
    assert fc_dict['date_time']['day']
    assert fc_dict['date_time']['hour']
    assert fc_dict['date_time']['minute']
    assert fc_dict['date_time']['second']

# Generated at 2022-06-20 19:18:48.109629
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts import FactCollector

    ansible_module = type('AnsibleModuleStub', (object,), {
        'params': {},
    })

    # DateTimeFactCollector uses platform module functions which fail with
    # fake filesystem mounted in test workspace. We need to mock them.
    import ansible.module_utils.facts.collectors.date_time as date_time
    import datetime as dt
    import time

    old_time_strftime = time.strftime
    old_dt_utc_from_timestamp = dt.datetime.utcfromtimestamp
    old_dt_from_timestamp = dt.datetime.fromtimestamp
    old_dt_now = dt.datetime.now

    def now_stub():
        return dt.datetime

# Generated at 2022-06-20 19:18:50.213294
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    facts = DateTimeFactCollector()
    facts.collect()

# Generated at 2022-06-20 19:18:59.259087
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    result = fact_collector.collect()
    assert 'date_time' in result
    result = result['date_time']
    assert result['year'] == datetime.datetime.now().strftime('%Y')
    assert result['month'] == datetime.datetime.now().strftime('%m')
    assert result['weekday'] == datetime.datetime.now().strftime('%A')
    assert result['weekday_number'] == datetime.datetime.now().strftime('%w')
    assert result['weeknumber'] == datetime.datetime.now().strftime('%W')
    assert result['day'] == datetime.datetime.now().strftime('%d')

# Generated at 2022-06-20 19:19:00.697398
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    df = DateTimeFactCollector()
    assert df.name == 'date_time'

# Generated at 2022-06-20 19:19:09.090304
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtf = DateTimeFactCollector()
    facts = dtf.collect()
    assert isinstance(facts['date_time'], dict)
    assert isinstance(facts['date_time']['year'], str)
    assert isinstance(facts['date_time']['month'], str)
    assert isinstance(facts['date_time']['weekday'], str)
    assert isinstance(facts['date_time']['weekday_number'], str)
    assert isinstance(facts['date_time']['weeknumber'], str)
    assert isinstance(facts['date_time']['day'], str)
    assert isinstance(facts['date_time']['hour'], str)
    assert isinstance(facts['date_time']['minute'], str)

# Generated at 2022-06-20 19:19:18.958782
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtf = DateTimeFactCollector()
    facts = dtf.collect()
    assert facts['date_time']['year'] == '2018'
    assert facts['date_time']['month'] == '06'
    assert facts['date_time']['weekday'] == 'Tuesday'
    assert facts['date_time']['weekday_number'] == '2'
    assert facts['date_time']['day'] == '05'
    assert facts['date_time']['hour'] == '08'
    assert facts['date_time']['minute'] == '30'
    assert facts['date_time']['second'] == '45'
    assert facts['date_time']['epoch'] != ''
    assert facts['date_time']['epoch_int'] != ''

# Generated at 2022-06-20 19:19:30.452559
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Create the DateTimeFactCollector object
    dtfc_obj = DateTimeFactCollector()
    # Call method
    response = dtfc_obj.collect()
    # Basic assertions
    assert response is not None
    assert type(response) is dict
    assert 'date_time' in response
    assert type(response['date_time']) is dict
    # Assertions on response['date_time']
    assert len(response['date_time']) > 1
    assert 'year' in response['date_time']
    assert 'month' in response['date_time']
    assert 'weekday' in response['date_time']
    assert 'weekday_number' in response['date_time']
    assert 'weeknumber' in response['date_time']
    assert 'day' in response['date_time']

# Generated at 2022-06-20 19:20:54.294711
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtf_collector = DateTimeFactCollector()
    facts_dict = dtf_collector.collect()
    assert facts_dict['date_time']['year'].isdigit() and len(facts_dict['date_time']['year']) == 4
    assert facts_dict['date_time']['month'].isdigit() and len(facts_dict['date_time']['month']) == 2
    assert facts_dict['date_time']['weekday'] in ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
    assert facts_dict['date_time']['weekday_number'].isdigit() and len(facts_dict['date_time']['weekday_number']) == 1

# Generated at 2022-06-20 19:20:59.617932
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'
    assert date_time_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:21:02.186075
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector is not None

# Generated at 2022-06-20 19:21:15.345228
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dc = DateTimeFactCollector()
    facts_dict = {}

# Generated at 2022-06-20 19:21:19.244337
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'


# Generated at 2022-06-20 19:21:23.165459
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector.collect()
    assert isinstance(date_time_facts['date_time'], dict)

# Generated at 2022-06-20 19:21:35.883027
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    date_time_facts = dtfc.collect()

    assert isinstance(date_time_facts['date_time']['epoch'], str)
    assert isinstance(date_time_facts['date_time']['epoch_int'], str)
    assert isinstance(date_time_facts['date_time']['iso8601_micro'], str)
    assert isinstance(date_time_facts['date_time']['iso8601'], str)
    assert isinstance(date_time_facts['date_time']['date'], str)
    assert isinstance(date_time_facts['date_time']['time'], str)


# Generated at 2022-06-20 19:21:37.243489
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()

# Generated at 2022-06-20 19:21:41.371748
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_collector = DateTimeFactCollector()
    date_time = date_time_collector.collect().get('date_time')
    assert date_time.__class__ == dict



# Generated at 2022-06-20 19:21:44.326865
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    a = DateTimeFactCollector()
    assert a != None
    assert a.name == 'date_time'
    assert a._fact_ids == set()
