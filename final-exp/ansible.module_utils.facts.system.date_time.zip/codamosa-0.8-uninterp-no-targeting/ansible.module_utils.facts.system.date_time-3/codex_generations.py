

# Generated at 2022-06-20 19:11:47.859997
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'
    assert dtfc.priority == 10
    assert dtfc._fact_ids == set()



# Generated at 2022-06-20 19:11:50.565825
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector.name == 'date_time'
    obj = DateTimeFactCollector()
    assert obj._fact_ids == set()


# Generated at 2022-06-20 19:11:58.046654
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_Collector = DateTimeFactCollector()
    datetime_fact = test_Collector.collect()
    assert datetime_fact['date_time']['date'] == time.strftime('%Y-%m-%d')
    assert datetime_fact['date_time']['time'] == time.strftime('%H:%M:%S')
    assert datetime_fact['date_time']['day'] == time.strftime('%d')
    assert datetime_fact['date_time']['hour'] == time.strftime('%H')
    assert datetime_fact['date_time']['minute'] == time.strftime('%M')
    assert datetime_fact['date_time']['month'] == time.strftime('%m')

# Generated at 2022-06-20 19:12:00.892822
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    datetime_fact_test_obj = DateTimeFactCollector()
    assert datetime_fact_test_obj.collect()

# Generated at 2022-06-20 19:12:01.763341
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()

# Generated at 2022-06-20 19:12:14.763977
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collector = DateTimeFactCollector()
    facts = collector.collect()
    assert type(facts['date_time']) is dict
    assert 'year' in facts['date_time'].keys()
    assert 'month' in facts['date_time'].keys()
    assert 'day' in facts['date_time'].keys()
    assert 'weekday' in facts['date_time'].keys()
    assert 'weekday_number' in facts['date_time'].keys()
    assert 'weeknumber' in facts['date_time'].keys()
    assert 'hour' in facts['date_time'].keys()
    assert 'minute' in facts['date_time'].keys()
    assert 'second' in facts['date_time'].keys()
    assert 'epoch' in facts['date_time'].keys()
   

# Generated at 2022-06-20 19:12:17.902513
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    """This is a constructor test case"""
    dtf = DateTimeFactCollector()
    assert dtf.name == 'date_time'

# Generated at 2022-06-20 19:12:21.043007
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'
    assert 'date_time' not in x._fact_ids

# Generated at 2022-06-20 19:12:23.083431
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dfc = DateTimeFactCollector()
    assert(dfc.name == 'date_time')

# Generated at 2022-06-20 19:12:25.598387
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Constructor test without arguments
    facts = DateTimeFactCollector()
    assert isinstance(facts, DateTimeFactCollector)

# Generated at 2022-06-20 19:12:33.066195
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    datetime_facts = DateTimeFactCollector()
    assert datetime_facts.name == "date_time"
    assert isinstance(datetime_facts.collect(), dict)

# Generated at 2022-06-20 19:12:34.016564
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()


# Generated at 2022-06-20 19:12:46.775820
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # All tests will be run with the below initialization of the base class
    from ansible.module_utils.facts.parsers.system.base import BaseFactParser
    args = {'module_args': ''}
    object = BaseFactParser(args)

    # Create an instance of class DateTimeFactCollector
    collector = DateTimeFactCollector(object)

    # Call the method collect of class DateTimeFactCollector
    result = collector.collect()

    # Assertion
    assert result is not None

# Generated at 2022-06-20 19:12:52.779438
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_collector = DateTimeFactCollector()
    collected_facts = dict()
    collected_facts = date_time_collector.collect(module=None, collected_facts=collected_facts)
    assert collected_facts.get('date_time') is not None

# Generated at 2022-06-20 19:13:01.880520
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Default values
    now = datetime.datetime.now()
    epoch_ts = time.time()
    DateTimeFactCollector_object = DateTimeFactCollector()
    facts_dict = DateTimeFactCollector_object.collect(None, None)

    # Expected values
    date_time_facts = {}
    date_time_facts['year'] = now.strftime('%Y')
    date_time_facts['month'] = now.strftime('%m')
    date_time_facts['weekday'] = now.strftime('%A')
    date_time_facts['weekday_number'] = now.strftime('%w')
    date_time_facts['weeknumber'] = now.strftime('%W')
    date_time_facts['day'] = now.strftime('%d')
    date

# Generated at 2022-06-20 19:13:09.810821
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():

    dummy_module = object()
    date_time_facts = DateTimeFactCollector().collect(module=dummy_module)

    assert date_time_facts['date_time']['year']
    assert date_time_facts['date_time']['month']
    assert date_time_facts['date_time']['weekday']
    assert date_time_facts['date_time']['weekday_number']
    assert date_time_facts['date_time']['weeknumber']
    assert date_time_facts['date_time']['day']
    assert date_time_facts['date_time']['hour']
    assert date_time_facts['date_time']['minute']
    assert date_time_facts['date_time']['second']

# Generated at 2022-06-20 19:13:12.761375
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'


# Generated at 2022-06-20 19:13:23.063204
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    mock_module = AnsibleModuleMock()
    facts_dict = {}

    dtf = DateTimeFactCollector()

    facts_dict['date_time'] = dtf.collect(module=mock_module, collected_facts=facts_dict)

    assert isinstance(facts_dict['date_time']['epoch'], str)
    assert isinstance(facts_dict['date_time']['epoch_int'], str)
    assert len(facts_dict['date_time']['epoch']) > 0
    assert len(facts_dict['date_time']['epoch_int']) > 0


# Generated at 2022-06-20 19:13:25.732614
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time = DateTimeFactCollector()
    assert date_time.name == 'date_time'
    assert date_time.collect()['date_time'] is not None

# Generated at 2022-06-20 19:13:31.210335
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj.name == 'date_time'
    assert obj._fact_ids == set()

    assert type(obj.collect()) == dict
    assert 'date_time' in obj.collect()

# Generated at 2022-06-20 19:13:43.362011
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    foo = DateTimeFactCollector()
    assert foo.name == 'date_time'
    assert type(foo._fact_ids) == set


# Generated at 2022-06-20 19:13:51.652472
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    DATE_TIME_COLLECTOR = DateTimeFactCollector()

    result = DATE_TIME_COLLECTOR.collect()

    assert 'date_time' in result

    assert 'year' in result['date_time']
    assert 'month' in result['date_time']
    assert 'weekday' in result['date_time']
    assert 'weekday_number' in result['date_time']
    assert 'weeknumber' in result['date_time']
    assert 'day' in result['date_time']
    assert 'hour' in result['date_time']
    assert 'minute' in result['date_time']
    assert 'second' in result['date_time']
    assert 'epoch' in result['date_time']
    assert 'epoch_int' in result['date_time']
    assert 'date'

# Generated at 2022-06-20 19:13:55.569952
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Unit test for method collect of class DateTimeFactCollector"""
    DateTimeFactCollector._fact_ids = set()
    DateTimeFactCollector.collect()

# Generated at 2022-06-20 19:13:59.445164
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'
    assert date_time_fact_collector._fact_ids == set()



# Generated at 2022-06-20 19:14:01.340609
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()
    assert collector



# Generated at 2022-06-20 19:14:08.095780
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
	_dt = DateTimeFactCollector()

	# test if the result of collect method is a dictionary
	collect_result = _dt.collect()
	assert isinstance(collect_result, dict)
	assert collect_result['date_time']['epoch_int'] != ""

# Generated at 2022-06-20 19:14:11.361355
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
  
    # Create instance of DateTimeFactCollector
    date_time = DateTimeFactCollector()

    # Check the name of DateTimeFactCollector
    assert date_time.name == 'date_time' , "Name of DateTimeFactCollector is not equal to date_time"


# Generated at 2022-06-20 19:14:15.719590
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Make sure the 'date_time' fact is present,
    and contains the correct key/value pairs.
    """

    date_time_collector = DateTimeFactCollector()

    # Execute the method that we wish to test
    facts = date_time_collector.collect()

    # Verify the results
    assert 'date_time' in facts, 'The "date_time" fact was not present in the returned facts!'
    assert facts['date_time'], 'The "date_time" fact was empty!'
    assert type(facts['date_time']) == dict, 'The "date_time" fact was not a dictionary!'
    assert len(facts['date_time']) == 24, 'The "date_time" fact contained the wrong number of key/value pairs!'

# Generated at 2022-06-20 19:14:16.833837
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_facts = DateTimeFactCollector()
    assert date_time_facts

# Generated at 2022-06-20 19:14:24.435015
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-20 19:14:41.672280
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfa = DateTimeFactCollector()
    assert dtfa.name == 'date_time'
    assert dtfa.collect() is not None

# Generated at 2022-06-20 19:14:54.583593
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    example = {}
    for k in ('year', 'month', 'weekday', 'weekday_number', 'day', 'hour', 'minute', 'second',
              'epoch', 'epoch_int', 'date', 'time', 'iso8601_micro', 'iso8601', 'iso8601_basic',
              'iso8601_basic_short', 'tz', 'tzzone', 'tz_dst', 'tz_offset'):
        example[k] = '1'

    facts = {'date_time': example}
    dtfc = DateTimeFactCollector()
    dtfc_result = dtfc.collect(collected_facts=facts)
    assert isinstance(dtfc_result, dict)
    assert len(dtfc_result) == 1
    assert 'date_time' in dtfc_result


# Generated at 2022-06-20 19:15:04.014457
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Create instance of class DateTimeFactCollector
    dtf = DateTimeFactCollector()
    # Run some tests on method collect of class DateTimeFactCollector
    result = dtf.collect()
    assert isinstance(result, dict) and result.keys() == set(['date_time'])
    assert isinstance(result['date_time'], dict)
    assert isinstance(result['date_time']['year'], six.string_types)
    assert isinstance(result['date_time']['month'], six.string_types)
    assert isinstance(result['date_time']['weekday'], six.string_types)
    assert isinstance(result['date_time']['weekday_number'], six.string_types)

# Generated at 2022-06-20 19:15:13.150858
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    ansible_date_time_facts = dtfc.collect()

    assert type(ansible_date_time_facts['date_time']['epoch']) is str
    assert len(ansible_date_time_facts['date_time']['epoch_int']) == len(ansible_date_time_facts['date_time']['epoch'])
    assert len(ansible_date_time_facts['date_time']['iso8601']) == 20
    assert len(ansible_date_time_facts['date_time']['iso8601_micro']) == 25
    assert len(ansible_date_time_facts['date_time']['iso8601_basic']) == 20

# Generated at 2022-06-20 19:15:15.842382
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    try:
        assert(DateTimeFactCollector())
    except:
        assert(False)


# Generated at 2022-06-20 19:15:17.444281
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    my_dtf = DateTimeFactCollector()
    assert my_dtf is not None
    assert my_dtf.name == 'date_time'

# Generated at 2022-06-20 19:15:21.666542
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()
    assert collector.name == 'date_time'
    assert set(collector._fact_ids) == set()


# Generated at 2022-06-20 19:15:25.055939
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()
    assert collector.name == 'date_time'
    assert collector._fact_ids == set()


# Generated at 2022-06-20 19:15:34.931516
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    coll = DateTimeFactCollector(None)
    facts_dict = coll.collect()
    assert 'date_time' in facts_dict
    assert 'epoch' in facts_dict['date_time']
    assert 'epoch_int' in facts_dict['date_time']
    assert 'year' in facts_dict['date_time']
    assert 'month' in facts_dict['date_time']
    assert 'day' in facts_dict['date_time']
    assert 'weeknumber' in facts_dict['date_time']
    assert 'weekday' in facts_dict['date_time']
    assert 'weekday_number' in facts_dict['date_time']
    assert 'hour' in facts_dict['date_time']
    assert 'minute' in facts_dict['date_time']

# Generated at 2022-06-20 19:15:40.417508
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtf = DateTimeFactCollector()
    assert dtf.name == 'date_time'
    assert isinstance(dtf._fact_ids, set)
    assert dtf._fact_ids == set()


# Generated at 2022-06-20 19:16:12.773682
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'
    assert x._fact_ids == set()

# Generated at 2022-06-20 19:16:16.662351
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    from ansible.module_utils.facts import FactsCollector
    from ansible.module_utils.facts.collectors import date_time
    facts_module = FactsCollector()
    assert isinstance(facts_module.collectors[0], date_time.DateTimeFactCollector)

# Generated at 2022-06-20 19:16:19.216219
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dates = DateTimeFactCollector()
    assert(dates.collect().keys() == ['date_time'])

# Generated at 2022-06-20 19:16:21.064785
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dfc = DateTimeFactCollector()
    assert dfc.name == 'date_time'

# Generated at 2022-06-20 19:16:23.314447
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    with DateTimeFactCollector() as tester:
        assert hasattr(tester, 'name')
        assert hasattr(tester, 'collect')

# Generated at 2022-06-20 19:16:27.435983
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt.name == 'date_time'
    #assert dt._fact_ids == set()
    #assert dt._platform == 'all'

# Generated at 2022-06-20 19:16:30.551242
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert isinstance(dt, DateTimeFactCollector)
    assert isinstance(dt.name, str)
    assert isinstance(dt._fact_ids, set)



# Generated at 2022-06-20 19:16:34.544724
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()

# Generated at 2022-06-20 19:16:35.789921
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
        x = DateTimeFactCollector()
        assert x.name == "date_time"

# Generated at 2022-06-20 19:16:37.130093
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()

# Generated at 2022-06-20 19:17:37.761081
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert isinstance(dtfc, DateTimeFactCollector)


# Generated at 2022-06-20 19:17:40.570175
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == "date_time"
    assert dtfc._fact_ids == set()


# Generated at 2022-06-20 19:17:47.680918
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_obj = DateTimeFactCollector()

    # Test with functional parameters
    # Test with valid parameters
    
    result = test_obj.collect()
    assert result is not None

    # Test with invalid parameters
    # result = test_obj.collect(module="dummy")
    # assert result is not None

# Generated at 2022-06-20 19:17:51.428926
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    result = dict()
    d_obj = DateTimeFactCollector()
    result['date_time'] = d_obj.collect()
    assert(result != {})
    assert(result['date_time'] != {})



# Generated at 2022-06-20 19:18:00.065174
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    ansible_facts = dict()
    collector = DateTimeFactCollector()
    test_facts = collector.collect(inexistent_module_param='IGNORE', ansible_facts=ansible_facts)
    assert test_facts['date_time'] is not None
    assert len(test_facts['date_time']) is not None
    assert len(test_facts['date_time']) > 0

# Generated at 2022-06-20 19:18:10.558145
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    class CustomModule(object):
        def __init__(self):
            self.params = {}
    test_module = CustomModule()
    test_module.params['gather_subset'] = []
    test_module.params['filter'] = '*'
    facts = DateTimeFactCollector(test_module).collect()
    assert facts['date_time'] is not None
    assert 'date' in facts['date_time']
    assert 'utcnow' in facts['date_time']



# Generated at 2022-06-20 19:18:24.584154
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_facts_collector = DateTimeFactCollector()
    assert isinstance(date_time_facts_collector, BaseFactCollector)

    # print('date_time_facts_collector:', date_time_facts_collector)
    data_time_facts = date_time_facts_collector.collect()
    # print("data_time_facts:", data_time_facts)
    # print("data_time_facts['date_time']['time']:", data_time_facts['date_time']['time'])
    assert isinstance(data_time_facts['date_time']['time'], str)
    assert len(data_time_facts['date_time']['time']) == 8
    assert data_time_facts['date_time']['time'].startswith

# Generated at 2022-06-20 19:18:27.323608
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
  DateTimeFactCollector = DateTimeFactCollector()
  DateTimeFactCollector.collect()


# Generated at 2022-06-20 19:18:30.762721
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    facts = DateTimeFactCollector()
    assert facts.name == 'date_time'
    assert facts._fact_ids == set()


# Generated at 2022-06-20 19:18:32.893002
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'

# Generated at 2022-06-20 19:20:51.541838
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dateTimeFactCollector = DateTimeFactCollector()
    assert dateTimeFactCollector is not None
    assert dateTimeFactCollector.name == 'date_time'
    assert isinstance(dateTimeFactCollector._fact_ids, set)
    assert len(dateTimeFactCollector._fact_ids) == 0
    assert hasattr(dateTimeFactCollector, 'collect')
    assert callable(getattr(dateTimeFactCollector, 'collect'))

# Generated at 2022-06-20 19:21:05.283937
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Init an instance of DateTimeFactCollector
    date_time_fact_collector = DateTimeFactCollector()
    # Collect date time facts
    date_time_facts = date_time_fact_collector.collect()
    # Verify date_time facts are collected
    assert date_time_facts['date_time']['year'] is not None
    assert date_time_facts['date_time']['month'] is not None
    assert date_time_facts['date_time']['weekday'] is not None
    assert date_time_facts['date_time']['weekday_number'] is not None
    assert date_time_facts['date_time']['weeknumber'] is not None
    assert date_time_facts['date_time']['day'] is not None

# Generated at 2022-06-20 19:21:13.021835
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()

    assert date_time_fact_collector.name == 'date_time'
    assert date_time_fact_collector._fact_ids is not None
    assert len(date_time_fact_collector._fact_ids) == 0

test_DateTimeFactCollector()

# Unit test to check calling instance of class DateTimeFactCollector

# Generated at 2022-06-20 19:21:25.425224
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    '''
    Test if the method collect of class DateTimeFactCollector
    returns values as expected.

    We cannot test all possible cases, but we should test at least
    the most obvious ones.
    '''

    ##############################################################
    # First, try a test with a mock module because we want to
    # be able to control the values of the date and the time.
    ##############################################################

    # Create a DateTimeFactCollector object to be tested
    # for all tests in this unit test.
    dtf = DateTimeFactCollector()

    # Define the expected values for the facts that we want to test.

# Generated at 2022-06-20 19:21:28.024703
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_obj = DateTimeFactCollector()
    test_obj.collect()

# Generated at 2022-06-20 19:21:29.314808
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj.name == 'date_time'
    assert obj._fact_ids == set()


# Generated at 2022-06-20 19:21:31.339040
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector.name == 'date_time'

# Generated at 2022-06-20 19:21:33.932109
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector.name == 'date_time'
    assert DateTimeFactCollector._fact_ids == set()

# Generated at 2022-06-20 19:21:37.039061
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    d = DateTimeFactCollector()
    assert d is not None

# Generated at 2022-06-20 19:21:41.753199
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_DateTimeFactCollector = DateTimeFactCollector()
    out_dict = test_DateTimeFactCollector.collect()
    assert out_dict == {'date_time': {}}, "Result of DateTimeFactCollector.collect() is wrong"