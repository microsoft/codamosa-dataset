

# Generated at 2022-06-20 19:11:45.892386
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()

# Generated at 2022-06-20 19:11:47.859325
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collector = DateTimeFactCollector()
    result = collector.collect()
    assert result['date_time']['year'] is not None

# Generated at 2022-06-20 19:11:50.246487
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'
    assert x._fact_ids == set()

# Generated at 2022-06-20 19:11:53.551923
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    res = fact_collector.collect()
    assert(len(res) == 1)
    assert(res['date_time']['epoch'] == str(int(time.time())))
    assert(res['date_time']['epoch_int'] == str(int(time.time())))

# Generated at 2022-06-20 19:11:56.520204
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    '''Unit test for constructor of class DateTimeFactCollector'''

    # Create an instance of DateTimeFactCollector
    my_obj = DateTimeFactCollector()

    # Check instance created successfully
    assert isinstance(my_obj, DateTimeFactCollector)

# Generated at 2022-06-20 19:11:58.602632
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_collector = DateTimeFactCollector()
    assert date_time_collector.name == "date_time"
    assert date_time_collector._fact_ids == set()


# Generated at 2022-06-20 19:12:06.559521
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    facts_dict = {}
    date_time_facts = {}

    # Store the timestamp once, then get local and UTC versions from that
    epoch_ts = time.time()
    now = datetime.datetime.fromtimestamp(epoch_ts)
    utcnow = datetime.datetime.utcfromtimestamp(epoch_ts)

    date_time_facts['year'] = now.strftime('%Y')
    date_time_facts['month'] = now.strftime('%m')
    date_time_facts['weekday'] = now.strftime('%A')
    date_time_facts['weekday_number'] = now.strftime('%w')
    date_time_facts['weeknumber'] = now.strftime('%W')

# Generated at 2022-06-20 19:12:11.268798
# Unit test for constructor of class DateTimeFactCollector

# Generated at 2022-06-20 19:12:20.228613
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    instance = DateTimeFactCollector()
    assert isinstance(instance, DateTimeFactCollector)
    collect_result = instance.collect()

    assert collect_result['date_time']['year'] is not None
    assert collect_result['date_time']['month'] is not None
    assert collect_result['date_time']['weekday'] is not None
    assert collect_result['date_time']['weekday_number'] is not None
    assert collect_result['date_time']['weeknumber'] is not None
    assert collect_result['date_time']['day'] is not None
    assert collect_result['date_time']['hour'] is not None
    assert collect_result['date_time']['minute'] is not None

# Generated at 2022-06-20 19:12:23.145801
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    This is a unit test for the method collect of class
    DateTimeFactCollector.
    """
    def test_func():
        pass

    DateTimeFactCollector().collect(module=test_func, collected_facts={})

# Generated at 2022-06-20 19:12:36.633212
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import time
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.date_time import DateTimeFactCollector
    from ansible.module_utils._text import to_bytes, to_native

    date_time_fact_collector = DateTimeFactCollector()

    # test ansible.module_utils.facts.collector.BaseFactCollector.__init__
    assert isinstance(date_time_fact_collector, BaseFactCollector)
    assert date_time_fact_collector.name == 'date_time'

    # test ansible.module_utils.facts.collectors.date_time.DateTimeFactCollector.collect
    epoch_ts = time.time()
    utcnow = datetime.datetime.utcfromtimestamp

# Generated at 2022-06-20 19:12:47.532552
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Check if DateTimeFactCollector.collect() returns a proper date time facts."""
    # arrange
    dateTimeFactCollector = DateTimeFactCollector()
    # act
    date_time_facts = dateTimeFactCollector.collect()
    # assert
    assert 'date_time' in date_time_facts
    assert 'year' in date_time_facts['date_time']
    assert 'month' in date_time_facts['date_time']
    assert 'weekday' in date_time_facts['date_time']
    assert 'weekday_number' in date_time_facts['date_time']
    assert 'weeknumber' in date_time_facts['date_time']
    assert 'day' in date_time_facts['date_time']

# Generated at 2022-06-20 19:12:49.429270
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    fact_collector = DateTimeFactCollector()
    assert fact_collector is not None

# Generated at 2022-06-20 19:13:01.299871
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    facts_dict = date_time_fact_collector.collect()

    assert isinstance(facts_dict['date_time'], dict)
    assert 'year' in facts_dict['date_time']
    assert 'month' in facts_dict['date_time']
    assert 'weekday' in facts_dict['date_time']
    assert 'weekday_number' in facts_dict['date_time']
    assert 'weeknumber' in facts_dict['date_time']
    assert 'day' in facts_dict['date_time']
    assert 'hour' in facts_dict['date_time']
    assert 'minute' in facts_dict['date_time']
    assert 'second' in facts_dict['date_time']
    assert 'epoch' in facts

# Generated at 2022-06-20 19:13:09.694730
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    from ansible.module_utils.facts import fact_collector
    import ansible.module_utils.facts.collector.date_time

    module = basic.AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
            gather_network_resources=dict(default=['all'], type='list')
        )
    )

    module.exit_json = lambda **kwargs: kwargs
    module.fail_json = lambda **kwargs: kwargs

    if not module.params['gather_subset']:
        module.params['gather_subset'] = ['all']


# Generated at 2022-06-20 19:13:21.553473
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Arrange
    dtFactsCollector = DateTimeFactCollector()

    # Act
    result = dtFactsCollector.collect()

    # Assert
    assert 'date_time' in result.keys()
    assert isinstance(result['date_time'], dict)
    assert result['date_time']['epoch'].isdigit()
    assert result['date_time']['epoch_int'].isdigit()
    assert result['date_time']['year'].isdigit()
    assert result['date_time']['month'].isdigit()
    assert result['date_time']['weekday'].isalpha()
    assert result['date_time']['weekday_number'].isdigit()

# Generated at 2022-06-20 19:13:23.275700
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    '''Test DateTimeFactCollector.collect()'''
    DateTimeFactCollector().collect()

# Generated at 2022-06-20 19:13:30.154504
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    class MockModule():
        def __init__(self):
            self.params = {}

    # run DateTimeFactCollector collect method to verify it returns facts
    dt_collector = DateTimeFactCollector()
    # date_time facts are returned
    assert isinstance(dt_collector.collect(module=MockModule()), dict) is True
    # facts under date_time key
    assert 'date_time' in dt_collector.collect(module=MockModule())
    # verify all facts are present
    assert len(dt_collector.collect(module=MockModule()).get('date_time')) == 18

# Generated at 2022-06-20 19:13:41.246869
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtf = DateTimeFactCollector()
    dtf.collect()
    assert 'date_time' in dtf.facts
    assert 'year' in dtf.facts['date_time']
    assert 'month' in dtf.facts['date_time']
    assert 'weekday' in dtf.facts['date_time']
    assert 'weekday_number' in dtf.facts['date_time']
    assert 'weeknumber' in dtf.facts['date_time']
    assert 'day' in dtf.facts['date_time']
    assert 'hour' in dtf.facts['date_time']
    assert 'minute' in dtf.facts['date_time']
    assert 'second' in dtf.facts['date_time']
    assert 'epoch' in dtf.facts['date_time']

# Generated at 2022-06-20 19:13:47.858033
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Testing string and integer format of epoch
    date_time_facts = DateTimeFactCollector().collect()
    assert date_time_facts['date_time']['epoch'].isdigit()
    epoch_str = date_time_facts['date_time']['epoch']
    assert int(epoch_str) == int(date_time_facts['date_time']['epoch_int'])

# Generated at 2022-06-20 19:13:57.545612
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector
    assert obj.name == 'date_time'
    assert obj._fact_ids == set()


# Generated at 2022-06-20 19:14:06.178379
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    result = DateTimeFactCollector().collect()
    assert 'date_time' in result
    assert 'year' in result['date_time']
    assert 'month' in result['date_time']
    assert 'weekday' in result['date_time']
    assert 'weekday_number' in result['date_time']
    assert 'weeknumber' in result['date_time']
    assert 'day' in result['date_time']
    assert 'hour' in result['date_time']
    assert 'minute' in result['date_time']
    assert 'second' in result['date_time']
    assert 'epoch' in result['date_time']
    assert 'epoch_int' in result['date_time']
    assert 'date' in result['date_time']
    assert 'time' in result['date_time']

# Generated at 2022-06-20 19:14:09.021223
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector.collect()

# Generated at 2022-06-20 19:14:10.052514
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
   dtfc = DateTimeFactCollector()


# Generated at 2022-06-20 19:14:22.628128
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import time
    import datetime


# Generated at 2022-06-20 19:14:32.351320
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collector = DateTimeFactCollector()
    collected_facts = collector.collect()

# Generated at 2022-06-20 19:14:37.723010
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()
    assert isinstance(collector, DateTimeFactCollector)
    assert collector.name == 'date_time'
    assert collector._fact_ids == set()


# Generated at 2022-06-20 19:14:39.854279
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj.name == 'date_time'

# Generated at 2022-06-20 19:14:41.297507
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    d = DateTimeFactCollector()
    assert 'date_time' == d.name

# Generated at 2022-06-20 19:14:44.721804
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'
    assert set(x._fact_ids) == set()


# Generated at 2022-06-20 19:14:56.167700
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtFactCollector = DateTimeFactCollector()
    assert dtFactCollector.name == 'date_time'


# Generated at 2022-06-20 19:15:00.157234
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    facts_dict = {}
    f = DateTimeFactCollector(module=None, collected_facts=facts_dict)
    f.collect()
    assert 'date_time' in facts_dict


# Generated at 2022-06-20 19:15:13.729426
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time = DateTimeFactCollector()
    date_time.collect()

# Generated at 2022-06-20 19:15:17.140981
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    result = DateTimeFactCollector()
    assert result.name == 'date_time'
    assert result._fact_ids == set()


# Generated at 2022-06-20 19:15:19.275958
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj.name == 'date_time'

# Generated at 2022-06-20 19:15:30.446091
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_facts = DateTimeFactCollector().collect()
    assert date_time_facts['date_time']['year'] == time.strftime('%Y')
    assert date_time_facts['date_time']['month'] == time.strftime('%m')
    assert date_time_facts['date_time']['weekday'] == time.strftime('%A')
    assert date_time_facts['date_time']['weekday_number'] == time.strftime('%w')
    assert date_time_facts['date_time']['weeknumber'] == time.strftime('%W')
    assert date_time_facts['date_time']['day'] == time.strftime('%d')

# Generated at 2022-06-20 19:15:33.126918
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collector = DateTimeFactCollector({}, {})
    res = collector.collect()

    assert type(res) == dict


# Generated at 2022-06-20 19:15:35.612388
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    result = DateTimeFactCollector()
    assert result is not None


# Generated at 2022-06-20 19:15:46.932421
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Arrange
    import math
    import time

    from ansible.module_utils.facts.collector import BaseFactCollector

    test_subject = DateTimeFactCollector()
    epoch_timestamp = str(math.trunc(time.time()))

    # Act
    result = test_subject.collect()
    
    # Assert
    assert 'year' in result['date_time']
    assert 'month' in result['date_time']
    assert 'weekday' in result['date_time']
    assert 'weekday_number' in result['date_time']
    assert 'weeknumber' in result['date_time']
    assert 'day' in result['date_time']
    assert 'hour' in result['date_time']
    assert 'minute' in result['date_time']

# Generated at 2022-06-20 19:15:58.282151
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    y = '2019'
    m = '04'
    d = '30'
    h = '16'
    mt = '12'
    s = '17'
    base_date_time = y + '-' + m + '-' + d + ' ' + h + ':' + mt + ':' + s
    date_time_facts = {}
    date_time_facts['year'] = y
    date_time_facts['month'] = m
    date_time_facts['weekday'] = 'Tuesday'
    date_time_facts['weekday_number'] = '2'
    date_time_facts['weeknumber'] = '18'
    date_time_facts['day'] = d
    date_time_facts['hour'] = h
    date_time_facts['minute'] = mt

# Generated at 2022-06-20 19:16:24.325138
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collector = DateTimeFactCollector()
    collected_facts = collector.collect()
    assert collected_facts['date_time']['date'] == time.strftime('%Y-%m-%d')
    assert collected_facts['date_time']['time'] == time.strftime('%H:%M:%S')
    assert collected_facts['date_time']['epoch'] == time.strftime('%s')
    assert collected_facts['date_time']['epoch_int'] == time.strftime('%s')



# Generated at 2022-06-20 19:16:28.992580
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    facts = fact_collector.collect()
    assert len(facts['date_time']) > 10

# Generated at 2022-06-20 19:16:38.417179
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # assert True
    collector = DateTimeFactCollector()
    result = collector.collect()
    assert 'date_time' in result
    assert result['date_time']['epoch'] is not None
    assert result['date_time']['epoch_int'] is not None
    assert result['date_time']['iso8601'] is not None
    assert result['date_time']['iso8601_micro'] is not None
    assert result['date_time']['iso8601_basic'] is not None
    assert result['date_time']['iso8601_basic_short'] is not None
    assert result['date_time']['date'] is not None
    assert result['date_time']['time'] is not None
    assert result['date_time']['tz'] is not None

# Generated at 2022-06-20 19:16:46.493798
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dc = DateTimeFactCollector()
    facts = dc.collect()
    assert isinstance(facts['date_time']['epoch'], str)
    assert isinstance(facts['date_time']['epoch_int'], str)
    # Verify epoch and epoch_int have integer values
    assert isinstance(int(facts['date_time']['epoch']), int)
    assert isinstance(int(facts['date_time']['epoch_int']), int)

# Generated at 2022-06-20 19:16:49.583439
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert isinstance(DateTimeFactCollector(), DateTimeFactCollector)

# Generated at 2022-06-20 19:17:02.562844
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import datetime
    import time

    ansible_date_time = DateTimeFactCollector()
    ansible_date_time.collect()

    # Store the timestamp once, then get local and UTC versions from that
    epoch_ts = time.time()
    now = datetime.datetime.fromtimestamp(epoch_ts)
    utcnow = datetime.datetime.utcfromtimestamp(epoch_ts)

    assert int(ansible_date_time.collect()['date_time']['year']) == now.year
    assert int(ansible_date_time.collect()['date_time']['month']) == now.month
    assert ansible_date_time.collect()['date_time']['weekday'] == now.strftime('%A')

# Generated at 2022-06-20 19:17:08.088928
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    res = dt.collect()
    assert DateTimeFactCollector.name in res.keys()
    assert dt.name in res.keys()
    assert 'date_time' in res[dt.name].keys()

# Generated at 2022-06-20 19:17:10.594934
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt.name == 'date_time'


# Generated at 2022-06-20 19:17:12.793003
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt_fact_collector = DateTimeFactCollector()

    # For now, there are no assertions here
    dt_fact_collector.collect()

# Generated at 2022-06-20 19:17:14.356273
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    DateTimeFactCollector().collect()


# Generated at 2022-06-20 19:17:50.713207
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt_collector = DateTimeFactCollector()
    date_time_facts = dt_collector.collect()
    assert date_time_facts['date_time'] is not None



# Generated at 2022-06-20 19:17:55.615321
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_facts = DateTimeFactCollector()

    # Check if the returned name is correct.
    assert date_time_facts.name == 'date_time'

# Generated at 2022-06-20 19:17:56.391996
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    pass

# Generated at 2022-06-20 19:18:04.032967
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Build module stub
    module = AnsibleModuleStub()

    # Build a DateTimeFactCollector with the module stub
    date_time_fact_collector = DateTimeFactCollector(module)

    # Call method collect of the DateTimeFactCollector
    date_time_facts = date_time_fact_collector.collect()

    # Check content of the collected facts
    assert len(date_time_facts.keys()) == 1
    assert 'date_time' in date_time_facts
    assert len(date_time_facts['date_time'].keys()) >= 13

# Generated at 2022-06-20 19:18:14.401662
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    facts = dtfc.collect()
    assert facts['date_time'] is not None
    assert facts['date_time']['year'] is not None
    assert facts['date_time']['month'] is not None
    assert facts['date_time']['weekday'] is not None
    assert facts['date_time']['weekday_number'] is not None
    assert facts['date_time']['weeknumber'] is not None
    assert facts['date_time']['day'] is not None
    assert facts['date_time']['hour'] is not None
    assert facts['date_time']['minute'] is not None
    assert facts['date_time']['second'] is not None
    assert facts['date_time']['epoch'] is not None

# Generated at 2022-06-20 19:18:17.927795
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    """
    Test DateTimeFactCollector constructor.
    """
    assert DateTimeFactCollector.name == 'date_time'

# Generated at 2022-06-20 19:18:27.922232
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collector = DateTimeFactCollector()
    collected_facts = collector.collect()    

# Generated at 2022-06-20 19:18:36.488600
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    d_t_collector = DateTimeFactCollector()
    d_t_collect = d_t_collector.collect()
    assert 'date_time' in d_t_collect
    assert 'year' in d_t_collect['date_time']
    assert 'month' in d_t_collect['date_time']
    assert 'weekday' in d_t_collect['date_time']
    assert 'weekday_number' in d_t_collect['date_time']
    assert 'weeknumber' in d_t_collect['date_time']
    assert 'day' in d_t_collect['date_time']
    assert 'hour' in d_t_collect['date_time']
    assert 'minute' in d_t_collect['date_time']

# Generated at 2022-06-20 19:18:48.109940
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Test that DateTimeFactCollector can collect correct date and time facts."""
    date_time_collector = DateTimeFactCollector()
    facts_dict = date_time_collector.collect()
    now = datetime.datetime.now()

    assert facts_dict['date_time']['year'] == now.strftime('%Y')
    assert facts_dict['date_time']['month'] == now.strftime('%m')
    assert facts_dict['date_time']['weekday'] == now.strftime('%A')
    assert facts_dict['date_time']['weekday_number'] == now.strftime('%w')
    assert facts_dict['date_time']['weeknumber'] == now.strftime('%W')

# Generated at 2022-06-20 19:18:55.929921
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    result = DateTimeFactCollector.collect()
    assert result['date_time']['year'] == time.strftime('%Y')
    assert result['date_time']['month'] == time.strftime('%m')
    assert result['date_time']['weekday'] == time.strftime('%A')
    assert result['date_time']['weekday_number'] == time.strftime('%w')
    assert result['date_time']['weeknumber'] == time.strftime('%W')
    assert result['date_time']['day'] == time.strftime('%d')
    assert result['date_time']['hour'] == time.strftime('%H')
    assert result['date_time']['minute'] == time.strftime('%M')

# Generated at 2022-06-20 19:20:10.526665
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtf = DateTimeFactCollector()
    assert dtf.name == 'date_time'

# Generated at 2022-06-20 19:20:13.496619
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt.name == 'date_time'

# Generated at 2022-06-20 19:20:19.207729
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # create object of DateTimeFactCollector
    obj = DateTimeFactCollector()

    # call collect method of DateTimeFactCollector
    result = obj.collect()

    assert result.get('date_time').get('year') == (datetime.datetime.today()).strftime('%Y')

# Generated at 2022-06-20 19:20:32.184102
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    fd = DateTimeFactCollector()
    assert fd.name == 'date_time'
    assert fd.collect()['date_time']['year'] != ''
    assert fd.collect()['date_time']['month'] != ''
    assert fd.collect()['date_time']['weekday'] != ''
    assert fd.collect()['date_time']['weekday_number'] != ''
    assert fd.collect()['date_time']['weeknumber'] != ''
    assert fd.collect()['date_time']['day'] != ''
    assert fd.collect()['date_time']['hour'] != ''
    assert fd.collect()['date_time']['minute'] != ''
    assert fd.collect()['date_time']['second'] != ''

# Generated at 2022-06-20 19:20:40.707930
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    '''Unit test for method collect of class DateTimeFactCollector.'''
    # create a fact Collector object
    coll = DateTimeFactCollector()
    # run the collect method
    collected_facts = coll.collect()
    # set of expected keys in facts returned from method collect of class DateTimeFactCollector
    expected_keys = set(['date_time'])
    # check if the returned facts are as expected
    assert set(collected_facts.keys()) == expected_keys


# Generated at 2022-06-20 19:20:44.709320
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_collector = DateTimeFactCollector()
    assert date_time_collector.name == 'date_time'


# Generated at 2022-06-20 19:20:53.196681
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Unit test for the method DateTimeFactCollector.collect"""
    date_time_facts = DateTimeFactCollector().collect()
    assert isinstance(date_time_facts, dict)
    for key in date_time_facts:
        assert isinstance(key, str)
        assert isinstance(date_time_facts[key], dict)
        for subkey in date_time_facts[key]:
            assert isinstance(subkey, str)
            assert isinstance(date_time_facts[key][subkey], str)

# Generated at 2022-06-20 19:21:06.113536
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'
    assert not dtfc._fact_ids

# Generated at 2022-06-20 19:21:16.439059
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts.collector import FactCollector

    dt_collector = DateTimeFactCollector()
    fact_collector = FactCollector()

    # Initialize the dict to store collected facts for unit test
    collected_facts = dict()

    # Execute the logic that needs to be tested
    fact_collector.collect(dt_collector, collected_facts=collected_facts)

    # Assert resulting dict to expectations of this unit test
    assert collected_facts['date_time']
    assert 'year' in collected_facts['date_time']
    assert 'month' in collected_facts['date_time']
    assert 'weekday' in collected_facts['date_time']
    assert 'weekday_number' in collected_facts['date_time']

# Generated at 2022-06-20 19:21:18.522754
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector().name == 'date_time'
