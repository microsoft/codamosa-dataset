

# Generated at 2022-06-20 19:11:45.850827
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # see https://github.com/ansible/ansible/pull/56238
    pass

# Generated at 2022-06-20 19:11:46.821968
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector().collect()

# Generated at 2022-06-20 19:11:54.028958
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-20 19:11:58.077486
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():

    # Create DateTimeFactCollector object
    obj_date_time_fact_collector = DateTimeFactCollector()

    # Test whether fact_ids are in class variable
    if obj_date_time_fact_collector._fact_ids:
        test_status = 1
    else:
        test_status = 0

    assert test_status, "Test 1 (test_DateTimeFactCollector): Failed"


# Generated at 2022-06-20 19:12:06.476917
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # NOTE: Since it is not trivial to have unit tests which can run properly
    #       on any Windows machines, this unit test is intended to cover
    #       the main path and major possibilities.
    #       Tests which are not run will require manual validation.

    # Initialization
    dtf = DateTimeFactCollector()
    # Mock DateTimeFactCollector.collect

# Generated at 2022-06-20 19:12:09.699407
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'
    assert x._fact_ids == set()


# Generated at 2022-06-20 19:12:12.451369
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    ansible_facts = dt.collect()

    assert ansible_facts['date_time']['date'] is not None, "date should not be None"
    assert ansible_facts['date_time']['time'] is not None, "time should not be None"
    assert ansible_facts['date_time']['epoch'] is not None, "epoch should not be None"

# Generated at 2022-06-20 19:12:23.373103
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fc = DateTimeFactCollector()
    res = fc.collect()
    assert 'date_time' in res.keys()
    for key in ['year', 'date', 'month', 'weekday', 'weekday_number', 'weeknumber', 'day', 'hour', 'minute', 'second', 'epoch', 'iso8601_micro', 'iso8601', 'time']:
        assert key in res['date_time'].keys()
    assert type(res['date_time']['epoch']) == str
    assert res['date_time']['epoch']

# Generated at 2022-06-20 19:12:35.874040
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    facts = fact_collector.collect()
    assert facts["date_time"]["date"] is not None
    assert facts["date_time"]["time"] is not None
    assert facts["date_time"]["iso8601"] is not None
    assert facts["date_time"]["iso8601_micro"] is not None
    assert facts["date_time"]["epoch"] is not None
    assert facts["date_time"]["epoch_int"] is not None
    assert facts["date_time"]["epoch"] == facts["date_time"]["epoch_int"]
    assert facts["date_time"]["iso8601_basic"] is not None
    assert facts["date_time"]["iso8601_basic_short"] is not None

# Generated at 2022-06-20 19:12:44.225269
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    result = fact_collector.collect()
    assert result.get('date_time', None) is not None
    assert result['date_time'].get('iso8601_micro', None) is not None
    assert result['date_time'].get('epoch_int', None) is not None
    assert result['date_time'].get('tz_dst', None) is not None

# Generated at 2022-06-20 19:12:58.418875
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Create an instance of DateTimeFactCollector
    # and test if it is a instance of BaseFactCollector
    fact_collector = DateTimeFactCollector()
    assert(isinstance(fact_collector, BaseFactCollector))

    # Check the facts dict returned by the collect method with the
    # facts dict returned by the collect method of the class DateTimeFactCollector
    facts_dict = fact_collector.collect()
    date_time_facts = facts_dict.get('date_time')

# Generated at 2022-06-20 19:13:00.924380
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
   dt_collector = DateTimeFactCollector()
   assert dt_collector.name == 'date_time'
   assert dt_collector._fact_ids == set()

# Generated at 2022-06-20 19:13:03.542548
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtf = DateTimeFactCollector()
    assert dtf.name == 'date_time'
    assert dtf._fact_ids == set()

# Generated at 2022-06-20 19:13:06.843979
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    facts = DateTimeFactCollector()
    facts_list = facts.collect()
    assert 'date_time' in facts_list
    assert 'epoch' in facts_list['date_time']
    assert 'epoch_int' in facts_list['date_time']

# Generated at 2022-06-20 19:13:13.313624
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    #Instantiate empty object
    d = DateTimeFactCollector()

    #Check if object is of proper class
    assert isinstance(d, DateTimeFactCollector)

    #Check if object has name property
    assert d.name == "date_time"


# Generated at 2022-06-20 19:13:14.817172
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x

# Generated at 2022-06-20 19:13:22.764529
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'

    for fact_id in date_time_fact_collector._fact_ids:
        assert fact_id in ('year', 'month', 'weekday', 'weekday_number', 'weeknumber', 'day', 'hour', 'minute', 'second', 'epoch', 'epoch_int', 'date', 'time', 'iso8601_micro', 'iso8601', 'iso8601_basic', 'iso8601_basic_short', 'tz', 'tz_dst', 'tz_offset')

# Generated at 2022-06-20 19:13:31.727590
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_facts = DateTimeFactCollector().collect()['date_time']
    assert date_time_facts['year'] == datetime.datetime.utcnow().strftime('%Y')
    assert date_time_facts['month'] == datetime.datetime.utcnow().strftime('%m')
    assert date_time_facts['weekday'] == datetime.datetime.utcnow().strftime('%A')
    assert date_time_facts['weekday_number'] == datetime.datetime.utcnow().strftime('%w')
    assert date_time_facts['day'] == datetime.datetime.utcnow().strftime('%d')
    assert date_time_facts['hour'] == datetime.datetime.utcnow().strftime('%H')
    assert date_time_

# Generated at 2022-06-20 19:13:35.377636
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt_fact_collector = DateTimeFactCollector()
    assert dt_fact_collector.name == 'date_time'

# Generated at 2022-06-20 19:13:37.215256
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    """Unit test for constructor of class DateTimeFactCollector"""
    DateTimeFactCollector()

# Generated at 2022-06-20 19:13:44.709804
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dfc = DateTimeFactCollector()
    assert dfc.name == 'date_time'
    assert dfc._fact_ids == set()


# Generated at 2022-06-20 19:13:51.995190
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_facts_collector = DateTimeFactCollector()
    results = date_time_facts_collector.collect()

    assert results['date_time']['year']
    assert results['date_time']['month']
    assert results['date_time']['day']
    assert results['date_time']['minute']
    assert results['date_time']['second']
    assert results['date_time']['epoch']
    assert results['date_time']['epoch_int'] == results['date_time']['epoch']
    assert results['date_time']['weekday']
    assert results['date_time']['weekday_number']
    assert results['date_time']['weeknumber']
    assert results['date_time']['hour']
    assert results

# Generated at 2022-06-20 19:14:02.948714
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Check if the DateTimeFactCollector method collect works
    as expected.
    """
    date_time = DateTimeFactCollector()
    date_time_facts = date_time.collect()

    assert 'date_time' in date_time_facts
    assert 'year' in date_time_facts['date_time']
    assert 'month' in date_time_facts['date_time']
    assert 'day' in date_time_facts['date_time']
    assert 'hour' in date_time_facts['date_time']
    assert 'minute' in date_time_facts['date_time']
    assert 'second' in date_time_facts['date_time']
    assert 'weekday' in date_time_facts['date_time']

# Generated at 2022-06-20 19:14:06.552353
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_collector = DateTimeFactCollector()
    assert date_time_collector.name == "date_time"


# Generated at 2022-06-20 19:14:14.028042
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    def fake_fromtimestamp(input): #pylint: disable=unused-argument
        return 'fromtimestamp'

    def fake_utcfromtimestamp(input): #pylint: disable=unused-argument
        return 'utcfromtimestamp'

    def fake_strftime(string):
        string_dict = {'%Y': '2017', '%m': '01', '%A': 'Monday', '%w': '2', '%W': '3', '%d': '01', '%H': '01', '%M': '01', '%S': '01', '%s': '1483228801', '%f': '123456'}
        return string_dict.get(string, '')

    def fake_tzname():
        return ['daylight', 'daylight']


# Generated at 2022-06-20 19:14:16.776289
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    Dtf = DateTimeFactCollector()
    print(Dtf.collect())


# Generated at 2022-06-20 19:14:20.722545
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    datetimeFactCollector = DateTimeFactCollector()
    assert datetimeFactCollector.name == 'date_time'
    assert datetimeFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:14:23.565684
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Test return value of module methods:
    #   DateTimeFactCollector.collect
    item = DateTimeFactCollector()
    assert item.collect()

# Generated at 2022-06-20 19:14:32.697707
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector

    # need a _load_plugins() method to set up the fact modules
    fact_collector = BaseFactCollector()
    fact_collector._load_plugins()

    # get the date_time module and instantiate it, get the facts
    dtf = fact_collector.get_module_facts('date_time')
    dtf_facts = dtf.populate()

    # make sure the module sees a module argument
    assert basic.AnsibleModule, dtf.module

    # run the constructor for DateTimeFactCollector
    dtf_collector = DateTimeFactCollector()

    # check if the constructor for DateTimeFactCollector correctly assigns name

# Generated at 2022-06-20 19:14:40.111087
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Create a DateTimeFactCollector object to test
    test_DateTimeFactCollector = DateTimeFactCollector()

    # Create a new datetime object
    date = datetime.datetime.now()

    # Call collect method on DateTimeFactCollector
    testDateTimeFacts = test_DateTimeFactCollector.collect()

    # Check if date_time dictionary has the correct keys
    assert testDateTimeFacts['date_time']['year'] == date.strftime('%Y')
    assert testDateTimeFacts['date_time']['month'] == date.strftime('%m')
    assert testDateTimeFacts['date_time']['weekday'] == date.strftime('%A')

# Generated at 2022-06-20 19:14:57.788520
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """ Test collect method of DateTimeFactCollector"""
    d = DateTimeFactCollector()
    date_time_facts = d.collect()
    assert date_time_facts['date_time']
    assert date_time_facts['date_time']['year']
    assert date_time_facts['date_time']['month']
    assert date_time_facts['date_time']['weekday']
    assert date_time_facts['date_time']['weekday_number']
    assert date_time_facts['date_time']['weeknumber']
    assert date_time_facts['date_time']['day']
    assert date_time_facts['date_time']['hour']
    assert date_time_facts['date_time']['minute']

# Generated at 2022-06-20 19:15:00.625805
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    result = DateTimeFactCollector().collect()
    assert result['date_time']['date'] == datetime.datetime.now().strftime("%Y-%m-%d")

# Generated at 2022-06-20 19:15:13.756792
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtf = DateTimeFactCollector()
    ts = time.time()
    utcnow = datetime.datetime.utcfromtimestamp(ts)
    now = datetime.datetime.fromtimestamp(ts)
    epoch_ts = str(int(now.strftime('%s')))

    assert isinstance(dtf.collect(), dict)
    assert isinstance(dtf.collect()['date_time'], dict)
    assert dtf.collect()['date_time']['day'] == now.strftime('%d')
    assert dtf.collect()['date_time']['date'] == now.strftime('%Y-%m-%d')
    assert dtf.collect()['date_time']['epoch'] == epoch_ts

# Generated at 2022-06-20 19:15:23.325660
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    ctor_args = (None, None)
    ctor_kwargs = {}
    date_time_fact_collector = DateTimeFactCollector(*ctor_args, **ctor_kwargs)
    assert date_time_fact_collector
    assert date_time_fact_collector.name == 'date_time'
    # Test that the class is immutable
    with pytest.raises(AttributeError):
        date_time_fact_collector.name = 'test'

# Generated at 2022-06-20 19:15:26.325416
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == "date_time"
    print('Constructor test passed')


# Generated at 2022-06-20 19:15:36.744452
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Unit test for method collect of class DateTimeFactCollector"""

    # Setup a unit-test stub
    class StubModule(object):
        """Class stub for unit-testing"""
        params = None
        args = None

    # Create a unit-test stub instance
    collect_stub = StubModule()

    # Create a DateTimeFactCollector instance
    date_time_collector_inst = DateTimeFactCollector()

    date_time_facts = date_time_collector_inst.collect(module=collect_stub)['date_time']

    # Validate returned values
    assert date_time_facts['year'] == time.strftime('%Y')
    assert date_time_facts['month'] == time.strftime('%m')
    assert date_time_facts['weekday'] == time.strftime('%A')

# Generated at 2022-06-20 19:15:47.375230
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Create instance of object DateTimeFactCollector
    date_time_fact_collector = DateTimeFactCollector()

    # Test output of method collect of object DateTimeFactCollector
    date_time_facts = date_time_fact_collector.collect()
    assert date_time_facts['date_time']['year'] == datetime.datetime.now().strftime('%Y')
    assert date_time_facts['date_time']['month'] == datetime.datetime.now().strftime('%m')
    assert date_time_facts['date_time']['weekday'] == datetime.datetime.now().strftime('%A')
    assert date_time_facts['date_time']['weekday_number'] == datetime.datetime.now().strftime('%w')
    assert date_

# Generated at 2022-06-20 19:15:58.820325
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Test that the DateTimeFactCollector.collect() method will return a dict that
    has date_time as a key, and the value of date_time is a dict with the facts
    'year', 'month', 'weekday', 'day', 'hour', 'minute', 'second', 'epoch',
    'date', 'time', 'iso8601_micro', 'iso8601', 'tz', 'tz_dst', 'tz_offset'
    """
    date_time_fc = DateTimeFactCollector()
    date_time_fc.collect()
    results_dict = date_time_fc.collect()
    assert 'date_time' in results_dict
    assert len(results_dict) == 1
    assert 'year' in results_dict['date_time']

# Generated at 2022-06-20 19:16:06.916746
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    gf = DateTimeFactCollector()
    data = gf.collect()
    assert 'date_time' in data
    data = data['date_time']

    # Just make sure it is not empty
    # FIXME: Ideally we should check that it is a valid datetime also
    assert data['year']
    assert data['month']
    assert data['weekday']
    assert data['weekday_number']
    assert data['weeknumber']
    assert data['day']
    assert data['hour']
    assert data['minute']
    assert data['second']
    assert data['epoch']
    assert data['epoch_int']
    assert data['date']
    assert data['time']
    assert data['iso8601_micro']
    assert data['iso8601']
    assert data['iso8601_basic']


# Generated at 2022-06-20 19:16:19.608567
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    collector_obj = get_collector_instance('DateTimeFactCollector')
    date_time_facts = collector_obj.collect()
    assert isinstance(date_time_facts, dict)
    assert collector_obj.name in date_time_facts
    assert isinstance(date_time_facts[collector_obj.name], dict)
    for key in ['year', 'month', 'weekday', 'weekday_number', 'weeknumber', 'day',
                'hour', 'minute', 'second', 'epoch', 'epoch_int', 'date', 'time',
                'tz', 'tz_dst', 'tz_offset']:
        assert key in date_time_facts[collector_obj.name]

# Generated at 2022-06-20 19:16:35.673776
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtrfc = DateTimeFactCollector()
    dtrfc.collect()

# Generated at 2022-06-20 19:16:40.116412
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    fact_collector = DateTimeFactCollector()
    assert(fact_collector.name == 'date_time')
    assert(fact_collector._fact_ids == set())


# Generated at 2022-06-20 19:16:48.143950
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    c = DateTimeFactCollector()
    m = c.collect()
    if not "date_time" in m:
        raise Exception()
    if not "epoch" in m["date_time"]:
        raise Exception()
    if not "tz_dst" in m["date_time"]:
        raise Exception()
    if not "tz_offset" in m["date_time"]:
        raise Exception()


if __name__ == '__main__':
    print('Executing test cases...')
    test_DateTimeFactCollector_collect()
    print('All test cases completed successfully.')

# Generated at 2022-06-20 19:16:55.965755
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    import mock, datetime
    from ansible.module_utils.facts.collector import BaseFactCollector


    class TestDateTimeFactCollector(DateTimeFactCollector):
        name = 'date_time'

    test_obj = TestDateTimeFactCollector()
    assert isinstance(test_obj, BaseFactCollector) is True


# Generated at 2022-06-20 19:16:57.292068
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()

# Generated at 2022-06-20 19:17:09.482910
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.utils import FactsCollectorCache
    from ansible.module_utils.facts.collector import TestFileGlob
    from ansible.module_utils.facts.collector.system import TestSystemFactCollector
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.date_time
    import ansible.module_utils.facts.hardware
    import ansible.module_utils.facts.pci
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.service_mgr
    collector_list = [ansible.module_utils.facts.system.SystemFactCollector,
                      ansible.module_utils.facts.date_time.DateTimeFactCollector]
    cache = FactsCollector

# Generated at 2022-06-20 19:17:13.006248
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt_fact_collector = DateTimeFactCollector()
    assert dt_fact_collector is not None


# Generated at 2022-06-20 19:17:15.145688
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()
    assert collector.name == 'date_time'

# Generated at 2022-06-20 19:17:22.122510
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    assert dtfc is not None
    date_time_facts = dtfc.collect()
    assert date_time_facts is not None
    assert len(date_time_facts) == 1

    dtf = date_time_facts['date_time']
    assert dtf is not None
    assert 'year' in dtf
    assert dtf['year'] is not None
    assert len(dtf['year']) == 4
    assert 'month' in dtf
    assert dtf['month'] is not None
    assert len(dtf['month']) == 2
    assert 'weekday' in dtf
    assert dtf['weekday'] is not None
    assert len(dtf['weekday']) > 0
    assert 'weekday_number' in dtf
    assert d

# Generated at 2022-06-20 19:17:32.481195
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Create a DateTimeFactCollector instance
    fact_collector = DateTimeFactCollector()
    # Create a dict with the expected variables, for asertions

# Generated at 2022-06-20 19:18:02.244177
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector.name == 'date_time'

# Generated at 2022-06-20 19:18:05.741486
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = DateTimeFactCollector()
    result = dt.collect()

    assert result['date_time']['tz']

# Generated at 2022-06-20 19:18:10.038858
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_collector = DateTimeFactCollector()
    assert date_time_collector.name == 'date_time'
    assert date_time_collector._fact_ids == set()



# Generated at 2022-06-20 19:18:12.263936
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    fact_collector = DateTimeFactCollector()
    assert fact_collector.name == 'date_time'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:18:16.767541
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    df = DateTimeFactCollector()
    assert df.name == 'date_time'
    assert df._fact_ids == set()


# Generated at 2022-06-20 19:18:27.365125
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # initializing dates
    now = datetime.datetime.now()

    # Dict to collect the data

# Generated at 2022-06-20 19:18:28.786348
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_collector = DateTimeFactCollector()
    assert test_collector.collect()


# Generated at 2022-06-20 19:18:32.694969
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt_fact_collector = DateTimeFactCollector()
    ansible_date_time_facts = dt_fact_collector.collect()
    assert type(ansible_date_time_facts['date_time']) is dict

# Generated at 2022-06-20 19:18:46.322459
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    my_obj = DateTimeFactCollector()
    my_ret = my_obj.collect()
    assert my_ret['date_time']['year'] == datetime.datetime.now().strftime('%Y')
    assert my_ret['date_time']['month'] == datetime.datetime.now().strftime('%m')
    assert my_ret['date_time']['weekday'] == datetime.datetime.now().strftime('%A')
    assert my_ret['date_time']['weekday_number'] == datetime.datetime.now().strftime('%w')
    assert my_ret['date_time']['weeknumber'] == datetime.datetime.now().strftime('%W')
    assert my_ret['date_time']['day'] == datetime.datetime

# Generated at 2022-06-20 19:18:49.889388
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    col = DateTimeFactCollector()
    col.collect()
    keys = ['date_time']
    assert keys == col.collect().keys()

# Generated at 2022-06-20 19:19:58.409874
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector.name == 'date_time'
    assert DateTimeFactCollector._fact_ids == set()
    assert DateTimeFactCollector.collect(None, None)['date_time']
    assert 'weekday' in DateTimeFactCollector.collect(None, None)['date_time'].keys()

# Generated at 2022-06-20 19:20:02.674962
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'
    assert dtfc._fact_ids == set()



# Generated at 2022-06-20 19:20:06.317198
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtf = DateTimeFactCollector()
    facts_dict = dtf.collect(None, None)
    assert facts_dict is not None

# Generated at 2022-06-20 19:20:14.163087
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Unit test for method collect of class DateTimeFactCollector."""
    dtf = DateTimeFactCollector()
    sdt = "2016-04-17 01:27:41"


# Generated at 2022-06-20 19:20:25.193393
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_obj = DateTimeFactCollector()
    date_time_dic = date_time_obj.collect()

    assert isinstance(date_time_dic, dict)
    assert 'date_time' in date_time_dic
    assert len(date_time_dic) is 1
    assert isinstance(date_time_dic['date_time'], dict)

    date_time_dic = date_time_dic.get('date_time')
    assert len(date_time_dic) == 23
    assert 'year' in date_time_dic
    assert 'month' in date_time_dic
    assert 'weekday' in date_time_dic
    assert 'weekday_number' in date_time_dic
    assert 'weeknumber' in date_time_d

# Generated at 2022-06-20 19:20:30.097107
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt_fact_collector = DateTimeFactCollector()
    assert dt_fact_collector.name == 'date_time'
    assert len(dt_fact_collector._fact_ids) == 0


# Generated at 2022-06-20 19:20:40.745323
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    ansible_facts = fact_collector.collect()
    # tests below are to ensure the fact_collector is returning the expected data
    assert ansible_facts['date_time']['tz']
    assert ansible_facts['date_time']['date']
    assert ansible_facts['date_time']['time']
    assert ansible_facts['date_time']['weekday']
    assert ansible_facts['date_time']['iso8601']


# Generated at 2022-06-20 19:20:54.167195
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.collectors.date_time import DateTimeFactCollector
    from ansible.module_utils._text import to_bytes
    import time
    ts = time.time()
    ctime = time.ctime()
    DateTimeFactCollector.collect(Facts({}))
    epoch = time.strftime('%s')
    epoch_int = str(int(epoch))
    year = time.strftime('%Y')
    month = time.strftime('%m')
    weekday = time.strftime('%A')
    weekday_number = time.strftime('%w')
    weeknumber = time.strftime('%W')
    day = time.strftime('%d')

# Generated at 2022-06-20 19:20:58.016172
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'
    assert x._fact_ids == set()



# Generated at 2022-06-20 19:21:00.402560
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    c = DateTimeFactCollector()
    assert c.name == 'date_time'