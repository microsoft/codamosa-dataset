

# Generated at 2022-06-20 19:11:44.850666
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert len(DateTimeFactCollector()._fact_ids) != 0

# Generated at 2022-06-20 19:11:46.518966
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = DateTimeFactCollector()
    assert dt.collect().keys() == {u'date_time'}

# Generated at 2022-06-20 19:11:49.202311
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Create instance of DateTimeFactCollector
    dt = DateTimeFactCollector()
    # Check if method collect returns type dict
    assert isinstance(dt.collect(), dict)

# Generated at 2022-06-20 19:11:50.423344
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = DateTimeFactCollector()
    assert isinstance(dt.collect(), dict)

# Generated at 2022-06-20 19:11:57.915950
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.collect()["date_time"]["year"] == datetime.datetime.now().strftime("%Y")
    assert date_time_fact_collector.collect()["date_time"]["month"] == datetime.datetime.now().strftime("%m")
    assert date_time_fact_collector.collect()["date_time"]["weekday"] == datetime.datetime.now().strftime("%A")
    assert date_time_fact_collector.collect()["date_time"]["weekday_number"] == datetime.datetime.now().strftime("%w")
    assert date_time_fact_collector.collect()["date_time"]["weeknumber"] == datetime

# Generated at 2022-06-20 19:12:00.128317
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
     date_time_collector = DateTimeFactCollector()


# Generated at 2022-06-20 19:12:02.522588
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'
    assert DateTimeFactCollector._fact_ids == set()

# Generated at 2022-06-20 19:12:05.309849
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    facts = DateTimeFactCollector()
    assert facts.name == 'date_time'

# Generated at 2022-06-20 19:12:08.249038
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    fact_collector = DateTimeFactCollector()
    assert fact_collector.name == 'date_time'

# Generated at 2022-06-20 19:12:10.255252
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    c = DateTimeFactCollector()
    print(c.collect())

# Generated at 2022-06-20 19:12:16.600710
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    f = DateTimeFactCollector()
    assert f.name == 'date_time'

# Generated at 2022-06-20 19:12:23.864350
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    class LazyFacts:
        def __init__(self):
            self.data = {}
    lazy_facts = LazyFacts()
    collector = DateTimeFactCollector(module=None, collected_facts=lazy_facts)
    collected_facts = collector.collect()
    assert 'date_time' in collected_facts
    assert isinstance(collected_facts['date_time'], dict)
    assert len(collected_facts['date_time']) > 0

# Generated at 2022-06-20 19:12:31.716972
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # Setup a test DateTimeFactCollector
    test_datetime_fc = DateTimeFactCollector()

    # Test method collect
    test_datetime_facts = test_datetime_fc.collect()

    assert(isinstance(test_datetime_facts, dict))
    assert('date_time' in test_datetime_facts)

# Generated at 2022-06-20 19:12:36.808172
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector.collect()
    date_time_facts = date_time_fact_collector.get_facts()['date_time']
    assert type(date_time_facts) == dict
    assert type(date_time_facts['epoch']) == str
    assert type(date_time_facts['epoch_int']) == str
    assert type(date_time_facts['date']) == str
    assert type(date_time_facts['time']) == str

# Generated at 2022-06-20 19:12:45.282444
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():

    dtf = DateTimeFactCollector()
    assert 'date_time' in dtf._fact_ids
    assert dtf._fact_ids == {'date_time'}
    assert dtf.name == 'date_time'

    # Test instance's copy of instance variables
    dtf1 = DateTimeFactCollector()
    dtf._fact_ids.add('test')
    assert 'test' not in dtf1._fact_ids
    assert dtf1.name == 'date_time'

# Generated at 2022-06-20 19:12:51.996979
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    result = dtfc.collect()
    assert 'date_time' in result
    assert 'date' in result['date_time']
    assert 'time' in result['date_time']
    assert 'iso8601' in result['date_time']

# Generated at 2022-06-20 19:12:54.878410
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    fact_collector = DateTimeFactCollector()
    assert fact_collector.name == 'date_time'
    assert fact_collector._fact_ids == frozenset()

# Generated at 2022-06-20 19:12:59.053810
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'
    assert not date_time_fact_collector._fact_ids
    assert date_time_fact_collector._fetch_cache == set()

# Generated at 2022-06-20 19:13:04.515805
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Test DateTimeFactCollector.collect"""
    # Arrange
    dt_facts_collector = DateTimeFactCollector()

    # Act
    result = dt_facts_collector.collect()

    # Assert
    assert result is not None
    assert type(result) is dict
    assert 'date_time' in result
    assert type(result['date_time']) is dict
    assert len(result['date_time']) > 0
    for key, value in result['date_time'].iteritems():
        assert type(key) is str
        assert type(value) is str

# Generated at 2022-06-20 19:13:18.705445
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_collector = DateTimeFactCollector()
    date_time_facts = date_time_collector.collect()

    assert "date_time" in date_time_facts
    date_time_dict = date_time_facts["date_time"]
    assert "year" in date_time_dict
    assert "month" in date_time_dict
    assert "day" in date_time_dict
    assert "date" in date_time_dict
    assert "hour" in date_time_dict
    assert "minute" in date_time_dict
    assert "second" in date_time_dict
    assert "time" in date_time_dict
    assert "epoch" in date_time_dict
    assert "iso8601_micro" in date_time_dict
    assert "iso8601" in date_

# Generated at 2022-06-20 19:13:28.094712
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()
    assert collector.name == 'date_time'

# Generated at 2022-06-20 19:13:29.563661
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    DateTimeFactCollector()

# Generated at 2022-06-20 19:13:33.178172
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_collector = DateTimeFactCollector()
    assert date_time_collector.name == 'date_time'

# Generated at 2022-06-20 19:13:34.726464
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    DateTimeFactCollector().collect()

# Generated at 2022-06-20 19:13:36.881641
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
   x=DateTimeFactCollector()
   assert x.name == 'date_time'
   assert x._fact_ids == set()


# Generated at 2022-06-20 19:13:41.324927
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'
    assert len(dtfc._fact_ids) is 0


# Generated at 2022-06-20 19:13:42.938607
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()

# Generated at 2022-06-20 19:13:45.004348
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert isinstance(DateTimeFactCollector(), DateTimeFactCollector)

# Generated at 2022-06-20 19:13:52.069511
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    data_time_instance = DateTimeFactCollector()
    date_time_facts = data_time_instance.collect()
    # Check if values are not empty and matches the expected result
    assert date_time_facts['date_time']['weekday']
    assert type(date_time_facts['date_time']['weekday']) == str
    assert date_time_facts['date_time']['date']
    assert type(date_time_facts['date_time']['date']) == str
    assert date_time_facts['date_time']['day']
    assert type(date_time_facts['date_time']['day']) == str
    assert date_time_facts['date_time']['month']
    assert type(date_time_facts['date_time']['month'])

# Generated at 2022-06-20 19:13:56.030135
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt_fc = DateTimeFactCollector()
    assert dt_fc.name == 'date_time'
    assert dt_fc._fact_ids == set()

# Generated at 2022-06-20 19:14:09.104338
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # DateTimeFactCollector initialization
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'
    assert set() == dtfc._fact_ids



# Generated at 2022-06-20 19:14:11.231567
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    """Test the constructor of the DateTimeFactCollector.

    :return: No return value
    :rtype: None
    """
    assert DateTimeFactCollector().name == 'date_time'

# Generated at 2022-06-20 19:14:13.177754
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Check whether __init__ method works well
    date_time_fact_collector_instance = DateTimeFactCollector()
    assert isinstance(date_time_fact_collector_instance, DateTimeFactCollector)


# Generated at 2022-06-20 19:14:14.597962
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    DateTimeFactCollector.collect()

# Generated at 2022-06-20 19:14:23.874075
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    now = datetime.datetime.now()
    epoch_ts = time.time()
    utcnow = datetime.datetime.utcfromtimestamp(epoch_ts)
    facts = dtfc.collect()
    epoch_int = str(int(time.strftime('%s')))
    if epoch_int == '' or epoch_int[0] == '%':
        epoch_int = str(int(time.time()))
    assert facts['date_time']['year'] == now.strftime('%Y')
    assert facts['date_time']['month'] == now.strftime('%m')
    assert facts['date_time']['weekday'] == now.strftime('%A')

# Generated at 2022-06-20 19:14:26.251972
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert( obj.name == 'date_time' )


# Generated at 2022-06-20 19:14:28.146723
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    dtfc.collect()

# Generated at 2022-06-20 19:14:36.409108
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-20 19:14:39.220940
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_obj = DateTimeFactCollector()
    assert date_time_obj is not None

# Generated at 2022-06-20 19:14:49.632081
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    ns = DateTimeFactCollector().collect(module=None, collected_facts=None)

# Generated at 2022-06-20 19:15:05.363611
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt_collector = DateTimeFactCollector()
    dt_collector.collect()

# Generated at 2022-06-20 19:15:07.009570
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
   collector = DateTimeFactCollector()
   assert collector.name == 'date_time'
   assert collector._fact_ids == set()

# Generated at 2022-06-20 19:15:08.093132
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert isinstance(DateTimeFactCollector(), DateTimeFactCollector)

# Generated at 2022-06-20 19:15:11.149344
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'
    assert isinstance(dtfc._fact_ids, set)

# Generated at 2022-06-20 19:15:11.988452
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()



# Generated at 2022-06-20 19:15:15.045168
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()
    assert isinstance(collector, DateTimeFactCollector)

# Generated at 2022-06-20 19:15:18.566483
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'
    assert x._fact_ids == set()

# Generated at 2022-06-20 19:15:20.904658
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector.name == 'date_time'

# Generated at 2022-06-20 19:15:23.546540
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    class_to_test = DateTimeFactCollector()
    assert 'date_time' in class_to_test.collect()

# Generated at 2022-06-20 19:15:25.394013
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    dtfc.collect()

# Generated at 2022-06-20 19:15:46.656917
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    expected_date_time_facts = {
        'day': '01',
        'date': '2019-09-01',
        'hour': '01',
        'tz_offset': '+0900',
        'epoch_int': '1567351223',
        'weekday_number': '0',
        'weekday': 'Sunday',
        'tz': 'JST',
        'minute': '02',
        'epoch': '1567351223',
        'second': '03',
        'weeknumber': '35',
        'tz_dst': 'JST',
        'time': '01:02:03',
        'month': '09',
        'year': '2019'
    }
    date_time_fact_collector = DateTimeFactCollector()
    facts_dict = date

# Generated at 2022-06-20 19:15:57.744519
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import sys
    import pytest
    from . import DateTimeFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Set up the test object
    date_time_collector = DateTimeFactCollector()
    date_time_collector.collect = BaseFactCollector.collect
    date_time_collector.name = 'date_time'

    # Get the expected and actual results

# Generated at 2022-06-20 19:15:59.690217
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    c = DateTimeFactCollector()
    assert c.name == 'date_time'

# Generated at 2022-06-20 19:16:06.807275
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    Module = type('', (object,), {'params': {'module': 'testmodule', 'collected_facts': 'testfacts'}})
    DateTime = type('', (object,), {})
    test_DateTime = DateTime()
    test_DateTime.strftime = lambda x: x
    datetime = type('', (object,), {'utcnow': test_DateTime, 'fromtimestamp': test_DateTime, 'datetime': test_DateTime})
    time = type('', (object,), {'time': test_DateTime, 'strftime': lambda x: x, 'localtime': test_DateTime, 'tzname': ['tzname_fake', 'tzname_fake']})
    date_time_fact_collector = DateTimeFactCollector()

# Generated at 2022-06-20 19:16:12.785477
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()

    # This test will fail if we run around midnight
    assert dtfc.collect()['date_time']['date'] == time.strftime('%Y-%m-%d')

# Generated at 2022-06-20 19:16:14.108977
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()
    assert collector

# Generated at 2022-06-20 19:16:16.249241
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()

# Generated at 2022-06-20 19:16:19.983056
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'
    assert dtfc._fact_ids == set()


# Generated at 2022-06-20 19:16:23.055324
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'
    assert isinstance(x._fact_ids, set)

# Generated at 2022-06-20 19:16:25.466631
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Check instance creation
    DateTimeFactCollector()



# Generated at 2022-06-20 19:17:04.822761
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    datetime_collector = DateTimeFactCollector()
    collected_facts = datetime_collector.collect()
    assert 'date_time' in collected_facts
    assert len(collected_facts['date_time']) > 0
    for fact in collected_facts['date_time']:
        assert fact in [
                'year', 'month', 'weekday', 'weekday_number', 'weeknumber',
                'day', 'hour', 'minute', 'second', 'epoch', 'epoch_int',
                'date', 'time', 'iso8601_micro', 'iso8601', 'iso8601_basic',
                'iso8601_basic_short', 'tz', 'tz_dst', 'tz_offset'
            ]


# Generated at 2022-06-20 19:17:10.102898
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfact = DateTimeFactCollector()

    facts_dict = dtfact.collect()
    assert isinstance(facts_dict, dict)
    assert isinstance(facts_dict['date_time'], dict)
    assert facts_dict['date_time']['day'] == datetime.datetime.now().strftime('%d')

# Generated at 2022-06-20 19:17:15.504849
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt_fact_collector = DateTimeFactCollector()
    assert dt_fact_collector.name == 'date_time'
    assert dt_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:17:17.049306
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj.name == 'date_time'

# Generated at 2022-06-20 19:17:22.320997
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    datetime_collector = DateTimeFactCollector()
    assert datetime_collector.name == 'date_time'
    assert datetime_collector._fact_ids == set()

# Generated at 2022-06-20 19:17:25.675600
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    m_DateTimeFactCollector = DateTimeFactCollector()
    assert m_DateTimeFactCollector is not None


# Generated at 2022-06-20 19:17:34.998708
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    with open('tests/unit/ansible_collections/ansible/community/plugins/module_utils/facts/date_time.py', 'rU') as f:
        before = f.readlines()
    my_module_utils = DateTimeFactCollector()
    result = my_module_utils.collect()

# Generated at 2022-06-20 19:17:37.738565
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'
    assert x._fact_ids == set()

# Generated at 2022-06-20 19:17:40.538781
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Tests for constructor of class DateTimeFactCollector
    date_time_facts = DateTimeFactCollector()
    assert date_time_facts.name == "date_time"
    assert date_time_facts._fact_ids == set()


# Generated at 2022-06-20 19:17:53.898729
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector.collect()

# Generated at 2022-06-20 19:18:54.109664
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt
    assert dt.name == 'date_time'
    assert len(dt._fact_ids) == 0


# Generated at 2022-06-20 19:19:01.055345
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector.collect()
    assert date_time_facts['date_time']['epoch_int'] == str(int(time.time()))

# Generated at 2022-06-20 19:19:10.369567
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import datetime
    datetime.datetime.fromtimestamp = lambda t: datetime.datetime(2020, 4, 20, 4, 5, 6)
    utcnow = datetime.datetime(2020, 4, 20, 4, 5, 6)
    datetime.datetime.utcfromtimestamp = lambda t: utcnow
    time.strftime = lambda f, t: '2020-04-20 04:05:06'
    time.strftime.__name__ = 'strftime'
    time.tzname = ['', '']
    time.tzname.__name__ = 'tzname'
    result = DateTimeFactCollector.collect()

# Generated at 2022-06-20 19:19:14.621513
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_collector = DateTimeFactCollector()
    assert date_time_collector.name == 'date_time'
    assert date_time_collector._fact_ids == set()

# Generated at 2022-06-20 19:19:16.068338
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    factcollector = DateTimeFactCollector()
    assert factcollector.name == 'date_time'
    assert factcollector._fact_ids == set()

# Generated at 2022-06-20 19:19:29.411839
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    tz = time.tzname[0]

    # we use a fixed timestamp in the tests, to avoid issues when
    # the test takes too long and the result of the timestamp
    # gets updated
    # The fixed timestamp is based on 2018-10-04 18:40:00 +0200
    fixed_timestamp = 1536481600000
    # The timestamp is milliseconds since epoch and is on +0200 timezone
    # We calculate epoch and datetime object as they are used by fact
    epoch = float(fixed_timestamp) / 1000
    now = datetime.datetime.fromtimestamp(epoch)
    utcnow = datetime.datetime.utcfromtimestamp(epoch)

    date_time_facts_expected = {}
    date_time_facts_expected['year'] = now.strftime('%Y')
    date_time_

# Generated at 2022-06-20 19:19:30.421760
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dc = DateTimeFactCollector()
    assert dc.collect()['date_time']

# Generated at 2022-06-20 19:19:35.571115
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Create an instance of DateTimeFactCollector
    df = DateTimeFactCollector()
    # Call method collect
    result = df.collect()
    assert result['date_time']['date'] == datetime.datetime.today().strftime('%Y-%m-%d')

# Generated at 2022-06-20 19:19:41.621027
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    tester = DateTimeFactCollector()
    assert tester.name == 'date_time'
    assert 'year' in tester._fact_ids
    assert 'month' in tester._fact_ids
    assert 'weekday' in tester._fact_ids
    assert 'weekday_number' in tester._fact_ids
    assert 'weeknumber' in tester._fact_ids
    assert 'day' in tester._fact_ids
    assert 'hour' in tester._fact_ids
    assert 'minute' in tester._fact_ids
    assert 'second' in tester._fact_ids
    assert 'epoch' in tester._fact_ids


# Generated at 2022-06-20 19:19:43.746350
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj_DateTimeFactCollector = DateTimeFactCollector()
    assert obj_DateTimeFactCollector.name == 'date_time'
    assert obj_DateTimeFactCollector._fact_ids == set()