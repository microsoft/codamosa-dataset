

# Generated at 2022-06-20 19:11:45.765334
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    d = DateTimeFactCollector()
    assert d.name == 'date_time'


# Generated at 2022-06-20 19:11:53.554572
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    dt = DateTimeFactCollector(BaseFactCollector())


# Generated at 2022-06-20 19:11:55.186159
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    print('Testing %s' % __file__)
    fact_collector = DateTimeFactCollector()
    results = fact_collector.collect()

    assert 'date_time' in results
    assert 'year' in results['date_time']
    assert 'epoch' in results['date_time']

# Generated at 2022-06-20 19:11:56.313381
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # create the instance of class DateTimeFactCollector
    cls = DateTimeFactCollector()

    # Test if the instance has been created correctly
    assert cls.name == 'date_time'

# Generated at 2022-06-20 19:11:59.336937
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector
    assert date_time_fact_collector.name == 'date_time'

# Generated at 2022-06-20 19:12:07.318103
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """ Unit test of AnsibleModuleUtils.facts.collector.DateTimeFactCollector.collect """

    # Create a fact collector
    fact_collector = DateTimeFactCollector()

    # Collect facts
    collected_facts = fact_collector.collect()

    # Test all collected facts are available
    for key in ('year', 'month', 'weekday', 'weekday_number', 'weeknumber', 'day', 'hour', 'minute', 'second', 'epoch', 'epoch_int', 'date', 'time', 'iso8601_micro', 'iso8601', 'iso8601_basic', 'iso8601_basic_short', 'tz', 'tz_dst', 'tz_offset'):
        assert key in collected_facts['date_time']

    # Test epoch_int = epoch

# Generated at 2022-06-20 19:12:17.851119
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # Arrange
    # Time zone is automatically set by the system,
    # and hence cannot be controlled for testing.
    # Set the time zone to UTC to reduce test fragility.
    # TODO(jhc): fix this test.
    import os
    os.environ['TZ'] = 'UTC'

    # Act
    date_time_fact_collector = DateTimeFactCollector()
    collected_facts = date_time_fact_collector.collect()

    # Assert
    assert collected_facts['date_time']['year'] == '2017'
    assert collected_facts['date_time']['month'] == '11'
    assert collected_facts['date_time']['weekday'] == 'Friday'
    assert collected_facts['date_time']['weekday_number'] == '5'
   

# Generated at 2022-06-20 19:12:20.974640
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt.name == 'date_time'
    assert dt._fact_ids == set()

# Generated at 2022-06-20 19:12:23.307672
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()
    assert collector.name == 'date_time'
    assert collector._fact_ids == set()


# Generated at 2022-06-20 19:12:34.344475
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # create new DateTimeFactCollector object
    dtf = DateTimeFactCollector()
    # call collect
    res = dtf.collect()
    assert all(key in res['date_time'] for key in ['year', 'month', 'weekday', 'weekday_number', 'weeknumber', 'day', 'hour', 'minute', 'second', 'epoch', 'epoch_int', 'date', 'time', 'iso8601_micro', 'iso8601', 'iso8601_basic', 'iso8601_basic_short', 'tz', 'tz_dst', 'tz_offset'])

# Generated at 2022-06-20 19:12:41.285542
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # The method under test is implemented in this file as a class method of
    # DateTimeFactCollector, which implements CollectorsPluginBase and therefore
    # is not a callable object.  Testing for this method is therefore not
    # available at this time.
    pass

# Generated at 2022-06-20 19:12:42.082319
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    pass

# Generated at 2022-06-20 19:12:45.518167
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'
    assert type(date_time_fact_collector._fact_ids) == set

# Generated at 2022-06-20 19:12:54.551057
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    # check that the class is initialized properly
    assert date_time_fact_collector
    assert date_time_fact_collector.name == 'date_time'
    assert date_time_fact_collector._fact_ids == set()



# Generated at 2022-06-20 19:12:58.763025
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collector = DateTimeFactCollector()
    facts_dict = collector.collect()
    print(facts_dict)
    assert facts_dict.get('date_time') is not None
    assert facts_dict['date_time'].get('iso8601') is not None

# Generated at 2022-06-20 19:13:00.039673
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    DateTimeFactCollector().collect()

# Generated at 2022-06-20 19:13:04.485189
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    test_DateTimeFactCollector = DateTimeFactCollector()
    assert test_DateTimeFactCollector.name == 'date_time'
    assert test_DateTimeFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:13:08.615507
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector.name == 'date_time'
    assert DateTimeFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:13:13.398190
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt is not None
    assert dt.name == 'date_time'
    assert dt._fact_ids == set()


# Generated at 2022-06-20 19:13:16.657110
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    facts = dtfc.collect()
    assert isinstance(facts, dict)
    assert 'date_time' in facts, "Missing date_time dictionary in facts"
    assert isinstance(facts['date_time'], dict)

# Generated at 2022-06-20 19:13:28.120934
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-20 19:13:40.230394
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    d = DateTimeFactCollector()

    assert d.name == 'date_time'
    result = d.collect()
    assert 'epoch' in result['date_time']
    assert 'epoch_int' in result['date_time']
    assert 'date' in result['date_time']
    assert 'time' in result['date_time']
    assert 'iso8601' in result['date_time']
    assert 'iso8601_micro' in result['date_time']
    assert 'iso8601_basic' in result['date_time']
    assert 'iso8601_basic_short' in result['date_time']
    assert 'tz' in result['date_time']
    assert 'tz_dst' in result['date_time']
    assert 'tz_offset' in result['date_time']
   

# Generated at 2022-06-20 19:13:46.480751
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    """Test DateTime Fact Collector"""
    assert isinstance(DateTimeFactCollector(), DateTimeFactCollector)

    assert DateTimeFactCollector().name == 'date_time', 'DateTime Fact Collector did not have the correct value for name var'

    assert isinstance(DateTimeFactCollector().collect(), dict)

# Generated at 2022-06-20 19:14:00.986683
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    """Unit test for DateTimeFactCollector as defined in date_time.py.

    This unit test is not meant to be used as actual unit tests, but rather is
    to be used to help with development, as a safety precaution, and
    a sanity check. Unit testing of Ansible modules is still in its infancy
    and this is a step in that process.

    Output:
        None: No output
    """

    import json
    from ansible.module_utils.facts import ansible_collector
    myFacts = ansible_collector.get_all_facts(None, None)
    print(json.dumps(myFacts, sort_keys=True, indent=4))
    print(myFacts['date_time']['year'])
    print(myFacts['date_time']['month'])

# Generated at 2022-06-20 19:14:08.779124
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # arrange
    ansible_module = MockModule()
    collector = DateTimeFactCollector(ansible_module)

    # act
    facts = collector.collect()

    # assert
    assert 'date_time' in facts
    assert 'year' in facts['date_time']
    assert 'month' in facts['date_time']
    assert 'weekday' in facts['date_time']
    assert 'weekday_number' in facts['date_time']
    assert 'weeknumber' in facts['date_time']
    assert 'day' in facts['date_time']
    assert 'hour' in facts['date_time']
    assert 'minute' in facts['date_time']
    assert 'second' in facts['date_time']
    assert 'epoch' in facts['date_time']
    assert 'epoch_int'

# Generated at 2022-06-20 19:14:22.077994
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtc = DateTimeFactCollector()
    facts_dict = dtc.collect()
    assert facts_dict['date_time']['year'] == datetime.datetime.now().strftime('%Y')
    assert facts_dict['date_time']['month'] == datetime.datetime.now().strftime('%m')
    assert facts_dict['date_time']['weekday'] == datetime.datetime.now().strftime('%A')
    assert facts_dict['date_time']['weekday_number'] == datetime.datetime.now().strftime('%w')
    assert facts_dict['date_time']['weeknumber'] == datetime.datetime.now().strftime('%W')
    assert facts_dict['date_time']['day'] == datetime.datetime.now

# Generated at 2022-06-20 19:14:32.139262
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    facts_dict = {}
    date_time_facts = {}

    date_time_facts['epoch'] = str(int(time.time()))
    date_time_facts['epoch_int'] = str(int(time.time()))
    date_time_facts['iso8601_micro'] = datetime.datetime.utcfromtimestamp(time.time()).strftime("%Y-%m-%dT%H:%M:%S.%fZ")
    date_time_facts['iso8601'] = datetime.datetime.utcfromtimestamp(time.time()).strftime("%Y-%m-%dT%H:%M:%SZ")
    date_time_facts['iso8601_basic'] = datetime.datetime.fromtimestamp(time.time()).str

# Generated at 2022-06-20 19:14:45.498262
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    new_instance = DateTimeFactCollector()
    result = new_instance.collect()
    assert result['date_time']['date'] is not None
    expected_keys = set(['year', 'month', 'weekday', 'weekday_number', 'weeknumber', 'day', 'hour', 'minute', 'second',
                         'epoch', 'epoch_int', 'date', 'time', 'iso8601_micro', 'iso8601', 'iso8601_basic', 'iso8601_basic_short',
                         'tz', 'tz_dst', 'tz_offset'])
    assert set(result['date_time'].keys()) == expected_keys
    assert set(result.keys()) == set(['date_time'])
    assert isinstance(result['date_time']['year'], str)

# Generated at 2022-06-20 19:14:46.786927
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # No constructor test - default behavior behaves as expected.
    return True

# Generated at 2022-06-20 19:14:57.565431
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Unit test for method collect of class DateTimeFactCollector
    :return:
    """
    date_time_facts = {}
    date_time = datetime.datetime.now()
    date_time_facts['year'] = date_time.strftime('%Y')
    date_time_facts['month'] = date_time.strftime('%m')
    date_time_facts['weekday'] = date_time.strftime('%A')
    date_time_facts['weekday_number'] = date_time.strftime('%w')
    date_time_facts['weeknumber'] = date_time.strftime('%W')
    date_time_facts['day'] = date_time.strftime('%d')
    date_time_facts['hour'] = date_time.strftime('%H')

# Generated at 2022-06-20 19:15:13.838736
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
	dt = DateTimeFactCollector()
	assert(dt)
	assert(dt.collect())
	assert(type(dt.collect()) is dict)
	assert(dt.collect()['date_time'])
	assert(type(dt.collect()['date_time']) is dict)
	assert('year' in dt.collect()['date_time'])
	assert('month' in dt.collect()['date_time'])
	assert('weekday' in dt.collect()['date_time'])
	assert('weekday_number' in dt.collect()['date_time'])
	assert('weeknumber' in dt.collect()['date_time'])
	assert('day' in dt.collect()['date_time'])

# Generated at 2022-06-20 19:15:19.227786
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts import Collector

    c = Collector()
    f = DateTimeFactCollector(c)

    for key in f.collect().keys():
        assert key == 'date_time'

    return True

# Generated at 2022-06-20 19:15:30.446197
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    result = date_time_fact_collector.collect()
    assert result['date_time']['year'] == "2020"
    assert result['date_time']['month'] == "09"
    assert result['date_time']['weekday'] == "Tuesday"
    assert result['date_time']['weekday_number'] == "2"
    assert result['date_time']['weeknumber'] == "36"
    assert result['date_time']['day'] == "29"
    assert result['date_time']['hour'] == "13"
    assert result['date_time']['minute'] == "45"
    assert result['date_time']['second'] == "35"

# Generated at 2022-06-20 19:15:39.484892
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-20 19:15:41.547549
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector().name == 'date_time'


# Generated at 2022-06-20 19:15:43.777786
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    ansible_date_time_obj = DateTimeFactCollector()
    assert ansible_date_time_obj.name == 'date_time'

# Generated at 2022-06-20 19:15:49.426298
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt_col = DateTimeFactCollector()
    assert isinstance(dt_col, DateTimeFactCollector)
    assert dt_col.name == 'date_time'
    assert not dt_col._fact_ids


# Generated at 2022-06-20 19:15:50.820360
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    c = DateTimeFactCollector({})
    assert c.name == 'date_time'

# Generated at 2022-06-20 19:15:53.790113
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt
    assert dt.name == 'date_time'
    assert dt._fact_ids == set()

# Generated at 2022-06-20 19:16:04.936322
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import time
    import datetime
    fact_collector = DateTimeFactCollector()
    facts_dict = fact_collector.collect()
    now = datetime.datetime.now()
    assert facts_dict['date_time']['year'] == now.strftime('%Y')
    assert facts_dict['date_time']['month'] == now.strftime('%m')
    assert facts_dict['date_time']['weekday'] == now.strftime('%A')
    assert facts_dict['date_time']['weekday_number'] == now.strftime('%w')
    assert facts_dict['date_time']['weeknumber'] == now.strftime('%W')
    assert facts_dict['date_time']['day'] == now.strftime('%d')
    assert facts

# Generated at 2022-06-20 19:16:23.179295
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    datetime_collector = DateTimeFactCollector()
    collected_date_time_facts = datetime_collector.collect()
    assert type(collected_date_time_facts) is dict, 'collected_date_time_facts is not a dictionary'
    assert 'date_time' in collected_date_time_facts, 'date_time is not in collected_date_time_facts'
    date_time = collected_date_time_facts['date_time']
    assert type(date_time) is dict, 'date_time is not a dictionary'
    assert date_time['year'] is not None, 'year is not set'
    assert date_time['month'] is not None, 'month is not set'
    assert date_time['weekday_number'] is not None, 'weekday_number is not set'

# Generated at 2022-06-20 19:16:29.148987
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    data_time_collector = DateTimeFactCollector()
    data_time_facts = data_time_collector.collect()
    assert data_time_facts is not None
    assert 'date_time' in data_time_facts
    assert data_time_facts['date_time'] is not None
    assert 'year' in data_time_facts['date_time']

# Generated at 2022-06-20 19:16:33.949793
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'
    assert date_time_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:16:38.977969
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Initialize class object
    dfc = DateTimeFactCollector()
    # Call method collect
    facts_dict = dfc.collect()
    # Assert length of dictionary is 1
    assert len(facts_dict) == 1
    # Assert length of sub-dictionary is 21
    assert len(facts_dict['date_time']) == 21
    # Assert length of tz_offset is 5
    assert len(facts_dict['date_time']['tz_offset']) == 5

# Generated at 2022-06-20 19:16:42.286157
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()
    assert collector.name == 'date_time'
    assert collector._fact_ids == set()


# Generated at 2022-06-20 19:16:45.625138
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == "date_time"
    assert dtfc._fact_ids == set()


# Generated at 2022-06-20 19:16:51.853888
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_facts_dict = date_time_fact_collector.collect()
    assert date_time_facts_dict['date_time']['year']



# Generated at 2022-06-20 19:17:00.525448
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Test DateTimeFactCollector.collect()

    DateTimeFactCollector.collect() method is a no-op.

    """
    dtfc = DateTimeFactCollector()
    result = dtfc.collect()

    # date_time facts should contain the key date_time
    assert 'date_time' in result

    # date_time facts should be a dictionary
    assert isinstance(result['date_time'], dict)

    # date_time facts should contain the key year
    assert 'year' in result['date_time']

    # The value of year should be a string
    assert isinstance(result['date_time']['year'], str)
    assert len(result['date_time']['year']) == 4

    # date_time facts should contain the key month

# Generated at 2022-06-20 19:17:10.522509
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    actual_results = DateTimeFactCollector().collect()
    # results will be a dict containing a single item whose value is a dict
    assert type(actual_results) == dict and len(actual_results) == 1
    assert 'date_time' in actual_results
    datetime_results = actual_results['date_time']
    # ensure all expected keys are present in the dict
    # some could be missing in rare cases such as when the time zone is set to an invalid value
    # strftime syntax and behavior vary from platform to platform, so we can't check the values
    assert 'year' in datetime_results
    assert 'month' in datetime_results
    assert 'weekday' in datetime_results
    assert 'weekday_number' in datetime_results
    assert 'weeknumber' in datetime_results

# Generated at 2022-06-20 19:17:12.340554
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    DateTimeFactCollector().collect()



# Generated at 2022-06-20 19:17:33.987772
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_collector = DateTimeFactCollector()
    assert date_time_collector.name == 'date_time'
    assert date_time_collector._fact_ids == set()

# Generated at 2022-06-20 19:17:42.872387
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    dtfc._module = None
    dtfc._collected_facts = {}
    dtfc.collect()
    result = dtfc._collected_facts
    assert isinstance(result, dict)
    assert 'date_time' in result
    assert result['date_time']
    localtime = time.localtime()
    assert 'year' in result['date_time']
    assert result['date_time']['year'] == time.strftime("%Y", localtime)
    assert 'month' in result['date_time']
    assert result['date_time']['month'] == time.strftime("%m", localtime)
    assert 'weekday' in result['date_time']
    assert result['date_time']['weekday'] == time.str

# Generated at 2022-06-20 19:17:46.328230
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():

    date_time_fact_collector = DateTimeFactCollector()

    assert date_time_fact_collector.name == 'date_time', "date_time_fact_collector name should be date_time"

# Generated at 2022-06-20 19:17:50.794259
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # create DateTimeFactCollector
    f = DateTimeFactCollector()
    # check its name
    assert f.name == "date_time"
    # check its empty fact_ids
    assert f._fact_ids == set()


# Generated at 2022-06-20 19:17:54.487359
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt.name == 'date_time'

# Generated at 2022-06-20 19:18:05.271218
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    result = dict()

# Generated at 2022-06-20 19:18:06.127350
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    pass

# Generated at 2022-06-20 19:18:06.932940
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    DateTimeFactCollector.collect()

# Generated at 2022-06-20 19:18:10.477206
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'
    assert dtfc._fact_ids == set()
    

# Generated at 2022-06-20 19:18:14.766737
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fc = DateTimeFactCollector()

    assert date_time_fc.name == 'date_time'


# Generated at 2022-06-20 19:18:48.350658
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Create instance of class DateTimeFactCollector
    dtObj = DateTimeFactCollector()
    # Check method collect of class DateTimeFactCollector returns a dictionary
    assert isinstance(dtObj.collect(), dict)

# Generated at 2022-06-20 19:18:51.442420
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Unit test for method collect of class DateTimeFactCollector"""
    date_time = DateTimeFactCollector()
    assert 'date_time' in date_time.collect()

# Generated at 2022-06-20 19:18:59.649864
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact = DateTimeFactCollector()
    datetime_data = fact.collect()['date_time']
    now = datetime.datetime.utcnow()
    assert datetime_data['iso8601_micro'] == now.strftime("%Y-%m-%dT%H:%M:%S.%fZ"), "Failed to collect the iso8601_micro datetime fact"
    assert datetime_data['iso8601'] == now.strftime("%Y-%m-%dT%H:%M:%SZ"), "Failed to collect the iso8601 datetime fact"
    assert datetime_data['iso8601_basic'] == now.strftime("%Y%m%dT%H%M%S%f"), "Failed to collect the iso8601_basic datetime fact"
   

# Generated at 2022-06-20 19:19:01.055176
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    DateTimeFactCollector().collect()

# Generated at 2022-06-20 19:19:03.614037
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    datetime = DateTimeFactCollector()
    assert datetime.name == 'date_time'


# Generated at 2022-06-20 19:19:04.863373
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    fc = DateTimeFactCollector()
    assert fc.name == 'date_time'



# Generated at 2022-06-20 19:19:08.378756
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    instance = DateTimeFactCollector()
    assert isinstance(instance, DateTimeFactCollector)



# Generated at 2022-06-20 19:19:11.492736
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    c = DateTimeFactCollector()
    assert c.name == 'date_time'
    assert c._fact_ids == set()


# Generated at 2022-06-20 19:19:12.797288
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    my_object = DateTimeFactCollector()
    assert my_object.name == 'date_time'
    assert my_object._fact_ids == set()


# Unit Test for collect method of class DateTimeFactCollector

# Generated at 2022-06-20 19:19:20.125098
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts import Facts

    # Create a new instance of DateTimeFactCollector
    dtf = DateTimeFactCollector()

    # Create a new instance of Facts and run the
    # DateTimeFactCollector.collect method
    facts_instance = Facts(module_name='test')
    dtf.collect(module=facts_instance)

    # Verify the dates and time are correct types
    assert isinstance(facts_instance.facts['date_time']['month'], basestring)
    assert isinstance(facts_instance.facts['date_time']['weekday'], basestring)
    assert isinstance(facts_instance.facts['date_time']['weekday_number'], basestring)

# Generated at 2022-06-20 19:20:35.048779
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'
    assert x._fact_ids == set()

# Generated at 2022-06-20 19:20:45.081816
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Initializing mock values
    collected_facts = {}
    module = 'TestModule'

# Generated at 2022-06-20 19:20:51.529813
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import json
    import os
    import sys
    import time
    import unittest

    sys.path.insert(0, os.path.normpath(os.path.join(os.path.dirname(__file__), '..')))
    from ansible.module_utils.facts import FactCollector

    # Create a dummy result to use as input
    result = {'ansible_facts': {}}

    # Create a dummy module to use as input
    class DummyModule(object):
        def __init__(self):
            self.params = {}

    # Create a dummy module to use as input
    dummy_module = DummyModule()

    # get the collector object
    DateTimeFactCollector_obj = FactCollector.get_collector('date_time')

    # Test the method "collect" of class DateTimeFact

# Generated at 2022-06-20 19:20:56.010746
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'
    assert dtfc._fact_ids == set()


# Generated at 2022-06-20 19:21:03.139272
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_collector = DateTimeFactCollector()

    # test with module=None
    facts_dict = date_time_collector.collect(module=None)

    # test with collected_facts={}
    # module parameter is required
    facts_dict = date_time_collector.collect(module=None, collected_facts={})
    assert facts_dict == {}

# Generated at 2022-06-20 19:21:07.520106
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():

    # Constructor of class DateTimeFactCollector
    obj = DateTimeFactCollector()

    # Instance created successfully
    assert 1 == 1

# Generated at 2022-06-20 19:21:16.896965
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    date_time_facts = dtfc.collect()
    assert isinstance(date_time_facts, dict)
    assert 'date_time' in date_time_facts.keys()
    assert isinstance(date_time_facts['date_time'], dict)
    date_time_facts_dict = date_time_facts['date_time']
    # since this test could be ran in an hour where DST is in effect, only
    # check for valid data
    assert 'tz_dst' in date_time_facts_dict
    assert isinstance(date_time_facts_dict['tz_dst'], basestring)
    assert len(date_time_facts_dict['tz_dst']) > 1

# Generated at 2022-06-20 19:21:26.946278
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # test method requirements
    date_time_fact_collector = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector.collect()
    assert type(date_time_facts) is dict
    assert 'date_time' in date_time_facts.keys()

    # test data type of required facts
    date_time_fact = date_time_facts['date_time']
    if date_time_fact['epoch'] == '' or date_time_fact['epoch'][0] == '%':
        epoch = int(time.time())
    else:
        epoch = int(date_time_fact['epoch'])
    assert type(date_time_fact['year']) is str
    assert type(date_time_fact['month']) is str

# Generated at 2022-06-20 19:21:37.495984
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts import ansible_local
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    module_mock = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    module_mock.params = {}
    module_mock.check_mode = False
    module_mock.exit_json = lambda x: x
    module_mock.fail_json = lambda x: x

    date_time_fact_collector_mock = DateTimeFactCollector(module_mock)
    date_time_fact = date_time_fact_collector_mock.collect()

    # Check epoch is returned as integer or string, but not float
    epoch_fact = date_time_fact

# Generated at 2022-06-20 19:21:38.689684
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'
    assert type(x._fact_ids) == set