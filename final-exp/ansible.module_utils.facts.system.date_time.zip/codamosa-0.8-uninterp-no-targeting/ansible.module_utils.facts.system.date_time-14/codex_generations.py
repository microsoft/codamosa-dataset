

# Generated at 2022-06-20 19:11:44.525296
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time = DateTimeFactCollector()
    assert date_time.name == 'date_time'

# Generated at 2022-06-20 19:11:46.862607
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Test with default parameters
    DateTimeFactCollector().collect()


if __name__ == '__main__':
    test_DateTimeFactCollector_collect()

# Generated at 2022-06-20 19:11:50.347488
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()

    assert dt.name == 'date_time'
    assert dt.priority == 70

    year = datetime.datetime.now().strftime("%Y")
    assert dt.collect().get('date_time').get('year') == year

# Generated at 2022-06-20 19:11:52.510803
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector.collect()

    assert date_time_fact_collector.name == 'date_time'

# Generated at 2022-06-20 19:11:54.820725
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_facts = DateTimeFactCollector()
    assert date_time_facts.name == 'date_time'
    assert date_time_facts._fact_ids.__len__() == 0


# Generated at 2022-06-20 19:12:01.396671
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtf = DateTimeFactCollector()
    ansible_facts = {}
    result = dtf.collect(collected_facts=ansible_facts)

# Generated at 2022-06-20 19:12:03.889891
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # FIXME: we need a unit test for all fact modules :-/
    pass

# Generated at 2022-06-20 19:12:10.304969
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = DateTimeFactCollector()
    res = dt.collect()
    assert 'date_time' in res
    assert 'year' in res['date_time']
    assert 'month' in res['date_time']
    assert 'iso8601' in res['date_time']

# Generated at 2022-06-20 19:12:12.803125
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    facter = DateTimeFactCollector()
    assert facter.name == 'date_time'
    assert facter._fact_ids == set()

# Generated at 2022-06-20 19:12:24.928124
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Unit test for method collect of class DateTimeFactCollector
    """
    # Mock datetime.datetime.fromtimestamp(time.time()) to return a limited number
    # of fields
    old_fromtimestamp = datetime.datetime.fromtimestamp
    datetime.datetime.fromtimestamp = lambda t: datetime.datetime(2015, 5, 20, 19, 32, 5)
    # Mock datetime.datetime.utcfromtimestamp(time.time()) to return a limited number
    # of fields
    old_utcfromtimestamp = datetime.datetime.utcfromtimestamp
    datetime.datetime.utcfromtimestamp = lambda t: datetime.datetime(2015, 5, 20, 19, 32, 5)
    # Mock time.time() to return a specific number
    old_time

# Generated at 2022-06-20 19:12:32.063480
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    """
    Check the constructor of class DateTimeFactCollector
    """
    dtfc = DateTimeFactCollector()
    assert(hasattr(dtfc, 'name'))
    assert(hasattr(dtfc, '_fact_ids'))


# Generated at 2022-06-20 19:12:42.687482
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Arrange
    now1 = datetime.datetime.now()
    now2 = datetime.datetime.now()
    fake_time_module = MockDateTime(now1, now2)
    date_time_fact_collector = DateTimeFactCollector()

    # Act
    result = date_time_fact_collector.collect(module=fake_time_module)

    # Assert

# Generated at 2022-06-20 19:12:50.257666
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    factCollector = DateTimeFactCollector()
    assert factCollector.collect() is not None
    assert factCollector.collect().get('date_time') is not None
    date_time_facts = factCollector.collect().get('date_time')
    assert date_time_facts.get('year') is not None
    assert date_time_facts.get('month') is not None
    assert date_time_facts.get('weekday') is not None
    assert date_time_facts.get('weekday_number') is not None
    assert date_time_facts.get('weeknumber') is not None
    assert date_time_facts.get('day') is not None
    assert date_time_facts.get('hour') is not None
    assert date_time_facts.get('minute') is not None
    assert date_

# Generated at 2022-06-20 19:12:58.161169
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # If I create an instance of DateTimeFactCollector,
    # then the instance name is "date_time".
    assert 'date_time' == DateTimeFactCollector().name
    # If I call the collect method of the DateTimeFactCollector
    # instance then it returns a dictionary with a value for
    # the key 'date_time.iso8601_micro'.
    assert DateTimeFactCollector().collect()['date_time']['iso8601_micro']

# Generated at 2022-06-20 19:12:59.602718
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()


# Generated at 2022-06-20 19:13:05.068001
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_collector = DateTimeFactCollector()
    collected_facts = date_time_collector.collect(module=None, collected_facts=None)
    assert isinstance(collected_facts, dict)
    assert 'date_time' in collected_facts, "date_time facts are missing"

# Generated at 2022-06-20 19:13:11.269670
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'
    assert date_time_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:13:22.247844
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    module = None
    collected_facts = None
    c = DateTimeFactCollector()
    result = c.collect()
    assert 'date_time' in result
    # %s, %f and %w aren't supported on OS X
    assert 'epoch' in result['date_time'] and result['date_time']['epoch'] == c.now.strftime('%s')
    assert 'epoch_int' in result['date_time'] and int(float(result['date_time']['epoch_int'])) == int(time.time())
    assert result['date_time']['weekday_number'] == c.now.strftime('%w')

# Generated at 2022-06-20 19:13:23.610467
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    obj = DateTimeFactCollector()
    obj.collect()
    return True

# Generated at 2022-06-20 19:13:32.364793
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    result = DateTimeFactCollector().collect()
    assert 'date_time' in result
    assert 'date_time' in result
    assert 'year' in result['date_time']
    assert 'month' in result['date_time']
    assert 'weekday' in result['date_time']
    assert 'weekday_number' in result['date_time']
    assert 'weeknumber' in result['date_time']
    assert 'day' in result['date_time']
    assert 'hour' in result['date_time']
    assert 'minute' in result['date_time']
    assert 'second' in result['date_time']
    assert 'epoch' in result['date_time']
    assert 'epoch_int' in result['date_time']
    assert 'date' in result['date_time']

# Generated at 2022-06-20 19:13:40.827403
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'
    assert x._fact_ids == set()
    assert x.collect()['date_time']['weekday']

# Generated at 2022-06-20 19:13:44.268511
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector.name == 'date_time'
    assert DateTimeFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:13:47.459044
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()

    assert date_time_fact_collector.name == 'date_time'
    assert date_time_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:13:49.133434
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()


# Generated at 2022-06-20 19:14:01.857212
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.base import BaseFactCollector
    import datetime

    collector = Collector()
    datetime_collector = DateTimeFactCollector(collector)
    epoch_date_time_facts = datetime_collector.collect()
    datetime_facts = epoch_date_time_facts['date_time']
    now = datetime.datetime.now()
    utcnow = datetime.datetime.utcnow()
    assert datetime_facts['epoch'] == str(int(now.strftime('%s')))
    assert datetime_facts['epoch_int'] == str(int(utcnow.strftime('%s')))

# Generated at 2022-06-20 19:14:04.071367
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    DateTimeFactCollector.collect()

# Generated at 2022-06-20 19:14:08.894341
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_collector = DateTimeFactCollector()
    assert date_time_collector.name == 'date_time'
    assert date_time_collector._fact_ids == set()


# Generated at 2022-06-20 19:14:09.946180
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector.name == 'date_time'

# Generated at 2022-06-20 19:14:17.107806
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtf = DateTimeFactCollector()
    facts = dtf.collect()

    assert len(facts) == 1
    assert 'date_time' in facts
    assert len(facts['date_time']) > 10
    assert facts['date_time']['year'] == datetime.datetime.now().year

# Generated at 2022-06-20 19:14:20.626940
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt_factcollector = DateTimeFactCollector()
    assert dt_factcollector.name == 'date_time'
    assert not dt_factcollector._fact_ids

# Generated at 2022-06-20 19:14:29.316551
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()

# Generated at 2022-06-20 19:14:32.638966
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_facts = DateTimeFactCollector()
    assert date_time_facts is not None

# Generated at 2022-06-20 19:14:45.695221
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import sys

    # Skip the test if Python major version is less than 2.7
    if sys.version_info.major < 2 or (sys.version_info.major == 2 and sys.version_info.minor < 7):
        return

    # Set the is_local flag to True to test the method as though
    # it is running locally
    collector = DateTimeFactCollector()
    facts = collector.collect(None, None)

    assert len(facts) == 1
    assert 'date_time' in facts

    date_time_facts = facts['date_time']

    # There must be exactly 18 date-time facts
    assert len(date_time_facts) == 18

    # Validate the year fact
    assert 'year' in date_time_facts
    assert date_time_facts['year'].isdigit()

   

# Generated at 2022-06-20 19:14:47.666172
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    test = DateTimeFactCollector()
    assert test.name == 'date_time'
    assert test._fact_ids is not None

# Generated at 2022-06-20 19:14:49.921391
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    fc = DateTimeFactCollector()


# Generated at 2022-06-20 19:15:02.389634
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    #Set up class objects
    base_fact_collector = BaseFactCollector()
    date_time_fact_collector = DateTimeFactCollector()

    #Test case 1
    collected_facts = base_fact_collector.collect()
    collected_facts['date_time'] = date_time_fact_collector.collect()
    date_time_facts = collected_facts['date_time']
    assert date_time_facts['year'] == datetime.datetime.now().strftime('%Y')
    assert date_time_facts['month'] == datetime.datetime.now().strftime('%m')
    assert date_time_facts['weekday'] == datetime.datetime.now().strftime('%A')
    assert date_time_facts['weekday_number'] == datetime.datetime.now().str

# Generated at 2022-06-20 19:15:07.912200
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
     aDateTimeFactCollector = DateTimeFactCollector()
     assert aDateTimeFactCollector.name == 'date_time'
     assert set(aDateTimeFactCollector._fact_ids) == set()



# Generated at 2022-06-20 19:15:11.949133
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    target = DateTimeFactCollector()
    result = target.collect()
    assert(isinstance(result, dict))
    assert(result['date_time']['epoch'] != '' and result['date_time']['epoch'][0] != '%')

# Generated at 2022-06-20 19:15:15.045743
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt_fact_collector = DateTimeFactCollector()
    dt_fact_collector.collect()

# Generated at 2022-06-20 19:15:23.416955
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # constructor of DateTimeFactCollector
    date_fact_collector = DateTimeFactCollector()
    assert date_fact_collector is not None

    # get name of DateTimeFactCollector
    assert date_fact_collector.name == 'date_time'

    # get fact ids of DateTimeFactCollector
    assert 'date_time' in date_fact_collector._fact_ids

# Generated at 2022-06-20 19:15:47.718722
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = DateTimeFactCollector()
    dt_facts = dt.collect()["date_time"]
    assert dt_facts["month"] == datetime.datetime.now().strftime('%m')
    assert dt_facts["weekday"] == datetime.datetime.now().strftime('%A')
    assert dt_facts["weekday_number"] == datetime.datetime.now().strftime('%w')
    assert dt_facts["weeknumber"] == datetime.datetime.now().strftime('%W')
    assert dt_facts["day"] == datetime.datetime.now().strftime('%d')
    assert dt_facts["hour"] == datetime.datetime.now().strftime('%H')

# Generated at 2022-06-20 19:15:50.293627
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_collector = DateTimeFactCollector()
    assert type(date_time_collector.collect()) == dict

# Generated at 2022-06-20 19:15:54.930108
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Unit test for method collect of class DateTimeFactCollector"""
    collected_facts = dict()
    collector = DateTimeFactCollector()
    collected_facts = collector.collect()
    assert collected_facts['date_time']['day'] == datetime.datetime.now().strftime('%d')

# Generated at 2022-06-20 19:16:04.105874
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collect = DateTimeFactCollector().collect
    result = collect()
    assert result['date_time']['time'] == time.strftime("%H:%M:%S")
    assert result['date_time']['iso8601_basic_short'] == time.strftime("%Y%m%dT%H%M%S")
    # Make sure epoch is parsable to int
    assert int(result['date_time']['epoch']) > 0
    assert result['date_time']['tz'] == time.strftime("%Z")
    assert result['date_time']['tz_dst'] == time.tzname[1]
    assert result['date_time']['tz_offset'] == time.strftime("%z")

# Generated at 2022-06-20 19:16:07.461913
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj.name == 'date_time'
    assert obj._fact_ids == set()


# Generated at 2022-06-20 19:16:19.850715
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Create an instance of the DateTimeFactCollector
    date_time_fact_collector = DateTimeFactCollector()

    # Call the collect method
    date_time_facts = date_time_fact_collector.collect()

    assert date_time_facts['date_time']['year']
    assert date_time_facts['date_time']['month']
    assert date_time_facts['date_time']['weekday']
    assert date_time_facts['date_time']['weekday_number']
    assert date_time_facts['date_time']['weeknumber']
    assert date_time_facts['date_time']['day']
    assert date_time_facts['date_time']['hour']
    assert date_time_facts['date_time']['minute']

# Generated at 2022-06-20 19:16:30.976170
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """DateTimeFactCollector - collect method
    
    Test DateTimeFactCollector.collect method to check if return
    dictionary with the right keys and values.
    
    Parameters
    ----------
    module : object, optional
        Reference to a module object. (The AnsibleModule api object.)

    collected_facts : dict, optional
        Dictionary of collected facts.
    
    Returns
    -------
    facts_dict : dict
        Dictionary with the right keys and values.
    
    """
    # Test a dictionary with the right keys and values

# Generated at 2022-06-20 19:16:40.656225
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    collected_facts = fact_collector.collect()
    assert 'date_time' in collected_facts.keys()
    assert 'epoch' in collected_facts['date_time'].keys()
    assert 'epoch_int' in collected_facts['date_time'].keys()
    assert 'iso8601' in collected_facts['date_time'].keys()
    assert 'iso8601_basic' in collected_facts['date_time'].keys()
    assert 'iso8601_basic_short' in collected_facts['date_time'].keys()
    assert 'iso8601_micro' in collected_facts['date_time'].keys()
    assert 'minute' in collected_facts['date_time'].keys()

# Generated at 2022-06-20 19:16:41.636573
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()


# Generated at 2022-06-20 19:16:45.957566
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    gathered_facts = DateTimeFactCollector().collect()
    # this is a very simple test, but if it fails, we'll get a traceback
    assert gathered_facts['date_time']['year'] == str(datetime.datetime.now().year)

# Generated at 2022-06-20 19:17:17.625662
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time = DateTimeFactCollector()
    assert date_time.name == 'date_time'
    assert date_time._fact_ids == set()

# Generated at 2022-06-20 19:17:31.121923
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time = date_time_fact_collector.collect(None, None)['date_time']
    now = datetime.datetime.now()
    utcnow = datetime.datetime.utcnow()
    assert date_time['year'] == now.strftime("%Y")
    assert date_time['month'] == now.strftime("%m")
    assert date_time['day'] == now.strftime("%d")
    assert date_time['hour'] == now.strftime("%H")
    assert date_time['minute'] == now.strftime("%M")
    assert date_time['second'] == now.strftime("%S")
    assert date_time['epoch'] == now.strftime("%s")
   

# Generated at 2022-06-20 19:17:33.034022
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # TODO: Implement unit test
    assert True == True


# Generated at 2022-06-20 19:17:42.571299
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'

# Generated at 2022-06-20 19:17:49.997741
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    '''
    Test for method collect of class DateTimeFactCollector.
    '''
    dtfc = DateTimeFactCollector(None)
    res = dtfc.collect(None)
    assert res['date_time']['tz_dst'] != datetime.timezone.utc.tzname(None)


# Generated at 2022-06-20 19:17:51.307445
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()


# Generated at 2022-06-20 19:17:53.798332
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()

# Generated at 2022-06-20 19:17:56.872285
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Test method collect of class DateTimeFactCollector
    """
    import sys
    from ansible.module_utils.facts.collector import MockModule
    collector = DateTimeFactCollector()
    module = MockModule()
    collected_facts = collector.collect(module=module)
    assert 'date_time' in collected_facts



# Generated at 2022-06-20 19:18:00.576947
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Test constructor creates object of type DateTimeFactCollector
    dateTimeFactCollector = DateTimeFactCollector()
    assert(isinstance(dateTimeFactCollector, DateTimeFactCollector))


# Generated at 2022-06-20 19:18:04.882677
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    __date_time_fact_collector = DateTimeFactCollector()
    print(__date_time_fact_collector.collect())

# Generated at 2022-06-20 19:19:08.600131
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()

    assert collector.name == 'date_time'
    assert collector.priority == 60

# Generated at 2022-06-20 19:19:11.781407
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector.name == 'date_time'
    assert DateTimeFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:19:14.917023
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'
    assert date_time_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:19:17.192405
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_collector = DateTimeFactCollector()
    assert date_time_collector.name == 'date_time'
    assert len(date_time_collector._fact_ids) == 0


# Generated at 2022-06-20 19:19:30.089690
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fc = DateTimeFactCollector()

# Generated at 2022-06-20 19:19:33.027286
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    obj = DateTimeFactCollector()
    obj._module = object()
    result = obj.collect()
    assert result is not None

# Generated at 2022-06-20 19:19:36.040391
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    result = type(x) is DateTimeFactCollector
    assert result


# Generated at 2022-06-20 19:19:37.095906
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector().name == 'date_time'

# Generated at 2022-06-20 19:19:46.785977
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt.name == 'date_time'
    for fact in ['year', 'month', 'weekday', 'weekday_number', 'weeknumber', 'day', 'hour', 'minute', 'second', 'epoch', 'time', 'iso8601_micro', 'iso8601_basic', 'tz', 'tz_dst', 'tz_offset']:
        assert fact in dt._fact_ids

# Generated at 2022-06-20 19:19:53.169454
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():

    # Test constructor of DateTimeFactCollector
    collector = DateTimeFactCollector()
    assert collector.name == 'date_time'
    assert collector._fact_ids == set()
    assert isinstance(collector, BaseFactCollector)
    assert isinstance(collector.collect(), dict)