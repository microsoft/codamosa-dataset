

# Generated at 2022-06-20 19:11:45.290724
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    """Test DateTimeFactCollector class"""
    DateTimeFactCollector()

# Generated at 2022-06-20 19:11:48.680646
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    facts = DateTimeFactCollector()

    result = facts.collect()
    assert isinstance(result, dict)
    assert isinstance(result['date_time'], dict)
    assert 'iso8601' in result['date_time']

# Generated at 2022-06-20 19:11:49.637474
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    result = DateTimeFactCollector()
    assert result

# Generated at 2022-06-20 19:11:52.157457
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt_facts_collector = DateTimeFactCollector()
    assert dt_facts_collector.name == 'date_time'
    assert dt_facts_collector._fact_ids == set()


# Generated at 2022-06-20 19:11:53.516674
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()
    assert collector.name == 'date_time'
    assert not collector._fact_ids

# Generated at 2022-06-20 19:11:54.971452
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtObj = DateTimeFactCollector()

    assert dtObj.name == 'date_time'

# Generated at 2022-06-20 19:11:59.249548
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts.collector.system import SystemFactCollector
    from ansible.module_utils.facts.collector.system.distribution import DistributionFactCollector
    DateTimeFactCollector_instance = DateTimeFactCollector()
    res = DateTimeFactCollector_instance.collect()
    assert "date_time" in res
    for i in range(19) :
        assert res["date_time"].keys()[i] in res["date_time"]

# Generated at 2022-06-20 19:12:03.119585
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    test_facts = DateTimeFactCollector.collect()

    assert test_facts is not None
    assert 'date_time' in test_facts
    assert test_facts['date_time'] is not None
    assert len(test_facts['date_time']) > 0

# Generated at 2022-06-20 19:12:07.189226
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = DateTimeFactCollector()
    res = dt.collect()
    assert "date_time" in res.keys()

# Generated at 2022-06-20 19:12:08.820101
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'
    assert date_time_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:12:12.237965
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()


# Generated at 2022-06-20 19:12:19.425328
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    (dtfm, dtf, collected_facts) = setup_DateTimeFactCollector()
    collected_facts = dtf.collect(collected_facts=collected_facts)
    assert 'date_time' in collected_facts
    assert len(collected_facts['date_time'].keys()) == 19

# Generated at 2022-06-20 19:12:26.720719
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector.collect()
    assert(date_time_facts['date_time']['year'])
    assert(date_time_facts['date_time']['month'])
    assert(date_time_facts['date_time']['weekday'])
    assert(date_time_facts['date_time']['weekday_number'])
    assert(date_time_facts['date_time']['weeknumber'])
    assert(date_time_facts['date_time']['day'])
    assert(date_time_facts['date_time']['hour'])
    assert(date_time_facts['date_time']['minute'])

# Generated at 2022-06-20 19:12:32.531406
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    dtfc.collect()

    # time.tzname is different in some Linux, so this test is not going to work
    #assert 'tz_dst' in dtfc['date_time']
    assert 'tz_offset' in dtfc['date_time']

# Generated at 2022-06-20 19:12:33.801673
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()

# Generated at 2022-06-20 19:12:37.740087
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_collector = DateTimeFactCollector()
    test_collector.collect()

# Generated at 2022-06-20 19:12:47.911098
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    date_time_facts_dict = fact_collector.collect()
    assert 'date_time' in date_time_facts_dict
    date_time_facts = date_time_facts_dict['date_time']
    assert 'year' in date_time_facts
    assert 'month' in date_time_facts
    assert 'weekday' in date_time_facts
    assert 'weekday_number' in date_time_facts
    assert 'weeknumber' in date_time_facts
    assert 'day' in date_time_facts
    assert 'hour' in date_time_facts
    assert 'minute' in date_time_facts
    assert 'second' in date_time_facts
    assert 'epoch' in date_time_facts

# Generated at 2022-06-20 19:12:49.854251
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector.name == 'date_time'

# Generated at 2022-06-20 19:12:55.704739
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    c = DateTimeFactCollector()
    result = c.collect()
    # Testing len(dict) instead of each key/value pair to avoid testing
    # implementation details:
    assert len(result) == 1
    assert len(result['date_time']) == 18

# Generated at 2022-06-20 19:12:59.452228
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_data = DateTimeFactCollector({}, [])
    data = date_time_data.collect()
    assert 'date_time' in data.keys()

# Generated at 2022-06-20 19:13:09.668718
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt_obj = DateTimeFactCollector()
    result = dt_obj.collect()
    assert (type(result) is dict)
    assert ('date_time' in result)
    assert (result['date_time']['year'] == datetime.datetime.now().strftime("%Y"))
    assert (result['date_time']['month'] == datetime.datetime.now().strftime("%m"))
    assert (result['date_time']['date'] == datetime.datetime.now().strftime("%Y-%m-%d"))
    assert (result['date_time']['day'] == datetime.datetime.now().strftime("%d"))

# Generated at 2022-06-20 19:13:11.348404
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # TODO: create a testcase when complete
    pass

# Generated at 2022-06-20 19:13:22.571429
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    #Create a DateTimeFactCollector object
    dtf = DateTimeFactCollector()
    dtf.collect()

    #Test if method collect generates the right facts data
    ansible_facts = dtf.collect()
    assert ansible_facts != None
    assert ansible_facts['date_time'] != None
    assert len(ansible_facts['date_time']) == 16

    #Test if method collect generates the right facts data for 'year'
    assert ansible_facts['date_time']['year'] == time.strftime('%Y')

    #Test if method collect generates the right facts data for 'month'
    assert ansible_facts['date_time']['month'] == time.strftime('%m')

    #Test if method collect generates the right facts data for 'weekday'

# Generated at 2022-06-20 19:13:27.535047
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    test_w = DateTimeFactCollector()

    # some facts are missing - check only the ones we can test
    test_data = {'date_time': {'date': '2020-11-11', 'time': '12:12:12', 'tz': 'CET', 'tz_offset': '+0100'}}
    assert test_data == test_w.collect(collected_facts=None)

# Generated at 2022-06-20 19:13:30.271772
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dcf = DateTimeFactCollector()
    assert(dcf.name == 'date_time')

# Generated at 2022-06-20 19:13:37.575338
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtf = DateTimeFactCollector()
    #For the unit test, create a datetime object for which we know the
    #expected output
    dt = datetime.datetime(year=2016, month=11, day=23, hour=14, minute=30, second=17, microsecond=123456)
    #Create a timestamp from the datetime object
    ts = time.mktime(dt.timetuple())
    #Update the epoch key to the known value
    dtf.collect(collected_facts=dict(date_time=dict(epoch=str(int(ts)))))
    #Create a dictionary for the expected results

# Generated at 2022-06-20 19:13:41.539940
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'
    assert x._fact_ids == set()

# Generated at 2022-06-20 19:13:45.004922
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'

# Generated at 2022-06-20 19:13:46.321358
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()

# Generated at 2022-06-20 19:14:00.951816
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
        This function implements a unit test for the
        collect method of DateTimeFactCollector class.
    """
    date_time_collector = DateTimeFactCollector()
    result = date_time_collector.collect()
    assert result['date_time'] != None
    assert result['date_time']['year'] != None
    assert result['date_time']['month'] != None
    assert result['date_time']['weekday'] != None
    assert result['date_time']['weekday_number'] != None
    assert result['date_time']['weeknumber'] != None
    assert result['date_time']['day'] != None
    assert result['date_time']['hour'] != None
    assert result['date_time']['minute'] != None

# Generated at 2022-06-20 19:14:08.583947
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Check if correct argument is passed to super class
    collector = DateTimeFactCollector()
    assert collector.name == 'date_time'


# Generated at 2022-06-20 19:14:11.604266
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_collector = DateTimeFactCollector({})
    facts_dict = date_time_collector.collect()
    assert 'date_time' in facts_dict
    assert facts_dict['date_time']['epoch_int'] == facts_dict['date_time']['epoch']

# Generated at 2022-06-20 19:14:17.842276
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import pytest

    c = DateTimeFactCollector()
    kwargs = dict(collected_facts=dict())
    result = c.collect(**kwargs)
    assert 'date_time' in result
    assert 'year' in result['date_time'].keys()


# Generated at 2022-06-20 19:14:21.184132
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'

# Generated at 2022-06-20 19:14:30.979188
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts import collector
    fact = collector.get('date_time').get_collection_from_cache()
    keys = ['date', 'year', 'time', 'minute', 'weekday_number', 'day', 'tz', 'epoch_int', 'epoch', 'tz_offset', 'weeknumber', 'month', 'second', 'hour', 'weekday', 'iso8601_micro', 'tz_dst', 'iso8601', 'iso8601_basic_short', 'iso8601_basic']
    assert fact.keys() == keys, "method collect from DateTimeFactCollector did not return '%s' but '%s' instead" % (keys, fact.keys())


# Generated at 2022-06-20 19:14:44.670384
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts import ansible_collections_path
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.module_utils._text import to_bytes
    from ansible_collections.misc.facts.plugins.module_utils.date_time import DateTimeFactCollector

    # Get DateTimeFactCollector
    collection_paths = [ansible_collections_path('misc.facts')]
    loader = AnsibleCollectionLoader()
    loader.set_collection_paths(collection_paths)
    collection = loader.load_collections([to_bytes(u'misc.facts')])[0]
    loader.set_collection_info(collection)
    plugin = [x for x in collection.plugins if x.name == 'date_time']
    module = plugin[0]

# Generated at 2022-06-20 19:14:56.326063
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Test DateTimeFactCollector.collect
    """
    dtf = DateTimeFactCollector()
    collected_facts = dtf.collect()

    assert 'date_time' in collected_facts
    assert 'year' in collected_facts['date_time']
    assert 'month' in collected_facts['date_time']
    assert 'weekday' in collected_facts['date_time']
    assert 'weekday_number' in collected_facts['date_time']
    assert 'weeknumber' in collected_facts['date_time']
    assert 'day' in collected_facts['date_time']
    assert 'hour' in collected_facts['date_time']
    assert 'minute' in collected_facts['date_time']
    assert 'second' in collected_facts['date_time']
    assert 'epoch' in collected_

# Generated at 2022-06-20 19:14:59.458031
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'
    assert x._fact_ids == set()

# Generated at 2022-06-20 19:15:02.279761
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'
    assert date_time_fact_collector._fact_ids == set(['date_time'])


# Generated at 2022-06-20 19:15:14.452028
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = DateTimeFactCollector()
    facts = dt.collect()
    assert facts['date_time']['year'] is not None
    assert facts['date_time']['month'] is not None
    assert facts['date_time']['weekday'] is not None
    assert facts['date_time']['weekday_number'] is not None
    assert facts['date_time']['weeknumber'] is not None
    assert facts['date_time']['day'] is not None
    assert facts['date_time']['hour'] is not None
    assert facts['date_time']['minute'] is not None
    assert facts['date_time']['second'] is not None
    assert facts['date_time']['epoch'] is not None

# Generated at 2022-06-20 19:15:31.213223
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_facts = DateTimeFactCollector()
    result = date_time_facts.collect()

# Generated at 2022-06-20 19:15:34.930995
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    unit = DateTimeFactCollector()
    unit.collect()
    # check that we have a string in epoch
    assert unit.collect()['date_time']['epoch']

# Generated at 2022-06-20 19:15:36.643427
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    actual = DateTimeFactCollector().collect()
    assert actual['date_time']

# Generated at 2022-06-20 19:15:40.418210
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    test = DateTimeFactCollector()
    assert test.name == 'date_time'
    assert test._fact_ids == set()


# Generated at 2022-06-20 19:15:46.992336
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
  # Test default constructor, should create empty dict
  my_date_time_fact_collector = DateTimeFactCollector()

  assert(my_date_time_fact_collector.name == 'date_time')
  assert(my_date_time_fact_collector._fact_ids == set())

  my_date_time_fact_dict = my_date_time_fact_collector.collect()
  assert('date_time' in my_date_time_fact_dict)
  assert(my_date_time_fact_dict['date_time'] != None)


# Generated at 2022-06-20 19:15:50.154099
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    bc = DateTimeFactCollector()
    assert bc.name == 'date_time'
    assert bc._fact_ids == set()

# Generated at 2022-06-20 19:15:52.110547
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    x = DateTimeFactCollector()
    x.collect()

# Generated at 2022-06-20 19:15:53.599260
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    a = DateTimeFactCollector()
    assert a is not None


# Generated at 2022-06-20 19:15:58.560044
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():

    date_time_fact_collector = DateTimeFactCollector()

    assert date_time_fact_collector.name == 'date_time'
    assert isinstance(date_time_fact_collector._fact_ids, set)



# Generated at 2022-06-20 19:16:08.011136
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    test DateTimeFactCollector.collect
    """

# Generated at 2022-06-20 19:16:25.741570
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj.name == 'date_time'
    assert obj.collector == DateTimeFactCollector.collect
    assert len(obj._fact_ids) == 1
    assert obj._fact_ids == set(['ansible_date_time'])

# Generated at 2022-06-20 19:16:28.725737
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Create instance of DateTimeFactCollector
    date_time_facts = DateTimeFactCollector()


# Generated at 2022-06-20 19:16:32.467821
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    c = DateTimeFactCollector()
    facts = c.collect()
    assert 'date_time' in facts
    assert isinstance(facts['date_time'], dict)

# Generated at 2022-06-20 19:16:35.978650
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    the_test = DateTimeFactCollector()
    assert the_test.name == 'date_time'
    assert the_test._fact_ids == set()


# Generated at 2022-06-20 19:16:48.223536
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_facts = DateTimeFactCollector().collect()
    assert date_time_facts['date_time']['date'] == datetime.datetime.now().strftime('%Y-%m-%d')
    assert date_time_facts['date_time']['day'] == datetime.datetime.now().strftime('%d')
    assert date_time_facts['date_time']['epoch'] == str(int(time.time()))
    assert date_time_facts['date_time']['hour'] == datetime.datetime.now().strftime('%H')
    assert date_time_facts['date_time']['iso8601'] == datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
   

# Generated at 2022-06-20 19:16:52.813779
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    fact_collector = DateTimeFactCollector()
    assert fact_collector.name == 'date_time'
    assert isinstance(fact_collector._fact_ids, set)


# Generated at 2022-06-20 19:17:05.041284
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Test DateTimeFactCollector.collect()."""
    collector = DateTimeFactCollector()
    collected_facts = dict()
    collector.collect(collected_facts=collected_facts)
    # The test is that this does not cause an exception.
    assert 'date_time' in collected_facts
    # This tests that certain fields are present, but does not check that the
    # values are correct.

# Generated at 2022-06-20 19:17:08.474307
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Unit test for method collect of class DateTimeFactCollector
    """
    date_time_fact_ins = DateTimeFactCollector()
    date_time_fact_ins.collect()


# Generated at 2022-06-20 19:17:19.852506
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Compose a mocked module object
    test_module = type('', (), {
        'params': dict(
            gather_subset=[],
            gather_timeout=10,
            filter=dict(),
            ansible_facts={}
        ),
        '_ansible_version': (2, 6, 0),
        '_ansible_module_name': 'test'
    })()
    # Compose a mocked collected facts dictionary, which is empty
    test_collected_facts = dict()

    DateTimeFactCollector.collect(test_module, test_collected_facts)

    # Verify whether the target method returns the expected result
    assert 'date_time' in test_collected_facts
    assert type(test_collected_facts['date_time']) is dict

# Generated at 2022-06-20 19:17:23.413232
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Unit test for the method 'collect'.
    """
    dt_fc = DateTimeFactCollector()
    dt_fc.collect()

# Generated at 2022-06-20 19:18:04.248864
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    DATETIME_PROC_FILE = open('tests/unit/module_utils/facts/files/date_time', 'rb')

    class MockModule:
        pass

    class MockTime:
        @staticmethod
        def time():
            return 1234567891
        @staticmethod
        def strftime(fmt):
            return fmt


# Generated at 2022-06-20 19:18:14.485555
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-20 19:18:25.974134
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    DateTimeFactCollector_obj = DateTimeFactCollector()
    res = DateTimeFactCollector_obj.collect()

# Generated at 2022-06-20 19:18:35.178422
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt_fc = DateTimeFactCollector()
    dt_facts = dt_fc.collect()
    assert 'date_time' in dt_facts.keys()
    assert 'year' in dt_facts['date_time'].keys()
    assert 'month' in dt_facts['date_time'].keys()
    assert 'weekday' in dt_facts['date_time'].keys()
    assert 'weekday_number' in dt_facts['date_time'].keys()
    assert 'weeknumber' in dt_facts['date_time'].keys()
    assert 'day' in dt_facts['date_time'].keys()
    assert 'hour' in dt_facts['date_time'].keys()
    assert 'minute' in dt_facts['date_time'].keys()

# Generated at 2022-06-20 19:18:46.723032
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    facts = fact_collector.collect()
    assert isinstance(facts, dict)
    assert 'date_time' in facts
    assert isinstance(facts['date_time'], dict)
    date_time_keys = ['year', 'month', 'weekday', 'weekday_number', 'weeknumber', 'day',
                      'hour', 'minute', 'second', 'epoch', 'epoch_int', 'date', 'time', 'iso8601_micro',
                      'iso8601', 'tz', 'tz_offset', 'tz_dst']
    for key in date_time_keys:
        assert key in facts['date_time']
        assert facts['date_time'][key]

# Generated at 2022-06-20 19:18:57.871021
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    module = None
    collected_facts = None
    date_time_fact_collector = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector.collect(module, collected_facts)
    date_time_facts_values = date_time_facts['date_time']

    # The following tests are made in order to ensure that the collected time
    # data is correct, and that it is always collected.
    assert date_time_facts_values['year']
    assert date_time_facts_values['month']
    assert date_time_facts_values['weekday']
    assert date_time_facts_values['weekday_number']
    assert date_time_facts_values['weeknumber']
    assert date_time_facts_values['day']
    assert date_time_facts_values['hour']

# Generated at 2022-06-20 19:19:00.490767
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'


# Generated at 2022-06-20 19:19:03.390743
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert issubclass(DateTimeFactCollector, BaseFactCollector) == True
    assert DateTimeFactCollector.name == 'date_time'

# Generated at 2022-06-20 19:19:12.164016
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtf = DateTimeFactCollector()
    collected_facts = dtf.collect()
    assert collected_facts is not None
    assert 'date_time' in collected_facts
    assert 'year' in collected_facts['date_time']
    assert 'month' in collected_facts['date_time']
    assert 'weekday' in collected_facts['date_time']
    assert 'weekday_number' in collected_facts['date_time']
    assert 'weeknumber' in collected_facts['date_time']
    assert 'day' in collected_facts['date_time']
    assert 'hour' in collected_facts['date_time']
    assert 'minute' in collected_facts['date_time']
    assert 'second' in collected_facts['date_time']
    assert 'epoch' in collected_facts['date_time']


# Generated at 2022-06-20 19:19:14.125790
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_obj = DateTimeFactCollector()
    assert date_time_obj

# Generated at 2022-06-20 19:20:32.662333
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Test that the collector can return at least one datetime fact
    """

    dt_collector = DateTimeFactCollector()
    # Call collect
    collected_facts = dt_collector.collect()

    # Check result of collect method

# Generated at 2022-06-20 19:20:44.047354
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    df = DateTimeFactCollector()

# Generated at 2022-06-20 19:20:51.277308
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_facts = DateTimeFactCollector()
    response = date_time_facts.collect()['date_time']
    assert response['epoch_int'] == str(int(time.time()))
    assert response['epoch'] == str(time.time())
    assert not any(char in response['second'] for char in ['.', ','])

# Generated at 2022-06-20 19:20:57.624061
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt_collector = DateTimeFactCollector()
    assert dt_collector.collect()['date_time']['iso8601_basic_short'] == \
        datetime.datetime.utcnow().strftime("%Y%m%dT%H%M%S")

# Generated at 2022-06-20 19:20:59.937055
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj.name == 'date_time'

# Generated at 2022-06-20 19:21:04.693190
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    now = datetime.datetime.now()
    epoch_ts = time.time()
    assert(int(epoch_ts) == int(now.strftime('%s')))
    assert(int(epoch_ts) == int(DateTimeFactCollector().collect()['date_time']['epoch']))

# Generated at 2022-06-20 19:21:09.181155
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    d_t_facts = DateTimeFactCollector()

    assert d_t_facts.name == 'date_time'
    assert d_t_facts._fact_ids == set()


# Generated at 2022-06-20 19:21:14.071396
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Unit test for method collect of class DateTimeFactCollector"""
    date_time_fact_collector = DateTimeFactCollector()
    ret = date_time_fact_collector.collect()
    print("Return from method collect of class DateTimeFactCollector:")
    print(ret)



# Generated at 2022-06-20 19:21:18.075447
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt.name == 'date_time'
    assert dt._fact_ids == set()


# Generated at 2022-06-20 19:21:20.599127
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt
    assert dt.name == 'date_time'