

# Generated at 2022-06-20 19:11:53.404375
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    datetime_facts = DateTimeFactCollector().collect()

    assert isinstance(datetime_facts, dict)
    assert datetime_facts['date_time']['year'] == datetime.datetime.now().strftime('%Y')
    assert datetime_facts['date_time']['month'] == datetime.datetime.now().strftime('%m')
    assert datetime_facts['date_time']['weekday'] == datetime.datetime.now().strftime('%A')
    assert datetime_facts['date_time']['weekday_number'] == datetime.datetime.now().strftime('%w')
    assert datetime_facts['date_time']['weeknumber'] == datetime.datetime.now().strftime('%W')

# Generated at 2022-06-20 19:11:56.065837
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    """This function is used to test constructor of class DateTimeFactCollector.

    :return: no return value
    :rtype: none
    """
    dt = DateTimeFactCollector()
    assert dt.name == 'date_time'

# Generated at 2022-06-20 19:12:02.210938
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-20 19:12:07.120194
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc._fact_ids == set()
    assert dtfc.name == 'date_time'


# Generated at 2022-06-20 19:12:11.944513
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'
    assert date_time_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:12:13.339380
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt_constructor = DateTimeFactCollector()
    assert dt_constructor.name == 'date_time'

# Generated at 2022-06-20 19:12:15.081030
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    pass

# Generated at 2022-06-20 19:12:15.957800
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    d = DateTimeFactCollector()
    assert d.name == 'date_time'


# Generated at 2022-06-20 19:12:18.516901
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_facts = DateTimeFactCollector()
    assert date_time_facts is not None

# Generated at 2022-06-20 19:12:21.502844
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector('date_time')
    assert 'date_time' == dt.name
    assert hasattr(dt, 'collect')

# Generated at 2022-06-20 19:12:28.779414
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt_collector = DateTimeFactCollector()

    assert isinstance(dt_collector, DateTimeFactCollector)
    assert isinstance(dt_collector, BaseFactCollector)

# Generated at 2022-06-20 19:12:37.110888
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Prepare test data
    test_time = '2000-01-01T01:00:00.000000Z'

# Generated at 2022-06-20 19:12:47.700088
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = DateTimeFactCollector()
    data = dt.collect(None, None)
    assert 'date_time' in data
    assert isinstance(data['date_time'], dict)
    assert 'year' in data['date_time']
    assert 'month' in data['date_time']
    assert 'weekday' in data['date_time']
    assert 'weekday_number' in data['date_time']
    assert 'weeknumber' in data['date_time']
    assert 'day' in data['date_time']
    assert 'hour' in data['date_time']
    assert 'minute' in data['date_time']
    assert 'second' in data['date_time']
    assert 'epoch' in data['date_time']

# Generated at 2022-06-20 19:12:50.780999
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    col = DateTimeFactCollector()
    assert col.name == 'date_time'
    assert col._fact_ids == set()


# Generated at 2022-06-20 19:12:56.227789
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Returns the date_time dictionary.
    :return: Returns True/False upon success/failure of the test.
    """

    collector = DateTimeFactCollector()
    try:
        collector.collect()
    except:
        return False
    return True


# Generated at 2022-06-20 19:12:59.452210
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert(dt.name == 'date_time')
    assert(dt._fact_ids == set())

# Generated at 2022-06-20 19:13:05.020382
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # We need a deepcopy of the dictionary because we are going to modify it.
    import copy
    collector = DateTimeFactCollector()
    assert collector.name == 'date_time'
    assert collector.collect()['date_time']['date'] == datetime.datetime.now().strftime('%Y-%m-%d')

# Generated at 2022-06-20 19:13:08.688371
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector.name == "date_time"
    assert DateTimeFactCollector._fact_ids == set()

# Generated at 2022-06-20 19:13:11.006502
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Unit test for method collect of class DateTimeFactCollector."""
    dt_fact_collector = DateTimeFactCollector()

    facts_dict = dt_fact_collector.collect()
    assert isinstance(facts_dict, dict)

# Generated at 2022-06-20 19:13:23.063225
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts.collector import DictCollector
    from ansible.module_utils.facts.collector import FactsCollector

    date_time_fact_collector = DateTimeFactCollector()
    fact_collector = FactsCollector()

# Generated at 2022-06-20 19:13:39.785013
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import platform
    import time

    # Mock the epoch time
    time.time = lambda: 1000.0

    dtf = DateTimeFactCollector()
    result = dtf.collect()

    assert result['ansible_date_time']['year'] == '1970'
    assert result['ansible_date_time']['date'] == '1970-01-01'
    assert result['ansible_date_time']['time'] == '02:46:40'
    assert result['ansible_date_time']['iso8601'] == '1970-01-01T02:46:40Z'
    assert len(result['ansible_date_time']['iso8601_micro']) == str("1970-01-01T02:46:40.000000Z")

# Generated at 2022-06-20 19:13:48.190415
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collector = DateTimeFactCollector()
    collected_facts = collector.collect()

    # These three facts are returned in the collected facts
    assert collected_facts['date_time']['epoch_int'] != ''
    assert collected_facts['date_time']['time'] != ''
    assert collected_facts['date_time']['tz'] != ''
    assert collected_facts['date_time']['tz_dst'] != ''
    assert collected_facts['date_time']['tz_offset'] != ''

# Generated at 2022-06-20 19:13:55.168276
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # arrange
    ftc = DateTimeFactCollector()

    # assert
    assert ftc.name == 'date_time'
    assert hasattr(ftc, '_fact_ids')
    assert hasattr(ftc, 'collect')

# Unit Test for method collect of class DateTimeFactCollector

# Generated at 2022-06-20 19:13:56.450451
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'
    assert x._fact_ids == set()

# Generated at 2022-06-20 19:14:05.739777
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fc = DateTimeFactCollector()

    date_time = date_time_fc.collect()
    assert date_time['date_time']['year'] == datetime.datetime.now().strftime('%Y')
    assert date_time['date_time']['month'] == datetime.datetime.now().strftime('%m')
    assert date_time['date_time']['weekday'] == datetime.datetime.now().strftime('%A')
    assert date_time['date_time']['weekday_number'] == datetime.datetime.now().strftime('%w')
    assert date_time['date_time']['weeknumber'] == datetime.datetime.now().strftime('%W')
    assert date_time['date_time']['day'] == dat

# Generated at 2022-06-20 19:14:08.245877
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:14:14.357889
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """DateTimeFactCollector - collect()
    Validate that the collect() method of DateTimeFactCollector
    returns the current date and time as a dictionary.
    """

    collected_facts = dict()
    collector = DateTimeFactCollector()
    result = collector.collect(collected_facts=collected_facts)

    # Default date/time when the Linux system clock is not set right is
    # 1/1/1970, which is UTC Epoch time (unix time) 0

# Generated at 2022-06-20 19:14:19.546465
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Create instance of DateTimeFactCollector
    dtfc = DateTimeFactCollector()  # noqa: F841

    # Asserts for method collect of class DateTimeFactCollector
    assert type(dtfc.collect()) is dict

# Generated at 2022-06-20 19:14:30.025778
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    facts = dtfc.collect()
    time_facts = facts['date_time']

    assert len(time_facts) == 20
    assert time_facts.get('year') is not None
    assert time_facts.get('month') is not None
    assert time_facts.get('weekday') is not None
    assert time_facts.get('weekday_number') is not None
    assert time_facts.get('weeknumber') is not None
    assert time_facts.get('day') is not None
    assert time_facts.get('hour') is not None
    assert time_facts.get('minute') is not None
    assert time_facts.get('second') is not None
    assert time_facts.get('epoch') is not None

# Generated at 2022-06-20 19:14:32.798079
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'

# Generated at 2022-06-20 19:14:43.726218
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time = DateTimeFactCollector()
    assert(len(date_time.collect().keys()) == 1)
    print(date_time.collect())

# Generated at 2022-06-20 19:14:46.765219
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj.name == 'date_time'
    assert obj._fact_ids == set()


# Generated at 2022-06-20 19:14:57.527278
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    module = None
    collected_facts = None
    dt_instance = DateTimeFactCollector()
    assert dt_instance.name == 'date_time'
    fact_dict = dt_instance.collect(module, collected_facts)
    assert fact_dict.get('date_time') != None
    assert fact_dict.get('date_time').get('year') != None
    assert fact_dict.get('date_time').get('month') != None
    assert fact_dict.get('date_time').get('weekday') != None
    assert fact_dict.get('date_time').get('weekday_number') != None
    assert fact_dict.get('date_time').get('weeknumber') != None
    assert fact_dict.get('date_time').get('day') != None

# Generated at 2022-06-20 19:15:00.404197
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()
    assert collector.name == 'date_time'
    assert collector._fact_ids == set()

# Generated at 2022-06-20 19:15:13.730101
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = DateTimeFactCollector()
    res = dt.collect()
    _date = datetime.date.today()
    _time = datetime.datetime.now()
    assert res['date_time']['year'] == str(_date.year)
    assert res['date_time']['month'] == str(_date.month)
    assert res['date_time']['weekday'] == str(_date.strftime('%A'))
    assert res['date_time']['weekday_number'] == str(_date.strftime('%w'))
    assert res['date_time']['weeknumber'] == str(_date.strftime('%W'))
    assert res['date_time']['day'] == str(_date.day)
    assert res['date_time']['hour'] == str

# Generated at 2022-06-20 19:15:15.116376
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():	
	pass


# Generated at 2022-06-20 19:15:23.414130
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtf = DateTimeFactCollector()
    dt_facts = dtf.collect()
    assert 'date_time' in dt_facts
    assert type(dt_facts['date_time']) == dict
    # Just test for two random values we expect
    assert 'epoch' in dt_facts['date_time']
    assert 'tz' in dt_facts['date_time']



# Generated at 2022-06-20 19:15:32.891408
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    date_time fact collector test class
    :return:
    """

    # Test function requires to run within an actual ansible run
    # Use following commad for testing
    # ansible localhost -m setup --tree ./tests/files/date_time_test/
    # ansible localhost -m setup --tree ./tests/files/date_time_test/ -a 'filter=ansible_date_time'
    # Expected result:
    # "ansible_date_time": {
    #         "day": "02",
    #         "epoch_int": "1479008800",
    #         "iso8601_basic": "20161102T11192017698272",
    #         "iso8601_basic_short": "20161102T11192017",
    #         "iso8601_

# Generated at 2022-06-20 19:15:45.908360
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-20 19:15:50.229977
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_collector = DateTimeFactCollector()
    assert date_time_collector.name == 'date_time'
    assert isinstance(date_time_collector._fact_ids, set)

# Generated at 2022-06-20 19:16:07.017822
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()

# Generated at 2022-06-20 19:16:11.765692
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt.name == "date_time"
    assert dt._fact_ids == set()



# Generated at 2022-06-20 19:16:21.266244
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    now = datetime.datetime.utcnow()

# Generated at 2022-06-20 19:16:24.481912
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'
    assert dtfc._fact_ids == set()


# Generated at 2022-06-20 19:16:27.918668
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    cfac = DateTimeFactCollector()
    cfac.collect()

# Generated at 2022-06-20 19:16:31.010653
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Test to collect date/time related facts
    """
    date_time_fact_collector = DateTimeFactCollector()
    facts_dict = date_time_fact_collector.collect()
    assert facts_dict['date_time']

# Generated at 2022-06-20 19:16:34.957407
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():

    # Test DateTimeFactCollector without any params
    DateTimeFactCollector()

# Generated at 2022-06-20 19:16:39.169051
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    DateTimeFactCollector_obj = DateTimeFactCollector()
    facts_dict = DateTimeFactCollector_obj.collect()
    assert len(facts_dict) == 1

# Generated at 2022-06-20 19:16:41.636996
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    c = DateTimeFactCollector()
    ansible_facts = dict()

    # Test collection
    result = c.collect(collected_facts=ansible_facts)
    assert result['date_time']['epoch'] != ''

# Generated at 2022-06-20 19:16:44.049332
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    facts = dtfc.collect()
    for fact in facts:
        assert facts[fact] is not None

# Generated at 2022-06-20 19:17:18.194417
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'
    assert isinstance(date_time_fact_collector._fact_ids, set) is True


# Generated at 2022-06-20 19:17:31.198700
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtf = DateTimeFactCollector()
    collected_facts = {}
    dtf.collect(collected_facts=collected_facts)
    assert collected_facts['date_time']['iso8601']
    assert collected_facts['date_time']['iso8601_basic']
    assert collected_facts['date_time']['iso8601_basic_short']
    assert collected_facts['date_time']['iso8601_micro']
    assert collected_facts['date_time']['time']
    assert collected_facts['date_time']['weeknumber']
    assert collected_facts['date_time']['weekday_number']
    assert collected_facts['date_time']['tz']
    assert collected_facts['date_time']['tz_dst']

# Generated at 2022-06-20 19:17:33.181662
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert isinstance(DateTimeFactCollector(None), DateTimeFactCollector)

# Generated at 2022-06-20 19:17:35.637288
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collector = DateTimeFactCollector()
    results = collector.collect()
    assert results['date_time']['month']

# Generated at 2022-06-20 19:17:37.417757
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_facts = DateTimeFactCollector()
    assert date_time_facts.name == 'date_time'
    assert date_time_facts._fact_ids == set()

# Generated at 2022-06-20 19:17:40.376011
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector.name == 'date_time'
    DateTimeFactCollector._fact_ids == set()
    DateTimeFactCollector.name = 'date_time'
    DateTimeFactCollector._fact_ids = set()


# Generated at 2022-06-20 19:17:43.281002
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt.name == 'date_time'

# Generated at 2022-06-20 19:17:55.056980
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    class AnsibleModuleMock():
        pass

    class DateTimeFactCollectorMock(DateTimeFactCollector):

        def __init__(self):

            super(DateTimeFactCollectorMock, self).__init__()

            self.set_cached_facts('date_time', dict())

    datetime_factcollector = DateTimeFactCollectorMock()

    ansible_module = AnsibleModuleMock()
    date_time_facts = datetime_factcollector.collect(ansible_module)

    datetime_facts = date_time_facts['date_time']

    assert datetime_facts['year']
    assert datetime_facts['month']
    assert datetime_facts['weekday']
    assert datetime_facts['weekday_number']
    assert datetime_facts['weeknumber']

# Generated at 2022-06-20 19:17:58.187823
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    c = DateTimeFactCollector()
    assert c.name == 'date_time'
    assert 'date_time' in c._fact_ids

# Generated at 2022-06-20 19:18:01.032316
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    fc = DateTimeFactCollector()
    assert fc.name == 'date_time'
    assert fc._fact_ids == set()


# Generated at 2022-06-20 19:19:08.875413
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtf1 = DateTimeFactCollector()
    assert dtf1._name == 'date_time'
    assert dtf1._fact_ids == set()

# Generated at 2022-06-20 19:19:12.084026
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    my_DateTimeFactCollector = DateTimeFactCollector()
    assert my_DateTimeFactCollector.name == 'date_time'
    assert my_DateTimeFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:19:14.621501
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'


# Generated at 2022-06-20 19:19:16.991603
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector != None
    assert date_time_fact_collector.name == 'date_time'

# Generated at 2022-06-20 19:19:26.787897
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
     
    # Create instance of DateTimeFactCollector
    date_time_fact_collector = DateTimeFactCollector()

    # Validate values of instance attributes
    assert date_time_fact_collector.name == 'date_time'
    assert date_time_fact_collector._fact_ids == set()

    # Check that the method collect is implemented
    assert callable(getattr(date_time_fact_collector, "collect", None))

# Generated at 2022-06-20 19:19:34.250833
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # Arrange: Create a DateTimeFactCollector object and set the epoch variable
    datetime_fact_collector = DateTimeFactCollector()

    # Act: Call the collect method
    result = datetime_fact_collector.collect()

    # Assert: Assert that the result is an object
    assert isinstance(result, object)

# Generated at 2022-06-20 19:19:41.727844
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    ffc = DateTimeFactCollector()

# Generated at 2022-06-20 19:19:43.335635
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'
    assert 'date_time' in x._fact_ids

# Generated at 2022-06-20 19:19:49.615634
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_facts = DateTimeFactCollector().collect()
    assert date_time_facts is not None
    assert date_time_facts['date_time']['date'] != ''
    assert date_time_facts['date_time']['epoch'] != ''
    assert date_time_facts['date_time']['epoch_int'] != ''
    assert date_time_facts['date_time']['iso8601'] != ''
    assert date_time_facts['date_time']['iso8601_basic'] != ''
    assert date_time_facts['date_time']['iso8601_basic_short'] != ''
    assert date_time_facts['date_time']['iso8601_micro'] != ''
    assert date_time_facts['date_time']['month'] != ''


# Generated at 2022-06-20 19:19:53.733096
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'
    assert dtfc._fact_ids == set()

