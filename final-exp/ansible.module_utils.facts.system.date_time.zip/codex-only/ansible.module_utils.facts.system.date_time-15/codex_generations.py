

# Generated at 2022-06-23 00:58:27.906136
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    obj_collector = DateTimeFactCollector()
    facts_dict = obj_collector.collect()

    # The following is the full dictionary that we are expecting

# Generated at 2022-06-23 00:58:38.697222
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fc = DateTimeFactCollector()
    facts = fc.collect()
    assert isinstance(facts, dict)
    assert 'date_time' in facts
    assert isinstance(facts['date_time'], dict)
    # Following keys are always defined
    assert 'date' in facts['date_time']
    assert 'day' in facts['date_time']
    assert 'hour' in facts['date_time']
    assert 'iso8601' in facts['date_time']
    assert 'minute' in facts['date_time']
    assert 'month' in facts['date_time']
    assert 'second' in facts['date_time']
    assert 'time' in facts['date_time']
    assert 'tz' in facts['date_time']
    assert 'tz_dst' in facts['date_time']
   

# Generated at 2022-06-23 00:58:42.108098
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == "date_time"
    assert isinstance(x._fact_ids, set)
    assert len(x._fact_ids) == 0

# Generated at 2022-06-23 00:58:50.098961
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_collector = DateTimeFactCollector()
    ansible_facts = dict()

    # Correct behavior
    result = test_collector.collect(collected_facts=ansible_facts)
    assert isinstance(result, dict)
    assert 'date_time' in result
    assert isinstance(result['date_time']['iso8601'], str)
    assert isinstance(result['date_time']['tz'], str)

    # No effect on collected_facts
    assert ansible_facts == dict()

# Generated at 2022-06-23 00:58:57.253461
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtf = DateTimeFactCollector()
    result = dtf.collect()
    assert 'epoch' in result['date_time']
    assert 'weekday' in result['date_time']
    assert 'day' in result['date_time']
    assert 'hour' in result['date_time']
    assert 'minute' in result['date_time']
    assert 'second' in result['date_time']


# Generated at 2022-06-23 00:59:07.901125
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dc = DateTimeFactCollector()
    # Make sure that the time value don't change while executing the test
    timestamp = datetime.datetime.utcfromtimestamp(time.time())
    facts = dc.collect()

    assert 'date_time' in facts
    assert type(facts['date_time']) is dict
    assert 'year' in facts['date_time']
    assert type(facts['date_time']['year']) is str
    assert facts['date_time']['year'] == timestamp.strftime('%Y')
    assert 'month' in facts['date_time']
    assert type(facts['date_time']['month']) is str
    assert facts['date_time']['month'] == timestamp.strftime('%m')
    assert 'date' in facts['date_time']

# Generated at 2022-06-23 00:59:10.083922
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_facts_obj = DateTimeFactCollector()
    assert date_facts_obj.name == 'date_time'

# Generated at 2022-06-23 00:59:12.361353
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    DateTimeFactCollector_obj = DateTimeFactCollector()
    test_subject = DateTimeFactCollector_obj.collect()
    assert test_subject is not None

# Generated at 2022-06-23 00:59:14.199899
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    c = DateTimeFactCollector()
    result = c.collect()
    print(result)



# Generated at 2022-06-23 00:59:16.746833
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    fact_collector = DateTimeFactCollector()
    assert fact_collector.name == 'date_time'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-23 00:59:20.626555
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.date_time import DateTimeFactCollector
    c = Collector(None, None)
    date_time_collector = DateTimeFactCollector(None, None)
    assert date_time_collector is not None

# Generated at 2022-06-23 00:59:31.043561
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
   def test_facts_many_facts(self):
       class DummyModule(object):
           def __init__(self):
               # Store the timestamp once, then get local and UTC versions from that
               self.epoch_ts = time.time()
               self.now = datetime.datetime.fromtimestamp(self.epoch_ts)
               self.utcnow = datetime.datetime.utcfromtimestamp(self.epoch_ts)

           def get_option(self, option):
               return False

       # Store the timestamp once, then get local and UTC versions from that
       epoch_ts = time.time()
       now = datetime.datetime.fromtimestamp(epoch_ts)
       utcnow = datetime.datetime.utcfromtimestamp(epoch_ts)
       d = DummyModule

# Generated at 2022-06-23 00:59:33.747324
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    datetime_fact_collector = DateTimeFactCollector()
    # Make sure the method returns a type of dict 
    assert isinstance(datetime_fact_collector.collect(), dict)

# Generated at 2022-06-23 00:59:43.761537
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    A unit test for the method collect of class DateTimeFactCollector
    """
    test_module = None
    test_collected_facts = None

    dtfc = DateTimeFactCollector()
    dtfc.collect(test_module, test_collected_facts)

    # Year
    assert(type(dtfc.collect(test_module, test_collected_facts)['date_time']['year']) == str)
    assert(len(dtfc.collect(test_module, test_collected_facts)['date_time']['year']) == 4)
    assert(dtfc.collect(test_module, test_collected_facts)['date_time']['year'][0] == '2')

    # Month

# Generated at 2022-06-23 00:59:48.501227
# Unit test for constructor of class DateTimeFactCollector

# Generated at 2022-06-23 00:59:59.794605
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import ansible.module_utils.facts.collector
    import datetime

    epoch_ts = time.time()
    now = datetime.datetime.fromtimestamp(epoch_ts)
    utcnow = datetime.datetime.utcfromtimestamp(epoch_ts)

    collector = ansible.module_utils.facts.collector.get_collector('DateTimeFactCollector')
    result = collector.collect()
    assert result['date_time']['year'] == now.strftime('%Y')
    assert result['date_time']['month'] == now.strftime('%m')
    assert result['date_time']['weekday'] == now.strftime('%A')
    assert result['date_time']['weekday_number'] == now.strftime('%w')
   

# Generated at 2022-06-23 01:00:02.705324
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    """Test DateTimeFactCollector"""
    date_time_obj = DateTimeFactCollector()
    assert date_time_obj.name == 'date_time'

# Generated at 2022-06-23 01:00:05.064880
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    datetime_fact_collector = DateTimeFactCollector()
    assert datetime_fact_collector is not None


# Generated at 2022-06-23 01:00:07.922925
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    BaseFactCollector.clear_module_cache()
    fact_collector = DateTimeFactCollector()
    collected_facts = fact_collector.collect()
    assert collected_facts['date_time']['hour'] == time.strftime("%H")

# Generated at 2022-06-23 01:00:15.206684
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Test when date_time is not specified in the list of fact_ids to be collected
    DateTimeFactCollector._fact_ids = set()
    DateTimeFactCollector.collect()
    assert 'date_time' not in DateTimeFactCollector._fact_ids

    # Test when date_time is specified in the list of fact_ids to be collected
    DateTimeFactCollector._fact_ids = set(['date_time'])
    DateTimeFactCollector.collect()
    assert 'date_time' in DateTimeFactCollector._fact_ids

# Generated at 2022-06-23 01:00:18.974900
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_facts = DateTimeFactCollector()
    assert date_time_facts.name == 'date_time'
    assert date_time_facts._fact_ids == set()


# Generated at 2022-06-23 01:00:29.412256
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import time

    # Creating a class instance
    date_time_fact_collector_instance = DateTimeFactCollector()

    # Testing the method with a mocked object
    facts_dict = {}
    date_time_facts = {}

    # Store the timestamp once, then get local and UTC versions from that
    epoch_ts = time.time()
    now = datetime.datetime.fromtimestamp(epoch_ts)
    utcnow = datetime.datetime.utcfromtimestamp(epoch_ts)

    date_time_facts['year'] = now.strftime('%Y')
    date_time_facts['month'] = now.strftime('%m')
    date_time_facts['weekday'] = now.strftime('%A')
    date_time_facts['weekday_number'] = now.strftime

# Generated at 2022-06-23 01:00:33.463549
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    module = None
    collected_facts = None
    facts_collector = DateTimeFactCollector()
    facts_collector.collect(module, collected_facts)
    assert isinstance(facts_collector, DateTimeFactCollector)

# Generated at 2022-06-23 01:00:42.848248
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Unit tests for class DateTimeFactCollector"""
    # Import libraries
    import ansible.module_utils.facts.collector

    # Collect date_time facts
    dt_fc = DateTimeFactCollector()
    dt_facts = dt_fc.collect()

    # Check value of month
    assert dt_facts['date_time']['month'] == datetime.datetime.now().strftime('%m')

    # Check value of date
    assert dt_facts['date_time']['date'] == datetime.datetime.now().strftime('%Y-%m-%d')

    # Check value of day
    assert dt_facts['date_time']['day'] == datetime.datetime.now().strftime('%d')

    # Check value of weeknumber
    assert dt

# Generated at 2022-06-23 01:00:46.425751
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collector = DateTimeFactCollector()
    collected_facts = collector.collect()
    assert isinstance(collected_facts, dict) == True
    assert 'date_time' in collected_facts == True
    assert isinstance(collected_facts['date_time'], dict) == True
    assert isinstance(collected_facts['date_time']['epoch'], str) == True
    assert isinstance(collected_facts['date_time']['epoch_int'], str) == True
    assert collected_facts['date_time']['epoch'] == collected_facts['date_time']['epoch_int'] == True
    assert len(collected_facts['date_time']['epoch']) > 0

# Generated at 2022-06-23 01:00:50.477155
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtf = DateTimeFactCollector()
    collected_facts = dtf.collect()
    assert 'date_time' in collected_facts

# Generated at 2022-06-23 01:00:54.734072
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    ans_date_time = DateTimeFactCollector()
    ans_date_time.collect()
    values = ans_date_time.get_facts()
    assert True == ans_date_time.has_facts(values)



# Generated at 2022-06-23 01:00:55.987072
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    fact_collector.collect()

# Generated at 2022-06-23 01:00:58.138883
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_created = DateTimeFactCollector()
    assert date_time_created.name == "date_time"
    assert date_time_created._fact_ids == set()

# Generated at 2022-06-23 01:01:03.290183
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    mod = None
    fact_collector = DateTimeFactCollector(mod)
    result = fact_collector.collect()
    assert result['date_time']['tz'] == time.strftime("%Z")

# Generated at 2022-06-23 01:01:05.627943
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()
    assert collector.name == 'date_time'
    assert 'date_time' in collector._fact_ids

# Generated at 2022-06-23 01:01:15.851151
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    collected_facts = fact_collector.collect()

    assert 'date_time' in collected_facts
    expected_date_time_facts = ['year', 'month', 'weekday', 'weekday_number',
            'weeknumber', 'day', 'hour', 'minute', 'second', 'epoch',
            'epoch_int', 'date', 'time', 'iso8601_micro', 'iso8601',
            'iso8601_basic', 'iso8601_basic_short', 'tz', 'tz_dst', 'tz_offset']
    for fact in expected_date_time_facts:
        assert fact in collected_facts['date_time']

# Generated at 2022-06-23 01:01:18.116011
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj.name == 'date_time'
    assert obj._fact_ids == set()

# Generated at 2022-06-23 01:01:21.422889
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    # There are no constructor parameters for DateTimeFactCollector so there is nothing to test

# Generated at 2022-06-23 01:01:24.527396
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    mydate = DateTimeFactCollector()
    assert isinstance(mydate, DateTimeFactCollector)
    assert mydate.name == 'date_time'


# Generated at 2022-06-23 01:01:31.469326
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Unit tests for DateTimeFactCollector.collect()"""

    datetime_facts = DateTimeFactCollector()

    # Prepare the test case
    loaded_facts = {}
    test_module = None

    # Test the module action
    datetime_facts.collect(test_module, loaded_facts)

    # Test collected_facts
    assert loaded_facts['date_time']['year'] != ''
    assert loaded_facts['date_time']['month'] != ''
    assert loaded_facts['date_time']['weekday'] != ''
    assert loaded_facts['date_time']['weekday_number'] != ''
    assert loaded_facts['date_time']['weeknumber'] != ''
    assert loaded_facts['date_time']['day'] != ''

# Generated at 2022-06-23 01:01:40.907029
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-23 01:01:49.321847
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'
    assert dtfc._fact_ids == set()

    # test collect() of DateTimeFactCollector class
    # collects date_time facts
    results = dtfc.collect()
    assert 'date_time' in results
    assert results['date_time']['weekday'] == time.strftime("%A")

# Generated at 2022-06-23 01:01:54.604284
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert isinstance(x, DateTimeFactCollector)
    assert x.name == "date_time"
    assert isinstance(x._fact_ids, set)
    assert len(x._fact_ids) == 0


# Generated at 2022-06-23 01:01:56.526422
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_collector = DateTimeFactCollector()
    date_time_collector.collect()

# Generated at 2022-06-23 01:01:57.246175
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    fc = DateTimeFactCollector()
    assert fc.name == 'date_time'

# Generated at 2022-06-23 01:02:01.380560
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Create instance of DateTimeFactCollector
    dt = DateTimeFactCollector()
    # Check name of class
    assert dt.name == 'date_time'
    # Check if _fact_ids sets correctly
    assert dt._fact_ids == set()


# Generated at 2022-06-23 01:02:05.752466
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'
    assert hasattr(date_time_fact_collector, '_fact_ids')

# Generated at 2022-06-23 01:02:07.594030
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    s = DateTimeFactCollector()
    assert s.name == 'date_time'

# Generated at 2022-06-23 01:02:18.025974
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Unit test for method collect of class DateTimeFactCollector
    """
    obj = DateTimeFactCollector()
    output = obj.collect()
    assert 'date_time' in output, 'Date_time is not in output'
    assert 'weekday' in output['date_time'], 'weekday is not in output'
    assert 'weeknumber' in output['date_time'], 'weeknumber is not in output'
    assert 'day' in output['date_time'], 'day is not in output'
    assert 'hour' in output['date_time'], 'hour is not in output'
    assert 'minute' in output['date_time'], 'minute is not in output'
    assert 'second' in output['date_time'], 'second is not in output'

# Generated at 2022-06-23 01:02:20.530618
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    my_dtfc = DateTimeFactCollector()
    assert my_dtfc.name == 'date_time'



# Generated at 2022-06-23 01:02:25.825968
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Unit test for method DateTimeFactCollector.collect()
    fact_collector = DateTimeFactCollector(None, {})
    result = fact_collector.collect()

    assert result is not None
    assert len(result) != 0
    assert result.get('date_time') is not None
    assert result.get('date_time').get('weekday') is not None

# Generated at 2022-06-23 01:02:37.795715
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Check if the method collect returns expected result.
    # Mock class attributes of the datetime.datetime class
    datetime.datetime.now = lambda *args, **kw: datetime.datetime(1, 1, 1)
    datetime.datetime.utcnow  = lambda *args, **kw: datetime.datetime(1, 1, 1)
    datetime.datetime.strftime = lambda *args, **kw: "strftime_mocked_now"
    datetime.datetime.fromtimestamp = lambda *args, **kw: datetime.datetime(1, 1, 1)
    datetime.datetime.utcfromtimestamp = lambda *args, **kw: datetime.datetime(1, 1, 1)

# Generated at 2022-06-23 01:02:46.776561
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    now = datetime.datetime.now()
    utcnow = datetime.datetime.utcnow()
    epoch_ts = time.time()
    test = DateTimeFactCollector()

    # test when epoch_ts is casted to int
    epoch_ts = int(epoch_ts)
    facts_dict = test.collect()
    assert facts_dict['date_time']['year'] == now.strftime('%Y')
    assert facts_dict['date_time']['month'] == now.strftime('%m')
    assert facts_dict['date_time']['weekday'] == now.strftime('%A')
    assert facts_dict['date_time']['weekday_number'] == now.strftime('%w')
    assert facts_dict['date_time']['weeknumber']

# Generated at 2022-06-23 01:02:53.705340
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Test method `DateTimeFactCollector.collect()`"""
    import json
    import tempfile

    tmpfile = tempfile.NamedTemporaryFile()

    # Check if empty facts file
    fs = DateTimeFactCollector()
    fs.collect()

    fs = DateTimeFactCollector()
    facts = fs.collect()

    tmpfile.write(json.dumps(facts).encode())
    tmpfile.flush()

    with open(tmpfile.name) as f:
        for line in f.readlines():
            if "date_time" in line:
                assert isinstance(json.loads(line), dict)

    tmpfile.close()

# Generated at 2022-06-23 01:03:04.477971
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj.name == 'date_time'

    # we need to mock, not just the date, but the date's format
    # we don't collect date, just parse it from the epoch, which
    # we parcel out instead
    obj.now = datetime.datetime.now()
    obj.epoch_ts = time.time()
    obj.utcnow = datetime.datetime.utcfromtimestamp(int(obj.epoch_ts))

    time.strftime = lambda x: 'test_time_strftime'
    time.tzname = ('test_time_tzname[0]', 'test_time_tzname[1]')
    obj.now.strftime = lambda x: 'test_strftime'

# Generated at 2022-06-23 01:03:06.694965
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    myDateTimeFactCollector = DateTimeFactCollector()
    assert myDateTimeFactCollector.name == 'date_time'

# Generated at 2022-06-23 01:03:10.273017
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'
    assert date_time_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:03:12.274234
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_collector = DateTimeFactCollector()
    assert date_time_collector.name == 'date_time'

# Generated at 2022-06-23 01:03:17.476584
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    EpochInt = str(int(time.time()))
    Epoch = str(int(time.time()))
    if Epoch == '' or Epoch[0] == '%':
        Epoch = str(int(time.time()))
    WeekNumber = time.strftime("%W")
    # Collect date_time facts
    date_time_fact = DateTimeFactCollector()
    date_time_facts = date_time_fact.collect()
    # Check for expected collected facts
    assert date_time_facts['date_time']['year'] == time.strftime("%Y")
    assert date_time_facts['date_time']['month'] == time.strftime("%m")
    assert date_time_facts['date_time']['weekday'] == time.strftime("%A")
   

# Generated at 2022-06-23 01:03:30.001849
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_facts = DateTimeFactCollector()

    assert date_time_facts.name == 'date_time'
    assert date_time_facts._fact_ids == set()

    epoch_ts = time.time()
    now = datetime.datetime.fromtimestamp(epoch_ts)
    utcnow = datetime.datetime.utcfromtimestamp(epoch_ts)
    assert type(date_time_facts.collect()['date_time']['year']) == str
    assert type(date_time_facts.collect()['date_time']['month']) == str
    assert type(date_time_facts.collect()['date_time']['weekday']) == str

# Generated at 2022-06-23 01:03:32.705232
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector().name == 'date_time'
    assert set(DateTimeFactCollector()._fact_ids) == {'date_time'}

# Generated at 2022-06-23 01:03:37.694377
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = DateTimeFactCollector()
    collected_facts = dt.collect()
    assert isinstance(collected_facts, dict)
    assert 'date_time' in collected_facts
    assert len(collected_facts['date_time']) >= 14
    assert 'tz' in collected_facts['date_time']
    # assert 'date' in collected_facts['date_time']

# Generated at 2022-06-23 01:03:49.164703
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact = DateTimeFactCollector()
    date_time = date_time_fact.collect()
    # date_time.exist: True
    assert date_time.get('date_time').get('year')
    assert date_time.get('date_time').get('month')
    assert date_time.get('date_time').get('weekday')
    assert date_time.get('date_time').get('weekday_number')
    assert date_time.get('date_time').get('weeknumber')
    assert date_time.get('date_time').get('day')
    assert date_time.get('date_time').get('hour')
    assert date_time.get('date_time').get('minute')
    assert date_time.get('date_time').get('second')
    assert date

# Generated at 2022-06-23 01:03:53.008664
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt.name == 'date_time'
    assert dt._fact_ids == set()


# Generated at 2022-06-23 01:03:55.447419
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()
    assert collector.name == 'date_time'
    assert collector.collect() is not None

# Generated at 2022-06-23 01:04:05.833102
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Setup
    date_time_facts = {}
    date_time_facts['year'] = "2019"
    date_time_facts['month'] = "01"
    date_time_facts['weekday'] = "Tuesday"
    date_time_facts['weekday_number'] = "2"
    date_time_facts['weeknumber'] = "1"
    date_time_facts['day'] = "01"
    date_time_facts['hour'] = "15"
    date_time_facts['minute'] = "31"
    date_time_facts['second'] = "15"
    date_time_facts['epoch'] = "1546325075"
    date_time_facts['epoch_int'] = "1546325075"

# Generated at 2022-06-23 01:04:09.067833
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt_collector = DateTimeFactCollector()
    assert isinstance(dt_collector, DateTimeFactCollector)
    assert dt_collector.name == "date_time"

# Generated at 2022-06-23 01:04:10.146648
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector.name == 'date_time'
    assert DateTimeFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:04:12.698082
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    d = DateTimeFactCollector()
    assert d.name == 'date_time'
    assert d._fact_ids == set()

# Generated at 2022-06-23 01:04:15.884291
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'

# Generated at 2022-06-23 01:04:20.267868
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import doctest
    from ansible.module_utils.facts import FactCollector
    doctest.testmod(FactCollector)

if __name__ == '__main__':
    test_DateTimeFactCollector_collect()

# Generated at 2022-06-23 01:04:22.910424
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'
    assert dtfc._fact_ids == set()


# Generated at 2022-06-23 01:04:31.423975
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # A real epoch timestamp to use for testing.
    epoch_ts = 1503569515.571771
    dtfc = DateTimeFactCollector()

    # Patch the time method with a known time.
    with mock.patch.object(dtfc, 'date_time') as date_time:
        date_time.time.return_value = epoch_ts
        date_time.tzname.return_value = ('EDT', 'EST')

        result = dtfc.collect()


# Generated at 2022-06-23 01:04:34.382089
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'
    assert len(dtfc._fact_ids) == 0

# Generated at 2022-06-23 01:04:42.321265
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    test_dict = fact_collector.collect()
    # Test epoch_int key
    assert 'epoch_int' in test_dict.get('date_time').keys()
    # Test epoch_int key
    assert 'iso8601_basic_short' in test_dict.get('date_time').keys()

# Generated at 2022-06-23 01:04:44.884629
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    result = dtfc.collect()
    assert result['date_time']['iso8601_micro'].endswith('Z')

# Generated at 2022-06-23 01:04:55.084382
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtf = DateTimeFactCollector()
    collected_facts = { 'date_time': {} }
    dtf.collect(collected_facts=collected_facts)

# Generated at 2022-06-23 01:04:57.839919
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'
    assert x._fact_ids == set()


# Generated at 2022-06-23 01:05:07.661427
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Test method collect of class DateTimeFactCollector
    """
    # Initialize empty dict for collected facts
    collected_facts = dict()
    # Initialize class instance
    date_time_fact_collector = DateTimeFactCollector()
    # Execute method collect
    date_time_facts = date_time_fact_collector.collect(collected_facts=collected_facts)
    # Check if the method returned a dict as expected
    assert isinstance(date_time_facts, dict)
    # Check if the returned dict contains a key 'date_time'
    assert 'date_time' in date_time_facts
    # Check if the returned dict['date_time'] is a dict itself
    assert isinstance(date_time_facts['date_time'], dict)
    # Check if the returned dict['date_time

# Generated at 2022-06-23 01:05:16.956345
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()

    assert dtfc.name == 'date_time', 'name of DateTimeFactCollector should be \'date_time\', but it is {0}'.format(dtfc.name)
    assert dtfc.priority == 85, 'priority of DateTimeFactCollector should be 85, but it is {0}'.format(dtfc.priority)
    assert dtfc._fact_ids == set(), '_fact_ids of DateTimeFactCollector should be empty, but it is {0}'.format(dtfc._fact_ids)
    assert dtfc.required_module == 'datetime', 'required_module of DateTimeFactCollector should be \'datetime\', but it is {0}'.format(dtfc.required_module)


# Generated at 2022-06-23 01:05:27.299243
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    assert dtfc is not None

    facts_dict = dtfc.collect()
    assert facts_dict is not None
    date_time_facts = facts_dict['date_time']
    assert date_time_facts is not None
    assert 'year' in date_time_facts
    assert 'month' in date_time_facts
    assert 'weekday' in date_time_facts
    assert 'weekday_number' in date_time_facts
    assert 'weeknumber' in date_time_facts
    assert 'day' in date_time_facts
    assert 'hour' in date_time_facts
    assert 'minute' in date_time_facts
    assert 'second' in date_time_facts
    assert 'epoch' in date_time_facts

# Generated at 2022-06-23 01:05:38.692403
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    datetime_facts = DateTimeFactCollector()
    date_time_facts = datetime_facts.collect()
    assert 'second' in date_time_facts["date_time"]
    assert 'date' in date_time_facts["date_time"]
    assert 'time' in date_time_facts["date_time"]
    assert 'iso8601_micro' in date_time_facts["date_time"]
    assert 'iso8601' in date_time_facts["date_time"]
    assert 'iso8601_basic' in date_time_facts["date_time"]
    assert 'iso8601_basic_short' in date_time_facts["date_time"]
    assert 'tz' in date_time_facts["date_time"]
    assert 'tz_dst' in date_time_facts["date_time"]

# Generated at 2022-06-23 01:05:50.114300
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = DateTimeFactCollector()

    facts_dict = dt.collect()

    assert type(facts_dict) is dict
    assert 'date_time' in facts_dict
    assert type(facts_dict['date_time']) is dict
    assert 'year' in facts_dict['date_time']
    assert 'month' in facts_dict['date_time']
    assert 'weekday' in facts_dict['date_time']
    assert 'weekday_number' in facts_dict['date_time']
    assert 'weeknumber' in facts_dict['date_time']
    assert 'day' in facts_dict['date_time']
    assert 'hour' in facts_dict['date_time']
    assert 'minute' in facts_dict['date_time']

# Generated at 2022-06-23 01:05:57.441967
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    '''
    Unit test for method collect of class DateTimeFactCollector
    '''
    d_t_fact_coll = DateTimeFactCollector()
    facts = d_t_fact_coll.collect()
    # 2036-02-07T06:28:16Z
    assert(facts['date_time']['year'] == '2036')
    assert(facts['date_time']['month'] == '02')
    assert(facts['date_time']['day'] == '07')
    assert(facts['date_time']['hour'] == '06')
    assert(facts['date_time']['minute'] == '28')
    assert(facts['date_time']['second'] == '16')
    assert(facts['date_time']['epoch'] == '2021341296')


# Generated at 2022-06-23 01:06:05.912180
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collector = DateTimeFactCollector()
    facts_dict = collector.collect()
    assert 'date_time' in facts_dict
    assert 'epoch_int' in facts_dict['date_time']
    assert 'epoch' in facts_dict['date_time']
    assert isinstance(int(facts_dict['date_time']['epoch_int']), int)
    assert isinstance(int(facts_dict['date_time']['epoch']), int)

# Generated at 2022-06-23 01:06:16.053490
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_collector = DateTimeFactCollector()
    res = date_time_collector.collect()
    assert 'date_time' in res
    assert 'year' in res['date_time']
    assert 'month' in res['date_time']
    assert 'weekday' in res['date_time']
    assert 'weekday_number' in res['date_time']
    assert 'weeknumber' in res['date_time']
    assert 'day' in res['date_time']
    assert 'hour' in res['date_time']
    assert 'minute' in res['date_time']
    assert 'second' in res['date_time']
    assert 'date' in res['date_time']
    assert 'time' in res['date_time']
    assert 'epoch' in res['date_time']

# Generated at 2022-06-23 01:06:20.563471
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector.name == 'date_time'
    assert DateTimeFactCollector._fact_ids is not None
    assert type(DateTimeFactCollector._fact_ids) == set

# Generated at 2022-06-23 01:06:24.317732
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    f = DateTimeFactCollector()
    assert f.name == 'date_time'
    assert f._fact_ids == set()

# Generated at 2022-06-23 01:06:36.392277
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collector = DateTimeFactCollector()
    res = collector.collect()
    assert res['date_time']['year'] == '2018'
    assert res['date_time']['month'] == '09'
    assert res['date_time']['weekday'] == 'Wednesday'
    assert res['date_time']['weekday_number'] == '3'
    assert int(res['date_time']['weeknumber']) >= 36
    assert int(res['date_time']['day']) >= 1
    assert int(res['date_time']['hour']) >= 12
    assert int(res['date_time']['minute']) >= 30
    assert int(res['date_time']['second']) >= 30
    assert res['date_time']['epoch'] != ''

# Generated at 2022-06-23 01:06:38.999406
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'

# Generated at 2022-06-23 01:06:40.500812
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'



# Generated at 2022-06-23 01:06:53.451881
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    result = {}
    now = datetime.datetime.now()
    utcnow = datetime.datetime.utcnow()
    time_tuple = time.localtime()
    time_tuple_utc = time.gmtime()

# Generated at 2022-06-23 01:06:55.716402
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'
    assert dtfc._fact_ids == set()


# Generated at 2022-06-23 01:07:03.416739
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    test_obj = DateTimeFactCollector()

    # test with normal run
    result = test_obj.collect()

    # assert expected results
    assert 'date_time' in result
    date_time = result['date_time']
    assert isinstance(date_time, dict)

    assert 'year' in date_time
    assert date_time['year'] == datetime.datetime.now().strftime('%Y')

    assert 'month' in date_time
    assert date_time['month'] == datetime.datetime.now().strftime('%m')

    assert 'weekday' in date_time
    assert date_time['weekday'] == datetime.datetime.now().strftime('%A')

    assert 'weekday_number' in date_time
    assert date_time['weekday_number'] == dat

# Generated at 2022-06-23 01:07:14.125895
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Arrange
    module = None

# Generated at 2022-06-23 01:07:18.663992
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_object = DateTimeFactCollector()
    test_object.collect()
    # This test returns a dictionary - it would be better if it returned a string
    #assert(test_object.get_fact_names() == ['date_time'])
    #assert(test_object.get_fact('date_time') == 'date_time')

# Generated at 2022-06-23 01:07:23.947538
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Constructor of class DateTimeFactCollector
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'
    if type(date_time_fact_collector._fact_ids) not in (set, frozenset, list, tuple):
        raise AssertionError()


# Generated at 2022-06-23 01:07:25.169593
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Unit test for constructor of class VersionFactCollector
    DateTimeFactCollector()

# Generated at 2022-06-23 01:07:26.693623
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_obj = DateTimeFactCollector()
    test_obj.collect()

# Generated at 2022-06-23 01:07:29.459350
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_obj = DateTimeFactCollector()
    assert date_time_obj.name == 'date_time'

# Generated at 2022-06-23 01:07:34.991477
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Unit test for method collect of class DateTimeFactCollector
    """
    # TODO: remove me when 2.0 is the standard
    dt_fc = DateTimeFactCollector()
    assert dt_fc.collect() == dt_fc.collect(None)
    assert isinstance(dt_fc.collect(), dict)
    assert 'date_time' in dt_fc.collect()

# Generated at 2022-06-23 01:07:38.081229
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    op1 = DateTimeFactCollector()
    assert op1.name == "date_time"
    assert op1._fact_ids == set()


# Generated at 2022-06-23 01:07:49.589880
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    obj = DateTimeFactCollector()
    results = obj.collect()
    time_string = time.ctime().split(' ')
    month_map = {'Jan': '01',
                 'Feb': '02',
                 'Mar': '03',
                 'Apr': '04',
                 'May': '05',
                 'Jun': '06',
                 'Jul': '07',
                 'Aug': '08',
                 'Sep': '09',
                 'Oct': '10',
                 'Nov': '11',
                 'Dec': '12'}
    weekday_map = {'Mon': 0,
                   'Tue': 1,
                   'Wed': 2,
                   'Thu': 3,
                   'Fri': 4,
                   'Sat': 5,
                   'Sun': 6}


# Generated at 2022-06-23 01:07:50.781683
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'

# Generated at 2022-06-23 01:07:52.356277
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj.name == 'date_time'



# Generated at 2022-06-23 01:08:05.401439
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    epoch = 1470010800
    d = DateTimeFactCollector()
    d._module = None
    d._collect_debug_info = False
    d._collect_subset = None
    d._gather_subset = None
    d._collected_facts = {}
    d._collect_subset = []
    date_time_facts = d.collect(datetime.datetime.utcfromtimestamp(epoch))['date_time']

    assert date_time_facts['year'] == '2016'
    assert date_time_facts['month'] == '08'
    assert date_time_facts['weekday'] == 'Monday'
    assert date_time_facts['weekday_number'] == '1'
    assert date_time_facts['weeknumber'] == '32'
    assert date_time_facts['day']

# Generated at 2022-06-23 01:08:07.500525
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    facts_collector = DateTimeFactCollector()
    assert facts_collector is not None

# Generated at 2022-06-23 01:08:08.824291
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == "date_time"

# Generated at 2022-06-23 01:08:12.925674
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'
    assert date_time_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:08:15.392350
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'

# Generated at 2022-06-23 01:08:22.144983
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtf_collector = DateTimeFactCollector()
    result_dict = dtf_collector.collect()
    assert type(result_dict) == dict
    assert 'date_time' in result_dict
    assert type(result_dict['date_time']) == dict
    assert 'date' in result_dict['date_time']
    assert 'time' in result_dict['date_time']
    assert 'epoch_int' in result_dict['date_time']