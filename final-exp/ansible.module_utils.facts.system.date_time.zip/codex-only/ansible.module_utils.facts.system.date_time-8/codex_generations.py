

# Generated at 2022-06-23 00:58:23.269694
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt._fact_ids == set()
    assert dt.name == 'date_time'


# Generated at 2022-06-23 00:58:27.087963
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_obj = DateTimeFactCollector()
    assert date_time_obj.name == 'date_time'
    assert date_time_obj.priority == 70
    assert date_time_obj._fact_ids == set()


# Generated at 2022-06-23 00:58:30.833483
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()
    assert collector.name == 'date_time'
    assert collector._fact_ids == set()

# Generated at 2022-06-23 00:58:40.089214
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """DateTimeFactCollector - gather date and time facts is working as expected.

    :return:
    """
    # Set up class instance to be tested.
    dtf = DateTimeFactCollector()

    # Set up a sample for testing.

# Generated at 2022-06-23 00:58:49.993991
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_facts_dict = date_time_fact_collector.collect()
    assert isinstance(date_time_facts_dict, dict)
    assert 'date_time' in date_time_facts_dict.keys()
    assert 'epoch' in date_time_facts_dict['date_time'].keys()
    assert 'epoch_int' in date_time_facts_dict['date_time'].keys()
    assert 'date' in date_time_facts_dict['date_time'].keys()
    assert 'time' in date_time_facts_dict['date_time'].keys()
    assert 'year' in date_time_facts_dict['date_time'].keys()
    assert 'month' in date_time_facts_

# Generated at 2022-06-23 00:58:52.287671
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'

# Generated at 2022-06-23 00:59:03.491404
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import datetime
    import time
    import pytz

    # Testing date_time facts
    date_time = DateTimeFactCollector()
    facts = date_time.collect()
    now_utc = datetime.datetime.now(pytz.utc)

    assert 'date_time' in facts
    assert facts['date_time']['date'] == now_utc.strftime('%Y-%m-%d')
    assert facts['date_time']['time'] == now_utc.strftime('%H:%M:%S')
    assert facts['date_time']['iso8601'] == now_utc.strftime('%Y-%m-%dT%H:%M:%SZ')
    assert facts['date_time']['iso8601_micro'] == now_

# Generated at 2022-06-23 00:59:13.136199
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.date_time import DateTimeFactCollector
    import datetime
    import time

    # create an instance of the DateTimeFactCollector class
    date_time_fact_collector = DateTimeFactCollector()

    # create an instance of the BaseFactCollector class
    base_fact_collector = BaseFactCollector()

    # create an instance of the ActiveCollectorsDict class
    active_collectors_dict = collector.ActiveCollectorsDict()

    # set the instance of the DateTimeFactCollector class in the active collectors dict
    active_collectors_dict.set_collector('date_time', date_time_fact_collector)

# Generated at 2022-06-23 00:59:16.791284
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_facts_collector = DateTimeFactCollector()
    assert date_time_facts_collector is not None
    assert date_time_facts_collector.name == "date_time"
    assert len(date_time_facts_collector._fact_ids) == 0

# Generated at 2022-06-23 00:59:24.366720
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible_collections.ansible.community.plugins.module_utils.facts.collector import BaseFactCollector
    from ansible_collections.ansible.community.plugins.module_utils.facts.collector import Collector
    from ansible_collections.ansible.community.plugins.module_utils import facts
    import datetime
    import unittest

    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set()

        def collect(self, module=None, collected_facts=None):
            facts_dict = {'test': {'foo': 'bar'}}
            return facts_dict

    class Test2Collector(BaseFactCollector):
        name = 'test2'
        _fact_ids = set()


# Generated at 2022-06-23 00:59:37.489997
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    '''Unit test for constructor of class DateTimeFactCollector'''
    date_time_facts = DateTimeFactCollector()
    date_time_facts_data = date_time_facts.collect()

    assert date_time_facts_data['date_time']['year'] == time.strftime('%Y')
    assert date_time_facts_data['date_time']['month'] == time.strftime('%m')
    assert date_time_facts_data['date_time']['weekday'] == time.strftime('%A')
    assert date_time_facts_data['date_time']['weekday_number'] == time.strftime('%w')
    assert date_time_facts_data['date_time']['weeknumber'] == time.strftime('%W')
    assert date_time

# Generated at 2022-06-23 00:59:39.016685
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert isinstance(DateTimeFactCollector(), BaseFactCollector)

# Generated at 2022-06-23 00:59:42.704722
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact = DateTimeFactCollector()
    results = fact.collect()

    assert results['date_time']['time'] is not None
    assert results['date_time']['epoch_int'] is not None
    assert results['date_time']['epoch'] is not None

# Generated at 2022-06-23 00:59:44.607151
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_collector = DateTimeFactCollector()
    assert date_time_collector.name == 'date_time'

# Generated at 2022-06-23 00:59:51.841902
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_facts = DateTimeFactCollector()

# Generated at 2022-06-23 00:59:54.938726
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    ansible_date_time = DateTimeFactCollector()
    assert ansible_date_time.name == 'date_time'

# Generated at 2022-06-23 00:59:58.033342
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    fc = DateTimeFactCollector()
    assert fc.name == 'date_time'
    assert fc._fact_ids == set()


# Generated at 2022-06-23 01:00:01.028345
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_collector = DateTimeFactCollector()
    assert date_collector.name == "date_time"
    assert 'date_time' in date_collector._fact_ids


# Generated at 2022-06-23 01:00:03.345109
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact = DateTimeFactCollector()
    result = fact.collect()
    assert result['date_time']['year'] == str(datetime.datetime.today().year)

# Generated at 2022-06-23 01:00:06.930891
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    datetime_fact_test = DateTimeFactCollector()

    # Test the constructor of the class DateTimeFactCollector was successful
    assert isinstance(datetime_fact_test, DateTimeFactCollector)

    # Test the collect() method of the class DateTimeFactCollector was successful
    datetime_fact_test.collect()

# Generated at 2022-06-23 01:00:15.923620
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector

    dtfc = DateTimeFactCollector()
    assert isinstance(dtfc, BaseFactCollector)

    facts_dict = dtfc.collect()
    assert isinstance(facts_dict, dict)

    collector = Collector(module=None)
    collector.collect(dtfc)
    assert collector.exists(dtfc.name)

    assert collector.collect(dtfc) == {dtfc.name: dtfc.collect()[dtfc.name]}


# Generated at 2022-06-23 01:00:18.504707
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'

# Generated at 2022-06-23 01:00:24.476071
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dateTimeFactCollector = DateTimeFactCollector()

    # Assert that inherited class members are initialised correctly
    assert dateTimeFactCollector.name == 'date_time'
    assert dateTimeFactCollector._fact_ids == set()

    # Assert that inherited method collect functions as expected
    from ansible.module_utils.facts import ansible_collector
    ansible_collector.collect_all()
    ansible_collector.collect_all()

# Generated at 2022-06-23 01:00:33.985491
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtf = DateTimeFactCollector()
    # date_time[u'epoch_int'] and date_time[u'epoch'] should be equal
    # date_time[u'epoch_int'] should be int
    # date_time[u'epoch'] should be str
    # date_time[u'date'] and date_time[u'time'] should be equal
    # date_time[u'date'] should have length 10
    # date_time[u'time'] should have length 8
    # date_time[u'iso8601_micro'] should have length 24
    # date_time[u'iso8601'] should have length 20
    # date_time[u'iso8601_basic'] should have length 21
    # date_time[u'iso8601_basic_short'] should have length 16


# Generated at 2022-06-23 01:00:47.062507
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    f = DateTimeFactCollector()
    r = f.collect()
    # import json to check the values
    # print json.dumps(r)
    assert 'date_time' in r
    assert 'date_time' in r
    assert 'epoch' in r['date_time']
    assert 'date' in r['date_time']
    assert 'time' in r['date_time']
    assert 'year' in r['date_time']
    assert 'month' in r['date_time']
    assert 'weekday' in r['date_time']
    assert 'weekday_number' in r['date_time']
    assert 'weeknumber' in r['date_time']
    assert 'day' in r['date_time']
    assert 'hour' in r['date_time']
    assert 'minute'

# Generated at 2022-06-23 01:00:51.571358
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():

    # Create object of class DateTimeFactCollector
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector is not None

# Generated at 2022-06-23 01:00:53.910643
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'



# Generated at 2022-06-23 01:01:01.938627
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import time
    epoch_ts = time.time()
    now = datetime.datetime.fromtimestamp(epoch_ts)

# Generated at 2022-06-23 01:01:04.809897
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Use the 'localtime' implementation for the test so that neither
    # time nor datetime module will be mocked
    DateTimeFactCollector(localtime=True)

# Generated at 2022-06-23 01:01:07.937204
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    DateTimeFactCollector().collect()

# Generated at 2022-06-23 01:01:09.913339
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Create instance of DateTimeFactCollector
    DateTimeFactCollector()

# Generated at 2022-06-23 01:01:22.837409
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    results = dtfc.collect()
    assert results['date_time']
    assert results['date_time']['year']
    assert results['date_time']['month']
    assert results['date_time']['date']
    assert results['date_time']['time']
    assert results['date_time']['weekday']
    assert results['date_time']['weekday_number']
    assert results['date_time']['weeknumber']
    assert results['date_time']['day']
    assert results['date_time']['hour']
    assert results['date_time']['minute']
    assert results['date_time']['second']
    assert results['date_time']['epoch']

# Generated at 2022-06-23 01:01:27.064732
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    fc = DateTimeFactCollector()
    assert isinstance(fc, DateTimeFactCollector)
    assert fc.name == 'date_time'
    expected_fact_ids = set()
    assert fc._fact_ids == expected_fact_ids


# Generated at 2022-06-23 01:01:34.089900
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dateTimeFactCollector = DateTimeFactCollector()
    assert isinstance(dateTimeFactCollector, DateTimeFactCollector) == True
    assert isinstance(dateTimeFactCollector, BaseFactCollector) == True
    assert dateTimeFactCollector.name == 'date_time'
    assert isinstance(dateTimeFactCollector._fact_ids, set) == True


# Generated at 2022-06-23 01:01:35.392744
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()
    assert collector.name == "date_time"

# Generated at 2022-06-23 01:01:40.569420
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Instance of DateTimeFactCollector
    dt_facts = DateTimeFactCollector()
    # Attributes of DateTimeFactCollector
    assert dt_facts.name == 'date_time'
    assert dt_facts.priority == 80
    assert dt_facts._fact_ids == set()


# Generated at 2022-06-23 01:01:45.472955
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector.name == 'date_time'
    collector = DateTimeFactCollector()
    assert collector.name == 'date_time'

# Generated at 2022-06-23 01:01:48.619489
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    """Test the constructor of DateTimeFactCollector class."""

    datetime_fact_collector = DateTimeFactCollector()
    assert datetime_fact_collector.name == 'date_time'

# Generated at 2022-06-23 01:01:52.018082
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'
    assert date_time_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:01:56.845717
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    a = DateTimeFactCollector()
    assert hasattr(a, 'name'), 'Failed to set name attribute'
    assert hasattr(a, '_fact_ids'), 'Failed to set _fact_ids attribute'


# Generated at 2022-06-23 01:02:06.280622
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import json

    # setup initial data for the test
    collected_facts = {}
    DateTime_facts = DateTimeFactCollector()
    retrieved_facts = DateTime_facts.collect(collected_facts)
    result = json.loads(json.dumps(retrieved_facts))
    assert result["date_time"]["year"] == str(datetime.datetime.now().year)
    assert result["date_time"]["month"] == str(datetime.datetime.now().month)
    assert result["date_time"]["date"] == str(datetime.datetime.now().date())
    assert result["date_time"]["time"] == str(datetime.datetime.now().time())

# Generated at 2022-06-23 01:02:10.400661
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collector = DateTimeFactCollector()
    result = collector.collect()
    assert 'date_time' in result
    assert 'time' in result['date_time']
    assert 'tz_offset' in result['date_time']

# Generated at 2022-06-23 01:02:12.006858
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()


# Generated at 2022-06-23 01:02:14.449850
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'
    assert dtfc._fact_ids == set()

# Generated at 2022-06-23 01:02:26.667224
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    import datetime
    import time

    # test for the module existence
    assert(DateTimeFactCollector.name == 'date_time')

    # test for the type of returned object
    mytime = get_collector_instance(DateTimeFactCollector, module=None)
    assert(isinstance(mytime, DateTimeFactCollector))

    # test for the returned object attributes
    epoch_ts = time.time()
    now = datetime.datetime.fromtimestamp(epoch_ts)
    utcnow = datetime.datetime.utcfromtimestamp(epoch_ts)


# Generated at 2022-06-23 01:02:33.264514
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():

    # The call to constructor should not raise any exceptions
    date_time_fact_collector = DateTimeFactCollector()

    # Test properties of the DateTimeFactCollector instance
    assert(date_time_fact_collector.name == "date_time")
    assert(isinstance(date_time_fact_collector._fact_ids, set))
    assert(len(date_time_fact_collector._fact_ids) == 0)


# Generated at 2022-06-23 01:02:37.445460
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fc = DateTimeFactCollector()
    assert date_time_fc.name == 'date_time'
    assert date_time_fc._fact_ids == set()


# Generated at 2022-06-23 01:02:38.844473
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    a = DateTimeFactCollector()
    assert isinstance(a, BaseFactCollector) and isinstance(a.collect(), dict)

# Generated at 2022-06-23 01:02:48.040816
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    epoch_now = time.time()
    dt_now = datetime.datetime.fromtimestamp(epoch_now)
    utc_now = datetime.datetime.utcfromtimestamp(epoch_now)


# Generated at 2022-06-23 01:02:59.788432
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    def mock_time_time():
        return 1534451783

    d = DateTimeFactCollector()

    # Test with mocked time
    with mock.patch.object(time, 'time', mock_time_time):
        collected_facts = d.collect()

        assert collected_facts['date_time']['year'] == '2018'
        assert collected_facts['date_time']['month'] == '08'
        assert collected_facts['date_time']['weekday'] == 'Friday'
        assert collected_facts['date_time']['weekday_number'] == '5'
        assert collected_facts['date_time']['weeknumber'] == '32'
        assert collected_facts['date_time']['day'] == '10'

# Generated at 2022-06-23 01:03:05.842427
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_module = DateTimeFactCollector()
    all_facts = date_time_fact_module.collect()
    assert 'date_time' in all_facts
    assert 'month' in all_facts['date_time']
    assert 'epoch' in all_facts['date_time']


# Generated at 2022-06-23 01:03:09.178252
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()
    assert collector.name == 'date_time'
    assert collector._fact_ids == set()

# Generated at 2022-06-23 01:03:11.493731
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    try:
        DateTimeFactCollector()
        assert True
    except:
        assert False

# Generated at 2022-06-23 01:03:18.949966
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # Set up test environment.
    test_module = None
    test_facts = {}
    date_time_fact_collector = DateTimeFactCollector()

    # Run test.
    date_time_facts = date_time_fact_collector.collect(test_module, test_facts)

    # Assertions
    assert date_time_facts['date_time']['year'] is not None

# Generated at 2022-06-23 01:03:25.660702
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time = DateTimeFactCollector()
    assert date_time.name == 'date_time'
    assert date_time._fact_ids == set(['date_time'])



# Generated at 2022-06-23 01:03:27.365018
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collector = DateTimeFactCollector()
    result = collector.collect()
    assert('date_time' in result)

# Generated at 2022-06-23 01:03:31.613982
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    fact_collector = DateTimeFactCollector()
    assert fact_collector.name == 'date_time'
    assert not fact_collector._fact_ids
    assert fact_collector.collect()['date_time']['year'] == datetime.datetime.now().strftime('%Y')

# Generated at 2022-06-23 01:03:36.274577
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time = DateTimeFactCollector()
    assert date_time.name == "date_time"
    assert date_time._fact_ids == set()
    assert date_time._fact_ids != None
    assert date_time.has_dependencies == False
    assert date_time.has_dependencies != True


# Generated at 2022-06-23 01:03:47.494871
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Test setup
    ans_facts = {}

    # Set up the DateTimeFactCollector class
    Collector = DateTimeFactCollector()

    # Test the DateTimeFactCollector class
    ans_facts = Collector.collect(collected_facts=ans_facts)

    # Test the date_time facts
    assert ans_facts['date_time']['year'] != ''
    assert ans_facts['date_time']['month'] != ''
    assert ans_facts['date_time']['weekday'] != ''
    assert ans_facts['date_time']['weekday_number'] != ''
    assert ans_facts['date_time']['weeknumber'] != ''
    assert ans_facts['date_time']['day'] != ''
    assert ans_facts['date_time']['hour'] != ''

# Generated at 2022-06-23 01:03:50.538771
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj.name == 'date_time'
    assert obj._fact_ids == set()

# Generated at 2022-06-23 01:03:53.229949
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    facts = DateTimeFactCollector().collect()
    assert isinstance(facts, dict)
    assert isinstance(facts['date_time'], dict)

# Generated at 2022-06-23 01:04:04.060964
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Test case 1 - unix
    test_module = object

# Generated at 2022-06-23 01:04:08.072537
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector.name == 'date_time'
    assert DateTimeFactCollector._fact_ids == set()


# Generated at 2022-06-23 01:04:12.265599
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtf = DateTimeFactCollector()
    assert dtf.name == 'date_time'
    assert isinstance(dtf._fact_ids, set)
    assert dtf.collect()['date_time']['epoch_int'] == str(int(time.time()))

# Generated at 2022-06-23 01:04:22.412189
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # use a datetime of 2017-03-15T13:30:56.000000Z
    datetime_string = '2017-03-15T13:30:56.000000Z'
    iso8601_micro_format = '%Y-%m-%dT%H:%M:%S.%fZ'
    utcnow = datetime.datetime.strptime(datetime_string, iso8601_micro_format)

    def mock_now(format):
        if format == '%Y-%m-%d':
            return '2017-03-15'
        elif format == '%H:%M:%S':
            return '13:30:56'
        elif format == '%s':
            return int(utcnow.strftime(format))

# Generated at 2022-06-23 01:04:25.192006
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    fact_collector = DateTimeFactCollector()
    assert isinstance(fact_collector, DateTimeFactCollector)
    assert fact_collector.name == 'date_time'

# Generated at 2022-06-23 01:04:27.214173
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'
    assert not dtfc._fact_ids

# Generated at 2022-06-23 01:04:28.768073
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    pass

# Generated at 2022-06-23 01:04:33.141663
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Unit test for method collect of class DateTimeFactCollector
    """
    obj = DateTimeFactCollector()
    result = obj.collect()
    assert result['date_time']['epoch_int'] == str(int(time.time()))


# Generated at 2022-06-23 01:04:36.915263
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Creating object of class DateTimeFactCollector
    dtf = DateTimeFactCollector()
    # assert class variable
    assert dtf.name == 'date_time'
    assert dtf._fact_ids == set()

# Generated at 2022-06-23 01:04:40.665721
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    collector = DateTimeFactCollector()
    result = {}
    date_time = collector.collect(None,result)
    assert date_time == {}


# Generated at 2022-06-23 01:04:44.542539
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    f = DateTimeFactCollector()
    # Returned value should be a dict
    assert isinstance(f.collect(), dict)


# Generated at 2022-06-23 01:04:54.787219
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
  import os
  import sys
  import unittest

  # Make sure the env vars needed for the test are set
  unittest.TestCase().assertTrue(os.environ.get('ANSIBLE_INVENTORY') != None)
  unittest.TestCase().assertTrue(os.environ.get('ANSIBLE_ROLES_PATH') != None)

  # Generate the ansible arguments and environment needed.
  ansible_args = ['--inventory-file', os.environ['ANSIBLE_INVENTORY'],
                  '--connection', 'local',
                  '--module-name', 'setup',
                  '--module-path', os.path.dirname(__file__) + '/../../../lib/ansible/modules/system',
                  'all', '-m', 'setup']
  ansible_

# Generated at 2022-06-23 01:04:56.508720
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # TODO: Add tests for DateTimeFactCollector
    pass

# Generated at 2022-06-23 01:05:02.051234
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():

    class MockModule(object):
        def __init__(self):
            self.params = {}

    class MockFacts(object):
        def __init__(self):
            self.facts = {}

    obj = DateTimeFactCollector(MockModule(), MockFacts())

    assert obj.name == 'date_time'
    assert obj._fact_ids == set()

# Generated at 2022-06-23 01:05:06.653003
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_collector = DateTimeFactCollector()

    print('date_time_collector.name: {}'.format(date_time_collector.name))
    print('date_time_collector.fact_ids: {}'.format(date_time_collector._fact_ids))

if __name__ == '__main__':
    test_DateTimeFactCollector()

# Generated at 2022-06-23 01:05:08.397842
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtf = DateTimeFactCollector()
    assert type(dtf.collect()) == dict

# Generated at 2022-06-23 01:05:10.315019
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert 'date_time' in dt._fact_ids

# Generated at 2022-06-23 01:05:17.737932
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    constructor = DateTimeFactCollector()
    assert hasattr(constructor, "name")
    assert hasattr(constructor, "_fact_ids")
    assert not constructor._fact_ids
    assert hasattr(constructor, "collect")


# Generated at 2022-06-23 01:05:29.013533
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    factCollector = DateTimeFactCollector()
    factCollector.collect()
    date_time_facts = factCollector.collect()['date_time']
    assert date_time_facts['year']
    assert date_time_facts['month']
    assert date_time_facts['weekday']
    assert date_time_facts['weekday_number']
    assert date_time_facts['weeknumber']
    assert date_time_facts['day']
    assert date_time_facts['hour']
    assert date_time_facts['minute']
    assert date_time_facts['second']
    assert date_time_facts['epoch']
    assert date_time_facts['epoch_int']
    assert date_time_facts['date']
    assert date_time_facts['time']

# Generated at 2022-06-23 01:05:37.280295
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    c = DateTimeFactCollector()
    date_time_facts = c.collect()['date_time']
    assert date_time_facts['epoch'] != '%s'
    assert date_time_facts['epoch_int'] != '%s'
    assert date_time_facts['epoch_int'] == str(int(date_time_facts['epoch']))
    assert date_time_facts['iso8601_micro'].endswith('Z')
    assert date_time_facts['iso8601'].endswith('Z')



# Generated at 2022-06-23 01:05:40.613770
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    result = DateTimeFactCollector()
    date_time_facts_dict = result.collect()
    assert 'date_time' in date_time_facts_dict

# Generated at 2022-06-23 01:05:43.507392
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Testing DateTimeFactCollector.collect"""
    collector = DateTimeFactCollector()
    result = collector.collect()
    keys = sorted(result.keys())
    expected = ['date_time']
    assert keys == expected

# Generated at 2022-06-23 01:05:46.030831
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dc = DateTimeFactCollector()
    result = dc.collect()
    assert 'date_time' in result.keys()

# Generated at 2022-06-23 01:05:54.836805
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Unit test for method collect of class DateTimeFactCollector"""

    # Load instance of DateTimeFactCollector
    dtfc = DateTimeFactCollector()

    # call collect method of DateTimeFactCollector
    t = time.time()
    dt_facts = dtfc.collect()

    # validate the content of date_time fact
    assert "date_time" in dt_facts
    date_time_facts = dt_facts["date_time"]
    assert "year" in date_time_facts
    assert "month" in date_time_facts
    assert "weekday" in date_time_facts
    assert "weekday_number" in date_time_facts
    assert "weeknumber" in date_time_facts
    assert "day" in date_time_facts
    assert "hour" in date_time

# Generated at 2022-06-23 01:05:57.514141
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector.name == 'date_time'
    assert DateTimeFactCollector._fact_ids == set()


# Generated at 2022-06-23 01:06:01.381396
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    try:
        DateTimeFactCollector()
    except Exception:
        assert False, 'DateTimeFactCollector failed to instantiate'

# Generated at 2022-06-23 01:06:04.552887
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt.name == 'date_time'
    assert dt._fact_ids == set()


# Generated at 2022-06-23 01:06:09.223556
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()

    # Make sure the needed class attributes exist
    assert date_time_fact_collector.name == 'date_time'
    assert date_time_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:06:16.145177
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    # just test that these keys are present
    assert set(['year', 'month', 'hour', 'timezone', 'weekday', 'weekday_number', 'weeknumber', 'iso8601_micro', 'iso8601', 'tz', 'minute', 'tz_offset', 'day', 'tz_dst', 'iso8601_basic', 'iso8601_basic_short', 'date', 'second', 'epoch', 'epoch_int']) == set(dtfc.collect()['date_time'].keys())

# Generated at 2022-06-23 01:06:27.201602
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dateTimeFactCollector = DateTimeFactCollector()
    dateTimeFactCollector._module = None
    dateTimeFactCollector._collected_facts = None
    # This test was created to debug a failure in TimeFactCollector
    # which returns nanoseconds instead of seconds in epoch
    # https://github.com/ansible/ansible/issues/15309
    output = dateTimeFactCollector.collect(None, None)
    # if the following assert fails then we have the problem
    assert int(output['date_time']['epoch_int']) == int(output['date_time']['epoch'])

# Generated at 2022-06-23 01:06:31.028548
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'
    assert date_time_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:06:33.560136
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    data = list()
    data.append('date_time')
    data.append(set())
    DateTimeFactCollector.__init__(data)
    assert data == ['date_time', set()]

# Generated at 2022-06-23 01:06:35.304176
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'
    assert x._fact_ids == set()

# Generated at 2022-06-23 01:06:38.588329
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector().name == 'date_time'


# Generated at 2022-06-23 01:06:40.097249
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    print(obj)
    assert obj.name == 'date_time'

# Generated at 2022-06-23 01:06:48.671805
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = DateTimeFactCollector()
    result = dt.collect()

# Generated at 2022-06-23 01:06:50.796874
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    res = DateTimeFactCollector()
    assert type(res.collect()) == dict

# Generated at 2022-06-23 01:06:53.787002
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    facts_obj = DateTimeFactCollector()
    result = facts_obj.collect()
    if result:
        pass
    else:
        raise Exception()

# Generated at 2022-06-23 01:07:04.742904
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    date_time_facts = fact_collector.collect()
    assert type(date_time_facts) is dict
    assert date_time_facts['date_time']
    assert date_time_facts['date_time']['year']
    assert date_time_facts['date_time']['month']
    assert date_time_facts['date_time']['weekday']
    assert date_time_facts['date_time']['weekday_number']
    assert date_time_facts['date_time']['weeknumber']
    assert date_time_facts['date_time']['day']
    assert date_time_facts['date_time']['hour']
    assert date_time_facts['date_time']['minute']
    assert date_

# Generated at 2022-06-23 01:07:13.294067
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    c = DateTimeFactCollector()
    res = c.collect()
    assert(res['date_time']['year'] == '2016')
    assert(res['date_time']['month'] == '11')
    assert(res['date_time']['weekday'] == 'Tuesday')
    assert(res['date_time']['weekday_number'] == '2')
    assert(res['date_time']['weeknumber'] == '45')
    assert(res['date_time']['day'] == '29')
    assert(res['date_time']['hour'] == '20')
    assert(res['date_time']['minute'] == '07')
    assert(res['date_time']['second'] == '27')

# Generated at 2022-06-23 01:07:14.635216
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    result = DateTimeFactCollector()
    assert result != None


# Generated at 2022-06-23 01:07:26.687868
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    collected_facts = dtfc.collect()
    assert collected_facts['date_time']['time'] == '23:44:44'
    assert collected_facts['date_time']['month'] == '06'
    assert collected_facts['date_time']['weekday_number'] == '5'
    assert collected_facts['date_time']['tz_dst'] == 'PDT'
    assert collected_facts['date_time']['tz'] == 'PDT'
    assert collected_facts['date_time']['day'] == '19'
    assert collected_facts['date_time']['iso8601_basic_short'] == '20150619T234444'

# Generated at 2022-06-23 01:07:36.641608
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_facts = DateTimeFactCollector().collect()['date_time']
    assert date_time_facts['year'] is not None
    assert date_time_facts['month'] is not None
    assert date_time_facts['weekday'] is not None
    assert date_time_facts['weekday_number'] is not None
    assert date_time_facts['weeknumber'] is not None
    assert date_time_facts['day'] is not None
    assert date_time_facts['hour'] is not None
    assert date_time_facts['minute'] is not None
    assert date_time_facts['second'] is not None
    assert date_time_facts['epoch'] is not None
    assert date_time_facts['date'] is not None
    assert date_time_facts['time'] is not None
    assert date_

# Generated at 2022-06-23 01:07:38.471446
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # check if module DateTimeFactCollector is working in expected way
    assert(1)

# Generated at 2022-06-23 01:07:40.933308
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector().name == 'date_time'
    assert DateTimeFactCollector()._fact_ids == set()

# Generated at 2022-06-23 01:07:43.764371
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_obj = DateTimeFactCollector()
    assert date_time_obj.name == 'date_time'
    assert len(date_time_obj._fact_ids) == 0


# Generated at 2022-06-23 01:07:45.797651
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    class Module:
        pass
    collector = DateTimeFactCollector()
    assert collector.collect(Module)

# Generated at 2022-06-23 01:07:56.434930
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Unit test for method collect of class DateTimeFactCollector"""
    import os
    from ansible.module_utils.facts import ansible_facts

    env_dict = ansible_facts.get_env_facts()
    test_obj = DateTimeFactCollector()
    result = test_obj.collect(env_dict)
    assert 'date_time' in result
    assert type(result['date_time']) is dict
    assert 'month' in result['date_time']
    assert type(result['date_time']['month']) is str
    assert len(result['date_time']['month']) == 2
    assert 'year' in result['date_time']
    assert type(result['date_time']['year']) is str

# Generated at 2022-06-23 01:07:57.830491
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()


# Generated at 2022-06-23 01:08:07.392646
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtf_collector = DateTimeFactCollector()
    epoch_ts = time.time()
    now = datetime.datetime.fromtimestamp(epoch_ts)
    utcnow = datetime.datetime.utcfromtimestamp(epoch_ts)
    date_time = dict()
    date_time['year'] = now.strftime('%Y')
    date_time['month'] = now.strftime('%m')
    date_time['weekday'] = now.strftime('%A')
    date_time['weekday_number'] = now.strftime('%w')
    date_time['weeknumber'] = now.strftime('%W')
    date_time['day'] = now.strftime('%d')
    date_time['hour'] = now.strftime('%H')
   

# Generated at 2022-06-23 01:08:09.350442
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_instance = DateTimeFactCollector()

    assert date_time_instance is not None


# Generated at 2022-06-23 01:08:10.750605
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()

# Generated at 2022-06-23 01:08:21.989469
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    result = fact_collector.collect()
    assert 'date_time' in result
    assert 'year' in result['date_time']
    assert 'month' in result['date_time']
    assert 'weekday' in result['date_time']
    assert 'weekday_number' in result['date_time']
    assert 'weeknumber' in result['date_time']
    assert 'day' in result['date_time']
    assert 'hour' in result['date_time']
    assert 'minute' in result['date_time']
    assert 'second' in result['date_time']
    assert 'epoch' in result['date_time']
    assert 'epoch_int' in result['date_time']
    assert 'date' in result['date_time']
