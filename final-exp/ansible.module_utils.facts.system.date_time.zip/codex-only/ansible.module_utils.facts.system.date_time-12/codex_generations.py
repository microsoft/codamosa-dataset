

# Generated at 2022-06-23 00:58:19.389008
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt.name == 'date_time'
    assert dt._fact_ids == set()


# Generated at 2022-06-23 00:58:28.475829
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # Generate "collected_facts"
    collected_facts = {'ansible_facts': {'date_time': {}}}

    # Generate "DateTimeFactCollector" instance
    module = None
    date_time_fact_collector = DateTimeFactCollector()

    # Get "collected_facts" from DateTimeFactCollector
    collected_facts = date_time_fact_collector.collect(module=module,
            collected_facts=collected_facts)

    # Get "date_time" facts
    date_time_facts = collected_facts.get('ansible_facts').get('date_time')

    # Check if "epoch" is an integer
    try:
        int(date_time_facts.get('epoch'))
    except:
        assert False, "epoch is not an integer"



# Generated at 2022-06-23 00:58:30.416350
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj.name == 'date_time'

# Generated at 2022-06-23 00:58:32.001299
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector.name == 'date_time'

# Generated at 2022-06-23 00:58:35.915156
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector.name == 'date_time'
    assert DateTimeFactCollector._fact_ids == set()
    assert isinstance(DateTimeFactCollector._fact_ids, set)

# Generated at 2022-06-23 00:58:41.909535
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # Test with an empty "collected_facts"
    dtfc = DateTimeFactCollector()
    dtfc_result = dtfc.collect()
    assert dtfc_result['date_time']['date'] == datetime.datetime.utcnow().strftime('%Y-%m-%d')

# Generated at 2022-06-23 00:58:45.827545
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtFact = DateTimeFactCollector()
    assert(isinstance(dtFact, DateTimeFactCollector))
    assert(isinstance(dtFact.collect(), dict))

# Generated at 2022-06-23 00:58:50.208956
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_facts = DateTimeFactCollector().collect()
    assert date_time_facts
    assert date_time_facts['date_time']
    for test_item in date_time_facts['date_time']:
        assert isinstance(date_time_facts['date_time'][test_item], str)

# Generated at 2022-06-23 00:58:53.771867
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt_fact = DateTimeFactCollector()
    assert dt_fact.name == 'date_time'
    assert not dt_fact._fact_ids


# Generated at 2022-06-23 00:58:54.846106
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()


# Generated at 2022-06-23 00:59:05.810342
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Initialize the class
    dt_fc = DateTimeFactCollector()

    # get the facts
    facts = dt_fc.collect()
    dt_facts = facts['date_time']

    assert dt_facts['year'] == time.strftime('%Y')
    assert dt_facts['month'] == time.strftime('%m')
    assert dt_facts['weekday'] == time.strftime('%A')
    assert dt_facts['weekday_number'] == time.strftime('%w')
    assert dt_facts['weeknumber'] == time.strftime('%W')
    assert dt_facts['day'] == time.strftime('%d')
    assert dt_facts['hour'] == time.strftime('%H')
    assert dt_facts['minute'] == time

# Generated at 2022-06-23 00:59:08.465549
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_collector = DateTimeFactCollector()
    assert date_time_collector.name == 'date_time'
    assert date_time_collector._fact_ids == set()


# Generated at 2022-06-23 00:59:18.217028
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Test the DateTimeFactCollector collect method"""

# Generated at 2022-06-23 00:59:29.730226
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_test_obj = DateTimeFactCollector()
    date_time_test_obj.collect()
    return (date_time_test_obj._fact_ids == {'epoch', 'epoch_int', 'date', 'time', 'year',
                                             'month', 'weekday_number', 'weeknumber', 'day',
                                             'weekday', 'hour', 'minute', 'second', 'iso8601_micro',
                                             'iso8601', 'iso8601_basic', 'iso8601_basic_short', 'tz',
                                             'tz_dst', 'tz_offset'})


# Run the unit test for this file
if __name__ == '__main__':
    print("Running test for ansible module utils datetime facts")
    test_DateTimeFactCollector_collect

# Generated at 2022-06-23 00:59:33.298005
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    """ Test correct constructor of DateTimeFactCollector """
    date_time = DateTimeFactCollector()
    assert date_time
    assert date_time.name == 'date_time'
    assert date_time._fact_ids == set()


# Generated at 2022-06-23 00:59:43.370239
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Note: this test has known failures on platforms that have problems with timezones
    # For example, Mac OSX converts "CST" to "CDT" in the timezone tests, which is unlikely correct
    # However, the Python documentation doesn't specify what is correct, so who knows
    # These tests are left in as not to break on 2.2, but will be removed in 2.3
    expected_epoch = str(int(time.time()))
    collector = DateTimeFactCollector()
    results = collector.collect()
    assert 'date_time' in results
    assert 'epoch' in results['date_time']
    assert results['date_time']['epoch'] == expected_epoch
    assert 'epoch_int' in results['date_time']
    assert results['date_time']['epoch_int']

# Generated at 2022-06-23 00:59:51.361179
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    now = datetime.datetime.utcnow()
    epoch_ts = time.time()

    dtfc = DateTimeFactCollector()

    facts = dtfc.collect()

    assert facts['date_time']['year'] == now.strftime('%Y')
    assert facts['date_time']['month'] == now.strftime('%m')
    assert facts['date_time']['weekday'] == now.strftime('%A')
    assert facts['date_time']['weekday_number'] == now.strftime('%w')
    assert facts['date_time']['weeknumber'] == now.strftime('%W')
    assert facts['date_time']['day'] == now.strftime('%d')
    assert facts['date_time']['hour'] == now.str

# Generated at 2022-06-23 01:00:03.611669
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Replace module argument with a MagicMock to prevent actual calls to the module
    module = 'test_module'
    collected_facts = 'test_facts'

    epoch_ts = time.time()
    now = datetime.datetime.fromtimestamp(epoch_ts)
    utcnow = datetime.datetime.utcfromtimestamp(epoch_ts)


# Generated at 2022-06-23 01:00:07.052740
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtf_collector = DateTimeFactCollector()
    assert dtf_collector.name == 'date_time'
    assert len(dtf_collector._fact_ids) == 0

# Generated at 2022-06-23 01:00:07.976319
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()

# Generated at 2022-06-23 01:00:09.733534
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector().name == 'date_time'


# Generated at 2022-06-23 01:00:19.041292
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Unit test for method collect of class DateTimeFactCollector"""
    import time
    from ansible.module_utils.facts.collector import BaseFactCollector

    collector = DateTimeFactCollector()
    assert isinstance(collector, BaseFactCollector)

    collected_facts = {}

    facts_dict = collector.collect(collected_facts)
    assert 'date_time' in facts_dict
    assert isinstance(facts_dict['date_time'], dict)

    date_time_facts = facts_dict['date_time']

    assert 'year' in date_time_facts
    assert len(date_time_facts['year']) == 4
    assert int(date_time_facts['year']) >= 2018

    assert 'month' in date_time_facts
    assert len(date_time_facts['month'])

# Generated at 2022-06-23 01:00:22.223480
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Test method DateTimeFactCollector.collect for pep8 compliance
    """
    datetime_collector = DateTimeFactCollector()
    _ = datetime_collector.collect()

# Generated at 2022-06-23 01:00:28.719843
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collect_obj = DateTimeFactCollector()
    ret_dict = collect_obj.collect()
    assert ret_dict['date_time']['iso8601'] == '2012-12-10T09:36:17Z'
    assert ret_dict['date_time']['iso8601_micro'] == '2012-12-10T09:36:17.000000Z'

# Generated at 2022-06-23 01:00:31.338066
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt_collector = DateTimeFactCollector()
    assert dt_collector.name == 'date_time'

# Unit test to check if the collect method returns the proper dictionary.

# Generated at 2022-06-23 01:00:41.217248
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtf = DateTimeFactCollector()
    # Run collect
    collected_facts = dtf.collect()

    # Validate results
    date_time_facts = collected_facts['date_time']

    assert date_time_facts['epoch'] is not None
    assert date_time_facts['epoch_int'] is not None
    assert date_time_facts['date'] is not None
    assert date_time_facts['time'] is not None
    assert date_time_facts['iso8601'] is not None
    assert date_time_facts['iso8601_micro'] is not None
    assert date_time_facts['iso8601_basic'] is not None
    assert date_time_facts['iso8601_basic_short'] is not None
    assert date_time_facts['tz_offset'] is not None

# Generated at 2022-06-23 01:00:46.506609
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = DateTimeFactCollector.collect()
    assert dt['date_time']['year'] == datetime.datetime.now().strftime("%Y")

# Generated at 2022-06-23 01:00:53.377752
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dc = DateTimeFactCollector()
    facts = dc.collect()
    assert 'date_time' in facts
    assert 'year' in facts['date_time']
    assert 'weeknumber' in facts['date_time']
    assert 'date' in facts['date_time']


# Generated at 2022-06-23 01:00:59.928810
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():

    # Create an instance of DateTimeFactCollector
    date_time_fact_collector = DateTimeFactCollector()

    # Test name
    assert date_time_fact_collector.name == 'date_time', \
        "Expected name is 'date_time'"

    # Test _fact_ids
    assert isinstance(date_time_fact_collector._fact_ids, set), \
        "_fact_ids should be a set"

    for fact_id in date_time_fact_collector._fact_ids:
        assert fact_id == 'date_time', 'Expected fact_id is date_time'

# Generated at 2022-06-23 01:01:03.853458
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():

    # Creates instance of the 'DateTimeFactCollector'
    my_obj = DateTimeFactCollector()

    # Checks if the name of the instance is "date_time"
    assert my_obj.name == "date_time"

# Generated at 2022-06-23 01:01:12.483988
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.collector import BaseFactCollector

    facts_obj = Facts(module=None)
    collector = BaseFactCollector.get_collector('date_time', facts_obj)
    output = collector.collect()

    print(output)

    assert 'epoch' in output
    assert 'epoch_int' in output
    assert 'iso8601' in output
    assert 'iso8601_basic' in output
    assert 'iso8601_basic_short' in output
    assert 'iso8601_micro' in output
    assert 'month' in output
    assert 'year' in output
    assert 'date' in output
    assert 'day' in output
    assert 'weekday_number' in output
    assert 'weeknumber'

# Generated at 2022-06-23 01:01:25.237344
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-23 01:01:29.022014
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # Create a test DateTimeFactCollector object
    dtfc = DateTimeFactCollector()
    assert dtfc is not None

    # Collect some facts
    facts = dtfc.collect()
    assert dtfc is not None
    assert isinstance(facts, dict)
    assert 'date_time' in facts

# Generated at 2022-06-23 01:01:39.910395
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    epoch_ts = time.time()
    now = datetime.datetime.fromtimestamp(epoch_ts)
    utcnow = datetime.datetime.utcfromtimestamp(epoch_ts)
    dtfc = DateTimeFactCollector()
    # check the values of facts before executing collect function
    assert dtfc.name == 'date_time'
    assert len(dtfc.collect_fn) == 0
    assert dtfc._fact_ids == set()
    # check if collect() method works as intended
    dtfc_collect = dtfc.collect()
    assert dtfc_collect.get('date_time') is not None
    assert dtfc_collect.get('date_time').get('year') == now.strftime('%Y')

# Generated at 2022-06-23 01:01:50.304609
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Create a collector object and check if it has been created correctly
    dtf = DateTimeFactCollector()

    expected_fields_keys = set(['date_time'])
    assert dtf._fact_ids == expected_fields_keys


# Generated at 2022-06-23 01:01:54.507553
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt.name == 'date_time', 'Invalid DateTimeFactCollector name attribute'
    assert dt._fact_ids == set(), 'Invalid DateTimeFactCollector _fact_ids attribute'

    # Call collect method
    dt.collect()

# Generated at 2022-06-23 01:02:00.346429
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_facts_collector = DateTimeFactCollector()
    date_time_facts = date_time_facts_collector.collect()
    assert 'date_time' in date_time_facts
    assert 'date' in date_time_facts['date_time']
    assert 'time' in date_time_facts['date_time']
    assert 'hour' in date_time_facts['date_time']

# Generated at 2022-06-23 01:02:02.908896
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    datetime_factcollector = DateTimeFactCollector()

# Generated at 2022-06-23 01:02:05.029878
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'



# Generated at 2022-06-23 01:02:09.371120
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # get a DateTimeFactCollector object
    dateTimeFactCollector = DateTimeFactCollector()

    # get facts of datetime
    collected_facts = dateTimeFactCollector.collect()

    # assert the collected facts are not empty
    assert collected_facts is not None

# Generated at 2022-06-23 01:02:19.875999
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """ Unit test for method collect of class DateTimeFactCollector """
    from ansible.module_utils.facts.collectors import BaseFactCollector
    from ansible.module_utils.facts.collectors.date_time import DateTimeFactCollector

    obj = DateTimeFactCollector()
    # Basic test of every attribute, no need to test values of the attributes.
    assert isinstance(obj, BaseFactCollector)
    assert obj.name == 'date_time'
    assert isinstance(obj._fact_ids, set)
    assert len(obj._fact_ids) == 0
    result = obj.collect()
    assert isinstance(result, dict)
    assert type(result['date_time']) == dict

# Generated at 2022-06-23 01:02:21.094743
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert type(obj) == DateTimeFactCollector

# Generated at 2022-06-23 01:02:25.146162
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    mock_module = type('module', (object,), {})()
    mock_collector = DateTimeFactCollector(mock_module)
    result = mock_collector.collect()
    # Just some basic sanity check to make sure the result is a dictionary
    assert result != {}

# Generated at 2022-06-23 01:02:27.678386
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    a = DateTimeFactCollector()
    assert a.name == 'date_time'
    assert a._fact_ids == set()


# Generated at 2022-06-23 01:02:29.510515
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    d = DateTimeFactCollector()
    assert(type(d) == DateTimeFactCollector)


# Generated at 2022-06-23 01:02:33.434995
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dateTimeFactCollector = DateTimeFactCollector()
    assert dateTimeFactCollector is not None

# Generated at 2022-06-23 01:02:36.089616
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    result = DateTimeFactCollector()
    assert result
    assert result.name == 'date_time'
    assert result.fact_ids == set()

# Generated at 2022-06-23 01:02:41.094203
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'
    assert isinstance(date_time_fact_collector._fact_ids, set)
    assert not date_time_fact_collector._fact_ids


# Generated at 2022-06-23 01:02:52.315345
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    ans = fact_collector.collect()
    assert ans.get('date_time') is not None
    assert ans.get('date_time').get('year') is not None
    assert ans.get('date_time').get('month') is not None
    assert ans.get('date_time').get('weekday') is not None
    assert ans.get('date_time').get('weekday_number') is not None
    assert ans.get('date_time').get('weeknumber') is not None
    assert ans.get('date_time').get('day') is not None
    assert ans.get('date_time').get('hour') is not None
    assert ans.get('date_time').get('minute') is not None

# Generated at 2022-06-23 01:02:56.341680
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Create instance of class DateTimeFactCollector
    datetime_fact_collector_instance = DateTimeFactCollector()

    # Check the name of the fact collector
    assert datetime_fact_collector_instance.name == 'date_time'


# Generated at 2022-06-23 01:02:58.793237
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'


# Generated at 2022-06-23 01:03:00.684524
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc


# Generated at 2022-06-23 01:03:04.024759
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    datetimefact = DateTimeFactCollector()
    assert datetimefact.collect() is not None

# Generated at 2022-06-23 01:03:13.918242
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    df = DateTimeFactCollector()
    res = df.collect()
    assert ('date_time' in res)
    dt = res['date_time']
    assert ('year' in dt)
    assert ('month' in dt)
    assert ('weekday' in dt)
    assert ('weekday_number' in dt)
    assert ('weeknumber' in dt)
    assert ('day' in dt)
    assert ('hour' in dt)
    assert ('minute' in dt)
    assert ('second' in dt)
    assert ('epoch' in dt)
    assert ('epoch_int' in dt)
    assert ('date' in dt)
    assert ('time' in dt)
    assert ('iso8601_micro' in dt)

# Generated at 2022-06-23 01:03:17.602178
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector == 'date_time'
    assert date_time_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:03:20.535382
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x
    assert x.name == 'date_time'
    assert isinstance(x.collect(), dict)

# Generated at 2022-06-23 01:03:28.867955
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Create an instance of DateTimeFactCollector
    DateTimeFactCollectorObject = DateTimeFactCollector()

    # Call method collect of DateTimeFactCollector object
    result = DateTimeFactCollectorObject.collect()

    # Check if result is of type dict
    assert isinstance(result, dict)

    # Check if key date_time is in result
    assert 'date_time' in result

    # Check if value of date_time key is of type dict
    assert isinstance(result['date_time'], dict)

# Generated at 2022-06-23 01:03:32.045111
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    '''Unit test for method collect of class DateTimeFactCollector'''

    dtfc = DateTimeFactCollector()
    dtfc.collect()


# Unit test generator for DateTimeFactCollector

# Generated at 2022-06-23 01:03:34.653890
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_info = DateTimeFactCollector()
    assert date_time_info.name == 'date_time'
    assert date_time_info._fact_ids == set()

# Generated at 2022-06-23 01:03:41.178313
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    dtf = DateTimeFactCollector()

    dt = dtf.collect()

    assert 'date_time' in dt
    assert 'year' in dt['date_time']
    assert dt['date_time']['year'] == datetime.datetime.now().strftime('%Y')

# Generated at 2022-06-23 01:03:47.197632
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_facts_collector = DateTimeFactCollector()
    result = date_time_facts_collector.collect()
    now = datetime.datetime.now()
    assert result['date_time']['year'] == str(now.year)
    assert result['date_time']['weekday'] == now.strftime('%A')
    assert result['date_time']['date'] == now.strftime('%Y-%m-%d')

# Generated at 2022-06-23 01:03:59.219051
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_collected = DateTimeFactCollector()
    date_collected_return = date_collected.collect()

    assert date_collected_return['date_time']['date']
    assert date_collected_return['date_time']['day']
    assert date_collected_return['date_time']['epoch']
    assert date_collected_return['date_time']['hour']
    assert date_collected_return['date_time']['iso8601']
    assert date_collected_return['date_time']['iso8601_basic']
    assert date_collected_return['date_time']['iso8601_basic_short']
    assert date_collected_return['date_time']['iso8601_micro']

# Generated at 2022-06-23 01:04:06.959174
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():

    dateTimeFactCollector = DateTimeFactCollector()

    # Check whether instance is of correct class
    assert dateTimeFactCollector.__class__ == DateTimeFactCollector, "dateTimeFactCollector is not of type DateTimeFactCollector"

    # Check if correct values are returned
    assert dateTimeFactCollector.name == 'date_time', "dateTimeFactCollector name is not set to 'date_time'"
    assert isinstance(dateTimeFactCollector._fact_ids, set), "dateTimeFactCollector._fact_ids is not of type set"

# Unit test and run function for collect function of class DateTimeFactCollector

# Generated at 2022-06-23 01:04:09.171917
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert isinstance(x, DateTimeFactCollector)


# Generated at 2022-06-23 01:04:20.631425
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-23 01:04:29.572651
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import json
    import os
    import platform
    import pytest
    from ansible.module_utils.facts import get_module_scrubber_args, ModuleScrubber
    from ansible.module_utils.facts.collector import BaseFactCollector
    import ansible.utils.py26compat as compat

    fc = DateTimeFactCollector()
    res = fc.collect()
    # Sanity check

# Generated at 2022-06-23 01:04:32.181326
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    datetime_fact = DateTimeFactCollector()
    assert datetime_fact.name == 'date_time'


# Generated at 2022-06-23 01:04:42.307580
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fake_module = {
        'ansible_facts': {},
    }

    dtf = DateTimeFactCollector()
    # Needed to avoid a circular import.
    dtf.module = fake_module
    result = dtf.collect()

    # Check if expected root key is created
    assert 'date_time' in result

    # Check if all the subkeys are present
    assert 'year' in result['date_time']
    assert 'month' in result['date_time']
    assert 'weekday' in result['date_time']
    assert 'weekday_number' in result['date_time']
    assert 'weeknumber' in result['date_time']
    assert 'day' in result['date_time']
    assert 'hour' in result['date_time']

# Generated at 2022-06-23 01:04:46.277995
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    test class DateTimeFactCollector and collect method
    """
    dt_obj = DateTimeFactCollector()
    assert('date_time' in dt_obj.collect().keys())

# Generated at 2022-06-23 01:04:56.401514
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Class DateTimeFactCollector to test
    cls_factcollector = DateTimeFactCollector()

    # Check empty collected_facts
    collected_facts = {}
    # Get the result of method collect for class DateTimeFactCollector

# Generated at 2022-06-23 01:04:59.814190
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collector = DateTimeFactCollector()
    test_dict = collector.collect()
    assert 'date_time' in test_dict
    assert 'epoch_int' in test_dict['date_time']

# Generated at 2022-06-23 01:05:01.296325
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    facts = DateTimeFactCollector()
    assert 'date_time' == facts.name

# Generated at 2022-06-23 01:05:09.850257
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_facts_collector = DateTimeFactCollector()
    collected_facts = date_time_facts_collector.collect()

    if not collected_facts:
        raise AssertionError('No facts are returned')

    date_time_facts = collected_facts.get('date_time', None)

    if not date_time_facts:
        raise AssertionError('No date_time facts are returned')

# Generated at 2022-06-23 01:05:15.070223
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fc = DateTimeFactCollector(None)
    date_time_fc.collect()

# Generated at 2022-06-23 01:05:26.155205
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    dtfc.collect()
    if dtfc.name != 'date_time':
        raise Exception('Expected date_time')
    if not dtfc._fact_ids:
        raise Exception('Expected _fact_ids to be set')
    for x in ['epoch', 'epoch_int', 'date', 'time', 'iso8601_micro', 'iso8601', 'tz', 'tz_dst', 'tz_offset']:
        if x not in dtfc.collection.keys():
            raise Exception('Expected {} to be in collection'.format(x))

# import module snippets
from ansible.module_utils.basic import *
# from ansible.module_utils.facts import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 01:05:28.680039
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fc = DateTimeFactCollector()
    assert date_time_fc.collect() != {}

# Generated at 2022-06-23 01:05:31.392287
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt_fc = DateTimeFactCollector()
    assert dt_fc.name == 'date_time'
    assert dt_fc._fact_ids == set()


# Generated at 2022-06-23 01:05:42.369526
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import pytest
    from ansible.module_utils.facts import collector

    def side_effect(*args):
        return args[0]

    # patch base fact collector's get_file_content method to do nothing
    # (we don't need to read from file to verify return values)
    collector.BaseFactCollector.get_file_content = side_effect

    f = DateTimeFactCollector()
    results = f.collect()
    assert (results is not None)
    assert (len(results) == 1)
    assert (results['date_time']['iso8601'] is not None)
    # backup_to_dir is a 'date' fact, is should contain '/'
    assert ('/' in results['date_time']['date'])

# Generated at 2022-06-23 01:05:52.720477
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Test if the facts are as expected
    fc = DateTimeFactCollector()
    fc.collect()
    date_time_facts = fc.get_facts()
    assert date_time_facts['date_time']['year'] == time.strftime('%Y')
    assert date_time_facts['date_time']['month'] == time.strftime('%m')
    assert date_time_facts['date_time']['weekday'] == time.strftime('%A')
    assert date_time_facts['date_time']['weekday_number'] == time.strftime('%w')
    assert date_time_facts['date_time']['weeknumber'] == time.strftime('%W')
    assert date_time_facts['date_time']['day'] == time.strftime

# Generated at 2022-06-23 01:05:55.799967
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj.name == 'date_time'
    assert obj._fact_ids == set(['date_time'])


# Generated at 2022-06-23 01:05:58.809496
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    fact_collector = DateTimeFactCollector('date_time', 'date_time')
    assert fact_collector.name == 'date_time'



# Generated at 2022-06-23 01:06:02.679185
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # check if all facts is present ( just check if there is no exception )
    DateTimeFactCollector().collect()

# Generated at 2022-06-23 01:06:04.263197
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collector = DateTimeFactCollector()
    assert 'date_time' in collector.collect()

# Generated at 2022-06-23 01:06:13.679498
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts import collector

    # Stub the method get of class PlatformFactCollector
    collector.get = get_platform_fact_collector_get

    date_time_collector = DateTimeFactCollector()
    date_time_facts = date_time_collector.collect()

    assert 'date_time' in date_time_facts
    assert 'month' in date_time_facts['date_time']
    assert 'date' in date_time_facts['date_time']
    assert 'day' in date_time_facts['date_time']
    assert 'time' in date_time_facts['date_time']
    assert 'tz' in date_time_facts['date_time']


# Generated at 2022-06-23 01:06:22.737492
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Tests method collect of class DateTimeFactCollector
    """
    # Arrange
    import platform
    import time

    def set_up_mock_platform(module_platform):
        """Mocks platform.platform() and platform.machine() calls."""
        module_platform.platform.return_value = "Linux-3.10.0-957.el7.x86_64-x86_64-with-centos-7.6.1810-Core"
        module_platform.machine.return_value = "x86_64"

    def set_up_mock_time(module_time):
        """Mocks time.time() call."""

# Generated at 2022-06-23 01:06:24.572656
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Test new DateTimeFactCollector is created
    collector = DateTimeFactCollector()
    assert isinstance(collector, DateTimeFactCollector)


# Generated at 2022-06-23 01:06:27.773445
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    datetimecollector = DateTimeFactCollector()
    assert datetimecollector.name == "date_time"

# Generated at 2022-06-23 01:06:39.070911
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector.collect()['date_time']
    assert(len(date_time_facts) == 16)
    assert(date_time_facts['year'] == time.strftime("%Y"))
    assert(date_time_facts['month'] == time.strftime("%m"))
    assert(date_time_facts['weekday'] == time.strftime("%A"))
    assert(date_time_facts['weekday_number'] == time.strftime("%w"))
    assert(date_time_facts['weeknumber'] == time.strftime("%W"))
    assert(date_time_facts['day'] == time.strftime("%d"))

# Generated at 2022-06-23 01:06:41.443683
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt.name == 'date_time'
    assert dt._fact_ids == set()


# Generated at 2022-06-23 01:06:54.766976
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Variable to store collector instance
    DateTimeFactCollector_collector = DateTimeFactCollector()
    # Dictionary to store test result
    DateTimeFactCollector_collector_test = {}

    # Check if module name is 'date_time'
    if DateTimeFactCollector_collector.name == "date_time":
        DateTimeFactCollector_collector_test.update({"Module name test": "Pass"})
    else:
        DateTimeFactCollector_collector_test.update({"Module name test": "Fail"})

    # Check if date_time dictionary is the return value of method collect
    if type(DateTimeFactCollector_collector.collect()) == dict:
        DateTimeFactCollector_collector_test.update({"Collect method return type test": "Pass"})
    else:
        DateTime

# Generated at 2022-06-23 01:06:58.598895
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_obj = DateTimeFactCollector()
    date_time = date_time_obj.collect()
    assert date_time['date_time']['epoch'] != ""
    assert date_time['date_time']['epoch_int'] != ""
    assert date_time['date_time']['tz_offset'] != ""

# Generated at 2022-06-23 01:07:01.078693
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'


# Generated at 2022-06-23 01:07:02.912996
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    a = DateTimeFactCollector()
    assert(a.name == 'date_time')

# Generated at 2022-06-23 01:07:05.847137
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dateTime = DateTimeFactCollector()

    #Verifying if the date_time facts are available
    dateTime_facts = dateTime.collect()
    assert 'date_time' in dateTime_facts

# Generated at 2022-06-23 01:07:14.548189
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible_collections.ansible.community.plugins.module_utils.facts import collector
    from ansible.module_utils.facts.collector import get_collector_instances

    fc = collector.CollectorFactory()
    (dtfc,) = get_collector_instances(fc, [DateTimeFactCollector,])
    result = dtfc.collect()

# Generated at 2022-06-23 01:07:15.733265
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()

# Generated at 2022-06-23 01:07:21.071188
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'
    assert date_time_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:07:32.747421
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fc = DateTimeFactCollector()
    date_time_facts = date_time_fc.collect()

# Generated at 2022-06-23 01:07:35.731397
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector.name == 'date_time'
    assert isinstance(DateTimeFactCollector._fact_ids, (set,)) == True

# Generated at 2022-06-23 01:07:39.638446
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    '''Unit test for constructor of class DateTimeFactCollector'''
    obj = DateTimeFactCollector()
    assert obj.name == 'date_time'
    assert isinstance(obj._fact_ids, set)


# Generated at 2022-06-23 01:07:46.353695
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Unit test for the method collect of the class DateTimeFactCollector
    """

    # Test the case where the module parameter is not a module
    dtfc = DateTimeFactCollector()
    result = dtfc.collect(collected_facts=None)

    assert len(result.items()) == 1
    assert 'date_time' in result

    # Test the case where the module parameter is a module
    dtfc2 = DateTimeFactCollector()
    result = dtfc2.collect(collected_facts=None)

    assert len(result.items()) == 1
    assert 'date_time' in result

# Generated at 2022-06-23 01:07:49.365344
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
  DateTimeFactCollector()



# Generated at 2022-06-23 01:07:59.005317
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    input_module = None
    input_collected_facts = None

# Generated at 2022-06-23 01:08:03.481457
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():

    # Testing if the constructor of DateTimeFactCollector returns a object.
    obj=DateTimeFactCollector()
    assert obj is not None


# Generated at 2022-06-23 01:08:07.195008
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'
    assert set(x._fact_ids) == set()


# Generated at 2022-06-23 01:08:09.621470
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    instance = DateTimeFactCollector()

    assert instance.name == 'date_time'
    assert instance._fact_ids == set()

# Generated at 2022-06-23 01:08:21.210998
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_obj = DateTimeFactCollector()
    result = test_obj.collect()
    assert result['date_time'] is not None
    assert result['date_time']['iso8601_micro'] is not None
    assert result['date_time']['iso8601'] is not None
    assert result['date_time']['time'] is not None
    assert result['date_time']['tz'] is not None
    assert result['date_time']['tz_dst'] is not None
    assert result['date_time']['tz_offset'] is not None
    assert result['date_time']['date'] is not None
    assert result['date_time']['year'] is not None
    assert result['date_time']['month'] is not None