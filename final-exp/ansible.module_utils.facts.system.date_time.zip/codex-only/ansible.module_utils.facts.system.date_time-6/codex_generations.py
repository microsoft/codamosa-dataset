

# Generated at 2022-06-23 00:58:18.093321
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_facts = DateTimeFactCollector()
    assert date_time_facts.name == 'date_time'

# Generated at 2022-06-23 00:58:20.169430
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_facts = DateTimeFactCollector()
    assert date_time_facts.name == 'date_time'
    assert date_time_facts._fact_ids == set()


# Generated at 2022-06-23 00:58:22.879861
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt.name == 'date_time'

# Generated at 2022-06-23 00:58:27.129007
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector.name == 'date_time'
    assert isinstance(DateTimeFactCollector._fact_ids, set)
    assert DateTimeFactCollector.collect()['date_time']['year'] == str(datetime.datetime.now().year)

# Generated at 2022-06-23 00:58:31.226035
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector(None)
    assert obj.name == "date_time"
    assert obj._fact_ids == set(["date_time"])

# Generated at 2022-06-23 00:58:33.626435
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    c = DateTimeFactCollector()
    assert c.name == 'date_time'
    assert set(c._fact_ids) == set()

# Generated at 2022-06-23 00:58:36.412843
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector._name == 'date_time'
    instance = DateTimeFactCollector()
    assert instance._name == 'date_time'
    assert instance._fact_ids == set()

# Generated at 2022-06-23 00:58:49.514823
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtf = DateTimeFactCollector()
    dtf.collect()
    assert dtf.collect()['date_time']['year'] == str(time.localtime().tm_year)
    assert dtf.collect()['date_time']['month'] == str(time.localtime().tm_mon)
    assert dtf.collect()['date_time']['weekday'] == time.strftime('%A', time.localtime())
    assert dtf.collect()['date_time']['weekday_number'] == str(time.localtime().tm_wday)
    assert dtf.collect()['date_time']['weeknumber'] == str(time.localtime().tm_yday)

# Generated at 2022-06-23 00:58:53.614781
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dc = DateTimeFactCollector()
    facts = dc.collect()
    assert 'date_time' in facts
    assert 'minute' in facts['date_time']

# Generated at 2022-06-23 00:58:55.779441
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_facts = DateTimeFactCollector()
    assert date_time_facts.name == 'date_time'

# Generated at 2022-06-23 00:59:02.025004
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Check without parameters
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'
    assert dtfc.collect() == {}

    # Check with empty dictionary
    dtfc = DateTimeFactCollector({})
    assert dtfc.name == 'date_time'
    assert dtfc.collect() == {}

# Generated at 2022-06-23 00:59:04.369556
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector


# Generated at 2022-06-23 00:59:13.894188
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_collector = DateTimeFactCollector()
    date_time_facts = date_time_collector.collect()
    assert date_time_facts.keys()[0] == 'date_time'
    assert 'year' in date_time_facts['date_time']
    assert 'month' in date_time_facts['date_time']
    assert 'weekday' in date_time_facts['date_time']
    assert 'weekday_number' in date_time_facts['date_time']
    assert 'weeknumber' in date_time_facts['date_time']
    assert 'day' in date_time_facts['date_time']
    assert 'hour' in date_time_facts['date_time']
    assert 'minute' in date_time_facts['date_time']

# Generated at 2022-06-23 00:59:22.611129
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    datetime_collector = DateTimeFactCollector()
    facts = datetime_collector.collect()
    assert 'date_time' in facts
    assert 'year' in facts['date_time']
    assert 'month' in facts['date_time']
    assert 'weekday' in facts['date_time']
    assert 'weekday_number' in facts['date_time']
    assert 'weeknumber' in facts['date_time']
    assert 'day' in facts['date_time']
    assert 'hour' in facts['date_time']
    assert 'minute' in facts['date_time']
    assert 'second' in facts['date_time']
    assert 'epoch' in facts['date_time']
    assert 'epoch_int' in facts['date_time']

# Generated at 2022-06-23 00:59:24.498210
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # From local facts module
    d = DateTimeFactCollector()
    assert d is not None

# Generated at 2022-06-23 00:59:37.490442
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtf = DateTimeFactCollector()

# Generated at 2022-06-23 00:59:39.071061
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()


# Generated at 2022-06-23 00:59:41.630697
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Fixture is a DateTimeFactCollector instance
    fixture = DateTimeFactCollector()

    # Test collect method
    assert 'date_time' in fixture.collect()

# Generated at 2022-06-23 00:59:45.607731
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()

# Generated at 2022-06-23 00:59:58.126213
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    c = DateTimeFactCollector()
    facts = c.collect()
    date_time_facts = facts['date_time']

    assert 'year' in date_time_facts.keys()
    assert 'month' in date_time_facts.keys()
    assert 'weekday' in date_time_facts.keys()
    assert 'weekday_number' in date_time_facts.keys()
    assert 'weeknumber' in date_time_facts.keys()
    assert 'day' in date_time_facts.keys()
    assert 'hour' in date_time_facts.keys()
    assert 'minute' in date_time_facts.keys()
    assert 'second' in date_time_facts.keys()
    assert 'epoch' in date_time_facts.keys()
    assert 'epoch_int' in date_

# Generated at 2022-06-23 01:00:00.200464
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    c = DateTimeFactCollector()
    assert c.name == 'date_time'


# Generated at 2022-06-23 01:00:11.973690
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = DateTimeFactCollector()
    dt_dict = dt.collect()
    assert 'date_time' in dt_dict
    assert 'year' in dt_dict['date_time']
    assert 'month' in dt_dict['date_time']
    assert 'weekday' in dt_dict['date_time']
    assert 'weekday_number' in dt_dict['date_time']
    assert 'weeknumber' in dt_dict['date_time']
    assert 'day' in dt_dict['date_time']
    assert 'hour' in dt_dict['date_time']
    assert 'minute' in dt_dict['date_time']
    assert 'second' in dt_dict['date_time']

# Generated at 2022-06-23 01:00:15.387744
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # simple tests, to be expanded
    dt = DateTimeFactCollector()
    facts = dt.collect()
    assert(facts['date_time']['year'] != "")

# Generated at 2022-06-23 01:00:17.210302
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt_facts = DateTimeFactCollector()
    assert dt_facts.name == 'date_time'

# Generated at 2022-06-23 01:00:19.335210
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    assert dtfc.collect()

# Generated at 2022-06-23 01:00:22.272442
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'

# Generated at 2022-06-23 01:00:24.596491
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector() # noqa


# Generated at 2022-06-23 01:00:35.064015
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Create class instance
    dtfc = DateTimeFactCollector()
    result = dtfc.collect()

    # These facts should be defined, and should always be strings
    assert all(k in result['date_time'].keys() for k in ["year", "month", "weekday", "weekday_number", "weeknumber", "day", "hour", "minute", "second", "epoch", "epoch_int", "date", "time", "iso8601", "iso8601_basic", "iso8601_basic_short", "tz", "tz_dst", "tz_offset"])
    assert all(isinstance(x, str) for x in result['date_time'].values())

# Generated at 2022-06-23 01:00:43.943519
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Unit test for method collect of class DateTimeFactCollector
    """

    def __mock_now_time(value):
        """Returns a mock datetime.datetime.now object"""
        return datetime.datetime.fromtimestamp(value)

    # Create a DateTimeFactCollector object
    datetime_fact_collector = DateTimeFactCollector()

    # Set mock values for datetime.datetime.now object to return epoch_ts
    epoch_ts = 140000000
    datetime_fact_collector.__mock_now = __mock_now_time(epoch_ts)

    # Get a facts_dict for date_time fact
    facts_dict = datetime_fact_collector.collect()

    # Assert the return dictionary

# Generated at 2022-06-23 01:00:46.290032
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector is not None

# Generated at 2022-06-23 01:00:58.337350
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    facts = fact_collector.collect()
    assert 'date_time' in facts
    assert 'year' in facts['date_time']
    assert 'month' in facts['date_time']
    assert 'weekday' in facts['date_time']
    assert 'weekday_number' in facts['date_time']
    assert 'weeknumber' in facts['date_time']
    assert 'day' in facts['date_time']
    assert 'hour' in facts['date_time']
    assert 'minute' in facts['date_time']
    assert 'second' in facts['date_time']
    assert 'epoch' in facts['date_time']
    assert 'epoch_int' in facts['date_time']
    assert 'date' in facts['date_time']


# Generated at 2022-06-23 01:01:02.461675
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    d = DateTimeFactCollector()
    assert d.name == 'date_time'
    assert isinstance(d.collect(), dict)

# Generated at 2022-06-23 01:01:10.591708
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    result = fact_collector.collect()
    assert(len(fact_collector._fact_ids) == 0)
    assert('date_time' in result)
    assert(len(result['date_time']) == 24)
    assert(result['date_time']['epoch'] == result['date_time']['epoch_int'])
    assert(int(result['date_time']['epoch']) > 0)
    assert(result['date_time']['iso8601'][-1] == 'Z')
    assert(int(result['date_time']['tz_offset']) in range(-1200, +1200))

# Generated at 2022-06-23 01:01:16.109291
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    import sys
    date_time_facts = DateTimeFactCollector()
    # Required by ansible
    for key in date_time_facts.collect().keys():
        sys.modules[__name__].__dict__[key] = date_time_facts.collect()[key]

# Generated at 2022-06-23 01:01:27.568838
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import sys
    import fact_collector

    datetime_facts = {}
    # Store the timestamp once, then get local and UTC versions from that
    epoch_ts = time.time()
    now = datetime.datetime.fromtimestamp(epoch_ts)
    utcnow = datetime.datetime.utcfromtimestamp(epoch_ts)

    datetime_facts['year'] = now.strftime('%Y')
    datetime_facts['month'] = now.strftime('%m')
    datetime_facts['weekday'] = now.strftime('%A')
    datetime_facts['weekday_number'] = now.strftime('%w')
    datetime_facts['weeknumber'] = now.strftime('%W')
    datetime_facts['day'] = now.strftime('%d')

# Generated at 2022-06-23 01:01:35.258600
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    facts = dtfc.collect()
    assert isinstance(facts, dict)

    assert 'date_time' in facts
    assert facts['date_time']
    assert isinstance(facts['date_time'], dict)

    daily_keys_exist = ('day', 'date', 'weekday_number', 'weekday', 'month', 'year', 'hour', 'weeknumber')

# Generated at 2022-06-23 01:01:37.657673
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    fact_collector = DateTimeFactCollector()
    assert fact_collector.name == 'date_time'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:01:42.039312
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    test_fact_collector = DateTimeFactCollector()
    assert test_fact_collector.name == 'date_time'
    assert isinstance(test_fact_collector._fact_ids, set)
    assert not test_fact_collector._fact_ids

# Generated at 2022-06-23 01:01:46.636832
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert isinstance(DateTimeFactCollector(), BaseFactCollector) and (len(DateTimeFactCollector().collect().keys()) == 1)

# Generated at 2022-06-23 01:01:48.059898
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector.name == 'date_time'

# Generated at 2022-06-23 01:01:58.019137
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt_facts = DateTimeFactCollector()
    ans_facts = dt_facts.collect()

    # Only test a subset of fields to minimize the impact of changes
    assert 'date_time' in ans_facts
    date_time_facts = ans_facts['date_time']
    assert 'day' in date_time_facts
    assert 'hour' in date_time_facts
    assert 'minute' in date_time_facts
    assert 'second' in date_time_facts
    assert 'iso8601' in date_time_facts
    assert 'iso8601_basic' in date_time_facts
    assert 'iso8601_micro' in date_time_facts
    assert 'iso8601_basic_short' in date_time_facts
    assert 'tz_offset' in date_time_facts

    # Test that

# Generated at 2022-06-23 01:01:59.712059
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt.name == 'date_time'
    assert dt._fact_ids == set()

# Generated at 2022-06-23 01:02:02.614845
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()

    assert dtfc
    assert dtfc.name == 'date_time'
    assert not dtfc._fact_ids


# Generated at 2022-06-23 01:02:07.108989
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dateTimeFactCollector = DateTimeFactCollector()
    assert dateTimeFactCollector.name == 'date_time'
    assert not dateTimeFactCollector._fact_ids

# Generated at 2022-06-23 01:02:11.746413
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # ensure_list will only take list as argument
    obj = DateTimeFactCollector()
    assert obj.name == "date_time", "name of DateTimeFactCollector should be date_time"
    assert obj._fact_ids == set(), "_fact_ids of DateTimeFactCollector should be set"

# Generated at 2022-06-23 01:02:14.186286
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'
    assert dtfc._fact_ids == set()

# Generated at 2022-06-23 01:02:16.498586
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector is not None


# Generated at 2022-06-23 01:02:18.318296
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj.name == 'date_time'

# Generated at 2022-06-23 01:02:23.132912
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    #
    # Create a DateTimeFactCollector and try to collect
    # facts with the constructor
    #
    date_time_fact_collector = DateTimeFactCollector()

    #
    # Check the result against known values
    #
    assert isinstance(date_time_fact_collector.collect(None), dict)
    assert 'date_time' in date_time_fact_collector.collect(None)
    return

# Generated at 2022-06-23 01:02:35.135815
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    no_collector = DateTimeFactCollector()
    result = no_collector.collect({})
    assert isinstance(result, dict)
    assert result['date_time']['year'] == str(datetime.datetime.utcnow().strftime('%Y'))
    assert result['date_time']['month'] == str(datetime.datetime.utcnow().strftime('%m'))
    assert result['date_time']['weekday'] == str(datetime.datetime.utcnow().strftime('%A'))
    assert result['date_time']['weekday_number'] == str(datetime.datetime.utcnow().strftime('%w'))

# Generated at 2022-06-23 01:02:41.344505
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    dtfc_result = dtfc.collect()
    assert isinstance(dtfc_result, dict)
    assert 'date_time' in dtfc_result
    dtfc_result = dtfc_result['date_time']
    assert 'iso8601' in dtfc_result
    assert 'tz' in dtfc_result
    assert 'tz_offset' in dtfc_result

# Generated at 2022-06-23 01:02:50.080796
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector({})
    date_time_dict = fact_collector.collect()
    date_time_facts = date_time_dict.get('date_time')
    assert date_time_facts['year'] == datetime.datetime.now().strftime('%Y')
    assert date_time_facts['month'] == datetime.datetime.now().strftime('%m')
    assert date_time_facts['weekday'] == datetime.datetime.now().strftime('%A')
    assert date_time_facts['weekday_number'] == datetime.datetime.now().strftime('%w')
    assert date_time_facts['weeknumber'] == datetime.datetime.now().strftime('%W')
    assert date_time_facts['day'] == datetime.dat

# Generated at 2022-06-23 01:02:53.410378
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()

    assert date_time_fact_collector.name == 'date_time'

    assert date_time_fact_collector.collect()

    return

# Generated at 2022-06-23 01:03:05.085262
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collector = DateTimeFactCollector()
    facts = collector.collect()
    if facts:
        assert('date_time' in facts)
        date_time = facts['date_time']
        assert('year' in date_time)
        assert('month' in date_time)
        assert('weekday' in date_time)
        assert('weekday_number' in date_time)
        assert('weeknumber' in date_time)
        assert('day' in date_time)
        assert('hour' in date_time)
        assert('minute' in date_time)
        assert('second' in date_time)
        assert('epoch' in date_time)
        assert('epoch_int' in date_time)
        assert('date' in date_time)
        assert('time' in date_time)
       

# Generated at 2022-06-23 01:03:14.768877
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    now = datetime.datetime.now()

# Generated at 2022-06-23 01:03:28.282905
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    result = fact_collector.collect()

    # Only testing non-epoch facts as epoch facts cannot be tested due to
    # the fact that the test will take longer than a second to run.
    assert result['date_time']['year'] == time.strftime("%Y")
    assert result['date_time']['month'] == time.strftime("%m")
    assert result['date_time']['weekday'] == time.strftime("%A")
    assert result['date_time']['weekday_number'] == time.strftime("%w")
    assert result['date_time']['weeknumber'] == time.strftime("%W")
    assert result['date_time']['day'] == time.strftime("%d")
    assert result

# Generated at 2022-06-23 01:03:38.675166
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_collector = DateTimeFactCollector()
    date_time_fact = date_time_collector.collect()
    assert date_time_fact['date_time']['year']
    assert date_time_fact['date_time']['month']
    assert date_time_fact['date_time']['weekday']
    assert date_time_fact['date_time']['weekday_number']
    assert date_time_fact['date_time']['weeknumber']
    assert date_time_fact['date_time']['day']
    assert date_time_fact['date_time']['hour']
    assert date_time_fact['date_time']['minute']
    assert date_time_fact['date_time']['second']

# Generated at 2022-06-23 01:03:41.701163
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'


# Generated at 2022-06-23 01:03:50.891622
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    a = DateTimeFactCollector()
    result = a.collect()

    assert 'date_time' in result
    assert result['date_time']
    assert 'year' in result['date_time']
    assert 'month' in result['date_time']
    assert 'weekday' in result['date_time']
    assert 'weekday_number' in result['date_time']
    assert 'weeknumber' in result['date_time']
    assert 'day' in result['date_time']
    assert 'hour' in result['date_time']
    assert 'minute' in result['date_time']
    assert 'second' in result['date_time']
    assert 'epoch' in result['date_time']
    assert 'epoch_int' in result['date_time']

# Generated at 2022-06-23 01:03:53.158823
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    res = DateTimeFactCollector().collect()
    assert res['date_time']['weekday'] != ''

# Generated at 2022-06-23 01:04:04.155895
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    a = 'abc'
    b = {'a': 'b'}
    fact_collector = DateTimeFactCollector()
    fact_collector.collect(a, b)
    facts_dict = fact_collector.collect(a, b)
    assert 'date_time' in facts_dict
    assert 'year' in facts_dict['date_time']
    assert 'month' in facts_dict['date_time']
    assert 'weekday' in facts_dict['date_time']
    assert 'weekday_number' in facts_dict['date_time']
    assert 'weeknumber' in facts_dict['date_time']
    assert 'day' in facts_dict['date_time']
    assert 'hour' in facts_dict['date_time']
    assert 'minute' in facts_dict['date_time']


# Generated at 2022-06-23 01:04:15.397729
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_collector = DateTimeFactCollector()
    result = date_time_collector.collect()
    assert result
    # ensure all the keys are in the json result
    assert 'date_time' in result
    assert 'weekday' in result['date_time']
    assert 'time' in result['date_time']
    assert 'year' in result['date_time']
    assert 'date' in result['date_time']
    assert 'epoch' in result['date_time']
    assert 'tz' in result['date_time']
    assert 'tz_dst' in result['date_time']
    assert 'tz_offset' in result['date_time']


# Generated at 2022-06-23 01:04:26.711808
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    datetimeFactCollectorInstance = DateTimeFactCollector()
    epoch_ts = time.time()
    now = datetime.datetime.fromtimestamp(epoch_ts)
    utcnow = datetime.datetime.utcfromtimestamp(epoch_ts)

# Generated at 2022-06-23 01:04:29.433207
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj.name == 'date_time'

# Generated at 2022-06-23 01:04:39.830612
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact = DateTimeFactCollector()
    result = fact.collect()
    assert 'date_time' in result
    assert 'time' in result['date_time']
    assert 'epoch' in result['date_time']
    assert 'date' in result['date_time']
    assert 'year' in result['date_time']
    assert 'month' in result['date_time']
    assert 'weekday' in result['date_time']
    assert 'weekday_number' in result['date_time']
    assert 'weeknumber' in result['date_time']
    assert 'day' in result['date_time']
    assert 'hour' in result['date_time']
    assert 'minute' in result['date_time']
    assert 'second' in result['date_time']

# Generated at 2022-06-23 01:04:52.445172
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    facter = DateTimeFactCollector()
    result = facter.collect()
    assert result['date_time']['iso8601_basic_short'] != u''
    assert result['date_time']['tz'] != u''
    assert result['date_time']['day'] != u''
    assert result['date_time']['second'] != u''
    assert result['date_time']['year'] != u''
    assert result['date_time']['iso8601'] != u''
    assert result['date_time']['iso8601_micro'] != u''
    assert result['date_time']['tz_offset'] != u''
    assert result['date_time']['tz_dst'] != u''
    assert result['date_time']['date'] != u''

# Generated at 2022-06-23 01:04:56.177759
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    o = DateTimeFactCollector()
    assert o.name == 'date_time'
    assert o._fact_ids == set(), "_fact_ids should be set()"

# Generated at 2022-06-23 01:05:02.879136
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()

    assert dt.name == 'date_time', 'Expected date_time, found %s' % dt.name
    assert len(dt._fact_ids) == 1, 'Expected exactly one fact id, found %s' % len(dt._fact_ids)
    assert 'date_time' in dt._fact_ids, 'Expected date_time in %s' % dt._fact_ids



# Generated at 2022-06-23 01:05:05.251739
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'

# Generated at 2022-06-23 01:05:20.564381
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Test the collect method of DateTimeFactCollector
    """
    dt_fc = DateTimeFactCollector()

    # Testing the collect method.
    # The collect method of DateTimeFactCollector has no return value.
    # Testing that the return value is None.

# Generated at 2022-06-23 01:05:22.137610
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    DateTimeFactCollector().collect()

# Generated at 2022-06-23 01:05:31.905190
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-23 01:05:35.402302
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_facts = DateTimeFactCollector()
    assert date_time_facts.name == 'date_time'
    assert date_time_facts._fact_ids == set()


# Generated at 2022-06-23 01:05:38.309966
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    test_collector = DateTimeFactCollector()
    assert test_collector.name == 'date_time'
    assert isinstance(test_collector._fact_ids, set)

# Generated at 2022-06-23 01:05:42.239228
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()
    assert collector.name == 'date_time'
    assert isinstance(collector._fact_ids, set)
    assert len(collector._fact_ids) == 0


# Generated at 2022-06-23 01:05:45.548047
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()
    assert collector.name == 'date_time'
    assert isinstance(collector._fact_ids, set)


# Generated at 2022-06-23 01:05:54.521668
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Unit test for method collect of class DateTimeFactCollector
    """
    dtfc = DateTimeFactCollector()
    facts = dtfc.collect()
    assert isinstance(facts, dict)
    assert 'date_time' in facts
    assert isinstance(facts['date_time'], dict)
    # Ensure an epoch fact is present
    assert 'epoch' in facts['date_time']
    assert 'epoch' in facts['date_time']
    # Ensure an epoch_int fact is present
    assert 'epoch_int' in facts['date_time']
    assert 'epoch_int' in facts['date_time']
    # Ensure all the other facts are present
    assert 'year' in facts['date_time']
    assert 'month' in facts['date_time']
    assert 'weekday'

# Generated at 2022-06-23 01:06:05.281860
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    now = datetime.datetime.now()
    epoch_ts = time.time()
    dtf = DateTimeFactCollector()
    assert dtf.name == "date_time"
    assert dtf.collect()['date_time']['month'] == now.strftime('%m')
    assert dtf.collect()['date_time']['year'] == now.strftime('%Y')
    assert dtf.collect()['date_time']['weekday'] == now.strftime('%A')
    assert dtf.collect()['date_time']['weekday_number'] == now.strftime('%w')
    assert dtf.collect()['date_time']['weeknumber'] == now.strftime('%W')
    assert dtf.collect()['date_time']['day'] == now

# Generated at 2022-06-23 01:06:08.053483
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector.__name__ == "DateTimeFactCollector"
    assert isinstance(DateTimeFactCollector, BaseFactCollector)

# Generated at 2022-06-23 01:06:10.094192
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt.name == 'date_time'
    assert len(dt._fact_ids) == 0

# Generated at 2022-06-23 01:06:11.693187
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    d = DateTimeFactCollector()
    result = d.collect()
    assert "date_time" in result

# Generated at 2022-06-23 01:06:13.883090
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'
    assert x._fact_ids == set()


# Generated at 2022-06-23 01:06:22.880553
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    result = DateTimeFactCollector().collect()

    # check structure of result
    assert isinstance(result, dict)
    assert 'date_time' in result
    assert isinstance(result['date_time'], dict)

    # check date_time keys
    date_time_keys = (
        'year', 'month', 'weekday', 'weekday_number', 'weeknumber', 'day',
        'hour', 'minute', 'second', 'epoch', 'epoch_int', 'date', 'time',
        'iso8601_micro', 'iso8601', 'iso8601_basic', 'iso8601_basic_short',
        'tz', 'tz_dst', 'tz_offset'
    )

    # check presence of keys

# Generated at 2022-06-23 01:06:26.357624
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()

    # We want to test these properties.
    assert collector.name == 'date_time'

# Generated at 2022-06-23 01:06:38.292849
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    collector = DateTimeFactCollector()
    facts = collector.collect()

    assert facts['date_time']['year'] == datetime.datetime.now().strftime('%Y')
    assert facts['date_time']['month'] == datetime.datetime.now().strftime('%m')
    assert facts['date_time']['weekday'] == datetime.datetime.now().strftime('%A')
    assert facts['date_time']['weekday_number'] == datetime.datetime.now().strftime('%w')
    assert facts['date_time']['weeknumber'] == datetime.datetime.now().strftime('%W')
    assert facts['date_time']['day'] == datetime.datetime.now().strftime('%d')

# Generated at 2022-06-23 01:06:40.875572
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtf = DateTimeFactCollector()
    assert dtf.name == 'date_time'
    assert dtf.collect()['date_time']['tz_offset'] == time.strftime("%z")

# Generated at 2022-06-23 01:06:53.976315
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    module = None
    collected_facts = None
    date_time_fact_collector = DateTimeFactCollector()
    test_date_time_facts = date_time_fact_collector.collect(module, collected_facts)
    assert isinstance(test_date_time_facts, dict)
    assert 'date_time' in test_date_time_facts.keys()
    assert isinstance(test_date_time_facts['date_time'], dict)
    assert 'year' in test_date_time_facts['date_time'].keys()
    assert isinstance(test_date_time_facts['date_time']['year'], str)
    assert 'month' in test_date_time_facts['date_time'].keys()

# Generated at 2022-06-23 01:06:56.242758
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert hasattr(dtfc, 'name') and dtfc.name == 'date_time'

# Generated at 2022-06-23 01:07:06.072113
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    o = DateTimeFactCollector()
    test_result = o.collect(collected_facts=None)
    assert 'date_time' in test_result
    assert 'date' in test_result['date_time']
    assert 'time' in test_result['date_time']
    assert 'year' in test_result['date_time']
    assert 'month' in test_result['date_time']
    assert 'weekday' in test_result['date_time']
    assert 'weekday_number' in test_result['date_time']
    assert 'day' in test_result['date_time']
    assert 'hour' in test_result['date_time']
    assert 'minute' in test_result['date_time']
    assert 'second' in test_result['date_time']
    assert 'epoch'

# Generated at 2022-06-23 01:07:08.091557
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()
    assert type(collector) == DateTimeFactCollector

# Generated at 2022-06-23 01:07:19.723116
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collector = DateTimeFactCollector()
    now = datetime.datetime.now()
    result = collector.collect()

# Generated at 2022-06-23 01:07:24.388406
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Create class object and test for object creation
    dt_collector_obj = DateTimeFactCollector()
    assert dt_collector_obj is not None
    # Test class attributes
    assert dt_collector_obj.name == 'date_time'
    assert dt_collector_obj._fact_ids == set()



# Generated at 2022-06-23 01:07:35.061873
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import pytest
    # Data processing
    result = DateTimeFactCollector().collect()
    # Assertions
    assert type(result) is dict
    assert type(result['date_time']) is dict
    assert type(result['date_time']['year']) is str
    assert type(result['date_time']['month']) is str
    assert type(result['date_time']['weekday']) is str
    assert type(result['date_time']['weekday_number']) is str
    assert type(result['date_time']['weeknumber']) is str
    assert type(result['date_time']['day']) is str
    assert type(result['date_time']['hour']) is str
    assert type(result['date_time']['minute']) is str

# Generated at 2022-06-23 01:07:37.165700
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    Facts = DateTimeFactCollector()
    collected_facts = Facts.collect()
    assert collected_facts is not None

# Generated at 2022-06-23 01:07:38.745449
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj.name == 'date_time'

# Generated at 2022-06-23 01:07:50.246284
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt_col = DateTimeFactCollector()
    dt_col_facts = dt_col.collect(None, None)

    assert 'date_time' in dt_col_facts
    assert 'date' in dt_col_facts['date_time']
    assert 'epoch' in dt_col_facts['date_time']
    assert 'epoch_int' in dt_col_facts['date_time']
    assert 'hour' in dt_col_facts['date_time']
    assert 'iso8601' in dt_col_facts['date_time']
    assert 'iso8601_basic' in dt_col_facts['date_time']
    assert 'iso8601_basic_short' in dt_col_facts['date_time']
    assert 'iso8601_micro'

# Generated at 2022-06-23 01:07:51.515014
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    result = DateTimeFactCollector()
    assert result.name == 'date_time'

# Generated at 2022-06-23 01:07:53.064884
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtf = DateTimeFactCollector()
    assert dtf.name == "date_time"

# Generated at 2022-06-23 01:08:03.043524
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import doctest
    from ansible.module_utils.facts import ansible_facts
    m_module = type('module', (), {'params':{'gather_subset': 'all'}, 'exit_json': lambda x: None, 'fail_json': lambda x: None})()
    result = ansible_facts.get_fact_dict(m_module)
    assert 'date_time' in result
    print(result['date_time'])
    print(result['date_time']['iso8601_micro'])
    assert doctest.testmod()[0] == 0

# Generated at 2022-06-23 01:08:10.969440
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    test_collector = get_collector_instance('DateTimeFactCollector')
    result = test_collector.collect()
    assert(result['date_time']['month'])
    assert(result['date_time']['day'])
    assert(result['date_time']['epoch_int'])
    assert(result['date_time']['tz'])

# Generated at 2022-06-23 01:08:22.196835
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    test_DateTimeFactCollector_collect:
    Test that DateTimeFactCollector class method collect() is working as expected
    """

    # Using assertEqual and assertTrue methods of unittest.TestCase
    # https://docs.python.org/2/library/unittest.html#assert-methods

    import datetime
    import time

    # Create a DateTimeFactCollector object
    dtf = DateTimeFactCollector()
    dtf._fact_ids = set()

    # Get date_time facts
    dt_facts_dict = dtf.collect()
    assertEqual(dt_facts_dict.has_key('date_time'), True)

    # Get current values of date_time facts
    now = datetime.datetime.now()
    utcnow = datetime.datetime.ut