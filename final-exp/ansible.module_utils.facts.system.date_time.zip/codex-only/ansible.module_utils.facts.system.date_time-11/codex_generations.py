

# Generated at 2022-06-23 00:58:24.546071
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()
    assert 'date_time' in collector.collect().keys()
    assert 'year' in collector.collect()['date_time']
    assert 'epoch' in collector.collect()['date_time']
    assert 'epoch_int' in collector.collect()['date_time']
    assert 'iso8601_micro' in collector.collect()['date_time']

# Generated at 2022-06-23 00:58:35.466669
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """ Unit test for method collect of class DateTimeFactCollector
    """
    date_time_facts = DateTimeFactCollector()
    facts = date_time_facts.collect()

    required_facts = dict(
        date_time = dict(
            iso8601 = 'defined',
            iso8601_basic = 'defined',
            iso8601_basic_short = 'defined',
            iso8601_micro = 'defined',
            tz = 'defined',
            tz_dst = 'defined',
            tz_offset = 'defined'
            )
        )
    for key in required_facts['date_time']:
        assert facts['date_time'][key] == required_facts['date_time'][key]


# Generated at 2022-06-23 00:58:48.733711
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact = DateTimeFactCollector()
    date_time_fact_result = date_time_fact.collect()
    assert 'date_time' in date_time_fact_result
    for date_time_fact_key in ('day', 'time', 'month', 'year', 'epoch', 'iso8601', 'weekday_number',
                               'tz_dst', 'weeknumber', 'iso8601_basic', 'weekday', 'tz_offset', 'date',
                               'tz', 'iso8601_basic_short', 'iso8601_micro', 'hour', 'epoch_int',
                               'minute', 'second'):
        assert date_time_fact_key in date_time_fact_result['date_time']

# Generated at 2022-06-23 00:58:52.470687
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():

    obj = DateTimeFactCollector()
    assert obj.name == 'date_time'
    assert len(obj._fact_ids) == 0

# Generated at 2022-06-23 00:58:55.652802
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'
    assert x._fact_ids == set()


# Generated at 2022-06-23 00:58:58.011100
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Return value of collect method
    collector = DateTimeFactCollector()
    facts = collector.collect()
    assert 'date_time' in facts

# Generated at 2022-06-23 00:59:00.723547
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt_collector = DateTimeFactCollector()
    assert dt_collector.name == 'date_time'

# Generated at 2022-06-23 00:59:11.491331
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Verify class name
    assert DateTimeFactCollector().name == 'date_time'

    # Verify that class is getting facts to be collected
    assert 'date_time' in DateTimeFactCollector().collect()

    # Verify that date_time facts are being collected
    dateTimeFact = DateTimeFactCollector().collect().get('date_time')
    assert dateTimeFact.get('year') is not None
    assert dateTimeFact.get('month') is not None
    assert dateTimeFact.get('weekday') is not None
    assert dateTimeFact.get('weekday_number') is not None
    assert dateTimeFact.get('day') is not None
    assert dateTimeFact.get('hour') is not None
    assert dateTimeFact.get('minute') is not None
    assert dateTimeFact.get('second') is not None


# Generated at 2022-06-23 00:59:14.021223
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    """
    Test case for the class DateTimeFactCollector.
    """
    datetimefact = DateTimeFactCollector()
    assert datetimefact.name == 'date_time'

# Generated at 2022-06-23 00:59:22.720870
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collected_facts = dict()
    dtfc = DateTimeFactCollector('date_time', collected_facts)
    res = dtfc.collect()

    assert isinstance(res, dict)
    assert 'date_time' in res
    assert isinstance(res['date_time'], dict)

    assert 'year' in res['date_time']
    assert isinstance(res['date_time']['year'], str)
    assert len(res['date_time']['year'])

    assert 'month' in res['date_time']
    assert isinstance(res['date_time']['month'], str)
    assert len(res['date_time']['month'])

    assert 'weekday' in res['date_time']

# Generated at 2022-06-23 00:59:26.220642
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_collector = DateTimeFactCollector()
    assert date_time_collector.__class__.__name__ == "DateTimeFactCollector"
    assert date_time_collector.name == "date_time"

# Generated at 2022-06-23 00:59:30.924105
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_facts = DateTimeFactCollector()
    assert date_time_facts.name == "date_time"
    assert date_time_facts._fact_ids == set()


# Generated at 2022-06-23 00:59:34.442995
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collected_facts = {}
    collector = DateTimeFactCollector()
    fact_data = collector.collect(collected_facts=collected_facts)
    assert fact_data['date_time']['tz'] == time.strftime("%Z")

# Generated at 2022-06-23 00:59:35.488619
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    DateTimeFactCollector.collect()

# Generated at 2022-06-23 00:59:38.517566
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector(
        module=None,
        collected_facts=None
    )
    assert dtfc.name == 'date_time'
    assert dtfc._fact_ids == set()

# Generated at 2022-06-23 00:59:40.437367
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector().name == 'date_time'
    assert DateTimeFactCollector()._fact_ids == set()


# Generated at 2022-06-23 00:59:49.116254
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    actual_result = fact_collector.collect()
    assert actual_result['date_time']
    assert actual_result['date_time']['year']
    assert actual_result['date_time']['month']
    assert actual_result['date_time']['weekday_number']
    assert actual_result['date_time']['weeknumber']
    assert actual_result['date_time']['day']
    assert actual_result['date_time']['hour']
    assert actual_result['date_time']['minute']
    assert actual_result['date_time']['second']
    assert actual_result['date_time']['epoch']
    assert actual_result['date_time']['epoch_int']
    assert actual_

# Generated at 2022-06-23 00:59:52.336316
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = DateTimeFactCollector()
    dt.collect()

    assert dt.name == 'date_time'
    assert isinstance(dt._fact_ids, set)


# Generated at 2022-06-23 01:00:03.045856
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    '''Unit test for method collect of class DateTimeFactCollector'''
    dtf = DateTimeFactCollector()
    result = dtf.collect()

# Generated at 2022-06-23 01:00:14.156195
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # input parameters
    module=None
    collected_facts=None

    # expected results

# Generated at 2022-06-23 01:00:15.684150
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_collector = DateTimeFactCollector()
    assert date_time_collector is not None

# Generated at 2022-06-23 01:00:17.676467
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt_collector = DateTimeFactCollector()
    assert dt_collector.name == 'date_time'

# Generated at 2022-06-23 01:00:25.856270
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_collector = DateTimeFactCollector()
    date_time_facts = date_time_collector.collect()

    assert 'date_time' in date_time_facts

    # test for required facts
    for fact in ['year', 'month', 'weekday', 'weekday_number', 'day', 'hour',
                 'minute', 'second', 'epoch', 'epoch_int',
                 'date', 'time', 'tz', 'tz_dst', 'tz_offset']:
        assert fact in date_time_facts['date_time']

# Generated at 2022-06-23 01:00:35.930745
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # Construct DateTimeFactCollector object to test method collect
    date_time_fc = DateTimeFactCollector()

    # Call method collect
    date_time_facts = date_time_fc.collect()

    # Test it is a dictionary
    assert isinstance(date_time_facts, dict)

    # Test dictionary is not empty
    assert date_time_facts != {}

    # Test date_time is in dictionary
    assert 'date_time' in date_time_facts

    # Test date_time is a dictionary
    assert isinstance(date_time_facts['date_time'], dict)

    # Test date_time dictionary is not empty
    assert date_time_facts['date_time'] != {}

# Generated at 2022-06-23 01:00:38.387427
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'



# Generated at 2022-06-23 01:00:43.530037
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'
    # _fact_ids can be anything
    assert date_time_fact_collector._fact_ids is not None
    assert date_time_fact_collector._fact_ids != []

# Generated at 2022-06-23 01:00:45.664309
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt.name == 'datetime'


# Generated at 2022-06-23 01:00:54.796754
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dc = DateTimeFactCollector()

    time_now = time.time()
    time_later = time.time()
    while time_now > time_later:
        time_later = time.time()

    results = dc.collect()
    assert type(results['date_time']['epoch_int']) is str
    assert type(int(results['date_time']['epoch'])) is int
    assert int(results['date_time']['epoch']) <= int(time_later)
    assert type(results['date_time']['year']) is str
    assert type(results['date_time']['month']) is str
    assert type(results['date_time']['weekday']) is str
    assert type(results['date_time']['day']) is str
   

# Generated at 2022-06-23 01:00:59.228825
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Testing a non-integer epoch.
    datetime_facts = DateTimeFactCollector()
    datetime_facts_dict = datetime_facts.collect()
    assert datetime_facts_dict['date_time']['epoch_int'] != '%s'
    assert int(datetime_facts_dict['date_time']['epoch_int']) == int(time.time())

# Generated at 2022-06-23 01:01:09.726375
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """ Test the method collect of class DateTimeFactCollector """
    # Create an instance of DateTimeFactCollector
    lDateTimeFactCollector = DateTimeFactCollector()
    # Retrieve the facts
    ldate_time_fact = lDateTimeFactCollector.collect()
    # Check if the date_time fact is present
    assert 'date_time' in ldate_time_fact
    # Check some values in the date_time fact
    assert ldate_time_fact['date_time']['year'] is not None
    assert ldate_time_fact['date_time']['month'] is not None
    assert ldate_time_fact['date_time']['weekday_number'] is not None
    assert ldate_time_fact['date_time']['weekday'] is not None
    assert ldate_

# Generated at 2022-06-23 01:01:16.361587
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Generate instance of DateTimeFactCollector
    dc = DateTimeFactCollector()

    # Generate dictionary of required facts
    test_facts = dc.collect()

    # Assert that the datetime facts are not empty
    assert test_facts
    assert test_facts.get('date_time')
    assert test_facts.get('date_time').get('date')
    assert test_facts.get('date_time').get('time')
    assert test_facts.get('date_time').get('iso8601')

# Generated at 2022-06-23 01:01:24.979571
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Mock the params needed for the method collect of DateTimeFactCollector. (Return an empty dictionary)
    def fake_collect(self, module=None, collected_facts=None):
        return {}

    # Save the original method collect to m_collect.
    m_collect = DateTimeFactCollector.collect

    # Replace the method collect of DateTimeFactCollector with the fake_collect.
    DateTimeFactCollector.collect = fake_collect

    # Create an object of DateTimeFactCollector.
    dt_collector = DateTimeFactCollector()

    # The following are the expected results.

# Generated at 2022-06-23 01:01:32.549619
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Initializing class DateTimeFactCollector
    dtf = DateTimeFactCollector()
    # Getting epoch timestamp
    epoch_ts = time.time()
    # Getting date and time from timestamp
    now = datetime.datetime.fromtimestamp(epoch_ts)
    # Getting utc date and time from timestamp
    utcnow = datetime.datetime.utcfromtimestamp(epoch_ts)
    # Asserting date_time_facts with date and time
    date_time_facts = dtf._set_date_time_facts(now, utcnow, epoch_ts)
    assert date_time_facts['year'] == now.strftime('%Y')
    assert date_time_facts['month'] == now.strftime('%m')
    assert date_time_facts['weekday'] == now.str

# Generated at 2022-06-23 01:01:34.178537
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    #Test 1: Test the constructor
    DateTimeFactCollector()

# Generated at 2022-06-23 01:01:45.660311
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Returns ansible_facts gather date_time facts module data
    """
    class AnsibleModule:
        def fail_json(self, msg):
            raise Exception(msg)

    module = AnsibleModule()
    collector = DateTimeFactCollector(module=module)
    facts = collector.collect()
    assert facts["date_time"]["epoch"] == str(int(time.time()))
    assert facts["date_time"]["epoch_int"] == str(int(time.time()))
    assert facts["date_time"]["iso8601_basic"] == time.strftime("%Y%m%dT%H%M%S%f")

# Generated at 2022-06-23 01:01:54.807787
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts import gathering
    from ansible.module_utils.facts.collection import FactsCollectionManager
    from ansible.module_utils.facts.collectors.network import NetworkFactCollector
    from ansible.playbook import PlayContext

    from ansible.plugins.loader import vars_loader

    context = PlayContext()
    context.CLIARGS = {'module_vars': {}}
    fact_collection_manager = FactsCollectionManager(context)
    fact_collection_manager.add_collector(DateTimeFactCollector())

    result = fact_collection_manager.collect()

    assert result['date_time']['year'] == datetime.datetime.now().strftime('%Y')

# Generated at 2022-06-23 01:01:56.970079
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    time.strftime("%Y")
    test_obj = DateTimeFactCollector()
    assert isinstance(test_obj.collect(), dict)

# Generated at 2022-06-23 01:02:06.353704
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    dtfc_collect = dtfc.collect()
    assert dtfc_collect['date_time']['year'] is not None
    assert dtfc_collect['date_time']['month'] is not None
    assert dtfc_collect['date_time']['weekday'] is not None
    assert dtfc_collect['date_time']['weekday_number'] is not None
    assert dtfc_collect['date_time']['weeknumber'] is not None
    assert dtfc_collect['date_time']['day'] is not None
    assert dtfc_collect['date_time']['hour'] is not None
    assert dtfc_collect['date_time']['minute'] is not None

# Generated at 2022-06-23 01:02:08.369947
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt is not None


# Generated at 2022-06-23 01:02:10.743698
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()

    assert date_time_fact_collector.collect() != None

# Generated at 2022-06-23 01:02:12.315587
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    f = DateTimeFactCollector()
    assert f is not None

# Generated at 2022-06-23 01:02:15.598148
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'
    assert sorted(x._fact_ids) == ['date_time']
    assert DateTimeFactCollector.name == 'date_time'

# Generated at 2022-06-23 01:02:17.703014
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    assert collect()['date_time'] or collect()['date_time'] == {}

# Generated at 2022-06-23 01:02:21.216071
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    datetimefactcollector = DateTimeFactCollector()
    collected_date_time_facts = datetimefactcollector.collect()
    assert "date_time" in collected_date_time_facts

# Generated at 2022-06-23 01:02:30.753875
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-23 01:02:36.262268
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    result = DateTimeFactCollector()

    assert result is not None
    assert result.name == 'date_time'
    assert result._fact_ids == set()


# Generated at 2022-06-23 01:02:39.006089
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    """Unit test for constructor of class DateTimeFactCollector"""
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector.collect()

# Generated at 2022-06-23 01:02:41.524551
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'


# Generated at 2022-06-23 01:02:43.623372
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector().name == 'date_time'
    assert DateTimeFactCollector()._fact_ids == set()


# Generated at 2022-06-23 01:02:46.534468
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    test_date_time_facts = DateTimeFactCollector()
    assert test_date_time_facts != None



# Generated at 2022-06-23 01:02:54.471423
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-23 01:03:05.595661
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Return a set of unix and UTC related fact for ansible."""

    # Take one existing fact collector
    fact_collector1 = DateTimeFactCollector()
    results = fact_collector1.collect()
    # Make sure that time is valid:
    time_keys = ['epoch', 'epoch_int', 'date', 'time', 'iso8601_micro', 'iso8601', 'iso8601_basic', 'iso8601_basic_short']
    for time_key in time_keys:
        time_result = results['date_time'][time_key]
        assert time_result
        if time_key == 'epoch':
            time_result_as_int = int(float(time_result))

# Generated at 2022-06-23 01:03:14.779718
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # create instance of class
    test_DateTimeFactCollector = DateTimeFactCollector()

    # call method collect
    result = test_DateTimeFactCollector.collect()

    # number of items in result should be 1
    assert len(result) == 1

    # value of the key 'date_time' should be 1
    assert len(result['date_time']) == 20

    # value of the key 'date_time.year' should be 1
    assert len(result['date_time']['year']) == 4

    # value of the key 'date_time.month' should be 1
    assert len(result['date_time']['month']) == 2

    # value of the key 'date_time.weekday' should be 1
    assert len(result['date_time']['weekday']) > 0



# Generated at 2022-06-23 01:03:17.679474
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collector = DateTimeFactCollector()
    results = collector.collect()
    assert isinstance(results['date_time'], dict)

# Generated at 2022-06-23 01:03:30.420890
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_class = DateTimeFactCollector()
    test_module = {
        'model': 'iMac14,2',
        'platform': 'Darwin',
        'returndata': {
            'sysname': 'Darwin',
        }
    }
    test_facts = {}
    result = test_class.collect(test_module, test_facts)
    assert result['date_time'] is not None
    assert result['date_time']['epoch'] is not None
    assert result['date_time']['date'] is not None
    assert result['date_time']['time'] is not None
    assert result['date_time']['iso8601_micro'] is not None
    assert result['date_time']['iso8601'] is not None

# Generated at 2022-06-23 01:03:32.902432
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtf = DateTimeFactCollector()
    assert dtf.name == 'date_time'
    assert dtf._fact_ids == set()


# Generated at 2022-06-23 01:03:35.137468
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    df = DateTimeFactCollector()
    assert df.name == 'date_time'
    assert df.collect() is not None

# Generated at 2022-06-23 01:03:44.440084
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fc = DateTimeFactCollector()
    facts = fc.collect()
    assert facts['date_time']['epoch'] != ''
    assert facts['date_time']['epoch_int'] != ''
    assert facts['date_time']['date'] != ''
    assert facts['date_time']['time'] != ''
    assert facts['date_time']['iso8601_micro'] != ''
    assert facts['date_time']['iso8601'] != ''
    assert facts['date_time']['iso8601_basic'] != ''
    assert facts['date_time']['iso8601_basic_short'] != ''
    assert facts['date_time']['tz'] != ''
    assert facts['date_time']['tz_dst'] != ''

# Generated at 2022-06-23 01:03:53.751637
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_facts = DateTimeFactCollector().collect()

# Generated at 2022-06-23 01:03:56.138839
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt_fc = DateTimeFactCollector()
    assert(dt_fc.name == "date_time")


# Generated at 2022-06-23 01:03:58.999525
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector = DateTimeFactCollector()
    assert DateTimeFactCollector.name == 'date_time'
    assert DateTimeFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:04:02.200096
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_facts = DateTimeFactCollector().collect()
    assert date_time_facts['date_time']['date'] == datetime.datetime.now().strftime('%Y-%m-%d')

# Generated at 2022-06-23 01:04:03.353883
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()

# Generated at 2022-06-23 01:04:08.678245
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt_collector = DateTimeFactCollector()

    assert dt_collector.name == "date_time"
    assert dt_collector.priority == 10
    assert dt_collector._fact_ids == set()


# Generated at 2022-06-23 01:04:13.770622
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    """Unit test for DateTimeFactCollector"""
    # DateTimeFactCollector instance
    dtf = DateTimeFactCollector()
    # Assert the return value of name method
    assert dtf.name == 'date_time'
    # Assert the type of return value of collect method
    assert isinstance(dtf.collect(), dict)

# Generated at 2022-06-23 01:04:25.759953
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_facts_dict = DateTimeFactCollector().collect()
    date_time_facts = date_time_facts_dict['date_time']
    assert date_time_facts['epoch_int'] == str(int(time.time()))
    assert date_time_facts['epoch'] == str(int(time.time()))
    assert date_time_facts['iso8601_micro'][:24] == datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S")
    assert date_time_facts['iso8601'][:19] == datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S")

# Generated at 2022-06-23 01:04:27.502521
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()


# Generated at 2022-06-23 01:04:39.373284
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtf = DateTimeFactCollector()
    date_time_facts = dtf.collect()['date_time']

    assert isinstance(date_time_facts['year'], str), \
        'Year fact is not a string'
    assert len(date_time_facts['year']) == 4, \
        'Year fact is not 4 digits'

    assert isinstance(date_time_facts['month'], str), \
        'Month fact is not a string'
    assert len(date_time_facts['month']) == 2, \
        'Month fact is not 2 digits'

    assert isinstance(date_time_facts['weekday'], str), \
        'Weekday fact is not a string'
    assert len(date_time_facts['weekday']) > 0, \
        'Weekday fact is empty'



# Generated at 2022-06-23 01:04:51.963974
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    result = date_time_fact_collector.collect()
    assert result['date_time']['weekday'] == 'Tuesday'
    assert result['date_time']['weekday_number'] == '2'
    assert result['date_time']['weeknumber'] == '21'
    assert result['date_time']['day'] == '07'
    assert result['date_time']['hour'] == '15'
    assert result['date_time']['minute'] == '27'
    assert result['date_time']['second'] == '17'
    assert result['date_time']['epoch'] == result['date_time']['epoch_int']

# Generated at 2022-06-23 01:05:03.795841
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector.collect()
    assert date_time_facts['date_time']['year'] == time.strftime("%Y")
    assert date_time_facts['date_time']['month'] == time.strftime("%m")
    assert date_time_facts['date_time']['weekday'] == time.strftime("%A")
    assert date_time_facts['date_time']['weekday_number'] == time.strftime("%w")
    assert date_time_facts['date_time']['weeknumber'] == time.strftime("%W")
    assert date_time_facts['date_time']['day'] == time.strftime("%d")

# Generated at 2022-06-23 01:05:08.002239
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'
    assert dtfc._fact_ids == set()


# Generated at 2022-06-23 01:05:22.766497
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # Test with empty facts dict
    facts = {}
    dt = DateTimeFactCollector()
    dt.collect(collected_facts=facts)

    # Test with existing date_time facts

# Generated at 2022-06-23 01:05:32.363027
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collector = DateTimeFactCollector()
    facts_dict = collector.collect()
    assert 'date_time' in facts_dict
    assert 'year' in facts_dict['date_time']
    assert 'month' in facts_dict['date_time']
    assert 'day' in facts_dict['date_time']
    assert 'weekday' in facts_dict['date_time']
    assert 'weekday_number' in facts_dict['date_time']
    assert 'weeknumber' in facts_dict['date_time']
    assert 'hour' in facts_dict['date_time']
    assert 'minute' in facts_dict['date_time']
    assert 'second' in facts_dict['date_time']
    assert 'epoch' in facts_dict['date_time']
    assert 'epoch_int' in facts_

# Generated at 2022-06-23 01:05:43.139838
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # First, generate the dict that we expect
    epoch_ts = time.time()
    expected = {}
    expected['date_time'] = {}
    now = datetime.datetime.fromtimestamp(epoch_ts)
    utcnow = datetime.datetime.utcfromtimestamp(epoch_ts)
    expected['date_time']['year'] = now.strftime('%Y')
    expected['date_time']['month'] = now.strftime('%m')
    expected['date_time']['weekday'] = now.strftime('%A')
    expected['date_time']['weekday_number'] = now.strftime('%w')
    expected['date_time']['weeknumber'] = now.strftime('%W')
    expected['date_time']['day']

# Generated at 2022-06-23 01:05:48.526930
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    module_mock = mock.MagicMock()
    collected_facts_mock = {}
    test_DateTimeFactCollector = DateTimeFactCollector()

    test_DateTimeFactCollector.collect(module_mock, collected_facts_mock)

    assert module_mock.collect_facts.fact_ids == ["date_time"]

# Generated at 2022-06-23 01:05:52.890008
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    ansible_facts = {}
    result = fact_collector.collect(collected_facts=ansible_facts)

    # check if result is a valid dictionary
    assert isinstance(result, dict)

    # check if result['date_time'] is a valid dictionary
    assert isinstance(result['date_time'], dict)

# Generated at 2022-06-23 01:05:54.246695
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector.name == 'date_time'

# Generated at 2022-06-23 01:05:58.989178
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector is not None
    assert date_time_fact_collector.name == 'date_time'
    assert date_time_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:06:02.774087
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    d = DateTimeFactCollector()
    assert isinstance(d, DateTimeFactCollector)

# Generated at 2022-06-23 01:06:13.165131
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_facts = DateTimeFactCollector().collect()
    assert 'date_time' in date_time_facts
    assert isinstance(date_time_facts['date_time'], dict)
    assert 'year' in date_time_facts['date_time']
    assert 'month' in date_time_facts['date_time']
    assert 'weekday' in date_time_facts['date_time']
    assert 'weekday_number' in date_time_facts['date_time']
    assert 'weeknumber' in date_time_facts['date_time']
    assert 'day' in date_time_facts['date_time']
    assert 'hour' in date_time_facts['date_time']
    assert 'minute' in date_time_facts['date_time']
    assert 'second' in date_time

# Generated at 2022-06-23 01:06:17.881440
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    dt = DateTimeFactCollector()

    # Test collect return values
    assert type(dt.collect()) is dict
    for k, v in dt.collect().items():
        assert type(k) is str
        assert type(v) is dict
        for k1, v1 in v.items():
            assert type(k1) is str
            assert type(v1) is str

# Generated at 2022-06-23 01:06:20.853783
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector(None)
    assert collector.name == 'date_time'
    assert collector._fact_ids == set()


# Generated at 2022-06-23 01:06:25.763296
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    """
    Unit test for constructor of class DateTimeFactCollector
    """
    expected_name = 'date_time'

    fact = DateTimeFactCollector()
    assert fact.name == expected_name


# Generated at 2022-06-23 01:06:37.803571
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts.collector import FactCollector
    import datetime

    fc = FactCollector()
    fc.collectors['date_time'] = DateTimeFactCollector()
    result = fc.collect(module=None, collected_facts=None)
    dt = datetime.datetime.utcnow()
    assert result['date_time']['year'] == dt.strftime('%Y')
    assert result['date_time']['month'] == dt.strftime('%m')
    assert result['date_time']['weekday'] == dt.strftime('%A')
    assert result['date_time']['weekday_number'] == dt.strftime('%w')
    assert result['date_time']['weeknumber'] == dt.str

# Generated at 2022-06-23 01:06:40.174177
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    fact_collector = DateTimeFactCollector()
    assert fact_collector.name == 'date_time'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:06:52.888089
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Unit test for method collect of class DateTimeFactCollector"""
    from platform import system
    from sys import version_info

    d = DateTimeFactCollector()

    if not isinstance(d, BaseFactCollector):
        raise Exception("'DateTimeFactCollector' is not a subclass of 'BaseFactCollector'")

    if not hasattr(d, 'collect'):
        raise Exception("'DateTimeFactCollector' has not 'collect' method")

    if not isinstance(d.collect, classmethod):
        raise Exception("'DateTimeFactCollector' method 'collect' is not a class method")

    dtf = d.collect()

    if not isinstance(dtf, dict):
        raise Exception("'DateTimeFactCollector' method 'collect' does not return a dictionary")


# Generated at 2022-06-23 01:06:58.053003
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'
    assert dtfc._fact_ids == set()
    assert dtfc.collect()['date_time']['tz_dst'] == time.tzname[1]

# Generated at 2022-06-23 01:07:01.219681
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_collector = DateTimeFactCollector()
    date_time_dict = date_time_collector.collect()
    assert not date_time_dict.get('date_time').get('iso8601') == ''

# Generated at 2022-06-23 01:07:12.513071
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-23 01:07:23.237521
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    class DummyModule:
        def fail_json(self, *args, **kwargs):
            pass

    def mock_time_strftime(fmt_str, *args, **kwargs):
        import re
        import time

        tz = time.strftime("%Z")
        tz_dst = time.tzname[1]
        tz_offset = time.strftime("%z")

        dt = time.localtime(time.time())


# Generated at 2022-06-23 01:07:25.734237
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    f = DateTimeFactCollector()
    assert f.name == 'date_time'
    assert f.collect() == {'date_time': {}}

# Generated at 2022-06-23 01:07:35.926338
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts.collector import ContentException
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsParseException
    from ansible.module_utils.facts.collector import FactsUnsupportedException
    import time

    # Setup test object
    fact_collector = DateTimeFactCollector()

    # Setup module argument spec
    module_args_spec = {}

    # Setup module return values
    module_return_values = dict()

    # Setup a fake datetime object
    date_time = time.strptime('Tue Mar  2 16:31:21 PST 2010', '%a %b %d %H:%M:%S %Z %Y')

    # Setup fake datetime.datetime object with magic method __str__

# Generated at 2022-06-23 01:07:37.644390
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    d = DateTimeFactCollector()
    assert d.name == 'date_time'

# Generated at 2022-06-23 01:07:41.887193
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector
    assert date_time_fact_collector.name == 'date_time'
    assert date_time_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:07:44.296378
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    fact_collector = DateTimeFactCollector()
    assert fact_collector.name == "date_time"


# Generated at 2022-06-23 01:07:49.147430
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dateTimeFactCollector = DateTimeFactCollector()
    assert dateTimeFactCollector.name == 'date_time'
    assert dateTimeFactCollector._fact_ids == set()

# Unit test to cover the case when collect is called with only a module and
# the collected_facts are not provided

# Generated at 2022-06-23 01:07:57.541288
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts import ansible_collections
    from ansible.module_utils.facts.collector import AnsibleFactsCollector
    DateTimeFactCollector.name = 'date_time'

    # get number of facts before any test
    initial_len = len(AnsibleFactsCollector.get_collection(
        DateTimeFactCollector.name).get_fact_names())

    collector = DateTimeFactCollector()
    facts = collector.collect()

    # test that the collected facts are valid
    gathered_fact_names = set(facts['date_time'].keys())

# Generated at 2022-06-23 01:08:07.245442
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-23 01:08:17.114376
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    f = DateTimeFactCollector()

    facts = {}
    ansible_facts = f.collect(collected_facts=facts)

    assert 'date_time' in ansible_facts
    assert 'epoch' in ansible_facts['date_time']
    assert 'epoch_int' in ansible_facts['date_time']
    assert 'epoch' == ansible_facts['date_time']['epoch_int']
    assert datetime.datetime.fromtimestamp(float(ansible_facts['date_time']['epoch'])).strftime('%Y-%m-%d') == ansible_facts['date_time']['date']

# Generated at 2022-06-23 01:08:19.920739
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time = DateTimeFactCollector()
    assert date_time.name == 'date_time'
    assert date_time._fact_ids == set()
