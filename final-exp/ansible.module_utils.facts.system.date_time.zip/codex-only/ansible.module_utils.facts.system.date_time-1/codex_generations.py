

# Generated at 2022-06-23 00:58:24.276901
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    date_time = DateTimeFactCollector()

    # Get date_time facts
    date_time_facts = date_time.collect()

    # Check if date_time is present in the facts
    assert('date_time' in date_time_facts)

    # Check if the time facts are present in the facts
    assert('year' in date_time_facts['date_time'])
    assert('month' in date_time_facts['date_time'])
    assert('weekday' in date_time_facts['date_time'])
    assert('weekday_number' in date_time_facts['date_time'])
    assert('weeknumber' in date_time_facts['date_time'])
    assert('day' in date_time_facts['date_time'])

# Generated at 2022-06-23 00:58:26.886391
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
  c = DateTimeFactCollector()
  assert c.name == 'date_time'
  assert c._fact_ids == set()


# Generated at 2022-06-23 00:58:34.464133
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    facts_dict = {}
    date_time_facts = {}

    date_time_facts['year'] = None
    date_time_facts['month'] = None
    date_time_facts['weekday'] = None
    date_time_facts['weekday_number'] = None
    date_time_facts['weeknumber'] = None
    date_time_facts['day'] = None
    date_time_facts['hour'] = None
    date_time_facts['minute'] = None
    date_time_facts['second'] = None
    date_time_facts['epoch'] = None
    date_time_facts['epoch_int'] = None
    date_time_facts['date'] = None
    date_time_facts['time'] = None
    date_time_facts['iso8601_micro'] = None
    date

# Generated at 2022-06-23 00:58:44.983857
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():

    tm = "2018-01-31T14:43:04.108817Z"
    dt = datetime.datetime.strptime(tm, '%Y-%m-%dT%H:%M:%S.%fZ')
    now = datetime.datetime.fromtimestamp(time.time())
    assert ((now.strftime('%Y')) == (dt.strftime('%Y')))
    assert ((now.strftime('%m')) == (dt.strftime('%m')))
    assert ((now.strftime('%A')) == (dt.strftime('%A')))
    assert ((now.strftime('%w')) == (dt.strftime('%w')))

# Generated at 2022-06-23 00:58:47.376390
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert len(DateTimeFactCollector._fact_ids) == 1
    assert 'date_time' in DateTimeFactCollector._fact_ids

# Generated at 2022-06-23 00:58:49.254542
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dateTimeFactCollector = DateTimeFactCollector()
    dateTimeFactCollector.collect()

# Generated at 2022-06-23 00:58:53.627670
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collector = DateTimeFactCollector()
    facts = collector.collect()
    assert facts['date_time']['date'] == time.strftime("%Y-%m-%d")

# Generated at 2022-06-23 00:58:55.045740
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()
    assert collector.name == 'date_time'

# Generated at 2022-06-23 00:59:06.001580
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector

    # set up test data
    module = None
    collected_facts = None

# Generated at 2022-06-23 00:59:09.634391
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    '''Test DateTimeFactCollector.collect()'''

    # Compose

    # Act
    dtfc = DateTimeFactCollector()
    dtfc.collect()

    # Assert
    assert dtfc.collect()['date_time']['year'] == time.strftime("%Y")

# Generated at 2022-06-23 00:59:19.021223
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-23 00:59:24.742932
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collector = DateTimeFactCollector()
    result = collector.collect()
    assert isinstance(result, dict)
    assert result['date_time']['iso8601_basic']


# Generated at 2022-06-23 00:59:28.283234
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    dtfc.collect()

# Generated at 2022-06-23 00:59:30.463226
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_facts_collector = DateTimeFactCollector()
    assert date_time_facts_collector is not None

# Generated at 2022-06-23 00:59:37.268891
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts import ansible_collected_facts

    dtf = DateTimeFactCollector()
    dtf.collect(module=None, collected_facts=ansible_collected_facts)
    assert ansible_collected_facts['date_time']['hour'] is not None
    assert ansible_collected_facts['date_time']['second'] is not None
    assert ansible_collected_facts['date_time']['date'] is not None



# Generated at 2022-06-23 00:59:46.664502
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import os
    import pytest
    from datetime import datetime
    from mock import patch, mock_open

    fake_datetime = datetime(year=2020, month=12, day=1)
    fake_datetime_utc = datetime(year=2020, month=12, day=1)
    fake_timestamp = fake_datetime.timestamp()

    with patch('ansible.module_utils.facts.collector.time') as time_mock:
        time_mock.time.return_value = fake_timestamp
        time_mock.strftime.return_value = '%Y-%m-%dT%H:%M:%S%z'
        time_mock.tzname = ('Z', 'P')
        m = DateTimeFactCollector()
        result = m.collect()

# Generated at 2022-06-23 00:59:50.319096
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector.name == 'date_time'
    assert DateTimeFactCollector._fact_ids == set()
    assert DateTimeFactCollector.collect() != {}

# Generated at 2022-06-23 00:59:54.555666
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Note: Using assertIsNone so that test fails if DateTimeFactCollector
    #       class is trying to do anything more than just creating an empty
    #       instance of itself.
    assert isinstance(DateTimeFactCollector(), DateTimeFactCollector)

# Generated at 2022-06-23 00:59:57.091490
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dateTimeFactCollector = DateTimeFactCollector()
    assert dateTimeFactCollector.name == 'date_time'



# Generated at 2022-06-23 00:59:59.630424
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    d = DateTimeFactCollector()
    assert d.name == 'date_time'
    assert d._fact_ids == set()


# Generated at 2022-06-23 01:00:02.117861
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    t = DateTimeFactCollector()
    assert t.name == 'date_time'
    assert sorted(t.collect().keys()) == ['date_time']

# Generated at 2022-06-23 01:00:11.309091
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt_fc = DateTimeFactCollector()
    datetime_dict = dt_fc.collect()
    # Check consistency of epoch_int and epoch
    assert datetime_dict['date_time']['epoch_int'] == datetime_dict['date_time']['epoch']
    # Use datetime to check that iso8601_micro format is valid ISO 8601
    datetime.datetime.strptime(datetime_dict['date_time']['iso8601_micro'], "%Y-%m-%dT%H:%M:%S.%fZ")

# Generated at 2022-06-23 01:00:16.702273
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    fact_collector = DateTimeFactCollector()
    assert len(fact_collector._collectors) == 1, 'Invalid number of subcollectors returned'
    assert fact_collector.name == 'date_time', 'Invalid name returned'
    assert len(fact_collector._fact_ids) == 0, 'Invalid list of dependencies returned'


# Generated at 2022-06-23 01:00:17.859571
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()

# Generated at 2022-06-23 01:00:19.019879
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    result = DateTimeFactCollector()
    assert result is not None

# Generated at 2022-06-23 01:00:29.457737
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Unit test for class DateTimeFactCollector
    """
    collector = DateTimeFactCollector()
    epoch_ts = time.time()
    epoch = str(int(epoch_ts))
    now = datetime.datetime.fromtimestamp(epoch_ts)
    utcnow = datetime.datetime.utcfromtimestamp(epoch_ts)

    utc_offset = time.altzone if time.daylight else time.timezone
    tz_offset = str(datetime.timedelta(seconds=-utc_offset)).replace('-', '+')


# Generated at 2022-06-23 01:00:40.642842
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Unit test for method collect of class DateTimeFactCollector"""
    # Create an instance of class DateTimeFactCollector
    date_time_fact_collector = DateTimeFactCollector()
    assert isinstance(date_time_fact_collector, DateTimeFactCollector)
    # Call method collect of class DateTimeFactCollector
    # with mocked datetime
    with mock.patch('ansible.module_utils.facts.collectors.date_time.datetime') as mock_datetime:
        with mock.patch('ansible.module_utils.facts.collectors.date_time.time') as mock_time:
            time_tuple = (2017, 3, 16, 12, 14, 33, 3, 75, 0)

# Generated at 2022-06-23 01:00:46.850464
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dateTimeFactCollector = DateTimeFactCollector()
    assert dateTimeFactCollector.name == 'date_time'
    assert set(dateTimeFactCollector._fact_ids) == set()


# Generated at 2022-06-23 01:00:50.378709
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_facts = DateTimeFactCollector()
    assert date_time_facts.name == 'date_time'

# Generated at 2022-06-23 01:01:01.079723
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-23 01:01:10.264390
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Unit test for method collect of class DateTimeFactCollector.
    """
    DateTimeFactCollector = DateTimeFactCollector()
    result = DateTimeFactCollector.collect()

    assert 'date_time' in result
    assert 'year' in result.get('date_time')
    assert 'month' in result.get('date_time')
    assert 'weekday' in result.get('date_time')
    assert 'weekday_number' in result.get('date_time')
    assert 'weeknumber' in result.get('date_time')
    assert 'day' in result.get('date_time')
    assert 'hour' in result.get('date_time')
    assert 'minute' in result.get('date_time')
    assert 'second' in result.get('date_time')

# Generated at 2022-06-23 01:01:12.703962
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    class MockModule():
        pass

    module = MockModule()
    DateTimeFactCollector().collect(module)

# Generated at 2022-06-23 01:01:25.444896
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # create an instance of the class
    fact_collector = DateTimeFactCollector()

    # call the collect method
    facts_dict = fact_collector.collect()

    assert isinstance(facts_dict, dict)
    assert 'date_time' in facts_dict
    assert isinstance(facts_dict['date_time'], dict)
    assert len(facts_dict['date_time']) == 18
    assert 'year' in facts_dict['date_time']
    assert 'month' in facts_dict['date_time']
    assert 'weekday' in facts_dict['date_time']
    assert 'weekday_number' in facts_dict['date_time']
    assert 'weeknumber' in facts_dict['date_time']
    assert 'day' in facts_dict['date_time']
    assert 'hour'

# Generated at 2022-06-23 01:01:28.083380
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    collected_facts = date_time_fact_collector.collect()
    print(collected_facts)


# Generated at 2022-06-23 01:01:39.436615
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    def _utcnow():
        return datetime.datetime(2014, 12, 22, 12, 12, 12, 12)

    # Test with a dummy utcnow function
    DateTimeFactCollector.collect(utcnow=_utcnow)

    assert datetime.datetime.utcfromtimestamp(int(DateTimeFactCollector.collect()['date_time']['epoch'])) == _utcnow()
    assert datetime.datetime.utcfromtimestamp(int(DateTimeFactCollector.collect()['date_time']['epoch_int'])) == _utcnow()
    assert 'date_time' in DateTimeFactCollector.collect()
    assert 'year' in DateTimeFactCollector.collect()['date_time']

# Generated at 2022-06-23 01:01:42.881470
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    # assert the fact_ids are the same
    assert dtfc.fact_ids == set(['date_time'])

# Unit test of collect function of class DateTimeFactCollector

# Generated at 2022-06-23 01:01:45.413861
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    assert DateTimeFactCollector.collect()

# Generated at 2022-06-23 01:01:47.301201
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    facts_collector = DateTimeFactCollector()
    assert facts_collector.name == 'date_time'

# Generated at 2022-06-23 01:01:50.075881
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    result = date_time_fact_collector.collect()
    assert result.get('date_time') is not None

# Generated at 2022-06-23 01:02:01.573863
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector.collect()
    assert date_time_facts['date_time']['second'] == "0"
    assert date_time_facts['date_time']['epoch'] == "0"
    assert date_time_facts['date_time']['epoch_int'] == "0"
    assert date_time_facts['date_time']['date'] == "1970-01-01"
    assert date_time_facts['date_time']['time'] == "00:00:00"
    assert date_time_facts['date_time']['iso8601_micro'] == "1970-01-01T00:00:00.000000Z"

# Generated at 2022-06-23 01:02:03.552730
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == "date_time"

# Generated at 2022-06-23 01:02:14.202402
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()

    result = date_time_fact_collector.collect()

    assert result['ansible_facts']['date_time']['year'] == datetime.datetime.now().strftime("%Y")
    assert result['ansible_facts']['date_time']['weekday'] == datetime.datetime.now().strftime("%A")
    assert result['ansible_facts']['date_time']['date'] == datetime.datetime.now().strftime("%Y-%m-%d")
    assert result['ansible_facts']['date_time']['time'] == datetime.datetime.now().strftime("%H:%M:%S")

# Generated at 2022-06-23 01:02:16.498330
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj is not None
    assert obj.name == 'date_time'
    assert obj.collect() is not None
  
test_DateTimeFactCollector()

# Generated at 2022-06-23 01:02:27.490644
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    date_time_fact_collector = DateTimeFactCollector()

    date_time_facts = date_time_fact_collector.collect()

    assert 'date_time' in date_time_facts
    assert 'year' in date_time_facts['date_time']
    assert 'month' in date_time_facts['date_time']
    assert 'weekday' in date_time_facts['date_time']
    assert 'weekday_number' in date_time_facts['date_time']
    assert 'weeknumber' in date_time_facts['date_time']
    assert 'day' in date_time_facts['date_time']
    assert 'hour' in date_time_facts['date_time']
    assert 'minute' in date_time_facts['date_time']
    assert 'second' in date_

# Generated at 2022-06-23 01:02:32.185544
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_collector = DateTimeFactCollector()
    date_time_collector_facts = date_time_collector.collect()
    assert isinstance(date_time_collector_facts, dict) is True
    assert isinstance(date_time_collector_facts.get('date_time'), dict) is True

# Generated at 2022-06-23 01:02:36.303312
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
     dt = DateTimeFactCollector()
     facts = dt.collect()
     assert 'date_time' in facts
     assert isinstance(facts['date_time'], dict)
     assert len(facts['date_time']) > 0

# Generated at 2022-06-23 01:02:37.597146
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()


# Generated at 2022-06-23 01:02:40.468817
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'
    assert x._fact_ids == set()

# Generated at 2022-06-23 01:02:42.598665
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    t = DateTimeFactCollector()
    assert t is not None
    assert t.name == 'date_time'
    assert t._fact_ids == set()

# Generated at 2022-06-23 01:02:45.055049
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    result = DateTimeFactCollector()
    assert isinstance(result, DateTimeFactCollector)

# Generated at 2022-06-23 01:02:47.836700
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Test the constructor
    facts_collector = DateTimeFactCollector()
    assert isinstance(facts_collector, DateTimeFactCollector)



# Generated at 2022-06-23 01:02:51.449254
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fc = DateTimeFactCollector()
    assert date_time_fc.name == "date_time"


# Generated at 2022-06-23 01:03:02.646626
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Arrange
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts import _get_collectors
    import types
    import datetime
    import time
    collectors = _get_collectors()
    time_now = time.time()
    time_now_rounded = time_now - time_now % 1
    time_now_rounded_int = str(int(time_now_rounded))
    dt = datetime.datetime.fromtimestamp(time_now)
    dt_utc = datetime.datetime.utcfromtimestamp(time_now)

    # Act
    dt_fc = FactCollector.get_collector(collectors, 'date_time')
    facts_dict = dt_fc.collect()

    # Assert

# Generated at 2022-06-23 01:03:07.217170
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_facts = DateTimeFactCollector()
    assert date_time_facts.name == 'date_time'
    assert 'date_time' in date_time_facts._fact_ids
    assert date_time_facts._fact_ids.__len__() == 1

# Generated at 2022-06-23 01:03:09.659133
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt.name == 'date_time'
    assert dt._fact_ids == set()


# Generated at 2022-06-23 01:03:21.403495
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    utcnow = datetime.datetime.utcnow()
    epoch_ts = (utcnow - datetime.datetime(1970, 1, 1)).total_seconds()
    epoch_ts_int = int(epoch_ts)

    utcnow = datetime.datetime.utcfromtimestamp(epoch_ts)
    now = datetime.datetime.fromtimestamp(epoch_ts)

    epoch = now.strftime('%s')
    if epoch == '' or epoch[0] == '%':
        epoch = str(epoch_ts)

    epoch_int = str(int(now.strftime('%s')))
    if epoch_int == '' or epoch_int[0] == '%':
        epoch_int = str(int(epoch_ts))

    expected_result = {}
   

# Generated at 2022-06-23 01:03:26.681752
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt_fact_collector = DateTimeFactCollector()

    assert dt_fact_collector.name == 'date_time'
    assert not dt_fact_collector.collect()
    assert not compiled_regex_match(re.compile('%(?:f|z)'), dt_fact_collector.collect()['date_time']['tz_offset'])

# Generated at 2022-06-23 01:03:28.803566
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    ''' Unit test for method ansible.module_utils.facts.collectors.dns.DateTimeFactCollector.collect() '''
    pass

# Generated at 2022-06-23 01:03:30.736905
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtf = DateTimeFactCollector()
    assert dtf.name == 'date_time'

# Generated at 2022-06-23 01:03:40.743838
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Test case 1: 'strftime('%s')' returns string
    now = datetime.datetime.fromtimestamp(1539370900)
    actual = DateTimeFactCollector().collect(collected_facts=None)['date_time']

# Generated at 2022-06-23 01:03:44.055809
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt_obj = DateTimeFactCollector()

    assert dt_obj.name == 'date_time'
    assert dt_obj._fact_ids == set()

# Generated at 2022-06-23 01:03:45.598334
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    facts = DateTimeFactCollector()
    assert facts is not None

# Generated at 2022-06-23 01:03:54.687123
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collector = DateTimeFactCollector()

    result = collector.collect()
    assert result['date_time']['year']
    assert result['date_time']['month']
    assert result['date_time']['weekday']
    assert result['date_time']['weekday_number']
    assert result['date_time']['weeknumber']
    assert result['date_time']['day']
    assert result['date_time']['hour']
    assert result['date_time']['minute']
    assert result['date_time']['second']
    assert result['date_time']['epoch']
    assert result['date_time']['epoch_int']
    assert result['date_time']['date']
    assert result['date_time']['time']
    assert result

# Generated at 2022-06-23 01:04:05.361161
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    import datetime

    fake_item = {}

    fake_item['date_time'] = {}

    fake_item['date_time']['year'] = datetime.datetime.now().strftime('%Y')
    fake_item['date_time']['month'] = datetime.datetime.now().strftime('%m')
    fake_item['date_time']['weekday'] = datetime.datetime.now().strftime('%A')
    fake_item['date_time']['weekday_number'] = datetime.datetime.now().strftime('%w')
    fake_item['date_time']['weeknumber'] = datetime.datetime.now().strftime('%W')

# Generated at 2022-06-23 01:04:07.107947
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'

# Generated at 2022-06-23 01:04:09.083687
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Initialize the instance
    date_time_collector = DateTimeFactCollector()

    # Check the values of the instance
    assert date_time_collector.name == "date_time"
    assert date_time_collector._fact_ids == set()

# Generated at 2022-06-23 01:04:19.004072
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts.collector.date_time import DateTimeFactCollector
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.processor.date_time import DateTimeProcessor
    from ansible.module_utils.facts.processor.base import BaseProcessor

    date_time_fact_collector = DateTimeFactCollector()
    facts = Facts()
    date_time_fact_collector.collect(None, facts)
    date_time_facts = facts.get('datetime')
    assert isinstance(date_time_facts, dict)
    assert 'year' in date_time_facts
    assert 'month' in date_time_facts
    assert 'weekday' in date_time_facts
    assert 'weekday_number' in date_time_

# Generated at 2022-06-23 01:04:21.879295
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_collector = DateTimeFactCollector()
    assert date_time_collector.name == 'date_time'
    assert 'date_time' in date_time_collector._fact_ids

# Generated at 2022-06-23 01:04:30.547218
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    facts_collector = FactsCollector()
    date_time_fact_collector = DateTimeFactCollector(facts_collector)
    facts_collector._collected_facts = {'date_time': {}}
    date_time_fact_collector.collect()
    # assert results
    assert 'date_time' in facts_collector._collected_facts
    assert 'epoch' in facts_collector._collected_facts['date_time']
    assert 'epoch_int' in facts_collector._collected_facts['date_time']
    assert 'date' in facts_collector._collected_facts['date_time']
    assert 'time' in facts_collector._collected_facts['date_time']

# Generated at 2022-06-23 01:04:32.574444
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    d = DateTimeFactCollector()
    assert d is not None
    assert d.name == 'date_time'

# Generated at 2022-06-23 01:04:38.007072
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import platform, sys
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Set date_time collector to be called
    ansible.module_utils.facts.collector.ALL_COLLECTORS['date_time'] = ansible.module_utils.facts.collector.DateTimeFactCollector()
    facts_dict = FactCollector().collect()
    assert isinstance(facts_dict, dict)
    assert isinstance(facts_dict['date_time'], dict)
    assert facts_dict['date_time']['year'] == time.strftime('%Y')
    assert facts_dict['date_time']['month'] == time.strftime('%m')

# Generated at 2022-06-23 01:04:40.855162
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Initialization of DateTimeFactCollector object
    dtfc = DateTimeFactCollector()
    # Test the collect method
    dtfc.collect()

# Generated at 2022-06-23 01:04:45.415939
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts import stubs
    date_time_fact_collector = DateTimeFactCollector(stubs.ModuleStub())
    assert date_time_fact_collector.collect() is not None

# Generated at 2022-06-23 01:04:49.634810
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():

    # Create an instance of DateTimeFactCollector
    dtf = DateTimeFactCollector()

    # Check value of DateTimeFactCollector object
    assert dtf.name == 'date_time'
    assert dtf._fact_ids == set()


# Generated at 2022-06-23 01:04:50.364215
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()


# Generated at 2022-06-23 01:05:02.928046
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt.name == 'date_time'

# Generated at 2022-06-23 01:05:11.429661
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """ Test the return value of DateTimeFactCollector.collect() with dummy values.

    The DateTimeFactCollector.collect() method should return ansible_date_time facts as a dict of time-related sub-dicts.

    Args:
        None

    Returns:
        None

    Raises:
        None
    """
    dtf = DateTimeFactCollector()
    assert "date_time" in dtf.collect(), "date_time fact is missing from DateTimeFactCollector.collect() return value"

# Generated at 2022-06-23 01:05:25.596685
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    
    _DateTimeFactCollector = DateTimeFactCollector()
    result = _DateTimeFactCollector.collect(module=None, collected_facts=None)
    assert result["date_time"]["year"] == datetime.datetime.now().strftime("%Y")
    assert result["date_time"]["month"] == datetime.datetime.now().strftime("%m")
    assert result["date_time"]["weekday"] == datetime.datetime.now().strftime("%A")
    assert result["date_time"]["weekday_number"] == datetime.datetime.now().strftime("%w")
    assert result["date_time"]["weeknumber"] == datetime.datetime.now().strftime("%W")
    assert result["date_time"]["day"] == dat

# Generated at 2022-06-23 01:05:36.608608
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Dummy class for unit testing constructor of DateTimeFactCollector
    class DummyModule():
        def __init__(self):
            self.params = {}
            self.config_file = None

        def get_config_file(self):
            return self.config_file

        def get_bin_path(self, binary):
            return "/usr/bin/{0}".format(binary)

    # Dummy facts for unit testing constructor of DateTimeFactCollector
    class DummyFacts():
        def __init__(self):
            self.module_name = None

        def get_module_name(self):
            return self.module_name

    # Call constructor to Unit test
    DateTimeFactCollector(DummyModule(), DummyFacts())

# Generated at 2022-06-23 01:05:40.246672
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'
    assert date_time_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:05:43.097270
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_facts = DateTimeFactCollector()
    assert date_time_facts.name == 'date_time'
    assert date_time_facts._fact_ids == set()


# Generated at 2022-06-23 01:05:45.606724
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
        f = DateTimeFactCollector()
        assert f.name == 'date_time'


# Generated at 2022-06-23 01:05:56.760416
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    result = fact_collector.collect()
    assert not result == {}
    assert result['date_time']['year'].isdigit()
    assert result['date_time']['month'].isdigit()
    assert result['date_time']['day'].isdigit()
    assert result['date_time']['hour'].isdigit()
    assert result['date_time']['minute'].isdigit()
    assert result['date_time']['second'].isdigit()
    assert result['date_time']['epoch'].isdigit()
    assert result['date_time']['epoch_int'].isdigit()
    assert result['date_time']['date'].isdigit()

# Generated at 2022-06-23 01:05:59.296614
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Test case for DateTimeFactCollector
    dtfc = DateTimeFactCollector()
    if dtfc:
        print ("Testcase for DateTimeFactCollector is passed")

# Generated at 2022-06-23 01:06:03.262093
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Instantiate class
    DateTimeFactCollectorF = DateTimeFactCollector()
    # Call method collect
    DateTimeFactCollectorF.collect()

# Generated at 2022-06-23 01:06:05.194246
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    fact_collector = DateTimeFactCollector()
    assert fact_collector.name == 'date_time'

# Generated at 2022-06-23 01:06:07.424596
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    facts_dict = DateTimeFactCollector().collect()
    assert facts_dict['date_time']['year'] != ""


# Generated at 2022-06-23 01:06:09.241537
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x
    assert x.name == 'date_time'

# Generated at 2022-06-23 01:06:18.615260
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time = DateTimeFactCollector()
    date_time_data = date_time.collect()
    date_time_tests = date_time_data['date_time']
    assert date_time_tests['year']
    assert date_time_tests['month']
    assert date_time_tests['weekday']
    assert date_time_tests['weekday_number']
    assert date_time_tests['weeknumber']
    assert date_time_tests['day']
    assert date_time_tests['hour']
    assert date_time_tests['minute']
    assert date_time_tests['second']
    assert date_time_tests['epoch']
    assert date_time_tests['epoch_int']
    assert date_time_tests['date']
    assert date_time_tests['time']
    assert date

# Generated at 2022-06-23 01:06:30.780254
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    temp_dt = datetime.datetime(2015, 2, 27, 1, 2, 3, 4)
    temp_d = datetime.datetime(2015, 2, 27, 0, 0, 0, 0)
    temp_t = datetime.datetime(1900, 1, 1, 1, 2, 3, 4)
    dt_dict = temp_dt.timetuple()
    d_dict = temp_d.timetuple()
    t_dict = temp_t.timetuple()
    dt_dict.__dict__['tm_zone'] = 'America/Los_Angeles'
    dt_dict.__dict__['tm_gmtoff'] = -28800
    d_dict.__dict__['tm_zone'] = 'America/Los_Angeles'

# Generated at 2022-06-23 01:06:33.033033
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """ Test the method collect of DateTimeFactCollector for its
    return datatype.
    """

    assert isinstance(DateTimeFactCollector().collect(), dict)

# Generated at 2022-06-23 01:06:40.902680
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtf = DateTimeFactCollector()
    dt_facts = dtf.collect()
    assert dt_facts
    assert 'date_time' in dt_facts
    assert 'year' in dt_facts['date_time']
    assert 'month' in dt_facts['date_time']
    assert 'weekday' in dt_facts['date_time']
    assert 'weekday_number' in dt_facts['date_time']
    assert 'weeknumber' in dt_facts['date_time']
    assert 'day' in dt_facts['date_time']
    assert 'hour' in dt_facts['date_time']
    assert 'minute' in dt_facts['date_time']
    assert 'second' in dt_facts['date_time']

# Generated at 2022-06-23 01:06:53.976529
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    epoch_ts = time.time()

# Generated at 2022-06-23 01:06:55.944854
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fixture = DateTimeFactCollector()
    fixture.collect()

# Generated at 2022-06-23 01:07:00.084336
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    datetime_fact = DateTimeFactCollector()
    assert isinstance(datetime_fact, BaseFactCollector)
    assert datetime_fact.collect() != {}
    assert datetime_fact.collect()['date_time']['epoch_int'] != ''

# Generated at 2022-06-23 01:07:01.781796
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Times will be different, so just assert the class is created
    DateTimeFactCollector()

# Generated at 2022-06-23 01:07:03.183255
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()

# Generated at 2022-06-23 01:07:07.051735
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    '''
    Make sure the default values of constructor are correct
    '''
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'
    assert dtfc._fact_ids == set()


# Generated at 2022-06-23 01:07:09.774490
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dateTimeFactCollector = DateTimeFactCollector()
    assert dateTimeFactCollector.name == "date_time"
    assert dateTimeFactCollector._fact_ids == set()



# Generated at 2022-06-23 01:07:14.147721
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Create instance of class DateTimeFactCollector
    date_time_fact_collector = DateTimeFactCollector()
    # Call method collect of class DateTimeFactCollector
    date_time_fact_collector.collect()

# Generated at 2022-06-23 01:07:17.214086
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = DateTimeFactCollector()
    facts = dt.collect()
    assert facts['date_time']['day'] == datetime.datetime.now().strftime('%d')

# Generated at 2022-06-23 01:07:19.147062
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    ans_fact = DateTimeFactCollector()
    # Check whether the collector is well initialized
    assert ans_fact.name == 'date_time'

# Generated at 2022-06-23 01:07:20.300266
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()

# Generated at 2022-06-23 01:07:30.287521
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # These values will be mocked during the test, no need to seed them.
    collected_facts = {}
    module = None

    # Our implementation of setuptools doesn't seem to call our test setup
    # class, so we do this here.
    DateTimeFactCollector._fact_ids = set()

    # Create our test collector and call collect().
    datetime_fc = DateTimeFactCollector()
    result = datetime_fc.collect(module, collected_facts)

    # Assert that the results are what we expected.
    assert 'date_time' in result
    date_time = result['date_time']
    assert 'month' in date_time
    assert 'weekday' in date_time
    assert 'weekday_number' in date_time
    assert 'weeknumber' in date_time

# Generated at 2022-06-23 01:07:34.746348
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    """
    Unit test for constructor of class DateTimeFactCollector
    """
    date_time = DateTimeFactCollector()
    result = date_time.collect()
    assert isinstance(result['date_time'], dict), 'Result is not a dict'
    assert len(result['date_time']) >= 7, 'Test setup has changed'

# Generated at 2022-06-23 01:07:38.535298
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    datetime_collector = DateTimeFactCollector()
    assert datetime_collector.name == 'date_time'
    assert datetime_collector._fact_ids == set()


# Generated at 2022-06-23 01:07:50.029764
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    c = DateTimeFactCollector()
    # the fact is not expected to be collected on the first call
    result = c.collect()
    assert {} == result
    # the fact is expected to be collected on the second call
    result = c.collect()

# Generated at 2022-06-23 01:07:51.639838
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    dtfc.collect()


# Generated at 2022-06-23 01:07:54.176600
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    result = dtfc.collect()
    assert result.get('date_time')
    assert isinstance(result['date_time'], dict)

# Generated at 2022-06-23 01:08:03.116748
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    DTFactor = DateTimeFactCollector()
    DTFactor.collect()
    assert 'date_time' in DTFactor.facts_dict
    assert 'date' in DTFactor.facts_dict['date_time']
    assert 'time' in DTFactor.facts_dict['date_time']
    assert 'epoch' in DTFactor.facts_dict['date_time']
    assert 'hour' in DTFactor.facts_dict['date_time']
    assert 'minute' in DTFactor.facts_dict['date_time']
    assert 'second' in DTFactor.facts_dict['date_time']
    assert 'tz_offset' in DTFactor.facts_dict['date_time']
    assert 'iso8601' in DTFactor.facts_dict['date_time']

# Generated at 2022-06-23 01:08:15.495565
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtf = DateTimeFactCollector()
    dtf_facts = dtf.collect()
    assert dtf_facts['date_time']['year'] != '0000'
    assert dtf_facts['date_time']['month'] != '00'
    assert dtf_facts['date_time']['weeknumber'] != '00'
    assert dtf_facts['date_time']['day'] != '00'
    assert dtf_facts['date_time']['hour'] != '00'
    assert dtf_facts['date_time']['minute'] != '00'
    assert dtf_facts['date_time']['second'] != '00'
    assert dtf_facts['date_time']['epoch'] != '0'