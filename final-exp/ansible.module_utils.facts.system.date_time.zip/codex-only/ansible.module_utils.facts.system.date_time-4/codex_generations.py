

# Generated at 2022-06-23 00:58:24.570781
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Test method `collect` of class DateTimeFactCollector.

    This test method assumes that a local system time is:
       2018-05-30T11:51:12.982704

    """
    DTC = DateTimeFactCollector()
    dtf = DTC.collect()['date_time']
    assert(dtf['year'] == '2018')
    assert(dtf['month'] == '05')
    assert(dtf['weekday'] == 'Wednesday')
    assert(dtf['weekday_number'] == '3')
    assert(dtf['weeknumber'] == '22')
    assert(dtf['day'] == '30')
    assert(dtf['hour'] == '11')
    assert(dtf['minute'] == '51')
    assert(dtf['second'] == '12')


# Generated at 2022-06-23 00:58:36.114800
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    datetimeFactCollector = DateTimeFactCollector()
    result = datetimeFactCollector.collect()
    assert isinstance(result['date_time'], dict)
    assert isinstance(result['date_time']['year'], str)
    assert isinstance(result['date_time']['month'], str)
    assert isinstance(result['date_time']['weekday'], str)
    assert isinstance(result['date_time']['weekday_number'], str)
    assert isinstance(result['date_time']['weeknumber'], str)
    assert isinstance(result['date_time']['day'], str)
    assert isinstance(result['date_time']['hour'], str)
    assert isinstance(result['date_time']['minute'], str)
   

# Generated at 2022-06-23 00:58:46.147790
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    # There is no real guarantee that the test will run at this precise
    # instant, so we will use a known datetime.
    known_dt = datetime.datetime(year=2017, month=3, day=13,
                                 hour=15, minute=28, second=46)
    known_epoch = int(known_dt.strftime('%s'))
    assert (dtfc.collect()['date_time']['epoch'] == str(known_epoch))

# Generated at 2022-06-23 00:58:49.306486
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'
    assert x._fact_ids == set()

# Unit tests for collect() of class DateTimeFactCollector

# Generated at 2022-06-23 00:59:01.935951
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'
    # facts_dict['date_time'] should have 15 keys
    assert len(date_time_fact_collector._fact_ids) == 15
    date_time = date_time_fact_collector._fact_ids
    assert 'year' in date_time
    assert 'month' in date_time
    assert 'weekday' in date_time
    assert 'weekday_number' in date_time
    assert 'weeknumber' in date_time
    assert 'day' in date_time
    assert 'hour' in date_time
    assert 'minute' in date_time
    assert 'second' in date_time
    assert 'epoch' in date_time

# Generated at 2022-06-23 00:59:03.855958
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    a=DateTimeFactCollector()
    t=a.collect()
    assert isinstance(t, dict)

# Generated at 2022-06-23 00:59:07.192990
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    test_instance = DateTimeFactCollector()
    assert 'date_time' == test_instance.name
    assert 'date_time' in test_instance.fact_ids
    assert 0 < len(test_instance.fact_ids)

# Generated at 2022-06-23 00:59:16.327779
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Initialize the DateTimeFactCollector object
    test_DateTimeFactCollector_obj = DateTimeFactCollector()
    result = test_DateTimeFactCollector_obj.collect()
    assert isinstance(result, dict)
    assert list(result['date_time'].keys()) == ['year', 'month', 'weekday', 'weekday_number', 'weeknumber', 'day', 'hour', 'minute', 'second', 'epoch', 'epoch_int', 'date', 'time', 'iso8601_micro', 'iso8601', 'iso8601_basic', 'iso8601_basic_short', 'tz', 'tz_dst', 'tz_offset']

# Generated at 2022-06-23 00:59:20.337903
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'
    assert len(x._fact_ids) == 0


# Generated at 2022-06-23 00:59:31.094402
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import unittest2 as unittest
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.datetime import DateTimeFactCollector

    class TestCollector(Collector):
        _fact_class = DateTimeFactCollector

        def __init__(self):
            self._facts_cache = None

        def get_fact_cache(self):
            return self._facts_cache

    class TestDateTimeFactCollector(unittest.TestCase):
        def test_DateTimeFactCollector_collect(self):
            collector = TestCollector()
            facts_dict = collector.collect()
            self.assertIn('date_time', facts_dict)

            date_time_facts = facts_dict['date_time']

# Generated at 2022-06-23 00:59:32.568119
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'

# Generated at 2022-06-23 00:59:35.640866
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    """Unit test for constructor of class DateTimeFactCollector"""
    date_time_collector = DateTimeFactCollector()
    assert isinstance(date_time_collector, BaseFactCollector)

# Generated at 2022-06-23 00:59:37.072221
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    assert dtfc.collect()

# Generated at 2022-06-23 00:59:39.523972
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dateTimeFactCollectorObj = DateTimeFactCollector()
    assert dateTimeFactCollectorObj is not None


# Generated at 2022-06-23 00:59:42.021831
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_facts = DateTimeFactCollector()
    date_time_facts.collect()
    assert date_time_facts.name == 'date_time'

# Generated at 2022-06-23 00:59:56.770202
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    requirements = [['date']]
    module = None

# Generated at 2022-06-23 01:00:00.256976
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()
    assert collector.name == 'date_time'

    # validate _fact_ids is set to an empty set
    assert collector._fact_ids == set()


# Generated at 2022-06-23 01:00:01.392029
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    DateTimeFactCollector().collect()

# Generated at 2022-06-23 01:00:04.218672
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    dtfc.collect()

# Test method collect of class DateTimeFactCollector
test_DateTimeFactCollector_collect()

# Generated at 2022-06-23 01:00:15.318451
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Create DateTimeFactCollector object
    collector = DateTimeFactCollector()
    # Create dict for collected facts
    collected_facts = dict()
    now = datetime.datetime.now()
    utcnow = datetime.datetime.utcnow()
    # Create dict for mock-implemented method 'get_file_content' of class BaseFactCollector
    def mock_get_file_content(file):
        # In this test, get_file_content is not used
        pass
    # Create dict for mock-implemented method 'exec_command' of class BaseFactCollector
    # In this test, exec_command is not used
    def mock_exec_command(cmd):
        pass
    # Create dict for mock-implemented method 'get_file_lines' of class BaseFactCollector
    # In this

# Generated at 2022-06-23 01:00:26.481449
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    class mock_and_save_collected_facts():
        def __init__(self):
            self.facts = {}

        def save_fact(self, key, value):
            self.facts[key] = value

        def get_facts(self):
            return self.facts

    mock_collected_facts = mock_and_save_collected_facts()


# Generated at 2022-06-23 01:00:29.289403
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    from ansible.module_utils.facts import Collector

    collected_facts = Collector().collect(module=None, collected_facts=None)
    assert collected_facts['date_time']

# Generated at 2022-06-23 01:00:39.851571
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.system.date_time import DateTimeFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.os import OsFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.sysctl import SysctlFactCollector

    # Create a FactsCollector object with DateTimeFactCollector, DistributionFactCollect

# Generated at 2022-06-23 01:00:41.317943
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()
    assert collector.name == 'date_time'

# Generated at 2022-06-23 01:00:53.550312
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Instantiate an object of DateTimeFactCollector class.
    test_date_time_fact_collector = DateTimeFactCollector()

    # Check the name of the class.
    assert test_date_time_fact_collector.name == 'date_time', \
        "test_date_time_fact_collector.name should return 'date_time' but it returned " + \
        test_date_time_fact_collector.name + " instead."

    # Check the name of the class.
    assert test_date_time_fact_collector._fact_ids == set(), \
        "test_date_time_fact_collector._fact_ids should return set() but it returned " + \
        test_date_time_fact_collector._fact_ids.__str__() + " instead."

    # Check the

# Generated at 2022-06-23 01:01:03.006827
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    date_time_collector = DateTimeFactCollector()
    date_time_facts = date_time_collector.collect()

    assert date_time_facts.get('date_time') is not None

    date_time_fact = date_time_facts.get('date_time')

    assert date_time_fact['year'] != ''
    assert date_time_fact['month'] != ''
    assert date_time_fact['weekday'] != ''
    assert date_time_fact['weekday_number'] != ''
    assert date_time_fact['weeknumber'] != ''
    assert date_time_fact['day'] != ''
    assert date_time_fact['hour'] != ''
    assert date_time_fact['minute'] != ''
    assert date_time_fact['second'] != ''
    assert date_time_fact

# Generated at 2022-06-23 01:01:12.073700
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtf = DateTimeFactCollector()
    result = dtf.collect()

    # We should get a dict with exactly one key
    assert len(result) == 1
    assert 'date_time' in result

    # Check some fields that should be present in date_time
    date_time = result['date_time']

    # Validate that there is a key for each of the fields
    keys = date_time.keys()
    assert 'minutes' in keys
    assert 'day' in keys
    assert 'month' in keys
    assert 'time' in keys
    assert 'date' in keys
    assert 'epoch' in keys
    assert 'iso8601' in keys
    assert 'tz_offset' in keys
    assert 'tz' in keys
    assert 'weekday_number' in keys
    assert 'hour' in keys


# Generated at 2022-06-23 01:01:24.792593
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import sys

    if sys.version_info.major == 2:
        now = datetime.datetime.utcnow()
    else:
        now = datetime.datetime.now()

    time_struct = time.localtime()
    epoch_ts = time.time()

    dtfc = DateTimeFactCollector()
    facts_dict = dtfc.collect()

    assert type(facts_dict['date_time']) == dict
    assert facts_dict['date_time']['year'] == now.strftime('%Y')
    assert facts_dict['date_time']['month'] == now.strftime('%m')
    assert facts_dict['date_time']['weekday'] == time.strftime('%A', time_struct)

# Generated at 2022-06-23 01:01:33.894976
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # creating an instance of class DateTimeFactCollector
    date_time_fact_collector = DateTimeFactCollector()
    # execute the collect method of DateTimeFactCollector class
    date_time_facts = date_time_fact_collector.collect()
    date_time_fact_dict = date_time_facts['date_time']
    # check if the collected date_time_fact_dict is not empty
    assert date_time_fact_dict
    # check if the collected date_time_fact_dict is of type dict
    assert isinstance(date_time_fact_dict, dict)
    # check if the epoch key of the dictionary is not empty
    assert date_time_fact_dict['epoch']

# Generated at 2022-06-23 01:01:42.392348
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    tz_name = time.tzname
    epoch_ts = time.time()
    now = datetime.datetime.fromtimestamp(epoch_ts)
    utcnow = datetime.datetime.utcfromtimestamp(epoch_ts)


# Generated at 2022-06-23 01:01:53.807329
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    facts = dtfc.collect()
    assert(type(facts) is dict)
    assert('date_time' in facts)
    assert('year' in facts['date_time'])
    assert('month' in facts['date_time'])
    assert('weekday' in facts['date_time'])
    assert('weekday_number' in facts['date_time'])
    assert('weeknumber' in facts['date_time'])
    assert('day' in facts['date_time'])
    assert('hour' in facts['date_time'])
    assert('minute' in facts['date_time'])
    assert('second' in facts['date_time'])
    assert('epoch' in facts['date_time'])

# Generated at 2022-06-23 01:01:56.344056
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    t = DateTimeFactCollector()
    assert t.name == 'date_time'
    assert not t._fact_ids

# Generated at 2022-06-23 01:01:59.028281
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector(
        module=None,
        collected_facts=None
    )
    assert collector.name == 'date_time'
    assert collector._fact_ids == set()


# Generated at 2022-06-23 01:02:07.943442
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts import Facts

    g = DateTimeFactCollector()
    results = g.collect(None, Facts())

    time_max = time.time() + 5
    time_min = time.time() - 5
    assert results['date_time']['epoch'] == results['date_time']['epoch_int']
    assert float(results['date_time']['epoch']) >= time_min
    assert float(results['date_time']['epoch']) <= time_max
    assert int(results['date_time']['epoch_int']) >= time_min
    assert int(results['date_time']['epoch_int']) <= time_max

# Generated at 2022-06-23 01:02:18.774347
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts.collector import Collectors
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import timeout
    import ansible.module_utils.facts.collector.date_time

    dtf = ansible.module_utils.facts.collector.date_time.DateTimeFactCollector(Collectors({}, Facts({}), None))
    _c = dtf.collect()
    assert 'date_time' in _c
    assert 'date' in _c['date_time']
    assert 'iso8601_basic' in _c['date_time']
    assert 'epoch' in _c['date_time']

# Generated at 2022-06-23 01:02:22.164043
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt.name == 'date_time'
    assert dt._fact_ids == set()
    assert type(dt.collect()) == dict


# Generated at 2022-06-23 01:02:24.899685
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    fc = DateTimeFactCollector()
    assert fc.name == 'date_time'
    assert fc._fact_ids == set()


# Generated at 2022-06-23 01:02:28.192619
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_facts_instance = DateTimeFactCollector()
    assert date_time_facts_instance.name == 'date_time'
    assert date_time_facts_instance._fact_ids == set()

# Generated at 2022-06-23 01:02:30.444667
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
	result = DateTimeFactCollector()
	assert result is not None


# Generated at 2022-06-23 01:02:43.458993
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import ansible.module_utils.facts.collectors.date_time as date_time_collector
    import datetime
    import time
    test_case_1 = date_time_collector.DateTimeFactCollector()
    dt = test_case_1.collect()
    year = dt['date_time']['year']
    month = dt['date_time']['month']
    day = dt['date_time']['day']
    hour = dt['date_time']['hour']
    minute = dt['date_time']['minute']
    second = dt['date_time']['second']
    epoch = dt['date_time']['epoch']
    today = datetime.date.today()
    now = datetime.datetime.now()

# Generated at 2022-06-23 01:02:53.063132
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    result = dtfc.collect()

    assert 'date_time' in result
    assert 'epoch' in result['date_time']
    assert 'epoch_int' in result['date_time']
    assert 'date' in result['date_time']
    assert 'time' in result['date_time']
    assert 'iso8601' in result['date_time']
    assert 'tz' in result['date_time']
    assert 'tz_dst' in result['date_time']
    assert 'tz_offset' in result['date_time']
    assert result['date_time']['epoch'] == result['date_time']['epoch_int']
    assert int(result['date_time']['epoch']) > 0

# Generated at 2022-06-23 01:02:56.074858
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt_facts = DateTimeFactCollector()
    assert dt_facts.name == 'date_time'
    assert dt_facts._fact_ids == set()

# Generated at 2022-06-23 01:02:58.375131
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt_facts = DateTimeFactCollector()
    assert dt_facts.name == 'date_time'


# Generated at 2022-06-23 01:03:02.452944
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():

    print("Testing constructor of class DateTimeFactCollector")

    f = DateTimeFactCollector()

    if f.name != 'date_time':
        raise AssertionError("Failed to create object with correct name")


# Generated at 2022-06-23 01:03:11.983261
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    time_data = time.localtime()
    dtfc.collect()
    # Lets test some of the values
    assert dtfc.get_facts()['date_time']['year'] == time.strftime("%Y", time_data)
    assert dtfc.get_facts()['date_time']['month'] == time.strftime("%m", time_data)
    assert dtfc.get_facts()['date_time']['weekday'] == time.strftime("%A", time_data)
    assert dtfc.get_facts()['date_time']['weekday_number'] == time.strftime("%w", time_data)

# Generated at 2022-06-23 01:03:16.875219
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj.name == "date_time"
    assert obj._fact_ids == set()


# Generated at 2022-06-23 01:03:26.585233
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    import types
    from ansible.module_utils.facts.collector import BaseFactCollector

    date_time_fact_collector = DateTimeFactCollector()
    # Test that class implements method
    assert hasattr(date_time_fact_collector, "collect")
    assert type(date_time_fact_collector.collect) == types.MethodType
    # Test that method overrides parent class method
    assert date_time_fact_collector.collect != BaseFactCollector.collect
    # Test that output of method is a dictionary
    assert isinstance(date_time_fact_collector.collect(), dict)

# Generated at 2022-06-23 01:03:31.132404
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # First create an instance of the DateTimeFactCollector class
    x = DateTimeFactCollector()

    # Execute the collect() method of the DateTimeFactCollector class
    dict = x.collect()
    # Make sure the returned object is of the right type
    assert(isinstance(dict, dict))

# Generated at 2022-06-23 01:03:39.541788
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    facts_dict = date_time_fact_collector.collect()
    assert 'date_time' in facts_dict, "No date time facts"
    date_time_facts = facts_dict['date_time']
    assert 'epoch' in date_time_facts, "No epoch fact"
    assert 'epoch_int' in date_time_facts, "No epoch_int fact"
    assert 'iso8601_micro' in date_time_facts, "No iso8601_micro fact"
    assert 'iso8601_basic' in date_time_facts, "No iso8601_basic fact"
    assert 'iso8601_basic_short' in date_time_facts, "No iso8601_basic_short fact"

# Generated at 2022-06-23 01:03:49.252471
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    facts = fact_collector.collect()
    # Example facts
    # {'date_time': {'year': '2019', 'month': '03', 'weekday': 'Tuesday', 'weekday_number': '2', 'weeknumber': '10', 'day': '26', 'hour': '00', 'minute': '00', 'second': '00', 'epoch': '1553582414', 'epoch_int': '1553582414', 'date': '2019-03-26', 'time': '00:00:14', 'iso8601_micro': '2019-03-26T08:00:14.946092Z', 'iso8601': '2019-03-26T08:00:14Z', 'iso8601_basic': '20190326T000000946092

# Generated at 2022-06-23 01:04:01.370406
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = datetime.datetime.now()
    dt_iso = dt.isoformat()
    dt_utc = datetime.datetime.utcnow()
    

    # Create a mock class, with a fake collect method
    class MockClass:
        def __init__(self, dt, dt_iso, dt_utc):
            self._dt = dt
            self._dt_iso = dt_iso
            self._dt_utc = dt_utc

        def utcnow(self):
            return self._dt_utc

        def fromtimestamp(self, ts):
            return self._dt

        def utcfromtimestamp(self, ts):
            return self._dt_utc

        def isofromat(self):
            return self._dt_iso

    


# Generated at 2022-06-23 01:04:09.414105
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    tests:
      date_time.DateTimeFactCollector:
        collect:
    """
    collector = DateTimeFactCollector()
    # List of fields expected
    fields = [
        'year',
        'month',
        'weekday',
        'weekday_number',
        'weeknumber',
        'day',
        'hour',
        'minute',
        'second',
        'epoch',
        'epoch_int',
        'date',
        'time',
        'iso8601_micro',
        'iso8601',
        'iso8601_basic',
        'iso8601_basic_short',
        'tz',
        'tz_dst',
        'tz_offset',
    ]
    # Set of fields expected

# Generated at 2022-06-23 01:04:10.935887
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector().name == 'date_time'

# Generated at 2022-06-23 01:04:13.212446
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'


# Generated at 2022-06-23 01:04:21.082512
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()
    assert collector.name == 'date_time', \
        'Wrong DateTimeFactCollector.name. Expected "date_time", got {0}'.format(collector.name)
    assert len(collector._fact_ids) == 0, \
        'Wrong DateTimeFactCollector._fact_ids. Expected 0, got {0}'.format(len(collector._fact_ids))


# Generated at 2022-06-23 01:04:22.822899
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt.name == 'date_time'

# Generated at 2022-06-23 01:04:32.418789
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # Initialize the collector.
    test_dt_collector = DateTimeFactCollector()
    date_time_facts = test_dt_collector.collect()

    # note that this 'date_time' key is not in the facts_dict
    # since a key is added for the ansible_local object
    # (which is a subclass of DateTimeFactCollector)
    # to use for the hostname facts.
    assert 'date_time' in date_time_facts
    assert 'year' in date_time_facts['date_time']
    assert 'month' in date_time_facts['date_time']
    assert 'weekday' in date_time_facts['date_time']
    assert 'day' in date_time_facts['date_time']
    assert 'hour' in date_time_facts['date_time']

# Generated at 2022-06-23 01:04:37.990339
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Unit test for method collect of class DateTimeFactCollector"""

    date_time_fact_collector = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector.collect()
    assert 'date_time' in date_time_facts
    assert 'year' in date_time_facts['date_time']
    assert 'month' in date_time_facts['date_time']
    assert 'weekday' in date_time_facts['date_time']
    assert 'weekday_number' in date_time_facts['date_time']
    assert 'weeknumber' in date_time_facts['date_time']
    assert 'day' in date_time_facts['date_time']
    assert 'hour' in date_time_facts['date_time']
    assert 'minute' in date_time

# Generated at 2022-06-23 01:04:39.067466
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    assert 1 == 1

# Generated at 2022-06-23 01:04:42.644850
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_fact_collector = DateTimeFactCollector()
    assert date_fact_collector.name == 'date_time'

# Generated at 2022-06-23 01:04:44.835526
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtf = DateTimeFactCollector()
    assert dtf.name == 'date_time'
    assert isinstance(dtf._fact_ids, set)

# Generated at 2022-06-23 01:04:46.679405
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'

# Generated at 2022-06-23 01:04:50.240889
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    """Tests the constructor for class DateTimeFactCollector"""

    dt = DateTimeFactCollector()
    assert dt.name == 'date_time'
    assert dt._fact_ids == set()

# Generated at 2022-06-23 01:04:52.791299
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = DateTimeFactCollector()
    assert 'date_time' in dt.collect().keys()

# Generated at 2022-06-23 01:04:56.115403
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    r = DateTimeFactCollector()
    assert r.name == 'date_time'
    assert r._fact_ids == set()

# Generated at 2022-06-23 01:04:58.661577
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'
    assert x._fact_ids == set()

# Generated at 2022-06-23 01:05:05.166813
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    df = DateTimeFactCollector()
    fact_dict = df.collect()
    # Assert that a date_time key is returned
    assert fact_dict.get('date_time')
    # Assert that epoch_int has integer value
    assert int(fact_dict.get('date_time').get('epoch_int'))
    # Assert that epoch_int is valid (roughly)
    assert int(fact_dict.get('date_time').get('epoch_int')) != 0
    # Assert that epoch has string value
    assert isinstance(fact_dict.get('date_time').get('epoch'), str)


# Generated at 2022-06-23 01:05:06.478362
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()

# Generated at 2022-06-23 01:05:11.379482
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Test instantiation of DateTimeFactCollector
    DateTimeFactCollector()
    # Test generation of random fact in dict format (name and data)
    DateTimeFactCollector().collect()

if __name__ == '__main__':
    # Unit test code
    test_DateTimeFactCollector()
    exit()

# Generated at 2022-06-23 01:05:17.118151
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():

    s = DateTimeFactCollector()
    assert s.name == 'date_time'
    assert 'date_time' in s._fact_ids

# Generated at 2022-06-23 01:05:27.417516
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_facts = {}
    date_time_facts['year'] = '2012'
    date_time_facts['month'] = '11'
    date_time_facts['weekday'] = 'Thursday'
    date_time_facts['weekday_number'] = '4'
    date_time_facts['weeknumber'] = '45'
    date_time_facts['day'] = '22'
    date_time_facts['hour'] = '16'
    date_time_facts['minute'] = '32'
    date_time_facts['second'] = '41'
    date_time_facts['epoch'] = '1353512561'
    date_time_facts['epoch_int'] = '1353512561'
    date_time_facts['date'] = '2012-11-22'
    date_

# Generated at 2022-06-23 01:05:31.608702
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    input_module = mock_module()
    input_module.params = {'gather_subset': ['!all', 'network']}
    input_facts = {}
    # Constructor of class DateTimeFactCollector
    DateTimeFactCollector(input_module, input_facts)

# Generated at 2022-06-23 01:05:33.515842
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'
    assert dtfc._fact_ids == set()


# Generated at 2022-06-23 01:05:43.924014
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    test_collector = DateTimeFactCollector()
    test_collected_facts = {}
    test_facts = {}

# Generated at 2022-06-23 01:05:45.627921
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    my_dt = DateTimeFactCollector()
    assert my_dt.name == 'date_time'

# Generated at 2022-06-23 01:05:56.760493
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    fact_collector = DateTimeFactCollector()
    now = datetime.datetime.utcnow()

# Generated at 2022-06-23 01:05:58.581928
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_facts = DateTimeFactCollector()
    assert date_time_facts.name == 'date_time'

# Generated at 2022-06-23 01:06:03.080720
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fixture = DateTimeFactCollector()
    data = fixture.collect()
    assert data['date_time']['iso8601_micro']

# Generated at 2022-06-23 01:06:05.436118
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()
    assert collector.name == 'date_time'
    assert collector._fact_ids == set()

# Generated at 2022-06-23 01:06:06.391185
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()

# Generated at 2022-06-23 01:06:08.836668
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtf = DateTimeFactCollector()
    dtf.collect()
    assert(dtf is not None)
    assert(dtf.name == 'date_time')

# Generated at 2022-06-23 01:06:10.425465
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector.collect()

# Generated at 2022-06-23 01:06:14.276825
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    """Test DateTimeFactCollector instantiation"""
    date_time_collector = DateTimeFactCollector()
    assert date_time_collector.name == 'date_time'
    assert date_time_collector._fact_ids == set()


# Generated at 2022-06-23 01:06:24.298956
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtf = DateTimeFactCollector()

    assert dtf.collect() is not None
    assert isinstance(dtf.collect(), dict)
    assert 'date_time' in dtf.collect()
    assert dtf.collect()['date_time'] is not None
    assert isinstance(dtf.collect()['date_time'], dict)
    assert dtf.collect()['date_time']['year'] is not None
    assert dtf.collect()['date_time']['month'] is not None
    assert dtf.collect()['date_time']['weekday'] is not None
    assert dtf.collect()['date_time']['weekday_number'] is not None
    assert dtf.collect()['date_time']['weeknumber'] is not None

# Generated at 2022-06-23 01:06:36.391421
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Initialize a DateTimeFactCollector object
    date_time_obj = DateTimeFactCollector()
    # Store the timezone information of current instance
    time_zone = time.strftime("%Z")
    # Store the daylight saving time information of current instance
    time_zone_dst = time.tzname[1]
    # Store the offset information of current instance
    time_zone_offset = time.strftime("%z")
    # Store the local time information of current instance
    now = datetime.datetime.fromtimestamp(time.time())
    # Store epoch_time information of current instance
    epoch_ts = time.time()
    # Store current month
    month = now.strftime('%m')
    # Store current day
    day = now.strftime('%d')
    # Store current year
    yr

# Generated at 2022-06-23 01:06:38.692441
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj.name == 'date_time'

# Generated at 2022-06-23 01:06:39.892363
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj.name == 'date_time'

# Generated at 2022-06-23 01:06:41.673746
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    class MockModule:
        pass
    module = MockModule()
    DateTimeFactCollector().collect()

# Generated at 2022-06-23 01:06:46.692182
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    DateTimeFactCollector = DateTimeFactCollector()
    facts = Collector().collect(DateTimeFactCollector)
    assert facts['date_time']['year'] == '2017'


# Generated at 2022-06-23 01:06:49.124524
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    try:
        DateTimeFactCollector()
    except:
        raise AssertionError("Failed to instantiate collector")


# Generated at 2022-06-23 01:07:01.435469
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    c = DateTimeFactCollector()
    facts = c.collect()
    assert type(facts) == dict
    assert facts.has_key('date_time')
    assert type(facts['date_time']) == dict
    # Note: year is not a key of date_time.  It is only a key of ansible_date_time.
    assert facts['date_time'].has_key('year')
    assert type(facts['date_time']['year']) == str
    assert facts['date_time'].has_key('month')
    assert type(facts['date_time']['month']) == str
    assert facts['date_time'].has_key('weekday')
    assert type(facts['date_time']['weekday']) == str
    assert facts['date_time'].has_key

# Generated at 2022-06-23 01:07:10.728580
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    ft = DateTimeFactCollector()
    facts = ft.collect()
    assert(facts['date_time']['hour'] == datetime.datetime.now().strftime("%H"))
    assert(facts['date_time']['iso8601_micro'] == datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.%fZ"))
    assert(facts['date_time']['iso8601_basic'] == datetime.datetime.now().strftime("%Y%m%dT%H%M%S%f"))


# Generated at 2022-06-23 01:07:14.077026
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # create a collector of DateTimeFactCollector class
    collecotr = DateTimeFactCollector()
    # check if the collector created is an object of BaseFactCollector class 
    assert isinstance(collecotr, BaseFactCollector)

# Generated at 2022-06-23 01:07:16.837315
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    """This is a test for the constructor of the DateTimeFactCollector class"""
    x = DateTimeFactCollector()
    # Test the class name
    assert x.name == 'date_time'

# Generated at 2022-06-23 01:07:20.300479
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date = DateTimeFactCollector()
    assert date.name == 'date_time'



# Generated at 2022-06-23 01:07:31.060823
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.collector.datetime import DateTimeFactCollector

    module = FakeAnsibleModule()
    facts_obj = Facts(module)
    fact_collector = DateTimeFactCollector(module=module, facts=facts_obj)
    assert isinstance(fact_collector, FactCollector)
    assert isinstance(fact_collector, DateTimeFactCollector)
    assert fact_collector.name == 'date_time'
    assert fact_collector._fact_ids == {'date_time'}


# Generated at 2022-06-23 01:07:40.189458
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    c = DateTimeFactCollector()
    result = c.collect()
    assert result is not None
    assert 'date_time' in result
    assert 'year' in result['date_time']
    assert 'month' in result['date_time']
    assert 'weekday' in result['date_time']
    assert 'weekday_number' in result['date_time']
    assert 'weeknumber' in result['date_time']
    assert 'day' in result['date_time']
    assert 'hour' in result['date_time']
    assert 'minute' in result['date_time']
    assert 'second' in result['date_time']
    assert 'epoch' in result['date_time']
    assert 'epoch_int' in result['date_time']
    assert 'date' in result['date_time']

# Generated at 2022-06-23 01:07:47.647909
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Create a DateTimeFactCollector object
    DateTimeFactCollectorObject = DateTimeFactCollector()

    # Check the instance created is of type DateTimeFactCollector
    assert isinstance(DateTimeFactCollectorObject, DateTimeFactCollector)

    # Check the name of instance is 'date_time'
    assert DateTimeFactCollectorObject.name == 'date_time'

    # Check the _fact_ids of instance is a empty set
    assert DateTimeFactCollectorObject._fact_ids == set()


# Generated at 2022-06-23 01:07:57.703373
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts import FactCollector

    date_time_fact_collector = DateTimeFactCollector(module=None)
    facts_dict = date_time_fact_collector.collect(module=None, collected_facts=None)

    assert isinstance(facts_dict, dict), 'result must be of type dict'
    assert 'date_time' in facts_dict, 'result must contain a "date_time" key.'

    date_time_facts = facts_dict['date_time']
    assert isinstance(date_time_facts, dict), 'result["date_time"] must be of type dict'
    assert 'year' in date_time_facts, 'result["date_time"] must contain a year key.'

# Generated at 2022-06-23 01:08:04.363508
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    class module_mock(object):
        def __init__(self):
            self.ids = {}
    module = module_mock()
    dtfc = DateTimeFactCollector(module)
    assert dtfc.collect().keys() == ['date_time']
    assert not dtfc.collect()['date_time']['epoch'].startswith('%')
    assert not dtfc.collect()['date_time']['epoch_int'].startswith('%')

# Generated at 2022-06-23 01:08:07.028120
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    """This function returns the DateTimeFactCollector object for testing."""
    return DateTimeFactCollector()

# Generated at 2022-06-23 01:08:18.802400
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = DateTimeFactCollector()
    d = dt.collect()
    assert isinstance(d, dict)
    assert len(d) == 1

    # Ensure all of the required keys are present and the values are the right
    # type.  Don't expect anything more than that.