

# Generated at 2022-06-23 00:58:23.714252
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    facts = DateTimeFactCollector().collect()
    assert facts == load_fixture('date_time_facts.json')
    assert facts['date_time']['weeknumber'] != '%W'

# Generated at 2022-06-23 00:58:27.085119
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    objDateTimeFactCollector = DateTimeFactCollector()
    assert objDateTimeFactCollector.name == "date_time"
    assert objDateTimeFactCollector._fact_ids == set()

# Generated at 2022-06-23 00:58:38.329986
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import re
    import pytest
    from mock import patch
    from ansible.module_utils.facts.collector import BaseFactCollector

    # given
    test_object = DateTimeFactCollector()
    test_object.get_file_content = lambda *args: None

    # when
    with patch.object(BaseFactCollector, 'collect', return_value={}):
        with patch('ansible.module_utils.facts.collector.time_monotonic', return_value=1505126753.768012):
            with patch('ansible.module_utils.facts.collector.datetime', autospec=True) as mock_datetime:
                mock_datetime.datetime.fromtimestamp.return_value = datetime.datetime(2017, 9, 12, 15, 52, 33, 768012)
                mock

# Generated at 2022-06-23 00:58:50.438592
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-23 00:59:02.101037
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_facts = DateTimeFactCollector()

# Generated at 2022-06-23 00:59:04.827440
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'
    assert x._fact_ids == set()
    assert x.collect() is not None

# Generated at 2022-06-23 00:59:13.387665
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    c = DateTimeFactCollector.collect()
    assert type(c['date_time']['year']) is str
    assert type(c['date_time']['month']) is str
    assert type(c['date_time']['weekday']) is str
    assert type(c['date_time']['weekday_number']) is str
    assert type(c['date_time']['weeknumber']) is str
    assert type(c['date_time']['day']) is str
    assert type(c['date_time']['hour']) is str
    assert type(c['date_time']['minute']) is str
    assert type(c['date_time']['second']) is str
    assert type(c['date_time']['epoch']) is str
   

# Generated at 2022-06-23 00:59:22.196608
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = DateTimeFactCollector()
    D = dt.collect()
    assert isinstance(D, dict)
    assert 'date_time' in D.keys()
    assert isinstance(D['date_time'], dict)
    assert 'year' in D['date_time'].keys()
    assert 'month' in D['date_time'].keys()
    assert 'weekday' in D['date_time'].keys()
    assert 'weekday_number' in D['date_time'].keys()
    assert 'weeknumber' in D['date_time'].keys()
    assert 'day' in D['date_time'].keys()
    assert 'hour' in D['date_time'].keys()
    assert 'minute' in D['date_time'].keys()

# Generated at 2022-06-23 00:59:24.906808
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    assert(DateTimeFactCollector.collect()['date_time']['time'] == datetime.datetime.now().strftime("%H:%M:%S"))

# Generated at 2022-06-23 00:59:29.683321
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt.name == 'date_time'
    assert dt._fact_ids == set()

# Generated at 2022-06-23 00:59:30.305657
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    pass

# Generated at 2022-06-23 00:59:40.911835
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Unit test for method collect of class DateTimeFactCollector"""

    # Create instance of DateTimeFactCollector class
    instance = DateTimeFactCollector()

    # Call method collect of class DateTimeFactCollector with empty module and collected_facts
    # This should return a dictionary containing the key 'date_time'
    assert isinstance(instance.collect(None, None), dict)
    assert 'date_time' in instance.collect(None, None)

    # Call method collect of class DateTimeFactCollector with empty module and collected_facts
    # This should return a dictionary containing the correct values for the date_time facts
    date_time_facts = instance.collect(None, None)['date_time']

    assert isinstance(date_time_facts['year'], str)
    assert date_time_facts['year'].isdigit()



# Generated at 2022-06-23 00:59:49.563770
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc is not None
    assert dtfc.name == 'date_time'
    assert dtfc._fact_ids == set()
    assert isinstance(dtfc, BaseFactCollector)


# Generated at 2022-06-23 01:00:01.563304
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Test DateTimeFactCollector Collection
    t_utcnow = datetime.datetime.utcnow()
    t_now = datetime.datetime.now()

    dtf = DateTimeFactCollector()
    dtf_facts = dtf.collect()

    # Test date_time facts
    date_time = dtf_facts['date_time']
    assert date_time['year'] == t_now.strftime("%Y")
    assert date_time['month'] == t_now.strftime("%m")
    assert date_time['weekday'] == t_now.strftime("%A")
    assert date_time['weekday_number'] == t_now.strftime("%w")
    assert date_time['weeknumber'] == t_now.strftime("%W")

# Generated at 2022-06-23 01:00:02.652797
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()


# Generated at 2022-06-23 01:00:14.010236
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts import search_dict_on_key
    from time import time
    from time import sleep
    from time import gmtime
    from time import strftime
    collector = DateTimeFactCollector()
    fixture = collector.collect({}, [])
    assert search_dict_on_key(fixture, 'date_time')
    assert fixture['date_time']['year'] == strftime('%Y')
    assert fixture['date_time']['month'] == strftime('%m')
    assert fixture['date_time']['weekday'] == strftime('%A')
    assert fixture['date_time']['weekday_number'] == strftime('%w')
    assert fixture['date_time']['weeknumber'] == strftime('%W')

# Generated at 2022-06-23 01:00:24.019492
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_facts = DateTimeFactCollector.collect()['date_time']
    assert date_time_facts['year'] == str(datetime.datetime.now().year)
    assert date_time_facts['month'] == str(datetime.datetime.now().month).zfill(2)
    assert date_time_facts['weekday']
    assert date_time_facts['weekday_number']
    assert date_time_facts['weeknumber']
    assert date_time_facts['day'] == str(datetime.datetime.now().day).zfill(2)
    assert date_time_facts['hour'] == str(datetime.datetime.now().hour).zfill(2)
    assert date_time_facts['minute'] == str(datetime.datetime.now().minute).zfill(2)


# Generated at 2022-06-23 01:00:29.869384
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    f = DateTimeFactCollector()
    d = f.collect()
    assert isinstance(d, dict)
    assert d["date_time"]["tz_dst"] == time.tzname[1]
    assert d["date_time"]["tz_offset"] == time.strftime("%z")


# to be removed when the deprecated date time fact module is removed

# Generated at 2022-06-23 01:00:35.675792
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import pytest

    # Test case - get date_time facts
    date_time_facts = DateTimeFactCollector().collect()
    if isinstance(date_time_facts, dict):
        assert ('date_time' in dict(date_time_facts).keys())
    else:
        pytest.fail('date_time facts is not a dict')



# Generated at 2022-06-23 01:00:44.402583
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_collector = DateTimeFactCollector()
    date_time_facts = date_time_collector.collect()
    assert date_time_facts['date_time']['epoch'] == str(int(time.time()))
    assert len(date_time_facts['date_time']['iso8601_basic']) == 20
    assert len(date_time_facts['date_time']['iso8601_basic_short']) == 17
    assert len(date_time_facts['date_time']['epoch_int']) >= 10
    assert len(date_time_facts['date_time']['iso8601_micro']) == 24
    assert len(date_time_facts['date_time']['iso8601']) == 20

# Generated at 2022-06-23 01:00:47.450283
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'
    assert x._fact_ids == set()


# Generated at 2022-06-23 01:00:57.212921
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # We're not validating the data itself as this would require an
    # unrealistic amount of mocking. Mostly, we're just making sure that
    # collect() returns a dict.

    import sys

    # Get parent module
    if sys.version_info[0] == 2:
        import __init__ as parent
    else:
    	from .. import __init__ as parent

    # Instantiate subclass
    dt_fact_collector = parent.DateTimeFactCollector()

    # Call superclass method
    facts = dt_fact_collector.collect()

    # Assert
    assert isinstance(facts, dict) and 'date_time' in facts

# Generated at 2022-06-23 01:01:09.506325
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-23 01:01:16.217345
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collect = DateTimeFactCollector()
    facts = collect.collect()
    assert 'date_time' in facts
    assert 'date' in facts['date_time']
    assert 'time' in facts['date_time']
    assert 'epoch' in facts['date_time']
    assert 'iso8601' in facts['date_time']

# Generated at 2022-06-23 01:01:27.527807
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # instantiate
    date_time_collector = DateTimeFactCollector()
    date_time_facts = date_time_collector.collect()

    # test expected results
    assert date_time_facts is not None
    assert 'date_time' in date_time_facts
    assert 'year' in date_time_facts['date_time']
    assert 'month' in date_time_facts['date_time']
    assert 'weekday' in date_time_facts['date_time']
    assert 'weekday_number' in date_time_facts['date_time']
    assert 'weeknumber' in date_time_facts['date_time']
    assert 'day' in date_time_facts['date_time']
    assert 'hour' in date_time_facts['date_time']
    assert 'minute' in date

# Generated at 2022-06-23 01:01:32.391116
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Check if DateTimeFactCollector is declared properly
    factCollector = DateTimeFactCollector()
    assert factCollector.name == "date_time"
    assert factCollector._fact_ids == set()


# Generated at 2022-06-23 01:01:41.577117
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-23 01:01:53.743320
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Create an instance of the DateTimeFactCollector class
    collector = DateTimeFactCollector()

    # Call the collect method
    collected_facts = collector.collect()

    assert 'date_time' in collected_facts

    assert 'date' in collected_facts['date_time']
    assert 'time' in collected_facts['date_time']
    assert 'iso8601' in collected_facts['date_time']
    assert 'iso8601_basic' in collected_facts['date_time']
    assert 'iso8601_micro' in collected_facts['date_time']
    assert 'iso8601_basic_short' in collected_facts['date_time']
    assert 'epoch' in collected_facts['date_time']
    assert 'epoch_int' in collected_facts['date_time']

# Generated at 2022-06-23 01:01:58.701148
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Test for date_time facts when date_time fact is true
    date_time_fact = DateTimeFactCollector()
    date_time_facts = date_time_fact.collect()
    assert date_time_facts["date_time"]["month"] == time.strftime("%m")

# Generated at 2022-06-23 01:02:01.839489
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    """Test constructor of DateTimeFactCollector"""

    obj = DateTimeFactCollector()

    # Assert type of instance
    assert isinstance(obj, DateTimeFactCollector)


# Generated at 2022-06-23 01:02:03.732306
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    c = DateTimeFactCollector()
    assert c.name == 'date_time'
    assert len(c._fact_ids) == 0

# Generated at 2022-06-23 01:02:05.403780
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj.name == 'date_time'

# Generated at 2022-06-23 01:02:09.071850
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Init a DateTimeFactCollector
    DateTimeFactCollector_obj = DateTimeFactCollector()

    # Test the collect method
    assert DateTimeFactCollector_obj.collect()['date_time']


# Generated at 2022-06-23 01:02:11.482196
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector is not None


# Generated at 2022-06-23 01:02:13.936957
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'
    assert x._fact_ids == set()

# Generated at 2022-06-23 01:02:26.483076
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts.collectors.date_time import DateTimeFactCollector
    dtf = DateTimeFactCollector(None, None)
    fd = dtf.collect()
    assert 'date_time' in fd
    assert 'epoch' in fd['date_time']
    assert 'day' in fd['date_time']
    assert 'hour' in fd['date_time']
    assert 'minute' in fd['date_time']
    assert 'month' in fd['date_time']
    assert 'second' in fd['date_time']
    assert 'time' in fd['date_time']
    assert 'weekday' in fd['date_time']
    assert 'weekday_number' in fd['date_time']
    assert 'weeknumber' in f

# Generated at 2022-06-23 01:02:28.749738
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtf = DateTimeFactCollector()
    assert dtf.name == 'date_time'
    assert dtf._fact_ids == set()

# Generated at 2022-06-23 01:02:30.979893
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()

    assert collector.name == 'date_time'
    assert collector._fact_ids == set()


# Generated at 2022-06-23 01:02:36.947257
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    ansible_date_time = DateTimeFactCollector()
    assert ansible_date_time.name == 'date_time'
    assert not ansible_date_time._fact_ids


# Generated at 2022-06-23 01:02:40.557362
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtf = DateTimeFactCollector()

    assert isinstance(dtf.collect(), dict)
    assert len(dtf.collect()['date_time'].keys()) == 20

# Generated at 2022-06-23 01:02:42.865516
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    from ansible_collections.ansible.community.plugins.module_utils.facts.collectors.date_time import DateTimeFactCollector

    date_time_facts = DateTimeFactCollector()

    assert date_time_facts.name == 'date_time'
    assert date_time_facts._fact_ids == set()

# Generated at 2022-06-23 01:02:49.143863
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt_instance = DateTimeFactCollector()
    collected_facts = dt_instance.collect()
    assert collected_facts['date_time']['iso8601'] is not None
    assert collected_facts['date_time']['epoch_int'] is not None
    assert collected_facts['date_time']['day'] is not None
    assert collected_facts['date_time']['minute'] is not None


# Generated at 2022-06-23 01:03:00.363016
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from collections import namedtuple
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import get_collector_instance

    # This test will fail if the UTC offset is not 0 or +00:00
    # because it tests for a specific string output for iso8601_micro

    Facts = namedtuple('Facts', ['all', 'module_setup'])
    fact_collector = get_collector_instance(FactCollector, 'DateTimeFactCollector')
    results = fact_collector.collect()

    # Tests that the key 'date_time' is present
    assert 'date_time' in results

    # Tests that the year result is 4 characters long
    assert len(results['date_time']['year']) == 4

    # Test the the format is YYY

# Generated at 2022-06-23 01:03:12.100119
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_collector = DateTimeFactCollector()
    date_time_fact = date_time_collector.collect()

# Generated at 2022-06-23 01:03:13.006948
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    DateTimeFactCollector.collect()

# Generated at 2022-06-23 01:03:19.319901
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # Collect the facts.
    fact_collector = DateTimeFactCollector()
    datetime_facts = fact_collector.collect(module=None, collected_facts=None)

    # The module supposes that the type of the epoch_int is integer.
    epoch_int = datetime_facts['date_time']['epoch_int']
    assert isinstance(int(epoch_int), int)

# Generated at 2022-06-23 01:03:28.380335
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    dtfc_dict = dtfc.collect()
    assert isinstance(dtfc_dict, dict)
    assert 'date_time' in dtfc_dict
    assert isinstance(dtfc_dict['date_time'], dict)
    assert 'date' in dtfc_dict['date_time']
    assert 'time' in dtfc_dict['date_time']


# Generated at 2022-06-23 01:03:38.766678
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    '''DateTimeFactCollector.collect should return a dict with the current
    date_time values'''

    import pytest

    # create DateTimeFactCollector object
    dtf = DateTimeFactCollector()
    assert dtf.name == 'date_time'
    assert dtf._fact_ids == set()

    # retrieve current date_time
    date_time = dtf.collect()

    # confirm the current date_time has been retrieved and the result
    # is an AnsibleFact object
    expected_facts = date_time
    assert date_time == expected_facts
    assert isinstance(date_time, dict)

    # confirm that a KeyError is raised if an invalid key is requested
    with pytest.raises(KeyError) as err:
        with pytest.warns(None) as warns:
            date_

# Generated at 2022-06-23 01:03:40.629825
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector.name == 'date_time'
    # This can vary depending on what time is n when unit test was ran
    assert len(DateTimeFactCollector().collect()['date_time']) == 20

# Generated at 2022-06-23 01:03:49.484675
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Unit test method collect of DateTimeFactCollector
    """
    from ansible.module_utils.facts import periodic
    import pytest
    # TODO: If all the fact collectors are aggregated into a
    # single object and returned, then the test logic can be
    # simplified. But there would also be code cleanup work.
    #
    #
    # inv: inventory object
    #
    # This object is required when some of the fact collectors
    # are depend on inventory groups. For example, the
    # NetworkFactCollector depends on inventory groups.
    inv = periodic.Inventory('localhost')
    collector = DateTimeFactCollector(inv, None)
    # facts: facts collected by DateTimeFactCollector
    facts = collector.collect()
    date_time_facts = facts['date_time']

    # year is expected to have

# Generated at 2022-06-23 01:04:01.478648
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_DateTimeFactCollector = DateTimeFactCollector()

# Generated at 2022-06-23 01:04:03.561733
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    datetime_fact_collector = DateTimeFactCollector()
    assert datetime_fact_collector is not None


# Generated at 2022-06-23 01:04:09.474172
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_facts = DateTimeFactCollector()

    # Create a Fake module
    import types
    module = types.ModuleType('ansible_fake_module')
    date_time_facts.collect(module=module, collected_facts=None)


# Generated at 2022-06-23 01:04:10.988995
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    f = DateTimeFactCollector()
    assert f.name == 'date_time'

# Generated at 2022-06-23 01:04:13.987297
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dateTimeFact = DateTimeFactCollector()
    assert dateTimeFact.name == 'date_time'
    assert dateTimeFact._fact_ids == set()


# Generated at 2022-06-23 01:04:25.899137
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collectr = DateTimeFactCollector()
    assert collectr.name == 'date_time'

# Generated at 2022-06-23 01:04:37.939179
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    datetime_collector = DateTimeFactCollector()
    now = datetime.datetime.now()
    # datetime.datetime.now() is supported in python >= 2.7 so some checks are
    # only run for python >= 2.7.
    assert datetime_collector.collect()['date_time']['year'] == now.strftime('%Y')
    assert 'iso8601_micro' in datetime_collector.collect()['date_time']
    if hasattr(datetime, 'fromtimestamp'):
        now = datetime.datetime.fromtimestamp(time.time())
        assert datetime_collector.collect()['date_time']['epoch'] == now.strftime('%s')

# Generated at 2022-06-23 01:04:42.122507
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_collector = DateTimeFactCollector()
    test_facts = test_collector.collect()
    assert 'date_time' in test_facts
    assert 'epoch' in test_facts['date_time']


# Generated at 2022-06-23 01:04:51.868019
# Unit test for constructor of class DateTimeFactCollector

# Generated at 2022-06-23 01:04:55.439731
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()

    assert collector.name == 'date_time'
    assert len(collector._fact_ids) == 0



# Generated at 2022-06-23 01:04:58.614821
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert(dt.name == 'date_time')
    assert(dt._fact_ids == set())


# Generated at 2022-06-23 01:05:01.037823
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj
    assert obj.name == 'date_time'
    assert obj._fact_ids == set()

# Generated at 2022-06-23 01:05:14.242015
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    datetime_collector = DateTimeFactCollector()
    collected_datetime_facts = datetime_collector.collect()
    assert 'date_time' in collected_datetime_facts
    assert 'year' in collected_datetime_facts['date_time']
    assert 'month' in collected_datetime_facts['date_time']
    assert 'weekday' in collected_datetime_facts['date_time']
    assert 'weekday_number' in collected_datetime_facts['date_time']
    assert 'weeknumber' in collected_datetime_facts['date_time']
    assert 'day' in collected_datetime_facts['date_time']
    assert 'hour' in collected_datetime_facts['date_time']
    assert 'minute' in collected_datetime_facts['date_time']

# Generated at 2022-06-23 01:05:17.737052
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt_fc = DateTimeFactCollector()
    assert dt_fc.name == 'date_time'
    assert dt_fc._fact_ids == set()

# Generated at 2022-06-23 01:05:27.841084
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_facts = {}
    date_time_facts['day'] = '17'
    date_time_facts['epoch'] = '1453271776'
    date_time_facts['epoch_int'] = '1453271776'
    date_time_facts['hour'] = '04'
    date_time_facts['iso8601'] = '2016-01-17T04:46:16Z'
    date_time_facts['iso8601_basic'] = '20160117T0451247'
    date_time_facts['iso8601_basic_short'] = '20160117T0451'

# Generated at 2022-06-23 01:05:36.250767
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts.collectors.date_time import DateTimeFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collector
    import datetime
    import time

    # The actual class is actually constructed with args, so we get rid of them
    real_init = DateTimeFactCollector.__init__
    def fake_init(self,*args,**kwargs):
        return real_init(self)
    DateTimeFactCollector.__init__ = fake_init

    fact_collector_object = DateTimeFactCollector(module=None, collected_facts=None)
    result = fact_collector_object.collect()
    assert isinstance(result, dict)
    assert 'date_time' in result.keys()


# Generated at 2022-06-23 01:05:39.891396
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    params = {'date_time': {}}
    dtf = DateTimeFactCollector(params)
    dtf.collect()
    assert params['date_time']['epoch_int'] == str(int(time.time()))

# Generated at 2022-06-23 01:05:41.874007
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    c = DateTimeFactCollector()
    facts = c.collect()
    assert facts['date_time'] is not None

# Generated at 2022-06-23 01:05:52.320406
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    collected_facts = fact_collector.collect()
    assert isinstance(collected_facts, dict)

# Generated at 2022-06-23 01:06:03.598973
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
	time_data = time.time()
	data = time.ctime(time_data)
	now = datetime.datetime.now()


# Generated at 2022-06-23 01:06:08.612067
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    """Unit test for constructor of class DateTimeFactCollector"""
    # Construct an instance of DateTimeFactCollector
    date_time_fact_collector = DateTimeFactCollector()
    # Test if the instance is successfully constructed
    assert isinstance(date_time_fact_collector, DateTimeFactCollector)

# Generated at 2022-06-23 01:06:10.611254
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'

# Generated at 2022-06-23 01:06:23.153447
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    now = datetime.datetime.now()
    # epoch_int, epoch, iso8601_micro, iso8601
    # iso8601_basic, iso8601_basic_short
    # cannot be guaranteed to be the same
    # because of the possibility of another
    # second passing, split into units
    date_time_facts = DateTimeFactCollector().collect()
    assert date_time_facts
    assert date_time_facts['date_time']
    assert date_time_facts['date_time']['year'] == now.strftime('%Y')
    assert date_time_facts['date_time']['month'] == now.strftime('%m')
    assert date_time_facts['date_time']['weekday'] == now.strftime('%A')

# Generated at 2022-06-23 01:06:26.606984
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time = DateTimeFactCollector()
    assert date_time.name == 'date_time'
    assert date_time._fact_ids == set()

# Generated at 2022-06-23 01:06:34.970830
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact = DateTimeFactCollector()
    result = fact.collect()
    assert type(result) is dict
    for KEY in ['year', 'month', 'weekday', 'weekday_number', 'weeknumber', 'day',
                'hour', 'minute', 'second', 'epoch', 'epoch_int', 'date', 'iso8601',
                'iso8601_micro', 'iso8601_basic', 'iso8601_basic_short', 'tz', 'tz_dst',
                'tz_offset']:
        assert (KEY in result['date_time'])

# Generated at 2022-06-23 01:06:48.409263
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    class MockModule(object):
        def __init__(self, params):
            self.params = params

        def fail_json(self, msg):
            self.msg = msg

    collector = DateTimeFactCollector()

    # Test 1: Collecting facts without any parameters
    # Ensure no exception thrown and that the fact collection
    # succeeded.
    module = MockModule({})
    assert collector.collect(module=module) is not None

    # Test 2: Asserting the dates and times are returned.
    # Check that all times are set to current time.
    # The test will pass if the time is earlier than the
    # current time since we don't want to test for exact
    # time.
    cur_time = datetime.datetime.now()

# Generated at 2022-06-23 01:06:52.006817
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtf = DateTimeFactCollector()
    assert dtf.name == 'date_time'
    assert isinstance(dtf._fact_ids, set)


# Generated at 2022-06-23 01:06:55.588510
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    facts_collector_obj = DateTimeFactCollector()
    assert facts_collector_obj is not None
    assert facts_collector_obj._fact_ids == set()
    assert facts_collector_obj.name == 'date_time'

# Generated at 2022-06-23 01:06:58.376256
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'
    assert dtfc._fact_ids == set()

# Generated at 2022-06-23 01:07:01.964000
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt_fact = DateTimeFactCollector()
    assert dt_fact.name == 'date_time'
    assert dt_fact._fact_ids == set()

# Generated at 2022-06-23 01:07:13.172827
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import pytz

    # Test initialization of DateTimeFactCollector
    dt_fc = DateTimeFactCollector()

    # Test get_epoch_for_timezone
    assert dt_fc.get_epoch_for_timezone(datetime.datetime(2017, 1, 8, 8, 0, 0), None) == 1483804000
    assert dt_fc.get_epoch_for_timezone(datetime.datetime(2017, 1, 8, 8, 0, 0), 'UTC') == 1483804000
    assert dt_fc.get_epoch_for_timezone(datetime.datetime(2017, 1, 8, 8, 0, 0), 'GMT') == 1483804000

# Generated at 2022-06-23 01:07:15.540840
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()
    assert collector.name == 'date_time'
    assert collector._fact_ids == set()


# Generated at 2022-06-23 01:07:19.188456
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Create DateTimeFactCollector and collect facts.
    # This test is not run when facts are collected on a remote host.
    # It is purely to test the constructor of the object.
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector.collect()

# Generated at 2022-06-23 01:07:21.418938
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    datetime = DateTimeFactCollector()
    assert datetime.name == 'date_time'
    assert datetime._fact_ids == set()

# Generated at 2022-06-23 01:07:25.787132
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()

    assert date_time_fact_collector.name == 'date_time'
    assert date_time_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:07:26.576011
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()

# Generated at 2022-06-23 01:07:33.521050
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_fact_collector = DateTimeFactCollector()
    date_fact_dict = date_fact_collector.collect()
    assert 'date_time' in date_fact_dict
    # Check some values
    assert 'second' in date_fact_dict['date_time']
    assert 'tz_offset' in date_fact_dict['date_time']
    assert 'year' in date_fact_dict['date_time']
    assert 'epoch_int' in date_fact_dict['date_time']

# Generated at 2022-06-23 01:07:35.781838
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert isinstance(x, DateTimeFactCollector)

# Generated at 2022-06-23 01:07:37.918444
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_collector = DateTimeFactCollector()
    assert date_time_collector.collect != "ERROR"

# Generated at 2022-06-23 01:07:40.369860
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    y = DateTimeFactCollector()
    assert y.name == 'date_time'
    assert set([]) == y._fact_ids



# Generated at 2022-06-23 01:07:41.496414
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    DateTimeFactCollector.collect()

# Generated at 2022-06-23 01:07:42.582654
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert(obj)

# Generated at 2022-06-23 01:07:45.007205
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_collector = DateTimeFactCollector()
    assert date_time_collector.name == 'date_time'

# Generated at 2022-06-23 01:07:49.422009
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtf = DateTimeFactCollector()
    # class name is 'DateTimeFactCollector'
    assert dtf.name == 'date_time'
    # _fact_ids is a set()
    assert isinstance(dtf._fact_ids, set) == True

# Generated at 2022-06-23 01:07:57.369531
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtf = DateTimeFactCollector()
    post_result = dtf.collect()
    assert 'date_time' in post_result
    for key in ['year', 'month', 'weekday', 'weekday_number', 'weeknumber', 'day', 'hour', 'minute',
                'second', 'epoch', 'epoch_int', 'date', 'time', 'iso8601_micro',
                'iso8601', 'iso8601_basic', 'iso8601_basic_short', 'tz', 'tz_dst', 'tz_offset']:
        assert key in post_result['date_time']


# Generated at 2022-06-23 01:07:59.739484
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'
    assert x._fact_ids == set()


# Generated at 2022-06-23 01:08:07.502408
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    """
    We are going to create a dictionary of facts called result
    that should match the expected result
    """
    # Creation of collector
    dt = DateTimeFactCollector()
    result = dt.collect()
    # Assertions for keys that should exist
    assert 'date_time' in result
    assert 'epoch' in result['date_time']
    assert 'iso8601' in result['date_time']
    # Assertions for the types of results
    assert isinstance(result['date_time']['epoch'], str)
    assert isinstance(result['date_time']['iso8601'], str)


# Generated at 2022-06-23 01:08:09.461381
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_facts = DateTimeFactCollector()
    assert date_time_facts is not None

# Generated at 2022-06-23 01:08:11.698505
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    """
    Unit test for class DateTimeFactCollector
    """
    DateTimeFactCollector()

# Generated at 2022-06-23 01:08:14.578683
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert isinstance(dtfc, DateTimeFactCollector)
    assert dtfc.name == 'date_time'

# Generated at 2022-06-23 01:08:17.160780
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    facts = DateTimeFactCollector()
    assert DateTimeFactCollector
    assert isinstance(facts, DateTimeFactCollector)

# Generated at 2022-06-23 01:08:27.037792
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Create the DateTimeFactCollector object
    date_time_facts_instance = DateTimeFactCollector()

    # Test the method collect and its returned dictionary
    # The 'date_time' key should be a dictionary with all the date/time facts
    date_time_facts = date_time_facts_instance.collect()
    assert isinstance(date_time_facts['date_time'], dict)
    assert len(date_time_facts['date_time']) == 17

    # Test that all the date/time facts are there.
    # We should have the keys 'year', 'month', 'weekday', 'weekday_number',
    # 'weeknumber', 'day', 'hour', 'minute', 'second', 'epoch', 'epoch_int',
    # 'date', 'time', 'iso8601_micro', 'iso86