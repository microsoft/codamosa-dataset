

# Generated at 2022-06-23 00:58:24.357043
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # Initialize the collector
    sut = DateTimeFactCollector()

    # Collect date_time facts
    facts = sut.collect()

    # Assert date_time facts present
    assert 'date_time' in facts
    assert 'year' in facts['date_time']
    assert 'month' in facts['date_time']
    assert 'weekday' in facts['date_time']
    assert 'weekday_number' in facts['date_time']
    assert 'weeknumber' in facts['date_time']
    assert 'day' in facts['date_time']
    assert 'hour' in facts['date_time']
    assert 'minute' in facts['date_time']
    assert 'second' in facts['date_time']
    assert 'epoch' in facts['date_time']
    assert 'epoch_int'

# Generated at 2022-06-23 00:58:26.931894
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dateTime = DateTimeFactCollector()
    assert not dateTime._fact_ids
    assert dateTime.name == 'date_time'

# Generated at 2022-06-23 00:58:33.901137
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    module = AnsibleModuleMock()
    collected_facts = {}
    date_time_fact_collector = DateTimeFactCollector()
    result = date_time_fact_collector.collect(module, collected_facts)

    assert 'date_time' in result
    assert 'iso8601_micro' in result['date_time']
    assert result['date_time']['iso8601_micro'] != ''


# Generated at 2022-06-23 00:58:35.997036
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_facts_collector = DateTimeFactCollector()
    date_time_facts_collector.collect()



# Generated at 2022-06-23 00:58:38.950926
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'
    assert date_time_fact_collector._fact_ids == set()


# Generated at 2022-06-23 00:58:41.168090
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'


# Generated at 2022-06-23 00:58:43.649070
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector.name == 'date_time'



# Generated at 2022-06-23 00:58:54.018336
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    result = date_time_fact_collector.collect()


# Generated at 2022-06-23 00:59:05.022023
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()


# Generated at 2022-06-23 00:59:07.745877
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    '''testing the DateTimeFactCollector constructor'''
    fact_collector = DateTimeFactCollector()
    assert fact_collector is not None
    assert fact_collector.name == 'date_time'

# Generated at 2022-06-23 00:59:10.724998
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.collect().get('date_time') is not None

# Generated at 2022-06-23 00:59:16.614617
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'
    assert x._fact_ids == set(['date_time'])
    assert x._fact_class == 'system'
    assert x.collect()['date_time']['year'] == datetime.datetime.now().strftime('%Y')
    assert x.collect()['date_time']['month'] == datetime.datetime.now().strftime('%m')

# Generated at 2022-06-23 00:59:24.298306
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-23 00:59:28.920984
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    f = DateTimeFactCollector()
    assert f.name == 'date_time'
    assert f._fact_ids == set()

# Generated at 2022-06-23 00:59:39.766520
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = DateTimeFactCollector()
    date_time_facts = dt.collect()['date_time']
    assert date_time_facts['time']
    assert date_time_facts['hour']
    assert date_time_facts['tz_dst']
    assert date_time_facts['date']
    assert date_time_facts['weekday']
    assert date_time_facts['month']
    assert date_time_facts['tz_offset']
    assert date_time_facts['weeknumber']
    assert date_time_facts['epoch']
    assert date_time_facts['epoch_int']
    assert date_time_facts['year']
    assert date_time_facts['day']
    assert date_time_facts['weekday_number']
    assert date_time_facts['tz']

# Generated at 2022-06-23 00:59:41.497443
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt_fact_collector = DateTimeFactCollector()
    dt_fact_collector.collect()

# Generated at 2022-06-23 00:59:56.326104
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector.collect()
    assert 'date_time' in date_time_facts
    assert 'year' in date_time_facts['date_time']
    assert 'month' in date_time_facts['date_time']
    assert 'weekday' in date_time_facts['date_time']
    assert 'weekday_number' in date_time_facts['date_time']
    assert 'weeknumber' in date_time_facts['date_time']
    assert 'day' in date_time_facts['date_time']
    assert 'hour' in date_time_facts['date_time']
    assert 'minute' in date_time_facts['date_time']
    assert 'second' in date_

# Generated at 2022-06-23 01:00:01.620569
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    from ansible.module_utils.facts.collector import Collector, get_collector_instance
    x = get_collector_instance(DateTimeFactCollector)
    assert isinstance(x, DateTimeFactCollector)
    assert isinstance(x, Collector)
    assert DateTimeFactCollector.name == 'date_time'

# Generated at 2022-06-23 01:00:03.549635
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact = DateTimeFactCollector()
    assert date_time_fact.name == 'date_time'

# Generated at 2022-06-23 01:00:04.997109
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    DateTimeFactCollector.collect()

# Generated at 2022-06-23 01:00:16.015048
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_facts = DateTimeFactCollector()
    date_time_facts_dict = date_time_facts.collect()
    assert date_time_facts_dict is not None
    assert 'date_time' in date_time_facts_dict
    assert 'year' in date_time_facts_dict['date_time']
    assert 'month' in date_time_facts_dict['date_time']
    assert 'weekday' in date_time_facts_dict['date_time']
    assert 'weekday_number' in date_time_facts_dict['date_time']
    assert 'weeknumber' in date_time_facts_dict['date_time']
    assert 'day' in date_time_facts_dict['date_time']
    assert 'hour' in date_time_facts_dict['date_time']


# Generated at 2022-06-23 01:00:18.558144
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector.collect()

# Generated at 2022-06-23 01:00:29.059045
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collector = DateTimeFactCollector()
    facts = collector.collect()
    assert 'date_time' in facts
    assert 'year' in facts['date_time']
    assert 'month' in facts['date_time']
    assert 'weekday' in facts['date_time']
    assert 'weekday_number' in facts['date_time']
    assert 'weeknumber' in facts['date_time']
    assert 'day' in facts['date_time']
    assert 'hour' in facts['date_time']
    assert 'minute' in facts['date_time']
    assert 'second' in facts['date_time']
    assert 'epoch' in facts['date_time']
    assert 'epoch_int' in facts['date_time']
    assert 'date' in facts['date_time']

# Generated at 2022-06-23 01:00:40.396208
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # arrange
    mock_module = object()
    mock_collected_facts = object()
    date_time_fact_collector = DateTimeFactCollector()


# Generated at 2022-06-23 01:00:47.847969
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    """Test DateTimeFactCollector."""

    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector

    collector_class_name = 'DateTimeFactCollector'
    DataTimeFactCollector = get_collector_instance(collector_class_name)

    assert isinstance(DataTimeFactCollector, BaseFactCollector)
    assert DataTimeFactCollector.name == 'date_time'


# Generated at 2022-06-23 01:00:58.883614
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Tests class DateTimeFactCollector method collect
    """

    dtfc = DateTimeFactCollector()

    # Retrieve date_time facts
    date_time_facts = dtfc.collect()
    year = date_time_facts['date_time']['year']
    month = date_time_facts['date_time']['month']
    weekday = date_time_facts['date_time']['weekday']
    weekday_number = date_time_facts['date_time']['weekday_number']
    weeknumber = date_time_facts['date_time']['weeknumber']
    day = date_time_facts['date_time']['day']
    hour = date_time_facts['date_time']['hour']

# Generated at 2022-06-23 01:01:02.082187
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fc = DateTimeFactCollector()
    date_time_fc.collect()

# Generated at 2022-06-23 01:01:10.832315
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector(None)
    epoch_ts = time.time()
    now = datetime.datetime.fromtimestamp(epoch_ts)
    utcnow = datetime.datetime.utcfromtimestamp(epoch_ts)

    # Collect if data exists
    facts = date_time_fact_collector.collect()
    assert 'date_time' in facts
    data_time_data = facts['date_time']
    assert 'year' in data_time_data
    assert 'month' in data_time_data
    assert 'weekday' in data_time_data
    assert 'weekday_number' in data_time_data
    assert 'weeknumber' in data_time_data
    assert 'day' in data_time_data
    assert 'hour'

# Generated at 2022-06-23 01:01:13.611799
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():

    test_date_time_fact_collector = DateTimeFactCollector()

    assert test_date_time_fact_collector.name == 'date_time'

# Generated at 2022-06-23 01:01:25.935299
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collectors.date_time import DateTimeFactCollector
    # Creating a object of the DateTimeFactCollector collect method
    test_obj = DateTimeFactCollector()
    # Creating a dict of date_time facts

# Generated at 2022-06-23 01:01:27.437349
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    facts = DateTimeFactCollector()
    assert facts.name == 'date_time'

# Generated at 2022-06-23 01:01:38.909937
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert not dtfc._fact_ids
    epoch_ts = time.time()
    now = datetime.datetime.fromtimestamp(epoch_ts)
    utcnow = datetime.datetime.utcfromtimestamp(epoch_ts)
    dtfc_fact = dtfc.collect()
    year = now.strftime('%Y')
    month = now.strftime('%m')
    weekday = now.strftime('%A')
    weekday_number = now.strftime('%w')
    weeknumber = now.strftime('%W')
    day = now.strftime('%d')
    hour = now.strftime('%H')
    minute = now.strftime('%M')
    second = now.strftime('%S')

# Generated at 2022-06-23 01:01:41.103595
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    datetime_fact_collector = DateTimeFactCollector()
    assert datetime_fact_collector.name == "date_time"

# Generated at 2022-06-23 01:01:43.559856
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    DateTimeFactCollector().collect()

# Generated at 2022-06-23 01:01:47.000819
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert not date_time_fact_collector.get_fact_ids()
    assert date_time_fact_collector.name == 'date_time'


# Generated at 2022-06-23 01:01:48.009987
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    DateTimeFactCollector().collect()

# Generated at 2022-06-23 01:01:50.305153
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj.name == 'date_time'
    assert obj._fact_ids == set()


# Generated at 2022-06-23 01:01:53.372119
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'


# Generated at 2022-06-23 01:01:56.574025
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    """Unit test class constructor of DateTimeFactCollector"""
    date_time_collector = DateTimeFactCollector()
    assert date_time_collector.name == 'date_time'

# Generated at 2022-06-23 01:01:58.934317
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    fact_collector = DateTimeFactCollector()
    assert fact_collector.name == 'date_time'


# Generated at 2022-06-23 01:01:59.633526
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    pass

# Generated at 2022-06-23 01:02:02.529528
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Check the class(static) variable value.
    assert DateTimeFactCollector.name == 'date_time'
    assert DateTimeFactCollector._fact_ids == set()


# Generated at 2022-06-23 01:02:13.529006
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    datetime_collector = DateTimeFactCollector()
    ansible_facts = datetime_collector.collect()
    assert ansible_facts['date_time']['year'] == datetime.datetime.now().strftime('%Y')
    assert ansible_facts['date_time']['month'] == datetime.datetime.now().strftime('%m')
    assert ansible_facts['date_time']['weekday'] == datetime.datetime.now().strftime('%A')
    assert ansible_facts['date_time']['weekday_number'] == datetime.datetime.now().strftime('%w')
    assert ansible_facts['date_time']['weeknumber'] == datetime.datetime.now().strftime('%W')

# Generated at 2022-06-23 01:02:18.318305
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    datetimefactcollector = DateTimeFactCollector()
    assert datetimefactcollector.name == 'date_time'
    assert datetimefactcollector._fact_ids == set()

# Generated at 2022-06-23 01:02:21.279362
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    DateTimeFactCollector_obj = DateTimeFactCollector()
    test_output = DateTimeFactCollector_obj.collect()
    assert len(test_output) == 1

# Generated at 2022-06-23 01:02:25.291993
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    fact_collector_obj=DateTimeFactCollector()
    assert fact_collector_obj.name == 'date_time'
    assert fact_collector_obj._fact_ids == set()
    assert fact_collector_obj.is_active()


# Generated at 2022-06-23 01:02:36.908654
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.date_time import DateTimeFactCollector
    from ansible.module_utils.facts.utils import FactsGetter
    from ansible.module_utils.facts import gather_subset
    from ansible.module_utils.facts.facts import FactCache
    fact_cache = FactCache()
    fact_cache.load_cache(None, CACHE_DESTINATION)

    # Collect facts of all collectors
    DateTimeFactCollector.__code__ = None
    DateTimeFactCollector._fact_ids = set()
    DateTimeFactCollector.__module__ = 'ansible.module_utils.facts.collector.date_time'

# Generated at 2022-06-23 01:02:38.340601
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    a = DateTimeFactCollector()
    assert a.name == 'date_time'

# Generated at 2022-06-23 01:02:40.115868
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact = DateTimeFactCollector()
    assert date_time_fact.name == 'date_time'

# Generated at 2022-06-23 01:02:44.816974
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # The return of DateTimeFactCollector.collect should
    # be a dictionary and should contain a key 'date_time'
    import ansible.module_utils.facts.collectors.date_time as date_time
    c = date_time.DateTimeFactCollector()
    assert isinstance(c.collect(), dict)
    assert 'date_time' in c.collect()

# Generated at 2022-06-23 01:02:53.705335
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    test_date_time_collector = DateTimeFactCollector()

    result = test_date_time_collector.collect()
    date_time_facts = result['date_time']
    assert date_time_facts['year'] == datetime.datetime.now().strftime('%Y')
    assert date_time_facts['month'] == datetime.datetime.now().strftime('%m')
    assert date_time_facts['weekday'] == datetime.datetime.now().strftime('%A')
    assert date_time_facts['weekday_number'] == datetime.datetime.now().strftime('%w')
    assert date_time_facts['weeknumber'] == datetime.datetime.now().strftime('%W')
    assert date_time_facts['day'] == datetime.datetime.now

# Generated at 2022-06-23 01:03:03.711869
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dateTimeFactCollector = DateTimeFactCollector()
    collected_facts = dateTimeFactCollector.collect()
    assert collected_facts['date_time']['year']
    assert collected_facts['date_time']['month']
    assert collected_facts['date_time']['weekday']
    assert collected_facts['date_time']['weekday_number']
    assert collected_facts['date_time']['weeknumber']
    assert collected_facts['date_time']['day']
    assert collected_facts['date_time']['hour']
    assert collected_facts['date_time']['minute']
    assert collected_facts['date_time']['second']

# Generated at 2022-06-23 01:03:09.176240
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt_facts = DateTimeFactCollector()
    facts = dt_facts.collect()
    assert(dt_facts.name in facts)
    assert(facts['date_time']['epoch'])
    assert(facts['date_time']['epoch_int'])
    assert(facts['date_time']['iso8601_micro'])

# Generated at 2022-06-23 01:03:17.955929
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Collect facts for current system
    facts = DateTimeFactCollector().collect()
    # Ensure date_time is present in fact key
    assert 'date_time' in facts.keys()
    # Ensure date_time facts is a dictionary and is not empty
    assert isinstance(facts['date_time'], dict)
    assert facts['date_time'] != {}
    # Check existence of some key
    assert 'day' in facts['date_time']

# Generated at 2022-06-23 01:03:20.844969
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
  dt = DateTimeFactCollector()
  assert dt.name == 'date_time'
  assert dt._fact_ids == set()

# Generated at 2022-06-23 01:03:32.320054
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.collector import collector_singleton
    from ansible.module_utils.facts.collector.system import SystemCollector

    collector_singleton.clear_fact_cache()

    # Add system collectors to the singleton
    collector_singleton.add_collector(SystemCollector)

    # Create a new DateTimeFactCollector object
    date_time = DateTimeFactCollector()

    # Call _collect_date_time() method
    result = date_time.collect()


# Generated at 2022-06-23 01:03:33.368932
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()

# Generated at 2022-06-23 01:03:45.735005
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    '''
    inspect the epoch, year, month, weekday, weekday_number, weeknumber, day, hour, minute, second, time,
    and tz_offset values of DateTimeFactCollector
    '''
    # given
    dtf = DateTimeFactCollector()
    # when
    datetime_facts = dtf.collect()
    # then
    assert datetime_facts['date_time']['epoch_int']
    assert datetime_facts['date_time']['year']
    assert datetime_facts['date_time']['month']
    assert datetime_facts['date_time']['weekday']
    assert datetime_facts['date_time']['weekday_number']
    assert datetime_facts['date_time']['weeknumber']

# Generated at 2022-06-23 01:03:48.795259
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    datetime_collector = DateTimeFactCollector()
    assert datetime_collector.name == 'date_time'
    assert isinstance(datetime_collector._fact_ids, set)

# Generated at 2022-06-23 01:03:50.919921
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date = DateTimeFactCollector()
    assert(date.name == 'date_time')

# Generated at 2022-06-23 01:03:53.158298
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    test_instance = DateTimeFactCollector()
    assert test_instance.name == 'date_time'

# Generated at 2022-06-23 01:04:04.017010
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = DateTimeFactCollector()
    collected = dt.collect()
    assert isinstance(collected, dict)
    assert 'date_time' in collected

    date_time = collected['date_time']

    assert isinstance(date_time, dict)
    assert 'year' in date_time
    assert 'month' in date_time
    assert 'weekday' in date_time
    assert 'weekday_number' in date_time
    assert 'weeknumber' in date_time
    assert 'day' in date_time
    assert 'hour' in date_time
    assert 'minute' in date_time
    assert 'second' in date_time
    assert 'epoch' in date_time
    assert 'epoch_int' in date_time
    assert 'date' in date_time
    assert 'time'

# Generated at 2022-06-23 01:04:08.903442
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert issubclass(DateTimeFactCollector, BaseFactCollector)
    assert DateTimeFactCollector.name == 'date_time'
    assert DateTimeFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:04:18.837686
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    dtime = DateTimeFactCollector()

# Generated at 2022-06-23 01:04:21.282564
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collect = DateTimeFactCollector()
    assert collect.name == 'date_time'
    assert collect._fact_ids == set()


# Generated at 2022-06-23 01:04:30.641641
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Tests the collect method of DateTimeFactCollector
    """

# Generated at 2022-06-23 01:04:35.875261
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Test that DateTimeFactCollector class exists and its method collect will return a dict"""
    dt = DateTimeFactCollector()
    assert isinstance(dt, DateTimeFactCollector)
    assert isinstance(dt._fact_ids, set)
    assert isinstance(dt.name, str)
    assert isinstance(dt.collect(), dict)

# Generated at 2022-06-23 01:04:40.320528
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    """
    Tests for the DateTimeFactCollector constructor
    """
    c = DateTimeFactCollector()
    assert c.name == 'date_time'
    assert c._fact_ids == set()

# Generated at 2022-06-23 01:04:52.749418
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    now = datetime.datetime.now()
    epoch_ts = time.time()
    utcnow = datetime.datetime.utcfromtimestamp(epoch_ts)

# Generated at 2022-06-23 01:05:04.475274
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # This import statement should be first in the file
    from ansible.module_utils.facts import FactCollector

    # Make an instance of the class DateTimeFactCollector
    date_time_fact_collector = DateTimeFactCollector()

    # Get the value of the instance's attribute _fact_ids
    date_time_fact_ids = date_time_fact_collector._fact_ids

    # These are the facts being collected
    facts_dict = {}
    date_time_facts = {}

    # Store the timestamp once, then get local and UTC versions from that
    epoch_ts = time.time()
    now = datetime.datetime.fromtimestamp(epoch_ts)
    utcnow = datetime.datetime.utcfromtimestamp(epoch_ts)

    date_time_facts['year'] = now

# Generated at 2022-06-23 01:05:06.964474
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    t_fact = DateTimeFactCollector()
    result = t_fact.name
    assert result == 'date_time'

# Generated at 2022-06-23 01:05:22.045564
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Tests the collect method of DateTimeFactCollector.
    """
    mod = AnsibleModuleMock()
    coll = DateTimeFactCollector(module=mod)

# Generated at 2022-06-23 01:05:30.914912
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.collector import TestModule
    from ansible.module_utils.facts.collector.date_time import DateTimeFactCollector
    from ansible.module_utils.facts.collector.date_time import test_appliance_DateTimeFactCollector_collect

    dtfc = DateTimeFactCollector()
    assert dtfc.collect(module=None, collected_facts=None) == test_appliance_DateTimeFactCollector_collect()
    assert dtfc.name == 'date_time'

    with pytest.raises(Exception) as excinfo:
        dtfc.collect(module=TestModule(), collected_facts=None)

# Generated at 2022-06-23 01:05:33.353654
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    facts = fact_collector.collect()
    assert len(facts['date_time'])

# Generated at 2022-06-23 01:05:34.560056
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()


# Generated at 2022-06-23 01:05:35.728634
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert isinstance(DateTimeFactCollector(), DateTimeFactCollector)

# Generated at 2022-06-23 01:05:38.152529
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_facter = DateTimeFactCollector()
    assert date_time_facter.name == 'date_time'

# Generated at 2022-06-23 01:05:39.924261
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # This function is called from Unit tests file test_controller.py
    return None

# Generated at 2022-06-23 01:05:50.755089
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    dtfc._module = MockModule()
    dtfc._collected_facts = {}
    dtfc.collect()
    assert 'date_time' in dtfc._collected_facts
    assert 'month' in dtfc._collected_facts['date_time']
    assert 'day' in dtfc._collected_facts['date_time']
    assert 'year' in dtfc._collected_facts['date_time']
    assert 'hour' in dtfc._collected_facts['date_time']
    assert 'minute' in dtfc._collected_facts['date_time']
    assert 'second' in dtfc._collected_facts['date_time']

# Generated at 2022-06-23 01:05:56.188856
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collector = DateTimeFactCollector()
    date_time_facts = collector.collect()
    assert date_time_facts['date_time']['hour'] == time.strftime("%H")
    assert date_time_facts['date_time']['tz_offset'] == time.strftime("%z")
    assert date_time_facts['date_time']['date'] == time.strftime("%Y-%m-%d")

# Generated at 2022-06-23 01:06:00.191245
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtcol = DateTimeFactCollector()

    assert 'date_time' in dtcol.collect().keys(), 'date_time fact could not be found in facts'
    assert len(dtcol._fact_ids) == 0, 'date_time collector will not store any fact ids'

# Generated at 2022-06-23 01:06:03.686307
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collector = DateTimeFactCollector()
    datetime_dict = collector.collect()

    assert 'date_time' in datetime_dict


# Generated at 2022-06-23 01:06:04.758716
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()

# Generated at 2022-06-23 01:06:06.936405
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collector = DateTimeFactCollector()
    facts = collector.collect()
    assert len(facts['date_time']) != 0

# Generated at 2022-06-23 01:06:16.956108
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    collected_facts = dtfc.collect()
    assert 'date_time' in collected_facts
    assert 'epoch' in collected_facts['date_time']
    assert 'epoch_int' in collected_facts['date_time']
    assert 'iso8601' in collected_facts['date_time']
    assert 'iso8601_basic' in collected_facts['date_time']
    assert 'iso8601_basic_short' in collected_facts['date_time']
    assert 'iso8601_micro' in collected_facts['date_time']
    assert 'time' in collected_facts['date_time']
    assert 'tz' in collected_facts['date_time']
    assert 'tz_dst' in collected_facts['date_time']

# Generated at 2022-06-23 01:06:18.247717
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    set(DateTimeFactCollector._fact_ids) == set()

# Generated at 2022-06-23 01:06:21.567043
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    test_collector = DateTimeFactCollector()
    assert test_collector.name == 'date_time'
    assert not test_collector.is_file_collector
    assert not test_collector.is_subset_collector


# Generated at 2022-06-23 01:06:25.703801
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtFC = DateTimeFactCollector()
    assert dtFC.name == 'date_time'
    assert not dtFC._fact_ids


# Generated at 2022-06-23 01:06:37.749226
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dateTimeFactCollector = DateTimeFactCollector()
    dateTimeFactCollector.collect()
    data = dateTimeFactCollector.get_facts()
    # We have no way to test the epoch value
    data['date_time']['epoch'] = '12454545'
    data['date_time']['epoch_int'] = '12454545'

# Generated at 2022-06-23 01:06:46.788481
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_collector = DateTimeFactCollector()
    actual_date_time_facts = date_time_collector.collect()['date_time']
    assert isinstance(actual_date_time_facts, dict), "Expected data type for 'date_time_facts' is 'dict'"


# Generated at 2022-06-23 01:06:49.234985
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'

# Generated at 2022-06-23 01:06:52.406760
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
   fact_collector = DateTimeFactCollector()
   assert fact_collector.name == 'date_time'



# Generated at 2022-06-23 01:06:54.824813
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()
    assert collector.name == 'date_time'
    assert collector._fact_ids == set()


# Generated at 2022-06-23 01:06:57.023587
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_facts = DateTimeFactCollector().collect()
    assert date_time_facts is not None
    assert len(date_time_facts) == 1


# Generated at 2022-06-23 01:07:00.539672
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    collected_data = {}
    collected_data['date_time'] = date_time_fact_collector.collect()
    assert len(collected_data) > 0
    assert len(collected_data['date_time']) > 0

# Generated at 2022-06-23 01:07:10.678545
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_collector = DateTimeFactCollector()
    date_time_facts = date_time_collector.collect()
    assert len(date_time_facts) == 1
    for fact_name in ['year', 'month', 'day', 'date',
                      'weekday', 'weekday_number', 'weeknumber',
                      'hour', 'minute', 'second', 'time',
                      'epoch', 'epoch_int',
                      'tz', 'tz_dst', 'tz_offset',
                      'iso8601', 'iso8601_basic', 'iso8601_basic_short', 'iso8601_micro']:
        assert fact_name in date_time_facts['date_time']

# Generated at 2022-06-23 01:07:12.851533
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    instance = DateTimeFactCollector()
    assert instance.name == 'date_time'

# Generated at 2022-06-23 01:07:23.548141
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    assert isinstance(dtfc,DateTimeFactCollector)
    assert dtfc.collect()['date_time']['year'] != ''
    assert dtfc.collect()['date_time']['month'] != ''
    assert dtfc.collect()['date_time']['weekday'] != ''
    assert dtfc.collect()['date_time']['weekday_number'] != ''
    assert dtfc.collect()['date_time']['weeknumber'] != ''
    assert dtfc.collect()['date_time']['day'] != ''
    assert dtfc.collect()['date_time']['hour'] != ''
    assert dtfc.collect()['date_time']['minute'] != ''
    assert dtfc.collect

# Generated at 2022-06-23 01:07:24.742342
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
  d = DateTimeFactCollector()
  f = d.collect()


# Generated at 2022-06-23 01:07:30.806044
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    '''Unit test method collect of class DateTimeFactCollector'''
    date_time_facts = DateTimeFactCollector()
    assert all(key in date_time_facts.collect()['date_time']
                for key in ['year', 'month', 'weekday', 'weekday_number',
                            'weeknumber', 'day', 'hour', 'minute', 'second',
                            'epoch', 'epoch_int', 'date', 'time',
                            'iso8601_micro', 'iso8601', 'iso8601_basic',
                            'iso8601_basic_short', 'tz', 'tz_dst', 'tz_offset'])


# Generated at 2022-06-23 01:07:35.455857
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():

    # Test with valid name for DateTimeFactCollector class
    x = DateTimeFactCollector('date_time')
    assert x.name == 'date_time'
    assert x._fact_ids == set()

    # Test with invalid name for DateTimeFactCollector class
    y = DateTimeFactCollector(None)
    assert y.name is None
    assert y._fact_ids == set()


# Generated at 2022-06-23 01:07:46.908914
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    facts = dtfc.collect()
    assert(isinstance(facts, dict))
    assert(facts['date_time'])
    assert(facts['date_time']['year'])
    assert(facts['date_time']['month'])
    assert(facts['date_time']['weekday'])
    assert(facts['date_time']['weekday_number'])
    assert(facts['date_time']['weeknumber'])
    assert(facts['date_time']['day'])
    assert(facts['date_time']['hour'])
    assert(facts['date_time']['minute'])
    assert(facts['date_time']['second'])
    assert(facts['date_time']['epoch'])

# Generated at 2022-06-23 01:07:54.132748
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Test for constructor of class DateTimeFactCollector
    assert DateTimeFactCollector.name == 'date_time'
    # Test for method collect
    facts_dict = DateTimeFactCollector().collect()
    assert facts_dict['date_time']['epoch'] is not ''
    assert facts_dict['date_time']['epoch_int'] is not ''
    assert facts_dict['date_time']['date'] is not ''
    assert facts_dict['date_time']['time'] is not ''

# Generated at 2022-06-23 01:08:05.561121
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    print("Testing creation of DateTimeFactCollector instance")
    myDatetimeFactCollector = DateTimeFactCollector()
    assert myDatetimeFactCollector.name == 'date_time', "DateTimeFactCollector.name should equal 'date_time', but equals " + myDatetimeFactCollector.name
    assert type(myDatetimeFactCollector._fact_ids) == set, "DateTimeFactCollector._fact_ids should be a set, but is a " + str(type(myDatetimeFactCollector._fact_ids))
    assert len(myDatetimeFactCollector._fact_ids) == 0, "DateTimeFactCollector._fact_ids should be an empty set, but the length is " + str(len(myDatetimeFactCollector._fact_ids))
    print("Successfully instantiated DateTimeFactCollector")

#

# Generated at 2022-06-23 01:08:08.554005
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector.name == 'date_time'
    assert hasattr(DateTimeFactCollector,'collect')
    assert hasattr(DateTimeFactCollector,'_fact_ids')

# Generated at 2022-06-23 01:08:20.238339
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    my_datetime = DateTimeFactCollector()
    date_time_facts = my_datetime.collect()
    print("date_time_facts = %s" % date_time_facts)
    assert 'date_time' in date_time_facts
    my_date_time = date_time_facts['date_time']
    assert 'epoch' in my_date_time
    assert len(my_date_time['epoch']) > 0
    assert my_date_time['epoch'].isdigit()
    assert 'epoch_int' in my_date_time
    assert len(my_date_time['epoch_int']) > 0
    assert my_date_time['epoch_int'].isdigit()
    assert 'date' in my_date_time
    assert 'time' in my