

# Generated at 2022-06-23 00:58:23.214633
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    c = DateTimeFactCollector()
    assert c._fact_ids == {'date_time'}, \
        "Fail: DateTimeFactCollector() fails to create an empty fact_ids."

# Generated at 2022-06-23 00:58:35.092642
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fc = DateTimeFactCollector()
    facts_dict = date_time_fc.collect()

    assert 'date_time' in facts_dict
    assert 'epoch' in facts_dict['date_time']
    assert 'epoch_int' in facts_dict['date_time']
    assert 'date' in facts_dict['date_time']
    assert 'time' in facts_dict['date_time']
    assert 'iso8601_micro' in facts_dict['date_time']
    assert 'iso8601' in facts_dict['date_time']
    assert 'iso8601_basic' in facts_dict['date_time']
    assert 'iso8601_basic_short' in facts_dict['date_time']
    assert 'tz' in facts_dict['date_time']

# Generated at 2022-06-23 00:58:48.289282
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import platform
    import pytest
    from ansible.utils.pytest import AnsibleExitJson, AnsibleFailJson, ModuleTestCase

    import ansible.module_utils.facts.system.date_time as dtf

    # When collect is called, the gathered facts should be returned
    provider_mock = ModuleTestCase.get_module_mock(platform, spec=['python_version'])
    provider_mock.python_version = (2, 7)
    dtfObj = dtf.DateTimeFactCollector(provider_mock)
    facts = dtfObj.collect()
    assert isinstance(dtfObj.populate_facts(facts), dict)

    # When python_version is not 2.7+, an exception should raised

# Generated at 2022-06-23 00:59:00.591380
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dc = DateTimeFactCollector()
    result = dc.collect()
    assert 'date_time' in result
    assert 'year' in result['date_time']
    assert 'month' in result['date_time']
    assert 'weekday' in result['date_time']
    assert 'weekday_number' in result['date_time']
    assert 'weeknumber' in result['date_time']
    assert 'day' in result['date_time']
    assert 'hour' in result['date_time']
    assert 'minute' in result['date_time']
    assert 'second' in result['date_time']
    assert 'epoch' in result['date_time']
    assert 'epoch_int' in result['date_time']
    assert 'date' in result['date_time']

# Generated at 2022-06-23 00:59:01.330505
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    fixture = DateTimeFactCollector()
    assert fixture

# Generated at 2022-06-23 00:59:04.749873
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    module = None
    collected_facts = None
    test = DateTimeFactCollector()
    assert test
    assert test.name == 'date_time'
    assert test.collect(module, collected_facts)



# Generated at 2022-06-23 00:59:07.120544
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'
    assert isinstance(dtfc._fact_ids, set)

# Generated at 2022-06-23 00:59:17.784872
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # setup
    class MockTime(object):
        def time(self):
            return 1234567890.123456
        def strftime(self, value):
            if value == "%Y":
                return "2009"
            elif value == "%m":
                return "02"
            elif value == "%A":
                return "Monday"
            elif value == "%w":
                return "1"
            elif value == "%W":
                return "06"
            elif value == "%d":
                return "23"
            elif value == "%H":
                return "11"
            elif value == "%M":
                return "55"
            elif value == "%S":
                return "00"
            elif value == "%s":
                return "1234567890"

# Generated at 2022-06-23 00:59:29.176554
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Call the method collect of class DateTimeFactCollector
    # We have to use __init__ function and then this function
    # to test a private function or a function which uses
    # self.
    collected_facts = DateTimeFactCollector().collect()
    # Check that the collect function returns a dict
    assert type(collected_facts) is dict

    # Check that all the keys and values of the dict are
    # correct. The only possible problem could be if we
    # are not able to convert a particular value to string
    # which I am almost sure will not happen in
    # any known case.
    #
    # Also the value of now might change in the very first
    # second of the execution of this function. Because
    # of this the unit test will fail. To avoid this
    # we need to give a time to the unit test to

# Generated at 2022-06-23 00:59:40.015372
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    '''Test module for DateTimeFactCollector.collect'''

    dtf = DateTimeFactCollector()

    # Small hack to test only the method collect
    if dtf.name == 'date_time':
        res = dtf.collect()
        assert 'date_time' in res, res
        assert 'year' in res['date_time'], res['date_time']
        assert 'weeknumber' in res['date_time'], res['date_time']
        assert 'epoch_int' in res['date_time'], res['date_time']
        assert 'iso8601_basic_short' in res['date_time'], res['date_time']
        assert 'tz_offset' in res['date_time'], res['date_time']


# Generated at 2022-06-23 00:59:42.614330
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # DateTimeFactCollector object creation test
    date_time_fact_collector_obj = DateTimeFactCollector()
    assert date_time_fact_collector_obj

# Generated at 2022-06-23 00:59:50.722201
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts.collectors import collector_module
    import json
    test_dt = DateTimeFactCollector()
    assert 'date_time' in test_dt.collect()
    test_dt = collector_module.get_collector('date_time')
    # TODO: assert isinstance(test_dt, DateTimeFactCollector)
    assert 'date_time' in test_dt.collect()
    # TODO: test for facts that are platform specific
    # TODO: test for facts that are GNU/Linux specific
    # TODO: test for facts that are platform+distro specific
    # TODO: test for facts that are FreeBSD specific
    # TODO: test for facts that are SmartOS specific
    # TODO: test for facts that are SunOS specific

# Generated at 2022-06-23 00:59:56.596578
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    collected_facts = fact_collector.collect()
    assert isinstance(collected_facts['date_time'], dict)
    assert collected_facts['date_time']['year']
    assert collected_facts['date_time']['weekday_number']



# Generated at 2022-06-23 00:59:58.251919
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    F = DateTimeFactCollector()
    assert F.name == 'date_time'

# Generated at 2022-06-23 01:00:10.352377
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-23 01:00:18.986483
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseFileFactsCollector
    from ansible.module_utils.facts.collection import collect_all
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts
    import ansible.module_utils

    # Check the type of "ansible.module_utils.facts.collector"


# Generated at 2022-06-23 01:00:21.704112
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtf = DateTimeFactCollector()
    assert(dtf.name == 'date_time')
    assert(dtf._fact_ids == set())


# Generated at 2022-06-23 01:00:34.098332
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    """Test instantiating DateTimeFactCollector class object."""
    date_time_collector = DateTimeFactCollector()
    assert date_time_collector.name == 'date_time'

# Generated at 2022-06-23 01:00:39.704240
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Test DateTimeFactCollector.collect()
    # Instantiate DateTimeFactCollector class without module argument
    # Assert that returned value contains expected facts

    class AnsibleModule(object):
        def __init__(self, *a, **b):
            self.params = b
            self.fail_json = self.warn = lambda *a, **b: None

    collected_facts = {}
    dtf = DateTimeFactCollector(AnsibleModule(name='dummy', **{}))
    result = dtf.collect(collected_facts=collected_facts)
    assert 'date_time' in result.keys(), 'No date_time found in %s' % result.keys()
    assert 'year' in result['date_time'].keys(), 'No year found in %s' % result['date_time'].keys

# Generated at 2022-06-23 01:00:41.568949
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj.name == 'date_time'


# Generated at 2022-06-23 01:00:44.183993
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Unit test for method DateTimeFactCollector.collect
    """
    datetime_collector = DateTimeFactCollector()
    assert datetime_collector.collect()

# Generated at 2022-06-23 01:00:47.604152
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    # Ensure that the method fails if no DateTime is provided
    with pytest.raises(TypeError):
        dtfc.collect()

# Generated at 2022-06-23 01:00:58.806767
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Input parameters to unit test
    module_params = {}

    # Expected return value of the collect method for the given module parameters

# Generated at 2022-06-23 01:01:00.741373
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()
    assert collector.name == 'date_time'
    assert len(collector._fact_ids) == 0



# Generated at 2022-06-23 01:01:07.330981
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.date_time import DateTimeFactCollector
    date_time_fact_collector = DateTimeFactCollector()
    assert isinstance(date_time_fact_collector, BaseFactCollector)
    assert date_time_fact_collector.name == 'date_time'
    assert date_time_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:01:12.447208
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dateTimeFactCollector = DateTimeFactCollector()
    assert dateTimeFactCollector
    assert dateTimeFactCollector.name == 'date_time'
    assert isinstance(dateTimeFactCollector._fact_ids, set)
    assert isinstance(dateTimeFactCollector.collect(), dict)


# Generated at 2022-06-23 01:01:15.114897
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    coll = DateTimeFactCollector()
    assert coll.name == 'date_time'

# Generated at 2022-06-23 01:01:17.197003
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    d = DateTimeFactCollector()
    assert d.name == 'date_time'


# Generated at 2022-06-23 01:01:19.160865
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt_collector = DateTimeFactCollector()
    assert dt_collector.name == 'date_time'

# Generated at 2022-06-23 01:01:23.700936
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    """
    Unit test for DateTimeFactCollector constructor.
    """
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'
    assert dtfc._fact_ids == set()



# Generated at 2022-06-23 01:01:34.055240
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from datetime import datetime as testdatetime
    module = []
    collected_facts = []

    # Generate the output of the method to be tested
    collector = DateTimeFactCollector()
    result = collector.collect(module, collected_facts)
    facts = result['date_time']

    assert(facts['year'] == testdatetime.now().strftime('%Y'))
    assert(facts['month'] == testdatetime.now().strftime('%m'))
    assert(facts['weekday'] == testdatetime.now().strftime('%A'))
    assert(facts['weekday_number'] == testdatetime.now().strftime('%w'))
    assert(facts['weeknumber'] == testdatetime.now().strftime('%W'))

# Generated at 2022-06-23 01:01:42.528766
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import sys
    import pytest
    import ansible.module_utils.facts.collectors.date_time as datetimetest

    fake_module = type('module', (object,), {'exit_json': lambda x: x, 'fail_json': lambda x: x})
    # Runs the  collect method from DateTimeFactCollector
    # and store the result in a variable
    datetime_result = datetimetest.DateTimeFactCollector(fake_module).collect()

    # Tests the type of the returned value
    assert isinstance(datetime_result['date_time'], dict)
    # Tests if the size of the dictionary returned is 10
    assert len(datetime_result['date_time'].keys()) == 19
    # Tests if the strings returned are of the expected type

# Generated at 2022-06-23 01:01:47.479920
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    datetime_fact_collector = DateTimeFactCollector()
    assert datetime_fact_collector.name == 'date_time'
    assert type(datetime_fact_collector._fact_ids) == set

# Generated at 2022-06-23 01:01:57.543299
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    '''Unit test for method collect of class DateTimeFactCollector'''

    # Construct the object
    datetime_collector = DateTimeFactCollector()

    # Call method collect
    # Tests for method 'collect' of class 'DateTimeFactCollector'
    collected_facts = datetime_collector.collect()
    assert 'date_time' in collected_facts
    date_time_facts = collected_facts['date_time']
    assert 'year' in date_time_facts
    assert date_time_facts['year']
    assert 'month' in date_time_facts
    assert date_time_facts['month']
    assert 'weekday' in date_time_facts
    assert date_time_facts['weekday']
    assert 'weekday_number' in date_time_facts

# Generated at 2022-06-23 01:02:06.827763
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = DateTimeFactCollector()
    facts = dt.collect()
    assert len(facts['date_time']) > 0
    assert facts['date_time']['year'] == str(datetime.datetime.now().strftime('%Y'))
    assert facts['date_time']['month'] == str(datetime.datetime.now().strftime('%m'))
    assert facts['date_time']['weekday'] == str(datetime.datetime.now().strftime('%A'))
    assert facts['date_time']['weekday_number'] == str(datetime.datetime.now().strftime('%w'))
    assert facts['date_time']['weeknumber'] == str(datetime.datetime.now().strftime('%W'))

# Generated at 2022-06-23 01:02:17.737966
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    obj = DateTimeFactCollector()
    result = obj.collect()

# Generated at 2022-06-23 01:02:28.385139
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()

# Generated at 2022-06-23 01:02:30.628981
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt.name == 'date_time'
    assert dt._fact_ids == set()

# Generated at 2022-06-23 01:02:43.623581
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_collector = DateTimeFactCollector()
    collected_facts = date_time_collector.collect()

    assert 'date_time' in collected_facts
    collected_date_time = collected_facts['date_time']
    assert 'epoch' in collected_date_time
    assert 'epoch_int' in collected_date_time
    assert 'iso8601' in collected_date_time
    assert 'iso8601_basic' in collected_date_time
    assert 'iso8601_basic_short' in collected_date_time
    assert 'iso8601_micro' in collected_date_time
    assert 'second' in collected_date_time
    assert 'tz' in collected_date_time
    assert 'tz_dst' in collected_date_time
    assert 'tz_offset' in collected_

# Generated at 2022-06-23 01:02:46.573733
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt.name == 'date_time', 'Test DateTimeFactCollector constructor'
    assert dt._fact_ids == set(), 'Test DateTimeFactCollector constructor'



# Generated at 2022-06-23 01:02:47.518383
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    DateTimeFactCollector.collect()

# Generated at 2022-06-23 01:02:52.093426
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt.name == 'date_time'
    assert dt._fact_ids == set()


# Generated at 2022-06-23 01:02:55.662301
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'
    assert not date_time_fact_collector._fact_ids

# Generated at 2022-06-23 01:03:00.180764
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    d_t_f_c = DateTimeFactCollector()
    d_t_c_facts = d_t_f_c.collect()
    assert d_t_c_facts['date_time']
    assert d_t_c_facts['date_time']['day']

# Generated at 2022-06-23 01:03:01.598483
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()
    assert collector.name == 'date_time'

# Generated at 2022-06-23 01:03:03.811555
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector.name == 'date_time'
    assert DateTimeFactCollector._fact_ids == set()


# Generated at 2022-06-23 01:03:13.108969
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_dt = DateTimeFactCollector()
    result = test_dt.collect()
    assert result['date_time']['year'] != '', 'Date Time collector failed to create year!'
    assert result['date_time']['month'] != '', 'Date Time collector failed to create month!'
    assert result['date_time']['weekday'] != '', 'Date Time collector failed to create weekday!'
    assert result['date_time']['weekday_number'] != '', 'Date Time collector failed to create weekday number!'
    assert result['date_time']['weeknumber'] != '', 'Date Time collector failed to create week number!'
    assert result['date_time']['day'] != '', 'Date Time collector failed to create day!'

# Generated at 2022-06-23 01:03:22.341545
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_collector = DateTimeFactCollector()
    date_time_facts = date_time_collector.collect()
    assert(date_time_facts['date_time']['year'] != '')
    assert(date_time_facts['date_time']['month'] != '')
    assert(date_time_facts['date_time']['weekday'] != '')
    assert(date_time_facts['date_time']['weekday_number'] != '')
    assert(date_time_facts['date_time']['weeknumber'] != '')
    assert(date_time_facts['date_time']['day'] != '')
    assert(date_time_facts['date_time']['hour'] != '')

# Generated at 2022-06-23 01:03:24.790522
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector
    assert x.name == 'date_time'
    assert x._fact_ids == set([])

# Generated at 2022-06-23 01:03:27.272559
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fc = DateTimeFactCollector()
    fact = fc.collect()['date_time']
    assert fact['year'] == datetime.datetime.now().strftime('%Y')

# Generated at 2022-06-23 01:03:30.322807
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert isinstance(obj, DateTimeFactCollector)
    assert obj.name == 'date_time'
    assert not obj._fact_ids


# Generated at 2022-06-23 01:03:38.919927
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Test logic to get the date time facts"""
    collector = DateTimeFactCollector()
    facts_dict = {}
    date_time_facts = {}

    # Store the timestamp once, then get local and UTC versions from that
    epoch_ts = time.time()
    now = datetime.datetime.fromtimestamp(epoch_ts)
    utcnow = datetime.datetime.utcfromtimestamp(epoch_ts)

    date_time_facts['year'] = now.strftime('%Y')
    date_time_facts['month'] = now.strftime('%m')
    date_time_facts['weekday'] = now.strftime('%A')
    date_time_facts['weekday_number'] = now.strftime('%w')

# Generated at 2022-06-23 01:03:42.682878
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtf = DateTimeFactCollector()
    assert dtf.name == 'date_time'
    assert dtf._fact_ids == set()


# Generated at 2022-06-23 01:03:49.000752
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # Initialize DateTimeFactCollector class instance
    dtfc = DateTimeFactCollector()

    # Execute collect() method
    result = dtfc.collect()

    # Verify results
    assert result['date_time']['epoch_int'] is not None
    assert result['date_time']['time'] is not None
    assert result['date_time']['tz'] is not None

# Unit test execution
if __name__ == '__main__':

    test_DateTimeFactCollector_collect()

# Generated at 2022-06-23 01:03:52.236749
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()
    assert collector.name == 'date_time'
    assert len(collector._fact_ids) == 0


# Generated at 2022-06-23 01:03:56.033610
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x
    assert x.name == 'date_time'
    assert isinstance(x._fact_ids, set)
    assert x._fact_ids == set()


# Generated at 2022-06-23 01:03:58.102035
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert isinstance(x, DateTimeFactCollector)

# Generated at 2022-06-23 01:03:59.647348
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt_fc = DateTimeFactCollector()
    dt_fc.collect()

# Generated at 2022-06-23 01:04:02.000299
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector.name == 'date_time'
    assert DateTimeFactCollector._fact_ids == set()



# Generated at 2022-06-23 01:04:14.954170
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    fake_now = datetime.datetime(2016, 6, 1, 12, 0, 0)
    module = AnsibleModule
    module.get_bin_path = MagicMock(return_value=None)
    with patch.object(time, 'time', return_value=1464781200.0):
        with patch.object(datetime, 'datetime', return_value=fake_now):
            facts_dict = DateTimeFactCollector().collect(module=module)


# Generated at 2022-06-23 01:04:15.964430
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()

# Generated at 2022-06-23 01:04:27.063700
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    now = datetime.datetime.now()
    # Mock the current time to now
    module = {}
    class_name = "ansible.module_utils.facts.collector.date_time.DateTimeFactCollector"
    class_name_new = "ansible.module_utils.facts.collector.date_time_new.DateTimeFactCollector"
    # class_name_new = "ansible.module_utils.facts.DateTimeFactCollector"
    # class_name_new = "module_util_facts.DateTimeFactCollector"
    class_name_new = "facts.DateTimeFactCollector"
    # class_name = "facts.DateTimeFactCollector"
    # class_name = "facts.collector.DateTimeFactCollector"
    # class_name = "facts.collector.

# Generated at 2022-06-23 01:04:29.938756
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt.name == 'date_time'

# Generated at 2022-06-23 01:04:33.424221
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt_collector = DateTimeFactCollector()
    assert dt_collector.name == 'date_time'
    assert not dt_collector._fact_ids


# Generated at 2022-06-23 01:04:39.706236
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_collector = DateTimeFactCollector()
    test_facts = {}
    result_facts_dict = test_collector.collect()
    # Each fact should be a dict and should have a value
    for fact_name in result_facts_dict['date_time']:
        assert isinstance(result_facts_dict['date_time'][fact_name], type(''))
        assert result_facts_dict['date_time'][fact_name] != ''

# Generated at 2022-06-23 01:04:43.213705
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    fact_collector = DateTimeFactCollector()
    assert fact_collector.name == 'date_time'

# Generated at 2022-06-23 01:04:47.657713
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt_fact_collector = DateTimeFactCollector()
    assert isinstance(dt_fact_collector, DateTimeFactCollector)
    assert dt_fact_collector.name == 'date_time'
    assert dt_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:04:49.280472
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj.name == 'date_time'

# Generated at 2022-06-23 01:04:52.921383
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    result = {}
    fact_collector = DateTimeFactCollector(None, result)
    assert fact_collector.name == 'date_time'
    assert fact_collector.collection_type == 'per_host'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:04:54.270899
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    d = DateTimeFactCollector()
    assert d.name == 'date_time'

# Generated at 2022-06-23 01:04:56.567429
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    pass


if __name__ == '__main__':
    print(DateTimeFactCollector().collect())

# Generated at 2022-06-23 01:05:01.094871
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    c = DateTimeFactCollector()
    assert c.name == 'date_time'
    assert c._fact_ids == set(['date_time'])


# Generated at 2022-06-23 01:05:05.252277
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'

# Generated at 2022-06-23 01:05:20.630264
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = DateTimeFactCollector()
    collected_facts = dt.collect()
    assert collected_facts['date_time']['year'] == datetime.datetime.now().strftime("%Y")
    assert collected_facts['date_time']['month'] == datetime.datetime.now().strftime("%m")
    assert collected_facts['date_time']['day'] == datetime.datetime.now().strftime("%d")
    assert collected_facts['date_time']['hour'] == datetime.datetime.now().strftime("%H")
    assert collected_facts['date_time']['minute'] == datetime.datetime.now().strftime("%M")

# Generated at 2022-06-23 01:05:21.738940
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector.collect()

# Generated at 2022-06-23 01:05:31.582030
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Prepare test data
    ansible_module = None
    collected_facts = None

    # Instantiate DateTimeFactCollector object
    date_time_fact_collector = DateTimeFactCollector()

    # Execute test function
    result = date_time_fact_collector.collect(ansible_module, collected_facts)

    # Check result

# Generated at 2022-06-23 01:05:34.167466
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj.name == 'date_time'
    assert len(obj.collect()) > 0

# Generated at 2022-06-23 01:05:44.451282
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # NOTE: maybe move this test to test_facts_module.py?

    # initialize
    fct = DateTimeFactCollector()

# Generated at 2022-06-23 01:05:55.881705
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Test ansible.module_utils.facts.system.date_time.DateTimeFactCollector._collect_date_time_facts."""
    date_time_module_name = 'ansible.module_utils.facts.system.date_time'
    date_time_collector = DateTimeFactCollector()
    collected_facts = {'date_time': {}}
    test_date_time_facts = {}

    # Test platform-specific facts
    epoch_ts = time.time()
    now = datetime.datetime.fromtimestamp(epoch_ts)
    utcnow = datetime.datetime.utcfromtimestamp(epoch_ts)

    test_date_time_facts['year'] = now.strftime('%Y')

# Generated at 2022-06-23 01:05:59.251944
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    _date_time_fact_collector = DateTimeFactCollector()
    result = _date_time_fact_collector.collect(collected_facts=None)
    assert result['date_time']

# Generated at 2022-06-23 01:06:02.316747
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_collector = DateTimeFactCollector()


# Generated at 2022-06-23 01:06:05.069257
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt.name == 'date_time'
    assert dt._fact_ids == set()



# Generated at 2022-06-23 01:06:07.042119
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'
    assert x._fact_ids is not None

# Generated at 2022-06-23 01:06:10.460983
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    datetime_obj = DateTimeFactCollector()
    assert datetime_obj.name == 'date_time'
    # Test epoch_int fact
    datetime_obj.collect()
    assert 'epoch_int' in datetime_obj.collect()['date_time'].keys()

# Generated at 2022-06-23 01:06:20.465017
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_collector = DateTimeFactCollector()
    date_time_facts = date_time_collector.collect()
    assert date_time_facts['date_time']['date']
    assert date_time_facts['date_time']['time']
    assert date_time_facts['date_time']['epoch']
    assert date_time_facts['date_time']['epoch_int']
    assert date_time_facts['date_time']['tz_offset']
    assert date_time_facts['date_time']['tz']
    assert date_time_facts['date_time']['iso8601_micro']
    assert date_time_facts['date_time']['iso8601']

# Generated at 2022-06-23 01:06:25.223910
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'
    assert x._fact_ids == set()
    assert isinstance(x, BaseFactCollector)


# Generated at 2022-06-23 01:06:29.195417
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    datetime_collector = DateTimeFactCollector()

    assert datetime_collector.name == 'date_time'
    assert datetime_collector._fact_ids == set()


# Generated at 2022-06-23 01:06:31.934486
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    fact_collector.collect()
    assert len(fact_collector.get_facts()) == 1

# Generated at 2022-06-23 01:06:34.754020
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'
    assert dtfc._fact_ids == set()


# Generated at 2022-06-23 01:06:39.240538
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    c = DateTimeFactCollector()
    assert c.name == 'date_time'
    assert c._fact_ids == set()

# Generated at 2022-06-23 01:06:51.578384
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Preparing for testing
    now = datetime.datetime.now()
    utcnow = datetime.datetime.utcnow()
    date_time_facts = {}
    date_time_facts['year'] = now.strftime('%Y')
    date_time_facts['month'] = now.strftime('%m')
    date_time_facts['weekday'] = now.strftime('%A')
    date_time_facts['weekday_number'] = now.strftime('%w')
    date_time_facts['weeknumber'] = now.strftime('%W')
    date_time_facts['day'] = now.strftime('%d')
    date_time_facts['hour'] = now.strftime('%H')

# Generated at 2022-06-23 01:06:55.416466
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_test = DateTimeFactCollector()
    date_time = date_time_test.collect()
    assert date_time['date_time']['second'] == time.strftime("%S")


# Generated at 2022-06-23 01:06:57.363453
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector.name == 'date_time'

# Generated at 2022-06-23 01:06:59.240180
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_facts = DateTimeFactCollector()
    assert date_time_facts.name == 'date_time'

# Generated at 2022-06-23 01:07:00.855267
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj.name == 'date_time'

# Generated at 2022-06-23 01:07:12.185331
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    f = DateTimeFactCollector()
    facts = f.collect()
    assert type(facts['date_time']) is dict
    assert 'year' in facts['date_time']
    assert 'month' in facts['date_time']
    assert 'weekday' in facts['date_time']
    assert 'weekday_number' in facts['date_time']
    assert 'weeknumber' in facts['date_time']
    assert 'day' in facts['date_time']
    assert 'hour' in facts['date_time']
    assert 'minute' in facts['date_time']
    assert 'second' in facts['date_time']
    assert 'epoch' in facts['date_time']
    assert 'epoch_int' in facts['date_time']
    assert 'date' in facts['date_time']

# Generated at 2022-06-23 01:07:15.122626
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact = DateTimeFactCollector()

    assert date_time_fact.name == 'date_time'
    assert set() == date_time_fact._fact_ids



# Generated at 2022-06-23 01:07:24.641829
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import platform
    import copy
    first_line = "WARNING: this is not a complete test; it does not test for the values returned by datetime.datetime's strftime method"
    second_line = "WARNING: this is not a complete test; it does not test for the values returned by time's strftime method"
    third_line = "WARNING: this is not a complete test; it does not test for the values returned by time's tzname method"
    test_object = DateTimeFactCollector()
    ret = test_object.collect()
    # The following print message is for testers to customise output messages
    #print(ret)
    assert(ret is not None), test_object.name + '.collect is returning None instead of a dictionary'

# Generated at 2022-06-23 01:07:28.855001
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    """Test constructor of DateTimeFactCollector"""
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'
    assert date_time_fact_collector.collect() is not None

# Generated at 2022-06-23 01:07:32.103235
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():

    # create the object for DateTimeFactCollector module
    class_instance = DateTimeFactCollector()

    # check if there are no errors while creating class
    assert not class_instance


# Generated at 2022-06-23 01:07:41.199676
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    time.strftime("%Y")

    # Create an instance of AnsibleModule
    module = type('module', (object,), dict(params={}))()
    module.params = dict(collection_type='network', gather_subset='min')
    module.params = dict(collection_type='network', gather_timeout=1)

    # Create an instance of DateTimeFactCollector and call method collect
    date_time_fact_collector = DateTimeFactCollector()
    res_dict = date_time_fact_collector.collect(module)

    # Test the result
    print(res_dict)
    assert len(res_dict) == 1
    assert res_dict['date_time'] != {}
    assert len(res_dict['date_time']) == 19

# Generated at 2022-06-23 01:07:52.580471
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import pytest
    import importlib

    module_name = 'ansible.module_utils.facts.system.date_time.DateTimeFactCollector'
    module = importlib.import_module(module_name)
    DateTimeFactCollectorClass = getattr(module, 'DateTimeFactCollector')
    DateTimeFactCollectorInst = DateTimeFactCollectorClass()

# Generated at 2022-06-23 01:07:55.991746
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():

    assert isinstance(DateTimeFactCollector, object)

# Generated at 2022-06-23 01:08:06.359026
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Create a test DateTimeFactCollector object
    date_time_fact_collector = DateTimeFactCollector()

    # The timestamp used to generate local and utc datetime objects.
    epoch_ts = time.time()
    now = datetime.datetime.fromtimestamp(epoch_ts)
    utcnow = datetime.datetime.utcfromtimestamp(epoch_ts)

    # Collect the facts
    facts = date_time_fact_collector.collect()

    # Verify the facts
    assert facts['date_time']['year'] == now.strftime('%Y')
    assert facts['date_time']['month'] == now.strftime('%m')
    assert facts['date_time']['weekday'] == now.strftime('%A')

# Generated at 2022-06-23 01:08:10.749513
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_facts = DateTimeFactCollector().collect()
    assert date_time_facts['date_time']['epoch'].isdigit()
    assert date_time_facts['date_time']['epoch_int'].isdigit()

# vim: set et ts=4 sts=4 sw=4

# Generated at 2022-06-23 01:08:13.283616
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    D = DateTimeFactCollector()
    assert D.name == 'date_time'
    assert D._fact_ids == set()



# Generated at 2022-06-23 01:08:14.875742
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector.name == 'date_time'

# Generated at 2022-06-23 01:08:25.413504
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Returns information about the datetime."""
    date_time_facts = DateTimeFactCollector().collect()
    assert len(date_time_facts) == 1
    assert type(date_time_facts) is dict
    assert 'date_time' in date_time_facts
    assert len(date_time_facts['date_time']) == 18
    assert 'year' in date_time_facts['date_time']
    assert type(date_time_facts['date_time']['year']) is str
    assert len(date_time_facts['date_time']['year']) == 4
    assert 'month' in date_time_facts['date_time']
    assert type(date_time_facts['date_time']['month']) is str