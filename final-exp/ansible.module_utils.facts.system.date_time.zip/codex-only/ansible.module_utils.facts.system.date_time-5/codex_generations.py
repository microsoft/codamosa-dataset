

# Generated at 2022-06-23 00:58:22.164538
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    f = DateTimeFactCollector()
    assert isinstance(f.collect(), dict)
    assert 'date_time' in f.collect()
    assert isinstance(f.collect()['date_time'], dict)
    assert 'date' in f.collect()['date_time']
    assert 'time' in f.collect()['date_time']

# Generated at 2022-06-23 00:58:30.533257
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # create an empty DateTimeFactCollector
    DateTimeFactCollector_inst = DateTimeFactCollector()

    # collect
    DateTimeFactCollector_res = DateTimeFactCollector_inst.collect()

    assert 'date_time' in DateTimeFactCollector_res
    assert 'weekday' in DateTimeFactCollector_res['date_time']
    assert len(DateTimeFactCollector_res['date_time']['weekday']) > 0
    assert 'year' in DateTimeFactCollector_res['date_time']
    assert len(DateTimeFactCollector_res['date_time']['year']) == 4
    assert 'month' in DateTimeFactCollector_res['date_time']
    assert len(DateTimeFactCollector_res['date_time']['month']) == 2
   

# Generated at 2022-06-23 00:58:40.518628
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    class AnsibleModuleFake:
        def __init__(self):
            ansible_facts = {'ansible_local': {}, 'ansible_date_time': {}}
            self.params = {'gather_subset': ['all']}
            self.ansible_facts = ansible_facts

        def exit_json(self, **kwargs):
            pass

        def fail_json(self, **kwargs):
            pass

    obj = DateTimeFactCollector()
    obj.collect(AnsibleModuleFake())

# Generated at 2022-06-23 00:58:52.214828
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Test the collect method of DateTimeFactCollector
    result = DateTimeFactCollector().collect()
    # Make sure we get the expected date_time facts
    assert isinstance(result, dict)
    assert 'date_time' in result
    assert isinstance(result['date_time'], dict)
    assert isinstance(result['date_time']['epoch'], str)
    assert isinstance(result['date_time']['epoch_int'], str)
    assert isinstance(result['date_time']['date'], str)
    assert isinstance(result['date_time']['time'], str)
    assert isinstance(result['date_time']['iso8601_micro'], str)
    assert isinstance(result['date_time']['iso8601'], str)

# Generated at 2022-06-23 00:58:54.684359
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()
    assert collector.name == 'date_time'
    assert collector._fact_ids == set()


# Generated at 2022-06-23 00:58:57.960797
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    '''
    Unit test for method collect of class DateTimeFactCollector
    '''
    # DateTimeFactCollector object
    obj = DateTimeFactCollector()
    # Collect facts
    obj.collect()

# Generated at 2022-06-23 00:59:08.503307
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Tests if dictionary contains the correct information
    """
    dtf = DateTimeFactCollector()
    date_time_facts = dtf.collect()['date_time']
    if date_time_facts['year'] != str(datetime.datetime.now().strftime('%Y')):
        raise AssertionError
    if date_time_facts['month'] != str(datetime.datetime.now().strftime('%m')):
        raise AssertionError
    if date_time_facts['weekday'] != str(datetime.datetime.now().strftime('%A')):
        raise AssertionError
    if date_time_facts['weekday_number'] != str(datetime.datetime.now().strftime('%w')):
        raise AssertionError

# Generated at 2022-06-23 00:59:16.426974
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    time_now = time.localtime()
    assert time_now.tm_year == int(DateTimeFactCollector().collect()['date_time']['year'])
    assert time_now.tm_mon == int(DateTimeFactCollector().collect()['date_time']['month'])
    assert time_now.tm_mday == int(DateTimeFactCollector().collect()['date_time']['day'])
    assert time_now.tm_hour == int(DateTimeFactCollector().collect()['date_time']['hour'])
    assert time_now.tm_min == int(DateTimeFactCollector().collect()['date_time']['minute'])
    assert time_now.tm_sec == int(DateTimeFactCollector().collect()['date_time']['second'])
   

# Generated at 2022-06-23 00:59:18.533913
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    dtfc.collect()

# Generated at 2022-06-23 00:59:29.990829
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    f = DateTimeFactCollector()
    collected_facts = {}
    expected_facts = {}
    now = datetime.datetime.now()
    utcnow = datetime.datetime.utcnow()
    expect_date_time_facts = {}
    expect_date_time_facts['year'] = now.strftime('%Y')
    expect_date_time_facts['month'] = now.strftime('%m')
    expect_date_time_facts['weekday'] = now.strftime('%A')
    expect_date_time_facts['weekday_number'] = now.strftime('%w')
    expect_date_time_facts['weeknumber'] = now.strftime('%W')
    expect_date_time_facts['day'] = now.strftime('%d')
    expect_date_

# Generated at 2022-06-23 00:59:40.620874
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact = DateTimeFactCollector()
    result = fact.collect()
    assert 'date_time' in result
    assert result['date_time']['year'] == time.strftime('%Y')
    assert result['date_time']['month'] == time.strftime('%m')
    assert result['date_time']['weekday'] == time.strftime('%A')
    assert result['date_time']['weekday_number'] == time.strftime('%w')
    assert result['date_time']['weeknumber'] == time.strftime('%W')
    assert result['date_time']['day'] == time.strftime('%d')
    assert result['date_time']['hour'] == time.strftime('%H')
    assert result['date_time']['minute']

# Generated at 2022-06-23 00:59:41.892329
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector.name == 'date_time'

# Generated at 2022-06-23 00:59:56.679179
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Create instance of class
    collector = DateTimeFactCollector()

    # get facts
    facts = collector.collect()
    date_time_facts = facts.get('date_time')

    # Check return content
    assert date_time_facts['year']
    assert date_time_facts['month']
    assert date_time_facts['weekday']
    assert date_time_facts['weekday_number']
    assert date_time_facts['weeknumber']
    assert date_time_facts['day']
    assert date_time_facts['hour']
    assert date_time_facts['minute']
    assert date_time_facts['second']
    assert date_time_facts['epoch']
    assert date_time_facts['epoch_int']
    assert date_time_facts['date']
    assert date_time_

# Generated at 2022-06-23 01:00:00.654064
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time = DateTimeFactCollector()
    assert date_time.name == "date_time"
    assert len(date_time._fact_ids) == 0
    # assert len(date_time._plugin_classes) == 1

# Generated at 2022-06-23 01:00:03.505474
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    result = DateTimeFactCollector()

    assert result
    assert result.name == 'date_time'
    assert result._fact_ids == set()



# Generated at 2022-06-23 01:00:06.998946
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_facts_collector = DateTimeFactCollector()
    assert date_time_facts_collector.name == 'date_time'
    assert date_time_facts_collector._fact_ids == set()


# Generated at 2022-06-23 01:00:07.889428
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    DateTimeFactCollector.collect()



# Generated at 2022-06-23 01:00:17.864893
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-23 01:00:30.075578
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Unit test for method collect of class DateTimeFactCollector"""
    fact_collector = DateTimeFactCollector()
    result = fact_collector.collect()
    assert type(result) == dict
    assert 'date_time' in result
    assert type(result['date_time']) == dict
    assert 'year' in result['date_time']
    assert 'month' in result['date_time']
    assert 'weeknumber' in result['date_time']
    assert 'weekday' in result['date_time']
    assert 'weekday_number' in result['date_time']
    assert 'day' in result['date_time']
    assert 'hour' in result['date_time']
    assert 'minute' in result['date_time']
    assert 'second' in result['date_time']

# Generated at 2022-06-23 01:00:33.088872
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtf = DateTimeFactCollector()
    assert dtf.name == 'date_time'
    assert dtf._fact_ids == set()


# Generated at 2022-06-23 01:00:41.667518
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    fact_collector = get_collector_instance('date_time')
    facts = fact_collector.collect()
    assert 'date_time' in facts, "date_time not found in facts"
    assert 'year' in facts['date_time'], "date_time.year not found in facts"
    assert 'epoch' in facts['date_time'], "date_time.epoch not found in facts"
    assert 'date' in facts['date_time'], "date_time.date not found in facts"
    assert 'time' in facts['date_time'], "date_time.time not found in facts"

# Generated at 2022-06-23 01:00:44.681094
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    results = DateTimeFactCollector().collect()
    # The method will return a valid time format,
    # so the length is enough to test the method.
    assert len(results['date_time']['month']) == 2

# Generated at 2022-06-23 01:00:57.052357
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    datetime_fact_collector = DateTimeFactCollector()
    facts = datetime_fact_collector.collect()
    assert facts['date_time']['year']
    assert facts['date_time']['month']
    assert facts['date_time']['weekday']
    assert facts['date_time']['weekday_number']
    assert facts['date_time']['weeknumber']
    assert facts['date_time']['day']
    assert facts['date_time']['hour']
    assert facts['date_time']['minute']
    assert facts['date_time']['second']
    assert facts['date_time']['epoch']
    assert facts['date_time']['epoch_int']
    assert facts['date_time']['date']

# Generated at 2022-06-23 01:01:09.430947
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    c = DateTimeFactCollector()
    output = c.collect()

    assert output.get('date_time') is not None, 'Expected at least some output'
    assert isinstance(output.get('date_time'), dict), 'Expected a dict'

    dt = output.get('date_time')
    assert dt.get('second') is not None and len(dt.get('second')) == 2, 'Expected a two digit second'
    assert dt.get('minute') is not None and len(dt.get('minute')) == 2, 'Expected a two digit minute'
    assert dt.get('hour') is not None and len(dt.get('hour')) == 2, 'Expected a two digit hour'

# Generated at 2022-06-23 01:01:12.263511
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    d = DateTimeFactCollector()
    assert d.name == 'date_time'
    assert d._fact_ids == set()

# Generated at 2022-06-23 01:01:12.948726
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    pass

# Generated at 2022-06-23 01:01:14.881845
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    collector = DateTimeFactCollector()
    assert collector.name == 'date_time'
    assert collector._fact_ids == set()

# Generated at 2022-06-23 01:01:16.982452
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    x = DateTimeFactCollector()
    assert x.name == 'date_time'
    assert isinstance(x.collect(), dict)

# Generated at 2022-06-23 01:01:18.031579
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    DateTimeFactCollector.collect()

# Generated at 2022-06-23 01:01:22.157690
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Make sure we get back a dictionary with an key date_time that contains various time related data.
    """
    # Create the object
    DateTimeFactCollectorObj = DateTimeFactCollector()

    # Call method collect
    DateTimeFactCollectorObj.collect()

    # Check our results
    assert 'date_time' in DateTimeFactCollectorObj.collect()

# Generated at 2022-06-23 01:01:23.889845
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dt = DateTimeFactCollector()
    assert dt is not None

# Generated at 2022-06-23 01:01:24.974994
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    DateTimeFactCollector().collect()

# Generated at 2022-06-23 01:01:26.804793
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """Test DateTimeFactCollector.collect()
    """

    DateTimeFactCollector.collect()

# Generated at 2022-06-23 01:01:38.827434
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    ansible_collector.load_collections(['../../plugins/modules/date_time_facts/'])

    def mock_module(name, *args, **kwargs):
        class MockModule:
            def __init__(self, name, *args, **kwargs):
                self.name = name
            def fail_json(self, *args, **kwargs):
                pass
        return MockModule(name, *args, **kwargs)
    module = mock_module('test_module')
    dt = DateTimeFactCollector(module)

    # Using the provided fromTimeStamp factory method, compare the datetime
    # object to the date_time fact data retrieved from the test target.

# Generated at 2022-06-23 01:01:40.323626
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    f = DateTimeFactCollector()
    assert f.name == 'date_time'

# Generated at 2022-06-23 01:01:50.662581
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    date_timeFactCollector = DateTimeFactCollector()
    collected_facts = date_timeFactCollector.collect()

    # Test the result
    assert 'date_time' in collected_facts
    assert 'year' in collected_facts['date_time']
    assert 'month' in collected_facts['date_time']
    assert 'weekday' in collected_facts['date_time']
    assert 'weekday_number' in collected_facts['date_time']
    assert 'weeknumber' in collected_facts['date_time']
    assert 'day' in collected_facts['date_time']
    assert 'hour' in collected_facts['date_time']
    assert 'minute' in collected_facts['date_time']
    assert 'second' in collected_facts['date_time']

# Generated at 2022-06-23 01:02:02.216644
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collector = DateTimeFactCollector()

    result = collector.collect()['date_time']
    assert result['year']
    assert result['month']
    assert result['weekday']
    assert result['weekday_number']
    assert result['weeknumber']
    assert result['day']
    assert result['hour']
    assert result['minute']
    assert result['second']
    assert result['epoch']
    assert result['epoch_int']
    assert result['date']
    assert result['time']
    assert result['iso8601_micro']
    assert result['iso8601']
    assert result['iso8601_basic']
    assert result['iso8601_basic_short']
    assert result['tz']
    assert result['tz_dst']
    assert result['tz_offset']

# Generated at 2022-06-23 01:02:05.293177
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    x = DateTimeFactCollector()
    result = x.collect()
    assert type(result) is dict
    assert type(result['date_time']) is dict

# Generated at 2022-06-23 01:02:07.560721
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj.name == 'date_time'
    assert obj._fact_ids == set()


# Generated at 2022-06-23 01:02:18.468219
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = DateTimeFactCollector()
    res = dt.collect()
    assert(res['date_time']['year'] != '')
    assert(res['date_time']['month'] != '')
    assert(res['date_time']['weekday'] != '')
    assert(res['date_time']['weekday_number'] != '')
    assert(res['date_time']['weeknumber'] != '')
    assert(res['date_time']['day'] != '')
    assert(res['date_time']['hour'] != '')
    assert(res['date_time']['minute'] != '')
    assert(res['date_time']['second'] != '')
    assert(res['date_time']['epoch'] != '')

# Generated at 2022-06-23 01:02:22.328104
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'
    assert date_time_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:02:26.251592
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    results = DateTimeFactCollector().collect()
    assert results['date_time']['iso8601_micro'] == datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.%fZ")

# Generated at 2022-06-23 01:02:29.301645
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    d = DateTimeFactCollector()
    fact = d.collect()
    assert fact['date_time']['date'] == datetime.datetime.now().strftime('%Y-%m-%d')

# Generated at 2022-06-23 01:02:41.163023
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    print('Test: DateTimeFactCollector.collect()')
    print('')

    try:
        # Specify the module prefixed with ansible.module_utils.facts.collectors
        test_collector = DateTimeFactCollector()

        # Get the facts
        test_facts = test_collector.collect()

        # Print out the facts
        print('Facts:')
        print(test_facts)
    except:
        print('ERROR: Exception raised when calling DateTimeFactCollector.collect()')

if __name__ == '__main__':
    # Test DateTimeFactCollector
    test_DateTimeFactCollector_collect()

# Generated at 2022-06-23 01:02:49.928954
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    ''' Test DateTimeFactCollector.collect
        Verify we have some data, and we have the specific keys we want
    '''
    import time, datetime, pytest

    date_time_fc = DateTimeFactCollector()
    test_data = date_time_fc.collect()

    assert 'date_time' in test_data
    assert 'date' in test_data['date_time']
    assert 'iso8601_micro' in test_data['date_time']
    assert 'iso8601_basic' in test_data['date_time']
    assert 'tz' in test_data['date_time']
    assert 'tz_dst' in test_data['date_time']
    assert 'tz_offset' in test_data['date_time']

# Generated at 2022-06-23 01:03:00.481277
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    datetime_collector = DateTimeFactCollector()
    datetime_collector._module = DummyModule()
    ansible_facts = {}

    # Test date_time facts
    ansible_facts = datetime_collector.collect(module=None, collected_facts=None)

    assert 'date_time' in ansible_facts
    assert 'epoch' in ansible_facts['date_time']
    assert 'epoch_int' in ansible_facts['date_time']
    assert ansible_facts['date_time']['epoch'] == ansible_facts['date_time']['epoch_int']
    assert 'iso8601' in ansible_facts['date_time']
    assert 'iso8601_micro' in ansible_facts['date_time']
    assert 'tz' in ansible_

# Generated at 2022-06-23 01:03:05.426153
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Test the collect method
    """
    dtcollect = DateTimeFactCollector()
    dtcollect.collect()
    myfacts = dtcollect.collect_facts()
    assert myfacts['date_time']['epoch_int']

# Generated at 2022-06-23 01:03:08.101121
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collector = DateTimeFactCollector()
    collected_facts = collector.collect()
    # Test date_time fact
    assert collected_facts['date_time']['epoch'] != ''

# Generated at 2022-06-23 01:03:11.126068
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():

    date_time_constructor = DateTimeFactCollector()

    assert date_time_constructor.name == 'date_time'
    assert not date_time_constructor._fact_ids


# Generated at 2022-06-23 01:03:16.204958
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtf = DateTimeFactCollector()

    assert dtf.name == 'date_time'
    assert dtf._fact_ids == set()

# Generated at 2022-06-23 01:03:29.885335
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    collected_facts = fact_collector.collect()

    utcnow = datetime.datetime.utcfromtimestamp(time.time())

    assert collected_facts['date_time']['year'].isdigit()
    assert collected_facts['date_time']['month'].isdigit()
    assert collected_facts['date_time']['weekday'].isalpha()
    assert collected_facts['date_time']['weekday_number'].isdigit()
    assert collected_facts['date_time']['weeknumber'].isdigit()
    assert collected_facts['date_time']['day'].isdigit()
    assert collected_facts['date_time']['hour'].isdigit()

# Generated at 2022-06-23 01:03:40.108071
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    collected_facts = {}
    collected_facts = fact_collector.collect(collected_facts=collected_facts)
    assert 'date_time' in collected_facts
    assert 'year' in collected_facts['date_time']
    assert 'month' in collected_facts['date_time']
    assert 'weekday' in collected_facts['date_time']
    assert 'weekday_number' in collected_facts['date_time']
    assert 'weeknumber' in collected_facts['date_time']
    assert 'day' in collected_facts['date_time']
    assert 'hour' in collected_facts['date_time']
    assert 'minute' in collected_facts['date_time']
    assert 'second' in collected_facts['date_time']

# Generated at 2022-06-23 01:03:49.284310
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = DateTimeFactCollector()

    # Expected value
    # Pycharm 2018.1.5 flags this as an error.  The test passes with no failure.

# Generated at 2022-06-23 01:03:51.086951
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    DateTimeFactCollector()

# Generated at 2022-06-23 01:03:55.501941
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'
    assert date_time_fact_collector.collect()
    assert date_time_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:03:57.895520
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtf = DateTimeFactCollector()
    assert dtf.name == 'date_time'
    assert dtf._fact_ids == set()

# Generated at 2022-06-23 01:04:00.787334
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = DateTimeFactCollector()
    assert len(dt.collect().keys()) == 1
    assert dt.collect().get('date_time').get('year') != ''

# Generated at 2022-06-23 01:04:02.647087
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    facts_collector = DateTimeFactCollector()
    assert facts_collector.name == 'date_time'

# Generated at 2022-06-23 01:04:15.266522
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fake_FactsCollector = DateTimeFactCollector()
    actual = fake_FactsCollector.collect()

# Generated at 2022-06-23 01:04:26.710610
# Unit test for constructor of class DateTimeFactCollector

# Generated at 2022-06-23 01:04:29.434518
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    assert dtfc.collect()

# Generated at 2022-06-23 01:04:32.461347
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    df = DateTimeFactCollector()
    assert df.name == 'date_time'
    assert len(df.collect()) == 1
    assert df.collect()['date_time']

# Generated at 2022-06-23 01:04:42.495982
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time = DateTimeFactCollector()
    result = date_time.collect()
    assert result['date_time']
    assert result['date_time']['year']
    assert result['date_time']['month']
    assert result['date_time']['weekday']
    assert result['date_time']['weekday_number']
    assert result['date_time']['weeknumber']
    assert result['date_time']['day']
    assert result['date_time']['hour']
    assert result['date_time']['minute']
    assert result['date_time']['second']
    assert result['date_time']['epoch']
    assert result['date_time']['epoch_int']
    assert result['date_time']['date']
    assert result

# Generated at 2022-06-23 01:04:52.151237
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-23 01:04:56.344933
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Constructor without arguments
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'
    assert dtfc._fact_ids == set()



# Generated at 2022-06-23 01:05:00.202019
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    """Unit tests for DateTimeFactCollector's constructor"""
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'
    assert dtfc._fact_ids == set()


# Generated at 2022-06-23 01:05:03.754214
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtfc = DateTimeFactCollector()
    assert dtfc.name == 'date_time'


# Generated at 2022-06-23 01:05:15.041411
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    module = None
    collector = DateTimeFactCollector(module=module)
    facts_dict = collector.collect()

    assert isinstance(facts_dict, dict)
    assert 'date_time' in facts_dict
    assert 'year' in facts_dict['date_time']
    assert 'month' in facts_dict['date_time']
    assert 'weekday' in facts_dict['date_time']
    assert 'day' in facts_dict['date_time']
    assert 'hour' in facts_dict['date_time']
    assert 'minute' in facts_dict['date_time']
    assert 'second' in facts_dict['date_time']
    assert 'epoch' in facts_dict['date_time']
    assert 'epoch_int' in facts_dict['date_time']

# Generated at 2022-06-23 01:05:20.616279
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """ Unit test for method collect of class DateTimeFactCollector """

    """ Hello """

    # Some codes to test.
    # some_code = 'some_code'
    # assert(some_code == 'some_code')

    # other_code = 'other_code'
    # assert(other_code == 'other_code')

# Generated at 2022-06-23 01:05:29.688943
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    now = datetime.datetime.now()
    then = datetime.datetime.now() + datetime.timedelta(seconds=-1)
    later = datetime.datetime.now() + datetime.timedelta(seconds=-2)
    facts_dict = DateTimeFactCollector().collect()
    date_time_facts = facts_dict['date_time']
    assert date_time_facts['year'] == now.strftime('%Y')
    assert date_time_facts['month'] == now.strftime('%m')
    assert date_time_facts['weekday'] in now.strftime('%A')
    assert int(date_time_facts['weekday_number']) == datetime.datetime.weekday(now)
    assert int(date_time_facts['weeknumber']) == datetime.date

# Generated at 2022-06-23 01:05:31.990140
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    obj = DateTimeFactCollector()
    assert obj


# vim: set expandtab ts=4 sw=4:

# Generated at 2022-06-23 01:05:34.559669
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt_collector = DateTimeFactCollector()
    results = dt_collector.collect(collected_facts={})
    assert results != {}

# Generated at 2022-06-23 01:05:44.741665
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfz = DateTimeFactCollector()

    # check epoch
    data_ts = int(time.time())
    # Test epoch (or equivalent if epoch not available) is formalized as iso8601_micro format
    assert int(dtfz.collect()['date_time']['epoch']) <= data_ts
    # Test epoch_int (or equivalent if epoch not available) is formalized as iso8601_micro format
    assert int(dtfz.collect()['date_time']['epoch_int']) <= data_ts

    # check iso8601
    data_dt = datetime.datetime.utcfromtimestamp(data_ts)

# Generated at 2022-06-23 01:05:47.311581
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    try:
        datetime.strptime('2000', '%S')
    except ValueError:
        return
    assert False, "DateTimeFactCollector_collect is not implemented"

# Generated at 2022-06-23 01:05:57.672782
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collector = DateTimeFactCollector()
    date_time_facts = collector.collect()

    assert date_time_facts['epoch'] != ''
    assert 0 <= int(date_time_facts['epoch']) < 100000
    assert date_time_facts['epoch_int'] != ''
    assert 0 <= int(date_time_facts['epoch_int']) < 100000
    assert date_time_facts['day'] != ''
    assert not int(date_time_facts['day']) > 31
    assert date_time_facts['weekday_number'] != ''
    assert not int(date_time_facts['weekday_number']) > 7
    assert date_time_facts['weeknumber'] != ''
    assert not int(date_time_facts['weeknumber']) > 53
    assert date_time_facts

# Generated at 2022-06-23 01:06:00.723994
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    # Test 1: Run to make sure it doesn't throw any exceptions
    DateTimeFactCollector()

# Generated at 2022-06-23 01:06:07.227902
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    result = dtfc.collect()
    assert 'date_time' in result
    assert 'date' in result['date_time']
    assert 'weekday' in result['date_time']
    assert 'day' in result['date_time']
    assert 'time' in result['date_time']
    assert 'tz' in result['date_time']

# Generated at 2022-06-23 01:06:09.773986
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtf = DateTimeFactCollector()
    assert dtf.name == 'date_time'
    assert dtf._fact_ids == set()


# Generated at 2022-06-23 01:06:17.863583
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    module = None
    collected_facts = None
    dtfc = DateTimeFactCollector()
    datetime_facts = dtfc.collect(module, collected_facts)['date_time']

    assert datetime_facts['year']
    assert datetime_facts['month']
    assert datetime_facts['weekday']
    assert datetime_facts['weekday_number']
    assert datetime_facts['weeknumber']
    assert datetime_facts['day']
    assert datetime_facts['hour']
    assert datetime_facts['minute']
    assert datetime_facts['second']
    assert datetime_facts['epoch']
    assert datetime_facts['epoch_int']
    assert datetime_facts['date']
    assert datetime_facts['time']

# Generated at 2022-06-23 01:06:19.982876
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_collector = DateTimeFactCollector()
    date_time_collector.collect()

# Generated at 2022-06-23 01:06:21.897836
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    dtfc.collect()

# Generated at 2022-06-23 01:06:32.914613
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Create a DateTimeFactCollector instance
    dtfc = DateTimeFactCollector()

    # Get the data from method collect
    data = dtfc.collect()

    # Test if data is a dict
    assert isinstance(data, dict)

    # Test if the dict is of the expected format
    assert 'date_time' in data
    assert isinstance(data['date_time'], dict)
    for k, v in data['date_time'].items():
        assert isinstance(k, str)
        assert isinstance(v, str)
        assert not k == 'date_time'

# Generated at 2022-06-23 01:06:38.627299
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    c = DateTimeFactCollector()
    result = c.collect()
    assert len(result.keys()) == 1 and 'date_time' in result

# Generated at 2022-06-23 01:06:46.528167
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact = DateTimeFactCollector()
    date_time_fact_res = date_time_fact.collect()
    assert date_time_fact_res['date_time']['month'] == '02'
    assert date_time_fact_res['date_time']['iso8601_basic_short'] == datetime.datetime.now().strftime("%Y%m%dT%H%M%S")
    assert date_time_fact_res['date_time']['tz'] == time.strftime("%Z")

# Generated at 2022-06-23 01:06:48.262396
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    testobj = DateTimeFactCollector()
    assert testobj
    assert testobj.name == 'date_time'


# Generated at 2022-06-23 01:06:50.270947
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    """Test DateTimeFactCollector constructor"""
    DateTimeFactCollector()

# Generated at 2022-06-23 01:06:51.844181
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fc = DateTimeFactCollector()
    assert fc.collect()

# Generated at 2022-06-23 01:06:54.859337
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # arrange
    data = DateTimeFactCollector()
    # act
    retVal = data.collect()
    # assert
    assert retVal['date_time']

# Generated at 2022-06-23 01:06:56.740822
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    dtf = DateTimeFactCollector()
    assert dtf.name == 'date_time'
    assert dtf._fact_ids == set()

# Generated at 2022-06-23 01:06:58.737281
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector

# Generated at 2022-06-23 01:07:02.004700
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector = DateTimeFactCollector()
    collected_facts = {}
    facts = fact_collector.collect(None, collected_facts)
    assert 'date_time' in facts

# Generated at 2022-06-23 01:07:13.217793
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_facts = DateTimeFactCollector()
    ansible_date_time_facts = date_time_facts.collect()

    # Test for values returned by class method collect
    assert ansible_date_time_facts is not None
    assert ansible_date_time_facts['date_time'] is not None
    assert ansible_date_time_facts['date_time']['year'] is not None
    assert ansible_date_time_facts['date_time']['month'] is not None
    assert ansible_date_time_facts['date_time']['weekday'] is not None
    assert ansible_date_time_facts['date_time']['weekday_number'] is not None
    assert ansible_date_time_facts['date_time']['weeknumber'] is not None

# Generated at 2022-06-23 01:07:16.361644
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_facts = DateTimeFactCollector()
    assert date_time_facts.name == 'date_time'
    assert 'date_time' in date_time_facts._fact_ids

# Generated at 2022-06-23 01:07:28.912834
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    utcnow = datetime.datetime.utcnow()
    dt_fact_collector = DateTimeFactCollector()
    collected_date_time_facts = dt_fact_collector.collect()
    assert collected_date_time_facts['date_time']['weekday'] == time.strftime("%A")
    assert collected_date_time_facts['date_time']['epoch'] == str(int(time.time()))
    assert collected_date_time_facts['date_time']['tz_dst'] == time.tzname[1]
    assert collected_date_time_facts['date_time']['iso8601_micro'] == utcnow.strftime("%Y-%m-%dT%H:%M:%S.%fZ")

# Generated at 2022-06-23 01:07:38.023298
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # Setup test object
    d = DateTimeFactCollector()
    fact = {}

    # Sample output from running ansible -m setup -a
    # "date_time": {
    #     "date": "2018-01-09",
    #     "day": "09",
    #     "epoch": "1515519509",
    #     "epoch_int": "1515519509",
    #     "hour": "07",
    #     "iso8601": "2018-01-09T07:58:29Z",
    #     "iso8601_basic": "20180109T075829",
    #     "iso8601_basic_short": "20180109T075829",
    #     "iso8601_micro": "2018-01-09T07:58:29.493537

# Generated at 2022-06-23 01:07:39.582665
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
        myTestClass = DateTimeFactCollector()
        assert myTestClass is not None

# Generated at 2022-06-23 01:07:44.680371
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collector = DateTimeFactCollector()
    facts = collector.collect()
    # same result is got when calling "date -Iseconds"
    assert facts['date_time']['iso8601'] == datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')

# Generated at 2022-06-23 01:07:55.561803
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtf = DateTimeFactCollector()
    dtf_dict = dtf.collect()
    assert 'date_time' in dtf_dict
    assert dtf_dict['date_time']['year']
    assert dtf_dict['date_time']['month']
    assert dtf_dict['date_time']['weekday']
    assert dtf_dict['date_time']['weekday_number']
    assert dtf_dict['date_time']['weeknumber']
    assert dtf_dict['date_time']['day']
    assert dtf_dict['date_time']['hour']
    assert dtf_dict['date_time']['minute']
    assert dtf_dict['date_time']['second']

# Generated at 2022-06-23 01:07:58.154071
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_object = DateTimeFactCollector()
    assert date_time_object.name == 'date_time'
    assert len(date_time_object._fact_ids) == 0



# Generated at 2022-06-23 01:08:03.328060
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert isinstance(DateTimeFactCollector, object)
    assert DateTimeFactCollector.name == 'date_time'
    assert isinstance(DateTimeFactCollector._fact_ids, set)


# Generated at 2022-06-23 01:08:05.167009
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    assert DateTimeFactCollector.name == 'date_time'

# Generated at 2022-06-23 01:08:09.891224
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_obj = DateTimeFactCollector()
    test_dict = date_time_obj.collect()
    assert 'date_time' in test_dict
    assert 'epoch' in test_dict['date_time']
    assert 'date' in test_dict['date_time']

# Generated at 2022-06-23 01:08:13.975248
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    datetimefact = DateTimeFactCollector()
    assert datetimefact.name == 'date_time'
    assert datetimefact.priority == 80
    assert len(datetimefact._fact_ids) == 0



# Generated at 2022-06-23 01:08:17.879449
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.name == 'date_time'
    assert len(date_time_fact_collector._fact_ids) == 0


# Generated at 2022-06-23 01:08:21.060187
# Unit test for constructor of class DateTimeFactCollector
def test_DateTimeFactCollector():
    datetime_fact_collector = DateTimeFactCollector()
    assert datetime_fact_collector.name == 'date_time'
    assert datetime_fact_collector._fact_ids == set()