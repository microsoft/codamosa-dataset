

# Generated at 2022-06-12 17:56:50.036374
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 17:56:51.425361
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    i = LinuxAcademyIE()
    assert i.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-12 17:56:53.894585
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE("LinuxAcademyIE", "linuxacademy.com")

# Generated at 2022-06-12 17:57:03.847985
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'LinuxAcademy.com'
    assert ie.IE_DESC == 'Linux Academy: Cloud & Linux training'
    assert ie.EXTRACTOR_KEY == LinuxAcademyIE.ie_key()
    assert ie.IE_KEY == LinuxAcademyIE.ie_key()
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''


# Generated at 2022-06-12 17:57:06.829424
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    login = LinuxAcademyIE()
    # test if login is instance of LinuxAcademyIE
    assert isinstance(login, LinuxAcademyIE)

# Generated at 2022-06-12 17:57:07.418162
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-12 17:57:16.873184
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
  url = 'https://linuxacademy.com/api/v1/courses/7971/chapters/14737/lectures/136813'
  linuxacademyIE = LinuxAcademyIE(url)
  assert linuxacademyIE.get_url() == url
  assert linuxacademyIE.get_url_query() is None
  assert linuxacademyIE.get_url_query_dict() == {}
  assert linuxacademyIE.get_url_query_parameter("nonexisting") is None
  assert linuxacademyIE.get_url_query_parameter("nonexisting", "default") == "default"
  assert linuxacademyIE.get_url_query_parameter("nonexisting", default="default") == "default"
  assert linuxacademyIE.get_url

# Generated at 2022-06-12 17:57:27.551182
# Unit test for constructor of class LinuxAcademyIE

# Generated at 2022-06-12 17:57:28.480401
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()

# Generated at 2022-06-12 17:57:29.289057
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert instance



# Generated at 2022-06-12 17:57:46.425847
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()

# Generated at 2022-06-12 17:57:47.033848
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 17:57:48.403836
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE.LinuxAcademyIE._get_ie_class_by_key(LinuxAcademyIE.ie_key(), False)
    assert ie

# Generated at 2022-06-12 17:57:50.868556
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert(LinuxAcademyIE.__module__ == 'youtube_dl.extractor.linuxacademy')

# Generated at 2022-06-12 17:57:52.202049
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None, None)

# Generated at 2022-06-12 17:57:54.148385
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-12 17:58:05.524373
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    la_ie = LinuxAcademyIE('test-la')
    assert la_ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert la_ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert la_ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert la_ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-12 17:58:07.244163
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info_extractor = LinuxAcademyIE();
    assert info_extractor is not None

# Generated at 2022-06-12 17:58:13.729689
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE().ie_key() == 'LinuxAcademy'
    assert LinuxAcademyIE()._NETRC_MACHINE == 'linuxacademy'
    assert LinuxAcademyIE()._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert LinuxAcademyIE()._ORIGIN_URL == 'https://linuxacademy.com'
    assert LinuxAcademyIE()._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-12 17:58:24.425020
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/' \
                            '(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|' \
                            'modules/view/id/(?P<course_id>\d+))'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-12 17:59:19.928015
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test normal use case
    LinuxAcademyIE("https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2")
    # Test bad URL
    try:
        LinuxAcademyIE("https://www.youtube.com/watch?v=YsMKI1ZmWn0")
    except ExtractorError as e:
        assert e.args[0]
    # Test value error
    try:
        LinuxAcademyIE("")
    except ValueError as e:
        assert e.args[0]

# Generated at 2022-06-12 17:59:22.974075
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    i = LinuxAcademyIE()

c = LinuxAcademyIE()
c.extract('https://linuxacademy.com/cp/modules/view/id/154')

# Generated at 2022-06-12 17:59:25.705985
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():

    mock_config = {'login': 'test', 'password': '1234'}
    instance = LinuxAcademyIE(mock_config)
    # No exception should be raised by constructor
    assert instance

# Generated at 2022-06-12 17:59:32.084109
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE(): 
    info_extractor = LinuxAcademyIE(InfoExtractor(), 'linuxacademy', 'username', 'password')
    assert info_extractor._NETRC_MACHINE == 'linuxacademy'
    assert info_extractor._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert info_extractor._ORIGIN_URL == 'https://linuxacademy.com'
    assert info_extractor._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-12 17:59:40.486572
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Constructor test for class LinuxAcademyIE
    """
    info_extractor = LinuxAcademyIE()
    assert info_extractor._AUTHORIZE_URL == "https://login.linuxacademy.com/authorize"
    assert info_extractor._NETRC_MACHINE == "linuxacademy"
    assert info_extractor._CLIENT_ID == "KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx"
    assert info_extractor._ORIGIN_URL == "https://linuxacademy.com"

# Generated at 2022-06-12 17:59:41.952626
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 17:59:42.991902
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None)

# Generated at 2022-06-12 17:59:48.532341
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    'Constructor works with valid urls'
    valid_urls = [
        'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2',
        'https://linuxacademy.com/cp/modules/view/id/154',
    ]
    for url in valid_urls:
        LinuxAcademyIE._real_initialize(LinuxAcademyIE(url))

# Generated at 2022-06-12 17:59:58.518888
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.NETRC_MACHINE == 'linuxacademy'
    assert ie._VALID_URL == 'https?://(?:www\\.)?linuxacademy\\.com/cp/(?:courses/lesson/course/\\d+/lesson/\\d+|modules/view/id/\\d+)'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-12 18:00:02.120824
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = "https://linuxacademy.com/cp/modules/view/id/154"
    ie = LinuxAcademyIE()
    # test_login()
    # test_real_initialize()
    # test_real_extract()

# Generated at 2022-06-12 18:01:42.727471
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    '''
    Unit test of constructor for class LinuxAcademyIE. This test should not
    throw an exception.
    '''
    LinuxAcademyIE()

# Generated at 2022-06-12 18:01:44.308411
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    Youtube().initialize()
    INSTANCE = LinuxAcademyIE()
test_LinuxAcademyIE()

# Generated at 2022-06-12 18:01:46.598958
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Unit test for constructor of class LinuxAcademyIE
    """
    la = LinuxAcademyIE()
    assert la is not None


# Generated at 2022-06-12 18:01:49.195939
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Incorrect URL
    assert LinuxAcademyIE.suitable('https://incorrect.url') == False
    assert LinuxAcademyIE.suitable('https://linuxacademy.com/cp/') == False

# Generated at 2022-06-12 18:01:51.982980
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE('LinuxAcademy', 'windowsacademy')
    assert ie.get_settings() == [('username', 'Uploader username'), ('password', 'Uploader password')]


# Generated at 2022-06-12 18:01:56.525657
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie_ = LinuxAcademyIE()
    assert ie_._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie_._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie_._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie_._NETRC_MACHINE == 'linuxacademy'


# Generated at 2022-06-12 18:01:57.967064
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE(): assert LinuxAcademyIE('https://linuxacademy.com/cp/modules/item/id/154')

# Generated at 2022-06-12 18:02:03.967893
# Unit test for constructor of class LinuxAcademyIE

# Generated at 2022-06-12 18:02:13.406869
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    class ConstructorTestLinuxAcademyIE(LinuxAcademyIE):
        IE_NAME = 'linuxacademy.com'
        IE_DESC = True  # Do not list
        _VALID_URL = r'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/.*/lesson/.*'

        _TESTS = [{
            'url': 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
            'only_matching': True,
        }]

        def _real_initialize(self):
            raise NotImplementedError()

        def _real_extract(self, url):
            raise NotImplementedError()
    return ConstructorTestLinuxAcademyIE

# Generated at 2022-06-12 18:02:14.713447
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    IE = LinuxAcademyIE(None)
    assert isinstance(IE, LinuxAcademyIE)

# Generated at 2022-06-12 18:05:39.047060
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() is not None

# Generated at 2022-06-12 18:05:40.635460
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE(None)
    except:
        print('LinuxAcademyIE constructor failed')


# Generated at 2022-06-12 18:05:41.248052
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 18:05:42.633671
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)

# Generated at 2022-06-12 18:05:49.736868
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_linuxacademy import (
        _CLIENT_ID, _NETRC_MACHINE, _PASSWORD, _USERNAME)
    from ..netrc import _NETRC_MACHINE_TOKEN, _NETRC_MACHINE_USERNAME
    obj = LinuxAcademyIE()
    assert obj.CLIENT_ID == _CLIENT_ID
    assert obj.NETRC_MACHINE == _NETRC_MACHINE
    assert obj.AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert obj.ORIGIN_URL == 'https://linuxacademy.com'
    assert obj.BASE_URL == 'https://linuxacademy.com/cp'

# Generated at 2022-06-12 18:05:51.274879
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-12 18:05:51.973147
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_obj = LinuxAcademyIE()
    assert test_obj

# Generated at 2022-06-12 18:05:53.412491
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()

# Generated at 2022-06-12 18:05:55.504691
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Unit test for constructor of class LinuxAcademyIE."""
    LinuxAcademyIE('test')

# Generated at 2022-06-12 18:05:59.110644
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Get a LinuxAcademyIE object of object type InfoExtractor from config
    ie = LinuxAcademyIE()
    # Check if it's an InfoExtractor object
    assert type(ie) == InfoExtractor
    # Check if has 'linuxacademy' URL pattern in ie._VALID_URL
    assert ie._VALID_URL, ie._VALID_URL
    # Check if has 'linuxacademy' in ie._NETRC_MACHINE
    assert ie._NETRC_MACHINE, ie._NETRC_MACHINE

