

# Generated at 2022-06-12 17:56:49.407733
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE().ie_key() == 'LinuxAcademy'



# Generated at 2022-06-12 17:56:51.090651
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    if ie is not None:
        print("LinuxAcademyIE Constructor is not implemented")


# Generated at 2022-06-12 17:56:55.214667
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test with a username and password.
    LinuxAcademyIE(
        LinuxAcademyIE._create_alternate_ie(
            LinuxAcademyIE, 'linuxacademyusername', 'linuxacademypassword')
    )
    # Test with no username and password.
    LinuxAcademyIE(
        LinuxAcademyIE._create_alternate_ie(LinuxAcademyIE)
    )

# Generated at 2022-06-12 17:56:56.509338
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'linuxacademy'


# Generated at 2022-06-12 17:56:58.591077
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Unit tests for constructor of class LinuxAcademyIE.
    """
    IE_linuxacademy = LinuxAcademyIE()
    print('LinuxAcademyIE constructor: %s' % IE_linuxacademy)


# Generated at 2022-06-12 17:57:03.346036
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    if 'linuxacademy' not in {x.name for x in InfoExtractor._ies}:
        raise AssertionError('Unit test for LinuxAcademyIE must be performed after declaration of this class')
    if 'LinuxAcademy' not in InfoExtractor._ALL_CLASSES:
        raise AssertionError('WindowsAzureIE does not exist in InfoExtractor._ALL_CLASSES')
    return LinuxAcademyIE

# Generated at 2022-06-12 17:57:08.498787
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    successful_constructor_test_message = 'Successful constructor test'
    failed_constructor_test_message = 'Failed constructor test'

    if LinuxAcademyIE is not None:
        print(successful_constructor_test_message)
    else:
        print(failed_constructor_test_message)

# Generated at 2022-06-12 17:57:17.482350
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME.lower() == 'linuxacademy'
    assert ie.IE_DESC.lower() == 'linux academy'
    assert ie._VALID_URL.lower() == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'

# Generated at 2022-06-12 17:57:19.056843
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert issubclass(LinuxAcademyIE, InfoExtractor)

# Generated at 2022-06-12 17:57:20.586267
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE('foo', 'bar')
    assert ie.username == 'foo'
    assert ie.password == 'bar'

# Generated at 2022-06-12 17:57:57.029865
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-12 17:58:01.125468
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._valid_url("""https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675""")
    assert ie._valid_url("""https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2""")
    assert ie._valid_url("""https://linuxacademy.com/cp/modules/view/id/154""")

# Generated at 2022-06-12 17:58:05.638603
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-12 17:58:12.462144
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LAIE = LinuxAcademyIE()
    assert LAIE.IE_NAME == "linuxacademy"
    assert LAIE._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-12 17:58:15.948374
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_ie = LinuxAcademyIE();
    assert linux_academy_ie.IE_NAME == 'linuxacademy'
    assert linux_academy_ie.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-12 17:58:17.067615
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 17:58:19.130677
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_importer import TestImporter
    LinuxAcademyIE()
    TestImporter()

# Generated at 2022-06-12 17:58:20.762210
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    print(ie)

# Generated at 2022-06-12 17:58:28.783703
# Unit test for constructor of class LinuxAcademyIE

# Generated at 2022-06-12 17:58:29.456819
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 17:59:54.657101
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 17:59:56.047133
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE.ie_key()

# Generated at 2022-06-12 18:00:03.183073
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_urls = ['https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
                 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2',
                 'https://linuxacademy.com/cp/modules/view/id/154']
    for url in test_urls:
        obj = LinuxAcademyIE()
        obj._real_initialize()
        obj._real_extract(url)

# Generated at 2022-06-12 18:00:11.659706
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE('LinuxAcademy', 'linuxacademy')
    assert ie._downloader.username == 'LinuxAcademy'
    assert ie._downloader.password == 'linuxacademy'
    assert ie._downloader.params['username'] == 'LinuxAcademy'
    assert ie._downloader.params['password'] == 'linuxacademy'
    assert ie.username == 'LinuxAcademy'
    assert ie.password == 'linuxacademy'
    assert ie.params['username'] == 'LinuxAcademy'
    assert ie.params['password'] == 'linuxacademy'
    assert not ie._downloader.params.get('videopassword') and not ie.params.get('videopassword')
    assert not ie._downloader.params.get('usenetrc')

# Generated at 2022-06-12 18:00:13.820586
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 18:00:15.150318
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 18:00:16.039350
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 18:00:17.644902
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print(LinuxAcademyIE._CLIENT_ID)
    return LinuxAcademyIE

# Generated at 2022-06-12 18:00:20.371829
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info_extractor = LinuxAcademyIE()
    assert 'LinuxAcademy' in str(info_extractor)
    assert 'LinuxAcademyIE' in str(info_extractor)

# Generated at 2022-06-12 18:00:21.446644
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()

# Generated at 2022-06-12 18:03:51.538330
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # download sample video file
    # open('linuxAcademy.file', 'wb').write(
    #    LinuxAcademyIE._download_webpage_handle(
    #        'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2', None, 'Downloading video file')[0].read())
    # create instance of class LinuxAcademy
    LinuxAcademy_instance = LinuxAcademyIE()
    # test parse()
    LinuxAcademy_instance._real_extract(
        'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')

# Generated at 2022-06-12 18:03:59.485305
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.__class__.__name__ == 'LinuxAcademyIE'
    assert ie._LOGIN_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._NETRC_MACHINE == 'linuxacademy'

    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.working == True

    assert ie._VALID_URL == '''(?x)https?://(?:www\\.)?linuxacademy\\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|modules/view/id/(?P<course_id>\\d+))'''

# Generated at 2022-06-12 18:04:03.659412
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    chapter_id, course_id, lecture_id = '7971', '', '2'
    mobj = re.match(LinuxAcademyIE._VALID_URL, url)
    assert chapter_id == mobj.group('chapter_id')
    assert course_id == mobj.group('course_id')
    assert lecture_id == mobj.group('lesson_id')

# Generated at 2022-06-12 18:04:04.561016
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # case 1:
    LinuxAcademyIE()._login()

# Generated at 2022-06-12 18:04:09.292852
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Unit test for constructor of class LinuxAcademyIE."""
    url = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    valid_url_match = r'https?://(?:www\.)?linuxacademy\.com/cp/.+/\d+'
    invalid_url_match = r'https?://(?:www\.)?linuxacademy\.com/cp/.+/\d+/\d+'
    with pytest.raises(RegexNotFoundError) as e:
        LinuxAcademyIE._valid_url(url, invalid_url_match)
    with pytest.raises(RegexNotFoundError) as e:
        LinuxAcademyIE._valid_url(url, valid_url_match)

# Generated at 2022-06-12 18:04:17.621871
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert(
        LinuxAcademyIE(None)._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    )
    assert(
        LinuxAcademyIE(None)._ORIGIN_URL == 'https://linuxacademy.com'
    )
    assert(
        LinuxAcademyIE(None)._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    )
    assert(
        LinuxAcademyIE(None)._NETRC_MACHINE == 'linuxacademy'
    )

# Generated at 2022-06-12 18:04:18.308900
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    return test_LinuxAcademyIE()

# Generated at 2022-06-12 18:04:19.389519
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    tk = LinuxAcademyIE()
    assert tk.utility_type == LinuxAcademyIE

# Generated at 2022-06-12 18:04:20.010649
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 18:04:21.636806
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()
