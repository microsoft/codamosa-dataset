

# Generated at 2022-06-12 17:56:53.323084
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test LinuxAcademyIE constructor
    ie = LinuxAcademyIE("LinuxAcademyIE", "")
    assert ie is not None

# Generated at 2022-06-12 17:56:57.582380
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    l = LinuxAcademyIE(None)
    l._login()


test_cases = [{
    'url': 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
    'only_matching': True,
}, {
    'url': 'https://linuxacademy.com/cp/modules/view/id/154',
    'only_matching': True,
}]

# Generated at 2022-06-12 17:56:59.752357
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie is not None

# Generated at 2022-06-12 17:57:00.725254
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 17:57:03.646128
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ai = LinuxAcademyIE()
    assert ai.__class__.__name__ == "LinuxAcademyIE"

# Generated at 2022-06-12 17:57:14.519962
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-12 17:57:16.674828
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    t = LinuxAcademyIE()

# Generated at 2022-06-12 17:57:20.824910
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    command = LinuxAcademyIE()
    assert isinstance(command, InfoExtractor)

# Generated at 2022-06-12 17:57:32.735812
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|https?://(?:www\.)?linuxacademy\.com/cp/modules/view/id/(?P<course_id>\d+)'

# Generated at 2022-06-12 17:57:40.200473
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import re
    valid_urls = [
        'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
        'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2',
        'https://linuxacademy.com/cp/modules/view/id/154',
    ]
    url_pattern = re.compile(LinuxAcademyIE._VALID_URL)
    for url in valid_urls:
        assert url_pattern.match(url)


# Generated at 2022-06-12 17:58:14.624985
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 17:58:18.152132
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademy_ie = LinuxAcademyIE()
    assert linuxacademy_ie.ie_key() == LinuxAcademyIE.ie_key()
    assert linuxacademy_ie.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-12 17:58:27.479514
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import unittest
    from youtube_dl.utils import url_basename

    def mock_urlopen(request, *args, **kwargs):
        class MockURLOpen(object):
            def getcode(self):
                return 200


# Generated at 2022-06-12 17:58:28.664677
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, InfoExtractor)



# Generated at 2022-06-12 17:58:29.331217
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE("LinuxAcademy")

# Generated at 2022-06-12 17:58:30.366086
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Unit test constructor of class LinuxAcademyIE
    """
    LinuxAcademyIE()

# Generated at 2022-06-12 17:58:37.480864
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ies = LinuxAcademyIE()

# Generated at 2022-06-12 17:58:39.718462
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._NAME == 'linuxacademy'
    assert ie._VALID_URL == ie._VALID_URL

# Generated at 2022-06-12 17:58:49.151742
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    course_id = '154'
    url = 'https://linuxacademy.com/cp/modules/view/id/' + course_id
    actual = LinuxAcademyIE()._real_extract(url)

# Generated at 2022-06-12 17:58:53.537998
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Run test with credentials from the environment
    username = os.environ.get('LINUX_ACADEMY_USERNAME')
    password = os.environ.get('LINUX_ACADEMY_PASSWORD')
    if username and password:
        assert LinuxAcademyIE._login(
            LinuxAcademyIE(), username, password)
        assert LinuxAcademyIE.suitable(
            LinuxAcademyIE.ie_key(), 'LinuxAcademy')

# Generated at 2022-06-12 17:59:42.445871
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')

# Generated at 2022-06-12 17:59:43.451096
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 17:59:51.239800
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    constructor = LinuxAcademyIE(fallback=False)
    assert constructor.IE_NAME == 'LinuxAcademy'
    assert constructor.VALID_URL == 'https://linuxacademy.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert constructor.AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert constructor.ORIGIN_URL == 'https://linuxacademy.com'
    assert constructor.CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert constructor.NETRC_MACHINE == 'linuxacademy'
    assert constructor.headers == {}
   

# Generated at 2022-06-12 17:59:53.204752
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
	assert LinuxAcademyIE(LinuxAcademyIE.ie_key()) == LinuxAcademyIE

# Generated at 2022-06-12 18:00:01.216525
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test 1: input with all required fields
    # Returns a LinuxAcademyIE object
    assert isinstance(
        LinuxAcademyIE(
            LinuxAcademyIE.ie_key(),
            LinuxAcademyIE._VALID_URL,
            {}),
        LinuxAcademyIE)

    # Test 2: input with only one required field
    # Should raise an AssertionError because of missing required fields
    try:
        LinuxAcademyIE(LinuxAcademyIE.ie_key())
    except AssertionError:
        pass

    # Test 3: input with invalid URL
    # Should raise an ExtractorError because of invalid URL
    # Either wrap the assertRaises with a try-catch block or use context manager:

# Generated at 2022-06-12 18:00:10.245666
# Unit test for constructor of class LinuxAcademyIE

# Generated at 2022-06-12 18:00:13.788488
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import unittest
    # TODO: add more tests.

    class LinuxAcademyIETest(unittest.TestCase):
        def test_class_creation(self):
            ie = LinuxAcademyIE()
            self.assertIsInstance(ie, LinuxAcademyIE,
                                  'LinuxAcademyIE class creation failed.')

    unittest.main()

# Generated at 2022-06-12 18:00:17.294208
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    result = LinuxAcademyIE('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675','/usr/local/bin/youtube-dl')

# Generated at 2022-06-12 18:00:19.057514
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()


if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-12 18:00:25.539298
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    L = LinuxAcademyIE()
    assert L._NETRC_MACHINE == 'linuxacademy'
    assert L._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert L._ORIGIN_URL == 'https://linuxacademy.com'
    assert L._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'

# Generated at 2022-06-12 18:02:25.059364
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'
    assert LinuxAcademyIE.ie_key() != 'LinuxAcademY'

# Generated at 2022-06-12 18:02:25.938420
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.login()

# Generated at 2022-06-12 18:02:26.569033
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE

# Generated at 2022-06-12 18:02:27.215406
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 18:02:31.796495
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # pylint: disable=protected-access
    ie = LinuxAcademyIE('LinuxAcademy')
    assert ie.name == 'LinuxAcademy'
    assert ie.ie_key() == 'LinuxAcademy'
    assert re.match(ie._VALID_URL, 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    assert re.match(ie._VALID_URL, 'https://linuxacademy.com/cp/modules/view/id/154')
    assert re.match(ie._VALID_URL, 'https://www.linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')

# Generated at 2022-06-12 18:02:34.581002
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test creation and initialization of class LinuxAcademyIE"""
    loaded = LinuxAcademyIE()
    assert loaded is not None

# Generated at 2022-06-12 18:02:38.366850
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://www.linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    class_LinuxAcademyIE = LinuxAcademyIE(url)
    assert isinstance(class_LinuxAcademyIE, LinuxAcademyIE)

# Generated at 2022-06-12 18:02:41.223805
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._TESTS
    ie._real_initialize()

# Generated at 2022-06-12 18:02:49.614858
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'

    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''


# Generated at 2022-06-12 18:02:50.883103
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()