

# Generated at 2022-06-12 17:56:54.632065
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE().ie_key() == "LinuxAcademy"

# Generated at 2022-06-12 17:56:59.274460
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # basic sanity test
    try:
        u = LinuxAcademyIE(duration=200)
        assert u.duration == 200
        assert u._login == u._real_initialize
    except AttributeError as e:
        print(e)
        assert False

# Generated at 2022-06-12 17:57:02.671483
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    a = LinuxAcademyIE()
    assert isinstance(a._AUTHORIZE_URL, compat_str)
    assert isinstance(a._ORIGIN_URL, compat_str)
    assert isinstance(a._CLIENT_ID, compat_str)

# Generated at 2022-06-12 17:57:12.139229
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.is_info_extractor == True
    assert ie.IE_NAME == 'Linux Academy'
    assert ie.IE_DESC == 'Linux Academy online training platform'
    assert ie.IE_KEY == 'linuxacademy'
    assert ie._VALID_URL == 'https?://(?:www\\.)?linuxacademy\\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|modules/view/id/(?P<course_id>\\d+))'

# Generated at 2022-06-12 17:57:17.365159
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Unit test function for constructor of LinuxAcademyIE"""
    class_name = LinuxAcademyIE.__name__
    test_class = globals()[class_name]
    instance = test_class()
    assert isinstance(instance, LinuxAcademyIE)
    assert test_class.ie_key() == 'LinuxAcademy'
    assert test_class.ie_key_no_ie() == 'LinuxAcademy'
    assert class_name in LinuxAcademyIE.__doc__


# Generated at 2022-06-12 17:57:20.651449
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE().ie_key() == 'LinuxAcademy'

# Generated at 2022-06-12 17:57:21.370493
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 17:57:32.460538
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    test_url = "https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675"
    info = ie.extract(test_url)
    assert info.get('title') == 'What Is Data Science'
    assert info.get('id') == '7971-2'
    assert info.get('chapter_id') == '7971'
    assert info.get('chapter_number') == 1
    assert info.get('chapter') == 'Data Science Foundations'
    assert len(info.get('formats')) == 4
    assert info.get('formats')[0].get('ext') == 'mp4'
test_LinuxAcademyIE()

# Generated at 2022-06-12 17:57:41.346632
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_obj = LinuxAcademyIE()
    assert test_obj._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert test_obj._TESTS
    assert test_obj._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert test_obj._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-12 17:57:43.592171
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert isinstance(instance, LinuxAcademyIE)

# Generated at 2022-06-12 17:58:05.790385
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test constructor of LinuxAcademyIE"""
    ie_obj = LinuxAcademyIE('video', None, None)
    assert(ie_obj.is_login_required)

# Generated at 2022-06-12 17:58:07.953537
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LA = LinuxAcademyIE()
    # No login info
    LA._real_initialize()
    # Login info
    LA = LinuxAcademyIE()
    LA._real_initialize()

# Generated at 2022-06-12 17:58:09.110635
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    global LinuxAcademyIE
    LinuxAcademyIE = LinuxAcademyIE('test')
    assert LinuxAcademyIE == 'test'

# Generated at 2022-06-12 17:58:11.105248
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE(None).get_testcase_templates() != LinuxAcademyIE.get_testcase_templates()

# Generated at 2022-06-12 17:58:17.796264
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

    assert(ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize')
    assert(ie._ORIGIN_URL == 'https://linuxacademy.com')
    assert(ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx')
    assert(ie._NETRC_MACHINE == 'linuxacademy')

# Generated at 2022-06-12 17:58:21.433230
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_ie_instance = LinuxAcademyIE()
    assert(test_ie_instance.ie_key() == 'LinuxAcademy')
    assert(test_ie_instance.IE_NAME == 'linuxacademy')

# Generated at 2022-06-12 17:58:24.500348
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    # Check for login
    ie.login = lambda: None
    ie._real_initialize()
    assert ie._login == LinuxAcademyIE._login, "Test for login failed!"


# Generated at 2022-06-12 17:58:27.569606
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
        NOTE: we should use classmethods here.
    """
    # TESTS
    # TEST 1, no netrc
    ie = LinuxAcademyIE()

    with pytest.raises(ExtractorError) as e:
        ie.__init__()


# Generated at 2022-06-12 17:58:28.244867
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxAcademyIE = LinuxAcademyIE()

# Generated at 2022-06-12 17:58:28.677993
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-12 17:58:59.625955
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test attribute existence
    ie = LinuxAcademyIE(InfoExtractor())
    assert ie.client_id
    assert ie.origin_url

# Generated at 2022-06-12 17:59:00.349698
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 17:59:01.054872
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 17:59:02.094332
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 17:59:04.016601
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
    except:
        return True
    return False

if __name__ == '__main__':
    print(test_LinuxAcademyIE())

# Generated at 2022-06-12 17:59:09.410201
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    def test_func(module_name, module_id, **kwargs):
        instance = LinuxAcademyIE()
        assert instance.suitable(None, 'https://linuxacademy.com/cp/modules/view/id/%s' % module_id)
        assert instance._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
        assert instance._NETRC_MACHINE == 'linuxacademy'
        assert instance.IE_NAME == 'linuxacademy'

        return instance(url='https://linuxacademy.com/cp/modules/view/id/%s' % module_id, **kwargs)


# Generated at 2022-06-12 17:59:11.739377
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE._NETRC_MACHINE == "linuxacademy"
    assert LinuxAcademyIE._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-12 17:59:15.128520
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE().IE_NAME == "LinuxAcademy"


# Generated at 2022-06-12 17:59:16.626596
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    x = LinuxAcademyIE()
    print(x)
  
if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-12 17:59:23.503739
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    '''
    Function for testing constructor of class LinuxAcademyIE
    '''
    linuxacademy_ie = LinuxAcademyIE()
    assert linuxacademy_ie._VALID_URL == r'(?x)\Ahttps?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))\Z'

# Generated at 2022-06-12 18:00:10.206910
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Arrange
    test_url = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    # Act
    linux_academy_ie = LinuxAcademyIE()
    # Assert
    assert linux_academy_ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-12 18:00:11.325528
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._real_initialize() is None

# Generated at 2022-06-12 18:00:19.994129
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import os, sys
    username = os.environ.get('LINUXACADEMY_USERNAME', None)
    password = os.environ.get('LINUXACADEMY_PASSWORD', None)
    if username is None or password is None:
        sys.stderr.write('Please provide Linux Academy username and password with environment variables LINUXACADEMY_USERNAME and LINUXACADEMY_PASSWORD!\n')
        sys.exit(-1)

    ie = LinuxAcademyIE()
    ie._login()

# Generated at 2022-06-12 18:00:26.358110
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert(ie._AUTHORIZE_URL == "https://login.linuxacademy.com/authorize")
    assert(ie._ORIGIN_URL == "https://linuxacademy.com")
    assert(ie._CLIENT_ID == "KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx")
    assert(ie._NETRC_MACHINE == "linuxacademy")

# Generated at 2022-06-12 18:00:37.106817
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test method extractor.LinuxAcademyIE.__init__()"""
    # From https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675

    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'

    extractor = LinuxAcademyIE()
    extractor.initialize()

    # Extractor URL
    assert (extractor._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/\d+/lesson/\d+|https?://(?:www\.)?linuxacademy\.com/cp/modules/view/id/\d+')

    # Test fields

# Generated at 2022-06-12 18:00:45.393120
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_linuxacademy import TEST_LINUXACADEMY
    from .test_linuxacademy import TEST_LINUXACADEMY_PLAYLIST
    from .test_linuxacademy import mock_extractor_of

    ie = mock_extractor_of(LinuxAcademyIE)
    # loading modules, but only ones that are needed
    ie.extractors = [
        'internal:linuxacademy',
        'internal:extractor_test_linuxacademy',
    ]
    ie._login()
    ie._real_extract(TEST_LINUXACADEMY_PLAYLIST)
    ie._real_extract(TEST_LINUXACADEMY)

# Generated at 2022-06-12 18:00:46.538767
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.name == 'linuxacademy'


# Generated at 2022-06-12 18:00:48.214287
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 18:00:51.883408
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    test_LinuxAcademyIE()

    Invoke the constructor of class LinuxAcademyIE
    with a valid url and valid credentials. Verify that
    the attributes are set correctly.
    """

    ie = LinuxAcademyIE()
    ie._login()
    assert ie._username == 'linuxacademy_unittest'
    assert ie._password == 'linuxacademy_unittest'

# Generated at 2022-06-12 18:00:56.321285
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert LinuxAcademyIE._ORIGIN_URL == 'https://linuxacademy.com'
    assert LinuxAcademyIE._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-12 18:02:50.272257
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-12 18:02:52.191993
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE(None)._NETRC_MACHINE == 'linuxacademy'


# Generated at 2022-06-12 18:02:53.847681
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 18:02:55.858044
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == "LinuxAcademy"


# Generated at 2022-06-12 18:02:57.198908
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 18:03:04.836156
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.generic import GenericIE
    ydl = YoutubeDL({'username': 'john@doe.com', 'password': '123', 'force_generic_extractor': True})
    ie = GenericIE._get_info_extractor(ydl, 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    assert isinstance(ie, LinuxAcademyIE)

# Generated at 2022-06-12 18:03:05.605341
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 18:03:07.137452
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'LinuxAcademy.com'


# Generated at 2022-06-12 18:03:11.086398
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.SUCCESS == 'SUCCESS'
    assert ie.extractor_key == 'LinuxAcademy'
    assert ie.extractor_key == 'LinuxAcademy'

# Generated at 2022-06-12 18:03:15.726926
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test the code to construct the object
    # LinuxAcademyIE('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    return