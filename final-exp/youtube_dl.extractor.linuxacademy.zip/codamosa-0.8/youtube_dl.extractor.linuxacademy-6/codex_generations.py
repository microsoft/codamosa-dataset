

# Generated at 2022-06-12 17:56:52.252491
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)


# Generated at 2022-06-12 17:56:54.667167
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('LinuxAcademy')

# Generated at 2022-06-12 17:56:55.547836
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 17:56:58.228508
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)

# Generated at 2022-06-12 17:57:04.082990
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE('https://not-existing.linuxacademy.com')
    test_cases = [('http://linuxacademy.com/cp/courses/lesson/course/123/lesson/1', '123-1')]
    for url, expected_id in test_cases:
        assert ie._real_extract(url)['id'] == expected_id

# Generated at 2022-06-12 17:57:09.227944
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE().extract_info('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    LinuxAcademyIE().extract_info('https://linuxacademy.com/cp/modules/view/id/154')

# Generated at 2022-06-12 17:57:12.563271
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Create an instance of class of LinuxAcademyIE
    ie = LinuxAcademyIE()
    # Verify that RealDebridIE is an instance of YoutubeIE
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 17:57:18.623373
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    attributes = vars(LinuxAcademyIE(InfoExtractor))
    assert attributes['_VALID_URL'] == LinuxAcademyIE._VALID_URL
    assert attributes['_TESTS'] == LinuxAcademyIE._TESTS
    assert attributes['_AUTHORIZE_URL'] == LinuxAcademyIE._AUTHORIZE_URL
    assert attributes['_ORIGIN_URL'] == LinuxAcademyIE._ORIGIN_URL
    assert attributes['_CLIENT_ID'] == LinuxAcademyIE._CLIENT_ID
    assert attributes['_NETRC_MACHINE'] == LinuxAcademyIE._NETRC_MACHINE
test_LinuxAcademyIE()

# Generated at 2022-06-12 17:57:25.281686
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # pylint: disable=protected-access
    assert LinuxAcademyIE._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-12 17:57:27.101263
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_LinuxAcademyIE = LinuxAcademyIE()
    assert test_LinuxAcademyIE

# Generated at 2022-06-12 17:57:51.058164
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test a valid url
    url = LinuxAcademyIE()._VALID_URL
    mobj = re.match(LinuxAcademyIE._VALID_URL, url)
    assert mobj
    assert url == 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    assert mobj.group('chapter_id') == '7971'
    assert mobj.group('lesson_id') == '2'
    assert mobj.group('course_id') is None

    # Test another valid url
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    mobj = re.match(LinuxAcademyIE._VALID_URL, url)
    assert mobj

# Generated at 2022-06-12 17:57:53.935990
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.__class__.__name__ == 'LinuxAcademyIE'
    

# Generated at 2022-06-12 17:58:00.197512
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():

    # Unit test for constructor of class LinuxAcademyIE with test url
    ie = LinuxAcademyIE(url="https://linuxacademy.com/cp/modules/view/id/154")
    assert ie.url == "https://linuxacademy.com/cp/modules/view/id/154"
    assert ie.id == "154"

# Generated at 2022-06-12 17:58:08.505638
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie=LinuxAcademyIE()
    assert ie._VALID_URL==r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-12 17:58:09.833224
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    Ie = LinuxAcademyIE(None)
    assert Ie.login() == True

# Generated at 2022-06-12 17:58:13.246117
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """ Tests whether constructor of class LinuxAcademyIE exists and is callable """
    instance = LinuxAcademyIE()
    assert 'LinuxAcademy' in instance.IE_NAME
    assert 'LinuxAcademy' in instance.ie_key()
    assert instance is not None


# Generated at 2022-06-12 17:58:15.105711
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    if __name__ == '__main__':
        test_LinuxAcademyIE()


# Generated at 2022-06-12 17:58:25.369521
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE();
    assert ie.IE_NAME == 'LinuxAcademy'
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.server_url == 'https://s.pythonanywhere.com/extractors/LinuxAcademy'
    assert ie.host == 'linuxacademy.com'
    assert ie._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/' + \
        '(?:courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|' + \
        'modules/view/id/(?P<course_id>\\d+))' 
    assert ie._NETRC_MACHINE == 'linuxacademy'
   

# Generated at 2022-06-12 17:58:28.958799
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        testcase = LinuxAcademyIE('youtube')
        error = 'testcase: \'{}\', expected: \'{}\', received: \'{}\''.format(type(testcase), '__main__.LinuxAcademyIE', type(testcase))
        assert type(testcase) is LinuxAcademyIE
    except AssertionError as e:
        print(e, error)


# Generated at 2022-06-12 17:58:31.946603
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    filename = "LinuxAcademyIE.py"
    version = "v0.0.1"
    description = "Linux Academy Downloader"
    LinuxAcademyIE()

# Generated at 2022-06-12 17:59:31.868444
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
    except Exception:
        assert False

# Generated at 2022-06-12 17:59:33.515369
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert(ie is not None)

# Generated at 2022-06-12 17:59:35.213403
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
    except Exception:
        raise AssertionError("Unexpected Exception raised " +
                             "when creating an object of LinuxAcademyIE")

# Generated at 2022-06-12 17:59:43.959334
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    lsit = LinuxAcademyIE()
    print(lsit._VALID_URL)
    print(lsit._TESTS)
    print(lsit._AUTHORIZE_URL)
    print(lsit._ORIGIN_URL)
    print(lsit._CLIENT_ID)
    print(lsit._NETRC_MACHINE)
    # print(lsit._real_initialize())


if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-12 17:59:44.881717
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 17:59:47.307266
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        la_ie = LinuxAcademyIE()
    except:
        print("Failed to initialize the constructor.")

# Generated at 2022-06-12 17:59:48.665962
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('test', 'LinuxAcademy')

# Generated at 2022-06-12 17:59:50.877868
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert (isinstance(instance, LinuxAcademyIE))

# Generated at 2022-06-12 17:59:52.949848
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademyIE = LinuxAcademyIE()
    print(linuxacademyIE)

# Generated at 2022-06-12 18:00:01.027822
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Test the LinuxAcademyIE class constructor
    """
    infoExtractor = LinuxAcademyIE()

# Generated at 2022-06-12 18:02:08.677110
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.IE_NAME == 'LinuxAcademy'
    assert ie.IE_DESC == 'linuxacademy.com courses'
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN

# Generated at 2022-06-12 18:02:09.816117
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE("LinuxAcademy")
    assert instance

# Generated at 2022-06-12 18:02:12.508170
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # test LinuxAcademyIE
    test_video = LinuxAcademyIE()

    print("Testing LinuxAcademyIE module")
    test_video._login()

# Generated at 2022-06-12 18:02:13.275565
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 18:02:22.076604
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import io
    import unittest.mock

    class FakeResponse:
        def __init__(self, status):
            self.status = status

        def read(self):
            return b'{ "description": "%s" }' % status

    def fake_urlopen(conn):
        return FakeResponse(conn.headers['authorization'])

    with unittest.mock.patch('urllib.request.urlopen', fake_urlopen):
        with io.open('test_data/linuxacademy_login_error.html', encoding='utf-8') as f:
            course_webpage = f.read()

        ie = LinuxAcademyIE()
        ie.extract(course_webpage)
        assert ie.username == 'johndoe'

# Generated at 2022-06-12 18:02:22.803432
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 18:02:25.911223
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert instance.name == 'linuxacademy'
    assert LinuxAcademyIE._VALID_URL == r'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'

# Generated at 2022-06-12 18:02:26.749881
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-12 18:02:27.423299
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()._login()

# Generated at 2022-06-12 18:02:32.547910
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == LinuxAcademyIE._VALID_URL
    assert ie._AUTHORIZE_URL == LinuxAcademyIE._AUTHORIZE_URL
    assert ie._ORIGIN_URL == LinuxAcademyIE._ORIGIN_URL
    assert ie._NETRC_MACHINE == LinuxAcademyIE._NETRC_MACHINE
    assert ie._CLIENT_ID == LinuxAcademyIE._CLIENT_ID
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.suitable('') == False
    assert ie.suitable(url) == True
    assert ie.get_real