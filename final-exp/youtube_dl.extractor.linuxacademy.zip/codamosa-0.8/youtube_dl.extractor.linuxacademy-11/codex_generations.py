

# Generated at 2022-06-12 17:56:47.774262
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 17:56:48.597912
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()


# Generated at 2022-06-12 17:56:51.052666
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    class_ = LinuxAcademyIE
    obj = class_()
    assert obj is not None

if __name__ == '__main__':
    test_LinuxAcademyIE()
    print("All tests successfully passed")

# Generated at 2022-06-12 17:56:57.267079
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    account_info = {
        'login': 'your username',
        'password': 'your password',
    }
    linuxacademy = LinuxAcademyIE(account_info)
    assert linuxacademy._NETRC_MACHINE == "linuxacademy"
    assert linuxacademy._CLIENT_ID == "KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx"
    assert linuxacademy._ORIGIN_URL == "https://linuxacademy.com"
    assert linuxacademy._AUTHORIZE_URL == "https://login.linuxacademy.com/authorize"

# Generated at 2022-06-12 17:57:00.398699
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    '''LinuxAcademyIE test'''
    # LinuxAcademyIE(InfoExtractor) test
    LinuxAcademyIE_instance = LinuxAcademyIE()


# Generated at 2022-06-12 17:57:12.732455
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert obj.IE_NAME == 'linuxacademy'
    assert obj._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|modules/view/id/(?P<course_id>\\d+))'
    assert obj._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert obj._ORIGIN_URL == 'https://linuxacademy.com'
    assert obj._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert obj._NETRC

# Generated at 2022-06-12 17:57:13.633451
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('LinuxAcademy')

# Generated at 2022-06-12 17:57:19.527693
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE(
        'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')._VALID_URL == 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'

# Generated at 2022-06-12 17:57:20.242995
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(None)
    assert ie is not None

# Generated at 2022-06-12 17:57:21.704393
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_class = LinuxAcademyIE()
    assert test_class.ie_key() == 'LinuxAcademy'
    assert type(test_class.suitable(None)) == bool


# Generated at 2022-06-12 17:58:00.014535
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    global LinuxAcademyIE
    LinuxAcademyIE("Linux Academy", "https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675")

# Generated at 2022-06-12 17:58:02.294766
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert isinstance(instance, LinuxAcademyIE)
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-12 17:58:04.194656
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 17:58:05.143610
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 17:58:12.728934
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    valid_url = 'https://www.linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    adm = LinuxAcademyIE(None)
    mobj = adm._VALID_URL
    print(mobj)
    m = re.match(mobj, valid_url)
    print(m.group('chapter_id'))
    print(m.group('lesson_id'))
    print(m.group('course_id'))
    print(m.group('title'))
    print(m.group('description'))
    print(m.group('timestamp'))

# Generated at 2022-06-12 17:58:23.492089
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print("Testing constructor for class LinuxAcademyIE")
    myLinuxAcademyIE = LinuxAcademyIE(0, 0)
    print(myLinuxAcademyIE)
    # Example test for LinuxAcademyIE.ie_key()
    print("Testing LinuxAcademyIE.ie_key() for class LinuxAcademyIE")
    assert myLinuxAcademyIE.ie_key() == "linuxacademy"
    # Example test for LinuxAcademyIE._real_initialize()
    print("Testing LinuxAcademyIE._real_initialize() for class LinuxAcademyIE")
    myLinuxAcademyIE._real_initialize()
    assert myLinuxAcademyIE != None
    # Example test for LinuxAcademyIE._login()

# Generated at 2022-06-12 17:58:30.705525
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_urls = ['https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
                 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2',
                 'https://linuxacademy.com/cp/modules/view/id/154']
    test_account = {'username': 'username', 'password': 'password'}
    # Test login
    test_ie = LinuxAcademyIE()
    test_ie.login_account(test_account)
    # Test extract_info
    for test_url in test_urls:
        test_info = test_ie.extract_info(test_url)
        assert(len(test_info['formats']) == 1)

# Generated at 2022-06-12 17:58:37.962713
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        url = 'https://linuxacademy.com/cp/modules/view/id/154'
        course = LinuxAcademyIE().extract(url)
        course_json = '{}'.format(course)
        assert 'AWS Certified Cloud Practitioner' in course_json
    except Exception as e:
        print('unit test of class LinuxAcademyIE failed: {}'.format(e))


# Generated at 2022-06-12 17:58:40.673420
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert obj.IE_NAME == "LinuxAcademy"
    assert obj.IE_KEY == "LinuxAcademy"

# Generated at 2022-06-12 17:58:43.867895
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    message = 'Password for Linux Academy account not specified'
    try:
        LinuxAcademyIE()
    except Exception as e:
        assert message in str(e)
    else:
        assert False, 'No exception raised'

# Generated at 2022-06-12 18:00:15.258722
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)'
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'

# Generated at 2022-06-12 18:00:23.363764
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._NETRC_MACHINE == "linuxacademy"
    assert LinuxAcademyIE()._VALID_URL == r'https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'
    assert LinuxAcademyIE()._AUTHORIZE_URL == "https://login.linuxacademy.com/authorize"
    assert LinuxAcademyIE()._ORIGIN_URL == "https://linuxacademy.com"

# Generated at 2022-06-12 18:00:27.348526
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_utils import clear_test_cases
    clear_test_cases(__file__, 'test_LinuxAcademyIE')

    for test_case in LinuxAcademyIE._TESTS:
        try:
            ie = LinuxAcademyIE(test_case['url'])
        except TypeError as e:
            if not isinstance(e.args[0], re.error):
                raise
        else:
            if not ie:
                raise TypeError("LinuxAcademyIE(%s) instance is null" % test_case['url'])


if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-12 18:00:28.236994
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 18:00:29.837331
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Name of class of the object created by constructor
    assert(LinuxAcademyIE == LinuxAcademyIE()).__class__.__name__ == 'LinuxAcademyIE'

# Generated at 2022-06-12 18:00:30.867805
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test constructor of class LinuxAcademyIE"""
    assert LinuxAcademyIE(None) is not None

# Generated at 2022-06-12 18:00:31.484331
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie_obj = LinuxAcademyIE()

# Generated at 2022-06-12 18:00:36.802146
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Arrange
    _VALID_URL = r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    _AUTHORIZE_URL = 'https://login.linuxacademy.com/authorize'
    _ORIGIN_URL = 'https://linuxacademy.com'
    _CLIENT_ID = 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-12 18:00:38.272798
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """test LinuxAcademyIE"""
    # Test for constructor
    i = LinuxAcademyIE()


# Generated at 2022-06-12 18:00:42.037410
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from . import LinuxAcademyIE
    assert LinuxAcademyIE.ie_key() == 'linuxacademy'
    assert LinuxAcademyIE.ie_key(url='https://any_url.com') == 'linuxacademy'

# Generated at 2022-06-12 18:02:41.377088
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    e = LinuxAcademyIE()

# Generated at 2022-06-12 18:02:43.280631
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert instance is not None, "Has to return a Python object"

# Generated at 2022-06-12 18:02:47.516536
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Windows error message: '%1 is not a valid Win32 application.'
    # See https://github.com/ytdl-org/youtube-dl/issues/6114
    assert LinuxAcademyIE('LinuxAcademy')._NETRC_MACHINE == 'linuxacademy'
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-12 18:02:53.400893
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    if 'linuxacademy' in os.environ:
        ie = LinuxAcademyIE()
        assert ie.IE_NAME == 'linuxacademy'
        assert ie._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course(\d+)/lesson(\d+)'
        assert ie._NETRC_MACHINE == 'linuxacademy'
        # assert ie._LOGIN_URL == 'https://login.linuxacademy.com'
        assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
        assert ie._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-12 18:02:54.324510
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test = LinuxAcademyIE()

# Generated at 2022-06-12 18:03:04.701355
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE('LinuxAcademy')
    assert obj._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-12 18:03:06.736209
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('LinuxAcademy', 'www.linuxacademy.com/cp').login()

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-12 18:03:09.368394
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test constructor of class LinuxAcademyIE
    info_extractor = LinuxAcademyIE()

# Generated at 2022-06-12 18:03:14.080074
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        # issue raised in https://github.com/ytdl-org/youtube-dl/pull/16468
        ie = LinuxAcademyIE()._login()
    except KeyError:
        pass

# Generated at 2022-06-12 18:03:21.889874
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    try:
        test_urls = ['https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
                'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
                ]
        for url in test_urls:
            obj.extract(url)
    except Exception as e:
        print('Test Failed: %s' % e)


if __name__ == '__main__':
    test_LinuxAcademyIE()