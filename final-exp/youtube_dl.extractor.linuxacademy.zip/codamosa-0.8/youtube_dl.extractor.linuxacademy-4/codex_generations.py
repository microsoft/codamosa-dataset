

# Generated at 2022-06-12 17:57:02.905166
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.IE_NAME == 'linuxacademy'
    assert ie._VALID_URL == LinuxAcademyIE._VALID_URL
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie._TESTS == LinuxAcademyIE._TESTS
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-12 17:57:03.878402
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE is not None

# Generated at 2022-06-12 17:57:06.830550
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test LinuxAcademyIE constructor"""
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)

# Generated at 2022-06-12 17:57:09.272395
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    with pytest.raises(ExtractorError, match=r'^Wrong login info$'):
        LinuxAcademyIE()._login()

# Generated at 2022-06-12 17:57:12.609030
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    infoExtractor = LinuxAcademyIE()
    # assert constructor test
    assert infoExtractor.browser == None
    assert infoExtractor.username == None
    assert infoExtractor.password == None


# Generated at 2022-06-12 17:57:14.901779
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    class_name = globals()['LinuxAcademyIE']
    ins = class_name()
    print(ins.test())

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-12 17:57:18.786184
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test simple single lecture
    LinuxAcademyIE(
        LinuxAcademyIE.ie_key(),
        'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')

    # Test whole course
    LinuxAcademyIE(
        LinuxAcademyIE.ie_key(),
        'https://linuxacademy.com/cp/modules/view/id/154')

# Generated at 2022-06-12 17:57:19.518751
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    return LinuxAcademyIE

# Generated at 2022-06-12 17:57:20.785730
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE("LinuxAcademyIE").ie_key() == "LinuxAcademy"

# Generated at 2022-06-12 17:57:25.595376
# Unit test for constructor of class LinuxAcademyIE

# Generated at 2022-06-12 17:57:47.729543
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'LinuxAcademy'

# Generated at 2022-06-12 17:57:50.272654
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
    except Exception as e:
        assert False, "Exception in constructor of class LinuxAcademyIE"

# Generated at 2022-06-12 17:57:51.691314
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

# Generated at 2022-06-12 17:58:03.983054
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'LinuxAcademy'
    assert ie.IE_DESC == 'LinuxAcademy'
    assert ie._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._

# Generated at 2022-06-12 17:58:05.786593
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert isinstance(LinuxAcademyIE({}), LinuxAcademyIE)


# Generated at 2022-06-12 17:58:14.544139
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert ie._TESTS[0]['url'] == 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    assert ie._TESTS[0]['info_dict']['id'] == '7971-2'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-12 17:58:20.713416
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Unit test for constructor of class LinuxAcademyIE
    """
    linuxacademie = LinuxAcademyIE()

    assert linuxacademie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert linuxacademie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-12 17:58:23.709263
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info = LinuxAcademyIE('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    assert(info._login() is None)

# Generated at 2022-06-12 17:58:25.212739
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'


# Generated at 2022-06-12 17:58:31.312984
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

    if not ie._login():
        print('No access to Linux Academy account. Skipping tests.')
        return

    assert 'AWS Certified Cloud Practitioner' == ie._extract_playlist_title('https://linuxacademy.com/cp/modules/view/id/154')
    assert ie._extract_playlist_count('https://linuxacademy.com/cp/modules/view/id/154') == 41
    assert 'What Is Data Science' == ie._extract_title('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')

# Generated at 2022-06-12 17:59:31.066913
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE("www.example.com")
    assert ie._AUTHORIZE_URL == "https://login.linuxacademy.com/authorize"
    assert ie._ORIGIN_URL == "https://linuxacademy.com"
    assert ie._CLIENT_ID == "KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx"
    assert ie._NETRC_MACHINE == "linuxacademy"


# Generated at 2022-06-12 17:59:31.801813
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 17:59:33.854093
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Create an instance and run the test
    LinuxAcademyIE.test()

if __name__ == "__main__":
    # Create an instance and run the test
    LinuxAcademyIE.test()

# Generated at 2022-06-12 17:59:34.566881
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()


# Generated at 2022-06-12 17:59:46.965183
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert hasattr(ie, "_AUTHORIZE_URL")
    assert hasattr(ie, "_ORIGIN_URL")
    assert hasattr(ie, "_CLIENT_ID")
    assert hasattr(ie, "_NETRC_MACHINE")
    # Unit test for _real_initialize() and _login()
    ie._real_initialize()
    assert ie._login() == None
    # Unit test for _real_extract()
    ie = LinuxAcademyIE()
    assert isinstance(
        ie._real_extract(
            'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'),
        dict)
    # Unit test for _real_extract()

# Generated at 2022-06-12 17:59:47.935191
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 17:59:52.694071
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    Test_LinuxAcademyIE = LinuxAcademyIE.suite()
    i = Test_LinuxAcademyIE().loadTestsFromTestCase(Test_LinuxAcademyIE)
    p = unittest.TextTestRunner(verbosity=2).run(i)
    assert(p.wasSuccessful())

# Generated at 2022-06-12 18:00:02.741792
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    video_url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    video_id = '7971-2'
    video_title = 'What Is Data Science'
    video_description = 'md5:c574a3c20607144fb36cb65bdde76c99'
    video_timestamp = 1607387907
    video_duration = 304

    linuxacademy_ie = LinuxAcademyIE()
    info_dict = linuxacademy_ie._real_extract(video_url)

    assert info_dict.get('id') == video_id
    assert info_dict.get('ext') == 'mp4'
    assert info_dict.get('title') == video_title

# Generated at 2022-06-12 18:00:06.666197
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    x = LinuxAcademyIE()
    assert(x.IE_NAME == 'Linux Academy')
    assert(x.IE_DESC == 'Linux Academy')
    assert(x._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize')
    assert(x.IE_KEY == 'LinuxAcademy')

# Generated at 2022-06-12 18:00:07.522067
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

# Generated at 2022-06-12 18:02:10.995721
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test the instantiation of the class
    assert LinuxAcademyIE

# Generated at 2022-06-12 18:02:14.268619
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    with open('tests/data/linuxacademy_courses_01.json', 'rb') as f:
        course_data = json.load(f)
    la_ie = LinuxAcademyIE()
    la_ie._real_extract(course_data['url'])

# Generated at 2022-06-12 18:02:14.999096
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()


# Generated at 2022-06-12 18:02:15.789242
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()

# Generated at 2022-06-12 18:02:17.114623
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE is not None

# Generated at 2022-06-12 18:02:23.582557
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Tests for non-existed error-case
    # We are checking for 'AssertionError: Login info not available'
    # because it is not possible to occur in normal running environment
    # but will be very useful in case of any API change
    try:
        LinuxAcademyIE('LinuxAcademy')
    except AssertionError as e:
        if str(e) == 'Login info not available':
            return
        raise RuntimeError("Incorrect error message: '%s' instead of 'Login info not available'" % str(e))
    raise RuntimeError("'AssertionError: Login info not available' was not occurred")

# Generated at 2022-06-12 18:02:24.747505
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Instantiate the class
    LinuxAcademyIE()

# Generated at 2022-06-12 18:02:26.853717
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert issubclass(LinuxAcademyIE, InfoExtractor)

# Generated at 2022-06-12 18:02:29.068717
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
    except Exception as e:
        print(e)

# Generated at 2022-06-12 18:02:37.179682
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    test_credentials = ie._get_login_info()
    if test_credentials is None:
        return None
    username, password = test_credentials
    ie._login()
    webpage, urlh = ie._download_webpage_handle(
        'https://linuxacademy.com/cp/modules/view/id/154', None,
        'Downloading authorize page')
    assert username.encode('utf-8') in urlh.read()