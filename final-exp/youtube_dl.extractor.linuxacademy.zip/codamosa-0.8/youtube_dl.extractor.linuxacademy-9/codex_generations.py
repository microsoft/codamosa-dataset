

# Generated at 2022-06-12 17:56:48.853211
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
    except:
        pytest.fail('Error')

# Generated at 2022-06-12 17:56:50.364411
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-12 17:56:52.024182
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

if __name__ == "__main__":
    test_LinuxAcademyIE()

# Generated at 2022-06-12 17:56:55.726058
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Use a dummy video URL
    url = "https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2"
    obj = LinuxAcademyIE()
    obj._downloader.params.update({'videopassword': 'test'})
    obj._login()
    obj._real_extract(url)

# Generated at 2022-06-12 17:56:56.972973
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-12 17:56:58.564650
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    print(LinuxAcademyIE()._real_extract(url))

# Generated at 2022-06-12 17:57:03.871514
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-12 17:57:14.681680
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import unittest
    class LinuxAcademyIETest(unittest.TestCase):
        def __init__(self, methodName='runTest'):
            super(LinuxAcademyIETest, self).__init__(methodName)

        def setUp(self):
            self.ie = LinuxAcademyIE()

        def test_constructor(self):
            self.assertEqual(self.ie.ie_key(), 'LinuxAcademy')
            self.assertEqual(self.ie.server, 'login.linuxacademy.com')
            self.assertEqual(self.ie.username, 'ubuntu')
            self.assertEqual(self.ie.password, 'ubuntu')

    suite = unittest.TestLoader().loadTestsFromTestCase(LinuxAcademyIETest)
    un

# Generated at 2022-06-12 17:57:16.110932
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie is not None



# Generated at 2022-06-12 17:57:17.948598
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    LinuxAcademyIE is class designed to be used as base class for
    other InfoExtractors
    """
    ie = LinuxAcademyIE(None)
    assert ie.login() == False

# Generated at 2022-06-12 17:57:55.949987
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-12 17:58:06.539834
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    a = LinuxAcademyIE()
    assert a._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'

# Generated at 2022-06-12 17:58:07.713101
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 17:58:15.891932
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        from . import netrc
    except ImportError:
        raise ImportError('Please install netrc module to test LinuxAcademyIE.')

    # Get netrc auth
    auth_info = netrc.netrc().authenticators(LinuxAcademyIE._NETRC_MACHINE)
    if not auth_info:
        raise ExtractorError('You must specify %s login and password in .netrc:'
                             'https://github.com/rg3/youtube-dl/blob/master/README.md#netrc' % LinuxAcademyIE._NETRC_MACHINE, expected=True)
    username = auth_info[0]
    password = auth_info[2]

    ie = LinuxAcademyIE()
    ie._login()


# Generated at 2022-06-12 17:58:25.952818
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    i = LinuxAcademyIE()
    assert(i._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    ''')
    assert(i._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize')
    assert(i._ORIGIN_URL == 'https://linuxacademy.com')

# Generated at 2022-06-12 17:58:29.962771
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Init empty LinuxAcademyIE object
    LinuxAcademy = LinuxAcademyIE()
    # Use _real_initialize() method
    LinuxAcademy._real_initialize()
    # Test _login() method
    assert_raises(ExtractorError, LinuxAcademy._login)
    # Test _real_extract() method
    assert_raises(ExtractorError, LinuxAcademy._real_extract, "https://linuxacademy.com/cp/modules/view/id/154")

# Generated at 2022-06-12 17:58:34.348061
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
        LinuxAcademyIE()._login()
        LinuxAcademyIE()._real_initialize()
        LinuxAcademyIE()._real_extract("https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675")
        LinuxAcademyIE()._real_extract("https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2")
        LinuxAcademyIE()._real_extract("https://linuxacademy.com/cp/modules/view/id/154")

    except:
        return False
    return True

# Generated at 2022-06-12 17:58:36.627406
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-12 17:58:47.050380
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxAcademyIE = LinuxAcademyIE('LinuxAcademyIE');
    print("Testing class LinuxAcademyIE(InfoExtractor)")
    print("linuxAcademyIE  :\t%s" % (linuxAcademyIE))
    assert(linuxAcademyIE is not None)
    assert(linuxAcademyIE._VALID_URL is not None)
    assert(linuxAcademyIE._AUTHORIZE_URL is not None)
    assert(linuxAcademyIE._ORIGIN_URL is not None)
    assert(linuxAcademyIE._CLIENT_ID is not None)
    assert(linuxAcademyIE._NETRC_MACHINE is not None)
    assert(linuxAcademyIE._downloader is not None)
    # TODO: Add tests for _login method

#

# Generated at 2022-06-12 17:58:52.401265
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_ie_obj = LinuxAcademyIE()
    assert linux_academy_ie_obj.suitable(None, 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    assert linux_academy_ie_obj.suitable(None, 'https://linuxacademy.com/cp/modules/view/id/154')
    assert not linux_academy_ie_obj.suitable(None, 'https://linuxacademy.com')

# Generated at 2022-06-12 18:00:09.949355
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('LinuxAcademy');

# Generated at 2022-06-12 18:00:16.563683
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        import http.cookiejar as cookielib
    except ImportError:
        import cookielib

    def login(self, *args, **kwargs):
        self._login()

    def extract(self, *args, **kwargs):
        return self._real_extract(*args, **kwargs)

    # TODO: create a test account and add login info
    username = password = None

    ie_module = __import__('youtube_dl.extractor.' + 'linuxacademy', globals(), locals(), ['LinuxAcademyIE'], 1)
    LinuxAcademyIE.login = login
    LinuxAcademyIE.extract = extract
    LinuxAcademyIE._LOGIN_URI = 'https://login.linuxacademy.com/login'
    LinuxAcademyIE._NETRC_MACH

# Generated at 2022-06-12 18:00:17.580423
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert 'Linux Academy' in ie.IE_NAME

# Generated at 2022-06-12 18:00:20.040067
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    # pylint: disable=protected-access
    assert ie._login == ie.__login, 'Constructor of class LinuxAcademyIE tested OK'

# Generated at 2022-06-12 18:00:25.069298
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    obj = LinuxAcademyIE()
    print(obj.suitable(url))
    assert obj.suitable(url)
    print(obj.extract(url))
    #assert obj.suitable(url)

# Generated at 2022-06-12 18:00:30.372794
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    with open('test/test_data/linuxacademy_login_info.json') as f:
        test_data = json.load(f)
    for td in test_data:
        if 'linuxacademy' in td.get('netrc_machine', ''):
            LinuxAcademyIE()._login()



# Generated at 2022-06-12 18:00:33.993903
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .common import test_resolve_url
    test_resolve_url(LinuxAcademyIE, 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')

# Generated at 2022-06-12 18:00:36.317889
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    IA = LinuxAcademyIE()
    assert IA is not None, "Creation of object of class LinuxAcademyIE failed."

# Generated at 2022-06-12 18:00:38.448207
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE({}).ie_key() == 'LinuxAcademy'
    assert LinuxAcademyIE({})._NetrcAuthenticator.name == 'linuxacademy'

# Generated at 2022-06-12 18:00:39.821710
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 18:04:29.733938
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test import get_testcases
    cases = get_testcases(LinuxAcademyIE, suite='Unittest')
    LinuxAcademyIE._login = lambda self: None
    for case in cases:
        linuxacademyIE = LinuxAcademyIE()
        linuxacademyIE._real_initialize()
        linuxacademyIE._real_extract(case['url'])
test_LinuxAcademyIE.test = 'test'

# Generated at 2022-06-12 18:04:31.685430
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from . import LinuxAcademyIE
    la = LinuxAcademyIE(None)
    assert la.IE_NAME == la.ie_key()

# Generated at 2022-06-12 18:04:34.153881
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    if __name__ == '__main__':
        #Test Linux Academy
        LinuxAcademyIE('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')

# Generated at 2022-06-12 18:04:35.813489
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy = LinuxAcademyIE('LinuxAcademy')
    assert linux_academy._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-12 18:04:41.040942
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert re.match(LinuxAcademyIE._VALID_URL, 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    assert re.match(LinuxAcademyIE._VALID_URL, 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    assert re.match(LinuxAcademyIE._VALID_URL, 'https://linuxacademy.com/cp/modules/view/id/154')
    assert not re.match(LinuxAcademyIE._VALID_URL, 'https://www.linuxacademy.com/cp/dashboard/view/id/2639')


# Generated at 2022-06-12 18:04:43.491907
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test constructor"""
    assert LinuxAcademyIE("LinuxAcademyIE", "linuxacademy", [])


if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-12 18:04:47.004044
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
   username = 'username'
   password = 'password'
   cls = LinuxAcademyIE(username=username, password=password)
   assert cls.username == username
   assert cls.password == password
   assert cls.netrc_machine == LinuxAcademyIE._NETRC_MACHINE

# Generated at 2022-06-12 18:04:53.633753
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    url = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    result = ie._real_extract(url)
    assert result['id'] == '1498-2'
    assert result['title'] == 'What Is Data Science'
    assert result['description'] == 'md5:c574a3c20607144fb36cb65bdde76c99'
    assert result['duration'] == 304
    # it does not request full url, but should be able to get the url from the page source
    assert 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2/module/2' in result['url']
    assert result['formats'] != []

# Generated at 2022-06-12 18:04:55.353608
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_ie = LinuxAcademyIE()
    assert test_ie.name == 'LinuxAcademy'

# Generated at 2022-06-12 18:05:03.465687
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == (r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    ''')