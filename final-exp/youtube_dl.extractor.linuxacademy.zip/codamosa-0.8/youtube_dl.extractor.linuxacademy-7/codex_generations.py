

# Generated at 2022-06-12 17:56:52.850481
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    try:
        assert ie
    except Exception as e:
        print(e)

# Generated at 2022-06-12 17:56:56.215777
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # When username and password are both not provided, no login is expected
    LinuxAcademyIE(None, None)
    # When username or password is provided, method _login is expected to be called
    LinuxAcademyIE('username', None)
    LinuxAcademyIE(None, 'password')
    LinuxAcademyIE('username', 'password')

# Generated at 2022-06-12 17:57:02.360712
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test the constructor of class LinuxAcademyIE."""
    assert LinuxAcademyIE != None
    lacie = LinuxAcademyIE()
    assert lacie != None
    assert lacie.ie_key() == 'LinuxAcademy'
    assert lacie.ie_name() == 'linuxacademy'
    assert lacie.ie_description() == 'Video learning for IT pros and developers'

# Generated at 2022-06-12 17:57:10.123932
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademy_ie = LinuxAcademyIE()
    assert linuxacademy_ie._VALID_URL is not None
    assert linuxacademy_ie._TESTS is not None
    assert linuxacademy_ie._AUTHORIZE_URL is not None
    assert linuxacademy_ie._ORIGIN_URL is not None
    assert linuxacademy_ie._CLIENT_ID is not None
    assert linuxacademy_ie._NETRC_MACHINE is not None

# Generated at 2022-06-12 17:57:12.396483
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert_raises(
        ExtractorError,
        lambda: LinuxAcademyIE(object())._real_initialize())

# Generated at 2022-06-12 17:57:19.237594
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    #Unit test for constructor of class LinuxAcademyIE
    """Constructor test case of LinuxAcademyIE"""

# Generated at 2022-06-12 17:57:20.113047
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
        assert True
    except:
        assert False

# Generated at 2022-06-12 17:57:21.021179
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-12 17:57:22.743555
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 17:57:25.251224
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import unittest

    class LinuxAcademyIETest(unittest.TestCase):
        def test_linuxAcademyIE(self):
            linuxAcademyIE = LinuxAcademyIE()
            linuxAcademyIE._login()


# Generated at 2022-06-12 17:58:03.468042
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 17:58:10.028454
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import sys
    import unittest

    class LinuxAcademyIETest(unittest.TestCase):
        def setUp(self):
            self.ie = LinuxAcademyIE(sys.argv[-1])

        def test_LinuxAcademyIE_login(self):
            self.ie._login()

        def test_LinuxAcademyIE_get_login_info(self):
            self.ie._get_login_info()

    unittest.main()

# Generated at 2022-06-12 17:58:10.610429
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE

# Generated at 2022-06-12 17:58:13.375483
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(None)
    assert ie.name == "linuxacademy"
    assert ie.ie_key() == "linuxacademy"

# Generated at 2022-06-12 17:58:16.284426
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-12 17:58:24.302760
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        import netrc
    except ImportError:
        raise unittest.SkipTest('Python module netrc is required for this test.')
    credentials = netrc.netrc().authenticators(LinuxAcademyIE._NETRC_MACHINE)
    if not credentials:
        raise unittest.SkipTest(
            'No login credentials found in ~/.netrc for %s.' % LinuxAcademyIE._NETRC_MACHINE)
    import requests
    requests.Session().cookies.clear()
    return LinuxAcademyIE({'username': credentials[0], 'password': credentials[2]})

# Generated at 2022-06-12 17:58:30.787492
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    module_info = LinuxAcademyIE()._real_extract('https://linuxacademy.com/cp/modules/view/id/154')
    assert module_info['id'] == '154'
    assert module_info['title'] == 'AWS Certified Cloud Practitioner'
    assert module_info['description'] == 'md5:a68a299ca9bb98d41cca5abc4d4ce22c'
    assert module_info['duration'] == 28835
    assert module_info['_type'] == 'playlist'
    assert len(module_info['entries']) == 41
    chapter_info = next(e for e in module_info['entries'] if e['chapter_number'] == 1)
    assert chapter_info['title'] == 'Introduction to AWS'

# Generated at 2022-06-12 17:58:42.023239
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.__doc__ == 'Generic Linux Academy extractor'
    assert LinuxAcademyIE.__name__ == 'LinuxAcademyIE'
    assert LinuxAcademyIE(info_extractor=None)._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-12 17:58:44.417335
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'

# Generated at 2022-06-12 17:58:46.519876
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test constructor of the class LinuxAcademyIE"""
    ie = LinuxAcademyIE(None)
    assert ie != None

# Generated at 2022-06-12 18:00:14.678200
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxAcademy = LinuxAcademyIE()

# Generated at 2022-06-12 18:00:17.162022
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE(None, None);
    except ExtractorError:
        assert True;
    else:
        assert False;

# Generated at 2022-06-12 18:00:18.369511
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():

    ie = LinuxAcademyIE()
    ie._real_initialize()

# Generated at 2022-06-12 18:00:19.871931
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # without login
    LinuxAcademyIE()._login()

# Generated at 2022-06-12 18:00:24.510263
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.get_username() == 'test', 'username must be test.'
    assert ie.get_password() == 'test', 'password must be test.'
    assert ie.get_netrc_machine() == 'linuxacademy', 'machine  must be linuxacademy.'

# Generated at 2022-06-12 18:00:26.617185
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE(None, None)
    assert instance

# Generated at 2022-06-12 18:00:27.793116
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
  assert LinuxAcademyIE

# Generated at 2022-06-12 18:00:29.805610
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie is not None

# Generated at 2022-06-12 18:00:32.267070
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # pylint: disable=redefined-outer-name
    ie = LinuxAcademyIE
    for attr in ['_VALID_URL', 'ie_key', '_TESTS']:
        assert hasattr(ie, attr)

# Generated at 2022-06-12 18:00:33.081989
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('LinuxAcademy', 'linuxacademy', None)

# Generated at 2022-06-12 18:02:29.302432
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 18:02:30.828678
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 18:02:32.122319
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    video = LinuxAcademyIE.ie_key('LinuxAcademy')

# Generated at 2022-06-12 18:02:40.655725
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.IE_DESC == 'Linux Academy'
    assert ie._VALID_URL == 'https?://(?:www\\\.)?linuxacademy\\\.com/cp/courses/lesson/course/(?P<chapter_id>\\\d+)/lesson/(?P<lesson_id>\\\d+)|https?://(?:www\\\.)?linuxacademy\\\.com/cp/modules/view/id/(?P<course_id>\\\d+)'

# Generated at 2022-06-12 18:02:41.684532
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 18:02:43.158280
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'linuxacademy'

# Generated at 2022-06-12 18:02:44.114091
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 18:02:51.230264
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.get_login_info() == (None, None)
    # ie.username = ie.password = ie.login_state_url = ie.login_data = ie.access_token = None
    ie.set_login_info('test', 'test')
    assert ie.get_login_info() == ('test', 'test')
    assert ie._real_initialize() is None
    assert ie.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-12 18:03:02.563973
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'

# Generated at 2022-06-12 18:03:03.658479
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Object should be instantiated without any argument
    assert LinuxAcademyIE()