

# Generated at 2022-06-12 17:56:55.795634
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert obj.suitable('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    assert obj.suitable('https://linuxacademy.com/cp/modules/view/id/154')
    assert obj.suitable('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    assert not obj.suitable('http://example.com')

# Generated at 2022-06-12 17:56:58.121467
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert isinstance(LinuxAcademyIE({}), LinuxAcademyIE)

# Generated at 2022-06-12 17:56:59.858567
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie

# Generated at 2022-06-12 17:57:08.584764
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    def test_ie(url, success):
        try:
            LinuxAcademyIE(url)
            assert success
        except ExtractorError:
            assert not success
    # Test for valid URL
    valid_url = "https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2"
    test_ie(valid_url, True)
    # Test for invalid URL
    invalid_url = "https://www.linuxacademy.com/"
    test_ie(invalid_url, False)

# Generated at 2022-06-12 17:57:13.710827
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    try:
        site = ie._login()
    except Exception as e:
        print(e)
        return
    assert site is not None
    assert isinstance(ie._download_webpage(ie._AUTHORIZE_URL), str)

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-12 17:57:24.882445
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert not hasattr(LinuxAcademyIE(), '_login')
    assert not hasattr(LinuxAcademyIE(), 'username')
    assert not hasattr(LinuxAcademyIE(), 'password')
    assert hasattr(LinuxAcademyIE(), '_real_initialize')

    assert hasattr(LinuxAcademyIE._VALID_URL, '__mod__')
    assert hasattr(LinuxAcademyIE._AUTHORIZE_URL, '__mod__')

    assert hasattr(LinuxAcademyIE._login, '__call__')
    assert hasattr(LinuxAcademyIE()._login, '__call__')
    assert hasattr(LinuxAcademyIE(), '_download_webpage_handle')
    assert hasattr(LinuxAcademyIE(), '_download_webpage')

# Generated at 2022-06-12 17:57:34.042788
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.IE_SHORT_NAME == 'linuxacademy'
    assert ie._VALID_URL == LinuxAcademyIE._VALID_URL
    assert ie._TESTS == LinuxAcademyIE._TESTS
    assert ie._AUTHORIZE_URL == LinuxAcademyIE._AUTHORIZE_URL
    assert ie._ORIGIN_URL == LinuxAcademyIE._ORIGIN_URL
    assert ie._CLIENT_ID == LinuxAcademyIE._CLIENT_ID
    assert ie._NETRC_MACHINE == LinuxAcademyIE._NETRC_MACHINE
    # Test for method _real_initialize
    ie._real_initialize()
    # Test for method _login

# Generated at 2022-06-12 17:57:42.770982
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

    assert(ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx')
    assert(ie._NETRC_MACHINE == 'linuxacademy')
    assert(ie._ORIGIN_URL == 'https://linuxacademy.com')
    assert(ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize')

# Generated at 2022-06-12 17:57:45.199358
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """ Test a few URLs from the site """
    LinuxAcademyIE('LinuxAcademy').download_url('https://linuxacademy.com/cp/modules/view/id/154')

# Generated at 2022-06-12 17:57:52.490934
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test constructor of class LinuxAcademyIE"""
    url = r'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.suitable(url)

# Generated at 2022-06-12 17:58:27.661998
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()._real_initialize()

# Generated at 2022-06-12 17:58:31.242756
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-12 17:58:42.295829
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    course_id = '154'
    url = 'https://linuxacademy.com/cp/modules/view/id/' + course_id
    ies = LinuxAcademyIE.working_ies
    assert LinuxAcademyIE.ie_key() in ies, "LinuxAcademyIE must be list of working ies in YoutubeIE"
    linuxacademyie = LinuxAcademyIE(ies)
    assert linuxacademyie._VALID_URL == LinuxAcademyIE._VALID_URL, "Valid URL must be same with instance variable of LinuxAcademyIE"
    assert linuxacademyie._NETRC_MACHINE, "LinuxAcademyIE must have netrc machine for login"

    module = linuxacademyie._download_webpage(url, course_id)
    module = linuxacademy

# Generated at 2022-06-12 17:58:44.104848
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 17:58:45.256136
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()
    

# Generated at 2022-06-12 17:58:47.302478
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE("LinuxAcademy")
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-12 17:58:54.339257
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test constructor with valid url that points to a video
    t1 = "https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675"
    linuxacademyie = LinuxAcademyIE(LinuxAcademyIE._VALID_URL)
    assert re.match(linuxacademyie._VALID_URL, t1)

    # Test constructor with valid url that points to a course
    t2 = "https://linuxacademy.com/cp/modules/view/id/154"
    linuxacademyie = LinuxAcademyIE(LinuxAcademyIE._VALID_URL)
    assert re.match(linuxacademyie._VALID_URL, t2)

    # Test constructor with invalid url

# Generated at 2022-06-12 17:59:04.445957
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    la = LinuxAcademyIE()
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    mobj = re.match(la._VALID_URL, url)
    chapter_id, lecture_id, course_id = mobj.group('chapter_id', 'lesson_id', 'course_id')
    item_id = course_id if course_id else '%s-%s' % (chapter_id, lecture_id)
    webpage = la._download_webpage(url, item_id)
    # course path

# Generated at 2022-06-12 17:59:05.291306
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE("LinuxAcademy.LinuxAcademyIE")

# Generated at 2022-06-12 17:59:07.713869
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 18:00:27.994656
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'

# Generated at 2022-06-12 18:00:29.464534
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('LinuxAcademy')

# Generated at 2022-06-12 18:00:30.077807
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 18:00:35.781315
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    # Check if the login method is called
    ie._login = lambda: None
    with open('test/testdata/linuxacademy_test_urls.json', 'r') as f:
        test_urls = json.loads(f.read())
    for test_url in test_urls:
        assert ie._real_extract(test_url) is not None

# Generated at 2022-06-12 18:00:37.578020
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_LinuxAcademyIE = LinuxAcademyIE()
    # test constructor
    assert test_LinuxAcademyIE is not None

# Generated at 2022-06-12 18:00:39.819926
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test import TestLinuxAcademyIE
    to_test = TestLinuxAcademyIE()
    to_test.test_LinuxAcademyIE()

# Generated at 2022-06-12 18:00:42.726236
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import unittest
    suite = unittest.TestSuite()
    suite.addTest(LinuxAcademyIE("test_login"))
    unittest.TextTestRunner().run(suite)

# Generated at 2022-06-12 18:00:44.412568
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    a = LinuxAcademyIE()
    assert(a is not None)

# Generated at 2022-06-12 18:00:47.980382
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.suitable('https://linuxacademy.com/cp/modules/view/id/154')
    assert ie.suitable('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')

# Generated at 2022-06-12 18:00:49.063779
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert isinstance(LinuxAcademyIE(), LinuxAcademyIE)

# Generated at 2022-06-12 18:04:22.964999
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert(LinuxAcademyIE.ie_key() == 'LinuxAcademy')
    assert(LinuxAcademyIE.ie_key() != 'Youtube')

# Generated at 2022-06-12 18:04:29.944800
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE().IE_NAME['linuxacademy'] == 'Linux Academy'

    # Unit test for method _real_extract(self, url)
    assert LinuxAcademyIE()._real_extract(
        'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')['id'] == '7971-2'

    course_id = '154'
    assert LinuxAcademyIE()._real_extract(
        'https://linuxacademy.com/cp/modules/view/id/' + course_id)['id'] == course_id

    course_id = '1498'
    chapter_id = '2'
    lesson_id = '9'

# Generated at 2022-06-12 18:04:36.217049
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # No login credentials
    LinuxAcademyIE()
    # No login credentials & no netrc credentials
    LinuxAcademyIE(downloader=lambda : FakeYDL({'usenetrc': False}))
    # Login credentials
    assert LinuxAcademyIE({'username': 'username', 'password': 'password'})._downloader.params['username'] == 'username'
    # Session cookie
    assert LinuxAcademyIE({'session_cookie': 'session'})._downloader.params['session_cookie'] == 'session'
    # netrc credentials
    LinuxAcademyIE(downloader=lambda : FakeYDL({'usenetrc': True}))


# Generated at 2022-06-12 18:04:37.402298
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(object, 'api_key')

# Generated at 2022-06-12 18:04:39.051273
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    myclass = LinuxAcademyIE()
    assert myclass.IE_NAME == 'linuxacademy'

# Generated at 2022-06-12 18:04:40.179995
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    print(ie)

# Generated at 2022-06-12 18:04:42.406746
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert obj is not None
    assert obj._VALID_URL == obj.VALID_URL
    assert obj._TESTS == obj.TESTS

# Generated at 2022-06-12 18:04:43.288158
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 18:04:45.520595
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Constructor test LinuxAcademyIE
    """
    # Check if LinuxAcademyIE constructor throw an exception
    LinuxAcademyIE(None)

# Generated at 2022-06-12 18:04:46.115902
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()