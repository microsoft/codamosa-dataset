

# Generated at 2022-06-12 17:56:48.022283
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()._real_initialize



# Generated at 2022-06-12 17:56:49.049129
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 17:56:56.664020
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

    assert (ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx')
    assert (ie._ORIGIN_URL == 'https://linuxacademy.com')
    assert (ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize')
    assert (ie._NETRC_MACHINE == 'linuxacademy')

# Generated at 2022-06-12 17:56:59.508277
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    i = LinuxAcademyIE()
    test_url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    # test_url = 'https://linuxacademy.com/cp/modules/view/id/154'
    result = i._real_extract(test_url)
    print(result)

# Generated at 2022-06-12 17:57:03.231165
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print('Unit test for class LinuxAcademyIE')
    le = LinuxAcademyIE()
    print(le._ORIGIN_URL)
    print('Finished')

test_LinuxAcademyIE()

# Generated at 2022-06-12 17:57:04.169823
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None)

# Generated at 2022-06-12 17:57:08.843031
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675') is not None
    assert LinuxAcademyIE('https://linuxacademy.com/cp/modules/view/id/154') is not None
    assert LinuxAcademyIE('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2') is not None

# Generated at 2022-06-12 17:57:10.071471
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE("LinuxAcademy")

# Generated at 2022-06-12 17:57:15.654214
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'

# Generated at 2022-06-12 17:57:24.020800
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(display_id="7971-2", url="https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675")
    assert ie._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'

if __name__ == '__main__':
    sys.exit(test_LinuxAcademyIE())

# Generated at 2022-06-12 17:58:06.644102
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    with open('test.html') as f:
        data = f.read()
        assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
        assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
        assert ie._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-12 17:58:07.794205
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 17:58:15.994435
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import os.path
    import sys
    import unittest

    try:
        from unittest.mock import MagicMock
    except ImportError:
        from mock import Mock as MagicMock

    def mock_login():
        li = LinuxAcademyIE()
        li._login = MagicMock(return_value=None)
        return li

    class LinuxAcademyDetailPageTest(unittest.TestCase):
        """Unit tests for LinuxAcademy detail pages"""

        def setUp(self):
            self.li = mock_login()
            self.unit_dir = os.path.dirname(sys.modules[__name__].__file__)
            self.test_page_path = os.path.join(
                self.unit_dir,
                'test/test.html'
            )



# Generated at 2022-06-12 17:58:25.987151
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import requests
    import io
    import json
    import pickle
    import unittest

    from .common import mock

    # Mock requests object
    class LinuxAcademyTestFile():
        def read(self):
            return '{}'

        def close(self):
            return '{}'

    test_file = LinuxAcademyTestFile()

    f = io.BytesIO()
    f.write(b"foo")
    f.seek(0)

    response = requests.Response()
    response._content = pickle.dumps(test_file)
    response.status_code = 200

    requests_object = mock.MockRequests(response)

    class TestLinuxAcademyIE(unittest.TestCase):
        def test_login(self):
            la = LinuxAcademyIE()
           

# Generated at 2022-06-12 17:58:26.932831
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    x = LinuxAcademyIE()
    assert type(x) == LinuxAcademyIE

# Generated at 2022-06-12 17:58:30.183158
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test = """
    def test_LinuxAcademyIE(self):
        """
    test_result = ""
    # testing method _real_initialize in class LinuxAcademyIE
    test_result += LinuxAcademyIE._real_initialize(LinuxAcademyIE)
    # testing method _login in class LinuxAcademyIE
    test_result += LinuxAcademyIE._login(LinuxAcademyIE)
    # testing method _real_extract in class LinuxAcademyIE
    test_result += LinuxAcademyIE._real_extract(LinuxAcademyIE)
    return test_result

# Generated at 2022-06-12 17:58:35.688158
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE(object())._NETRC_MACHINE == 'linuxacademy'
    assert LinuxAcademyIE(object())._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert LinuxAcademyIE(object())._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert LinuxAcademyIE(object())._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-12 17:58:42.019600
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test empty video ID
    video_id = ''
    assert str(LinuxAcademyIE(video_id)) == 'YouTube video ID must not be empty'
    # Test unavailable video ID
    video_id = '123'
    assert str(LinuxAcademyIE(video_id)) == 'The requested video doesn\'t exist or is blocked'
    # Test available video ID
    video_id = 'BdJKm16Co6M'
    assert LinuxAcademyIE(video_id) is not None

# Generated at 2022-06-12 17:58:51.492385
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    name = "LinuxAcademyIE"
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert ie._TESTS[0]['url'] == 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    assert ie._TESTS[0]['info_dict']['id'] == '7971-2'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-12 17:58:52.740874
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE({})
    assert obj.IE_NAME == 'linuxacademy'

# Generated at 2022-06-12 17:59:38.905032
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    infoExtractor = LinuxAcademyIE(None)
    assert infoExtractor.is_login_required()

# Generated at 2022-06-12 17:59:42.012445
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    L = LinuxAcademyIE()
if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-12 17:59:46.876100
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # To test init function of class LinuxAcademyIE
    # ie_key (str): A string identifying the extractor, should be unique within this project.
    # ie_object (InfoExtractor): The object created from class InfoExtractor
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'
    LinuxAcademyIE.ie_object = InfoExtractor

# Generated at 2022-06-12 17:59:49.874285
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    class_ = LinuxAcademyIE
    ie = class_('http://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    assert ie.__class__ == class_

# Generated at 2022-06-12 17:59:54.308856
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import sys
    if sys.version_info >= (3, 4):
        # nested class is not supported
        raise Exception('This test requires Python < 3.4')
    from .test_login import check_login
    ie = LinuxAcademyIE()
    check_login(ie)

# Generated at 2022-06-12 17:59:56.007087
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE("")

# Generated at 2022-06-12 17:59:57.089550
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie


# Generated at 2022-06-12 18:00:06.849180
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # pylint: disable=protected-access
    li = LinuxAcademyIE()
    assert li._VALID_URL == (
        r"""https?://(?:www\.)?linuxacademy\.com/cp/
        (?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
        modules/view/id/(?P<course_id>\d+))""")
    # Test mobject values
    mobj = re.match(li._VALID_URL, 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    assert mobj.group('chapter_id') == '7971'

# Generated at 2022-06-12 18:00:09.410886
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        obj = LinuxAcademyIE()
        obj._login()
    except Exception as ex:
        print('Unit test failed: %s' % str(ex))

# Generated at 2022-06-12 18:00:20.858522
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # pylint: disable=no-members
    # pylint: disable=too-many-public-methods
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'LinuxAcademy'
    assert ie.IE_DESC == 'Linux Academy training videos'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-12 18:02:15.749816
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 18:02:22.010372
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    if 1:
        raise NotImplementedError('This test is disabled due to a lack of credentials')

    import csv
    from io import StringIO

    cred = os.environ.get('LINUX_ACADEMY_ACCOUNT', None)
    cred = StringIO(cred) if cred else open('../../tests/linux_academy.txt')
    for account in csv.reader(cred, delimiter=' '):
        LinuxAcademyIE().download_creds_only(account)

# Generated at 2022-06-12 18:02:28.188982
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|modules/view/id/(?P<course_id>\\d+))'

# Generated at 2022-06-12 18:02:32.693052
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Unit test for class LinuxAcademyIE
    """
    LinuxAcademyIE()
    # Test call to _login()
    la_ie = LinuxAcademyIE()
    la_ie._login()

# Generated at 2022-06-12 18:02:35.659439
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test exception
    from .. import LinuxAcademyIE
    # Will thrown exception if login is not ok
    a = LinuxAcademyIE()

# Generated at 2022-06-12 18:02:38.221131
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.__class__.__name__ == "LinuxAcademyIE"
    assert ie.ie_key() == 'LinuxAcademy'



# Generated at 2022-06-12 18:02:41.719733
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .common import test_ie_constructor
    test_ie_constructor(LinuxAcademyIE)

##################################################################################

# Generated at 2022-06-12 18:02:46.262866
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Create a dummy class for testing
    class DummyLinuxAcademyIE(LinuxAcademyIE):
        pass

    # Test input parameters
    DummyLinuxAcademyIE(None, None)
    DummyLinuxAcademyIE(None, None, None)
    DummyLinuxAcademyIE(None, None, None, None)
    DummyLinuxAcademyIE(None, None, None, None, None)
    DummyLinuxAcademyIE(None, None, None, None, None, None)
    DummyLinuxAcademyIE(None, None, None, None, None, None, None)

# Generated at 2022-06-12 18:02:47.172839
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('linuxacademy')._login()

# Generated at 2022-06-12 18:02:53.277001
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE._CLIENT_ID == "KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx"
    assert LinuxAcademyIE._NETRC_MACHINE == "linuxacademy"
    assert LinuxAcademyIE._TESTS[0]['url'] == \
        'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    assert LinuxAcademyIE._TESTS[0]['info_dict']['id'] == '7971-2'
    assert LinuxAcademyIE._TESTS[0]['info_dict']['title'] == 'What Is Data Science'