

# Generated at 2022-06-12 17:56:49.852798
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    # file_path = '~/.netrc'
    # ie._set_login_info(domain='', username='', password='', filename=file_path)

# Generated at 2022-06-12 17:56:51.277656
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import doctest
    return doctest.run_docstring_examples(LinuxAcademyIE, globals())

# Generated at 2022-06-12 17:56:52.175469
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 17:56:58.869134
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE._VALID_URL == \
           r'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert LinuxAcademyIE._TESTS[0]['url'] == \
           'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    assert LinuxAcademyIE._TESTS[0]['info_dict']['id'] == '7971-2'
    assert LinuxAcademyIE._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-12 17:57:01.876500
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Unit test of LinuxAcademyIE class.

    """
    ie = LinuxAcademyIE()
    assert ie is not None


# Generated at 2022-06-12 17:57:10.453894
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    i = LinuxAcademyIE()
    assert i._VALID_URL == LinuxAcademyIE._VALID_URL
    assert i._TESTS == LinuxAcademyIE._TESTS
    assert i._AUTHORIZE_URL == LinuxAcademyIE._AUTHORIZE_URL
    assert i._ORIGIN_URL == LinuxAcademyIE._ORIGIN_URL
    assert i._CLIENT_ID == LinuxAcademyIE._CLIENT_ID
    assert i._NETRC_MACHINE == LinuxAcademyIE._NETRC_MACHINE

# Generated at 2022-06-12 17:57:12.007618
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_LinuxAcademyIE = LinuxAcademyIE()

# Generated at 2022-06-12 17:57:16.819419
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    ie._login()


# Generated at 2022-06-12 17:57:22.966470
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    class_LinuxAcademyIE = LinuxAcademyIE(None)
    class_LinuxAcademyIE.constructor()
    # this test is meaningless, since all the operations it tests are implemented to no-operation functions
    assert(True)

# Generated at 2022-06-12 17:57:24.233173
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_DESC == 'LinuxAcademy'
    assert ie.__name__ == 'linuxacademy'

# Generated at 2022-06-12 17:57:42.368122
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()

# Generated at 2022-06-12 17:57:45.818014
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """test_LinuxAcademyIE: Tests for LinuxAcademyIE """
    # tests for constructor of class LinuxAcademyIE"""
    ie_ = LinuxAcademyIE('linuxacademy')
    assert ie_
    assert ie_.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-12 17:57:49.565118
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Unit test for constructor of class LinuxAcademyIE
    """
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'LinuxAcademy'
    assert ie.IE_DESC == 'Linux Academy'
    assert ie._VALID_URL == ie.VALID_URL
    assert ie._NETRC_MACHINE == ie.NETRC_MACHINE
    assert ie._AUTHORIZE_URL == ie.AUTHORIZE_URL
    assert ie._ORIGIN_URL == ie.ORIGIN_URL
    assert ie._CLIENT_ID == ie.CLIENT_ID

# Generated at 2022-06-12 17:57:53.784828
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Class constructor
    # Should return a singleton.
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.ie_name() == 'LinuxAcademy'

# Generated at 2022-06-12 17:57:55.677932
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Unit tests for LinuxAcademyIE._login

# Generated at 2022-06-12 17:57:58.046045
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    L = LinuxAcademyIE()
    assert isinstance(L, InfoExtractor)

# Generated at 2022-06-12 17:58:01.304477
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    
    # Expected :
    # return a linux academy instance
    from .linuxacademy import LinuxAcademyIE
    test_instance = LinuxAcademyIE()
    assert test_instance is not None

# Generated at 2022-06-12 17:58:04.531514
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert(True)
    # linux_academy = LinuxAcademyIE()
    # linux_academy.download_webpage = mock.MagicMock(return_value=b'test_page')
    # linux_academy._login()

# Generated at 2022-06-12 17:58:10.646368
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test for constructor without arguments
    try:
        LinuxAcademyIE()
    except TypeError as exception:
        assert exception.args[0] == "__init__() missing 2 required positional arguments: 'username' and 'password'"

    # Test for constructor with arguments
    try:
        LinuxAcademyIE("fake_username", "fake_password")
    except TypeError as exception:
        assert exception.args[0] == "__init__() takes 1 positional argument but 3 were given"

# Generated at 2022-06-12 17:58:12.122576
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.login_possible() is True

# Generated at 2022-06-12 17:59:00.589727
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    class MockInfoExtractor(InfoExtractor):
        def _call_login_method(self):
            super(LinuxAcademyIE, self)._login()

    assert hasattr(MockInfoExtractor, '_call_login_method')

# Generated at 2022-06-12 17:59:06.989103
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    class Mock_LinuxAcademyIE(LinuxAcademyIE):
        def _download_webpage_handle(self, url_or_request, video_id, note, errnote=None, fatal=True,
                                     data=None, headers=None, query=None):
            return None, None
    la_ie = Mock_LinuxAcademyIE()
    url = 'https://login.linuxacademy.com/authorize'

# Generated at 2022-06-12 17:59:09.148573
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    return LinuxAcademyIE('https://linuxacademy.com/cp/courses/lesson/course/1498/section/2/lesson/2', None)

# Generated at 2022-06-12 17:59:11.776504
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert(ie.get_username() != None)
    assert(ie.get_password() != None)
    assert(ie.IE_NAME == 'linuxacademy')

# Generated at 2022-06-12 17:59:23.039328
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_common import get_extractor
    from ..compat import compat_str
    # Tests for class LinuxAcademyIE

# Generated at 2022-06-12 17:59:23.777340
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()


# Generated at 2022-06-12 17:59:26.608987
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 17:59:33.770248
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        import httpretty  # noqa: F401
    except ImportError:
        raise ImportError('LinuxAcademyIE tests need httpretty module')
    from .. import LinuxAcademyIE

    linuxacademyIE = LinuxAcademyIE('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')

    assert linuxacademyIE._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert linuxacademyIE._NETRC_MACHINE == 'linuxacademy'


# Generated at 2022-06-12 17:59:34.967630
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    res = ie._real_initialize()
    return res

# Generated at 2022-06-12 17:59:36.122378
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.__class__ == LinuxAcademyIE

# Generated at 2022-06-12 18:00:57.259428
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print("Running test_LinuxAcademyIE")
    l = LinuxAcademyIE()
    assert l is not None

# Generated at 2022-06-12 18:01:00.904476
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie_test = LinuxAcademyIE('LinuxAcademyIE')
    assert ie_test.ie_key() == 'LinuxAcademy'
    assert ie_test.ie_key() in ie_test.genie


if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-12 18:01:02.665178
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    username, password = 'foo@bar.com', 'bar'
    LinuxAcademyIE(InfoExtractor())._login(username,password)

# Generated at 2022-06-12 18:01:04.073865
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    '''
    Test if the LinuxAcademyIE can be initialized
    '''
    LinuxAcademyIE()

# Generated at 2022-06-12 18:01:04.906716
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

# Generated at 2022-06-12 18:01:10.781728
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'

# Generated at 2022-06-12 18:01:21.871963
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import logging
    logging.basicConfig(level=logging.DEBUG,
                        format=('[%(levelname)s] [%(asctime)s] [%(filename)s] '
                                '[%(funcName)s] [%(lineno)d] :(%(message)s)'))
    ie = LinuxAcademyIE()

    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    result = ie._real_extract(url)
    assert result['id'] == 154
    assert len(result['entries']) == 41

    url = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    result = ie._real_extract(url)

# Generated at 2022-06-12 18:01:22.902640
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-12 18:01:25.280075
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None)

# Generated at 2022-06-12 18:01:25.793337
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-12 18:04:44.771948
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_url = "https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2"
    ie = LinuxAcademyIE()
    instance = ie.ie_key()
    assert instance == 'LinuxAcademy'

# Generated at 2022-06-12 18:04:50.986001
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert(ie.IE_NAME == 'linuxacademy')
    assert(ie.IE_DESC == 'Linux Academy')
    assert(ie._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)')
    assert(ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize')
    assert(ie._ORIGIN_URL == 'https://linuxacademy.com')

# Generated at 2022-06-12 18:04:57.448004
# Unit test for constructor of class LinuxAcademyIE

# Generated at 2022-06-12 18:04:59.951436
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_case = LinuxAcademyIE(
        'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    assert test_case is not None

# Generated at 2022-06-12 18:05:01.833793
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from __main__ import LinuxAcademyIE
    test_inst = LinuxAcademyIE()
    assert isinstance(test_inst, LinuxAcademyIE)

# Generated at 2022-06-12 18:05:02.690565
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademy = LinuxAcademyIE()

# Generated at 2022-06-12 18:05:03.688781
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie is not None

# Generated at 2022-06-12 18:05:04.578203
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-12 18:05:05.211241
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 18:05:06.243166
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None, {}, {});