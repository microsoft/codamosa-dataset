

# Generated at 2022-06-12 17:56:51.249141
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-12 17:56:56.939960
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test for valid URL that uses chapter_id and lesson_id
    LinuxAcademyIE('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    # Test for valid URL that uses course_id
    LinuxAcademyIE('https://linuxacademy.com/cp/modules/view/id/154')
    # Test for invalid URL that uses no chapter_id, lesson_id and course_id
    LinuxAcademyIE('https://linuxacademy.com/cp/courses/lesson/course/////lesson//module/')

# Generated at 2022-06-12 17:57:05.781833
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Login info not required to download single video
    # But required to download whole course
    # login_info = {
    #     'username': '',
    #     'password': ''
    # }
    # ie = LinuxAcademyIE(login_info=login_info)

    ie = LinuxAcademyIE()

    # Single video
    url = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    info = ie.extract(url)
    assert info['title'] == 'Overview of the Cloud Practitioner Exam'
    assert info['id'] == '1498-2'
    assert info['duration'] == 158

    # Download whole course
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    info

# Generated at 2022-06-12 17:57:09.883400
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test class for LinuxAcademyIE"""
    # Create a test for constructor of class LinuxAcademyIE
    ie = LinuxAcademyIE(None)
    # Test that LinuxAcademyIE is a subclass of InfoExtractor
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 17:57:18.161618
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == '(?x)https?://(?:www\\.)?linuxacademy\\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|modules/view/id/(?P<course_id>\\d+))'

# Generated at 2022-06-12 17:57:20.458573
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademy_ie = LinuxAcademyIE()
    assert(linuxacademy_ie._CLIENT_ID == "KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx")

# Generated at 2022-06-12 17:57:26.927437
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    if getattr(LinuxAcademyIE, '_login', None):
        InfoExtractor._download_webpage = lambda self, *args, **kwargs: args[0]
        ie = LinuxAcademyIE()
        url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
        assert getattr(ie, '_login_info', None), \
            'Failed to load login info from .netrc or environment'
        username, password = ie._login_info

# Generated at 2022-06-12 17:57:28.567576
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.__class__ == LinuxAcademyIE


# Generated at 2022-06-12 17:57:31.993006
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Unit test for constructor of class LinuxAcademyIE
    """

    print("LinuxAcademyIE.test_LinuxAcademyIE() - Start")

    linux_academy_ie_unit_test_obj = LinuxAcademyIE()

    print("LinuxAcademyIE.test_LinuxAcademyIE() - Done")

# Generated at 2022-06-12 17:57:35.206315
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test both the 1st and the 2nd constructor of class LinuxAcademyIE
    ie = LinuxAcademyIE(LinuxAcademyIE.ie_key(), LinuxAcademyIE._VALID_URL)
    ie = LinuxAcademyIE(LinuxAcademyIE.ie_key())

# Generated at 2022-06-12 17:58:00.732025
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    class TestLinuxAcademyIE(LinuxAcademyIE):
        def _download_webpage(self, *args, **kwargs):
            assert args[1] is not None
        def _download_webpage_handle(self, *args, **kwargs):
            assert args[1] is not None
            return args[1], args[1]

    TestLinuxAcademyIE()._real_initialize()

# Generated at 2022-06-12 17:58:06.279980
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-12 17:58:07.793143
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'linuxacademy'

# Generated at 2022-06-12 17:58:08.644063
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 17:58:09.614749
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 17:58:13.980468
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Create object of class LinuxAcademyIE
    ie = LinuxAcademyIE()

    # Run _real_extract() method of class LinuxAcademyIE
    ie._real_extract('https://linuxacademy.com/cp/modules/view/id/154')

# Run unittest
if __name__ == "__main__":
    test_LinuxAcademyIE()

# Generated at 2022-06-12 17:58:24.620838
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    tst = LinuxAcademyIE()
    assert tst.IE_NAME == "linuxacademy:courses"
    assert tst._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'

# Generated at 2022-06-12 17:58:25.441794
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()

# Generated at 2022-06-12 17:58:26.787800
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-12 17:58:30.261440
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # init
    ie = LinuxAcademyIE()
    # get property value
    assert ie.AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie.ORIGIN_URL == 'https://linuxacademy.com'
    assert ie.CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-12 17:59:26.506386
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info = LinuxAcademyIE() 
    assert info

# Generated at 2022-06-12 17:59:27.848321
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-12 17:59:35.536943
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    # see class variables
    # print "[DEBUG] ie._VALID_URL = " + ie._VALID_URL
    # print "[DEBUG] ie._TESTS = " + str(ie._TESTS)
    # see class methods
    # print "[DEBUG] ie._real_initialize()"
    # ie._real_initialize()
    # print "[DEBUG] ie._login()"
    # ie._login()
    # print "[DEBUG] course example #1"
    # urls = ['https://linuxacademy.com/cp/modules/view/id/154']
    # for url in urls:
    #     print "[DEBUG] url = " + url
    #     i = ie._real_extract(url)
    #     print "[DEBUG] i = " + i


# Generated at 2022-06-12 17:59:47.802080
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    input_urls = [
        'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
        'https://linuxacademy.com/cp/modules/view/id/154'
    ]


# Generated at 2022-06-12 17:59:49.613060
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test that everything works using netrc
    ie = LinuxAcademyIE('LinuxAcademy')
    ie._login()
    LinuxAcademyIE('LinuxAcademy')

# Generated at 2022-06-12 17:59:59.221200
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxAcademyIE = LinuxAcademyIE('LinuxAcademy', 'linuxacademy')

# Generated at 2022-06-12 18:00:07.174290
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.name() == 'LinuxAcademy'
    assert ie.int_name() == 'LinuxAcademy'
    assert ie.description() == 'Linux Academy is the #1 online Linux education site.'
    assert ie.url_re() == ie._VALID_URL
    assert ie.test() == {
        'url': 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
        'only_matching': False,
        'skip': 'Requires Linux Academy account credentials',
    }


# Generated at 2022-06-12 18:00:12.651458
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert LinuxAcademyIE._ORIGIN_URL == 'https://linuxacademy.com'
    assert LinuxAcademyIE._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert LinuxAcademyIE._NETRC_MACHINE == 'linuxacademy'


# Generated at 2022-06-12 18:00:14.028904
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    a = LinuxAcademyIE()
    assert a

# Generated at 2022-06-12 18:00:15.281558
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 18:02:12.274398
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_ie = LinuxAcademyIE()

# Generated at 2022-06-12 18:02:15.452613
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-12 18:02:19.070538
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(LinuxAcademyIE.ie_key())
    ie._real_initialize()

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-12 18:02:19.886982
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    IE = LinuxAcademyIE()

# Generated at 2022-06-12 18:02:25.059593
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.IE_DESC == 'LinuxAcademy'
    assert ie._VALID_URL == 'https?://(?:www\\.)?linuxacademy\\.com/cp/courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)'
    assert ie.IE_KEY == 'LinuxAcademy'
    assert ie.NETRC_MACHINE == 'linuxacademy'



# Generated at 2022-06-12 18:02:27.184926
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    if not isinstance(LinuxAcademyIE, type):
        _test_LinuxAcademyIE()

# Generated at 2022-06-12 18:02:30.309593
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxAcademyIE = LinuxAcademyIE()
    temp = linuxAcademyIE._AUTHORIZE_URL
    assert temp is not None

# Generated at 2022-06-12 18:02:40.123267
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'linuxacademy'
    assert ie.IE_NAME == 'linuxacademy'
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-12 18:02:48.760017
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .common import test_notification
    from .common import test_html_content_sanitizer
    from .common import test_timestamp_counter
    from .common import test_video_with_smil_formats_and_metadata
    from .common import test_no_warning_on_extraction
    from .common import test_html_content_matches_with_metadata


# Generated at 2022-06-12 18:02:49.948010
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
        assert True == True
    except Exception:
        assert False == True
