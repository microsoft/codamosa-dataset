

# Generated at 2022-06-12 17:56:48.210515
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_extractors import _make_extractor
    _make_extractor(LinuxAcademyIE)

# Generated at 2022-06-12 17:56:56.113384
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_object = LinuxAcademyIE('LinuxAcademy', 'md5')
    assert (test_object._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize')
    assert (test_object._ORIGIN_URL == 'https://linuxacademy.com')
    assert (test_object._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx')
    assert (test_object._NETRC_MACHINE == 'linuxacademy')

    test_object = LinuxAcademyIE('LinuxAcademy', 'md5')
    assert (test_object._AUTHORIZE_URL is not None)
    assert (test_object._ORIGIN_URL is not None)

# Generated at 2022-06-12 17:56:57.524091
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    x = LinuxAcademyIE()
    assert type(x).__module__ == 'youtubedl.extractor.linuxacademy'

# Generated at 2022-06-12 17:57:01.852258
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    IE = LinuxAcademyIE()
    IE.initialize()
    IE._login()
    assert IE.get_test_result(url) == 'Expected output'

# Generated at 2022-06-12 17:57:03.792263
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE('NoUNITtest').ie_key() == 'linuxacademy'

# Generated at 2022-06-12 17:57:05.546858
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

# Generated at 2022-06-12 17:57:06.977634
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    my_inst = LinuxAcademyIE()
    print(my_inst)

# Generated at 2022-06-12 17:57:15.129567
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'
    assert LinuxAcademyIE.ie_name() == 'LinuxAcademy'
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'
    assert LinuxAcademyIE.ie_description() == 'Linux Academy online courses'
    assert LinuxAcademyIE.ie_keywords() == ['LinuxAcademy']
    assert LinuxAcademyIE.ie_url() == 'https://linuxacademy.com'
    assert LinuxAcademyIE.ie_icon() == 'https://linuxacademy.com/favicon.ico'
    assert LinuxAcademyIE.ie_logo() == 'https://linuxacademy.com/favicon.ico'

# Generated at 2022-06-12 17:57:16.987466
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    print(ie)



# Generated at 2022-06-12 17:57:18.082501
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # This test is just to check that LinuxAcademyIE is working
    # properly
    LinuxAcademyIE()

# Generated at 2022-06-12 17:57:51.049175
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    x = LinuxAcademyIE()

# Generated at 2022-06-12 17:58:03.493133
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert LinuxAcademyIE._NETRC_MACHINE == 'linuxacademy'
    assert LinuxAcademyIE._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert LinuxAcademyIE._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-12 17:58:05.746653
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 17:58:10.645503
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-12 17:58:11.498178
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_object = LinuxAcademyIE()

# Generated at 2022-06-12 17:58:15.723414
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_urls = ('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',)
    for test_url in test_urls:
        yield(LinuxAcademyIE, test_url)

# Generated at 2022-06-12 17:58:18.021597
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE('LinuxAcademyIE')

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-12 17:58:27.384138
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    success = True # So far the tests have been successful
    ie = LinuxAcademyIE()
    # Unit test for the constructor of class LinuxAcademyIE
    if ie._NETRC_MACHINE != 'linuxacademy':
        success = False
        print('Test failed: LinuxAcademyIE._NETRC_MACHINE attribute of class LinuxAcademyIE has the wrong value')
    if ie._CLIENT_ID != 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx':
        success = False
        print('Test failed: LinuxAcademyIE._CLIENT_ID attribute of class LinuxAcademyIE has the wrong value')
    if ie._ORIGIN_URL != 'https://linuxacademy.com':
        success = False

# Generated at 2022-06-12 17:58:30.423788
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 17:58:32.521499
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Unit test for constructor of class LinuxAcademyIE.
    """
    LinuxAcademyIE()

# Generated at 2022-06-12 17:59:27.074821
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._real_initialize() is None

# Generated at 2022-06-12 17:59:29.095124
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(None)
    ie._login()
    assert(ie)

# Generated at 2022-06-12 17:59:30.731803
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Unit test for constructor of class LinuxAcademyIE"""
    obj = LinuxAcademyIE()

# Generated at 2022-06-12 17:59:32.065434
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None)

# Generated at 2022-06-12 17:59:37.755484
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-12 17:59:41.442598
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    class TestLinuxAcademyIE(LinuxAcademyIE):
        def _login(self):
            pass

    TestLinuxAcademyIE()

# Generated at 2022-06-12 17:59:51.672948
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import re
    m = re.match(LinuxAcademyIE._VALID_URL, "https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675")
    assert m
    assert m.group("chapter_id") == "7971"
    assert m.group("lesson_id") == "2"
    assert not m.group("course_id")

    m = re.match(LinuxAcademyIE._VALID_URL, "https://linuxacademy.com/cp/modules/view/id/154")
    assert m
    assert not m.group("chapter_id")
    assert not m.group("lesson_id")
    assert m.group("course_id") == "154"

# Generated at 2022-06-12 17:59:57.975682
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    for url in [
            'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
            'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2',
            'https://linuxacademy.com/cp/modules/view/id/154']:
        print(LinuxAcademyIE._build_url_result(url))
        assert str(LinuxAcademyIE._build_url_result(url)) == url

# Generated at 2022-06-12 17:59:59.538089
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 18:00:02.741842
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'linuxacademy'
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademyIE'

# Generated at 2022-06-12 18:01:48.099531
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL ==  'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert ie._login_info().id == 'linuxacademy'
    assert ie._login() == None

# Generated at 2022-06-12 18:01:56.085052
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_cases = [
        {
            # Test valid lecture URL
            'url': 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
            'chapter_id': '7971',
            'lecture_id': '2',
            'course_id': None,
            'item_id': '7971-2'
        },
        {
            # Test valid course URL
            'url': 'https://linuxacademy.com/cp/modules/view/id/154',
            'chapter_id': None,
            'lecture_id': None,
            'course_id': '154',
            'item_id': '154'
        }
    ]
    for test_case in test_cases:
        mobj = re.match

# Generated at 2022-06-12 18:02:01.836011
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Url is a lesson url
    test_url = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    ie = LinuxAcademyIE()
    mobj = re.match(ie._VALID_URL, test_url)
    chapter_id = mobj.group('chapter_id')
    lesson_id = mobj.group('lesson_id')
    course_id = mobj.group('course_id')
    # course_id is None and chapter_id and lesson_id are not None
    assert course_id is None
    assert chapter_id is not None
    assert lesson_id is not None
    # Url is a course url
    test_url = 'https://linuxacademy.com/cp/modules/view/id/154'


# Generated at 2022-06-12 18:02:03.669662
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == "LinuxAcademy"

# Generated at 2022-06-12 18:02:08.582276
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert ie._TESTS[0]['url'] == 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'

# Generated at 2022-06-12 18:02:10.325064
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'
# unit test for class LinuxAcademyIE

# Generated at 2022-06-12 18:02:17.202380
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_cases = [
        # auth_data contains login information
        (True, None),
        # auth_data contains no login information
        (False, ExtractorError),
    ]
    for success, expected_exception in test_cases:
        try:
            LinuxAcademyIE({
                'auth': 'linuxacademy',
                'username': 'test_username' if success else None,
                'password': 'test_password' if success else None,
            })
        except Exception as e:
            assert isinstance(e, expected_exception)
        else:
            assert not expected_exception

# Generated at 2022-06-12 18:02:19.561441
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE('LinuxAcademy')
    assert obj._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-12 18:02:20.786232
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    m = LinuxAcademyIE(None)
    assert m is not None

# Generated at 2022-06-12 18:02:23.744499
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        # Test the constructor
        ie = LinuxAcademyIE()
        if ie._login is None:
            print('Constructor failed')
    except Exception:
        print('Failed to test constructor')

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-12 18:05:52.007107
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .. import LinuxAcademyIE
    test = LinuxAcademyIE()
    pass

# Generated at 2022-06-12 18:05:53.471915
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 18:05:54.692629
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie is not None

# Generated at 2022-06-12 18:06:05.140161
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = LinuxAcademyIE()._VALID_URL

# Generated at 2022-06-12 18:06:14.439822
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test the constructor
    ie = LinuxAcademyIE()
    assert(ie.IE_NAME == 'linuxacademy')
    assert(ie.IE_DESC == 'Linux Academy')
    assert(ie._VALID_URL == '(?x)https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)')

# Generated at 2022-06-12 18:06:15.111197
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 18:06:15.755526
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 18:06:17.282079
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None, {}, {'url': 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'})