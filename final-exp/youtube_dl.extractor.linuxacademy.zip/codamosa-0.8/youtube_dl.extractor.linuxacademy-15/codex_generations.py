

# Generated at 2022-06-12 17:56:54.445499
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    youtube_ie = LinuxAcademyIE()
    youtube_ie.extract(url='https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    assert youtube_ie.extract(url='https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')

# Generated at 2022-06-12 17:56:55.233231
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 17:57:01.401480
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        ie = LinuxAcademyIE('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
        error = None
        if not ie._login():
            if not ie._login():
                error = 'LinuxAcademyIE._login not return True or False.'
    except Exception as e:
        error = e

    assert not error

# Generated at 2022-06-12 17:57:04.125799
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
    except:
        assert False, 'Failed to create object of class LinuxAcademyIE'


# Generated at 2022-06-12 17:57:07.214366
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_LAIE = LinuxAcademyIE()
    assert test_LAIE.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-12 17:57:09.076092
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademy = LinuxAcademyIE('LinuxAcademy')
    assert LinuxAcademy is not None

# Generated at 2022-06-12 17:57:10.312248
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 17:57:11.877978
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    _test_class_validity(LinuxAcademyIE)

# Generated at 2022-06-12 17:57:13.212860
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert obj.name == 'linuxacademy'

# Generated at 2022-06-12 17:57:14.583918
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-12 17:57:51.645924
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-12 17:57:54.510840
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    IEObject = LinuxAcademyIE()
    assert IEObject.ie_key() == LinuxAcademyIE.ie_key()

# Generated at 2022-06-12 17:58:05.751970
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    inst = LinuxAcademyIE()
    assert inst._VALID_URL == 'https?://(?:www\\.)?linuxacademy\\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|modules/view/id/(?P<course_id>\\d+))'

# Generated at 2022-06-12 17:58:07.920118
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE(LinuxAcademyIE.ie_key())._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-12 17:58:11.343092
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE(None)._NETRC_MACHINE == 'linuxacademy'
    assert LinuxAcademyIE(None)._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'


# Generated at 2022-06-12 17:58:13.507552
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE(None)
    except Exception:
        print("Unit test failed.")

# Generated at 2022-06-12 17:58:22.093150
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Unit test for constructor of class LinuxAcademyIE"""
    class_test = LinuxAcademyIE()
    class_test._login()
    assert(class_test._NETRC_MACHINE == "linuxacademy")
    assert(class_test._AUTHORIZE_URL == "https://login.linuxacademy.com/authorize")
    assert(class_test._ORIGIN_URL == "https://linuxacademy.com")
    assert(class_test._CLIENT_ID == "KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx")

# Generated at 2022-06-12 17:58:29.472263
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'
    assert LinuxAcademyIE({}).ie_key() == 'LinuxAcademy'
    # test direct overide
    class LinuxAcademyChildIE(LinuxAcademyIE):
        pass
    child_ie = LinuxAcademyChildIE({})
    assert child_ie.ie_key() == 'LinuxAcademyChild'
    # test overide by changing _real_extract_classes
    class LinuxAcademyChild2IE(LinuxAcademyIE):
        _real_extract_classes = []
        pass
    child2_ie = LinuxAcademyChild2IE({})
    assert child2_ie.ie_key() == 'LinuxAcademy'
    # test overide by adding _real_extract_classes

# Generated at 2022-06-12 17:58:30.996520
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert "LinuxAcademyIE(" in str(ie)
    assert ie.ie_key() == 'linuxacademy'


# Generated at 2022-06-12 17:58:42.143096
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Create class instance
    LA_ie = LinuxAcademyIE()

    # Check if unit tests are running. If not, exit.
    if LA_ie._downloader is not None:
        exit()

    # Check if regex are set properly
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    m = re.match(LA_ie._VALID_URL, url)
    chapter_id, lesson_id, course_id = m.group('chapter_id', 'lesson_id', 'course_id')
    item_id = course_id if course_id else '%s-%s' % (chapter_id, lesson_id)

# Generated at 2022-06-12 17:59:37.417398
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'LinuxAcademy'

# Generated at 2022-06-12 17:59:42.390127
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    login_info = {"username": "username", "password": "password"}
    ie = LinuxAcademyIE(_NETRC_MACHINE, login_info)
    assert ie.username == "username"
    assert ie.password == "password"

# Generated at 2022-06-12 17:59:43.442794
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 17:59:44.706101
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie is not None

# Generated at 2022-06-12 17:59:46.582005
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.__class__.__name__ == 'LinuxAcademyIE'

# Generated at 2022-06-12 17:59:48.252210
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    inst = LinuxAcademyIE()
    assert isinstance(inst, LinuxAcademyIE)


# Generated at 2022-06-12 17:59:49.744826
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert issubclass(LinuxAcademyIE, InfoExtractor)

# Generated at 2022-06-12 17:59:52.102537
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Unit test for constructor of class LinuxAcademyIE."""

    i = LinuxAcademyIE()
    assert i

# Generated at 2022-06-12 17:59:53.250047
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 17:59:54.659039
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE("LinuxAcademy")


# Generated at 2022-06-12 18:01:45.925550
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('LinuxAcademy', 'linuxacademy.com')
    LinuxAcademyIE('LinuxAcademy', 'www.linuxacademy.com')


# Generated at 2022-06-12 18:01:49.454617
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_downloader import get_testcases_1

    for tc in get_testcases_1():
        if tc['expected'].get('skip') and 'Linux Academy account' not in tc['expected']['skip']:
            continue
        LinuxAcademyIE()._real_initialize()
        break

# Generated at 2022-06-12 18:01:55.403612
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    '''
    Unit test for constructor of class LinuxAcademyIE
    '''
    # Test with correct url
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    assert LinuxAcademyIE._VALID_URL.match(url)

    # Test with wrong url
    url = 'https://google.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    assert not LinuxAcademyIE._VALID_URL.match(url)

# Generated at 2022-06-12 18:01:58.415121
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from ..downloader import create_downloader
    from .common import InfoExtractor

    ydl = create_downloader({
        'username': 'TEST_USERNAME',
        'password': 'TEST_PASSWORD',
    })
    ie = InfoExtractor(ydl, 'LinuxAcademy')
    assert isinstance(ie, LinuxAcademyIE)

# Generated at 2022-06-12 18:02:01.728343
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.IE_DESC == 'Linux Academy'
    assert ie._LOGIN_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-12 18:02:04.507178
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = IE_TESTS['linuxacademy']('linuxacademy', 'linuxacademy:linuxacademy')
    ie.initialize()

    # It is not possible to test more than initialization

# Generated at 2022-06-12 18:02:05.736176
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    la = LinuxAcademyIE()
    print(type(la))

# Generated at 2022-06-12 18:02:08.170822
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    print('LinuxAcademyIE succesfully intialized')

# Generated at 2022-06-12 18:02:09.266955
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert isinstance(LinuxAcademyIE(), LinuxAcademyIE)



# Generated at 2022-06-12 18:02:11.724912
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    username = ie._username()
    password = ie._password()
    assert username is not None
    assert password is not None

# Generated at 2022-06-12 18:05:43.657666
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    instance._login()
    # Check if a specific method is available in the class
    assert hasattr(instance, '_real_initialize')
    assert hasattr(instance, '_real_extract')


# Generated at 2022-06-12 18:05:50.774594
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    constructor = LinuxAcademyIE()
    assert constructor._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert constructor._NETRC_MACHINE == 'linuxacademy'
    assert constructor._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert constructor._ORIGIN_URL == 'https://linuxacademy.com'
    assert constructor._AUTHOR

# Generated at 2022-06-12 18:05:53.702106
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # construct object
    ie = LinuxAcademyIE()
    # check type of object
    assert ie.__class__.__name__ == 'LinuxAcademyIE'

# Generated at 2022-06-12 18:06:04.284054
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Unit test for constructor of the class "LinuxAcademyIE".
    """

# Generated at 2022-06-12 18:06:05.541674
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'linuxacademy'

# Generated at 2022-06-12 18:06:09.560172
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    la = LinuxAcademyIE('LinuxAcademy', '1.0')
    print(la)

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-12 18:06:10.258856
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('LinuxAcademy')

# Generated at 2022-06-12 18:06:15.082719
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_LinuxAcademyIE = LinuxAcademyIE("")
    assert test_LinuxAcademyIE._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    return