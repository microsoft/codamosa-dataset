

# Generated at 2022-06-12 17:56:47.140291
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert obj

# Generated at 2022-06-12 17:56:50.365253
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Testing for constructor of class LinuxAcademyIE
    ie = LinuxAcademyIE()
    if not ie._login():
        raise ExtractorError('Unit test for LinuxAcademyIE failed.')
    print('Unit test for LinuxAcademyIE passed.')

# Generated at 2022-06-12 17:56:56.942698
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_linuxacademy_com import test_LinuxAcademyIE
    ie = test_LinuxAcademyIE(LinuxAcademyIE)
    # assert ie.IE_NAME == LinuxAcademyIE.IE_NAME
    assert ie._VALID_URL == LinuxAcademyIE._VALID_URL
    assert ie._NETRC_MACHINE == LinuxAcademyIE._NETRC_MACHINE
    assert ie._TESTS == LinuxAcademyIE._TESTS
    assert ie.__doc__ == LinuxAcademyIE.__doc__
    assert ie.SUCCESS == LinuxAcademyIE.SUCCESS
    assert ie.FAILURE == LinuxAcademyIE.FAILURE

# Generated at 2022-06-12 17:56:58.267784
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 17:57:06.035132
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-12 17:57:08.500648
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Unit test for constructor of class LinuxAcademyIE
    # Returns: instance of class LinuxAcademyIE
    return LinuxAcademyIE()

# Generated at 2022-06-12 17:57:11.833624
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    laie = LinuxAcademyIE()
    print('start to test LinuxAcademyIE!')
    try:
        laie._real_initialize()
    except:
        pass
    return

# Generated at 2022-06-12 17:57:14.108593
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ''' 
    Unit test for constructor of class LinuxAcademyIE
    '''
    obj = LinuxAcademyIE()
    assert obj != None

# Generated at 2022-06-12 17:57:24.939763
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    filename = 'test_LinuxAcademyIE.txt'
    web_page = open(filename, 'r').read()
    pattern1 = r'player\.lesson\s*=\s*({.+?})\s*;'
    obj1 = LinuxAcademyIE.extract_data(pattern1, web_page)
    assert obj1['timestamp'] == '2017-05-10T00:01:00+0000'
    assert obj1['lesson_name'] == 'JavaScript Objects'
    assert obj1['md_desc'] == 'In this lesson, we are going to discuss how to interact with Objects in JavaScript'

    pattern2 = r'player\.playlist\s*=\s*(\[.+?\])\s*;'

# Generated at 2022-06-12 17:57:28.779003
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    if "LinuxAcademyIE" != ie.IE_NAME:
        raise AssertionError("Unexpected value for IE_NAME")
    if "LinuxAcademy" != ie.IE_DESC:
        raise AssertionError("Unexpected value for IE_DESC")
    if "linuxacademy.com" != ie._NETRC_MACHINE:
        raise AssertionError("Unexpected value for _NETRC_MACHINE")



# Generated at 2022-06-12 17:58:03.895497
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
        assert True
    except Exception as err:
        assert False, err

# Generated at 2022-06-12 17:58:04.912065
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None)._login()

# Generated at 2022-06-12 17:58:05.912591
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 17:58:08.015890
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_cases = [
        LinuxAcademyIE(username='foo',password='bar'),
        LinuxAcademyIE(username='foo',password='bar',token_secret='baz')
    ]
    return test_cases

# Generated at 2022-06-12 17:58:08.894130
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 17:58:16.533320
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademy_ie = LinuxAcademyIE()
    assert linuxacademy_ie._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/modules/view/id/(?P<course_id>\d+)'
    assert linuxacademy_ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert linuxacademy_ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert linuxacademy_ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert linuxacademy_ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-12 17:58:18.241864
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .common import InfoExtractor
    InfoExtractor.test()
    return LinuxAcademyIE

# Generated at 2022-06-12 17:58:23.965115
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, LinuxAcademyIE)
    assert isinstance(ie._AUTHORIZE_URL, str)
    assert isinstance(ie._ORIGIN_URL, str)
    assert isinstance(ie._CLIENT_ID, str)
    assert isinstance(ie._NETRC_MACHINE, str)

# Generated at 2022-06-12 17:58:26.487040
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.IE_DESC == 'linuxacademy.com'

# Generated at 2022-06-12 17:58:29.573436
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    testurl = 'https://linuxacademy.com/cp/modules/view/id/154'
    la = LinuxAcademyIE()
    test = la._real_initialize()
    test2 = la._real_extract(testurl)
    assert test == None
    assert test2 != None
    assert test2['id'] == testurl[-3:]

# Generated at 2022-06-12 18:00:04.526081
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE("LinuxAcademyIE", "linuxacademy")
    linuxacademy = LinuxAcademyIE("LinuxAcademyIE", "linuxacademy")
    # Test for a nonexistent function
    try:
        linuxacademy.assert_func('assert_func')
    except Exception:
        pass
    # Test for a nonexistent key
    try:
        linuxacademy._get_login_info()
    except Exception:
        pass

# Generated at 2022-06-12 18:00:10.765444
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.__class__.__name__ == 'LinuxAcademyIE'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'


# Generated at 2022-06-12 18:00:17.337453
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE('linuxacademy', 'linuxacademy')
    assert bool(ie._AUTHORIZE_URL)
    assert bool(ie._ORIGIN_URL)
    assert bool(ie._CLIENT_ID)
    assert bool(ie._NETRC_MACHINE)

# Generated at 2022-06-12 18:00:19.459825
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():

    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'

    ie = LinuxAcademyIE()
    ie._login()

# Generated at 2022-06-12 18:00:25.745346
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info_dict = LinuxAcademyIE("https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675").extract()
    assert "What Is Data Science" == info_dict['title']
    assert "This lecture will introduce the concepts behind data science, including big data and machine learning." == info_dict['description']
    assert 1607387907 == info_dict['timestamp']
    assert 304 == info_dict['duration']

# Generated at 2022-06-12 18:00:36.478182
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import unittest
    from YoutubeDL.extractor import LinuxAcademyIE
    from YoutubeDL.extractor import InfoExtractor
    from YoutubeDL import YoutubeDL
    from YoutubeDL.utils import ConflictError
    from .test_common import get_testcases
    from . import get_testcases as test_linuxacademy
    from . import get_testcases as test_common

    # Testing for class LinuxAcademyIE class without any error
    class TestLinuxAcademyIE(unittest.TestCase):
        def setUp(self):
            self.ie = LinuxAcademyIE(YoutubeDL({}))

        def test_succesful_construction(self):
            self.assertEqual(self.ie.ie_key(), 'LinuxAcademy')

    # Testing for class LinuxAcademyIE class with error

# Generated at 2022-06-12 18:00:37.367661
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('LinuxAcademy')

# Generated at 2022-06-12 18:00:46.249463
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    init_data = extractor = None
    init_data = {
        '__init__': {'url': url, 'ie': LinuxAcademyIE(), 'playlist_mincount': 0}
    }
    for test_data in init_data.values():
        ie = test_data.pop('ie')
        extractor = ie.__class__(**test_data)
        assert extractor._VALID_URL == LinuxAcademyIE.VALID_URL
        assert extractor._AUTHORIZE_URL == LinuxAcademyIE.AUTHORIZE_URL
        assert extractor._ORIGIN_URL == LinuxAcademyIE.ORIGIN_URL
        assert extractor._CLIENT_ID == LinuxAcademyIE.CLIENT_ID
        assert extractor._NETRC_MACHINE == LinuxAcademyIE

# Generated at 2022-06-12 18:00:47.979488
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    return LinuxAcademyIE(
    )

# Generated at 2022-06-12 18:00:53.461904
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE().suitable("https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675")
    assert LinuxAcademyIE().suitable("https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2")
    assert LinuxAcademyIE().suitable("https://linuxacademy.com/cp/modules/view/id/154")
    

# Generated at 2022-06-12 18:02:46.794809
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    a = LinuxAcademyIE('http://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    assert a.ie_key() == 'LinuxAcademy'
    assert a.ie_name() == 'LinuxAcademy'
    #assert a.download == a._download_webpage

# Generated at 2022-06-12 18:02:48.514454
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE('LinuxAcademy')
    assert ie is not None

# Generated at 2022-06-12 18:02:49.770907
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 18:02:55.103803
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print(LinuxAcademyIE._build_url_result('https://linuxacademy.com/cp/modules/view/id/154'))
    print(LinuxAcademyIE._build_url_result('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'))

# Generated at 2022-06-12 18:02:57.200872
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert not LinuxAcademyIE()._LOGIN_REQUIRED

# Generated at 2022-06-12 18:02:58.081177
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-12 18:03:00.764918
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Here are the unit tests for the LinuxAcademyIE.
# If tests fail, correct the code please.

# Generated at 2022-06-12 18:03:02.714210
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert obj._CLIENT_ID is not None
    assert obj._ORIGIN_URL is not None

# Generated at 2022-06-12 18:03:06.038003
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    module = LinuxAcademyIE()
    assert module.get_blacklist_ie_key()
    assert module.is_logged()

# Generated at 2022-06-12 18:03:09.798771
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    my_ia = LinuxAcademyIE()
    assert my_ia.IE_NAME == 'LinuxAcademy'
    assert my_ia._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|modules/view/id/(?P<course_id>\\d+))'