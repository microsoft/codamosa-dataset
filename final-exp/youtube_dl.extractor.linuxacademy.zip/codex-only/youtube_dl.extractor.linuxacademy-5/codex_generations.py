

# Generated at 2022-06-24 12:47:31.036265
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert isinstance(LinuxAcademyIE(), InfoExtractor)


# Generated at 2022-06-24 12:47:42.243944
# Unit test for constructor of class LinuxAcademyIE

# Generated at 2022-06-24 12:47:53.440767
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_assert(LinuxAcademyIE._VALID_URL == LinuxAcademyIE.VALID_URL)
    test_assert(LinuxAcademyIE._TESTS == LinuxAcademyIE.TESTS)
    # Make sure every test includes linux_academy
    for test in LinuxAcademyIE._TESTS:
        test_assert(isinstance(test, dict))
        test_assert('linuxacademy' in test['url'])
    test_assert(LinuxAcademyIE._AUTHORIZE_URL == LinuxAcademyIE.AUTHORIZE_URL)
    test_assert(LinuxAcademyIE._ORIGIN_URL == LinuxAcademyIE.ORIGIN_URL)

# Generated at 2022-06-24 12:47:56.885665
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert LinuxAcademyIE()._NETRC_MACHINE == 'linuxacademy'


# Generated at 2022-06-24 12:48:03.642396
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

    # Test if _CLIENT_ID is set to a valid value
    assert ie._CLIENT_ID
    assert len(ie._CLIENT_ID) >= 1

    # Test if _AUTHORIZE_URL is set to a valid value
    assert ie._AUTHORIZE_URL
    assert re.match(r'https?://.*?\.com/.*?', ie._AUTHORIZE_URL)

    # Test if _ORIGIN_URL is set to a valid value
    assert ie._ORIGIN_URL
    assert re.match(r'https?://.*?\.com/.*?', ie._ORIGIN_URL)

    # Test if _NETRC_MACHINE is set to a valid value
    assert ie._NETRC_MACHINE

# Generated at 2022-06-24 12:48:13.787883
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_input = [
        {
            'URL': 'https://linuxacademy.com/cp/modules/view/id/154',
            'playlist_count': 41,
        },
    ]
    for t in test_input:
        result = LinuxAcademyIE().extract(t['URL'])
        assert result['_type'] == 'playlist'
        assert len(result['entries']) == t['playlist_count']
        assert 'https://linuxacademy.com/cp/lessons/module/154/lessons/26823' in result['entries'][0]['url']
        assert 'https://linuxacademy.com/cp/lessons/module/154/lessons/26842' in result['entries'][1]['url']

# Generated at 2022-06-24 12:48:20.749423
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'

# Generated at 2022-06-24 12:48:24.913302
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    infoExtractor = LinuxAcademyIE(None)
    assert infoExtractor._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert infoExtractor._NETRC_MACHINE == 'linuxacademy'


# Generated at 2022-06-24 12:48:25.582576
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE

# Generated at 2022-06-24 12:48:26.426459
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE

# Generated at 2022-06-24 12:48:27.947899
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert XboxClipsIE()._VALID_URL('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')

# Generated at 2022-06-24 12:48:28.599685
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:48:31.016408
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'

# Generated at 2022-06-24 12:48:41.601700
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_obj = object.__new__(LinuxAcademyIE)
    assert test_obj.ie_name() == "linuxacademy"
    assert test_obj.ie_key() == "LinuxAcademy"
    assert test_obj.ie_description() == "Linux Academy"
    # Output a list containing valid video URL and a video information dictionnary
    test_url, test_info = test_obj._extract_valid_url_and_video_info("https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675")
    assert test_url == "https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675"
    assert isinstance(test_info, dict)
    assert test

# Generated at 2022-06-24 12:48:42.480926
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:48:45.393662
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:48:48.709432
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Unit test for LinuxAcademyIE
    # Returns a test instance of LinuxAcademyIE
    youtube_ie = LinuxAcademyIE()
    return youtube_ie

# Generated at 2022-06-24 12:48:50.091372
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # This is not a real test, just a constructor unit test to check if failure
    # is raised or not.
    LinuxAcademyIE('LinuxAcademy', 'linuxacademy.com')

# Generated at 2022-06-24 12:48:56.054051
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test import TestIE

    def test_with_url(url, *args, **kwargs):
        request = kwargs.pop('request')

        ie = LinuxAcademyIE()
        assert ie.suitable(url), url  # url should be suitable for this instance of the class
        test_ie = TestIE(ie, url, *args, **kwargs)
        test_ie.run(request=request)


# Generated at 2022-06-24 12:49:06.055575
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Unit test for valid url
    url = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    ied = LinuxAcademyIE()
    assert ied._VALID_URL == re.compile(r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    ''')

    # Unit test for invalid url
    url = 'https://www.youtube.com/watch/?v=JyNHaTjT9Sc'
   

# Generated at 2022-06-24 12:49:09.436391
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    video_info = ie._real_extract('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    assert video_info['id']

# Generated at 2022-06-24 12:49:16.569284
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert LinuxAcademyIE.IE_NAME == ie.IE_NAME
    ie.login()
    assert re.match(LinuxAcademyIE._VALID_URL, 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'
    ie.extract('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:49:22.181607
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # The site is highly dynamic, and too much a PITA to test, so we just test
    # the login function with a valid password and a bad one
    ies = [LinuxAcademyIE(), LinuxAcademyIE()]
    for (pw, valid) in (('BADPASSWORD', False), ('GOODPASSWORD', True)):
        ies[0]._netrc_password = pw
        ies[1]._password = pw
        for ie in ies:
            try:
                ie._login()
                assert valid
            except ExtractorError as e:
                assert not valid, e.message

# Generated at 2022-06-24 12:49:27.075083
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    with pytest.raises(ExtractorError) as exc_info:
        LinuxAcademyIE().login()
    LinuxAcademyIE()._real_initialize()
    LinuxAcademyIE()._real_extract('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')

# Generated at 2022-06-24 12:49:29.612359
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Constructor without providing any argument
    LinuxAcademyIE()
    # Constructor with providing arguments
    LinuxAcademyIE(None, 'username', 'password')

# Generated at 2022-06-24 12:49:30.579578
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:49:35.296657
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    la_ie = LinuxAcademyIE()
    print(la_ie._AUTHORIZE_URL)
    print(la_ie._ORIGIN_URL)
    print(la_ie._CLIENT_ID)
    print(la_ie._NETRC_MACHINE)

if __name__ == '__main__':
    test_LinuxAcademyIE()
    print('Done')

# Generated at 2022-06-24 12:49:42.195466
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info = LinuxAcademyIE()._real_extract('https://linuxacademy.com/cp/modules/view/id/154')
    course_id = info['id']

    assert re.match(r'\d+', course_id) is not None
    if course_id == '154':
        assert 'AWS Certified Cloud Practitioner' == info['title']
        assert 'md5:a68a299ca9bb98d41cca5abc4d4ce22c' == info['description']
        assert info['duration'] == 28835
        assert len(info['entries']) == 41
    else:
        # course 155 has same video titles as course 154, so title comparison will fail
        assert 'AWS Certified Cloud Practitioner' == info['title']

# Generated at 2022-06-24 12:49:46.772757
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test constructor of class LinuxAcademyIE"""
    if not LinuxAcademyIE.working():
        pytest.skip(msg='LinuxAcademyIE requires login, skipping test.')
    LinuxAcademyIE('LinuxAcademy', 'linuxacademy.com')

# Generated at 2022-06-24 12:49:49.648328
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Constructing a instance of LinuxAcademyIE should not raise any error
    """
    # pylint: disable=W0108
    ie = LinuxAcademyIE()

# Generated at 2022-06-24 12:49:52.484738
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
    except Exception as e:
        print(e)
        assert False, "Invalid construction of LinuxAcademyIE"


# Generated at 2022-06-24 12:49:58.699695
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test login with invalid credentials
    ie = LinuxAcademyIE()
    ie.username = 'invalid_username'
    ie.password = 'invalid_password'
    ie.login()

    # Test login with valid credentials
    ie.username = 'bfirmansyah84@gmail.com'
    ie.password = 'password'
    ie.login()

# Generated at 2022-06-24 12:50:04.664562
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert 'login' in obj._real_initialize.__name__
    assert 'extract' in obj._real_extract.__name__
    assert 'LinuxAcademy' in obj.IE_NAME
    assert 'LinuxAcademy' in obj.IE_DESC
    assert obj._VALID_URL
    assert obj.ie_key() == 'LinuxAcademy'
    assert obj._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:50:07.574709
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    class Object(object):
        pass
    x = "aws-certified-cloud-practitioner-course"
    v = Object()
    v.group = lambda x: x
    v.group.__getitem__ = lambda s, i: x
    assert LinuxAcademyIE._real_extract(v, x)

# Generated at 2022-06-24 12:50:09.145664
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info = LinuxAcademyIE()
    return info


# Generated at 2022-06-24 12:50:21.438437
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.IE_DESC == 'Linux Academy'
    assert ie._VALID_URL == r'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'

# Generated at 2022-06-24 12:50:32.809523
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test the constructor parameters
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert ie._TESTS[0]['url'] == 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    assert ie._TESTS[0]['info_dict']['id'] == '7971-2'
    assert ie._TESTS[0]['info_dict']['title'] == 'What Is Data Science'

# Generated at 2022-06-24 12:50:35.439367
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:50:37.778232
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
  class_ = LinuxAcademyIE
  test_inst = class_()
  assert test_inst.__class__ == class_

# Generated at 2022-06-24 12:50:38.754915
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()


# Generated at 2022-06-24 12:50:41.324676
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_LinuxAcademyIE_instance = LinuxAcademyIE()
    assert isinstance(test_LinuxAcademyIE_instance, LinuxAcademyIE)

# Generated at 2022-06-24 12:50:44.576351
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Instantiate the class
    Lin_Academy = LinuxAcademyIE()
    # Call the constructor
    Lin_Academy._real_initialize()


if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:50:52.573916
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    url = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    mobj = re.match(ie._VALID_URL, url)
    chapter_id, lesson_id, course_id = mobj.group('chapter_id', 'lesson_id', 'course_id')
    item_id = course_id if course_id else '%s-%s' % (chapter_id, lesson_id)
    assertion = chapter_id == '1498' and lesson_id == '2' and course_id == None and item_id == '1498-2'
    assert assertion, "LinuxAcademyIE.__init__() failed"
    

# Generated at 2022-06-24 12:50:53.774974
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:50:56.574958
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Without credentials
    LinuxAcademyIE(None)
    # Successfull Login
    LinuxAcademyIE(None)

# Generated at 2022-06-24 12:51:00.627930
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Arrange
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    # Act
    result = LinuxAcademyIE().extract(url)
    # Assert
    assert 'playlist' == result['_type']

# Generated at 2022-06-24 12:51:02.268970
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE(None)._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:51:03.499198
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()


# Generated at 2022-06-24 12:51:07.511285
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test creation of class
    ie_obj=LinuxAcademyIE()

    # Test the login functionality
    username = "USERNAME"
    password = "PASSWORD"
    ie_obj.username = username
    ie_obj.password = password
    ie_obj._login()

# Generated at 2022-06-24 12:51:08.443880
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:51:09.476547
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None)

# Generated at 2022-06-24 12:51:11.588994
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from . import linuxacademy
    return not linuxacademy.LinuxAcademyIE()._login_required



# Generated at 2022-06-24 12:51:13.310552
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie is not None


# Generated at 2022-06-24 12:51:14.661583
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()

# Generated at 2022-06-24 12:51:25.678266
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    my_LinuxAcademyIE = LinuxAcademyIE()
    assert (my_LinuxAcademyIE._NETRC_MACHINE == 'linuxacademy'), "test_LinuxAcademyIE: assert #1 failed"
    assert (my_LinuxAcademyIE._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'), "test_LinuxAcademyIE: assert #2 failed"
    assert (my_LinuxAcademyIE._ORIGIN_URL == 'https://linuxacademy.com'), "test_LinuxAcademyIE: assert #3 failed"

# Generated at 2022-06-24 12:51:27.584823
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert(LinuxAcademyIE.ie_key() == 'linuxacademy')

# Unit testing

# Generated at 2022-06-24 12:51:32.622650
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Tests for constructor of class LinuxAcademyIE."""
    name = LinuxAcademyIE.__name__
    class_ = globals()[name]
    instance = class_()
    assert instance.__class__ == class_
    assert isinstance(instance, (InfoExtractor,))

# Generated at 2022-06-24 12:51:33.798370
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:51:34.806553
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    temp = LinuxAcademyIE()

# Generated at 2022-06-24 12:51:37.920435
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert obj._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-24 12:51:42.462172
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    infoExtractor = LinuxAcademyIE()
    assert infoExtractor is not None
    assert infoExtractor._VALID_URL is not None
    assert infoExtractor._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert infoExtractor._ORIGIN_URL == 'https://linuxacademy.com'
    assert infoExtractor._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert infoExtractor._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:51:44.109054
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None, None, None)

# Generated at 2022-06-24 12:51:47.204837
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Constructor
    obj=LinuxAcademyIE() # This will raise an exception if it fails
    assert isinstance(obj, LinuxAcademyIE)


# Generated at 2022-06-24 12:51:49.461597
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    if test_LinuxAcademyIE.__name__ == '__main__':
        test_LinuxAcademyIE()
    else:
        pass

# Generated at 2022-06-24 12:51:51.611046
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
    except (AttributeError, NameError):
        raise # exception expected


# Generated at 2022-06-24 12:51:53.311558
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert isinstance(instance, LinuxAcademyIE)


# Generated at 2022-06-24 12:51:55.922292
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    repr(ie)
    ie.suitable('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')

# Generated at 2022-06-24 12:51:56.752011
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:51:57.708288
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:51:59.347525
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Explicitly test without login
    LinuxAcademyIE()

# Generated at 2022-06-24 12:52:02.948824
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Parse https://linuxacademy.com/cp/modules/view/id/154
    """
    LinuxAcademyIE('https://linuxacademy.com/cp/modules/view/id/154')

# Generated at 2022-06-24 12:52:04.244444
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None, None, None)

# Generated at 2022-06-24 12:52:07.363343
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Unit test for constructor of class LinuxAcademyIE
    """
    # pylint:disable=maybe-no-member,too-few-public-methods
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:52:10.181220
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_acad_ie = LinuxAcademyIE()
    #Checking if linux academy login is done
    if linux_acad_ie._login():
        return True
    else:
        return False

# Generated at 2022-06-24 12:52:16.453605
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|modules/view/id/(?P<course_id>\\d+))'  # noqa

# Generated at 2022-06-24 12:52:23.138024
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print('Constructor test for class LinuxAcademyIE')
    print('Attempting to instantiate the constructor')
    try:
        ie = LinuxAcademyIE()
    except Exception as e:
        print('FAILED: Could not instantiate the constructor\n{}'.format(e))
        raise
    print('SUCCESS: Constructor instantiated')
    print('Releasing the object')
    del ie
    pass


# Generated at 2022-06-24 12:52:27.382684
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    print(ie.IE_NAME)
    print(ie.IE_DESC)
    print(ie.VALID_URL)
    print(ie.extract('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'))

# Generated at 2022-06-24 12:52:28.368961
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:52:33.839535
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
  try:
    url_test = "https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2"
    ie = LinuxAcademyIE()
    ie._login()
    ie._real_extract(url_test)
    print('Test succeeded')
  except:
    print('Test failed')

if __name__ == '__main__':
  test_LinuxAcademyIE()

# Generated at 2022-06-24 12:52:34.853452
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:52:38.685513
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Normal usage test
    LinuxAcademyIE('LinuxAcademy', 'linuxacademy.com', 'username', 'password')
    # Username and/or password not provided test
    LinuxAcademyIE('LinuxAcademy', 'linuxacademy.com', None, None)

# Generated at 2022-06-24 12:52:40.561971
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == "linuxacademy"

# Generated at 2022-06-24 12:52:42.519964
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:52:54.368685
# Unit test for constructor of class LinuxAcademyIE

# Generated at 2022-06-24 12:52:55.962316
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
    except Exception:
        pass

# Generated at 2022-06-24 12:52:57.363793
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print(LinuxAcademyIE('LinuxAcademy'))

# Generated at 2022-06-24 12:53:04.290237
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    expected = '{"extraParams": {"scope": "openid email user_impersonation profile", "redirect_uri": "https://linuxacademy.com", "connection": "Userna...'
    assert ie._parse_json(
        ie._search_regex(
            r'atob\(\s*(["\'])(?P<value>(?:(?!\1).)+)\1', expected,
            'login info', group='value'), None,
        transform_source=lambda x: compat_b64decode(x).decode('utf-8')
    )['extraParams'] == expected

# Generated at 2022-06-24 12:53:08.652889
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import unittest
    from . import LinuxAcademyIE

    test = LinuxAcademyIE()
    test.login()

    print("\n" + str(LinuxAcademyIE))
    print(test.AUTHORIZE_URL)
    print(test.CLIENT_ID)
    print(test.NETRC_MACHINE)
    print(test.ORIGIN_URL)

# Generated at 2022-06-24 12:53:09.632704
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('LinuxAcademy')

# Generated at 2022-06-24 12:53:20.848259
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Example
    {
    "_type": "url_transparent",
    "url": "http://www.linuxacademy.com/cp/courses/lesson/course/1498/lesson/2",
    "title": "Instructor Introduction",
    "description": "Welcome to this course. We will introduce ourselves and explain our goals. ",
    "duration": 305,
    "timestamp": 1392815900,
    }
    """

    # test LinuxAcademyIE(InfoExtractor)
    ie =  LinuxAcademyIE()
    # test LinuxAcademyIE._real_extract
    course = ie._real_extract('http://www.linuxacademy.com/cp/modules/view/id/154')
    assert course['_type'] == 'playlist'

# Generated at 2022-06-24 12:53:24.494270
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Unit test for constructor of class LinuxAcademyIE"""
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    assert LinuxAcademyIE._VALID_URL.match(url) is not None
    assert LinuxAcademyIE.suitable(url) is True

# Generated at 2022-06-24 12:53:34.971278
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-24 12:53:39.078793
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE('LinuxAcademyIE', None, None)
    ie._login()
    test = ie.extract('https://linuxacademy.com/cp/modules/view/id/154')
    assert test['_type'] == 'playlist'
    assert test['id'] == '154'
    assert len(test['entries']) == 41

# Generated at 2022-06-24 12:53:44.224135
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.suitable("https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2")
    assert ie.suitable("https://linuxacademy.com/cp/modules/view/id/154")

# Generated at 2022-06-24 12:53:46.129346
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    '''
    See https://github.com/ytdl-org/youtube-dl/pull/19666#issuecomment-589872906
    '''
    # First, just test if it can be initialized
    LinuxAcademyIE()

# Generated at 2022-06-24 12:53:49.840035
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        import requests
    except ImportError:
        requests = None
    if requests:
        ie = LinuxAcademyIE()
        assert ie._downloader is not None
    else:
        ie = LinuxAcademyIE()
        assert ie._downloader is None

# Generated at 2022-06-24 12:53:51.698490
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None, None)

test_LinuxAcademyIE()

# Generated at 2022-06-24 12:53:56.693713
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Verifies that the contructor of class LinuxAcademyIE works."""
    filename = 'linux-academy-class-LinuxAcademyIE.conf'
    if not os.path.isfile(filename):
        pytest.skip("No credentials file found: " + filename)
    return LinuxAcademyIE()

# Generated at 2022-06-24 12:53:57.784665
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:54:09.179320
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .netrc import netrc
    from .exceptions import RegexNotFoundError
    from .compat import exists
    from .utils import urljoin
    from .compat import compat_str
    class LinuxAcademyIE(InfoExtractor):
        _NETRC_MACHINE = 'linuxacademy'
        _VALID_URL = r'https?://www\.linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'

# Generated at 2022-06-24 12:54:20.761450
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(None)
    assert ie.IE_NAME == 'linuxacademy'
    assert ie._VALID_URL == r'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'

# Generated at 2022-06-24 12:54:31.688080
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_url = 'https://linuxacademy.com/cp/modules/view/id/154'
    url_list = ['https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
                'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2',
                'https://linuxacademy.com/cp/modules/view/id/154']
    test_info = {
        'id': '154',
        'title': 'AWS Certified Cloud Practitioner',
        'description': 'md5:a68a299ca9bb98d41cca5abc4d4ce22c',
        'duration': 28835,
    }

# Generated at 2022-06-24 12:54:41.027922
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.suitable('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675') == True
    assert LinuxAcademyIE.suitable('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2') == True
    assert LinuxAcademyIE.suitable('https://linuxacademy.com/cp/modules/view/id/154') == True
    assert LinuxAcademyIE.suitable('https://linuxacademy.com/cp/modules/view/name/intro-to-big-data-and-apache-hadoop') == True

# Generated at 2022-06-24 12:54:42.403468
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()._valid_url('1', '2')

# Generated at 2022-06-24 12:54:43.683187
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'LinuxAcademy'

# Generated at 2022-06-24 12:54:44.583202
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(IE_NAME, True)

# Generated at 2022-06-24 12:54:46.097651
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Test case for LinuxAcademyIE()
    """
    LinuxAcademyIE()

# Generated at 2022-06-24 12:54:46.879463
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:54:48.165813
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    ie._login()

# Generated at 2022-06-24 12:54:54.562410
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    '''
    Test construction of class LinuxAcademyIE.
    '''
    linux_academy_ie = LinuxAcademyIE()
    assert linux_academy_ie is not None
    assert linux_academy_ie.ie_key() == 'LinuxAcademy'
    assert linux_academy_ie.name == 'Linux Academy'

# Generated at 2022-06-24 12:54:56.473290
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE();
    assert ie.IE_NAME == 'linuxacademy'

# Generated at 2022-06-24 12:54:59.950425
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE().test('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    assert LinuxAcademyIE().test('https://linuxacademy.com/cp/modules/view/id/154')

# Generated at 2022-06-24 12:55:00.733901
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Constructor of class LinuxAcademyIE
    LinuxAcademyIE(None)

# Generated at 2022-06-24 12:55:01.689065
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:55:13.994565
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_urls = (
        ('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2', {}),
        ('https://linuxacademy.com/cp/modules/view/id/154', {
            'title': 'AWS Certified Cloud Practitioner',
            'description': 'This course is designed to start your journey with AWS. We will cover the most important aspects of AWS and give you a solid foundation to prepare for learning more and gaining further certifications.',
            'duration': 28835
        })
    )

    # test for class initialization
    for (url, expected_data) in test_urls:
        ie = LinuxAcademyIE()
        item = ie._real_extract(url)
        assert item.get('title') == expected_data.get('title')
       

# Generated at 2022-06-24 12:55:15.754895
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'

    assert 'linuxacademy.com' in ie.working

# Generated at 2022-06-24 12:55:26.419845
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    To run:
    `python -m unittest -v test_LinuxAcademyIE`
    """
    import unittest

    class TestLinuxAcademyIE(unittest.TestCase):
        def test_constructor(self):
            LinuxAcademyIE = globals()['LinuxAcademyIE']
            self.assertEqual(LinuxAcademyIE._AUTHORIZE_URL, 'https://login.linuxacademy.com/authorize')
            self.assertEqual(LinuxAcademyIE._ORIGIN_URL, 'https://linuxacademy.com')
            self.assertEqual(LinuxAcademyIE._CLIENT_ID, 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx')
            self.assertE

# Generated at 2022-06-24 12:55:27.143774
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:55:34.105830
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    if 1:
        assert LinuxAcademyIE().ie_key('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2') == 'LinuxAcademy'
        assert LinuxAcademyIE().ie_key('https://linuxacademy.com/cp/modules/view/id/154') == 'LinuxAcademy'
        assert LinuxAcademyIE().ie_key('https://www.linuxacademy.com/cp/courses/lesson/course/1498/lesson/2') == 'LinuxAcademy'
        assert LinuxAcademyIE().ie_key('https://www.linuxacademy.com/cp/modules/view/id/154') == 'LinuxAcademy'

# Generated at 2022-06-24 12:55:37.185648
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test constructor of class LinuxAcademyIE."""
    # without a password
    LinuxAcademyIE('linuxacademy')

    # with a password
    LinuxAcademyIE('linuxacademy', 'password')

# Generated at 2022-06-24 12:55:39.852817
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-24 12:55:41.934485
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_cases.test_linuxacademy import test_LinuxAcademy
    test_LinuxAcademy().run()

# Generated at 2022-06-24 12:55:51.031146
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'(?x)\Ahttps?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))\Z'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-24 12:55:53.408216
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Constructs and returns an instance of LinuxAcademyIE."""
    return LinuxAcademyIE()

# Generated at 2022-06-24 12:55:54.850713
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert isinstance(LinuxAcademyIE(), InfoExtractor)


# Generated at 2022-06-24 12:55:59.254293
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .common import ExtractorError
    from .common import g_password_protected_video_urls

    for url in g_password_protected_video_urls:
        with pytest.raises(ExtractorError):
            LinuxAcademyIE()._real_extract(url)

# Generated at 2022-06-24 12:56:04.607988
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    inst = LinuxAcademyIE()
    assert inst.login_page == 'https://login.linuxacademy.com/authorize'
    assert inst.client_id == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert inst.login_done_page == 'https://login.linuxacademy.com/login/callback'

# Generated at 2022-06-24 12:56:05.585583
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:56:07.213907
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE("video_url")
    assert True

# Generated at 2022-06-24 12:56:09.996073
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_obj = LinuxAcademyIE('LinuxAcademyIE', 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675', {}, {})
    assert(test_obj.get_instance_id() == '249e9e59b391441d8cdbf30bd75b12f2')

# Generated at 2022-06-24 12:56:12.635237
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert(ie._LOGIN_URL == 'https://login.linuxacademy.com/login')

# Generated at 2022-06-24 12:56:15.166652
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    a = LinuxAcademyIE()
    a.to_screen('test')
    a.add_default_info_extractors()
    a.add_default_openers()

# Generated at 2022-06-24 12:56:17.233549
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:56:18.560850
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie is not None


# Generated at 2022-06-24 12:56:28.237706
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    class_name = LinuxAcademyIE.__name__
    # Construction of class
    obj1 = LinuxAcademyIE()
    assert obj1.__class__.__name__ == class_name, \
            "obj1.__class__.__name__ != {0}".format(class_name)
    # To check if the _VALID_URL is a valid regular expression string
    assert re.match(LinuxAcademyIE._VALID_URL, \
                     obj1._VALID_URL) != None, \
                    "re.match(Inspector._VALID_URL, obj1._VALID_URL) == None)"

# Generated at 2022-06-24 12:56:30.652985
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert(LinuxAcademyIE().ie_key() == 'LinuxAcademy')
    assert(LinuxAcademyIE().IE_NAME == 'LinuxAcademy')
    assert(LinuxAcademyIE()._NETRC_MACHINE == 'linuxacademy')

# Generated at 2022-06-24 12:56:33.070451
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        import keyring
        keyring.set_password('LinuxAcademy', 'username', 'password')
    except Exception:
        pass

    LinuxAcademyIE()

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:56:37.027039
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Unit test for the constructor of class LinuxAcademyIE
    # Assert the static variable _NETRC_MACHINE
    assert LinuxAcademyIE._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:56:38.029757
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:56:39.960080
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE("LinuxAcademyIE", "linuxacademy.com", 80, True)
    assert ie


# Generated at 2022-06-24 12:56:45.308702
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Check valid URL
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    urlhandlers = [LinuxAcademyIE()]
    # Check whether LinuxAcademyIE can handle valid URL
    assert LinuxAcademyIE.suitable(url)
    assert LinuxAcademyIE.ie_key() == 'linuxacademy'

# Generated at 2022-06-24 12:56:46.738065
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-24 12:56:57.377563
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    lai = LinuxAcademyIE()
    assert lai._VALID_URL == "https?://(?:www\\.)?linuxacademy\\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|modules/view/id/(?P<course_id>\\d+))"
    assert lai._TESTS[0]["url"] == "https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675"
    assert lai._TESTS[1]["url"] == "https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2"

# Generated at 2022-06-24 12:56:58.602023
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Constructor of InfoExtractor
    InfoExtractor(LinuxAcademyIE())

# Generated at 2022-06-24 12:57:00.098251
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import sys
    sys.modules['Cryptodome'] = sys.modules['Crypto']
    from .test_linuxacademy import test_LinuxAcademyIE
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:57:01.865311
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print('Running test_LinuxAcademyIE() constructor')
    linuxAcademyIE = LinuxAcademyIE()
    print(linuxAcademyIE)

# Generated at 2022-06-24 12:57:07.099128
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Validate test cases are valid and the IE works.
    """
    # Unit test for constructor of class LinuxAcademyIE
    ie = LinuxAcademyIE()
    # Unit test YouTubeIE
    # Validate extractors
    ie.extract('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    ie.extract('https://linuxacademy.com/cp/modules/view/id/154')

# Generated at 2022-06-24 12:57:08.352812
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    iif = LinuxAcademyIE()

# Generated at 2022-06-24 12:57:09.091341
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()

# Generated at 2022-06-24 12:57:11.661874
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    testInstance = LinuxAcademyIE()
    assert testInstance.IE_NAME == 'LinuxAcademy'
    assert testInstance.IE_KEY == 'LinuxAcademy'

# Generated at 2022-06-24 12:57:12.294858
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:57:16.687791
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test creation of LinuxAcademyIE instance
    instance = LinuxAcademyIE()
    assert instance.suitable('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    assert instance.suitable('https://linuxacademy.com/cp/modules/view/id/154')

# Generated at 2022-06-24 12:57:18.152035
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    testInstance = LinuxAcademyIE()

# Generated at 2022-06-24 12:57:19.855260
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:57:30.307582
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie_instance = LinuxAcademyIE()
    assert(ie_instance.extract_urls('https://linuxacademy.com/cp/modules/view/id/154') == ['https://linuxacademy.com/cp/modules/view/id/154'])
    assert(ie_instance.extract_urls('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2') == ['https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'])