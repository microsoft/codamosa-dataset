

# Generated at 2022-06-24 12:47:41.715604
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    if not hasattr(LinuxAcademyIE, '_login'):
        return

    print("Testing constructor of class LinuxAcademyIE")
    ie = LinuxAcademyIE()

    print("Testing basic attributes of class LinuxAcademyIE")
    assert ie._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'

# Generated at 2022-06-24 12:47:44.366575
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .modules import linuxacademy
    return run_test_class(linuxacademy.LinuxAcademyIE)


# Generated at 2022-06-24 12:47:45.014618
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:47:49.113820
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info_extractor = LinuxAcademyIE()
    assert hasattr(info_extractor, '_NETRC_MACHINE')
    assert hasattr(info_extractor, '_ORIGIN_URL')
    assert hasattr(info_extractor, '_CLIENT_ID')

# Generated at 2022-06-24 12:47:49.808130
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:47:52.283198
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('')

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:47:54.728550
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')

# Generated at 2022-06-24 12:47:59.233087
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # TODO: Add more tests in LinuxAcademyIE.
    test_url = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    # test_url = 'https://linuxacademy.com/cp/modules/view/id/154'
    laie = LinuxAcademyIE()
    laie._real_extract(test_url)

# Generated at 2022-06-24 12:48:00.430655
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    return LinuxAcademyIE(None)._login()

# Generated at 2022-06-24 12:48:01.310930
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE._VALID_URL

# Generated at 2022-06-24 12:48:03.004656
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'linuxacademy'

# Generated at 2022-06-24 12:48:04.413472
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LA_ie = LinuxAcademyIE()



# Generated at 2022-06-24 12:48:05.445549
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    return LinuxAcademyIE()

# Generated at 2022-06-24 12:48:09.921186
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # The constructor is called statically in LinuxAcademyIE.ie_key()
    # The following code is to test the constructor
    ie = LinuxAcademyIE()
    assert ie.username is None
    assert ie.password is None
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:48:10.743045
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test = LinuxAcademyIE()
    print(test)

# Generated at 2022-06-24 12:48:13.527074
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    LinuxAcademyIE.test(url)

# Generated at 2022-06-24 12:48:15.059992
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert isinstance(instance, LinuxAcademyIE)

# Generated at 2022-06-24 12:48:21.645977
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    #assert LinuxAcademyIE(unit_test=True)

    #exit()
    #assert LinuxAcademyIE(unit_test=True)

    print("\n==Unit test is done==")



# Generated at 2022-06-24 12:48:25.695219
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    if not os.path.exists(os.path.join(os.getcwd(), 'LinuxAcademyIE')):
        os.makedirs(os.path.join(os.getcwd(), 'LinuxAcademyIE'))

    LinuxAcademyIE._real_initialize()

# Generated at 2022-06-24 12:48:31.810170
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test for a normal case using my credentials
    try:
        import netrc
    except ImportError:
        return
    try:
        netrc_data = netrc.netrc()
        linuxacademy_username, _, linuxacademy_password = netrc_data.authenticators(
            LinuxAcademyIE._NETRC_MACHINE)
        video_url = 'https://linuxacademy.com/cp/courses/lesson/course/1704/lesson/1'
        LinuxAcademyIE()._login()
        info = LinuxAcademyIE()._real_extract(video_url)
        assert(info['title'] == 'Introduction')
    except:
        return

test_LinuxAcademyIE()

# Generated at 2022-06-24 12:48:35.087162
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Loading LinuxAcademyIE in a try-except block to catch errors
    try:
        LinuxAcademyIE()
    except Exception as exc:
        assert False, 'Failed to initialize LinuxAcademyIE: %s' % str(exc)

# Generated at 2022-06-24 12:48:38.328788
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    a = LinuxAcademyIE()
    print(a)
    print("id of LinuxAcademyIE is <<%s>>" %a.ie_key())

# Generated at 2022-06-24 12:48:39.925006
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
    except Exception:
        pass

# Generated at 2022-06-24 12:48:48.493591
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE("")
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize', 'Unexpected value for _AUTHORIZE_URL'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com', 'Unexpected value for _ORIGIN_URL'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx', 'Unexpected value for _CLIENT_ID'
    assert ie._NETRC_MACHINE == 'linuxacademy', 'Unexpected value for _NETRC_MACHINE'

# Generated at 2022-06-24 12:48:57.421876
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # test item_id for single video
    assert LinuxAcademyIE._VALID_URL == '^(?x)' + (
        'https?://'
        '(?:www\\.)?linuxacademy\\.(?:co(?:m|\\.uk)|tech)'
        '(?:\\:\\d+)?/cp/'
        '(?:'
        'courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|'
        'modules/view/id/(?P<course_id>\\d+)'
        ')'
    )

# Generated at 2022-06-24 12:48:59.436293
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_ie = LinuxAcademyIE()
    assert linux_academy_ie



# Generated at 2022-06-24 12:49:07.963219
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # pylint: disable=import-error
    # To be able to import without having to install all Linux Academy dependencies
    from .test_linuxacademy import FakeLoginResponse, FakeTokenValidationResponse
    from .test_linuxacademy import load_resource as load_fake_response
    from .test_linuxacademy import FakeCoursePage
    from .test_linuxacademy import FakeCourseModule
    from .test_linuxacademy import FakeCourseSection
    from .test_linuxacademy import FakeCourseLesson
    from .test_linuxacademy import FakeCourseItem
    import pytest
    import requests
    requests.Session.login = lambda _, username, password: (
        FakeLoginResponse().add_token(username, password))

# Generated at 2022-06-24 12:49:08.988836
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:49:13.384880
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info = LinuxAcademyIE()
    assert info._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert info._ORIGIN_URL == 'https://linuxacademy.com'
    assert info._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:49:14.256280
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:49:25.247199
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_imports import factory
    from .test_imports import platform
    from .test_imports import sys
    from .test_imports import os
    from .test_imports import netrc
    from .test_imports import unittest
    from .test_imports import YoutubeDL

    if sys.platform == 'darwin':
        # https://github.com/rg3/youtube-dl/issues/2384
        return
    # Copied from test_youtube_dl.py
    def test_download(url, params={}):
        filename = sys.argv[0] if len(sys.argv) >= 1 else __file__
        filename = os.path.basename(filename)
        test_dir = os.path.join(os.path.dirname(filename), 'temp')

# Generated at 2022-06-24 12:49:32.111345
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import unittest
    class LinuxAcademyIETest(unittest.TestCase):
        def test_get_login_info():
            login_info = LinuxAcademyIE._get_login_info()
            assert len(login_info) == 2
        def test_real_initialize():
            LinuxAcademyIE._real_initialize()
        def test_real_extract():
            LinuxAcademyIE._real_extract(LinuxAcademyIE._VALID_URL)
    unittest.main()

# Generated at 2022-06-24 12:49:33.162363
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None, 'LinuxAcademy')

# Generated at 2022-06-24 12:49:41.056971
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

    data = {
        '_VALID_URL': ie._VALID_URL,
        '_TESTS': ie._TESTS,
        '_AUTHORIZE_URL': ie._AUTHORIZE_URL,
        '_ORIGIN_URL': ie._ORIGIN_URL,
        '_CLIENT_ID': ie._CLIENT_ID,
        '_NETRC_MACHINE': ie._NETRC_MACHINE
    }


# Generated at 2022-06-24 12:49:52.760150
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.http_headers == {
        'Origin': 'https://login.linuxacademy.com'
    }
    assert ie._VALID_URL == re.compile(r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    ''')
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:49:53.856249
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None, None)

# Generated at 2022-06-24 12:49:56.016073
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    i = LinuxAcademyIE()
    assert i.IE_NAME == 'linuxacademy'

# Generated at 2022-06-24 12:49:57.382157
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:49:59.894709
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert(LinuxAcademyIE.ie_key() == 'LinuxAcademy')
    LinuxAcademyIE(None)



# Generated at 2022-06-24 12:50:01.646534
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:50:02.624478
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None, None, None)

# Generated at 2022-06-24 12:50:10.372533
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test Cookie Error
    url = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    assert LinuxAcademyIE.cookie_error(url) == False
    # Test Authorize URL
    assert LinuxAcademyIE._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    # Test Origin URL
    assert LinuxAcademyIE._ORIGIN_URL == 'https://linuxacademy.com'
    # Test Client ID
    assert LinuxAcademyIE._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    # Test NetRC Machine

# Generated at 2022-06-24 12:50:11.488030
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    a = LinuxAcademyIE()

# Generated at 2022-06-24 12:50:15.061486
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    l = LinuxAcademyIE()
    assert(l is not None)


# Generated at 2022-06-24 12:50:17.230769
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE(test_LinuxAcademyIE.test_extractor) is not None

# Generated at 2022-06-24 12:50:27.638475
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert instance._VALID_URL == r'https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'

# Generated at 2022-06-24 12:50:33.182051
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ''' This function is used to test the __init__ function of LinuxAcademyIE class '''
    try_login = True
    laIE = LinuxAcademyIE(None, try_login)
    assert laIE.login is try_login

    try_login = False
    laIE = LinuxAcademyIE(None, try_login)
    assert laIE.login is try_login

# Generated at 2022-06-24 12:50:38.341914
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.__class__.__name__ == 'LinuxAcademyIE'
    assert ie.ie_key() == 'linuxAcademy'
    assert ie.server_encoding == 'utf-8'
    assert ie._VALID_URL == ie._VALID_URL


# Generated at 2022-06-24 12:50:47.360924
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test 1 : Good input
    print("Call _login function with good input")
    # Make a instance of LinuxAcademyIE
    la_ie = LinuxAcademyIE()
    # Login in Linux Academy
    la_ie._login()

    # Test 2 : Bad input
    print("Call _login function with bad input")
    # Remove username and password in netrc file
    # Make a instance of LinuxAcademyIE
    la_ie2 = LinuxAcademyIE()
    # Login in Linux Academy
    la_ie2._login()

    # Test 1 : _real_extract function with good input
    print("Call _real_extract function with good input")
    # Get html of url with good input

# Generated at 2022-06-24 12:50:51.717738
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    extractor = LinuxAcademyIE()
    actual = extractor.suitable(url)
    expected = True
    assert(actual == expected)

# Generated at 2022-06-24 12:50:53.927760
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    result = LinuxAcademyIE()
    assert isinstance(result, LinuxAcademyIE)

# Generated at 2022-06-24 12:51:01.313045
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:51:08.372678
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Testing empty `username` and `password`
    la = LinuxAcademyIE(username="", password="")
    assert la._NETRC_MACHINE == "linuxacademy"
    assert la._CLIENT_ID == "KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx"
    assert la._AUTHORIZE_URL == "https://login.linuxacademy.com/authorize"
    assert la._ORIGIN_URL == "https://linuxacademy.com"

# Generated at 2022-06-24 12:51:13.612915
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    IE = LinuxAcademyIE()
    assert(IE.suitable('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'))
    assert(not IE.suitable('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'))

# Generated at 2022-06-24 12:51:15.934503
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    assert ie.login_info == ('login', 'pass')
    assert ie.username == 'login'
    assert ie.password == 'pass'

# Generated at 2022-06-24 12:51:24.976540
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE("https://linuxacademy.com/cp/modules/view/id/154");
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert ie._NETRC_MACHINE == 'linuxacademy'



# Generated at 2022-06-24 12:51:25.950164
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

# Generated at 2022-06-24 12:51:26.757012
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:51:28.190781
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE

# Generated at 2022-06-24 12:51:35.102407
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    course_url = 'https://linuxacademy.com/cp/modules/view/id/154'
    linuxacademy_ie = LinuxAcademyIE()
    assert linuxacademy_ie.ie_key() == 'LinuxAcademy'
    assert linuxacademy_ie.suitable(course_url)
    version, version_num = linuxacademy_ie._version()
    assert version == '1.2.6'

# Generated at 2022-06-24 12:51:45.348772
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Unit test for constructor of class LinuxAcademyIE
    """
    temp = LinuxAcademyIE('LinuxAcademyIE')
    assert temp._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert temp._ORIGIN_URL == 'https://linuxacademy.com'
    assert temp._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert temp._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:51:48.979355
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert(ie.extract('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')['id']  == '7971-2')

# Generated at 2022-06-24 12:51:54.779770
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # go to https://linuxacademy.com/cp/
    #   and check the source code of the webpage
    #   to find out token, value, and key
    #   then construct LinuxAcademyIE
    url = "https://linuxacademy.com/cp/courses/lesson/course/46/lesson/2/module/215"
    ie = LinuxAcademyIE()
    ie.login()
    ie.extract(url)

# Generated at 2022-06-24 12:51:58.287623
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test for cases where constructor CAN throw an exception
    # First test is the unittest convention
    with pytest.raises(Exception):
        LinuxAcademyIE(None)

    # Second test is just to ensure the proper exception is thrown
    with pytest.raises(AttributeError):
        LinuxAcademyIE(None)

# Generated at 2022-06-24 12:52:04.506337
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Login on test website
    username = "test_username"
    password = "test_password"
    ie = LinuxAcademyIE(username=username, password=password)
    # Check if username and password are correct
    if(ie._username == username and ie._password == password):
        print("Login test : OK")
    else:
        print("Login test : FAIL")



# Generated at 2022-06-24 12:52:10.580172
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy:account'
    assert ie.IE_DESC == 'Linux Academy'
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-24 12:52:16.186373
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # URL https://linuxacademy.com/cp/modules/view/id/154
    LinuxAcademyIE().test_course(
        'http://www.linuxacademy.com/cp/modules/view/id/154')

    # URL https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675
    LinuxAcademyIE().test_video(
        'http://www.linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')

# Generated at 2022-06-24 12:52:17.352677
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:52:18.486672
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:52:19.776038
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:52:21.398270
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(LinuxAcademyIE.ie_key())

# Generated at 2022-06-24 12:52:31.279949
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    ie = LinuxAcademyIE()
    try:
        ie._login()
    except ExtractorError as e:
        if isinstance(e.cause, compat_HTTPError) and e.cause.code == 401:
            error = ie._parse_json(e.cause.read(), None)
            message = error.get('description') or error['code']
            raise ExtractorError(
                '%s said: %s' % (ie.IE_NAME, message), expected=True)
        raise

    ie._real_extract(url)
    ie._real_extract('https://linuxacademy.com/cp/modules/view/id/154')

# Generated at 2022-06-24 12:52:33.960939
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE is InfoExtractor.make_IE_from_url_pattern('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')

# Generated at 2022-06-24 12:52:34.949452
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:52:36.098122
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    unittest.main()

# Generated at 2022-06-24 12:52:39.016579
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # This test loads the module for the class LinuxAcademyIE.
    obj = LinuxAcademyIE(0)
    assert isinstance(obj, LinuxAcademyIE)


# Generated at 2022-06-24 12:52:43.027446
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        import ntlm_auth
    except ImportError:
        ntlm_auth = None

    if not ntlm_auth:
        raise ImportError('ntlm_auth required')

    ie = LinuxAcademyIE(None)
    ie._login()

# Generated at 2022-06-24 12:52:54.918639
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == LinuxAcademyIE._VALID_URL
    assert ie._LOGIN_URL == None
    assert ie._NETRC_MACHINE == LinuxAcademyIE._NETRC_MACHINE

# Generated at 2022-06-24 12:53:03.997378
# Unit test for constructor of class LinuxAcademyIE

# Generated at 2022-06-24 12:53:08.892621
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    module = LinuxAcademyIE()
    assert module.__class__.__name__ == 'LinuxAcademyIE'
    assert module.IE_NAME == 'linuxacademy'
    assert module.IE_DESC == 'Linux Academy'
    assert module._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert module._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:53:13.701264
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
    except Exception as e:
        print(str(e))
        print("Failed to initialize class LinuxAcademyIE")


if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:53:15.888754
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie.username, str)
    assert isinstance(ie.password, str)

# Generated at 2022-06-24 12:53:17.975967
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert hasattr(ie, '_real_initialize')


if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:53:27.019136
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LA = LinuxAcademyIE()
    # Test with single video url
    url = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    LA._real_extract(url)
    # Test with class url
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    LA._real_extract(url)
    # Unit test for function _login
    LA._login()
    # Unit test for function _download_webpage
    LA._download_webpage('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2', None)
    # Unit test for function _download_webpage_handle

# Generated at 2022-06-24 12:53:32.864726
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE.test_video_info_url(LinuxAcademyIE, 'https://linuxacademy.com/cp/modules/view/id/154')
    LinuxAcademyIE.test_video_info_url(LinuxAcademyIE, 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')

# Generated at 2022-06-24 12:53:34.086106
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:53:41.516197
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    def _test_extractor(url, video_id, title):
        ie = LinuxAcademyIE(LinuxAcademyIE.create_ie())
        ie.set_downloader(object)
        info = ie.extract(url)
        assert info['id'] == video_id
        assert info['title'] == title
    # test course url
    _test_extractor(
        'https://linuxacademy.com/cp/modules/view/id/154',
        '154',
        'AWS Certified Cloud Practitioner')
    # test single video url
    _test_extractor(
        'https://linuxacademy.com/cp/courses/lesson/course/9909/lesson/3/module/1400',
        '9909-3',
        'Introduction to Passport')

# Generated at 2022-06-24 12:53:51.706129
# Unit test for constructor of class LinuxAcademyIE

# Generated at 2022-06-24 12:53:52.938055
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None, '')

# Generated at 2022-06-24 12:53:56.861687
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print("Unit test started")
    a = LinuxAcademyIE()
    a._real_extract("https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675")
    test_LinuxAcademyIE.result = True
    print("Unit test finished")

test_LinuxAcademyIE.result = False

if __name__ == '__main__':
    test_LinuxAcademyIE()
    print(test_LinuxAcademyIE.result)
    if not test_LinuxAcademyIE.result:
        exit(1)

# Generated at 2022-06-24 12:53:57.994653
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:54:06.702364
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """ Tests LinuxAcademyIE constructor """
    # pylint: disable=redefined-outer-name

    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'

    # From test case
    ie = LinuxAcademyIE('https://linuxacademy.com/cp/')
    assert ie.IE_NAME == 'linuxacademy'

    # Invalid case
    ie = LinuxAcademyIE('https://linuxacademy.com/cp')
    assert ie.IE_NAME != 'linuxacademy'

# Generated at 2022-06-24 12:54:07.990386
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(InfoExtractor)

# Generated at 2022-06-24 12:54:19.566497
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    ie = LinuxAcademyIE()
    ie._login()
    actual_url, actual_info_dict = ie._extract_url_and_id(url)
    actual_title = ie._html_search_regex(
        r'(?s)<h1[^>]+class="[^"]*\btitle\b[^"]*"[^>]*>\s*(?P<value>.+?)\s*</h1>',
        actual_info_dict['webpage'],
        'title', default=None, group='value')
    assert actual_title == 'AWS Certified Cloud Practitioner'
    assert actual_url == url
    assert actual_info_dict['playlist_count'] == 41


# Generated at 2022-06-24 12:54:23.078983
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test for constructor of class LinuxAcademyIE"""
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    LinuxAcademyIE(InfoExtractor())

# Generated at 2022-06-24 12:54:24.286997
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:54:27.636834
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE.suitable('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')

# Generated at 2022-06-24 12:54:28.645413
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()

# Generated at 2022-06-24 12:54:29.606259
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:54:30.543435
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None, {})

# Generated at 2022-06-24 12:54:31.518712
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:54:35.406560
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    inst = LinuxAcademyIE()
    assert inst.IE_NAME == 'Linux Academy'
    assert inst.VALID_URL == LinuxAcademyIE._VALID_URL


if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:54:36.552319
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('', '')

# Generated at 2022-06-24 12:54:38.858535
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.__class__.__name__ == 'LinuxAcademyIE'

# Generated at 2022-06-24 12:54:42.038083
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test for class LinuxAcademyIE:
    # create an instance of class LinuxAcademyIE,
    # to test whether the constructor works
    ie = LinuxAcademyIE()

test_LinuxAcademyIE()

# Generated at 2022-06-24 12:54:42.832940
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None)._login()

# Generated at 2022-06-24 12:54:43.754592
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:54:46.030362
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        # Test with valid credentials
        username, password = ('REDACTED', 'REDACTED')
        LinuxAcademyIE(username, password)
        # Test with invalid credentials
        LinuxAcademyIE('foo', 'bar')
    except Exception as e:
        assert False, str(e)

# Generated at 2022-06-24 12:54:52.645883
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        from crypt import crypt
        from getpass import getpass
    except ImportError:
        crypt = None
        getpass = None

    username = input('Username: ')
    password = getpass('Password: ') if getpass else ''

    ie = LinuxAcademyIE()
    if crypt is not None:
        password = crypt(password, 'ab')
    ie._login_info = username, password
    ie.to_screen('Logging in')
    ie._login()

    # TODO: Add tests to make sure we're getting the right thing when
    # we're logged in. Also add tests that hit the course URL, and
    # ensure we're getting the right thing from that. We can make a
    # throw-away account for the tests.
    # See http://ytdl-org.github.io/

# Generated at 2022-06-24 12:54:54.753648
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.protocol == 'https'

# Generated at 2022-06-24 12:55:03.550217
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert obj._NETRC_MACHINE == 'linuxacademy'
    assert obj._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert obj._ORIGIN_URL == 'https://linuxacademy.com'
    assert obj._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-24 12:55:04.606818
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:55:05.801051
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:55:17.357671
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    modules = [{
        'items': [{
            'type': {'name': 'Section'},
            'url': '/lp/-/',
            'course_name': 'AWS Certified Cloud Practitioner',
            'course_module': '2'
            }, {
            'type': {'name': 'Lesson', 'slug': 'lesson'},
            'url': '/lp/-/show/',
            'title': 'AWS Certified Cloud Practitioner',
            'md_desc': 'AWS Certified Cloud Practitioner',
            'duration': '3:32',
            'date': 'Nov 12, 2019',
            'created_on': '2019-11-12T00:00:00+00:00',
            'lesson_name': 'AWS Certified Cloud Practitioner'
            }]
        }]

# Generated at 2022-06-24 12:55:18.315142
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:55:26.732720
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Sorry, I can't find a way to create a mock netrc class
    # If so, we can test it better
    ied = LinuxAcademyIE()
    assert ied.username is None
    assert ied.password is None
    assert ied._NETRC_MACHINE == 'linuxacademy'
    assert ied._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ied._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'

# Generated at 2022-06-24 12:55:27.527526
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()

# Generated at 2022-06-24 12:55:28.967572
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    ie._real_initialize()
    assert ie._login() is not None

# Generated at 2022-06-24 12:55:30.917075
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert instance.ie_key() in ['LinuxAcademy']
    assert instance.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:55:35.256269
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'linuxAcademy'
    assert ie.extractor.ie_key_map['LinuxAcademy'] == ie.ie_key()
    assert ie.SUCCESS == ie._login()

# Generated at 2022-06-24 12:55:36.329244
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:55:38.164846
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():

    # Call the constructor of class LinuxAcademyIE
    linuxacademy_ie = LinuxAcademyIE()

# Generated at 2022-06-24 12:55:40.043742
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Check if unit test can construct an object of LinuxAcademyIE class
    LinuxAcademyIE()

# Generated at 2022-06-24 12:55:48.825186
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # using a dummy account to test
    user_credentials = ["lac_test@gmail.com", "Test1234!"]

    course_url = "https://linuxacademy.com/cp/modules/view/id/154"
    linuxacademy_ie = LinuxAcademyIE._build_request({'username': user_credentials[0], 'password': user_credentials[1]})
    linuxacademy_ie.login()
    list_entries = linuxacademy_ie._real_extract(course_url)['entries']
    # print out all the entries
    for ix, entry in enumerate(list_entries):
        print(ix, entry)

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:55:53.688294
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie._VALID_URL == r'https?://(?:www\.)?linuxacademy\.com/cp/' + 'courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NET

# Generated at 2022-06-24 12:55:55.702672
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    my_ie = LinuxAcademyIE()
    assert my_ie.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:56:05.851347
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert (len(ie._TESTS) == 3)
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT

# Generated at 2022-06-24 12:56:07.140645
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()

# Generated at 2022-06-24 12:56:08.512663
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert(ie is not None)


# Generated at 2022-06-24 12:56:10.127752
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # testing constructor of class LinuxAcademyIE
    obj = LinuxAcademyIE()
    assert obj.ie_key() == 'LinuxAcademy'
    assert obj.ie_key() == 'LinuxAcademy'
    return

# Generated at 2022-06-24 12:56:11.277780
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    construct_ie_instance(LinuxAcademyIE)

# Generated at 2022-06-24 12:56:19.315175
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Get all methods of class LinuxAcademyIE
    methods = LinuxAcademyIE.__dict__

    # Check to see if all methods in LinuxAcademyIE are called
    for key in methods:
        method_name = methods[key].__name__

        if method_name == '__init__':
            continue
        if method_name == 'test_LinuxAcademyIE':
            continue
        if method_name == '__module__':
            continue

        print("Checking that %s is called in constructor..." % (method_name))
        LinuxAcademyIE()
        print("OK!")

# Run test
if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:56:22.140496
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    class_name = 'LinuxAcademyIE'
    class_constructor = globals()[class_name]
    class_instance = class_constructor()
    assert class_instance

# Generated at 2022-06-24 12:56:23.175593
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert isinstance(instance, InfoExtractor)


# Generated at 2022-06-24 12:56:30.299271
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test Linux Academy constructor"""
    assert LinuxAcademyIE._NETRC_MACHINE == 'linuxacademy'
    assert LinuxAcademyIE._VALID_URL == r'(?x)\Ahttps?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'

# Generated at 2022-06-24 12:56:33.447118
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'


# Generated at 2022-06-24 12:56:39.843407
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    submodule_dict = dict()
    submodule_dict["test1"] = dict()
    submodule_dict["test1"]["test2"] = "test3"

    test_obj = LinuxAcademyIE({}, {})
    # test for try_get method
    assert test_obj.try_get(submodule_dict, lambda x: x["test1"]["test2"], str) == "test3"
    return

# Generated at 2022-06-24 12:56:41.104099
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # log in to Linux Academy
    LinuxAcademyIE()

# Generated at 2022-06-24 12:56:43.884716
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # print(LinuxAcademyIE())
    resp = LinuxAcademyIE()
    assert resp.IE_NAME == "LinuxAcademy"

# Generated at 2022-06-24 12:56:44.916401
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:56:50.103489
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Check that it raises error if no credentials
    ie = LinuxAcademyIE(IE_NAME, {})
    ie.initialize()
    with pytest.raises(ExtractorError, match='account credentials'):
        ie.extract('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')

# Generated at 2022-06-24 12:56:51.135152
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:56:52.571893
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(InfoExtractor())._real_initialize()

# Generated at 2022-06-24 12:56:53.953525
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie is not None

# Generated at 2022-06-24 12:56:56.889588
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        xtractor = LinuxAcademyIE()
        xtractor._login()
    except:
        assert False, "Unit test for LinuxAcademyIE constructor failed"
    assert True

# Generated at 2022-06-24 12:57:03.026072
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Check extractor which has neither _VALID_URL nor _WORKING
    class LinuxAcademyIE(InfoExtractor):
        _VALID_URL = None

        def _real_extract(self, url):
            pass

    url = 'foo'
    assert LinuxAcademyIE(InfoExtractor(None))._real_initialize()
    # Check extractor which has neither _VALID_URL nor _WORKING
    LinuxAcademyIE._VALID_URL = LinuxAcademyIE._WORKING = False
    with pytest.raises(ExtractorError) as excinfo:
        LinuxAcademyIE(InfoExtractor(None))._real_initialize()
    assert str(excinfo.value) == 'LinuxAcademy is not supported for url: %s' % url

# Generated at 2022-06-24 12:57:06.404169
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE(): # pylint: disable=missing-function-docstring
    ie = LinuxAcademyIE(None)
    assert ie is not None

# Generated at 2022-06-24 12:57:07.413283
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:57:09.435807
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test = LinuxAcademyIE()
    assert isinstance(test, LinuxAcademyIE)

# Generated at 2022-06-24 12:57:10.537466
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE(): 
    LinuxAcademyIE("")

# Generated at 2022-06-24 12:57:13.508671
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Run the class constructor unit tests"""

    # Create an instance of the class
    la = LinuxAcademyIE()

    # Check that the object initialized properly
    assert la.is_logged_in() == False

# Generated at 2022-06-24 12:57:18.173836
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE({})
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-24 12:57:20.891931
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert obj is not None

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:57:30.982560
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''