

# Generated at 2022-06-24 12:47:33.359720
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        # Initialize
        test = LinuxAcademyIE()

    except Exception as e:
        print (e)

# Generated at 2022-06-24 12:47:44.755262
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(None, {}, {}, {}, {})
    assert ie._VALID_URL == r'https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'

# Generated at 2022-06-24 12:47:46.836314
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
        print("Linux Academy class created successfully")
    except:
        print("Linux Academy class not created")

# Generated at 2022-06-24 12:47:57.095160
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    mobj = re.match(LinuxAcademyIE._VALID_URL, url)
    chapter_id, lecture_id, course_id = mobj.group('chapter_id', 'lesson_id', 'course_id')
    item_id = course_id if course_id else '%s-%s' % (chapter_id, lecture_id)
    # instantiate LinuxAcademyIE
    ie = LinuxAcademyIE(url)
    # download webpage
    webpage = ie._download_webpage(url, item_id)
    assert webpage is not None
    # try to extract playlist count
    assert 'playlist_count' in ie._real_extract(url)

# Generated at 2022-06-24 12:47:58.838736
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Tested on:
    # https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675
    assert LinuxAcademyIE._VALID_URL == LinuxAcademyIE._VALID_URL.strip()

# Generated at 2022-06-24 12:48:02.482191
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(linuxacademy_username='', linuxacademy_password='')
    LinuxAcademyIE(username='', password='')
    LinuxAcademyIE(username='', password='')

# Generated at 2022-06-24 12:48:04.793514
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE({})._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert LinuxAcademyIE({})._NETRC_MACHINE == 'linuxacademy'


# Generated at 2022-06-24 12:48:06.180848
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_ie = LinuxAcademyIE()


# Generated at 2022-06-24 12:48:15.875809
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    name = 'linuxacademy'
    ie_class = 'LinuxAcademyIE'
    ie_instance = LinuxAcademyIE(name, ie_class)
    assert ie_instance.name == name
    assert ie_instance.ie_key() == ie_class
    assert ie_instance._NETRC_MACHINE == 'linuxacademy'
    assert ie_instance._TESTS
    assert ie_instance._VALID_URL
    assert ie_instance._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie_instance._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie_instance._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'


# Generated at 2022-06-24 12:48:17.685608
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:48:18.790666
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    x = LinuxAcademyIE()

# Generated at 2022-06-24 12:48:20.433314
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .common import InfoExtractor
    from .linuxacademy import LinuxAcademyIE

    assert isinstance(LinuxAcademyIE(), InfoExtractor)

# Generated at 2022-06-24 12:48:23.421545
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE(None, None)
    except TypeError as e:
        if "__init__() takes at least 3 arguments (2 given)" not in str(e):
            raise

# Generated at 2022-06-24 12:48:24.809371
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

    assert 'Linux Academy' == ie.IE_NAME

# Generated at 2022-06-24 12:48:26.386680
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)

# Generated at 2022-06-24 12:48:29.409850
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, InfoExtractor)
    assert hasattr(ie, "_login")
    assert hasattr(ie, "_real_extract")
    assert ie._VALID_URL is not None
    assert ie._NETRC_MACHINE is not None


# Generated at 2022-06-24 12:48:34.033856
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.IE_DESC == 'Linux Academy'
    assert ie.VALID_URL == LinuxAcademyIE._VALID_URL
    assert ie._VALID_URL == LinuxAcademyIE._VALID_URL
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-24 12:48:39.922583
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('LinuxAcademyIE', 'linuxacademy.com')
    LinuxAcademyIE('LinuxAcademyIE', 'linuxacademy.com/cp/modules/view/id/154')
    LinuxAcademyIE('LinuxAcademyIE', 'linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')

# Generated at 2022-06-24 12:48:40.908557
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:48:43.629039
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie_LinuxAcademy = LinuxAcademyIE(None)
    assert ie_LinuxAcademy
    assert ie_LinuxAcademy._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:48:48.382812
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'LinuxAcademy'
    assert ie.IE_DESC == 'Linux Academy'
    assert ie._VALID_URL is not None
    assert ie._TEST is not None

# Generated at 2022-06-24 12:48:54.350365
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert not ie._login()
    assert not ie._real_initialize()
    assert not ie._real_extract('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    assert not ie._real_extract('https://linuxacademy.com/cp/modules/view/id/154')

# Generated at 2022-06-24 12:49:00.886869
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    _LinuxAcademyIE = lambda: None
    try:
        _LinuxAcademyIE.__bases__ = (LinuxAcademyIE,)
    except TypeError:
        _LinuxAcademyIE.__bases__ = (LinuxAcademyIE,)
    _ = LinuxAcademyIE  # noqa


if __name__ == '__main__':
    from . import main
    main(LinuxAcademyIE, __name__)

# Generated at 2022-06-24 12:49:02.247670
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('LinuxAcademy', 'linuxacademy.com')

# Generated at 2022-06-24 12:49:03.263017
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()


# Generated at 2022-06-24 12:49:07.450736
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Constructor without api key
    try:
        LinuxAcademyIE()
        assert False
    except TypeError:
        assert True
    # Constructor with api key
    try:
        LinuxAcademyIE('test_key')
        assert True
    except TypeError:
        assert False

# Generated at 2022-06-24 12:49:09.681508
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_linux_academy_ie = LinuxAcademyIE(None)
    assert test_linux_academy_ie is not None

# Generated at 2022-06-24 12:49:10.708439
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None)

# Generated at 2022-06-24 12:49:12.484266
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:49:19.019449
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test the constructor of LinuxAcademyIE
    # Instance needs to be created with secret and username
    ie = LinuxAcademyIE('linuxacademy', 'username')
    assert(ie._NETRC_MACHINE == 'linuxacademy')
    assert(ie._username == 'username')
    assert(ie._real_initialize.__name__ == '_login')
    assert(type(ie._real_initialize.__code__) == type(type))

# Generated at 2022-06-24 12:49:21.257765
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)
    assert callable(ie.extract)

# Generated at 2022-06-24 12:49:23.367689
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
    except Exception as e:
        assert False, "Error thrown: %s" % str(e)

# Generated at 2022-06-24 12:49:24.433756
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:49:34.066910
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    class_instance = LinuxAcademyIE()
    assert class_instance._VALID_URL == '''(?x)
                            https?://
                                (?:www\.)?linuxacademy\.com/cp/
                                (?:
                                    courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|
                                    modules/view/id/(?P<course_id>\\d+)
                                )
                            '''

# Generated at 2022-06-24 12:49:41.594979
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == "linuxacademy"
    assert ie._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert not ie._login_expected
    assert ie._AUTHORIZE_URL == "https://login.linuxacademy.com/authorize"
    assert ie._ORIGIN_URL == "https://linuxacademy.com"
    assert ie._CLIENT_ID == "KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx"

# Generated at 2022-06-24 12:49:44.853619
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    arguments = []
    # Test with empty arguments
    assert LinuxAcademyIE(*arguments)
    # Test with arguments
    arguments = [
        'username', 'password']
    assert LinuxAcademyIE(*arguments)

# Generated at 2022-06-24 12:49:47.714273
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE is not None

if __name__ == "__main__":
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:49:48.974418
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(InfoExtractor())

# Generated at 2022-06-24 12:50:00.582217
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import Mockingbird
    with Mockingbird.Mockingbird() as mock:
        mock.add_scenario({
            "url": "https://linuxacademy.com/cp/modules/view/id/154",
            "filename": "linuxacademy_module.json",
            "match_querystring": True,
        })
        mock.set_return_value({
            "url": "https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2",
            "filename": "linuxacademy_lesson.html",
            "match_querystring": True,
        })

# Generated at 2022-06-24 12:50:09.131505
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademy_ie = LinuxAcademyIE()
    assert linuxacademy_ie._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert linuxacademy_ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert linuxacademy_ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert linuxacademy_ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert linuxacademy_ie._NET

# Generated at 2022-06-24 12:50:21.050150
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    for url in (
        'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
        'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
        'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2',
        'https://linuxacademy.com/cp/modules/view/id/154',
    ):
        assert LinuxAcademyIE.suitable(url)
        ie = LinuxAcademyIE(url)
        assert ie.url == url
        assert ie.params["skip_download"]
        assert isinstance(ie.params["skip_download"], bool)

# Generated at 2022-06-24 12:50:23.501300
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    jaimeLinuxAcademyIE = LinuxAcademyIE(None)
    assert jaimeLinuxAcademyIE.IE_NAME == 'linuxacademy'

# Generated at 2022-06-24 12:50:34.482657
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # constructor
    expected_type = LinuxAcademyIE

    assert(type(expected_type.__name__) == 'str'), \
    'LinuxAcademyIE constructor type error'

    assert(LinuxAcademyIE.IE_NAME == 'linuxacademy'), \
    'LinuxAcademyIE IE_NAME constant error'

    assert(LinuxAcademyIE.IE_DESC == 'LinuxAcademy'), \
    'LinuxAcademyIE IE_DESC constant error'

    assert(LinuxAcademyIE.VALID_URL != ''), \
    'LinuxAcademyIE VALID_URL constant error'

    # _real_initialize
    # _login
    # _real_extract
    # _download_webpage_handle

    # _download_webpage
    # _download_webpage_handle

# Generated at 2022-06-24 12:50:39.521677
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._NETRC_MACHINE == 'linuxacademy'
    assert LinuxAcademyIE()._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert LinuxAcademyIE()._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert LinuxAcademyIE()._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-24 12:50:42.313752
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    if not isinstance(obj, LinuxAcademyIE):
        print("Object not an instance of class LinuxAcademyIE")
        return False
    return True


# Generated at 2022-06-24 12:50:44.861958
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    '''
    Test calling constructor of LinuxAcademyIE class
    '''
    ie = LinuxAcademyIE(None, None)
    assert ie != None

# Generated at 2022-06-24 12:50:49.595938
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_url = "https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675"

    ie = LinuxAcademyIE(test_url)

    if isinstance(ie, type(InfoExtractor)):
        assert "LinuxAcademyIE" in str(type(ie))
    else:
        assert "InfoExtractor" in str(type(ie))

# Generated at 2022-06-24 12:50:55.345774
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj1 = LinuxAcademyIE('')
    assert obj1.ie_key() == 'LinuxAcademy'
    assert obj1.ie_name() == 'Linux Academy'
    assert obj1._NETRC_MACHINE == 'linuxacademy'
    
# Testing the main features of class LinuxAcademyIE

# Generated at 2022-06-24 12:51:01.653461
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.IE_DESC == 'Linux Academy'
    assert ie.VALID_URL == LinuxAcademyIE._VALID_URL
    assert ie.AUTHORIZE_URL == LinuxAcademyIE._AUTHORIZE_URL
    assert ie.ORIGIN_URL == LinuxAcademyIE._ORIGIN_URL
    assert ie.CLIENT_ID == LinuxAcademyIE._CLIENT_ID
    assert ie.NETRC_MACHINE == LinuxAcademyIE._NETRC_MACHINE

# Generated at 2022-06-24 12:51:04.628969
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE("")
    except Exception as e:
        print("Failed to invoke constructor: " + str(e))


# Generated at 2022-06-24 12:51:06.903903
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Unit test for constructor of class LinuxAcademyIE
    info = LinuxAcademyIE()
    assert(info != None)
    return info

# Generated at 2022-06-24 12:51:13.044594
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'(?x)https?://(?:www\.|)(linuxacademy\.com)/cp/courses/lesson/course/(?P<id>\d+)/lesson/(?P<lecture_id>\d+)'
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-24 12:51:20.374419
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'


# Generated at 2022-06-24 12:51:21.880754
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie is not None


# Generated at 2022-06-24 12:51:24.166277
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test name of LinuxAcademyIE class
    assert LinuxAcademyIE.IE_NAME == 'linuxacademy:course'

# Generated at 2022-06-24 12:51:31.268539
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(None)
    assert(ie._VALID_URL == LinuxAcademyIE._VALID_URL)
    assert(ie._AUTHORIZE_URL == LinuxAcademyIE._AUTHORIZE_URL)
    assert(ie._ORIGIN_URL == LinuxAcademyIE._ORIGIN_URL)
    assert(ie._CLIENT_ID == LinuxAcademyIE._CLIENT_ID)
    assert(ie._NETRC_MACHINE == LinuxAcademyIE._NETRC_MACHINE)

# Generated at 2022-06-24 12:51:41.710051
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # test to build instance with bad access token
    try:
        LinuxAcademyIE("token")
        assert False, "Instanciating class with bad access token should raise exception."
    except Exception:
        pass
    # test to build instance with good access token

# Generated at 2022-06-24 12:51:45.042456
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .common import InfoExtractor
    ie = InfoExtractor(LinuxAcademyIE.ie_key())
    if (ie.ie_key() != 'LinuxAcademy'):
        return False
    return True

# Generated at 2022-06-24 12:51:46.732903
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test = LinuxAcademyIE()
    print(test._login())

# Generated at 2022-06-24 12:51:53.453156
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'LinuxAcademy'
    assert ie.IE_DESC == 'Linux Academy online video courses, tutorials, and training.'
    assert ie._VALID_URL == LinuxAcademyIE._VALID_URL
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-24 12:51:55.076088
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Unit test for constructor of class LinuxAcademyIE
    """
    LinuxAcademyIE()


# Generated at 2022-06-24 12:52:06.328125
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    def _test_lesson(url, chapter_id, lecture_id, course_id, expected_title):
        chapter_id, lecture_id, course_id = int(chapter_id), int(lecture_id), int(course_id)
        item_id = course_id if course_id else '%s-%s' % (chapter_id, lecture_id)
        ie = LinuxAcademyIE()
        mobj = re.match(LinuxAcademyIE._VALID_URL, url)
        chapter_id_m, lecture_id_m, course_id_m = mobj.group('chapter_id', 'lesson_id', 'course_id')
        assert int(chapter_id_m) == chapter_id, "chapter_id is incorrect"
        assert int(lecture_id_m) == lecture

# Generated at 2022-06-24 12:52:07.711274
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:52:14.701370
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    #downloading login page
    def random_string():
        return ''.join([
            random.choice('0123456789ABCDEFGHIJKLMNOPQRSTUVXYZabcdefghijklmnopqrstuvwxyz-._~')
            for _ in range(32)])


# Generated at 2022-06-24 12:52:15.844730
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:52:18.729823
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE('LinuxAcademy', 'https://linuxacademy.com', 'linuxacademy')
    assert ie is not None

# Generated at 2022-06-24 12:52:19.993012
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:52:22.068775
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_youtube import test_youtube_urls
    test_youtube_urls(LinuxAcademyIE)

# Generated at 2022-06-24 12:52:23.787050
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_linuxacademy import test_login
    test_login()

# Generated at 2022-06-24 12:52:33.745006
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    page_url = "https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675"
    # Test with a lesson
    lesson = LinuxAcademyIE()
    lesson.suitable(page_url)
    lesson.extract(page_url)
    assert lesson._downloader is not None
    assert lesson._hidden_inputs(None) is None

    # Test with a course
    course_url = "https://linuxacademy.com/cp/modules/view/id/154"
    course = LinuxAcademyIE()
    course.suitable(course_url)
    course.extract(course_url)
    course_url = "https://linuxacademy.com/cp/modules/view/id/154"

# Generated at 2022-06-24 12:52:36.048674
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
    except Exception as e:
        assert False, e
    # TODO: test_real_initialize()

# Generated at 2022-06-24 12:52:37.271159
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:52:38.684690
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:52:39.811268
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert isinstance(LinuxAcademyIE(), InfoExtractor)

# Generated at 2022-06-24 12:52:41.600140
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._downloader.params['username'] == "None"
    assert LinuxAcademyIE()._downloader.params['password'] == "None"
    

# Generated at 2022-06-24 12:52:43.256853
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Should not raise any error extractor.
    LinuxAcademyIE()

# Generated at 2022-06-24 12:52:44.259524
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:52:46.273997
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie is not None

# Test every function in LinuxAcademyIE

# Generated at 2022-06-24 12:52:47.764279
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    return LinuxAcademyIE()

# Generated at 2022-06-24 12:52:48.915268
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None)

# Generated at 2022-06-24 12:52:50.916766
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE('linuxacademy')
    assert ie.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:52:56.081491
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # test_LinuxAcademyIE_sample 
    ie = LinuxAcademyIE()
    # test_LinuxAcademyIE_get_login_info 
    assert ie.get_login_info() == (None, None)
    # test_LinuxAcademyIE_login 
    assert ie.login() is None
    # test_LinuxAcademyIE_get_login_info_again 
    assert ie.get_login_info() == (None, None)
    # test_LinuxAcademyIE_login_again 
    assert ie.login() is None
    # test_LinuxAcademyIE_course_path 
    assert ie.course_path(None) is None
    # test_LinuxAcademyIE_single_video_path 
    assert ie.single_video_path(None) is None


# Generated at 2022-06-24 12:52:57.562803
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.IE_NAME == 'LinuxAcademy'

# Generated at 2022-06-24 12:53:00.353506
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:53:08.590275
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert not hasattr(LinuxAcademyIE, 'IE_NAME')
    LinuxAcademyIE()
    assert hasattr(LinuxAcademyIE, 'IE_NAME')
    assert LinuxAcademyIE.IE_NAME == 'linuxacademy'
    assert not hasattr(LinuxAcademyIE, '_VALID_URL')
    LinuxAcademyIE()
    assert hasattr(LinuxAcademyIE, '_VALID_URL')

# Generated at 2022-06-24 12:53:12.059409
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    #Check if the constructor of LinuxAcademyIE class is working properly
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)

# Generated at 2022-06-24 12:53:15.750523
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE(None, None)._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'


# Generated at 2022-06-24 12:53:24.077473
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(None)

    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-24 12:53:27.790229
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_cases = ['https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2', 'https://linuxacademy.com/cp/modules/view/id/154']
    for test_url in test_cases:
        LinuxAcademyIE()._login()

# Generated at 2022-06-24 12:53:34.281070
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # The following tests require an active Linux Academy account login
    unittest.TestCase.skipTest(unittest.TestCase(), 'Requires valid account credentials!')
    # Uncomment the following lines to run the test
    # _, _ = get_login_info()
    # username, password = _
    # LinuxAcademyIE(username=username, password=password)

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:53:41.616566
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # pylint: disable=line-too-long

    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    LinuxAcademyIE._download_webpage = lambda self, url, *args, **kwargs: url
    LinuxAcademyIE._hidden_inputs = lambda self, url: {'access_token': 'access_token', 'token_type': 'token_type'}
    LinuxAcademyIE._download_webpage = lambda self, url, *args, **kwargs: url
    info_dict = LinuxAcademyIE()._real_extract(url)
    assert info_dict.get('id') == '7971-2'

# Generated at 2022-06-24 12:53:42.217615
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:53:50.601844
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_common import make_subtest
    from .common import InfoExtractor
    from .youtube import YoutubeIE
    from .generic import GenericIE

    ie= InfoExtractor(LinuxAcademyIE.ie_key())

    #  This test checks if it is a YoutubeIE object
    ie_subtest = make_subtest(ie, 'LinuxAcademyIE YoutubeIE', YoutubeIE)
    ie_subtest.run()

    #  This test checks if it is a GenericIE object
    ie_subtest = make_subtest(ie, 'LinuxAcademyIE GenericIE', GenericIE)
    ie_subtest.run()

# Generated at 2022-06-24 12:53:52.127790
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print(LinuxAcademyIE().supported_ie)

# Generated at 2022-06-24 12:53:53.761475
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert isinstance(LinuxAcademyIE(), LinuxAcademyIE)

# Generated at 2022-06-24 12:53:55.007383
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:54:07.236739
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Create object of class LinuxAcademyIE
    ie = LinuxAcademyIE()

    # Test the name of the class
    assert ie.IE_NAME == 'linuxacademy'
    # Test the expected valid url
    expected = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    assert ie._VALID_URL == expected
    # Test the expected tests

# Generated at 2022-06-24 12:54:08.797666
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    IE = LinuxAcademyIE()
    assert(IE.extractor_key == LinuxAcademyIE.ie_key())

# Generated at 2022-06-24 12:54:09.775391
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()


# Generated at 2022-06-24 12:54:10.412955
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-24 12:54:18.335296
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    u = 'https://linuxacademy.com/cp/modules/view/id/154'
    assert(LinuxAcademyIE.suitable(u))
    assert(LinuxAcademyIE._VALID_URL == LinuxAcademyIE._VALID_URL)
    assert(LinuxAcademyIE._CLIENT_ID == LinuxAcademyIE._CLIENT_ID)
    assert(LinuxAcademyIE._NETRC_MACHINE == LinuxAcademyIE._NETRC_MACHINE)
    return

# Generated at 2022-06-24 12:54:29.339501
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_ie = LinuxAcademyIE()
    assert linux_academy_ie.IE_NAME == 'LinuxAcademy'
    assert linux_academy_ie.IE_DESC == 'Linux Academy'
    assert linux_academy_ie._VALID_URL == r'(?x)\Ahttps?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))\Z'
    assert linux_academy_ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert linux_academy_ie._ORIGIN

# Generated at 2022-06-24 12:54:31.001259
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.IE_NAME == 'LinuxAcademy'

# Generated at 2022-06-24 12:54:34.487757
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.__name__ == 'LinuxAcademy'
    assert ie.ie_key() == 'linuxacademy'
    assert ie(LinuxAcademyIE.VALID_URL)

# Generated at 2022-06-24 12:54:36.389979
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._CLIENT_ID
    assert ie._NETRC_MACHINE

# Generated at 2022-06-24 12:54:46.497053
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    filename = 'test.txt'
    infile = open(filename,"w")
    # The page from URL
    pageUrl = 'https://linuxacademy.com/cp/courses/lesson/course/158/lesson/4/module/158'
    infile.write(pageUrl)
    infile.close()
    infile = open(filename,"r")
    info_extractor = LinuxAcademyIE(infile)
    # Unit test for check_valid_url
    assert info_extractor.check_valid_url(pageUrl)
    # Unit test for _real_extract
    # Get the result of the URL
    info_extractor._real_extract(pageUrl)
    # Get the current video URL

# Generated at 2022-06-24 12:54:51.254620
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    #create a temporary object of class LinuxAcademyIE
    linux_academy = LinuxAcademyIE()
    #call the _real_initialize method of object linux_academy_class
    linux_academy._real_initialize()
    #call the _real_extract method of object linux_academy_class
    linux_academy._real_extract('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    

# Generated at 2022-06-24 12:54:53.752420
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademy_ie = LinuxAcademyIE()
    print(linuxacademy_ie)
    assert(linuxacademy_ie is not None)

# Generated at 2022-06-24 12:54:56.031371
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Instantiate
    LinuxAcademyIE()
    return 0
# Call test_LinuxAcademyIE()
test_LinuxAcademyIE()

# Generated at 2022-06-24 12:55:04.309953
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Testing URL format like https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675
    assert LinuxAcademyIE._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )'''

    # Testing URL format like https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2

# Generated at 2022-06-24 12:55:15.306583
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie._VALID_URL == LinuxAcademyIE._VALID_URL
    # assert ie.NETRC_MACHINE == LinuxAcademyIE.NETRC_MACHINE
    assert ie._WORKING == False
    ie._WORKING = True
    ie.IE_NAME = 'Test Name'
    ie.USERNAME = 'Test Username'
    ie._VALID_URL = 'Test URL'
    ie.NETRC_MACHINE = 'Test Machine'
    # ie.report_download_webpage(...)
    ie._login()
    ie._real_extract('http://test_url')

# Generated at 2022-06-24 12:55:16.239741
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:55:26.916543
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    filename = 'tests/test_data/test_LinuxAcademy.txt'
    userpass = re.search('(.+):(.+)\n', open(filename,'r').read()).group(1, 2)
    username = userpass[0]
    password = userpass[1]
    # Unit test for constructor of class LinuxAcademyIE
    la = LinuxAcademyIE()
    la.ie_key()
    # Unit test for _real_initialize
    la._real_initialize()
    # Unit test for _real_extract
    # The following is subject to change since a new account/password
    # could be used as a parameter to the unit test.

# Generated at 2022-06-24 12:55:36.838276
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # 'course_id': r'\d+',
    # 'chapter_id': r'\d+',
    # 'lesson_id': r'\d+',
    # 'chapter': r'[^"]+',
    # 'chapter_number': r'[^"]+',
    # 'course_id': r'\d+',
    # 'm3u8_url': r'https?://[^"]+\.m3u8',
    pattern = re.compile(LinuxAcademyIE._VALID_URL)
    assert pattern.match('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    assert pattern.match('https://linuxacademy.com/cp/modules/view/id/154')

# Generated at 2022-06-24 12:55:40.857168
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    infoExtractor = LinuxAcademyIE()
    assert(infoExtractor.IE_NAME == 'linuxacademy' or infoExtractor.IE_NAME == 'LinuxAcademy')
    assert(infoExtractor.IE_DESC == 'Linux Academy' or infoExtractor.IE_DESC == 'LinuxAcademy.com')
test_LinuxAcademyIE()

# Generated at 2022-06-24 12:55:43.150346
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie is not None
    assert ie.ie_key() == "LinuxAcademy"
    assert ie.ie_name() == "LinuxAcademy"

# Generated at 2022-06-24 12:55:44.300066
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print("Testing LinuxAcademyIE")
    objIE = LinuxAcademyIE()

# Generated at 2022-06-24 12:55:46.695794
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    test_LinuxAcademyIE
    """

    assert(LinuxAcademyIE().ie_key() == 'LinuxAcademy')

# Generated at 2022-06-24 12:55:50.433849
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE(None)._CLIENT_ID != ""
    assert LinuxAcademyIE(None)._ORIGIN_URL != ""
    assert LinuxAcademyIE(None)._AUTHORIZE_URL != ""
    assert LinuxAcademyIE(None)._VALID_URL != ""

# Generated at 2022-06-24 12:55:55.366201
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    lai = LinuxAcademyIE()
    assert lai._VALID_URL == r'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'

# Generated at 2022-06-24 12:55:57.037180
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    print("Testing LinuxAcademyIE constructed successfully")

# Generated at 2022-06-24 12:56:06.520877
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import os
    import subprocess
    from ydl_functions import get_ydl_version

    ydl_version = get_ydl_version()

    def fail(msg):
        raise Exception("Test failed: %s" % msg)

    if os.name != 'posix' or os.getuid() != 0:
        print("This test requires root permissions because it needs an internet connection")
        print("Please run it as root, as in 'sudo %s'" % sys.argv[0])
        return

    if not re.match(r'\d+\.\d+\.\d+', ydl_version):
        fail("Unable to obtain youtube-dl version")


# Generated at 2022-06-24 12:56:08.158138
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('')

# Generated at 2022-06-24 12:56:10.099248
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # test if LinuxAcademyIE instance is created successfully
    assert LinuxAcademyIE()


# Generated at 2022-06-24 12:56:11.226095
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:56:12.479794
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:56:17.653293
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    for url in (
        'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
        'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2',
        'https://linuxacademy.com/cp/modules/view/id/154'
    ):
        LinuxAcademyIE().suitable(url)

# Generated at 2022-06-24 12:56:20.415480
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)

# Generated at 2022-06-24 12:56:21.183050
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:56:22.158518
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('foo')

# Generated at 2022-06-24 12:56:25.137847
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    # Test for _real_initialize()
    ie._real_initialize()
    # Test for _real_extract()
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    ie._real_extract(url)

# Generated at 2022-06-24 12:56:26.313211
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    return type(ie) is LinuxAcademyIE

# Generated at 2022-06-24 12:56:29.737433
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    username, password = LinuxAcademyIE._get_login_info()
    ie = LinuxAcademyIE()
    ie._login()



# Generated at 2022-06-24 12:56:31.268174
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test the constructor of LinuxAcademyIE
    LinuxAcademyIE()

# Generated at 2022-06-24 12:56:34.160771
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()
    # If the unit test execution reach the last line of this unit test, in
    # this case, there were no errors, and the test has passed.
    assert True

# Generated at 2022-06-24 12:56:43.060265
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Syntax for importing class without actually running code in module
    from .test_linuxacademy import LinuxAcademyIE
    # Assign parameters from out test function to the
    #   parameters from the constructor for the class we are testing
    ie = LinuxAcademyIE(params={})
    # Verify that the assignment was successful by comparing
    #   parameters
    assert ie._VALID_URL == LinuxAcademyIE._VALID_URL
    assert ie._TESTS == LinuxAcademyIE._TESTS
    assert ie._AUTHORIZE_URL == LinuxAcademyIE._AUTHORIZE_URL
    assert ie._ORIGIN_URL == LinuxAcademyIE._ORIGIN_URL
    assert ie._CLIENT_ID == LinuxAcademyIE._CLIENT_ID
    assert ie._NETRC_MACHINE

# Generated at 2022-06-24 12:56:45.260748
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    i = LinuxAcademyIE()
    assert isinstance(i, InfoExtractor)
    assert isinstance(i, LinuxAcademyIE)

# Generated at 2022-06-24 12:56:55.947927
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    t = LinuxAcademyIE()
    assert t._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-24 12:56:56.650727
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert(LinuxAcademyIE.ie_key())

# Generated at 2022-06-24 12:56:57.683413
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:57:05.071093
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie_instance = LinuxAcademyIE()
    assert ie_instance._NETRC_MACHINE == "linuxacademy"
    assert ie_instance._CLIENT_ID == "KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx"
    assert ie_instance._ORIGIN_URL == "https://linuxacademy.com"
    assert ie_instance._AUTHORIZE_URL == "https://login.linuxacademy.com/authorize"

# Generated at 2022-06-24 12:57:08.660055
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    class_instance = LinuxAcademyIE()
    assert class_instance.get_username() == 'YOUR_USERNAME'
    assert class_instance.get_password() == 'YOUR_PASSWORD'

# Generated at 2022-06-24 12:57:09.360459
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE(None) is not None

# Generated at 2022-06-24 12:57:18.546929
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    login_test_url = 'https://www.linuxacademy.com/?redirect=/home'
    website_url = 'https://www.linuxacademy.com/'
    # Create a class instance
    ie = LinuxAcademyIE()
    # Get login info if error happens
    username, password = ie._get_login_info()
    if username is None:
        raise Exception('Linux Academy credentials not available, add them to your .netrc file')
    # Get the HTTPReqest plugin
    extractor = ie._download_webpage_handle
    # Get the login page
    webpage, urlh = extractor(login_test_url, None, 'Downloading login page')
    # Get the parsed login info
    url = urlh.geturl()

# Generated at 2022-06-24 12:57:29.158095
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert(instance.IE_NAME == 'LinuxAcademy')
    assert(instance.IE_DESC == 'Linux Academy')
    assert(instance._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|modules/view/id/(?P<course_id>\\d+))')
    assert(instance._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize')
    assert(instance._ORIGIN_URL == 'https://linuxacademy.com')

# Generated at 2022-06-24 12:57:30.307581
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()._real_initialize()

# Generated at 2022-06-24 12:57:32.595048
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test for constructor's exceptions
    with pytest.raises(AssertionError):
        LinuxAcademyIE("")
