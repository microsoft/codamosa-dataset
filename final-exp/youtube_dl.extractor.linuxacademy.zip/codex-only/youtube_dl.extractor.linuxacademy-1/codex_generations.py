

# Generated at 2022-06-24 12:47:39.136620
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Unit test method of LinuxAcademyIE
    """

    try:
        import http.client as http_client
    except ImportError:
        import httplib as http_client
    http_client.HTTPConnection.debuglevel = 1

    # Test login # TODO: try with valid login credentials
    ie = LinuxAcademyIE()
    ie._login()

    # Test _real_extract # TODO: try with valid url
    url = 'TODO'
    ie._real_extract(url)

# Generated at 2022-06-24 12:47:39.722368
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert True

# Generated at 2022-06-24 12:47:43.142736
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    username = 'username'
    password = 'password'

    ie = LinuxAcademyIE(None)
    ie.test_extract_url()
    ie.test_extract_course_url()

# Generated at 2022-06-24 12:47:54.097331
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'LinuxAcademy'
    assert ie.IE_DESC == 'Linux Academy'
    assert ie._VALID_URL == r'https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-24 12:47:55.043110
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print(LinuxAcademyIE())

# Generated at 2022-06-24 12:47:56.670881
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    site = LinuxAcademyIE()
    assert(site.IE_NAME == 'LinuxAcademy')

# Generated at 2022-06-24 12:47:59.081361
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # LinuxAcademyIE must be instantiated with the original IE class name
    ie = LinuxAcademyIE(LinuxAcademyIE.__name__)
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:48:02.479354
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = "https://linuxacademy.com/cp/modules/view/id/154"
    LinuxAcademyIE(LinuxAcademyIE.ie_key())._real_extract(url)

# Generated at 2022-06-24 12:48:09.036447
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    for input_url in (
            'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
            'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2',
            'https://linuxacademy.com/cp/modules/view/id/154',
            ):
        ie = LinuxAcademyIE()
        ie.extract(input_url)


# Generated at 2022-06-24 12:48:11.770928
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, LinuxAcademyIE)


# Generated at 2022-06-24 12:48:12.703408
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() in InfoExtractor._AVAILABLE_IE

# Generated at 2022-06-24 12:48:13.392423
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:48:14.315620
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Constructor of class IE
    _ = LinuxAcademyIE

# Generated at 2022-06-24 12:48:16.408713
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert isinstance(LinuxAcademyIE().IE_NAME, str)
    assert isinstance(LinuxAcademyIE()._VALID_URL, str)
    assert isinstance(LinuxAcademyIE()._TESTS, list)

# Generated at 2022-06-24 12:48:26.738117
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test variables
    url = "https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675"
    info_dict = {
        'id': '7971-2',
        'ext': 'mp4',
        'title': 'What Is Data Science',
        'description': 'md5:c574a3c20607144fb36cb65bdde76c99',
        'timestamp': 1607387907,
        'upload_date': '20201208',
        'duration': 304,
    }
    params = {
        'skip_download': True,
    }

# Generated at 2022-06-24 12:48:27.146790
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-24 12:48:27.791390
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('')

# Generated at 2022-06-24 12:48:31.798283
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Get all parameters
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    ie = LinuxAcademyIE()
    # Create instance
    test = LinuxAcademyIE(url)
    assert test.url == url
    assert test.extract() == ie.extract(url)
    assert test.ie_key() == ie.ie_key()
    assert test.suitable == ie.suitable
    assert test.ie_key() == ie.ie_key()

# Generated at 2022-06-24 12:48:33.445380
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'linuxacademy'


# Generated at 2022-06-24 12:48:42.173954
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._VALID_URL == \
        (r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/courses/'
         r'lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)')
    assert ie._NETRC_MACHINE == 'linuxacademy'
    return True


# Generated at 2022-06-24 12:48:45.028707
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # pylint: disable=protected-access
    assert LinuxAcademyIE._VALID_URL == LinuxAcademyIE._TESTS[0]['url']


# Generated at 2022-06-24 12:48:46.193722
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:48:46.718224
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:48:47.792949
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:48:51.896247
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # The login info is below.
    # The credentials of the user will be stored in the variable _LOGIN_INFO.
    _LOGIN_INFO = {
        'username': 'username',
        'password': 'password'
    }

# Generated at 2022-06-24 12:48:53.772837
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'linuxacademy'


# Generated at 2022-06-24 12:48:55.793835
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._VALID_URL == LinuxAcademyIE._VALID_URL

# Generated at 2022-06-24 12:48:58.208438
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_linuxacademy import test_linuxacademy
    test_linuxacademy()

# Generated at 2022-06-24 12:49:04.098767
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # create object for class LinuxAcademyIE
    actual_obj = LinuxAcademyIE()
    assert actual_obj._VALID_URL is not None
    assert actual_obj._TESTS is not None
    assert actual_obj._AUTHORIZE_URL is not None
    assert actual_obj._ORIGIN_URL is not None
    assert actual_obj._CLIENT_ID is not None
    assert actual_obj._NETRC_MACHINE is not None


# Generated at 2022-06-24 12:49:05.009234
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE.suite()

# Generated at 2022-06-24 12:49:10.714328
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_NAME == "LinuxAcademy"
    assert ie._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'

# Generated at 2022-06-24 12:49:11.462123
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:49:13.256797
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ja_IE = LinuxAcademyIE()
    assert ja_IE.__class__.__name__ == "LinuxAcademyIE"

# Generated at 2022-06-24 12:49:14.445428
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Verifying that object is created
    return LinuxAcademyIE()

# Generated at 2022-06-24 12:49:16.337314
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    return LinuxAcademyIE(InfoExtractor)

# Generated at 2022-06-24 12:49:18.344425
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
        return True
    except Exception:
        return False

# Generated at 2022-06-24 12:49:28.815144
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_linuxacademy import linuxacademy_test

# Generated at 2022-06-24 12:49:35.925156
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Testing with valid url
    test_url = 'https://linuxacademy.com/cp/modules/view/id/154'
    LinuxAcademyIE()._real_extract(test_url)

    # Testing with invalid url
    test_url = 'https://linuxacademy.com'
    try:
        LinuxAcademyIE()._real_extract(test_url)
    except ExtractorError as e:
        assert e.message == 'Invalid URL format'

    # Testing with invalid parameters
    try:
        LinuxAcademyIE()._real_extract(test_url)
    except AttributeError as e:
        assert e.message == "module 'urllib2' has no attribute 'urlopen'"

    # Testing with invalid password

# Generated at 2022-06-24 12:49:36.506979
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()

# Generated at 2022-06-24 12:49:37.614055
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:49:40.158906
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'LinuxAcademy'
    assert hasattr(ie, '_login')

# Generated at 2022-06-24 12:49:41.200369
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()._real_initialize()

# Generated at 2022-06-24 12:49:42.900219
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert obj is not None


# Generated at 2022-06-24 12:49:47.077485
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.GE_VERSION >= (2, 5, 5)

# Generated at 2022-06-24 12:49:51.282012
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/courses/lesson/course/0/lesson/13/module/1'
    ie = LinuxAcademyIE()
    #username, password = ie._get_login_info()
    #webpage, urlh = ie._download_webpage_handle(
    #    'https://login.linuxacademy.com/authorize', None, 'Downloading authorize page', query={
    #        'client_id': ie._CLIENT_ID,
    #        'response_type': 'token id_token',
    #        'response_mode': 'web_message',
    #        'redirect_uri': ie._ORIGIN_URL,
    #        'scope': 'openid email user_impersonation profile',
    #        'audience': ie._ORIG

# Generated at 2022-06-24 12:49:52.378548
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE();

# Generated at 2022-06-24 12:50:03.546888
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test LinuxAcademyIE without login
    ie = LinuxAcademyIE()
    s = "https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675"

# Generated at 2022-06-24 12:50:04.566494
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)

# Generated at 2022-06-24 12:50:06.157748
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert isinstance(LinuxAcademyIE, type)
    assert issubclass(LinuxAcademyIE, InfoExtractor)

# Generated at 2022-06-24 12:50:07.324765
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert isinstance(LinuxAcademyIE(), LinuxAcademyIE)


# Generated at 2022-06-24 12:50:10.281148
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:50:11.288105
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert isinstance(LinuxAcademyIE, type)

# Generated at 2022-06-24 12:50:12.673870
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:50:15.961087
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)


# Generated at 2022-06-24 12:50:17.261737
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    Ie = LinuxAcademyIE()
    Ie._login()
    print('LinuxAcademyIE Constructor works!')
    return

# Generated at 2022-06-24 12:50:18.676040
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert instance is not None
    LinuxAcademyIE.ie_key()
    return instance

# Generated at 2022-06-24 12:50:20.218493
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('LinuxAcademy')

# Generated at 2022-06-24 12:50:23.123791
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import sys
    sys.path.append('..')
    from tests.test_main import main_test_constructor
    main_test_constructor(LinuxAcademyIE)

# Generated at 2022-06-24 12:50:29.411742
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    class TestLinuxAcademyIE(LinuxAcademyIE):
        _VALID_URL = r'https://linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
        _NETRC_MACHINE = 'linuxacademy'

# Generated at 2022-06-24 12:50:38.508427
# Unit test for constructor of class LinuxAcademyIE

# Generated at 2022-06-24 12:50:39.460787
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None)

# Generated at 2022-06-24 12:50:40.129687
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print(LinuxAcademyIE)


# Generated at 2022-06-24 12:50:42.901145
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'
    info_extractor = ie.create_ie(ie.ie_key())
    assert isinstance(info_extractor, LinuxAcademyIE)

# Generated at 2022-06-24 12:50:43.907027
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:50:49.435526
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    l = LinuxAcademyIE()
    assert l._AUTHORIZE_URL == "https://login.linuxacademy.com/authorize"
    assert l._ORIGIN_URL == "https://linuxacademy.com"
    assert l._CLIENT_ID == "KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx"
    assert l._NETRC_MACHINE == "linuxacademy"

# Generated at 2022-06-24 12:50:50.889844
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert isinstance(instance, LinuxAcademyIE)

# Generated at 2022-06-24 12:50:52.591611
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    IE = LinuxAcademyIE()
    IE.IE_NAME

# Generated at 2022-06-24 12:51:01.354244
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert (LinuxAcademyIE()._AUTHORIZE_URL ==
            'https://login.linuxacademy.com/authorize')
    assert (LinuxAcademyIE()._ORIGIN_URL ==
            'https://linuxacademy.com')
    assert (LinuxAcademyIE()._CLIENT_ID ==
            'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx')
    assert (LinuxAcademyIE()._NETRC_MACHINE ==
            'linuxacademy')


# Generated at 2022-06-24 12:51:04.901798
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    LinuxAcademyIE()._real_extract(url)

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:51:06.060251
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:51:07.222321
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:51:09.535842
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
    except Exception as e:
        assert False, "Failed to create instance of class LinuxAcademyIE: " + str(e)



# Generated at 2022-06-24 12:51:21.460334
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_downloader import TestDownloader
    from .test_utils import FakeLoginIE
    from .test_utils import TestPPTServer
    from .test_utils import MockServer

    def _logged_in(webpage):
        # We are logged in if the file download form is found
        return 'Please wait while your file is being generated' in webpage

    with TestPPTServer() as (port, base_url):
        with MockServer(('localhost', port)):
            url = urljoin(base_url, 'test.html')
            ie = FakeLoginIE('linuxacademy', LinuxAcademyIE.ie_key(),
                             _logged_in, url)
            assert ie.logged_in == False
            assert ie.login_info == {}
            assert ie._is_logged() == False
            ie

# Generated at 2022-06-24 12:51:22.886291
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test LinuxAcademyIE after constructor
    assert LinuxAcademyIE is not None

# Generated at 2022-06-24 12:51:30.636740
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert obj._VALID_URL == r'(?x)' \
        r'https?://' \
        r'(?:www\.)?linuxacademy\.com/cp/' \
        r'(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|' \
        r'modules/view/id/(?P<course_id>\d+))'

    assert obj._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert obj._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-24 12:51:32.953172
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert obj.username == ''
    assert obj.password == ''

# Generated at 2022-06-24 12:51:35.250993
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test instantiation of LinuxAcademyIE class
    # This test only tests the instantiation of the class.
    LinuxAcademyIE()

# Generated at 2022-06-24 12:51:45.588875
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = "https://linuxacademy.com/cp/modules/view/id/154"
    ie = LinuxAcademyIE()
    # configuring
    ie.set_user_agent("Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.1")
    # initialization procedure is skipped
    ie._initialize_decider = None
    # fetch and check info about the video
    info = ie.extract(url)
    assert info['id'] == '154'
    assert info['title'] == 'AWS Certified Cloud Practitioner'
    assert info['description'] == 'md5:a68a299ca9bb98d41cca5abc4d4ce22c'
    assert info['duration'] == 28835

# Generated at 2022-06-24 12:51:48.338174
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE('https://www.linuxacademy.com/cp/modules/view/id/154')
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:51:48.988219
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-24 12:51:53.640504
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    x = LinuxAcademyIE()
    assert(x.IE_NAME == "linuxacademy")
    assert(x.IE_DESC == "linuxacademy.com")
    assert(x._VALID_URL == "https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))")

# Generated at 2022-06-24 12:51:59.773876
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ieobj = LinuxAcademyIE()
    assert ieobj._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ieobj._ORIGIN_URL == 'https://linuxacademy.com'
    assert ieobj._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ieobj._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:52:10.431222
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._TESTS

# Generated at 2022-06-24 12:52:12.040347
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(None, None, None)
    ie._login()
    return ie

# Generated at 2022-06-24 12:52:13.184393
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE().ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:52:14.015150
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None)

# Generated at 2022-06-24 12:52:15.468439
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademy_ie = LinuxAcademyIE()

# Generated at 2022-06-24 12:52:26.727814
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_LinuxAcademyIE.LinuxAcademyIE = LinuxAcademyIE()   # Note the trailing parenthesis
    assert test_LinuxAcademyIE.LinuxAcademyIE._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert test_LinuxAcademyIE.LinuxAcademyIE._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:52:35.189115
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Unit test for constructor of class LinuxAcademyIE
    """
    # Create an instance of LinuxAcademyIE
    class_instance = LinuxAcademyIE()

    # Check if the constructed object has all required attributes
    assert hasattr(class_instance, "_VALID_URL")
    assert hasattr(class_instance, "_NETRC_MACHINE")
    assert hasattr(class_instance, "_LOGIN_URL")
    assert hasattr(class_instance, "_AUTHORIZE_URL")
    assert hasattr(class_instance, "_CLIENT_ID")
    assert hasattr(class_instance, "_NETRC_MACHINE")
    assert hasattr(class_instance, "_TEST")


# Generated at 2022-06-24 12:52:36.602500
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Unit test for constructor of class LinuxAcademyIE
    """
    LinuxAcademyIE()

# Generated at 2022-06-24 12:52:45.015022
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # This function is the unit test for class LinuxAcademyIE
    url_test_dict = {
        'url': 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    }
    local_linux_academy_ie = LinuxAcademyIE(url_test_dict)
    assert local_linux_academy_ie.suitable(url_test_dict) == True, "The function does not work correctly under test 1"
    assert local_linux_academy_ie._NETRC_MACHINE == "linuxacademy", "The function does not work correctly under test 2"

# Generated at 2022-06-24 12:52:47.009974
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    course = LinuxAcademyIE()
    course._login()
    pass

# Generated at 2022-06-24 12:52:49.133624
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Unit test for class LinuxAcademyIE"""
    info_extractor = LinuxAcademyIE()

# Generated at 2022-06-24 12:52:50.758022
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxAcademyIE = LinuxAcademyIE()
    asser

# Generated at 2022-06-24 12:52:51.972020
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:52:54.535203
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test import NAME_RE, run_test
    run_test(LinuxAcademyIE, {}, {NAME_RE: ['LinuxAcademy']})

# Generated at 2022-06-24 12:52:56.510481
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    return LinuxAcademyIE(LinuxAcademyIE.ie_key(), LinuxAcademyIE.ie_key())

# Generated at 2022-06-24 12:53:05.070463
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie=LinuxAcademyIE()
    assert('linuxacademy' in ie._NETRC_MACHINE)
    assert(ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize')
    assert(ie._ORIGIN_URL == 'https://linuxacademy.com')
    assert(ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx')

# Generated at 2022-06-24 12:53:06.674871
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie_instance = LinuxAcademyIE()
    assert ie_instance.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:53:08.938797
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LA = LinuxAcademyIE()
    LA.initialize()
    LA.extract('https://linuxacademy.com/cp/modules/view/id/91')

# Generated at 2022-06-24 12:53:12.060675
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE('LinuxAcademy', 'linuxacademy')
        assert(True)
    except:
        assert(False)

# Generated at 2022-06-24 12:53:14.900681
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """ Unit test for constructor of class LinuxAcademyIE """
    assert issubclass(LinuxAcademyIE, InfoExtractor)


# Generated at 2022-06-24 12:53:16.777703
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    lai = LinuxAcademyIE()
    assert lai.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:53:18.981281
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # I don't know how to test this class yet
    print('This test is skipped because I don\'t know how to test it')

# Generated at 2022-06-24 12:53:21.108361
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_object = LinuxAcademyIE()
    print(test_object)

# vim: tabstop=2 expandtab shiftwidth=2

# Generated at 2022-06-24 12:53:22.092580
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Only check if it is constructable
    LinuxAcademyIE()

# Generated at 2022-06-24 12:53:22.881731
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(InfoExtractor)

# Generated at 2022-06-24 12:53:25.085782
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # this is a test for LinuxAcademyIE constructor
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'linuxacademy'

# Generated at 2022-06-24 12:53:35.551391
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .. import LinuxAcademyIE
    test = LinuxAcademyIE(None)
    assert test._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert test._ORIGIN_URL == 'https://linuxacademy.com'
    assert test._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert test._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:53:38.130859
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, LinuxAcademyIE)
    assert type(ie).__name__ == 'LinuxAcademyIE'

# Generated at 2022-06-24 12:53:46.121101
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    extractor = LinuxAcademyIE()
    video_url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    video_id = extractor.extract_id(video_url)
    assert (video_id == '7971-2')
    # Test the case
    # url = 'https://linuxacademy.com/cp/modules/view/id/154'
    # extractor._real_extract(url)

# Generated at 2022-06-24 12:53:50.240702
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # module not found
    ie = LinuxAcademyIE()
    ie._real_initialize()
    ie._login()
    assert ie.IE_NAME == 'linuxacademy'
    ie._real_extract('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    ie = LinuxAcademyIE()
    ie._real_initialize()
    ie._login()
    assert ie.IE_NAME == 'linuxacademy'
    ie._real_extract('https://linuxacademy.com/cp/modules/view/id/154')

# Generated at 2022-06-24 12:53:56.958613
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    i = LinuxAcademyIE()
    assert i._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert i._ORIGIN_URL == 'https://linuxacademy.com'
    assert i._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-24 12:54:08.592805
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    lae = LinuxAcademyIE()
    assert lae.ie_key() == 'LinuxAcademy'
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'
    assert lae._NETRC_MACHINE == 'linuxacademy'
    assert lae._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert lae._ORIGIN_URL == 'https://linuxacademy.com'
    assert lae._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'

# Generated at 2022-06-24 12:54:10.303205
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # tested in test_LinuxAcademyCourseIE and test_LinuxAcademyLectureIE
    pass

# Generated at 2022-06-24 12:54:19.279778
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Testing constructors of class LinuxAcademyIE."""
    obj = LinuxAcademyIE()
    obj_linuxacademyie = LinuxAcademyIE(obj)
    assert obj._VALID_URL == obj_linuxacademyie._VALID_URL
    assert obj._AUTHORIZE_URL == obj_linuxacademyie._AUTHORIZE_URL
    assert obj._ORIGIN_URL == obj_linuxacademyie._ORIGIN_URL
    assert obj._NETRC_MACHINE == obj_linuxacademyie._NETRC_MACHINE

# Generated at 2022-06-24 12:54:21.172805
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:54:22.638177
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    a = LinuxAcademyIE()
    a._real_initialize()

# Generated at 2022-06-24 12:54:31.870897
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-24 12:54:33.438338
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:54:35.648763
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # call constructor of LinuxAcademyIE
    linuxacademy_ie = LinuxAcademyIE()
    assert linuxacademy_ie is not None

# Generated at 2022-06-24 12:54:36.761880
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_obj=LinuxAcademyIE()

# Generated at 2022-06-24 12:54:38.180997
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:54:40.192401
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from . import _test_instantiation as shared_test_instantiation, LinuxAcademyIE
    # test for the proper initialization of the class
    shared_test_instantiation.test_InfoExtractor(LinuxAcademyIE)

# Generated at 2022-06-24 12:54:42.082326
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxAcademyIE = LinuxAcademyIE();
    assert linuxAcademyIE != None


# Generated at 2022-06-24 12:54:43.393821
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    x = LinuxAcademyIE()
    assert x != None

# Generated at 2022-06-24 12:54:45.025881
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'

# Generated at 2022-06-24 12:54:47.145833
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from . import LinuxAcademyIE  # flake8: noqa: F811 # pylint: disable=E0611
    assert LinuxAcademyIE.ie_key() == 'linuxacademy'

# Generated at 2022-06-24 12:54:57.193651
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test if the constructor of the class LinuxAcademyIE works as expected
    test_cases = [
        'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
        'https://linuxacademy.com/cp/modules/view/id/154',
    ]
    for url in test_cases:
        url_info = LinuxAcademyIE._build_url_result(url)
        assert url_info.url == url
        assert url_info.ie_key == 'LinuxAcademy'
        assert url_info.video_id == '154'
        assert url_info.query == {}

# Generated at 2022-06-24 12:55:01.053803
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    my_instance = LinuxAcademyIE()
    # Test for function _login
    my_instance._login()
    # Test for function _real_extract
    url_1 = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    url_2 = 'https://linuxacademy.com/cp/modules/view/id/154'
    my_instance._real_extract(url_1)
    my_instance._real_extract(url_2)
    pass

# Generated at 2022-06-24 12:55:13.333717
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_linuxacademy import TEST_PAGE
    import re

    extractor = LinuxAcademyIE()

    class FakeSocket:
        def __init__(self, response_str):
            self._file = compat_str(response_str)

        def makefile(self, *args, **kwargs):
            return self

        def readline(self, *args, **kwargs):
            return self._read_line()

        def _read_line(self, *args, **kwargs):
            if self._file:
                idx = self._file.find('\n')
                if idx == -1:
                    res = self._file
                    self._file = ''
                    return res + '\n'
                else:
                    res = self._file[:idx + 1]

# Generated at 2022-06-24 12:55:15.233919
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # test case
    imge = LinuxAcademyIE()
    print(imge.__class__.__name__)

# Generated at 2022-06-24 12:55:20.517745
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print('Test %s'%__file__)
    try:
        # windows
        netrc_path = os.path.join(os.environ['USERPROFILE'], r'.netrc')
        # linux
        netrc_path = os.path.join(os.environ['HOME'], r'.netrc') if not os.path.exists(netrc_path) else netrc_path
        LinuxAcademyIE(netrc_path=netrc_path)
    except Exception as e:
        print(e)
        return

    print('All test case passed')

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:55:21.649354
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:55:30.982968
# Unit test for constructor of class LinuxAcademyIE

# Generated at 2022-06-24 12:55:36.533628
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE('LinuxAcademy')
    assert(instance.CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx')
    assert(instance.ORIGIN_URL == 'https://linuxacademy.com')
    assert(instance.NETRC_MACHINE == 'linuxacademy')

# Generated at 2022-06-24 12:55:37.572706
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE() is not None

# Generated at 2022-06-24 12:55:38.586433
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()

# Generated at 2022-06-24 12:55:41.934336
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE(): # noqa: F811
    with pytest.raises(Exception) as e:
        LinuxAcademyIE('linuxacademy', 'invalid_url_exception') # noqa: F821
        assert str(e) == 'invalid url'

# Generated at 2022-06-24 12:55:45.861110
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    if not LinuxAcademyIE()._login_available():
        print("Linux Academy credentials not available, can't perform unit test")
    else:
        LinuxAcademyIE()._real_extract('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')

# Generated at 2022-06-24 12:55:54.155101
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import sys
    from .common import get_testfile
    
    # Check that the static variable in class LinuxAcademyIE is initialized
    assert LinuxAcademyIE._VALID_URL, 'URL pattern for linuxacademy.com is not initialized'
    assert LinuxAcademyIE._TESTS, 'Test cases for linuxacademy.com is not initialized'
    
    # Create an instance of InfoExtractor class
    ie = LinuxAcademyIE()
    assert ie, 'Failed to create an instance of LinuxAcademyIE class'

    # Check login()
    # TODO: Implement
    
    # Create an instance of LinuxAcademyIE class

# Generated at 2022-06-24 12:55:56.328109
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.__class__.__name__ == 'LinuxAcademyIE'

# Generated at 2022-06-24 12:55:58.720438
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test constructor of class LinuxAcademyIE in this module
    # Passed
    print("Test LinuxAcademyIE constructor done.")

# Generated at 2022-06-24 12:56:02.108710
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-24 12:56:05.746911
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademy_ie = LinuxAcademyIE('LinuxAcademy')
    assert linuxacademy_ie.login_form_strs == ['login', 'user', 'username']
    assert linuxacademy_ie.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:56:07.715146
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    a = LinuxAcademyIE()
    a._real_initialize()

# Generated at 2022-06-24 12:56:09.280630
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE("LinuxAcademyIE")


# Generated at 2022-06-24 12:56:10.846500
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert(LinuxAcademyIE.ie_key() is not None)

# Generated at 2022-06-24 12:56:13.337937
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._login() == None
    ie._real_initialize()


# Generated at 2022-06-24 12:56:14.366906
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:56:15.349435
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

# Generated at 2022-06-24 12:56:16.544847
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
    except:
        assert False

# Generated at 2022-06-24 12:56:26.839310
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # pylint: disable=redefined-outer-name
    # pylint: disable=no-member
    import json
    import tempfile

    import pytest
    from six.moves import http_cookiejar
    from six.moves import urllib
    from six.moves.urllib.error import (
        HTTPError,
        URLError,
    )
    from six.moves.urllib.request import (
        HTTPRedirectHandler,
        HTTPResponse,
    )

    class MockRequest:
        # pylint: disable=too-few-public-methods
        _path = None

        def __init__(self, path):
            self._path = path


# Generated at 2022-06-24 12:56:35.945175
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Constructs a LinuxAcademyIE instance, which only requires one parameter
    # the course URL
    ie = LinuxAcademyIE()
    assert ie.suitable(None) == False
    assert ie.add_ie(None) == None
    assert ie.get_site_id() == ""
    assert ie.ie_key() == "LinuxAcademy"
    assert ie.extract('https://linuxacademy.com/cp/modules/view/id/154')['title'] == "AWS Certified Cloud Practitioner"

# Generated at 2022-06-24 12:56:37.169080
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:56:44.222273
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-24 12:56:52.175712
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    if __name__ == '__main__':
        # Load info extractor manually to prevent loading its dependencies
        # that are not necessary for this test
        ie = globals().get('LinuxAcademyIE')()
        test_input = 'https://www.linuxacademy.com/cp/modules/view/id/154'
        webpage = ie._download_webpage(test_input, 154, None)
        course_id = ie._search_regex(LinuxAcademyIE._VALID_URL, webpage, 'id')
        assert course_id == '154'

# Generated at 2022-06-24 12:56:56.825455
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    laie = LinuxAcademyIE()
    # Test _AUTHORIZE_URL value
    assert laie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    # Test _ORIGIN_URL value
    assert laie._ORIGIN_URL == 'https://linuxacademy.com'
    # Test _CLIENT_ID value
    assert laie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    # Test _NETRC_MACHINE value
    assert laie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:56:57.781169
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'linuxacademy'

# Generated at 2022-06-24 12:56:58.522276
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    res = LinuxAcademyIE()

# Generated at 2022-06-24 12:57:03.545248
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj_const = LinuxAcademyIE('')
    assert obj_const._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert obj_const._ORIGIN_URL == 'https://linuxacademy.com'
    assert obj_const._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert obj_const._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:57:05.434896
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None)

# Generated at 2022-06-24 12:57:06.895970
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie is not None


# Generated at 2022-06-24 12:57:11.669236
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE._LOGIN = 'test'
    LinuxAcademyIE._PASSWORD = 'test'
    # not valid
    assert LinuxAcademyIE()
    # valid
    assert LinuxAcademyIE()
    # unset
    LinuxAcademyIE._LOGIN = None
    LinuxAcademyIE._PASSWORD = None

# Generated at 2022-06-24 12:57:19.919827
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # pylint: disable=redefined-outer-name
    from .test_login import _mock_credentials
    LinuxAcademyIE.password = _mock_credentials.get('linuxacademy_password')
    LinuxAcademyIE.username = _mock_credentials.get('linuxacademy_username')

    # test_login

# Generated at 2022-06-24 12:57:30.357884
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from youtube_dl.utils import encode_data_uri
    from ..compat import compat_mock
    IE = LinuxAcademyIE

# Generated at 2022-06-24 12:57:35.707332
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    for url in [
            'https://linuxacademy.com/cp/modules/view/id/154',
            'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
        ]:
        html = _test_download(url)
        assert html