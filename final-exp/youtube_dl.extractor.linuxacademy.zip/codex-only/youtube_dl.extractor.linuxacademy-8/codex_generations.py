

# Generated at 2022-06-24 12:47:30.852317
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:47:34.174131
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert isinstance(LinuxAcademyIE().IE_NAME, str)
    assert isinstance(LinuxAcademyIE().SUCCESS_EMPTY_RESPONSE, bool)

# Generated at 2022-06-24 12:47:36.160171
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()
    # Test was successful if no error is thrown

# Generated at 2022-06-24 12:47:38.958178
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    le = LinuxAcademyIE()
    assert hasattr(le, '_NETRC_MACHINE')
    assert hasattr(le, '_CLIENT_ID')

# Generated at 2022-06-24 12:47:39.782206
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie is not None

# Generated at 2022-06-24 12:47:43.192226
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # create an instance of the class
    ix = LinuxAcademyIE()
    # return True if all the assertion passed
    assert ix
    # if assertion fails, return False, then print error
    assert all(ix)

# Generated at 2022-06-24 12:47:44.315873
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:47:46.056265
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import pytest
    from ..utils import extract_info

    pytest.main(__file__)

# Generated at 2022-06-24 12:47:49.385687
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.hostname() == 'linuxacademy.com'
    assert ie.IE_NAME == LinuxAcademyIE.IE_NAME
    assert ie.ssl() is False

# Generated at 2022-06-24 12:47:52.806433
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE("https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675")
    print(ie.IE_NAME)

# Generated at 2022-06-24 12:47:56.330555
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Unit test for constructor of class LinuxAcademyIE"""
    LinuxAcademyIE('LinuxAcademy', 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675', [], {})

# Generated at 2022-06-24 12:47:57.099986
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:48:01.248033
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_url=str('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    test_obj=LinuxAcademyIE(test_url)
    assert LinuxAcademyIE.ie_key() == 'linuxacademy'
    assert test_obj.ie_key() == 'linuxacademy'
    assert test_obj._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'

# Generated at 2022-06-24 12:48:07.637563
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE(None, 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    assert instance.suitable('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    assert instance.suitable('https://linuxacademy.com/cp/modules/view/id/154')



# Generated at 2022-06-24 12:48:09.085601
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:48:09.700403
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:48:11.485758
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    if (ie != None):
        print("LinuxAcademyIE constructed!")

# Generated at 2022-06-24 12:48:17.753298
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test constructors of LinuxAcademyIE
    obj = LinuxAcademyIE()
    assert obj.suitable('http://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    assert obj.suitable('https://linuxacademy.com/cp/modules/view/id/154')
    assert obj.suitable('https://linuxacademy.com/cp/courses/lesson/course')
    assert not obj.suitable('https://linuxacademy.com/cp/courses/lesson/course.html')
    assert not obj.suitable('http://linuxacademy.com/cp')
    assert not obj.suitable('https://linuxacademy.com')
    assert not obj.suitable(None)

# Generated at 2022-06-24 12:48:27.481621
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test the class constructor
    ies_class = LinuxAcademyIE.ie_key()
    obj = ies_class(LinuxAcademyIE.IE_NAME, LinuxAcademyIE.ie_key())
    assert obj._VALID_URL == LinuxAcademyIE._VALID_URL
    assert obj._AUTHORIZE_URL == LinuxAcademyIE._AUTHORIZE_URL
    assert obj._ORIGIN_URL == LinuxAcademyIE._ORIGIN_URL
    assert obj._CLIENT_ID == LinuxAcademyIE._CLIENT_ID
    assert obj._NETRC_MACHINE == LinuxAcademyIE._NETRC_MACHINE
    assert obj._login == LinuxAcademyIE._login
    assert obj._real_initialize == LinuxAcademyIE._real_initialize

# Generated at 2022-06-24 12:48:28.366380
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert(LinuxAcademyIE().ie_key() == 'LinuxAcademy')

# Generated at 2022-06-24 12:48:29.288003
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE().ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:48:34.318608
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie._VALID_URL == r'https?://(?:www\.)?linuxacademy\.com/cp/(courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC

# Generated at 2022-06-24 12:48:42.832531
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert ('linuxacademy', None) in LinuxAcademyIE._LOGIN_RESTORE_PAGE_INDEX.values()
    assert ('linuxacademy', None) in LinuxAcademyIE._LOGIN_RESTORE_VIDEO_INDEX.values()
    assert ('linuxacademy', None) in LinuxAcademyIE._LOGIN_RESTORE_PLAYLIST_INDEX.values()
    assert ('linuxacademy', None) in LinuxAcademyIE._login_info_index.values()
    assert ('linuxacademy', None) in LinuxAcademyIE._NETRC_MACHINE_INDEX.values()

# Generated at 2022-06-24 12:48:44.123711
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:48:45.657714
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None, 'http://test.test/test')

# Generated at 2022-06-24 12:48:57.749006
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    e = LinuxAcademyIE()
    assert e.__class__.__name__ == 'LinuxAcademyIE'
    assert e.IE_NAME == 'linuxacademy'
    assert e._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'

# Generated at 2022-06-24 12:49:01.102490
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    test_url = 'https://linuxacademy.com/cp/modules/view/id/154'
    ie.extract('test_url')


test_LinuxAcademyIE()

# Generated at 2022-06-24 12:49:02.434999
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.name == "LinuxAcademy"


# Generated at 2022-06-24 12:49:03.810067
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:49:05.546844
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('https://linuxacademy.com/cp/modules/view/id/154')

# Generated at 2022-06-24 12:49:07.353278
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_LinuxAcademyIE = LinuxAcademyIE()
    test_LinuxAcademyIE._login()

# Generated at 2022-06-24 12:49:14.015816
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Unit test is able to get lesson, sure that this test is passed too
    assert LinuxAcademyIE()._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''


# Generated at 2022-06-24 12:49:24.978904
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/courses/lesson/course/1234/lesson/5678'
    assert LinuxAcademyIE._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert LinuxAcademyIE._ORIGIN_URL == 'https://linuxacademy.com'
    assert LinuxAcademyIE._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert LinuxAcademyIE._NETRC_MACHINE == 'linuxacademy'
    # Test url parsing

# Generated at 2022-06-24 12:49:34.709956
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    _VALID_URL = r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    _AUTHORIZE_URL = 'https://login.linuxacademy.com/authorize'
    _ORIGIN_URL = 'https://linuxacademy.com'
    _CLIENT_ID = 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    _NETRC_MACHINE = 'linuxacademy'


# Generated at 2022-06-24 12:49:35.781705
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    # fake login
    ie._login()



# Generated at 2022-06-24 12:49:37.427300
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(None)
    assert ie.VALID_URL == LinuxAcademyIE._VALID_URL

# Generated at 2022-06-24 12:49:39.315288
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'

# Generated at 2022-06-24 12:49:41.397600
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(_download_json,
                    lambda _: _['_type'])()._real_initialize()

# Generated at 2022-06-24 12:49:44.754894
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    username = input("Please enter your Linux Academy username: ")
    password = getpass("Please enter your Linux Academy password (won't be echoed): ")
    ie = LinuxAcademyIE(username=username, password=password)

# Generated at 2022-06-24 12:49:46.825225
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    ie.login()
    assert(True)

# Generated at 2022-06-24 12:49:49.700383
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-24 12:50:01.315500
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    with open("/home/manh/Work/Github/youtube-dl/youtube_dl/extractor/tests/testdata/test_linuxacademy/login.json") as login_json_file:
        login_json = json.load(login_json_file)
    with open("/home/manh/Work/Github/youtube-dl/youtube_dl/extractor/tests/testdata/test_linuxacademy/module.json") as module_json_file:
        module_json = json.load(module_json_file)
    with open("/home/manh/Work/Github/youtube-dl/youtube_dl/extractor/tests/testdata/test_linuxacademy/lesson.json") as lesson_json_file:
        lesson_json = json.load(lesson_json_file)

# Generated at 2022-06-24 12:50:02.717422
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxAcademyIE = LinuxAcademyIE()
    assert linuxAcademyIE != None
    assert linuxAcademyIE._TEST == True

# Generated at 2022-06-24 12:50:04.530695
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    class_ = LinuxAcademyIE
    ie = class_()
    assert ie._NETRC_MACHINE == 'linuxacademy'

    assert not class_._LOGIN_REQUIRED

# Generated at 2022-06-24 12:50:07.098917
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    account_info = {
        'username': 'boo@boo.com',
        'password': 'boo'
    }
    ie = LinuxAcademyIE()
    ie._login()

# Generated at 2022-06-24 12:50:10.328692
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert not LinuxAcademyIE._login_required()
    assert LinuxAcademyIE._login_required(LinuxAcademyIE('k', 'p')._real_extract(CHANNEL_URL))

# Generated at 2022-06-24 12:50:11.818770
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()
    LinuxAcademyIE()

# Generated at 2022-06-24 12:50:23.840405
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-24 12:50:26.019790
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_utils import instance_constructor_test
    instance_constructor_test(LinuxAcademyIE)

# Generated at 2022-06-24 12:50:33.134321
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie
    assert LinuxAcademyIE._AUTHORIZE_URL == ie._AUTHORIZE_URL
    assert LinuxAcademyIE._ORIGIN_URL == ie._ORIGIN_URL
    assert LinuxAcademyIE._CLIENT_ID == ie._CLIENT_ID
    assert LinuxAcademyIE._NETRC_MACHINE == ie._NETRC_MACHINE
    assert LinuxAcademyIE._TESTS == ie._TESTS


# Generated at 2022-06-24 12:50:37.442617
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    
    test_url = 'https://linuxacademy.com/cp/modules/view/id/154'
    test_playlist_count = 41
    test_obj = LinuxAcademyIE()
    downloader_result = test_obj.extract(test_url)
    if len(downloader_result['entries']) != test_playlist_count:
        assert False

# Generated at 2022-06-24 12:50:41.063151
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # This test uses a real account but no real action is performed
    # This test is only run when an environemnt variable is set
    import os
    if 'LA_USERNAME' not in os.environ:
        return
    LinuxAcademyIE(
        {'username': os.environ['LA_USERNAME'], 'password': os.environ['LA_PASSWORD']}
    )._login()

# Generated at 2022-06-24 12:50:46.961034
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert obj._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert obj._ORIGIN_URL == 'https://linuxacademy.com'
    assert obj._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert obj._NETRC_MACHINE == 'linuxacademy'


# Generated at 2022-06-24 12:50:58.986049
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    with open('test/test_data/download.linuxacademy.com/course.json', 'r') as f:
        course = json.load(f)

    assert course["id"] == '154'
    assert course['title'] == 'AWS Certified Cloud Practitioner'
    assert course['description'] == 'This course is designed to equip you with the knowledge and skills required to pass the AWS Certified Cloud Practitioner exam. Learn about AWS cloud concepts, security best practices, pricing, and support as you prepare for the associate-level certification.'
    assert course['duration'] == 28835
    assert len(course['entries']) == 41
    
    assert type(course['entries'][0]) == dict
    assert course['entries'][0]['_type'] == 'url_transparent'

# Generated at 2022-06-24 12:51:02.852359
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.suitable('https://linuxacademy.com/cp/modules/view/id/154')
    assert ie.suitable('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')

# Generated at 2022-06-24 12:51:05.559796
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    IE_LinuxAcademy = LinuxAcademyIE()
    assert isinstance(IE_LinuxAcademy, LinuxAcademyIE)
    assert isinstance(IE_LinuxAcademy, InfoExtractor)


# Generated at 2022-06-24 12:51:07.247660
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try_get(None, lambda x: x['name'])

# Generated at 2022-06-24 12:51:10.942702
# Unit test for constructor of class LinuxAcademyIE

# Generated at 2022-06-24 12:51:22.795873
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-24 12:51:25.382901
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE(LinuxAcademyIE.ie_key())
    except Exception:
        print("Error in constructor of class LinuxAcademyIE")

# Generated at 2022-06-24 12:51:28.680258
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        print(LinuxAcademyIE('linuxacademy', 'linuxacademy.com'))
    except Exception as e:
        print('Caught error: %s' % e.__class__.__name__)

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:51:39.905138
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_downloader import Downloader, UseNetrcOptionDownloader
    from .common import InfoExtractor
    from ..extractor import gen_extractors
    from ..utils import setproctitle
    import sys
    import types
    import unittest
    import warnings
    setproctitle('youtube-dl test script')

    # Prepare some arguments to create an instance of class Downloader
    # However, we will not actually run the Downloader

# Generated at 2022-06-24 12:51:50.461780
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Here we are going to test whether the constructor of the LinuxAcademyIE class raises
    # an exception for invalid URLs and does not raise an exception for valid URLs.
    good_urls = [
        'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    ]
    bad_urls = [
        'https://linuxacademy.com/',
    ]
    for good_url in good_urls:
        print("Testing good url: " + good_url)
        temp = LinuxAcademyIE()
        assert temp._match_id(good_url) is not None
    for bad_url in bad_urls:
        print("Testing bad url: " + bad_url)
        temp = LinuxAcademyIE()
        assert temp._match_id

# Generated at 2022-06-24 12:51:52.159838
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        assert LinuxAcademyIE.ie_key()
    except Exception as err:
        print(err)

# Generated at 2022-06-24 12:51:53.132663
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(InfoExtractor())

# Generated at 2022-06-24 12:52:00.345727
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.IE_NAME == 'LinuxAcademy'
    assert ie.ie._WORKING == True
    assert ie._VALID_URL == ie.VALID_URL # pylint: disable=protected-access
    assert ie._TESTS == ie.TESTS # pylint: disable=protected-access
    assert ie._AUTHORIZE_URL == ie.AUTHORIZE_URL # pylint: disable=protected-access
    assert ie._ORIGIN_URL == ie.ORIGIN_URL # pylint: disable=protected-access
    assert ie._CLIENT_ID == ie.CLIENT_ID # pylint: disable=protected-access

# Generated at 2022-06-24 12:52:02.052450
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE() == 'linuxacademy'

# Generated at 2022-06-24 12:52:06.240536
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test for Windows
    ie = LinuxAcademyIE()
    print(ie)
    # Test for Linux
    LinuxAcademyIE()
    print(ie)

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:52:07.000995
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None)

# Generated at 2022-06-24 12:52:14.188690
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.IE_DESC == 'Linux Academy'
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-24 12:52:25.746331
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
   # Create object of class LinuxAcademyIE
   le = LinuxAcademyIE()

   # Testcase 1
   # Test case for valid input
   le = LinuxAcademyIE()
   assert le._VALID_URL == r'(?x)\b((?:https?://|www\d{0,3}[.]|[a-z0-9.\-]+[.][a-z]{2,4}/)(?:[^\s()<>]+|\(([^\s()<>]+|(\([^\s()<>]+\)))*\))+(?:\(([^\s()<>]+|(\([^\s()<>]+\)))*\)|[^\s`!()\[\]{};:\'".,<>?«»“”‘’]))'
  

# Generated at 2022-06-24 12:52:31.898538
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._NETRC_MACHINE == 'linuxacademy'
    assert LinuxAcademyIE()._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert LinuxAcademyIE()._ORIGIN_URL == 'https://linuxacademy.com'
    assert LinuxAcademyIE()._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'


# Generated at 2022-06-24 12:52:33.210150
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE is not None


# Generated at 2022-06-24 12:52:43.055769
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.__class__.__name__ == 'LinuxAcademyIE'
    assert ie._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'

# Generated at 2022-06-24 12:52:49.405195
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test login with invalid credentials
    with LinuxAcademyIE(username="invalid", password="invalid") as ie:
        ie.login()
        # Test extractor
        ie.extract('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:52:53.053589
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print(LinuxAcademyIE('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'))
    

# Generated at 2022-06-24 12:52:54.215927
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:52:55.360257
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

# Generated at 2022-06-24 12:52:59.061544
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test functionality of class constructor LinuxAcademyIE."""
    ie = LinuxAcademyIE()
    if ie.login_required():
        print("Login required")
    if ie.is_logged():
        print("Logged state")


# Generated at 2022-06-24 12:53:01.095065
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test with login
    ie = LinuxAcademyIE()
    ie.set_login('username', 'password')
    # Test without login
    LinuxAcademyIE()

# Generated at 2022-06-24 12:53:03.588017
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        assert LinuxAcademyIE
    except NameError:
        return
    # get test suite from module
    from .common import getSuite
    from .common import getTestsModule
    from .extractor import YoutubeIE
    import requests
    import sys

    sys.modules['requests'] = requests

    suite = getSuite(getTestsModule(LinuxAcademyIE))
    suite.run()

# Generated at 2022-06-24 12:53:06.548352
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(LinuxAcademyIE.IE_NAME)
    ie.set_downloader(None)
    ie.set_login_info(None, None)
    assert isinstance(ie.suitable(None), list)

# Generated at 2022-06-24 12:53:17.881872
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_ie = LinuxAcademyIE()
    assert linux_academy_ie.IE_NAME == "linuxacademy"
    assert linux_academy_ie.IE_DESC == "Linux Academy"
    assert linux_academy_ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-24 12:53:21.109511
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    access_token = LinuxAcademyIE()
    assert access_token._CLIENT_ID is not None
    assert access_token._NETRC_MACHINE == LinuxAcademyIE._NETRC_MACHINE

# Generated at 2022-06-24 12:53:22.515432
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert(LinuxAcademyIE.ie_key() == 'LinuxAcademy')

# Generated at 2022-06-24 12:53:23.356955
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(1)

# Generated at 2022-06-24 12:53:27.623709
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test constructors for LinuxAcademyIE class."""
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'LinuxAcademy'
    assert ie._VALID_URL == ''
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie._CLIENT_ID == ''
    assert ie._ORIGIN_URL == ''
    assert ie._AUTHORIZE_URL == ''



# Generated at 2022-06-24 12:53:32.553454
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test constructor of class LinuxAcademyIE with correct url
    assert LinuxAcademyIE.suitable('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    # Test constructor with incorrect url
    assert not LinuxAcademyIE.suitable('http://test.test')

# Generated at 2022-06-24 12:53:33.888587
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None)

# Generated at 2022-06-24 12:53:34.522604
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-24 12:53:42.737813
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    global ie
    ie = LinuxAcademyIE()
    global username
    username = input("Please enter your Linux Academy username: ")
    global password
    password = input("Please enter your Linux Academy password: ")
    try:
        test_url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2'
        _, _ = ie._download_webpage(test_url, None)
    except ExtractorError as e:
        if isinstance(e.cause, compat_HTTPError) and e.cause.code == 401:
            print("Please check your username and password!")
        raise

# Generated at 2022-06-24 12:53:46.172437
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Unit test for LinuxAcademyIE
    """
    linux_academy_ie = LinuxAcademyIE()
    assert linux_academy_ie.IE_NAME == "linuxacademy"

# Generated at 2022-06-24 12:53:47.008467
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie is not None

# Generated at 2022-06-24 12:53:52.937519
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE('LinuxAcademy')
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-24 12:53:54.031943
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()


# Generated at 2022-06-24 12:53:55.280355
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:53:56.854167
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.is_logged

# Generated at 2022-06-24 12:53:58.510293
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE().IE_NAME == 'linuxacademy'

# Generated at 2022-06-24 12:54:04.473059
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Ensure that the constructor of class LinuxAcademyIE uses the correct
    # client identifier
    assert hasattr(LinuxAcademyIE, '_CLIENT_ID')
    assert LinuxAcademyIE._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-24 12:54:11.919094
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    '''
    Example of unit test.
    '''
    # Constructor of class LinuxAcademyIE
    #
    # The first input argument is url.
    # The second input argument is ie_key of info extractor.
    # The third input argument is 'video' or 'playlist'
    # The fourth input argument is 'static' or 'dynamic'.
    # The fifth input argument is 'manual' or 'automatic'.
    # The sixth input argument is 'yes' or 'no'.
    la_ie = LinuxAcademyIE('http://www.linuxacademy.com', 'LinuxAcademy', 'video', 'static', 'manual', 'no');

    # Test whether is_suitable() is working properly
    # This is a method of class InfoExtractor
    # The input argument is url.

# Generated at 2022-06-24 12:54:18.122426
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == 'https?://(?:www\\.)?linuxacademy\\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|modules/view/id/(?P<course_id>\\d+))'

# Generated at 2022-06-24 12:54:23.458254
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    extractor = LinuxAcademyIE()
    Test = extractor._TESTS[0]
    result1 = extractor._real_extract(Test['url'])
    result2 = extractor._real_extract(Test['url'])
    assert((result1 is not None) and (result2 is not None))
    assert((result1['id'] == result2['id']) and (result1['formats'] == result2['formats']))

# Generated at 2022-06-24 12:54:33.324208
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademy = LinuxAcademyIE()
    assert linuxacademy._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert linuxacademy._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert linuxacademy._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-24 12:54:37.645460
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_promo_code_ie import PromoCodeIE
    from .test_sapo_ie import SapoIE
    from .test_udemy import UdemyIE
    LinuxAcademyIE()
    PromoCodeIE()
    SapoIE()
    UdemyIE()

# Generated at 2022-06-24 12:54:39.119131
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from ..utils import test_cases

    test_cases(LinuxAcademyIE)

# Generated at 2022-06-24 12:54:41.517939
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE
    except NameError:
        raise AssertionError("Cannot find class LinuxAcademyIE")

# Generated at 2022-06-24 12:54:42.491005
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:54:47.924841
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    la_ie_constructor = LinuxAcademyIE()
    print(la_ie_constructor)
    la_ie_constructor._real_initialize()


'''
Credit: https://github.com/nixxquality/youtube-dl/pull/11881/commits/8413b4d43f30adb1a7b1d7618e19d3cfa55004f3, https://github.com/ytdl-org/youtube-dl/pull/21380
'''

# Generated at 2022-06-24 12:54:50.582655
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
   LinuxAcademyIE()

# Generated at 2022-06-24 12:54:58.188596
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_ie = LinuxAcademyIE()
    assert linux_academy_ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert linux_academy_ie._NETRC_MACHINE == 'linuxacademy'
    assert linux_academy_ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert linux_academy_ie._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-24 12:54:59.482466
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    LinuxAcademyIE(url)

# Generated at 2022-06-24 12:55:05.516820
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_linuxacademy import test_linuxacademy_login

    # Start with login
    test_linuxacademy_login()

    # Continue with testing class LinuxAcademyIE

    # URL for testing.
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    # Instantiate class LinuxAcademyIE
    LinuxAcademyIE()._real_extract(url)

# Generated at 2022-06-24 12:55:08.307946
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    i = LinuxAcademyIE()
    
    # Test request
    result = i._real_initialize()
    
    # Test result
    assert result == None

# Generated at 2022-06-24 12:55:16.021203
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'


# Generated at 2022-06-24 12:55:16.934777
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:55:27.597239
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert instance.IE_NAME == "LinuxAcademy"
    assert instance.IE_DESC == "Linux Academy"
    assert instance._VALID_URL == r'https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'
    assert instance._NETRC_MACHINE == "linuxacademy"
    assert instance._AUTHORIZE_URL == "https://login.linuxacademy.com/authorize"
    assert instance._ORIGIN_URL == "https://linuxacademy.com"


# Generated at 2022-06-24 12:55:30.850714
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """ Test cases for LinuxAcademyIE """

    # Construct an object of class LinuxAcademyIE
    test_obj = LinuxAcademyIE()

    # Verify that the object is instance of the class LinuxAcademyIE
    assert isinstance(test_obj, LinuxAcademyIE)

# Generated at 2022-06-24 12:55:33.579935
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test that LinuxAcademyIE is working."""
    instance = LinuxAcademyIE()
    assert isinstance(instance, LinuxAcademyIE)

# Generated at 2022-06-24 12:55:35.003022
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE(None).IE_NAME == 'linuxacademy'

# Generated at 2022-06-24 12:55:36.078287
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:55:45.521579
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == "https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))"
    assert ie._TESTS[0]['url'] == 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    assert ie._TESTS[1]['url'] == 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'

# Generated at 2022-06-24 12:55:46.612111
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:55:47.503107
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:55:48.469577
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:55:50.108765
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxAcademyIE = LinuxAcademyIE()
    print(linuxAcademyIE)

# Generated at 2022-06-24 12:55:51.281703
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:55:52.678284
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert type(LinuxAcademyIE()).__name__ == "LinuxAcademyIE"

# Generated at 2022-06-24 12:55:56.464023
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == LinuxAcademyIE._VALID_URL
    assert ie._NETRC_MACHINE == LinuxAcademyIE._NETRC_MACHINE

# Generated at 2022-06-24 12:56:06.233154
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-24 12:56:17.056450
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    tmp = instance._download_webpage('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/1', '78')
    tmp = instance._search_regex(r'window\.lesson\s*=\s*({.+?})\s*;', tmp, 'lesson', default='{}')
    tmp = instance._parse_json(tmp, '78')
    tmp = instance._download_webpage('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2', '79')
    tmp = instance._download_webpage('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2', '1499')
    tmp = instance._

# Generated at 2022-06-24 12:56:22.116820
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info=LinuxAcademyIE()
    assert info.IE_NAME == 'linuxacademy'
    assert 'courses' in info.VALID_URL
    assert info.NETRC_MACHINE == 'linuxacademy'
    assert 'login' in info.AUTHORIZE_URL
    assert info.ORIGIN_URL == 'https://linuxacademy.com'
    assert info.CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-24 12:56:27.564157
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():

    # Create a dummy subclass with the given netloc
    class TestLinuxAcademyIE(LinuxAcademyIE):
        _NETLOC = 'x'

    # Test extraction for a url with the given netloc
    ie = TestLinuxAcademyIE()
    assert ie._NETLOC == 'x'
    assert ie._TEST == {
        'url': 'https://x/cp/courses/lesson/course/7971/lesson/2/module/675',
        'only_matching': False,
    }

# Generated at 2022-06-24 12:56:32.309832
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert "LinuxAcademyIE" == LinuxAcademyIE.ie_key()
    assert "linuxacademy.com" == LinuxAcademyIE._VALID_URL
    assert "https://www.linuxacademy.com" == LinuxAcademyIE._ORIGIN_URL

# Generated at 2022-06-24 12:56:42.094157
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Create directory containing login credentials
    from tempfile import mkdtemp
    from shutil import rmtree
    from os.path import join
    from .test_utils import (
        TEST_NETRC_CONTENTS,
        TEST_NETRC_PATH,
        FakeNetrcHelper,
    )
    from ..compat import (
        compat_os_PathLike,
    )
    tempdir = mkdtemp()

# Generated at 2022-06-24 12:56:52.802491
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    This function is used to test the constructor of class LinuxAcademyIE
    :return: None
    """
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    linuxacademyie = LinuxAcademyIE()._real_initialize()
    linuxacademyie._login()
    video = linuxacademyie._real_extract(url)

    print("chapter number: ", video["entries"][0]["chapter_number"])
    print("chapter title: ", video["entries"][0]["chapter"])
    print("chapter id: ", video["entries"][0]["chapter_id"])
    print()
    print("title: ", video["entries"][0]["title"])


# Generated at 2022-06-24 12:56:57.332414
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    user_agent = instance._USER_AGENT
    if user_agent.startswith('Wget/'):
        assert user_agent[len('Wget/'):].startswith(instance.VERSION)
    else:
        assert user_agent.startswith(instance.IE_NAME)

# Generated at 2022-06-24 12:57:03.381660
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from . import LinuxAcademyIE
    from . import ExtractorError
    from . import compat_HTTPError
    import json
    import pytest
    import sys
    if sys.version_info < (3, 0):
        from HTMLParser import HTMLParser
        compat_unescape = HTMLParser().unescape
    else:
        import html
        compat_unescape = html.unescape
    import re
    import urllib2
    from .compat import parse_duration
    from .common import InfoExtractor
    from .compat import (
        compat_b64decode,
        compat_HTTPError,
        compat_str,
        compat_urllib_error,
    )

# Generated at 2022-06-24 12:57:14.730098
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.server_address() == 'https://login.linuxacademy.com'

    # _AUTHORIZE_URL is not missing
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'

    # _ORIGIN_URL is not missing
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'

    # _CLIENT_ID is not missing
    assert ie._CLIENT_ID == "KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx"

    # _NETRC_MACHINE is not missing

# Generated at 2022-06-24 12:57:22.693015
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    class_ = LinuxAcademyIE
    username, password = class_._get_login_info()
    ie = class_(username=username, password=password)
    assert ie.username == username
    assert ie.password == password
    assert ie._client_id == class_._CLIENT_ID
    assert ie._origin_url == class_._ORIGIN_URL
    assert ie._netrc_machine == class_._NETRC_MACHINE
    assert ie._authorize_url == class_._AUTHORIZE_URL

# Generated at 2022-06-24 12:57:25.111003
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    IE = LinuxAcademyIE()
    IE._login()
    IE._real_extract("https://linuxacademy.com/cp/modules/view/id/154")

# Generated at 2022-06-24 12:57:25.655311
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

# Generated at 2022-06-24 12:57:26.573199
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()

# Generated at 2022-06-24 12:57:30.941471
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():

    testUrl = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    submoduleId = '7971-2'
    testId = LinuxAcademyIE.extract_submodule_id(testUrl)
    assert submoduleId == testId