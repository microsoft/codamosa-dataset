

# Generated at 2022-06-24 12:47:31.619350
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE

# Generated at 2022-06-24 12:47:33.202314
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.login_info is None

# Generated at 2022-06-24 12:47:34.275588
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print (LinuxAcademyIE)

# Generated at 2022-06-24 12:47:38.825708
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    _login_info = {'username': 'username', 'password': 'password123'}
    _downloader = None
    _ie = LinuxAcademyIE(_login_info, _downloader)
    _authenticate = False
    assert _authenticate == _ie._login()

# Generated at 2022-06-24 12:47:43.629969
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test LinuxAcademyIE extracts
    ie = LinuxAcademyIE()
    # Linux Academy course URL
    course_url = 'https://linuxacademy.com/cp/modules/view/id/154'
    # Linux Academy course data

# Generated at 2022-06-24 12:47:54.550892
# Unit test for constructor of class LinuxAcademyIE

# Generated at 2022-06-24 12:47:55.206022
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    return

# Generated at 2022-06-24 12:47:58.486080
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.IE_NAME == 'LinuxAcademy'
    # check if the _NETRC_MACHINE matches the class name
    assert ie._NETRC_MACHINE == ie.IE_NAME

# Generated at 2022-06-24 12:48:03.870127
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('https://linuxacademy.com/cp/modules/view/id/154')

LinuxAcademyIE({
    'class': LinuxAcademyIE,
    'add_ie': ['Azure'],
})('https://linuxacademy.com/cp/modules/view/id/154')


# Generated at 2022-06-24 12:48:04.901059
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:48:05.936482
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert instance

# Generated at 2022-06-24 12:48:07.266373
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:48:10.914485
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._NETRC_MACHINE == 'linuxacademy'
    assert LinuxAcademyIE().ie_key() == 'LinuxAcademy'
    assert LinuxAcademyIE._VALID_URL.match('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    assert LinuxAcademyIE._VALID_URL.match('https://linuxacademy.com/cp/modules/view/id/154')


# Generated at 2022-06-24 12:48:18.869152
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print("Testing constructor of class LinuxAcademyIE")
    # Should raise an exception if no URL provided
    try:
        la = LinuxAcademyIE()
        raise AssertionError("ValueError not raised")
    except ValueError as e:
        print(e)

    # Should raise an exception if invalid URL provided
    try:
        la = LinuxAcademyIE("https://w3schools.com")
        raise AssertionError("ExtractorError not raised")
    except ExtractorError as e:
        print(e)

    # Should raise an exception if non-playlist URL provided

# Generated at 2022-06-24 12:48:20.054592
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from . import linuxacademy
    ie = linuxacademy.LinuxAcademyIE()

# Generated at 2022-06-24 12:48:22.278271
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    IE = LinuxAcademyIE()
    assert IE
    assert IE.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:48:23.659125
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Ensure that we can pass the constructor without arguments
    LinuxAcademyIE()

# Generated at 2022-06-24 12:48:26.065627
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info_extractor_test_module('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675', None)

# Generated at 2022-06-24 12:48:29.443408
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE(None)

    assert obj._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert obj._ORIGIN_URL == 'https://linuxacademy.com'
    assert obj._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert obj._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:48:37.239384
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert isinstance(LinuxAcademyIE.suitable('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'),
                      list)
    assert LinuxAcademyIE.suitable('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2') != []
    assert LinuxAcademyIE.suitable('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2') == []

# Generated at 2022-06-24 12:48:41.443996
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Test cases for instantiating objects of class LinuxAcademyIE
    """

    # Test with valid arguments
    try:
        LinuxAcademyIE('linuxacademy', 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx')
    except Exception:
        assert False

    # Test with invalid arguments
    try:
        LinuxAcademyIE('linuxacademy')
    except Exception:
        assert True

    # Test with invalid arguments
    try:
        LinuxAcademyIE('linuxacademy', 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx', 'linuxacademy')
    except Exception:
        assert True


# Generated at 2022-06-24 12:48:48.383271
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:48:49.643617
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()



# Generated at 2022-06-24 12:48:50.857474
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()

# Generated at 2022-06-24 12:48:52.347106
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert obj != None

# Generated at 2022-06-24 12:48:54.252823
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    class_ = LinuxAcademyIE
    assert issubclass(class_, InfoExtractor)



# Generated at 2022-06-24 12:48:59.683292
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print("testLinuxAcademyIE")
    print("Testing LinuxAcademyIE constructor")
    test_url = "https://linuxacademy.com/cp/modules/view/id/154"
    ie = LinuxAcademyIE()
    ie.url = test_url
    assert ie.url == test_url


# Generated at 2022-06-24 12:49:05.046722
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # For constructor testing, I need to make sure that my LinuxAcademyIE object is valid.
    # My object should be an instance of InfoExtractor.
    
    # Create new LinuxAcademyIE object. Call this object LinuxAcademy
    LinuxAcademy = LinuxAcademyIE()

    # Make assertion that LinuxAcademy is an instance of InfoExtractor
    assert isinstance(LinuxAcademy, InfoExtractor)


# Generated at 2022-06-24 12:49:10.362396
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print("Unit test for constructor of class LinuxAcademyIE")
    print("\tConstructor => LinuxAcademyIE()")
    print("\tConstructor => LinuxAcademyIE(None)")
    print("\tConstructor => LinuxAcademyIE(object)")
    LinuxAcademyIE()
    LinuxAcademyIE(None)
    LinuxAcademyIE(object)


# Generated at 2022-06-24 12:49:16.166688
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    '''
    Test LinuxAcademyIE:
    '''
    # Test for class LinuxAcademyIE
    if os.path.isfile('.config'):
        import configparser
        config = configparser.ConfigParser()
        config.read('.config')
        config.sections()
        os.environ['linux_academy_username'] = config['Linux Academy']['username']
        os.environ['linux_academy_password'] = config['Linux Academy']['password']
    _ = LinuxAcademyIE(None)

# Generated at 2022-06-24 12:49:20.077408
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_linuxacademyie = LinuxAcademyIE()
    test_linuxacademyie.extract_info_from_url('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')

# Generated at 2022-06-24 12:49:21.960351
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Test creating an instance of LinuxAcademyIE
    """
    LinuxAcademyIE()

# Generated at 2022-06-24 12:49:29.909715
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE('LinuxAcademy')._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert LinuxAcademyIE('LinuxAcademy')._ORIGIN_URL == 'https://linuxacademy.com'
    assert LinuxAcademyIE('LinuxAcademy')._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert LinuxAcademyIE('LinuxAcademy')._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:49:31.505951
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()._login()
    except ExtractorError:
        pass

# Generated at 2022-06-24 12:49:32.305543
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:49:38.493273
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'

# Generated at 2022-06-24 12:49:41.353072
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    l = LinuxAcademyIE("https://linuxacademy.com/cp/modules/view/id/154")
    assert (l.ie_key()=='LinuxAcademy')

# Generated at 2022-06-24 12:49:49.187445
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_obj = LinuxAcademyIE()
    assert test_obj._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert test_obj._ORIGIN_URL == 'https://linuxacademy.com'
    assert test_obj._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert test_obj._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:49:50.313448
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(object)

# Generated at 2022-06-24 12:49:51.471270
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('username', 'password', False)

# Generated at 2022-06-24 12:49:52.537379
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()


# Generated at 2022-06-24 12:50:03.679634
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_url = 'https://linuxacademy.com/cp/modules/view/id/154'
    example_url = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    try:
        # linuxacademy account credentials needed
        LinuxAcademyIE()._login()
    except ExtractorError as e:
        if e.args[0].startswith('Linux Academy said'):
            raise ExtractorError('%s said: %s' % (LinuxAcademyIE.ie_key(), e.args[0].split(': ', 1)[1]), expected=True)
        raise

    LinuxAcademyIE()._real_extract(example_url)
    LinuxAcademyIE()._real_extract(test_url)

# Generated at 2022-06-24 12:50:04.489908
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    inf = LinuxAcademyIE()
    assert inf


# Generated at 2022-06-24 12:50:11.489612
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info_extractor = LinuxAcademyIE()
    assert info_extractor._VALID_URL == '^https?://' + \
           r'(?:www\.)?linuxacademy\.com/cp/' + \
           r'(?:' + \
           r'courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)' + \
           r'|' + \
           r'modules/view/id/(?P<course_id>\d+)' + \
           r')'

# Generated at 2022-06-24 12:50:22.324211
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.login_url == "https://login.linuxacademy.com/authorize"
    assert ie.login_state_url == "https://linuxacademy.com/cp/login/tokenValidateLogin/token/%s"
    assert ie.authorize_url == "https://login.linuxacademy.com/login/callback"
    assert ie.playlist_url == "https://linuxacademy.com/cp/modules/view/id/%s"
    assert ie.course_url == "https://linuxacademy.com/cp/courses/lesson/course/%s/lesson/%s/module/%s"

# Generated at 2022-06-24 12:50:23.731284
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test instantiation
    inst = LinuxAcademyIE()
    assert inst is not None

# Generated at 2022-06-24 12:50:24.823183
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('example')

# Generated at 2022-06-24 12:50:35.548162
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == \
           r'https?://(?:www\.)?linuxacademy\.com/cp/' \
           r'(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|' \
           r'modules/view/id/(?P<course_id>\d+))'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie

# Generated at 2022-06-24 12:50:38.973834
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.suitable(ie.url_result('https://www.linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'))

# Generated at 2022-06-24 12:50:47.833572
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-24 12:50:51.981947
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Initialize object of LinuxAcademyIE class
    from .common import InfoExtractor
    LinuxAcademyIE = InfoExtractor._create_ie('LinuxAcademy', 'linuxacademy')
    test_LinuxAcademyIE = LinuxAcademyIE(None)

# Generated at 2022-06-24 12:51:02.223877
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.IE_DESC == 'Linux Academy'
    assert ie._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-24 12:51:13.253929
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():

    # Test LinuxAcademyIE._get_login_info to get information from a netrc file
    assert LinuxAcademyIE._get_login_info() == ('u', 'p')

    # Test LinuxAcademyIE._real_initialize to make sure the login process is not changed
    test_login = LinuxAcademyIE()
    test_login._login = lambda: True
    test_login._real_initialize()

    # Test LinuxAcademyIE._real_extract for a lecture file
    lecture = LinuxAcademyIE()
    test_lecture = lecture._real_extract('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    assert test_lecture['id'] == '7971-2'

# Generated at 2022-06-24 12:51:24.623047
# Unit test for constructor of class LinuxAcademyIE

# Generated at 2022-06-24 12:51:30.959496
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:51:33.890976
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    TestClass = LinuxAcademyIE
    expected_result = TestClass
    assert TestClass is expected_result



# Generated at 2022-06-24 12:51:34.528543
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()


# Generated at 2022-06-24 12:51:36.427531
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert isinstance(instance, LinuxAcademyIE)

# Generated at 2022-06-24 12:51:37.830896
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:51:48.286444
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    filename = 'test_LinuxAcademy'
    # test valid url
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    test_LinuxAcademy = LinuxAcademyIE()
    result = test_LinuxAcademy._real_extract(url)
    assert isinstance(result, dict)
    assert 'entries' in result.keys()
    assert isinstance(result['entries'], list)
    assert '_type' in result.keys()
    assert result['_type'] == 'playlist'
    assert 'id' in result.keys()
    assert 'title' in result.keys()
    assert result['title'] == 'AWS Certified Cloud Practitioner'
    assert 'description' in result.keys()

# Generated at 2022-06-24 12:51:50.461215
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    print (instance)
    assert(isinstance(instance, LinuxAcademyIE))


# Generated at 2022-06-24 12:51:51.191002
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:51:51.799503
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-24 12:51:57.676858
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    inputs = ['8WwHjFvVmAQ2AOZu', '3b9a0a7c5d6d5da8']
    outputs = ['8WwHjFvVmAQ2AOZu', '3b9a0a7c5d6d5da8']
    assert(len(inputs) == len(outputs))
    for i in range(len(inputs)):
        assert(ie._hidden_inputs(inputs[i]) == outputs[i])

# Generated at 2022-06-24 12:52:08.238737
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE("https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675")
    test_cases = [
        (ie.extract, 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'),
        (ie.extract, 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'),
        (ie.extract, 'https://linuxacademy.com/cp/modules/view/id/154'),
    ]
    for tester, url in test_cases:
        with pytest.raises(IE_DESC):
            tester(url)

# Generated at 2022-06-24 12:52:09.620809
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert isinstance(obj, LinuxAcademyIE)

# Generated at 2022-06-24 12:52:16.563395
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'
    assert hasattr(ie, '_real_initialize')
    assert hasattr(ie, '_real_extract')
    assert hasattr(ie, '_login')
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_TESTS')
    assert hasattr(ie, '_AUTHORIZE_URL')
    assert hasattr(ie, '_ORIGIN_URL')
    assert hasattr(ie, '_CLIENT_ID')
    assert hasattr(ie, '_NETRC_MACHINE')
    assert callable(ie._real_initialize)

# Generated at 2022-06-24 12:52:19.657067
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
    except Exception as e:
        assert e.args[0] == "Can't extract without a Linux Academy account"
        return

# Generated at 2022-06-24 12:52:30.326742
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-24 12:52:31.333008
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:52:39.155259
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test LinuxAcademyIE instantiation with no authinfo
    ie = LinuxAcademyIE()
    assert ie.username is None
    assert ie.password is None
    assert ie._login_token is None
    assert ie._access_token is None

    # Test LinuxAcademyIE instantiation with username, password
    ie = LinuxAcademyIE(username="foo", password="bar")
    assert ie.username == "foo"
    assert ie.password == "bar"
    assert ie._login_token is None
    assert ie._access_token is None

    # Test LinuxAcademyIE instantiation with username, password and login_token
    ie = LinuxAcademyIE(username="foo", password="bar", login_token="baz")
    assert ie.username == "foo"
    assert ie.password == "bar"
   

# Generated at 2022-06-24 12:52:43.552575
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    IE_NAME = LinuxAcademyIE.ie_key()
    def get_extractor(login):
        class MyLinuxAcademyIE(LinuxAcademyIE):
            def _real_initialize(this):
                this._login = login
        return MyLinuxAcademyIE
    ie = get_extractor(lambda *args, **kwargs: None)()

# Generated at 2022-06-24 12:52:55.522064
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert instance._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-24 12:52:56.407633
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_LinuxAcademyIE = LinuxAcademyIE()

# Generated at 2022-06-24 12:52:57.814754
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test constructor of LinuxAcademyIE"""
    la = LinuxAcademyIE()

# Generated at 2022-06-24 12:52:58.607401
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()._login()

# Generated at 2022-06-24 12:53:00.825165
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'linuxacademy:course'
    assert LinuxAcademyIE.ie_key() == LinuxAcademyIE.ie_key() # It must be a static object

# Generated at 2022-06-24 12:53:04.254726
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Test the Linux Academy constructor
    """
    # Check expected IE name
    assert LinuxAcademyIE.ie_key() == 'linuxacademy'
    # Check expected name
    ie = LinuxAcademyIE(LinuxAcademyIE.ie_key())
    assert ie.name == 'linuxacademy'

# Generated at 2022-06-24 12:53:05.157224
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:53:06.081250
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert linuxacademyIE()

# Generated at 2022-06-24 12:53:07.255389
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()._real_initialize()

# Generated at 2022-06-24 12:53:18.585540
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import os
    import unittest
    import shutil
    import tempfile

    class TestLinuxAcademyIE(unittest.TestCase):

        def setUp(self):
            self.test_folder = tempfile.mkdtemp()
            self.username = os.environ.get('LINUX_ACADEMY_USERNAME')
            self.password = os.environ.get('LINUX_ACADEMY_PASSWORD')
            self.url = 'https://linuxacademy.com/cp/modules/view/id/154'
            self.ie = None
            if self.username and self.password:
                self.ie = LinuxAcademyIE(
                    downloader=None,
                    download_directory=self.test_folder)


# Generated at 2022-06-24 12:53:20.212430
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)

# Generated at 2022-06-24 12:53:23.991798
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-24 12:53:34.280551
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE().IE_NAME == 'linuxacademy'
    assert LinuxAcademyIE()._VALID_URL == r'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'

# Generated at 2022-06-24 12:53:36.597092
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    lainstance = LinuxAcademyIE(test_LinuxAcademyIE)
    lainstance.suitable(url)

# Generated at 2022-06-24 12:53:38.130896
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    t = LinuxAcademyIE(None)
    assert t.__class__ == LinuxAcademyIE

# Generated at 2022-06-24 12:53:49.639908
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'linuxacademy'
    assert LinuxAcademyIE._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'
    assert LinuxAcademyIE._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert LinuxAcademyIE._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-24 12:54:02.074550
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_ie = LinuxAcademyIE()
    assert test_ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert test_ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert test_ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert test_ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:54:05.408805
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('LinuxAcademyIE', 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')

# Generated at 2022-06-24 12:54:08.000476
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-24 12:54:08.928331
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()

# Generated at 2022-06-24 12:54:20.537748
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    #
    # Unit test for constructor of class LoginInfoExtractor.
    #
    # The test case should be run with the following command line:
    #    python -m test_linuxacademy
    #
    # The test case will be successful if the output of the above
    # command is:
    #    login info: {'username': 'john_doe', 'password': 'swordfish'}
    #
    import io
    import logging
    import os
    import sys
    import unittest
    from unittest import mock

    with mock.patch.dict(os.environ, {'USER': 'john_doe'}):
        sys.stderr = sys.stdout = io.StringIO()
        logging.basicConfig(stream=sys.stderr, level=logging.DEBUG)

# Generated at 2022-06-24 12:54:31.467673
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Method: _login
    # Scenario: client_id does not match
    # Expected: client_id does not match
    assert_raises(ExtractorError,
                  LinuxAcademyIE._build_login_request,
                  '', LinuxAcademyIE._AUTHORIZE_URL,
                  LinuxAcademyIE._ORIGIN_URL, 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx',
                  'Username-Password-Authentication',
                  )

    # Method: _login
    # Scenario: Redirect_uri does not match
    # Expected: Redirect_uri does not match

# Generated at 2022-06-24 12:54:32.594031
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE() != None

# Generated at 2022-06-24 12:54:36.499525
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test constructor of class LinuxAcademyIE"""
    # Get the instance of class LinuxAcademyIE
    test_instance = LinuxAcademyIE()
    # Test the instance of class LinuxAcademyIE
    assert isinstance(test_instance, LinuxAcademyIE)

# Generated at 2022-06-24 12:54:38.392610
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:54:40.690868
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
        assert False
    except ExtractorError as e:
        assert 'Requires login' in str(e)

# Generated at 2022-06-24 12:54:42.217766
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(InfoExtractor)


# Generated at 2022-06-24 12:54:46.536165
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert re.match(LinuxAcademyIE._VALID_URL, 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    assert re.match(LinuxAcademyIE._VALID_URL, 'https://linuxacademy.com/cp/modules/view/id/154')

# Generated at 2022-06-24 12:54:47.380902
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

# Generated at 2022-06-24 12:54:53.524062
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.IE_DESC == 'Linux Academy'
    assert ie.VALID_URL
    assert ie._VALID_URL == ie.VALID_URL
    ie = LinuxAcademyIE(ie)
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.IE_DESC == 'Linux Academy'
    assert ie.VALID_URL
    assert ie._VALID_URL == ie.VALID_URL
    ie = LinuxAcademyIE(ie=ie)
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.IE_DESC == 'Linux Academy'
    assert ie.VALID_URL
    assert ie._VALID_URL == ie.VALID_URL
   

# Generated at 2022-06-24 12:54:54.513367
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

# Generated at 2022-06-24 12:54:55.641095
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()



# Generated at 2022-06-24 12:54:57.425276
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
        assert True
    except:
        assert False

# Generated at 2022-06-24 12:54:58.728735
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # default
    LinuxAcademyIE()    
    

# Generated at 2022-06-24 12:55:00.631484
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():

    # Test to check creation of a object
    ie = LinuxAcademyIE()
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-24 12:55:12.812286
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Check the constructor of class LinuxAcademyIE.
    """
    # Mock the static method _login

# Generated at 2022-06-24 12:55:13.810773
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()

# Generated at 2022-06-24 12:55:23.316945
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|modules/view/id/(?P<course_id>\\d+))'
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'

# Generated at 2022-06-24 12:55:24.448141
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:55:32.279419
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info_extractor = LinuxAcademyIE('test')
    assert info_extractor._VALID_URL == \
        r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert info_extractor._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert info_extractor._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-24 12:55:37.288126
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(
        None,
        'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
        {},
        'linuxacademy',
        'p4ssw0rd',
    )
    ie.initialize()
    assert ie

# Generated at 2022-06-24 12:55:38.674173
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_ie_object = LinuxAcademyIE()
    assert test_ie_object is not None

# Generated at 2022-06-24 12:55:40.720562
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(None)
    ie = LinuxAcademyIE({'username': '', 'password': ''})

# Generated at 2022-06-24 12:55:41.456444
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None)

# Generated at 2022-06-24 12:55:43.411607
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # test case 1 - no parameter passed
    LinuxAcademyIE()

    # test case 2 - empty parameter passed
    LinuxAcademyIE({})

# Generated at 2022-06-24 12:55:46.429452
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Unit test for constructor of class LinuxAcademyIE
    """
    ie = LinuxAcademyIE()
    assert ie._NETRC_MACHINE == 'linuxacademy'


# Generated at 2022-06-24 12:55:54.544159
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert(LinuxAcademyIE.IE_NAME == 'linuxacademy')
    assert(LinuxAcademyIE.IE_DESC == 'Linux Academy')
    assert(LinuxAcademyIE.__name__ == 'LinuxAcademyIE')
    assert(LinuxAcademyIE.VALID_URL == LinuxAcademyIE._VALID_URL)
    assert(LinuxAcademyIE.TEST == LinuxAcademyIE._TESTS)
    ie_linuxacademy = LinuxAcademyIE(None)
    assert(ie_linuxacademy.IE_NAME == 'linuxacademy')
    assert(ie_linuxacademy.IE_DESC == 'Linux Academy')
    assert(ie_linuxacademy.__name__ == 'LinuxAcademyIE')

# Generated at 2022-06-24 12:55:58.055785
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie_key = LinuxAcademyIE.ie_key()
    ie = LinuxAcademyIE()
    assert ie_key == ie.ie_key()
    assert ie_key in ie._ies

# Generated at 2022-06-24 12:56:00.119065
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj_LinuxAcademyIE = LinuxAcademyIE()
    assert obj_LinuxAcademyIE is not None

# Generated at 2022-06-24 12:56:02.508651
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # testing constructor of class LinuxAcademyIE
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'

# Generated at 2022-06-24 12:56:04.818384
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # TODO: You can create mock for this unit test.
    raise Exception('You must write your own mock for this unit test.')

# Generated at 2022-06-24 12:56:12.045795
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Values for `url` param are from tests data
    for url in ('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
                'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2',
                'https://linuxacademy.com/cp/modules/view/id/154'):
        LinuxAcademyIE().suitable(url) is True

# Generated at 2022-06-24 12:56:16.299061
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    ie = LinuxAcademyIE()
    ie._real_initialize()
    ie._real_extract(url)
    assert ie != None

# Generated at 2022-06-24 12:56:23.122618
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    class_ = LinuxAcademyIE
    assert class_.ie_key() == 'LinuxAcademy'
    assert class_.ie_key() == 'LinuxAcademy'
    assert class_.ie_key() == 'LinuxAcademy'
    assert class_.ie_key() == 'LinuxAcademy'
    assert class_.ie_key() == 'LinuxAcademy'
    instance = class_()
    assert instance.SUCCESS

# Generated at 2022-06-24 12:56:24.769388
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert(LinuxAcademyIE.ie_key() == 'LinuxAcademy')

test_LinuxAcademyIE()

# Generated at 2022-06-24 12:56:26.319567
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE._match_id(LinuxAcademyIE._VALID_URL)

# Generated at 2022-06-24 12:56:28.201837
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()._login()

# Generated at 2022-06-24 12:56:33.394883
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """test_LinuxAcademyIE"""
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    la = LinuxAcademyIE()._login(url)
    print(la)
    return 0

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:56:34.633230
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE


# Generated at 2022-06-24 12:56:36.151759
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:56:40.992564
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = LinuxAcademyIE._VALID_URL.replace("(?P<", "(")
    mobj = re.match(url, "https://www.linuxacademy.com/cp/courses/lesson/course/7971/lesson/2")
    assert mobj.group("chapter_id") == "7971"
    assert mobj.group("lesson_id") == "2"

# Generated at 2022-06-24 12:56:45.356867
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import unittest
    ie = LinuxAcademyIE()
    url = ie.extract_url("https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2")
    print(url)
# test_LinuxAcademyIE()

# Generated at 2022-06-24 12:56:48.637596
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    if not LinuxAcademyIE.suitable('https://linuxacademy.com/cp/modules/view/id/154'):
        raise Exception('Test failure of constructor of class LinuxAcademyIE')

# Generated at 2022-06-24 12:56:50.303895
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    obj._login()

# Generated at 2022-06-24 12:56:51.341820
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:56:57.421262
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE('LinuxAcademy')
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-24 12:56:58.133750
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(dict())

# Generated at 2022-06-24 12:57:00.339960
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # LinuxAcademyIE is a wrapper that configures the class to use a specified
    # extractor, so no test is needed
    assert(not LinuxAcademyIE)

# Generated at 2022-06-24 12:57:01.756276
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    res = LinuxAcademyIE()
    assert res.ie_key() == 'LinuxAcademy'


# Generated at 2022-06-24 12:57:02.555782
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE("")

# Generated at 2022-06-24 12:57:04.048945
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert type(ie) == LinuxAcademyIE

# Generated at 2022-06-24 12:57:15.260562
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'Linux Academy'
    assert ie.ANNOUNCEMENT_URL == 'https://linuxacademy.com/announcement'
    assert LinuxAcademyIE._VALID_URL == LinuxAcademyIE.VALID_URL
    assert LinuxAcademyIE._TESTS == LinuxAcademyIE.TESTS
    assert LinuxAcademyIE._AUTHORIZE_URL == LinuxAcademyIE.AUTHORIZE_URL
    assert LinuxAcademyIE._ORIGIN_URL == LinuxAcademyIE.ORIGIN_URL
    assert LinuxAcademyIE._CLIENT_ID == LinuxAcademyIE.CLIENT_ID
    assert LinuxAcademyIE._NETRC_MACHINE == LinuxAcademyIE.NETRC_MACH

# Generated at 2022-06-24 12:57:17.036279
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    instance._real_initialize()
    instance._real_initialize()

# Generated at 2022-06-24 12:57:24.891991
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE._VALID_URL == LinuxAcademyIE._VALID_URL
    assert LinuxAcademyIE._AUTHORIZE_URL == LinuxAcademyIE._AUTHORIZE_URL
    assert LinuxAcademyIE._ORIGIN_URL == LinuxAcademyIE._ORIGIN_URL
    assert LinuxAcademyIE._CLIENT_ID == LinuxAcademyIE._CLIENT_ID
    assert LinuxAcademyIE._NETRC_MACHINE == LinuxAcademyIE._NETRC_MACHINE


# Generated at 2022-06-24 12:57:36.143212
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    init_data = '{"private_info":{"private_urls":["https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2","https://linuxacademy.com/cp/modules/view/id/415","https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2"],"private_data":{"username": "Your email address","password":"Your password"}}}'
    iface = LinuxAcademyIE(init_data)
    assert iface.ie_key() == 'linuxacademy'
    assert iface.ie_name() == 'LinuxAcademy'
    assert iface.ie_id() == 'linuxAcademy'
    assert iface.ie_shortname() == 'LA'