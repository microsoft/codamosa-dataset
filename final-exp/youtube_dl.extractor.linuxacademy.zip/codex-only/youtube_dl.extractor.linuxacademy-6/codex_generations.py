

# Generated at 2022-06-24 12:47:30.166045
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE.ie_key()
    assert obj.__class__.__name__ == "type"
    assert obj.__name__ == "LinuxAcademyIE"

# Generated at 2022-06-24 12:47:35.203442
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print("Testing class LinuxAcademyIE...")
    LinuxAcademyIE(None)._real_initialize()
    print("Class LinuxAcademyIE tested.")

# Test for LinuxAcademyIE()
if __name__ == "__main__":
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:47:46.005695
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Cover when login fails
    class TestLinuxAcademyIE(LinuxAcademyIE):
        def _real_initialize(self):
            self.login_fail = True

        def _login(self):
            if self.login_fail:
                raise ExtractorError(
                    '%s said: Login error' % self.IE_NAME, expected=True)

    TestLinuxAcademyIE('linuxacademy')._login()

    # Cover when login succeeds
    class TestLinuxAcademyIE(LinuxAcademyIE):
        def _real_initialize(self):
            self.login_succeed = True

        def _login(self):
            if self.login_succeed:
                return

    TestLinuxAcademyIE('linuxacademy')._login()

# Generated at 2022-06-24 12:47:50.461124
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    class TempArgs():
        def __init__(self):
            self.username = 'duis'
            self.password = 'ultrices'
    args = TempArgs()
    LinuxAcademyIE._login(object(), args)
    assert args.username == 'duis'
    assert args.password == 'ultrices'

# Generated at 2022-06-24 12:47:53.292608
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        lai = LinuxAcademyIE()
        lai._login()
    except compat_HTTPError as e:
        print(e)

# Generated at 2022-06-24 12:47:56.760225
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Constructor test
    """
    ie = LinuxAcademyIE()
    # Currently no public video to test
    ie.extract('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')

# Generated at 2022-06-24 12:48:00.478137
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Positive test case
    try:
        LinuxAcademyIE
    except NameError:
        # expected if LinuxAcademyIE is not defined
        assert False
    # Negative test case
    try:
        LinuxAcademyI
    except NameError:
        # expected if LinuxAcademyI is not defined
        assert True

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:48:05.199028
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()._real_extract('https://linuxacademy.com/cp/modules/view/id/154')
    assert ie['id'] == '154'
    assert ie['_type'] == 'playlist'
    assert ie['title'] == 'AWS Certified Cloud Practitioner'
    assert ie['description']

# Generated at 2022-06-24 12:48:06.648029
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Check object creation
    LinuxAcademyIE('LinuxAcademyIE')

# Generated at 2022-06-24 12:48:14.663505
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_object = LinuxAcademyIE()
    assert test_object
    assert test_object.ie_key() == 'LinuxAcademy'
    assert test_object._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert test_object._ORIGIN_URL == 'https://linuxacademy.com'
    assert test_object._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert test_object._NETRC_MACHINE == 'linuxacademy'


# Generated at 2022-06-24 12:48:21.341669
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test for case when video does not exist
    video_url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/99/module/675'
    try:
        LinuxAcademyIE()._real_extract(video_url)
        assert (False), "Exception expected"
    except Exception as e:
        assert (isinstance(e, ExtractorError) and 'Linux Academy said: The lesson you requested was not found.' in e.message), "Exception not working"
    # Test for case when video exists
    video_url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    LinuxAcademyIE()._real_extract(video_url)

# Generated at 2022-06-24 12:48:22.383430
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:48:23.373777
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE

# Generated at 2022-06-24 12:48:30.943156
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    module_name = 'test_LinuxAcademyIE'
    description = 'This is a test class!'
    author = 'Desire_D'
    title = 'Linux Academy'

    # Instantiating LinuxAcademyIE
    obj = LinuxAcademyIE()

    # Checking for class variables
    assert obj._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert obj._NETRC_MACHINE == 'linuxacademy'
    assert obj._

# Generated at 2022-06-24 12:48:32.594375
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # assert LinuxAcademyIE._VALID_URL
    assert LinuxAcademyIE._TESTS

# Generated at 2022-06-24 12:48:34.319434
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'LinuxAcademy'

# Generated at 2022-06-24 12:48:44.085359
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.IE_DESC == 'Linux Academy'
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_

# Generated at 2022-06-24 12:48:45.600298
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert(LinuxAcademyIE.ie_key() == 'LinuxAcademy')

# Generated at 2022-06-24 12:48:57.591115
# Unit test for constructor of class LinuxAcademyIE

# Generated at 2022-06-24 12:49:01.799055
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    global LinuxAcademyIE
    # Test the constructors and initialize
    LinuxAcademyIE('testlinuxacademyobject')
    # Test _real_initialize
    test_ie = LinuxAcademyIE('testlinuxacademyobject')
    test_ie._initialize()
    # Test _login
    test_ie._login()

# Generated at 2022-06-24 12:49:05.792616
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    test_instance = LinuxAcademyIE(url)
    print('test_instance: ' + test_instance)
    assert(test_instance)


# Generated at 2022-06-24 12:49:08.796359
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    path = 'test/linuxacademy.mp4'
    module = LinuxAcademyIE.__new__(LinuxAcademyIE)
    module._real_initialize()
    module._download_webpage(path)

# Generated at 2022-06-24 12:49:09.826769
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:49:10.543045
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None)

# Generated at 2022-06-24 12:49:13.343563
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # An error is raised when create an object of class LinuxAcademyIE
    # because of credentials (username and password) to login is not given
    ie = LinuxAcademyIE()
    assert ie


# Generated at 2022-06-24 12:49:18.427313
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE().IE_NAME == "linuxacademy"
    assert LinuxAcademyIE().IE_DESC == "Linux Academy"
    assert LinuxAcademyIE()._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''


# Generated at 2022-06-24 12:49:19.467599
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:49:28.664999
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .. import LinuxAcademyIE
    from .. const import LABEL_PROG_RE, LABEL_PROG_IE
    from ..const import LABEL_PROG_PROVIDER

    # Test the private instance method _login of the class LinuxAcademyIE
    def test_LinuxAcademyIE_login():
        ie = LinuxAcademyIE(LABEL_PROG_RE, LABEL_PROG_IE, LABEL_PROG_PROVIDER, 'LinuxAcademy')
        # Test to execute _login without login credentials
        ie._login()
        # Test to execute _login with existing login credentials
        ie._real_initialize()

# Generated at 2022-06-24 12:49:33.035203
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie._VALID_URL, str)
    assert isinstance(ie._TESTS, list)
    assert isinstance(ie._AUTHORIZE_URL, str)
    assert isinstance(ie._ORIGIN_URL, str)
    assert isinstance(ie._CLIENT_ID, str)
    assert isinstance(ie._NETRC_MACHINE, str)

# Generated at 2022-06-24 12:49:37.056391
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    options = {
        'username': 'username',
        'password': 'password',
    }
    IE = LinuxAcademyIE(options)
    actual = IE.username
    expected = 'username'
    assert actual == expected
    actual = IE.password
    expected = 'password'
    assert actual == expected


# Generated at 2022-06-24 12:49:39.104400
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademy = LinuxAcademyIE()
    linuxacademy._real_initialize()

# Generated at 2022-06-24 12:49:42.245743
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
        print("Test Class is created successfully")
    except:
        print("Test Class is not created")



# Generated at 2022-06-24 12:49:43.765211
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Constructor of class LinuxAcademyIE
    LinuxAcademyIE()

# Generated at 2022-06-24 12:49:45.868257
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    l = LinuxAcademyIE()
    assert l.IE_NAME == 'linuxacademy'

# Generated at 2022-06-24 12:49:57.987467
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test = LinuxAcademyIE()

    assert test.IE_NAME == 'linuxacademy'
    assert test._VALID_URL == r'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|https?://(?:www\.)?linuxacademy\.com/cp/modules/view/id/(?P<course_id>\d+)'
    assert test._NETRC_MACHINE == 'linuxacademy'
    assert test._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert test._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-24 12:50:07.421317
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print("\nTesting LinuxAcademyIE")
    inst = LinuxAcademyIE()
    assert inst._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)'
    assert inst._TESTS[0]['url'] == 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    assert inst._TESTS[1]['url'] == 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'

# Generated at 2022-06-24 12:50:20.146317
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    inst = LinuxAcademyIE()
    assert inst.get_match_groups() == [('chapter_id', 'lesson_id', 'course_id')]
    assert inst.get_valid_urls() == [
        'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
        'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2',
        'https://linuxacademy.com/cp/modules/view/id/154'
    ]
    assert inst.get_login_info() == ['linuxacademy', None]
    assert inst._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert inst._ORIGIN_URL

# Generated at 2022-06-24 12:50:21.273733
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:50:22.250062
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

# Generated at 2022-06-24 12:50:25.511127
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert obj._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'


# Generated at 2022-06-24 12:50:29.869529
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Create a new instance of the class LinuxAcademyIE
    from . import test as parent
    test = parent.__dict__.get("SubtitlesTest")
    linuxacademy = LinuxAcademyIE()
    parent.assertIsInstance(linuxacademy, test)
    return

# Generated at 2022-06-24 12:50:38.810433
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == '(?x)https?://(?:www\\.)?linuxacademy\\.com/cp/courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|https?://(?:www\\.)?linuxacademy\\.com/cp/modules/view/id/(?P<course_id>\\d+)'

# Generated at 2022-06-24 12:50:44.542592
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    print(ie._NETRC_MACHINE)
    print(ie._AUTHORIZE_URL)
    print(ie._ORIGIN_URL)
    print(ie._CLIENT_ID)
    # output:
    # linuxacademy
    # https://login.linuxacademy.com/authorize
    # https://linuxacademy.com
    # KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx

# Generated at 2022-06-24 12:50:49.638857
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    username = 'username'
    password = 'password'
    ie = LinuxAcademyIE(params={'username': username, 'password': password})
    assert ie._CLIENT_ID is not None
    assert ie._ORIGIN_URL is not None
    assert ie._NETRC_MACHINE is not None
    assert ie._login_info()[1] == (username, password)
    assert ie._real_initialize() is None

# Generated at 2022-06-24 12:50:51.578529
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert obj.IE_NAME == 'LinuxAcademy'

# Generated at 2022-06-24 12:50:55.972623
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_object = LinuxAcademyIE()
    assert test_object.ie_key() == "LinuxAcademy"
    assert test_object.ie_key() in list(InfoExtractor._ALL_CLASSES.keys())

# Generated at 2022-06-24 12:50:58.092140
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE('LinuxAcademyIE').ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:50:59.191368
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()


# Generated at 2022-06-24 12:51:01.656901
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
        # Instanciate LinuxAcademyIE object
        laIE = LinuxAcademyIE()
        # Call method _real_initialize
        laIE._real_initialize()

# Generated at 2022-06-24 12:51:03.611993
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Constructor should return an instance of LinuxAcademyIE
    instance = LinuxAcademyIE()
    assert isinstance(instance, LinuxAcademyIE)

# Generated at 2022-06-24 12:51:14.762249
# Unit test for constructor of class LinuxAcademyIE

# Generated at 2022-06-24 12:51:15.799423
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

# Generated at 2022-06-24 12:51:17.709737
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Test constructor of class LinuxAcademyIE
    """
    LinuxAcademyIE()

# Generated at 2022-06-24 12:51:28.080323
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.WORKING == False
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-24 12:51:35.884136
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE();
    assert(ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize')
    assert(ie._ORIGIN_URL == 'https://linuxacademy.com')
    assert(ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx')
    assert(ie._NETRC_MACHINE == 'linuxacademy')
test_LinuxAcademyIE()

# Generated at 2022-06-24 12:51:37.732922
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_LinuxAcademyIE = LinuxAcademyIE('linuxacademy')



# Generated at 2022-06-24 12:51:38.555128
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert(LinuxAcademyIE.ie_key() == 'linuxacademy')

# Generated at 2022-06-24 12:51:40.220602
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._login() is None
    ie.login()

# Generated at 2022-06-24 12:51:44.784824
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ies = [LinuxAcademyIE()]
    for ie in ies:
        assert(ie.ie_key() == LinuxAcademyIE.ie_key())
        assert(ie.IE_NAME == LinuxAcademyIE.IE_NAME)
        assert(ie._VALID_URL == LinuxAcademyIE._VALID_URL)

# Generated at 2022-06-24 12:51:50.613925
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test empty _CLIENT_ID
    LinuxAcademyIE._CLIENT_ID = ''
    try:
        LinuxAcademyIE()
    except:
        pass
    finally:
        # Reset _CLIENT_ID
        LinuxAcademyIE._CLIENT_ID = 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-24 12:51:51.986737
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    a=LinuxAcademyIE()
    a._real_initialize()
    print("test is over")

# Generated at 2022-06-24 12:51:53.310253
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie
    assert ie._login()

# Generated at 2022-06-24 12:51:55.903598
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE(None)._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-24 12:52:06.811310
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE('linuxacademy', 'linuxacademy.com')

    assert ie._USER_AGENT == 'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.0'
    assert ie._DEFAULT_TIMEOUT == 10
    assert ie._DEFAULT_PROXY_SERVER == '127.0.0.1:8118'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_M

# Generated at 2022-06-24 12:52:08.538937
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_result = LinuxAcademyIE()
    assert test_result._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:52:16.590568
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # test a random url
    API_URL = 'linuxacademy'
    _RESPONSE_URL = 'test/test_linuxacademy.json'
    _TEST = {
        'url': API_URL,
        'info_dict': {
            'id': API_URL,
        },
        'params': {
            'skip_download': True,
        },
    }
    _TEST.update({
        'params': {
            'skip_download': True,
            'write_subtitles': True,
            'write_all_thumbnails': True
        }
    })
    from .common import FakeYDL
    fake_ydl = FakeYDL()
    with fake_ydl as ydl:
        ydl.add_default_info_extractors()
        ydl.download

# Generated at 2022-06-24 12:52:22.386621
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ies = [x for x in globals().values() if isinstance(x, type) and issubclass(x, InfoExtractor)]
    for ie in ies:
        assert isinstance(ie, type) and issubclass(ie, InfoExtractor)
        assert hasattr(ie, 'ie_key') and ie.ie_key() == ie.ie_key()

# Generated at 2022-06-24 12:52:32.441235
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    def test_LAcademyIE(name, args, kwargs, expected, expected_exc=None):
        if expected_exc:
            with pytest.raises(expected_exc) as excinfo:
                LinuxAcademyIE(*args, **kwargs)
            assert excinfo.value.args == expected
        else:
            instance = LinuxAcademyIE(*args, **kwargs)
            assert instance.IE_NAME == 'linuxacademy'
            assert instance.LOGIN_REQUIRED == True
            assert instance._VALID_URL == r'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'


# Generated at 2022-06-24 12:52:42.800942
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import os
    import sys
    import unittest

    # Hack to load the required class in the tests while keeping the import
    # outside of the main script
    sys.modules["yadisk"] = __import__("yadisk")
    sys.modules["yadisk.yadisk"] = __import__("yadisk.yadisk")

    here = os.path.dirname(os.path.abspath(__file__))
    web_page_file = os.path.join(here, "test.html")
    with open(web_page_file, "rb") as f:
        web_page = f.read().decode('utf-8')

    class MyTestCase(unittest.TestCase):
        def test_webpage(self):
            LinuxAcademyIE()._parse_m3u

# Generated at 2022-06-24 12:52:45.819256
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # No Linux Academy credentials throws error
    with pytest.raises(ExtractorError) as e:
        LinuxAcademyIE()._login()
    assert e.type in (ExtractorError, compat_HTTPError)

# Generated at 2022-06-24 12:52:53.574937
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_url = "https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2"
    raw_result = LinuxAcademyIE()._real_extract(test_url)
    if raw_result.get('entries'):
        assert 'entries' not in raw_result
        for entry in raw_result['entries']:
            assert 'formats' not in entry
    else:
        assert 'formats' in raw_result

# Generated at 2022-06-24 12:52:56.839182
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    ie = LinuxAcademyIE()
    ie._real_initialize()
    assert ie._real_extract(url)

# Generated at 2022-06-24 12:52:58.292584
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test import test_LinuxAcademyIE
    return test_LinuxAcademyIE(LinuxAcademyIE)

# Generated at 2022-06-24 12:53:00.464660
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Check what the constructor returns when the credentials are missing
    assert LinuxAcademyIE()._login() is None

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:53:01.966804
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    name = 'LinuxAcademyIE'
    obj = globals()[name]
    assert obj

# Generated at 2022-06-24 12:53:06.548741
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Unit test for LinuxAcademyIE class
    """
    global ie
    ie = LinuxAcademyIE()
    username = os.environ.get('LINUXACADEMY_USERNAME', None)
    password = os.environ.get('LINUXACADEMY_PASSWORD', None)
    if username and password:
        ie._login()
    assert ie != None

# Generated at 2022-06-24 12:53:17.878050
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Instantiate an instance of LinuxAcademyIE
    obj_LinuxAcademyIE = LinuxAcademyIE()
    # Check that the _AUTHORIZE_URL is set to the correct value
    assert obj_LinuxAcademyIE._AUTHORIZE_URL=='https://login.linuxacademy.com/authorize'
    # Check that the _ORIGIN_URL is set to the correct value
    assert obj_LinuxAcademyIE._ORIGIN_URL=='https://linuxacademy.com'
    # Check that the _CLIENT_ID is set to the correct value
    assert obj_LinuxAcademyIE._CLIENT_ID=='KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    # Check that the _NETRC_MACHINE

# Generated at 2022-06-24 12:53:21.825476
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        assert (LinuxAcademyIE._LOGIN_URL == "https://login.linuxacademy.com/login/callback") == True
    except:
        print("ERROR - test_LinuxAcademyIE - Failed")
    else:
        print("OK - test_LinuxAcademyIE - OK")



# Generated at 2022-06-24 12:53:24.053427
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    return LinuxAcademyIE("https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675" , "")

# Generated at 2022-06-24 12:53:34.376086
# Unit test for constructor of class LinuxAcademyIE

# Generated at 2022-06-24 12:53:36.389971
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        __test__ = {
            'linuxacademy': LinuxAcademyIE
        }
    except NameError:
        pass

# Generated at 2022-06-24 12:53:39.827090
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE('linuxacademy')
    assert ie is not None
    assert ie.ie_key() == 'linuxacademy'
    assert ie.ie_key() == 'LinuxAcademy'


# Generated at 2022-06-24 12:53:44.223463
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Unit tests to verify the LinuxAcademyIE module.
    """
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.IE_NAME == 'LinuxAcademy'

# Generated at 2022-06-24 12:53:48.258726
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    json_testing_url = "https://www.youtube.com/watch?v=Mh0W0ULInCs"
    sample_input_1 = [json_testing_url,'test','test','test','test','test','test','test','test','test','test','test','test','test', 'test']

    test_video = LinuxAcademyIE()
    test_video.initialize()
    test_video.extract(json_testing_url)
    test_video.extract(sample_input_1)
    success = True
    assert success


# Generated at 2022-06-24 12:53:52.028627
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        from test.test_download import fake_input
        from test.test_download import fake_getpass
    except (ImportError, NameError):
        return

    with fake_input('linuxacademy-login', 'linuxacademy-password'):
        with fake_getpass():
            LinuxAcademyIE()

# Generated at 2022-06-24 12:54:04.576308
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    filename = 'testdata/test_LinuxAcademyIE.json'
    testcases = load_json(filename)
    # For each test case
    for case in testcases:
        # Get the parameters
        params = case.get('params')
        in_url = params.get('url')
        expected_url = params.get('expected_url')
        expected_result = case.get('expected_result')
        # Create the instance of LinuxAcademyIE
        ie = LinuxAcademyIE()
        # Extract the url
        url = ie._real_initialize(in_url=in_url)
        # Assert expected == actual
        assert_equal(url, expected_url)
        assert_equal(ie._course_id, expected_result['course_id'])

# Generated at 2022-06-24 12:54:11.229566
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    unit_test_ie = LinuxAcademyIE()
    assert unit_test_ie._VALID_URL == LinuxAcademyIE._VALID_URL
    assert unit_test_ie._NETRC_MACHINE == LinuxAcademyIE._NETRC_MACHINE
    assert unit_test_ie._AUTHORIZE_URL == LinuxAcademyIE._AUTHORIZE_URL
    assert unit_test_ie._ORIGIN_URL == LinuxAcademyIE._ORIGIN_URL
    assert unit_test_ie._CLIENT_ID == LinuxAcademyIE._CLIENT_ID
    assert unit_test_ie._TESTS == LinuxAcademyIE._TESTS

# Generated at 2022-06-24 12:54:12.372251
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:54:17.242381
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # create an instance of class LinuxAcademyIE
    la_ie = LinuxAcademyIE();
    la_ie._real_initialize();
    la_ie.ie_key();
    la_ie._real_extract('https://linuxacademy.com/cp/modules/view/id/154');

# Generated at 2022-06-24 12:54:18.659047
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # TODO implement some tests
    pass

# Generated at 2022-06-24 12:54:21.931518
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        lec = LinuxAcademyIE()
    except:
        assert 0, "IE LinuxAcademyIE() failed"
    else:
        assert lec, "IE LinuxAcademyIE() no object generated"

# Generated at 2022-06-24 12:54:23.298851
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:54:24.811072
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    l = LinuxAcademyIE()
    assert l is not None
    return True

# Generated at 2022-06-24 12:54:27.729679
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._NETRC_MACHINE == 'linuxacademy'


# Generated at 2022-06-24 12:54:30.410818
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    class_name = "LinuxAcademyIE"
    obj = LinuxAcademyIE(class_name)
    assert obj.name == "LinuxAcademy"

# Generated at 2022-06-24 12:54:31.745445
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # check constructor without exception
    LinuxAcademyIE(None)

# Generated at 2022-06-24 12:54:39.901077
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # There are two ways to call the constructor of a class
    # a. Using the method for other class
    # b. Using the constructor for the class
    # Here we have used the method for other class.

    # This method returns an instance of the class
    # LinuxAcademyIE, which we have named as
    # ie_linux_academy.
    ie_linux_academy = InfoExtractor.getInfoExtractor(LinuxAcademyIE.ie_key())
    assert isinstance(
        ie_linux_academy,
        LinuxAcademyIE)

# Generated at 2022-06-24 12:54:46.956565
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE("LinuxAcademyIE")
    assert ie.__class__.__name__ == "LinuxAcademyIE"
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''


# Generated at 2022-06-24 12:54:51.869770
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    obj = LinuxAcademyIE()
    assert obj.suitable(url) == True

# Generated at 2022-06-24 12:54:59.337845
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test for constructor of class LinuxAcademyIE
    ie = LinuxAcademyIE()
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie._VALID_URL == r'''(?x)
                                https?://
                                    (?:www\.)?linuxacademy\.com/cp/
                                    (?:
                                        courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                                        modules/view/id/(?P<course_id>\d+)
                                    )
                                '''

# Generated at 2022-06-24 12:55:00.215974
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:55:12.282797
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """ This function is used to test the constructor of the class
    LinuxAcademyIE, for partial test cases.
    Note:
        1. This is a unit test
        2. Functions which are used for testing is not part of production code
    Args:
        None
    Returns:
        None
    Raises:
        AssertionError: If test fails
    """
    from .common import InfoExtractor
    from ..utils import (
        compat_b64decode,
        compat_HTTPError,
        compat_str,
        js_to_json,
    )
    from ..compat import (
        compat_b64decode,
        compat_HTTPError,
        compat_str,
    )
    from ..utils import js_to_json

    ie_obj = LinuxAcademyIE()

    # Test case 1

# Generated at 2022-06-24 12:55:13.178586
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:55:20.426464
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_cases = [
        (
            'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
            '7971-2',
        ),
        (
            'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2',
            '1498-2',
        ),
        (
            'https://linuxacademy.com/cp/modules/view/id/154',
            '154',
        ),
    ]
    for url, expected_id in test_cases:
        assert LinuxAcademyIE._id_from_url(url) == expected_id

# Generated at 2022-06-24 12:55:30.314833
# Unit test for constructor of class LinuxAcademyIE

# Generated at 2022-06-24 12:55:31.525131
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:55:33.724704
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    global LinuxAcademyIE
    assert isinstance(LinuxAcademyIE, type)

# Generated at 2022-06-24 12:55:41.483332
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    instance = ie.suitable('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    assert instance == True
    instance = ie.suitable('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    assert instance == True
    instance = ie.suitable('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    assert instance == True

# Generated at 2022-06-24 12:55:42.618296
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test empty video
    LinuxAcademyIE(None)

# Generated at 2022-06-24 12:55:51.698784
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    logindata = {
        '_type': 'form',
        'url': 'https://login.linuxacademy.com/usernamepassword/login',
        'title': 'Linux Academy login',
        'test': lambda x: 'request_type' in x or 'username' in x,
        'fields': {
            'client_id': 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx',
            'redirect_uri': 'https://linuxacademy.com',
            'tenant': 'lacausers',
            'connection': 'Username-Password-Authentication',
            'username': 'myusername',
            'password': 'mypassword',
            'sso': 'true',
        },
    }
    ie = LinuxAcademyIE()
   

# Generated at 2022-06-24 12:56:03.256919
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test LinuxAcademyIE constructor."""
    # Check for invalid values
    with pytest.raises(TypeError):
        LinuxAcademyIE({"url": "https://linuxacademy.com/cp/modules/view/id/154", "id": None, "upload_date": None, "title": "AWS Certified Cloud Practitioner", "description": "md5:a68a299ca9bb98d41cca5abc4d4ce22c", "duration": 28835})

# Generated at 2022-06-24 12:56:04.921604
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # test constructor
    assert issubclass(LinuxAcademyIE, InfoExtractor)

# Generated at 2022-06-24 12:56:05.886191
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()


# Generated at 2022-06-24 12:56:07.140572
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:56:08.279875
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert bool(LinuxAcademyIE()._VALID_URL)

# Generated at 2022-06-24 12:56:14.933967
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(None)
    assert isinstance(ie, LinuxAcademyIE)
    assert ie._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'

# Generated at 2022-06-24 12:56:18.557818
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert (LinuxAcademyIE()._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx')

# Generated at 2022-06-24 12:56:20.831689
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    downloader = LinuxAcademyIE()
    assert downloader.login() == None

# Generated at 2022-06-24 12:56:21.837988
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:56:27.377972
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from unittest import TestCase
    from youtube_dl.compat import mock

    mock_self = mock.Mock(spec=LinuxAcademyIE)
    mock_self.username = None
    mock_self.password = None
    mock_self.raise_login_required.side_effect = ExtractorError

    with TestCase.assertRaises(TestCase, ExtractorError):
        LinuxAcademyIE._login(mock_self)
    assert not mock_self.raise_login_required.called

# Generated at 2022-06-24 12:56:37.983725
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_cases = {'7971-2': 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
                  '1498-2': 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2',
                  '154': 'https://linuxacademy.com/cp/modules/view/id/154'}
    for key in test_cases.keys():
        LinuxAcademyIE(test_cases[key])
    print('LinuxAcademyIE passed')

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:56:44.428449
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Called from test_LinuxAcademyIE
    def check_test_LinuxAcademyIE(self, string):
        self.assertEqual(len(string), 32)
        self.assertEqual(len(re.findall('[a-z0-9]', string)), 32)
        self.assertEqual(len(re.findall('[A-Z]', string)), 0)

    import inspect

    code = inspect.getsource(check_test_LinuxAcademyIE)
    code = re.findall(r'return\s*(.+?)\s*;\s*$', code)[0]
    return_value = eval(code)

    check_test_LinuxAcademyIE(0, return_value)

test_LinuxAcademyIE()

# Generated at 2022-06-24 12:56:54.283397
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    with open('test.json', 'r') as f:
        html_page = json.load(f)
    m = LinuxAcademyIE()
    assert m.ie_key() == 'LinuxAcademy'
    assert m.video_id() == '7971-2'
    assert m.is_logged() == False
    assert m._sort_formats(m._extract_m3u8_formats(html_page['url'], html_page['id'], 'mp4', 'm3u8_native', 'hls')) == html_page['formats']
    assert m._real_extract(html_page['url']) == html_page['info']
    assert m.is_logged() == True

# Generated at 2022-06-24 12:56:59.339586
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    class OAuth2TestIE(LinuxAcademyIE):
        _VALID_URL = r'(?x)https?://(?:www\.)?linuxacademy\.com/.*'

        def _real_initialize(self):
            self._login()

        def _real_extract(self, url):
            raise NotImplementedError

    get_testcases_for_extractor(OAuth2TestIE)

# Generated at 2022-06-24 12:57:00.933877
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    i = LinuxAcademyIE()
    assert i.__class__.__name__ == LinuxAcademyIE.__name__

# Generated at 2022-06-24 12:57:05.713654
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie._VALID_URL == r'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:57:15.935506
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    xt = LinuxAcademyIE()
    assert(xt._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx')
    assert(xt._NETRC_MACHINE == 'linuxacademy')
    assert(xt._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize')
    assert(xt._ORIGIN_URL == 'https://linuxacademy.com')

# Generated at 2022-06-24 12:57:21.739070
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from ..utils import TestIE
    from ..extractors.common import InfoExtractor
    # Test constructor of LinuxAcademyIE
    linuxAcademy_test = TestIE(
        'linuxacademy',
        ie=LinuxAcademyIE)
    assert isinstance(linuxAcademy_test.ie, InfoExtractor)

# Generated at 2022-06-24 12:57:23.630888
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie,LinuxAcademyIE)

# Generated at 2022-06-24 12:57:33.980110
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert obj._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'