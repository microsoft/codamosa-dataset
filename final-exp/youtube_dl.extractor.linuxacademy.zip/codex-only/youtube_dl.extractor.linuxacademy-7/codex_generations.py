

# Generated at 2022-06-24 12:47:31.520587
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxAcademyIE = LinuxAcademyIE()

# Generated at 2022-06-24 12:47:33.104032
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE({'username': 'user', 'password': 'password'})

# Generated at 2022-06-24 12:47:35.053606
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert not LinuxAcademyIE('https://linuxacademy.com/cp/modules/view/id/154')

# Generated at 2022-06-24 12:47:36.800092
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675', 'LinuxAcademyIE')

# Generated at 2022-06-24 12:47:37.942503
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE();

# Generated at 2022-06-24 12:47:48.921932
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.__class__.__name__ == 'LinuxAcademyIE'
    assert ie._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'

# Generated at 2022-06-24 12:47:50.652320
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.__name__ in LinuxAcademyIE.ie_key()



# Generated at 2022-06-24 12:47:53.486333
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    class_ = LinuxAcademyIE

    # Test class initialization
    assert class_ == LinuxAcademyIE


# Generated at 2022-06-24 12:47:54.807783
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    l = LinuxAcademyIE()
    # I think this call is enough for testing the constructor
    l._real_initialize()

# Generated at 2022-06-24 12:47:56.448130
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._LOGIN_REQUIRED == True

# Generated at 2022-06-24 12:48:00.194405
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
        linux_academy_ie = LinuxAcademyIE()
        linux_academy_ie._real_extract('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
        linux_academy_ie._real_extract('https://linuxacademy.com/cp/modules/view/id/154')

# Generated at 2022-06-24 12:48:01.093665
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:48:02.383032
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('linuxacademy')

# Generated at 2022-06-24 12:48:04.557484
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert(ie)


if __name__ == "__main__":
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:48:05.143610
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None)

# Generated at 2022-06-24 12:48:14.420361
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # fixture: id, title
    URLS = [('147', ' "The Basics of The Cloud'),
            ('56', 'Infrastructure Configurations in AWS')]

    for index, obj in enumerate(URLS):
        obj_id, obj_title = obj
        index = index + 1
        ids = obj_id
        url = "https://linuxacademy.com/cp/modules/view/id/{}".format(ids)

        l = LinuxAcademyIE()
        result = l.extract(url)
        assert result['id'] == obj_id
        assert result['title'].find(obj_title) != -1


if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:48:19.785692
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    '''
    Unit test for constructor of class LinuxAcademyIE
    '''
    la_ie = LinuxAcademyIE(None)
    assert la_ie._NETRC_MACHINE == 'linuxacademy'
    assert la_ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert la_ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert la_ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'

# Generated at 2022-06-24 12:48:21.182805
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    result = LinuxAcademyIE()
    assert result


# Generated at 2022-06-24 12:48:24.550863
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_url = 'https://linuxacademy.com/cp/modules/view/id/154'
    playlist = LinuxAcademyIE._build_playlist(LinuxAcademyIE, test_url)
    assert playlist is not None

# Generated at 2022-06-24 12:48:25.583014
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import logging
    logging.basicConfig(level=logging.INFO)
    LinuxAcademyIE()

# Generated at 2022-06-24 12:48:31.271269
# Unit test for constructor of class LinuxAcademyIE

# Generated at 2022-06-24 12:48:39.146783
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == "LinuxAcademy"
    assert ie.ie_key() == 'linuxacademy'
    assert ie._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'


# Generated at 2022-06-24 12:48:39.939051
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-24 12:48:42.249259
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_linuxacademy import test_linuxacademyIE
    ie = test_linuxacademyIE(LinuxAcademyIE)
    ie._login()

# Generated at 2022-06-24 12:48:43.629203
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    IE = LinuxAcademyIE()
    assert isinstance(IE, InfoExtractor)

# Generated at 2022-06-24 12:48:45.761662
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_ie = LinuxAcademyIE()
    assert linux_academy_ie

# Generated at 2022-06-24 12:48:47.211241
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:48:53.309423
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        from .test_linuxacademy import LinuxAcademyTests
    except ImportError:
        from linuxacademy_tests import LinuxAcademyTests

    for test_name, test in LinuxAcademyTests.items():
        _, value = test()
        if value is not None:
            ie = LinuxAcademyIE(*value)
            ie.to_screen(test_name)

# Generated at 2022-06-24 12:48:54.404838
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:49:04.966545
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

# Generated at 2022-06-24 12:49:11.538013
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info_dicts = [{
        'id': '7971-2',
        'ext': 'mp4',
        'title': 'What Is Data Science',
        'description': 'md5:c574a3c20607144fb36cb65bdde76c99',
        'timestamp': 1607387907,
        'upload_date': '20201208',
        'duration': 304,
    }, {
        'id': '154',
        'title': 'AWS Certified Cloud Practitioner',
        'description': 'md5:a68a299ca9bb98d41cca5abc4d4ce22c',
        'duration': 28835,
    }]
    for info_dict in info_dicts:
        # initialize of class LinuxAcademyIE without arguments
        info_extractor = LinuxAc

# Generated at 2022-06-24 12:49:20.939542
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Testing with valid input
    test_object = LinuxAcademyIE(None)
    # Testing with invalid input
    try:
        # Testing with None type input
        test_object.username = None
        test_object.password = None
        test_object.LINUXACADEMY_CLIENT_ID = None
        LinuxAcademyIE(None)
    except Exception as e:
        # Testing with valid inputs
        test_object.username = "username"
        test_object.password = "password"
        test_object.LINUXACADEMY_CLIENT_ID = "KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx"
        LinuxAcademyIE(None)

# Generated at 2022-06-24 12:49:23.213860
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    not_working_ie = LinuxAcademyIE()
    # Unit test for constructor of class LinuxAcademyIE
    def test_LinuxAcademyIE_dummy():
        ie = LinuxAcademyIE()
        assert ie is not None

# Generated at 2022-06-24 12:49:24.666428
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert instance is not None

# Generated at 2022-06-24 12:49:25.806272
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('linuxacademy')

# Generated at 2022-06-24 12:49:29.699163
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    inst = LinuxAcademyIE()
    assert inst._CLIENT_ID != ''
    assert inst._NETRC_MACHINE == 'linuxacademy'
    assert inst._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'

# Generated at 2022-06-24 12:49:30.988705
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE().ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:49:32.512443
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE is not None, 'constructor of class LinuxAcademyIE failed to be constructed'

# Generated at 2022-06-24 12:49:33.775528
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    la_instance = LinuxAcademyIE()
    assert la_instance is not None

# Generated at 2022-06-24 12:49:38.868526
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_urls import TestUrls
    # Check if url matches valid url
    url = "https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2"
    instance = TestUrls(url)
    assert(LinuxAcademyIE.ie_key() == instance.get_info_extractor_key())
    # Check if the instance of class is created
    assert(isinstance(instance, LinuxAcademyIE))

# Generated at 2022-06-24 12:49:50.664246
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Arrange
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    # Act and Assert
    linuxAcademy = LinuxAcademyIE()
    assert linuxAcademy._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|modules/view/id/(?P<course_id>\\d+))'

# Generated at 2022-06-24 12:50:02.111048
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    cases = [
        # empty string
        '',
        # trailing space
        '  ',
        # valid URL
        'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
        # invalid URL
        'https://linuxacademy.com/not-a-valid-url',
        # invalid URL
        'https://www.youtube.com/watch?v=C0DPdy98e4c',
        # invalid URL
        'www.youtube.com',
    ]
    for case in cases:
        if case != '':
            print('Case: ' + case)
            i = LinuxAcademyIE(case)
            url = i.url
            print('  URL: ' + url)
            # test our __init__() is validating

# Generated at 2022-06-24 12:50:05.978914
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == LinuxAcademyIE._VALID_URL
    assert ie._TESTS == LinuxAcademyIE._TESTS
    assert ie._AUTHORIZE_URL == LinuxAcademyIE._AUTHORIZE_URL
    assert ie._ORIGIN_URL == LinuxAcademyIE._ORIGIN_URL
    assert ie._CLIENT_ID == LinuxAcademyIE._CLIENT_ID
    assert ie._NETRC_MACHINE == LinuxAcademyIE._NETRC_MACHINE

# Generated at 2022-06-24 12:50:06.816818
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()


# Generated at 2022-06-24 12:50:19.297052
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

    assert(ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize')
    assert(ie._ORIGIN_URL == 'https://linuxacademy.com')
    assert(ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx')
    assert(ie._NETRC_MACHINE == 'linuxacademy')
    assert(ie._LOGIN_URL == 'https://login.linuxacademy.com/authorize')

# Generated at 2022-06-24 12:50:20.718191
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert(LinuxAcademyIE.ie_key() == 'LinuxAcademy')

# Generated at 2022-06-24 12:50:32.240443
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademyIE = LinuxAcademyIE('http://www.linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    info_dict = linuxacademyIE.extract('http://www.linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    assert info_dict['id'] == '7971-2'
    assert info_dict['title'] == 'What Is Data Science'
    assert info_dict['description'] == 'md5:c574a3c20607144fb36cb65bdde76c99'
    assert info_dict['timestamp'] == 1607387907
    assert info_dict['upload_date'] == '20201208'

# Generated at 2022-06-24 12:50:34.587171
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:50:44.193295
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Unit test for constructor of class LinuxAcademyIE
    lai = LinuxAcademyIE()
    assert lai._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'
    assert lai._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert lai._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-24 12:50:47.696412
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._CLIENT_ID  == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:50:53.222438
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    dummy_url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    info_extractor = LinuxAcademyIE()
    assert info_extractor._VALID_URL == LinuxAcademyIE._VALID_URL
    assert info_extractor._TESTS == LinuxAcademyIE._TESTS
    assert info_extractor._downloader == None
    assert info_extractor.suitable(dummy_url) == True
    info_extractor._real_extract(dummy_url)

# Generated at 2022-06-24 12:50:54.878735
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()._login()

# Generated at 2022-06-24 12:50:56.827559
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademy_ie = LinuxAcademyIE()

# Generated at 2022-06-24 12:50:59.345485
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # 1.1: test construction of class LinuxAcademyIE
    ie = LinuxAcademyIE()
    assert ie is not None


# Generated at 2022-06-24 12:51:09.090001
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print('------ Test LinuxAcademyIE constructor ------')
    # Test with incomplete URL
    incomplete_url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/'
    extracted = LinuxAcademyIE()._real_extract(incomplete_url)
    print('Test incomplete URL')
    print('Extracted id: %s' % extracted.get('id'))
    # Test with complete URL
    complete_url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    extracted = LinuxAcademyIE()._real_extract(complete_url)
    print('Test complete URL')
    print('Extracted id: %s' % extracted.get('id'))

# Generated at 2022-06-24 12:51:13.153332
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = "https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2"
    LinuxAcademyIE().suitable(url)
    LinuxAcademyIE()._real_extract(url)

# Generated at 2022-06-24 12:51:14.467921
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
   print(LinuxAcademyIE())

# Generated at 2022-06-24 12:51:17.561248
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        # Check if class LinuxAcademyIE is defined
        LinuxAcademyIE(None)
        # Return true if class is defined
        return True
    except:
        return False

# Generated at 2022-06-24 12:51:27.360926
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:51:28.781387
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ies = LinuxAcademyIE()
    assert ies is not None

# Generated at 2022-06-24 12:51:39.999767
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)'

# Generated at 2022-06-24 12:51:45.794137
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import os
    import tempfile
    from .html_netrc_downloader import HtmlNetrcDownloader

    with tempfile.NamedTemporaryFile(delete=True, mode="w") as rcfile_obj:

        rcfile_obj.write("""
machine linuxacademy login a@b.c password x
""")
        rcfile_obj.flush()
        os.chmod(rcfile_obj.name, 0o600)

        downloader = HtmlNetrcDownloader(params=dict(username='a@b.c', password='x'))
        downloader.add_netrc_file(rcfile_obj.name)

        ie = LinuxAcademyIE(downloader=downloader)
        assert ie._real_initialize()


# Generated at 2022-06-24 12:51:47.307852
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:51:56.674981
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import copy
    import os

    os.environ.clear()

    obj = LinuxAcademyIE()
    assert obj is not None
    assert copy.deepcopy(obj._DEFAULT_HEADERS) == {
        'Accept-Charset': 'UTF-8,*;q=0.5',
        'Accept-Language': 'en-US,en;q=0.8',
        'Host': 'www.linuxacademy.com',
        'User-Agent': 'Ytdl',
        'X-Requested-With': 'XMLHttpRequest',
        'referer': 'https://www.linuxacademy.com/',
    }

    obj = LinuxAcademyIE()
    assert obj is not None

# Generated at 2022-06-24 12:51:59.671207
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    res = ie._real_extract('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    print(res)

if __name__ == "__main__":
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:52:03.349628
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    i = LinuxAcademyIE('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    assert i is not None


# Generated at 2022-06-24 12:52:08.912256
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

# Unit tests for class LinuxAcademyIE
# TODO: Add tests for methods: _login, _real_extract, _real_initialize, extract, _search_regex, _hidden_inputs, _parse_json, _download_webpage, _download_webpage_handle

if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-24 12:52:10.432049
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert type(ie) == LinuxAcademyIE

# Generated at 2022-06-24 12:52:11.099516
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert(obj == LinuxAcademyIE)

# Generated at 2022-06-24 12:52:12.661610
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # assert that the constructor of class LinuxAcademyIE
    # returns an instance of InfoExtractor or its descendant
    obj = LinuxAcademyIE()
    assert isinstance(obj, InfoExtractor)

# Generated at 2022-06-24 12:52:15.459402
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._NETRC_MACHINE == 'linuxacademy'
    assert LinuxAcademyIE()._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-24 12:52:17.512763
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    # 'Wrong login credentials'
    # ie._login()

# Generated at 2022-06-24 12:52:25.381968
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'

# Generated at 2022-06-24 12:52:35.042662
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import os
    import unittest

    class LinuxAcademyTestCase(unittest.TestCase):
        dict_test_linuxacademy = {
            'url': 'https://linuxacademy.com/cp/modules/view/id/154',
            'only_matching': True
        }

        # Unit test _real_extract method

# Generated at 2022-06-24 12:52:41.597644
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    course_url = ''
    ie = LinuxAcademyIE()
    course_webpage = ''
    # Test for method _login
    ie._login()

    # Test for method _real_extract
    try:
        info = ie._real_extract(course_url)
        assert info['id'] is not None
    except:
        raise AssertionError(
            'test_LinuxAcademyIE: test for method _real_extract failed')

test_LinuxAcademyIE()

# Generated at 2022-06-24 12:52:42.869349
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass # TODO: Write unit tests

# Generated at 2022-06-24 12:52:52.581400
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test the unit test for LinuxAcademyIE"""
    # Given:
    _test_LinuxAcademyIE_url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    # When:
    try:
        linuxacademy_ie = LinuxAcademyIE()
        linuxacademy_ie._real_initialize()
        linuxacademy_ie._real_extract(url=_test_LinuxAcademyIE_url)
    except Exception:
        raise    
    # Then:
    assert(linuxacademy_ie != None)

# Generated at 2022-06-24 12:53:02.328128
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_ie = LinuxAcademyIE()
    assert test_ie._AUTHORIZE_URL == "https://login.linuxacademy.com/authorize"
    assert test_ie._ORIGIN_URL == "https://linuxacademy.com"
    assert test_ie._CLIENT_ID == "KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx"
    assert test_ie._NETRC_MACHINE == "linuxacademy"

# Generated at 2022-06-24 12:53:10.057490
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        import requests
    except ImportError as error:
        # Test is skipped because requests is not installed
        import unittest
        raise unittest.SkipTest(str(error))

    ie = LinuxAcademyIE('LinuxAcademy')


# Generated at 2022-06-24 12:53:20.928488
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    IE = LinuxAcademyIE('Linux Academy', 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    assert IE.ie_key() == 'LinuxAcademy'
    assert IE.name() == 'Linux Academy'
    assert IE._VALID_URL == r'^https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'
    assert IE._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'

# Generated at 2022-06-24 12:53:23.273176
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()  # Check implicit call of static method _real_extract
    LinuxAcademyIE()._login()  # Check implicit call of static method _real_initialize

# Generated at 2022-06-24 12:53:24.849402
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)


# Generated at 2022-06-24 12:53:26.533712
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    IE = LinuxAcademyIE()
    assert IE.ie_key() == 'linuxacademy'
    assert IE.RATELIMIT is True

# Generated at 2022-06-24 12:53:27.982456
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert issubclass(LinuxAcademyIE, InfoExtractor)

# Generated at 2022-06-24 12:53:38.243070
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from unittest import TestCase

    class TestLinuxAcademyIE(TestCase):

        def test_class_constructor(self):
            linuxacademy_ie = LinuxAcademyIE()
            self.assertEqual(linuxacademy_ie.ie_key(), 'LinuxAcademy')
            self.assertEqual(linuxacademy_ie.IE_NAME, 'linuxacademy:course')
            self.assertEqual(
                linuxacademy_ie._VALID_URL,
                r'^https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/'
                r'course/(?P<chapter_id>\d+)/lesson/(?P<lecture_id>\d+)$')

# Generated at 2022-06-24 12:53:43.475235
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print(LinuxAcademyIE(None)._AUTHORIZE_URL) 
    print(LinuxAcademyIE(None)._ORIGIN_URL)
    print(LinuxAcademyIE(None)._CLIENT_ID) 
    print(LinuxAcademyIE(None)._NETRC_MACHINE)

# Generated at 2022-06-24 12:53:44.180580
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-24 12:53:46.074812
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(
        'http://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
        'https://linuxacademy.com/cp/modules/view/id/154')

# Generated at 2022-06-24 12:53:52.723745
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie_obj = LinuxAcademyIE()
    ie_obj.IE_NAME
    ie_obj.ie_key()
    ie_obj.url_result('')
    ie_obj.valid()
    ie_obj._download_webpage
    ie_obj._html_search_regex
    ie_obj._json_search_regex
    ie_obj._login
    ie_obj._real_extract('')
    ie_obj._real_initialize()
    ie_obj.suitable('')
    ie_obj.initialize()
    ie_obj.extract('')

# Generated at 2022-06-24 12:53:54.435164
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    _LA_IE = LinuxAcademyIE()
    assert _LA_IE is not None

# Generated at 2022-06-24 12:54:06.798073
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    url = "https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2"
    webpage = obj._download_webpage(url, 'single video path')
    m3u8_url_obj = obj._parse_json(
            obj._search_regex(
                r'player\.playlist\s*=\s*(\[.+?\])\s*;', webpage, 'playlist'),
            'single video path')[0]
    obj._extract_m3u8_formats(
            m3u8_url_obj['file'], 'single video path', 'mp4', entry_protocol='m3u8_native',
            m3u8_id='hls')

# Generated at 2022-06-24 12:54:07.987935
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('LinuxAcademy')

# Generated at 2022-06-24 12:54:19.566902
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert obj.get_test_cases()
    assert obj.get_test_videos()

# Unit tests for LinuxAcademyIE and LinuxAcademyCourseIE
#
# They are part of the official test suite, but are runnable
# on any Linux Academy account in order to be actually useful.
#
# Usage:
#     python -m YoutubeDL.ie.linuxacademy \
#        --username <YOUR_USERNAME> --password <YOUR_PASSWORD>
#
# Note that running these tests requires
# a valid Linux Academy account,
# and may charge your credit card if you don't have a Premium subscription.

if __name__ == '__main__':
    from ..test import _main_common
    _main_common(LinuxAcademyIE, __name__)

# Generated at 2022-06-24 12:54:27.964284
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_cases = (
        "",
        "https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675",
        "https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2",
        "https://linuxacademy.com/cp/modules/view/id/154",
    )

    for test_case in test_cases:
        print("Testing constructor on test case: %s" % test_case)

        LinuxAcademyIE(test_case)

# Generated at 2022-06-24 12:54:28.699319
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:54:29.412359
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:54:35.944484
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    class MockLinuxAcademyIE(LinuxAcademyIE):
        def __init__(self, *args, **kwargs):
            self.__dict__ = kwargs
            super(MockLinuxAcademyIE, self).__init__(*args)
        def _download_webpage(self, *args, **kwargs):
            return args[0]
        def _real_initialize(self):
            pass
    # Empty string for both username and password
    obj = MockLinuxAcademyIE(username='', password='')
    assert not obj._login()
    # Empty string for username
    obj._password = 'dummy'
    assert not obj._login()
    # Empty string for password
    obj._username = 'dummy'
    obj._password = ''
    assert not obj._login()

# Generated at 2022-06-24 12:54:38.285676
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    t = LinuxAcademyIE
    t.test_LinuxAcademyIE()

# Generated at 2022-06-24 12:54:42.587151
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # it is not possible to unit test this class because it requires login credentials
    # we can at least test that it was instantiated correctly
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.netrc_machine == 'linuxacademy'

# Generated at 2022-06-24 12:54:43.349565
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:54:50.436975
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    extractor = LinuxAcademyIE()

    assert extractor._VALID_URL == LinuxAcademyIE._VALID_URL

    assert extractor._AUTHORIZE_URL == LinuxAcademyIE._AUTHORIZE_URL
    assert extractor._ORIGIN_URL == LinuxAcademyIE._ORIGIN_URL
    assert extractor._CLIENT_ID == LinuxAcademyIE._CLIENT_ID
    assert extractor._NETRC_MACHINE == LinuxAcademyIE._NETRC_MACHINE

    assert extractor._login == LinuxAcademyIE._login
    assert extractor._real_initialize == LinuxAcademyIE._real_initialize
    assert extractor._real_extract == LinuxAcademyIE._real_extract

# Generated at 2022-06-24 12:54:54.137615
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    # just checking if the unit test can be initialized
    # the _real_extract is skipped with the skip parameter
    ie._real_extract('https://www.linuxacademy.com/cp/modules/view/id/270')

# Generated at 2022-06-24 12:55:03.106335
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():

    # Test passing all required parameter
    obj = LinuxAcademyIE(LinuxAcademyIE._VALID_URL, params={})
    assert obj._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|https?://(?:www\.)?linuxacademy\.com/cp/modules/view/id/(?P<course_id>\d+)'
    assert obj._TESTS[2]['url'] == 'https://linuxacademy.com/cp/modules/view/id/154'

    # Test passing less parameters than required
    with pytest.raises(TypeError) as excinfo:
        LinuxAcademyIE()
   

# Generated at 2022-06-24 12:55:04.329886
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:55:13.286540
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    x = LinuxAcademyIE()
    test_LinuxAcademyIE = [
        {
            'file': 'https://v.linuxacademy.com/app/p/courses/lesson/course/9351/lesson/1/module/7383/getFLVScript?s=1549985885&_=1549985885',
            'note': 'Test constructor of class LinuxAcademyIE',
        },
    ]
    for i in test_LinuxAcademyIE:
        assert x.suitable(i['file'])

# Generated at 2022-06-24 12:55:22.420190
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import requests
    import vcr
    my_vcr = vcr.VCR(
        cassette_library_dir='test/test_cassettes/test_LinuxAcademyIE',
        record_mode='new_episodes',
        match_on=['uri', 'method'])
    with my_vcr.use_cassette('test_LinuxAcademyIE_init.yaml',
                             decode_compressed_response=True,
                             record_mode='none'):
        la_ie = LinuxAcademyIE()
        assert isinstance(la_ie, LinuxAcademyIE)
        assert isinstance(la_ie._downloader, requests.Session)
        assert la_ie._downloader.auth is None

# Generated at 2022-06-24 12:55:29.611261
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    user = 'myuser'
    password = '123456'
    ie = LinuxAcademyIE(None, None, None, None, None,
                        user=user, password=password)
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-24 12:55:30.674114
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:55:31.849085
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:55:42.242531
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Detailed test of constructor of LinuxAcademyIE class

    # creation of class object
    ie = LinuxAcademyIE()

    # check for the variables defined in constructor
    assert ie._LOGIN_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'

    # Mock response for unit test

# Generated at 2022-06-24 12:55:44.031437
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test constructor
    ies = LinuxAcademyIE()

    # Test _authenticate method
    ies._authenticate()

# Generated at 2022-06-24 12:55:45.236820
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()._login()

# Generated at 2022-06-24 12:55:53.805942
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    #Download requieres a login beacuse it is an account specific content
    with pytest.raises(ExtractorError) as excinfo:
        ie.extract(url)
    assert excinfo.match('requires Linux Academy account credentials')
    #Basic test if the extraction process is correct
    ie.extract(url)
    date_format = '%Y-%m-%d %H:%M:%S'
    assert ie.name == 'LinuxAcademy'
    assert ie.description == 'md5:a68a299ca9bb98d41cca5abc4d4ce22c'
    assert ie.duration == 28835

# Generated at 2022-06-24 12:56:04.568581
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    ie = LinuxAcademyIE(url)
    assert ie._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|modules/view/id/(?P<course_id>\\d+))'

# Generated at 2022-06-24 12:56:15.317017
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    lai = LinuxAcademyIE()
    assert lai.login == lai._login
    assert lai._VALID_URL == lai._VALID_URL
    assert lai._TESTS == lai._TESTS
    assert lai.IE_NAME == lai.IE_NAME
    assert lai._AUTHORIZE_URL == lai._AUTHORIZE_URL
    assert lai._ORIGIN_URL == lai._ORIGIN_URL
    assert lai._CLIENT_ID == lai._CLIENT_ID
    assert lai._NETRC_MACHINE == lai._NETRC_MACHINE
    assert lai._REAL_INITIALIZE == lai._real_initialize
    assert lai._REAL_EXT

# Generated at 2022-06-24 12:56:23.995387
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    # test case 1
    try:
        ie.extract('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    except ExtractorError as e:
        assert(e.cause.code == 401)
    # test case 2
    try:
        ie.extract('https://linuxacademy.com/cp/modules/view/id/154')
    except ExtractorError as e:
        assert(e.cause.code == 401)

# Generated at 2022-06-24 12:56:26.202278
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert issubclass(LinuxAcademyIE, InfoExtractor)
    assert LinuxAcademyIE.ie_key() == 'linuxacademy'


# Generated at 2022-06-24 12:56:30.054856
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test method to check constructor of class LinuxAcademyIE."""
    linux_academy_instance = LinuxAcademyIE()
    assert linux_academy_instance != None

# Generated at 2022-06-24 12:56:32.832852
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

if __name__ == "__main__":
    import sys
    import doctest
    doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-24 12:56:35.423346
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'LinuxAcademy'

# Generated at 2022-06-24 12:56:36.470180
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

# Generated at 2022-06-24 12:56:45.166449
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    ie = LinuxAcademyIE(None, {'url': url})
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'

# Generated at 2022-06-24 12:56:46.984172
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie
    assert ie.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:56:57.556978
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'linuxacademy'

    # Multi forum support in test case
    from ..utils import make_ExtractorError
    from .test_linuxacademy_com import test_linuxacademy_com

# Generated at 2022-06-24 12:56:58.294013
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()


# Generated at 2022-06-24 12:56:59.032948
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    li = LinuxAcademyIE()

# Generated at 2022-06-24 12:57:04.462470
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'''(?x)
                                https?://
                                    (?:www\.)?linuxacademy\.com/cp/
                                    (?:
                                        courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                                        modules/view/id/(?P<course_id>\d+)
                                    )
                                '''
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-24 12:57:06.455188
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_ie = LinuxAcademyIE('LinuxAcademy')
    assert test_ie

# Generated at 2022-06-24 12:57:07.878847
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    tester = LinuxAcademyIE()
    tester._login()

# Generated at 2022-06-24 12:57:15.260707
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL.match('https://www.linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    assert ie._VALID_URL.match('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    module = ie.extract('https://linuxacademy.com/cp/modules/view/id/154')
    assert module['id'] == '154'

# Generated at 2022-06-24 12:57:16.023347
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:57:23.056669
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test with both course URL and lesson URL
    LinuxAcademyIE('LinuxAcademyIE', 'linuxacademy.com', True)('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    LinuxAcademyIE('LinuxAcademyIE', 'linuxacademy.com', True)('https://linuxacademy.com/cp/modules/view/id/154')

# Generated at 2022-06-24 12:57:23.797349
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()


# Generated at 2022-06-24 12:57:31.523988
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

    # test for _login function
    assert ie._login() is None

    # test for _real_extract function