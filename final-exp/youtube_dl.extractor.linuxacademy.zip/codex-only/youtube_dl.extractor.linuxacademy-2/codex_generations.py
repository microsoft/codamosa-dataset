

# Generated at 2022-06-24 12:47:34.751533
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    obj = LinuxAcademyIE.ie_key()
    assert obj.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:47:35.405533
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-24 12:47:37.765198
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Simple test of constructor of class LinuxAcademyIE
    """
    ie = LinuxAcademyIE()

# Generated at 2022-06-24 12:47:48.729606
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # test_LinuxAcademyIE_constructor()

    linuxAcademyIE = LinuxAcademyIE()
    assert linuxAcademyIE._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-24 12:47:50.808805
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademy_ie = LinuxAcademyIE()
    assert linuxacademy_ie.ie_key() == 'LinuxAcademy'
    assert linuxacademy_ie.ie_name() == 'LinuxAcademy'

# Generated at 2022-06-24 12:47:53.635230
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test Linux Academy IE
    if __name__ == "__main__":
        test = LinuxAcademyIE()
        assert test

# Generated at 2022-06-24 12:48:00.848167
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .common import fake_urlopen
    try:
        import requests
        requests.post = fake_urlopen(content='{"access_token": "my_access_token"}')
        IE = LinuxAcademyIE(username='my_username', password='my_password')
        IE._login()
        assert IE._download_webpage(
            'https://linuxacademy.com/cp/login/tokenValidateLogin/token/my_access_token',
            None, 'Downloading token validation page')
    except ExtractorError:
        pass
    # This should raise an error as the constructor fails to log in
    raises = pytest.raises(ExtractorError)
    raises(IE = LinuxAcademyIE())

# Generated at 2022-06-24 12:48:11.439328
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    if ie.IE_NAME != "linuxacademy":
        raise Exception("Invalid IE Name")
    if ie.IE_DESC != "Linux Academy":
        raise Exception("Invalid IE Description")
    if ie.VALID_URL == "":
        raise Exception("Invalid VALID_URL")
    if ie._NETRC_MACHINE != "linuxacademy":
        raise Exception("Invalid NETRC_MACHINE")
    if ie._AUTHORIZE_URL != "https://login.linuxacademy.com/authorize":
        raise Exception("Invalid AUTHORIZE_URL")
    if ie._ORIGIN_URL != "https://linuxacademy.com":
        raise Exception("Invalid ORIGIN_URL")

# Generated at 2022-06-24 12:48:16.073401
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    IE = LinuxAcademyIE()
    assert IE.ie_key() == 'LinuxAcademy', 'LinuxAcademy class must be called LinuxAcademy'
    url = IE._match_id('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    assert url == '1498-2', 'The url found using the _match_id method is not valid'

# Generated at 2022-06-24 12:48:23.517517
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'linuxacademy'
    assert LinuxAcademyIE._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert LinuxAcademyIE._ORIGIN_URL == 'https://linuxacademy.com'
    assert LinuxAcademyIE._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'


# Generated at 2022-06-24 12:48:29.346041
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_cases = [
        ('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2',
         'https://linuxacademy.com/cp/modules/view/id/154'),
        ('https://linuxacademy.com/cp/modules/view/id/1498',
         'https://linuxacademy.com/cp/modules/view/id/154')
    ]
    for test in test_cases:
        test_url = test[0]
        expected_course_path = test[1]
        le = LinuxAcademyIE()
        actual_course_path = le._get_course_path(test_url)

# Generated at 2022-06-24 12:48:30.058573
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE(None)

# Generated at 2022-06-24 12:48:30.650670
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE

# Generated at 2022-06-24 12:48:41.261839
# Unit test for constructor of class LinuxAcademyIE

# Generated at 2022-06-24 12:48:46.723307
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    In this test case, we do not check for the downloading of actual data
    as that requires login.
    Instead we check if the constructor of the LinuxAcademyIE class
    works correctly.
    """
    from ..test import _TEST_INSTANCES_NUMBER
    for test_number in range(_TEST_INSTANCES_NUMBER):
        LinuxAcademyIE()

# Generated at 2022-06-24 12:48:47.792505
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:48:49.534521
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._CLIENT_ID != ''

# Generated at 2022-06-24 12:48:51.222135
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:48:52.298757
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE._login()

# Generated at 2022-06-24 12:48:53.362415
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:48:55.434290
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():

    # when
    inst = LinuxAcademyIE()

    # then
    assert inst is not None

# Generated at 2022-06-24 12:48:58.695215
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._real_initialize() is None
    # Need a login to pass the test
    #assert ie._login() is None

# Generated at 2022-06-24 12:49:09.141254
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    email = 'foo@bar.com'
    password = 'bar'
    # expected url for uploading

# Generated at 2022-06-24 12:49:17.080109
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_input1 = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    test_output1 = LinuxAcademyIE(test_input1)
    assert test_output1 is not None

    test_input2 = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    test_output2 = LinuxAcademyIE(test_input2)
    assert test_output2 is not None

    test_input3 = 'https://linuxacademy.com/cp/modules/view/id/154'
    test_output3 = LinuxAcademyIE(test_input3)
    assert test_output3 is not None

# Generated at 2022-06-24 12:49:27.524496
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert obj.IE_NAME == 'linuxacademy'
    assert obj._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'
    if obj._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx':
        assert obj._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
        assert obj._ORIGIN_URL == 'https://linuxacademy.com'
       

# Generated at 2022-06-24 12:49:28.531702
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('LinuxAcademy')

# Generated at 2022-06-24 12:49:29.551397
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE().name == 'LinuxAcademy'

# Generated at 2022-06-24 12:49:36.597261
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._VALID_URL == (
        r'https?://(?:www\.)?linuxacademy\.com/cp/'
        r'(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|'
        r'modules/view/id/(?P<course_id>\d+))')

# Generated at 2022-06-24 12:49:48.176260
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():  # pylint: disable=missing-function-docstring
    # This test is an example of extracting information from a webpage
    # The webpage is "https://linuxacademy.com/cp/modules/view/id/154"
    # The webpage contains information about the course named "AWS Certified Cloud Practitioner"
    # The output is a log of the information extracted from the webpage
    x = LinuxAcademyIE()
    x._login()
    wp = x._download_webpage(
        'https://linuxacademy.com/cp/modules/view/id/154',
        '154',
    )
    m = re.search(r'window\.module\s*=\s*({.+?})\s*;', wp)
    assert m is not None

# Generated at 2022-06-24 12:49:53.323671
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    new_LinuxAcademyIE = None
    try:
        new_LinuxAcademyIE = LinuxAcademyIE()
    except Exception as exception:
        assert False, "Could not create LinuxAcademyIE object - exception: " + str(exception)
    assert new_LinuxAcademyIE is not None


# Generated at 2022-06-24 12:49:56.014970
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None, {'username': 'foo_user', 'password': 'foo_pwd'})



# Generated at 2022-06-24 12:50:05.228152
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.IE_DESC == 'Linux Academy'
    assert ie._VALID_URL == ie.VALID_URL
    assert ie._NETRC_MACHINE == ie.NETRC_MACHINE
    assert ie._AUTHORIZE_URL == ie.AUTHORIZE_URL
    assert ie._ORIGIN_URL == ie.ORIGIN_URL
    assert ie._CLIENT_ID == ie.CLIENT_ID
    assert ie._TESTS == ie.TESTS
    assert ie == globals()['LinuxAcademyIE']()
    assert ie.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:50:11.923549
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # This function is called from test_main() with argument None
    # Must return a dictionary with information about extracted video
    course_name = 'AWS Certified Cloud Practitioner'
    expected_count = 2
    expected_titles = [
        'AWS Certified Cloud Practitioner - Course Introduction',
        'AWS Certified Cloud Practitioner - Module 1 - Introduction to AWS']
    actual_results = {}
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    course_id = '154'
    ie = LinuxAcademyIE()
    actual_results = ie._real_extract(url)
    actual_count = len(actual_results['entries'])
    actual_titles = [entry['title'] for entry in actual_results['entries']]

    # Verify the result for

# Generated at 2022-06-24 12:50:15.615479
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test constructor of class LinuxAcademyIE
    LinuxAcademyIE(LinuxAcademyIE.ie_key())

# Generated at 2022-06-24 12:50:17.975304
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Check if the constructor of LinuxAcademyIE is working.

    It should always pass.

    TODO: Improve the check
    """
    ie = LinuxAcademyIE()

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:50:20.578514
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-24 12:50:21.721094
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE

# Generated at 2022-06-24 12:50:29.037259
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    x = LinuxAcademyIE()
    assert x._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert x._ORIGIN_URL == 'https://linuxacademy.com'
    assert x._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert x._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:50:30.929761
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test import get_testcases
    for case in get_testcases(LinuxAcademyIE):
        yield case

# Generated at 2022-06-24 12:50:34.973795
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.suitable(LinuxAcademyIE._build_url_result(LinuxAcademyIE._VALID_URL, {}))
    assert not LinuxAcademyIE.suitable(LinuxAcademyIE._build_url_result("https://linuxacademy.com/", {}))


# Generated at 2022-06-24 12:50:43.810334
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test case for one single video
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    result = LinuxAcademyIE()._real_extract(url)
    assert result['id'] == '7971-2'
    assert result['duration'] == 304
    assert result['timestamp'] == 1607387907
    # Test case for a course
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    result = LinuxAcademyIE()._real_extract(url)
    assert result['id'] == '154'
    assert result['entries'][0]['id'] == '154-1046'

# Generated at 2022-06-24 12:50:44.814164
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()

# Generated at 2022-06-24 12:50:52.981262
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test pre-defined values
    assert LinuxAcademyIE._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert LinuxAcademyIE._NETRC_MACHINE == 'linuxacademy'
    assert LinuxAcademyIE._ORIGIN_URL == 'https://linuxacademy.com'
    assert LinuxAcademyIE._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'

    # Test values generated from others

# Generated at 2022-06-24 12:51:02.720972
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    "Unit test for LinuxAcademyIE"
    # Test get_course_id
    la = LinuxAcademyIE()
    course_url = "https://linuxacademy.com/cp/modules/view/id/154"
    course_id = la._match_id(course_url)
    assert course_id == "154"
    # Test get_lesson_id
    chapter_url = "https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675"
    lesson_id = la._match_id(chapter_url)
    assert lesson_id == "7971-2"

# Generated at 2022-06-24 12:51:14.087161
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test the static methods
    assert LinuxAcademyIE.ie_key() == "LinuxAcademy"
    assert LinuxAcademyIE.suitable('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    assert LinuxAcademyIE.suitable('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2') == False
    assert LinuxAcademyIE.suitable('https://linuxacademy.com/cp/modules/view/id/154') == True
    assert LinuxAcademyIE.suitable('https://linuxacademy.com/cp/modules/view/id/154/') == False

# Generated at 2022-06-24 12:51:15.489398
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import requests
    LinuxAcademyIE(requests.Session(),'','','','')

# Generated at 2022-06-24 12:51:17.803056
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

if __name__ == "__main__":
    import unittest
    unittest.main()

# Generated at 2022-06-24 12:51:19.839164
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Run tests only if network connection is available
    LinuxAcademyIE()

# Generated at 2022-06-24 12:51:29.022367
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert(ie.ie_key() == 'LinuxAcademy')
    assert(ie._VALID_URL == ('https?://(?:www\\.)?linuxacademy\\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|modules/view/id/(?P<course_id>\\d+))'))
    assert(ie._NETRC_MACHINE == 'linuxacademy')
    assert(ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize')
    assert(ie._ORIGIN_URL == 'https://linuxacademy.com')

# Generated at 2022-06-24 12:51:30.907091
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # No need to test since it's only a subclassed IE
    assert True is True

# Generated at 2022-06-24 12:51:32.988537
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    LinuxAcademyIE('https://linuxacademy.com/cp/modules/view/id/154')

# Generated at 2022-06-24 12:51:37.734338
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test that exception is raised if username and password are not provided
    linuxacademy_ie = LinuxAcademyIE()
    linuxacademy_ie._login()
    linuxacademy_ie._real_initialize()
    assert linuxacademy_ie._downloader.password_manager._netrc_machine  == 'linuxacademy'

# Generated at 2022-06-24 12:51:39.128353
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxAcademy = LinuxAcademyIE()

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:51:41.492850
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Arrange
    # Act
    a = LinuxAcademyIE()
    # Assert
    assert a
    assert a.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:51:44.652182
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademy_ie = LinuxAcademyIE()
    assert len([item for item in linuxacademy_ie.ie._ies if item.IE_NAME == 'LinuxAcademy']) == 1

# Generated at 2022-06-24 12:51:54.909942
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_cases = [
        {
            'url': 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
            'item_id': '7971-2',
            'm3u8_url': 'https://media.linuxacademy.com/media/course/src/7/7971/7971-2-hls/7971-2.m3u8',
        },
        {
            'url': 'https://linuxacademy.com/cp/modules/view/id/154',
            'item_id': '154',
        },
    ]

# Generated at 2022-06-24 12:51:59.925092
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = "https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675"
    lesson_id = "7971-2"
    browser = LinuxAcademyIE()
    web_page = browser._download_webpage(url,lesson_id)


# Generated at 2022-06-24 12:52:05.408997
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Unit test for constructor of class LinuxAcademyIE
    """
    test_cases = [
        ("""https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675""",)
    ]
    for url in test_cases:
        LinuxAcademyIE()._login()

# Generated at 2022-06-24 12:52:06.145650
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()
    return

# Generated at 2022-06-24 12:52:06.899006
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:52:11.098765
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # url is a valid url of LinuxAcademyIE
    url = "https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2"
    ie = LinuxAcademyIE(url)
    ie._real_initialize()
    assert(isinstance(ie, LinuxAcademyIE))

# Generated at 2022-06-24 12:52:12.039854
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:52:13.230991
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert isinstance(LinuxAcademyIE(), InfoExtractor)

# Generated at 2022-06-24 12:52:14.057593
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    return LinuxAcademyIE(None)

# Generated at 2022-06-24 12:52:16.856696
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie=LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)
    ie._login()


# Generated at 2022-06-24 12:52:18.377545
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    IE = LinuxAcademyIE()
    IE.initialize()

# Generated at 2022-06-24 12:52:29.165201
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert(ie._NETRC_MACHINE == 'linuxacademy')
    assert(ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize')
    assert(ie._ORIGIN_URL == 'https://linuxacademy.com')
    assert(ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx')

# Generated at 2022-06-24 12:52:34.496287
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE();
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie._LOGIN_INFO, tuple)
    assert isinstance(ie._AUTHORIZE_URL, str)
    assert isinstance(ie._ORIGIN_URL, str)
    assert isinstance(ie._CLIENT_ID, str)
    assert isinstance(ie._NETRC_MACHINE, str)


# Generated at 2022-06-24 12:52:39.826120
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ext = LinuxAcademyIE()
    ext._login()
    ext._real_extract(test_LinuxAcademyIE._TESTS[0]['url'])
    ext._real_extract(test_LinuxAcademyIE._TESTS[1]['url'])
    ext._real_extract(test_LinuxAcademyIE._TESTS[2]['url'])

# Generated at 2022-06-24 12:52:40.391816
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-24 12:52:41.389085
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()()

# Generated at 2022-06-24 12:52:43.022236
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_shared import YoutubeIE
    YoutubeIE.test_linux_academy()

# Generated at 2022-06-24 12:52:53.576795
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print("Unit test for constructor of class LinuxAcademyIE...")
    laie = LinuxAcademyIE()
    assert laie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )'''
    print("Finish unit test for constructor of class LinuxAcademyIE...")

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:52:55.094109
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    a = LinuxAcademyIE()
    a._NETRC_MACHINE = 'linuxacademy'
    a._real_initialize()

# Generated at 2022-06-24 12:53:02.384827
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE('LinuxAcademy', None)

    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    mobj = re.match(ie._VALID_URL, url)
    chapter_id, lecture_id, course_id = mobj.group('chapter_id', 'lesson_id', 'course_id')
    item_id = course_id if course_id else '%s-%s' % (chapter_id, lecture_id)
    webpage = ie._download_webpage(url, item_id)


# Generated at 2022-06-24 12:53:10.082671
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    test_url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    # Verify that LinuxAcademyIE can be instantiated.
    assert isinstance(instance, LinuxAcademyIE)
    # Verify that LinuxAcademyIE matches given test_url.
    assert re.match(instance._VALID_URL, test_url)
    # Verify that LinuxAcademyIE._real_initialize raises ExtractorError
    # when username is not given.
    instance.username = None
    instance.password = None
    with pytest.raises(ExtractorError):
        instance._real_initialize()
    # Verify that LinuxAcademyIE._real_initialize raises ExtractorError
    # when password is

# Generated at 2022-06-24 12:53:10.740315
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    _ = LinuxAcademyIE(InfoExtractor);

# Generated at 2022-06-24 12:53:11.877467
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None, None)

# Generated at 2022-06-24 12:53:13.381231
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(InfoExtractor())._login()

# Generated at 2022-06-24 12:53:14.896841
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    return LinuxAcademyIE()

# Generated at 2022-06-24 12:53:16.415881
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('LinuxAcademy', 'linuxacademy')

# Generated at 2022-06-24 12:53:18.107234
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert(instance.ie_key() == 'LinuxAcademy')

# Generated at 2022-06-24 12:53:19.021976
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:53:25.641458
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():

    # Setup for unit test
    testUrl = 'https://linuxacademy.com/cp/modules/view/id/154/'
    expected_id = '154'
    expected_title = 'AWS Certified Cloud Practitioner'
    expected_duration = 28835

    # Initialize extractor and verify title, id and duration
    extractor = LinuxAcademyIE()._real_initialize()
    assert extractor._download_webpage(testUrl).find(expected_title) != -1
    assert extractor._real_extract(testUrl)['id'] == expected_id
    assert extractor._real_extract(testUrl)['duration'] == expected_duration

# Generated at 2022-06-24 12:53:27.367276
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('https://linuxacademy.com/cp/modules/view/id/154')

# Generated at 2022-06-24 12:53:34.971535
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        import netrc
    except ImportError:
        raise ImportError('LinuxAcademyIE requires netrc library')
    try:
        netrc_data = netrc.netrc()
        info = netrc_data.authenticators('linuxacademy')
    except (netrc.NetrcParseError, IOError):
        raise ExtractorError('You must set your Linux Academy credentials in .netrc')
    assert info is not None
    LinuxAcademyIE('linuxacademy', 'LinuxAcademyIE')._login()

# Generated at 2022-06-24 12:53:40.767298
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    constr = LinuxAcademyIE

    assert(constr.suitable(
        'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    ))

    assert(constr.suitable('https://linuxacademy.com/cp/modules/view/id/154'))

    assert(not constr.suitable('https://linuxacademy.com/cp/courses'))

# Generated at 2022-06-24 12:53:46.699728
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademy_ie = LinuxAcademyIE()
    try:
        linuxacademy_ie._login()
    except ExtractorError as e:
        if not isinstance(
                e.cause,
                compat_HTTPError) or e.cause.code != 401:
            raise

test_LinuxAcademyIE()

# Generated at 2022-06-24 12:53:47.557945
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie is not None

# Generated at 2022-06-24 12:53:54.745910
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test = LinuxAcademyIE('LinuxAcademy').test_login()
    if test:
        print('video_id: ' + test['id'])
        print('title: ' + test['title'])
        print('description: ' + test['description'])
        print('duration: ' + test['duration'])
        print('timestamp: ' + test['timestamp'])
        if 'chapter' in test:
            print('chapter: ' + test['chapter'])
        if 'chapter_number' in test:
            print('chapter_number: ' + test['chapter_number'])
        print('video_url: ' + test['formats'][0]['url'])
        print('\n')
    else:
        print('Failed to login')


if __name__ == '__main__':
    test

# Generated at 2022-06-24 12:53:56.066775
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()

# Generated at 2022-06-24 12:53:58.049760
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    e = LinuxAcademyIE()
    r = e.IE_NAME
    assert r == 'LinuxAcademy'

# Generated at 2022-06-24 12:54:00.272571
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:54:10.414748
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-24 12:54:17.909969
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(None)
    assert ie.AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie.ORIGIN_URL == 'https://linuxacademy.com'
    assert ie.CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie.NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:54:19.981611
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademyie = LinuxAcademyIE()
    assert linuxacademyie._CLIENT_ID

# Generated at 2022-06-24 12:54:21.929843
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie_linuxacademy = LinuxAcademyIE()
    assert(ie_linuxacademy.parameters()['name'] == 'linuxacademy')

# Generated at 2022-06-24 12:54:23.299123
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:54:24.431238
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE('')
    assert obj

# Generated at 2022-06-24 12:54:28.848462
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    cur_ie = LinuxAcademyIE()
    assert(cur_ie.suitable('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'))
    assert(cur_ie.suitable('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'))
    assert(cur_ie.suitable('https://linuxacademy.com/cp/modules/view/id/154'))

# Generated at 2022-06-24 12:54:29.709934
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie

# Generated at 2022-06-24 12:54:30.626792
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = LinuxAcademyIE()
    assert url

# Generated at 2022-06-24 12:54:31.614965
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert isinstance(LinuxAcademyIE, type)

# Generated at 2022-06-24 12:54:41.856642
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test parsing of a playlist
    linuxacademy_ie = LinuxAcademyIE()
    course_id = '154'
    parsed_course = linuxacademy_ie._real_extract('https://linuxacademy.com/cp/modules/view/id/' + course_id)
    # Check that the playlist has the expected number of lectures
    real_number_of_lectures = 41
    actual_number_of_lectures = len(parsed_course.get('entries'))
    assert actual_number_of_lectures == real_number_of_lectures, 'Course %s actually has %d lectures instead of %d' % (course_id, actual_number_of_lectures, real_number_of_lectures)

# Generated at 2022-06-24 12:54:49.902286
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(None)
    assert ie._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert ie._TESTS == [{'only_matching': True, 
                          'url': 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'}]
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-24 12:54:56.570160
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    ie = LinuxAcademyIE()
    assert ie.ie_key() == LinuxAcademyIE.ie_key()
    assert ie.suitable(url)
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.VALID_URL == LinuxAcademyIE._VALID_URL
    assert ie.TEST == LinuxAcademyIE._TESTS

# Generated at 2022-06-24 12:54:57.129534
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:54:57.997908
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
    except:
        assert False

# Generated at 2022-06-24 12:55:02.474403
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Default case
    extractor = LinuxAcademyIE({})
    assert extractor._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert extractor._NETRC_MACHINE == 'linuxacademy'

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:55:04.416918
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert(LinuxAcademyIE()._NETRC_MACHINE == 'linuxacademy')

# Generated at 2022-06-24 12:55:16.481497
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-24 12:55:17.879614
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE('LinuxAcademy')._VALID_URL

# Generated at 2022-06-24 12:55:19.377105
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(LinuxAcademyIE._download_webpage, None, None)

# Generated at 2022-06-24 12:55:21.208268
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)

# Generated at 2022-06-24 12:55:24.847038
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # unit test case for constructor of class LinuxAcademyIE
    IE = LinuxAcademyIE()
    assert isinstance(IE, LinuxAcademyIE), "Unit test case for constructor of class LinuxAcademyIE has failed"

# Generated at 2022-06-24 12:55:26.591720
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie
    assert ie._CLIENT_ID
    assert ie._NETRC_MACHINE
    assert ie._ORIGIN_URL
    assert ie._AUTHORIZE_URL

# Generated at 2022-06-24 12:55:27.508737
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:55:28.987770
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert instance.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:55:31.072197
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    LinuxAcademyIE.supertube(url)

# Generated at 2022-06-24 12:55:32.272664
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None)

# Generated at 2022-06-24 12:55:37.287103
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.ie_key() in LinuxAcademyIE.ie_key()
    assert ie.domain() == 'linuxacademy.com'
    assert ie.domain() in LinuxAcademyIE.ie_key()

# Generated at 2022-06-24 12:55:43.535737
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Case: invalid url
    invalid_url = 'http://example.com/25472?bla=lol&foo=bar'
    assert not LinuxAcademyIE._VALID_URL.match(invalid_url)

    # Case: valid url
    valid_url = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    assert LinuxAcademyIE._VALID_URL.match(valid_url)


# Generated at 2022-06-24 12:55:44.375607
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE is not None

# Generated at 2022-06-24 12:55:45.545915
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:55:47.072293
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try_get(test_LinuxAcademyIE, lambda x: x == 'test')

# Generated at 2022-06-24 12:55:49.194827
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE(None)
    except Exception as e:
        print(e)



# Generated at 2022-06-24 12:56:00.572518
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert obj._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?linuxacademy\.com/cp/
                            (?:
                                courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                                modules/view/id/(?P<course_id>\d+)
                            )
                        '''
    assert obj._TESTS[0]['url'] == 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    assert obj._TESTS[0]['info_dict']['id'] == '7971-2'
    assert obj._TESTS

# Generated at 2022-06-24 12:56:06.699816
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:56:14.004840
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    info_dict = {
        'id': '154',
        'title': 'AWS Certified Cloud Practitioner',
        'description': 'md5:a68a299ca9bb98d41cca5abc4d4ce22c',
        'duration': 28835,
    }
    playlist_count = 41
    LinuxAcademyIE()._real_extract(url)

# Generated at 2022-06-24 12:56:17.854078
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # check if LinuxAcademyIE was initialized with correct _NETRC_MACHINE and _CLIENT_ID
    video_url = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    instance = LinuxAcademyIE()
    assert instance._NETRC_MACHINE == 'linuxacademy'
    assert instance._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    # check if LinuxAcademyIE raise exception without credentials
    with pytest.raises(ExtractorError):
        instance._real_extract(video_url)

# Generated at 2022-06-24 12:56:19.301756
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:56:28.452894
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    URL_Base= 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    URL_Base_2= 'https://linuxacademy.com/cp/modules/view/id/154'


# Generated at 2022-06-24 12:56:39.844701
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert 'linuxacademy.com' in ie.VALID_URL
    assert 'linuxacademy.com' in ie.IE_DESC
    assert ie._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-24 12:56:45.998340
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    params = {
        'username': 'sduser',
        'password': 'sduserPWDGoesHere'
    }
    ie = LinuxAcademyIE(*params)
    assert ie._TEST == params
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-24 12:56:47.032744
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()


# Generated at 2022-06-24 12:56:52.959960
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'linuxacademy'
    assert LinuxAcademyIE.ie_key(url='https://linuxacademy.com/cp/modules/view/id/154') == 'linuxacademy'
    assert LinuxAcademyIE.ie_key(url='https://linuxacademy.com/test') != 'linuxacademy'

# Generated at 2022-06-24 12:56:56.662696
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    LinuxAcademyIE('https://linuxacademy.com/cp/modules/view/id/154')

# Generated at 2022-06-24 12:56:57.341350
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print(LinuxAcademyIE())

# Generated at 2022-06-24 12:56:58.597482
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # should raise ExtractorError with error message
    # that says: 'requires Linux Academy credentials'
    IE = LinuxAcademyIE()

# Generated at 2022-06-24 12:57:03.149710
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # pylint: disable=protected-access
    linuxAcademyIE = LinuxAcademyIE('linuxAcademy', 'LinuxAcademy')
    assert linuxAcademyIE.username is None
    assert linuxAcademyIE.password is None

    # Testing a valid URL using _VALID_URL property of class LinuxAcademyIE
    test_url = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    # pylint: disable=protected-access
    assert linuxAcademyIE._VALID_URL == test_url

# Generated at 2022-06-24 12:57:04.744249
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    return LinuxAcademyIE({})

# Generated at 2022-06-24 12:57:06.695694
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE.suites = ['test']
    return True

# Generated at 2022-06-24 12:57:07.731269
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE().ie_key()

# Generated at 2022-06-24 12:57:13.241539
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    input_values = ['https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2',
                    'https://linuxacademy.com/cp/modules/view/id/154']
    for input_value in input_values:
        try:
            assert LinuxAcademyIE(input_value)
        except Exception:
            assert False
    assert True

# Generated at 2022-06-24 12:57:15.080711
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademy_ie = LinuxAcademyIE()
    assert linuxacademy_ie is not None

# Generated at 2022-06-24 12:57:17.310781
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy = LinuxAcademyIE()
    ie = linux_academy
    assert ie.get_real_ie() == LinuxAcademyIE

# Generated at 2022-06-24 12:57:18.362546
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    constructor_test(LinuxAcademyIE)


# Generated at 2022-06-24 12:57:19.536977
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:57:23.721782
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    try:
        userName,password = ie._get_login_info()
        ie._login()
    except ExtractorError as e:
        print('No fetch because: %s' % (e.cause))
        return

# Generated at 2022-06-24 12:57:24.500566
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:57:26.569600
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Running the test for an instance of the class
    assert isinstance(LinuxAcademyIE(), InfoExtractor)

# Generated at 2022-06-24 12:57:30.240862
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test without login
    ie = LinuxAcademyIE()
    assert ie._download_webpage_handle.__name__ == '_download_webpage_handle'
    # Test with login
    ie = LinuxAcademyIE(username='', password='')
    assert ie._download_webpage_handle.__name__ == '_real_initialize'