

# Generated at 2022-06-24 12:47:31.280378
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info = LinuxAcademyIE()
    assert info.IE_NAME == 'linuxacademy'

# Generated at 2022-06-24 12:47:32.408430
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None)

# Generated at 2022-06-24 12:47:43.769317
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'
    assert ie._TESTS.__class__ is list
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-24 12:47:45.646958
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)

# Generated at 2022-06-24 12:47:47.773685
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print(LinuxAcademyIE())

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:47:50.696792
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ctor_name = LinuxAcademyIE.__name__
    ctor = getattr(LinuxAcademyIE, ctor_name)

    assert ctor == LinuxAcademyIE

# Generated at 2022-06-24 12:47:52.033576
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:47:56.286809
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        assert LinuxAcademyIE.ie_key() != 'linuxacademy'
    except AssertionError as exc:
        raise AssertionError('Please do not change the value returned by '
                             'LinuxAcademyIE.ie_key()') from exc

    LinuxAcademyIE(None)

# Generated at 2022-06-24 12:48:02.856637
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_linux_academy import test_linux_academy_login
    from .test_linux_academy import test_linux_academy_login_correct
    from .test_linux_academy import test_linux_academy_login_incorrect

    # For positive test cases,
    # initialize LinuxAcademyIE class
    test_linux_academy_login_correct(LinuxAcademyIE)
    # For negative test cases,
    # initialize LinuxAcademyIE class
    test_linux_academy_login_incorrect(LinuxAcademyIE)
    # For default test cases,
    # initialize LinuxAcademyIE class
    test_linux_academy_login(LinuxAcademyIE)

# Generated at 2022-06-24 12:48:05.054693
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_linuxacademy import TestLinuxAcademy
    return TestLinuxAcademy('LinuxAcademy.com').run()

# Generated at 2022-06-24 12:48:06.081787
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:48:10.952952
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert instance.suitable('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    assert not instance.suitable('https://linuxacademy.com/cp/modules/view/id/154')

# Generated at 2022-06-24 12:48:17.256377
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # create an object of LinuxAcademyIE
    la = LinuxAcademyIE()
    # try to login
    username = 'YOUR_USER_NAME'
    password = 'YOUR_PASSWORD'
    la._login(username, password)
    # create mock value
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    m3u8_url = 'https://d3xt5qkhiqx5x5.cloudfront.net/prod/875261/7971-2/mp4/7971-2_1.m3u8'

    if not la.is_logged_in():
        return None
    # extract the content

# Generated at 2022-06-24 12:48:27.080619
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert(LinuxAcademyIE('LinuxAcademy', 'linuxacademy').ie_key() == 'LinuxAcademy')
    assert(LinuxAcademyIE('LinuxAcademy', 'linuxacademy').ie_key() != 'youtube')
    assert(LinuxAcademyIE('LinuxAcademy', 'linuxacademy')._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx')
    assert(LinuxAcademyIE('LinuxAcademy', 'linuxacademy')._NETRC_MACHINE == 'linuxacademy')
    assert(LinuxAcademyIE('LinuxAcademy', 'linuxacademy')._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize')

# Generated at 2022-06-24 12:48:30.261305
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    example = ("https://linuxacademy.com/cp/courses/lesson/course/1498/"
               "lesson/2")
    ie = LinuxAcademyIE()
    assert ie.suitable(example)
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.VALID_URL == LinuxAcademyIE._VALID_URL
    assert ie.url_result(example)

# Generated at 2022-06-24 12:48:32.044214
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    ie._real_initialize()
    print("Successful initialisation")

# Generated at 2022-06-24 12:48:33.356165
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE(): return

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:48:35.185476
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    l = LinuxAcademyIE()
    assert l
    assert l.IE_NAME == 'linuxacademy'

# Generated at 2022-06-24 12:48:36.463691
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()


# Generated at 2022-06-24 12:48:41.810821
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    for url in [
        # course
        'https://linuxacademy.com/cp/modules/view/id/154',
        # lesson
        'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2',
    ]:
        LinuxAcademyIE._downloader = None
        LinuxAcademyIE(url)

# Generated at 2022-06-24 12:48:43.118366
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert(LinuxAcademyIE().ie_key() == 'LinuxAcademy' )

# Generated at 2022-06-24 12:48:44.371591
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:48:45.446718
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None, None)

# Generated at 2022-06-24 12:48:52.858094
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    def _hidden_inputs(html_text):
        return re.findall(r'<input[^>]+type="hidden"[^>]+>', html_text)
    from .test_linuxacademy import course_page
    course_page_hidden_inputs = _hidden_inputs(course_page)
    assert len(course_page_hidden_inputs) == 1
    assert 'name="csrfmiddlewaretoken"' in course_page_hidden_inputs[0]

# Generated at 2022-06-24 12:48:58.747533
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    '''
    Test if the constructor of LinuxAcademyIE class raises a missing credentials exception or not
    '''
    # Test if the constructor raises a missing credentials exception
    try:
        LinuxAcademyIE(None, None)._login()
        assert False
    except ExtractorError as e:
        assert 'Linux Academy account credentials are missing' in str(e)

# Generated at 2022-06-24 12:48:59.778974
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    constructor = LinuxAcademyIE

# Generated at 2022-06-24 12:49:01.176687
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.login() is False

# Generated at 2022-06-24 12:49:03.249722
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE('test', 'LinuxAcademy', 'LinuxAcademy')
    ie.login()
    print(ie.info())

# Generated at 2022-06-24 12:49:05.207060
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    lae = LinuxAcademyIE()
    lae._real_initialize()
    assert isinstance(lae, LinuxAcademyIE)

# Generated at 2022-06-24 12:49:13.469286
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # No need to test the module, if _extract_url() and _real_extract() fails
    # the module is going to fail anyways.
    assert LinuxAcademyIE._valid_url('', {}) is False
    assert LinuxAcademyIE._valid_url('', {'url': ''}) is False
    assert LinuxAcademyIE._valid_url('', {'url': 'https://linuxacademy.com/cp/modules/view/id/154'}) is True
    assert LinuxAcademyIE._valid_url('', {'url': 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'}) is True

# Generated at 2022-06-24 12:49:19.925801
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import sys
    import os
    import subprocess
    try:
        from subprocess import DEVNULL # py3k
    except ImportError:
        DEVNULL = open(os.devnull, 'wb')
    rel_file_path = "test_LinuxAcademyIE.mkv"
    proc = subprocess.Popen(['youtube-dl', '--test-id', 'https://linuxacademy.com/cp/modules/view/id/154'], stdout=DEVNULL, stderr=subprocess.PIPE);
    out, err = proc.communicate()
    regex = re.compile("^\[download\] Destination: " + rel_file_path);
    if(proc.returncode != 0):
        sys.exit("Error: " + err.decode("utf-8"));
   

# Generated at 2022-06-24 12:49:21.199290
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('https://linuxacademy.com/cp/modules/view/id/154')

# Generated at 2022-06-24 12:49:31.197975
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE('LinuxAcademy')
    assert(obj._VALID_URL == "(?x)https?://(?:www\\.)?linuxacademy\\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|modules/view/id/(?P<course_id>\\d+))")
    assert(obj._AUTHORIZE_URL == "https://login.linuxacademy.com/authorize")
    assert(obj._ORIGIN_URL == "https://linuxacademy.com")
    assert(obj._CLIENT_ID == "KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx")

# Generated at 2022-06-24 12:49:34.930631
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(None)
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.ie_key('linuxacademy:lesson') == 'LinuxAcademy'
    assert ie.ie_key('linuxacademy:course') == 'LinuxAcademy'

# Generated at 2022-06-24 12:49:37.365717
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from . import LinuxAcademyIE
    test_object = LinuxAcademyIE.LinuxAcademyIE()
    assert test_object._VALID_URL == LinuxAcademyIE._VALID_URL

# Generated at 2022-06-24 12:49:39.233326
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:49:40.529720
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:49:45.093557
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Simple test to verify that LinuxAcademyIE's constructor method works
    """
    # Construct an instance of LinuxAcademyIE
    linuxacademy_ie = LinuxAcademyIE()
    # Test the _real_initialize method
    linuxacademy_ie._real_initialize()


# Generated at 2022-06-24 12:49:53.687410
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # We don't need to create a LinuxAcademyIE instance to test its constructor.
    # It has no custom functionality yet.
    assert LinuxAcademyIE("LinuxAcademyIE", {
        "ie_key": "LinuxAcademyIE",
        "module": "linuxacademy",
        "title": "Linux Academy",
        "description": "A cloud technology training platform",
        "patterns": [r"(?:https?://)?(?:www\.)?linuxacademy\.com/cp/[^/]+/(?:lesson|modules/view/id)/"]
    })

# Generated at 2022-06-24 12:50:04.622105
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert instance.IE_NAME == 'linuxacademy'
    assert instance._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'
    assert instance._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert instance._ORIGIN_URL == 'https://linuxacademy.com'
    assert instance._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
   

# Generated at 2022-06-24 12:50:05.277224
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:50:07.226474
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Use the constructor with the params (None)
    instance = LinuxAcademyIE(None)

# Test cases according to the documentation in class LinuxAcademyIE

# Generated at 2022-06-24 12:50:08.537690
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    d = LinuxAcademyIE()
    assert d

# Generated at 2022-06-24 12:50:11.136048
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._downloader is not None
    assert ie.username is None
    assert ie.password is None
    assert ie.subscription is False

# Generated at 2022-06-24 12:50:17.176032
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE(None)
    assert obj.__class__.__name__ == LinuxAcademyIE.__name__
    assert obj.ie_key() == 'LinuxAcademy'
    assert obj.ie_name() == 'LinuxAcademy'

# Generated at 2022-06-24 12:50:26.321369
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Not creating a LinuxAcademyIE object
    assert LinuxAcademyIE._VALID_URL == r'^(?P<PROTOCOL>https?)://(?:www\.)?linuxacademy\.com/(?P<TYPE>cp/)(?:(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lecture_id>\d+)|modules/view/id/(?P<course_id>\d+))|(?:videos?/details/id/(?P<video_id>\d+)))$'
    assert LinuxAcademyIE._TESTS[0]['url'] == 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    assert LinuxAcademyIE._T

# Generated at 2022-06-24 12:50:28.014128
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'linuxAcademy'

# Generated at 2022-06-24 12:50:33.501842
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE(None)._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert LinuxAcademyIE(None)._ORIGIN_URL == 'https://linuxacademy.com'
    assert LinuxAcademyIE(None)._NETRC_MACHINE == 'linuxacademy'


# Generated at 2022-06-24 12:50:36.838445
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test import get_testcases
    for tcase in get_testcases(LinuxAcademyIE, [LinuxAcademyIE._VALID_URL], [LinuxAcademyIE._NETRC_MACHINE]):
        yield tcase


# Generated at 2022-06-24 12:50:37.609982
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Check that the constructor works
    temp = LinuxAcademyIE()


# Generated at 2022-06-24 12:50:39.597547
# Unit test for constructor of class LinuxAcademyIE

# Generated at 2022-06-24 12:50:42.043815
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Unit test for constructor of class LinuxAcademyIE
    """
    ie = LinuxAcademyIE()
    assert len(ie._TESTS) != 0

# Generated at 2022-06-24 12:50:44.193083
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'LinuxAcademy', "IE name should be LinuxAcademy"

# Generated at 2022-06-24 12:50:45.974429
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    mocker = Mocker()
    LinuxAcademyIE._login = mocker.Mock()
    LinuxAcademyIE(mocker.Mock())

# Generated at 2022-06-24 12:50:54.199780
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = LinuxAcademyIE._VALID_URL
    mobj = re.match(url, 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    assert(mobj.group('chapter_id') == '7971' and mobj.group('lesson_id') == '2')
    mobj = re.match(url, 'https://linuxacademy.com/cp/modules/view/id/154')
    assert(mobj.group('course_id') == '154')


# Generated at 2022-06-24 12:50:57.822906
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
        assert True
    except EnvironmentError as e:
        assert 'LinuxAcademy account credentials' in str(e)

# Generated at 2022-06-24 12:50:59.393753
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE('LinuxAcademy') == LinuxAcademyIE

# Generated at 2022-06-24 12:51:05.439254
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info = LinuxAcademyIE()
    assert(info._VALID_URL == "https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))")
    assert(info._NETRC_MACHINE == "linuxacademy")

# Generated at 2022-06-24 12:51:12.485777
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test constructor of class LinuxAcademyIE."""
    # url can't be empty
    with pytest.raises(AssertionError):
        LinuxAcademyIE(url='')

    # url must match valid url
    with pytest.raises(ExtractorError):
        LinuxAcademyIE(url='https://linuxacademy.com')

    # url must be a string
    with pytest.raises(AssertionError):
        LinuxAcademyIE(url=123)

    # url must be valid
    with pytest.raises(ExtractorError):
        LinuxAcademyIE(url='https://linuxacademy.com/cp/courses/lesson/course/[*]/lesson/[*]')

# Generated at 2022-06-24 12:51:15.638475
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    x = LinuxAcademyIE()
    assert isinstance(x, LinuxAcademyIE)
    assert x.ie_key() == "LinuxAcademy"

# Generated at 2022-06-24 12:51:16.721185
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:51:26.702916
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    t = LinuxAcademyIE()
    t._login()
    # Test case: passing an URL returns a dictionary with data of the video
    assert 'title' in t._real_extract('https://linuxacademy.com/cp/modules/view/id/154')
    # Test case: passing a bad URL return an error
    with pytest.raises(ExtractorError):
        t._real_extract('https://linuxacademy.com/cp/modules/view/id/1500')
    # Test case: passing an URL for a video returns a dictionary with data of the video
    assert 'title' not in t._real_extract('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')

# Generated at 2022-06-24 12:51:37.340076
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = "https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675"
    info_dict = {
        'id': '7971-2',
        'ext': 'mp4',
        'title': 'What Is Data Science',
        'description': 'md5:c574a3c20607144fb36cb65bdde76c99',
        'timestamp': 1607387907,
        'upload_date': '20201208',
        'duration': 304,
    }
    params = {
        'skip_download': True,
    }
    return LinuxAcademyIE().extract(url, params)

# Generated at 2022-06-24 12:51:42.362455
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import sys
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
    from tests.test_linuxacademy import test_linuxacademy
    test_linuxacademy.test_suite_run(LinuxAcademyIE)


if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:51:44.384144
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademy = LinuxAcademyIE()
    assert  linuxacademy is not None

# Generated at 2022-06-24 12:51:49.081003
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE();
    assert(ie.IE_NAME == 'Linux Academy')

if __name__ == "__main__":
    from test_utils import run_test
    run_test(LinuxAcademyIE)
    run_test(test_LinuxAcademyIE)

# Generated at 2022-06-24 12:51:54.866827
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert 'LinuxAcademy' in ie.IE_NAME
    assert 'linuxacademy' in ie._NETRC_MACHINE
    assert ie._VALID_URL in ie._TESTS[0]['url']
    assert ie._TESTS[1]['only_matching']
    assert ie._AUTHORIZE_URL not in ie._TESTS[0]['url']
    assert 'Linux Academy' in ie.IE_NAME

# Generated at 2022-06-24 12:51:58.724397
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_utils import get_testcases
    for tc in get_testcases(LinuxAcademyIE, {'skip': 'Requires Linux Academy account credentials'}, 'class'):
        tc.fun('test_'+tc.function_name)()

# Generated at 2022-06-24 12:52:07.941195
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .testcases import TestClass
    return TestClass(
        LinuxAcademyIE,
        [{
            '_type': 'url_transparent',
            'url': 'https://linuxacademy.com/cp/modules/view/id/154',
            'info_dict': {
                'id': '154',
                'title': 'AWS Certified Cloud Practitioner',
                'description': 'md5:a68a299ca9bb98d41cca5abc4d4ce22c',
                'duration': 28835,
            },
            'playlist_count': 41,
            'skip': 'Requires Linux Academy account credentials',
        }],
        True
    )

# Generated at 2022-06-24 12:52:09.848486
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        import http.cookiejar
        cj = http.cookiejar.CookieJar()
        LinuxAcademyIE(1,2,cj)
    except ImportError:
        import cookielib
        cj = cookielib.CookieJar()
        LinuxAcademyIE(1,2,cj)

# Generated at 2022-06-24 12:52:15.145963
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._NETRC_MACHINE == 'linuxacademy'
    assert LinuxAcademyIE()._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert LinuxAcademyIE()._ORIGIN_URL == 'https://linuxacademy.com'
    assert LinuxAcademyIE()._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'

# Generated at 2022-06-24 12:52:17.623211
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Following code will fail if constructor of LinuxAcademyIE is not correct
    ie = LinuxAcademyIE(LinuxAcademyIE.ie_key())

# Generated at 2022-06-24 12:52:19.377236
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    template_test(LinuxAcademyIE, lambda ie: ie._VALID_URL)

# Generated at 2022-06-24 12:52:20.503002
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:52:22.551265
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('https://linuxacademy.com/cp/modules/view/id/154')

# Generated at 2022-06-24 12:52:24.586808
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Initialize and call the constructor of class LinuxAcademyIE
    LinuxAcademyIE(None)

# Generated at 2022-06-24 12:52:25.740602
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE() is not None

# Generated at 2022-06-24 12:52:27.001327
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print('test linuxacademy.com')
    LinuxAcademyIE()

# Generated at 2022-06-24 12:52:27.973622
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    return LinuxAcademyIE('LinuxAcademy')

# Generated at 2022-06-24 12:52:29.420918
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info_extractor = LinuxAcademyIE()
    info_extractor._login()

# Generated at 2022-06-24 12:52:30.371438
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:52:35.182868
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Check that the correct InfoExtractor is selected (LinuxAcademyIE class)
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    ie = LinuxAcademyIE(url)
    assert isinstance(ie, LinuxAcademyIE)

# Generated at 2022-06-24 12:52:44.037406
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    class_ = LinuxAcademyIE(None)

    assert_raises_regex = _test_lib.assertRaisesRegex
    assert_raises_regex(TypeError, '__init__\\(\\) takes exactly 2 arguments \(1 given\)$', class_.__init__)

    assert_equal = _test_lib.assertEqual
    assert_equal('linuxacademy', class_._NETRC_MACHINE)

    assert_false = _test_lib.assertFalse
    assert_false(class_._AUTHORIZE_URL is None)
    assert_false(class_._ORIGIN_URL is None)
    assert_false(class_._CLIENT_ID is None)
    assert_false(class_._VALID_URL is None)

# Generated at 2022-06-24 12:52:47.298615
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie._VALID_URL == LinuxAcademyIE._VALID_URL

# Generated at 2022-06-24 12:52:48.967763
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(None)
    ie.login()

# Generated at 2022-06-24 12:52:59.805585
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'

# Generated at 2022-06-24 12:53:00.629638
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:53:03.775407
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('https://www.linuxacademy.com/cp/modules/view/id/154')
    LinuxAcademyIE('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')

# Generated at 2022-06-24 12:53:06.144649
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Given a url find if the IExtractor can handle the url
    """
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    ie = LinuxAcademyIE()
    assert ie.suitable(url)


# Generated at 2022-06-24 12:53:08.367780
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert obj
    urls = obj._VALID_URL
    assert urls
    return

# Generated at 2022-06-24 12:53:09.723725
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # test login without any creds
    LinuxAcademyIE()

# Generated at 2022-06-24 12:53:20.598017
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    opts = {'age_limit': 18}
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'
    assert LinuxAcademyIE._VALID_URL == LinuxAcademyIE.ie_key()
    assert LinuxAcademyIE._NETRC_MACHINE == 'linuxacademy'
    ie = LinuxAcademyIE(opts)
    assert ie._VALID_URL == LinuxAcademyIE._VALID_URL
    assert ie.ie_key() == LinuxAcademyIE.ie_key()
    assert ie._NETRC_MACHINE == LinuxAcademyIE._NETRC_MACHINE
    assert ie.suitable(opts) is True
    assert ie.working() is True
    assert ie._login() is None

# Generated at 2022-06-24 12:53:22.309516
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    # library is not accessible
    assert ie._login() == None

# Generated at 2022-06-24 12:53:25.048624
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_utils import BoundaryTestCase

    class LinuxAcademyTestCase(BoundaryTestCase):
        def setUp(self):
            self.ie = LinuxAcademyIE()

    with LinuxAcademyTestCase(LinuxAcademyIE.__module__) as testcase:
        testcase.run_extractor_tests()

# Generated at 2022-06-24 12:53:31.339763
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:53:38.687257
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    def unit_test_constructor(**kwargs):
        """Test constructor of class LinuxAcademyIE"""
        ie = LinuxAcademyIE(**kwargs)
        # Testing for 'Username' and 'Password' specified in _TESTS
        assert ie._downloader.username == 'YOUTUBE_TEST_USERNAME'
        assert ie._downloader.password == 'YOUTUBE_TEST_PASSWORD'
        # Testing for update of _NETRC_MACHINE
        assert ie._downloader._netrc_machine == 'linuxacademy'

    unit_test_constructor()

# Generated at 2022-06-24 12:53:46.699864
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        #UnitTest for @_login
        #test_LinuxAcademyIE._login(test_LinuxAcademyIE())
        #UnitTest for @_real_extract
        test_LinuxAcademyIE._real_extract(test_LinuxAcademyIE(), "https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675")
    except Exception as e:
        print(e)
#test_LinuxAcademyIE()

# Generated at 2022-06-24 12:53:49.556892
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    ie = LinuxAcademyIE()
    ie.extract(url)

# Generated at 2022-06-24 12:53:52.487673
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():

    # pylint: disable=protected-access
    # pylint: disable=unused-argument

    # Create object of LinuxAcademyIE
    obj = LinuxAcademyIE()

    # Invoke the constructor of LinuxAcademyIE
    obj._real_initialize()

# Generated at 2022-06-24 12:53:54.649261
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'linuxacademy'



# Generated at 2022-06-24 12:53:55.970323
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:53:59.508311
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie_key1 = LinuxAcademyIE.ie_key()
    ie_key2 = LinuxAcademyIE.ie_key()
    assert(ie_key1 != ie_key2)

# Generated at 2022-06-24 12:54:02.753256
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    main_cls = LinuxAcademyIE.ie_key()
    inst = main_cls.working_class()
    inst._real_initialize()


# Generated at 2022-06-24 12:54:04.319606
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    raise NotImplementedError

# Generated at 2022-06-24 12:54:09.852424
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(None)
    assert ie.AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie.ORIGIN_URL == 'https://linuxacademy.com'
    assert ie.CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie.NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:54:10.889638
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:54:12.005823
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # TODO: Add test
    pass

# Generated at 2022-06-24 12:54:23.064934
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    for url in (
            'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
            'https://linuxacademy.com/cp/modules/view/id/154'):
        assert LinuxAcademyIE.suitable(url)
        assert LinuxAcademyIE.suitable(url.upper())
        assert LinuxAcademyIE.suitable(url.lower())
        assert LinuxAcademyIE.suitable(url.capitalize())
        assert LinuxAcademyIE.suitable(url.title())
        assert LinuxAcademyIE.suitable(url.swapcase())
        assert LinuxAcademyIE.suitable(url.replace('//', '////'))

# Generated at 2022-06-24 12:54:28.501070
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    my_LinuxAcademyIE = LinuxAcademyIE()
    if(my_LinuxAcademyIE is not None):
        print("LinuxAcademyIE unit test is passed")

if __name__ == '__main__':
    # Unit test for constructor of class LinuxAcademyIE
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:54:31.076959
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    username, password = LinuxAcademyIE._get_login_info()
    assert isinstance(username, compat_str)
    assert isinstance(password, compat_str)

# Generated at 2022-06-24 12:54:42.082722
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = "https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675"
    inst = LinuxAcademyIE()
    inst._real_initialize()

    resp = inst._download_webpage(url, "7971-2")

    m3u8_url = inst._parse_json(
        inst._search_regex(
            r'player\.playlist\s*=\s*(\[.+?\])\s*;', resp, 'playlist'),
        '7971-2')[0]['file']


# Generated at 2022-06-24 12:54:43.870162
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-24 12:54:45.452231
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == ie.ie_key()
    assert ie.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:54:46.733645
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_DESC == "LinuxAcademy"

# Generated at 2022-06-24 12:54:47.614642
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

# Generated at 2022-06-24 12:54:59.072590
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test = LinuxAcademyIE()
    assert(test._VALID_URL == 'https?://(?:www\\.)?linuxacademy\\.com/cp/\n                        (?:courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|\n                            modules/view/id/(?P<course_id>\\d+)\n                        )')

# Generated at 2022-06-24 12:55:00.494714
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert (isinstance(instance, LinuxAcademyIE))

# Generated at 2022-06-24 12:55:05.423315
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # The access token changes every time
    la_ie = LinuxAcademyIE()
    assert la_ie._CLIENT_ID is not None
    assert la_ie._NETRC_MACHINE is not None
    assert la_ie._AUTHORIZE_URL is not None
    assert la_ie._ORIGIN_URL is not None

# Generated at 2022-06-24 12:55:06.443413
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:55:16.327476
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    # License: CC BY-NC 3.0
    # Copyright: Copyright (C) Linux Academy, Inc. - All Rights Reserved.
    """
    def LinuxAcademyIE__init__(self):
        pass
    LinuxAcademyIE__init__ = LinuxAcademyIE.__init__
    LinuxAcademyIE.__init__ = LinuxAcademyIE__init__
    LinuxAcademyIE('LinuxAcademy',
                   'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    LinuxAcademyIE.__init__ = LinuxAcademyIE__init__

# Generated at 2022-06-24 12:55:27.002453
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-24 12:55:28.391359
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'

# Generated at 2022-06-24 12:55:34.797099
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    '''
    LinuxAcademyIE(InfoExtractor) requires:
        self.username
        self.password
        self.client_id
        self.authorize_url
        self.origin_url
        self.netrc_machine
    '''
    from .test_linuxacademy import _assert_ie_validity
    ie = LinuxAcademyIE('linuxacademy')
    _assert_ie_validity(ie, 'linuxacademy')

# Generated at 2022-06-24 12:55:44.497031
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_object = LinuxAcademyIE(LinuxAcademyIE.ie_key())
    assert(test_object.suitable('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')) is True
    assert(test_object.suitable('https://linuxacademy.com/cp/modules/view/id/154')) is True
    assert(test_object.suitable('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')) is True
    assert(test_object.suitable('https://www.nachdemdie.de/feed/')) is False
    assert(test_object.suitable('https://www.youtube.com/')) is False


# Generated at 2022-06-24 12:55:45.695952
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:55:46.743061
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:55:48.070067
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert instance is not None

# Generated at 2022-06-24 12:55:49.736630
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
	la=LinuxAcademyIE()
	assert la.IE_NAME == "linuxacademy"

# Generated at 2022-06-24 12:55:50.622242
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:55:51.774364
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('LinuxAcademyIE','www.linuxacademy.com')

# Generated at 2022-06-24 12:55:53.408551
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:55:56.401270
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from . import LinuxAcademyIE
    ie = LinuxAcademyIE()
    assert(ie is not None)
    assert(isinstance(ie, LinuxAcademyIE))

# Generated at 2022-06-24 12:55:57.461039
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:55:59.945528
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxAcademy = LinuxAcademyIE()
    assert linuxAcademy.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:56:03.432943
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2'
    ie = LinuxAcademyIE(url)
    assert ie.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:56:04.618024
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
	LinuxAcademyIE(None, None)

# Generated at 2022-06-24 12:56:13.865322
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    test LinuxAcademyIE for a lecture of an online course
    """

    # Check for the linux academy lecture
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    la = LinuxAcademyIE()
    la.extract(url)

    # Check the title
    assert la._TITLE == 'What Is Data Science'

    # Check the description
    assert la._DESCRIPTION == 'Wesley Chun, Instructor of Data Science, explains what data science is and'

    # Check the duration
    assert la._DURATION == 304

# Generated at 2022-06-24 12:56:22.251442
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_obj = LinuxAcademyIE(None)
    assert test_obj._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert test_obj._ORIGIN_URL == 'https://linuxacademy.com'
    assert test_obj._CLIENT_ID =='KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert test_obj._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:56:24.060620
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_linuxacademy import test_extract_linuxacademy
    test_extract_linuxacademy('LinuxAcademyIE', LinuxAcademyIE)

# Generated at 2022-06-24 12:56:25.267740
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:56:27.563552
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'linuxacademy'
    assert LinuxAcademyIE.ie_key() in LinuxAcademyIE.ie_keys()



# Generated at 2022-06-24 12:56:30.638918
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    IE = LinuxAcademyIE()
    assert isinstance(IE, LinuxAcademyIE)
    assert isinstance(IE, InfoExtractor)

# Generated at 2022-06-24 12:56:32.159709
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxAcademy = LinuxAcademyIE();
    assert linuxAcademy is not None

# Generated at 2022-06-24 12:56:41.261439
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL is not None
    assert ie._login() is not None
    assert ie._real_extract("https://linuxacademy.com/cp/modules/view/id/154") is not None
    # Test void of _real_initialize()
    ie = LinuxAcademyIE(username="user", password="12345")
    assert ie._login() is not None
    assert ie._real_extract("https://linuxacademy.com/cp/modules/view/id/154") is not None
    # Test if you not fill in the username and password
    ie = LinuxAcademyIE()
    assert ie._login() is None

# Generated at 2022-06-24 12:56:44.034336
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    if isinstance(instance, LinuxAcademyIE):
        assert(True)



# Generated at 2022-06-24 12:56:45.072048
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:56:47.324721
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.get_testcases_require_login() is True
    print('LinuxAcademyIE tests passed.')

# Generated at 2022-06-24 12:56:49.162901
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:56:50.221625
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_linuxacademy import test_LinuxAcademyIE
    test_LinuxAcademyIE(LinuxAcademyIE())

# Generated at 2022-06-24 12:56:51.236331
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:57:00.657446
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    tester = LinuxAcademyIE()
    assert tester._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'
    assert tester._TESTS[0]['url'] == 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    assert tester._TESTS[0]['info_dict']['id'] == '7971-2'

# Generated at 2022-06-24 12:57:01.511309
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:57:03.043439
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == LinuxAcademyIE.ie_key()



# Generated at 2022-06-24 12:57:04.693458
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()._login()

# Generated at 2022-06-24 12:57:11.566520
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(None)
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:57:17.348133
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-24 12:57:18.135421
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()


# Generated at 2022-06-24 12:57:19.805044
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        a = LinuxAcademyIE()
    except:
        pass

# Generated at 2022-06-24 12:57:25.718465
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Simple test for the constructor of the class LinuxAcademyIE
    """
    assert LinuxAcademyIE.ie_key() == 'linuxacademy'
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademyIE'
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademyIE.ie_key'

# Generated at 2022-06-24 12:57:27.057304
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxAcademy = LinuxAcademyIE()

# Generated at 2022-06-24 12:57:29.074688
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert isinstance(LinuxAcademyIE, type)
    assert issubclass(LinuxAcademyIE, InfoExtractor)