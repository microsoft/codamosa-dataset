

# Generated at 2022-06-24 12:47:33.254960
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
        Class test
    """
    assert LinuxAcademyIE.__name__ == 'LinuxAcademyIE'


# Generated at 2022-06-24 12:47:34.136287
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert isinstance(LinuxAcademyIE(), InfoExtractor)

# Generated at 2022-06-24 12:47:39.857591
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(InfoExtractor(),"http://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675")
    LinuxAcademyIE(InfoExtractor(),"https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675")

# Generated at 2022-06-24 12:47:41.246982
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.class_method_get_login

# Generated at 2022-06-24 12:47:52.387913
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    video_id = '7971-2'
    video_title = 'What Is Data Science'

    url_instance = LinuxAcademyIE(url)
    downloaded_webpage = url_instance._download_webpage(url, video_id)

    assert downloaded_webpage is not None
    assert downloaded_webpage == LinuxAcademyIE._real_extract(url_instance, url)

    m3u8_url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675?format=json'

# Generated at 2022-06-24 12:47:58.129309
# Unit test for constructor of class LinuxAcademyIE

# Generated at 2022-06-24 12:48:00.884915
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
    except:
        assert False
    assert True

# Generated at 2022-06-24 12:48:02.898450
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print("Debug: Test")
    ie = LinuxAcademyIE()
    print(ie)

# Generated at 2022-06-24 12:48:03.916598
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()

# Generated at 2022-06-24 12:48:12.999222
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    file = open('test_cases/test_case_linuxacademyie.json', 'r')
    test_cases = json.loads(file.read())
    file.close()

    for test_case in test_cases:
        video_url = test_case["url"]
        linuxacademy_ie = LinuxAcademyIE(LinuxAcademyIE.ie_key(), LinuxAcademyIE.ie_name())
        info = linuxacademy_ie.extract(video_url)

        assert info['id'] == test_case["id"]
        assert info['title'] == test_case["title"]
        assert info['description'].strip() == test_case["description"].strip()

# Generated at 2022-06-24 12:48:16.747429
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Simple unit test for LinuxAcademyIE.
    """

    unit_test = LinuxAcademyIE( None )
    unit_test.login()

    assert unit_test.username is not None
    assert unit_test.password is not None

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:48:24.806190
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_inputs = [
        (1, "lesson", "Linux Academy", "Movie A", "This is a test movie"),
        (2, "lesson", "Linux Academy", "Movie B", "This is another test movie"),
        (3, "lesson", "Linux Academy", "Movie C", "This is the third test movie"),
        ]

    request_url = "https://linuxacademy.com"

    linuxacademy_ie = LinuxAcademyIE()

    # Test initialization of LinuxAcademyIE object
    assert linuxacademy_ie.get_url() == request_url

# Generated at 2022-06-24 12:48:29.019133
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test for the contructor of class LinuxAcademyIE"""
    ies = [LinuxAcademyIE()]
    assert ies[0]._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-24 12:48:33.728951
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    with open('test/test_data/linuxacademy.com/courses/lesson/course/1498/lesson/2.html') as f:
        data = f.read()
    cout = ie._real_extract('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2', data)
    assert cout['id'] == '1498-2'
    assert cout['title'] == 'Introduction to Digital Forensics'
    assert cout['description'] == 'md5:3c24b856a955dcf6a2e6b0bbc8f7af00'
    assert cout['timestamp'] == 1528467055
    assert cout['duration'] == 724
    assert cout['formats'] is not None


# Generated at 2022-06-24 12:48:42.968632
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    if __name__ == "__main__":
        # Parsing of course URL, playlist count with course_id
        print ("Running test_LinuxAcademyIE")
        LinuxAcademyModule = LinuxAcademyIE()
        test_url = 'https://linuxacademy.com/cp/modules/view/id/154'
        test_playlists = LinuxAcademyModule._real_extract(test_url)
        print (test_playlists)
        assert test_playlists['id'] == '154'
        assert test_playlists['entries'][0]['id'] == '154-1'
        assert len(test_playlists['entries']) == 41


# Generated at 2022-06-24 12:48:47.581557
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('https://linuxacademy.com/cp/courses/lesson/course/5043/lesson/1/module/1584')
    LinuxAcademyIE('https://linuxacademy.com/cp/modules/view/id/154')
    return True

# Generated at 2022-06-24 12:48:53.259375
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == "https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)"
    assert ie._ORIGIN_URL == "https://linuxacademy.com"

# Generated at 2022-06-24 12:48:59.535891
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Creating an instance of class LinuxAcademyIE
    linux_academy_ie = LinuxAcademyIE()
    # Testing whether url of class LinuxAcademyIE is correct or not
    test_url = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    assert linux_academy_ie._VALID_URL == test_url

# Generated at 2022-06-24 12:49:02.797889
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # In order to test this IE, you must provide your credentials in a netrc file
    # with an entry matching _NETRC_MACHINE
    ie = LinuxAcademyIE()
    ie._login()
    assert ie._access_token is not None

# Generated at 2022-06-24 12:49:10.166492
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == '^https?://(?:www\\.)?linuxacademy\\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|modules/view/id/(?P<course_id>\\d+))$'

# Generated at 2022-06-24 12:49:17.831673
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_utils import fake_urlopen

    # Test constructor of class LinuxAcademyIE
    test_class = LinuxAcademyIE()

    # Test for method '_login'
    # Case 1: failed to get access token due to unauthorized error
    test_case_1 = {}
    fake_urlopen_mock_args_1 = test_case_1.setdefault('fake_urlopen_mock_args', {})

# Generated at 2022-06-24 12:49:26.589748
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    newIE = LinuxAcademyIE()
    assert newIE
    assert newIE.ie_key() == 'LinuxAcademy'
    assert newIE._VALID_URL == newIE.VALID_URL
    assert newIE._TESTS  == newIE.TESTS
    assert newIE._AUTHORIZE_URL == newIE.AUTHORIZE_URL
    assert newIE._ORIGIN_URL == newIE.ORIGIN_URL
    assert newIE._CLIENT_ID == newIE.CLIENT_ID
    assert newIE._NETRC_MACHINE == newIE.NETRC_MACHINE
# Constructor End


# Generated at 2022-06-24 12:49:35.377898
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_url = 'https://linuxacademy.com/cp/modules/view/id/205'
    la = LinuxAcademyIE()
    assert la.get_login_info() == (None, None)
    la._login()
    la_course = la.extract(test_url)
    assert la_course['id'] == '205'
    assert len(la_course['entries']) == 7
    assert 'AWS Certified Developer - Associate' in la_course['entries'][0]['title']
    la_video = la.extract(la_course['entries'][0]['url'])
    assert la_video['id'] == '205-13'
    assert la_video['title'] == 'AWS Certified Developer - Associate'

# Generated at 2022-06-24 12:49:39.305363
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    with open('test/testdata/testfile', 'r', encoding='utf-8') as myfile:
        # name a variable to hold the data read
        html = myfile.read()
        # TODO: add more tests
        # test with arguments:
        #  1. url - url of the website to be scraped
        LinuxAcademyIE(html)

# Generated at 2022-06-24 12:49:44.948040
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE == LinuxAcademyIE()

# Main code for testing
r"""
from subprocess import call
call(["python", "-m", "unittest", "linuxacademy.py"])
"""
if __name__ == '__main__':
    # Testing the constructor of class LinuxAcademyIE
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:49:56.849791
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_common import result_fixture
    test_data = [('7971-2', 'What Is Data Science', '7f4ca4b4d7a96566d5b7c5372e2b3448'),
                 ('154', 'AWS Certified Cloud Practitioner', 'a68a299ca9bb98d41cca5abc4d4ce22c')]
    ie = LinuxAcademyIE()
    for vid, name, res in test_data:
        ie.extract('https://linuxacademy.com/cp/courses/lesson/course/{vid}/lesson/2/'.format(vid=vid))
        assert ie._json_ld['title'] == name
        assert ie._url_result['id'] == vid

# Generated at 2022-06-24 12:50:00.865826
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    assert LinuxAcademyIE.suitable(test_url) == True

# Generated at 2022-06-24 12:50:01.882194
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()

# Generated at 2022-06-24 12:50:05.319087
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.name == 'LinuxAcademy'
    assert ie.description == 'Linux Academy Online Training'
    assert ie.ie_key() == 'linuxacademy'
    assert ie.extractor == LinuxAcademyIE

# Generated at 2022-06-24 12:50:17.235353
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import sys
    import json
    from itertools import islice
    from .common import Playlist

    input_filename = sys.argv[1]
    input_string = open(input_filename).read()
    assert isinstance(input_string, str)
    input_dict = json.loads(input_string)
    assert isinstance(input_dict, dict)
    url = input_dict['url']
    la_ie = LinuxAcademyIE()
    la_ie.initialize()
    output_dict = la_ie.extract(url)
    output_string = json.dumps(output_dict, indent=4)
    output_filename = input_filename + '.out'
    open(output_filename, 'w').write(output_string)

test_LinuxAcademyIE()

# Generated at 2022-06-24 12:50:18.699568
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    instance._login()

# Generated at 2022-06-24 12:50:23.796013
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert obj._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert obj._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert obj._ORIGIN_URL == 'https://linuxacademy.com'


# Generated at 2022-06-24 12:50:25.510149
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None, None).LinuxAcademyIE(None, None)

# Generated at 2022-06-24 12:50:35.632315
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test if the constructor of class LinuxAcademyIE is working."""

    # Ensure the caller is passing in a valid URL
    valid_url = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    invalid_url = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/349830984'
    assert LinuxAcademyIE._VALID_URL.match(valid_url)
    assert LinuxAcademyIE._VALID_URL.match(invalid_url) is None

    # Test if the constructor of class LinuxAcademyIE is working
    extractor = LinuxAcademyIE()
    assert extractor.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:50:37.184073
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('LinuxAcademy', 'en')

# Generated at 2022-06-24 12:50:38.669515
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_courses import test_courses

    test_courses(LinuxAcademyIE)

# Generated at 2022-06-24 12:50:40.253661
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .. import LinuxAcademyIE
    LinuxAcademyIE()

# Generated at 2022-06-24 12:50:49.516987
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    example_data = {
        '_type': 'url_transparent',
        'url': "https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2/module/675",
        'ie_key': LinuxAcademyIE.ie_key(),
        'title': 'What Is Data Science',
        'description': 'md5:c574a3c20607144fb36cb65bdde76c99',
        'timestamp': 1607387907,
        'duration': 304,
    }
    assert LinuxAcademyIE().suitable('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    assert LinuxAcademyIE()._real_extract(example_data['url'])['title'] == example

# Generated at 2022-06-24 12:50:53.977415
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == ie.__class__.__name__
    assert ie.ie_key() == ie.__class__.__name__

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:50:58.200398
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Init class LinuxAcademyIE
    ie = LinuxAcademyIE()
    # Testing get_login_info()
    ie.get_login_info()
    # Testing _login()
    ie._login()

# Generated at 2022-06-24 12:51:01.350711
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.name == 'linuxacademy'
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.host == 'linuxacademy.com'
    assert ie.description

# Generated at 2022-06-24 12:51:04.777362
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url_test = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    LinuxAcademyIE().suitable(url_test)

# Generated at 2022-06-24 12:51:07.050887
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
        assert False
    except:
        assert True
    return


# Generated at 2022-06-24 12:51:07.963486
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:51:17.561159
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.IE_NAME == 'LinuxAcademy'
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert ie.__name__ == 'LinuxAcademy'

# Generated at 2022-06-24 12:51:19.558207
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE([])
    except NameError:
        pass

# Generated at 2022-06-24 12:51:22.796194
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    x = LinuxAcademyIE()
    y = LinuxAcademyIE(password='password')
    z = LinuxAcademyIE(username='username')
    assert x
    assert y
    assert z


# Generated at 2022-06-24 12:51:32.198200
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Without any arguments, a LinuxAcademyIE object should be initialized with
    success.

    """
    instance = LinuxAcademyIE()
    assert instance.IE_NAME == 'linuxacademy'
    assert instance._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert instance._NETRC_MACHINE == 'linuxacademy'
    assert instance._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert instance._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-24 12:51:34.710437
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE.ie_key()
    except Exception as e:
        raise Exception(e)


# Generated at 2022-06-24 12:51:44.742254
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instructors = ['Josh Samuelson', 'Michael Spayd']
    course = LinuxAcademyIE.LinuxAcademyCourse(
        'https://linuxacademy.com/cp/modules/view/id/154',
        title='AWS Certified Cloud Practitioner',
        description='md5:a68a299ca9bb98d41cca5abc4d4ce22c',
        duration=28835,
        instructors=instructors)
    assert course.title == 'AWS Certified Cloud Practitioner'
    assert course.description == 'md5:a68a299ca9bb98d41cca5abc4d4ce22c'
    assert course.duration == 28835
    assert course.instructors == instructors

# Generated at 2022-06-24 12:51:54.951196
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    title = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    ie = LinuxAcademyIE()
    # Create an instance of InfoExtractor type
    assert(isinstance(ie, InfoExtractor) )
    # Create an instance of LinuxAcademyIE
    assert(isinstance(ie, LinuxAcademyIE) )
    # Call the method of InfoExtractor that creates an instance of _VALID_URL
    match = LinuxAcademyIE._VALID_URL_RE.match(url)
    # Assert the _VALID_URL created by the _VALID_URL_RE.match

# Generated at 2022-06-24 12:51:58.353293
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert(LinuxAcademyIE.ie_key() == "linuxacademy")
    assert(LinuxAcademyIE.ie_key(ie="linuxacademy") == "linuxacademy")

# Generated at 2022-06-24 12:52:07.939611
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE('prompt',
                        'https://linuxacademy.com/cp/modules/view/id/154',
                        )
    assert ie._NETRC_MACHINE == 'linuxacademy'
    ie._real_initialize()
    assert ie._VALID_URL == (
        r'(?x)https?://(?:www\.)?linuxacademy\.com'
        r'/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))')
    return ie


# Generated at 2022-06-24 12:52:11.775680
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    if Internet() is False:
        raise SkipTest("Can't run test if there's no internet connection.")
    ie = LinuxAcademyIE("linux academy")
    ie.initialize()
    ie.login()
    assert ie.username is not None
    assert ie.password is not None
    ie.login()

# Generated at 2022-06-24 12:52:16.324938
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE('linuxacademy.com', 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675', 'abd')
    assert ie.ie_key() == LinuxAcademyIE.ie_key()

# Generated at 2022-06-24 12:52:17.891668
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    if not ie._login():
        raise Exception

# Generated at 2022-06-24 12:52:20.051838
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-24 12:52:30.638047
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.suitable(None) == False
    assert ie.suitable('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675') == True
    assert ie.suitable('https://linuxacademy.com/cp/modules/view/id/154') == True
    assert ie.suitable('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2') == True
    assert ie.suitable('https://www.linuxacademy.com/cp/courses/lesson/course/1498/lesson/2') == True

# Generated at 2022-06-24 12:52:41.071031
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_user_agent import user_agent_capture_constructor
    from .test_user_agent import thread_capture_constructor
    thread_capture_constructor()
    user_agent_capture_constructor()
    (result, ua, trace) = thread_capture_constructor(
        {'extractor': ['linuxacademy', 'linuxacademy:cp']}, url='https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    assert result["entries"][0]["ie_key"] == "Linuxacademy"
    assert result["entries"][1]["ie_key"] == "LinuxAcademy"

# Generated at 2022-06-24 12:52:42.678901
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE(None)
    assert obj == LinuxAcademyIE

# Generated at 2022-06-24 12:52:44.456529
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Returns true if object is LinuxAcademyIE
    assert isinstance(LinuxAcademyIE(), LinuxAcademyIE)

# Generated at 2022-06-24 12:52:45.137771
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-24 12:52:47.588705
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # We have to make sure that no exception would be raised
    LinuxAcademyIE(None)

# Generated at 2022-06-24 12:52:48.966831
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    extractor = LinuxAcademyIE()
    assert extractor.NETRC_MACHINE == "linuxacademy"

# Generated at 2022-06-24 12:52:49.584254
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

# Generated at 2022-06-24 12:52:51.768900
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxAcademyIE = LinuxAcademyIE()
    assert linuxAcademyIE is not None


# Generated at 2022-06-24 12:52:55.696158
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Este método é um simples teste da construção de instância de classes.
    """
    linux_academy = LinuxAcademyIE()
    assert(linux_academy is not None)

# Generated at 2022-06-24 12:52:57.451025
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_cases = []
    for case in test_cases:
        print("constructor_test_case:", case)
        ie = LinuxAcademyIE()
        print("result:", ie)

# Generated at 2022-06-24 12:53:03.764449
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    username = 'user'
    password = 'pass'
    obj = LinuxAcademyIE(username, password)
    assert obj._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert obj._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert obj._ORIGIN_URL == 'https://linuxacademy.com'
    assert obj._NETRC_MACHINE == 'linuxacademy'



# Generated at 2022-06-24 12:53:07.656401
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # direct construction of LinuxAcademyIE should not be possible
    # since _VALID_URL requires credentials
    try:
        LinuxAcademyIE('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2')
    except ExtractorError as e:
        assert True
    else:
        assert False

# Generated at 2022-06-24 12:53:12.269772
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(0)
    assert ie.http.cookiejar is not None

    ie = LinuxAcademyIE(0)
    assert ie.http.cookiejar is not None
    assert ie.http.cookiejar is ie.http.cookiejar

# Generated at 2022-06-24 12:53:22.197187
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Default test cases for LinuxAcademyIE
    """
    ie = LinuxAcademyIE()
    assert ie.ie_key() == "LinuxAcademy", \
        "IE Name should be LinuxAcademy"
    assert ie._VALID_URL == "https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))", \
        "Url pattern should match exactly"
    assert ie._AUTHORIZE_URL == "https://login.linuxacademy.com/authorize",  \
        "Authorize Url should be correct"

# Generated at 2022-06-24 12:53:23.073918
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    laie = LinuxAcademyIE()

# Generated at 2022-06-24 12:53:24.573788
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert isinstance(instance, LinuxAcademyIE)

# Generated at 2022-06-24 12:53:28.425207
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Login parameters may change in future
    u = 'https://linuxacademy.com/cp/modules/view/id/154'
    opts = {
        'username': u,
        'password': u,
    }
    test_instance = LinuxAcademyIE(opts)
    assert test_instance

# Generated at 2022-06-24 12:53:31.339215
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert(ie.IE_NAME == 'linuxacademy')
    assert(ie.IE_DESC == 'Linux Academy')

# Generated at 2022-06-24 12:53:33.478268
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Basic test of class LinuxAcademyIE
    """
    LinuxAcademyIE()

# Generated at 2022-06-24 12:53:34.512176
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    temp_ie = LinuxAcademyIE()

# Generated at 2022-06-24 12:53:36.527094
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # try to create an instance of the class
    ie_class = LinuxAcademyIE(None)
    assert ie_class is not None


# Generated at 2022-06-24 12:53:38.052954
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)


# Generated at 2022-06-24 12:53:49.557092
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE();
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.IE_DESC == 'Linux Academy'
    assert ie.VALID_URL == (
        'https?://(?:www\\.)?linuxacademy\\.com/cp/'
        '(?:courses/lesson/course/\\d+/lesson/\\d+|'
        'modules/view/id/\\d+)'
    )
    assert ie._LOGIN_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-24 12:53:51.978475
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try_get(None, lambda x: x['foo'])
    clean_html(None)


# Generated at 2022-06-24 12:53:53.155360
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()


# Generated at 2022-06-24 12:54:00.060823
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Python program to create Unit test for constructor of class LinuxAcademyIE
    """
    try:
        if __name__ == '__main__':
            # Calling the main function
            test_LinuxAcademyIE()
    except Exception as e:
        print('Error in test_LinuxAcademyIE is {}'.format(str(e)))
    finally:
        print('Completed Unit testing for LinuxAcademyIE constructor')

# Generated at 2022-06-24 12:54:10.309695
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    test_url = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    # test for _VALID_URL
    assert LinuxAcademyIE._VALID_URL == ie._VALID_URL
    # test for real_extract
    result = ie.real_extract(test_url)
    assert result['id'] == '1498-2'
    # test for _login
    result = ie._login()
    assert result is None
    # test for _real_initialize
    result = ie._real_initialize()
    assert result is None
    # test if error occurs in _real_initialize

# Generated at 2022-06-24 12:54:12.267113
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == "LinuxAcademy"

# Generated at 2022-06-24 12:54:22.257612
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.IE_DESC == 'LinuxAcademy.com'
    assert ie._VALID_URL == LinuxAcademyIE._VALID_URL
    assert ie._AUTHORIZE_URL == LinuxAcademyIE._AUTHORIZE_URL
    assert ie._ORIGIN_URL == LinuxAcademyIE._ORIGIN_URL
    assert ie._CLIENT_ID == LinuxAcademyIE._CLIENT_ID
    assert ie._NETRC_MACHINE == LinuxAcademyIE._NETRC_MACHINE
    assert ie._TESTS == LinuxAcademyIE._TESTS

# Generated at 2022-06-24 12:54:23.148024
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:54:24.529327
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademy_ie = LinuxAcademyIE()
    assert linuxacademy_ie

# Generated at 2022-06-24 12:54:33.869197
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    username, password = ie._get_login_info()
    if username is None:
        return
    access_token = ie._login()
    course_id = '154'
    webpage = ie._download_webpage('https://linuxacademy.com/cp/modules/view/id/154', course_id)
    module = ie._parse_json(
        ie._search_regex(
            r'window\.module\s*=\s*({.+?})\s*;', webpage, 'module'),
        course_id)
    chapter = module['items'][0]
    title = chapter.get('title')
    description = chapter.get('md_desc') or clean_html(chapter.get('desc'))
    print('title = %s' % title)
   

# Generated at 2022-06-24 12:54:35.301387
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert(LinuxAcademyIE.ie_key() == 'LinuxAcademy')

# Generated at 2022-06-24 12:54:42.632058
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie_obj = LinuxAcademyIE()
    assert ie_obj._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie_obj._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie_obj._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie_obj._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:54:43.571511
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:54:44.222791
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:54:54.283786
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-24 12:54:58.766066
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    #try:
    #    url = 'http://www.linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    #    ie = LinuxAcademyIE()
    #except:
    #    assert 0, 'Error in creating constructor of class LinuxAcademyIE'
    pass

# Generated at 2022-06-24 12:55:01.019516
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Constructor without arguments
    try:
        LinuxAcademyIE()
        assert False
    except TypeError as exc:
        assert str(exc) == '__init__() missing 1 required positional argument: \'url\''

# Generated at 2022-06-24 12:55:05.323146
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:55:06.737192
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    return LinuxAcademyIE()
test_LinuxAcademyIE.__test__ = False

# Generated at 2022-06-24 12:55:08.367057
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # pylint: disable=pointless-statement
    LinuxAcademyIE

# Generated at 2022-06-24 12:55:10.814175
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:55:19.302740
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-24 12:55:19.939388
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:55:21.415557
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() is not None

# Generated at 2022-06-24 12:55:23.370684
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE == type(LinuxAcademyIE({}))

# Generated at 2022-06-24 12:55:24.499585
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE._VALID_URL

# Generated at 2022-06-24 12:55:25.956285
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE == type(LinuxAcademyIE({}))

# Generated at 2022-06-24 12:55:27.594378
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # To check if LinuxAcademyIE has been imported
    ie = LinuxAcademyIE()

# Generated at 2022-06-24 12:55:28.429306
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:55:38.957087
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-24 12:55:41.800100
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademy_ie = LinuxAcademyIE('linuxacademy', 'LinuxAcademy')
    assert linuxacademy_ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:55:47.320804
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_ie = LinuxAcademyIE(None)
    assert test_ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert test_ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert test_ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert test_ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:55:48.295920
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:55:49.943466
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """ Unit test for constructor of class LinuxAcademyIE """
    # Successful creation of object
    assert LinuxAcademyIE

# Generated at 2022-06-24 12:56:01.738435
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE, 'test_LinuxAcademyIE: Not class instance'
    assert LinuxAcademyIE._NETRC_MACHINE == 'linuxacademy', \
    'test_LinuxAcademyIE: _NETRC_MACHINE not equal linuxacademy'
    assert LinuxAcademyIE._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx', \
    'test_LinuxAcademyIE: _CLIENT_ID not equal KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-24 12:56:02.438328
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:56:03.745698
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE is not None


# Generated at 2022-06-24 12:56:04.585121
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-24 12:56:15.655077
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_downloader import FakeYDL
    from .test_downloader import TestDownloader

    # Test without login
    test_downloader = TestDownloader({'username': '', 'password': ''})
    LinuxAcademyIE._login = lambda x: None
    test_downloader.add_info_extractor(LinuxAcademyIE)
    with FakeYDL(test_downloader) as ydl:
        assert ydl.download(['https://linuxacademy.com/cp/modules/view/id/154'])

    # Test with login
    test_downloader = TestDownloader({'username': 'linuxacademy', 'password': 'linuxacademy'})
    test_downloader.add_info_extractor(LinuxAcademyIE)

# Generated at 2022-06-24 12:56:17.419325
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:56:27.379199
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    r"""Tests LinuxAcademyIE against input"""
    test_cases = [
        {
            'url': 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
            'item_id': '7971-2',
        },
        {
            'url': 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2',
            'item_id': '1498-2',
        },
        {
            'url': 'https://linuxacademy.com/cp/modules/view/id/154',
            'item_id': '154',
        },
    ]

# Generated at 2022-06-24 12:56:31.423754
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    # this test is to make sure Python 2.x compatibility for TestTemplates.test_test_template()
    assert ie.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:56:32.521283
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    t = LinuxAcademyIE()

# Generated at 2022-06-24 12:56:39.487343
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    result = LinuxAcademyIE()
    assert result._CLIENT_ID == "KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx"
    assert result._NETRC_MACHINE == 'linuxacademy'
    assert result._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert result._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-24 12:56:43.191121
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        print("Test")
    except AssertionError as e:
        print("Assertion error: %s" % e.message)
        raise

if __name__ == "__main__":
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:56:47.429513
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Simple test for downloading a single video"""
    LinuxAcademyIE().download_webpage(
        "https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2",
        "test")


test_LinuxAcademyIE()

# Generated at 2022-06-24 12:56:49.629088
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert hasattr(ie, '_NETRC_MACHINE')

# Generated at 2022-06-24 12:56:52.359468
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None, 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2/module/675')

# Generated at 2022-06-24 12:57:01.532570
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    testCase = {'url': 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
                'type': 'Linux Academy',
                'id': '7971-2',
                'ext': 'mp4',
                'title': 'What Is Data Science',
                'description': 'md5:c574a3c20607144fb36cb65bdde76c99',
                'timestamp': 1607387907,
                'upload_date': '20201208',
                'duration': 304}

    ie = LinuxAcademyIE()
    info = ie.extract(testCase['url'])

    assert(info['id'] == testCase['id'])
    assert(info['ext'] == testCase['ext'])

# Generated at 2022-06-24 12:57:03.091685
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
    except Exception as e:
        assert False, e
    assert True

# Generated at 2022-06-24 12:57:04.744789
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print(LinuxAcademyIE)

# Generated at 2022-06-24 12:57:11.242865
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(
        LinuxAcademyIE.ie_key(),
        LinuxAcademyIE._VALID_URL,
        LinuxAcademyIE._TESTS,
        LinuxAcademyIE._AUTHORIZE_URL,
        LinuxAcademyIE._ORIGIN_URL,
        LinuxAcademyIE._CLIENT_ID,
        LinuxAcademyIE._NETRC_MACHINE)
    return ie

# Generated at 2022-06-24 12:57:16.443137
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from youtube_dl.compat import unittest

    class LinuxAcademyIETestCase(unittest.TestCase):
        def test_constructor(self):
            site_ie = LinuxAcademyIE()
            self.assertEqual(site_ie.ie_key(), 'LinuxAcademy')
            self.assertEqual(site_ie.ie_key(), 'LinuxAcademy')

# Generated at 2022-06-24 12:57:19.391876
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(None) # type: LinuxAcademyIE
    assert isinstance(ie, LinuxAcademyIE)

# Generated at 2022-06-24 12:57:20.526947
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None)

# Generated at 2022-06-24 12:57:22.596790
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test LinuxAcademyIE constructor."""
    LinuxAcademyIE("LinuxAcademyIE")

# Generated at 2022-06-24 12:57:23.629831
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    check_valid_constructor(LinuxAcademyIE)

# Generated at 2022-06-24 12:57:24.396077
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:57:31.912816
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert ie._TESTS[0]['url'] == 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    assert ie._TESTS[0]['info_dict']['id'] == '7971-2'