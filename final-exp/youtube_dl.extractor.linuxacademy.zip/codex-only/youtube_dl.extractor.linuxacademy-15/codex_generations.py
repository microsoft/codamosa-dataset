

# Generated at 2022-06-24 12:47:31.606314
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(object)

# Generated at 2022-06-24 12:47:43.095800
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-24 12:47:51.581285
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Constructor of LinuxAcademyIE
    ie = LinuxAcademyIE(
        LinuxAcademyIE._VALID_URL,
        LinuxAcademyIE.ie_key(),
    )

    assert ie._VALID_URL == LinuxAcademyIE._VALID_URL
    assert ie._AUTHORIZE_URL == LinuxAcademyIE._AUTHORIZE_URL
    assert ie._ORIGIN_URL == LinuxAcademyIE._ORIGIN_URL
    assert ie._CLIENT_ID == LinuxAcademyIE._CLIENT_ID
    assert ie._NETRC_MACHINE == LinuxAcademyIE._NETRC_MACHINE

# Generated at 2022-06-24 12:48:00.599760
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    global ie
    ie = LinuxAcademyIE()
    assert ie
    # Download web page from URL, e.g.
    # https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    webpage = ie.download_webpage(url, None)
    assert webpage
    # Parse the web page using regular expressions
    m3u8_url = ie._parse_json(ie._search_regex(r'player\.playlist\s*=\s*(\[.+?\])\s*;', webpage, 'playlist'), None)
    assert m3u8_url
    # Download m3

# Generated at 2022-06-24 12:48:03.372685
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
    except Exception as e:
        assert "LinuxAcademyIE" in str(e), "Should catch that exception"

# Generated at 2022-06-24 12:48:09.821193
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    filename = 'tests/test_data/linuxacademy/input.txt'
    with open(filename, 'r') as f:
        input_data = f.read()
    lecture_obj = LinuxAcademyIE(input_data, None)
    assert lecture_obj.extract_filename_from_url() == 'LinuxAcademy-Linux-Foundations-IOL-Foundations-Lab-1-Solution-2020-06-15_04-20-19.mp4'

# Generated at 2022-06-24 12:48:13.788058
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    '''
    Test constructor of class LinuxAcademyIE
    '''
    # Test without credentials
    LinuxAcademyIE()

    # Test with credentials
    credentials = {'username': 'username', 'password': 'password'}
    LinuxAcademyIE(credentials=credentials)

# Generated at 2022-06-24 12:48:15.265513
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.ms_to_seconds(b'00:00:05.400') == 5.4

# Generated at 2022-06-24 12:48:16.975140
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie is not None
    assert ie.ie_key() == 'linuxacademy'

# Generated at 2022-06-24 12:48:18.200396
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:48:20.155781
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._NETRC_MACHINE == 'linuxacademy'


# Generated at 2022-06-24 12:48:22.794688
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # call the constructor with a public video,
    # and test if video can be fetched
    ies = LinuxAcademyIE()
    ies.test()

# Generated at 2022-06-24 12:48:24.176850
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    v = LinuxAcademyIE()
    assert v is not None

# Generated at 2022-06-24 12:48:24.936063
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:48:26.064476
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    class UnitTestClass():
        def __init__(self):
            self.ie = LinuxAcademyIE("")

# Generated at 2022-06-24 12:48:26.887166
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:48:30.058548
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._AUTHORIZE_URL == ie._AUTHORIZE_URL
    assert ie._CLIENT_ID == ie._CLIENT_ID
    assert ie._NETRC_MACHINE == ie._NETRC_MACHINE
    assert ie._ORIGIN_URL == ie._ORIGIN_URL
    assert ie._VALID_URL == ie._VALID_URL

# Generated at 2022-06-24 12:48:34.471507
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE(None)
    except TypeError as e:
        assert False, f"LinuxAcademyIE constructor requires an object of 'downloader' class"
        assert str(e) == 'LinuxAcademyIE() missing 1 required positional argument: \'downloader\'', 'error msg is different'


# Generated at 2022-06-24 12:48:36.682378
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    tester = LinuxAcademyIE()
    assert isinstance(tester, LinuxAcademyIE)

# Generated at 2022-06-24 12:48:42.801042
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:48:50.429565
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test cases from example URLs
    lai = LinuxAcademyIE()
    assert lai.IE_NAME, 'linuxacademy'
    assert lai.VALID_URL, 'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/\d+/lesson/\d+'
    assert lai.NETRC_MACHINE, 'linuxacademy'
# Unit test of _real_extract()

# Generated at 2022-06-24 12:49:01.461554
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'

# Generated at 2022-06-24 12:49:02.220053
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()


# Generated at 2022-06-24 12:49:03.876487
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ies = LinuxAcademyIE()
    assert type(ies) == LinuxAcademyIE

# Generated at 2022-06-24 12:49:05.136263
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        return LinuxAcademyIE(None, None)
        
    except Exception as e:
        print(e)
        return None


# Generated at 2022-06-24 12:49:06.513144
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Call constructor
    LinuxAcademyIE()

# Generated at 2022-06-24 12:49:07.569601
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    objIE = LinuxAcademyIE()
    assert objIE.IE_NAME

# Generated at 2022-06-24 12:49:09.779943
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    instance._real_extract("https://linuxacademy.com/cp/modules/view/id/154")

# Generated at 2022-06-24 12:49:17.648020
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    module = LinuxAcademyIE()
    test_obj = LinuxAcademyIE._TESTS[0]
    # Parameters in Module initialization
    assert(module._VALID_URL == LinuxAcademyIE._VALID_URL)
    assert(module._CLIENT_ID == LinuxAcademyIE._CLIENT_ID)
    assert(module._NETRC_MACHINE == LinuxAcademyIE._NETRC_MACHINE)
    assert(module._TEST == LinuxAcademyIE._TESTS)
    # Parameters in extract method
    assert(module._downloader.params['noplaylist'] == True)
    mobj = re.match(module._VALID_URL, test_obj['url'])
    assert(mobj.group('chapter_id'))

# Generated at 2022-06-24 12:49:19.417183
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # test constructor
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'LinuxAcademy'

# Generated at 2022-06-24 12:49:25.910208
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_linuxacademy import TEST_CASE_FILE_WITH_COMMENTS, TEST_CASE_FILE_WITHOUT_COMMENTS, TEST_CASE_FILE_WITH_WRONG_FORMAT
    from .utils import TEST_CASE_FILE_WITH_COMMENTS_PATH, TEST_CASE_FILE_WITHOUT_COMMENTS_PATH, TEST_CASE_FILE_WITH_WRONG_FORMAT_PATH
    import os

    if (os.path.isfile(TEST_CASE_FILE_WITH_COMMENTS_PATH)
            and os.path.isfile(TEST_CASE_FILE_WITHOUT_COMMENTS_PATH)
            and os.path.isfile(TEST_CASE_FILE_WITH_WRONG_FORMAT_PATH)):

        linuxacad

# Generated at 2022-06-24 12:49:30.985909
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_utils import FakeLoginExtractor
    obj = FakeLoginExtractor(LinuxAcademyIE)
    assert obj._NETRC_MACHINE == obj.ie._NETRC_MACHINE  # pylint: disable=protected-access
    assert obj._CLIENT_ID == obj.ie._CLIENT_ID  # pylint: disable=protected-access
    assert obj._ORIGIN_URL == obj.ie._ORIGIN_URL  # pylint: disable=protected-access
    assert obj._VALID_URL == obj.ie._VALID_URL  # pylint: disable=protected-access

# Generated at 2022-06-24 12:49:32.239596
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    _u = LinuxAcademyIE(None)._real_extract
    LinuxAcademyIE(None)._real_initialize()

# Generated at 2022-06-24 12:49:40.395419
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Run unit test for LinuxAcademyIE.
    """
    need_login = False
    if need_login:
        username = input("Please input a Linux Academy username")
        password = input("Please input a Linux Academy password")
        IE = LinuxAcademyIE(username,password)
    else:
        IE = LinuxAcademyIE()

    test_urls = [
        # Test course url
        'https://linuxacademy.com/cp/modules/view/id/154',
        # Test lecture url
        'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    ]
    for url in test_urls:
        print("url=",url)
        result = IE.extract(url)
        print("result=",result)

# Generated at 2022-06-24 12:49:52.064961
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_utils import make_mock_extractors, get_testdata_dir
    from .test_utils import check_extractor_err_message
    extractors = make_mock_extractors(get_testdata_dir(), [
            ('LinuxAcademyIE', 'test.linuxacademy.com:80/?username=test&password=test',
                    'test.linuxacademy.com:80', 'test.linuxacademy.com:80/test', '', '', ''),
            ('LinuxAcademyIE', 'test.linuxacademy.com:80/?username=undefined',
                    'test.linuxacademy.com:80', '', '', '', 'LinuxAcademy.com account is missing')
            ])

# Generated at 2022-06-24 12:50:03.315493
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test for the constructor of the class LinuxAcademyIE
    ie = LinuxAcademyIE()
    assert(ie._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|modules/view/id/(?P<course_id>\\d+))')
    assert(ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize')
    assert(ie._ORIGIN_URL == 'https://linuxacademy.com')
    assert(ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx')

# Generated at 2022-06-24 12:50:04.717538
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._login is not None
    assert ie._real_initialize is not None
    assert ie._real_extract is not None

# Generated at 2022-06-24 12:50:06.136759
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test get instance without calling real_initialize()
    ie = LinuxAcademyIE(LinuxAcademyIE.ie_key())

# Generated at 2022-06-24 12:50:07.650275
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'LinuxAcademy'



# Generated at 2022-06-24 12:50:17.850091
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ied = LinuxAcademyIE()
    assert ied.IE_NAME == 'linuxacademy'
    assert ied.IE_DESC == 'Linux Academy'
    assert ied._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ied._ORIGIN_URL == 'https://linuxacademy.com'
    assert ied._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ied._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:50:19.296635
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_instance = LinuxAcademyIE('LinuxAcademy')

# Generated at 2022-06-24 12:50:20.336676
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE._login()

# Generated at 2022-06-24 12:50:21.807411
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    if __name__ == '__main__':
        test_LinuxAcademyIE()

# Generated at 2022-06-24 12:50:28.277931
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Check that LinuxAcademyIE can be created
    ie = LinuxAcademyIE()
    # Check that tabulate_results can be called
    #ie.tabulate_results(ie.extract('https://linuxacademy.com/cp/modules/view/id/154'), verbose=True)

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:50:32.288157
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    IE = LinuxAcademyIE()
    assert isinstance(IE, InfoExtractor)
    assert hasattr(IE, '_login')
    assert hasattr(IE, '_real_initialize')
    assert hasattr(IE, '_real_extract')

# Generated at 2022-06-24 12:50:36.119804
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    if LinuxAcademyIE._login not in LinuxAcademyIE._download_webpage.__defaults__:
        raise ValueError("Login function not in LinuxAcademyIE")

# Generated at 2022-06-24 12:50:39.514553
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    _input = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    _output = LinuxAcademyIE("email", "password")._VALID_URL == _input
    assert _output

# Generated at 2022-06-24 12:50:45.444065
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .module.linuxacademy import LinuxAcademyIE
    import warnings
    warnings.filterwarnings("ignore",
                            category=DeprecationWarning)
    test_object = LinuxAcademyIE()
    print(test_object)
    print(test_object.name)
    print(test_object.ie_key())
    print(test_object.ie_key() == 'LinuxAcademy')
    print(test_object._VALID_URL)
    print(test_object._NETRC_MACHINE)


# Generated at 2022-06-24 12:50:47.440300
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE('LinuxAcademyIE')
    assert ie.username == None
    assert ie.password == None

# Generated at 2022-06-24 12:50:49.705942
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Unit test for constructor of class LinuxAcademyIE."""
    LinuxAcademyIE("LinuxAcademyIE", ["linuxacademy.com"])

# Generated at 2022-06-24 12:50:53.162300
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Constructor test
    """
    # Testing with a video
    result = LinuxAcademyIE()
    # make sure it is an instance of the right class
    assert result.__class__ == LinuxAcademyIE

# Generated at 2022-06-24 12:50:55.295389
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test constructor for the LinuxAcademyIE class."""
    LinuxAcademyIE()

# Generated at 2022-06-24 12:50:57.280327
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert isinstance(LinuxAcademyIE(), InfoExtractor)

# Generated at 2022-06-24 12:51:06.294483
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|https?://(?:www\.)?linuxacademy\.com/cp/modules/view/id/(?P<course_id>\d+)'

# Generated at 2022-06-24 12:51:07.267098
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxAcademy = LinuxAcademyIE()

# Generated at 2022-06-24 12:51:10.595595
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Arrange
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    ie = LinuxAcademyIE()
    
    # Act
    ie._real_extract(url)

    # Assert

# Generated at 2022-06-24 12:51:11.221931
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-24 12:51:12.414741
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:51:15.583377
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from . import linuxacademy
    ies = linuxacademy.LinuxAcademyIE()
    assert isinstance(ies, linuxacademy.LinuxAcademyIE)

# Generated at 2022-06-24 12:51:25.020757
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(downloader=None)
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.suitable(None) == False
    assert ie.suitable(False) == False
    assert ie.suitable('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2') == True
    assert ie.suitable('https://linuxacademy.com/cp/modules/view/id/154') == True
    assert ie.suitable('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675') == True

# Generated at 2022-06-24 12:51:31.862228
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # pylint: disable=redefined-outer-name
    username = 'abc123'
    password = 'def456'
    netrc_machine = 'linuxacademy'
    linux_academy_ie = LinuxAcademyIE({
        'username': username,
        'password': password,
        'netrc_machine': netrc_machine
    })

    assert linux_academy_ie._NETRC_MACHINE == netrc_machine

    assert linux_academy_ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert linux_academy_ie._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-24 12:51:34.009297
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)

# Generated at 2022-06-24 12:51:35.056684
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:51:41.748416
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test of class LinuxAcademyIE, with a valid url, with an invalid url
    if __name__ == "__main__":
        url = "https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675"
        try:
            LinuxAcademyIE()
            assert 1==1
        except:
            pass
        try:
            LinuxAcademyIE(url)
            assert 1==1
        except Exception as e:
            print(e)
            assert 1==2

# Generated at 2022-06-24 12:51:52.445684
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # To be changed
    login = "username"
    passwd = "password"
    # Testing with a random course to extract video
    # Must be changed over time to always be a valid link
    course_url = "https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/1/module/675"
    ie = LinuxAcademyIE()
    ie.set_username(login)
    ie.set_password(passwd)
    ie.set_cookiejar()

    # Testing method to extract a course
    course_info = ie.extract(course_url)
    print('\n')
    if not course_info:
        print('No course found. Verify URL or credentials')
    else:
        print('Course title: %s' % course_info['title'])
       

# Generated at 2022-06-24 12:51:55.480935
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxAcademy = LinuxAcademyIE()
    assert len(linuxAcademy._TESTS) > 0
    assert linuxAcademy.name == 'linuxacademy'
    assert linuxAcademy.IE_NAME == 'linuxacademy'

# Generated at 2022-06-24 12:51:56.320406
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

# Generated at 2022-06-24 12:51:58.472613
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie_LinuxAcademy = LinuxAcademyIE()
    print(ie_LinuxAcademy.login)
    print(ie_LinuxAcademy.IE_NAME)


# Generated at 2022-06-24 12:52:01.526502
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test normal videos
    LinuxAcademyIE()._real_initialize()

    # Test course playlists
    LinuxAcademyIE()._real_initialize()

# Generated at 2022-06-24 12:52:04.141429
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE('LinuxAcademyIE')
    assert ie.IE_NAME == 'LinuxAcademyIE'

# Generated at 2022-06-24 12:52:05.185543
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None, None)

# Generated at 2022-06-24 12:52:07.073254
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE();

_mock_xpath_result = [{
    'attrib': {
        'value': 'value',
    },
}]


# Generated at 2022-06-24 12:52:08.213880
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Constructor of LinuxAcademyIE class should pass
    LinuxAcademyIE()

# Generated at 2022-06-24 12:52:15.071455
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'LinuxAcademy'
    assert ie._VALID_URL == 'https?://(?:www\\.)?linuxacademy\\.com/cp/courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)'

# Generated at 2022-06-24 12:52:18.000860
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Basic test for constructor of LinuxAcademyIE"""
    # If a test fails, an exception will be raised inside the constructor
    LinuxAcademyIE(None, {})

# Generated at 2022-06-24 12:52:20.616565
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_utils import TestLinuxAcademyIE
    return TestLinuxAcademyIE(LinuxAcademyIE).run()

# Generated at 2022-06-24 12:52:21.784344
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:52:22.870783
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

# Generated at 2022-06-24 12:52:31.424878
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Initialize variables
    video_url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    video_id = '7971-2'

    # Create instance of class LinuxAcademyIE
    video_info_extractor = LinuxAcademyIE()

    # Test _real_initialize() method
    video_info_extractor._real_initialize()

    # Test _real_extract() method
    video_info = video_info_extractor._real_extract(video_url)

    # Verify values
    assert(video_info['id'] == video_id)

# Generated at 2022-06-24 12:52:32.353297
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:52:33.961263
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():

    la_ie = LinuxAcademyIE()
    assert(la_ie._NETRC_MACHINE is not None)

# Generated at 2022-06-24 12:52:37.041918
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    global LinuxAcademyIE
    class LinuxAcademyIE(LinuxAcademyIE):
        def _authorize(self):
            pass
    global ie
    ie = LinuxAcademyIE()

# Generated at 2022-06-24 12:52:43.674997
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.name == 'linuxacademy'
    assert ie.description == 'Linux Academy IE Test'
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-24 12:52:45.969752
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_main import TestIE
    from .test_login import test_login

    test_login(LinuxAcademyIE, TestIE)

# Generated at 2022-06-24 12:52:48.133675
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    asserter = LinuxAcademyIE()
    assert asserter

# Generated at 2022-06-24 12:52:58.055567
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # pylint: disable=protected-access
    from .common import InfoExtractor
    from .common import class_names_not_due_to_a_unittest
    not_assigned = set([x for x in class_names_not_due_to_a_unittest(InfoExtractor) if x.startswith('LinuxAcademy')])
    all_classes = set(InfoExtractor._ALL_CLASSES)
    infoExtractor_classes_for_LinuxAcademy = all_classes - not_assigned
    assert len(infoExtractor_classes_for_LinuxAcademy) == 1
    assert LinuxAcademyIE.__name__ in infoExtractor_classes_for_LinuxAcademy

# Generated at 2022-06-24 12:53:06.125147
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.params['load_cookies'] is not None
    assert ie.params['cachedir'] is not None
    assert ie.params['noplaylist'] is None
    assert ie.params['nocheckcertificate'] is None
    assert ie.params['includesubtitles'] is None
    assert ie.params['skip_download'] is not None
    assert ie.params['extract_flat'] is not None
    assert ie.params['daterange'] is None
    assert ie.params['min_views'] is None
    assert ie.params['max_views'] is None
    assert ie.params['matchtitle'] is None
    assert ie.params['rejecttitle'] is None
    assert ie.params['min_upload_date'] is None

# Generated at 2022-06-24 12:53:07.661091
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie is not None

# Generated at 2022-06-24 12:53:08.937144
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.__name__ == 'LinuxAcademyIE'

# Generated at 2022-06-24 12:53:10.598145
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    module = LinuxAcademyIE()

# Generated at 2022-06-24 12:53:12.215078
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'linuxacademy'

# Generated at 2022-06-24 12:53:17.788416
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        """
        A LinuxAcademyIE object is created using a URL
        """
        LinuxAcademyIE('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    except Exception as e:
        print("Error creating LinuxAcademyIE object with a URL")
        print(e)
    return

# Generated at 2022-06-24 12:53:18.715278
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:53:21.326096
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert 'LinuxAcademy' == LinuxAcademyIE.ie_key()
    assert not LinuxAcademyIE.ie_key('/link/to/video/whatever?that')


# Generated at 2022-06-24 12:53:22.307245
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    construct_test_case(LinuxAcademyIE)

# Generated at 2022-06-24 12:53:23.092475
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()._real_initialize()

# Generated at 2022-06-24 12:53:23.970248
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()

# Generated at 2022-06-24 12:53:26.058630
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    if not LinuxAcademyIE.working():
        return
    data = LinuxAcademyIE()._login()
    assert data is not None, "LinuxAcedamyIE._login() failed"

# Generated at 2022-06-24 12:53:31.385565
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    '''
        Constructor of class LinuxAcademyIE
    '''
    try:
        # Loading resources
        # Loading sample video
        # Create an instance of class LinuxAcademyIE
        linuxacademy_ie = LinuxAcademyIE()
        assert linuxacademy_ie is not None
    except Exception as ex:
        print(ex)


# Generated at 2022-06-24 12:53:38.433818
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == LinuxAcademyIE._VALID_URL
    assert ie._TESTS == LinuxAcademyIE._TESTS
    assert ie._AUTHORIZE_URL == LinuxAcademyIE._AUTHORIZE_URL
    assert ie._ORIGIN_URL == LinuxAcademyIE._ORIGIN_URL
    assert ie._CLIENT_ID == LinuxAcademyIE._CLIENT_ID
    assert ie._NETRC_MACHINE == LinuxAcademyIE._NETRC_MACHINE

# Generated at 2022-06-24 12:53:42.033130
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Instantiate class LinuxAcademyIE
    ie = LinuxAcademyIE()
    # Check the type of instance ie
    assert isinstance(ie, LinuxAcademyIE)

# Generated at 2022-06-24 12:53:43.602821
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Test case for LinuxAcademyIE.__init__()
    """
    # initialise instance
    ia = LinuxAcademyIE()
    assert ia.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:53:45.809745
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert(ie.IE_NAME == 'linuxacademy')

# Generated at 2022-06-24 12:53:49.252390
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_cases = [] # What does it mean?
    test_cases.append(LinuxAcademyIE(None))
    test_cases.append(LinuxAcademyIE(None, 'LinuxAcademyIE'))
    return


# Generated at 2022-06-24 12:53:54.704855
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        # Test the constructor.
        test = LinuxAcademyIE(linuxacademy_test=True)
    finally:
        # Test the destructor.
        test.__del__()

# Test to check the status of the LinuxAcademyIE.ie_key() method.

# Generated at 2022-06-24 12:54:00.576536
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx' and LinuxAcademyIE()._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize' and LinuxAcademyIE().IE_NAME == 'linuxacademy'

# Generated at 2022-06-24 12:54:02.027852
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    unittest.main()

# Generated at 2022-06-24 12:54:09.820402
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    username = "BogdanVukojevic"
    password = "xQIgPVhb"
    ie = LinuxAcademyIE(username, password)
    assert(ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx')
    assert(ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize')
    assert(ie._ORIGIN_URL == 'https://linuxacademy.com')
    assert(ie._NETRC_MACHINE == 'linuxacademy')

# Generated at 2022-06-24 12:54:13.687947
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE
    LinuxAcademyIE.ie_key()
    LinuxAcademyIE._real_initialize()
    LinuxAcademyIE._login()
    LinuxAcademyIE._real_extract()

# Generated at 2022-06-24 12:54:15.791358
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    mp_IE = LinuxAcademyIE()
    mp_IE._real_initialize()
    mp_IE._login()

# Generated at 2022-06-24 12:54:17.351665
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE is not None


# Generated at 2022-06-24 12:54:18.712184
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    e = LinuxAcademyIE()

# Generated at 2022-06-24 12:54:19.766795
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()._login()

# Generated at 2022-06-24 12:54:24.334275
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    tested_class = LinuxAcademyIE()
    expected_value = "LinuxAcademyIE"
    assert tested_class.ie_key()==expected_value, "Expected %s, got %s" % (
            expected_value, tested_class.ie_key())


# Generated at 2022-06-24 12:54:25.077500
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:54:27.205334
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE().IE_NAME == 'linuxacademy'

# Generated at 2022-06-24 12:54:29.973948
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.__class__.__name__ == 'LinuxAcademyIE'
    assert ie._VALID_URL.__class__.__name__ == 'SRE_Pattern'
    assert ie._TESTS.__class__.__name__ == 'list'



# Generated at 2022-06-24 12:54:31.700115
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._downloader.login_info == {'NetrcMachine': 'linuxacademy'}

# Generated at 2022-06-24 12:54:34.816731
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, InfoExtractor)
    assert LinuxAcademyIE.ie_key() in InfoExtractor._ALL_INFO_EXTRACTORS


# Generated at 2022-06-24 12:54:37.590933
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    actual = LinuxAcademyIE('LinuxAcademy')
    assert actual._NETRC_MACHINE == 'linuxacademy'



# Generated at 2022-06-24 12:54:43.799458
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:54:49.468290
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Constructor test for class LinuxAcademyIE"""
    ie = LinuxAcademyIE(downloader=None)
    # test __init__
    assert ie.playlist_count == None
    assert ie.playlist_mincount == 0
    assert ie.user_agent == 'Linux Academy downloader'
    assert ie.num_downloads == None
    assert ie.params == {'nocheckcertificate': False, 'prefer_ffmpeg': True,
                         'quiet': False, 'noprogress': False,
                         'prefer_free_formats': False,
                         'skip_download': False}
    assert not ie._login_only
    assert ie._num_entries == None
    assert not ie._match_title
    assert not ie._match_id
    assert not ie._match_date
    assert not ie

# Generated at 2022-06-24 12:54:52.194416
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    if ie._downloader is None:
        ie._downloader = DummyDownloader()
    ie.initialize()

# Generated at 2022-06-24 12:54:54.329529
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')

# Generated at 2022-06-24 12:54:56.227092
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    module = LinuxAcademyIE()
    assert module is not None

test_LinuxAcademyIE()

# Generated at 2022-06-24 12:55:04.434780
# Unit test for constructor of class LinuxAcademyIE

# Generated at 2022-06-24 12:55:06.100465
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    ie.set_login_info()

# Generated at 2022-06-24 12:55:08.018560
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux = LinuxAcademyIE()
    assert isinstance(linux, LinuxAcademyIE)

# Generated at 2022-06-24 12:55:12.963996
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    # print(ie.__dict__)
    return

if __name__ == '__main__':
    # test_LinuxAcademyIE()
    test_LinuxAcademyIE()
    exit(0)

# Generated at 2022-06-24 12:55:13.948613
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()._login()

# Generated at 2022-06-24 12:55:14.703160
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None)._login()

# Generated at 2022-06-24 12:55:16.281955
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE

# test LinuxAcademyIE

# Generated at 2022-06-24 12:55:19.280845
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    expected_ie_key = 'LinuxAcademy:LinuxAcademy'
    ie = LinuxAcademyIE()
    assert ie.IE_KEY == expected_ie_key


# Generated at 2022-06-24 12:55:20.280375
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    if __name__ == "__main__":
        ie = LinuxAcademyIE()
        print(ie)

# Generated at 2022-06-24 12:55:23.071639
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Checks the constructor of class LinuxAcademyIE is not throwing any exception
    tester = LinuxAcademyIE()
    assert True

# Generated at 2022-06-24 12:55:26.190209
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE(None, None)
        assert False
    except RuntimeError:
        pass
    assert LinuxAcademyIE(None, None, 'linuxacademy')

# Generated at 2022-06-24 12:55:28.620976
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert hasattr(LinuxAcademyIE, 'ie_key')
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.IE_NAME == 'LinuxAcademy'

# Generated at 2022-06-24 12:55:29.791690
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info = LinuxAcademyIE()._real_initialize()

# Generated at 2022-06-24 12:55:31.799957
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE("LinuxAcademyIE", {"IE_NAME":"LinuxAcademyIE"})

# Generated at 2022-06-24 12:55:42.242709
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-24 12:55:43.113375
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()
    return True

# Generated at 2022-06-24 12:55:43.951895
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE() is not None

# Generated at 2022-06-24 12:55:47.377134
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    username, password = LinuxAcademyIE._get_login_info()
    # username, password = None, None
    # username, password = 'your_username', 'your_password'
    assert LinuxAcademyIE.test_login(username, password)

# Generated at 2022-06-24 12:55:49.756729
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    video = LinuxAcademyIE()
    video.initialize()
    video.extract('https://linuxacademy.com/cp/modules/view/id/154')

# Generated at 2022-06-24 12:55:55.367171
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'linuxAcademy'
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'

test = LinuxAcademyIE()

if __name__ == '__main__':
    test.main()

# Generated at 2022-06-24 12:55:56.176605
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert issubclass(LinuxAcademyIE, InfoExtractor)

# Generated at 2022-06-24 12:56:06.077450
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    _url = "https://www.linuxacademy.com/cp/courses/lesson/course/2071/lesson/4/module/4223"
    _expected = {
        'chapter_number': 1,
        'chapter_id': '2271',
        'timestamp': 1530241910,
        'duration': 130,
        '_type': 'url_transparent',
        'ie_key': 'LinuxAcademy',
        'title': 'Introduction to Business Leadership and Management',
        'url': _url,
        'chapter': 'Business Skills',
        'description': 'md5:e6d3e610f79d4ab4ae4f4c6f64b6a1d9',
    }
    assert LinuxAcademyIE()._real_extract(_url) == _expected

# Generated at 2022-06-24 12:56:08.108345
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # pylint:disable=unused-variable
    ie = LinuxAcademyIE()

# Generated at 2022-06-24 12:56:08.742629
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:56:11.598203
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    _test_LinuxAcademyIE = LinuxAcademyIE
    _test_LinuxAcademyIE._VALID_URL = LinuxAcademyIE._VALID_URL

# Generated at 2022-06-24 12:56:12.836365
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()


# Generated at 2022-06-24 12:56:13.865055
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(FakeInfoExtractor())

# Generated at 2022-06-24 12:56:15.567000
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert(ie.__class__.__name__ == 'LinuxAcademyIE')

# Generated at 2022-06-24 12:56:18.512938
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('LinuxAcademy', 'cp/courses/lesson/course/7971/lesson/2/module/675')

# Generated at 2022-06-24 12:56:25.290708
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ies = []
    info = {'_type': 'url_transparent',
            'url': 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
            'ie_key': 'LinuxAcademy',
            'title': 'What Is Data Science',
            'description': 'md5:c574a3c20607144fb36cb65bdde76c99',
            'timestamp': 1607387907,
            'duration': 304,
            'chapter': None,
            'chapter_id': None,
            'chapter_number': None}
    item_id = '7971-2'
    formats = []
    ies.append({'title': info['title']})
    ies.append({'title': item_id})

# Generated at 2022-06-24 12:56:28.201143
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie is not None
    assert ie.IE_NAME == 'linuxacademy'


# Generated at 2022-06-24 12:56:32.990019
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # pylint: disable=line-too-long
    # Constructor should return an object of class LinuxAcademyIE
    assert type(LinuxAcademyIE()) == LinuxAcademyIE

    # Constructor should return an object of class InfoExtractor
    assert type(LinuxAcademyIE()) == InfoExtractor

# Generated at 2022-06-24 12:56:34.211573
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:56:35.840109
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

# Generated at 2022-06-24 12:56:36.250737
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-24 12:56:37.773052
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    infoExtractor = LinuxAcademyIE()
    assert infoExtractor.IE_NAME == 'linuxacademy'



# Generated at 2022-06-24 12:56:38.724767
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:56:39.209522
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert True

# Generated at 2022-06-24 12:56:41.424013
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'
    assert isinstance(ie, LinuxAcademyIE)

# Generated at 2022-06-24 12:56:44.915780
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_generic_extractor import object_test
    e = object_test(LinuxAcademyIE, 'LinuxAcademyIE', 'linuxacademy.com')
    e.test()

# Generated at 2022-06-24 12:56:50.898242
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    p = LinuxAcademyIE()
    assert p._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert p._NETRC_MACHINE == 'linuxacademy'


# Generated at 2022-06-24 12:56:55.132072
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        raise ExtractorError(
            '%s said: %s' % (LinuxAcademyIE.IE_NAME, 'error'), expected=True)
    except ExtractorError as e:
        assert isinstance(e.cause, compat_HTTPError)
        assert e.cause.code == 401

# Generated at 2022-06-24 12:56:58.064705
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    r = LinuxAcademyIE()
    assert(r.ie_key() == 'LinuxAcademy')
    assert(r.IE_NAME == 'LinuxAcademy')
    assert(r.ie_key() in r.info_extractors.keys())
    assert(r.IE_NAME in r.info_extractors.keys())

# Generated at 2022-06-24 12:57:00.584332
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'
    assert LinuxAcademyIE.ie_key() == LinuxAcademyIE.ie_key()
    assert LinuxAcademyIE.test() == "linuxacademy.com"

# Generated at 2022-06-24 12:57:08.408407
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    get_login_info = LinuxAcademyIE._get_login_info
    get_login_info = staticmethod(get_login_info)
    if get_login_info.__name__ != LinuxAcademyIE._get_login_info.__name__:
        raise AssertionError('methods should be equal')

    LinuxAcademyIE._get_login_info = staticmethod(lambda dummy: (None, None))
    try:
        import youtube_dl.utils  # unavailable in unit tests
        youtube_dl.utils.clean_html
    except ImportError:
        # unit tests
        LinuxAcademyIE._download_webpage = staticmethod(lambda x, y, z, **e: '{}')

# Generated at 2022-06-24 12:57:09.113234
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:57:12.461788
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    i = LinuxAcademyIE()
    url = "https://linuxacademy.com/cp/modules/view/id/154"
    assert i.suitable(url)
    assert i.extract(url)


# Generated at 2022-06-24 12:57:13.957722
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie is not None

# Generated at 2022-06-24 12:57:15.715010
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.__class__.__name__ == 'LinuxAcademyIE'

# Generated at 2022-06-24 12:57:24.541514
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():

    # Test for empty constructor
    linuxAcademyIE = LinuxAcademyIE()
    
    # Test for constructor with valid URL
    linuxAcademyIE = LinuxAcademyIE('https://linuxacademy.com/cp/modules/view/id/154')

    # Test for constructor with invalid URL
    linuxAcademyIE = LinuxAcademyIE('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')

    # Test for constructor with None as URL
    linuxAcademyIE = LinuxAcademyIE(None)

    return

# Generated at 2022-06-24 12:57:33.586253
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    if LinuxAcademyIE not in globals().values():
        return 'LinuxAcademyIE not defined'
    try:
        instance = globals()[LinuxAcademyIE.__name__]()
    except:
        return 'Could not instantiate class: ' + LinuxAcademyIE.__name__
    for attr in dir(instance):
        if hasattr(getattr(linuxacademy, attr), '__call__'):
            try:
                getattr(instance, attr)()
            except:
                return 'Method failed: ' + LinuxAcademyIE.__name__ + '.' + attr + '()'
    return 'ok'