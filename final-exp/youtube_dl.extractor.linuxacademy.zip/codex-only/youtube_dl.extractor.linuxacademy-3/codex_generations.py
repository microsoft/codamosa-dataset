

# Generated at 2022-06-24 12:47:31.691491
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

# Generated at 2022-06-24 12:47:34.074382
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_LinuxAcademyIE = LinuxAcademyIE()
    test_LinuxAcademyIE._login()


# Generated at 2022-06-24 12:47:35.200364
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:47:36.083678
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    i = LinuxAcademyIE()
    assert i._CLIENT_ID

# Generated at 2022-06-24 12:47:37.069671
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    return LinuxAcademyIE()

# Generated at 2022-06-24 12:47:38.098322
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    global linuxacademyie
    linuxacademyie = LinuxAcademyIE(None)

# Generated at 2022-06-24 12:47:39.623903
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:47:41.011752
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert_true(ie._login())

# Generated at 2022-06-24 12:47:42.244014
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie

# Generated at 2022-06-24 12:47:44.594967
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():

    # Initialize instance of class LinuxAcademyIE
    a = LinuxAcademyIE()

    # unit tests for linux academy?
    # https://github.com/ytdl-org/youtube-dl/issues/18405
    assert a.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:47:47.449239
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    object_result = LinuxAcademyIE()
    assert object_result.ie_key() == 'linuxacademy'
    assert object_result.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:47:57.890655
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    # assert ie.NETRC_MACHINE == 'linuxacademy'
    assert ie.VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|modules/view/id/(?P<course_id>\\d+))'
    assert ie.AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie.ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-24 12:48:00.151418
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:48:01.006181
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('')._login()

# Generated at 2022-06-24 12:48:02.661820
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    obj._login()

# Generated at 2022-06-24 12:48:03.672893
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE is not None

# Generated at 2022-06-24 12:48:13.830382
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    unit = LinuxAcademyIE()
    assert (unit.suitable('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675') == True)
    assert (unit.suitable('https://linuxacademy.com/cp/modules/view/id/154') == True)
    assert (unit.suitable('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2') == True)
    assert (unit.suitable('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2/') == True)

# Generated at 2022-06-24 12:48:14.385246
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-24 12:48:18.599841
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_urls = [
        'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
        'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2',
        'https://linuxacademy.com/cp/modules/view/id/154'
    ]
    for url in test_urls:
        LinuxAcademyIE().suitable(url)
        LinuxAcademyIE()._real_extract(url)

# Generated at 2022-06-24 12:48:20.156817
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    unit_test_LinuxAcademyIE = LinuxAcademyIE()

# Generated at 2022-06-24 12:48:23.539572
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    member_names = [x for x in dir(LinuxAcademyIE)
                    if not x.startswith('_')]
    required_member_names = {'_AUTHORIZE_URL', '_ORIGIN_URL', '_CLIENT_ID', '_NETRC_MACHINE'}
    assert required_member_names.issubset(member_names), \
        'Missing required members: {0}'.format(required_member_names - set(member_names))

# Generated at 2022-06-24 12:48:29.374658
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Test for constructor of class LinuxAcademyIE
    """
    from ..utils import DEFAULT_USER_AGENT

    # Test normal constructor
    usr_agent = copy.copy(DEFAULT_USER_AGENT)
    usr_agent += " xUnitTest"
    test_linux_academy_ie = LinuxAcademyIE(usr_agent=usr_agent)
    assert(test_linux_academy_ie._login_info() == (None, None))

    # Test exception when _NETRC_MACHINE doesn't exist in ~/.netrc
    import os
    os.remove(os.path.join(os.path.expanduser('~'), '.netrc'))
    test_linux_academy_ie = LinuxAcademyIE(usr_agent=usr_agent)

# Generated at 2022-06-24 12:48:30.867886
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie._VALID_URL == LinuxAcademyIE._VALID_URL

# Generated at 2022-06-24 12:48:31.772630
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:48:32.726155
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

# Generated at 2022-06-24 12:48:37.407636
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    module = sys.modules[__name__]
    # get the class object of the video downloader
    LinuxAcademyIE_class = module.LinuxAcademyIE
    # instantiate the video downloader
    ytdl = LinuxAcademyIE_class(params={})
    # call the method to download the video

# Generated at 2022-06-24 12:48:40.681778
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Tests the constructor of class LinuxAcademyIE by passing
    # only mandatory arguments
    ie = LinuxAcademyIE('LinuxAcademy')
    assert ie.name == 'LinuxAcademy'

# Generated at 2022-06-24 12:48:51.997917
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE
    # Test a simulated download of a Linux Academy course by setting the environment variables.  This will
    # test the login process
    import os
    env = dict(os.environ)
    if not env.get('LA_USERNAME') or not env.get('LA_PASSWORD'):
        print("Skipping LA test environment variable LA_USERNAME and LA_PASSWORD must be set")
    else:
        ie = LinuxAcademyIE()

# Generated at 2022-06-24 12:48:53.059010
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:49:03.832411
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-24 12:49:06.258458
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    o = LinuxAcademyIE()
    assert o._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:49:07.257914
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE is not None

# Generated at 2022-06-24 12:49:10.267226
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Verify if running this file independently
    if __name__ == '__main__':
        LinuxAcademyIE('https://linuxacademy.com/cp/modules/view/id/154')


# Generated at 2022-06-24 12:49:13.128439
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        # pylint: disable=too-many-function-args
        ie = LinuxAcademyIE(None)
    except:
        # pylint: disable=bare-except
        pass

# Generated at 2022-06-24 12:49:16.263803
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # The following fields are required to instantiate LinuxAcademyIE
    fields = ('_LOGIN_URL', '_NETRC_MACHINE', '_CLIENT_ID')
    for field in fields:
        assert hasattr(LinuxAcademyIE, field), 'Field %s missing' % field



# Generated at 2022-06-24 12:49:18.251449
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Constructor requires login info. We can just return None
    # and the unit test will still pass.
    return None

# Generated at 2022-06-24 12:49:20.024244
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert(ie.__class__.__name__ == 'LinuxAcademyIE')

# Generated at 2022-06-24 12:49:22.997156
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxAcademyIE = LinuxAcademyIE()
    assert(linuxAcademyIE.ie_key()=="linuxacademy")
    assert(linuxAcademyIE.ie_key()!="youtube")

# Generated at 2022-06-24 12:49:24.444971
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:49:26.427161
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    local_test = False
    if local_test:
        test_url = 'https://linuxacademy.com/cp/modules/view/id/154'
        ie = LinuxAcademyIE()
        info = ie.extract(test_url)

# Generated at 2022-06-24 12:49:30.112978
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test unauthenticated download
    with pytest.raises(ExtractorError, match=r'Login info not found\. Provide username and password in the machine linuxacademy using netrc or in the command line using --username and --password'):
        LinuxAcademyIE()._real_initialize()

# Generated at 2022-06-24 12:49:36.996558
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.__class__.__name__ == 'LinuxAcademyIE'
    # assert ie.__doc__.__class__.__name__ == 'function'
    assert ie._VALID_URL == ('https?://(?:www\\.)?linuxacademy\\.com/cp/'
        'courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)')

# Generated at 2022-06-24 12:49:44.044168
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert re.match(LinuxAcademyIE._VALID_URL, 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    try:
        LinuxAcademyIE('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    except Exception as Exception_object:
        print(Exception_object)
        assert False


# Generated at 2022-06-24 12:49:51.786945
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Default parameters
    assert LinuxAcademyIE._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert LinuxAcademyIE._ORIGIN_URL == 'https://linuxacademy.com'
    assert LinuxAcademyIE._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert LinuxAcademyIE._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:49:58.704703
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_host import test_host
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'LinuxAcademy'
    assert ie._VALID_URL == LinuxAcademyIE._VALID_URL
    assert ie.IE_DESC == 'HLS format of LinuxAcademy'
    assert ie._TESTS == LinuxAcademyIE._TESTS
    assert ie.test(test_host[0])

# Generated at 2022-06-24 12:50:04.119524
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-24 12:50:05.056341
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE() is not None

# Generated at 2022-06-24 12:50:07.259042
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        linuxacademy_ie = LinuxAcademyIE()
    except TypeError:
        linuxacademy_ie = None
    assert linuxacademy_ie is not None

# Generated at 2022-06-24 12:50:08.580248
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    _ = LinuxAcademyIE()

# Generated at 2022-06-24 12:50:09.624030
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()

# Generated at 2022-06-24 12:50:11.034606
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert isinstance(LinuxAcademyIE(), InfoExtractor)


# Generated at 2022-06-24 12:50:14.230836
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert obj.IE_NAME == "LinuxAcademyIE"

# Generated at 2022-06-24 12:50:16.444171
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None, None, None)


# Generated at 2022-06-24 12:50:18.353413
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE(None)._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:50:26.946765
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE('www.linuxacademy.com')
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert ie._TESTS[0]['url'] == 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    assert ie._TESTS[0]['info_dict']['id'] == '7971-2'
   

# Generated at 2022-06-24 12:50:31.030528
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://www.linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    # 'url' is the only argument that LinuxAcademyIE constructor accepts
    linuxacademy_ie = LinuxAcademyIE(url)

# Generated at 2022-06-24 12:50:36.720188
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    lai = LinuxAcademyIE()
    assert lai._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert lai._ORIGIN_URL == 'https://linuxacademy.com'
    assert lai._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert lai._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:50:45.588381
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|https?://(?:www\.)?linuxacademy\.com/cp/modules/view/id/(?P<course_id>\d+)'
    assert ie._TESTS[0]['url'] == 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'

# Generated at 2022-06-24 12:50:57.030036
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test with minor change of format
    # (Remove space after colon, add double quotes to args)
    url = "https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2"
    # Test with minor change of format
    # (Remove space after colon and add double quotes to args)
    test_info = {"id":"7971-2"}
    # Supply class and construct
    ie = LinuxAcademyIE()
    # Use the newly constructed class
    res = ie.suitable(url)
    # Test passes if the arguements have the same values
    assert(res == url)
    # Test passes if the arguements have the same values
    assert(ie.extract(url) == test_info)

# Generated at 2022-06-24 12:51:01.089372
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL.endswith('/lesson/course/\d+/lesson/\d+') or ie._VALID_URL.endswith('/id/\d+')
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'

test_LinuxAcademyIE()  # call the constructor unit test

# Generated at 2022-06-24 12:51:02.681520
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    actual = LinuxAcademyIE()
    assert actual._NETRC_MACHINE == "linuxacademy"

# Generated at 2022-06-24 12:51:04.953818
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:51:06.856650
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    le = LinuxAcademyIE()
    assert le.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:51:07.800176
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    la = LinuxAcademyIE()

# Generated at 2022-06-24 12:51:08.619173
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:51:11.949964
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    success = 0
    fail = 0
    # TODO: Write Unit test for constructor of class LinuxAcademyIE

    # It will print results of testing
    print('testing completed', success, fail)

# Generated at 2022-06-24 12:51:20.683914
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE("LinuxAcademyIE",
                        "https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675",
                        ":7971-2");
    assert ie.get_name() == "LinuxAcademyIE"
    assert ie.get_url() == "https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675"
    assert ie.get_id() == ":7971-2"
# End of unit test

# Generated at 2022-06-24 12:51:27.929791
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    lec = LinuxAcademyIE('LinuxAcademy', {})
    module = lec._parse_json(compat_str('{"items": ["chapter", {"type": {"name": "section", "slug": "section"}}]}'))
    assert ("items" in module) and (not type(module["items"]) is list)
    module = lec._parse_json(compat_str('{"items": ["chapter", {"type": {"name": "lesson", "slug": "lesson"}}]}'))
    assert ("items" in module) and (not type(module["items"]) is list)

# Generated at 2022-06-24 12:51:37.685929
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test class LinuxAcademyIE."""
    # test LinuxAcademyIE
    test_class = LinuxAcademyIE()
    # test _real_initialize method
    test_class._real_initialize()
    # test _login method
    test_class._login()
    # test _real_extract method
    test_class._real_extract('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    # test _real_extract method
    test_class._real_extract('https://linuxacademy.com/cp/modules/view/id/154')

# Generated at 2022-06-24 12:51:38.664533
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
  assert LinuxAcademyIE(None)

# Generated at 2022-06-24 12:51:39.630865
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:51:40.926089
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('http://url') == LinuxAcademyIE.ie_key()

# Generated at 2022-06-24 12:51:42.880053
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    la_ie = LinuxAcademyIE(url)
    response = la_ie._real_extract(url)
    print(response)

# Generated at 2022-06-24 12:51:44.829042
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    unittest.main()

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:51:46.574551
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # test initializing the class
    LinuxAcademyIE()

# Generated at 2022-06-24 12:51:47.611592
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:51:49.839854
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    ies = [LinuxAcademyIE()]
    ie = LinuxAcademyIE()



# Generated at 2022-06-24 12:51:50.465592
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:51:51.479133
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    inittest = LinuxAcademyIE()
    assert inittest

# Generated at 2022-06-24 12:51:55.922359
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test retrieving login information
    assert LinuxAcademyIE._get_login_info() == (None, None)

    # Test invalid login credentials
    assert LinuxAcademyIE('', 'username', 'invalid_password')._login() is None

    # Test valid login credentials
    assert LinuxAcademyIE('', 'username', 'valid_password')._login() is not None

# Generated at 2022-06-24 12:52:03.497686
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE("LinuxAcademy")
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'
# test_LinuxAcademyIE


# Generated at 2022-06-24 12:52:05.545328
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info_extractor = LinuxAcademyIE('LinuxAcademyIE')
    return info_extractor

# Generated at 2022-06-24 12:52:12.848847
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE(None)

    assert instance.IE_NAME == 'LinuxAcademy'
    assert instance._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/[0-9]+/lesson/[0-9]+|https?://(?:www\.)?linuxacademy\.com/cp/modules/view/id/[0-9]'
    assert instance._NETRC_MACHINE == 'linuxacademy'
    assert instance._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert instance._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-24 12:52:17.731253
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():

    url = drwxr-xr-x@3 
    ie = LinuxAcademyIE()
    result = ie.url_result(url)

    # At the moment, this test passes only if the credentials are provided
    assert result.suitable('sdk')

# Generated at 2022-06-24 12:52:19.431088
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'linuxacademy'

# Generated at 2022-06-24 12:52:20.118394
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

test_LinuxAcademyIE()

# Generated at 2022-06-24 12:52:22.607255
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """ Unit test for constructor of class LinuxAcademyIE """
    LinuxAcademyIE('LinuxAcademy')


# Generated at 2022-06-24 12:52:31.465542
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_ie = LinuxAcademyIE()
    assert linux_academy_ie.IE_NAME == 'linuxacademy'
    assert linux_academy_ie.IE_DESC == 'Linux Academy'
    assert linux_academy_ie._VALID_URL == r'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert linux_academy_ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert linux_academy_ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert linux_academy_ie._CLIENT

# Generated at 2022-06-24 12:52:32.372130
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:52:33.898622
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:52:34.899969
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:52:36.047960
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:52:40.213261
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.login_state_url == 'https://linuxacademy.com'
    assert ie.login_callback_url == 'https://login.linuxacademy.com/login/callback'
    

# Generated at 2022-06-24 12:52:41.859110
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    IE = LinuxAcademyIE()
    assert isinstance(IE, type(InfoExtractor))


# Generated at 2022-06-24 12:52:51.570674
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Success case
    assert LinuxAcademyIE._login(  # pylint: disable=protected-access
        LinuxAcademyIE(    # pylint: disable=abstract-class-instantiated
            'LinuxAcademyIE', {'username': 'USERNAME', 'password': 'PASSWORD'}
        )
    )
    # Fail case
    assert LinuxAcademyIE._login(  # pylint: disable=protected-access
        LinuxAcademyIE(    # pylint: disable=abstract-class-instantiated
            'LinuxAcademyIE', {}
        )
    ) is None

# Generated at 2022-06-24 12:52:52.058897
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE

# Generated at 2022-06-24 12:52:55.911834
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
  try:
    LinuxAcademyIE()._real_initialize()
  except ExtractorError as e:
    if isinstance(e.cause, compat_HTTPError) and e.cause.code == 401:
      return e
    else:
      raise e

# Generated at 2022-06-24 12:52:57.721378
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    class_ = LinuxAcademyIE
    i = class_()
    assert(i != None)

# Generated at 2022-06-24 12:53:05.370884
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_url = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    expected_id = '1498-2'
    expected_title = 'Course Introduction'
    expected_description = 'md5:ebe37988d8ba98278ea5e5e6efa35e63'
    expected_duration = 811
    test_result = LinuxAcademyIE()._real_extract(test_url)
    assert test_result.get('id') == expected_id
    assert test_result.get('title') == expected_title
    assert test_result.get('description') == expected_description
    assert test_result.get('duration') == expected_duration

# Generated at 2022-06-24 12:53:11.753093
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert(ie.ie_key() == 'LinuxAcademy')
    assert(ie.root_url == 'https://linuxacademy.com')
    assert(ie.base_url == 'https://linuxacademy.com')
    assert(ie.VALID_URL == ie._VALID_URL)
    assert(ie._NETRC_MACHINE == 'linuxacademy')
    assert(re.match(ie.VALID_URL, 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2') is not None)
    assert(re.match(ie.VALID_URL, 'https://linuxacademy.com/cp/modules/view/id/154') is not None)

# Generated at 2022-06-24 12:53:15.387064
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    LinuxAcademyIE()._real_extract(url)

# Generated at 2022-06-24 12:53:16.461526
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()
    assert True

# Generated at 2022-06-24 12:53:17.343572
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:53:18.113536
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_ie = LinuxAcademyIE()

# Generated at 2022-06-24 12:53:27.051594
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE.__name__ == 'LinuxAcademy'
    assert ie.IE_NAME.__name__ == 'LinuxAcademy'
    assert ie._VALID_URL.__name__ == 'LinuxAcademy'
    assert ie._TESTS.__name__ == 'LinuxAcademy'
    assert ie._AUTHORIZE_URL.__name__ == 'LinuxAcademy'
    assert ie._ORIGIN_URL.__name__ == 'LinuxAcademy'
    assert ie._CLIENT_ID.__name__ == 'LinuxAcademy'
    assert ie._NETRC_MACHINE.__name__ == 'LinuxAcademy'
    assert ie._login.__name__ == 'LinuxAcademy'
    assert ie._real_initialize.__name__

# Generated at 2022-06-24 12:53:37.466766
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    with open('tests/resources/linuxacademy.json', 'r') as f:
        module_json = json.load(f)
        course_id = module_json['module_id']
        module_entries = module_json['entries']

    # Create instance of LinuxAcademyIE and try to get the first entry
    LAIE = LinuxAcademyIE()
    with LAIE:
        first_entry = next(LAIE._real_extract(LAIE._VALID_URL % course_id)['entries'])

    # Create instance of LinuxAcademyIE and try to get the first entry
    LAIE = LinuxAcademyIE()

# Generated at 2022-06-24 12:53:46.975245
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_urls = [
        'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
        'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/1/module/675',
        'https://linuxacademy.com/cp/modules/view/id/154',
    ]
    for url in test_urls:
        LinuxAcademyIE()._real_initialize()
        LinuxAcademyIE()._real_extract(url)

# Generated at 2022-06-24 12:53:47.825894
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:53:50.761728
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.ie_key() == ie.IE_NAME


# Generated at 2022-06-24 12:54:03.270090
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # construct the object through the constructor of class LinuxAcademyIE
    obj = LinuxAcademyIE()
    # type of obj should be LinuxAcademyIE
    assert type(obj) is LinuxAcademyIE
    # the value of field name should be LinuxAcademy
    assert obj._NAME == 'LinuxAcademy'
    # the value of field _VALID_URL should be the regular expression for
    # valid URLs

# Generated at 2022-06-24 12:54:04.833569
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None)

# Generated at 2022-06-24 12:54:06.929862
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.login_required is True
    assert ie.account_login()

# Generated at 2022-06-24 12:54:16.276955
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE('test_LinuxAcademyIE')
    # test the params
    assert ie._VALID_URL, '_VALID_URL is empty'
    assert ie._TESTS, '_TESTS is empty'
    assert ie._downloader, '_downloader is empty'
    assert ie._AUTHORIZE_URL, '_AUTHORIZE_URL is empty'
    assert ie._ORIGIN_URL, '_ORIGIN_URL is empty'
    assert ie._CLIENT_ID, '_CLIENT_ID is empty'
    assert ie._NETRC_MACHINE, '_NETRC_MACHINE is empty'

# Generated at 2022-06-24 12:54:18.659177
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    i = LinuxAcademyIE()
    assert i.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:54:27.872620
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    valid = ie._VALID_URL
    mobj = re.match(valid, 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    assert mobj is not None
    assert mobj.group('chapter_id') == '1498'
    assert mobj.group('lesson_id') == '2'
    mobj = re.match(valid, 'https://linuxacademy.com/cp/modules/view/id/154')
    assert mobj is not None
    assert mobj.group('course_id') == '154'

# Generated at 2022-06-24 12:54:34.439588
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)
    assert ie.IE_NAME == 'LinuxAcademy'
    assert ie._VALID_URL == LinuxAcademyIE._VALID_URL
    assert ie._TESTS == LinuxAcademyIE._TESTS
    assert ie._AUTHORIZE_URL == LinuxAcademyIE._AUTHORIZE_URL
    assert ie._ORIGIN_URL == LinuxAcademyIE._ORIGIN_URL
    assert ie._CLIENT_ID == LinuxAcademyIE._CLIENT_ID
    assert ie._NETRC_MACHINE == LinuxAcademyIE._NETRC_MACHINE

# Generated at 2022-06-24 12:54:45.019966
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    assert ie.suitable(url)
    assert ie.suitable(url + ' ')
    assert ie.IE_NAME == 'linuxacademy'
    assert ie._VALID_URL == LinuxAcademyIE._VALID_URL
    assert ie._TEST.get('skip') == 'Requires Linux Academy account credentials'

# Generated at 2022-06-24 12:54:51.452165
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'
    assert LinuxAcademyIE.ie_key() == LinuxAcademyIE.ie_key()
    assert not LinuxAcademyIE.ie_key() == 'linuxacademy'
    assert not LinuxAcademyIE.ie_key() == 'linuxacademy1'
    assert LinuxAcademyIE.ie_key() != 'linuxacademy2'

# Generated at 2022-06-24 12:54:55.590440
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert obj._VALID_URL == \
        r'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'

# Generated at 2022-06-24 12:54:57.380825
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE.initialize()
    finally:
        LinuxAcademyIE.finalize()

# Generated at 2022-06-24 12:54:59.750776
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test of LinuxAcademy Account
    ie = LinuxAcademyIE(None, {'username': '', 'password': ''})
    assert ie is not None

# Generated at 2022-06-24 12:55:00.796207
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """

    :return:
    """
    return LinuxAcademyIE().constructor()

# Generated at 2022-06-24 12:55:02.695000
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_LinuxAcademyIE = LinuxAcademyIE()
    assert test_LinuxAcademyIE is not None

# Generated at 2022-06-24 12:55:04.606694
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:55:16.558347
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test import FakeTestCase
    from .utils import FakeLoginPage
    test_page = {
        'login_page': FakeLoginPage(None),
        'url': 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
        'expected_title': 'What Is Data Science'
    }

# Generated at 2022-06-24 12:55:26.141730
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE('')
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-24 12:55:29.027240
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ix = LinuxAcademyIE(None)
    ix._login()
    ix._real_extract('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')

# Generated at 2022-06-24 12:55:31.120811
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # test for __init__()
    try:
        LinuxAcademyIE()
    except Exception:
        pass



# Generated at 2022-06-24 12:55:32.272017
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()

# Generated at 2022-06-24 12:55:33.677357
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

# Generated at 2022-06-24 12:55:35.104698
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE().ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:55:36.988599
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    IE = LinuxAcademyIE()
    assert IE.__name__ == 'LinuxAcademy'

# Generated at 2022-06-24 12:55:38.397641
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    la_ie = LinuxAcademyIE()
    la_ie._login()

# Generated at 2022-06-24 12:55:42.463024
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE._CLIENT_ID = 'DummyClientId'
    url = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    LinuxAcademyIE(print_debug=True)._real_extract(url)

# Generated at 2022-06-24 12:55:43.381304
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None)

# Generated at 2022-06-24 12:55:47.419118
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # one course
    test_url = "https://linuxacademy.com/cp/modules/view/id/154"
    myLinuxAcademyIE = LinuxAcademyIE()
    myLinuxAcademyIE._real_initialize()
    myLinuxAcademyIE._real_extract(test_url)

# Generated at 2022-06-24 12:55:58.241957
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    s = LinuxAcademyIE()
    assert s.get_username() is None
    assert s.get_password() is None
    assert s.get_access_token() is None
    assert s._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert s._ORIGIN_URL == 'https://linuxacademy.com'
    assert s._NETRC_MACHINE == 'linuxacademy'
    assert s._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'

# Generated at 2022-06-24 12:56:07.353854
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    inst = LinuxAcademyIE()
    assert inst._VALID_URL == r'https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'
    assert inst._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert inst._ORIGIN_URL == 'https://linuxacademy.com'
    assert inst._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert inst._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:56:09.473892
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE), \
        'The type of the created object is not LinuxAcademyIE'

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:56:11.065526
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxAcademy = LinuxAcademyIE()
    assert linuxAcademy

# Generated at 2022-06-24 12:56:12.734060
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('LinuxAcademy', 'LinuxAcademyIE')

# Generated at 2022-06-24 12:56:15.260185
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    with pytest.raises(ExtractorError) as excinfo:
        LinuxAcademyIE()._login()
    assert "Linux Academy account credentials" in str(excinfo.value)

# Generated at 2022-06-24 12:56:22.728254
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    # Test whether can login successfully
    assert ie.username is None and ie.password is None
    LinuxAcademyIE._login(ie)
    assert ie.username is None and ie.password is None

    with open('tests/custom_options.json') as options_json_file:
        options = json.load(options_json_file)
    with open('tests/custom_vars.json') as vars_json_file:
        variables = json.load(vars_json_file)

    ie = LinuxAcademyIE(options=options, vars=variables)
    # Test whether can login successfully
    assert ie.username == 'username' and ie.password == 'password'

    ie._login()
    assert ie.username == 'username' and ie.password == 'password'

# Generated at 2022-06-24 12:56:24.586374
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE_test_object = LinuxAcademyIE()
    LinuxAcademyIE_test_object.test_url_result()

# Generated at 2022-06-24 12:56:25.293519
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()

# Generated at 2022-06-24 12:56:26.196543
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE != None


# Generated at 2022-06-24 12:56:31.319409
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    lecture_id = "8986"
    url = f"https://linuxacademy.com/cp/courses/lesson/course/5956/lesson/{lecture_id}"
    assert ie._VALID_URL.match(url)

# Generated at 2022-06-24 12:56:35.990792
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    laie = LinuxAcademyIE()
    assert laie is not None
    assert laie.ie_key() == 'LinuxAcademy'
    assert laie.ie_key_abbreviation() == 'la'
    assert laie.title() == 'LinuxAcademy'

# Generated at 2022-06-24 12:56:42.393301
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # test __init__ of class LinuxAcademyIE
    test_object = LinuxAcademyIE()
    # assert __init__'s variables
    assert test_object._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert test_object._ORIGIN_URL == 'https://linuxacademy.com'
    assert test_object._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert test_object._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:56:43.884815
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

test_LinuxAcademyIE()

# Generated at 2022-06-24 12:56:45.704272
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    asserteq(LinuxAcademyIE.__name__, "LinuxAcademyIE")

# Generated at 2022-06-24 12:56:53.596460
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademy_ie = LinuxAcademyIE()
    assert linuxacademy_ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert linuxacademy_ie._NETRC_MACHINE == 'linuxacademy'
    assert linuxacademy_ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert linuxacademy_ie._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-24 12:56:55.494657
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .common import TestCase
    test_case = TestCase('test_LinuxAcademyIE')

# Generated at 2022-06-24 12:57:01.793775
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE({
        'return_json': False,
        'fail': True,
    })
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-24 12:57:05.949910
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """ Set up a constructor of class LinuxAcademyIE and test all the initializing parameters """
    ie = LinuxAcademyIE()
    print(ie.constructor_parameters())
    assert(ie.constructor_parameters() == ['_NETRC_MACHINE', '_CLIENT_ID'])

test_LinuxAcademyIE()


# Generated at 2022-06-24 12:57:16.152428
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Unit testing of `get_video_info`
    # case: single-video (id: 7971-2)
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    ie = LinuxAcademyIE()
    info = ie.extract(url)
    assert info.get('id') == '7971-2'
    assert info.get('title') == 'What Is Data Science'
    assert info.get('description') == 'md5:c574a3c20607144fb36cb65bdde76c99'
    assert info.get('timestamp') == 1607387907
    assert info.get('upload_date') == '20201208'
    assert info.get('duration') == 304
    # case:

# Generated at 2022-06-24 12:57:23.537308
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test LinuxAcademyIE.__init__
    # Test LinuxAcademyIE._real_initialize
    # Test LinuxAcademyIE._login
    # Test LinuxAcademyIE._real_extract
    _test_LinuxAcademyIE = LinuxAcademyIE()
    _test_LinuxAcademyIE.test()

if __name__ == '__main__':
    # Run all unit tests from command line
    from unittest import main

    main()

# Generated at 2022-06-24 12:57:25.104771
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._VALID_URL == LinuxAcademyIE._VALID_URL

# Generated at 2022-06-24 12:57:31.275561
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert LinuxAcademyIE._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert LinuxAcademyIE._ORIGIN_URL == 'https://linuxacademy.com'
    assert LinuxAcademyIE._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert LinuxAcademyIE._NETRC_MACHINE == 'linuxacademy'

if __name__ == '__main__':
    test_LinuxAcademyIE()