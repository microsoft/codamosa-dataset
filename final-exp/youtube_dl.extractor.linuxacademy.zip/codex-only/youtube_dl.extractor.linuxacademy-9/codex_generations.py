

# Generated at 2022-06-24 12:47:32.505400
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:47:33.615184
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()
    pass

# Generated at 2022-06-24 12:47:36.361732
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    lx = LinuxAcademyIE()
    assert lx.__class__.__name__ == 'LinuxAcademyIE'

# Generated at 2022-06-24 12:47:37.912861
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert (LinuxAcademyIE.__name__ == 'LinuxAcademy')

# Generated at 2022-06-24 12:47:48.877139
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import unittest

    # Unit test for LinuxAcademyIE constructor
    class TestLinuxAcademyIE(unittest.TestCase):
        def setUp(self):
            self.password = '****'
            self.username = '****'
            self.intro_url = 'https://linuxacademy.com/cp/modules/view/id/154'
            self.video_url = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'

        def test_using_login_info(self):
            ie = LinuxAcademyIE(username=self.username, password=self.password)
            ie._login()


# Generated at 2022-06-24 12:47:50.227688
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    video = LinuxAcademyIE()
    return video._login()

# Generated at 2022-06-24 12:47:59.773807
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert(LinuxAcademyIE().ie_key() == 'LinuxAcademy')
    assert(LinuxAcademyIE()._VALID_URL == r'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)')
    assert(LinuxAcademyIE()._NETRC_MACHINE == 'linuxacademy')
    assert(LinuxAcademyIE()._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize')
    assert(LinuxAcademyIE()._ORIGIN_URL == 'https://linuxacademy.com')

# Generated at 2022-06-24 12:48:00.625374
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE is not None

# Generated at 2022-06-24 12:48:02.617553
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:48:05.590560
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-24 12:48:15.409803
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:48:17.226888
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE("https://www.linuxacademy.com/cp/courses/lesson/course/5299/lesson/2")
    except TypeError:
        assert False
    else:
        assert True

# Generated at 2022-06-24 12:48:19.595665
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # These are simple test to know if the object is created
    ie = LinuxAcademyIE()
    assert ie != ""

# Generated at 2022-06-24 12:48:24.131380
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'
 
    # create object of class LinuxAcademyIE
    object_ = LinuxAcademyIE()

    # call to method ie_key
    out = object_.ie_key()

    # check response
    assert out == 'LinuxAcademy'

# Generated at 2022-06-24 12:48:31.367222
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test = LinuxAcademyIE()
    assert test.IE_NAME == 'linuxacademy'
    assert test._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert test._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert test._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-24 12:48:34.959369
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Unit test for constructor of class LinuxAcademyIE
    """
    ie = LinuxAcademyIE()
    assert ie._CLIENT_ID
    assert ie._NETRC_MACHINE
    assert ie._ORIGIN_URL
    assert ie._AUTHORIZE_URL

# Generated at 2022-06-24 12:48:44.415930
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    inst = LinuxAcademyIE()
    assert inst.ie_key() == 'LinuxAcademy'
    assert inst.IE_NAME == 'linuxacademy'
    assert inst._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert inst.SUPPORTED_ext == ['mp4']
    assert inst._TESTS[0]['url'] == "https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675"
    assert inst._TESTS[0]['info_dict']['title'] == "What Is Data Science"
    assert inst._TES

# Generated at 2022-06-24 12:48:45.975218
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert(ie.test_login())

# Generated at 2022-06-24 12:48:47.371731
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

# Generated at 2022-06-24 12:48:51.012427
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademy_ie = LinuxAcademyIE(TestExtractor, False)
    assert linuxacademy_ie.username is None
    assert linuxacademy_ie.password is None



# Generated at 2022-06-24 12:48:52.047581
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE('LinuxAcademy')

# Generated at 2022-06-24 12:48:53.933872
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
    except Exception as e:
        print(e)

# Generated at 2022-06-24 12:48:57.584643
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    # difference between python 2 and 3
    if hasattr(instance, '_real_initialize'):
        instance._real_initialize()
    else:
        instance._login()

# Generated at 2022-06-24 12:48:58.248802
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:49:00.069510
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    login = ie._login()
    assert login is None


# Generated at 2022-06-24 12:49:01.459524
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    return ie._VALID_URL

# Generated at 2022-06-24 12:49:03.159439
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'

# Generated at 2022-06-24 12:49:09.165710
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Unit test for constructor of class LinuxAcademyIE
    """

    ie = LinuxAcademyIE()
    assert ie._VALID_URL
    assert ie._TESTS
    assert ie._AUTHORIZE_URL
    assert ie._ORIGIN_URL
    assert ie._CLIENT_ID
    assert ie._NETRC_MACHINE
    
    # Test default values of its member variables if any
    assert ie._login == LinuxAcademyIE._login
    assert ie._real_initialize == LinuxAcademyIE._real_initialize
    assert ie._real_extract == LinuxAcademyIE._real_extract

# Generated at 2022-06-24 12:49:14.937480
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert os.path.isfile('./linuxacademy_test.txt')
    with open('./linuxacademy_test.txt','r') as file:
        li = []
        for line in file:
            line = line.strip('\n')
            li.append(line)
    
    username = li[0]
    password = li[1]

    # Initialize
    ie = LinuxAcademyIE(username = username, password = password)

    # Test extract
    url = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    ie.extract(url)

    # Test _real_extract

# Generated at 2022-06-24 12:49:24.574514
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademyie = LinuxAcademyIE('linuxacademy')
    assert linuxacademyie._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|modules/view/id/(?P<course_id>\\d+))'
    assert linuxacademyie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert linuxacademyie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:49:26.349524
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
  ie = LinuxAcademyIE()
  print(str(ie))

# Generated at 2022-06-24 12:49:35.538076
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'LinuxAcademy'
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.NETRC_MACHINE == 'linuxacademy'
    assert ie.VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert ie.ACCOUNT_NAME == 'Linux Academy'

# Generated at 2022-06-24 12:49:36.390014
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE

# Generated at 2022-06-24 12:49:37.251157
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:49:47.130197
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # raises error when no credentials specified
    assert LinuxAcademyIE(url='https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')._real_initialize()

    # raises error when invalid credentials specified
    ie = LinuxAcademyIE(url='https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    ie.username = 'invalid'
    ie.password = 'invalid'
    with pytest.raises(ExtractorError) as cm:
        ie._real_initialize()
    assert 'invalid credentials' in str(cm.value)

# Generated at 2022-06-24 12:49:48.176084
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:49:52.064415
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy = LinuxAcademyIE()
    assert linux_academy._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-24 12:49:53.113440
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:50:00.051547
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Creating test for constructor of class LinuxAcademyIE
    """
    ie = LinuxAcademyIE()
    assert ie._NETRC_MACHINE == "linuxacademy", "Test with _NETRC_MACHINE"
    assert ie._CLIENT_ID == "KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx", "Test with _CLIENT_ID"

# Generated at 2022-06-24 12:50:01.462804
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()
    LinuxAcademyIE()

# Generated at 2022-06-24 12:50:09.678665
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'

# Generated at 2022-06-24 12:50:11.586553
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:50:14.286111
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:50:16.885785
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    my_test = LinuxAcademyIE()
    assert 'LinuxAcademy' == my_test.IE_NAME

# Generated at 2022-06-24 12:50:17.946104
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    return LinuxAcademyIE()

# Generated at 2022-06-24 12:50:19.394800
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('LinuxAcademyIE')

# Generated at 2022-06-24 12:50:22.982243
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie is not None, 'Constructor of class LinuxAcademyIE is failed'

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:50:34.078549
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Unit test for constructor of class LinuxAcademyIE
    """
    from sys import version_info
    from io import StringIO
    from unittest import TestCase
    from unittest.mock import patch
    from pycurl import Curl
    from youtube_dl.compat import version, orderedSet

    class TestLinuxAcademyIE(TestCase):
        def setUp(self):
            self.lae = LinuxAcademyIE()

        # Test case for LinuxAcademyIE.ie_key
        def testie_key(self):
            """
            Unit test for ie_key of LinuxAcademyIE
            """
            result = self.lae.ie_key()
            self.assertEqual(result, 'LinuxAcademy')

        # Test case for LinuxAcademyIE.suitable


# Generated at 2022-06-24 12:50:40.997005
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test instantiation of class LinuxAcademyIE
    test_object = LinuxAcademyIE()
    # Test if URL was constructed correctly
    assert test_object._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    # Test if URL was constructed correctly
    assert test_object._ORIGIN_URL == 'https://linuxacademy.com'
    # Test if Client id was constructed correctly
    assert test_object._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    # Test if Netrc machine name was constructed correctly
    assert test_object._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:50:42.098933
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('test')

# Generated at 2022-06-24 12:50:43.085247
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    return LinuxAcademyIE

# Generated at 2022-06-24 12:50:43.716721
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE

# Generated at 2022-06-24 12:50:45.486812
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert LinuxAcademyIE == ie._get_IE()

# Generated at 2022-06-24 12:50:51.047587
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Some tests to document the exceptions thrown
    try:
        LinuxAcademyIE()
        # Exception thrown
        assert False
    except ExtractorError as e:
        assert 'LinuxAcademy' in e.msg
    extra_config = '-u username -p password'
    li = LinuxAcademyIE(extra_config)
    assert li.username == 'username' and li.password == 'password'

# Generated at 2022-06-24 12:50:58.147158
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test constructor of LinuxAcademyIE
    url = 'https://linuxacademy.com/cp/modules/view/id/154';
    instructor = LinuxAcademyIE(url);

    # Test login() method of LinuxAcademyIE
    instructor._login();

    # Test _real_extract() method of LinuxAcademyIE
    instructor._real_extract(url);

# Generated at 2022-06-24 12:51:01.737872
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    if hasattr(LinuxAcademyIE, '_download_webpage_handle'):
        return

    # Ensure that the login() method is going to be called:
    def login(*args, **kwargs):
        return {}, None

    LinuxAcademyIE._real_initialize = login
    LinuxAcademyIE(None)

# Generated at 2022-06-24 12:51:02.696691
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:51:03.684060
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    lector = LinuxAcademyIE()
    assert lector._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-24 12:51:14.854138
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(None)
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )'''
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-24 12:51:15.900001
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie_object = LinuxAcademyIE('')

# Generated at 2022-06-24 12:51:16.979488
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

# Generated at 2022-06-24 12:51:19.631788
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_url = 'https://linuxacademy.com/cp/modules/view/id/154'
    ie = LinuxAcademyIE(LinuxAcademyIE.create_ie(test_url))
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.suitable(test_url)
    assert ie.working() is False or ie.working() is True

# Generated at 2022-06-24 12:51:26.341859
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == "linuxacademy"
    assert ie.IE_DESC == "Linux Academy"
    assert ie._VALID_URL == r'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:51:38.067469
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    video_url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    username = 'username'
    password = 'password'
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.VALID_URL == LinuxAcademyIE._VALID_URL
    assert ie.TEST == LinuxAcademyIE._TESTS
    assert ie._NETRC_MACHINE == LinuxAcademyIE._NETRC_MACHINE
    assert ie._AUTHORIZE_URL == LinuxAcademyIE._AUTHORIZE_URL
    assert ie._ORIGIN_URL == LinuxAcademyIE._ORIGIN_URL
    assert ie._CLIENT_ID == LinuxAcademyIE._

# Generated at 2022-06-24 12:51:39.032752
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:51:46.732541
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    def test_class_object(cls, test_name):
        instance = cls()
        assert instance._NETRC_MACHINE == cls._NETRC_MACHINE, '_NETRC_MACHINE is not initialized for %s' % test_name
        assert instance._CLIENT_ID == cls._CLIENT_ID, '_NETRC_MACHINE is not initialized for %s' % test_name

    test_class_object(LinuxAcademyIE, 'LinuxAcademyIE')

    # Test class method
    LinuxAcademyIE.ie_key()

# Generated at 2022-06-24 12:51:48.580849
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    temp = LinuxAcademyIE()
    assert isinstance(temp, LinuxAcademyIE)

# Generated at 2022-06-24 12:51:57.008632
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.netrc_machine == 'linuxacademy'
    assert ie.password == 'linuxacademy'
    assert ie.username == 'linuxacademy'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'


# Generated at 2022-06-24 12:52:07.984212
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE('', '', '', '')
    assert ie._VALID_URL == '^https?://(?:www\\.)?linuxacademy\\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|modules/view/id/(?P<course_id>\\d+))$'

# Generated at 2022-06-24 12:52:10.809721
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert hasattr(ie, '_login')
    assert hasattr(ie, '_real_initialize')
    assert hasattr(ie, '_real_extract')

# Generated at 2022-06-24 12:52:11.690741
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:52:13.597571
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'
    assert LinuxAcademyIE.ie_key() in LinuxAcademyIE._downloaders

# Generated at 2022-06-24 12:52:15.416862
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LA = LinuxAcademyIE();

# Generated at 2022-06-24 12:52:18.868958
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
    except Exception as e:
        print(e)
        raise AssertionError("Failed to initialize instance of class LinuxAcademyIE")


# Generated at 2022-06-24 12:52:19.395366
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:52:20.560512
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:52:22.606808
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ix = LinuxAcademyIE()
    # assert isinstance(ix, LinuxAcademyIE) == True

# Generated at 2022-06-24 12:52:32.608966
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .. import LinuxAcademyIE
    assert LinuxAcademyIE.__name__ == 'LinuxAcademyIE'
    assert LinuxAcademyIE._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-24 12:52:42.916438
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_LinuxAcademy_object = LinuxAcademyIE()
    # test __init__
    assert test_LinuxAcademy_object._ORIGIN_URL == 'https://linuxacademy.com'
    assert test_LinuxAcademy_object._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert test_LinuxAcademy_object._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert test_LinuxAcademy_object._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:52:54.809477
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    for url in [ 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675', 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2', 'https://linuxacademy.com/cp/modules/view/id/154']:
        assert(LinuxAcademyIE.suitable(url) == True)

# Generated at 2022-06-24 12:52:57.474843
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    # import pprint
    # print(pprint.pformat(ie.__dict__))
    assert ie.__dict__

# Generated at 2022-06-24 12:52:58.556693
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert LinuxAcademyIE == type(ie)


# Generated at 2022-06-24 12:53:06.758215
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademy_ie = LinuxAcademyIE()
    username, password = linuxacademy_ie._get_login_info()
    location_on_disk = linuxacademy_ie._location

    if username is None:
        raise Exception(
            '\nChange location on disk of .netrc file to where you want it stored\n'
            'export _NETRC=~/.netrc\n')

    if linuxacademy_ie._NETRC_MACHINE not in location_on_disk:
        raise Exception(
            '\nMachine name is not in location on disk\n'
            'export _NETRC=~/.netrc\n')

    titl = 'What Is Data Science'

# Generated at 2022-06-24 12:53:12.730367
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    linuxacademy_ie = LinuxAcademyIE()
    linuxacademy_ie.initialize()
    linuxacademy_ie._login()
    linuxacademy_ie._real_extract(test_url)
    return linuxacademy_ie

# Generated at 2022-06-24 12:53:16.738662
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    username = str(0)
    password = username
    valid_login = True
    try:
        LinuxAcademyIE(username=username, password=password, downloader=None)
    except:
        valid_login = False
    assert valid_login

# Generated at 2022-06-24 12:53:24.494660
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert re.compile(LinuxAcademyIE._VALID_URL).match('https://www.linuxacademy.com/cp/courses/lesson/course/23/lesson/1/module/303')
    assert re.compile(LinuxAcademyIE._VALID_URL).match('https://www.linuxacademy.com/cp/modules/view/id/39')
    assert re.compile(LinuxAcademyIE._VALID_URL).match('https://www.linuxacademy.com/cp/courses/lesson/course/23/lesson/1')
    assert re.compile(LinuxAcademyIE._VALID_URL).match('https://www.linuxacademy.com/cp/modules/view/id/2202')

# Generated at 2022-06-24 12:53:27.731303
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test video
    test_video_url = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    # Test constructing an instance of class LinuxAcademyIE
    test_video = LinuxAcademyIE()._real_initialize()(test_video_url)

# Generated at 2022-06-24 12:53:30.300572
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(None, None)
    assert ie.username is None
    assert ie.password is None


# Generated at 2022-06-24 12:53:31.645887
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pc = LinuxAcademyIE('LinuxAcademy_python')
    assert pc != None


# Generated at 2022-06-24 12:53:33.783326
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'

# Generated at 2022-06-24 12:53:34.791512
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE() is not None

# Generated at 2022-06-24 12:53:36.960705
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    success = ie.suitable("https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2")
    assert True == success

# Generated at 2022-06-24 12:53:38.462277
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('LinuxAcademy')


# Generated at 2022-06-24 12:53:39.641688
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:53:43.162124
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'LinuxAcademy'
    assert ie.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:53:44.920305
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert isinstance(LinuxAcademyIE(), InfoExtractor)

# Generated at 2022-06-24 12:53:53.218362
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Function to test the constructor of class LinuxAcademyIE
    #
    # This function is used to test the constructor of class LinuxAcademyIE.
    #
    # Parameters
    # ----------
    #
    # Returns
    # -------
    #
    # Raises
    # ------
    #
    # See Also
    # --------

    ie = LinuxAcademyIE()
    try:
        ie._login()
    except ExtractorError:
        pass

    # To confirm the successful login, below function can be used to test the
    # ability to access the resource.
    #
    # ie._real_extract('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')

# Generated at 2022-06-24 12:54:05.665037
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == '''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|
                            modules/view/id/(?P<course_id>\\d+)
                        )
                    '''
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-24 12:54:06.886455
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

# Generated at 2022-06-24 12:54:11.123525
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    const = LinuxAcademyIE('LinuxAcademy', 'linuxacademy.com')
    assert const.name == 'LinuxAcademy'
    assert const.host == 'linuxacademy.com'
    assert const.IE_NAME == 'linuxacademy'
    assert const.REALM == 'Linux Academy'

# Generated at 2022-06-24 12:54:12.923089
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    la = LinuxAcademyIE()
    assert isinstance(la, InfoExtractor)

# Generated at 2022-06-24 12:54:16.809416
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)
    assert ie.ie_key() == 'LinuxAcademy'
_TEST = test_LinuxAcademyIE()


# Generated at 2022-06-24 12:54:25.927241
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    module = LinuxAcademyIE()
    assert module.__name__ == 'LinuxAcademy'
    assert module.IE_NAME == 'LinuxAcademy'
    assert hasattr(module, '_VALID_URL')
    assert module._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/' \
                                 r'(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'
    assert hasattr(module, '_NETRC_MACHINE')
    assert module._NETRC_MACHINE == 'linuxacademy'
    assert hasattr(module, '_TESTS')


# Generated at 2022-06-24 12:54:28.756470
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():

    assert(LinuxAcademyIE()._VALID_URL == "https?://(?:www\\.)?linuxacademy\\.com/cp/courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)")


# Generated at 2022-06-24 12:54:34.576759
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

    assert(ie.module.__name__ == 'linuxacademy')
    assert(ie.ie.__name__ == 'LinuxAcademyIE')
    assert(ie.ie_key() == 'linuxacademy')
    assert(ie.netrc_machine == 'linuxacademy')
    assert(ie.authorize_url == 'https://login.linuxacademy.com/authorize')
    assert(ie.origin_url == 'https://linuxacademy.com')
    assert(ie.client_id == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx')
    assert(ie.valid_url == LinuxAcademyIE._VALID_URL)

# Generated at 2022-06-24 12:54:45.145212
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == "https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))"
    assert ie._AUTHORIZE_URL == "https://login.linuxacademy.com/authorize"
    assert ie._ORIGIN_URL == "https://linuxacademy.com"
    assert ie._CLIENT_ID == "KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx"

# Extractor test for LinuxAcademyIE

# Generated at 2022-06-24 12:54:55.937142
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    kwargs = {'username': 'johndoe', 'password': 'johndoe'}
    assert LinuxAcademyIE(None)._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert LinuxAcademyIE(None)._ORIGIN_URL == 'https://linuxacademy.com'
    assert LinuxAcademyIE(None)._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert LinuxAcademyIE(None)._NETRC_MACHINE == 'linuxacademy'
    assert LinuxAcademyIE(None)._download_webpage('https://google.com/').startswith('<!doctype html>')
    assert LinuxAcad

# Generated at 2022-06-24 12:54:58.054701
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_linuxacademy import test_LinuxAcademyIE
    test = test_LinuxAcademyIE()
    test._test_constructor()

# Generated at 2022-06-24 12:55:05.519168
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_for_login = True

    def create_downloader(username, password):
        return LinuxAcademyIE(params={
            'username': username,
            'password': password,
        })

    # Test authentication
    if test_for_login:
        try:
            linuxAcademyIE = create_downloader(
                '<username>', '<password>')
        except ExtractorError as e:
            if isinstance(e.cause, compat_HTTPError) and e.cause.code in (401, 403, 404):
                raise Exception('Test for login failed: %s' % str(e))
    else:
        # Create a new LinuxAcademyIE instance
        linuxAcademyIE = create_downloader('', '')

    # Test extraction of https://linuxacademy.com/cp/courses/

# Generated at 2022-06-24 12:55:17.094900
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_cases = {
        '7971-2': '33b43d3c7d3a31a8ecec48aab70ef9c9',
        '154': '5e5f5d53c23d664d8a7a894274f4c7e9',
    }

    for linuxacademy_id, youtube_id in test_cases.items():
        downloader = LinuxAcademyIE()
        test_url = 'https://linuxacademy.com/cp/courses/lesson/course/{}/lesson/2/module/675'
        url = test_url.format(linuxacademy_id)

# Generated at 2022-06-24 12:55:27.758995
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'

# Generated at 2022-06-24 12:55:29.510179
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    an_instance = LinuxAcademyIE()
    assert an_instance is not None
    assert isinstance(an_instance, LinuxAcademyIE)

# Generated at 2022-06-24 12:55:37.811824
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_cases = (
        (LinuxAcademyIE, 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'),
        (LinuxAcademyIE, 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'),
        (LinuxAcademyIE, 'https://linuxacademy.com/cp/modules/view/id/154'),
    )
    for constructor, url in test_cases:
        ie = constructor(sox=None)
        assert ie.suitable(url)

# Generated at 2022-06-24 12:55:46.521542
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Unit test for constructor of class LinuxAcademyIE
    """
    valid_url = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    valid_url1 = 'https://linuxacademy.com/cp/modules/view/id/154'
    course_id = 154
    chapter_id = 1498
    lecture_id = 2

    ie_linux_academy = LinuxAcademyIE()
    ie_linux_academy._real_initialize()
    # Test case where course_id is present in url
    result = ie_linux_academy._real_extract(valid_url1)
    # Validate if the extracted information is as expected
    assert course_id == result['id']
    # Check if the API was called

# Generated at 2022-06-24 12:55:48.516366
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.__name__ == 'LinuxAcademy'
    assert LinuxAcademyIE.__doc__ == 'Basic linux academy extractor'

# Generated at 2022-06-24 12:55:49.647008
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print(LinuxAcademyIE())

# Generated at 2022-06-24 12:55:52.946592
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        from . import test_utils
        from . import test_youtube
        from . import test_dailymotion
    except (TypeError, ImportError):
        return

    test_utils.auto_recursive_tests(
        test_youtube,
        test_dailymotion,
        # test_vimeo,
    )

# Generated at 2022-06-24 12:55:54.714577
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Unit test for constructor of class LinuxAcademyIE."""
    # Test for an instance of the class LinuxAcademyIE
    assert isinstance(LinuxAcademyIE(), InfoExtractor)

# Generated at 2022-06-24 12:55:59.093660
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxAcademy = LinuxAcademyIE()
    # Test _login method
    linuxAcademy._login()
    # Test _real_initialize method
    linuxAcademy._real_initialize()
# Test _extract_m3u8_formats method

# Generated at 2022-06-24 12:56:01.343333
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE(None)._NETRC_MACHINE == LinuxAcademyIE.ie_key()

# Generated at 2022-06-24 12:56:05.453075
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_ie = LinuxAcademyIE('LinuxAcademyIE')
    assert(linux_academy_ie.ie_key() == 'LinuxAcademy')
    assert(linux_academy_ie.ie_key() == LinuxAcademyIE.ie_key())

# Generated at 2022-06-24 12:56:06.456237
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:56:08.109612
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import unittest
    unittest.main()

# Generated at 2022-06-24 12:56:09.171686
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:56:18.793789
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Unit test for constructor of class LinuxAcademyIE"""
    # Tested parameters are: ie, ie_key, _LOGIN_REQUIRED, _NETRC_MACHINE, _VALID_URL, _TITLE_RE, _DESCRIPTION_RE, _TIMESTAMP_RE, _DURATION_RE, _DURATION_SECS_RE, and _EXT_RE
    ie = LinuxAcademyIE()

    expected_ie = "linuxacademy"
    expected_ie_key = "LinuxAcademy"
    expected_login_required = True
    expected_netrc_machine = "linuxacademy"

# Generated at 2022-06-24 12:56:21.463944
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    d = LinuxAcademyIE()
    assert d.IE_NAME == 'linuxacademy'

# Generated at 2022-06-24 12:56:29.457807
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Linux Academy credentials
    LA_USER = None
    LA_PASSWORD = None
    LA_COURSE = '154'
    LA_LECTURE = '1549-2'
    LA_URL = 'https://linuxacademy.com/cp/courses/lesson/course/' + LA_COURSE + '/lesson/' + LA_LECTURE

    if LA_USER is not None and LA_PASSWORD is not None:
        IE = LinuxAcademyIE(username=LA_USER, password=LA_PASSWORD)
        # Course extraction test
        Extracted_Info = IE.extract(LA_COURSE)
        # Lecture Extraction test
        Extracted_Info = IE.extract(LA_URL)
        Extracted_Info = IE.extract(LA_LECTURE)

       

# Generated at 2022-06-24 12:56:35.839451
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    argv = []
    argv.append(['https://linuxacademy.com/cp/modules/view/id/154'])
    argv.append(['https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'])
    for url in argv:
        ie = LinuxAcademyIE()
        ie.extract(url[0])

# Generated at 2022-06-24 12:56:37.077459
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:56:38.813255
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE(LinuxAcademyIE.ie_key()).ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:56:39.575607
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()._login()

# Generated at 2022-06-24 12:56:40.402292
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:56:43.492103
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    infoExtractor = LinuxAcademyIE()
    assert infoExtractor.backend == 'linuxacademy'
    assert infoExtractor.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:56:45.704145
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('http://www.linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')

# Generated at 2022-06-24 12:56:47.174165
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._login != None

# Generated at 2022-06-24 12:56:54.236250
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    if ie.IE_NAME != 'linuxacademy':
        assert False
    if ie.IE_DESC != 'Linux Academy':
        assert False
    if ie._VALID_URL:
        assert False
    if ie._NETRC_MACHINE:
        assert False
    if ie._AUTHORIZE_URL:
        assert False
    if ie._CLIENT_ID:
        assert False
    if ie._ORIGIN_URL:
        assert False


# Generated at 2022-06-24 12:56:55.649954
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.IE_DESC == 'LinuxAcademy'

# Generated at 2022-06-24 12:56:58.929797
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert hasattr(LinuxAcademyIE, '_login')
    assert hasattr(LinuxAcademyIE, '_authorize_url')
    assert hasattr(LinuxAcademyIE, '_origin_url')
    assert hasattr(LinuxAcademyIE, '_client_id')
    assert hasattr(LinuxAcademyIE, '_netrc_machine')

# Generated at 2022-06-24 12:56:59.760000
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ydl = LinuxAcademyIE
    assert ydl is not None

# Generated at 2022-06-24 12:57:01.125843
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-24 12:57:06.205870
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
  ie = LinuxAcademyIE()
  assert isinstance(ie, InfoExtractor)
  assert hasattr(ie, 'IE_DESC')
  assert hasattr(ie, '_VALID_URL')
  assert hasattr(ie, '_download_webpage')
  assert hasattr(ie, '_real_extract')
  assert hasattr(ie, '_WORKING')
  assert hasattr(ie, '_TESTS')


# Generated at 2022-06-24 12:57:10.632620
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
       expected_result = 'https://www.linuxacademy.com'
       ie = LinuxAcademyIE()
       assert ie._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/.*'
       assert ie._ORIGIN_URL == expected_result,"Test for origin URL failed"

# Generated at 2022-06-24 12:57:12.808741
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE(None)._LOGIN_URL == 'https://linuxacademy.com/account/login/'

# Generated at 2022-06-24 12:57:20.545178
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import requests
    from .common import get_testdata_file_content
    from .common import post_request_nojson

    filename = 'LinuxAcademy.txt'
    username, password = get_testdata_file_content(filename).strip().split(':')
    ie = LinuxAcademyIE()
    with requests.Session() as session:
        post_request_nojson(session, ie._AUTHORIZE_URL, params={
            'client_id': ie._CLIENT_ID,
            'response_type': 'token id_token',
            'response_mode': 'web_message',
            'redirect_uri': ie._ORIGIN_URL,
            'scope': 'openid email user_impersonation profile',
            'audience': ie._ORIGIN_URL,
        })
        login_data

# Generated at 2022-06-24 12:57:21.698116
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_utils import _stub_extractor
    _stub_extractor(LinuxAcademyIE)

# Generated at 2022-06-24 12:57:22.766935
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE

# Generated at 2022-06-24 12:57:24.535213
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    r = LinuxAcademyIE()
    r._login()
    return r._real_extract('https://linuxacademy.com/cp/modules/view/id/154')

# Generated at 2022-06-24 12:57:25.503575
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None)

# Generated at 2022-06-24 12:57:30.685205
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'
    assert LinuxAcademyIE.get_info('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    assert LinuxAcademyIE.get_info('https://linuxacademy.com/cp/modules/view/id/154')

# Generated at 2022-06-24 12:57:39.699770
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'