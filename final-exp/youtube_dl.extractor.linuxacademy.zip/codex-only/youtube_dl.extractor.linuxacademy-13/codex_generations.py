

# Generated at 2022-06-24 12:47:42.004834
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.SUCCESS == 0
    assert ie.FAILED == 1
    assert ie.SKIPPED == -1
    assert ie.IE_NAME == 'linuxacademy'
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-24 12:47:43.673769
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE().IE_NAME == 'linuxacademy'

# Generated at 2022-06-24 12:47:45.180641
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    i = LinuxAcademyIE()
    assert(i)

# Generated at 2022-06-24 12:47:46.886794
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'LinuxAcademy'

# Generated at 2022-06-24 12:47:53.591570
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE().IE_NAME == 'linuxacademy'
    assert LinuxAcademyIE()._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)'
    assert LinuxAcademyIE()._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:47:55.619089
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == "linuxacademy"


# Unit tests for LinuxAcademyIE

# Generated at 2022-06-24 12:47:57.456401
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Given
    instance = LinuxAcademyIE()

    # When
    object_type = type(instance)

    # Then
    assert object_type is LinuxAcademyIE

# Generated at 2022-06-24 12:47:59.332886
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    return LinuxAcademyIE("https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675")

# Generated at 2022-06-24 12:48:09.868532
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import sys
    import os
    import unittest
    import tempfile
    import shutil
    import requests
    import json
    import re

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create the unit test
    class LinuxAcademyUnitTest(unittest.TestCase):

        def setUp(self):
            self.old_sys_path = sys.path
            sys.path = [temp_dir] + sys.path
            self.maxDiff = None
            self.units_under_test = 'linuxacademy'
            self.shell_colors = {
                'normal': '',
                'green': '',
                'red': '',
            }
            
        def tearDown(self):
            sys.path = self.old_sys_path
            shut

# Generated at 2022-06-24 12:48:10.909237
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()


# Generated at 2022-06-24 12:48:16.528456
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test constructor of class LinuxAcademyIE"""

    assert LinuxAcademyIE.__name__ == 'LinuxAcademyIE'
    assert LinuxAcademyIE.ie_name() == 'linuxacademy'
    url = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    exp_match = LinuxAcademyIE._VALID_URL
    assert re.match(exp_match, url) is not None
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    exp_match = LinuxAcademyIE._VALID_URL
    assert re.match(exp_match, url) is not None

# Generated at 2022-06-24 12:48:20.665132
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == 'https://linuxacademy.com/cp/'
    assert ie._TESTS == []
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'


# Generated at 2022-06-24 12:48:22.502404
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert obj.__class__.__name__ == 'LinuxAcademyIE'

# Generated at 2022-06-24 12:48:23.893255
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert isinstance(LinuxAcademyIE(), LinuxAcademyIE)


# Generated at 2022-06-24 12:48:25.612366
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE().IE_NAME == "LinuxAcademy"


# Generated at 2022-06-24 12:48:26.698014
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'LinuxAcademy'

# Generated at 2022-06-24 12:48:28.632178
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)
    assert ie.ie_key() == 'LinuxAcademy'


# Generated at 2022-06-24 12:48:30.224503
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    fields = [
        {'username': '', 'password': ''}
    ]
    for i in fields:
        assert LinuxAcademyIE(fields=i)


# Generated at 2022-06-24 12:48:31.997630
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(test_LinuxAcademyIE, test_LinuxAcademyIE.__name__)

# Generated at 2022-06-24 12:48:34.859158
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        linuxacademyIE = LinuxAcademyIE()
    except Exception as e:
        raise AssertionError('LinuxAcademyIE constructor raised %s.' % e)

# Generated at 2022-06-24 12:48:38.056187
# Unit test for constructor of class LinuxAcademyIE

# Generated at 2022-06-24 12:48:43.542391
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    l = LinuxAcademyIE()
    assert l._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert l._ORIGIN_URL == 'https://linuxacademy.com'
    assert l._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert l._NETRC_MACHINE == 'linuxacademy'


# Generated at 2022-06-24 12:48:55.479346
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .testcases import TestCase

    # no credentials
    t = TestCase('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    t.assert_raises(ExtractorError, lambda x: '401' in x)
    # wrong credentials
    t = TestCase('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
                 test_login_credentials=lambda *args, **kwargs: ('usr', 'pwd'))
    t.assert_raises(ExtractorError, lambda x: '401' in x)
    # valid credentials

# Generated at 2022-06-24 12:48:56.650090
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:48:57.501114
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('test')
    LinuxAcademyIE('test', 'test', 'test', {'test'})

# Generated at 2022-06-24 12:48:58.696485
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()

# Generated at 2022-06-24 12:49:05.526489
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert LinuxAcademyIE()._ORIGIN_URL == 'https://linuxacademy.com'
    assert LinuxAcademyIE()._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert LinuxAcademyIE()._NETRC_MACHINE == 'linuxacademy'
# End of Unit test for constructor of class LinuxAcademyIE

# Generated at 2022-06-24 12:49:06.512927
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert callable(LinuxAcademyIE)

# Generated at 2022-06-24 12:49:08.739657
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # reason to unit test the constructor:
    # it is an alias for YoutubeIE
    from .youtube import YoutubeIE
    assert LinuxAcademyIE is YoutubeIE

# Generated at 2022-06-24 12:49:10.559116
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    extractor_module = LinuxAcademyIE()
    return extractor_module
    

# Generated at 2022-06-24 12:49:12.621612
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # A call to __init__() of constructor of class LinuxAcademyIE
    # This test is required so that a coveralls report of coverage is generated
    LinuxAcademyIE()

# Generated at 2022-06-24 12:49:16.387845
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        with open('/home/mjm/code/youtube-dl/youtube_dl/test/resources/LinuxAcademy.credential') as f:
            LinuxAcademyIE('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    except Exception as e:
        print(e)


# Generated at 2022-06-24 12:49:19.168697
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = "https://linuxacademy.com/cp/modules/view/id/154"
    obj = LinuxAcademyIE()
    obj.initialize()

# Generated at 2022-06-24 12:49:20.893714
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:49:30.346632
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    x = LinuxAcademyIE('LinuxAcademyIE', 'https://linuxacademy.com/cp/modules/view/id/154')
    assert isinstance(x, LinuxAcademyIE)
    assert isinstance(x, InfoExtractor)
    assert x.IE_NAME == 'LinuxAcademyIE'
    assert x.AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert x.ORIGIN_URL == 'https://linuxacademy.com'
    assert x.CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert x.NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:49:31.197858
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:49:36.436425
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test case 1
    mobj = LinuxAcademyIE._VALID_URL.match("https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675")
    instance = LinuxAcademyIE()
    chapter_id, lecture_id, course_id = mobj.group('chapter_id', 'lesson_id', 'course_id')
    item_id = course_id if course_id else '%s-%s' % (chapter_id, lecture_id)
    test_url = instance._download_webpage("https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675", item_id)
    # Test case 2

# Generated at 2022-06-24 12:49:38.834158
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None, 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')

# Generated at 2022-06-24 12:49:39.408945
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-24 12:49:44.559811
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    IE = LinuxAcademyIE("linuxacademy")
    assert IE.ie_key() == "LinuxAcademy"
    assert IE.LOGIN_URL is None
    assert IE._AUTHORIZE_URL == "https://login.linuxacademy.com/authorize"
    assert IE.NETRC_MACHINE == "linuxacademy"

# Generated at 2022-06-24 12:49:46.219330
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert isinstance(LinuxAcademyIE(), InfoExtractor)

# Generated at 2022-06-24 12:49:58.280769
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test creating a LinuxAcademyIE instance
    #
    # Will create two LinuxAcademyIE instances in order to test a few
    # of the methods of LinuxAcademyIE.
    lai = LinuxAcademyIE(None)
    lai2 = LinuxAcademyIE(None)

    # Test member _CLIENT_ID
    assert lai._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

    # Test member _AUTHORIZE_URL
    assert lai._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'

    # Test member _ORIGIN_URL
    assert lai._ORIGIN_URL == 'https://linuxacademy.com'

    # Test member

# Generated at 2022-06-24 12:50:07.612472
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info_extractor = LinuxAcademyIE()
    assert info_extractor._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert info_extractor._NETRC_MACHINE == 'linuxacademy'
    assert info_extractor._ORIGIN_URL == 'https://linuxacademy.com'
    assert info_extractor._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'

# Generated at 2022-06-24 12:50:13.669778
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        throw_away_ie = LinuxAcademyIE()
    except ExtractorError as err:
        if 'login info' in err.args:
            raise AssertionError('Login credentials are needed for this test, please set LinuxAcademy account')
        else:
            raise AssertionError('Unexpected error thrown ' + err)

# Generated at 2022-06-24 12:50:18.046897
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # FIXME: test with a brand new account
    # login = os.environ['LINUXACADEMY_LOGIN']
    # password = os.environ['LINUXACADEMY_PASSWORD']
    pass

# Generated at 2022-06-24 12:50:21.945370
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # construct the class
    if hasattr(LinuxAcademyIE, 'test_LinuxAcademyIE'):
        return
    else:
        setattr(LinuxAcademyIE, 'test_LinuxAcademyIE', 1)
    mydl = LinuxAcademyIE()



# Generated at 2022-06-24 12:50:24.081593
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Testing if instance is created
    assert isinstance(LinuxAcademyIE(), LinuxAcademyIE)

# Generated at 2022-06-24 12:50:25.867533
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Validate the constructor
    ie = LinuxAcademyIE()

# Generated at 2022-06-24 12:50:29.361686
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()._login()
    except ExtractorError as e:
        if not e.args[0].startswith('Authentication required'):
            raise
    else:
        assert False

# Generated at 2022-06-24 12:50:30.876619
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert isinstance(LinuxAcademyIE({})._login(), None)

# Generated at 2022-06-24 12:50:35.630964
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test login success
    ie_obj = LinuxAcademyIE(None, {}, {
        'username': 'testuser',
        'password': 'testpass'
    })
    # Test login failed
    ie_obj = LinuxAcademyIE(None, {}, {
        'username': 'testuser',
        'password': 'wrongpass'
    })


# Generated at 2022-06-24 12:50:42.518029
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_cases = [
        'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
        'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2',
        'https://linuxacademy.com/cp/modules/view/id/154',
    ]
    for test_case in test_cases:
        yield \
            "Testcase: " + test_case, \
            lambda: LinuxAcademyIE(test_case)

# Generated at 2022-06-24 12:50:51.414211
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675/'
    instance = LinuxAcademyIE()
    assert(instance._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|modules/view/id/(?P<course_id>\\d+))')

# Generated at 2022-06-24 12:50:53.725763
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)

# Generated at 2022-06-24 12:50:56.518143
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert 'LinuxAcademy' == instance.IE_NAME

# Generated at 2022-06-24 12:51:03.733264
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    tester = LinuxAcademyIE()
    assert tester.IE_NAME == 'linuxacademy'
    assert tester._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''



# Generated at 2022-06-24 12:51:08.053904
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert isinstance(instance, InfoExtractor)
    assert isinstance(instance, LinuxAcademyIE)

# Generated at 2022-06-24 12:51:12.902104
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """ Unit test for constructor of class LinuxAcademyIE """
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    LinuxAcademyIE().suitable(url)
    LinuxAcademyIE().extract(url)

# Generated at 2022-06-24 12:51:14.275454
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:51:15.289166
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    o = LinuxAcademyIE()

# Generated at 2022-06-24 12:51:25.538247
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:51:32.153469
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    filename = "tests/testdata/linuxacademy.com/course.json"
    module_file = open(filename, "rb")
    module = json.load(module_file)
    module_file.close()
    items = list()
    chapter = None
    chapter_id = None
    chapter_number = None
    for item in module['items']:
        if not isinstance(item, dict):
            continue
        if 'section' in item['type'].values():
            chapter = item
            chapter_id = item.get('course_module')
            chapter_number = 1 if not chapter_number else chapter_number + 1
            continue
        if 'lesson' not in item['type'].values():
            continue
        url = item.get('url')
        title = item.get('title') or item.get

# Generated at 2022-06-24 12:51:33.849597
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademy = LinuxAcademyIE()
    return linuxacademy

# Generated at 2022-06-24 12:51:34.910553
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert isinstance(LinuxAcademyIE, type)

# Generated at 2022-06-24 12:51:36.038018
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:51:46.414245
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .common import TestCase
    from . import common
    from .common import mock_urllib_http_response

    class s(LinuxAcademyIE):
        def _download_webpage(self, url, video_id, note='', errnote='', fatal=False, data=None, headers={}):
            return webpage, urlh

        def _parse_json(self, webpage, video_id, transform_source=None, fatal=True):
            return json.loads(webpage)

        def _search_regex(self, pattern, string, name, default=NO_DEFAULT, fatal=True, flags=0, group=None):
            return re.search(pattern, string, flags).group(0)

    class t(TestCase):
        @classmethod
        def setUpClass(self):
            self.course_

# Generated at 2022-06-24 12:51:55.965312
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    mock_class_LinuxAcademy = LinuxAcademyIE
    mock_class_LinuxAcademy._download_json = lambda x,y: {}
    mock_class_LinuxAcademy._download_webpage = lambda x,y,z: ''
    mock_class_LinuxAcademy._download_webpage_handle = lambda x,y,z: ('','')
    mock_class_LinuxAcademy._hidden_inputs = lambda x: {}
    mock_class_LinuxAcademy._login = lambda x: None
    mock_class_LinuxAcademy._real_initialize = lambda x: None
    mock_class_LinuxAcademy._real_extract = lambda x,y: {}
    mock_class_LinuxAcademy.IE_NAME = 'LinuxAcademy'
    mock_class_LinuxAcademy

# Generated at 2022-06-24 12:51:58.536522
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.suitable('https://linuxacademy.com/cp/modules/view/id/154')

# Generated at 2022-06-24 12:51:59.554764
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:52:01.426001
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
    except Exception:
        pass

# Generated at 2022-06-24 12:52:02.535737
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:52:04.710187
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'


# Generated at 2022-06-24 12:52:13.797598
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._USER_AGENT == 'Mozilla/5.0 (X11; Linux x86_64; rv:62.0) Gecko/20100101 Firefox/62.0'
    assert LinuxAcademyIE()._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert LinuxAcademyIE()._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert LinuxAcad

# Generated at 2022-06-24 12:52:25.707937
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from ..test import (
        get_testdata_files_path,
        load_json_files
    )
    # Load m3u8 video urls for testing
    json_files = get_testdata_files_path(
        ['linuxacademy', 'playlist_data.json'])
    for json_file in json_files:
        for data in load_json_files([json_file]):
            # Load test data from json files
            video_id = data['_type']
            video_url = data['url']
            expected_video_urls = data['formats']

            # Test LinuxAcademyIE class constructor
            ie = LinuxAcademyIE()
            playlist = ie._real_extract(video_url)
            assert playlist['id'] == video_id

            # Test m3u8 video

# Generated at 2022-06-24 12:52:27.270806
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()
    # this test is to see that creating LinuxAcademyIE object does not fail

# Generated at 2022-06-24 12:52:28.982716
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE();
    assert ie.__class__.__name__ == "LinuxAcademyIE";

# Generated at 2022-06-24 12:52:31.238355
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.__class__.__name__ is LinuxAcademyIE.__name__

# Generated at 2022-06-24 12:52:32.498499
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert isinstance(LinuxAcademyIE(None), LinuxAcademyIE)

# Generated at 2022-06-24 12:52:34.080588
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    _LinuxAcademyIE = LinuxAcademyIE()
    _LinuxAcademyIE.initialize()

# Generated at 2022-06-24 12:52:35.096353
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:52:37.747409
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    '''
    The constructor must not raise an exception.
    '''
    try:
        LinuxAcademyIE()
    except Exception as ex:
        print(ex)
        raise

# Generated at 2022-06-24 12:52:39.544675
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print("Testing constructor of class LinuxAcademyIE")
    assert LinuxAcademyIE(None, None)

# Generated at 2022-06-24 12:52:51.574000
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'

    # Test construction of the _VALID_URL
    assert ie._VALID_URL == r'https?://(?:www\.)?linuxacademy\.com/cp/'
    assert re.match('^' + ie._VALID_URL, 'https://www.linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    assert re.match('^' + ie._VALID_URL, 'https://www.linuxacademy.com/cp/modules/view/id/154')
    # _VALID_URL must not match this

# Generated at 2022-06-24 12:52:52.841894
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:52:54.807680
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    return ie.IE_NAME == 'linuxacademy'

# Generated at 2022-06-24 12:52:56.738287
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE();
    assert ie.IE_NAME == 'linuxacademy'

# Generated at 2022-06-24 12:52:57.767095
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()._real_initialize()

# Generated at 2022-06-24 12:52:59.461441
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
        assert True
    except Exception:
        assert False


# Generated at 2022-06-24 12:53:01.670472
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert(LinuxAcademyIE.ie_key() == 'LinuxAcademy')
    assert(type(LinuxAcademyIE({})) is LinuxAcademyIE)


# Generated at 2022-06-24 12:53:02.848770
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    l = LinuxAcademyIE()
    assert l is not None

# Generated at 2022-06-24 12:53:04.034866
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LA = LinuxAcademyIE()
    LA.test_login()

# Generated at 2022-06-24 12:53:07.920320
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # given
    url = "https://linuxacademy.com/cp/courses/lesson/course/32/lesson/2/module/0"
    ie = LinuxAcademyIE()
    # when
    test_ie = IE_NAME.lower()
    # then
    assert ie.ie_key() == test_ie

# Generated at 2022-06-24 12:53:08.848750
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:53:20.165772
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE._NETRC_MACHINE == 'linuxacademy'
    assert LinuxAcademyIE._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert LinuxAcademyIE._ORIGIN_URL == 'https://linuxacademy.com'
    assert LinuxAcademyIE._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert re.match(LinuxAcademyIE._VALID_URL, 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2') is not None

# Generated at 2022-06-24 12:53:22.795220
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:53:24.294800
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)

# Generated at 2022-06-24 12:53:27.370477
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    la = LinuxAcademyIE()._real_initialize()
    # simple calls for class methods
    la._login()
    la._real_extract(url)

# Generated at 2022-06-24 12:53:31.535184
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'linuxacademy'
    assert LinuxAcademyIE(
        compat_urllib_request.Request('https://linuxacademy.com')
    )._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:53:33.232963
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert(isinstance(LinuxAcademyIE(), LinuxAcademyIE))

# Generated at 2022-06-24 12:53:36.789965
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from ..api import YoutubeIE

    ie_LinuxAcademy = LinuxAcademyIE(YoutubeIE._initialize())
    assert ie_LinuxAcademy._AUTHORIZE_URL is not None
    assert ie_LinuxAcademy._VALID_URL is not None

# Generated at 2022-06-24 12:53:38.842495
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)

# Generated at 2022-06-24 12:53:39.776930
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None, {})

# Generated at 2022-06-24 12:53:50.916621
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # When LinuxAcademyIE object is created, it calls _real_initialize() method,
    # which in turn, calls _login() method. This method uses _download_webpage()
    # method, which tries to download the url. Since we don't want the url to be
    # downloaded, we will mock it. One way to mock the url is to use a
    # 'MockRequest' as suggested here: https://github.com/ytdl-org/youtube-dl/blob/master/youtube_dl/extractor/common.py#L104
    mock_response = 'mock_response'
    MockRequest = type('MockRequest', (object,), {'text': mock_response})
    LinuxAcademyIE._download_webpage = lambda _self, url, video_id, note, errnote, fatal: MockRequest()

# Generated at 2022-06-24 12:53:55.917878
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # test with login
    LinuxAcademyIE._login = lambda self: None
    assert LinuxAcademyIE('linuxacademy', {})

    # test without login
    LinuxAcademyIE._login = None
    assert not LinuxAcademyIE('linuxacademy', {})

# Generated at 2022-06-24 12:54:03.270829
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:54:08.414134
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Should raise error if no account credentials are provided
    try:
        LinuxAcademyIE()._real_initialize()
    except ExtractorError as e:
        assert 'Linux Academy said: Not authorized to access this data' in str(e)
    # Should not raise error if account credentials are provided
    LinuxAcademyIE()._real_initialize()

# Generated at 2022-06-24 12:54:10.502388
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-24 12:54:20.163800
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie._VALID_URL == LinuxAcademyIE._VALID_URL
    assert ie._TESTS == LinuxAcademyIE._TESTS
    assert ie._AUTHORIZE_URL == LinuxAcademyIE._AUTHORIZE_URL
    assert ie._ORIGIN_URL == LinuxAcademyIE._ORIGIN_URL
    assert ie._CLIENT_ID == LinuxAcademyIE._CLIENT_ID
    assert ie._NETRC_MACHINE == LinuxAcademyIE._NETRC_MACHINE

# Generated at 2022-06-24 12:54:28.403751
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    constructor_test = 'LinuxAcademyIE must be initialized'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize', constructor_test
    assert ie._ORIGIN_URL == 'https://linuxacademy.com', constructor_test
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx', constructor_test
    assert ie._NETRC_MACHINE == 'linuxacademy', constructor_test

# Generated at 2022-06-24 12:54:35.479009
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try_get_assert = lambda x: x['id']
    try_get_error = lambda x: x['error']['message']

    ie = LinuxAcademyIE()
    username, password = ie._get_login_info()

    if username is None:
        raise AssertionError('Cannot test %s when no login info is available' % ie.IE_NAME)

    def random_string():
        return ''.join([
            random.choice('0123456789ABCDEFGHIJKLMNOPQRSTUVXYZabcdefghijklmnopqrstuvwxyz-._~')
            for _ in range(32)])


# Generated at 2022-06-24 12:54:45.226500
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    if ie._NETRC_MACHINE != 'linuxacademy':
        raise Exception('_NETRC_MACHINE does not match expected value')
    if ie._CLIENT_ID != 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx':
        raise Exception('_CLIENT_ID does not match expected value')
    if ie._ORIGIN_URL != 'https://linuxacademy.com':
        raise Exception('_ORIGIN_URL does not match expected value')
    if ie._AUTHORIZE_URL != 'https://login.linuxacademy.com/authorize':
        raise Exception('_AUTHORIZE_URL does not match expected value')

# Generated at 2022-06-24 12:54:46.689688
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_ie_instance = LinuxAcademyIE('linuxacademy')
    assert test_ie_instance is not None

# Generated at 2022-06-24 12:54:58.100210
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from ..utils import gzip_text
    def _mock_download_webpage(
            *args, **kwargs):
        headers = kwargs.get('headers', {})

# Generated at 2022-06-24 12:54:59.748804
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert(isinstance(instance, LinuxAcademyIE))

# Generated at 2022-06-24 12:55:00.361543
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    return LinuxAcademyIE

# Generated at 2022-06-24 12:55:01.179975
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE is not None

# Generated at 2022-06-24 12:55:02.338372
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    i = LinuxAcademyIE()

# Generated at 2022-06-24 12:55:03.933888
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('LinuxAcademyIE')


# Generated at 2022-06-24 12:55:10.762377
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .common import InfoExtractor
    from .extractors.youtube import YoutubeIE
    from .extractors.generic import GenericIE
    ie = LinuxAcademyIE("https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675")
    assert isinstance(ie, LinuxAcademyIE)


# Generated at 2022-06-24 12:55:17.089351
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert hasattr(ie, "ie_key") and ie.ie_key() == LinuxAcademyIE.ie_key()
    assert hasattr(ie, "IE_NAME") and ie.IE_NAME == "LinuxAcademy"
    assert hasattr(ie, "IE_VERSION") and ie.IE_VERSION == 1.0
    assert hasattr(ie, "LINUXACADEMY_IE_VERSION") and ie.LINUXACADEMY_IE_VERSION == 1.0

# Generated at 2022-06-24 12:55:18.180173
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:55:19.283373
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()._login()

# Generated at 2022-06-24 12:55:20.661728
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    x = LinuxAcademyIE()
    x._login()

# Generated at 2022-06-24 12:55:30.456856
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # 1.) Downloader was created
    assert LinuxAcademyIE.ie_key() == "LinuxAcademy"
    assert LinuxAcademyIE._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'

# Generated at 2022-06-24 12:55:31.612007
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    a = LinuxAcademyIE()

# Generated at 2022-06-24 12:55:42.067977
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        os.chdir(os.path.dirname(os.path.abspath(__file__)))
    except OSError:
        pass

    ie = LinuxAcademyIE()

    assert ie.embed_data() == dict(extractor='#=#@linux-academy#@#1')
    assert ie.embed_data(course_id=90) == dict(extractor='#=#@linux-academy#@#90')
    assert ie.embed_data(chapter_id=91, lesson_id=92) == dict(extractor='#=#@linux-academy#@#91-92')
    assert ie.embed_data(chapter_id=91, lesson_id=92, course_id=90) == dict(extractor='#=#@linux-academy#@#90')

    #

# Generated at 2022-06-24 12:55:43.229312
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_LinuxAcademyIE_impl(None)


# Generated at 2022-06-24 12:55:52.138862
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import sys
    import os
    import tempfile
    from . import get_testcases

    def get_tempfile(suffix):
        fd, fn = tempfile.mkstemp(suffix)
        os.close(fd)
        return fn

    def remove_tempfile(fn):
        try:
            os.remove(fn)
        except:
            pass

    for (case, id, url) in get_testcases(LinuxAcademyIE, sys.argv[1:]):
        if case.startswith('test___'):
            continue

        case('%s.%s' % (__name__, case), globals(), locals())

        password_file = get_tempfile('.netrc')

# Generated at 2022-06-24 12:55:54.196016
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie is not None

# Generated at 2022-06-24 12:56:04.876563
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # unit test for constructor of class LinuxAcademyIE
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.IE_DESC == 'Linux Academy - Online Linux Training'
    assert ie.VALID_URL
    assert re.match(ie.VALID_URL, 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    assert ie.NETRC_MACHINE == 'linuxacademy'
    assert ie.AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie.ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-24 12:56:15.904774
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademy = LinuxAcademyIE()
    assert linuxacademy._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'

# Generated at 2022-06-24 12:56:26.764902
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test constructor of class LinuxAcademyIE."""
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    expected_id = '7971-2'
    expected_ext = 'mp4'
    expected_title = 'What Is Data Science'
    expected_description = 'md5:c574a3c20607144fb36cb65bdde76c99'
    expected_timestamp = 1607387907
    expected_upload_date = '20201208'
    expected_duration = 304

    ie = LinuxAcademyIE()
    info = ie._real_extract(url)

    assert info['id'] == expected_id
    assert info['formats'][-1]['ext'] == expected_ext
   

# Generated at 2022-06-24 12:56:28.609738
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:56:32.988267
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.suitable(ie.url) == True

# Generated at 2022-06-24 12:56:38.861175
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademy_ie = LinuxAcademyIE()
    linuxacademy_ie.ie_key()
    assert linuxacademy_ie._NETRC_MACHINE == 'linuxacademy'
    assert linuxacademy_ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-24 12:56:43.033551
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test = LinuxAcademyIE()
    assert test._VALID_URL == '(?x)https?://(?:www\\.)?linuxacademy\\.com/cp/courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)'

# Generated at 2022-06-24 12:56:46.840646
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print("Testing LinuxAcademyIE")
    LA_TEST_URL = "https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2"
    ie = LinuxAcademyIE(LA_TEST_URL)

# Generated at 2022-06-24 12:56:47.985554
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:56:49.321781
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:56:56.354454
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # When unit testing, we want to be able to run all of the tests
    # without worrying about if we are logged in or not.  Thus, to isolate
    # the login() method, we monkey-patch the _login method.  This is also
    # why we have to test with this method instead of with a test.
    def _login_mock(self):
        pass
    LinuxAcademyIE._login = _login_mock
    la = LinuxAcademyIE()
    assert la.IE_NAME == 'linuxacademy'

# Generated at 2022-06-24 12:57:04.281689
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
        Unit test for constructor of class LinuxAcademyIE
    """
    # pylint: disable=protected-access
    # Create instance of the class to be unit tested with provided URL
    la = LinuxAcademyIE._build_request('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    # Create instance of the class to be unit tested with no URL provided
    la_no_url = LinuxAcademyIE()
    # Check that _real_initialize function is called
    assert la._IS_LOGIN == False
    assert la_no_url._IS_LOGIN == False
    la._real_initialize()
    la_no_url._real_initialize()
    assert la._IS_LOGIN == True
    assert la_no_

# Generated at 2022-06-24 12:57:05.784746
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Function join_urls used in LinuxAcademyIE.__init__ is unavailable in Python 3.8
    """
    LinuxAcademyIE('')

# Generated at 2022-06-24 12:57:07.545015
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # The class constructor already test many things so no need to create unit test for nothing
    LinuxAcademyIE()

# Generated at 2022-06-24 12:57:14.311362
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import os
    import shutil
    import tempfile
    try:
        temp_dir = tempfile.mkdtemp(suffix="-linux_academy")
        temp_file = os.path.join(temp_dir, ".netrc")
        shutil.copyfile(os.path.expanduser("~/.netrc"), temp_file)
        LinuxAcademyIE(temp_file)
    finally:
        if temp_dir:
            shutil.rmtree(temp_dir)

# Generated at 2022-06-24 12:57:15.778927
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('LinuxAcademy')

# Generated at 2022-06-24 12:57:27.198215
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    my_IE = LinuxAcademyIE()
    assert my_IE._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-24 12:57:30.482227
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # action -> constructor of class LinuxAcademyIE
    class_instance = LinuxAcademyIE(1, "test_LinuxAcademyIE", "Linux Academy Course")
    # condition -> instance is not None
    assert(class_instance is not None)

# Generated at 2022-06-24 12:57:32.447125
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == LinuxAcademyIE.ie_key()
    return True