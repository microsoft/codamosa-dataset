

# Generated at 2022-06-24 12:47:32.317668
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('LinuxAcademyIE', 'LinuxAcademy')

# Generated at 2022-06-24 12:47:33.822043
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE(None)



# Generated at 2022-06-24 12:47:45.180900
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Unit test for constructor of class LinuxAcademyIE"""

    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.IE_DESC == 'LinuxAcademy'
    assert ie._VALID_URL == '^(?x) https?:// (?:www\\.)?linuxacademy\\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|modules/view/id/(?P<course_id>\\d+)) '

# Generated at 2022-06-24 12:47:48.020577
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxAcademyIE = LinuxAcademyIE(downloader=None)
    assert linuxAcademyIE._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert linuxAcademyIE._NETRC_MACHINE == 'linuxacademy'


# Generated at 2022-06-24 12:47:50.306590
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test with a valid url and account credentials
    LinuxAcademyIE()._login()
    # Test with a valid url, but invalid account credentials
    test_LinuxAcademyIE_fail()
# Function to test the logic of test_LinuxAcademyIE()

# Generated at 2022-06-24 12:47:51.986288
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == "LinuxAcademy"

# Generated at 2022-06-24 12:47:53.718910
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE() is not None


# Generated at 2022-06-24 12:48:01.629190
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-24 12:48:07.496675
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE._login(LinuxAcademyIE)
    LinuxAcademyIE._real_extract(LinuxAcademyIE, 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    LinuxAcademyIE._real_extract(LinuxAcademyIE, 'https://linuxacademy.com/cp/modules/view/id/154')

# Generated at 2022-06-24 12:48:08.551409
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:48:11.393254
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_common import TestDownloader
    te = TestDownloader()
    ie = LinuxAcademyIE(te)
    ie._real_initialize()

# Generated at 2022-06-24 12:48:13.439410
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # test constructor without _VALID_URL
    ie = LinuxAcademyIE
    assert ie.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:48:19.186452
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademy_ie = LinuxAcademyIE()
    assert linuxacademy_ie.IE_NAME == 'linuxacademy'
    assert linuxacademy_ie._VALID_URL == '''https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|modules/view/id/(?P<course_id>\\d+))'''
    assert linuxacademy_ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert linuxacademy_ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert linuxacademy

# Generated at 2022-06-24 12:48:20.202051
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None)



# Generated at 2022-06-24 12:48:29.025427
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # test for IE
    le = InfoExtractor()
    le.add_ie(LinuxAcademyIE.ie_key(), LinuxAcademyIE)
    test_format = [{
        'url': 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
        'only_matching': True,
    },
        {
        'url': 'https://linuxacademy.com/cp/modules/view/id/154',
        'only_matching': True,
    }]
    test_video = {
        'url': 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
        'only_matching': True,
    }
    test_course

# Generated at 2022-06-24 12:48:30.299436
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    username = "test_username"
    password = "test_password"
    class_ = LinuxAcademyIE(username=username, password=password)
    assert class_.username == username
    assert class_.password == password

# Generated at 2022-06-24 12:48:33.174243
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Checking if it fails on fetching linuxacademy.co.uk/cp/courses/lesson/course/289/lesson/1/module/4"""
    LinuxAcademyIE()._real_initialize()

# Generated at 2022-06-24 12:48:43.355311
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert instance._VALID_URL ==  r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-24 12:48:44.650533
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:48:56.382749
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Unit

# Generated at 2022-06-24 12:48:58.695559
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    PythonTestInstance = LinuxAcademyIE("LinuxAcademyIE")
    assert PythonTestInstance.working == True

# Generated at 2022-06-24 12:49:01.832763
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Constructor test of class LinuxAcademyIE.
    """
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)

# Generated at 2022-06-24 12:49:09.498048
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert hasattr(ie, '_LOGIN_URL')
    assert hasattr(ie, '_NETRC_MACHINE')
    assert hasattr(ie, '_AUTHORIZE_URL')
    assert hasattr(ie, '_ORIGIN_URL')
    assert hasattr(ie, '_CLIENT_ID')
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_TESTS')
    assert hasattr(ie, '_download_webpage_handle')
    assert hasattr(ie, '_download_webpage')
    assert hasattr(ie, '_parse_json')
    assert hasattr(ie, '_search_regex')
    assert hasattr(ie, '_real_initialize')
    assert hasattr

# Generated at 2022-06-24 12:49:17.491322
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_cases = [
        {
            'decoded_url': 'linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
            'expected_url': 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
            'expected_expected_IE': None, 'expected_expected_IE_key': 'LinuxAcademy',
            'expected_expected_playlist_count': None,
            'expected_expected_playlist_mincount': None,
            'expected_module_entries': None,
            'expected_module_entries_len': None,
            'expected_module_entries_video_content_urls_len': None,
        },
    ]


# Generated at 2022-06-24 12:49:27.961348
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import sys
    import tempfile
    import os

    def get_auth_file():
        fd, path = tempfile.mkstemp()
        os.write(fd, b'\n'.join([
            b'machine login.linuxacademy.com',
            b'\tlogin username',
            b'\tpassword password',
            b'\taccount lacausers']))
        os.close(fd)
        return path
    # test with auth
    auth_file = get_auth_file()
    ie = LinuxAcademyIE(
        params={'username': 'username', 'password': 'password'},
        downloader=None,
        _downloader_params={'username': 'username', 'password': 'password'})
    ie.authenticate = get_auth_file()

# Generated at 2022-06-24 12:49:29.303551
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
    except:
        pass

# Generated at 2022-06-24 12:49:32.015398
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
        return True
    except NotImplementedError:
        return False

# Generated at 2022-06-24 12:49:32.881660
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:49:40.853263
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
  ie = LinuxAcademyIE()
  assert ie._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'
  assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
  assert ie._ORIGIN_URL == 'https://linuxacademy.com'
  assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:49:43.348136
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    res_class_member=LinuxAcademyIE.__name__
    assert res_class_member=='LinuxAcademyIE'

# Generated at 2022-06-24 12:49:45.819179
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademy_ie = LinuxAcademyIE()
    linuxacademy_ie._real_initialize()


# Generated at 2022-06-24 12:49:48.071220
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:49:49.752768
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    ie.login()

# Generated at 2022-06-24 12:49:51.171016
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'LinuxAcademy'

    expected = ['LinuxAcademy']
    assert ie.ie_key() == expected



# Generated at 2022-06-24 12:49:58.114631
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    resp = LinuxAcademyIE()._real_extract('https://linuxacademy.com/cp/modules/view/id/154')
    assert resp['playlist_count'] == 41
    assert resp['title'] == 'AWS Certified Cloud Practitioner'
    assert resp['description'] == 'md5:a68a299ca9bb98d41cca5abc4d4ce22c'
    assert resp['duration'] == 28835

# Generated at 2022-06-24 12:49:59.218194
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:50:04.651569
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.IE_DESC == 'Linux Academy'
    assert ie._VALID_URL == \
            r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson' + \
            r'/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-24 12:50:05.077384
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE

# Generated at 2022-06-24 12:50:11.849122
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._NETRC_MACHINE == 'linuxacademy'
    assert LinuxAcademyIE()._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert LinuxAcademyIE()._ORIGIN_URL == 'https://linuxacademy.com'
    assert LinuxAcademyIE()._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'

# Generated at 2022-06-24 12:50:15.510802
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE({
        'username': 'username123',
        'password': 'pasw1234'
    })

# Generated at 2022-06-24 12:50:17.600031
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE('LinuxAcademy')._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:50:21.610582
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info_extractor = LinuxAcademyIE()
    assert info_extractor._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert info_extractor._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:50:32.574273
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    mobj = re.match(LinuxAcademyIE._VALID_URL, 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    assert mobj.group('chapter_id') == '7971'
    assert mobj.group('lesson_id') == '2'
    assert mobj.group('course_id') is None

    mobj = re.match(LinuxAcademyIE._VALID_URL, 'https://linuxacademy.com/cp/modules/view/id/154')
    assert mobj.group('chapter_id') is None
    assert mobj.group('lesson_id') is None
    assert mobj.group('course_id') == '154'

# Generated at 2022-06-24 12:50:33.548937
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie

# Generated at 2022-06-24 12:50:35.099937
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert isinstance(instance, LinuxAcademyIE)
    assert instance.ie_key() == 'LinuxAcademy'


# Generated at 2022-06-24 12:50:36.449454
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE().ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:50:40.699406
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_url = 'https://linuxacademy.com/cp/modules/view/id/154'
    assert LinuxAcademyIE.suitable(test_url)
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademyIE'
    assert LinuxAcademyIE._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:50:41.597812
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    c = LinuxAcademyIE()
    assert c is not None


# Generated at 2022-06-24 12:50:42.935335
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('LinuxAcademyIE')


# Generated at 2022-06-24 12:50:44.717033
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """ Unit test for constructor of class LinuxAcademyIE """
    LinuxAcademyIE()



# Generated at 2022-06-24 12:50:48.490227
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # python 2.6
    # url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2'
    # la = LinuxAcademyIE(url)
    # assert(str(la.chapter_id) == "7971")
    pass

# Generated at 2022-06-24 12:50:56.584452
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        import http.server
        import socketserver
    except ImportError:
        import BaseHTTPServer as http
        import SocketServer as socketserver
    import threading
    import time

    from .common import http_test_server
    from ..utils import encode_data_uri

    class DummyServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
        """Dummy server"""

    def handle(self):
        """Handler for handle()"""
        pass

    def dummy_http_server(port):
        """Dummy HTTP server"""
        request_handler = http.server.SimpleHTTPRequestHandler
        request_handler.handle = handle
        server = DummyServer(('localhost', port), request_handler)
        server_thread = threading.Thread(target=server.serve_forever)
       

# Generated at 2022-06-24 12:50:57.822934
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:50:58.523059
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-24 12:51:01.443971
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        (LinuxAcademyIE())
    except Exception as e:
        print(str(e))
    else:
        print('LinuxAcademyIE is successfully installed')



# Generated at 2022-06-24 12:51:03.359256
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert hasattr(ie, '_NETRC_MACHINE')
    assert hasattr(ie, '_AUTHORIZE_URL')
    assert hasattr(ie, '_ORIGIN_URL')
    assert hasattr(ie, '_CLIENT_ID')


# Generated at 2022-06-24 12:51:04.675080
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
	LinuxAcademyIE(url)



# Generated at 2022-06-24 12:51:05.683117
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    return LinuxAcademyIE

# Generated at 2022-06-24 12:51:15.339546
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie.IE_NAME == 'linuxacademy'


# Generated at 2022-06-24 12:51:26.301809
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|https?://(?:www\.)?linuxacademy\.com/cp/modules/view/id/(?P<course_id>\d+)'

# Generated at 2022-06-24 12:51:28.094159
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie is not None

# Generated at 2022-06-24 12:51:34.215987
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE(None, None)
    except Exception as e:
        print("\nException: %s\n" % e)
        #assert e.code == 500
        #assert e.reason == 'Failed to login'
        #assert str(e) == 'Failed to login'
    return

test_LinuxAcademyIE()

# Generated at 2022-06-24 12:51:40.661387
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # logged in
    assert extract_info(
        None, None,
        'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
        '7971-2')
    # not logged in
    assert '7971-2' in extract_info(
        None, None,
        'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')

# Generated at 2022-06-24 12:51:47.763208
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    video = LinuxAcademyIE()._real_extract(
            "https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2")
    assert video['title'] == 'Overview'
    assert video['id'] == "1498-2"
    assert video['description'] == 'md5:e5ce5de5c541d00a8c6cd9ac1b506f6a'
    assert video['timestamp'] == 1418480350



# Generated at 2022-06-24 12:51:49.222605
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    class_linuxAcademyIE = LinuxAcademyIE


# Generated at 2022-06-24 12:51:52.114404
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    ie = LinuxAcademyIE()
    ie.extract(url)

# Generated at 2022-06-24 12:51:52.733499
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE

# Generated at 2022-06-24 12:52:03.106490
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Given
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2'

# Generated at 2022-06-24 12:52:04.350102
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    #TODO
    pass

# Generated at 2022-06-24 12:52:06.657603
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)
    assert ie.IE_NAME == 'LinuxAcademy'


# Generated at 2022-06-24 12:52:08.356647
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    if ie is not None:
        assert isinstance(ie, LinuxAcademyIE)

# Generated at 2022-06-24 12:52:13.792812
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:52:15.939475
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._WORKING == True


# Generated at 2022-06-24 12:52:17.347725
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    client = LinuxAcademyIE()

# Generated at 2022-06-24 12:52:24.105048
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        from .test_linuxacademy import LINUXACADEMY_USERNAME, LINUXACADEMY_PASSWORD
    except ImportError:
        return 'Test requires linuxacademy username and password'

    aie = LinuxAcademyIE()
    aie._login(
        username=LINUXACADEMY_USERNAME,
        password=LINUXACADEMY_PASSWORD)

# Generated at 2022-06-24 12:52:33.497626
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE('LinuxAcademy')
    expected_result = {
        '_VALID_URL': 'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/([0-9]+)/lesson/([0-9]+)',
        '_AUTHORIZE_URL': 'https://login.linuxacademy.com/authorize',
        '_ORIGIN_URL': 'https://linuxacademy.com',
        '_CLIENT_ID': 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx',
        '_NETRC_MACHINE': 'linuxacademy'
    }
    assert ie.__dict__ == expected_result

# Generated at 2022-06-24 12:52:43.190744
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    module = test_LinuxAcademyIE
    import os
    import unittest
    from .common import internet_resource_available, skip_if_no_network
    from . import get_testcases_from_json, FakeLoginNetrcAuthenticator

    test_cases = get_testcases_from_json(module, 'test_LinuxAcademyIE.json')

    @skip_if_no_network
    class TestLinuxAcademyIE(unittest.TestCase):
        def setUp(self):
            self.la_ie = LinuxAcademyIE(FakeLoginNetrcAuthenticator())
        def test_get_real_initialize(self):
            self.assertTrue(internet_resource_available(self.la_ie._ORIGIN_URL))

# Generated at 2022-06-24 12:52:44.558115
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # test LinuxAcademyIE constructor
    assert LinuxAcademyIE

# Generated at 2022-06-24 12:52:56.546498
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert not LinuxAcademyIE.suitable(None)
    assert LinuxAcademyIE.suitable('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    assert LinuxAcademyIE.suitable('https://linuxacademy.com/cp/modules/view/id/154')
    assert not LinuxAcademyIE.suitable('https://linuxacademy.com/cp/')

    # _login
    la = LinuxAcademyIE()
    try:
        # Login failed
        la._login()
    finally:
        la.to_screen('%s: Login tests completed.' % la.IE_NAME)

    # _real_initialize
    la = LinuxAcademyIE()

# Generated at 2022-06-24 12:53:02.177195
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    #Test for valid Youtube URL
    URL1 = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    linuxacademy_url1 = LinuxAcademyIE()._real_extract(URL1)
    assert linuxacademy_url1['id'] == '7971-2'
    assert linuxacademy_url1['title'] == 'What Is Data Science'
    assert linuxacademy_url1['description'] == 'md5:c574a3c20607144fb36cb65bdde76c99'
    assert linuxacademy_url1['timestamp'] == 1607387907
    assert linuxacademy_url1['upload_date'] == '20201208'

# Generated at 2022-06-24 12:53:03.045122
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:53:03.899205
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE.test()

# Generated at 2022-06-24 12:53:11.015736
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademyIE = LinuxAcademyIE(InfoExtractor())
    linuxacademyIE.login()
    info = linuxacademyIE._real_extract(url='https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')  # noqa
    assert info['id'] == '7971-2'
    assert info['title'] == 'What Is Data Science'
    assert info['description'] == 'md5:c574a3c20607144fb36cb65bdde76c99'
    info = linuxacademyIE._real_extract(url='https://linuxacademy.com/cp/modules/view/id/154')  # noqa
    assert info['id'] == '154'

# Generated at 2022-06-24 12:53:12.524163
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Simple test for the creation of an instance
    LinuxAcademyIE()

# Generated at 2022-06-24 12:53:13.649901
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()

# Generated at 2022-06-24 12:53:15.099910
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE("")

# Generated at 2022-06-24 12:53:16.443708
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:53:24.561220
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ''' Test case for login when username and password is given via
        command line argument.
    '''
    import os
    import sys
    LA_USERNAME = "-u"
    LA_PASSWORD = "-p"
    if LA_USERNAME in sys.argv and LA_PASSWORD in sys.argv:
        sys.argv.remove(LA_USERNAME)
        sys.argv.remove(LA_PASSWORD)

        import subprocess
        args = [sys.executable, os.path.abspath(__file__)]
        subprocess.check_call(args, env=dict(os.environ,
                                             LA_USERNAME=sys.argv[1],
                                             LA_PASSWORD=sys.argv[2]))

# Generated at 2022-06-24 12:53:29.385188
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert(ie.IE_NAME == 'linuxacademy')
    assert(ie.LOGIN_URL == 'https://login.linuxacademy.com/authorize')
    assert(ie.ORIGIN_URL == 'https://linuxacademy.com')
    assert(ie.NETRC_MACHINE == 'linuxacademy')

# Generated at 2022-06-24 12:53:30.154413
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-24 12:53:34.333441
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Arrange
    url = "https://linuxacademy.com/cp/modules/view/id/154"
    # Act
    instance = LinuxAcademyIE()
    # Assert
    assert isinstance(instance, LinuxAcademyIE)


# Generated at 2022-06-24 12:53:35.643465
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Successful initialization
    LinuxAcademyIE('LinuxAcademy')

# Generated at 2022-06-24 12:53:46.976315
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test case 1: login with valid username and password
    test_case_1 = LinuxAcademyIE({'username': 'test@example.com', 'password': 'test'})
    # Check if the class is initialized correctly
    assert test_case_1.username == 'test@example.com'
    assert test_case_1.password == 'test'
    assert test_case_1._downloader.params.get('username') == 'test@example.com'
    assert test_case_1._downloader.params.get('password') == 'test'
    # Test case 2: login with invalid username and password
    test_case_2 = LinuxAcademyIE({'username': 'test@example.com', 'password': 'test123'})
    # Check if the class is initialized correctly

# Generated at 2022-06-24 12:53:54.446344
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # default
    obj = LinuxAcademyIE()
    assert obj.NETRC_MACHINE == 'linuxacademy'
    assert obj.CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert obj.AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert obj.ORIGIN_URL == 'https://linuxacademy.com'
    assert obj.VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'

# Generated at 2022-06-24 12:54:06.853733
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    def _assert_match(regex, expected, actual):
        if expected != actual:
            print('Failed: %r %r %r' % (regex, expected, actual))
    _assert_match(LinuxAcademyIE._VALID_URL, True, re.match(LinuxAcademyIE._VALID_URL, 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675') is not None)
    _assert_match(LinuxAcademyIE._VALID_URL, True, re.match(LinuxAcademyIE._VALID_URL, 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2') is not None)

# Generated at 2022-06-24 12:54:18.336859
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == '''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-24 12:54:29.339741
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    login_info = {'login': 'username', 'password': 'password'}
    instance = LinuxAcademyIE(login_info)
    assert instance._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert instance._ORIGIN_URL == 'https://linuxacademy.com'
    assert instance._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert instance._NETRC_MACHINE == 'linuxacademy'

    login_info = {'login': '', 'password': ''}
    instance = LinuxAcademyIE(login_info)
    assert instance._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert instance

# Generated at 2022-06-24 12:54:30.497569
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE._VALID_URL

# Generated at 2022-06-24 12:54:33.534231
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    class ConstructedLinuxAcademyIE(LinuxAcademyIE):
        def _login(self):
            pass
    assert ConstructedLinuxAcademyIE.ie_key() == LinuxAcademyIE.ie_key()

# Generated at 2022-06-24 12:54:35.811662
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_info = 'Testing constructor of class LinuxAcademyIE.'
    ie = LinuxAcademyIE()
    assert ie is not None, test_info

# Generated at 2022-06-24 12:54:38.180997
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE("1", "2", "3", "4", "5")

# Generated at 2022-06-24 12:54:39.625247
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print(LinuxAcademyIE)
    LinuxAcademyIE


# Generated at 2022-06-24 12:54:41.995153
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # test constructor of LinuxAcademyIE
    try:
        LinuxAcademyIE(None)
    except TypeError:
        pass


# Generated at 2022-06-24 12:54:43.013424
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'

# Generated at 2022-06-24 12:54:48.031464
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    x = LinuxAcademyIE()
    assert x._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''


# Generated at 2022-06-24 12:54:50.683136
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:54:54.376478
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    tester = LinuxAcademyIE()
    assert(LinuxAcademyIE.ie_key() == 'LinuxAcademy')
    assert(LinuxAcademyIE.ie_key() in tester._ies)
    assert(tester.name in tester._ies)

# Generated at 2022-06-24 12:54:55.884873
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert isinstance(LinuxAcademyIE(), InfoExtractor)


# Generated at 2022-06-24 12:54:56.910102
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:55:02.777640
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_obj = LinuxAcademyIE(None)
    assert test_obj.ie_key() == 'LinuxAcademy'
    assert test_obj.ie_key() == 'LinuxAcademy'
    assert test_obj.ie_key() == 'LinuxAcademy'
    assert test_obj.ie_key() == 'LinuxAcademy'
    assert test_obj.ie_key() == 'LinuxAcademy'
    assert test_obj.ie_key() == 'LinuxAcademy'
test_LinuxAcademyIE()

# Generated at 2022-06-24 12:55:13.810507
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Login required
    linuxacademy = LinuxAcademyIE()(url="https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2")
    assert linuxacademy.get('skip') == 'Requires Linux Academy account credentials'
    assert linuxacademy.get('check_text') == 'requires account credentials'

    # Login required
    linuxacademy = LinuxAcademyIE()(url="https://linuxacademy.com/cp/modules/view/id/154")
    assert linuxacademy.get('skip') == 'Requires Linux Academy account credentials'
    assert linuxacademy.get('check_text') == 'requires account credentials'

# Generated at 2022-06-24 12:55:15.573572
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.IE_NAME == 'LinuxAcademy'


# Generated at 2022-06-24 12:55:17.140369
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.__class__.__name__ == 'LinuxAcademyIE'

# Generated at 2022-06-24 12:55:18.227765
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:55:21.312177
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
    except AssertionError:
        pass
    else:
        assert False, "Expected AssertionError in test_LinuxAcademyIE()"

# Generated at 2022-06-24 12:55:22.874566
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:55:26.003928
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test config file contains valid login credentials
    try:
        LinuxAcademyIE._login(LinuxAcademyIE)
        return True
    except (KeyError, ExtractorError):
        return False

# Generated at 2022-06-24 12:55:28.698191
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    "Test constructor of LinuxAcademyIE"
    url = 'http://www.linuxacademy.com/cp/courses/lesson/course/1/lesson/1'
    LinuxAcademyIE(compat_urllib_request.Request(url))


# Generated at 2022-06-24 12:55:32.462423
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # The unit test that calls LinuxAcademyIE class
    try:
        LinuxAcademyIE("LinuxAcademyIE","LinuxAcademyIE")
    except NameError as e:
        print("No LinuxAcademyIE class found")

#test_LinuxAcademyIE()

# Generated at 2022-06-24 12:55:36.636057
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    b = LinuxAcademyIE()
    assert b.get_options()['username'] != ''
    assert b.get_options()['password'] != ''
    assert b.get_options()['username'] != ''
    assert b.get_options()['password'] != ''

# Generated at 2022-06-24 12:55:41.208971
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'linuxacademy'
    assert LinuxAcademyIE.ie_key() == LinuxAcademyIE.ie_key()
    assert LinuxAcademyIE == LinuxAcademyIE.ie_key()
    assert LinuxAcademyIE.ie_key() == LinuxAcademyIE.ie_key()

# Generated at 2022-06-24 12:55:49.935553
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    path = 'tests/resources/linuxacademy/7971-2'
    test = '{"lesson_id":7971,"lesson_name":"What Is Data Science","lesson_subtitle":"","lesson_subtitle_md":"","lesson_subtitle_md_desc":"","lesson_type":301,"lesson_subtype":1,"source_type":3,"video_duration":303410,"video_duration_formatted":"05:03","video_source_id":"959b5698-7c2e-11ea-a7f1-0242ac120005"}'

# Generated at 2022-06-24 12:56:01.738087
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'

# Generated at 2022-06-24 12:56:11.597552
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test several subclasses:
    for ie_cls in (LinuxAcademyIE,
                   ):
        ie_instance = ie_cls("https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675")
        assert ie_instance._VALID_URL == "^https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|modules/view/id/(?P<course_id>\\d+))$"
        assert ie_instance._NETRC_MACHINE == "linuxacademy"

# Generated at 2022-06-24 12:56:13.590805
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
    except Exception as e:
        print(e)
        assert False



# Generated at 2022-06-24 12:56:17.097600
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'LinuxAcademy'
    assert ie.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-24 12:56:17.971419
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:56:21.139242
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        lin = LinuxAcademyIE()
        assert (True)
    except AssertionError:
        assert (False)


# Generated at 2022-06-24 12:56:22.663813
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(None,
                        {'username': 'johndoe', 'password': 'dumbpassword'})

# Generated at 2022-06-24 12:56:24.326483
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == "LinuxAcademy"

# Generated at 2022-06-24 12:56:26.201449
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # The only purpose of this test is to instantiate a class object
    LinuxAcademyIE(None)._real_initialize()

# Generated at 2022-06-24 12:56:33.879554
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():

    # test initialization
    ie = LinuxAcademyIE()
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-24 12:56:35.529726
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('')

# Generated at 2022-06-24 12:56:38.632955
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    #Testing with invalid url
    ia = LinuxAcademyIE()
    assert ia.ie_key() == 'LinuxAcademy', 'Constructor of class LinuxAcademyIE is not configured as required'

# Generated at 2022-06-24 12:56:39.329310
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:56:40.160420
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-24 12:56:51.287763
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.IE_DESC == 'LinuxAcademy.com'
    assert ie.VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|https?://(?:www\.)?linuxacademy\.com/cp/modules/view/id/(?P<course_id>\d+)'
    assert ie.NETRC_MACHINE == 'linuxacademy'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'

# Generated at 2022-06-24 12:57:00.696664
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print("Test LinuxAcademyIE")

    extractor = LinuxAcademyIE()

    # success
    assert extractor.ie_key() == 'LinuxAcademy'
    assert extractor.IE_NAME == 'linuxacademy'
    assert extractor.IE_DESC == 'LinuxAcademy'
    assert hasattr(extractor, '_NETRC_MACHINE')
    assert hasattr(extractor, '_TESTS')
    assert hasattr(extractor, '_VALID_URL')
    assert hasattr(extractor, '_download_webpage')
    assert hasattr(extractor, '_download_webpage_handle')
    assert hasattr(extractor, '_login')
    assert hasattr(extractor, '_parse_json')

# Generated at 2022-06-24 12:57:02.542650
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert not hasattr(LinuxAcademyIE, '_login')
    ie = LinuxAcademyIE()
    assert hasattr(ie, '_login')

# Generated at 2022-06-24 12:57:04.049023
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    a = LinuxAcademyIE()
    assert a._CLIENT_ID is not None

# Generated at 2022-06-24 12:57:07.544861
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info = LinuxAcademyIE()._real_extract("https://www.linuxacademy.com/cp/modules/view/id/154")
    print(info)

# Generated at 2022-06-24 12:57:12.657350
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test empty URL
    with pytest.raises(AssertionError):
        LinuxAcademyIE(downloader=None, ie_key=None)
    # Test invalid URL
    with pytest.raises(RegexNotFoundError):
        LinuxAcademyIE(downloader=None, ie_key=None).url_result('https://youtube.com/embed/12345678')

# Generated at 2022-06-24 12:57:13.762051
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    x = LinuxAcademyIE()

# Generated at 2022-06-24 12:57:20.395349
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test with url that contains only course or chapter_id or lecture_id or course_id
    unit_test_urls = ['https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2',
                      'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
                      'https://linuxacademy.com/cp/modules/view/id/154']

    for unit_test_url in unit_test_urls:
        obj = LinuxAcademyIE()
        # Extract info from url
        info = obj._real_extract(unit_test_url)
        print(info)

# Generated at 2022-06-24 12:57:30.443121
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_cases = LinuxAcademyIE._TESTS
    for case in test_cases:
        url = LinuxAcademyIE._VALID_URL % case['url']
        ie = LinuxAcademyIE(url)
        assert ie._VALID_URL == LinuxAcademyIE._VALID_URL
        assert ie._TESTS == LinuxAcademyIE._TESTS
        assert ie._AUTHORIZE_URL == LinuxAcademyIE._AUTHORIZE_URL
        assert ie._ORIGIN_URL == LinuxAcademyIE._ORIGIN_URL
        assert ie._CLIENT_ID == LinuxAcademyIE._CLIENT_ID
        assert ie._NETRC_MACHINE == LinuxAcademyIE._NETRC_MACHINE


# Generated at 2022-06-24 12:57:39.587609
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test = "https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2"
    test2 = "https://linuxacademy.com/cp/modules/view/id/154"

    linuxAcademy = LinuxAcademyIE()
    mobj = re.match(linuxAcademy._VALID_URL, test)
    chapter_id, lecture_id, course_id = mobj.group('chapter_id', 'lesson_id', 'course_id')
    item_id = course_id if course_id else '%s-%s' % (chapter_id, lecture_id)
    
    webpage = linuxAcademy._download_webpage(test, item_id)
    