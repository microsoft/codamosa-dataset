

# Generated at 2022-06-26 12:21:15.639994
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-26 12:21:17.613698
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_0 = LinuxAcademyIE()
    assert linux_academy_i_e_0


# Generated at 2022-06-26 12:21:19.214726
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert 'LinuxAcademy'[::-1] == 'ymedeAxunil'

# Generated at 2022-06-26 12:21:25.734411
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()
    assert 'LinuxAcademyIE' in str(linux_academy_i_e)
    assert linux_academy_i_e._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'
    assert linux_academy_i_e._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert linux_academy_i_e._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-26 12:21:27.997060
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE
    print('Created: %r' % LinuxAcademyIE)


# Generated at 2022-06-26 12:21:29.551583
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_0 = LinuxAcademyIE()

# Generated at 2022-06-26 12:21:31.762953
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from LinuxAcademy import LinuxAcademyIE
    assert_raises(TypeError, LinuxAcademyIE)
    return

# Generated at 2022-06-26 12:21:32.436723
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-26 12:21:34.127007
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_0 = LinuxAcademyIE()


# Generated at 2022-06-26 12:21:36.330941
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_1 = LinuxAcademyIE()


# Generated at 2022-06-26 12:21:57.548145
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'linuxacademy'

# Generated at 2022-06-26 12:22:00.945016
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx' in ie._CLIENT_ID

# Generated at 2022-06-26 12:22:03.420468
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE('test123', 'test123')
    except:
        raise Exception('test_LinuxAcademyIE failed')


# Generated at 2022-06-26 12:22:07.726912
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test access protected link
    LinuxAcademyIE()._download_webpage('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675', None)
    # Test access public link
    LinuxAcademyIE()._download_webpage('https://linuxacademy.com/cp/modules/view/id/154', None)

# Generated at 2022-06-26 12:22:17.855693
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # test assertions in constructor LinuxAcademyIE(InfoExtractor)
    ie = LinuxAcademyIE({
        'username': 'user',
        'password': 'pass',
    })
    for name, value in {
        '_login': ie._login,
        '_VALID_URL': ie._VALID_URL,
        '_CLIENT_ID': ie._CLIENT_ID,
        '_AUTHORIZE_URL': ie._AUTHORIZE_URL,
        '_ORIGIN_URL': ie._ORIGIN_URL,
        '_NETRC_MACHINE': ie._NETRC_MACHINE,
    }.items():
        assert getattr(ie, name) == value


# Generated at 2022-06-26 12:22:18.368451
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:22:20.537419
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    downloader = LinuxAcademyIE()
    assert downloader

# Generated at 2022-06-26 12:22:22.583906
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE.suite()


__all__ = ['LinuxAcademyIE', 'test_LinuxAcademyIE']

# Generated at 2022-06-26 12:22:31.455535
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info = {
        'id': '7971-2',
        'ext': 'mp4',
        'title': 'What Is Data Science',
        'description': 'md5:c574a3c20607144fb36cb65bdde76c99',
        'timestamp': 1607387907,
        'upload_date': '20201208',
        'duration': 304,
    }

    ie = LinuxAcademyIE()
    ie.initialize()
    lesson_info = ie.extract(
        'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
    )

    if isinstance(lesson_info, dict):
        assert lesson_info == info



# Generated at 2022-06-26 12:22:32.801295
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-26 12:23:13.508681
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademyie = LinuxAcademyIE()
    linuxacademyie._login()

# Generated at 2022-06-26 12:23:23.471932
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Constructor LinuxAcademyIE
    ie_LinuxAcademy = LinuxAcademyIE(None)

    # Public properties
    assert hasattr(ie_LinuxAcademy, '_VALID_URL')
    assert hasattr(ie_LinuxAcademy, '_TESTS')
    assert hasattr(ie_LinuxAcademy, '_AUTHORIZE_URL')
    assert hasattr(ie_LinuxAcademy, '_ORIGIN_URL')
    assert hasattr(ie_LinuxAcademy, '_CLIENT_ID')
    assert hasattr(ie_LinuxAcademy, '_NETRC_MACHINE')

    # Protected methods
    assert hasattr(ie_LinuxAcademy, '_real_initialize')
    assert hasattr(ie_LinuxAcademy, '_login')


# Generated at 2022-06-26 12:23:26.036112
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # test of constructor
    ie = LinuxAcademyIE()
    assert ie.login() is False    
    
test_LinuxAcademyIE()

# Generated at 2022-06-26 12:23:26.920569
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:23:28.652665
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    dl = LinuxAcademyIE()
    assert isinstance(dl, LinuxAcademyIE)

# Generated at 2022-06-26 12:23:36.724642
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Downloading login page
    # Downloading callback page
    # Extracting m3u8 information

    # Not required for testing as it is automatically done by the post_request_hook.
    # # Downloading token validation page
    ie = LinuxAcademyIE()
    ie.extract('https://linuxacademy.com/cp/modules/view/id/154')
    ie.extract('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')

# Generated at 2022-06-26 12:23:41.101280
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL
    assert ie._TESTS
    assert ie.SUCCESS_REGEX
    assert ie.FAILURE_REGEX
    assert ie._AUTHORIZE_URL
    assert ie._ORIGIN_URL
    assert ie._CLIENT_ID
    assert ie._NETRC_MACHINE

# Generated at 2022-06-26 12:23:41.916572
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:23:43.644847
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert(LinuxAcademyIE.ie_key() == 'LinuxAcademy')

# Generated at 2022-06-26 12:23:45.253361
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_object = LinuxAcademyIE()
    assert test_object.suffix == 'LinuxAcademy'

# Generated at 2022-06-26 12:25:18.378159
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    myExtractor = LinuxAcademyIE("https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2")
    assert myExtractor is not None, "Failed to instantiate LinuxAcademyIE"

# Generated at 2022-06-26 12:25:21.567605
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = urljoin(LinuxAcademyIE._ORIGIN_URL, "/cp/courses/lesson/course/7971/lesson/2/module/675")
    ie = LinuxAcademyIE()
    assert ie.suitable(url)
    assert url == ie.url_result(url).url

# Generated at 2022-06-26 12:25:28.297616
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    class_ = LinuxAcademyIE
    # Call the constructor of class LinuxAcademyIE
    obj = class_()
    # Check the properties of object obj
    assert obj._AUTHORIZE_URL == "https://login.linuxacademy.com/authorize"
    assert obj._ORIGIN_URL == "https://linuxacademy.com"
    assert obj._CLIENT_ID == "KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx"
    assert obj._NETRC_MACHINE == "linuxacademy"


# Generated at 2022-06-26 12:25:29.594964
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('LinuxAcademy', 'linuxacademy')

# Generated at 2022-06-26 12:25:30.424482
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:25:32.235326
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert(ie.IE_NAME == 'linuxacademy')
    assert(ie.IE_DESC == 'Linux Academy')

# Generated at 2022-06-26 12:25:33.860837
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    l = LinuxAcademyIE()
    assert isinstance(l, LinuxAcademyIE)

# Generated at 2022-06-26 12:25:34.805742
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    v = LinuxAcademyIE()
    assert v != None

# Generated at 2022-06-26 12:25:41.765756
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    ie._CLIENT_ID = "KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx"
    ie._AUTHORIZE_URL = "https://login.linuxacademy.com/authorize"
    ie._ORIGIN_URL = "https://linuxacademy.com"
    ie._NETRC_MACHINE = "linuxacademy"
    assert ie._CLIENT_ID == "KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx"
    assert ie._AUTHORIZE_URL == "https://login.linuxacademy.com/authorize"
    assert ie._ORIGIN_URL == "https://linuxacademy.com"
    assert ie

# Generated at 2022-06-26 12:25:45.931713
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ies = LinuxAcademyIE()
    ie = ies['linuxacademy']
    ie._KALTURA_ID = ie.ie_key()
    ie._CLIENT_ID = ie.ie_key()
    ie._NETRC_MACHINE = ie.ie_key()
    ie._AUTHORIZE_URL = ie.ie_key()
    ie._ORIGIN_URL = ie.ie_key()

# Generated at 2022-06-26 12:29:35.564134
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # yapf: disable
    test_videos = [
        [
            "https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2",
            "7e3f3b8e744a2a9509f5a8df6f8cd655",
        ]
    ]
    # yapf: enable

    def test_url(url, expected_hash):
        ie = LinuxAcademyIE()
        info = ie.extract(url)
        assert info["id"] in expected_hash

    for url, expected_hash in test_videos:
        test_url(url, expected_hash)

# Generated at 2022-06-26 12:29:39.570518
# Unit test for constructor of class LinuxAcademyIE

# Generated at 2022-06-26 12:29:45.165249
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    UINPUT_1 = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    UINPUT_2 = 'https://linuxacademy.com/cp/modules/view/id/154'
    OUTPUT_1 = '7971-2'
    OUTPUT_2 = '154'
    linux = LinuxAcademyIE()
    assert(linux._real_extract(UINPUT_1)['id'] == OUTPUT_1)
    assert(linux._real_extract(UINPUT_2)['id'] == OUTPUT_2)

# Generated at 2022-06-26 12:29:45.804241
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()

# Generated at 2022-06-26 12:29:46.955543
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE(None, None)
    except Exception as e:
        print(e)

# Generated at 2022-06-26 12:29:47.509934
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-26 12:29:49.460775
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()._login() # Detect if login works or not
    except ExtractorError as e:
        if not isinstance(e.cause, compat_HTTPError):
            raise
        assert e.cause.code == 401

# Generated at 2022-06-26 12:29:51.214528
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert isinstance(instance, LinuxAcademyIE)

# Generated at 2022-06-26 12:29:53.785915
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    inst_LinuxAcademyIE = LinuxAcademyIE('linuxacademy.com', 'LinuxAcademy')
    assert inst_LinuxAcademyIE.ie_key() == 'LinuxAcademy'
    assert inst_LinuxAcademyIE.ie_key() == LinuxAcademyIE.ie_key()

# Generated at 2022-06-26 12:29:54.842113
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    args = {'request': 'request'}
    assert LinuxAcademyIE(**args) != None