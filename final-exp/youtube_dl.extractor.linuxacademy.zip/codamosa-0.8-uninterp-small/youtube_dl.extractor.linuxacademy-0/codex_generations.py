

# Generated at 2022-06-26 12:21:23.383916
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert hasattr(LinuxAcademyIE, '_VALID_URL')
    assert hasattr(LinuxAcademyIE, '_TESTS')
    assert hasattr(LinuxAcademyIE, '_AUTHORIZE_URL')
    assert hasattr(LinuxAcademyIE, '_ORIGIN_URL')
    assert hasattr(LinuxAcademyIE, '_CLIENT_ID')
    assert hasattr(LinuxAcademyIE, '_NETRC_MACHINE')
    assert hasattr(LinuxAcademyIE, '_LOGIN_REQUIRED')
    assert hasattr(LinuxAcademyIE, '_downloader')
    assert hasattr(LinuxAcademyIE, '_WORKING')
    assert hasattr(LinuxAcademyIE, 'suitable')

# Generated at 2022-06-26 12:21:28.850503
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_1 = LinuxAcademyIE(downloader=None)
    linux_academy_i_e_0 = LinuxAcademyIE(downloader=linux_academy_i_e_1)


# Generated at 2022-06-26 12:21:29.962515
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert "LinuxAcademyIE"


# Generated at 2022-06-26 12:21:31.018832
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass


# Generated at 2022-06-26 12:21:33.992260
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()
    #assert linux_academy_i_e.extractor_key == 'LinuxAcademy'


# Generated at 2022-06-26 12:21:35.289264
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()


# Generated at 2022-06-26 12:21:45.910969
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert_raises(TypeError, LinuxAcademyIE)
    assert_raises(TypeError, LinuxAcademyIE, url=False)
    assert_raises(AttributeError, LinuxAcademyIE, url='test')
    assert_raises(AttributeError, LinuxAcademyIE, url=True)
    assert_raises(AttributeError, LinuxAcademyIE, url=None)
    linux_academy_i_e_1 = LinuxAcademyIE(url='test')

# Generated at 2022-06-26 12:21:48.611380
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_0 = LinuxAcademyIE()
    # Verify that LinuxAcademyIE.ie_key is static
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'


# Generated at 2022-06-26 12:21:59.233035
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()
    assert isinstance(linux_academy_i_e, LinuxAcademyIE)
    assert hasattr(linux_academy_i_e, '_VALID_URL')
    assert hasattr(linux_academy_i_e, '_TESTS')
    assert hasattr(linux_academy_i_e, '_AUTHORIZE_URL')
    assert hasattr(linux_academy_i_e, '_ORIGIN_URL')
    assert hasattr(linux_academy_i_e, '_CLIENT_ID')
    assert hasattr(linux_academy_i_e, '_NETRC_MACHINE')

# Generated at 2022-06-26 12:22:08.280925
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    klass = LinuxAcademyIE
    linux_academy_i_e_1 = LinuxAcademyIE()
    assert klass == LinuxAcademyIE
    assert (linux_academy_i_e_1._VALID_URL == klass._VALID_URL)
    assert (linux_academy_i_e_1._NETRC_MACHINE == klass._NETRC_MACHINE)
    assert (linux_academy_i_e_1._CLIENT_ID == klass._CLIENT_ID)
    assert (linux_academy_i_e_1._ORIGIN_URL == klass._ORIGIN_URL)
    assert (linux_academy_i_e_1._AUTHORIZE_URL == klass._AUTHORIZE_URL)

# Unit

# Generated at 2022-06-26 12:22:29.008386
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        a = LinuxAcademyIE()
    except:
        a = None
    assert a


# Generated at 2022-06-26 12:22:30.800034
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'LinuxAcademy'

# Generated at 2022-06-26 12:22:39.831849
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        os.makedirs("/tmp/linuxacademyie")
    except OSError:
        pass
    try:
        os.remove("/tmp/linuxacademyie/.netrc")
    except OSError:
        pass
    try:
        os.remove("/tmp/linuxacademyie/.youtube-dl.cache")
    except OSError:
        pass
    with open("/tmp/linuxacademyie/.netrc", "w") as netrc_file:
        netrc_file.write("""
machine linuxacademy
login test_linux_academy_username
password test_linux_academy_password_that_i_will_not_write_here
""")
    ie = LinuxAcademyIE()

    # Testing login functionality

# Generated at 2022-06-26 12:22:50.255225
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_downloader import FakeLogin, TestDownloader
    from .test_utils import TestInfoExtractor
    params = {'skip_download': True}

# Generated at 2022-06-26 12:22:51.114848
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:22:52.453079
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert(ie.IE_NAME == "LinuxAcademy")

# Generated at 2022-06-26 12:22:53.485187
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-26 12:22:54.489082
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert isinstance(LinuxAcademyIE(), LinuxAcademyIE)

# Generated at 2022-06-26 12:22:55.782036
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)

# Generated at 2022-06-26 12:22:56.529018
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:23:36.053086
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('LinuxAcademy', 'https://linuxacademy.com')

# Generated at 2022-06-26 12:23:40.467090
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    json.loads(LinuxAcademyIE()('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')._results[0])
    json.loads(LinuxAcademyIE()('https://linuxacademy.com/cp/modules/view/id/154')._results[0])
    raise SystemExit(0)

# Generated at 2022-06-26 12:23:41.912762
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_linuxacademy_com import test_LinuxAcademyIE

    return test_LinuxAcademyIE.__func__(LinuxAcademyIE)

# Generated at 2022-06-26 12:23:52.986690
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info_extractor_caption_data = {
        '_type': 'url_transparent',
        'id': '7971-2',
        'title': 'What Is Data Science',
        'formats': 'mp4',
        'ext': 'mp4',
        'description': 'md5:c574a3c20607144fb36cb65bdde76c99',
        'timestamp': 1607387907,
        'upload_date': '20201208',
        'duration': 304,
    }

    l_instance = LinuxAcademyIE()

# Generated at 2022-06-26 12:24:03.075734
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    class_ = LinuxAcademyIE
    ie = class_(None)
    assert class_ == ie.__class__
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.IE_DESC == 'Linux Academy'
    assert ie._VALID_URL == 'https?://(?:www\\.)?linuxacademy\\.com/cp/(?:modules/view/id/(?P<course_id>\\d+))?' \
                            '|(?:courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+))'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
   

# Generated at 2022-06-26 12:24:07.562803
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ia = LinuxAcademyIE()
    assert ia.IE_NAME == 'LinuxAcademy'
    assert ia._VALID_URL == r'''(?x)https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'''
    assert isinstance(ia._TESTS, list)

# Generated at 2022-06-26 12:24:08.765715
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    x = LinuxAcademyIE()
    x._login()

# Generated at 2022-06-26 12:24:10.497878
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert obj is not None

# Generated at 2022-06-26 12:24:11.967862
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # import sys
    # sys.settrace(tracefunc)

    ies = LinuxAcademyIE()
    ies.initialize()

# Generated at 2022-06-26 12:24:12.922328
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None)

# Generated at 2022-06-26 12:26:04.184170
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert obj.ie_key() == 'LinuxAcademy'
    assert obj.ie_key_name() == 'Linux Academy'
    # test for other constructor arguments

# Generated at 2022-06-26 12:26:10.178324
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from . import platform_call

    def assert_raises(exe, msg):
        with platform_call.assert_raises_regexp(ExtractorError, msg):
            ie = LinuxAcademyIE(exe)
            ie.extract('')

    exe = object()
    ie = LinuxAcademyIE(exe)
    assert ie._last_downloader == exe
    assert_raises(None, 'Downloader is required')
    assert_raises(exe, 'The credentials must be provided as login')

# Generated at 2022-06-26 12:26:11.932149
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.constructor_name == 'LinuxAcademyIE'

# Generated at 2022-06-26 12:26:12.454929
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-26 12:26:14.801280
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    module = LinuxAcademyIE()
    assert module.username is None, 'username should be None'
    assert module.password is None, 'password should be None'

# Generated at 2022-06-26 12:26:16.440701
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()._login()

if __name__ == '__main__':
    print(LinuxAcademyIE()._login())

# Generated at 2022-06-26 12:26:17.220972
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:26:18.216694
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:26:19.771879
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie

# Generated at 2022-06-26 12:26:22.246367
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    print("LinuxAcademyIE is about to be initiated.")
    ie._real_initialize()
    print("LinuxAcademyIE is initiated.")

test_LinuxAcademyIE()

# Generated at 2022-06-26 12:30:22.168670
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

if __name__ == "__main__":
    test_LinuxAcademyIE()

# Generated at 2022-06-26 12:30:24.074027
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test class constructor"""
    LinuxAcademyIE(None, "https://linuxacademy.com/cp/modules/view/id/154")


# Generated at 2022-06-26 12:30:25.559439
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert isinstance(instance, LinuxAcademyIE)

# Generated at 2022-06-26 12:30:26.982426
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

    assert ie.name == 'linuxacademy'
    assert ie.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-26 12:30:33.702511
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    with open('test_linuxacademy.js') as f:
        test_text = f.read()
    ie_test = LinuxAcademyIE({})

# Generated at 2022-06-26 12:30:34.723371
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:30:35.355483
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:30:39.025706
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from ..test import get_testcases
    ie = LinuxAcademyIE()
    def test_ie(url, data):
        ie.extract(url)
        for key in data:
            assert(ie.extract(url)[key]==data[key])
    testcases = get_testcases(ie.ie_key())
    for testcase in testcases:
        test_ie(testcase['url'], testcase['data'])

# Generated at 2022-06-26 12:30:40.762309
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        # Python 2.6 cannot unittest.TestCase.assertEqual
        assert LinuxAcademyIE._NETRC_MACHINE == 'linuxacademy'
    except:
        assert LinuxAcademyIE._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-26 12:30:46.780072
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    parameters = ['https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675']
    assert LinuxAcademyIE.ie_key() in LinuxAcademyIE._extractors
    assert LinuxAcademyIE.suitable(parameters[0])
    ie = LinuxAcademyIE()
    ie.initialize()
    ie._login()
    assert ie._real_extract(parameters[0])
# End of unit test for constructor of class LinuxAcademyIE