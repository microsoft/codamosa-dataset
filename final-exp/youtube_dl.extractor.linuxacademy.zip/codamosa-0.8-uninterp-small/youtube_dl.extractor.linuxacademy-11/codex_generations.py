

# Generated at 2022-06-26 12:21:17.075955
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_obj = LinuxAcademyIE()
    assert linux_academy_i_e_obj != None


# Generated at 2022-06-26 12:21:18.187921
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()
    assert linux_academy_i_e is not None

# Generated at 2022-06-26 12:21:28.857057
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert LinuxAcademyIE._TESTS[0]['url'] == 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    assert LinuxAcademyIE._TESTS[2]['url'] == 'https://linuxacademy.com/cp/modules/view/id/154'
    assert LinuxAcademyIE._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert LinuxAcademy

# Generated at 2022-06-26 12:21:30.338078
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert (LinuxAcademyIE.__name__ == 'LinuxAcademyIE')

# Generated at 2022-06-26 12:21:31.674236
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()


# Generated at 2022-06-26 12:21:32.811454
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_case_0()

# Generated at 2022-06-26 12:21:39.975780
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_0 = LinuxAcademyIE()
    assert linux_academy_i_e_0._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'


# Generated at 2022-06-26 12:21:42.810542
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():

    linux_academy_i_e = LinuxAcademyIE()
    assert linux_academy_i_e != None
    print(linux_academy_i_e)


# Generated at 2022-06-26 12:21:43.482111
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-26 12:21:44.776129
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    #print(test_case_0())
    print(1)

# Generated at 2022-06-26 12:22:05.796503
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    inst = LinuxAcademyIE(None)
    assert inst._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert inst._ORIGIN_URL == 'https://linuxacademy.com'
    assert inst._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-26 12:22:17.087590
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_ie = LinuxAcademyIE()
    assert linux_academy_ie._VALID_URL == \
           r'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert linux_academy_ie._TESTS[0]['url'] == \
           'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    assert linux_academy_ie._TESTS[0]['info_dict']['id'] == '7971-2'

# Generated at 2022-06-26 12:22:27.023220
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = "https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2"
    assert LinuxAcademyIE()._VALID_URL == LinuxAcademyIE()._VALID_URL
    IEInstance = LinuxAcademyIE()
    assert IEInstance.ie_key() == 'LinuxAcademy'
    assert IEInstance._NETRC_MACHINE == 'linuxacademy'
    assert IEInstance.suitable(url)
    assert IEInstance.IE_NAME == 'linuxacademy'
    assert IEInstance.IE_DESC == 'Linux Academy'
    audio_url = "https://f1.linuxacademy.com/wp-content/uploads/2019/07/01-Introduction.mp3"
    assert IEInstance.suitable(audio_url) == False

# Generated at 2022-06-26 12:22:30.139665
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    t_ie = LinuxAcademyIE('LinuxAcademy')
    ie_object = t_ie._real_initialize()
    assert ie_object is None, '_real_initialize should return None'

# Generated at 2022-06-26 12:22:31.760136
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    i = LinuxAcademyIE()
    assert i.IE_NAME == 'linuxacademy'

# Generated at 2022-06-26 12:22:33.106668
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE._TESTS.pop(0)

# Generated at 2022-06-26 12:22:34.040558
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

# Generated at 2022-06-26 12:22:44.140390
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    La = LinuxAcademyIE(object)
    assert La._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert La._ORIGIN_URL == 'https://linuxacademy.com'
    assert La._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert La._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-26 12:22:47.830286
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL is not None
    assert ie._NETRC_MACHINE is not None
    assert ie._CLIENT_ID is not None
    assert ie._ORIGIN_URL is not None
    assert ie._AUTHORIZE_URL is not None

# Generated at 2022-06-26 12:22:48.570098
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    global LinuxAcademyIE
    LinuxAcademyIE

# Generated at 2022-06-26 12:23:26.962498
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.__class__.__name__ == 'LinuxAcademyIE'

# Generated at 2022-06-26 12:23:29.987072
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE().IE_NAME == 'linuxacademy'
    assert LinuxAcademyIE()._VALID_URL == LinuxAcademyIE._VALID_URL

# Generated at 2022-06-26 12:23:40.556591
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .fake_webdav import FakeWebdavServerContextProvider
    from .fake_webdav_downloader import FakeWebdavDownloader
    from .server_context import ServerContext
    from .test_webdav import TEST_WEBDAV_SERVER_URL

    with FakeWebdavServerContextProvider() as webdav_server:
        webdav_server.add_entry(
            '{}/linuxacademy'.format(TEST_WEBDAV_SERVER_URL),
            entry_type='directory')

        context = ServerContext(
            downloader=FakeWebdavDownloader(ServerContext({})),
            username='u',
            password='p',
            server_url='{}/linuxacademy'.format(
                TEST_WEBDAV_SERVER_URL))
        context

# Generated at 2022-06-26 12:23:41.507472
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademy_ie = LinuxAcademyIE()
    assert linuxacademy_ie is not None

# Generated at 2022-06-26 12:23:43.690917
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.IE_NAME == 'linuxacademy'
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-26 12:23:50.590454
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # pylint: disable=protected-access
    # test with wrong login info
    with LinuxAcademyIE._build_request(LinuxAcademyIE, {}, {'username': 'test', 'password': 'test'}) as ie:
        ie.login()
        with pytest.raises(ExtractorError) as excinfo:
            ie._real_extract('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
        assert excinfo.value.cause.code == 401

# Generated at 2022-06-26 12:23:54.376060
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """ Test case for LinuxAcademyIE. """
    from .test_cmdline import cmdline
    i = cmdline(LinuxAcademyIE, [])
    i._real_initialize()

# Generated at 2022-06-26 12:23:55.704055
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    obj._login()

# Generated at 2022-06-26 12:24:00.114727
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    testimonial = next(iter(LinuxAcademyIE._TESTS))
    test_url = testimonial['url']
    ie = LinuxAcademyIE(test_url)
    assert ie._VALID_URL == LinuxAcademyIE._VALID_URL

# Generated at 2022-06-26 12:24:03.617060
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    # We can't create an instance of the Linux Academy class yet because
    # of the login. We will have to verify that the login function raises
    # an error with no credentials in place.
    with pytest.raises(ExtractorError):
        ie._login()

# Generated at 2022-06-26 12:25:35.106493
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:25:39.824522
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        # Test constructor
        ie = LinuxAcademyIE() # pylint: disable=too-many-function-args
        print(ie.IE_DESC)
    except (Exception): # pylint: disable=broad-except
        print('Failed to initialize %s instance' % LinuxAcademyIE.IE_NAME)

# Entry point for this script
if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-26 12:25:46.450406
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
   

# Generated at 2022-06-26 12:25:48.408745
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE._real_initialize()
    except ExtractorError as e:
        print('LinuxAcademyIE error: %s' % e)
        return False

    return True

# Generated at 2022-06-26 12:25:50.589457
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.IE_NAME == 'linuxacademy'
    assert ie._VALID_URL

# Generated at 2022-06-26 12:25:51.754849
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:25:59.970221
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert not LinuxAcademyIE.suitable("http://google.com")
    assert LinuxAcademyIE.suitable("https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2")
    assert LinuxAcademyIE.suitable("https://linuxacademy.com/cp/modules/view/id/154")

    lec = LinuxAcademyIE("https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2")
    assert lec.ie_key() == 'LinuxAcademy'

    info = lec.extract('https://linuxacademy.com/cp/modules/view/id/154')
    assert info['id'] == '154'

# Generated at 2022-06-26 12:26:01.851931
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    class_ = LinuxAcademyIE
    assert class_.ie_key() == 'linuxacademy'
    assert class_.working == True
    assert class_.__name__ == 'LinuxAcademyIE'

# Generated at 2022-06-26 12:26:05.126946
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    video = LinuxAcademyIE().extract(url)
    assert video['title'] == 'What Is Data Science'

# Generated at 2022-06-26 12:26:06.607522
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie is not None

# Generated at 2022-06-26 12:29:46.154518
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.IE_DESC == 'Login Required.'
    assert ie._VALID_URL == r'https?://(?:www\.)?linuxacademy\.com/cp/(courses/lesson/course/\d+/lesson/\d+|modules/view/id/\d+)'
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-26 12:29:46.931013
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_instantiation(LinuxAcademyIE)

# Generated at 2022-06-26 12:29:52.935070
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    testVideo = LinuxAcademyIE()
    assert(testVideo.IE_NAME == 'linuxacademy')
    assert(testVideo.IE_DESC == 'Linux Academy')
    assert(testVideo._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    ''')
    testVideo._login()
    testVideo._real_extract

# Generated at 2022-06-26 12:29:54.066575
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)

# Generated at 2022-06-26 12:29:54.715821
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:29:56.072726
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE();

# Generated at 2022-06-26 12:30:01.490782
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie_instance = LinuxAcademyIE()
    assert ie_instance._VALID_URL == '''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert ie_instance._TESTS[0]['url'] == 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    assert ie_instance._TESTS[0]['info_dict']['id'] == '7971-2'
    assert ie

# Generated at 2022-06-26 12:30:03.171587
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert isinstance(instance, LinuxAcademyIE)

# Generated at 2022-06-26 12:30:09.625198
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    infoExtractor = LinuxAcademyIE()
    assert infoExtractor._VALID_URL == \
        r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'
    assert infoExtractor._AUTHORIZE_URL == \
        'https://login.linuxacademy.com/authorize'
    assert infoExtractor._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-26 12:30:10.130703
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass