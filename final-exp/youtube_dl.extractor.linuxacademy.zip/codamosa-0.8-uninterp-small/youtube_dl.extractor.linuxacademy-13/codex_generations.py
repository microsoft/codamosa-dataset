

# Generated at 2022-06-26 12:21:24.272546
# Unit test for constructor of class LinuxAcademyIE

# Generated at 2022-06-26 12:21:25.928573
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_0 = LinuxAcademyIE()

# Generated at 2022-06-26 12:21:37.399423
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_0 = LinuxAcademyIE()
    assert linux_academy_i_e_0._login == None
    assert linux_academy_i_e_0._real_initialize == None
    assert linux_academy_i_e_0._real_extract == None
    assert linux_academy_i_e_0._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert linux_academy_i_e_0._ORIGIN_URL == 'https://linuxacademy.com'
    assert linux_academy_i_e_0._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert linux

# Generated at 2022-06-26 12:21:46.950792
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()

    assert linux_academy_i_e._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-26 12:21:47.481068
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-26 12:21:48.555180
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()

# Generates the test case for LinuxAcademyIE.test_LinuxAcademyIE()


# Generated at 2022-06-26 12:21:55.881852
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_0 = LinuxAcademyIE()
    assert isinstance(linux_academy_i_e_0, LinuxAcademyIE)

# Unit tests for LinuxAcademyIE class
if __name__ == '__main__':
    # linux_academy_i_e_0 = LinuxAcademyIE()
    test_case_0()

# Unit tests for LinuxAcademyIE class
if __name__ == '__main__':
    # test_LinuxAcademyIE()
    pass

# Generated at 2022-06-26 12:21:57.720366
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from . import _test_case_0 as _test_case_0_
    test_case_0()

# Generated at 2022-06-26 12:21:59.191686
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_ = LinuxAcademyIE()

# Generated at 2022-06-26 12:22:02.900593
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .common import InfoExtractor

    linux_academy_i_e = LinuxAcademyIE()
    linux_academy_i_e.initialize()
    assert isinstance(linux_academy_i_e, InfoExtractor)

# Generated at 2022-06-26 12:22:20.810099
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademy_IE = LinuxAcademyIE()
    linuxacademy_IE._real_initialize()



# Generated at 2022-06-26 12:22:22.141377
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'linuxacademy'

# Generated at 2022-06-26 12:22:24.329593
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info_extractor = LinuxAcademyIE()
    username, password = info_extractor._get_login_info()
    if username is None:
        assert username is None
        assert password is None

# Generated at 2022-06-26 12:22:25.201705
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ap = LinuxAcademyIE()

# Generated at 2022-06-26 12:22:26.117922
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()._login()

# Generated at 2022-06-26 12:22:30.994968
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test constructor of class LinuxAcademyIE."""
    assert(LinuxAcademyIE.IE_NAME == 'linuxacademy'
           and LinuxAcademyIE.IE_DESC == 'Linux Academy')
    assert(LinuxAcademyIE.VALID_URL_PATTERN.match('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
           and LinuxAcademyIE.VALID_URL_PATTERN.match('https://linuxacademy.com/cp/modules/view/id/154'))
    assert(LinuxAcademyIE._NETRC_MACHINE == 'linuxacademy')

# Generated at 2022-06-26 12:22:36.746664
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE('LinuxAcademy')
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-26 12:22:37.596627
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:22:47.831183
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Ensure that it raises an error for non-existant url
    with pytest.raises(ValueError) as e:
        LinuxAcademyIE('https://www.linuxacademy.com/', 'nopass')
    assert str(e.value) == 'Invalid URL "https://www.linuxacademy.com/".'

    # Ensure that it raises an error for non-existant account
    with pytest.raises(ExtractorError) as e:
        LinuxAcademyIE('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2',
                       'nopass')

# Generated at 2022-06-26 12:22:50.147119
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')

# Generated at 2022-06-26 12:23:31.467331
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
    except RuntimeError:
        assert True
    else: 
        assert False

# Generated at 2022-06-26 12:23:36.540807
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Example of Linux Academy video page
    # https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675
    linux_academy = LinuxAcademyIE()
    assert linux_academy.IE_NAME == 'linuxacademy'

# Generated at 2022-06-26 12:23:44.519066
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
  assert LinuxAcademyIE()._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-26 12:23:45.411273
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:23:46.267306
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()


# Generated at 2022-06-26 12:23:58.228916
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_utils import run_test_main, MockExtractor
    from .common import InfoExtractor
    from .common import USER_AGENTS

    username = 'testemail@example.com'
    password = 'testpassword'
    ie = LinuxAcademyIE()
    mock_extractor = MockExtractor()
    with run_test_main(mock_extractor, ie) as m:
        ie.add_default_headers({'User-Agent': random.choice(USER_AGENTS)})
        ie.add_login_info(username, password)

# Generated at 2022-06-26 12:24:05.096136
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # type: () -> None
    entry_info = LinuxAcademyIE()._real_extract(
        'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    assert entry_info['id'] == '7971-2'
    assert entry_info['title'] == 'What Is Data Science'
    assert entry_info['description'] == 'md5:c574a3c20607144fb36cb65bdde76c99'
    assert entry_info['timestamp'] == 1607387907
    assert entry_info['duration'] == 304

# Generated at 2022-06-26 12:24:10.985954
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    # _VALID_URL
    assert obj._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    # _TESTS

# Generated at 2022-06-26 12:24:13.786114
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    lai = LinuxAcademyIE(None)
    assert lai._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert lai._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-26 12:24:15.018822
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    IE = LinuxAcademyIE()
    print(IE)

# Generated at 2022-06-26 12:26:04.585986
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert isinstance(LinuxAcademyIE(), LinuxAcademyIE)

# Generated at 2022-06-26 12:26:05.778097
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert obj != None

# Generated at 2022-06-26 12:26:07.021826
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()


# Generated at 2022-06-26 12:26:08.983619
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()._real_extract(
        'https://linuxacademy.com/cp/modules/view/id/154'
    )

# Generated at 2022-06-26 12:26:14.032198
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    temp = LinuxAcademyIE()
    # check if the constructor functions correctly
    assert temp._VALID_URL == "https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))"

# Generated at 2022-06-26 12:26:16.548037
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    # Without account credentials
    ie.extract('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')


# Generated at 2022-06-26 12:26:17.327325
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None, None)

# Generated at 2022-06-26 12:26:18.320876
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:26:20.709632
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_discovery import test_LinuxAcademyIE
    test_LinuxAcademyIE(LinuxAcademyIE)


# Generated at 2022-06-26 12:26:24.917239
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_linuxacademy import test_LinuxAcademyIE
    # Creating a dummy class to use test_LinuxAcademyIE as a test for LinuxAcademyIE
    class DummyLinuxAcademyIE(LinuxAcademyIE):
        _VALID_URL = r'^$'
        _NETRC_MACHINE = None
    # Test for LinuxAcademyIE
    test_LinuxAcademyIE(DummyLinuxAcademyIE)

# Generated at 2022-06-26 12:30:19.815516
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    # User credentials are get from the user's home directory.
    ie._login()
    print('User login has been successful')

# Generated at 2022-06-26 12:30:21.322595
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    par = LinuxAcademyIE()
    par._real_initialize()
    par._login()

# Generated at 2022-06-26 12:30:28.246245
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert ie.i_e_key() == "LinuxAcademyIE"
    assert ie.i_e_ie() == "LinuxAcademyIE"
    assert ie.i_e_name() == "LinuxAcademy"
    assert ie.i_e_description() == "LinuxAcademy"
    assert ie.i_e_key()

# Generated at 2022-06-26 12:30:30.184810
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    ie._login()
    ie._real_extract("https://linuxacademy.com/cp/courses/lesson/course/46/lesson/2")

# Generated at 2022-06-26 12:30:36.627853
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'LinuxAcademy'
    assert ie.IE_DESC == 'LinuxAcademy.com'
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIG

# Generated at 2022-06-26 12:30:37.950573
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    username, password = LinuxAcademyIE._get_login_info()
    assert username != None
    assert password != None

# Generated at 2022-06-26 12:30:46.013970
# Unit test for constructor of class LinuxAcademyIE

# Generated at 2022-06-26 12:30:47.342662
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    IE = LinuxAcademyIE('linuxacademy')
    assert IE.IE_NAME == 'linuxacademy'

# Generated at 2022-06-26 12:30:55.276847
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    global LinuxAcademyIE

    class LinuxAcademyFakePage(object):

        class FakeResponse(object):
            def __init__(self, code):
                self.code = code

        def __init__(self, code=200):
            self._response = self.FakeResponse(code)
            self._content = 'Page content'
            self.url = 'https://login.linuxacademy.com/login/callback?state=state&code=code'
            self.headers = {'Content-Type': 'application/x-www-form-urlencoded'}

        def __enter__(self):
            return self

        def __exit__(self, *a, **kw):
            pass

        def getcode(self):
            return self._response.code

        def read(self):
            return self._content

       