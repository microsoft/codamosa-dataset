

# Generated at 2022-06-26 12:21:15.688896
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert callable(LinuxAcademyIE)

# Generated at 2022-06-26 12:21:16.945469
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()


# Generated at 2022-06-26 12:21:17.867965
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_case_0()

# Generated at 2022-06-26 12:21:19.544347
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_0 = LinuxAcademyIE()
    assert linux_academy_i_e_0

# Generated at 2022-06-26 12:21:21.369165
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()
    assert linux_academy_i_e

# Generated at 2022-06-26 12:21:25.036693
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Constructor of object.
    linux_academy_i_e = LinuxAcademyIE()


if __name__ == '__main__':
    import nose
    nose.runmodule()

# Generated at 2022-06-26 12:21:29.416530
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    _TEST_CASE_ = (
        (
            LinuxAcademyIE,
            [],
            {
                'params': {
                    'skip_download': True
                }
            },
            [test_case_0]
        ),
    )

# Generated at 2022-06-26 12:21:37.980598
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE(
        compat_HTTPError,
        ExtractorError,
        compat_str,
        compat_b64decode,
        clean_html,
        js_to_json,
        parse_duration,
        try_get,
        unified_timestamp,
        urlencode_postdata,
        urljoin,
        'LinuxAcademy',
        'LinuxAcademy',
        'LinuxAcademy',
        'LinuxAcademy',
        'LinuxAcademy',
        'LinuxAcademy'
    )


# Generated at 2022-06-26 12:21:47.127081
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_1 = LinuxAcademyIE()
    assert linux_academy_i_e_1._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize', "Attribut incorrect"
    assert linux_academy_i_e_1._ORIGIN_URL == 'https://linuxacademy.com', 'Attribut incorrect'
    assert linux_academy_i_e_1._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx', 'Attribut incorrect'
    assert linux_academy_i_e_1._NETRC_MACHINE == 'linuxacademy', 'Attribut incorrect'


# Generated at 2022-06-26 12:21:47.955100
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()

# Generated at 2022-06-26 12:22:05.650703
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-26 12:22:16.683775
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .common import InfoExtractor
    from ..compat import (compat_b64decode, compat_HTTPError, compat_str,
                          parse_duration)
    from ..utils import (ExtractorError, clean_html, unified_timestamp,
                         try_get)
    linux_academy_i_e = LinuxAcademyIE()
    # Test whether it is an instance of InfoExtractor
    assert isinstance(linux_academy_i_e, InfoExtractor)
    # Test whether the default ie_key of class InfoExtractor is overriden

# Generated at 2022-06-26 12:22:19.506896
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()
    assert isinstance(linux_academy_i_e, InfoExtractor)


# Generated at 2022-06-26 12:22:20.370665
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass
    # linux_academy_i_e_0 = LinuxAcademyIE()


# Generated at 2022-06-26 12:22:29.548765
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():

    # Create instance of class LinuxAcademyIE
    linux_academy_i_e_0 = LinuxAcademyIE()

    assert linux_academy_i_e_0._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'

# Generated at 2022-06-26 12:22:31.283299
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_0 = LinuxAcademyIE()
    # No need for testing

# Generated at 2022-06-26 12:22:31.903185
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_case_0()


# Generated at 2022-06-26 12:22:33.955628
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()

    # test_case_0 is a dummy test for the constructor


# Generated at 2022-06-26 12:22:34.863907
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert (LinuxAcademyIE())

# Generated at 2022-06-26 12:22:40.043275
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxAcademyIE_0 = LinuxAcademyIE()
    assert linuxAcademyIE_0._VALID_URL == 'https?:\/\/(?:www\.)?linuxacademy\.com\/cp\/(?:courses\/lesson\/course\/(?P<chapter_id>\d+)\/lesson\/(?P<lesson_id>\d+)|modules\/view\/id\/(?P<course_id>\d+))'

# Generated at 2022-06-26 12:23:02.129009
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    d = LinuxAcademyIE()
    assert isinstance(d, LinuxAcademyIE)

# Generated at 2022-06-26 12:23:03.441756
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:23:07.159148
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    if LinuxAcademyIE.ie_key() not in sys.modules:
        return
    ie = LinuxAcademyIE()
    ie.extract('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')

# Generated at 2022-06-26 12:23:07.684178
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
	LinuxAcademyIE

# Generated at 2022-06-26 12:23:16.324081
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ied = LinuxAcademyIE()
    assert ied.IE_NAME == 'linuxacademy'
    assert ied.VALID_URL == 'https?://(?:www\.)?(?:linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|linuxacademy\.com/cp/modules/view/id/(?P<course_id>\d+))'
    assert ied.VALID_URL == LinuxAcademyIE._VALID_URL
    assert ied._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ied._ORIGIN_URL == 'https://linuxacademy.com'
    assert ied._CLIENT_

# Generated at 2022-06-26 12:23:21.539817
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url='https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    lenacademy_ie=LinuxAcademyIE()
    # make sure it's runnable
    lenacademy_ie.extract(url)
test_LinuxAcademyIE()

# Generated at 2022-06-26 12:23:22.514087
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print(LinuxAcademyIE)

# Generated at 2022-06-26 12:23:29.512501
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    for name, url in [
        ('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675', '7971-2'),
        ('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2', None),
        ('https://linuxacademy.com/cp/modules/view/id/154', '154'),
    ]:
        ie = LinuxAcademyIE(name, url)
        assert ie.name == name
        assert ie.url == url

# Generated at 2022-06-26 12:23:40.343239
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert(ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    ''')

# Generated at 2022-06-26 12:23:42.707394
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE('test')
    assert obj.IE_NAME == 'LinuxAcademy'


if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-26 12:24:26.790643
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert instance._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert instance._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert instance._NETRC_MACHINE == 'linuxacademy'
    assert instance._ORIGIN_URL == 'https://linuxacademy.com'
    assert instance._TESTS[0]['info_dict']['duration'] == 304
    assert instance._TESTS[1]['only_matching'] == True
    assert instance._TESTS[2]['playlist_count'] == 41

# Generated at 2022-06-26 12:24:27.964482
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert isinstance(LinuxAcademyIE, type)

# Generated at 2022-06-26 12:24:30.422655
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test is unable to login since no environment variable is defined
    try:
        LinuxAcademyIE.test()
    except ExtractorError as e:
        if str(e) == 'Linux Academy account credentials missing':
            pass
        else:
            raise e

# Generated at 2022-06-26 12:24:41.246335
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    k = LinuxAcademyIE()
    assert k.IE_NAME == 'linuxacademy'
    assert k.VERSION == '1.0'
    assert k._VALID_URL == r'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert k._NETRC_MACHINE == 'linuxacademy'
    assert k._ORIGIN_URL == 'https://linuxacademy.com'
    assert k._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'

# Generated at 2022-06-26 12:24:42.881235
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxAcademyIE = LinuxAcademyIE() # testing the constructor of the class LinuxAcademyIE

# Generated at 2022-06-26 12:24:47.150783
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert obj._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert obj._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-26 12:24:56.277288
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxome = LinuxAcademyIE()
    assert linuxome._NETRC_MACHINE == 'linuxacademy'
    assert linuxome._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert linuxome._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert linuxome._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-26 12:25:01.150324
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_cases = [
        'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
        'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2',
        'https://linuxacademy.com/cp/modules/view/id/154',
    ]
    for url in test_cases:
        LinuxAcademyIE(url)

# Generated at 2022-06-26 12:25:01.908313
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_object(LinuxAcademyIE())

# Generated at 2022-06-26 12:25:09.509842
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    args = {
        'url': 'https://linuxacademy.com',
        'uid': '2222222',
        'playlist_mincount': 2,
    }
    linuxacademy_ie = LinuxAcademyIE(**args)
    assert linuxacademy_ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-26 12:26:54.982905
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info_extractor = LinuxAcademyIE(None)
    assert info_extractor.player_params_url == 'https://linuxacademy.com/player'
    assert info_extractor.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-26 12:26:56.125251
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-26 12:26:57.156875
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
    except ExtractorError:
        pass

# Generated at 2022-06-26 12:26:57.880120
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('LinuxAcademy')


# Generated at 2022-06-26 12:27:00.934796
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_class = LinuxAcademyIE("LinuxAcademyIE", {})
    assert test_class._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert test_class._ORIGIN_URL == 'https://linuxacademy.com'
    assert test_class._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert test_class._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-26 12:27:02.486817
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxAcademyIE = LinuxAcademyIE()
    print (linuxAcademyIE)

# Generated at 2022-06-26 12:27:04.783731
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert obj._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'

# Generated at 2022-06-26 12:27:12.903574
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(None)
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-26 12:27:14.427211
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE.ie_key()
    assert ie != None, 'LinuxAcademyIE is not initialized'

# Generated at 2022-06-26 12:27:15.379696
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    print(ie._AUTHORIZE_URL)