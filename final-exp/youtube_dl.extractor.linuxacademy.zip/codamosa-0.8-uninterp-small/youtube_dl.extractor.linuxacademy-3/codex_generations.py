

# Generated at 2022-06-26 12:21:19.003355
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test for _real_initialize() and function _login()
    linux_academy_i_e = LinuxAcademyIE()


# Generated at 2022-06-26 12:21:20.503173
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_case_0()

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-26 12:21:21.435127
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass


# Generated at 2022-06-26 12:21:24.724883
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()
    assert isinstance(linux_academy_i_e, LinuxAcademyIE)

# Generated at 2022-06-26 12:21:35.406628
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_1 = LinuxAcademyIE()
    assert linux_academy_i_e_1._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|modules/view/id/(?P<course_id>\\d+))'
    assert linux_academy_i_e_1._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert linux_academy_i_e_1._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-26 12:21:45.992692
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_ie = LinuxAcademyIE()
    assert linux_academy_ie.ie_key() == 'LinuxAcademy'
    assert linux_academy_ie.ie_key() == 'LinuxAcademy'
    assert linux_academy_ie.ie_key() == 'LinuxAcademy'
    assert linux_academy_ie.ie_key() == 'LinuxAcademy'
    assert linux_academy_ie.ie_key() == 'LinuxAcademy'
    assert linux_academy_ie.ie_key() == 'LinuxAcademy'
    assert linux_academy_ie.ie_key() == 'LinuxAcademy'
    assert linux_academy_ie.ie_key() == 'LinuxAcademy'
    assert linux_academy

# Generated at 2022-06-26 12:21:47.199402
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()

# Generated at 2022-06-26 12:21:57.149817
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_0 = LinuxAcademyIE()
    assert(linux_academy_i_e_0._TEST == 'test_case_0')
    linux_academy_i_e_0._TEST = 'test_case_1'
    assert(linux_academy_i_e_0._TEST == 'test_case_1')
    linux_academy_i_e_0._TEST = 'test_case_2'
    assert(linux_academy_i_e_0._TEST == 'test_case_2')
    linux_academy_i_e_0._TEST = linux_academy_i_e_0._TEST

# Generated at 2022-06-26 12:21:57.903728
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-26 12:21:58.931509
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass


# Generated at 2022-06-26 12:22:17.177764
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:22:19.499119
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(LinuxAcademyIE.ie_key(), LinuxAcademyIE._VALID_URL, {}, {})
    assert True

# Generated at 2022-06-26 12:22:21.171437
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:22:30.453216
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_dict1 = {
        'client_id': 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx',
        'response_type': 'token id_token',
        'response_mode': 'web_message',
        'redirect_uri': 'https://linuxacademy.com',
        'scope': 'openid email user_impersonation profile',
        'audience': 'https://linuxacademy.com',
        'state': 'PafNlRNbAaJsy3qQZsOeOzC1kaE7YFPm',
        'nonce': 'mQ2o7KjBvZMVw1rpUTZgB7ahXGv8HWn4',
    }
    assert test_dict1

# Generated at 2022-06-26 12:22:31.715120
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instream = LinuxAcademyIE()
    assert instream


# Generated at 2022-06-26 12:22:32.712862
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()


# Generated at 2022-06-26 12:22:33.282117
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:22:36.861523
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()._real_extract('https://linuxacademy.com/cp/modules/view/id/154')
    assert obj['id'] == '154'
    assert obj['title'] == 'AWS Certified Cloud Practitioner'
    assert obj['duration'] == 28835

# Generated at 2022-06-26 12:22:46.774137
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert(ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx')
    assert(ie._NETRC_MACHINE == 'linuxacademy')
    assert(ie._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)')
    assert(ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize')
    assert(ie._ORIGIN_URL == 'https://linuxacademy.com')

# Generated at 2022-06-26 12:22:47.983587
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert isinstance(LinuxAcademyIE(), LinuxAcademyIE)

# Generated at 2022-06-26 12:23:36.101364
# Unit test for constructor of class LinuxAcademyIE

# Generated at 2022-06-26 12:23:38.249725
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE(None)  # pylint: disable=unused-variable
    except ValueError:
        pass

# Generated at 2022-06-26 12:23:39.410173
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None, None, None)


# Generated at 2022-06-26 12:23:40.141333
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-26 12:23:46.478010
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-26 12:23:48.696332
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
    except Exception:
        assert False, 'Unable to construct class LinuxAcademyIE'

# Generated at 2022-06-26 12:24:00.553034
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test constructor
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-26 12:24:04.863802
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    for url in [r'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2',
                r'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2',
                r'https://linuxacademy.com/cp/modules/view/id/154']:
        LinuxAcademyIE.extract(url)

# Generated at 2022-06-26 12:24:09.547634
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Unit test for the LinuxAcademyIE constructor
    """
    ida = LinuxAcademyIE()
    assert ida._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ida._ORIGIN_URL == 'https://linuxacademy.com'
    assert ida._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ida._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-26 12:24:11.936351
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(1, 'http://linuxacademy.com/example')
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.name == 'LinuxAcademy'



# Generated at 2022-06-26 12:25:54.973622
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    login_info = lambda: [
        {'login': 'user', 'password': 'pwd'},
        {'login': 'user1', 'password': 'pwd1'},
        {'login': 'user2', 'password': 'pwd2'}
    ]
    ies = LinuxAcademyIE()
    ies.initialize()
    assert ies._login_info == login_info

# Generated at 2022-06-26 12:25:56.449796
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    try:
        ie._login()
        assert True
    except ExtractorError:
        assert False

# Generated at 2022-06-26 12:25:59.696406
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    x = LinuxAcademyIE()
    assert x._AGENT_NAME == 'Mozilla/5.0 (X11; Linux x86_64; rv:10.0) Gecko/20100101 Firefox/10.0 (Chrome)'
    assert x._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-26 12:26:05.229649
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.__class__.__name__ == LinuxAcademyIE.__name__
    assert ie.IE_NAME == LinuxAcademyIE.IE_NAME
    assert ie._VALID_URL == LinuxAcademyIE._VALID_URL
    assert ie._NETRC_MACHINE == LinuxAcademyIE._NETRC_MACHINE
    assert ie._AUTHORIZE_URL == LinuxAcademyIE._AUTHORIZE_URL
    assert ie._ORIGIN_URL == LinuxAcademyIE._ORIGIN_URL
    assert hasattr(ie, '_login') == hasattr(LinuxAcademyIE, '_login')
    assert ie._CLIENT_ID == LinuxAcademyIE._CLIENT_ID
    assert ie._download_webpage == LinuxAcad

# Generated at 2022-06-26 12:26:06.336833
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:26:15.344103
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import os

    current_dir = os.path.dirname(os.path.abspath(__file__))
    sample_file = os.path.join(current_dir, 'test_data', 'linuxacademy.txt')
    linuxacademy_text = open(sample_file).read()
    linuxacademy_ie = LinuxAcademyIE()

# Generated at 2022-06-26 12:26:16.163235
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()



# Generated at 2022-06-26 12:26:22.789364
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_cases = [
        ('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2',
         'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'),
        ('https://linuxacademy.com/cp/modules/view/id/154',
         'https://linuxacademy.com/cp/modules/view/id/154')
    ]
    for url, expected in test_cases:
        assert expected == LinuxAcademyIE._VALID_URL % url

# Generated at 2022-06-26 12:26:27.176544
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-26 12:26:29.468108
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        init = LinuxAcademyIE()._real_initialize
        authentication_failed = False
        try:
            init()
        except ExtractorError:
            authentication_failed = True
        assert authentication_failed
    except NameError:
        pass

# Generated at 2022-06-26 12:30:29.572087
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE();
    print(ie.extract(
        'https://linuxacademy.com/cp/modules/view/id/154'
    ))

# Generated at 2022-06-26 12:30:35.969694
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert obj._VALID_URL == '^(?x)https?://(?:www\\.)?linuxacademy\\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|modules/view/id/(?P<course_id>\\d+))$'

# Generated at 2022-06-26 12:30:38.690735
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print ("\nTesting LinuxAcademyIE of constructor\n")
    # create an object of the class to be tested
    LinuxAcademy_object = LinuxAcademyIE()
    # if the object is not created properly, then an assertion error
    assert LinuxAcademy_object


# Generated at 2022-06-26 12:30:39.762807
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert hasattr(ie, 'login')

# Generated at 2022-06-26 12:30:46.541956
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    account_for_test = {
        'username': 'linuxacademy-test',
        'password': 'osg3qw3C'
    }
    url_for_test = 'https://linuxacademy.com/cp/modules/view/id/154'
    ie = LinuxAcademyIE()
    # login
    try:
        ie._login_info = account_for_test
        ie._login()
    except Exception as e:
        print('Error:', e)
    # extract
    try:
        ie.extract(url_for_test)
    except Exception as e:
        print('Error:', e)

# Generated at 2022-06-26 12:30:48.952896
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    o = LinuxAcademyIE()
    assert o.__class__.__name__ == "LinuxAcademyIE"
    assert o.IE_NAME == "linuxacademy"
