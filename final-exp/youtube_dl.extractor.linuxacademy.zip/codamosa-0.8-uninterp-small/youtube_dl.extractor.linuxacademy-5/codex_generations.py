

# Generated at 2022-06-26 12:21:19.152437
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-26 12:21:25.712607
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():

    linux_academy_i_e = LinuxAcademyIE()

    module_0 = linux_academy_i_e.module_0
    assert module_0 == "linux_academy"
    module_1 = linux_academy_i_e.module_1
    assert module_1 == "linuxacademy.com"
    _ALLOW_URL_PARAMETERS = linux_academy_i_e._ALLOW_URL_PARAMETERS
    assert _ALLOW_URL_PARAMETERS == 'Same as err404'
    _VALID_URL = linux_academy_i_e._VALID_URL
    assert _VALID_URL == "https://(?:www\.)?linuxacademy\.com/cp/.*"
    _NETRC_MACHINE = linux_

# Generated at 2022-06-26 12:21:28.406383
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Should fail without arguments
    try:
        print(LinuxAcademyIE())
    except TypeError:
        print('No argument')


# Generated at 2022-06-26 12:21:31.250751
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # TODO: write unit test for LinuxAcademyIE
    return False


if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-26 12:21:36.019306
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE._VALID_URL
    assert LinuxAcademyIE._TESTS
    assert LinuxAcademyIE._AUTHORIZE_URL
    assert LinuxAcademyIE._ORIGIN_URL
    assert LinuxAcademyIE._CLIENT_ID
    assert LinuxAcademyIE._NETRC_MACHINE

# Generated at 2022-06-26 12:21:41.709018
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_0 = LinuxAcademyIE()
    # assert_equal below is used for unit test, please use it as the example below
    # assert_equal(true, linux_academy_i_e_0._login())

if __name__ == '__main__' or __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-26 12:21:44.907837
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        test_case_0()
    except (NotImplementedError, AttributeError, KeyError, ValueError, TypeError, Exception):
        raise


if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-26 12:21:47.240348
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert(
        LinuxAcademyIE.__doc__ == "Information extractor for linuxacademy.com courses\n    "
    )



# Generated at 2022-06-26 12:21:55.381174
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # netrc_machine = 'linuxacademy'
    # client_id = 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    # origin_url = 'https://linuxacademy.com'
    # authorize_url = 'https://login.linuxacademy.com/authorize'
    # # assert_raises:
    # #     assert_raises(AssertionError, assert_raises, ...)
    # #     assert_raises(AssertionError, assert_raises, ...)
    # linux_academy_i_e = LinuxAcademyIE()
    pass

# Generated at 2022-06-26 12:21:57.935827
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 12:22:19.676786
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    has_constructor = hasattr(LinuxAcademyIE, '_call_api')
    if has_constructor:
        print("'_call_api' callable found in constructor of LinuxAcademyIE class.")
    else:
        print("'_call_api' not found in constructor of LinuxAcademyIE class.")

# Generated at 2022-06-26 12:22:20.233670
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()



# Generated at 2022-06-26 12:22:22.732889
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    This test verifies that LinuxAcademyIE can be instantiated,
    and that the constructor does not throw an exception.
    """
    le = LinuxAcademyIE()

# Generated at 2022-06-26 12:22:23.661777
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:22:28.459825
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    obj = LinuxAcademyIE(url)
    assert obj.url == url
    assert obj.course_id == '154'
    assert obj.chapter_id is None
    assert obj.lecture_id is None
    assert obj.name == 'LinuxAcademy'
    assert obj.title is None
    assert obj.description is None
    assert obj.duration is None
    assert len(obj.formats) == 0
    assert obj.url == url

# Generated at 2022-06-26 12:22:33.695832
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademy_ie = LinuxAcademyIE()
    assert linuxacademy_ie.IE_DESC == 'Linux Academy'
    assert linuxacademy_ie.IE_NAME == 'linuxacademy'
    assert linuxacademy_ie.ie_key() == 'LinuxAcademy'
    assert linuxacademy_ie.js_to_json() == js_to_json


# Generated at 2022-06-26 12:22:40.833284
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    config = {
        'username': 'testuser',
        'password': 'testpass',
    }
    linuxacademy = LinuxAcademyIE(config=config)
    assert linuxacademy._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert linuxacademy._ORIGIN_URL == 'https://linuxacademy.com'
    assert linuxacademy._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert linuxacademy._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-26 12:22:44.681205
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    ie.extract('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')

# Generated at 2022-06-26 12:22:46.737777
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    infoExtractor = LinuxAcademyIE()
    assert infoExtractor.IE_NAME == 'linuxacademy'


# Generated at 2022-06-26 12:22:47.940401
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-26 12:23:37.049748
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    if len(LinuxAcademyIE._TESTS)<1:
        return

    import os
    import netrc
    LinuxAcademyIE._NETRC_MACHINE='linuxacademy'
    netrc_path=os.path.expanduser('~/.netrc')
    info = netrc.netrc(netrc_path).authenticators(LinuxAcademyIE._NETRC_MACHINE)
    if info is None:
        print('LinuxAcademy test: Skipped as no credentials found')
        return
    login_info=info[0:2]

    ie=LinuxAcademyIE()
    ie.add_default_headers({'Origin': ie._ORIGIN_URL})
    ie._login(*login_info)

# Generated at 2022-06-26 12:23:38.043954
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
   LinuxAcademyIE('', '')

# Generated at 2022-06-26 12:23:45.289509
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_cases = [
        { "source_url": "https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675", "expected_result": "7971-2", "title": "What Is Data Science" },
        { "source_url": "https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2", "expected_result": "1498-2", "title": "Lecture: Understanding the Cloud" },
        { "source_url": "https://linuxacademy.com/cp/modules/view/id/154", "expected_result": "154", "title": "AWS Certified Cloud Practitioner" }
    ]
    for test_case in test_cases:
        la_ie = LinuxAcad

# Generated at 2022-06-26 12:23:48.370871
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-26 12:23:51.040773
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Note: it is not possible to test username/password login
    assert LinuxAcademyIE._real_initialize();


# Generated at 2022-06-26 12:24:02.115030
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_cases = [
        {
            'input': 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
            'name': '7971-2',
            'ext': 'mp4'
        },
        {
            'input': 'https://linuxacademy.com/cp/modules/view/id/154',
            'name': '154',
            'ext': 'mp4'
        }
    ]
    for test_case in test_cases:
        test_case['input'] = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
        win = LinuxAcademyIE()

# Generated at 2022-06-26 12:24:02.987727
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE is not None

test_LinuxAcademyIE()


# Generated at 2022-06-26 12:24:04.553491
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    my_ia = LinuxAcademyIE()
    assert my_ia._CLIENT_ID is not None

# Generated at 2022-06-26 12:24:05.365593
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:24:06.144064
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()


# Generated at 2022-06-26 12:25:50.957351
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from ..test.test_download import TestDownload
    assert LinuxAcademyIE is not None
    instance = LinuxAcademyIE()
    assert instance is not None
    assert isinstance(instance, LinuxAcademyIE)

# Generated at 2022-06-26 12:25:51.820104
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()

# Generated at 2022-06-26 12:25:57.339327
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-26 12:26:03.649583
# Unit test for constructor of class LinuxAcademyIE

# Generated at 2022-06-26 12:26:08.096442
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE('LinuxAcademy', False)
    assert ie._AUTHORIZE_URL, "Authorize URL is not set"
    assert ie._ORIGIN_URL, "Origin URL is not set"
    assert ie._CLIENT_ID, "Client ID is not set"
    assert ie._NETRC_MACHINE, "Netrc machine is not set"

# Generated at 2022-06-26 12:26:11.400516
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    '''
    This test is only for the __init__ method
    '''
    ie = LinuxAcademyIE(None)
    # Testing if the __init__ method is working
    # assert (ie.test() == "test")
    pass

# Generated at 2022-06-26 12:26:12.335603
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE() is not None

# Generated at 2022-06-26 12:26:20.551090
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
   ie = LinuxAcademyIE()
   assert ie.extractor_key == 'linuxacademy'
   assert ie.IE_NAME == 'linuxacademy'
   assert ie.suitable(None) == False
   assert ie.suitable('') == False
   assert ie.suitable(LinuxAcademyIE._VALID_URL) == True
   assert ie.suitable('https://www.linuxacademy.com') == False
   assert ie.suitable('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675') == True
   assert ie.suitable('https://linuxacademy.com/cp/modules/view/id/154') == True

# Generated at 2022-06-26 12:26:27.877375
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Example of unit test
    return
    assert True


if __name__ == '__main__':
    import sys
    import os
    import unittest


    class TestLinuxAcademyIE(unittest.TestCase):
        """Unit test for LinuxAcademyIE class."""
        def setUp(self):
            """Set up test environment."""
            self._ie = LinuxAcademyIE()

        def test_class_attributes(self):
            """Test class attributes."""
            self.assertTrue(hasattr(self._ie, '_VALID_URL'))
            self.assertTrue(hasattr(self._ie, '_NETRC_MACHINE'))
            self.assertTrue(hasattr(self._ie, '_TESTS'))

# Generated at 2022-06-26 12:26:34.592255
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = "https://login.linuxacademy.com/authorize?client_id=KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx&response_type=token%20id_token&response_mode=web_message&redirect_uri=https%3A%2F%2Flinuxacademy.com&scope=openid%20email%20user_impersonation%20profile&audience=https%3A%2F%2Flinuxacademy.com&state=VxIo79gHV7Zhq3e3XBMpAjJyFV7Bzt2w&nonce=Rl2QDAJY4a4lFbeX9Dnf5ku5GW5SJ55d"  # pylint: disable

# Generated at 2022-06-26 12:30:35.301076
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    _LinuxAcademyIE = LinuxAcademyIE()

    # Test for module variable assignments
    assert _LinuxAcademyIE._VALID_URL == (
        r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    )
    # require linuxacademy account credentials
    assert _LinuxAcademyIE.IE_NAME == 'linuxacademy'
    assert _LinuxAcademyIE._NETRC_MACHINE == 'linuxacademy'
    assert _LinuxAcademy

# Generated at 2022-06-26 12:30:42.067236
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademyie = LinuxAcademyIE()
    assert linuxacademyie._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert linuxacademyie._TESTS[0]['url'] == 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    assert linuxacademyie._TESTS[0]['info_dict']['id'] == '7971-2'
    assert linuxacademyie._TESTS[0]['info_dict']['title'] == 'What Is Data Science'


# Generated at 2022-06-26 12:30:43.558540
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    if not isinstance(LinuxAcademyIE, object):
        return True
    return False

# Generated at 2022-06-26 12:30:52.024222
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'

    ie_info = ie.get_info(
        url='https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    )
    assert ie_info['id'] == '1498-2'
    assert ie_info['ext'] == 'mp4'
    assert ie_info['title'] == 'Hello World'
    assert ie_info['description'] == 'md5:7f9b4c4d4cb55a1e75c7a6e209ee27a8'
    assert ie_info['timestamp'] == 1607387464
    assert ie_info['upload_date'] == '20201208'
    assert ie_info['duration'] == 242

# Generated at 2022-06-26 12:30:52.742738
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()