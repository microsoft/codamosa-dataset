

# Generated at 2022-06-26 12:21:18.354153
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    object = LinuxAcademyIE()
    assert isinstance(object, LinuxAcademyIE)


if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-26 12:21:19.635079
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_0 = LinuxAcademyIE()


# Generated at 2022-06-26 12:21:21.445334
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print('Testing constructor')
    linux_academy_i_e_0 = LinuxAcademyIE()
    pass


# Generated at 2022-06-26 12:21:32.998360
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()
    assert linux_academy_i_e._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-26 12:21:43.573750
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # get an instance of LinuxAcademyIE
    linux_academy_i_e = LinuxAcademyIE()
    try:
        # check if it is an instance of InfoExtractor
        assert isinstance(linux_academy_i_e, InfoExtractor)
    except AssertionError:
        raise
    try:
        # check if it has _VALID_URL attribute
        assert hasattr(LinuxAcademyIE, '_VALID_URL')
    except AssertionError:
        raise
    try:
        # check if it has _TESTS attribute
        assert hasattr(LinuxAcademyIE, '_TESTS')
    except AssertionError:
        raise

# Generated at 2022-06-26 12:21:50.618740
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_0 = LinuxAcademyIE()
    linux_academy_i_e_1 = LinuxAcademyIE()
    linux_academy_i_e_2 = LinuxAcademyIE()
    linux_academy_i_e_3 = LinuxAcademyIE()
    linux_academy_i_e_4 = LinuxAcademyIE()
    linux_academy_i_e_5 = LinuxAcademyIE()
    linux_academy_i_e_6 = LinuxAcademyIE()
    linux_academy_i_e_7 = LinuxAcademyIE()

# Generated at 2022-06-26 12:21:58.181394
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test = ((LinuxAcademyIE.ie_key(), 'linuxacademy'),)
    try:
        for case in test:
            if case[0] == LinuxAcademyIE.ie_key():
                assert case[1] == LinuxAcademyIE.ie_key()
            else:
                assert False
    except AssertionError:
        raise AssertionError("Test LinuxAcademyIE was fail.")

test_case_0()
test_LinuxAcademyIE()


# Generated at 2022-06-26 12:22:01.650106
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()

if __name__ == '__main__':
    test_case_0()
    test_LinuxAcademyIE()

# Generated at 2022-06-26 12:22:09.541805
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print("Begin of UnitTest for constructor of class LinuxAcademyIE")
    unit_test_case = unittest.TestCase()
    linux_academy_i_e = LinuxAcademyIE()
    unit_test_case.assertEqual(linux_academy_i_e._VALID_URL, '^(?x)\n                    https?://\n                        (?:www\\.)?linuxacademy\\.com/cp/\n                        (?:(courses/lesson/course/([0-9]+)/lesson/([0-9]+)|modules/view/id/([0-9]+)))')
    linux_academy_i_e = LinuxAcademyIE(linux_academy_i_e.ie_key())

# Generated at 2022-06-26 12:22:21.077361
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_0 = LinuxAcademyIE()
    assert linux_academy_i_e_0._NETRC_MACHINE == 'linuxacademy'
    assert linux_academy_i_e_0._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert linux_academy_i_e_0._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-26 12:22:59.314381
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE(): 
    linux_academy_i_e_0 = LinuxAcademyIE()


# Generated at 2022-06-26 12:23:01.418386
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_0 = LinuxAcademyIE()

# Generated at 2022-06-26 12:23:03.745374
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()
    linux_academy_i_e.login()

# Generated at 2022-06-26 12:23:07.159467
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    l_inux_academy_i_e = LinuxAcademyIE()
    if(l_inux_academy_i_e is None):
        raise Exception("Failed to create object of class LinuxAcademyIE")


# Generated at 2022-06-26 12:23:08.111985
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_0 = LinuxAcademyIE()

# Generated at 2022-06-26 12:23:09.272884
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()

# Generated at 2022-06-26 12:23:09.923676
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass


# Generated at 2022-06-26 12:23:11.537638
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    _, url = test_case_0()
    assert url == 'https://login.linuxacademy.com/login/callback'

# Generated at 2022-06-26 12:23:12.562034
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()

# Generated at 2022-06-26 12:23:14.206912
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
   linux_academy_i_e = LinuxAcademyIE()


# Generated at 2022-06-26 12:23:47.713397
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie

# Generated at 2022-06-26 12:23:49.763358
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info = LinuxAcademyIE()
    assert isinstance(info, LinuxAcademyIE)

# Generated at 2022-06-26 12:23:51.494022
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
  instance = LinuxAcademyIE()
  print(instance)

# Generated at 2022-06-26 12:23:54.796709
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Unit test for constructor of class LinuxAcademyIE
    """
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)

# Generated at 2022-06-26 12:23:59.168557
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Test for LinuxAcademyIE.
    """
    #TODO
    from .test_utils import assertContains
    from .test_utils import assertEquals
    from .test_utils import assertRegex
    from .test_utils import assertStartsWith

# Generated at 2022-06-26 12:23:59.815899
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-26 12:24:01.475195
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'


# Generated at 2022-06-26 12:24:02.996397
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademy_ie = LinuxAcademyIE()
    assert linuxacademy_ie is not None;

# Generated at 2022-06-26 12:24:05.490567
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
    except Exception:
        import sys
        import traceback
        info = sys.exc_info()
        print(info[1])
        traceback.print_tb(info[2])
        print('')


# Generated at 2022-06-26 12:24:09.565905
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE), 'Is not instance of LinuxAcademyIE'
    assert ie.IE_NAME == 'linuxacademy', 'IE_NAME is not a linuxacademy'
    assert ie.get_username() is None, 'get_username returns a wrong value'
    assert ie.get_password() is None, 'get_password returns a wrong value'

# Generated at 2022-06-26 12:25:46.360954
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:25:50.080189
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    extractor = LinuxAcademyIE()
    assert extractor._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'

# Generated at 2022-06-26 12:25:58.875429
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test = LinuxAcademyIE()
    assert test.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-26 12:25:59.419128
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print(LinuxAcademyIE())

# Generated at 2022-06-26 12:25:59.886154
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-26 12:26:04.307238
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Constructor raises an exception when username or password is missing
    try:
        LinuxAcademyIE()
        raise AssertionError("Incorrect return value for missing credentials")
    except ExtractorError as exception:
        assert "Credentials missing" in str(exception)

    # Constructor does not raise an exception when username and password are provided
    LinuxAcademyIE(username='test', password='test')

# Generated at 2022-06-26 12:26:10.660478
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert hasattr(ie, "ie_key"), type(ie).__name__ + " has no ie_key"
    assert hasattr(ie, "_VALID_URL"), type(ie).__name__ + " has no _VALID_URL"
    assert hasattr(ie, "_login"), type(ie).__name__ + " has no _login"
    assert hasattr(ie, "_real_extract"), type(ie).__name__ + " has no _real_extract"


# Generated at 2022-06-26 12:26:12.409172
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info_extractor = LinuxAcademyIE()
    assert 'LinuxAcademyIE' in repr(info_extractor)

# Generated at 2022-06-26 12:26:20.216306
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Unit test for constructor of class LinuxAcademyIE"""

    # Test with a valid URL
    test_url = 'https://linuxacademy.com/cp/modules/view/id/154'
    test_linuxacademyie = LinuxAcademyIE(test_url)

    # Check if the URL has been properly normalized
    assert test_linuxacademyie.url == 'https://linuxacademy.com/cp/modules/view/id/154'

    # Test with a not valid URL
    test_invalid_url = 'https://linuxacademy.com/cp/'
    with pytest.raises(RegexNotFoundError):
        LinuxAcademyIE(test_invalid_url)

# Generated at 2022-06-26 12:26:22.437807
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_linuxacademy_com_authentication import _login_extractor
    le = _login_extractor(LinuxAcademyIE.ie_key())
    info = le.extract('https://linuxacademy.com/cp/modules/view/id/154')
    assert info['id'] == '154'
    assert info['title'] == 'AWS Certified Cloud Practitioner'


# Generated at 2022-06-26 12:30:17.935511
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxAcademy = LinuxAcademyIE()
    m = re.match(LinuxAcademyIE._VALID_URL, 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    print(m.group('chapter_id'))
    print(m.group('lesson_id'))
    print(m.group('course_id'))
    print(m.groups())

# test_LinuxAcademyIE()

# Generated at 2022-06-26 12:30:19.516650
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.login == ie._login
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-26 12:30:21.099285
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = ie.get_info_extractor('LinuxAcademy')('LinuxAcademy')
    assert instance

# Generated at 2022-06-26 12:30:22.386162
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test = LinuxAcademyIE()
    assert isinstance(test, (LinuxAcademyIE, InfoExtractor))

# Generated at 2022-06-26 12:30:24.011469
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # init LinuxAcademyIE
    linuxacademy_ie = LinuxAcademyIE()
    assert linuxacademy_ie

# Generated at 2022-06-26 12:30:24.713884
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

# Generated at 2022-06-26 12:30:28.762499
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_user = 'TEST_USER'
    test_pass = 'TEST_PASS'
    test_clid = 'TEST_CLID'
    test_origin = 'TEST_ORIGIN'
    test_machine = 'TEST_MACHINE'
    test_url = 'TEST_URL'
    test_item = 'TEST_ITEM'

    class MockNetrc(object):
        def authenticators(self, machine):
            if machine == test_machine:
                return (test_user, test_pass)
            return None

    class MockLinuxAcademyIE(LinuxAcademyIE):
        _CLIENT_ID = test_clid
        _ORIGIN_URL = test_origin
        _NETRC_MACHINE = test_machine


# Generated at 2022-06-26 12:30:31.418224
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test creating a instance of LinuxAcademyIE"""
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    ie = LinuxAcademyIE(url)
    assert isinstance(ie, LinuxAcademyIE)
    assert ie.url == url

# Generated at 2022-06-26 12:30:33.414409
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # It will raise error for credentials for account which does not exist.
    with pytest.raises(ExtractorError):
        LinuxAcademyIE()._real_initialize()

# Generated at 2022-06-26 12:30:37.230173
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info_extractor = LinuxAcademyIE()
    assert info_extractor._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''