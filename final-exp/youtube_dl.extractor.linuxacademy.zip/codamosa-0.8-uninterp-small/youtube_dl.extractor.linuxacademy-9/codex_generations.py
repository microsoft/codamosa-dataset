

# Generated at 2022-06-26 12:21:19.089012
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()


# Generated at 2022-06-26 12:21:20.405426
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_0 = LinuxAcademyIE()


# Generated at 2022-06-26 12:21:22.703593
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_0 = LinuxAcademyIE()
                # Expected test return value: linux_academy_i_e_0
                # Expected type: LinuxAcademyIE


# Generated at 2022-06-26 12:21:25.134919
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()


# Generated at 2022-06-26 12:21:30.385229
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.IE_NAME == "LinuxAcademy"
    assert LinuxAcademyIE.IE_DESC == "Linux Academy"
    assert LinuxAcademyIE.VALID_URL == LinuxAcademyIE._VALID_URL
    assert LinuxAcademyIE.TEST == LinuxAcademyIE._TESTS


# Generated at 2022-06-26 12:21:32.621776
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()
    assert linux_academy_i_e is not None


# Generated at 2022-06-26 12:21:34.668108
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test type of '_VALID_URL' attribute
    assert isinstance(LinuxAcademyIE._VALID_URL, str)


# Generated at 2022-06-26 12:21:38.430724
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()
    assert linux_academy_i_e is not None
# Test the case that the chapter_id and course_id are passed in constructor method

# Generated at 2022-06-26 12:21:39.101620
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_case_0()
    test_case_0()

# Generated at 2022-06-26 12:21:47.035283
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # if password isn't available in environment variable,
    # set netrc_machine to None
    netrc_machine = 'linuxacademy' if os.getenv('LINUX_ACADEMY_PASSWORD') else None
    linux_academy_i_e_1 = LinuxAcademyIE(
        username=os.getenv('LINUX_ACADEMY_USERNAME'),
        password=os.getenv('LINUX_ACADEMY_PASSWORD'),
        netrc_machine=netrc_machine
    )

if __name__ == '__main__':
    test_case_0()
    test_LinuxAcademyIE()

# Generated at 2022-06-26 12:22:14.845977
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Unit test doesn't need to work on real websites, so fake the website
    class FakeExtractor(LinuxAcademyIE):
        def _real_extract(self, url):
            return {
                '_type': 'playlist',
                'entries': [],
                'id': '123456',
                'title': 'My Playlist',
                'description': 'This is an example playlist',
                'duration': 3661,
            }
    ie = FakeExtractor('abc', 'abc')
    playlist = ie.extract()
    assert playlist.get('id') == '123456'
    assert playlist.get('title') == 'My Playlist'
    assert playlist.get('description') == 'This is an example playlist'
    assert playlist.get('duration') == 3661

# Generated at 2022-06-26 12:22:15.465427
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-26 12:22:21.821889
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_url = LinuxAcademyIE._VALID_URL
    test_url = LinuxAcademyIE._valid_url(test_url)
    test_url = LinuxAcademyIE._real_extract(test_url)
    test_url = LinuxAcademyIE._real_initialize(test_url)
    test_url = LinuxAcademyIE._login(test_url)

# Generated at 2022-06-26 12:22:28.743104
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    course_id = '7971'
    lecture_id = '2'
    item_id = course_id + '-' + lecture_id
    filename = '7971-2'
    chapter_id, chapter_number = None, None
    chapter = None
    lesson_url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2'
    title = 'What Is Data Science'
    description = '<p>In this lecture, we will discuss data science in general, including an Introduction to Machine Learning, an Introduction to Neural Networks, and an Introduction to Deep Learning.</p>'

# Generated at 2022-06-26 12:22:30.847001
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
    except Exception as e:
        print("Error: " + str(e))


# Generated at 2022-06-26 12:22:39.872249
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # MacOS and GNU/Linux use different versions of shell and curl to read
    # the contents of a netrc file.
    # This test is for Linux.
    # MacOS: Requires shell=bash, curl=7.64.0, netrc==0.10.3
    # Linux: Requires shell=sh, curl=7.58.0, netrc==0.10.3
    from .common import get_testdata_file
    from .test_common import TestBase
    credentials_file = get_testdata_file('netrc', 'linux_academy')
    assert os.path.isfile(credentials_file)
    netrc_file_contents = os.path.join(os.path.dirname(credentials_file), "unix")

# Generated at 2022-06-26 12:22:41.416777
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    try:
        ie._login()
    except ExtractorError:
        pass

# Generated at 2022-06-26 12:22:42.554156
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Creation
    LinuxAcademyIE()

# Generated at 2022-06-26 12:22:46.950013
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import unittest
    import requests


    class LinuxAcademyIETest(unittest.TestCase):
        def setUp(self):
            self.linuxAcademyIE = LinuxAcademyIE(requests)


    unittest.main()

# Generated at 2022-06-26 12:22:52.986957
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    # Test for exception of constructor with invalid url.
    input_urls = ('https://linuxacademy.com/cp/modules/view/id/',
                  'https://linuxacademy.com/cp/courses/lesson')
    for input_url in input_urls:
        ie.assertTrue(ie._VALID_URL)
        try:
            IE_test = LinuxAcademyIE(input_url)
        except Exception as e:
            ie.assertTrue(e)

# Generated at 2022-06-26 12:23:33.824454
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE(None)
    except Exception as e:
        assert False, "ERROR in LinuxAcademyIE.__init__: {}".format(str(e))
    assert True


# Generated at 2022-06-26 12:23:36.053216
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from . import LinuxAcademyIE
    assert LinuxAcademyIE

# Generated at 2022-06-26 12:23:36.616237
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE.ie_key()

# Generated at 2022-06-26 12:23:38.735359
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE._login(LinuxAcademyIE())
    except Exception as e:
        raise("Login failed")

# Generated at 2022-06-26 12:23:41.802241
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-26 12:23:43.190696
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test that the constructor can be used without throwing an exception.
    obj = LinuxAcademyIE()

# Generated at 2022-06-26 12:23:44.448643
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-26 12:23:45.333354
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
	ie = LinuxAcademyIE()


# Generated at 2022-06-26 12:23:56.200915
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Testing Login
    with open('tests/test_data/test_linuxAcademy.json', encoding='utf-8') as f:
        data = json.loads(f.read())
        ie = LinuxAcademyIE()
        ie.initialize()
        ie._login()
        for i, item in enumerate(data):
           # Testing URLs
            res = re.match(ie._VALID_URL, item['url'])
            assert res is not None, 'URL of item no. {} doesn\'t match!'.format(i+1)
            # Testing Manisfests

# Generated at 2022-06-26 12:23:58.045882
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(0)

# Generated at 2022-06-26 12:25:51.330145
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info_extractor = LinuxAcademyIE()
    assert info_extractor._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-26 12:25:52.086093
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:25:54.672582
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._downloader.params['noprogress']
    assert LinuxAcademyIE()._downloader.params['nopart']

# Generated at 2022-06-26 12:26:01.656697
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://www.linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    info = LinuxAcademyIE().extract(url)
    assert info['id'] == '1498-2'
    assert re.compile(r"^(What Is AWS|AWS Cloud Fundamentals)$").match(info['title'])
    assert re.compile(r'^(In this course|This course is a fundamental level)').match(info['description'])
    assert info['duration'] == 304
    assert info['chapter_number'] == 2
    assert re.compile(r'^(Cloud Fundamentals|Introduction to AWS)$').match(info['chapter'])
    assert 'formats' in info
    assert len(info['formats']) > 0
   

# Generated at 2022-06-26 12:26:03.569740
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE(None, None)
    except Exception as e:
        print(e)

# Generated at 2022-06-26 12:26:04.491455
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:26:08.310786
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademyIE = LinuxAcademyIE('LinuxAcademy', {'username': 'fakeemail@fakeemail.com', 'password': 'fakepassword'})
    assert linuxacademyIE.username == 'fakeemail@fakeemail.com'
    assert linuxacademyIE.password == 'fakepassword'

# Generated at 2022-06-26 12:26:09.308462
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._VALID_URL

# Generated at 2022-06-26 12:26:18.013386
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    IE = LinuxAcademyIE()
    assert(IE.params.update({'skip-download': True}))
    assert(IE.params.update({'format': "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best"}))

# Generated at 2022-06-26 12:26:25.689350
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test constructor
    def assertLinuxAcademyIE(url, item_id, username=None, password=None):
        ie = LinuxAcademyIE(url, item_id, username, password)

        assert ie.username == username
        assert ie.password == password
        assert ie.item_id == item_id

    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    assertLinuxAcademyIE(url, '154', 'username', 'password')
    assertLinuxAcademyIE('', '154', 'username', 'password')
    assertLinuxAcademyIE(url, '154')
    assertLinuxAcademyIE(url, '154', None, 'password')
    assertLinuxAcademyIE(url, '154', 'username', None)

# Generated at 2022-06-26 12:30:37.074371
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.suitable('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    assert ie.suitable('https://linuxacademy.com/cp/modules/view/id/154')
    assert not ie.suitable('http://linuxacademy.com/cp/home')
    assert ie.NAME == 'linuxacademy'
    assert ie.IE_NAME == 'linuxacademy:course'

# Generated at 2022-06-26 12:30:38.353082
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert instance._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-26 12:30:39.090710
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:30:44.550551
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_cases = [
        'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
        'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2',
        'https://linuxacademy.com/cp/modules/view/id/154',
    ]
    for test_case in test_cases:
        ie = LinuxAcademyIE()
        check_valid_url(ie.ie_key(), test_case)

# Generated at 2022-06-26 12:30:46.021359
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    loader = LinuxAcademyIE()
    print(loader)

# Generated at 2022-06-26 12:30:54.149990
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert obj
    assert obj._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert obj._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert obj._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'