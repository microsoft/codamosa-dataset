

# Generated at 2022-06-26 12:21:15.765048
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-26 12:21:16.354611
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-26 12:21:19.002971
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.__name__ == 'LinuxAcademyIE'
    assert LinuxAcademyIE.suitable(LinuxAcademyIE._VALID_URL) == True


# Generated at 2022-06-26 12:21:20.118734
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()


# Generated at 2022-06-26 12:21:31.438906
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # LinuxAcademyIE class uses '_download_webpage_handle' method to download the YouTube Playlist page
    # We create a mock object for the same using mock_download_page function of python-youtube-dl.
    mock_object = unittest.mock.Mock()
    mock_object.return_value = """<!DOCTYPE html>
    <html lang="en" dir="ltr" class="client-nojs">
              <head>
              <meta charset="UTF-8"/><title>Linux Academy | AWS, Linux, Azure, DevOps, Open Source &amp; More</title>
              </head>
              <body>
              </body>
              </html>
              """


# Generated at 2022-06-26 12:21:33.671108
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_0 = LinuxAcademyIE()
    assert linux_academy_i_e_0


# Generated at 2022-06-26 12:21:44.230510
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .common import InfoExtractor
    from .common import running_under_teamcity
    import sys
    import unittest

    # Derived from test case 0 from common.py
    class TestLinuxAcademy(unittest.TestCase):
        # Input Values
        _content = None
        _match = None
        _result = None

        def test_constructor(self):
            linux_academy_i_e_0 = LinuxAcademyIE()
            # Ensure that we get back the same object we put in
            self.assertEqual(linux_academy_i_e_0, linux_academy_i_e_0)
            # Ensure that it is an instance of InfoExtractor
            self.assertIsInstance(linux_academy_i_e_0, InfoExtractor)

    # If

# Generated at 2022-06-26 12:21:53.426719
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()
    # create properties
    linux_academy_i_e.username = 'user'
    linux_academy_i_e.password = 'pass'
    linux_academy_i_e.params = 'params'
    linux_academy_i_e.folder = 'folder'
    linux_academy_i_e.http_headers = 'headers'
    linux_academy_i_e.js_to_json = 'js_to_json'
    linux_academy_i_e._json_ld = 'ld'
    linux_academy_i_e.noplaylist = 'playlist'
    linux_academy_i_e._formats = 'formats'
    linux_acad

# Generated at 2022-06-26 12:21:54.943381
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()

# Generated at 2022-06-26 12:22:05.330532
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Define the Linux Academy video id, and the expected video title
    video_id = '7971-2'
    video_title = 'What Is Data Science'
    # Start of test case ================================
    linux_academy_i_e_1 = LinuxAcademyIE()
    # Expected: The url, and the expected video title
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    expected_title = video_title
    linux_academy_i_e_1.urls = [url]
    # Expected: The expected video title
    linux_academy_i_e_1.initialize()

# Generated at 2022-06-26 12:22:23.542730
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademy_ie = LinuxAcademyIE()
    linuxacademy_ie._login()

# Generated at 2022-06-26 12:22:27.746497
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(None)
    ie._login()
    assert(ie)
    ie._real_extract(ie._VALID_URL)
    ie = LinuxAcademyIE(None)
    ie._login()
    assert(ie)
    ie._real_extract('https://linuxacademy.com/cp/modules/view/id/154')

# Generated at 2022-06-26 12:22:30.934399
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == LinuxAcademyIE.ie_key()
    assert ie.NETRC_MACHINE == LinuxAcademyIE._NETRC_MACHINE

# Generated at 2022-06-26 12:22:33.361691
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.__dict__ == test_LinuxAcademyIE.__globals__['LinuxAcademyIE'].__dict__



# Generated at 2022-06-26 12:22:39.832683
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    username = 'username'
    password = 'password'

    d = LinuxAcademyIE(username = username, password = password)
    assert(d._NETRC_MACHINE == 'linuxacademy')
    assert(d._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx')
    assert(d._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize')
    assert(d._ORIGIN_URL == 'https://linuxacademy.com')

# Generated at 2022-06-26 12:22:45.924893
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        instance = LinuxAcademyIE()
        instance.test()
    except NameError as e:
        if 'test_LinuxAcademyIE' in str(e):
            print("NameError: " + str(e) + "\nIncorrect usage of test_LinuxAcademyIE")
        else:
            print("Other error: " + str(e))
    else:
        print("Everything is OK")

# Generated at 2022-06-26 12:22:49.588274
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert(ie._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)')

# Generated at 2022-06-26 12:22:55.651107
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.suitable('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    assert ie.suitable('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    assert ie.suitable('https://linuxacademy.com/cp/modules/view/id/154')
    assert not ie.suitable('https://linuxacademy.com/cp/')
    assert not ie.suitable('https://linuxacademy.com/cp/my-account')

# Generated at 2022-06-26 12:22:57.821010
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # construct a LinuxAcademyIE instance
    ie = LinuxAcademyIE()
    # test if it's an instance of InfoExtractor
    assert isinstance(ie, InfoExtractor)
    # test if true is true
    assert True

# Generated at 2022-06-26 12:23:06.081496
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(None)
    assert ie.params == {
        'skip_download': True,
    }
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-26 12:23:41.494809
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        from .shell import Shell
    except ImportError:
        return

    ie = LinuxAcademyIE()
    _, _, __, ___ = Shell.get_input_args(ie, 'linuxacademy.com/cp/modules/view/id/154')
    ie._login()

# Generated at 2022-06-26 12:23:42.151347
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
  ie = LinuxAcademyIE()

# Generated at 2022-06-26 12:23:44.712311
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(-1)
    assert(ie.params['headers'] == {'Authorization': 'Bearer %(token)s'})

# Generated at 2022-06-26 12:23:55.569981
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info_extractor = LinuxAcademyIE()
    assert (info_extractor.NETRC_MACHINE == 'linuxacademy')
    assert (info_extractor._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx')
    assert (info_extractor._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize')
    assert (info_extractor._ORIGIN_URL == 'https://linuxacademy.com')
    assert (info_extractor._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(\d+)/lesson/(\d+)|modules/view/id/(\d+))')

# Generated at 2022-06-26 12:24:03.380591
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test constructor of class LinuxAcademyIE"""
    # A test case for a normal page.
    page = LinuxAcademyIE('LinuxAcademy', 'LinuxAcademy')
    assert page.IE_NAME == 'LinuxAcademy'
    assert page.IE_DESC == 'LinuxAcademy'
    # A test case for a course.
    page = LinuxAcademyIE('LinuxAcademy-COURSE', 'LinuxAcademy')
    assert page.IE_NAME == 'LinuxAcademy-COURSE'
    assert page.IE_DESC == 'LinuxAcademy'

# Generated at 2022-06-26 12:24:06.527583
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert_raises(AttributeError, lambda: LinuxAcademyIE(username='foo', password='bar'))
    assert_raises(AttributeError, lambda: LinuxAcademyIE(username='foo'))
    assert_raises(AttributeError, lambda: LinuxAcademyIE(password='bar'))

# Generated at 2022-06-26 12:24:11.801385
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.js_to_json is not None
    assert ie._valid_url('https://www.linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-26 12:24:12.495438
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    x = LinuxAcademyIE()

# Generated at 2022-06-26 12:24:14.535720
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    IE_LinuxAcademy = LinuxAcademyIE()
    assert IE_LinuxAcademy.ie_key() == 'linuxacademy'

# Generated at 2022-06-26 12:24:15.532952
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert type(LinuxAcademyIE) == type

# Generated at 2022-06-26 12:25:59.540116
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        ie = LinuxAcademyIE()
        assert isinstance(ie, LinuxAcademyIE)
        assert ie.ie_key() == 'LinuxAcademy'
    except TypeError:
        print("TypeError: Invalid settings. Please update settings.json")

# Generated at 2022-06-26 12:26:01.179398
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test = LinuxAcademyIE()
    assert test

if __name__ == "__main__":
    import sys
    print(test_LinuxAcademyIE()._real_extract(sys.argv[1]))

# Generated at 2022-06-26 12:26:03.744047
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE('LinuxAcademy')
    except Exception as e:
        print(e)
        #assert False

# Generated at 2022-06-26 12:26:05.778536
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info = LinuxAcademyIE('NoSuchIE', '')
    assert info.name == 'LinuxAcademy'
    assert info.IE_NAME == 'LinuxAcademy'

# Generated at 2022-06-26 12:26:11.398948
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    i = LinuxAcademyIE()
    assert i.suitable('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    assert i.suitable('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    assert i.suitable('https://linuxacademy.com/cp/modules/view/id/154')

# Generated at 2022-06-26 12:26:20.215971
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == "LinuxAcademy"
    assert ie.ie_key() == "LinuxAcademy"
    assert ie.IE_DESC == "Linux Academy online courses"
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-26 12:26:21.262923
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()
    # test login
    LinuxAcademyIE._login()

# Generated at 2022-06-26 12:26:21.789576
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-26 12:26:22.640623
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:26:23.342546
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()._login()

# Generated at 2022-06-26 12:30:06.568774
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    class_ = LinuxAcademyIE
    assert hasattr(class_, 'ie_key')
    assert hasattr(class_, '_NETRC_MACHINE')
    assert hasattr(class_, '_VALID_URL')
    assert hasattr(class_, 'IE_NAME')

# Generated at 2022-06-26 12:30:07.946685
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ies = LinuxAcademyIE._build_ie_bool(None)
    assert ies == {"LinuxAcademyIE": True}

# Generated at 2022-06-26 12:30:08.618485
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None)()

# Generated at 2022-06-26 12:30:16.790162
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    username, password = None, None

    import os
    import netrc

    machine = LinuxAcademyIE._NETRC_MACHINE
    netrc_path = os.path.expanduser('~/.netrc')
    login_info = None
    if os.path.isfile(netrc_path):
        try:
            info_dict = netrc.netrc(netrc_path).authenticators(machine)
            if info_dict:
                login_info = info_dict
        except netrc.NetrcParseError as e:
            raise ExtractorError(
                'Parsing .netrc: %s' % compat_str(e), expected=True)
    if login_info:
        username = login_info[0]
        password = login_info[2]

    linux_academy = LinuxAc

# Generated at 2022-06-26 12:30:20.945984
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    course = LinuxAcademyIE()
    course.extract(url)
    assert course.playlist_count == 41
    print("Unit test for class LinuxAcademyIE successful")


if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-26 12:30:26.374262
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == LinuxAcademyIE._VALID_URL
    assert ie._AUTHORIZE_URL == LinuxAcademyIE._AUTHORIZE_URL
    assert ie._ORIGIN_URL == LinuxAcademyIE._ORIGIN_URL
    assert ie._CLIENT_ID == LinuxAcademyIE._CLIENT_ID
    assert ie._NETRC_MACHINE == LinuxAcademyIE._NETRC_MACHINE
    assert ie._TESTS == LinuxAcademyIE._TESTS
    assert ie._login() == None

# Generated at 2022-06-26 12:30:27.539946
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

if __name__ == "__main__":
    test_LinuxAcademyIE()

# Generated at 2022-06-26 12:30:28.789997
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-26 12:30:29.605917
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE('username', 'password')
    except:
        assert(False)

# Generated at 2022-06-26 12:30:30.623237
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'