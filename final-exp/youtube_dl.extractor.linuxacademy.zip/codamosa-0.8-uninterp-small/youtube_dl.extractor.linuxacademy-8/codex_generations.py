

# Generated at 2022-06-26 12:21:17.792866
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        test_case_0()
        unit_test_passed = True
    except:
        unit_test_passed = False
    test_cases_passed = True
    if not unit_test_passed:
        test_cases_passed = False
    assert test_cases_passed == True

# Generated at 2022-06-26 12:21:19.046651
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert test_case_0() == None


# Generated at 2022-06-26 12:21:25.325462
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert hasattr(LinuxAcademyIE(), '_NETRC_MACHINE'), \
        'LinuxAcademyIE is lacking a "_NETRC_MACHINE" attribute'
    assert hasattr(LinuxAcademyIE(), '_VALID_URL'), \
        'LinuxAcademyIE is lacking a "_VALID_URL" attribute'
    assert hasattr(LinuxAcademyIE(), '_TESTS'), \
        'LinuxAcademyIE is lacking a "_TESTS" attribute'

# Generated at 2022-06-26 12:21:29.327384
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test case 0: Run constructor of class LinuxAcademyIE
    linux_academy_i_e_0 = LinuxAcademyIE()
    assert isinstance(linux_academy_i_e_0, LinuxAcademyIE)



# Generated at 2022-06-26 12:21:30.067605
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-26 12:21:31.111097
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_case_0()

# Generated at 2022-06-26 12:21:32.998541
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_1 = LinuxAcademyIE()
    test_case_0()

# Generated at 2022-06-26 12:21:33.945017
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test with real credentials
    test_case_0()

# Generated at 2022-06-26 12:21:35.245778
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()

# Generated at 2022-06-26 12:21:37.883979
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_1 = LinuxAcademyIE()


# Generated at 2022-06-26 12:21:56.675137
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()


# Generated at 2022-06-26 12:21:59.393280
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    result = LinuxAcademyIE()
    assert (result.IE_NAME == 'linuxacademy')
    assert (result.IE_DESC == 'Linux Academy')

# Generated at 2022-06-26 12:22:08.375051
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    inst = LinuxAcademyIE()
    assert inst._NETRC_MACHINE == 'linuxacademy'
    assert inst._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert inst._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert inst._ORIGIN_URL == 'https://linuxacademy.com'
    assert inst._VALID_URL == r'https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'

# Generated at 2022-06-26 12:22:09.674620
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-26 12:22:17.683896
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test course url
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    LinuxAcademyIE(url)
    # Test lesson url
    url = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    LinuxAcademyIE(url)
    print('Successfully passed unit test for LinuxAcademyIE')

if __name__ == '__main__':
    # Run unit test for class LinuxAcademyIE
    test_LinuxAcademyIE()

# Generated at 2022-06-26 12:22:19.676954
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    extractor = LinuxAcademyIE()
    assert extractor.IE_NAME == 'LinuxAcademy'

# Generated at 2022-06-26 12:22:21.715712
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # This function is useful for debugging purposes, hence it is not yet
    # removed from the code.
    from .embed import LinuxAcademyEmbedIE
    constr = LinuxAcademyIE if False else LinuxAcademyEmbedIE
    constr.ie_key()

# Generated at 2022-06-26 12:22:26.077931
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    # Testing that login is required
    assert 'Username and Password required' in instance._login()
    # Testing the return of _real_extract
    assert 'id' in instance._real_extract('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')

# Generated at 2022-06-26 12:22:34.471176
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    testCases = [
        ('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
         '7971-2'),
        ('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2',
         '1498-2'),
        ('https://linuxacademy.com/cp/modules/view/id/154',
         '154'),
    ]
    ie = LinuxAcademyIE()
    for testCase in testCases:
        assert ie.suitable(testCase[0])
        assert ie.get_id(testCase[0]) == testCase[1]

# Generated at 2022-06-26 12:22:35.699495
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert isinstance(LinuxAcademyIE(None), LinuxAcademyIE)

# Generated at 2022-06-26 12:23:16.970017
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_LinuxAcademyIE = LinuxAcademyIE('LinuxAcademyIE')
    assert isinstance(test_LinuxAcademyIE, LinuxAcademyIE)

# Generated at 2022-06-26 12:23:22.550270
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    res = LinuxAcademyIE()._real_extract(url)
    expect_desc = 'In this course, you will learn about the basic fundamentals of cloud computing, how to interact with the AWS Management Console, and how to secure AWS resources.'
    assert res["description"] == expect_desc

# Generated at 2022-06-26 12:23:32.767469
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from os import getenv
    from .common import random_user_agent
    # Test LinuxAcademyIE without login credentials
    ie = LinuxAcademyIE()
    assert ie.username is None and ie.password is None
    assert ie._login_info() == (None, None)
    # Test LinuxAcademyIE with login credentials
    ie = LinuxAcademyIE(info_dict={
        'username': getenv('LA_USERNAME'),
        'password': getenv('LA_PASSWORD'),
    })
    assert ie.username == getenv('LA_USERNAME')
    assert ie.password == getenv('LA_PASSWORD')
    assert ie._login_info() == (getenv('LA_USERNAME'), getenv('LA_PASSWORD'))
    ie._downloader.user_agent = random_user_

# Generated at 2022-06-26 12:23:33.817435
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:23:35.675410
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    o = LinuxAcademyIE()

# Generated at 2022-06-26 12:23:39.036341
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-26 12:23:41.182178
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.constructor() == LinuxAcademyIE # constructor class method
    assert LinuxAcademyIE.ie_key() == 'linuxacademy'

# Generated at 2022-06-26 12:23:42.921121
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_ie = LinuxAcademyIE()
    assert linux_academy_ie.IE_NAME == 'linux_academy'

# Generated at 2022-06-26 12:23:48.862963
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert LinuxAcademyIE._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert LinuxAcademyIE._ORIGIN_URL == 'https://linuxacademy.com'
    assert LinuxAcademyIE._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-26 12:23:52.778647
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxAcademyIE = LinuxAcademyIE()
    assert re.match(linuxAcademyIE._VALID_URL, 'linuxacademy.com')

# Generated at 2022-06-26 12:25:37.222143
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(
        'LinuxAcademy', 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')

    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-26 12:25:41.684893
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Unit test for method _download_webpage_handle()
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    downloader_test_handle = LinuxAcademyIE()
    downloader_test_handle._login()
    webpage, urlh = downloader_test_handle._download_webpage_handle(url, None, 'Downloading authorize page')
    print(webpage)
    print(urlh.geturl())


# Generated at 2022-06-26 12:25:42.552157
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    n = LinuxAcademyIE()

# Generated at 2022-06-26 12:25:43.619990
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    if __name__ == '__main__':
        test_LinuxAcademyIE()

# Generated at 2022-06-26 12:25:50.558971
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    class_ = LinuxAcademyIE

    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    mobj = re.match(class_._VALID_URL, url)
    chapter_id, lecture_id, course_id = mobj.group('chapter_id', 'lesson_id', 'course_id')
    item_id = course_id if course_id else '%s-%s' % (chapter_id, lecture_id)

    webpage = class_._download_webpage(url, item_id)

    # course path
    chapter = None
    chapter_number = None
    chapter_id = None

# Generated at 2022-06-26 12:25:51.764430
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:25:58.732494
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test without login
    loader = LinuxAcademyIE()
    try:
        loader._login()
    except ExtractorError as e:
        assert 'requires Linux Academy account' in str(e)
    else:
        raise AssertionError('Expected an error')

    # Test with login
    loader = LinuxAcademyIE(username='foo', password='bar')
    try:
        loader._login()
    except ExtractorError as e:
        raise AssertionError(str(e))

    # Test many extractors
    loader = LinuxAcademyIE(username='foo', password='bar')
    assert len(loader._ies) > 1

# Generated at 2022-06-26 12:25:59.476843
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:26:00.235453
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE is not None


# Generated at 2022-06-26 12:26:09.159600
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Unit test for constructor of class LinuxAcademyIE
    from .common import InfoExtractor
    from ..utils import parse_duration

    ie = InfoExtractor(LinuxAcademyIE.ie_key())
    assert ie.IE_NAME == 'LinuxAcademy'
    assert ie.IE_DESC == 'Linux Academy'
    assert ie._VALID_URL == LinuxAcademyIE._VALID_URL
    assert ie.get_login_info() == (LinuxAcademyIE.get_login_info())
    mobj = re.match(ie._VALID_URL, 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    assert mobj.group('chapter_id') == '1498'

# Generated at 2022-06-26 12:30:06.710453
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE.suite().run()

# Generated at 2022-06-26 12:30:07.670869
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    l = LinuxAcademyIE()
    assert l is not None

# Generated at 2022-06-26 12:30:08.329382
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()

# Generated at 2022-06-26 12:30:09.026237
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    a = LinuxAcademyIE()

# Generated at 2022-06-26 12:30:10.351420
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info_extractor = LinuxAcademyIE()
    assert info_extractor.IE_NAME == "LinuxAcademy"

# Generated at 2022-06-26 12:30:14.966433
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'


# Generated at 2022-06-26 12:30:16.591258
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Tests for linuxacademy.
    """
    return LinuxAcademyIE()

# Generated at 2022-06-26 12:30:17.810979
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie is not None

# Generated at 2022-06-26 12:30:18.881246
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_item = LinuxAcademyIE()
    print(test_item)

# Generated at 2022-06-26 12:30:19.850846
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

