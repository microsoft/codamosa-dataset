

# Generated at 2022-06-26 12:21:16.169708
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()


# Generated at 2022-06-26 12:21:17.521112
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # __init__() takes no arguments
    test = LinuxAcademyIE()
    assert test.IE_NAME == 'LinuxAcademy'


# Generated at 2022-06-26 12:21:21.062625
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()

    # example of assert (exception handling)
    assert linux_academy_i_e, 'Error in the constructor of the class LinuxAcademyIE'


test_case_0()
test_LinuxAcademyIE()

# Generated at 2022-06-26 12:21:22.504088
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
  if __name__ == "__main__":
    # Run only if invoked directly
    test_case_0()

# Generated at 2022-06-26 12:21:34.215411
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
  file_path_0 = './linuxacademy.py'
  linux_academy_i_e_0 = LinuxAcademyIE(file_path_0)
  login_page_0 = 'https://login.linuxacademy.com/usernamepassword/login'

# Generated at 2022-06-26 12:21:38.341559
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from ytdl.extractor.linuxacademy import LinuxAcademyIE
    linux_academy_i_e = LinuxAcademyIE()
    print(linux_academy_i_e)


# Generated at 2022-06-26 12:21:47.731352
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_1 = LinuxAcademyIE()
    assert linux_academy_i_e_1._NETRC_MACHINE == "linuxacademy"
    assert linux_academy_i_e_1._ORIGIN_URL == "https://linuxacademy.com"
    assert linux_academy_i_e_1._AUTHORIZE_URL == "https://login.linuxacademy.com/authorize"
    assert linux_academy_i_e_1._CLIENT_ID == "KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx"

# Generated at 2022-06-26 12:21:57.979186
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert_raises(TypeError, LinuxAcademyIE, None)
    assert_raises(TypeError, LinuxAcademyIE, 'http://www.linuxacademy.com')
    assert_raises(TypeError, LinuxAcademyIE, 'http://www.linuxacademy.com', {'ie_key': 'LinuxAcademy'})
    assert_raises(TypeError, LinuxAcademyIE, 'http://www.linuxacademy.com', {'ie_key': 'LinuxAcademy'}, 'LinuxAcademy')
    assert_raises(TypeError, LinuxAcademyIE, 'http://www.linuxacademy.com', {'ie_key': 'LinuxAcademy'}, 'LinuxAcademy', 'http://www.linuxacademy.com')

# Generated at 2022-06-26 12:22:07.486679
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()
    pass # test case here
    # Unit test for _real_extract
    assert linux_academy_i_e._real_extract('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')

    # Unit test for _real_extract
    assert linux_academy_i_e._real_extract('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')

    # Unit test for _real_extract
    assert linux_academy_i_e._real_extract('https://linuxacademy.com/cp/modules/view/id/154')



# Generated at 2022-06-26 12:22:08.466904
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()

# Generated at 2022-06-26 12:22:50.703622
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .common import InfoExtractor
    from ..utils import parseDuration
    linux_academy_i_e = LinuxAcademyIE()
    assert linux_academy_i_e._VALID_URL == "https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))", "Error in valid url"
    assert linux_academy_i_e._AUTHORIZE_URL == "https://login.linuxacademy.com/authorize", "Error in authorize url"

# Generated at 2022-06-26 12:22:57.708745
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert isinstance(instance, LinuxAcademyIE)
    assert hasattr(instance, '_VALID_URL')
    assert hasattr(instance, '_TESTS')
    assert hasattr(instance, '_AUTHORIZE_URL')
    assert hasattr(instance, '_ORIGIN_URL')
    assert hasattr(instance, '_CLIENT_ID')
    assert hasattr(instance, '_NETRC_MACHINE')
    assert hasattr(instance, '_real_initialize')
    assert hasattr(instance, '_login')
    assert hasattr(instance, '_real_extract')
    assert hasattr(instance, 'suitable')
    assert hasattr(instance, '_download_webpage')

# Generated at 2022-06-26 12:23:00.867756
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    if __name__ == "__main__":
        # Unit test for constructor of class LinuxAcademyIE
        test_LinuxAcademyIE()

# Generated at 2022-06-26 12:23:09.745074
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'
    assert LinuxAcademyIE.extractor_key() == 'LinuxAcademy'
    assert LinuxAcademyIE.suitable(None) == False
    assert LinuxAcademyIE.suitable('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2') == True
    assert LinuxAcademyIE.normalize_url(
        'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2') == 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'

# Generated at 2022-06-26 12:23:12.009020
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    #
    # Example:
    #
    # linux_academy_i_e_0 = LinuxAcademyIE()
    #
    pass


# Generated at 2022-06-26 12:23:17.777185
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from extractor import Extractor
    from extractor import InfoExtractor
    from utils import *
    import sys
    import os.path as path
    import re
    import compat_urllib_parse
    import json
    import random
    import re
    import compat_b64decode
    import compat_HTTPError
    import compat_str
    import compat_urllib_parse
    import extractor
    import utils
    import urlparse
    import string
    import random
    import re
    import compat_urllib_parse
    import extractor
    import utils
    import urlparse
    import compat_urllib_request
    import compat_b64decode
    import string
    import random
    import json
    import m3u8_native
    import re
    import compat_urllib_parse

# Generated at 2022-06-26 12:23:21.591785
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_legacy_extractor import TestLegacyExtractor
    linux_academy_i_e_0 = LinuxAcademyIE()
    if isinstance(linux_academy_i_e_0, TestLegacyExtractor):
        assert True


# Generated at 2022-06-26 12:23:22.550875
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    windows_i_e = LinuxAcademyIE()

# Generated at 2022-06-26 12:23:23.391489
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_case_0()

# Generated at 2022-06-26 12:23:25.992765
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        test_case_0()
    except ExtractorError as e:
        assert 'Requires Linux Academy account credentials' in e.message

test_LinuxAcademyIE()

# Generated at 2022-06-26 12:24:01.187779
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:24:03.037195
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(LinuxAcademyIE.ie_key())
    assert ie.IE_NAME == 'linuxacademy'

# Generated at 2022-06-26 12:24:04.168179
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert(LinuxAcademyIE is not None)
    return()



# Generated at 2022-06-26 12:24:04.974039
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:24:05.759226
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:24:07.583383
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    This function tests constructor of class LinuxAcademyIE
    """
    try:
        LinuxAcademyIE()
    except ExtractorError:
        pass


# Generated at 2022-06-26 12:24:10.721974
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
#    print('\nTesting constructor of class LinuxAcademyIE\n')
    shouldReturn1 = 'test_LinuxAcademyIE() should return None'
    assert test_LinuxAcademyIE() == None, shouldReturn1

# Generated at 2022-06-26 12:24:12.432136
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    username, password = LinuxAcademyIE._get_login_info()
    assert username is not None and password is not None
    # Test the class constructor
    LinuxAcademyIE()

# Generated at 2022-06-26 12:24:20.251635
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_linuxacademy_course_module import LA_SINGLE_VIDEO_RECORD_TEST

    course_url = 'https://linuxacademy.com' + LA_SINGLE_VIDEO_RECORD_TEST['url']
    la = LinuxAcademyIE()
    mobj = re.match(la._VALID_URL, course_url)
    chapter_id, lecture_id, course_id = mobj.group('chapter_id', 'lesson_id', 'course_id')
    item_id = course_id if course_id else '%s-%s' % (chapter_id, lecture_id)

    la.download(course_url)

    # check video title

# Generated at 2022-06-26 12:24:28.504346
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # test for _VALID_URL
    valid_url = LinuxAcademyIE._VALID_URL
    assert re.match(valid_url, 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    assert re.match(valid_url, 'http://www.linuxacademy.com/cp/modules/view/id/154')
    assert re.match(valid_url, 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    assert not re.match(valid_url, 'https://linuxacademy.com/cp/courses/lesson/course')

# Generated at 2022-06-26 12:26:08.663132
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    module = LinuxAcademyIE(url='https://linuxacademy.com/cp/modules/view/id/154')
    assert module.url == 'https://linuxacademy.com/cp/modules/view/id/154', 'Wrong URL'
    assert module.playlist_count == 41, 'Wrong playlist count'

# Generated at 2022-06-26 12:26:10.406908
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)

# Generated at 2022-06-26 12:26:14.278663
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_common import load_json_tests
    test_cases = load_json_tests('linuxacademy.com', [
        'playlist.json',
        'single_video.json',
    ])
    for test_case in test_cases:
        yield 'test_LinuxAcademy', test_case

# Generated at 2022-06-26 12:26:22.670955
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_ie = LinuxAcademyIE()
    assert test_ie.IE_NAME == 'linuxacademy'
    assert test_ie.ie_key() == 'LinuxAcademy'
    assert test_ie._VALID_URL == r'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert test_ie._NETRC_MACHINE == 'linuxacademy'
    assert test_ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert test_ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'

# Generated at 2022-06-26 12:26:27.742977
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        #Check if "Linux Academy" is extracted correctly from
        #url: https://linuxacademy.com/cp/modules/view/id/154
        LA = LinuxAcademyIE();
        LA._login();
        LA._real_extract(
            "https://linuxacademy.com/cp/modules/view/id/154");
    except:
        #If unable to extract "Linux Academy",
        #raise an AssertionError with a message
        raise AssertionError("failed to extract Linux Academy");

# Generated at 2022-06-26 12:26:33.136180
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert(ie.__class__.__name__ ==  "LinuxAcademyIE")
    assert(isinstance(ie, InfoExtractor))
    assert(ie.ie_key() == "LinuxAcademy")
    assert(ie._VALID_URL == "^https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|modules/view/id/(?P<course_id>\\d+))$")

# Generated at 2022-06-26 12:26:33.771266
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE(): 
    assert LinuxAcademyIE(InfoExtractor())

# Generated at 2022-06-26 12:26:34.643959
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    # assert ie._real_initialize() == True

# Generated at 2022-06-26 12:26:40.345208
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    assert ie.suitable(url)
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|modules/view/id/(?P<course_id>\\d+))'

# Generated at 2022-06-26 12:26:41.063234
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE

# Generated at 2022-06-26 12:30:27.129493
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Basic test for constructor of class LinuxAcademyIE
    """
    LA_IE = LinuxAcademyIE()
    LA_IE._real_initialize()



# Generated at 2022-06-26 12:30:29.350714
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert hasattr(ie, '_login')
    assert hasattr(ie, '_real_initialize')
    assert hasattr(ie, '_real_extract')


# Generated at 2022-06-26 12:30:31.251714
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Unit test for constructor of class LinuxAcademyIE
    """
    la = LinuxAcademyIE()

    linuxacademy_credentials = la._get_login_info()

    assert linuxacademy_credentials is not None

    la._login()

# Generated at 2022-06-26 12:30:37.489553
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_ie = LinuxAcademyIE()
    assert test_ie.IE_NAME == 'linuxacademy'
    assert test_ie.ie_key() == 'LinuxAcademy'
    assert test_ie.NETRC_MACHINE == 'linuxacademy'
    assert test_ie._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'
    assert test_ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'

# Generated at 2022-06-26 12:30:45.571280
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-26 12:30:53.274962
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # test for working with the login request
    login_page = '''{
        "extraParams": {
            "client_id": "KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx",
            "redirect_uri": "https://linuxacademy.com",
            "tenant": "lacausers",
            "connection": "Username-Password-Authentication",
            "username": "helloo",
            "password": "bob",
            "sso": "true"
        }
    }'''

    # test for working with the login state request