

# Generated at 2022-06-26 12:21:16.104541
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert_raises(TypeError, LinuxAcademyIE)

# Generated at 2022-06-26 12:21:23.958731
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_case = {'name': 'js_to_json', 'msg': 'transform javascript object notation to json'}
    linux_academy_i_e = LinuxAcademyIE()
    assert(not linux_academy_i_e.is_login_required())
    assert(linux_academy_i_e.js_to_json('{"abc":1, "def": "ghi", "xyz": [1, 2, 3]}') == '{"abc":1, "def": "ghi", "xyz": [1, 2, 3]}')

# Generated at 2022-06-26 12:21:26.640822
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_0 = LinuxAcademyIE()
# unit test for method _real_initialize

# Generated at 2022-06-26 12:21:29.506752
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()
    assert linux_academy_i_e




# Generated at 2022-06-26 12:21:33.042850
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert_raises(RegexNotFoundError, LinuxAcademyIE._real_extract, LinuxAcademyIE(), "https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2")


# Generated at 2022-06-26 12:21:37.128507
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Unit test for _real_initialize method of class LinuxAcademyIE
    linux_academy_i_e_0 = LinuxAcademyIE()
    linux_academy_i_e_0._real_initialize()


# Generated at 2022-06-26 12:21:40.547217
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    lame = LinuxAcademyIE()
    assert(lame.ie_key() == 'LinuxAcademy')
    assert(lame.ie_name() == 'LinuxAcademy')

# Unit Test for real_extract()

# Generated at 2022-06-26 12:21:42.197919
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_0 = LinuxAcademyIE()


# Generated at 2022-06-26 12:21:43.216465
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:21:45.258440
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_1 = LinuxAcademyIE()


test_classes = [
    LinuxAcademyIE
    ]

# Generated at 2022-06-26 12:22:23.941683
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_0 = LinuxAcademyIE()
    assert linux_academy_i_e_0 is not None


# Generated at 2022-06-26 12:22:24.503772
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-26 12:22:26.761717
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_0 = LinuxAcademyIE()
    assert isinstance(linux_academy_i_e_0, LinuxAcademyIE)


# Generated at 2022-06-26 12:22:36.178932
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()
    assert linux_academy_i_e.IE_NAME == 'Linux Academy'
    assert linux_academy_i_e._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert linux_academy_i_e.NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-26 12:22:38.264928
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()
    assert linux_academy_i_e


# Generated at 2022-06-26 12:22:44.950978
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from ytdl.extractor.common import InfoExtractor
    linux_academy_i_e = LinuxAcademyIE(InfoExtractor())
    assert linux_academy_i_e.ie_key() == "LinuxAcademy"
    assert linux_academy_i_e.ie_key() == "LinuxAcademy"
    assert linux_academy_i_e.ie_key() == "LinuxAcademy"


# Generated at 2022-06-26 12:22:46.589976
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_case_0()


if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-26 12:22:47.792972
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()

# Generated at 2022-06-26 12:22:49.260778
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()



# Generated at 2022-06-26 12:22:54.122403
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # match url works as expected
    assert LinuxAcademyIE._match_url("https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675")
    assert not LinuxAcademyIE._match_url("https://www.youtube.com/watch?v=WYJG9XImeFk")
    # constructor can be called
    linux_academy_i_e_0 = LinuxAcademyIE()

# Generated at 2022-06-26 12:23:35.913833
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    inst = LinuxAcademyIE()
    assert inst.ie_key() == 'LinuxAcademy'
    assert inst.ie_name() == 'LinuxAcademy'
    assert inst.ie_version() is None


# Generated at 2022-06-26 12:23:36.843988
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:23:37.387906
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()


# Generated at 2022-06-26 12:23:42.146753
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # No value of username or password
    ie = LinuxAcademyIE()
    assert ie._login_info() == (None, None)

    # No value of password
    ie = LinuxAcademyIE(username='foo')
    assert ie._login_info() == ('foo', None)

    # No value of username
    ie = LinuxAcademyIE(password='bar')
    assert ie._login_info() == (None, 'bar')

# Generated at 2022-06-26 12:23:46.575472
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_download_common import _test_download_ie
    _test_download_ie(LinuxAcademyIE, {
        'ie_key': 'LinuxAcademy',
        'pattern': r'https://(?:www\.)?linuxacademy\.com/cp/.*',
        'login_required': True,
    })

# Generated at 2022-06-26 12:23:58.591454
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    This function tests the constructor for LinuxAcademyIE
    """
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'''(?x)
                                https?://
                                    (?:www\.)?linuxacademy\.com/cp/
                                    (?:
                                        courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                                        modules/view/id/(?P<course_id>\d+)
                                    )
                                '''
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-26 12:23:59.538894
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:24:07.456572
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    import io
    import os
    import sys
    import unittest
    import test.context
    curdir = os.path.dirname(os.path.abspath(__file__))
    test_dir = os.path.dirname(curdir)
    test_resources = os.path.join(test_dir, 'resources')
    sys.path.append(test_resources)
    from test_linux_academy import TestLinuxAcademyCredentials

    class TestLinuxAcademyIECredentials():
        def __init__(self):
            self.USERNAME = ''
            self.PASSWORD = ''

    credentials = TestLinuxAcademyIECredentials()

# Generated at 2022-06-26 12:24:08.164675
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('test')

# Generated at 2022-06-26 12:24:14.278347
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url_invalid_format = LinuxAcademyIE._VALID_URL
    url_valid_format = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2'
    mobj = re.match(LinuxAcademyIE._VALID_URL, url_invalid_format)
    assert mobj is None
    mobj = re.match(LinuxAcademyIE._VALID_URL, url_valid_format)
    assert mobj is not None

# Generated at 2022-06-26 12:25:59.771475
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert 'LinuxAcademyIE' in globals()
    assert 'InfoExtractor' in globals()

# Generated at 2022-06-26 12:26:00.234640
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-26 12:26:00.893797
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxAcademy = LinuxAcademyIE()

# Generated at 2022-06-26 12:26:04.132688
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Constructor test
    """
    linux_academy_ie = LinuxAcademyIE()
    assert linux_academy_ie.ie_key() == 'linuxacademy'
    assert linux_academy_ie.ie_name() == 'linuxacademy'
    assert linux_academy_ie.ie_version() == '1.0'
    assert linux_academy_ie.test()

# Generated at 2022-06-26 12:26:04.885091
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

# Generated at 2022-06-26 12:26:05.777914
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:26:15.130130
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert type(ie) == LinuxAcademyIE
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.ie_name() == 'linuxacademy'
    assert ie.js_to_json is not None
    assert ie._download_webpage is not None
    assert ie._download_webpage_handle is not None
    assert ie._hidden_inputs is not None
    assert ie._login is not None
    assert ie._real_extract is not None
    assert ie._real_initialize is not None
    assert ie._search_regex is not None
    assert ie._parse_json is not None
    assert ie._VALID_URL is not None
    assert ie._TESTS is not None
    assert ie._AUTHORIZE_URL is not None


# Generated at 2022-06-26 12:26:17.330181
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try_get_LinuxAcademyIE = LinuxAcademyIE(None)
    assert try_get_LinuxAcademyIE != None
    print("Test for constructor of class LinuxAcademyIE passed")


# Generated at 2022-06-26 12:26:18.321198
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:26:20.121332
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from . import env
    from .linuxacademy import LinuxAcademyIE
    laIE = LinuxAcademyIE._make_ie()
    laIE._login()
    assert env.USERNAME is not None
    assert env.PASSWORD is not None

# Generated at 2022-06-26 12:30:34.500899
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademy = LinuxAcademyIE()
    assert hasattr(linuxacademy, '_login')
    assert hasattr(linuxacademy, '_real_initialize')
    assert hasattr(linuxacademy, '_real_extract')
    assert hasattr(linuxacademy, '_VALID_URL')
    assert hasattr(linuxacademy, '_download_webpage')
    assert hasattr(linuxacademy, '_download_webpage_handle')
    assert hasattr(linuxacademy, '_parse_json')
    assert hasattr(linuxacademy, '_search_regex')
    assert hasattr(linuxacademy, '_hidden_inputs')
    assert hasattr(linuxacademy, '_get_login_info')

# Generated at 2022-06-26 12:30:37.218501
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.int_name() == 'LinuxAcademy'
    assert ie.extract_name() == 'LinuxAcademy'
    assert ie.suitable(None) is False
    assert ie.suitable('http://site.com') is False

# Generated at 2022-06-26 12:30:41.115732
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    if True:
        # Example of URL to download
        url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'

        # Instantiate an object of class LinuxAcademyIE
        linux_academy_ie = LinuxAcademyIE()
        linux_academy_ie._login()
        linux_academy_ie._real_extract(url)

# Generated at 2022-06-26 12:30:43.898885
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Unit tests for the constructor of the class LinuxAcademyIE()
    """
    ie_linux_academy = LinuxAcademyIE()
    assert ie_linux_academy is not None

# Generated at 2022-06-26 12:30:46.576307
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = "https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2"
    x = LinuxAcademyIE()
    x.extract(url)

# Generated at 2022-06-26 12:30:52.225117
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Tests LinuxAcademyIE"""
    # Netrc file should be available
    class test_LinuxAcademyIE(LinuxAcademyIE):
        def __init__(self, *args, **kwargs):
            super(test_LinuxAcademyIE, self).__init__(*args, **kwargs)

        def _real_initialize(self):
            super(test_LinuxAcademyIE, self)._real_initialize()

    test_LinuxAcademyIE(LinuxAcademyIE.ie_key())._real_initialize()