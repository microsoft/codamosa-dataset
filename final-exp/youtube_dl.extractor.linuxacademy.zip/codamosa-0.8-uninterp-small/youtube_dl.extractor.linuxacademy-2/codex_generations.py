

# Generated at 2022-06-26 12:21:16.267524
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 12:21:17.206431
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_case_0()

# Generated at 2022-06-26 12:21:19.171833
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()
    assert linux_academy_i_e


# Generated at 2022-06-26 12:21:21.327113
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()
    assert linux_academy_i_e.get_id() == LinuxAcademyIE.ie_key()

# Generated at 2022-06-26 12:21:22.463000
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()

# Generated at 2022-06-26 12:21:25.223452
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_0 = LinuxAcademyIE()


# Generated at 2022-06-26 12:21:26.227314
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    t = LinuxAcademyIE()

# Generated at 2022-06-26 12:21:31.897434
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    _prefered_set = LinuxAcademyIE._downloader.preferred_filename()
    _prefered_set = LinuxAcademyIE._downloader.preferred_filename()
    linux_academy_i_e = LinuxAcademyIE()
    test_LinuxAcademyIE()
    return linux_academy_i_e_0

# Generated at 2022-06-26 12:21:34.482869
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Trying to create a new LinuxAcademyIE object from class LinuxAcademyIE
   linux_academy_i_e_0 = LinuxAcademyIE()

# Generated at 2022-06-26 12:21:35.074805
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-26 12:21:53.813306
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademy_ie = LinuxAcademyIE()
    assert linuxacademy_ie is not None and linuxacademy_ie

# Generated at 2022-06-26 12:22:03.338491
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-26 12:22:10.916659
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    This method tests the __init__ method of LinuxAcademyIE.

    Current tests:
        - Test the initiation of an instance of this class.

    :return: No return.
    :raise exception: raises an exception if there is a problem with the test.
    """
    from ydl.extractor.linuxacademy import LinuxAcademyIE

    # to test the creation of an instance of this class.
    ie = LinuxAcademyIE(downloader=None)

    # Check if we get the same results for a specified url.
    assert ie.suitable('https://linuxacademy.com/cp/modules/view/id/154')

    return None


# Generated at 2022-06-26 12:22:13.546533
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
    except:
        print("Failed to instantiate class LinuxAcademyIE")

# Generated at 2022-06-26 12:22:22.048496
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert hasattr(LinuxAcademyIE, '_VALID_URL') is True
    assert hasattr(LinuxAcademyIE, '_TESTS') is True
    assert hasattr(LinuxAcademyIE, 'IE_NAME') is True
    assert hasattr(LinuxAcademyIE, '_NETRC_MACHINE') is True
    assert hasattr(LinuxAcademyIE, '_real_initialize') is True
    assert hasattr(LinuxAcademyIE, '_login') is True
    assert hasattr(LinuxAcademyIE, '_real_extract') is True
    return 0

# Generated at 2022-06-26 12:22:31.289386
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE._VALID_URL == r'https?://(?:www\.)?linuxacademy\.com/cp/modules/view/id/(?P<id>\d+)'
    assert LinuxAcademyIE._TESTS[0]['url'] == 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    assert LinuxAcademyIE._TESTS[0]['info_dict']['id'] == '7971-2'
    assert LinuxAcademyIE._TESTS[0]['info_dict']['title'] == 'What Is Data Science'

# Generated at 2022-06-26 12:22:32.623983
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    constructor_test(LinuxAcademyIE, ie='LinuxAcademy')

# Generated at 2022-06-26 12:22:35.275542
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert(LinuxAcademyIE.ie_key() == LinuxAcademyIE.ie_key())
    assert(LinuxAcademyIE.ie_key() == 'LinuxAcademy')

# Generated at 2022-06-26 12:22:40.380453
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test with login errors
    # LinuxAcademy may say "The username or password provided were not valid."
    # or "The username or password provided were not valid. Please try again."
    # The error message could be different in the future.
    try:
        LinuxAcademyIE(None)._login()
    except ExtractorError as e:
        if 'Invalid credentials' in str(e):
            pass
        else:
            raise

# Generated at 2022-06-26 12:22:45.853648
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    infoExtractor = LinuxAcademyIE()
    assert infoExtractor.originUrl == 'https://linuxacademy.com'
    assert infoExtractor.clientId == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert infoExtractor.netrcMachine == 'linuxacademy'

# Generated at 2022-06-26 12:23:32.879002
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(None)

    assert ie._VALID_URL == "https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))"
    assert ie._AUTHORIZE_URL == "https://login.linuxacademy.com/authorize"
    assert ie._ORIGIN_URL == "https://linuxacademy.com"
    assert ie._CLIENT_ID == "KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx"
    assert ie._NETRC_MACHINE == "linuxacademy"

# Generated at 2022-06-26 12:23:34.086998
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # TODO
    pass

# Generated at 2022-06-26 12:23:38.856168
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'linuxacademy'
    assert LinuxAcademyIE.ie_key() == LinuxAcademyIE.ie_key()
    assert LinuxAcademyIE.ie_key() != InfoExtractor.ie_key()
    assert LinuxAcademyIE != InfoExtractor

# Generated at 2022-06-26 12:23:40.382784
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)


# Generated at 2022-06-26 12:23:44.518580
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test usage of extractor with tests defined in the class"""
    ids = []
    for t in LinuxAcademyIE._TESTS:
        if t.get('info_dict'):
            ids.append(t['info_dict']['id'])
        else:
            ids.append(t['url'])
    return LinuxAcademyIE(neo_extractor_manager=None).extract(ids)

# Generated at 2022-06-26 12:23:55.342956
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Tests for LinuxAcademyIE constructor"""
    # Test for the class definition of LinuxAcademyIE
    assert(LinuxAcademyIE is not None)

    # Test for the definition of _VALID_URL
    assert(LinuxAcademyIE._VALID_URL is not None)

    # Test for definition of _NETRC_MACHINE
    assert(LinuxAcademyIE._NETRC_MACHINE is not None)

    # Test for definition of _AUTHORIZE_URL
    assert(LinuxAcademyIE._AUTHORIZE_URL is not None)

    # Test for definition of _ORIGIN_URL
    assert(LinuxAcademyIE._ORIGIN_URL is not None)

    # Test for definition of _CLIENT_ID

# Generated at 2022-06-26 12:23:58.318453
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    return LinuxAcademyIE(InfoExtractor())('https://linuxacademy.com/cp/modules/view/id/154')

# Generated at 2022-06-26 12:23:59.633943
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Does not fail without login credentials
    LinuxAcademyIE()._login()

# Generated at 2022-06-26 12:24:00.184138
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE() is not None

# Generated at 2022-06-26 12:24:07.833442
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        # Install pytest-mock if it's not installed
        import pytest_mock  # noqa
    except ImportError:
        # Install pytest-mock if it's not installed
        from setuptools.command.easy_install import main as easy_install
        easy_install(['pytest-mock'])

        import pytest_mock  # noqa
    from unittest.mock import patch
    patch('pytest_mock.patch', autospec=True).start()

    ie_class = LinuxAcademyIE.ie_key()
    ie = ie_class()
    ie.extract("https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675")
    #assert ie.result == ie.expectedResult
   

# Generated at 2022-06-26 12:25:47.551138
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    if ie._login() is None:
        print("Can not login!")
        exit(0)
    url = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    LinuxAcademyIE._real_extract(ie, url)


# Generated at 2022-06-26 12:25:50.144131
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Unit test for constructor of class LinuxAcademyIE"""
    obj_LAIE = LinuxAcademyIE()
    assert isinstance(obj_LAIE, LinuxAcademyIE)
    assert isinstance(obj_LAIE, InfoExtractor)

# Generated at 2022-06-26 12:25:53.181167
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    ie = LinuxAcademyIE()
    ie.initialize()
    ie.extract(url)

# Generated at 2022-06-26 12:25:55.292919
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Constructor test of class LinuxAcademyIE
    """
    LinuxAcademyIE()


# Generated at 2022-06-26 12:26:02.182422
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademyIE = LinuxAcademyIE()
    assert linuxacademyIE._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert linuxacademyIE._ORIGIN_URL == 'https://linuxacademy.com'
    assert linuxacademyIE._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert linuxacademyIE._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-26 12:26:03.489169
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    return LinuxAcademyIE({
        'username': 'unit_test',
        'password': 'unit_test',
    })._login()

# Generated at 2022-06-26 12:26:08.541606
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_LinuxAcademyIE_1 = LinuxAcademyIE()
    assert isinstance(test_LinuxAcademyIE_1, InfoExtractor)

    # test _real_initialize()
    test_LinuxAcademyIE_2 = LinuxAcademyIE()
    test_LinuxAcademyIE_2._real_initialize()
    assert isinstance(test_LinuxAcademyIE_2, InfoExtractor)



# Generated at 2022-06-26 12:26:12.481636
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.suitable('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    assert ie.suitable('https://linuxacademy.com/cp/modules/view/id/154')

# Generated at 2022-06-26 12:26:15.131404
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_object = LinuxAcademyIE()
    # Ensure that IE is initialized properly. Downloading of authorization page is needed for it.
    test_object._real_initialize()
    del test_object

# Generated at 2022-06-26 12:26:19.967015
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert (LinuxAcademyIE("https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675").__module__ == __name__)
    assert (LinuxAcademyIE("https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2").__module__ == __name__)

# Generated at 2022-06-26 12:30:07.568314
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE_download = LinuxAcademyIE.download
    try:
        LinuxAcademyIE.download = lambda *args, **kwargs: None
        ie = LinuxAcademyIE()
        assert hasattr(ie, '_login')
    finally:
        LinuxAcademyIE.download = LinuxAcademyIE_download

# Generated at 2022-06-26 12:30:11.241330
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test = LinuxAcademyIE()
    assert 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675' in test.suitable('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    assert 'https://login.linuxacademy.com/authorize' in test._login()

# Generated at 2022-06-26 12:30:12.722154
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    raise SkipTest('"Test LinuxAcademyIE"')
    LinuxAcademyIE()

# Generated at 2022-06-26 12:30:14.408152
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    inst = LinuxAcademyIE({})
    assert isinstance(inst, LinuxAcademyIE)


# Generated at 2022-06-26 12:30:16.570386
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE("LinuxAcademy");
    assert ie.IE_NAME == "LinuxAcademy"
    assert ie.IE_DESC == "Linux Academy"

# Generated at 2022-06-26 12:30:24.163791
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test if constructor works"""
    ie = LinuxAcademyIE(None)

# Generated at 2022-06-26 12:30:25.032396
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:30:27.337890
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)
    assert ie.ie_key() == "LinuxAcademy"
    assert ie.IE_NAME == "LinuxAcademy"


# Generated at 2022-06-26 12:30:34.042135
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_object = {
        'url': 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
        'info_dict': {
            'id': '7971-2',
            'ext': 'mp4',
            'title': 'What Is Data Science',
            'description': 'md5:c574a3c20607144fb36cb65bdde76c99',
            'timestamp': 1607387907,
            'upload_date': '20201208',
            'duration': 304,
        },
        'params': {
            'skip_download': True,
        },
        'skip': 'Requires Linux Academy account credentials',
    }

    linux_academy = LinuxAcademyIE()

    # Check the qualities and the

# Generated at 2022-06-26 12:30:34.752403
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()