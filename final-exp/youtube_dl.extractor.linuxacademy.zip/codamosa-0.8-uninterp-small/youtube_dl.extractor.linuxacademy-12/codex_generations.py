

# Generated at 2022-06-26 12:21:18.483111
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_0 = LinuxAcademyIE()



# Generated at 2022-06-26 12:21:19.793606
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()

# Generated at 2022-06-26 12:21:31.019093
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()
    assert linux_academy_i_e._VALID_URL == 'https?://(?:www\\.)?linuxacademy\\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|modules/view/id/(?P<course_id>\\d+))'

# Generated at 2022-06-26 12:21:33.265185
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_0 = LinuxAcademyIE()
    return linux_academy_i_e_0


# Generated at 2022-06-26 12:21:34.573712
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()


# Generated at 2022-06-26 12:21:37.168752
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_0 = LinuxAcademyIE()


# Generated at 2022-06-26 12:21:38.702407
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_0 = LinuxAcademyIE()

# Generated at 2022-06-26 12:21:39.522998
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._NETRC_MACHINE == 'linuxacademy'


# Generated at 2022-06-26 12:21:46.424078
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from LinuxAcademyIE import LinuxAcademyIE
    # Default constructor
    linux_academy_i_e = LinuxAcademyIE()
    # Constructor with parameters
    linux_academy_i_e = LinuxAcademyIE(username='0', password='1', downloader=None)
    # Assert the value of attributes
    assert linux_academy_i_e.username == '0'
    assert linux_academy_i_e.password == '1'
    assert linux_academy_i_e.downloader == None


# Generated at 2022-06-26 12:21:56.324430
# Unit test for constructor of class LinuxAcademyIE

# Generated at 2022-06-26 12:22:40.261019
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert "LinuxAcademyIE" == getattr(LinuxAcademyIE, "__name__", None)
    assert "IE" == getattr(LinuxAcademyIE, "ie_key", None)
    assert hasattr(LinuxAcademyIE, "_VALID_URL")
    assert hasattr(LinuxAcademyIE, "_download_webpage_handle")
    assert hasattr(LinuxAcademyIE, "report_warning")
    assert hasattr(LinuxAcademyIE, "_real_extract")
    assert hasattr(LinuxAcademyIE, "_extract_m3u8_formats")
    assert hasattr(LinuxAcademyIE, "_sort_formats")
    assert hasattr(LinuxAcademyIE, "_download_webpage")

# Generated at 2022-06-26 12:22:50.704741
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_1 = LinuxAcademyIE()
    assert linux_academy_i_e_1._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert linux_academy_i_e_1._ORIGIN_URL == 'https://linuxacademy.com'
    assert linux_academy_i_e_1._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert linux_academy_i_e_1._NETRC_MACHINE == 'linuxacademy'
    assert linux_academy_i_e_1._EXTRACTOR_KEY == 'LinuxAcademy'


# Generated at 2022-06-26 12:22:52.132435
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_0 = LinuxAcademyIE()


# Generated at 2022-06-26 12:22:53.234489
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert linux_academy_i_e_0 != None

# Generated at 2022-06-26 12:22:56.655008
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    o = LinuxAcademyIE()
    assert o._NETRC_MACHINE == 'linuxacademy'
    assert o._ORIGIN_URL == 'https://linuxacademy.com'
    assert o._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'


# Generated at 2022-06-26 12:23:01.168817
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert instance
    linux_academy_i_e_1 = LinuxAcademyIE()
    assert linux_academy_i_e_1


# Generated at 2022-06-26 12:23:06.159166
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e_0 = LinuxAcademyIE()
    linux_academy_i_e_0.login()
    linux_academy_i_e_0.extract('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')


# Generated at 2022-06-26 12:23:07.828979
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print("test_LinuxAcademyIE_constructor")
    test_case_0()


# Generated at 2022-06-26 12:23:15.999394
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()
    assert not linux_academy_i_e._LOGIN_REQUIRED
    assert linux_academy_i_e._VALID_URL == LinuxAcademyIE._VALID_URL
    assert linux_academy_i_e._CLIENT_ID == LinuxAcademyIE._CLIENT_ID
    assert linux_academy_i_e._NETRC_MACHINE == LinuxAcademyIE._NETRC_MACHINE
    assert linux_academy_i_e._AUTHORIZE_URL == LinuxAcademyIE._AUTHORIZE_URL
    assert linux_academy_i_e._ORIGIN_URL == LinuxAcademyIE._ORIGIN_URL

# Generated at 2022-06-26 12:23:17.894033
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()


# Generated at 2022-06-26 12:23:53.822099
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie is not None

# Generated at 2022-06-26 12:23:54.786833
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:23:55.731911
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    return LinuxAcademyIE()

# Generated at 2022-06-26 12:24:04.717559
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Following are three ways to test a method
    # Method 1: create an object of the class LinuxAcademyIE
    test_object = LinuxAcademyIE()

    # Method 2: use try-catch-assertion
    try:
        test_object = LinuxAcademyIE()
    except:
        assert False, "LinuxAcademyIE class should create objects with no exception"

    # Method 3: use exceptions checker decorator in test_utils.py
    @test_utils.check_exceptions
    def test_function():
        test_object = LinuxAcademyIE()
    try:
        test_function()
    except:
        assert False, "LinuxAcademyIE class should create objects with no exception"


# Generated at 2022-06-26 12:24:05.796228
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert 2 == LinuxAcademyIE()._VALID_URL

# Generated at 2022-06-26 12:24:11.384781
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test only the constructor, the other tests are already covered by YoutubeIE
    # In the constructor the following attributes are set:
    # _VALID_URL, _NETRC_MACHINE, _LOGIN_URL, _LOGIN_EMAIL_TITLE,
    # _LOGIN_EMAIL_TITLE, _LOGIN_PASSWORD_TITLE, _LOGIN_ERROR_MESSAGE
    # Those attributes are used by other functions of the YoutubeIE extractor

    # Test with the empty filename
    ie = LinuxAcademyIE('linuxacademy')
    # The YoutubeIE constructor will be called and the following attributes
    # will be set
    assert ie.ie_key() == 'Youtube'
    assert ie.ie_key() == 'Youtube'
    assert ie.username is None
    assert ie.password is None


# Generated at 2022-06-26 12:24:12.105138
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('LinuxAcademy')

# Generated at 2022-06-26 12:24:13.079283
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

# Generated at 2022-06-26 12:24:21.452265
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    d = LinuxAcademyIE(None)
    assert d.IE_NAME == "linuxacademy"
    assert d.NETRC_MACHINE == "linuxacademy"
    assert d.CLIENT_ID == "KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx"
    assert d.VALID_URL == r'https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'
    assert d.AUTHORIZE_URL == "https://login.linuxacademy.com/authorize"
    assert d.ORIG

# Generated at 2022-06-26 12:24:23.861188
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test the constructor of the LinuxAcademy class
    # ie = LinuxAcademyIE(LinuxAcademyIE.ie_key())
    print("TODO")

# Generated at 2022-06-26 12:26:04.062167
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()


if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-26 12:26:05.128591
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test login
    ie = LinuxAcademyIE()
    ie._login()

# Generated at 2022-06-26 12:26:07.310276
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert isinstance(LinuxAcademyIE(id='LinuxAcademy', ie_key='LinuxAcademy'), InfoExtractor)

# Generated at 2022-06-26 12:26:16.162999
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert re.search(LinuxAcademyIE._VALID_URL, 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675') is not None
    assert re.search(LinuxAcademyIE._VALID_URL, 'https://linuxacademy.com/cp/modules/view/id/154') is not None
    assert re.search(LinuxAcademyIE._VALID_URL, 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2') is not None
    assert re.search(LinuxAcademyIE._VALID_URL, 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2/') is not None

# Generated at 2022-06-26 12:26:16.939249
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(InfoExtractor)._login()

# Generated at 2022-06-26 12:26:17.941663
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:26:19.740552
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()




# Generated at 2022-06-26 12:26:21.110367
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert obj.SUCCEEDED


# Generated at 2022-06-26 12:26:23.098395
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    LinuxAcademyIE()
    """
    # Can I create an LinuxAcademyIE object without fail?
    assert LinuxAcademyIE() is not None

# Generated at 2022-06-26 12:26:30.014125
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'''(?x)https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'''
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-26 12:30:30.004882
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()


# Generated at 2022-06-26 12:30:34.248955
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE('')
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-26 12:30:36.244203
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import sys
    """ test LinuxAcademyIE constructor """
    sys.argv = ["LinuxAcademyIE", "https://linuxacademy.com/cp/modules/view/id/154"]
    LinuxAcademyIE()._login()

# Generated at 2022-06-26 12:30:37.432068
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    main()

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-26 12:30:39.827308
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE.IE_KEY = 'linuxacademy'
    LinuxAcademyIE.linuxacademy = LinuxAcademyIE()
    LinuxAcademyIE.linuxacademy.IE_KEY = 'linuxacademy'

# Generated at 2022-06-26 12:30:40.578577
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:30:42.067246
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)

# Generated at 2022-06-26 12:30:42.798820
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:30:51.469228
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Unit test for constructor of class LinuxAcademyIE
    """

    ie = LinuxAcademyIE()
    assert ie._VALID_URL, 'Regex VALID_URL missing'
    assert ie._TESTS, 'Missing unit tests'
    assert ie._AUTHORIZE_URL, 'Missing authorize url'
    assert ie._ORIGIN_URL, 'Missing origin url'
    assert ie._CLIENT_ID, 'Missing client id'
    assert ie._NETRC_MACHINE, 'Missing netrc machine'

    # test_real_initialize
    ie._real_initialize()

    # test_real_extract
    course_url = 'https://linuxacademy.com/cp/modules/view/id/154'
    #assert ie._real_extract(course_url)['id'] ==