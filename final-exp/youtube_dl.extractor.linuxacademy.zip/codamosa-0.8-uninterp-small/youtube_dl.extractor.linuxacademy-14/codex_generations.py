

# Generated at 2022-06-26 12:21:16.112675
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_i_e = LinuxAcademyIE()


# Generated at 2022-06-26 12:21:23.986041
# Unit test for constructor of class LinuxAcademyIE

# Generated at 2022-06-26 12:21:35.157710
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._NETRC_MACHINE == 'linuxacademy'
    assert LinuxAcademyIE()._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert LinuxAcademyIE()._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert LinuxAcademyIE()._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-26 12:21:38.705866
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        test_case_0()
    except Exception as e:
        print(e)
    else:
        print("test 0 is successful")


# Generated at 2022-06-26 12:21:43.419698
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    netrc_login_linuxacadmey = 'login_linuxacadmey'
    linux_academy_i_e_0 = LinuxAcademyIE(netrc_login_linuxacadmey)
    assert linux_academy_i_e_0._NETRC_MACHINE == netrc_login_linuxacadmey


# Generated at 2022-06-26 12:21:48.686836
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Entry url
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    # Instantiation of class LinuxAcademyIE
    linux_academy_i_e_1 = LinuxAcademyIE()
    # Call to _real_extract() method of class LinuxAcademyIE
    return linux_academy_i_e_1._real_extract(url)

# Generated at 2022-06-26 12:21:53.889885
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert test_case_0() == '\n        \n            https?://\n                (?:www\\.)?linuxacademy\\.com/cp/\n                (?:courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|modules/view/id/(?P<course_id>\\d+))\n        '

# Generated at 2022-06-26 12:21:56.225651
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert linux_academy_i_e_0


# Generated at 2022-06-26 12:21:59.643906
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # test the constructor of LinuxAcademyIE
    linux_academy_i_e = LinuxAcademyIE()
    assert linux_academy_i_e.IE_NAME == 'linuxacademy'


# Generated at 2022-06-26 12:22:00.383164
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-26 12:22:20.892970
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Construct an instance of LinuxAcademyIE
    linuxacademy_ie = LinuxAcademyIE()
    # test _login()
    linuxacademy_ie._login()

# Generated at 2022-06-26 12:22:26.036518
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'LinuxAcademy'
    assert ie._VALID_URL == r'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-26 12:22:31.631600
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

# Generated at 2022-06-26 12:22:33.357935
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info = LinuxAcademyIE()
    assert "LinuxAcademyIE" in info.info()

# Generated at 2022-06-26 12:22:42.475274
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Create an instance of class LinuxAcademyIE
    course = 'https://linuxacademy.com/cp/modules/view/id/154'
    lecture = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    linuxacademyIE = LinuxAcademyIE(None)
    # Test that instance LinuxAcademyIE
    assert(linuxacademyIE._download_webpage)
    assert(linuxacademyIE._login)
    assert(linuxacademyIE._real_initialize)
    assert(linuxacademyIE._real_extract)
    assert(linuxacademyIE._extract_m3u8_formats)

# Generated at 2022-06-26 12:22:52.458316
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._CLIENT_ID == "KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx"
    assert ie._NETRC_MACHINE == "linuxacademy"
    assert ie._ORIGIN_URL == "https://linuxacademy.com"
    assert ie._AUTHORIZE_URL == "https://login.linuxacademy.com/authorize"

# Generated at 2022-06-26 12:22:58.817333
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert type(ie) == LinuxAcademyIE
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.IE_DESC == 'LinuxAcademy'
    assert type(ie.ie_key()) == str
    assert type(ie.IE_DESC) == str
    assert ie.VALID_URL == ie._VALID_URL
    assert ie._VALID_URL == ie._TESTS[0]['url']
    assert ie._TESTS[0]['url'] == 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    assert ie._TESTS[0]['info_dict']['id'] == '7971-2'
    assert ie._TES

# Generated at 2022-06-26 12:23:05.252927
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Construct a LinuxAcademyIE object and check if it is the right class of object
    # If a LinuxAcademyIE object gets created, it is the right object
    assert isinstance(LinuxAcademyIE(), LinuxAcademyIE)
    # If a LoginInfoExtractor object gets created, then it is not the right object as it inherits from LinuxAcademyIE
    assert not isinstance(InfoExtractor(), LinuxAcademyIE)

# Generated at 2022-06-26 12:23:13.301713
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'''(?x)https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'''

# Generated at 2022-06-26 12:23:14.536790
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-26 12:24:00.905863
# Unit test for constructor of class LinuxAcademyIE

# Generated at 2022-06-26 12:24:04.315775
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert hasattr(LinuxAcademyIE, '_build_request')
    assert all(hasattr(LinuxAcademyIE, f) for f in
               ['_CLIENT_ID', '_NETRC_MACHINE', '_AUTHORIZE_URL', '_ORIGIN_URL'])



# Generated at 2022-06-26 12:24:05.118952
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:24:06.718945
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie is not None
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-26 12:24:08.073398
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Basic test
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.IE_DESC == 'Linux Academy'

# Generated at 2022-06-26 12:24:11.811728
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Tests that login is needed
    ie = LinuxAcademyIE()
    try:
        ie.suite()
        raise AssertionError('Should raise ExtractorError')
    except ExtractorError as e:
        assert 'Please provide your Linux Academy credentials' in str(e)

# Generated at 2022-06-26 12:24:15.147104
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('LinuxAcademy', 'cp', 'Linux Academy')
    LinuxAcademyIE('LinuxAcademy', 'cp', 'Linux Academy', 'username', 'password')
    LinuxAcademyIE('LinuxAcademy', 'cp', 'Linux Academy', 'username', 'wrong_password')

# Generated at 2022-06-26 12:24:17.632467
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Unit test for LinuxAcademyIE constructor
    """
    ie = LinuxAcademyIE()

    print(ie.IE_NAME)

# test_LinuxAcademyIE()

# Generated at 2022-06-26 12:24:18.388450
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:24:19.107254
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-26 12:26:06.607412
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .common import InfoExtractor
    InfoExtractor(LinuxAcademyIE.ie_key())._login()

# Generated at 2022-06-26 12:26:08.219539
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert LinuxAcademyIE.ie_key() == 'linuxacademy'

# Generated at 2022-06-26 12:26:09.231530
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    x = LinuxAcademyIE()

# Generated at 2022-06-26 12:26:12.154447
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert LinuxAcademyIE.ie_key() == 'linuxacademy'
    assert ie.suitable(LinuxAcademyIE.ie_key())

# Generated at 2022-06-26 12:26:14.201417
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        # Creating an instance of LinuxAcademyIE
        instance = LinuxAcademyIE()
    except:
        return False
    return True

# Generated at 2022-06-26 12:26:22.607874
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.IE_DESC == 'LinuxAcademy online courses'
    assert ie._VALID_URL == r'https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'

# Generated at 2022-06-26 12:26:29.578406
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-26 12:26:35.694493
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    class_ = LinuxAcademyIE(
        'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    assert class_._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-26 12:26:36.979382
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'

# Generated at 2022-06-26 12:26:41.833885
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Constructor of class LinuxAcademyIE
    """
    print(LinuxAcademyIE()._VALID_URL)
    print(LinuxAcademyIE()._TESTS)
    print(LinuxAcademyIE()._AUTHORIZE_URL)
    print(LinuxAcademyIE()._ORIGIN_URL)
    print(LinuxAcademyIE()._CLIENT_ID)
    print(LinuxAcademyIE()._NETRC_MACHINE)

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-26 12:30:39.182281
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    '''
    Constructor test
    '''
    assert LinuxAcademyIE.__name__ == 'LinuxAcademyIE'

# Generated at 2022-06-26 12:30:39.985643
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()



# Generated at 2022-06-26 12:30:44.310841
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info_extractor = LinuxAcademyIE()
    input = u'https://linuxacademy.com/cp/modules/view/id/154'
    try:
        info_extractor._login()
        info_extractor._real_extract(input)
    except Exception as ex:
        message = 'Exception occurs in _real_extract: %s' % str(ex)
        raise Exception(message)

# Generated at 2022-06-26 12:30:49.669950
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert LinuxAcademyIE()._ORIGIN_URL == 'https://linuxacademy.com'
    assert LinuxAcademyIE()._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert LinuxAcademyIE()._NETRC_MACHINE == 'linuxacademy'