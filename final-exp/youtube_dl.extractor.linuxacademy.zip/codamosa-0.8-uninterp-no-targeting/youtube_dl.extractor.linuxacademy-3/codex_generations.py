

# Generated at 2022-06-22 07:58:07.314950
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print(LinuxAcademyIE('linuxacademy'))

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-22 07:58:10.873104
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.name == 'linuxacademy'

# Generated at 2022-06-22 07:58:23.661712
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert ie._TESTS == [{
        'url': 'https://linuxacademy.com/cp/courses/lesson/course/630/lesson/2334/module/268',
        'only_matching': True
    }]
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'

# Generated at 2022-06-22 07:58:29.356335
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # LinuxAcademyIE has no test case, its extractor inherits from
    # GenericIE, so GenericIE has test case for it
    assert str(LinuxAcademyIE('LinuxAcademy', 'LinuxAcademy')) == '<LinuxAcademyIE(LinuxAcademy:LinuxAcademy)>'

# Generated at 2022-06-22 07:58:29.971921
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-22 07:58:31.058935
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 07:58:33.320647
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'LinuxAcademy'

# Generated at 2022-06-22 07:58:38.686228
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    course_id = '154'
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    laie = LinuxAcademyIE(
        {
            'lesson_id': '2',
            'chapter_id': '7971',
            'course_id': course_id,
            'course_url': url,
        })
    assert laie.course_id == course_id

# Generated at 2022-06-22 07:58:50.903618
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    '''
    Test a normal login
    '''
    from .test_linuxacademy_login import TEST_CREDENTIALS
    from .test_linuxacademy_login import TEST_STRING
    from .test_linuxacademy_login import TEST_LOGIN_DATA
    from .test_linuxacademy_login import TEST_LOGIN_PAGE
    from .test_linuxacademy_login import TEST_LOGIN_CALLBACK
    from .test_linuxacademy_login import TEST_LOGIN_STATE_URL

    # Mock _download_webpage
    def _download_webpage(url, *args, **kwargs):
        '''
        Mock the _download_webpage method of class LinuxAcademyIE
        '''
        # Invoke the correct _download_webpage

# Generated at 2022-06-22 07:58:52.494965
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    print(obj)

# Generated at 2022-06-22 07:59:12.282115
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_module(LinuxAcademyIE)

# Generated at 2022-06-22 07:59:22.420769
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info_extractor = LinuxAcademyIE()

    # constructor of class InfoExtractor
    assert info_extractor._downloader is not None
    assert info_extractor._WORKING_DIR_NAME == 'youtube-dl'
    assert info_extractor._downloader.cache.get.__func__ is not info_extractor._downloader.cache.get
    assert info_extractor._downloader.cache.read.__func__ is not info_extractor._downloader.cache.read
    assert info_extractor._downloader.cache.store.__func__ is not info_extractor._downloader.cache.store
    assert info_extractor._downloader.cache.store.__func__ is not info_extractor._downloader.cache.store
    assert info_extractor._downloader.cache.store.__func__ is not info

# Generated at 2022-06-22 07:59:27.132360
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    a_ie = LinuxAcademyIE()
    # a_ie._real_initialize()
    # download a video and extract it
    a_ie.download('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')

# Generated at 2022-06-22 07:59:30.575867
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    linuxacademy = LinuxAcademyIE(LinuxAcademyIE.ie_key())
    linuxacademy.extract(url)

# Generated at 2022-06-22 07:59:32.612270
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
    except:
        assert False
    assert True



# Generated at 2022-06-22 07:59:34.341910
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print("Running constructor test only")
    ie = LinuxAcademyIE()

# Generated at 2022-06-22 07:59:42.115974
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._NETRC_MACHINE == 'linuxacademy'
    assert LinuxAcademyIE()._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert LinuxAcademyIE()._ORIGIN_URL == 'https://linuxacademy.com'
    assert LinuxAcademyIE()._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'

# Generated at 2022-06-22 07:59:54.390795
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import os
    _SAMPLE_FILES_DIR = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'LinuxAcademy_sample'
    )
    ie = LinuxAcademyIE()
    expected_fields = ['url', 'title', 'description', 'duration', 'timestamp']
    for _, _, files in os.walk(_SAMPLE_FILES_DIR):
        for file in files:
            file_name, file_ext = os.path.splitext(file)
            if file_ext == '.json':
                file_url = os.path.join(_SAMPLE_FILES_DIR, file)
                _, _, results = os.walk(file_url).__next__()

# Generated at 2022-06-22 07:59:55.471770
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print(LinuxAcademyIE)


# Generated at 2022-06-22 08:00:00.988619
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert hasattr(ie, '_login') == True
    assert hasattr(ie, '_real_initialize') == True
    expected_url = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    assert ie._VALID_URL == expected_url
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-22 08:00:41.393364
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie
    assert ie.IE_NAME == 'linuxacademy'

# Generated at 2022-06-22 08:00:43.732392
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    testObj = LinuxAcademyIE()
    print(testObj._VALID_URL)

# Generated at 2022-06-22 08:00:46.704834
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._LOGIN_REQUIRED



# Generated at 2022-06-22 08:00:49.626511
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert isinstance(LinuxAcademyIE({}), LinuxAcademyIE)

# Generated at 2022-06-22 08:00:51.321768
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ja = LinuxAcademyIE()
    assert ja is not None

# Generated at 2022-06-22 08:00:51.921555
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 08:01:00.823842
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'

# Generated at 2022-06-22 08:01:01.833737
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 08:01:05.217900
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()._login()
    except ExtractorError as e:
        if isinstance(e.cause, compat_HTTPError) and e.cause.code == 401:
            # Unauthorized: credentials might be missing on purpose
            pass
        else:
            raise

# Generated at 2022-06-22 08:01:06.254771
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 08:02:36.967273
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test a range of URLs from linuxacademy.com
    urls_to_test = [
        'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
        'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2',
        'https://linuxacademy.com/cp/modules/view/id/154',
    ]

    for url in urls_to_test:
        LinuxAcademyIE().suitable(url)

# Generated at 2022-06-22 08:02:44.518739
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # __init__(self, _downloader=None, username=None, password=None,
    #               query={}, headers={}, origin_url=None,
    #               mpd_id='default', fmt='bestvideo', fatal=True,
    #               _type=None, test=False,
    #               **kwargs)

    ie = LinuxAcademyIE(username='user', password='123456')

    assert ie._downloader is None
    assert ie._username == 'user'
    assert ie._password == '123456'
    assert ie.username == 'user'
    assert ie.password == '123456'
    assert ie.query == {}
    assert ie.headers == {}
    assert ie.origin_url is None
    assert ie.mpd_id == 'default'

# Generated at 2022-06-22 08:02:45.870315
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 08:02:55.041587
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # The input string is incomplete b/c it is from the testing site
    parsed_url = urlparse('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    assert parsed_url.scheme == 'https'
    assert parsed_url.netloc == 'linuxacademy.com'
    assert parsed_url.path == '/cp/courses/lesson/course/7971/lesson/2/module/675'
    assert parsed_url.params == ''
    assert parsed_url.query == ''
    assert parsed_url.fragment == ''

# Generated at 2022-06-22 08:03:02.542476
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test for empty password
    ie_test = LinuxAcademyIE()
    # Test for incorrect password
    ie_test = LinuxAcademyIE(password='incorrect password')
    # Test for correct password
    ie_test = LinuxAcademyIE(password='correctpassword')
    # Test for incorrect username
    ie_test = LinuxAcademyIE(username='incorrectusername')
    # Test for correct username
    ie_test = LinuxAcademyIE(username='correctusername')
    # Test for empty username
    ie_test = LinuxAcademyIE(username='')

# Generated at 2022-06-22 08:03:03.176001
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-22 08:03:06.108698
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # test if succeeded
    assert LinuxAcademyIE.ie_key() == "LinuxAcademy"
    # test if it failed
    assert LinuxAcademyIE.ie_key() != "VoiceTube"



# Generated at 2022-06-22 08:03:07.913578
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # test for constructor with empty args
    LinuxAcademyIE()
    # test for constructor with empty kwargs
    LinuxAcademyIE(**{})

# Generated at 2022-06-22 08:03:09.185152
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    inst = LinuxAcademyIE()
    inst._login()

# Generated at 2022-06-22 08:03:10.052533
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE._login()

# Generated at 2022-06-22 08:06:47.214626
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('Linux Academy', 'linuxacademy.com')


# Generated at 2022-06-22 08:06:55.123383
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # 'online' mode
    LinuxAcademyIE._download_webpage = lambda self, url: {
        'url': 'http://www.example.com',
        'status': 200,
        'content': "<html><head><title>LinuxAcademy - download webpage test</title></head><body></body></html>",
        'headers': {},
        'http_headers': {},
    }
    # test case 1: return None
    assert (LinuxAcademyIE()._login() == None)
    # 'offline' mode

# Generated at 2022-06-22 08:06:56.655385
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import util
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    assert LinuxAcademyIE.suitable(util.url_basename(url)) is True

# Generated at 2022-06-22 08:07:07.190426
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert obj._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert obj._NETRC_MACHINE == 'linuxacademy'
    assert obj._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert obj._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
   

# Generated at 2022-06-22 08:07:11.509945
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Exercise constructor of class LinuxAcademyIE
    # Test whether a TypeError is raised for URLs that don't contain
    # a course or a lecture
    invalid_url = 'https://linuxacademy.com/cp/'
    instance = LinuxAcademyIE()
    with pytest.raises(TypeError):
        instance.suitable(invalid_url)

# Generated at 2022-06-22 08:07:17.246259
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE._VALID_URL == r'https?://(?:www\.)?linuxacademy\.com/cp/modules/view/id/(?P<id>\d+)'
    assert LinuxAcademyIE._TESTS == [{
        'url': 'https://linuxacademy.com/cp/modules/view/id/154',
        'info_dict': {
            'id': '154',
            'title': 'AWS Certified Cloud Practitioner',
            'description': 'md5:a68a299ca9bb98d41cca5abc4d4ce22c',
            'duration': 28835,
        },
        'playlist_count': 41,
        'skip': 'Requires Linux Academy account credentials',
    }]
    assert LinuxAcademyIE._AUTHORIZE_URL

# Generated at 2022-06-22 08:07:22.726522
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy = LinuxAcademyIE()
    assert isinstance(linux_academy._downloader, YoutubeDL) and linux_academy._login()


# Generated at 2022-06-22 08:07:30.361317
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'

# Generated at 2022-06-22 08:07:32.836438
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-22 08:07:33.729830
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()
