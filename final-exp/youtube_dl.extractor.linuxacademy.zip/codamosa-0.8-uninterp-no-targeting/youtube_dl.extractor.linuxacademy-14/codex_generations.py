

# Generated at 2022-06-22 07:58:06.690521
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_obj = LinuxAcademyIE()
    assert test_obj is not None

# Generated at 2022-06-22 07:58:07.382632
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('linuxacademy')

# Generated at 2022-06-22 07:58:18.289365
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == "https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))"

# Generated at 2022-06-22 07:58:20.193351
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._login() is None


# Generated at 2022-06-22 07:58:21.674127
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    return ie

# Generated at 2022-06-22 07:58:29.033185
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL is not None
    assert ie._NETRC_MACHINE is not None
    assert ie._CLIENT_ID is not None
    assert ie._AUTHORIZE_URL is not None
    assert ie._ORIGIN_URL is not None
    assert ie._TEST is not None
    assert ie.IE_NAME is not None
    assert ie.ie_key() is not None


# Generated at 2022-06-22 07:58:37.210095
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxAcademy = LinuxAcademyIE()
    assert linuxAcademy.IE_NAME == 'linuxacademy'
    assert linuxAcademy.AUTHORIZED_URL == 'https://login.linuxacademy.com/authorize'
    assert linuxAcademy.ORIGIN_URL == 'https://linuxacademy.com'
    assert linuxAcademy.CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert linuxAcademy.NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-22 07:58:39.439664
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert obj is not None

# Generated at 2022-06-22 07:58:40.181593
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    example = LinuxAcademyIE()

# Generated at 2022-06-22 07:58:48.188699
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # test absent account credentials
    with LinuxAcademyIE()._build_login_context():
        assert LinuxAcademyIE()._login() == None

    # test login with bad account credentials
    with LinuxAcademyIE(username="", password="")._build_login_context():
        assert LinuxAcademyIE()._login() == None

    #test login with good account credentials
    with LinuxAcademyIE(username="test_username", password="test_password")._build_login_context():
        assert LinuxAcademyIE()._login() == None

# Generated at 2022-06-22 07:59:29.133257
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    result = LinuxAcademyIE()
    assert(result._CLIENT_ID == "KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx")
    assert(result._NETRC_MACHINE == "linuxacademy")

# Generated at 2022-06-22 07:59:32.060579
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print("Running unit test for LinuxAcademyIE")
    assert(LinuxAcademyIE.name == 'linuxacademy')

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-22 07:59:34.816130
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    la_ie = LinuxAcademyIE()
    # Test correct imports
    assert la_ie

# Unit test to check if variables have been initialized correctly

# Generated at 2022-06-22 07:59:45.059494
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert obj.ie_key() == 'LinuxAcademy'
    assert obj.IE_NAME == 'LinuxAcademy'
    assert obj.VERSION == '1.0.0'
    assert obj._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-22 07:59:47.033707
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(downloader=lambda url: url)

# Generated at 2022-06-22 07:59:48.146540
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('test')

# Generated at 2022-06-22 07:59:59.397080
# Unit test for constructor of class LinuxAcademyIE

# Generated at 2022-06-22 08:00:07.605209
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Instantiation of class LinuxAcademyIE
    # "https://www.linuxacademy.com/"
    ie = LinuxAcademyIE()
    # Properties of class LinuxAcademyIE
    assert ie._VALID_URL == 'https?://(?:www\\.)?linuxacademy\\.com/cp/courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)'

# Generated at 2022-06-22 08:00:09.217471
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_LinuxAcademyIE = LinuxAcademyIE()



# Generated at 2022-06-22 08:00:12.374334
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Basic test case to check if LinuxAcademyIE
    can be instantiated. This is a test case of LinuxAcademyIE.
    """
    LinuxAcademyIE()

# Generated at 2022-06-22 08:01:48.113641
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test constructor of class LinuxAcademyIE"""
    # stub
    url = "https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675"
    # Unit test for constructor of class LinuxAcademyIE
    ie = LinuxAcademyIE({})
    assert ie.suitable(url)
    # Unit test for real_extract of class LinuxAcademyIE
    info = ie.extract(url)
    assert info["id"] == "7971-2"
    assert info["title"] == "What Is Data Science"
    assert info["description"] == "md5:c574a3c20607144fb36cb65bdde76c99"
    assert info["timestamp"] == 1607387907

# Generated at 2022-06-22 08:01:49.910190
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'

# Generated at 2022-06-22 08:01:56.276082
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_DESC == 'Linux Academy'
    assert ie.IE_NAME == 'linuxacademy'
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/\S*'

# Generated at 2022-06-22 08:01:58.688145
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    class test_arguments:
        proxy = None
        username = None
        password = None

    test_object = LinuxAcademyIE(test_arguments)
    assert(test_object.username is None)
    assert(test_object.password is None)

# Generated at 2022-06-22 08:02:10.710670
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try_login = False

    test_cases = [
        {
            'url': 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
            'info_dict': {
                'id': '7971-2',
                'ext': 'mp4',
                'title': 'What Is Data Science',
                'description': 'md5:c574a3c20607144fb36cb65bdde76c99',
                'timestamp': 1607387907,
                'upload_date': '20201208',
                'duration': 304,
            },
            'params': {
                'skip_download': True,
            },
            'skip': 'Requires Linux Academy account credentials',
        },
    ]


# Generated at 2022-06-22 08:02:13.549751
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test for generating a LinuxAcademyIE Obj
    try:
        LinuxAcademyIE()
    except:
        raise AssertionError('Failed to generate LinuxAcademyIE')

# Generated at 2022-06-22 08:02:17.131775
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    _test_IE = LinuxAcademyIE()
    assert _test_IE.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-22 08:02:18.136810
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()._login()

# Generated at 2022-06-22 08:02:29.957107
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE('LinuxAcademy', 'https://linuxacademy.com/cp/modules/view/id/154')
    assert ie._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|modules/view/id/(?P<course_id>\\d+))'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-22 08:02:32.107635
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie is not None

# Generated at 2022-06-22 08:06:18.998057
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE();
    # Testing of constructor, if it creates object of required type
    assert(isinstance(ie, LinuxAcademyIE))


# Generated at 2022-06-22 08:06:20.806601
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    print(ie._CLIENT_ID)
    print(ie._ORIGIN_URL)

# Generated at 2022-06-22 08:06:25.500202
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    print(ie._AUTHORIZE_URL)
    print(ie._ORIGIN_URL)
    print(ie._CLIENT_ID)
    pass

# Generated at 2022-06-22 08:06:28.143948
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Constructor test
    """
    linuxAcademyIE = LinuxAcademyIE()
    print(linuxAcademyIE)

# Generated at 2022-06-22 08:06:29.255031
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie

# Generated at 2022-06-22 08:06:32.353166
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    unit_test = LinuxAcademyIE.ie_key()
    assert unit_test

                # Unit test ends here

# Generated at 2022-06-22 08:06:39.627988
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    IE = LinuxAcademyIE("https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675")
    assert IE.ie_key() == "LinuxAcademy"
    assert IE.info_dict["id"] == "7971-2"
    assert IE.info_dict["description"].startswith("Linux Academy is built on the premise that sharing")
    assert IE.params["skip_download"] == True
    assert IE.info_dict["title"] == "What Is Data Science"
    assert IE.info_dict["timestamp"] == 1607387907
    assert IE.info_dict["upload_date"] == "20201208"
    assert IE.info_dict["duration"] == 304

# Generated at 2022-06-22 08:06:44.025487
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Case 1: No Authentication
    obj = LinuxAcademyIE()
    assert obj.username == None and obj.password == None
    # Case 2: With Authentication
    obj = LinuxAcademyIE(username='foo', password='bar')
    assert obj.username == 'foo' and obj.password == 'bar'

# Generated at 2022-06-22 08:06:50.943693
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_main import TestExtractors
    test = TestExtractors()

    info_extractor = LinuxAcademyIE(test.config)
    info_extractor._real_initialize()

    try:
        info_extractor._real_extract(test.urls['linuxacademy'])
        #test.assertEqual(test.urls['linuxacademy'])
    except:
        print("LinuxAcademyIE::test_LinuxAcademyIE - exception")

# Generated at 2022-06-22 08:06:58.944276
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie
    assert ie._AUTHORIZE_URL == "https://login.linuxacademy.com/authorize"
    assert ie._ORIGIN_URL == "https://linuxacademy.com"
    assert ie._CLIENT_ID == "KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx"
    assert ie._NETRC_MACHINE == "linuxacademy"