

# Generated at 2022-06-22 07:58:18.271882
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_cases = (
        {'url': 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
         'only_matching': True},
        {'url': 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2',
         'only_matching': True},
        {'url': 'https://linuxacademy.com/cp/modules/view/id/154',
         'only_matching': True},
    )
    for test_case in test_cases:
        assert LinuxAcademyIE().suitable(test_case['url'])
        if test_case['only_matching']:
            assert LinuxAcademyIE()._VALID_URL == LinuxAcademy

# Generated at 2022-06-22 07:58:30.155816
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LAIE = LinuxAcademyIE()
    assert LAIE.IE_NAME == "linuxacademy.com"
    assert LAIE._VALID_URL == r'https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'
    assert LAIE._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert LAIE._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-22 07:58:31.767849
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 07:58:40.773815
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Load provider test cases.
    for provider, cases in [('LinuxAcademy', 'linuxacademy.json')]:
        # Parse provider test cases.
        with open(os.path.join(os.path.dirname(__file__), cases)) as data_file:
            test_cases = json.load(data_file)
            # Iterate through each test case. 
            for test_case in test_cases:
                # Skip empty test cases.
                if not test_case:
                    continue
                # Collect test case arguments. 
                kwargs = test_case.get('args', {})
                # Load test case result.
                if 'result' in test_case:
                    result = test_case.get('result')
                else:
                    result = None
                # Run basic constructor assertions.

# Generated at 2022-06-22 07:58:50.950893
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Unit test for constructor of class LinuxAcademyIE."""
    # Create dummy class LinuxAcademyIE
    class DummyClass(LinuxAcademyIE):
        def __init__(self):
            super(DummyClass, self).__init__(
                ie_key='LinuxAcademyIE',
                ie_url_key='linuxacademy',
                pattern=r'http://linuxacademy\.com',
                ie_name='linuxacademy'
            )
    # Check if object of class LinuxAcademyIE is created successfully
    assert isinstance(DummyClass(), LinuxAcademyIE)

# Generated at 2022-06-22 07:59:01.773538
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/' + \
        '(?:courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|modules/view/id/(?P<course_id>\\d+))'

# Generated at 2022-06-22 07:59:12.238797
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_utils import Incomplete, TestFailure, TestSuccess, run_test_cases, \
        TestCase
    # url, [result]
    cases = [
        TestCase(
            'https://linuxacademy.com/cp/modules/view/id/154',
            Incomplete('requires Linux Academy account credentials')),
        TestCase(
            'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2',
            TestSuccess()),
        TestCase(
            'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
            Incomplete('requires Linux Academy account credentials')),
    ]
    run_test_cases(LinuxAcademyIE, cases)

# Generated at 2022-06-22 07:59:24.787328
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    course_url = 'https://linuxacademy.com/cp/modules/view/id/154'
    course_id = '154'
    course_name = 'AWS Certified Cloud Practitioner'
    course_duration = 28835
    course_duration_str = '7:48:55'
    course_playlist_url = 'https://linuxacademy.com/cp/modules/view/id/309'
    course_playlist_id = '309'
    course_playlist_name = 'AWS Certified Developer - Associate'
    course_playlist_duration = 25582
    course_playlist_duration_str = '7:06:22'
    lesson_url = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'

# Generated at 2022-06-22 07:59:27.540051
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    c = LinuxAcademyIE()
    assert c is not None
    assert c.IE_NAME == "LinuxAcademy"

# Generated at 2022-06-22 07:59:37.895639
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxAcademy = LinuxAcademyIE('LinuxAcademy')
    assert linuxAcademy._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-22 07:59:58.967325
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Check engine is working
    LinuxAcademyIE.ie_key()
    # Check extractor was constructed properly
    LinuxAcademyIE()

# Generated at 2022-06-22 08:00:00.642045
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(None)
    assert 'LinuxAcademy' in ie.IE_NAME

# Generated at 2022-06-22 08:00:02.649079
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(LinuxAcademyIE.ie_key())

# Generated at 2022-06-22 08:00:03.461265
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE is not None

# Generated at 2022-06-22 08:00:15.638026
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.linuxacademy import LinuxAcademyIE
    from youtube_dl.postprocessor.common import MetadataFromTitlePP

    with YoutubeDL({'extractors': [LinuxAcademyIE.ie_key()],
                    'postprocessors': [MetadataFromTitlePP(
                        ie_key='LinuxAcademy'
                        )]}) as ydl:
        obj = ydl.extract_info(
            'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
        assert(obj['id'] == '7971-2')
        assert(obj['ext'] == 'mp4')
        assert(obj['title'] == 'What Is Data Science')

# Generated at 2022-06-22 08:00:27.068883
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.__name__ == 'LinuxAcademyIE'
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'
    assert LinuxAcademyIE._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    ie = LinuxAcademyIE()
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-22 08:00:32.120865
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
    except Exception as e:
        raise AssertionError("Failed to instantiate class LinuxAcademyIE: {0}".format(e))

# Generated at 2022-06-22 08:00:36.917255
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_ie = LinuxAcademyIE()
    assert test_ie.ie_key() == 'LinuxAcademy'
    assert test_ie.IE_NAME == 'LinuxAcademy'
    assert test_ie._VALID_URL == LinuxAcademyIE._VALID_URL

# Generated at 2022-06-22 08:00:38.271951
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    e = LinuxAcademyIE()
    e._login()


# Generated at 2022-06-22 08:00:41.297266
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # test constructor
    u_co = LinuxAcademyIE(0)
    assert u_co.name == 'linuxacademy'
    assert u_co._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-22 08:01:10.873037
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'LinuxAcademy'
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie._VALID_URL == 'https?://(?:www\\.)?linuxacademy\\.com/cp/'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-22 08:01:18.874543
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print("Running test_LinuxAcademyIE()...")

    # Create an instance of the LinuxAcademyIE class
    instance = LinuxAcademyIE()

    # Download the page associated with the URL
    page = instance._download_webpage(LinuxAcademyIE._ORIGIN_URL, None)

    # Test that a substring of the page exists
    assert("Linux Academy" in page)

    print("Completed test_LinuxAcademyIE()")

if __name__ == "__main__":
    test_LinuxAcademyIE()

# Generated at 2022-06-22 08:01:28.397667
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_

# Generated at 2022-06-22 08:01:38.585812
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    myIE = LinuxAcademyIE()
    myIE._login() # In case you want to check the login
    # Below are the test scenarios for extracting the URL
    # refer to https://github.com/rg3/youtube-dl/blob/master/youtube_dl/extractor/edx.py for the complete details.
    #############################################################################################################
    # Scenario: single video path
    myURL = "https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675"
    myInfo = myIE.extract(myURL)
    print(myInfo)
    #############################################################################################################
    # Scenario: course path, id = 1
    myURL = "https://linuxacademy.com/cp/modules/view/id/1"
   

# Generated at 2022-06-22 08:01:46.859785
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    la = LinuxAcademyIE()
    assert la.get_urls_from_url('https://linuxacademy.com/cp/modules/view/id/154', la._VALID_URL) == [
        'https://linuxacademy.com/cp/modules/view/id/154',
    ]
    assert la.get_urls_from_url('https://linuxacademy.com/cp/courses/lesson/course/169/lesson/2', la._VALID_URL) == [
        'https://linuxacademy.com/cp/courses/lesson/course/169/lesson/2',
    ]

# Generated at 2022-06-22 08:01:48.674539
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Unit test for constructor of class LinuxAcademyIE"""
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'

# Generated at 2022-06-22 08:01:59.442206
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    username_test_results = [
        {
            'input': 'a@b.com',
            'expected': 'a@b.com'
        },
        {
            'input': 'a@z.edu',
            'expected': 'a@z.edu'
        },
        {
            'input': 'a@g.gov',
            'expected': 'a@g.gov'
        },
        {
            'input': 'a@b.co.uk',
            'expected': 'a@b.co.uk'
        }
    ]


# Generated at 2022-06-22 08:02:05.590339
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import io, sys, unittest
    sys.stdout = io.StringIO()
    linuxacademy = LinuxAcademyIE()
    assert linuxacademy
    sys.stdout = sys.__stdout__
    print('Tests Passed!')

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-22 08:02:06.660201
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 08:02:07.599181
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None, {})

# Generated at 2022-06-22 08:03:02.083556
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-22 08:03:09.258691
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_downloader import create_downloader
    from .test_optparser import setUpModule

    setUpModule()
    dl = create_downloader('linuxacademy')
    ie = dl._ies[0]
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-22 08:03:16.478494
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'

# Generated at 2022-06-22 08:03:22.379887
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL is not None
    assert ie._TEST is not None
    assert ie._NETRC_MACHINE is not None
    assert ie._AUTHORIZE_URL is not None
    assert ie._ORIGIN_URL is not None
    assert ie._CLIENT_ID is not None

# Generated at 2022-06-22 08:03:31.704199
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # mock a LessonVideo object
    video = type('TestVideo', (object,),
                 {'id': 7971,
                  'chapter_id': 2,
                  'lesson_id': 3,
                  'url': 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/4/module/675',
                  'title': 'What Is Data Science',
                  'description': 'md5:c574a3c20607144fb36cb65bdde76c99',
                  'timestamp': 1607387907,
                  'upload_date': '20201208',
                  'duration': 304
                  })

    # mock a Course object

# Generated at 2022-06-22 08:03:39.805568
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    raise RuntimeError(
        'Please install keyring module and set LinuxAcademy credentials '
        'https://github.com/ytdl-org/youtube-dl/blob/master/README.md#passwords')

    ie = LinuxAcademyIE()
    assert ie.username == '<someuser>'
    assert ie.password == '<somepass>'

# Generated at 2022-06-22 08:03:42.462804
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_ie = LinuxAcademyIE()
    assert test_ie
    assert test_ie.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-22 08:03:44.947149
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    m = LinuxAcademyIE()
    m.IE_NAME

# Generated at 2022-06-22 08:03:50.291076
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    # test if it implements the _login method
    assert callable(ie._login)
    # test if it implements the _real_initialize method
    assert callable(ie._real_initialize)
    # test if it implements the _real_extract method
    assert callable(ie._real_extract)

# Generated at 2022-06-22 08:03:51.309692
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
   pass

# Generated at 2022-06-22 08:05:52.777196
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    class_ = LinuxAcademyIE
    url = "https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2"
    args = (url,)
    kwargs = {'ie_key':'Generic'}    
    actual = class_(*args, **kwargs)

    assert actual.url == "https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2"
    assert actual.video_id == "1498-2"
    assert actual.course_id == None
    assert actual.chapter_id == "1498"
    assert actual.lecture_id == "2"
    assert actual.chapter_number == None
    assert actual.chapter == None

# Generated at 2022-06-22 08:05:54.294080
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-22 08:06:02.219019
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        from .test import test_linuxacademy
        # print(test_linuxacademy.__file__)
    except:
        print("'from .test import test_linuxacademy' not supported in this version of Python. "
              "'from test import test_linuxacademy' only works in Python 2.7 and earlier.")
    else:
        test_linuxacademy.main()

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-22 08:06:04.876783
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_LinuxAcademyIE_unit = LinuxAcademyIE()
    print(test_LinuxAcademyIE_unit)
    return


# Generated at 2022-06-22 08:06:07.820659
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        me = LinuxAcademyIE()
    except NameError:
        raise Exception('Failed to instantiate LinuxAcademyIE object')
    else:
        pass

# Generated at 2022-06-22 08:06:08.854876
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 08:06:10.601949
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-22 08:06:11.636518
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie

# Generated at 2022-06-22 08:06:14.382389
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_input = 'https://www.linuxacademy.com/cp/courses/lesson/course/7971/lesson/2'
    assert test_LinuxAcademyIE.ie_key() == 'LinuxAcademy'
    ie = LinuxAcademyIE(params={'url' : test_input})
    ie._real_extract(test_input)

# Generated at 2022-06-22 08:06:17.087439
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Constructor test for class LinuxAcademyIE
    """
    LinuxAcademyIE(None)