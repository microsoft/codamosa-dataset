

# Generated at 2022-06-22 07:58:12.383723
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Tests LinuxAcademyIE constructor"""
    constructor_test_base(LinuxAcademyIE, [], True)

# Generated at 2022-06-22 07:58:13.537954
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = linuxacademyIE('', True)
    obj.linuxacademyLogin()

# Generated at 2022-06-22 07:58:14.772597
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie

# Generated at 2022-06-22 07:58:23.903788
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # test LinuxAcademyIE class constructor
    ie = LinuxAcademyIE()
    assert ie is not None
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'

# Generated at 2022-06-22 07:58:25.275807
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 07:58:35.399183
# Unit test for constructor of class LinuxAcademyIE

# Generated at 2022-06-22 07:58:39.420425
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    l = LinuxAcademyIE()
    try:
        l._real_initialize()
        r = l._real_extract(url)
    except ExtractorError:
        r = None
    print(r)

# Generated at 2022-06-22 07:58:46.564536
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        from .test import linuxacademy
    except ImportError:
        print("test-linuxacademy.py import error or linuxacademy is missing")
        return

    linuxacademy.test_LinuxAcademyIE_initialize()
    linuxacademy.test_LinuxAcademyIE_real_initialize()
    linuxacademy.test_LinuxAcademyIE_login()
    linuxacademy.test_LinuxAcademyIE_real_extract()

# Generated at 2022-06-22 07:58:58.653066
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.IE_DESC == 'LinuxAcademy'
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CL

# Generated at 2022-06-22 07:59:00.066219
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert isinstance(LinuxAcademyIE("LinuxAcademyIE"), InfoExtractor)

# Generated at 2022-06-22 07:59:37.212375
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 07:59:38.947087
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(InfoExtractor)


# Generated at 2022-06-22 07:59:48.581854
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE._CLIENT_ID is not None
    assert LinuxAcademyIE._ORIGIN_URL is not None
    assert LinuxAcademyIE._AUTHORIZE_URL is not None
    assert LinuxAcademyIE._NETRC_MACHINE is not None

    ie = LinuxAcademyIE(None)
    ie._login()
    ie._real_extract('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    ie._real_extract('https://linuxacademy.com/cp/modules/view/id/154')

# Generated at 2022-06-22 07:59:50.136274
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-22 08:00:00.567817
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # python3 cannot call constructor of IE class directly
    # (more specifically, it cannot call constructor of its super class)
    linuxacademy = LinuxAcademyIE()
    assert linuxacademy.ie_key() == 'LinuxAcademy'
    assert linuxacademy.ie_key() == LinuxAcademyIE.ie_key()
    assert linuxacademy._VALID_URL == LinuxAcademyIE._VALID_URL
    assert linuxacademy._TESTS == LinuxAcademyIE._TESTS
    assert linuxacademy._download_webpage.__name__ == LinuxAcademyIE._download_webpage.__name__
    assert linuxacademy._real_extract.__name__ == LinuxAcademyIE._real_extract.__name__

# Generated at 2022-06-22 08:00:07.413340
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    autherize_url = 'https://login.linuxacademy.com/authorize'
    origin_url = 'https://linuxacademy.com'
    client_id = 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    netrc_machine = 'linuxacademy'

    instance = LinuxAcademyIE()
    assert(instance._AUTHORIZE_URL == autherize_url)
    assert(instance._ORIGIN_URL == origin_url)
    assert(instance._CLIENT_ID == client_id)
    assert(instance._NETRC_MACHINE == netrc_machine)

# Generated at 2022-06-22 08:00:16.244193
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    throwaway = ExtractorError("")
    # check for class properties
    assert LinuxAcademyIE._AUTHORIZE_URL != None
    assert LinuxAcademyIE._ORIGIN_URL != None
    assert LinuxAcademyIE._CLIENT_ID != None
    assert LinuxAcademyIE._NETRC_MACHINE != None
    # check for missing methods
    # check for missing error handling
    assert LinuxAcademyIE._login() != throwaway
    assert LinuxAcademyIE._real_extract() != throwaway
    assert LinuxAcademyIE._real_initialize() != throwaway

# Generated at 2022-06-22 08:00:27.642552
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'

# Generated at 2022-06-22 08:00:38.708598
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademy = LinuxAcademyIE()
    assert linuxacademy.IE_NAME == 'linuxacademy'
    assert linuxacademy._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert linuxacademy._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert linuxacademy._ORIGIN_URL == 'https://linuxacademy.com'
    assert linuxacademy

# Generated at 2022-06-22 08:00:40.101735
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_ie = LinuxAcademyIE()
    assert linux_academy_ie is not None

# Generated at 2022-06-22 08:01:22.813485
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test that you can declare your own LinuxAcademyIE
    class LocalLinuxAcademyIE(LinuxAcademyIE):
        pass
    # Test it
    LocalLinuxAcademyIE()._real_initialize()

# Generated at 2022-06-22 08:01:25.251901
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        # Create an instance of LinuxAcademyIE
        LinuxAcademyIE("LinuxAcademyIE")
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-22 08:01:29.801502
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # create an instance
    item_id = '154'
    url = 'https://linuxacademy.com/cp/modules/view/id/' + item_id
    # linuxacademy = LinuxAcademyIE()
    # print(linuxacademy.extract(url))
    print(LinuxAcademyIE().extract(url))

# Generated at 2022-06-22 08:01:32.626022
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert instance.ie_key() == "linuxacademy"
    assert instance.ie_name() == "LinuxAcademy"

# Generated at 2022-06-22 08:01:37.025170
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Dummy URL
    url = "https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675"
    # Create an instance of class
    assert LinuxAcademyIE(url) != None

# Generated at 2022-06-22 08:01:38.778183
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Tests whether the class constructor can be used without raising an error"""
    LinuxAcademyIE()

# Generated at 2022-06-22 08:01:40.253181
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    check_cls = LinuxAcademyIE
    check_cls(None)

# Generated at 2022-06-22 08:01:50.273926
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademy = LinuxAcademyIE()
    assert linuxacademy._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert linuxacademy._NETRC_MACHINE == 'linuxacademy'
    assert linuxacademy._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert linuxacademy._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-22 08:01:52.677260
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    my_ie = LinuxAcademyIE()
    return



# Generated at 2022-06-22 08:02:04.437325
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    i = LinuxAcademyIE()
    assert i.IE_NAME == 'linuxacademy'
    assert i.IE_DESC == 'LinuxAcademy.com videos'
    assert i._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-22 08:03:43.010815
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from . import LinuxAcademyIE

    # Constructor of LinuxAcademyIE test
    #
    # At the moment it is just a smoke test to verify that the constructor does not crash or
    # silently swallow exceptions.
    #
    # "LinuxAcademyIE.__init__()" would be the appropriate name for a test. However, naming the
    # test "LinuxAcademyIE.__init__" is not allowed and the underscore is important for the
    # doctest to work correctly.
    #
    # The following snippet must not be indented, otherwise doctest will fail.
    ia = LinuxAcademyIE()

# Generated at 2022-06-22 08:03:46.206299
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Unit tests for constructor of class LinuxAcademyIE"""
    YoutubeIE.workingInstance = None
    linuxAcademy = LinuxAcademyIE()
    linuxAcademy._login()

# Generated at 2022-06-22 08:03:48.621576
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._NETRC_MACHINE == 'linuxacademy'


# Generated at 2022-06-22 08:03:56.363549
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie_instance = LinuxAcademyIE(None)
    assert ie_instance._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie_instance._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie_instance._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie_instance._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-22 08:03:57.242997
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 08:04:08.415449
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # TODO: remove once Python 2 is no longer supported
    if sys.version_info[0] < 3:
        return

    # Tests of the the constructor
    # This test needs to be in a function because the line-number has to be
    # different than the line-number of the lines where the error is actually
    # raised
    def check_LinuxAcademyIE_init_assert(self):
        # The constructor raises an error if the JSON value for the playlist is
        # not a list
        # These are the same constructor options that YouTubeInvidiousIE has
        ie = LinuxAcademyIE(options={'outtmpl': '%(id)s-%(autonumber)s.%(ext)s'})
        # The playlist value is a dictionary

# Generated at 2022-06-22 08:04:11.864216
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    args = (
        ('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'),
        ('https://linuxacademy.com/cp/modules/view/id/154'),
    )
    for url in args:
        LinuxAcademyIE(url)

# Generated at 2022-06-22 08:04:13.300213
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # We can't test this, since we don't have any account
    pass

# Generated at 2022-06-22 08:04:14.764937
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_instance = LinuxAcademyIE()
    print(test_instance)

# Generated at 2022-06-22 08:04:19.019067
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        la_ie = LinuxAcademyIE()
    except:
        pass
    else:
        assert(False)
    assert('_login' not in dir(la_ie))