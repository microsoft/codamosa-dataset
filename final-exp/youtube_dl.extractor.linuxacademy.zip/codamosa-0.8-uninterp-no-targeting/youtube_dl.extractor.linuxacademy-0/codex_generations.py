

# Generated at 2022-06-22 07:58:14.521533
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.video_id is None
    assert ie.title is None
    assert ie.description is None
    assert ie._VALID_URL is None
    assert ie._TESTS is None
    assert ie._AUTHORIZE_URL is None
    assert ie._ORIGIN_URL is None
    assert ie._CLIENT_ID is None
    assert ie._NETRC_MACHINE is None

# Generated at 2022-06-22 07:58:20.899987
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    # test _real_initialize method
    ie._real_initialize()
    # test _login method
    ie._login()
    # test _real_extract method
    ie._real_extract('https://linuxacademy.com/cp/modules/view/id/154')

# Generated at 2022-06-22 07:58:32.257413
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    fake_login_page = """<html><body>
                        <input type="hidden" name="foo" value="bar" />
                        <input type="hidden" name="baz" value="quux" />
                        </body></html>"""

    fake_callback_page = """<html><body>
                            <script>authorizationResponse = {
                                "response": {"access_token": "foobar"}
                            }</script>
                            </body></html>"""


# Generated at 2022-06-22 07:58:35.219148
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-22 07:58:36.612495
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    Instance = LinuxAcademyIE()
    assert Instance is not None

# Generated at 2022-06-22 07:58:47.639277
# Unit test for constructor of class LinuxAcademyIE

# Generated at 2022-06-22 07:58:51.281735
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE(None)
    except TypeError as e:
        print(e)
        assert True
    else:
        assert False


# Generated at 2022-06-22 07:58:57.887599
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # check if the constructor of class LinuxAcademyIE is working
    from .common import InfoExtractor
    from .linuxacademy import LinuxAcademyIE
    ie = LinuxAcademyIE('https://linuxacademy.com/cp/modules/view/id/154')
    info = ie._real_extract('https://linuxacademy.com/cp/modules/view/id/154')
    assert info is not None

# Generated at 2022-06-22 07:59:04.230551
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE(
        'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
        'LinuxAcademyIE() Test', 'Test Description', '',
        'https://login.linuxacademy.com/authorize',
        'https://linuxacademy.com',
        'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx',
        'linuxacademy'
    )

# Generated at 2022-06-22 07:59:05.882158
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert isinstance(LinuxAcademyIE(), LinuxAcademyIE)

# Generated at 2022-06-22 07:59:43.082640
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()._login()


# Generated at 2022-06-22 07:59:44.250037
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 07:59:50.362012
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    simple_course_url = 'https://linuxacademy.com/cp/modules/view/id/154'
    info_dicts = LinuxAcademyIE()._real_extract(simple_course_url)

    assert info_dicts['_type'] == 'playlist'
    assert info_dicts['entries'][0]['_type'] == 'url_transparent'

# Generated at 2022-06-22 07:59:53.626901
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    playlists = ie.extract('https://linuxacademy.com/cp/modules/view/id/154')
    assert playlists

# Generated at 2022-06-22 07:59:55.507170
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    ie._login()


# Generated at 2022-06-22 07:59:58.776700
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
    except Exception as e:
        assert False, str(e)

    assert True

# Generated at 2022-06-22 08:00:05.616228
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert(LinuxAcademyIE.ie_key() == 'linuxacademy')
    assert(LinuxAcademyIE.suitable('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2') == True)
    assert(LinuxAcademyIE.suitable('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2') == True)
    assert(LinuxAcademyIE.suitable('https://linuxacademy.com/cp/modules/view/id/154') == True)

# Generated at 2022-06-22 08:00:07.797162
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()

# Generated at 2022-06-22 08:00:09.376659
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from . import LinuxAcademyIE
    ie = LinuxAcademyIE()

# Generated at 2022-06-22 08:00:10.874932
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

test_LinuxAcademyIE()

# Generated at 2022-06-22 08:01:37.824491
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE

# Generated at 2022-06-22 08:01:46.138893
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    random_string = ''.join([random.choice('0123456789ABCDEFGHIJKLMNOPQRSTUVXYZabcdefghijklmnopqrstuvwxyz-._~') for _ in range(32)])

# Generated at 2022-06-22 08:01:51.183689
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    YoutubeBaseInfoExtractor.__bases__ = (LinuxAcademyIE,)
    YoutubeBaseInfoExtractor.__name__ = 'LinuxAcademyIE'
    LinuxAcademyIE.test()
    del YoutubeBaseInfoExtractor.__bases__
    del YoutubeBaseInfoExtractor.__name__

# Generated at 2022-06-22 08:01:53.930852
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    username = ''
    password = ''
    liacademy = LinuxAcademyIE(username, password)

# Generated at 2022-06-22 08:02:01.815794
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try_login = False
    LA_username = LA_password = None

    import os
    import netrc
    try:
        netrc_path = os.path.expanduser('~/.netrc')
        LA_username, LA_password = netrc.netrc(netrc_path).authenticators('linuxacademy')[0:2]
    except (TypeError, IOError, netrc.NetrcParseError):
        pass

    LA_ie = LinuxAcademyIE(username=LA_username, password=LA_password)
    LA_ie._login()

# Generated at 2022-06-22 08:02:13.216850
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():

    # Test 1: Given a correct LinuxAcademyIE IE and a valid url, the function must return a LinuxAcademyIE object
    test1_LinuxAcademyIE = LinuxAcademyIE(LinuxAcademyIE.ie_key())
    test1_url = 'https://linuxacademy.com/cp/modules/view/id/154'
    test1_LinuxAcademyIE_object = test1_LinuxAcademyIE.extract('https://linuxacademy.com/cp/modules/view/id/154')
    assert isinstance(test1_LinuxAcademyIE_object, dict)

    # Test 2: Given a correct LinuxAcademyIE IE and a invalid url, the function must raise an exception

# Generated at 2022-06-22 08:02:16.272895
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._VALID_URL == LinuxAcademyIE._VALID_URL

# Generated at 2022-06-22 08:02:17.255929
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 08:02:22.670533
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # the url is the one called by Youtube in the base.js file
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    YouTubeIE()._handle_url(url)

# Generated at 2022-06-22 08:02:31.669604
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info_extractor = LinuxAcademyIE()
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'
    assert info_extractor._VALID_URL == r'''(?x)
                                          https?://
                                          (?:www\.)?linuxacademy\.com/cp/
                                          (?:
                                             courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                                             modules/view/id/(?P<course_id>\d+)
                                          )
                                      '''


# Generated at 2022-06-22 08:06:08.467130
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
   IE = LinuxAcademyIE()

# Generated at 2022-06-22 08:06:09.476240
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()


# Generated at 2022-06-22 08:06:19.285997
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Unit test for constructor of class LinuxAcademyIE
    """
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.IE_DESC == 'LinuxAcademy'
    assert ie._VALID_URL == '^https?://(?:www\.)?linuxacademy\.com/cp/(courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|modules/view/id/(?P<course_id>\\d+))$'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID

# Generated at 2022-06-22 08:06:26.313783
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    result_dict = LinuxAcademyIE()._real_extract(url)

# Generated at 2022-06-22 08:06:27.390985
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print(LinuxAcademyIE)

# Generated at 2022-06-22 08:06:31.090545
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_mixins import CachedNetworkAppTestCase
    from .test_network_app import CachedNetworkAppTestCase
    class NetworkAppTests(CachedNetworkAppTestCase):
        pass

    LinuxAcademyIE = LinuxAcademyIE()

# Generated at 2022-06-22 08:06:35.860015
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    o = LinuxAcademyIE()
    assert o.ie_key() == 'LinuxAcademy'
    assert o.ie_key() in LinuxAcademyIE.ie_key_map

# Generated at 2022-06-22 08:06:37.964679
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        ile = LinuxAcademyIE()
    except:
        assert False

# Generated at 2022-06-22 08:06:48.477283
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    username = 'test'
    password = 'test'
    # Init instance
    LAIE = LinuxAcademyIE(username, password)
    # Test for init of private fields
    assert LAIE._login_info == [username, password]
    assert LAIE._downloader == "DummyDownloader"
    assert LAIE._username == username
    assert LAIE._password == password
    # Test for init of public fields
    assert LAIE.USER_AGENT == "LinuxAcademy/1.0"
    assert LAIE.IE_NAME == "LinuxAcademy"
    assert LAIE.server == "LinuxAcademy"
    assert LAIE.http_headers == { 'User-Agent': LAIE.USER_AGENT }

# Generated at 2022-06-22 08:06:52.807071
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass
    # TODO: Find a lesson with a video download, and write a test for
    #       LinuxAcademyIE.extract()