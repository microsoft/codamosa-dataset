

# Generated at 2022-06-22 07:58:11.636843
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-22 07:58:14.933114
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = "https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675"
    module = LinuxAcademyIE()
    module.extract(url)

# Generated at 2022-06-22 07:58:19.822090
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Test if LinuxAcademyIE can be initialized
    """
    # Test if LinuxAcademyIE can be initialized
    # Get Youtube IE
    ie = LinuxAcademyIE()
    assert ie

# Generated at 2022-06-22 07:58:31.976171
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.__module__ == 'youtube_dl.extractor.linuxacademy'
    assert LinuxAcademyIE._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert LinuxAcademyIE._TESTS[0]['url'] == 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    assert LinuxAcademyIE._TESTS[0]['info_dict']['id'] == '7971-2'

# Generated at 2022-06-22 07:58:39.055936
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

    # Ensure correct instance
    assert isinstance(ie, LinuxAcademyIE)
    # Ensure correct type
    assert ie._TYPE == 'login'
    # Ensure correct regex
    assert ie._VALID_URL == ie._VALID_URL
    # Ensure correct tests
    assert ie._TESTS == ie._TESTS

    ie._real_initialize()
    ie._real_extract(ie._TESTS[0]['url'])
    ie._real_extract(ie._TESTS[2]['url'])

# Generated at 2022-06-22 07:58:45.215855
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # This test is designed to cover case where client_id and client_secret
    # are not in netrc.
    from .. import YoutubeDL

    ydl = YoutubeDL({
        'username': 'username',
        'password': 'password',
        'usenetrc': False,
    })

    ie = LinuxAcademyIE(ydl)
    assert ie._login_info() == ('username', 'password')

# Generated at 2022-06-22 07:58:52.162682
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert obj.suitable('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    assert obj.suitable('https://linuxacademy.com/cp/modules/view/id/154')
    assert not obj.suitable('https://google.com')
    assert not obj.suitable('https://linuxacademy.com/')

# Generated at 2022-06-22 07:58:53.339703
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 07:58:58.855868
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_ie = LinuxAcademyIE()
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    list_playlist = test_ie.playlist_result(url, test_ie._real_extract(url))
    assert list_playlist is not None
    assert len(list_playlist['entries']) == 41

# Generated at 2022-06-22 07:59:00.641640
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-22 07:59:21.573027
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_js_extractor import test_class_construtor
    test_class_construtor(LinuxAcademyIE)

# Generated at 2022-06-22 07:59:28.879859
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Tests constructor of the class LinuxAcademyIE"""
    try:
        ile = LinuxAcademyIE()
        print(ile)
        print(ile._AUTHORIZE_URL)
        print(ile._ORIGIN_URL)
        print(ile._CLIENT_ID)
        print(ile._NETRC_MACHINE)

        assert (True)
    except Exception as ex:
        print(ex)
        assert(False)


# Generated at 2022-06-22 07:59:31.912475
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert isinstance(LinuxAcademyIE(), InfoExtractor)

# Generated at 2022-06-22 07:59:42.726473
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # python2.6 does not have assertLogs
    if not hasattr(LinuxAcademyIE, 'assertLogs'):
        import contextlib
        import logging
        import sys
        @contextlib.contextmanager
        def assertLogs(logger=None, level=None):
            if logger is None:
                logs = []
                def record(*args):
                    logs.append(args)

                logger = logging.getLogger(None)
                handler = logging.StreamHandler(sys.stdout)
                handler.emit = record
                logger.addHandler(handler)
                handler.setLevel(level)
                yield logs
                logger.removeHandler(handler)
            else:
                with logger.logger.handlers[0].lock:
                    logger.disabled = False
                    logger.level = level

# Generated at 2022-06-22 07:59:50.194024
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
  LinuxAcademyIE()._real_extract("https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675")
  LinuxAcademyIE()._real_extract("https://linuxacademy.com/cp/modules/view/id/154")
  LinuxAcademyIE()._real_extract("https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2")

# Generated at 2022-06-22 07:59:52.978277
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == LinuxAcademyIE.__name__.replace('IE', '').lower()

# Generated at 2022-06-22 07:59:54.601107
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test if the IE class could be instantiated
    LinuxAcademyIE()

# Generated at 2022-06-22 08:00:05.353015
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from ..compat import preserve_element

    ie = LinuxAcademyIE()

# Generated at 2022-06-22 08:00:09.324595
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE('LinuxAcademy');
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'

# Generated at 2022-06-22 08:00:10.819732
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE("", "", 'LinuxAcademy')

# Generated at 2022-06-22 08:00:51.456691
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    l = LinuxAcademyIE()
    assert l.ie_key() == 'LinuxAcademy'
    assert l._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-22 08:00:54.236657
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie is not None
test_LinuxAcademyIE.test = ("python -m unittest "
                            "extractors.test_linuxacademy.test_LinuxAcademyIE")

# Generated at 2022-06-22 08:00:55.367758
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    return LinuxAcademyIE()

# Generated at 2022-06-22 08:00:56.794455
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test LinuxAcademyIE constructor"""
    assert LinuxAcademyIE is not None

# Generated at 2022-06-22 08:01:00.278428
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    i = LinuxAcademyIE()
    assert i.KEY == 'linuxacademy'
    assert i.IE_NAME == 'linuxacademy'
    assert i.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-22 08:01:01.118696
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-22 08:01:02.027495
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 08:01:09.774721
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    class TestLinuxAcademyIE(LinuxAcademyIE):
        def _real_initialize(self):
            """
            Override _real_initialize method to check that
            LinuxAcademyIE._login() is called within
            LinuxAcademyIE._real_initialize()
            """
            self.login_called = False
            self.login_called = True

        def _login(self):
            """
            Override _login method to check that
            LinuxAcademyIE._login() is called within
            LinuxAcademyIE._real_initialize()
            """
            self.login_called = True

        def _real_extract(self, url):
            return

    ie = TestLinuxAcademyIE()

# Generated at 2022-06-22 08:01:11.244703
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 08:01:12.781976
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 08:02:41.381754
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ies = [
        LinuxAcademyIE(),
    ]
    for ie in ies:
        assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-22 08:02:42.450782
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 08:02:43.910428
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 08:02:45.398278
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-22 08:02:56.813898
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert re.match(LinuxAcademyIE._VALID_URL, 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    assert re.match(LinuxAcademyIE._VALID_URL, 'https://www.linuxacademy.com/cp/modules/view/id/154')
    assert re.match(LinuxAcademyIE._VALID_URL, 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    assert not re.match(LinuxAcademyIE._VALID_URL, 'https://www.linuxacademy.com/cp/footer')

# Generated at 2022-06-22 08:02:57.576098
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-22 08:02:58.581791
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 08:03:02.458282
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('https://linuxacademy.com/cp/courses/lesson/course/10098/lesson/2/module/18717')

# Generated at 2022-06-22 08:03:03.632941
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert not obj == None

# Generated at 2022-06-22 08:03:11.762793
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'

# Generated at 2022-06-22 08:06:51.376368
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ExtractorError = __import__('youtube_dl.extractor.common').ExtractorError
    LinuxAcademyIE = __import__('youtube_dl.extractor.linuxacademy').LinuxAcademyIE
    LinuxAcademyIE({}, 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    LinuxAcademyIE({}, 'https://linuxacademy.com/cp/modules/view/id/154')
    # raise an exception if we try to construct LinuxAcademyIE without url argument
    try:
        LinuxAcademyIE({})
        assert False
    except ExtractorError as e:
        assert 'must override _real_extract' in str(e)

# Generated at 2022-06-22 08:06:55.709077
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

    assert ie.IE_NAME == 'linuxacademy'
    assert ie.NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-22 08:06:56.916384
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()._real_initialize()

# Generated at 2022-06-22 08:06:58.106610
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    shell = LinuxAcademyIE(params={})
    assert shell

# Generated at 2022-06-22 08:07:08.774110
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/' \
                            r'(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|' \
                            r'modules/view/id/(?P<course_id>\d+))'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-22 08:07:10.176661
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE();
    assert ie.IE_NAME == 'linuxacademy'

# Generated at 2022-06-22 08:07:10.952259
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None, {})

# Generated at 2022-06-22 08:07:18.668234
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Constructor: LinuxAcademyIE(IE_NAME, ie_key)
    LinuxAcademy_ie = LinuxAcademyIE("LinuxAcademy", "LinuxAcademy")
    # Call function to initilize the class
    LinuxAcademy_ie._real_initialize()
    # returns a list of 
    if LinuxAcademy_ie.extract("https://linuxacademy.com/cp/modules/view/id/154"):
        print("The course contains test video list")
    else:
        print("The course of video list is empty")

# Test case # 1

# Generated at 2022-06-22 08:07:23.110420
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.login() is None
    assert ie.username is None
    assert ie.password is None

if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-22 08:07:25.592058
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(username='fooman', password='barpass')
