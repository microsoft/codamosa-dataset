

# Generated at 2022-06-22 07:58:17.411088
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    test_url_course = 'https://linuxacademy.com/cp/modules/view/id/154'
    test_username ='linuxacademy@linuxacademy.com'
    test_password = 'linuxacademy'
    # constructor of LinuxAcademyIE
    ie = LinuxAcademyIE(default_output_dir='/tmp')
    # test _real_initialize
    ie._real_initialize()
    my_dict = {}
    my_dict['username'] = test_username
    my_dict['password'] = test_password
    ie._downloader.cache.store('linuxacademy', my_dict)
    ie = Linux

# Generated at 2022-06-22 07:58:18.699515
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    return LinuxAcademyIE

# Generated at 2022-06-22 07:58:24.442539
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    ie.initialize()
    info_print = ie._real_extract('https://linuxacademy.com/cp/modules/view/id/154')
    assert(info_print['id'] == '154')
    assert(info_print['title'] == 'AWS Certified Cloud Practitioner')
    assert(info_print['description'] == 'md5:a68a299ca9bb98d41cca5abc4d4ce22c')
    assert(info_print['duration'] == 28835)
    assert(info_print['playlist_count'] == 41)
    assert(info_print['skip'] == 'Requires Linux Academy account credentials')



# Generated at 2022-06-22 07:58:28.786772
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert(LinuxAcademyIE.suitable('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675') == 1)

# Generated at 2022-06-22 07:58:33.051159
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    this_class = globals()['LinuxAcademyIE']
    print(this_class)
# This is a unit test to make sure the class is working
#     this_class = globals()['LinuxAcademyIE']
#     print(this_class)

# Generated at 2022-06-22 07:58:41.777759
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_linuxacademy_com import extractor_for_url
    assert extractor_for_url('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675').IE_NAME == 'LinuxAcademy'
    assert extractor_for_url('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2').IE_NAME == 'LinuxAcademy'
    assert extractor_for_url('https://linuxacademy.com/cp/modules/view/id/154').IE_NAME == 'LinuxAcademy'

# Generated at 2022-06-22 07:58:53.573081
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info_extractor = LinuxAcademyIE('linuxacademy')
    assert info_extractor._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-22 07:58:55.714472
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    klass = LinuxAcademyIE
    inst = klass()
    assert isinstance(inst, LinuxAcademyIE)

# Generated at 2022-06-22 07:59:00.449460
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        from .test_main import options
    except ImportError:
        from compat import options

    options.password = 'test'
    options.username = 'test'
    test_class = LinuxAcademyIE()
    assert test_class._downloader.username == 'test'
    assert test_class._downloader.password == 'test'

# Generated at 2022-06-22 07:59:03.726287
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE('LinuxAcademy')
    return ie

# Generated at 2022-06-22 07:59:23.604710
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info = LinuxAcademyIE()
    return info

# Generated at 2022-06-22 07:59:24.723328
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
  obj = LinuxAcademyIE()

# Generated at 2022-06-22 07:59:33.468262
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Video examples: https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675
    # Course examples: https://linuxacademy.com/cp/modules/view/id/154
    assert LinuxAcademyIE.ie_key() == 'linuxacademy'
    assert LinuxAcademyIE._VALID_URL == r'https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'

# Generated at 2022-06-22 07:59:36.200157
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    '''
    Testing constructor of class LinuxAcademyIE
    '''    
    LinuxAcademyIE()

# Generated at 2022-06-22 07:59:37.692835
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE().ie_key() == 'LinuxAcademy'

# Generated at 2022-06-22 07:59:39.008246
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert isinstance(LinuxAcademyIE(), LinuxAcademyIE)

# Generated at 2022-06-22 07:59:40.118577
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 07:59:45.357324
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_dl import _TestDL

    # login.linuxacademy.com and linuxacademy.com should be mocked
    # to run the test
    _TestDL(LinuxAcademyIE()).download(
        'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')

# Generated at 2022-06-22 07:59:57.262346
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == "Linux Academy"

# Generated at 2022-06-22 07:59:58.966786
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(
        "https://linuxacademy.com/cp/modules/view/id/154")

# Generated at 2022-06-22 08:00:39.407836
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_class = LinuxAcademyIE()
    assert test_class.__class__.__name__ == 'LinuxAcademyIE'

# Generated at 2022-06-22 08:00:49.887087
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test constructor (with some fields of the class LinuxAcademyIE)
    # Test with the field, _AUTHORIZE_URL
    ie = LinuxAcademyIE
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    # Test with the field, _ORIGIN_URL
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    # Test with the field, _CLIENT_ID
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    # Test with the field, _NETRC_MACHINE
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-22 08:00:52.460217
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    name = 'LinuxAcademy'
    ie = LinuxAcademyIE(name)
    assert hasattr(ie, 'name')
    assert ie.name == name



# Generated at 2022-06-22 08:00:54.577130
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # TODO: Add more unit test cases.
    class ConstructorTest(unittest.TestCase):
        def testLinuxAcademyIE(self):
            LinuxAcademyIE()

# Generated at 2022-06-22 08:00:55.877847
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 08:00:56.832384
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 08:00:58.857736
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('LinuxAcademy')

# Generated at 2022-06-22 08:01:00.318569
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-22 08:01:01.605393
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 08:01:02.872920
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Construct and return an instance of this IE.
    return LinuxAcademyIE()

# Generated at 2022-06-22 08:02:29.631286
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-22 08:02:38.002179
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    class_ = linuxacademy_ie.LinuxAcademyIE
    i = class_('LinuxAcademy', 'LinuxAcademy', 'LinuxAcademy')
    assert isinstance(i, class_)
    assert isinstance(i, ie.InfoExtractor)

    # unit test for class LinuxAcademyIE
    print('')
    print('unit test for class LinuxAcademyIE')
    # test_LinuxAcademyIE1
    print('')
    print('test_LinuxAcademyIE1')
    # test_LinuxAcademyIE2
    print('')
    print('test_LinuxAcademyIE2')

# Generated at 2022-06-22 08:02:45.006988
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    username = "shangwang123"

# Generated at 2022-06-22 08:02:51.277361
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()     # concrete instance of LinuxAcademyIE
    assert ie.IE_NAME == "linuxacademy"
    assert ie.server_encoding == 'utf-8'
    assert ie.episode_pattern == r'(?:chapter|lecture) (?P<episode>\d+)(?:$|[. -])'


# Generated at 2022-06-22 08:02:53.563506
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Unit test for constructor of class LinuxAcademyIE"""
    # no exception thrown:
    LinuxAcademyIE(None)

# Generated at 2022-06-22 08:02:54.949136
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie != None

# Generated at 2022-06-22 08:02:57.326145
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info_extractor = LinuxAcademyIE()
    assert isinstance(info_extractor, LinuxAcademyIE)

# Generated at 2022-06-22 08:03:00.910850
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    assert ie
    assert isinstance(ie, LinuxAcademyIE)


# Generated at 2022-06-22 08:03:09.411847
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    course, lecture = LinuxAcademyIE._extract_url(url)
    assert course == LinuxAcademyIE(course)
    assert lecture == LinuxAcademyIE(lecture)
    assert course._download_webpage == lecture._download_webpage
    assert course._download_webpage(url) == lecture._download_webpage(url)
    assert course._download_webpage(url, 154) == lecture._download_webpage(url, 154)
    assert course._download_webpage(url, 154, 'test') == lecture._download_webpage(url, 154, 'test')

# Generated at 2022-06-22 08:03:11.959516
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Create instance of LinuxAcademyIE
    la_ie = LinuxAcademyIE()
    # Confirm that the instance of class LinuxAcademyIE is created
    assert isinstance(la_ie, LinuxAcademyIE)

# Generated at 2022-06-22 08:06:49.314334
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._CLIENT_ID is not None
    assert ie._NETRC_MACHINE is not None

# Generated at 2022-06-22 08:06:54.548680
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.IE_NAME == 'LinuxAcademy'

# Generated at 2022-06-22 08:06:57.988464
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Create instance of class LinuxAcademyIE
    linux = LinuxAcademyIE('https://linuxacademy.com', '7845-2')

    assert linux.user
    assert linux.password

# Generated at 2022-06-22 08:07:08.607606
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert re.match('https?://(?:www\.)?linuxacademy\.com/cp/', ie._VALID_URL)

# Generated at 2022-06-22 08:07:14.168950
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie != None
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie.__dict__.get('_login') == ie._login
    assert ie.__dict__.get('_real_initialize') == ie._real_initialize


# Generated at 2022-06-22 08:07:15.487173
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_linuxacademy import test_LinuxAcademyIE
    return test_LinuxAcademyIE(LinuxAcademyIE())

# Generated at 2022-06-22 08:07:20.016461
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Feel the above test cases to get a valid url
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    # Create a new instance of LinuxAcademyIE
    linuxAcademyIE = LinuxAcademyIE()
    # Load the webpage
    webpage = linuxAcademyIE._download_webpage(url, '7971-2')
    # Find the m3u8 playlist url
    m3u8_url = linuxAcademyIE._parse_json(
        linuxAcademyIE._search_regex(
            r'player\.playlist\s*=\s*(\[.+?\])\s*;', webpage, 'playlist'),
        '7971-2')[0]['file']
    # Extract the

# Generated at 2022-06-22 08:07:22.127176
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    li = LinuxAcademyIE()
    assert li.IE_NAME == 'linuxacademy'

# Generated at 2022-06-22 08:07:23.076145
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 08:07:27.422543
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    for ie in (
        LinuxAcademyIE,
    ):
        i = ie({})
        assert i.extract('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
        assert i.extract('https://linuxacademy.com/cp/modules/view/id/154')