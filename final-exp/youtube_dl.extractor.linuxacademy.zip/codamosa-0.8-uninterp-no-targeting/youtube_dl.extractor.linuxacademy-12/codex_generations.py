

# Generated at 2022-06-22 07:58:07.464679
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test LinuxAcademyIE constructor"""
    ie = LinuxAcademyIE()
    assert ie
    assert ie.ie_key() == "LinuxAcademy"

# Generated at 2022-06-22 07:58:18.370892
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'

    pass_info = {
        'username': '',
        'password': '',
    }

    LinuxAcademyIE._download_webpage = lambda *args: 'webpage'
    LinuxAcademyIE._login = lambda *args: '_login'
    LinuxAcademyIE._real_extract = lambda *args: 'real_extract' 

    try:
        ie = LinuxAcademyIE()
    except:
        raise Exception('An instance of class LinuxAcademyIE cannot be created!')

    assert ie._real_extract(url) == 'real_extract'
    assert ie._download_webpage == 'webpage'

# Generated at 2022-06-22 07:58:19.351000
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 07:58:31.334997
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from unittest import mock
    from . import make_test
    import os
    import requests

    fake_auth = requests.Response()
    fake_auth._content = b''
    fake_auth.status_code = 200

    fake_callback = requests.Response()
    fake_callback._content = b''
    fake_callback.status_code = 200

    fake_me = requests.Response()
    fake_me._content = b'{"sub": "fake_user_id"}'
    fake_me.status_code = 200


# Generated at 2022-06-22 07:58:32.354163
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 07:58:33.316277
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

# Generated at 2022-06-22 07:58:34.300353
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie

# Generated at 2022-06-22 07:58:41.878011
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Unit test for class LinuxAcademyIE"""
    # Test Linux Academy (requires NetRC credentials)
    try:
        test_ie = LinuxAcademyIE(downloader=None)
    except ExtractorError:
        # Skip tests if the downloader is not authenticated
        return
    test_ie.download("https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2")
    test_ie.download("https://linuxacademy.com/cp/modules/view/id/154")

# Generated at 2022-06-22 07:58:42.832724
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademy()

# Generated at 2022-06-22 07:58:52.800574
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert re.match(ie._VALID_URL, 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2') is not None
    assert ie._VALID_URL == 'https?://(?:www\\.)?linuxacademy\\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|modules/view/id/(?P<course_id>\\d+))'
    assert re.match(ie._VALID_URL, 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2') is not None

# Generated at 2022-06-22 07:59:32.869543
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'LinuxAcademy'
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-22 07:59:35.008259
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    # Test constructor
    assert ie._TEST == 'true'

# Generated at 2022-06-22 07:59:36.724916
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 07:59:38.844029
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert isinstance(
        LinuxAcademyIE(InfoExtractor()),
        InfoExtractor
    )

# Generated at 2022-06-22 07:59:40.371417
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-22 07:59:41.487393
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('Linux Academy', _VALID_URL)

# Generated at 2022-06-22 07:59:53.728272
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_ie = LinuxAcademyIE()
    assert linux_academy_ie.IE_NAME == 'linuxacademy'
    assert linux_academy_ie.IE_DESC == 'Linux Academy'
    assert linux_academy_ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-22 07:59:57.110285
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-22 07:59:59.171308
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    return

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-22 08:00:02.987252
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademyie = LinuxAcademyIE("https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2")
    assert linuxacademyie
test_LinuxAcademyIE()

# Generated at 2022-06-22 08:01:31.631618
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(None)
    ie._login()

# Generated at 2022-06-22 08:01:33.414480
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)

# Generated at 2022-06-22 08:01:37.492782
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        from .test_linuxacademy import DummyLinuxAcademyIE
    except ImportError:
        return
    DummyLinuxAcademyIE()._login()

# Generated at 2022-06-22 08:01:48.579814
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-22 08:01:50.371467
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE(None)._NETRC_MACHINE == 'linuxacademy'


# Generated at 2022-06-22 08:01:55.316763
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    desktop_linuxacademy_ie = LinuxAcademyIE()
    assert isinstance(desktop_linuxacademy_ie, LinuxAcademyIE)
    return desktop_linuxacademy_ie

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-22 08:01:58.591246
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test private method _login()
    login_test = LinuxAcademyIE()._login()
    assert isinstance(login_test, None)
    assert login_test == None
    return True

# Generated at 2022-06-22 08:02:08.696902
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

    test_urls = (
        'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
        'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2',
        'https://linuxacademy.com/cp/modules/view/id/154',
    )

    def _test_url(url):
        # this is the only tests available, because it require account credentials
        ie._login()

    for url in test_urls:
        ie.url_result(url)

# Generated at 2022-06-22 08:02:13.914047
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # First, construct a new object of LinuxAcademyIE class.
    obj = LinuxAcademyIE()

    # Assert that all the fields in the object are properly
    # initialized by inspecting the object.
    assert obj._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''


# Generated at 2022-06-22 08:02:16.146728
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print(LinuxAcademyIE(None))

# Generated at 2022-06-22 08:06:01.519259
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # test case for login
    lain = LinuxAcademyIE()
    lain._login()
    # test case for constructing via classname
    LinuxAcademyIE._download_webpage = lambda self, url, video_id, note, errnote: None
    lain = LinuxAcademyIE('linuxacademy')
    lain._login()

# Generated at 2022-06-22 08:06:11.984939
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    uvid = LinuxAcademyIE()
    assert uvid._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<id>\d+)/lesson/(?P<sid>\d+)'
    assert uvid._TESTS == [{
        'url': 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/22',
        'only_matching': True,
    }]
    # test private attributes
    assert uvid._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert uvid._ORIGIN_URL == 'https://linuxacademy.com'
    assert uvid._CLIENT_ID

# Generated at 2022-06-22 08:06:13.617563
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademyie = LinuxAcademyIE()  # pylint: disable=unused-variable

# Generated at 2022-06-22 08:06:16.859552
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    No better test possible because of login requirement
    """
    ie = LinuxAcademyIE()
    assert ie is not None

# Generated at 2022-06-22 08:06:17.935242
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 08:06:24.267767
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE('linuxacademy')
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'

    # Test for _real_initialize
    ie._real_initialize()


# Generated at 2022-06-22 08:06:25.553919
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()


# Generated at 2022-06-22 08:06:26.382518
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    import doctest
    doctest.testmod(LinuxAcademyIE)

# Generated at 2022-06-22 08:06:28.293746
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    module = LinuxAcademyIE()
    assert module.IE_NAME == 'linuxacademy'

# Generated at 2022-06-22 08:06:37.222456
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_cases = (
        (
            'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
            '7971-2',
        ),
        (
            'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2',
            '1498-2',
        ),
        (
            'https://linuxacademy.com/cp/modules/view/id/154',
            '154',
        ),
    )
    for url, expected in test_cases:
        ie = LinuxAcademyIE(url)
        assert ie.get_id() == expected