

# Generated at 2022-06-22 07:58:11.474064
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    obj.to_screen("hello world")

# Generated at 2022-06-22 07:58:13.422726
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert obj.name == 'LinuxAcademy'

# Generated at 2022-06-22 07:58:25.977002
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():

    test_obj = LinuxAcademyIE()

    assert test_obj._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'
    assert test_obj._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert test_obj._ORIGIN_URL == 'https://linuxacademy.com'
    assert test_obj._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert test_obj._

# Generated at 2022-06-22 07:58:27.065995
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE

# Generated at 2022-06-22 07:58:28.886761
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 07:58:30.352933
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    a = LinuxAcademyIE()
    assert a != None

# Generated at 2022-06-22 07:58:33.044428
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    la_ie = LinuxAcademyIE('linuxacademy')
    assert la_ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-22 07:58:42.812047
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    log("\n--------------------------------------------------------------------------------------------------------")
    log("--------------------------------------------------------------------------------------------------------")
    log("--------------------------------------------------------------------------------------------------------")
    log("--------------------------------------------------------------------------------------------------------\n")

    # assert that the _NETRC_MACHINE is LinuxAcademy
    assert LinuxAcademyIE._NETRC_MACHINE == 'LinuxAcademy'

    # assert that the _ORIGIN_URL is set to https://linuxacademy.com
    assert LinuxAcademyIE._ORIGIN_URL == 'https://linuxacademy.com'

    # assert that the _CLIENT_ID is set to KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx

# Generated at 2022-06-22 07:58:52.799939
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    course_id = 2
    username = '8'
    password = '8'
    extractor = LinuxAcademyIE(
        LinuxAcademyIE.ie_key(), LinuxAcademyIE.ie_key(), course_id,
        LinuxAcademyIE._AUTHORIZE_URL, LinuxAcademyIE._ORIGIN_URL,
        username, password)
    assert extractor._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert extractor._ORIGIN_URL == 'https://linuxacademy.com'
    assert extractor._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert extractor._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-22 07:58:54.695410
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.constructor is LinuxAcademyIE

# Generated at 2022-06-22 07:59:27.429241
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie == 'LinuxAcademyIE'
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/' \
        '(?:courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|modules/view/id/(?P<course_id>\\d+))'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-22 07:59:33.308789
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test = LinuxAcademyIE()
    assert test._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert test._ORIGIN_URL == 'https://linuxacademy.com'
    assert test._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert test._NETRC_MACHINE == 'linuxacademy'


# Generated at 2022-06-22 07:59:35.056631
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(LinuxAcademyIE._download_webpage)

# Generated at 2022-06-22 07:59:39.965226
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    u = LinuxAcademyIE()
    assert u._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert u._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-22 07:59:52.015126
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try_get(None, lambda x: x['type']['name'], compat_str)
    module_items = [
        {
            "type": {
                "name": "section"
            }
        },
        {
            "type": {
                "name": "lesson"
            }
        },
        {
            "type": {
                "name": "license"
            }
        }
    ]
    module = {
        "items": module_items
    }
    url = "https://linuxacademy.com/cp/modules/view/id/154"
    playlists = ["https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2"]
    LinuxAcademyIE()._build_playlists(playlists, module)

# Generated at 2022-06-22 07:59:53.921468
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'linuxacademy'

# Generated at 2022-06-22 08:00:03.230234
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info_extractor = LinuxAcademyIE()

    assert info_extractor.IE_NAME == 'linuxacademy'
    assert info_extractor.IE_DESC == 'Linux Academy'
    assert info_extractor._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert info_extractor._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'

# Generated at 2022-06-22 08:00:04.928375
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE._VALID_URL == LinuxAcademyIE._VALID_URL

# Generated at 2022-06-22 08:00:14.820069
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()._real_initialize()
    except ExtractorError as e:
        assert e.msg == 'Linux Academy account credentials are required for accessing course videos. '\
                        'Refer to the "login" and "password" options in the "general" section of the '\
                        'manual.', \
            'LinuxAcademyIE raises ExtractorError when credentials are missing'
    except:
        assert False, 'LinuxAcademyIE raises unknown exception when credentials are missing'
    else:
        assert False, 'LinuxAcademyIE does not raise exception when credentials are missing'

# Generated at 2022-06-22 08:00:17.529957
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert(ie.course_id is None)
    assert(ie.chapter_id is None)
    assert(ie.lecture_id is None)

# Generated at 2022-06-22 08:01:06.806080
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    TestClass = type(
        'TestClass',
        (object,),
        {'_download_webpage': lambda self, url, video_id, note, errnote, fatal: None}
    )
    TestClass = LinuxAcademyIE.create_copy(TestClass)
    TestClass()._real_initialize()

# Generated at 2022-06-22 08:01:09.325108
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE("https://linuxacademy.com/cp/modules/view/id/154")
    assert ie is not None


# Generated at 2022-06-22 08:01:20.246653
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.get_tld() == 'linuxacademy.com'
    assert ie.get_client_id() == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie.get_authorize_url() == 'https://login.linuxacademy.com/authorize'
    assert ie.get_netrc_machine() == 'linuxacademy'
    assert ie.get_origin_url() == 'https://linuxacademy.com'
    assert ie.get_chapter_id(7971, 2) == '7971-2'
    assert ie.get_chapter_id(None, None, '123') == '123'


# Generated at 2022-06-22 08:01:23.449651
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info = LinuxAcademyIE().info_extract("https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675")
    print("Id of the course : {} \nName of course : {} \nNumber of videos : {}".format(info['id'], info['title'], len(info['entries'])))

# Generated at 2022-06-22 08:01:25.436655
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()


# Generated at 2022-06-22 08:01:26.162832
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert True

# Generated at 2022-06-22 08:01:26.772273
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-22 08:01:30.283166
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Constructor without any argument
    instance = LinuxAcademyIE()
    # '_NETRC_MACHINE' and '_CLIENT_ID' attributes must be defined.
    assert instance._NETRC_MACHINE is not None
    assert instance._CLIENT_ID is not None

# Generated at 2022-06-22 08:01:37.976933
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test without credentials
    ie = LinuxAcademyIE()
    assert ie.username is None
    assert ie.password is None

    # Test with credentials
    class TestLinuxAcademyIE(LinuxAcademyIE):
        # Replace the static login method on the class
        # with an instance method for testing
        def _login(self):
            self.username = 'unit'
            self.password = 'test'
    ie = TestLinuxAcademyIE()
    assert ie.username == 'unit'
    assert ie.password == 'test'

# Generated at 2022-06-22 08:01:46.317158
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Check LinuxAcademyIE with valid url
    url = 'https://www.linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    linuxAcademy = LinuxAcademyIE(url)
    # Check LinuxAcademyIE._VALID_URL
    assert linuxAcademy._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    # Check LinuxAcademyIE._NETRC_MACHINE
    assert linuxAcademy._NETRC_MACHINE == 'linuxacademy'
    # Check LinuxAcademyIE.session.headers
    assert linux

# Generated at 2022-06-22 08:03:26.682039
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxAcademyExtractor = LinuxAcademyIE()
    assert linuxAcademyExtractor.IE_NAME == 'LinuxAcademy'
    assert linuxAcademyExtractor.ie_key() == 'LinuxAcademy'
    assert 'LinuxAcademy' in linuxAcademyExtractor._WORKING

# Generated at 2022-06-22 08:03:28.199143
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert linuxacademyIE == LinuxAcademyIE.iekey()


# Generated at 2022-06-22 08:03:30.057565
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-22 08:03:32.291380
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test when no credentials are provided
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)

# Generated at 2022-06-22 08:03:33.833828
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info = LinuxAcademyIE._login()
    assert info is not None


# Generated at 2022-06-22 08:03:38.143581
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'LinuxAcademy'
    assert ie.IE_DESC == 'Linux Academy account'

# Generated at 2022-06-22 08:03:39.869525
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._NETRC_MACHINE == "linuxacademy"

# Generated at 2022-06-22 08:03:46.370528
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Unit test for constructor of class LinuxAcademyIE."""
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    obj = LinuxAcademyIE()
    assert obj.ie_key() == 'LinuxAcademy'
    assert obj.suitable(url) and obj.IE_NAME == 'LinuxAcademy' and obj.WORKING == True and obj._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'
    assert obj._login()

# Generated at 2022-06-22 08:03:49.338459
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

    # Check if the constructed object is instance of InfoExtractor
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 08:03:54.533776
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from linuxacademy_api.api import LinuxAcademyAPIClient
    username, password = LinuxAcademyIE._get_login_info()
    api = LinuxAcademyAPIClient(username, password)
    assert api.course_modules()
    assert api.course_list()['data']