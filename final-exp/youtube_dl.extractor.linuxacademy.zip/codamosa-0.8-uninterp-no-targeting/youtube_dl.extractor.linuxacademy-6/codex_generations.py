

# Generated at 2022-06-22 07:58:15.959841
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from requests import Session
    from nose.tools import assert_equal

    class MySession(Session):
        def __init__(self):
            self.download_page_url = None
            Session.__init__(self)

        def _download_page(self, url, *args, **kwargs):
            self.download_page_url = url

        def get_page_url(self):
            return self.download_page_url

    s = MySession()
    ie = LinuxAcademyIE._get_ie(LinuxAcademyIE.ie_key())(s)
    ie._login()
    assert_equal(s.get_page_url(), ie._ORIGIN_URL)

# Generated at 2022-06-22 07:58:18.059901
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 07:58:25.739356
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test definition of a LinuxAcademyIE object
    test_obj = LinuxAcademyIE()
    # Test initialization of a LinuxAcademyIE object
    assert test_obj._real_initialize() is None
    # Test definition of an extract method of a LinuxAcademyIE object
    assert test_obj.extract('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')['id'] is not None


# Generated at 2022-06-22 07:58:34.399281
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from youtube_dl.downloader.http import HttpFD
    ie = LinuxAcademyIE({})
    assert ie
    assert ie.IE_DESC  == 'LinuxAcademy'
    assert ie.__name__ == 'LinuxAcademy'
    assert ie.ie_key() == 'LinuxAcademy'
    # unit test for _download_webpage
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    hd = HttpFD()
    response = hd.download(url, None)
    assert response
    assert response.code == 200


# Generated at 2022-06-22 07:58:35.569835
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Create a new instance of class LinuxAcademyIE
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-22 07:58:37.779947
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_utils import TestDownloader
    test = TestDownloader()

    test._downloader = LinuxAcademyIE()
    test._downloader._login()

    test.assertTrue(test.test_result['login'])
    test.assertTrue(test.test_result['login_only'])
    test._downloader = None

# Generated at 2022-06-22 07:58:38.377141
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-22 07:58:49.484850
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test LinuxAcademyIE constructor"""
    ie = LinuxAcademyIE('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    assert ie.NAME == 'linuxacademy'
    assert ie.IE_NAME == 'LinuxAcademy'
    assert ie._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|modules/view/id/(?P<course_id>\\d+))'
    assert ie._NETRC_MACHINE == 'linuxacademy'


# Generated at 2022-06-22 07:58:52.276631
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
        assert True
    except:
        assert False


# Generated at 2022-06-22 07:58:53.445846
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()

# Generated at 2022-06-22 07:59:24.625150
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_obj = LinuxAcademyIE()
    assert test_obj.IE_NAME == "linuxacademy"
    assert test_obj.IE_DESC == "LinuxAcademy.com"
    assert test_obj._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'
    assert test_obj._AUTHORIZE_URL == "https://login.linuxacademy.com/authorize"
    assert test_obj._ORIGIN_URL == "https://linuxacademy.com"
    assert test_obj._CLIENT_

# Generated at 2022-06-22 07:59:33.745989
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE._VALID_URL == 'https://linuxacademy.com/cp/courses/lesson/course/{chapter_id}/lesson/{lesson_id}'
    assert LinuxAcademyIE._NETRC_MACHINE == 'linuxacademy'
    assert LinuxAcademyIE._ORIGIN_URL == 'https://linuxacademy.com'
    assert LinuxAcademyIE._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert LinuxAcademyIE._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'

# Generated at 2022-06-22 07:59:35.278242
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('test_user', 'test_pass')

# Generated at 2022-06-22 07:59:37.845066
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    elem = LinuxAcademyIE()
    assert elem.IE_DESC == 'LinuxAcademy'

# Generated at 2022-06-22 07:59:39.148792
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('LinuxAcademy')

# Generated at 2022-06-22 07:59:49.693740
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # pylint: disable=invalid-name
    ie = LinuxAcademyIE()
    # pylint: disable=protected-access
    # LinuxAcademyIE._real_initialize
    ie._real_initialize()
    # LinuxAcademyIE._real_extract
    ie._real_extract('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    ie._real_extract('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    ie._real_extract('https://linuxacademy.com/cp/modules/view/id/154')

# Generated at 2022-06-22 07:59:51.431413
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(None,None,"")
    assert ie is not None

# Generated at 2022-06-22 07:59:56.204755
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    i = LinuxAcademyIE()
    assert i._TESTS == LinuxAcademyIE._TESTS
    assert i._VALID_URL == LinuxAcademyIE._VALID_URL
    assert i._NETRC_MACHINE == LinuxAcademyIE._NETRC_MACHINE

# Generated at 2022-06-22 08:00:00.610313
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        import netrc
    except ImportError:
        return False

    credentials = netrc.netrc().authenticators(LinuxAcademyIE._NETRC_MACHINE)
    if credentials is None:
        return False

    LinuxAcademyIE(test_LinuxAcademyIE.__name__, credentials[0], credentials[1])

# Generated at 2022-06-22 08:00:01.482968
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None)

# Generated at 2022-06-22 08:00:34.968601
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-22 08:00:36.769606
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Unit test for constructor of class LinuxAcademyIE"""
    ie = LinuxAcademyIE()

# Generated at 2022-06-22 08:00:39.735191
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():  # pylint: disable=redefined-outer-name
    """Unit test for LinuxAcademyIE"""
    assert LinuxAcademyIE.__name__ == 'LinuxAcademyIE'

# Generated at 2022-06-22 08:00:41.108637
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-22 08:00:42.098384
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()

# Generated at 2022-06-22 08:00:43.089824
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()

# Generated at 2022-06-22 08:00:45.413162
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-22 08:00:47.242276
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('LinuxAcademy')

# Generated at 2022-06-22 08:00:56.485126
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxAcademy = LinuxAcademyIE()
    assert linuxAcademy._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert linuxAcademy._NETRC_MACHINE == 'linuxacademy'
    assert linuxAcademy._ORIGIN_URL == 'https://linuxacademy.com'
    assert linuxAcademy._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'

# Generated at 2022-06-22 08:01:03.399346
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """ Unit test for class LinuxAcademyIE """
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    assert LinuxAcademyIE().suitable(url)
    assert LinuxAcademyIE()._VALID_URL == LinuxAcademyIE._VALID_URL
    assert LinuxAcademyIE()._TESTS == LinuxAcademyIE._TESTS
    assert LinuxAcademyIE().ie_key() == 'LinuxAcademy'

    i = LinuxAcademyIE(url)
    assert url == i._url
    assert url == i.url

# Generated at 2022-06-22 08:02:26.949085
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    assert re.match(LinuxAcademyIE._VALID_URL, url)

# Generated at 2022-06-22 08:02:32.112599
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == 'https?://(?:www\\.)?linuxacademy\\.com/cp/(?:courses/lesson/course/(?:\\d+)/lesson/(?:\\d+)|modules/view/id/(?:\\d+))'

# Generated at 2022-06-22 08:02:34.245304
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-22 08:02:35.237969
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()


# Generated at 2022-06-22 08:02:41.627283
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Instantiate the class with valid params
    inst = LinuxAcademyIE(id='test',title='test',url="https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675",
                          chapter_id='7971',lecture_id='2')
    # Check the init works as expected

# Generated at 2022-06-22 08:02:43.764282
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == LinuxAcademyIE.ie_key()

# Generated at 2022-06-22 08:02:47.160346
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    if ie._login() is not None:
        raise AssertionError('Login failed')
    assert ie.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-22 08:02:47.776890
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-22 08:02:49.655458
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 08:02:59.571019
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    IE = LinuxAcademyIE()
    assert(IE._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)')
    assert(IE._NETRC_MACHINE == 'linuxacademy')
    assert(IE._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize')
    assert(IE._ORIGIN_URL == 'https://linuxacademy.com')
    assert(IE._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx')
main()

# Generated at 2022-06-22 08:06:39.330955
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # set up the request URL
    url = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
    login_info = ('test_username', 'test_password')
    ie = LinuxAcademyIE(url, login_info)
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-22 08:06:48.405531
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(
        LinuxAcademyIE.create_ie(),
        'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
        {'username': 'nobody', 'password': 'pass'},
    )
    assert (ie.url == 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    assert (ie.login_info == {'username': 'nobody', 'password': 'pass'})

# Generated at 2022-06-22 08:06:49.325447
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None)

# Generated at 2022-06-22 08:06:56.526232
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'

# Generated at 2022-06-22 08:06:57.912335
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    raise RuntimeError('Unit test not available.')


# Generated at 2022-06-22 08:07:05.461045
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE._AUTHORIZE_URL >= 'https://login.linuxacademy.com/authorize'
    assert LinuxAcademyIE._ORIGIN_URL >= 'https://linuxacademy.com'
    assert LinuxAcademyIE._CLIENT_ID >= 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert LinuxAcademyIE._NETRC_MACHINE >= 'linuxacademy'
    

# Generated at 2022-06-22 08:07:06.608783
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None)


# Generated at 2022-06-22 08:07:07.743277
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert isinstance(LinuxAcademyIE(''), object)

# Generated at 2022-06-22 08:07:08.960868
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-22 08:07:18.991295
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    def run(url, login_status, match_regex):
        ie = LinuxAcademyIE(url)

        ie._login = lambda *a, **k: None

        if login_status == 'not':
            assert ie._real_initialize() == False
        elif login_status == 'succeed':
            ie._real_initialize()
            assert re.match(match_regex, ie._download_webpage('https://linuxacademy.com/cp/dashboard/view'))
        else:
            try:
                assert ie._real_initialize() == False
            except ExtractorError:
                pass
