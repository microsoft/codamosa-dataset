

# Generated at 2022-06-22 07:58:07.314364
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # constructor that support username and password
    assert LinuxAcademyIE(None, {'username': 'example@mail.com', 'password': 'password'})

# Generated at 2022-06-22 07:58:16.849602
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test OpenEdxIE
    test_ie_instance = LinuxAcademyIE()
    assert test_ie_instance._NETRC_MACHINE == 'linuxacademy'
    assert test_ie_instance._VALID_URL is not None
    assert test_ie_instance._NETRC_MACHINE is not None
    assert test_ie_instance._CLIENT_ID is not None
    assert test_ie_instance._AUTHORIZE_URL is not None
    assert test_ie_instance._ORIGIN_URL is not None
    assert test_ie_instance._TESTS is not None

# Generated at 2022-06-22 07:58:18.590298
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    global instance

    instance = LinuxAcademyIE()


# Generated at 2022-06-22 07:58:19.379128
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Constructor has no return value
    LinuxAcademyIE('LinuxAcademy')

# Generated at 2022-06-22 07:58:19.968360
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 07:58:23.371302
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print('Testing LinuxAcademyIE constructor')
    obj = LinuxAcademyIE()
    assert isinstance(obj, LinuxAcademyIE)
    assert obj.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-22 07:58:25.639381
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie_instance = LinuxAcademyIE()
    ie_instance._real_initialize()
    assert ie_instance._login

# Generated at 2022-06-22 07:58:30.054701
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    temp_test_LinuxAcademyIE = LinuxAcademyIE
    del LinuxAcademyIE
    try:
        LinuxAcademyIE()
        # Test implicitly calls __init__()
    except NameError:
        LinuxAcademyIE = temp_test_LinuxAcademyIE
        return
    raise Exception

# Generated at 2022-06-22 07:58:39.821337
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info_extractor = LinuxAcademyIE()
    assert info_extractor == LinuxAcademyIE.ie_key()
    assert info_extractor == LinuxAcademyIE.ie_key()
    assert info_extractor == LinuxAcademyIE.ie_key()
    assert info_extractor == LinuxAcademyIE.ie_key()
    assert info_extractor == LinuxAcademyIE.ie_key()
    assert info_extractor == LinuxAcademyIE.ie_key()
    assert info_extractor == LinuxAcademyIE.ie_key()
    assert info_extractor == LinuxAcademyIE.ie_key()
    assert info_extractor == LinuxAcademyIE.ie_key()
    assert info_extractor == LinuxAcademyIE.ie_key()
    assert info_extractor

# Generated at 2022-06-22 07:58:47.641630
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj_linuxAcademyIE = LinuxAcademyIE(None)
    print("Testing constructor of class LinuxAcademyIE")
    if isinstance(obj_linuxAcademyIE, LinuxAcademyIE):
        print("Yes object of class LinuxAcademyIE is created")
    else:
        print("Failed to create object of class LinuxAcademyIE")
        raise AssertionError("Failed to create object of class LinuxAcademyIE")

# Generated at 2022-06-22 07:59:29.685798
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert LinuxAcademyIE.ie_key() == 'linuxacademy'
    assert LinuxAcademyIE.ie_name() == 'LinuxAcademy'
    assert LinuxAcademyIE.ie_version() == '1.1.1'
    assert LinuxAcademyIE._VALID_URL() == ''
    assert LinuxAcademyIE._AUTHORIZE_URL() == ''
    assert LinuxAcademyIE._ORIGIN_URL() == ''
    assert LinuxAcademyIE._CLIENT_ID() == ''
    assert LinuxAcademyIE._NETRC_MACHINE() == 'linuxacademy'


# Generated at 2022-06-22 07:59:40.324597
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Unit test for LinuxAcademyIE"""

    # Declaring the instance variables
    linuxAcademyIE = LinuxAcademyIE(None)

    # Asserting the values
    assert linuxAcademyIE._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert linuxAcademyIE._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'

# Generated at 2022-06-22 07:59:44.140095
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    LinuxAcademyIE(InfoExtractor())._real_extract(url)

# Generated at 2022-06-22 07:59:56.303355
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():

    name = LinuxAcademyIE.ie_key()
    # Create and return an instance of the class
    obj = LinuxAcademyIE()
    assert obj is not None
    # Check for the expected methods
    assert hasattr(obj, '_login')
    assert hasattr(obj, '_real_extract')
    assert hasattr(obj, 'IE_NAME')
    assert hasattr(obj, '_VALID_URL')
    assert hasattr(obj, '_TEST')
    assert hasattr(obj, '_AUTHORIZE_URL')
    assert hasattr(obj, '_ORIGIN_URL')
    assert hasattr(obj, '_CLIENT_ID')
    assert hasattr(obj, '_NETRC_MACHINE')
    assert name == 'linuxacademy'

# Generated at 2022-06-22 07:59:58.221903
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    x = LinuxAcademyIE()
    print(x)

# Generated at 2022-06-22 08:00:03.071441
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE('No URL')
    except:
        print ('Invalid url error')
    try:
        LinuxAcademyIE('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    except:
        print ('Valid url error')


# Generated at 2022-06-22 08:00:14.768274
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from youtube_dl.YoutubeDL import YoutubeDL
    from pprint import pprint

    # test case: normal course
    print("* Testing normal LinuxAcademyIE course *")
    ydl = YoutubeDL({'username': '', 'password': ''})
    # run course test
    ydl.download(['https://linuxacademy.com/cp/modules/view/id/154'])

    # test case: individual lecture
    print("* Testing single lecture of LinuxAcademyIE course *")
    ydl = YoutubeDL({'username': '', 'password': ''})
    # run lecture test
    ydl.download(['https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'])

# Generated at 2022-06-22 08:00:26.128185
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_ie = LinuxAcademyIE()
    assert test_ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert test_ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert test_ie._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-22 08:00:26.877778
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    _ = LinuxAcademyIE

# Generated at 2022-06-22 08:00:30.745043
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-22 08:01:59.187782
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie,InfoExtractor)
    assert ie.IE_NAME == 'linuxacademy'

# Generated at 2022-06-22 08:02:00.642889
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('LinuxAcademyIE', 'LinuxAcademyIE')

# Generated at 2022-06-22 08:02:02.642064
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    result = ie._real_initialize()
    assert result is None

# Generated at 2022-06-22 08:02:09.606339
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert(ie.IE_NAME)
    assert(ie.IE_DESC)
    assert(ie._VALID_URL)
    assert(ie._TESTS)
    assert(ie._NETRC_MACHINE)
    assert(ie._AUTHORIZE_URL)
    assert(ie._ORIGIN_URL)
    assert(ie._CLIENT_ID)

# Generated at 2022-06-22 08:02:11.448136
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()._login()

# Generated at 2022-06-22 08:02:17.289861
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    example = LinuxAcademyIE()
    assert example._TESTS[0]['url'] == example._VALID_URL
    assert example._NETRC_MACHINE == 'linuxacademy'
    assert example._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-22 08:02:18.866031
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # created test case
    LinuxAcademyIE(None)

# Generated at 2022-06-22 08:02:23.837467
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    inputURL = "https://linuxacademy.com/cp/modules/view/id/154"

    assert inputURL == LinuxAcademyIE._VALID_URL
    assert 'LinuxAcademy' == LinuxAcademyIE._NETRC_MACHINE

# Generated at 2022-06-22 08:02:24.968069
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # TODO: Check if constructor does not throw an exception
    Firefox()


# Generated at 2022-06-22 08:02:27.688969
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.login_data is not None
    print('Test LinuxAcademyIE constructor passed!')


# Generated at 2022-06-22 08:06:02.790696
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('LinuxAcademyIE')

# Generated at 2022-06-22 08:06:04.286125
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert isinstance(LinuxAcademyIE(), InfoExtractor)

# Generated at 2022-06-22 08:06:06.771163
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    item = LinuxAcademyIE()
    assert item is not None


# Generated at 2022-06-22 08:06:17.040379
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # test with valid urls
    LinuxAcademyIE().test_video_urls(
        r'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    LinuxAcademyIE().test_video_urls(
        r'https://linuxacademy.com/cp/modules/view/id/154')
    LinuxAcademyIE().test_video_urls(
        r'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    # test with invalid urls
    LinuxAcademyIE().test_video_urls(
        r'https://linuxacademy.com/cp/courses')

# Generated at 2022-06-22 08:06:19.121319
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert(LinuxAcademyIE.ie_key() is not None)


# Generated at 2022-06-22 08:06:20.858080
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    '''
    Unit class test for constructor of class LinuxAcademyIE.
    '''
    LinuxAcademyIE('some/url')

# Generated at 2022-06-22 08:06:21.854833
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    print(ie)

# Generated at 2022-06-22 08:06:23.886373
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 08:06:27.192983
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_object = LinuxAcademyIE(None)
    assert test_object._AUTHORIZE_URL == "https://login.linuxacademy.com/authorize"

# Generated at 2022-06-22 08:06:37.307395
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie._VALID_URL == 'https?://(?:www\\.)?linuxacademy\\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|modules/view/id/(?P<course_id>\\d+))'