

# Generated at 2022-06-22 07:58:09.931679
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
    except TypeError:
        assert(False)
    return

# Generated at 2022-06-22 07:58:11.475851
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE

# Generated at 2022-06-22 07:58:13.900092
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    js_tester = LinuxAcademyIE(None)
    js_tester._login()

# Generated at 2022-06-22 07:58:21.756615
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._NETRC_MACHINE == 'linuxacademy'
    assert LinuxAcademyIE()._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert LinuxAcademyIE()._ORIGIN_URL == 'https://linuxacademy.com'
    assert isinstance(LinuxAcademyIE()._VALID_URL, str)

# Generated at 2022-06-22 07:58:24.810080
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Basic test for constructor of class LinuxAcademyIE
    """
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-22 07:58:37.040692
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test case:
    # 1. Check if the correct class instance is being returned on class initialization.
    # 2. Check if the login credentials are set correctly.
    # 3. Check if the necessary login credentials are present for an account.
    # 4. Check if the headers are set correctly.
    import sys
    import os
    from netrc import netrc
    from .common import HttpDummyServer

    os.environ['HOME'] = os.path.curdir
    for arg in sys.argv:
        if arg.startswith('--username='):
            username = arg[len('--username='):].replace('"', '')
            break
    else:
        username = None
    password = None

    # netrc file
    # Test run #1
    test_netrc = netrc()
    test_netrc

# Generated at 2022-06-22 07:58:44.643281
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_instance = LinuxAcademyIE()
    assert test_instance is not None
    # _AUTHORIZE_URL
    assert test_instance._AUTHORIZE_URL is not None
    # _ORIGIN_URL
    assert test_instance._ORIGIN_URL is not None
    # _CLIENT_ID
    assert test_instance._CLIENT_ID is not None
    # _NETRC_MACHINE
    assert test_instance._NETRC_MACHINE is not None

# Generated at 2022-06-22 07:58:46.418803
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)

# Generated at 2022-06-22 07:58:58.482923
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2
    # https://linuxacademy.com/cp/modules/view/id/154
    # https://github.com/rg3/youtube-dl/pull/19090/files
    # test for case of getting the video from the playlist
    item_info = LinuxAcademyIE._real_extract('https://linuxacademy.com/cp/modules/view/id/154')
    assert item_info['_type'] == 'playlist'
    assert 'id' in item_info
    assert 'title' in item_info
    assert 'description' in item_info
    assert 'duration' in item_info
    assert item_info['duration'] == 28835

# Generated at 2022-06-22 07:58:59.505690
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 07:59:19.658405
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 07:59:31.789298
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    class TestLinuxAcademyIE(LinuxAcademyIE):
        def _login(self):
            pass

    import os
    import tempfile
    from ..utils import make_temp_file
    from ..compat import is_py2

    if is_py2:
        from urlparse import urlparse
    else:
        from urllib.parse import urlparse

    # create fake unit tests

# Generated at 2022-06-22 07:59:42.669022
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Unit test for initializing class LinuxAcademyIE with url parameter
    """
    url = "https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675"
    ie = LinuxAcademyIE(url)
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-22 07:59:43.807424
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 07:59:51.431772
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_cases = [
        'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675',
        'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2',
        'https://linuxacademy.com/cp/modules/view/id/154',
    ]

    for test_case in test_cases:
        LinuxAcademyIE()

# Generated at 2022-06-22 07:59:52.541367
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 07:59:54.454965
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('LinuxAcademy', 'linuxacademy')

# Generated at 2022-06-22 07:59:55.591025
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()



# Generated at 2022-06-22 08:00:00.599064
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # The random tokens generated by random_string() should all be
    # different. Check this, just in case.
    token_set = set()
    for i in range(10):
        i = LinuxAcademyIE()
        token_set.add(i._random_string())
    assert len(token_set) == 10

# Generated at 2022-06-22 08:00:04.502037
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE('LinuxAcademy', 'http://www.linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    info = ie._real_initialize()
    print(info)
    assert ie._download_webpage

# Generated at 2022-06-22 08:00:44.620908
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE(None, None)._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-22 08:00:47.433356
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
    except:
        pass

# Generated at 2022-06-22 08:00:48.946933
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademy_ie = LinuxAcademyIE()._real_initialize()

# Generated at 2022-06-22 08:00:53.820688
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE('khanacademy', r'https://khanacademy.org/test/test_video_id')
    assert ie._NETRC_MACHINE == 'khanacademy'
    assert ie._VALID_URL == r'https?://(?:www\.)?khanacademy\.org/test/test_video_id'

# Generated at 2022-06-22 08:00:56.390903
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE()
        assert False
    except TypeError as e:
        assert e.message == 'LinuxAcademyIE needs at least one URL to extract.'

# Generated at 2022-06-22 08:01:03.200288
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_case import TestCase
    ie = TestCase.create_instance_of(TestCase, LinuxAcademyIE,
                                     'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    ie.initialize()
    assert ie._login() is None

    ie = TestCase.create_instance_of(TestCase, LinuxAcademyIE, 'https://linuxacademy.com/cp/modules/view/id/154')
    ie.initialize()
    assert ie._login() is None

# Generated at 2022-06-22 08:01:04.839115
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.username is None
    assert ie.password is None

# Generated at 2022-06-22 08:01:16.464065
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info_extractor = LinuxAcademyIE()
    assert info_extractor.ie_key() == 'LinuxAcademy'
    assert info_extractor.TITLE == 'LinuxAcademy'
    assert info_extractor._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert info_extractor._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert info_extractor._ORIGIN_URL

# Generated at 2022-06-22 08:01:20.330709
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    print(ie)
    assert(ie._login() == None)

# Generated at 2022-06-22 08:01:21.585516
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'LinuxAcademy'

# Generated at 2022-06-22 08:02:49.790802
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ex = LinuxAcademyIE()
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    assert ex.ie_key() == 'LinuxAcademy'
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'
    assert LinuxAcademyIE.suitable(url)
    assert LinuxAcademyIE.suitable(url) == True
    assert ex.suitable(url) == True
    assert ex._VALID_URL == LinuxAcademyIE._VALID_URL

# Generated at 2022-06-22 08:02:59.363565
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    print("Testing class LinuxAcademyIE")
    assert getattr(LinuxAcademyIE, '_AUTHORIZE_URL', None) == 'https://login.linuxacademy.com/authorize'
    assert getattr(LinuxAcademyIE, '_ORIGIN_URL', None) == 'https://linuxacademy.com'
    assert getattr(LinuxAcademyIE, '_CLIENT_ID', None) == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert getattr(LinuxAcademyIE, '_NETRC_MACHINE', None) == 'linuxacademy'

    print("Done testing class LinuxAcademyIE")


# Generated at 2022-06-22 08:03:05.853192
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE(None)
    assert obj._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert obj._ORIGIN_URL == 'https://linuxacademy.com'
    assert obj._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert obj._NETRC_MACHINE == 'linuxacademy'


# Generated at 2022-06-22 08:03:06.735884
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 08:03:08.877157
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.server_id() == 'login.linuxacademy.com'

# Generated at 2022-06-22 08:03:16.208141
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    with open('test-data/LinuxAcademy/test_LinuxAcademyIE_constructor.json', 'r') as f:
        config = json.loads(f.read())

    ie = LinuxAcademyIE()
    assert ie.client_id == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie.origin_url == 'https://linuxacademy.com'
    assert ie.authorize_url == 'https://login.linuxacademy.com/authorize'
    assert ie.netrc_machine == 'linuxacademy'

    config['client_id'] = 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-22 08:03:23.714946
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    constructor_test_base(
        LinuxAcademyIE,
        [
            # Test with lesson url
            'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2',
            # Test with chapter url
            'https://linuxacademy.com/cp/modules/view/id/154',
            # Test with invalid url
            'https://linuxacademy.com/cp/modules/view/id/invalid'
        ])

# Generated at 2022-06-22 08:03:27.554095
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE(None)._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'


# Generated at 2022-06-22 08:03:36.804921
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    page1 = get_test_data('test_course_path')
    page2 = get_test_data('test_single_lesson_path')
    course_data = LinuxAcademyIE._parse_json(LinuxAcademyIE._search_regex(r'window\.module\s*=\s*({.+?})\s*;', page1, 'module'), '154')
    lesson_data = LinuxAcademyIE._parse_json(LinuxAcademyIE._search_regex((r'window\.lesson\s*=\s*({.+?})\s*;', r'player\.lesson\s*=\s*({.+?})\s*;'), page2, 'lesson', default='{}'), '26474-2', fatal=False)

    # Unit test for parsing of course path

# Generated at 2022-06-22 08:03:38.213576
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    i = LinuxAcademyIE()

# Generated at 2022-06-22 08:07:13.307567
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-22 08:07:16.535618
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """ Unit test for constructor of class LinuxAcademyIE """
    assert(LinuxAcademyIE.ie_key() == 'LinuxAcademy')
    instance = LinuxAcademyIE()
    assert(instance.ie_key() == 'LinuxAcademy')

# Generated at 2022-06-22 08:07:21.396524
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert(LinuxAcademyIE()._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx')
    assert(LinuxAcademyIE()._NETRC_MACHINE == 'linuxacademy')
    assert(LinuxAcademyIE()._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize')
    assert(LinuxAcademyIE()._ORIGIN_URL == 'https://linuxacademy.com')

# Generated at 2022-06-22 08:07:22.957642
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    ie.extract()

# Generated at 2022-06-22 08:07:25.220528
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .common import test_login
    test_login(LinuxAcademyIE)

# Generated at 2022-06-22 08:07:34.606060
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
  url = 'https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2'
  LinuxAcademyIE().suitable(url)
  m = re.match(LinuxAcademyIE._VALID_URL, url)
  chapter_id = m.group('chapter_id')
  lecture_id = m.group('lesson_id')
  course_id = m.group('course_id')
  assert (chapter_id == '1498' and course_id == None and lecture_id == '2')

# Generated at 2022-06-22 08:07:35.125386
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-22 08:07:35.915471
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 08:07:37.291175
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('linuxacademy')

# Generated at 2022-06-22 08:07:38.315860
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()