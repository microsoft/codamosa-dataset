

# Generated at 2022-06-22 07:58:13.423002
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademyIE = LinuxAcademyIE()
    linuxacademyIE.initialize()
    linuxacademyIE.login()
   
test_LinuxAcademyIE()

# Generated at 2022-06-22 07:58:23.931625
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .. import LinuxAcademyIE
    assert LinuxAcademyIE.IE_NAME == 'linuxacademy'
    assert LinuxAcademyIE.IE_DESC == 'Linux Academy'
    assert LinuxAcademyIE.VALID_URL == LinuxAcademyIE._VALID_URL

# Generated at 2022-06-22 07:58:35.958883
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/\n                            (?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))\n                        '

# Generated at 2022-06-22 07:58:39.785428
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test for constructor of class LinuxAcademyIE"""
    # Call constructor of LinuxAcademyIE
    ie = LinuxAcademyIE()
    # Check if instance of LinuxAcademyIE
    assert isinstance(ie, LinuxAcademyIE)
    # Check instance of InfoExtractor
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-22 07:58:51.461558
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Purpose: To make sure we can create a LinuxAcademyIE object using it's required parameters as well as optional parameters
    Preconditions: None
    Test Steps:
        1. Create LinuxAcademyIE object using the required parameters
        2. Make sure the object is created correctly
    Assertions:
        1. The LinuxAcademyIE object should be created correctly with required parameters and additional optional parameters
        """
    ie = LinuxAcademyIE()
    assert(ie.ie_key() == "LinuxAcademy")
    assert(ie.IE_NAME == "linuxacademy")

# Generated at 2022-06-22 07:58:53.182966
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()._LOGIN_REQUIRED


# Generated at 2022-06-22 07:58:54.592046
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE().test()

# Generated at 2022-06-22 07:58:55.615301
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 07:59:05.006118
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    inst = LinuxAcademyIE(None)
    assert inst.get_url() == ''
    assert inst.ie_key() == 'LinuxAcademy'
    assert inst.ie_name() == 'LinuxAcademy'
    assert inst.get_host_from_url() == 'linuxacademy.com'
    assert inst.get_username_from_url() == ''
    assert inst.get_password_from_url() == ''
    assert inst.get_video_id_regex() == r'(?x) https?:// (?:www\.)?linuxacademy\.com/cp/ (?: courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)| modules/view/id/(?P<course_id>\d+) )'


# Generated at 2022-06-22 07:59:07.482979
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE('LinuxAcademy')
    assert ie.IE_NAME == 'LinuxAcademy'

# Generated at 2022-06-22 07:59:28.268432
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test constructor of class LinuxAcademy
    ie = LinuxAcademyIE()
    assert ie is not None

# Generated at 2022-06-22 07:59:29.002583
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    mytest = LinuxAcademyIE()


# Generated at 2022-06-22 07:59:30.022984
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)

# Generated at 2022-06-22 07:59:36.565797
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test a course in form of playlist
    course = LinuxAcademyIE().url_result('https://linuxacademy.com/cp/modules/view/id/154')
    assert course.title == 'AWS Certified Cloud Practitioner'
    assert course.duration == 28835
    assert course.description == 'md5:a68a299ca9bb98d41cca5abc4d4ce22c'
    assert course.id == '154'
    assert isinstance(course.entries, list)

# Generated at 2022-06-22 07:59:38.095209
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie is not None

# Generated at 2022-06-22 07:59:43.337674
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxAcademy = LinuxAcademyIE()
    assert linuxAcademy._VALID_URL == r'(?x)https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'

# Generated at 2022-06-22 07:59:44.608750
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 07:59:46.522050
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert 'LinuxAcademy' in LinuxAcademyIE.ie_key()

# Generated at 2022-06-22 07:59:57.997710
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test constructor of class LinuxAcademyIE"""
    _test_LinuxAcademyIE = LinuxAcademyIE('https://linuxacademy.com/cp/modules/view/id/154')
    assert _test_LinuxAcademyIE._VALID_URL == r'''(?x)
                                                https?://
                                                    (?:www\.)?linuxacademy\.com/cp/
                                                    (?:
                                                        courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                                                        modules/view/id/(?P<course_id>\d+)
                                                    )
                                                '''
    assert _test_LinuxAcademyIE._NETRC_MACHINE == 'linuxacademy'
   

# Generated at 2022-06-22 08:00:06.313506
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    download_url = "https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675"
    expected_output = {
        'id': '7971-2',
        'ext': 'mp4',
        'title': 'What Is Data Science',
        'description': 'md5:c574a3c20607144fb36cb65bdde76c99',
        'timestamp': 1607387907,
        'upload_date': '20201208',
        'duration': 304
    }

    extracted_output = LinuxAcademyIE()._real_extract({'url': download_url})

    assert extracted_output == expected_output


# Generated at 2022-06-22 08:00:45.818813
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Test for constructor of class LinuxAcademyIE"""
    instance = LinuxAcademyIE()
    assert instance is not None

# Generated at 2022-06-22 08:00:49.301292
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxAcademy_ie = LinuxAcademyIE({
        'username': 'user',
        'password': 'pwd',
    })
    assert isinstance(linuxAcademy_ie, LinuxAcademyIE)

# Generated at 2022-06-22 08:00:50.627892
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 08:00:52.017444
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()._real_initialize()

# Generated at 2022-06-22 08:00:53.471323
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE.LinuxAcademyIE(None, {}, {}, None)._login()

# Generated at 2022-06-22 08:00:56.756384
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
  test1 = LinuxAcademyIE()
  assert isinstance(test1, LinuxAcademyIE)
  # Unit test for _real_initialize
  test2 = test1._real_initialize()
  assert test2 == None

# Generated at 2022-06-22 08:01:02.790063
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(None)
    assert ie.IE_NAME == 'LinuxAcademy'
    assert ie.NETRC_MACHINE == 'linuxacademy'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-22 08:01:04.035834
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Verify that the class is actually constructed
    LinuxAcademyIE(InfoExtractor())

# Generated at 2022-06-22 08:01:04.863510
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 08:01:05.702965
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 08:02:33.512451
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE();
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.ie_name() == 'LinuxAcademy'

# Generated at 2022-06-22 08:02:34.908937
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'linuxacademy'


# Generated at 2022-06-22 08:02:39.888999
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == LinuxAcademyIE._VALID_URL
    assert ie._AUTHORIZE_URL == LinuxAcademyIE._AUTHORIZE_URL
    assert ie._ORIGIN_URL == LinuxAcademyIE._ORIGIN_URL
    assert ie._CLIENT_ID == LinuxAcademyIE._CLIENT_ID
    assert ie._NETRC_MACHINE == LinuxAcademyIE._NETRC_MACHINE

# Generated at 2022-06-22 08:02:42.061201
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 08:02:45.610992
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Success with valid login credentials.
    IE = LinuxAcademyIE(username="foo", password="bar")
    assert hasattr(IE, "username")
    assert IE.username == "foo"
    assert hasattr(IE, "password")
    assert IE.password == "bar"

# Generated at 2022-06-22 08:02:47.158267
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE("test_LinuxAcademyIE")

# Generated at 2022-06-22 08:02:51.180327
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = "https://linuxacademy.com/cp/modules/view/id/154"
    result = LinuxAcademyIE()
    result._real_extract(url)
    return result

# Generated at 2022-06-22 08:03:01.638388
# Unit test for constructor of class LinuxAcademyIE

# Generated at 2022-06-22 08:03:06.990991
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    testcase_LinuxAcademyIE_course = LinuxAcademyIE._TESTS[2]
    assert testcase_LinuxAcademyIE_course['url'] == \
        testcase_LinuxAcademyIE_course['info_dict']['id'] == '154'

    testcase_LinuxAcademyIE_video = LinuxAcademyIE._TESTS[0]
    assert testcase_LinuxAcademyIE_video['url'] == \
        testcase_LinuxAcademyIE_video['info_dict']['id'] == '7971-2'

# Generated at 2022-06-22 08:03:13.240533
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    test1 = LinuxAcademyIE()
    test1.test_login = False
    test1.to_screen(url)
    mobj = re.match(test1._VALID_URL, url)
    chapter_id, lecture_id, course_id = mobj.group('chapter_id', 'lesson_id', 'course_id')
    item_id = course_id if course_id else '%s-%s' % (chapter_id, lecture_id)

# Generated at 2022-06-22 08:06:57.907918
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

test_LinuxAcademyIE()

# Generated at 2022-06-22 08:06:59.898622
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie



# Generated at 2022-06-22 08:07:02.067567
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 08:07:07.154591
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-22 08:07:08.432558
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None)

# Generated at 2022-06-22 08:07:10.249611
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_obj = LinuxAcademyIE(False)
    assert test_obj.__class__.__name__ == "LinuxAcademyIE"

# Generated at 2022-06-22 08:07:14.763201
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    new_instance = LinuxAcademyIE()
    assert new_instance.suitable('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    assert new_instance.suitable('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    assert new_instance.suitable('https://linuxacademy.com/cp/modules/view/id/154')
    assert new_instance.IE_NAME == 'LinuxAcademy'

# Generated at 2022-06-22 08:07:17.109820
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.ie_key() in LinuxAcademyIE.ie_key()

# Generated at 2022-06-22 08:07:28.746224
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-22 08:07:38.487345
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'
    assert ie.IE_NAME == 'LinuxAcademy'
    assert ie.PREFERRED_ENCODING == 'utf-8'
    assert ie.TEST_URL == 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    assert ie.VALID_URL == '(?x)https?://(?:www\\.)?linuxacademy\\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)|modules/view/id/(?P<course_id>\\d+))'