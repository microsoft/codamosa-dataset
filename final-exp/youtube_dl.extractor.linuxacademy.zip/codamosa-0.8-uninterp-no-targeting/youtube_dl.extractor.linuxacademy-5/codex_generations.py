

# Generated at 2022-06-22 07:58:07.651101
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    raise NotImplementedError

# Generated at 2022-06-22 07:58:12.515184
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademy = LinuxAcademyIE('LinuxAcademy')
    assert linuxacademy._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-22 07:58:17.880604
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        from .netrc_login_info import _LOGIN_INFO
        username, password = _LOGIN_INFO['linuxacademy.com']
    except (ImportError, KeyError) as e:
        raise ImportError('You need to be logged in to linuxacademy.com to download videos')
    ie = LinuxAcademyIE({'username': username, 'password': password})
    ie._login()
    assert(ie.username == username and ie.password == password)
    assert(ie.username and ie.password)



# Generated at 2022-06-22 07:58:20.509425
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'linuxacademy'
    assert LinuxAcademyIE.ie_key() in LinuxAcademyIE._ies



# Generated at 2022-06-22 07:58:22.856732
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # call LinuxAcademyIE constructor
    ie = LinuxAcademyIE()


# Generated at 2022-06-22 07:58:26.180146
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    global LinuxAcademyIE
    LinuxAcademyIE("https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675")

# Generated at 2022-06-22 07:58:36.059508
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.IE_DESC == 'LinuxAcademy'
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CL

# Generated at 2022-06-22 07:58:47.174242
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie.IE_DESC == 'linuxacademy'
    assert ie._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'

# Generated at 2022-06-22 07:58:59.255279
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test for _login function
    # With adding test for the method _download_webpage_handle to extract the response headers
    # and check if the Authorization header is added
    i = LinuxAcademyIE()
    video_url = "https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675"
    username = "TestUsername"
    password = "TestPassword"
    i.username = username
    i.password = password
    webpage = i._download_webpage(video_url, None)
    webpage, urlh = i._download_webpage_handle(video_url, None, 'Downloading authorize page')

# Generated at 2022-06-22 07:59:01.343766
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie is not None and ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-22 07:59:32.277574
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    '''
    Unit test for constructor of class LinuxAcademyIE

    Tests for class LinuxAcademyIE are placed here as of now.
    The test case is a single video from the course "AWS Certified Developer-Associate"
    which is available at this link:
    https://linuxacademy.com/cp/courses/lesson/course/1347/lesson/8/module/1030
    '''
    LA = LinuxAcademyIE()
    LA._login()
    LA.url = 'https://linuxacademy.com/cp/courses/lesson/course/1347/lesson/8/module/1030'
    r = LA._real_extract(LA.url)
    assert r['id'] == '1347-8'
    assert r['title'] == 'AWS SQS'


# Generated at 2022-06-22 07:59:34.915005
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .ka_courses_list import LinuxAcademyCoursesListIE
    LinuxAcademyCoursesListIE(None)

# Generated at 2022-06-22 07:59:39.756161
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        LinuxAcademyIE(None, None)
    except NameError as e:
        if e.message == "'LinuxAcademyIE' is not defined":
            raise NameError('LinuxAcademyIE not defined')
        else:
            raise e

# Generated at 2022-06-22 07:59:44.694160
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Run test for class LinuxAcademyIE
    """
    try:
        from .linuxacademy import LinuxAcademyIE
        from .common import InfoExtractor
    except:
        from .linuxacademy import LinuxAcademyIE
        from .common import InfoExtractor
    obj = LinuxAcademyIE('test_LinuxAcademyIE')
    assert(obj.test('test'))
    return True

if '__main__' == __name__:
    if True == test_LinuxAcademyIE():
        print('LinuxAcademyIE tested')
    else:
        print('LinuxAcademyIE test failed')

# Generated at 2022-06-22 07:59:46.641357
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    obj._login()

# Generated at 2022-06-22 07:59:52.814871
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxAcademy = LinuxAcademyIE()
    assert linuxAcademy._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert linuxAcademy._ORIGIN_URL == 'https://linuxacademy.com'
    assert linuxAcademy._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-22 07:59:58.574873
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test Login and extract
    try:
        LinuxAcademyIE._download_webpage('https://linuxacademy.com/cp/modules/view/id/154')
    except ExtractorError as e:
        if isinstance(e.cause, compat_HTTPError) and e.cause.code == 401:
            pass
        else:
            raise

# Generated at 2022-06-22 08:00:07.108314
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test class exists
    assert LinuxAcademyIE is not None
    # Test we can generate class
    assert LinuxAcademyIE is not None
    # Test isinstance to check class is correct type
    assert isinstance(LinuxAcademyIE(), LinuxAcademyIE)
    # Test login is a method
    assert callable(LinuxAcademyIE._login)
    # Test login method exists
    assert LinuxAcademyIE._login is not None
    # Test login is callable
    assert callable(LinuxAcademyIE._login)
    # Test login does not return None
    assert LinuxAcademyIE._login() is not None
    # Test login returns a string
    assert isinstance(LinuxAcademyIE._login(), str)
    # Test _real_initialize is callable

# Generated at 2022-06-22 08:00:08.945765
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie != None

# Generated at 2022-06-22 08:00:10.873155
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_LinuxAcademyIE = LinuxAcademyIE()
    print(test_LinuxAcademyIE._login())

# Generated at 2022-06-22 08:00:56.827265
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    sub_test_models = {
        '_AUTHORIZE_URL': 'https://login.linuxacademy.com/authorize',
        '_ORIGIN_URL': 'https://linuxacademy.com',
        '_CLIENT_ID': 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx',
        '_NETRC_MACHINE': 'linuxacademy',
        '_VALID_URL': 'https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'
    }
    LinuxAcademyIE

# Generated at 2022-06-22 08:00:58.818758
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE().to_screen('b')

# Generated at 2022-06-22 08:01:08.468386
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Create test instance of LinuxAcademyIE
    ie = LinuxAcademyIE()
    # Test if 'Linux Academy' is in LinuxAcademyIE.ie_key()
    assert ie.IE_NAME in ie.ie_key()
    # Test if LinuxAcademyIE has output formats
    assert ie._VALID_URL == ie.VALID_URL
    assert ie._TESTS == ie.TESTS
    assert ie._AUTHORIZE_URL == ie.AUTHORIZE_URL
    assert ie._ORIGIN_URL == ie.ORIGIN_URL
    assert ie._CLIENT_ID == ie.CLIENT_ID
    assert ie._NETRC_MACHINE == ie.NETRC_MACHINE


# Generated at 2022-06-22 08:01:10.159592
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # TODO: test for actual video if possible
    account = LinuxAcademyIE(None)
    account._login()

# Generated at 2022-06-22 08:01:12.016698
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE(None)

# Generated at 2022-06-22 08:01:14.145817
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    ie._login()

# Generated at 2022-06-22 08:01:16.526290
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    assert obj._CLIENT_ID is not None
    assert obj._NETRC_MACHINE is not None

# Generated at 2022-06-22 08:01:21.483373
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """ Unit test for login method of LinuxAcademyIE class """
    linux_academy_ie = LinuxAcademyIE()
    assert linux_academy_ie is not None

# Generated at 2022-06-22 08:01:28.556850
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\\d+)/lesson/(?P<lesson_id>\\d+)'
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'

# Generated at 2022-06-22 08:01:33.279750
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        assert LinuxAcademyIE.IE_NAME
    except Exception as e:
        log.error('Cannot load LinuxAcademyIE: ' + str(e))
        return False
    else:
        log.info('Initialized LinuxAcademyIE')
        return True

# Generated at 2022-06-22 08:02:53.328425
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()

# Generated at 2022-06-22 08:02:55.270382
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 08:02:56.363390
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    constructor_test(LinuxAcademyIE)

# Generated at 2022-06-22 08:02:57.900575
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert_raises(ExtractorError, LinuxAcademyIE, None).login()

# Generated at 2022-06-22 08:03:00.803250
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .. import LinuxAcademyIE
    assert LinuxAcademyIE

# Generated at 2022-06-22 08:03:06.390353
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # url is of type str
    url_str = "str"
    # url is of type bytes
    url_bytes = b"bytes"
    try:
        # url is of type str
        ie_obj = LinuxAcademyIE(url_str)
        # url is of type bytes
        ie_obj = LinuxAcademyIE(url_bytes)
    except Exception as e:
        assert False, "There should be no exception for" \
        " LinuxAcademyIE instantiation"



# Generated at 2022-06-22 08:03:11.312980
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE(None)
    assert obj.AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert obj.ORIGIN_URL == 'https://linuxacademy.com'
    assert obj.CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert obj.NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-22 08:03:13.208285
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    inst = LinuxAcademyIE()
    inst.initialize()
    if not inst.username:
        raise ValueError('Login credentials are not provided. Please set username and password in secrets.json')

# Generated at 2022-06-22 08:03:23.944805
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    url_test_cases = [
        # chapter_id, lesson_id, course_id, expected result
        ('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675', 7971, 2, None),
        ('https://linuxacademy.com/cp/modules/view/id/154', None, None, 154)
    ]

    for url, chapter_id, lesson_id, course_id in url_test_cases:
        laie = LinuxAcademyIE(url)
        assert chapter_id == laie.chapter_id
        assert lesson_id == laie.lesson_id
        assert course_id == laie.course_id

# Generated at 2022-06-22 08:03:27.405041
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    info = LinuxAcademyIE()
    assert info.ie_key() == 'LinuxAcademy'
    assert info.ie_key() in info.gen_extractor_classes()

# Generated at 2022-06-22 08:07:04.150729
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert (LinuxAcademyIE()._AUTHORIZE_URL
        == 'https://login.linuxacademy.com/authorize')
    assert (LinuxAcademyIE()._ORIGIN_URL
        == 'https://linuxacademy.com')
    assert (LinuxAcademyIE()._CLIENT_ID
        == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx')
    assert (LinuxAcademyIE()._NETRC_MACHINE
        == 'linuxacademy')

# Generated at 2022-06-22 08:07:05.121726
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE(None)

# Generated at 2022-06-22 08:07:06.311384
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    yt_ie = LinuxAcademyIE()
    assert yt_ie is not None

# Generated at 2022-06-22 08:07:12.426002
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Tests for LinuxAcademyIE.__init__()
    ie = LinuxAcademyIE();
    assert ie._VALID_URL == ''
    assert ie._TESTS == []
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-22 08:07:15.711858
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        ie = LinuxAcademyIE()
        assert ie
    except Exception as e:
        assert False, "Failed to create instance of LinuxAcademyIE"

# Generated at 2022-06-22 08:07:16.606455
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()

# Generated at 2022-06-22 08:07:17.591529
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    instance = LinuxAcademyIE()
    assert instance is not None

# Generated at 2022-06-22 08:07:21.918702
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-22 08:07:25.257748
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._CLIENT_ID != None
    assert ie._NETRC_MACHINE != None
    assert ie._PYPI_VERSION != None

# Generated at 2022-06-22 08:07:34.937331
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try:
        import os
        import netrc
    except ImportError:
        return

    netrc_machine = 'linuxacademy'

    if not os.path.isfile(netrc.netrc().filename):
        return

    auth = netrc.netrc().authenticators(netrc_machine)
    if not auth:
        return

    ie = LinuxAcademyIE()
    assert ie.has_login() == True
    ie.password = auth[2]
    ie.username = auth[0]
    ie._login()
    assert ie.has_login() == True