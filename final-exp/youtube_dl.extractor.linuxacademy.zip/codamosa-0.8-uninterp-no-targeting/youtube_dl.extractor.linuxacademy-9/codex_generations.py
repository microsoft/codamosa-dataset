

# Generated at 2022-06-22 07:58:06.544606
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE() != None

# Generated at 2022-06-22 07:58:14.932873
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-22 07:58:18.539033
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE("LinuxAcademy")._NETRC_MACHINE == "linuxacademy"

# Generated at 2022-06-22 07:58:20.415013
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.ie_key() == 'LinuxAcademy'

# Generated at 2022-06-22 07:58:21.822905
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 07:58:24.200632
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE('LinuxAcademy')
    assert ie is not None


# Generated at 2022-06-22 07:58:26.855784
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # The following example is used to test the constructor
    testcase = LinuxAcademyIE()
    assert testcase.IE_NAME == "linuxacademy"

# Generated at 2022-06-22 07:58:34.200997
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test creating an instance of LinuxAcademyIE with a valid url.
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    ie = LinuxAcademyIE(url)
    # Test creating an instance of LinuxAcademyIE with an invalid url, it should
    # raise an error.
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module'
    ie = LinuxAcademyIE(url)

# Generated at 2022-06-22 07:58:43.253002
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    u = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    laie = LinuxAcademyIE(u)
    assert laie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''

# Generated at 2022-06-22 07:58:53.130996
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test creating a LinuxAcademyIE instance
    ieg = LinuxAcademyIE()
    # Test LinuxAcademyIE.IE_NAME
    assert ieg.IE_NAME == 'linuxacademy'
    # Test LinuxAcademyIE.login
    if (ieg.username is not None and ieg.password is not None):
        ieg._login()
    # Test LinuxAcademyIE.extract
    info = ieg._real_extract(
        'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    assert info['title'] == 'What Is Data Science'

# Generated at 2022-06-22 07:59:30.249789
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # ensure class constructor is properly initialized
    ie = LinuxAcademyIE()
    assert ie._VALID_URL.__doc__ == LinuxAcademyIE._VALID_URL.__doc__
    assert ie._NETRC_MACHINE == LinuxAcademyIE._NETRC_MACHINE

# Generated at 2022-06-22 07:59:32.507204
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ieObj = LinuxAcademyIE()
    assert ieObj._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'

# Generated at 2022-06-22 07:59:40.459990
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert ie._NETRC_MACHINE == 'linuxacademy'


# Generated at 2022-06-22 07:59:41.648314
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()


# Generated at 2022-06-22 07:59:46.000651
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():  # pylint: disable=redefined-outer-name
    from .common import FakeLoginIE
    ie = LinuxAcademyIE(FakeLoginIE('usename', 'password'))
    assert ie.username == 'usename'
    assert ie.password == 'password'

# Generated at 2022-06-22 07:59:47.872687
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    # Testing login function
    ie._login()

# Generated at 2022-06-22 07:59:59.159586
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linux_academy_course_url = 'https://linuxacademy.com/cp/modules/view/id/154'
    # For unit test, override the browser's user agent string
    LinuxAcademyIE.USER_AGENT = '"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36"'
    # Test in a real environment: Linux Academy course
    # This will try to download the first video in a Linux Academy course
    # To extract the video, user must provides the ID and the password (or the API token)
    # Which is saved in file "~/.netrc", in section:
    # machine linuxacademy
    # login [your Linux Academy user name (email)]

# Generated at 2022-06-22 08:00:00.083569
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 08:00:05.780654
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('http://example.com')
    LinuxAcademyIE('https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    LinuxAcademyIE('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    LinuxAcademyIE('https://linuxacademy.com/cp/modules/view/id/154')

# Generated at 2022-06-22 08:00:08.325030
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    l_ie = LinuxAcademyIE()
    l_ie._login()

# Generated at 2022-06-22 08:01:26.020756
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-22 08:01:27.754064
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    la = LinuxAcademyIE()
    assert la.login_path() == 'linuxacademy'

# Generated at 2022-06-22 08:01:36.642125
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Tests for Linux Academy courses
    url = 'https://linuxacademy.com/cp/modules/view/id/154'
    course = LinuxAcademyIE().extract(url)
    assert course['_type'] == 'playlist'
    assert 'playlist_count' in course
    assert url == course['url']

    # Tests for Linux Academy lectures
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2'
    lecture = LinuxAcademyIE().extract(url)
    assert lecture['id'] == '7971-2'
    assert lecture['_type'] == 'video'
    assert url == lecture['url']

# Generated at 2022-06-22 08:01:45.326532
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Test for windows systems
    if _WIN:
        from ..utils import get_exe_path

        if not get_exe_path('ffmpeg.exe'):
            raise Exception("Test for LinuxAcademyIE will not be performed due to missing ffmpeg.exe")

    last_authentication = None
    def authentication(http_template):
        from distutils.version import StrictVersion
        from ..utils import NO_DEFAULT
        
        # Avoid bug in requests library for versions older than 2.18.2
        if StrictVersion(requests.__version__) < StrictVersion('2.18.2'):
            raise NotImplementedError

        # Assert type of http header
        response = http_template()
        assert isinstance(response.headers, CaseInsensitiveDict)

        # Assert changing of authorization header
        non

# Generated at 2022-06-22 08:01:46.750069
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """Unit test for constructor of class LinuxAcademyIE
    """
    LinuxAcademyIE()

# Generated at 2022-06-22 08:01:48.299258
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie is not None

# Unit tests for _login method of class LinuxAcademyIE

# Generated at 2022-06-22 08:01:52.474310
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL == LinuxAcademyIE._VALID_URL
    assert ie._TESTS == LinuxAcademyIE._TESTS
    assert ie._AUTHORIZE_URL == LinuxAcademyIE._AUTHORIZE_URL
    assert ie._ORIGIN_URL == LinuxAcademyIE._ORIGIN_URL
    assert ie._CLIENT_ID == LinuxAcademyIE._CLIENT_ID
    assert ie._NETRC_MACHINE == LinuxAcademyIE._NETRC_MACHINE

# Generated at 2022-06-22 08:01:55.267901
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_login_LinuxAcademyIE()
    test_playlist_LinuxAcademyIE()
    test_course_LinuxAcademyIE()


# Activate unit test

# Generated at 2022-06-22 08:01:56.275796
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 08:01:57.357136
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE()

# Generated at 2022-06-22 08:03:27.008580
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE() is not None

# Generated at 2022-06-22 08:03:28.091935
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 08:03:31.980460
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # This is just a simple test. Please add more tests to this test case.
    output = LinuxAcademyIE()
    if not isinstance (output, LinuxAcademyIE):
        raise TypeError("LinuxAcademyIE is not of type LinuxAcademyIE")

# Generated at 2022-06-22 08:03:38.248466
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE('http://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    assert LinuxAcademyIE('http://linuxacademy.com/cp/modules/view/id/154')

# Generated at 2022-06-22 08:03:50.626788
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_LinuxAcademy = LinuxAcademyIE()
    assert test_LinuxAcademy._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert test_LinuxAcademy._ORIGIN_URL == 'https://linuxacademy.com'
    assert test_LinuxAcademy._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert test_LinuxAcademy._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-22 08:04:01.114615
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # unit test for field: _VALID_URL
    # test success
    match_result = LinuxAcademyIE._VALID_URL.match("https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675")
    assert match_result.group("chapter_id") == "7971"
    assert match_result.group("lesson_id") == "2"
    assert match_result.group("course_id") == None
    
    # test fail
    match_result = LinuxAcademyIE._VALID_URL.match("https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675/abc")
    assert match_result == None
    
    # test success
    match_result = Linux

# Generated at 2022-06-22 08:04:01.989171
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass

# Generated at 2022-06-22 08:04:03.488558
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 08:04:10.294506
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    def parse_unix_timestamp(timestamp):
        import datetime
        return datetime.datetime.utcfromtimestamp(timestamp)

    la_ie = LinuxAcademyIE()
    # la_ie._login()
    assert la_ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert la_ie._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert la_ie._NETRC_MACHINE == 'linuxacademy'
    assert la_ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'

# Generated at 2022-06-22 08:04:14.718079
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE.ie_key() == 'LinuxAcademy'
    assert isinstance(LinuxAcademyIE(None), InfoExtractor)
    assert LinuxAcademyIE.ie_key() == 'linuxacademy'
    assert LinuxAcademyIE.name == 'linuxacademy.com'

# Generated at 2022-06-22 08:07:44.578149
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    '''
    Unit test for constructor of class LinuxAcademyIE
    '''
    # Get the LinuxAcademyIE object
    linux_academy_ie = LinuxAcademyIE()
    # Check the type of object
    assert type(linux_academy_ie) == LinuxAcademyIE
    # Check whether linux_academy_ie object is an instance of InfoExtractor object
    assert isinstance(linux_academy_ie, InfoExtractor)