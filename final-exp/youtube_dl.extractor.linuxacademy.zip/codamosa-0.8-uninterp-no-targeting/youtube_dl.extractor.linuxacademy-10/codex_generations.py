

# Generated at 2022-06-22 07:58:17.276367
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie_obj = LinuxAcademyIE("linuxacademy")
    assert(ie_obj._VALID_URL == r'(?x)https?://(?:www\.|cp\.)?linuxacademy\.com/(?:cp/|watch/details/\d+/detailed/|)courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)')
    assert(ie_obj._AUTHORIZE_URL == "https://login.linuxacademy.com/authorize")
    assert(ie_obj._ORIGIN_URL == "https://linuxacademy.com")

# Generated at 2022-06-22 07:58:19.706306
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    """
    Test the LinuxAcademyIE constructor
    """
    ie = LinuxAcademyIE(None)
    assert ie is not None

# Generated at 2022-06-22 07:58:31.817487
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademyIE = LinuxAcademyIE()
    assert linuxacademyIE._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert linuxacademyIE._ORIGIN_URL == 'https://linuxacademy.com'
    assert linuxacademyIE._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'
    assert linuxacademyIE._NETRC_MACHINE == 'linuxacademy'

# Generated at 2022-06-22 07:58:40.764376
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    linuxacademy_ie = LinuxAcademyIE()
    # test for exception when unit test is run without credentials
    try:
        linuxacademy_ie._login()
        assert False
    except ExtractorError as e:
        assert e.expected
        assert e.message == 'linuxacademy said: You must pass a username'
    linuxacademy_ie.username = 'test'
    # test for exception when unit test is run with only username
    try:
        linuxacademy_ie._login()
        assert False
    except ExtractorError as e:
        assert e.expected
        assert e.message == 'linuxacademy said: You must pass a password'
    linuxacademy_ie.password = 'test'
    # test login without credentials in session
    linuxacademy_ie._login()

# Generated at 2022-06-22 07:58:44.643403
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # test to check if the constructor of the class LinuxAcademyIE
    # works correctly
    ie = LinuxAcademyIE()
    # test to check the name of the class
    assert ie.IE_NAME == 'linuxacademy'

# Generated at 2022-06-22 07:58:53.139815
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_obj = LinuxAcademyIE()
    assert test_obj
    assert test_obj._VALID_URL == \
        r'https?://(?:www\.)?linuxacademy\.com/cp/' + \
        r'(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|' + \
        r'modules/view/id/(?P<course_id>\d+))'
    assert test_obj._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert test_obj._ORIGIN_URL == 'https://linuxacademy.com'

# Generated at 2022-06-22 07:58:55.361445
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    la = LinuxAcademyIE()
    assert isinstance(la, LinuxAcademyIE)


# Generated at 2022-06-22 07:59:03.566281
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # This test is based on the following video
    #    https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675
    # which has been updated to https://linuxacademy.com/cp/modules/view/id/133
    # which does not appear to work anymore.
    url = 'https://linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675'
    assert LinuxAcademyIE.suitable(url)
    ie = LinuxAcademyIE()
    assert ie.suitable(url)
    ie._real_initialize()

# Generated at 2022-06-22 07:59:04.558234
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    try_get()

# Generated at 2022-06-22 07:59:06.599684
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    a = LinuxAcademyIE()
    a.to_screen('Testing LinuxAcademyIE')
    return a

# Generated at 2022-06-22 07:59:45.778020
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():

    assert(LinuxAcademyIE.ie_key() == 'linuxacademy')

# Generated at 2022-06-22 07:59:52.341040
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    with open('test_linuxacademy.json', 'r') as f:
        test_cases = json.loads(f.read())
    for test_case in test_cases:
        print('------------------------------')
        laie = LinuxAcademyIE()
        laie.test()
        laie._real_initialize()
        laie._real_extract(test_case['url'])

# Generated at 2022-06-22 07:59:54.237181
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LAIE = LinuxAcademyIE()
    assert LAIE

# Generated at 2022-06-22 07:59:55.320859
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 08:00:04.347444
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE._VALID_URL == 'https?://(?:www\.)?linuxacademy\.com/cp/(?:courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|modules/view/id/(?P<course_id>\d+))'
    assert LinuxAcademyIE._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert LinuxAcademyIE._ORIGIN_URL == 'https://linuxacademy.com'
    assert LinuxAcademyIE._CLIENT_ID == 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx'

# Generated at 2022-06-22 08:00:06.748287
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert isinstance(ie, LinuxAcademyIE)
    # Test login
    ie._login()

# Generated at 2022-06-22 08:00:08.437830
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    pass



# Generated at 2022-06-22 08:00:09.545420
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    return LinuxAcademyIE()

# Generated at 2022-06-22 08:00:20.518000
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test_login_data = {
        'client_id': 'KaWxNn1C2Gc7n83W9OFeXltd8Utb5vvx',
        'redirect_uri': 'https://linuxacademy.com/',
        'tenant': 'lacausers',
        'connection': 'Username-Password-Authentication',
        'username': '',
        'password': '',
        'sso': 'true',
    }
    ie = LinuxAcademyIE()
    username, password = ie._get_login_info()
    if username and password:
        # Test if the method _login() of class LinuxAcademyIE works properly
        test_login_data["username"] = username
        test_login_data["password"] = password
        test_webpage, test_urlh

# Generated at 2022-06-22 08:00:30.940870
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    # Load test cases
    test_cases = json.load(open("test_cases/test_cases_LinuxAcademyIE.json"))
    test_case_count = len(test_cases)

    # Test LinuxAcademyIE constructor
    linuxacademy_ie = LinuxAcademyIE()

    # Test __init__
    assert linuxacademy_ie._VALID_URL == r'https?://(?:www\.)?linuxacademy\.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)'
    assert linuxacademy_ie._NETRC_MACHINE == 'linuxacademy'

    # Test _real_initialize
    assert linuxacademy_ie._real_initialize() is None

   

# Generated at 2022-06-22 08:01:15.133658
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    test = LinuxAcademyIE()


if __name__ == '__main__':
    test_LinuxAcademyIE()

# Generated at 2022-06-22 08:01:16.310014
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 08:01:17.230059
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE()

# Generated at 2022-06-22 08:01:18.118110
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE('test user', 'test pass')

# Generated at 2022-06-22 08:01:22.137152
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    obj = LinuxAcademyIE()
    obj._real_initialize()
    obj.ie_key()

# Generated at 2022-06-22 08:01:29.241237
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'linuxacademy'
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?linuxacademy\.com/cp/
                        (?:
                            courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|
                            modules/view/id/(?P<course_id>\d+)
                        )
                    '''
    assert ie._NETRC_MACHINE == 'linuxacademy'
    assert ie._AUTHORIZE_URL == 'https://login.linuxacademy.com/authorize'
    assert ie._ORIGIN_URL == 'https://linuxacademy.com'
    assert ie

# Generated at 2022-06-22 08:01:36.290502
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert LinuxAcademyIE._VALID_URL.match('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    assert LinuxAcademyIE._VALID_URL.match('https://www.linuxacademy.com/cp/courses/lesson/course/7971/lesson/2/module/675')
    assert LinuxAcademyIE._VALID_URL.match('https://linuxacademy.com/cp/modules/view/id/154')

# Generated at 2022-06-22 08:01:37.491660
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    LinuxAcademyIE("")


# Generated at 2022-06-22 08:01:46.319313
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    from .test_utils import parse_playlist
    sample_playlist_url = 'https://linuxacademy.com/cp/modules/view/id/154'
    playlist_info = parse_playlist(LinuxAcademyIE, sample_playlist_url)
    assert playlist_info['id'] == '154'
    assert playlist_info['title'] == 'AWS Certified Cloud Practitioner'
    assert playlist_info['description'] == ('AWS Certified Cloud Practitioner - '
                                            'Domain 1- Foundational Concepts')
    assert playlist_info['duration'] == 28835

# Generated at 2022-06-22 08:01:49.762783
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE.ie_key() == LinuxAcademyIE.ie_key()

# Generated at 2022-06-22 08:03:35.385012
# Unit test for constructor of class LinuxAcademyIE

# Generated at 2022-06-22 08:03:37.360061
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    l = LinuxAcademyIE()
    assert l !=None

# Generated at 2022-06-22 08:03:45.283725
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    args=['https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2']
    #args=['https://linuxacademy.com/cp/modules/view/id/154']
    ies = LinuxAcademyIE()._real_initialize()
    info_dict = ies._real_extract(args[0])
    return info_dict['title']

# vim:ts=4:sw=4:et:

# Generated at 2022-06-22 08:03:46.712571
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie is not None


# Generated at 2022-06-22 08:03:48.787722
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie is not None

# Generated at 2022-06-22 08:03:53.310497
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie.IE_NAME == 'LinuxAcademyIE'
    assert ie.ie_key() == 'LinuxAcademyIE'
    assert ie.IE_DESC == 'Linux Academy'


# Generated at 2022-06-22 08:04:02.590137
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE()
    assert ie._VALID_URL.match('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/2')
    assert ie._VALID_URL.match('https://linuxacademy.com/cp/modules/view/id/154')
    assert not ie._VALID_URL.match('https://linuxacademy.com/cp/')
    # assert not ie._VALID_URL.match('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/')
    # assert not ie._VALID_URL.match('https://linuxacademy.com/cp/courses/lesson/course/1498/lesson/abc')

# Generated at 2022-06-22 08:04:04.286335
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ie = LinuxAcademyIE(None)
    assert ie.ie_key() == 'LinuxAcademy'


# Generated at 2022-06-22 08:04:07.675252
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    ieObj = LinuxAcademyIE()
    assert ieObj.__class__.__name__ == "LinuxAcademyIE"

# Generated at 2022-06-22 08:04:19.394115
# Unit test for constructor of class LinuxAcademyIE
def test_LinuxAcademyIE():
    assert LinuxAcademyIE._VALID_URL == 'https://linuxacademy.com/cp/courses/lesson/course/(?P<chapter_id>\d+)/lesson/(?P<lesson_id>\d+)|https://linuxacademy.com/cp/modules/view/id/(?P<course_id>\d+)'