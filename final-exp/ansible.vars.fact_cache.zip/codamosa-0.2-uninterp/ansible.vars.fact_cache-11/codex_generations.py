

# Generated at 2022-06-17 15:56:11.335747
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'test': 'test'}})
    assert fact_cache['localhost']['ansible_facts']['test'] == 'test'
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'test': 'test2'}})
    assert fact_cache['localhost']['ansible_facts']['test'] == 'test2'

# Generated at 2022-06-17 15:56:12.452624
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:56:19.911145
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'a': 1})
    assert fact_cache['host1'] == {'a': 1}
    fact_cache.first_order_merge('host1', {'b': 2})
    assert fact_cache['host1'] == {'a': 1, 'b': 2}
    fact_cache.first_order_merge('host2', {'a': 3})
    assert fact_cache['host2'] == {'a': 3}
    assert fact_cache['host1'] == {'a': 1, 'b': 2}
    fact_cache.first_order_merge('host2', {'b': 4})
    assert fact_cache['host2'] == {'a': 3, 'b': 4}

# Generated at 2022-06-17 15:56:21.337050
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:56:27.858244
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'a': 1, 'b': 2})
    assert fact_cache['host1'] == {'a': 1, 'b': 2}
    fact_cache.first_order_merge('host1', {'a': 3, 'c': 4})
    assert fact_cache['host1'] == {'a': 3, 'b': 2, 'c': 4}
    fact_cache.first_order_merge('host2', {'a': 5, 'b': 6})
    assert fact_cache['host2'] == {'a': 5, 'b': 6}

# Generated at 2022-06-17 15:56:34.078050
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Create a new instance of FactCache
    fact_cache = FactCache()
    # Create a new key and value
    key = 'test_key'
    value = {'test_key': 'test_value'}
    # Call first_order_merge
    fact_cache.first_order_merge(key, value)
    # Check if the key is in the cache
    assert key in fact_cache
    # Check if the value is in the cache
    assert value in fact_cache.values()

# Generated at 2022-06-17 15:56:47.627504
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'a': 1})
    assert fact_cache['host1'] == {'a': 1}
    fact_cache.first_order_merge('host1', {'b': 2})
    assert fact_cache['host1'] == {'a': 1, 'b': 2}
    fact_cache.first_order_merge('host2', {'a': 1})
    assert fact_cache['host2'] == {'a': 1}
    fact_cache.first_order_merge('host1', {'a': 2})
    assert fact_cache['host1'] == {'a': 2, 'b': 2}
    fact_cache.first_order_merge('host2', {'b': 2})

# Generated at 2022-06-17 15:56:48.788178
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin

# Generated at 2022-06-17 15:56:50.482169
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin

# Generated at 2022-06-17 15:56:51.665416
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache
    assert fact_cache._plugin

# Generated at 2022-06-17 15:56:54.307606
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None


# Generated at 2022-06-17 15:56:56.802770
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None
    assert fact_cache._plugin.__class__.__name__ == 'FactCacheData'

# Generated at 2022-06-17 15:57:03.333683
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc.first_order_merge('localhost', {'a': 1, 'b': 2})
    assert fc['localhost'] == {'a': 1, 'b': 2}
    fc.first_order_merge('localhost', {'b': 3, 'c': 4})
    assert fc['localhost'] == {'a': 1, 'b': 3, 'c': 4}

# Generated at 2022-06-17 15:57:07.123031
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:57:07.968651
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache

# Generated at 2022-06-17 15:57:09.758646
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 15:57:11.859774
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache._plugin is not None
    assert cache._plugin.__class__.__name__ == 'FactCacheData'


# Generated at 2022-06-17 15:57:12.958028
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:57:23.367201
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}

# Generated at 2022-06-17 15:57:28.924044
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'a': 1, 'b': 2})
    assert fact_cache['host1'] == {'a': 1, 'b': 2}
    fact_cache.first_order_merge('host1', {'b': 3, 'c': 4})
    assert fact_cache['host1'] == {'a': 1, 'b': 3, 'c': 4}

# Generated at 2022-06-17 15:57:36.075465
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('127.0.0.1', {'ansible_facts': {'test': 'test'}})
    assert fact_cache['127.0.0.1']['ansible_facts']['test'] == 'test'
    fact_cache.first_order_merge('127.0.0.1', {'ansible_facts': {'test': 'test2'}})
    assert fact_cache['127.0.0.1']['ansible_facts']['test'] == 'test2'

# Generated at 2022-06-17 15:57:37.355267
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache

# Generated at 2022-06-17 15:57:39.387020
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:57:44.431557
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin
    assert fc._plugin.contains == fc.__contains__
    assert fc._plugin.get == fc.__getitem__
    assert fc._plugin.set == fc.__setitem__
    assert fc._plugin.delete == fc.__delitem__
    assert fc._plugin.keys == fc.keys
    assert fc._plugin.flush == fc.flush

# Generated at 2022-06-17 15:57:46.718317
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 15:57:47.859513
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin is not None

# Generated at 2022-06-17 15:57:55.314835
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_key': 'test_value'})
    assert fact_cache['test_host']['test_key'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_key': 'test_value2'})
    assert fact_cache['test_host']['test_key'] == 'test_value2'

# Generated at 2022-06-17 15:58:02.059161
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value'})
    assert fact_cache['test_host']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value2'})
    assert fact_cache['test_host']['test_fact'] == 'test_value2'
    fact_cache.first_order_merge('test_host', {'test_fact2': 'test_value3'})
    assert fact_cache['test_host']['test_fact2'] == 'test_value3'

# Generated at 2022-06-17 15:58:03.231867
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:58:04.823024
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:58:16.818548
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'a': 1, 'b': 2})
    assert fact_cache['host1'] == {'a': 1, 'b': 2}
    fact_cache.first_order_merge('host1', {'b': 3, 'c': 4})
    assert fact_cache['host1'] == {'a': 1, 'b': 3, 'c': 4}

# Generated at 2022-06-17 15:58:19.284265
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin
    assert fc._plugin.__class__.__name__ == 'FactCacheData'

# Generated at 2022-06-17 15:58:25.471549
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value'})
    assert fact_cache['test_host']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_fact': 'new_value'})
    assert fact_cache['test_host']['test_fact'] == 'new_value'

# Generated at 2022-06-17 15:58:34.498931
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Create a fact cache
    fact_cache = FactCache()

    # Create a fact
    fact = {'fact': 'value'}

    # Create a host
    host = 'host'

    # Add the fact to the cache
    fact_cache.first_order_merge(host, fact)

    # Check that the fact has been added to the cache
    assert fact_cache[host] == fact

    # Update the fact
    fact['fact'] = 'new_value'

    # Add the fact to the cache
    fact_cache.first_order_merge(host, fact)

    # Check that the fact has been updated in the cache
    assert fact_cache[host] == fact

# Generated at 2022-06-17 15:58:37.279202
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'FactCachePlugin'

# Generated at 2022-06-17 15:58:39.859850
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'FactCacheData'

# Generated at 2022-06-17 15:58:48.639489
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge("test_host", {"test_fact": "test_value"})
    assert fact_cache["test_host"]["test_fact"] == "test_value"
    fact_cache.first_order_merge("test_host", {"test_fact": "test_value2"})
    assert fact_cache["test_host"]["test_fact"] == "test_value2"
    fact_cache.first_order_merge("test_host", {"test_fact2": "test_value2"})
    assert fact_cache["test_host"]["test_fact2"] == "test_value2"

# Generated at 2022-06-17 15:58:50.243206
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:58:55.617218
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'ansible_os_family': 'RedHat'})
    assert fact_cache['host1'] == {'ansible_os_family': 'RedHat'}
    fact_cache.first_order_merge('host1', {'ansible_distribution': 'CentOS'})
    assert fact_cache['host1'] == {'ansible_os_family': 'RedHat', 'ansible_distribution': 'CentOS'}
    fact_cache.first_order_merge('host1', {'ansible_os_family': 'Debian'})
    assert fact_cache['host1'] == {'ansible_os_family': 'Debian', 'ansible_distribution': 'CentOS'}

# Generated at 2022-06-17 15:59:04.577119
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('127.0.0.1', {'ansible_facts': {'test_fact': 'test_value'}})
    assert fact_cache['127.0.0.1']['ansible_facts']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('127.0.0.1', {'ansible_facts': {'test_fact': 'test_value2'}})
    assert fact_cache['127.0.0.1']['ansible_facts']['test_fact'] == 'test_value2'

# Generated at 2022-06-17 15:59:23.717126
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('localhost', {'ansible_os_family': 'RedHat'})
    assert fact_cache['localhost']['ansible_os_family'] == 'RedHat'
    fact_cache.first_order_merge('localhost', {'ansible_distribution': 'CentOS'})
    assert fact_cache['localhost']['ansible_distribution'] == 'CentOS'
    assert fact_cache['localhost']['ansible_os_family'] == 'RedHat'
    fact_cache.first_order_merge('localhost', {'ansible_os_family': 'Debian'})
    assert fact_cache['localhost']['ansible_os_family'] == 'Debian'

# Generated at 2022-06-17 15:59:30.923558
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'a': 1, 'b': 2})
    assert fact_cache['host1'] == {'a': 1, 'b': 2}
    fact_cache.first_order_merge('host1', {'b': 3, 'c': 4})
    assert fact_cache['host1'] == {'a': 1, 'b': 3, 'c': 4}

# Generated at 2022-06-17 15:59:32.825429
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:59:34.421453
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache

# Generated at 2022-06-17 15:59:37.328580
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:59:39.403246
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 15:59:41.283413
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:59:42.611753
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:59:43.461422
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:59:48.182403
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    cache.first_order_merge('host1', {'fact1': 'value1'})
    assert cache['host1']['fact1'] == 'value1'
    cache.first_order_merge('host1', {'fact2': 'value2'})
    assert cache['host1']['fact2'] == 'value2'
    cache.first_order_merge('host1', {'fact1': 'value3'})
    assert cache['host1']['fact1'] == 'value3'
    cache.first_order_merge('host2', {'fact1': 'value1'})
    assert cache['host2']['fact1'] == 'value1'
    cache.first_order_merge('host2', {'fact2': 'value2'})


# Generated at 2022-06-17 16:00:22.998927
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('localhost', {'ansible_os_family': 'RedHat'})
    assert fact_cache['localhost']['ansible_os_family'] == 'RedHat'
    fact_cache.first_order_merge('localhost', {'ansible_distribution': 'CentOS'})
    assert fact_cache['localhost']['ansible_distribution'] == 'CentOS'
    fact_cache.first_order_merge('localhost', {'ansible_distribution': 'Fedora'})
    assert fact_cache['localhost']['ansible_distribution'] == 'Fedora'
    fact_cache.first_order_merge('localhost', {'ansible_os_family': 'Debian'})

# Generated at 2022-06-17 16:00:25.985215
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'FactCacheData'

# Generated at 2022-06-17 16:00:30.152516
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_key', {'test_key': 'test_value'})
    assert fact_cache['test_key'] == {'test_key': 'test_value'}

# Generated at 2022-06-17 16:00:33.494626
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}

# Generated at 2022-06-17 16:00:34.495901
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 16:00:36.123734
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache

# Generated at 2022-06-17 16:00:47.230792
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1']['fact1'] == 'value1'
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1']['fact2'] == 'value2'
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1']['fact1'] == 'value3'
    fact_cache.first_order_merge('host2', {'fact1': 'value1'})
    assert fact_cache['host2']['fact1'] == 'value1'

# Generated at 2022-06-17 16:00:53.837257
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1']['fact1'] == 'value1'
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1']['fact2'] == 'value2'
    fact_cache.first_order_merge('host2', {'fact3': 'value3'})
    assert fact_cache['host2']['fact3'] == 'value3'
    fact_cache.first_order_merge('host1', {'fact1': 'value4'})
    assert fact_cache['host1']['fact1'] == 'value4'
    fact_cache.first

# Generated at 2022-06-17 16:00:57.462974
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.flush()
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'test': 'test'}})
    assert fact_cache['localhost']['ansible_facts']['test'] == 'test'
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'test': 'test2'}})
    assert fact_cache['localhost']['ansible_facts']['test'] == 'test2'
    fact_cache.flush()

# Generated at 2022-06-17 16:01:03.365478
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value'})
    assert fact_cache['test_host']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_fact': 'new_value'})
    assert fact_cache['test_host']['test_fact'] == 'new_value'

# Generated at 2022-06-17 16:02:06.802417
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'a': 1, 'b': 2})
    assert fact_cache['host1'] == {'a': 1, 'b': 2}
    fact_cache.first_order_merge('host1', {'a': 3, 'c': 4})
    assert fact_cache['host1'] == {'a': 3, 'b': 2, 'c': 4}
    fact_cache.first_order_merge('host2', {'a': 5, 'b': 6})
    assert fact_cache['host2'] == {'a': 5, 'b': 6}
    fact_cache.first_order_merge('host2', {'a': 7, 'c': 8})

# Generated at 2022-06-17 16:02:09.915011
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:02:11.081227
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 16:02:12.973677
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 16:02:14.693370
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin

# Generated at 2022-06-17 16:02:16.743575
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin.__class__.__name__ == 'FactCacheData'
    assert fc._plugin.cache_plugin == 'jsonfile'

# Generated at 2022-06-17 16:02:17.619317
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:02:20.290131
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None


# Generated at 2022-06-17 16:02:21.240844
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:02:22.076318
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 16:04:20.459720
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 16:04:22.732903
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:04:24.020342
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 16:04:29.313633
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge("host1", {"ansible_os_family": "Linux"})
    assert fact_cache["host1"] == {"ansible_os_family": "Linux"}
    fact_cache.first_order_merge("host1", {"ansible_distribution": "CentOS"})
    assert fact_cache["host1"] == {"ansible_os_family": "Linux", "ansible_distribution": "CentOS"}
    fact_cache.first_order_merge("host1", {"ansible_os_family": "RedHat"})
    assert fact_cache["host1"] == {"ansible_os_family": "RedHat", "ansible_distribution": "CentOS"}

# Generated at 2022-06-17 16:04:32.341850
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 16:04:33.604049
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc is not None

# Generated at 2022-06-17 16:04:35.330349
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None
    assert fact_cache._plugin.__class__.__name__ == 'FactCacheData'

# Generated at 2022-06-17 16:04:37.865197
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin is not None

# Generated at 2022-06-17 16:04:47.162256
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge("host1", {"fact1": "value1"})
    assert fact_cache["host1"] == {"fact1": "value1"}
    fact_cache.first_order_merge("host1", {"fact2": "value2"})
    assert fact_cache["host1"] == {"fact1": "value1", "fact2": "value2"}
    fact_cache.first_order_merge("host1", {"fact1": "value3"})
    assert fact_cache["host1"] == {"fact1": "value3", "fact2": "value2"}

# Generated at 2022-06-17 16:04:56.562652
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('hostname', {'ansible_facts': {'hostname': 'host1'}})
    assert fact_cache['hostname']['ansible_facts']['hostname'] == 'host1'
    fact_cache.first_order_merge('hostname', {'ansible_facts': {'hostname': 'host2'}})
    assert fact_cache['hostname']['ansible_facts']['hostname'] == 'host2'
    fact_cache.first_order_merge('hostname', {'ansible_facts': {'hostname': 'host3'}})
    assert fact_cache['hostname']['ansible_facts']['hostname'] == 'host3'