

# Generated at 2022-06-17 15:56:05.955823
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:56:13.618104
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}

# Generated at 2022-06-17 15:56:19.936747
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'a': 1, 'b': 2})
    assert fact_cache['host1'] == {'a': 1, 'b': 2}
    fact_cache.first_order_merge('host1', {'b': 3, 'c': 4})
    assert fact_cache['host1'] == {'a': 1, 'b': 3, 'c': 4}
    fact_cache.first_order_merge('host2', {'d': 5, 'e': 6})
    assert fact_cache['host2'] == {'d': 5, 'e': 6}

# Generated at 2022-06-17 15:56:21.377382
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:56:22.686471
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:56:29.469618
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}
    fact_cache.first_order_merge('host2', {'fact1': 'value1'})

# Generated at 2022-06-17 15:56:30.707545
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc


# Generated at 2022-06-17 15:56:31.859265
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:56:33.927984
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 15:56:34.951678
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:56:48.180851
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1']['fact1'] == 'value1'
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1']['fact2'] == 'value2'
    fact_cache.first_order_merge('host1', {'fact1': 'value1_new'})
    assert fact_cache['host1']['fact1'] == 'value1_new'
    fact_cache.first_order_merge('host2', {'fact1': 'value1'})
    assert fact_cache['host2']['fact1'] == 'value1'

# Generated at 2022-06-17 15:56:49.888767
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache._plugin is not None

# Generated at 2022-06-17 15:56:51.267353
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:56:52.781372
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 15:56:54.127228
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:56:55.847244
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:57:05.163840
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'a': 1, 'b': 2})
    assert fact_cache['host1'] == {'a': 1, 'b': 2}
    fact_cache.first_order_merge('host1', {'b': 3, 'c': 4})
    assert fact_cache['host1'] == {'a': 1, 'b': 3, 'c': 4}
    fact_cache.first_order_merge('host2', {'a': 1, 'b': 2})
    assert fact_cache['host1'] == {'a': 1, 'b': 3, 'c': 4}
    assert fact_cache['host2'] == {'a': 1, 'b': 2}

# Generated at 2022-06-17 15:57:07.389969
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc is not None

# Generated at 2022-06-17 15:57:14.481197
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('key1', {'k1': 'v1'})
    assert fact_cache['key1'] == {'k1': 'v1'}
    fact_cache.first_order_merge('key1', {'k2': 'v2'})
    assert fact_cache['key1'] == {'k1': 'v1', 'k2': 'v2'}
    fact_cache.first_order_merge('key1', {'k1': 'v3'})
    assert fact_cache['key1'] == {'k1': 'v3', 'k2': 'v2'}

# Generated at 2022-06-17 15:57:17.410380
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:57:21.566806
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 15:57:27.547287
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('localhost', {'ansible_os_family': 'RedHat'})
    assert fact_cache['localhost']['ansible_os_family'] == 'RedHat'
    fact_cache.first_order_merge('localhost', {'ansible_os_family': 'Debian'})
    assert fact_cache['localhost']['ansible_os_family'] == 'Debian'

# Generated at 2022-06-17 15:57:30.004157
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin
    assert fact_cache._plugin.name == 'memory'

# Generated at 2022-06-17 15:57:31.700394
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:57:32.813209
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:57:34.493089
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:57:38.411909
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 15:57:46.523441
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'a': 1, 'b': 2})
    assert fact_cache['host1'] == {'a': 1, 'b': 2}
    fact_cache.first_order_merge('host1', {'b': 3, 'c': 4})
    assert fact_cache['host1'] == {'a': 1, 'b': 3, 'c': 4}
    fact_cache.first_order_merge('host2', {'a': 1, 'b': 2})
    assert fact_cache['host2'] == {'a': 1, 'b': 2}

# Generated at 2022-06-17 15:57:47.800022
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 15:57:50.336090
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc is not None

# Generated at 2022-06-17 15:58:00.788952
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'a': 1, 'b': 2})
    assert fact_cache['host1'] == {'a': 1, 'b': 2}
    fact_cache.first_order_merge('host1', {'a': 3, 'c': 4})
    assert fact_cache['host1'] == {'a': 3, 'b': 2, 'c': 4}

# Generated at 2022-06-17 15:58:01.773592
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 15:58:06.378265
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}

# Generated at 2022-06-17 15:58:08.786905
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 15:58:11.101192
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:58:20.433766
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}

# Generated at 2022-06-17 15:58:21.735422
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:58:28.329467
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value'})
    assert fact_cache['test_host']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_fact': 'new_value'})
    assert fact_cache['test_host']['test_fact'] == 'new_value'
    fact_cache.first_order_merge('test_host', {'new_fact': 'new_value'})
    assert fact_cache['test_host']['new_fact'] == 'new_value'

# Generated at 2022-06-17 15:58:30.091303
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 15:58:34.905006
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    cache.first_order_merge('host1', {'fact1': 'value1'})
    assert cache['host1'] == {'fact1': 'value1'}
    cache.first_order_merge('host1', {'fact2': 'value2'})
    assert cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}

# Generated at 2022-06-17 15:58:42.341117
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:58:43.798967
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache

# Generated at 2022-06-17 15:58:45.792907
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 15:58:47.156570
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'


# Generated at 2022-06-17 15:58:49.831285
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:58:51.009399
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:58:52.130913
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:58:54.977649
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:59:03.552191
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value'})
    assert fact_cache['test_host']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_fact': 'new_value'})
    assert fact_cache['test_host']['test_fact'] == 'new_value'
    fact_cache.first_order_merge('test_host', {'new_fact': 'new_value'})
    assert fact_cache['test_host']['new_fact'] == 'new_value'

# Generated at 2022-06-17 15:59:05.171387
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:59:20.207474
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin is not None

# Generated at 2022-06-17 15:59:24.209020
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge("test_key", {"test_key": "test_value"})
    assert fact_cache["test_key"] == {"test_key": "test_value"}

    fact_cache.first_order_merge("test_key", {"test_key": "test_value2"})
    assert fact_cache["test_key"] == {"test_key": "test_value2"}

# Generated at 2022-06-17 15:59:32.660400
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'a': 1, 'b': 2})
    assert fact_cache['host1'] == {'a': 1, 'b': 2}
    fact_cache.first_order_merge('host1', {'b': 3, 'c': 4})
    assert fact_cache['host1'] == {'a': 1, 'b': 3, 'c': 4}
    fact_cache.first_order_merge('host2', {'a': 1, 'b': 2})
    assert fact_cache['host2'] == {'a': 1, 'b': 2}
    assert fact_cache.keys() == ['host1', 'host2']

# Generated at 2022-06-17 15:59:38.031767
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_key', {'test_key': 'test_value'})
    assert fact_cache['test_key'] == {'test_key': 'test_value'}
    fact_cache.first_order_merge('test_key', {'test_key': 'test_value2'})
    assert fact_cache['test_key'] == {'test_key': 'test_value2'}

# Generated at 2022-06-17 15:59:40.727235
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 15:59:42.707446
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:59:48.924631
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value'})
    assert fact_cache['test_host']['test_fact'] == 'test_value'

    fact_cache.first_order_merge('test_host', {'test_fact': 'new_value'})
    assert fact_cache['test_host']['test_fact'] == 'new_value'

# Generated at 2022-06-17 15:59:50.466460
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None


# Generated at 2022-06-17 15:59:53.273482
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:00:00.188135
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'test_fact': 'test_value'}})
    assert fact_cache['localhost']['ansible_facts']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'test_fact': 'new_value'}})
    assert fact_cache['localhost']['ansible_facts']['test_fact'] == 'new_value'

# Generated at 2022-06-17 16:00:29.332043
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:00:36.108223
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}

# Generated at 2022-06-17 16:00:37.958383
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 16:00:47.901744
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'a': 1, 'b': 2})
    assert fact_cache['host1'] == {'a': 1, 'b': 2}
    fact_cache.first_order_merge('host1', {'b': 3, 'c': 4})
    assert fact_cache['host1'] == {'a': 1, 'b': 3, 'c': 4}
    fact_cache.first_order_merge('host2', {'a': 1, 'b': 2})
    assert fact_cache['host2'] == {'a': 1, 'b': 2}
    fact_cache.first_order_merge('host2', {'b': 3, 'c': 4})

# Generated at 2022-06-17 16:00:53.409718
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}

# Generated at 2022-06-17 16:00:54.404595
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 16:00:56.793382
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 16:01:04.462567
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}

# Generated at 2022-06-17 16:01:05.430421
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin is not None

# Generated at 2022-06-17 16:01:07.324204
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None
    assert fact_cache._plugin.__class__.__name__ == 'FactCacheData'

# Generated at 2022-06-17 16:02:09.723224
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1']['fact1'] == 'value1'
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1']['fact2'] == 'value2'
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1']['fact1'] == 'value3'
    fact_cache.flush()

# Generated at 2022-06-17 16:02:16.713054
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('localhost', {'foo': 'bar'})
    assert fact_cache['localhost'] == {'foo': 'bar'}
    fact_cache.first_order_merge('localhost', {'foo': 'baz'})
    assert fact_cache['localhost'] == {'foo': 'baz'}
    fact_cache.first_order_merge('localhost', {'bar': 'baz'})
    assert fact_cache['localhost'] == {'foo': 'baz', 'bar': 'baz'}

# Generated at 2022-06-17 16:02:17.591200
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:02:20.053463
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:02:20.972215
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 16:02:31.519291
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'ansible_facts': {'fact1': 'value1'}})
    assert fact_cache['host1']['ansible_facts']['fact1'] == 'value1'
    fact_cache.first_order_merge('host1', {'ansible_facts': {'fact2': 'value2'}})
    assert fact_cache['host1']['ansible_facts']['fact1'] == 'value1'
    assert fact_cache['host1']['ansible_facts']['fact2'] == 'value2'
    fact_cache.first_order_merge('host1', {'ansible_facts': {'fact1': 'value3'}})

# Generated at 2022-06-17 16:02:35.562209
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('key1', {'key2': 'value2'})
    assert fact_cache['key1'] == {'key2': 'value2'}
    fact_cache.first_order_merge('key1', {'key3': 'value3'})
    assert fact_cache['key1'] == {'key2': 'value2', 'key3': 'value3'}

# Generated at 2022-06-17 16:02:38.323249
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 16:02:42.888318
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'


# Generated at 2022-06-17 16:02:50.274568
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}

# Generated at 2022-06-17 16:04:53.352797
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'test_fact': 'test_value'}})
    assert fact_cache['localhost']['ansible_facts']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'test_fact': 'test_value2'}})
    assert fact_cache['localhost']['ansible_facts']['test_fact'] == 'test_value2'

# Generated at 2022-06-17 16:04:56.447016
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}

# Generated at 2022-06-17 16:04:57.906516
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:05:04.476526
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('hostname', {'ansible_facts': {'hostname': 'test_hostname'}})
    assert fact_cache['hostname']['ansible_facts']['hostname'] == 'test_hostname'
    fact_cache.first_order_merge('hostname', {'ansible_facts': {'hostname': 'test_hostname2'}})
    assert fact_cache['hostname']['ansible_facts']['hostname'] == 'test_hostname2'

# Generated at 2022-06-17 16:05:05.900913
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache
    assert fact_cache._plugin

# Generated at 2022-06-17 16:05:16.664932
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'ansible_os_family': 'RedHat', 'ansible_distribution': 'CentOS'})
    assert fact_cache['host1'] == {'ansible_os_family': 'RedHat', 'ansible_distribution': 'CentOS'}
    fact_cache.first_order_merge('host1', {'ansible_os_family': 'RedHat', 'ansible_distribution': 'Fedora'})
    assert fact_cache['host1'] == {'ansible_os_family': 'RedHat', 'ansible_distribution': 'Fedora'}

# Generated at 2022-06-17 16:05:17.433756
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin

# Generated at 2022-06-17 16:05:24.702398
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge("test_host", {"test_fact": "test_value"})
    assert fact_cache["test_host"]["test_fact"] == "test_value"
    fact_cache.first_order_merge("test_host", {"test_fact": "new_value"})
    assert fact_cache["test_host"]["test_fact"] == "new_value"

# Generated at 2022-06-17 16:05:26.182783
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:05:29.313072
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('localhost', {'foo': 'bar'})
    assert fact_cache['localhost']['foo'] == 'bar'
    fact_cache.first_order_merge('localhost', {'foo': 'baz'})
    assert fact_cache['localhost']['foo'] == 'baz'