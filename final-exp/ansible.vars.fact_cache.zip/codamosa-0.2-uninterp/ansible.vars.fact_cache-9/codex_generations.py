

# Generated at 2022-06-17 15:56:13.440311
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}

# Generated at 2022-06-17 15:56:18.485006
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value'})
    assert fact_cache['test_host']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_fact': 'new_value'})
    assert fact_cache['test_host']['test_fact'] == 'new_value'

# Generated at 2022-06-17 15:56:21.576938
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin is not None
    assert fc._plugin.__class__.__name__ == 'FactCacheData'


# Generated at 2022-06-17 15:56:24.048260
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 15:56:30.185877
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Test case 1:
    #   - key is not in cache
    #   - value is not in cache
    #   - expected: key and value are added to cache
    cache = FactCache()
    key = 'test_key'
    value = 'test_value'
    cache.first_order_merge(key, value)
    assert key in cache
    assert cache[key] == value

    # Test case 2:
    #   - key is in cache
    #   - value is not in cache
    #   - expected: value is added to cache
    cache = FactCache()
    key = 'test_key'
    value = 'test_value'
    cache[key] = 'old_value'
    cache.first_order_merge(key, value)
    assert key in cache

# Generated at 2022-06-17 15:56:31.336387
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:56:32.454337
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:56:33.621590
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:56:37.452328
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value'})
    assert fact_cache['test_host']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_fact': 'new_value'})
    assert fact_cache['test_host']['test_fact'] == 'new_value'

# Generated at 2022-06-17 15:56:40.173960
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:56:43.546550
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:56:46.045570
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)


# Generated at 2022-06-17 15:56:47.169759
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 15:56:53.817801
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'foo': 'bar'}})
    assert fact_cache['localhost']['ansible_facts']['foo'] == 'bar'
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'foo': 'baz'}})
    assert fact_cache['localhost']['ansible_facts']['foo'] == 'baz'

# Generated at 2022-06-17 15:56:58.324478
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value'})
    assert fact_cache['test_host']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_fact': 'new_value'})
    assert fact_cache['test_host']['test_fact'] == 'new_value'
    fact_cache.first_order_merge('test_host', {'new_fact': 'new_value'})
    assert fact_cache['test_host']['new_fact'] == 'new_value'

# Generated at 2022-06-17 15:57:01.285648
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 15:57:02.081484
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache

# Generated at 2022-06-17 15:57:07.141758
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_key': 'test_value'})
    assert fact_cache['test_host']['test_key'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_key': 'test_value2'})
    assert fact_cache['test_host']['test_key'] == 'test_value2'
    fact_cache.first_order_merge('test_host', {'test_key2': 'test_value2'})
    assert fact_cache['test_host']['test_key2'] == 'test_value2'

# Generated at 2022-06-17 15:57:08.333423
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:57:15.468234
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1', 'fact2': 'value2'})
    assert fact_cache['host1']['fact1'] == 'value1'
    assert fact_cache['host1']['fact2'] == 'value2'
    fact_cache.first_order_merge('host1', {'fact1': 'value3', 'fact3': 'value4'})
    assert fact_cache['host1']['fact1'] == 'value3'
    assert fact_cache['host1']['fact2'] == 'value2'
    assert fact_cache['host1']['fact3'] == 'value4'

# Generated at 2022-06-17 15:57:19.016951
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:57:21.041651
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 15:57:22.440960
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 15:57:24.163848
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:57:30.784434
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}

# Generated at 2022-06-17 15:57:41.283937
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1', 'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value1', 'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value1', 'fact3': 'value3'})

# Generated at 2022-06-17 15:57:48.941288
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'a': 1, 'b': 2})
    fact_cache.first_order_merge('host2', {'a': 3, 'b': 4})
    fact_cache.first_order_merge('host1', {'a': 5, 'b': 6})
    assert fact_cache['host1'] == {'a': 5, 'b': 6}
    assert fact_cache['host2'] == {'a': 3, 'b': 4}

# Generated at 2022-06-17 15:57:58.895336
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc.first_order_merge('host1', {'fact1': 'value1'})
    assert fc['host1'] == {'fact1': 'value1'}
    fc.first_order_merge('host1', {'fact2': 'value2'})
    assert fc['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fc.first_order_merge('host2', {'fact3': 'value3'})
    assert fc['host2'] == {'fact3': 'value3'}
    fc.first_order_merge('host1', {'fact1': 'value4'})

# Generated at 2022-06-17 15:58:00.756109
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 15:58:01.487957
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc

# Generated at 2022-06-17 15:58:17.603380
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge("host1", {"fact1": "value1"})
    assert fact_cache["host1"] == {"fact1": "value1"}
    fact_cache.first_order_merge("host1", {"fact2": "value2"})
    assert fact_cache["host1"] == {"fact1": "value1", "fact2": "value2"}
    fact_cache.first_order_merge("host1", {"fact1": "value3"})
    assert fact_cache["host1"] == {"fact1": "value3", "fact2": "value2"}
    fact_cache.first_order_merge("host2", {"fact1": "value1"})

# Generated at 2022-06-17 15:58:19.029609
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin is not None


# Generated at 2022-06-17 15:58:25.054856
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}

# Generated at 2022-06-17 15:58:26.942419
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin

# Generated at 2022-06-17 15:58:28.671874
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 15:58:30.966956
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 15:58:41.485756
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1']['fact1'] == 'value1'
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1']['fact2'] == 'value2'
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1']['fact1'] == 'value3'
    fact_cache.first_order_merge('host2', {'fact1': 'value1'})
    assert fact_cache['host2']['fact1'] == 'value1'
    fact_cache.first

# Generated at 2022-06-17 15:58:45.579184
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None
    assert fact_cache._plugin.__class__.__name__ == 'FactCacheData'


# Generated at 2022-06-17 15:58:46.511563
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 15:58:47.376372
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 15:58:56.419065
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:58:57.473791
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache is not None

# Generated at 2022-06-17 15:59:04.103432
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value'})
    assert fact_cache['test_host']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_fact': 'new_value'})
    assert fact_cache['test_host']['test_fact'] == 'new_value'

# Generated at 2022-06-17 15:59:07.695943
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value'})
    assert fact_cache['test_host']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_fact': 'new_value'})
    assert fact_cache['test_host']['test_fact'] == 'new_value'

# Generated at 2022-06-17 15:59:10.821957
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin is not None

# Generated at 2022-06-17 15:59:11.841465
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:59:13.221106
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:59:14.709331
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:59:15.777084
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:59:24.844950
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('localhost', {'ansible_os_family': 'RedHat'})
    assert fact_cache['localhost']['ansible_os_family'] == 'RedHat'
    fact_cache.first_order_merge('localhost', {'ansible_distribution': 'CentOS'})
    assert fact_cache['localhost']['ansible_os_family'] == 'RedHat'
    assert fact_cache['localhost']['ansible_distribution'] == 'CentOS'
    fact_cache.first_order_merge('localhost', {'ansible_os_family': 'Debian'})
    assert fact_cache['localhost']['ansible_os_family'] == 'Debian'

# Generated at 2022-06-17 15:59:43.824267
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin.__class__.__name__ == 'FactCacheData'

# Generated at 2022-06-17 15:59:46.061448
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:59:51.485430
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value'})
    assert fact_cache['test_host']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_fact': 'new_value'})
    assert fact_cache['test_host']['test_fact'] == 'new_value'

# Generated at 2022-06-17 15:59:55.068566
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'FactCacheData'


# Generated at 2022-06-17 15:59:56.627530
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 15:59:57.587269
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 16:00:01.407077
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'a': 1, 'b': 2})
    fact_cache.first_order_merge('host1', {'b': 3, 'c': 4})
    assert fact_cache['host1'] == {'a': 1, 'b': 3, 'c': 4}

# Generated at 2022-06-17 16:00:07.064731
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    cache.first_order_merge('test_host', {'test_fact': 'test_value'})
    assert cache['test_host']['test_fact'] == 'test_value'
    cache.first_order_merge('test_host', {'test_fact': 'new_value'})
    assert cache['test_host']['test_fact'] == 'new_value'

# Generated at 2022-06-17 16:00:09.398644
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:00:12.700498
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}

# Generated at 2022-06-17 16:00:51.829028
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'test_fact': 'test_value'}})
    assert fact_cache['localhost']['ansible_facts']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'test_fact': 'test_value_2'}})
    assert fact_cache['localhost']['ansible_facts']['test_fact'] == 'test_value_2'

# Generated at 2022-06-17 16:00:57.039698
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'a': 1, 'b': 2})
    assert fact_cache['host1'] == {'a': 1, 'b': 2}
    fact_cache.first_order_merge('host1', {'a': 3, 'c': 4})
    assert fact_cache['host1'] == {'a': 3, 'b': 2, 'c': 4}
    fact_cache.first_order_merge('host2', {'a': 1, 'b': 2})
    assert fact_cache['host2'] == {'a': 1, 'b': 2}
    fact_cache.first_order_merge('host2', {'a': 3, 'c': 4})

# Generated at 2022-06-17 16:00:57.761731
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache._plugin is not None

# Generated at 2022-06-17 16:00:59.013981
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:01:04.822580
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value'})
    assert fact_cache['test_host']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_fact': 'new_value'})
    assert fact_cache['test_host']['test_fact'] == 'new_value'

# Generated at 2022-06-17 16:01:11.073934
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}

# Generated at 2022-06-17 16:01:17.579469
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge("host1", {"foo": "bar"})
    assert fact_cache["host1"] == {"foo": "bar"}
    fact_cache.first_order_merge("host1", {"foo": "baz"})
    assert fact_cache["host1"] == {"foo": "baz"}
    fact_cache.first_order_merge("host1", {"bar": "baz"})
    assert fact_cache["host1"] == {"foo": "baz", "bar": "baz"}

# Generated at 2022-06-17 16:01:22.328439
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin is not None
    assert fc._plugin.contains('test') is False
    fc['test'] = 'test'
    assert fc._plugin.contains('test') is True
    assert fc._plugin.get('test') == 'test'
    assert fc['test'] == 'test'
    assert fc.keys() == ['test']
    assert len(fc) == 1
    assert 'test' in fc
    assert fc.copy() == {'test': 'test'}
    fc.flush()
    assert fc._plugin.contains('test') is False
    assert fc._plugin.get('test') is None
    assert fc['test'] is None
    assert fc.keys() == []
    assert len(fc) == 0


# Generated at 2022-06-17 16:01:29.633451
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}

# Generated at 2022-06-17 16:01:30.397447
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:02:39.765676
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:02:43.745528
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert isinstance(fc, FactCache)


# Generated at 2022-06-17 16:02:45.691089
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:02:49.215586
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:02:50.319713
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:02:51.175769
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:02:52.772999
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin is not None


# Generated at 2022-06-17 16:02:59.420319
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}

# Generated at 2022-06-17 16:03:01.035366
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin


# Generated at 2022-06-17 16:03:02.464839
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 16:05:31.720804
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    cache.first_order_merge('hostname', {'ansible_facts': {'hostname': 'test'}})
    assert cache['hostname']['ansible_facts']['hostname'] == 'test'
    cache.first_order_merge('hostname', {'ansible_facts': {'hostname': 'test2'}})
    assert cache['hostname']['ansible_facts']['hostname'] == 'test2'
    cache.first_order_merge('hostname', {'ansible_facts': {'hostname': 'test3'}})
    assert cache['hostname']['ansible_facts']['hostname'] == 'test3'

# Generated at 2022-06-17 16:05:34.658516
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value'})
    assert fact_cache['test_host']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_fact': 'new_value'})
    assert fact_cache['test_host']['test_fact'] == 'new_value'

# Generated at 2022-06-17 16:05:47.450373
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}

# Generated at 2022-06-17 16:05:48.927457
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin.__class__.__name__ == 'FactCache'
    assert fc._plugin.__class__.__module__ == 'ansible.plugins.cache.fact_cache'

# Generated at 2022-06-17 16:05:49.591788
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 16:05:54.483637
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host2', {'fact3': 'value3'})
    assert fact_cache['host2'] == {'fact3': 'value3'}

# Generated at 2022-06-17 16:06:01.560234
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge("host1", {"ansible_os_family": "RedHat"})
    assert fact_cache["host1"] == {"ansible_os_family": "RedHat"}

    fact_cache.first_order_merge("host1", {"ansible_distribution": "CentOS"})
    assert fact_cache["host1"] == {"ansible_os_family": "RedHat", "ansible_distribution": "CentOS"}

# Generated at 2022-06-17 16:06:02.612215
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:06:04.674816
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin is not None