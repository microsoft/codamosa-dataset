

# Generated at 2022-06-17 15:56:13.085098
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value'})
    assert fact_cache['test_host']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value2'})
    assert fact_cache['test_host']['test_fact'] == 'test_value2'
    fact_cache.first_order_merge('test_host', {'test_fact2': 'test_value2'})
    assert fact_cache['test_host']['test_fact2'] == 'test_value2'

# Generated at 2022-06-17 15:56:18.222304
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value'})
    assert fact_cache['test_host']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_fact': 'new_value'})
    assert fact_cache['test_host']['test_fact'] == 'new_value'

# Generated at 2022-06-17 15:56:20.939227
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 15:56:22.287882
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:56:28.792084
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_key': 'test_value'})
    assert fact_cache['test_host']['test_key'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_key': 'test_value2'})
    assert fact_cache['test_host']['test_key'] == 'test_value2'
    fact_cache.first_order_merge('test_host', {'test_key2': 'test_value3'})
    assert fact_cache['test_host']['test_key2'] == 'test_value3'
    fact_cache.flush()

# Generated at 2022-06-17 15:56:29.753774
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 15:56:34.398971
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('key1', {'key2': 'value2'})
    assert fact_cache['key1'] == {'key2': 'value2'}
    fact_cache.first_order_merge('key1', {'key3': 'value3'})
    assert fact_cache['key1'] == {'key2': 'value2', 'key3': 'value3'}

# Generated at 2022-06-17 15:56:46.117708
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'test_fact': 'test_value'}})
    assert fact_cache['localhost']['ansible_facts']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'test_fact': 'test_value2'}})
    assert fact_cache['localhost']['ansible_facts']['test_fact'] == 'test_value2'

# Generated at 2022-06-17 15:56:54.300996
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}

# Generated at 2022-06-17 15:56:58.576230
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}

# Generated at 2022-06-17 15:57:01.245238
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 15:57:05.336722
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value'})
    assert fact_cache['test_host']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value2'})
    assert fact_cache['test_host']['test_fact'] == 'test_value2'

# Generated at 2022-06-17 15:57:11.896754
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value'})
    assert fact_cache['test_host']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value_2'})
    assert fact_cache['test_host']['test_fact'] == 'test_value_2'

# Generated at 2022-06-17 15:57:13.223097
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 15:57:17.618361
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 15:57:27.696889
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}
    fact_cache.first_order_merge('host2', {'fact1': 'value1'})

# Generated at 2022-06-17 15:57:34.433220
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'test_fact': 'test_value'}})
    assert fact_cache['localhost']['ansible_facts']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'test_fact': 'new_value'}})
    assert fact_cache['localhost']['ansible_facts']['test_fact'] == 'new_value'

# Generated at 2022-06-17 15:57:40.120173
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin.__class__.__name__ == 'FactCacheData'
    assert fc._plugin.__class__.__module__ == 'ansible.plugins.cache.fact_cache'


# Generated at 2022-06-17 15:57:42.348147
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 15:57:44.444364
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 15:57:46.814371
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache
    assert fact_cache._plugin

# Generated at 2022-06-17 15:57:47.918001
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:57:56.525102
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'ansible_facts': {'a': 1, 'b': 2}})
    fact_cache.first_order_merge('host1', {'ansible_facts': {'b': 3, 'c': 4}})
    assert fact_cache['host1']['ansible_facts']['a'] == 1
    assert fact_cache['host1']['ansible_facts']['b'] == 3
    assert fact_cache['host1']['ansible_facts']['c'] == 4

# Generated at 2022-06-17 15:57:57.940320
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:57:59.053661
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:58:00.056847
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:58:01.355498
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'FactCacheData'

# Generated at 2022-06-17 15:58:05.575505
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge("host1", {"fact1": "value1", "fact2": "value2"})
    assert fact_cache["host1"] == {"fact1": "value1", "fact2": "value2"}
    fact_cache.first_order_merge("host1", {"fact1": "value3", "fact3": "value3"})
    assert fact_cache["host1"] == {"fact1": "value3", "fact2": "value2", "fact3": "value3"}

# Generated at 2022-06-17 15:58:06.849793
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin is not None


# Generated at 2022-06-17 15:58:08.863337
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 15:58:12.544955
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache

# Generated at 2022-06-17 15:58:14.448908
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 15:58:20.436283
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value'})
    assert fact_cache['test_host']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_fact': 'new_value'})
    assert fact_cache['test_host']['test_fact'] == 'new_value'

# Generated at 2022-06-17 15:58:25.996529
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('localhost', {'ansible_os_family': 'RedHat'})
    assert fact_cache['localhost']['ansible_os_family'] == 'RedHat'
    fact_cache.first_order_merge('localhost', {'ansible_distribution': 'CentOS'})
    assert fact_cache['localhost']['ansible_distribution'] == 'CentOS'
    assert fact_cache['localhost']['ansible_os_family'] == 'RedHat'
    fact_cache.first_order_merge('localhost', {'ansible_os_family': 'Debian'})
    assert fact_cache['localhost']['ansible_os_family'] == 'Debian'

# Generated at 2022-06-17 15:58:27.811913
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:58:36.450386
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host2', {'fact1': 'value1'})
    assert fact_cache['host2'] == {'fact1': 'value1'}
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}

# Generated at 2022-06-17 15:58:38.689478
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin is not None

# Generated at 2022-06-17 15:58:46.480740
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    cache.first_order_merge('test_host', {'test_key': 'test_value'})
    assert cache['test_host']['test_key'] == 'test_value'
    cache.first_order_merge('test_host', {'test_key': 'test_value_2'})
    assert cache['test_host']['test_key'] == 'test_value_2'

# Generated at 2022-06-17 15:58:49.666996
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_key': 'test_value'})
    assert fact_cache['test_host']['test_key'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_key': 'test_value2'})
    assert fact_cache['test_host']['test_key'] == 'test_value2'

# Generated at 2022-06-17 15:58:50.327505
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:59:05.095033
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}
    fact_cache.first_order_merge('host2', {'fact1': 'value1'})

# Generated at 2022-06-17 15:59:06.695696
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None


# Generated at 2022-06-17 15:59:07.772965
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:59:15.275314
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('localhost', {'ansible_os_family': 'RedHat'})
    assert fact_cache['localhost']['ansible_os_family'] == 'RedHat'
    fact_cache.first_order_merge('localhost', {'ansible_os_family': 'Debian'})
    assert fact_cache['localhost']['ansible_os_family'] == 'Debian'

# Generated at 2022-06-17 15:59:22.002252
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'a': 1, 'b': 2})
    assert fact_cache['host1'] == {'a': 1, 'b': 2}
    fact_cache.first_order_merge('host1', {'b': 3, 'c': 4})
    assert fact_cache['host1'] == {'a': 1, 'b': 3, 'c': 4}

# Generated at 2022-06-17 15:59:26.497780
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'key1': 'value1'})
    assert fact_cache['host1'] == {'key1': 'value1'}
    fact_cache.first_order_merge('host1', {'key2': 'value2'})
    assert fact_cache['host1'] == {'key1': 'value1', 'key2': 'value2'}
    fact_cache.first_order_merge('host2', {'key1': 'value1'})
    assert fact_cache['host2'] == {'key1': 'value1'}

# Generated at 2022-06-17 15:59:27.575085
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 15:59:29.179629
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin

# Generated at 2022-06-17 15:59:30.197729
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:59:31.126355
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:59:44.241762
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 15:59:49.542716
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value'})
    assert fact_cache['test_host']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_fact': 'new_value'})
    assert fact_cache['test_host']['test_fact'] == 'new_value'

# Generated at 2022-06-17 15:59:51.086353
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:59:54.047925
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc is not None

# Generated at 2022-06-17 15:59:55.727938
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None


# Generated at 2022-06-17 16:00:01.222108
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'a': 1, 'b': 2})
    assert fact_cache['host1'] == {'a': 1, 'b': 2}
    fact_cache.first_order_merge('host1', {'a': 3, 'c': 4})
    assert fact_cache['host1'] == {'a': 3, 'b': 2, 'c': 4}

# Generated at 2022-06-17 16:00:04.151224
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin

# Generated at 2022-06-17 16:00:06.005064
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:00:08.798539
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:00:09.983593
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:00:38.648937
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 16:00:40.605513
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 16:00:44.141179
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 16:00:47.220803
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin
    assert fact_cache._plugin.name == C.CACHE_PLUGIN

# Generated at 2022-06-17 16:00:53.838242
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'a': 1, 'b': 2})
    assert fact_cache['host1'] == {'a': 1, 'b': 2}
    fact_cache.first_order_merge('host1', {'b': 3, 'c': 4})
    assert fact_cache['host1'] == {'a': 1, 'b': 3, 'c': 4}
    fact_cache.first_order_merge('host2', {'a': 1, 'b': 2})
    assert fact_cache['host2'] == {'a': 1, 'b': 2}
    fact_cache.first_order_merge('host2', {'b': 3, 'c': 4})

# Generated at 2022-06-17 16:00:55.698936
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache

# Generated at 2022-06-17 16:01:04.615882
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('key1', {'key2': 'value2'})
    assert fact_cache['key1']['key2'] == 'value2'
    fact_cache.first_order_merge('key1', {'key3': 'value3'})
    assert fact_cache['key1']['key3'] == 'value3'
    fact_cache.first_order_merge('key1', {'key2': 'value4'})
    assert fact_cache['key1']['key2'] == 'value4'
    fact_cache.first_order_merge('key1', {'key2': 'value5'})
    assert fact_cache['key1']['key2'] == 'value5'
    fact_cache.first

# Generated at 2022-06-17 16:01:12.444821
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Create a FactCache object
    fact_cache = FactCache()

    # Create a dictionary with key 'hostvars' and value 'hostvars_value'
    hostvars = {'hostvars': 'hostvars_value'}

    # Create a dictionary with key 'hostvars' and value 'hostvars_value_1'
    hostvars_1 = {'hostvars': 'hostvars_value_1'}

    # Call first_order_merge method of FactCache class with key 'hostvars' and value 'hostvars_value'
    fact_cache.first_order_merge('hostvars', 'hostvars_value')

    # Call first_order_merge method of FactCache class with key 'hostvars' and value 'hostvars_value_1'
    fact_cache

# Generated at 2022-06-17 16:01:18.944471
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}

# Generated at 2022-06-17 16:01:20.753547
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 16:02:22.129708
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1']['fact1'] == 'value1'
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1']['fact2'] == 'value2'
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1']['fact1'] == 'value3'
    fact_cache.flush()
    assert fact_cache.keys() == []

# Generated at 2022-06-17 16:02:22.785423
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 16:02:26.695024
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin == cache_loader.get(C.CACHE_PLUGIN)


# Generated at 2022-06-17 16:02:27.976247
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:02:34.930921
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1']['fact1'] == 'value1'
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1']['fact2'] == 'value2'
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1']['fact1'] == 'value3'

# Generated at 2022-06-17 16:02:38.155382
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin

# Generated at 2022-06-17 16:02:40.292120
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:02:49.428751
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin
    assert fact_cache._plugin.contains('localhost') == False
    assert fact_cache.keys() == []
    assert fact_cache.copy() == {}
    assert fact_cache.__len__() == 0
    assert fact_cache.__contains__('localhost') == False
    assert fact_cache.__getitem__('localhost') == None
    assert fact_cache.__setitem__('localhost', '127.0.0.1') == None
    assert fact_cache.__delitem__('localhost') == None
    assert fact_cache.__iter__() == []
    assert fact_cache.flush() == None
    assert fact_cache.keys() == []
    assert fact_cache.copy() == {}
    assert fact_cache.__len__() == 0

# Generated at 2022-06-17 16:02:55.623221
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1']['fact1'] == 'value1'
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1']['fact2'] == 'value2'
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1']['fact1'] == 'value3'
    fact_cache.first_order_merge('host2', {'fact1': 'value4'})
    assert fact_cache['host2']['fact1'] == 'value4'

# Generated at 2022-06-17 16:02:58.744664
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin
    assert fact_cache._plugin.contains('localhost') == False

# Generated at 2022-06-17 16:04:56.024795
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}

# Generated at 2022-06-17 16:04:57.148738
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:05:03.111036
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    cache.first_order_merge('test_host', {'test_key': 'test_value'})
    assert cache['test_host']['test_key'] == 'test_value'
    cache.first_order_merge('test_host', {'test_key': 'test_value2'})
    assert cache['test_host']['test_key'] == 'test_value2'

# Generated at 2022-06-17 16:05:03.796457
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:05:04.976860
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 16:05:16.101597
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'a': 1}})
    assert fact_cache['localhost']['ansible_facts']['a'] == 1
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'b': 2}})
    assert fact_cache['localhost']['ansible_facts']['b'] == 2
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'a': 3}})
    assert fact_cache['localhost']['ansible_facts']['a'] == 3
    assert fact_cache['localhost']['ansible_facts']['b'] == 2

# Generated at 2022-06-17 16:05:16.718912
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:05:18.610344
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None


# Generated at 2022-06-17 16:05:27.493034
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}

# Generated at 2022-06-17 16:05:30.844011
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('key', {'a': 1, 'b': 2})
    assert fact_cache['key'] == {'a': 1, 'b': 2}
    fact_cache.first_order_merge('key', {'a': 3, 'c': 4})
    assert fact_cache['key'] == {'a': 3, 'b': 2, 'c': 4}