

# Generated at 2022-06-17 15:56:12.258324
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'ansible_facts': {'test_fact': 'test_value'}})
    assert fact_cache['test_host']['ansible_facts']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'ansible_facts': {'test_fact': 'test_value2'}})
    assert fact_cache['test_host']['ansible_facts']['test_fact'] == 'test_value2'

# Generated at 2022-06-17 15:56:13.336479
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:56:20.483937
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}
    fact_cache.first_order_merge('host2', {'fact1': 'value1'})

# Generated at 2022-06-17 15:56:28.170697
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}
    fact_cache.first_order_merge('host2', {'fact3': 'value3'})

# Generated at 2022-06-17 15:56:36.382679
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Test for first_order_merge method of class FactCache
    # Test case 1:
    # Test for the case when the key is not present in the cache
    # Expected result:
    # The key and value should be added to the cache
    fact_cache = FactCache()
    key = 'test_key'
    value = 'test_value'
    fact_cache.first_order_merge(key, value)
    assert fact_cache[key] == value

    # Test case 2:
    # Test for the case when the key is present in the cache
    # Expected result:
    # The value should be updated in the cache
    value = 'test_value_updated'
    fact_cache.first_order_merge(key, value)
    assert fact_cache[key] == value

# Generated at 2022-06-17 15:56:47.531101
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}

# Generated at 2022-06-17 15:56:55.471720
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'new_value1'})
    assert fact_cache['host1'] == {'fact1': 'new_value1', 'fact2': 'value2'}

# Generated at 2022-06-17 15:57:01.735700
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'a': 1, 'b': 2})
    fact_cache.first_order_merge('host1', {'a': 3, 'c': 4})
    assert fact_cache['host1'] == {'a': 3, 'b': 2, 'c': 4}

# Generated at 2022-06-17 15:57:02.844234
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:57:06.291326
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:57:14.210211
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'foo': 'bar'})
    assert fact_cache['host1'] == {'foo': 'bar'}
    fact_cache.first_order_merge('host1', {'foo': 'baz'})
    assert fact_cache['host1'] == {'foo': 'baz'}
    fact_cache.first_order_merge('host1', {'bar': 'baz'})
    assert fact_cache['host1'] == {'foo': 'baz', 'bar': 'baz'}

# Generated at 2022-06-17 15:57:17.363954
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:57:18.383994
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache

# Generated at 2022-06-17 15:57:27.051714
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'a': 1, 'b': 2})
    assert fact_cache['host1'] == {'a': 1, 'b': 2}
    fact_cache.first_order_merge('host1', {'a': 2, 'c': 3})
    assert fact_cache['host1'] == {'a': 2, 'b': 2, 'c': 3}
    fact_cache.first_order_merge('host2', {'a': 1, 'b': 2})
    assert fact_cache['host2'] == {'a': 1, 'b': 2}

# Generated at 2022-06-17 15:57:34.253155
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'a': 1})
    assert fact_cache['host1'] == {'a': 1}
    fact_cache.first_order_merge('host1', {'b': 2})
    assert fact_cache['host1'] == {'a': 1, 'b': 2}
    fact_cache.first_order_merge('host1', {'a': 3})
    assert fact_cache['host1'] == {'a': 3, 'b': 2}

# Generated at 2022-06-17 15:57:35.836003
# Unit test for constructor of class FactCache
def test_FactCache():
    assert FactCache()

# Generated at 2022-06-17 15:57:38.411716
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None


# Generated at 2022-06-17 15:57:43.796851
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'a': 1, 'b': 2})
    assert fact_cache['host1'] == {'a': 1, 'b': 2}
    fact_cache.first_order_merge('host1', {'b': 3, 'c': 4})
    assert fact_cache['host1'] == {'a': 1, 'b': 3, 'c': 4}

# Generated at 2022-06-17 15:57:50.678479
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}

# Generated at 2022-06-17 15:57:52.298974
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:57:55.857529
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:57:57.192180
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 15:58:04.068959
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin
    assert fact_cache._plugin.contains('localhost') == False
    assert fact_cache.keys() == []
    assert fact_cache.copy() == {}
    assert fact_cache.flush() == None
    assert fact_cache.first_order_merge('localhost', {'ansible_facts': {'test': 'test'}}) == None
    assert fact_cache.keys() == ['localhost']
    assert fact_cache.copy() == {'localhost': {'ansible_facts': {'test': 'test'}}}
    assert fact_cache.flush() == None
    assert fact_cache.keys() == []
    assert fact_cache.copy() == {}

# Generated at 2022-06-17 15:58:06.050654
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 15:58:08.900389
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_key': 'test_value'})
    assert fact_cache['test_host']['test_key'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_key': 'test_value2'})
    assert fact_cache['test_host']['test_key'] == 'test_value2'

# Generated at 2022-06-17 15:58:19.029632
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}

# Generated at 2022-06-17 15:58:27.008865
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}

# Generated at 2022-06-17 15:58:28.713263
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:58:30.962901
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 15:58:37.367878
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}


# Generated at 2022-06-17 15:58:48.690603
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'test_fact': 'test_value'}})
    assert fact_cache['localhost']['ansible_facts']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'test_fact': 'test_value2'}})
    assert fact_cache['localhost']['ansible_facts']['test_fact'] == 'test_value2'

# Generated at 2022-06-17 15:58:53.223264
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('localhost', {'ansible_os_family': 'RedHat'})
    assert fact_cache['localhost']['ansible_os_family'] == 'RedHat'
    fact_cache.first_order_merge('localhost', {'ansible_os_family': 'Debian'})
    assert fact_cache['localhost']['ansible_os_family'] == 'Debian'

# Generated at 2022-06-17 15:58:55.513122
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:58:56.870502
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin is not None


# Generated at 2022-06-17 15:58:58.320493
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 15:59:08.061196
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1']['fact1'] == 'value1'
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1']['fact2'] == 'value2'
    fact_cache.first_order_merge('host2', {'fact1': 'value1'})
    assert fact_cache['host2']['fact1'] == 'value1'
    fact_cache.first_order_merge('host2', {'fact2': 'value2'})
    assert fact_cache['host2']['fact2'] == 'value2'

# Generated at 2022-06-17 15:59:10.935377
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:59:20.205563
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}

# Generated at 2022-06-17 15:59:20.890888
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 15:59:21.968184
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin is not None

# Generated at 2022-06-17 15:59:37.329908
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:59:39.479172
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:59:49.040400
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'key1': 'value1'})
    assert fact_cache['host1'] == {'key1': 'value1'}
    fact_cache.first_order_merge('host1', {'key2': 'value2'})
    assert fact_cache['host1'] == {'key1': 'value1', 'key2': 'value2'}
    fact_cache.first_order_merge('host1', {'key1': 'value3'})
    assert fact_cache['host1'] == {'key1': 'value3', 'key2': 'value2'}

# Generated at 2022-06-17 15:59:59.157288
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value'})
    assert fact_cache['test_host']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_fact': 'new_value'})
    assert fact_cache['test_host']['test_fact'] == 'new_value'
    fact_cache.first_order_merge('test_host', {'new_fact': 'new_value'})
    assert fact_cache['test_host']['new_fact'] == 'new_value'
    fact_cache.flush()

# Generated at 2022-06-17 16:00:00.534223
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:00:04.425844
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 16:00:07.609308
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin
    assert fact_cache._plugin.contains('localhost') == False

# Generated at 2022-06-17 16:00:13.629658
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}

# Generated at 2022-06-17 16:00:15.581609
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 16:00:17.888033
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 16:00:51.801011
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin
    assert fact_cache._plugin.contains('localhost') == False
    assert fact_cache._plugin.get('localhost') == None
    assert fact_cache._plugin.set('localhost', 'test') == None
    assert fact_cache._plugin.delete('localhost') == None
    assert fact_cache._plugin.keys() == []
    assert fact_cache._plugin.flush() == None
    assert fact_cache.copy() == {}
    assert fact_cache.keys() == []
    assert fact_cache.flush() == None
    assert fact_cache.first_order_merge('localhost', 'test') == None

# Generated at 2022-06-17 16:00:52.685086
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:00:54.102957
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None
    assert fact_cache._plugin.__class__.__name__ == 'FactCacheData'

# Generated at 2022-06-17 16:00:54.862132
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc is not None

# Generated at 2022-06-17 16:00:56.303272
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache

# Generated at 2022-06-17 16:00:57.085312
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache
    assert fact_cache._plugin

# Generated at 2022-06-17 16:00:58.152986
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:00:58.857907
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin is not None

# Generated at 2022-06-17 16:00:59.529795
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:01:00.889678
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache._plugin.__class__.__name__ == 'FactCacheData'
    assert cache._plugin.__class__.__module__ == 'ansible.plugins.cache.memory'

# Generated at 2022-06-17 16:01:57.062867
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:02:05.300141
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Test case 1:
    #   - host_cache is empty
    #   - host_facts is not empty
    #   - host_facts should be added to host_cache
    #   - host_facts should be added to fact_cache
    #   - host_cache should be added to fact_cache
    fact_cache = FactCache()
    host_cache = {}
    host_facts = {'ansible_os_family': 'RedHat'}
    fact_cache.first_order_merge('localhost', host_facts)
    assert fact_cache['localhost'] == host_facts
    assert fact_cache['localhost'] == host_cache

    # Test case 2:
    #   - host_cache is not empty
    #   - host_facts is not empty
    #   - host_facts should be added to host_cache
   

# Generated at 2022-06-17 16:02:11.428453
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.plugins.cache import BaseCacheModule
    from ansible.plugins.cache.memory import CacheModule as MemoryCacheModule
    from ansible.plugins.cache.redis import CacheModule as RedisCacheModule

    cache_plugin = 'memory'
    cache_plugin_class = MemoryCacheModule
    fact_cache = FactCache()
    assert isinstance(fact_cache._plugin, cache_plugin_class)

    cache_plugin = 'redis'
    cache_plugin_class = RedisCacheModule
    fact_cache = FactCache()
    assert isinstance(fact_cache._plugin, cache_plugin_class)

    cache_plugin = 'not_a_cache_plugin'
    cache_plugin_class = BaseCacheModule
    fact_cache = FactCache()
    assert isinstance(fact_cache._plugin, cache_plugin_class)

# Generated at 2022-06-17 16:02:13.075378
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:02:15.445536
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc is not None
    assert fc._plugin is not None
    assert fc._plugin.__class__.__name__ == 'FactCacheData'


# Generated at 2022-06-17 16:02:23.033683
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('key1', {'key2': 'value2'})
    assert fact_cache['key1']['key2'] == 'value2'
    fact_cache.first_order_merge('key1', {'key3': 'value3'})
    assert fact_cache['key1']['key2'] == 'value2'
    assert fact_cache['key1']['key3'] == 'value3'
    fact_cache.first_order_merge('key1', {'key2': 'value4'})
    assert fact_cache['key1']['key2'] == 'value4'
    assert fact_cache['key1']['key3'] == 'value3'

# Generated at 2022-06-17 16:02:29.503677
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}

# Generated at 2022-06-17 16:02:31.323917
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin is not None


# Generated at 2022-06-17 16:02:32.781285
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 16:02:33.847839
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:04:29.652591
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 16:04:37.927851
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value'})
    assert fact_cache['test_host']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_fact': 'new_value'})
    assert fact_cache['test_host']['test_fact'] == 'new_value'
    fact_cache.first_order_merge('test_host', {'new_fact': 'new_value'})
    assert fact_cache['test_host']['new_fact'] == 'new_value'
    fact_cache.flush()

# Generated at 2022-06-17 16:04:39.826245
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 16:04:46.747739
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc.first_order_merge('host1', {'a': 1, 'b': 2})
    assert fc['host1'] == {'a': 1, 'b': 2}
    fc.first_order_merge('host1', {'b': 3, 'c': 4})
    assert fc['host1'] == {'a': 1, 'b': 3, 'c': 4}

# Generated at 2022-06-17 16:04:49.074693
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin.__class__.__name__ == 'MemoryCacheModule'

# Generated at 2022-06-17 16:04:51.173112
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 16:04:52.140330
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin

# Generated at 2022-06-17 16:04:53.090527
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None


# Generated at 2022-06-17 16:04:53.841790
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:05:02.716894
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}