

# Generated at 2022-06-17 15:56:06.743020
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin is not None

# Generated at 2022-06-17 15:56:12.639803
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_key': 'test_value'})
    assert fact_cache['test_host']['test_key'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_key': 'test_value2'})
    assert fact_cache['test_host']['test_key'] == 'test_value2'

# Generated at 2022-06-17 15:56:19.857516
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin
    assert fact_cache._plugin.contains('localhost') == False
    assert fact_cache._plugin.get('localhost') == None
    assert fact_cache._plugin.set('localhost', 'localhost') == None
    assert fact_cache._plugin.contains('localhost') == True
    assert fact_cache._plugin.get('localhost') == 'localhost'
    assert fact_cache._plugin.delete('localhost') == None
    assert fact_cache._plugin.contains('localhost') == False
    assert fact_cache._plugin.get('localhost') == None
    assert fact_cache._plugin.keys() == []
    assert fact_cache._plugin.flush() == None
    assert fact_cache._plugin.keys() == []

# Generated at 2022-06-17 15:56:25.604170
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'test': 'test'}})
    assert fact_cache['localhost']['ansible_facts']['test'] == 'test'
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'test': 'test2'}})
    assert fact_cache['localhost']['ansible_facts']['test'] == 'test2'

# Generated at 2022-06-17 15:56:31.033078
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'a': 1, 'b': 2})
    assert fact_cache['host1'] == {'a': 1, 'b': 2}
    fact_cache.first_order_merge('host1', {'c': 3})
    assert fact_cache['host1'] == {'a': 1, 'b': 2, 'c': 3}
    fact_cache.first_order_merge('host2', {'a': 1, 'b': 2})
    assert fact_cache['host2'] == {'a': 1, 'b': 2}
    fact_cache.first_order_merge('host2', {'c': 3})

# Generated at 2022-06-17 15:56:35.699534
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value'})
    assert fact_cache['test_host']['test_fact'] == 'test_value'

    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value2'})
    assert fact_cache['test_host']['test_fact'] == 'test_value2'

# Generated at 2022-06-17 15:56:38.717945
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1']['fact1'] == 'value1'
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1']['fact2'] == 'value2'
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1']['fact1'] == 'value3'
    fact_cache.flush()

# Generated at 2022-06-17 15:56:41.977957
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}

# Generated at 2022-06-17 15:56:45.323757
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}

# Generated at 2022-06-17 15:56:46.579563
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc is not None


# Generated at 2022-06-17 15:56:54.127287
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value'})
    assert fact_cache['test_host']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_fact': 'new_value'})
    assert fact_cache['test_host']['test_fact'] == 'new_value'

# Generated at 2022-06-17 15:56:55.849710
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin

# Generated at 2022-06-17 15:57:05.163418
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host_1', {'fact_1': 'value_1'})
    assert fact_cache['host_1'] == {'fact_1': 'value_1'}
    fact_cache.first_order_merge('host_1', {'fact_2': 'value_2'})
    assert fact_cache['host_1'] == {'fact_1': 'value_1', 'fact_2': 'value_2'}
    fact_cache.first_order_merge('host_1', {'fact_1': 'value_3'})
    assert fact_cache['host_1'] == {'fact_1': 'value_3', 'fact_2': 'value_2'}

# Generated at 2022-06-17 15:57:07.028290
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache

# Generated at 2022-06-17 15:57:15.076537
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import pytest
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.plugins.loader import cache_loader
    from ansible.utils.display import Display
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    display = Display()
    class MockCachePlugin(MutableMapping):
        def __init__(self, *args, **kwargs):
            self.data = {}
        def __getitem__(self, key):
            return self.data[key]
        def __setitem__(self, key, value):
            self.data[key] = value
        def __delitem__(self, key):
            del self.data[key]
        def __contains__(self, key):
            return key in self.data

# Generated at 2022-06-17 15:57:18.333978
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'


# Generated at 2022-06-17 15:57:19.756108
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin is not None


# Generated at 2022-06-17 15:57:22.539458
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 15:57:28.624863
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'foo': 'bar'}})
    assert fact_cache['localhost']['ansible_facts']['foo'] == 'bar'
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'foo': 'baz'}})
    assert fact_cache['localhost']['ansible_facts']['foo'] == 'baz'

# Generated at 2022-06-17 15:57:29.347711
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache

# Generated at 2022-06-17 15:57:33.811855
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin

# Generated at 2022-06-17 15:57:35.615686
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 15:57:37.631349
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:57:39.609503
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin is not None

# Generated at 2022-06-17 15:57:40.993430
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc

# Generated at 2022-06-17 15:57:45.132939
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin is not None
    assert fc._plugin.__class__.__name__ == 'FactCacheData'


# Generated at 2022-06-17 15:57:46.754553
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:57:47.859660
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 15:57:55.047328
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('key', {'a': 1, 'b': 2})
    assert fact_cache['key'] == {'a': 1, 'b': 2}
    fact_cache.first_order_merge('key', {'b': 3, 'c': 4})
    assert fact_cache['key'] == {'a': 1, 'b': 3, 'c': 4}

# Generated at 2022-06-17 15:57:56.664096
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 15:58:03.054461
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:58:11.838466
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'test_fact': 'test_value'}})
    assert fact_cache['localhost']['ansible_facts']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'test_fact': 'test_value2'}})
    assert fact_cache['localhost']['ansible_facts']['test_fact'] == 'test_value2'

# Generated at 2022-06-17 15:58:13.942594
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:58:15.701728
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 15:58:16.817796
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 15:58:18.551338
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None


# Generated at 2022-06-17 15:58:25.802972
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'test_fact': 'test_value'}})
    assert fact_cache['localhost']['ansible_facts']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'test_fact': 'test_value2'}})
    assert fact_cache['localhost']['ansible_facts']['test_fact'] == 'test_value2'

# Generated at 2022-06-17 15:58:27.029915
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc is not None

# Generated at 2022-06-17 15:58:28.709320
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:58:35.939718
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1']['fact1'] == 'value1'
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1']['fact2'] == 'value2'
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1']['fact1'] == 'value3'

# Generated at 2022-06-17 15:58:54.941737
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'test': 'test'}})
    assert fact_cache['localhost']['ansible_facts']['test'] == 'test'
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'test': 'test2'}})
    assert fact_cache['localhost']['ansible_facts']['test'] == 'test2'
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'test2': 'test2'}})
    assert fact_cache['localhost']['ansible_facts']['test'] == 'test2'
    assert fact_cache['localhost']['ansible_facts']['test2']

# Generated at 2022-06-17 15:59:04.751362
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin
    assert fact_cache._plugin.contains('localhost') == False
    assert fact_cache.keys() == []
    assert fact_cache.copy() == {}
    assert fact_cache.flush() == None
    assert fact_cache.first_order_merge('localhost', {'ansible_facts': {'test_fact': 'test_value'}}) == None
    assert fact_cache.keys() == ['localhost']
    assert fact_cache.copy() == {'localhost': {'ansible_facts': {'test_fact': 'test_value'}}}
    assert fact_cache.flush() == None
    assert fact_cache.keys() == []
    assert fact_cache.copy() == {}

# Generated at 2022-06-17 15:59:06.106963
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 15:59:07.435714
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:59:08.380753
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 15:59:09.511435
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 15:59:10.512605
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None


# Generated at 2022-06-17 15:59:14.452862
# Unit test for constructor of class FactCache
def test_FactCache():
    # Test with a valid cache plugin
    cache = FactCache()
    assert cache._plugin is not None

    # Test with an invalid cache plugin
    C.CACHE_PLUGIN = 'invalid'
    try:
        cache = FactCache()
        assert False
    except AnsibleError:
        assert True

# Generated at 2022-06-17 15:59:15.844103
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None


# Generated at 2022-06-17 15:59:19.615565
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None
    assert fact_cache._plugin.name == C.CACHE_PLUGIN

# Generated at 2022-06-17 15:59:47.186294
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 15:59:48.340987
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 15:59:56.944118
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('hostname', {'ansible_facts': {'hostname': 'host1'}})
    assert fact_cache['hostname']['ansible_facts']['hostname'] == 'host1'
    fact_cache.first_order_merge('hostname', {'ansible_facts': {'hostname': 'host2'}})
    assert fact_cache['hostname']['ansible_facts']['hostname'] == 'host2'

# Generated at 2022-06-17 16:00:01.436088
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}

# Generated at 2022-06-17 16:00:04.192200
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin is not None

# Generated at 2022-06-17 16:00:06.004934
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin is not None

# Generated at 2022-06-17 16:00:08.018425
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache

# Generated at 2022-06-17 16:00:13.350182
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1']['fact1'] == 'value1'
    fact_cache.first_order_merge('host1', {'fact1': 'value2'})
    assert fact_cache['host1']['fact1'] == 'value2'
    fact_cache.first_order_merge('host1', {'fact2': 'value3'})
    assert fact_cache['host1']['fact2'] == 'value3'

# Generated at 2022-06-17 16:00:16.667473
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'FactCachePlugin'


# Generated at 2022-06-17 16:00:24.000305
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('hostname', {'ansible_facts': {'hostname': 'host1'}})
    assert fact_cache['hostname']['ansible_facts']['hostname'] == 'host1'
    fact_cache.first_order_merge('hostname', {'ansible_facts': {'hostname': 'host2'}})
    assert fact_cache['hostname']['ansible_facts']['hostname'] == 'host2'
    fact_cache.first_order_merge('hostname', {'ansible_facts': {'hostname': 'host3'}})
    assert fact_cache['hostname']['ansible_facts']['hostname'] == 'host3'
    fact_cache.first_

# Generated at 2022-06-17 16:01:20.368616
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 16:01:21.415680
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None


# Generated at 2022-06-17 16:01:22.392991
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:01:29.687765
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}

# Generated at 2022-06-17 16:01:30.660958
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None


# Generated at 2022-06-17 16:01:35.717210
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}
    fact_cache.first_order_merge('host2', {'fact1': 'value1'})

# Generated at 2022-06-17 16:01:38.854865
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'FactCacheData'

# Generated at 2022-06-17 16:01:41.850808
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None


# Generated at 2022-06-17 16:01:44.975991
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin == cache_loader.get(C.CACHE_PLUGIN)


# Generated at 2022-06-17 16:01:46.901647
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 16:03:46.240181
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache._plugin is not None
    assert cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 16:03:48.354892
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None


# Generated at 2022-06-17 16:03:54.940921
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'a': 1})
    assert fact_cache['host1'] == {'a': 1}
    fact_cache.first_order_merge('host1', {'b': 2})
    assert fact_cache['host1'] == {'a': 1, 'b': 2}
    fact_cache.first_order_merge('host2', {'a': 1})
    assert fact_cache['host2'] == {'a': 1}
    fact_cache.first_order_merge('host2', {'b': 2})
    assert fact_cache['host2'] == {'a': 1, 'b': 2}

# Generated at 2022-06-17 16:03:55.860991
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:03:56.686958
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 16:04:01.051307
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    cache.first_order_merge('localhost', {'foo': 'bar'})
    assert cache['localhost']['foo'] == 'bar'
    cache.first_order_merge('localhost', {'foo': 'baz'})
    assert cache['localhost']['foo'] == 'baz'
    cache.first_order_merge('localhost', {'foo': 'baz', 'bar': 'baz'})
    assert cache['localhost']['foo'] == 'baz'
    assert cache['localhost']['bar'] == 'baz'
    cache.first_order_merge('localhost', {'bar': 'foo'})
    assert cache['localhost']['foo'] == 'baz'
    assert cache['localhost']['bar'] == 'foo'


# Generated at 2022-06-17 16:04:02.578478
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:04:08.581357
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value'})
    assert fact_cache['test_host']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_fact': 'new_value'})
    assert fact_cache['test_host']['test_fact'] == 'new_value'

# Generated at 2022-06-17 16:04:10.342199
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache
    assert fact_cache._plugin

# Generated at 2022-06-17 16:04:14.615167
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value'})
    assert fact_cache['test_host']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_fact': 'new_value'})
    assert fact_cache['test_host']['test_fact'] == 'new_value'