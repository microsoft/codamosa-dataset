

# Generated at 2022-06-17 15:56:07.977194
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'a': 1, 'b': 2})
    assert fact_cache['host1'] == {'a': 1, 'b': 2}
    fact_cache.first_order_merge('host1', {'b': 3, 'c': 4})
    assert fact_cache['host1'] == {'a': 1, 'b': 3, 'c': 4}

# Generated at 2022-06-17 15:56:16.868293
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value'})
    assert fact_cache['test_host']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value2'})
    assert fact_cache['test_host']['test_fact'] == 'test_value2'
    fact_cache.first_order_merge('test_host', {'test_fact2': 'test_value2'})
    assert fact_cache['test_host']['test_fact2'] == 'test_value2'
    fact_cache.flush()

# Generated at 2022-06-17 15:56:24.797140
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value'})
    assert fact_cache['test_host']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_fact': 'new_value'})
    assert fact_cache['test_host']['test_fact'] == 'new_value'
    fact_cache.first_order_merge('test_host', {'new_fact': 'new_value'})
    assert fact_cache['test_host']['new_fact'] == 'new_value'

# Generated at 2022-06-17 15:56:25.603887
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin

# Generated at 2022-06-17 15:56:32.417826
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value'})
    assert fact_cache['test_host']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value_2'})
    assert fact_cache['test_host']['test_fact'] == 'test_value_2'

# Generated at 2022-06-17 15:56:36.687961
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value'})
    assert fact_cache['test_host']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_fact': 'new_value'})
    assert fact_cache['test_host']['test_fact'] == 'new_value'

# Generated at 2022-06-17 15:56:41.275062
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc
    assert fc._plugin
    assert fc._plugin.__class__.__name__ == 'FactCacheData'

# Generated at 2022-06-17 15:56:43.238938
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin is not None


# Generated at 2022-06-17 15:56:45.191216
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:56:54.700781
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('hostname', {'ansible_facts': {'hostname': 'host1'}})
    assert fact_cache['hostname']['ansible_facts']['hostname'] == 'host1'
    fact_cache.first_order_merge('hostname', {'ansible_facts': {'hostname': 'host2'}})
    assert fact_cache['hostname']['ansible_facts']['hostname'] == 'host2'
    fact_cache.first_order_merge('hostname', {'ansible_facts': {'hostname': 'host3'}})
    assert fact_cache['hostname']['ansible_facts']['hostname'] == 'host3'
    fact_cache.first_

# Generated at 2022-06-17 15:56:56.957150
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:57:01.030830
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'


# Generated at 2022-06-17 15:57:02.117909
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.name == 'memory'

# Generated at 2022-06-17 15:57:03.173521
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:57:13.997922
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'a': 1}})
    assert fact_cache['localhost']['ansible_facts']['a'] == 1
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'b': 2}})
    assert fact_cache['localhost']['ansible_facts']['b'] == 2
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'a': 3}})
    assert fact_cache['localhost']['ansible_facts']['a'] == 3
    assert fact_cache['localhost']['ansible_facts']['b'] == 2

# Generated at 2022-06-17 15:57:25.406861
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'a': 1})
    assert fact_cache['host1'] == {'a': 1}
    fact_cache.first_order_merge('host1', {'b': 2})
    assert fact_cache['host1'] == {'a': 1, 'b': 2}
    fact_cache.first_order_merge('host2', {'a': 3})
    assert fact_cache['host2'] == {'a': 3}
    fact_cache.first_order_merge('host2', {'b': 4})
    assert fact_cache['host2'] == {'a': 3, 'b': 4}

# Generated at 2022-06-17 15:57:27.642962
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin


# Generated at 2022-06-17 15:57:29.771252
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:57:35.341833
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'foo': 'bar'})
    assert fact_cache['host1'] == {'foo': 'bar'}
    fact_cache.first_order_merge('host1', {'foo': 'baz'})
    assert fact_cache['host1'] == {'foo': 'baz'}
    fact_cache.first_order_merge('host2', {'foo': 'bar'})
    assert fact_cache['host2'] == {'foo': 'bar'}

# Generated at 2022-06-17 15:57:44.952949
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1']['fact1'] == 'value1'
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1']['fact2'] == 'value2'
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1']['fact1'] == 'value3'
    fact_cache.first_order_merge('host2', {'fact1': 'value4'})
    assert fact_cache['host2']['fact1'] == 'value4'

# Generated at 2022-06-17 15:57:48.249437
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:57:49.312689
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:57:55.114845
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    cache.first_order_merge('test_host', {'test_fact': 'test_value'})
    assert cache['test_host']['test_fact'] == 'test_value'
    cache.first_order_merge('test_host', {'test_fact': 'new_value'})
    assert cache['test_host']['test_fact'] == 'new_value'

# Generated at 2022-06-17 15:57:56.126372
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:57:57.577687
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:58:03.395025
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin
    assert fact_cache._plugin.contains('localhost') == False
    assert fact_cache._plugin.get('localhost') == None
    fact_cache._plugin.set('localhost', {'ansible_facts': {'test': 'test'}})
    assert fact_cache._plugin.contains('localhost') == True
    assert fact_cache._plugin.get('localhost') == {'ansible_facts': {'test': 'test'}}
    fact_cache._plugin.delete('localhost')
    assert fact_cache._plugin.contains('localhost') == False
    assert fact_cache._plugin.get('localhost') == None

# Generated at 2022-06-17 15:58:15.789652
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}
    fact_cache.first_order_merge('host2', {'fact1': 'value1'})

# Generated at 2022-06-17 15:58:24.587333
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}

# Generated at 2022-06-17 15:58:26.857607
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin is not None

# Generated at 2022-06-17 15:58:36.449519
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin
    assert fc._plugin.contains('localhost') == False
    assert fc._plugin.get('localhost') == None
    assert fc._plugin.keys() == []
    assert fc._plugin.flush() == None
    assert fc._plugin.set('localhost', {'ansible_facts': {'test': 'test'}}) == None
    assert fc._plugin.contains('localhost') == True
    assert fc._plugin.get('localhost') == {'ansible_facts': {'test': 'test'}}
    assert fc._plugin.keys() == ['localhost']
    assert fc._plugin.flush() == None
    assert fc._plugin.contains('localhost') == False
    assert fc._plugin.get('localhost') == None
    assert f

# Generated at 2022-06-17 15:58:43.288087
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc is not None


# Generated at 2022-06-17 15:58:45.201839
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin is not None


# Generated at 2022-06-17 15:58:46.123135
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:58:50.568464
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value'})
    assert fact_cache['test_host']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value2'})
    assert fact_cache['test_host']['test_fact'] == 'test_value2'
    fact_cache.first_order_merge('test_host', {'test_fact2': 'test_value2'})
    assert fact_cache['test_host']['test_fact2'] == 'test_value2'

# Generated at 2022-06-17 15:59:01.393408
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge("host1", {"fact1": "value1"})
    assert fact_cache["host1"]["fact1"] == "value1"
    fact_cache.first_order_merge("host1", {"fact2": "value2"})
    assert fact_cache["host1"]["fact2"] == "value2"
    fact_cache.first_order_merge("host1", {"fact1": "value3"})
    assert fact_cache["host1"]["fact1"] == "value3"
    fact_cache.first_order_merge("host2", {"fact1": "value1"})
    assert fact_cache["host2"]["fact1"] == "value1"
    fact_cache.first_order_mer

# Generated at 2022-06-17 15:59:04.060570
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin

# Generated at 2022-06-17 15:59:05.386817
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin

# Generated at 2022-06-17 15:59:09.819041
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'a': 1, 'b': 2})
    assert fact_cache['host1'] == {'a': 1, 'b': 2}
    fact_cache.first_order_merge('host1', {'b': 3, 'c': 4})
    assert fact_cache['host1'] == {'a': 1, 'b': 3, 'c': 4}

# Generated at 2022-06-17 15:59:11.213159
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:59:12.669539
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:59:26.340357
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value'})
    assert fact_cache['test_host']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_fact': 'new_value'})
    assert fact_cache['test_host']['test_fact'] == 'new_value'

# Generated at 2022-06-17 15:59:27.439613
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:59:33.659147
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'a': 1, 'b': 2}})
    assert fact_cache['localhost']['ansible_facts']['a'] == 1
    assert fact_cache['localhost']['ansible_facts']['b'] == 2
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'b': 3, 'c': 4}})
    assert fact_cache['localhost']['ansible_facts']['a'] == 1
    assert fact_cache['localhost']['ansible_facts']['b'] == 3
    assert fact_cache['localhost']['ansible_facts']['c'] == 4

# Generated at 2022-06-17 15:59:35.836551
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 15:59:48.780365
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('hostname', {'ansible_facts': {'hostname': 'test'}})
    assert fact_cache['hostname'] == {'ansible_facts': {'hostname': 'test'}}
    fact_cache.first_order_merge('hostname', {'ansible_facts': {'hostname': 'test2'}})
    assert fact_cache['hostname'] == {'ansible_facts': {'hostname': 'test2'}}
    fact_cache.first_order_merge('hostname', {'ansible_facts': {'hostname': 'test3'}})
    assert fact_cache['hostname'] == {'ansible_facts': {'hostname': 'test3'}}
    fact_cache.first

# Generated at 2022-06-17 16:00:00.052500
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    cache.first_order_merge('host1', {'fact1': 'value1'})
    assert cache['host1'] == {'fact1': 'value1'}
    cache.first_order_merge('host1', {'fact2': 'value2'})
    assert cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    cache.first_order_merge('host2', {'fact1': 'value1'})
    assert cache['host2'] == {'fact1': 'value1'}
    cache.first_order_merge('host2', {'fact2': 'value2'})
    assert cache['host2'] == {'fact1': 'value1', 'fact2': 'value2'}
    cache.first

# Generated at 2022-06-17 16:00:00.999108
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:00:09.820305
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge("host1", {"ansible_facts": {"fact1": "value1"}})
    assert fact_cache["host1"]["ansible_facts"]["fact1"] == "value1"
    fact_cache.first_order_merge("host1", {"ansible_facts": {"fact2": "value2"}})
    assert fact_cache["host1"]["ansible_facts"]["fact1"] == "value1"
    assert fact_cache["host1"]["ansible_facts"]["fact2"] == "value2"
    fact_cache.first_order_merge("host1", {"ansible_facts": {"fact1": "value3"}})

# Generated at 2022-06-17 16:00:11.386552
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None


# Generated at 2022-06-17 16:00:12.855261
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None


# Generated at 2022-06-17 16:00:40.814376
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 16:00:42.735599
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache


# Generated at 2022-06-17 16:00:43.811417
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:00:46.412881
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:00:52.788802
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    from ansible.plugins.cache import BaseCacheModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cPickle as pickle

    class TestCacheModule(BaseCacheModule):
        def __init__(self):
            self._cache = {}

        def get(self, key):
            return pickle.loads(self._cache[key])

        def set(self, key, value):
            self._cache[key] = pickle.dumps(value)

        def contains(self, key):
            return key in self._cache

        def delete(self, key):
            del self._cache[key]

        def flush(self):
            self._cache = {}

        def keys(self):
            return self._cache.keys()


# Generated at 2022-06-17 16:00:56.696829
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'a': 'b'})
    assert fact_cache['host1'] == {'a': 'b'}
    fact_cache.first_order_merge('host1', {'c': 'd'})
    assert fact_cache['host1'] == {'a': 'b', 'c': 'd'}
    fact_cache.first_order_merge('host2', {'e': 'f'})
    assert fact_cache['host2'] == {'e': 'f'}

# Generated at 2022-06-17 16:00:57.463522
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin

# Generated at 2022-06-17 16:01:04.346765
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'test_fact': 'test_value'}})
    assert fact_cache['localhost']['ansible_facts']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'test_fact': 'test_value2'}})
    assert fact_cache['localhost']['ansible_facts']['test_fact'] == 'test_value2'

# Generated at 2022-06-17 16:01:05.260320
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:01:11.013552
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1', 'fact2': 'value2'})
    assert fact_cache['host1']['fact1'] == 'value1'
    assert fact_cache['host1']['fact2'] == 'value2'
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1']['fact1'] == 'value3'
    assert fact_cache['host1']['fact2'] == 'value2'

# Generated at 2022-06-17 16:01:41.502007
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None


# Generated at 2022-06-17 16:01:43.484948
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin


# Generated at 2022-06-17 16:01:48.926906
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1']['fact1'] == 'value1'
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1']['fact2'] == 'value2'
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1']['fact1'] == 'value3'

# Generated at 2022-06-17 16:01:51.618498
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 16:01:57.830615
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}

# Generated at 2022-06-17 16:01:59.009643
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:02:00.075356
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc is not None

# Generated at 2022-06-17 16:02:01.814837
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 16:02:02.980230
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 16:02:04.190510
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:03:00.181540
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 16:03:04.127353
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'a': 1})
    assert fact_cache['host1'] == {'a': 1}
    fact_cache.first_order_merge('host1', {'b': 2})
    assert fact_cache['host1'] == {'a': 1, 'b': 2}

# Generated at 2022-06-17 16:03:05.386060
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:03:06.481927
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 16:03:07.351884
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 16:03:08.201992
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin is not None

# Generated at 2022-06-17 16:03:09.289250
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'FactCachePlugin'

# Generated at 2022-06-17 16:03:09.893014
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache

# Generated at 2022-06-17 16:03:10.661596
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:03:12.081335
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:05:05.388200
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 16:05:12.728364
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'test': 'test'}})
    assert fact_cache['localhost']['ansible_facts']['test'] == 'test'
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'test': 'test2'}})
    assert fact_cache['localhost']['ansible_facts']['test'] == 'test2'

# Generated at 2022-06-17 16:05:14.190372
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:05:20.131684
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}
    fact_cache.first_order_merge('host2', {'fact1': 'value1'})

# Generated at 2022-06-17 16:05:22.195951
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 16:05:24.216276
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 16:05:25.809344
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:05:30.925407
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}

# Generated at 2022-06-17 16:05:31.946368
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin is not None


# Generated at 2022-06-17 16:05:34.265749
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    cache.first_order_merge('localhost', {'foo': 'bar'})
    assert cache['localhost']['foo'] == 'bar'
    cache.first_order_merge('localhost', {'foo': 'baz'})
    assert cache['localhost']['foo'] == 'baz'