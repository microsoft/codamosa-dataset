

# Generated at 2022-06-17 15:56:07.473584
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 15:56:09.557622
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:56:15.692770
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host', {'a': 1})
    assert fact_cache['host'] == {'a': 1}
    fact_cache.first_order_merge('host', {'b': 2})
    assert fact_cache['host'] == {'a': 1, 'b': 2}
    fact_cache.first_order_merge('host', {'a': 3})
    assert fact_cache['host'] == {'a': 3, 'b': 2}

# Generated at 2022-06-17 15:56:17.477789
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin is not None
    assert fc._plugin.__class__.__name__ == 'FactCacheData'

# Generated at 2022-06-17 15:56:19.734482
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin
    assert fact_cache._plugin.contains

# Generated at 2022-06-17 15:56:25.781641
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('key', {'a': 1})
    assert fact_cache['key'] == {'a': 1}
    fact_cache.first_order_merge('key', {'b': 2})
    assert fact_cache['key'] == {'a': 1, 'b': 2}
    fact_cache.first_order_merge('key', {'a': 3})
    assert fact_cache['key'] == {'a': 3, 'b': 2}

# Generated at 2022-06-17 15:56:35.517639
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}
    fact_cache.first_order_merge('host2', {'fact1': 'value1'})

# Generated at 2022-06-17 15:56:45.334156
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value'})
    assert fact_cache['test_host']['test_fact'] == 'test_value'

    fact_cache.first_order_merge('test_host', {'test_fact': 'new_value'})
    assert fact_cache['test_host']['test_fact'] == 'new_value'

# Generated at 2022-06-17 15:56:46.581020
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 15:56:48.877234
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 15:56:56.928270
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge("host1", {"ansible_os_family": "RedHat"})
    assert fact_cache["host1"]["ansible_os_family"] == "RedHat"
    fact_cache.first_order_merge("host1", {"ansible_os_family": "Debian"})
    assert fact_cache["host1"]["ansible_os_family"] == "Debian"
    fact_cache.first_order_merge("host2", {"ansible_os_family": "RedHat"})
    assert fact_cache["host2"]["ansible_os_family"] == "RedHat"

# Generated at 2022-06-17 15:57:00.166194
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc is not None

# Generated at 2022-06-17 15:57:01.547286
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:57:02.650947
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:57:07.289502
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}

# Generated at 2022-06-17 15:57:10.037790
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache._plugin is not None
    assert cache._plugin.__class__.__name__ == 'FactCacheData'


# Generated at 2022-06-17 15:57:11.496076
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None


# Generated at 2022-06-17 15:57:13.138327
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin is not None
    assert fc._plugin.__class__.__name__ == 'FactCacheData'

# Generated at 2022-06-17 15:57:15.479380
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 15:57:18.048006
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None


# Generated at 2022-06-17 15:57:22.343414
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:57:24.064964
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin


# Generated at 2022-06-17 15:57:25.449258
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 15:57:29.609796
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin is not None
    assert fc._plugin.__class__.__name__ == 'FactCacheData'


# Generated at 2022-06-17 15:57:34.633988
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'a': 1, 'b': 2})
    assert fact_cache['host1'] == {'a': 1, 'b': 2}
    fact_cache.first_order_merge('host1', {'b': 3, 'c': 4})
    assert fact_cache['host1'] == {'a': 1, 'b': 3, 'c': 4}

# Generated at 2022-06-17 15:57:37.417090
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:57:39.082955
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache
    assert fact_cache._plugin

# Generated at 2022-06-17 15:57:49.981075
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value'})
    assert fact_cache['test_host']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value2'})
    assert fact_cache['test_host']['test_fact'] == 'test_value2'
    fact_cache.first_order_merge('test_host', {'test_fact2': 'test_value2'})
    assert fact_cache['test_host']['test_fact'] == 'test_value2'
    assert fact_cache['test_host']['test_fact2'] == 'test_value2'

# Generated at 2022-06-17 15:57:51.155456
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc

# Generated at 2022-06-17 15:57:52.444129
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache._plugin is not None

# Generated at 2022-06-17 15:57:59.857554
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None


# Generated at 2022-06-17 15:58:00.890993
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:58:05.084551
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_key': 'test_value'})
    assert fact_cache['test_host']['test_key'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_key': 'test_value2'})
    assert fact_cache['test_host']['test_key'] == 'test_value2'
    fact_cache.first_order_merge('test_host', {'test_key2': 'test_value2'})
    assert fact_cache['test_host']['test_key2'] == 'test_value2'

# Generated at 2022-06-17 15:58:16.927415
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}
    fact_cache.first_order_merge('host2', {'fact1': 'value1'})

# Generated at 2022-06-17 15:58:18.950256
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'FactCacheData'

# Generated at 2022-06-17 15:58:20.491220
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 15:58:25.318514
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge("host1", {"fact1": "value1"})
    assert fact_cache["host1"] == {"fact1": "value1"}
    fact_cache.first_order_merge("host1", {"fact2": "value2"})
    assert fact_cache["host1"] == {"fact1": "value1", "fact2": "value2"}
    fact_cache.first_order_merge("host1", {"fact1": "value3"})
    assert fact_cache["host1"] == {"fact1": "value3", "fact2": "value2"}

# Generated at 2022-06-17 15:58:35.599080
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1']['fact1'] == 'value1'
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1']['fact2'] == 'value2'
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1']['fact1'] == 'value3'
    fact_cache.first_order_merge('host2', {'fact1': 'value1'})
    assert fact_cache['host2']['fact1'] == 'value1'
    fact_cache.first

# Generated at 2022-06-17 15:58:39.713782
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin is not None
    assert fc._plugin.__class__.__name__ == 'FactCacheData'


# Generated at 2022-06-17 15:58:42.047791
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:58:56.419892
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 15:59:01.725621
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value'})
    assert fact_cache['test_host']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_fact': 'new_value'})
    assert fact_cache['test_host']['test_fact'] == 'new_value'

# Generated at 2022-06-17 15:59:04.980809
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 15:59:09.511468
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_key': 'test_value'})
    assert fact_cache['test_host']['test_key'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_key': 'test_value2'})
    assert fact_cache['test_host']['test_key'] == 'test_value2'

# Generated at 2022-06-17 15:59:11.109441
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin is not None


# Generated at 2022-06-17 15:59:12.562450
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache._plugin is not None

# Generated at 2022-06-17 15:59:13.687194
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:59:15.123037
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 15:59:21.862587
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value'})
    assert fact_cache['test_host']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_fact': 'new_value'})
    assert fact_cache['test_host']['test_fact'] == 'new_value'

# Generated at 2022-06-17 15:59:26.584166
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}

# Generated at 2022-06-17 16:00:02.211854
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.plugins.cache import BaseFileCacheModule
    from ansible.plugins.cache.jsonfile import CacheModule as JsonFileCacheModule
    from ansible.plugins.cache.redis import CacheModule as RedisCacheModule
    from ansible.plugins.cache.yaml import CacheModule as YamlCacheModule

    # Test the constructor of class FactCache
    # Test the case when C.CACHE_PLUGIN is 'jsonfile'
    C.CACHE_PLUGIN = 'jsonfile'
    fact_cache = FactCache()
    assert isinstance(fact_cache._plugin, JsonFileCacheModule)

    # Test the case when C.CACHE_PLUGIN is 'redis'
    C.CACHE_PLUGIN = 'redis'
    fact_cache = FactCache()
    assert isinstance

# Generated at 2022-06-17 16:00:04.237055
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 16:00:06.004879
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:00:09.748331
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None
    assert fact_cache._plugin.__class__.__name__ == 'FactCacheData'


# Generated at 2022-06-17 16:00:11.034005
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:00:16.581957
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge("host1", {"ansible_facts": {"foo": "bar"}})
    assert fact_cache["host1"]["ansible_facts"]["foo"] == "bar"
    fact_cache.first_order_merge("host1", {"ansible_facts": {"foo": "baz"}})
    assert fact_cache["host1"]["ansible_facts"]["foo"] == "baz"
    fact_cache.first_order_merge("host1", {"ansible_facts": {"foo": "baz", "bar": "baz"}})
    assert fact_cache["host1"]["ansible_facts"]["foo"] == "baz"

# Generated at 2022-06-17 16:00:19.809593
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None
    assert fact_cache._plugin.name == 'memory'


# Generated at 2022-06-17 16:00:20.847123
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc is not None

# Generated at 2022-06-17 16:00:30.153573
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value'})
    assert fact_cache['test_host']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_fact': 'new_value'})
    assert fact_cache['test_host']['test_fact'] == 'new_value'

# Generated at 2022-06-17 16:00:31.944784
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 16:01:33.819810
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin
    assert fact_cache._plugin.contains('localhost') == False
    assert fact_cache._plugin.get('localhost') == None
    assert fact_cache._plugin.set('localhost', 'localhost') == None
    assert fact_cache._plugin.delete('localhost') == None
    assert fact_cache._plugin.contains('localhost') == False
    assert fact_cache._plugin.keys() == []
    assert fact_cache._plugin.flush() == None
    assert fact_cache._plugin.keys() == []
    assert fact_cache.copy() == {}
    assert fact_cache.keys() == []
    assert fact_cache.flush() == None
    assert fact_cache.keys() == []

# Generated at 2022-06-17 16:01:34.613759
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 16:01:37.057975
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 16:01:47.136610
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1', 'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3', 'fact3': 'value4'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2', 'fact3': 'value4'}

# Generated at 2022-06-17 16:01:57.992992
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin
    assert fact_cache._plugin.contains('localhost') == False
    assert fact_cache._plugin.get('localhost') == None
    assert fact_cache._plugin.set('localhost', 'localhost') == None
    assert fact_cache._plugin.contains('localhost') == True
    assert fact_cache._plugin.get('localhost') == 'localhost'
    assert fact_cache._plugin.delete('localhost') == None
    assert fact_cache._plugin.contains('localhost') == False
    assert fact_cache._plugin.get('localhost') == None
    assert fact_cache._plugin.flush() == None
    assert fact_cache._plugin.keys() == []
    assert fact_cache.copy() == {}
    assert fact_cache.keys() == []

# Generated at 2022-06-17 16:02:05.333008
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value'})
    assert fact_cache['test_host']['test_fact'] == 'test_value'
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value2'})
    assert fact_cache['test_host']['test_fact'] == 'test_value2'
    fact_cache.first_order_merge('test_host', {'test_fact2': 'test_value2'})
    assert fact_cache['test_host']['test_fact2'] == 'test_value2'

# Generated at 2022-06-17 16:02:06.420254
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:02:07.443931
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 16:02:11.142958
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache
    assert fact_cache._plugin
    assert fact_cache._plugin.contains
    assert fact_cache._plugin.get
    assert fact_cache._plugin.set
    assert fact_cache._plugin.delete
    assert fact_cache._plugin.keys
    assert fact_cache._plugin.flush
    assert fact_cache.copy
    assert fact_cache.keys
    assert fact_cache.flush
    assert fact_cache.first_order_merge

# Generated at 2022-06-17 16:02:13.075865
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-17 16:04:15.516090
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}

# Generated at 2022-06-17 16:04:17.879794
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 16:04:29.164623
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge("host1", {"fact1": "value1"})
    assert fact_cache["host1"]["fact1"] == "value1"
    fact_cache.first_order_merge("host1", {"fact2": "value2"})
    assert fact_cache["host1"]["fact2"] == "value2"
    fact_cache.first_order_merge("host1", {"fact1": "value3"})
    assert fact_cache["host1"]["fact1"] == "value3"
    fact_cache.first_order_merge("host2", {"fact1": "value1"})
    assert fact_cache["host2"]["fact1"] == "value1"
    fact_cache.first_order_mer

# Generated at 2022-06-17 16:04:31.981551
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:04:33.291684
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-17 16:04:39.576180
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache['host1'] == {'fact1': 'value1'}
    fact_cache.first_order_merge('host1', {'fact2': 'value2'})
    assert fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge('host1', {'fact1': 'value3'})
    assert fact_cache['host1'] == {'fact1': 'value3', 'fact2': 'value2'}

# Generated at 2022-06-17 16:04:41.526000
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:04:43.576405
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin

# Generated at 2022-06-17 16:04:45.484505
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-17 16:04:53.590074
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'a': 1, 'b': 2})
    assert fact_cache['host1'] == {'a': 1, 'b': 2}
    fact_cache.first_order_merge('host1', {'b': 3, 'c': 4})
    assert fact_cache['host1'] == {'a': 1, 'b': 3, 'c': 4}
    fact_cache.first_order_merge('host2', {'a': 5, 'b': 6})
    assert fact_cache['host2'] == {'a': 5, 'b': 6}