

# Generated at 2022-06-21 09:27:12.098323
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    assert C.CACHE_PLUGIN == 'memory'
    cache_plugin = cache_loader.get(C.CACHE_PLUGIN)
    cache_plugin.set('foo', 'bar')
    fact_cache = FactCache()
    assert 'foo' in fact_cache
    assert fact_cache['foo'] == 'bar'
    fact_cache.flush()
    fact_cache['foo'] = 'bar'
    iter = fact_cache.__iter__()
    assert next(iter)  == 'foo'

# Generated at 2022-06-21 09:27:14.286269
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = FactCache()
    fact_cache["a"] = "b"
    assert fact_cache["a"] == "b"
    # Reset fact_cache
    fact_cache._plugin.flush()

# Generated at 2022-06-21 09:27:18.683943
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    from ansible.plugins.cache import memory
    from ansible.plugins.cache.memory import CacheModule
    import mock

    cache = FactCache()
    cache._plugin = mock.create_autospec(CacheModule)

    cache.__setitem__('testkey', 'testvalue')

    assert cache._plugin.set.call_count == 1
    assert cache._plugin.set.call_args[0] == ('testkey', 'testvalue')


# Generated at 2022-06-21 09:27:19.539789
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    print(FactCache._plugin)


# Generated at 2022-06-21 09:27:20.910019
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    self = FactCache()
    self.flush()


# Generated at 2022-06-21 09:27:21.982702
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    pass


# Generated at 2022-06-21 09:27:26.903662
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():

    fact_cache = FactCache()
    fact_cache['test_key'] = 'test_value'
    assert 'test_key' in fact_cache
    del fact_cache['test_key']
    assert 'test_key' not in fact_cache


# Generated at 2022-06-21 09:27:36.941470
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    class CachePlugin:
        def __init__(self):
            self.storage = {'key': {'cache': 'cache_value'}}

        def contains(self, key):
            return True if key in self.storage else False

        def get(self, key):
            return self.storage[key]

        def set(self, key, value):
            self.storage[key] = value


    plugin_instance = CachePlugin()
    fact_cache = FactCache()
    fact_cache._plugin = plugin_instance
    fact_cache.first_order_merge('key', {'value': 'value_1'})

    assert fact_cache['key'] == {'cache': 'cache_value', 'value': 'value_1'}

# Generated at 2022-06-21 09:27:38.023244
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fc = FactCache()
    assert 'test' not in fc


# Generated at 2022-06-21 09:27:41.713830
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    cache_plugin = cache_loader.get("memory")
    if cache_plugin:
        fc = FactCache("localhost")
        fc["a"] = "b"
        assert next(iter(fc)) == "a"
    else:
        assert True


# Generated at 2022-06-21 09:27:50.219928
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fc = FactCache()
    key = 'test_key'
    val = 'test_val'
    fc.__setitem__(key, val)
    assert fc.__contains__(key)
    fc.__delitem__(key)
    assert not fc.__contains__(key)
    assert not fc.__contains__('invalid_key')


# Generated at 2022-06-21 09:27:52.997281
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    cache = FactCache()
    cache['ansible_local'] = {'ping': 'pong'}
    assert cache.keys() == ['ansible_local']


# Generated at 2022-06-21 09:27:54.086835
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    pass


# Generated at 2022-06-21 09:27:59.589810
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    cache = FactCache()
    host_cache = {}
    host_cache.__setitem__('facts', {'inventory_hostname': 'localhost'})
    cache.__setitem__('localhost', host_cache)
    host_cache = cache.__getitem__('localhost')
    assert(host_cache.__getitem__('facts') == {'inventory_hostname': 'localhost'})


# Generated at 2022-06-21 09:28:04.248874
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    '''
    :return:
    '''
    from ansible.plugins.cache import dict_cache

    cache = dict_cache.FactCache()

    foo = dict(bar=1)
    cache.set('foo', foo)

    cache.flush()
    assert cache.get('foo') == {}

# Generated at 2022-06-21 09:28:13.213321
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    # Check error message if facts are not cached
    fact_cache = FactCache()
    key = '192.16.0.1'
    try:
        fact_cache[key]
    except KeyError as e:
        msg = '192.16.0.1'
        assert msg in str(e)
        assert 'not in cache' in str(e)

    # Check cached facts are returned
    host_facts = {'kernel': 'Linux', 'hostname': 'testhost.example.org'}
    fact_cache[key] = host_facts
    assert fact_cache[key] == host_facts


# Generated at 2022-06-21 09:28:18.381430
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():

    def __len__():
        _plugin = ['plugin1', 'plugin2', 'plugin3']
        return len(_plugin)

    _plugin = ['plugin1', 'plugin2', 'plugin3']
    result = __len__()
    assert result == len(_plugin)


# Generated at 2022-06-21 09:28:25.156928
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    import copy

    # FactCache class instance
    fc = FactCache()
    data_set = {'a': 1, 'b': 2, 'c': 3}

    # Test shallow copy
    fc.update(data_set)
    assert data_set == fc

    # Test deep copy
    cp_data_set = copy.copy(data_set)
    assert cp_data_set == data_set
    cp_data_set['a'] = 'x'
    assert cp_data_set != data_set

# Generated at 2022-06-21 09:28:30.614809
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():

    # Create a new instance of the object under test with a cache object as input argument.
    # Note: __init__() of class FactCache uses only private methods of the given cache object.
    cache = FactCache(cache_loader.get(C.CACHE_PLUGIN))

    hosts_cache = [("host1", {}), ("host2", {})]

    # Call __iter__() on this new instance with the hosts cache as input argument.
    it = cache.__iter__(hosts_cache)
    next(it)

# Generated at 2022-06-21 09:28:35.783094
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    """ test_FactCache__setitem__
    """
    # Create an instance of FactCache
    fact_cache = FactCache()
    # Set the value of item
    fact_cache['item'] = 123
    # Get the value of item
    assert fact_cache['item'] == 123


# Generated at 2022-06-21 09:28:41.973810
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    try:
        FactCache().__getitem__("key")
    except Exception as e:
        if isinstance(e, KeyError):
            assert True
        else:
            assert False


# Generated at 2022-06-21 09:28:44.352052
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    """
    FactCache.__contains__(key)
    """
    #
    # Tests for __contains__(key)

    #
    # __contains__(key)
    #


# Generated at 2022-06-21 09:28:46.788306
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    print('Test: FactCache___iter__')
    import doctest
    doctest.testmod()


if __name__ == '__main__':
    test_FactCache___iter__()

# Generated at 2022-06-21 09:28:48.397848
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    assert FactCache().__len__() == 0


# Generated at 2022-06-21 09:28:51.080466
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache = FactCache()
    fact_cache['test_key'] = 'test_value'
    del fact_cache['test_key']



# Generated at 2022-06-21 09:28:52.494886
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = FactCache()
    fact_cache.__setitem__("key", "value")
    assert fact_cache._plugin.contains("key")
    assert fact_cache._plugin.get("key") == "value"


# Generated at 2022-06-21 09:29:05.785702
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = FactCache()

    # Copy-paste from test_announce_hosts:
    import json
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.cache import FactCache
    from ansible.plugins.loader import cache_loader, module_loader
    from ansible.vars.manager import VariableManager

    fact_cache = FactCache()
    # set up the necessary objects to load the inventory,
    # and then initialize the inventory plugin
    vault_pass = None
    loader = module_loader
    if 'VAULT_PASS' in os.environ:
        vault_pass = os.getenv('VAULT_PASS')
    vault_ids = []
    inventory_config = C.DEFAULT_INVENTORY_CONFIG_FILE
    inventory_script = None
    inventory_dir

# Generated at 2022-06-21 09:29:07.779770
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    instance = FactCache()
    assert isinstance(instance.__iter__(), type(iter([])))

# Generated at 2022-06-21 09:29:09.881333
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fact_cache = FactCache()
    fact_cache["foo"] = "bar"
    assert ('foo' in fact_cache)


# Generated at 2022-06-21 09:29:12.454442
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fact_cache=FactCache()
    # assert fact_cache['xyz'] == None
    assert fact_cache.get('xyz') == None


# Generated at 2022-06-21 09:29:28.893608
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    tests = dict(
        delete_existing=dict(
            fact_cache_contains_key=True,
            expected_deletion=True
        ),
        delete_non_existing=dict(
            fact_cache_contains_key=False,
            expected_deletion=False
        )
    )

    for test_name, testcase in tests.items():
        display.display("Starting test %s" % test_name)
        fact_cache = FactCache()
        fact_cache_contains_key = testcase['fact_cache_contains_key']
        expected_deletion = testcase['expected_deletion']
        key = 'foo'
        value = 'bar'
        fact_cache[key] = value
        if fact_cache_contains_key:
            assert key in fact_cache

# Generated at 2022-06-21 09:29:29.656284
# Unit test for constructor of class FactCache
def test_FactCache():
    _ = FactCache()

# Generated at 2022-06-21 09:29:32.149542
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    assert False, "No test for method __delitem__ of class FactCache"


# Generated at 2022-06-21 09:29:39.884216
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    source_facts = {'foo': 'bar', 'baz': 'quz'}
    first_order_facts = {'foo': 'baz', 'fooz': 'beez'}
    expected_facts = {'foo': 'baz', 'baz': 'quz', 'fooz': 'beez'}
    fact_cache = FactCache()
    fact_cache.update(source_facts)
    fact_cache.first_order_merge('foo', first_order_facts)
    assert fact_cache == expected_facts

# Generated at 2022-06-21 09:29:44.419316
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    from ansible.plugins.cache import FactCache

    fctCache1 = FactCache()
    fctCache1['key1'] = 'value1'
    fctCache1['key2'] = 'value2'

    fctCache2 = fctCache1.copy()

    assert fctCache1['key1'] == fctCache2['key1']
    assert fctCache1['key2'] == fctCache2['key2']

# Generated at 2022-06-21 09:29:52.123965
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    previous_facts = dict(fact_1='a', fact_2='b', fact_3='c')
    new_facts = dict(fact_3='d', fact_4='e')
    host = 'some.host'

    fact_cache.first_order_merge(host, previous_facts)
    previous_facts_and_new_keys = dict(previous_facts, **new_facts)
    assert fact_cache.get(host) == previous_facts_and_new_keys

    fact_cache.first_order_merge(host, new_facts)
    assert fact_cache.get(host) == dict(fact_1='a', fact_2='b', fact_3='d', fact_4='e')

    # ensure that the test is isolated

# Generated at 2022-06-21 09:29:57.755140
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    from ansible.module_utils.facts.cache import FactCache
    # Create a new cache and add a key
    cache = FactCache()
    cache['test_key'] = 'value'
    # Test if key exists in cache
    if 'test_key' in cache:
        print ("contains() works")
    else:
        print ("contains() does not work")

if __name__ == '__main__':
    test_FactCache___contains__()

# Generated at 2022-06-21 09:30:05.040623
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    cache = FactCache()
    cache['127.0.0.1'] = {'ansible_all_ipv4_addresses': '127.0.0.1'}
    # As it is not possible to compare dictionaries,
    # we will compare the result of the method "keys"
    assert cache.keys() == ['127.0.0.1']
    cache.flush()
    assert cache.keys() == []


# Generated at 2022-06-21 09:30:09.333095
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fc1 = FactCache()
    test_dict = {"192.168.0.123": {
        "ansible_facts": {
            "test_variable": "test_value"
        }
    }}
    mock_plugin = Mock()
    mock_plugin.contains.return_value = True
    mock_plugin.get.return_value = test_dict
    fc1._plugin = mock_plugin
    fc1.__delitem__("192.168.0.123")
    mock_plugin.delete.assert_called_with("192.168.0.123")



# Generated at 2022-06-21 09:30:12.937802
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = FactCache()
    fact_cache['test_key'] = 'test_value'
    assert 'test_key' in fact_cache.keys()

# Generated at 2022-06-21 09:30:23.953677
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fact_cache = FactCache()

    if not isinstance(fact_cache, FactCache):
        raise AssertionError('Unexpected type: %s' % type(fact_cache))

    if not isinstance(fact_cache, MutableMapping):
        raise AssertionError('Unexpected type: %s' % type(fact_cache))


# Generated at 2022-06-21 09:30:28.610141
# Unit test for method flush of class FactCache
def test_FactCache_flush():

    class MockPlugin:
        def __init__(self):
            self.params = None

        def flush(self):
            self.params = {'flush': None}

    mock_plugin = MockPlugin()
    fact_cache = FactCache()
    fact_cache._plugin = mock_plugin

    fact_cache.flush()

    assert mock_plugin.params == {'flush': None}

# Generated at 2022-06-21 09:30:31.803072
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    fact_cache['test'] = "test"
    fact_cache['test1'] = "test1"
    assert fact_cache.keys() == ['test', 'test1'], "keys return wrong value"


# Generated at 2022-06-21 09:30:34.246101
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    fact_cache['test_key'] = 'test_value'
    fact_cache.flush()
    assert 'test_key' not in fact_cache

# Generated at 2022-06-21 09:30:38.079362
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    d = FactCache()
    d['mykey'] = 'myvalue'
    d.flush()
    assert d.__len__() == 0, '_FactCache object should be empty'



# Generated at 2022-06-21 09:30:40.867791
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fc = FactCache()
    with pytest.raises(KeyError) as e:
        fc['localhost']


# Generated at 2022-06-21 09:30:51.011295
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    host_cache = {'ansible_all_ipv4_addresses': ['10.0.0.1'],
                  'ansible_all_ipv6_addresses': ['fe80::5054:ff:fe89:f1d8']}
    fact_cache.first_order_merge('example', host_cache)
    assert fact_cache['example'] == host_cache

    new_host_cache = {'ansible_all_ipv4_addresses': ['10.0.0.2'],
                      'ansible_all_ipv6_addresses': ['fe80::5054:ff:fe89:f1d8']}
    fact_cache.first_order_merge('example', new_host_cache)

# Generated at 2022-06-21 09:30:53.464060
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache != None

fact_cache = None

# Generated at 2022-06-21 09:30:58.352989
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fc = FactCache()
    fc['1'] = "a"
    fc['2'] = "b"
    fc['3'] = "c"

    assert len(fc) == 3

    fc['3'] = None
    assert len(fc) == 2



# Generated at 2022-06-21 09:31:06.368397
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fc = FactCache()

    # Case:
    #   no existing keys, flush
    assert len(fc) == 0
    fc.flush()
    assert len(fc) == 0

    # Case:
    #   existing keys, flush
    fc = FactCache()
    fc['key'] = 'value'
    assert len(fc) == 1
    fc.flush()
    assert len(fc) == 0

    # Case:
    #   existing keys, no flush
    fc = FactCache()
    fc['key'] = 'value'
    assert len(fc) == 1
    assert len(fc.flush()) == 0

# Generated at 2022-06-21 09:31:22.628526
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc.first_order_merge('test_host', {'a': '1'})
    fc.first_order_merge('test_host', {'b': '2'})
    assert fc['test_host'] == {'a': '1', 'b': '2'}
    fc.first_order_merge('test_host', {'a': '3'})
    assert fc['test_host'] == {'a': '3', 'b': '2'}
    fc.flush()

# Generated at 2022-06-21 09:31:25.707480
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    """
    Unit test for keys()
    """
    current_cache = FactCache()
    current_cache['a'] = 1
    assert current_cache.keys() == ['a'], "keys should be a list with 'a' as an element"

# Generated at 2022-06-21 09:31:30.355699
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    import tempfile
    import os

    my_dict = {}

    f = tempfile.NamedTemporaryFile(delete=False)
    os.unlink(f.name)

    my_facts = FactCache()
    my_facts["foo"] = "bar"

    my_dict["foo"] = "bar"

    if my_facts == my_dict:
        exit(True)
    else:
        exit(False)



# Generated at 2022-06-21 09:31:42.762730
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fcache = FactCache()
    host_facts = {}
    hostname = 'testhostname'
    fact_name = 'fact1'
    fact_value = 'value_ABC'
    host_facts[hostname] = {fact_name: fact_value}
    fcache.first_order_merge(hostname, host_facts[hostname])
    host_facts[hostname]['fact2'] = 'value_XYZ'
    fcache.first_order_merge(hostname, host_facts[hostname])
    host_facts[hostname][fact_name] = 'value_123'
    fcache.first_order_merge(hostname, host_facts[hostname])
    assert 'testhostname' in fcache.keys()

# Generated at 2022-06-21 09:31:47.011101
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    myfactcache = FactCache()
    myfactcache['test_key'] = 'test_value'
    myfactcache.flush()

    assert(len(myfactcache) == 0)

# Unit test to check the method first_order_merge of class FactCache

# Generated at 2022-06-21 09:31:51.874986
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fc = FactCache()
    fc['foo']= 'bar'
    fc['baz']= 'foo'
    copy = fc.copy()
    assert 'foo' in copy
    assert len(copy) == 2
    assert 'bar' in copy.values()


# Generated at 2022-06-21 09:31:58.649012
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    '''
    This is a test for the __delitem__ method of class FactCache
    '''

    # Create an instance of FactCache
    fc = FactCache()

    # Add a value in the cache
    fc['testkey'] = 1

    # Delete the added value
    del fc['testkey']

    # Check that the cache doesn't contain any value anymore
    assert len(fc) == 0


# Generated at 2022-06-21 09:32:02.674531
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fc = FactCache()
    a = {'a': 'a', 'b': 'b'}
    fc._plugin.a = a
    iteration = fc.__iter__()
    assert 'a' in iteration
    assert 'b' in iteration


# Generated at 2022-06-21 09:32:03.584529
# Unit test for constructor of class FactCache
def test_FactCache():
    assert FactCache()


# Generated at 2022-06-21 09:32:09.841055
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache_object = FactCache()
    with pytest.raises(AnsibleError) as excinfo:
        fact_cache_object.__setitem__('key', 'value')
    assert 'Unable to load the facts cache plugin' in str(excinfo.value)


# Generated at 2022-06-21 09:32:39.581006
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    from ansible.module_utils._text import to_native
    # Create a new instance of FactCache()
    fact_cache = FactCache()
    # Create a temporary section in the cache plugin
    fact_cache._plugin.set("test_section", {'test_key': True})
    # Test section exists in the cache plugin
    assert fact_cache._plugin.contains("test_section")
    # Test __getitem__ method
    assert fact_cache["test_section"]['test_key'] == True
    # Cleanup: delete test_section
    fact_cache.__delitem__("test_section")


# Generated at 2022-06-21 09:32:49.611747
# Unit test for method __iter__ of class FactCache

# Generated at 2022-06-21 09:32:58.288876
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    d = FactCache()
    d.first_order_merge("test", {"a": 1})
    assert d["test"] == {"a": 1}
    d.first_order_merge("test", {"b": 2})
    assert d["test"] == {"a": 1, "b": 2}
    d.first_order_merge("test", {"a": 3})
    assert d["test"] == {"a": 3, "b": 2}

# Generated at 2022-06-21 09:33:00.415156
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    facts_cache = FactCache()
    facts_cache["host1"] = {}
    assert facts_cache["host1"] == {}

# Generated at 2022-06-21 09:33:03.104623
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fj = FactCache()
    fj['hello'] = 'world'
    assert fj['hello'] == 'world'


# Generated at 2022-06-21 09:33:04.967759
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    pass


# Generated at 2022-06-21 09:33:06.340872
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    assert False, "Test not implemented"


# Generated at 2022-06-21 09:33:09.744725
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    a = FactCache()
    a['test'] = 'test'
    b = a.copy()
    assert len(b) == 1
    assert b['test'] == 'test'

# Generated at 2022-06-21 09:33:21.696823
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    assert fc._plugin.contains('abc') == False
    fc.first_order_merge('abc', {'x':1, 'y':2})
    assert fc._plugin.contains('abc') == True
    assert fc._plugin.get('abc') == {'x':1, 'y':2}
    fc.first_order_merge('abc', {'x':2, 'z':3})
    assert fc._plugin.get('abc') == {'x':2, 'y':2, 'z':3}
    assert fc.copy() == {'abc': {'x':2, 'y':2, 'z':3}}
    fc.flush()
    assert fc._plugin.contains('abc') == False

# Generated at 2022-06-21 09:33:25.791634
# Unit test for constructor of class FactCache
def test_FactCache():
    pobj = FactCache()
    assert isinstance(pobj, MutableMapping)
    assert pobj.__class__.__name__ == 'FactCache'

# Generated at 2022-06-21 09:34:22.428676
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    input_keys = ['a_key1', 'a_key2', 'a_key3']
    input_values = [1, 2, 3]

    fact_cache = FactCache()

    # Verify keys is emtpy before setting keys
    keys = fact_cache.keys()
    assert len(keys) == 0

    fact_cache_input = {}
    for index in range(3):
        fact_cache_input[input_keys[index]] = input_values[index]

    fact_cache.flush()
    assert len(fact_cache.keys()) == 0

    fact_cache.update(fact_cache_input)
    keys = fact_cache.keys()
    assert len(keys) == 3

    for key in keys:
        assert key in input_keys

# Generated at 2022-06-21 09:34:33.614455
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():

    import os
    import shutil
    import tempfile

    cache_dir = tempfile.mkdtemp()
    C.CACHE_PLUGIN = 'jsonfile'
    C.CACHE_PLUGIN_CONNECTION = 'local'
    C.CACHE_PLUGIN_PREFIX = os.path.join(cache_dir, 'test')
    C.CACHE_PLUGIN_TIMEOUT = 3600

    try:
        cache = FactCache()
        host = '127.0.0.1'

        cache[host] = {'test1': 'test1_value'}

        assert cache[host]['test1'] == 'test1_value'

    except Exception as e:
        print('test_FactCache___getitem__ error: %s' % (e))

# Generated at 2022-06-21 09:34:35.652361
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    a = FactCache()
    assert a.__contains__("foo") == False


# Generated at 2022-06-21 09:34:48.880229
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    try:
        cache = FactCache()
        cache['test_key'] = 'test_value'
    except Exception:
        assert False, 'Unexpected exception raised'

    if not isinstance(cache, FactCache):
        assert False, 'Subject is not an instance of the FactCache class'

    assert cache['test_key'] == 'test_value', 'Unexpected value for key test_key'

    try:
        del cache['test_key']
    except Exception:
        assert False, 'Unexpected exception raised'

    try:
        del cache['test_key']
    except KeyError:
        assert True, 'Expected exception raised'
    except Exception:
        assert False, 'Unexpected exception raised'
    else:
        assert False, 'Expected exception not raised'


# Generated at 2022-06-21 09:34:51.197926
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    # Testing is not applicable in this case
    pass


# Generated at 2022-06-21 09:34:57.891846
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    cache = FactCache()
    assert cache.keys() == []
    cache['key1'] = 'value'
    assert cache.keys() == ['key1']
    cache['key2'] = 'value'
    assert set(cache.keys()) == {'key1', 'key2'}
    del cache['key1']
    assert cache.keys() == ['key2']
    del cache['key2']
    assert cache.keys() == []


# Generated at 2022-06-21 09:35:02.855344
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fc = FactCache()
    fc['host1'] = {'fact1': 'value1'}
    fc['host2'] = {'fact2': 'value2'}
    fc['host3'] = {'fact3': 'value3'}
    d = fc.copy()
    assert d == {'host1': {'fact1': 'value1'}, 'host2': {'fact2': 'value2'}, 'host3': {'fact3': 'value3'}}
    assert fc.keys() == ['host1', 'host2', 'host3']


# Generated at 2022-06-21 09:35:05.209200
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    cache = FactCache()
    try:
        cache[""]
        assert False
    except KeyError:
        assert True
    cache.set("", "")
    assert cache.__getitem__("") == ""


# Generated at 2022-06-21 09:35:11.863828
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():

    # Test for invalid key
    fact_cache = FactCache()
    try:
        fact_cache['invalid-key']
        assert 'Should not come here'
    except KeyError:
        pass

    # Test for valid key
    fact_cache = FactCache()
    fact_cache._plugin.set('valid-key', 'valid-value')
    assert fact_cache['valid-key'] == 'valid-value'


# Generated at 2022-06-21 09:35:19.998974
# Unit test for constructor of class FactCache
def test_FactCache():
    import os
    cache = FactCache()
    cache['a'] = {'a': 'a'}
    assert cache['a'] == {'a': 'a'}
    cache['b'] = {'b': 'b'}
    assert cache['b'] == {'b': 'b'}
    assert len(cache) == 2
    assert 'a' in cache
    assert 'b' in cache
    assert 'c' not in cache
    assert cache.keys() == ['a', 'b']
    cache.flush()
    assert len(cache) == 0