

# Generated at 2022-06-21 09:27:11.173997
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    # create a new instance of class FactCache
    facts_cache = FactCache()
    # add more entry to facts_cache
    facts_cache['test1']='test value'
    facts_cache['test2']='test value2'
    for key in facts_cache:
        assert key in ['test1','test2']


# Generated at 2022-06-21 09:27:11.690678
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    pass # tested indirectly

# Generated at 2022-06-21 09:27:13.998127
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache = FactCache()
    fact_cache['key'] = 'value'
    assert len(fact_cache) == 1
    assert fact_cache['key'] == 'value'
    del fact_cache['key']
    assert len(fact_cache) == 0
    assert not fact_cache.keys()


# Generated at 2022-06-21 09:27:17.924707
# Unit test for constructor of class FactCache
def test_FactCache():
    def mock_plugin(*args, **kwargs):
        return True

    # Constructor called with default values
    cache_loader.get = mock_plugin
    cache = FactCache()
    assert cache._plugin == True

    # Constructor called with values
    cache_loader.get = mock_plugin
    cache = FactCache({'key': 'value'})
    assert cache._plugin == True
    assert cache['key'] == 'value'

    # Test fails when the cache plugin is not set
    C.CACHE_PLUGIN = ''
    try:
        cache = FactCache()
    except AnsibleError as e:
        assert "Unable to load the facts cache plugin" in e.message


# Generated at 2022-06-21 09:27:20.137714
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    expected_value = ["localhost.localdomain", "localhost.localdomain"]
    fact_cache = FactCache()
    assert fact_cache.keys() == expected_value

# Generated at 2022-06-21 09:27:26.601040
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    keys = []
    for host in ("host1", "host2", "host3"):
        for key in ["ansible_lsb.major_release", "ansible_lsb.description"]:
            keys.append((host, key))
    fact_cache = FactCache()
    fact_cache._plugin.set_many(keys)
    assert len(fact_cache.keys()) == 6



# Generated at 2022-06-21 09:27:28.987765
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    # Method unmocked test
    fc = FactCache()
    for k in fc:
        assert True


# Generated at 2022-06-21 09:27:33.280913
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    # Testing with a sample use-case
    # Note: we may need to add more test cases based on future use cases
    f = FactCache()
    f['test'] = 1
    for k in f:
        assert k == 'test', "Failed to iter over key"

# Generated at 2022-06-21 09:27:37.434474
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    _ = AnsibleError('Unable to load the facts cache plugin (memory).')
    cache = FactCache()
    cache['foo'] = 'bar'
    assert(cache.contains('foo'))
    del cache['foo']
    assert(not cache.contains('foo'))


# Generated at 2022-06-21 09:27:40.812233
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    factcache = FactCache()
    factcache.flush()
    factcache['test_key'] = None
    assert factcache.keys() == ['test_key']
    factcache.flush()
    assert factcache.keys() == []
    assert factcache.keys() is not None


# Generated at 2022-06-21 09:27:47.314617
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    factcache = FactCache()
    # This test has been generated using the following code:
    #
    # factcache = FactCache()
    # factcache['key'] = 'value'
    #

    assert factcache['key'] == 'value'


# Generated at 2022-06-21 09:27:51.446095
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    cache = FactCache()
    item = { "key": "value" }
    cache['item'] = item
    item_copy = cache.copy()
    assert item_copy == { "item": {"key": "value"} }



# Generated at 2022-06-21 09:27:59.042133
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    got = FactCache(C.CACHE_PLUGIN)
    assert  got in FactCache
    got = (ip for ip in range(8))
    assert  got in FactCache
    got = {'a':1, 'b':2}
    assert  got in FactCache
    got = {'a':1, 'b':2}
    assert  got in FactCache
    got = "hello"
    assert  got in FactCache
    got = '1'
    assert  got in FactCache
    got = '3'
    assert  got in FactCache

# Generated at 2022-06-21 09:28:03.680031
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    C.CACHE_PLUGIN = "memory"
    #import shutil
    #shutil.rmtree(str(os.path.expanduser("~/.ansible/tmp")))
    try:
        fact_cache = FactCache()
        fact_cache.flush()
        success = False
        message = " "
    except Exception as e:
        message = str(e)
    assert success, message

# Generated at 2022-06-21 09:28:07.553745
# Unit test for method keys of class FactCache
def test_FactCache_keys():

    mock_plugin = MockPlugin()
    Helper.cache_loader.set("plugin", mock_plugin)
    cache = FactCache(host)

    cache.keys()
    assert mock_plugin.mock_keys_called == 1



# Generated at 2022-06-21 09:28:17.073753
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    hosts = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
    f = FactCache()
    for host in hosts:
        f[host] = {}
        f[host]['foo'] = 'bar'

    # test that all hosts have a foo fact
    for host in hosts:
        assert f[host]['foo'] == 'bar'

    # test that the copy method returns a new dictionary
    c = f.copy()
    c['a'] = {'foo': 'baz'}
    assert c['a']['foo'] == 'baz'
    assert f['a']['foo'] == 'bar'



# Generated at 2022-06-21 09:28:17.698355
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    pass

# Generated at 2022-06-21 09:28:22.008619
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    fact_cache["localhost"] = {'foo': 'bar'}
    fact_cache["localhost"]['bar'] = 'baz'
    fact_cache.flush()
    if fact_cache["localhost"]:
        return True
    else:
        return False

# Generated at 2022-06-21 09:28:25.432408
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fc = FactCache()

    host_cache = {'first': 'Steven'}
    super(FactCache, fc).update(host_cache)

    assert next(iter(fc)) == 'first'


# Generated at 2022-06-21 09:28:27.445296
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    test_object = FactCache()
    assert_result = isinstance(test_object.__iter__(), iter)
    assert assert_result is True

# Generated at 2022-06-21 09:28:35.157015
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    '''
    Clears all the cached facts.
    '''
    def mock_plugin_flush(self):
        return True
    cache_loader.FactCache._plugin.flush=mock_plugin_flush
    f=cache_loader.FactCache()
    f.flush()

# Generated at 2022-06-21 09:28:36.512351
# Unit test for constructor of class FactCache
def test_FactCache():  # noqa
    fc = FactCache()  # noqa
    assert fc

# Generated at 2022-06-21 09:28:38.174086
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    cache = FactCache()
    for key in cache:
        assert key in cache


# Generated at 2022-06-21 09:28:42.636817
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    cache = FactCache()
    cache['key'] = 'value'
    cache['key2'] = 'value2'
    assert 'key' in cache
    assert 'key2' in cache
    del cache['key']
    assert 'key' not in cache
    del cache['key2']
    assert 'key2' not in cache

# Generated at 2022-06-21 09:28:46.700814
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc["foo"] = "bar"
    fc.first_order_merge("foo", {"baz": "qux"})
    assert fc["foo"] == {"baz": "qux"}

# Generated at 2022-06-21 09:28:54.705430
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    #Initialize variable : test_cache_plugin_obj
    test_cache_plugin_obj = cache_loader.get("jsonfile")

    fc = FactCache(C.CACHE_PLUGIN)

    #Test case 1
    fc._plugin = test_cache_plugin_obj
    key = 'test'
    host_facts = {key: {'fact1': 'val1'}}
    fc._plugin.set(key, host_facts[key])
    ans = {key: host_facts[key]}
    assert fc[key] == ans

    #Test case 2
    fc._plugin = test_cache_plugin_obj
    key = 'test'
    host_facts = {key: {'fact2': 'val2'}}
    fc._plugin.set(key, host_facts[key])

# Generated at 2022-06-21 09:28:58.735807
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    loader = cache_loader.get(C.CACHE_PLUGIN)
    fc = FactCache()
    fc._plugin = loader
    assert(fc.keys()==loader.keys())

# Generated at 2022-06-21 09:29:02.551084
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    fact_cache['a'] = 'b'
    assert len(fact_cache) == 1
    fact_cache.flush()
    assert len(fact_cache) == 0

# Generated at 2022-06-21 09:29:08.511987
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    fact_cache.__setitem__('key1', {'key1': 'value1'})
    fact_cache.__setitem__('key2', {'key2': 'value2'})
    assert fact_cache.copy() == {'key1': {'key1': 'value1'}, 'key2': {'key2': 'value2'}}

# Generated at 2022-06-21 09:29:10.550060
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    obj = FactCache()
    obj['a_key'] = 'a_value'
    result = 'a_key' in obj
    assert result == True

# Generated at 2022-06-21 09:29:19.327708
# Unit test for constructor of class FactCache
def test_FactCache():
    import ansible.module_utils.facts
    fact_cache = ansible.module_utils.facts.FactCache()
    assert(fact_cache is not None)

# Generated at 2022-06-21 09:29:21.890770
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    # __getitem__ is a method of class FactCache
    pass # TODO: write test


# Generated at 2022-06-21 09:29:27.821420
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    C.CACHE_PLUGIN = 'memory'
    fact_cache = FactCache()
    fact_cache.set = lambda key, value: key + value
    fact_cache.delete = lambda key: key
    # TODO
    # fact_cache.filter = lambda key, value: key + value
    fact_cache['foo'] = 'bar'
    fact_cache.delete('foo')
    # TODO
    # fact_cache.filter('foo', 'bar')


# Generated at 2022-06-21 09:29:31.487698
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fc = FactCache()
    fc['test1'] = 1
    fc['test2'] = 2
    fc['test3'] = 3
    assert len(fc) == 3
    

# Generated at 2022-06-21 09:29:32.765932
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    pass


# Generated at 2022-06-21 09:29:38.451303
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    # these are the input variables for this unit test
    key = "localhost"

    cache = FactCache()

    # this is the unit under test
    cache.__delitem__(key)

    # because this is a "void" method, this assertion is the only one that makes sense
    # if we got here then the unit passed the test
    assert True == True


# Generated at 2022-06-21 09:29:47.774890
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.plugins.cache import RESTCache
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.facts import collector

    # set class variable C.CACHE_PLUGIN to RESTCache to test that FactCache() is instantiated properly
    C.CACHE_PLUGIN = 'rest'

    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)
    assert isinstance(fact_cache._plugin, RESTCache)
    assert isinstance(fact_cache, MutableMapping)

    # set class variable C.CACHE_PLUGIN to 'memory' to test that default memory cache is instantiated properly
    C.CACHE_PLUGIN = 'memory'

    fact_cache = FactCache()
   

# Generated at 2022-06-21 09:29:50.588080
# Unit test for constructor of class FactCache
def test_FactCache():
    d = FactCache()
    d_values = d.copy()
    assert d_values == {}

# Generated at 2022-06-21 09:29:57.302098
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    # test for empty dict
    facts = FactCache()
    assert facts.copy() == {}
    # test for non-empty dict
    facts['test'] = 'test'
    assert facts.copy() == {'test': 'test'}

    # test that it is a copy and not a reference
    copy = facts.copy()
    copy['test_change'] = 'test_change'
    assert facts.copy() == {'test': 'test'}
    assert copy == {'test': 'test', 'test_change': 'test_change'}

# Generated at 2022-06-21 09:29:59.069542
# Unit test for constructor of class FactCache
def test_FactCache():
    fact = FactCache()
    assert isinstance(fact, FactCache)

# Generated at 2022-06-21 09:30:22.869174
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    from ansible.cache.memory import Plugin as MemoryPlugin
    from ansible.plugins.loader import cache_loader
    from ansible.module_utils._text import to_bytes, to_text

    cache_loader._fact_cache_cache = {}
    cache_loader._fact_cache_plugin = None
    memory_plugin = MemoryPlugin(None)
    memory_plugin.flush()
    cache_loader._fact_cache_cache = {'_plugin': memory_plugin}
    cache_loader._fact_cache_plugin = "memory"
    fact_cache = FactCache(None)
    fact_cache.flush()
    assert not memory_plugin.get(to_bytes('_plugin'))
    cache_loader._fact_cache_cache = {'_plugin': memory_plugin}
    cache_loader._fact_cache_plugin = "memory"

# Generated at 2022-06-21 09:30:24.220174
# Unit test for constructor of class FactCache
def test_FactCache():
    c = FactCache()
    assert c != None

# Generated at 2022-06-21 09:30:28.525188
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache = FactCache()

    fact_cache["test_key"] = "test_value"
    assert fact_cache["test_key"] == "test_value"
    del fact_cache["test_key"]
    try:
        assert fact_cache["test_key"] == None
    except KeyError:
        pass



# Generated at 2022-06-21 09:30:32.658740
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    import __main__ as main
    main.__cache__ = dict()
    main.__cache__['test1'] = 'test'

    factCache = FactCache()
    factCache['test1'] = 'test'
    assert factCache['test1'] == 'test'

    factCache.__delitem__('test1')
    assert 'test1' not in factCache.keys()

# Generated at 2022-06-21 09:30:45.004374
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    from ansible.plugins.cache.memory import CacheModule
    from ansible.plugins.cache.memory import FactCache

    plugin = CacheModule()
    cache = FactCache()
    cache._plugin = plugin

    cache.set = plugin.set
    cache.get = plugin.get
    cache.delete = plugin.delete
    cache.flush = plugin.flush
    cache.keys = plugin.keys

    cache.set("key", "value")
    assert cache.get("key") == "value"

    cache.set("key1", ["v1", "v2"])
    assert cache.get("key1") == ["v1", "v2"]

    # The method `copy` return the primitive copy of the keys and values from the cache.
    # If we add the key,value to the cache, then the method `copy` will return the dict

# Generated at 2022-06-21 09:30:49.597458
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    import re
    import inspect
    import pytest
    import sys
    x = sys.modules['ansible.module_utils.facts']
    cache = x.FactCache()
    x = cache.keys()
    assert not x
    y = list(x)
    assert not y
    z = len(x)
    assert not z

# Generated at 2022-06-21 09:30:58.861616
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache = FactCache(**{})

    fact_cache._plugin.contains = MagicMock(return_value=False)
    fact_cache._plugin.delete = MagicMock(return_value=None)

    fact_cache.__delitem__('test')
    assert fact_cache._plugin.delete.call_count == 0

    fact_cache._plugin.contains = MagicMock(return_value=True)
    fact_cache.__delitem__('test')
    assert fact_cache._plugin.delete.call_count == 1



# Generated at 2022-06-21 09:31:02.510093
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    # Test for FactCache class
    fact_cache = FactCache()

    fact_cache['factName'] = 'factValue'
    assert fact_cache.keys() == ['factName']



# Generated at 2022-06-21 09:31:05.541008
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fact_cache = FactCache()
    var = fact_cache['test1']
    # var is expect
    #assert var


# Generated at 2022-06-21 09:31:06.550451
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    cache = FactCache()
    cache.flush()

# Generated at 2022-06-21 09:31:30.809961
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    assert len(fact_cache) == 0

# Generated at 2022-06-21 09:31:32.409659
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    cache = FactCache()
    cache['test']='something'
    assert cache['test'] == 'something'


# Generated at 2022-06-21 09:31:34.735302
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    cache = FactCache()
    cache['a'] = 'b'
    cache.flush()
    assert not cache

# Generated at 2022-06-21 09:31:46.473073
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    # a cache instance is needed for testing and it is defined as a global variable
    global cache

    # define the input to the tested method
    host = 'local'

    # define the expected output from the tested method

# Generated at 2022-06-21 09:31:54.864044
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    facts = FactCache()

    # Ensure cache is empty
    facts.flush()

    # Test cache is empty, return: []
    assert facts.keys() == []

    # Set a fact in the cache
    test_fact = 'val'
    facts['test'] = test_fact

    # Test cache has the fact, return: ['test']
    assert facts.keys() == ['test']

    # Flush the cache
    facts.flush()

    # Test cache is empty, return: []
    assert facts.keys() == []

    # Delete the variable
    del facts



# Generated at 2022-06-21 09:31:57.555363
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    fact_cache[1] = "test value"
    assert len(fact_cache) == 1


# Generated at 2022-06-21 09:31:58.982592
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-21 09:32:00.456472
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    cache = FactCache()
    cache['test'] = 'test'
    assert cache['test'] == 'test'
    del cache['test']
    assert 'test' not in cache


# Generated at 2022-06-21 09:32:05.248976
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    factCache = FactCache()
    fact_value = {'ahostname': 'ahostname'}
    factCache['ahostname'] = fact_value
    #assert factCache.__getitem__('ahostname') == fact_value
    #assert factCache['ahostname'] == fact_value
    assert factCache.get_value('ahostname') == fact_value


# Generated at 2022-06-21 09:32:07.164542
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    cache = FactCache()
    key = 'foo'
    cache[key] = 'bar'
    assert cache[key] == 'bar'


# Generated at 2022-06-21 09:32:59.592513
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fc = FactCache()
    fc['a'] = {'a1': 'A1'}
    fc['b'] = {'b1': 'B1'}
    assert len(fc) == 2
    assert fc['a'] == {'a1': 'A1'}
    assert fc['b'] == {'b1': 'B1'}


# Generated at 2022-06-21 09:33:04.683571
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    fact_cache['key1'] = 'value1'
    fact_cache['key2'] = 'value2'

    assert fact_cache.copy() == {'key1': 'value1', 'key2': 'value2'}

# Generated at 2022-06-21 09:33:06.093169
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()

# Generated at 2022-06-21 09:33:07.039504
# Unit test for constructor of class FactCache
def test_FactCache():
    cacheobj = FactCache()

# Generated at 2022-06-21 09:33:11.338907
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = FactCache()
    fact_cache['host_key'] = 'host_value'

    fact_cache = fact_cache._plugin.get('host_key')
    assert fact_cache == 'host_value'


# Generated at 2022-06-21 09:33:21.084571
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    class Plugin:
        def __init__(self):
            self.cache = {'1': '1', '2': '2'}
        def contains(self, key):
            return self.cache.__contains__(key)

    plugin = Plugin()
    cache = FactCache()
    cache._plugin = plugin
    assert cache.__contains__('1') == plugin.cache.__contains__('1')
    assert cache.__contains__('2') == plugin.cache.__contains__('2')
    assert cache.__contains__('3') == plugin.cache.__contains__('3')


# Generated at 2022-06-21 09:33:22.146252
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    pass


# Generated at 2022-06-21 09:33:24.651755
# Unit test for constructor of class FactCache
def test_FactCache():
    factCache = FactCache()
    assert factCache is not None

# Generated at 2022-06-21 09:33:26.025253
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
  pass


# Generated at 2022-06-21 09:33:29.631024
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    fact_cache['hostname'] = 'laptop'
    assert fact_cache.flush() is None
    # Test if the flush method clear the cache
    assert len(fact_cache) is 0


# Generated at 2022-06-21 09:35:20.937289
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import MutableMapping

    class fake_plugin(MutableMapping):
        def contains(self, key):
            return True

        def delete(self, key):
            return True

        def get(self, key):
            return 'value'

        def keys(self):
            return ['key']

        def set(self, key, value):
            return True

        def flush(self):
            return True

    class FakeModuleUtilsCacheModule():
        @staticmethod
        def get(cache_plugin):
            return fake_plugin()

    class FakeDisplay():
        def __init__(self, *args, **kwargs):
            return


# Generated at 2022-06-21 09:35:30.722400
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    assert fact_cache.copy() == {}

    fact_cache['key1'] = {'a': 'b'}
    assert fact_cache['key1'] == {'a': 'b'}
    assert fact_cache.copy() == {'key1': {'a': 'b'}}

    fact_cache['key2'] = {'c': 'd'}
    assert fact_cache['key2'] == {'c': 'd'}
    assert fact_cache.copy() == {'key1': {'a': 'b'}, 'key2': {'c': 'd'}}

# Generated at 2022-06-21 09:35:34.439978
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    import pytest
    import ansible.plugins.cache.jsonfile

    cache = FactCache()
    cache._plugin = ansible.plugins.cache.jsonfile.FactCacheModule()

    pytest.raises(AnsibleError, cache.__delitem__, None)

# Generated at 2022-06-21 09:35:35.850910
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert isinstance(cache, FactCache)



# Generated at 2022-06-21 09:35:37.452882
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert isinstance(cache, FactCache)

# Unit tests for copy

# Generated at 2022-06-21 09:35:41.190386
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    from ansible.cache import FactCache
    facts = FactCache()
    facts["localhost"] = {"localhost": {},
                          "localhost.localdomain": {}
                          }
    del facts["localhost"]
    assert not facts.keys()


# Generated at 2022-06-21 09:35:43.577015
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    test_facts_cache = FactCache()
    test_facts_cache.flush()
    assert test_facts_cache._plugin.keys() == []


# Generated at 2022-06-21 09:35:44.797263
# Unit test for constructor of class FactCache
def test_FactCache():
    f = FactCache()
    assert isinstance(f, FactCache)

# Generated at 2022-06-21 09:35:48.697024
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    fact_cache['foo'] = 'bar'
    fact_cache['baz'] = 'qux'
    # used to raise KeyError
    try:
        fact_cache2 = fact_cache.copy()
        assert fact_cache2['foo'] == 'bar'
    except KeyError:
        assert False

# Generated at 2022-06-21 09:35:51.801162
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    c = FactCache()
    c.__setitem__("key1", "value1")
    # test the item is added to fact_cache
    assert c.__getitem__("key1") == "value1", "FactCache __setitem__ fails"
