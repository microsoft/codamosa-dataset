

# Generated at 2022-06-21 09:27:14.928519
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    import sys
    import pytest
    from collections import Mapping, Container

    from ansible.module_utils.six import iteritems


# Generated at 2022-06-21 09:27:22.395272
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():

    import tempfile

    fact_cache = FactCache()
    tmp_dir = tempfile.mkdtemp()

    # TODO: Find a better way to test __getitem__
    # The fact cache is initialized to a json file when the plugin is loaded
    # Add some data to it so that the test does not fail

    fact_cache._plugin._cache_file = tmp_dir + '/' + fact_cache._plugin._cache_file

    test_key = 'test_key'
    test_value = 'test_value'
    fact_cache[test_key] = test_value

    assert fact_cache[test_key] == test_value

test_FactCache___getitem__()



# Generated at 2022-06-21 09:27:26.387516
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    import collections
    fc=FactCache()
    print(isinstance(fc,collections.MutableMapping))
    print(fc._plugin)
    pass

test_FactCache___contains__()

# Generated at 2022-06-21 09:27:28.951014
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)
    assert isinstance(fact_cache, MutableMapping)

# Generated at 2022-06-21 09:27:39.297397
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    cached_facts_dict = FactCache()
    cached_facts_dict.flush()
    assert len(cached_facts_dict) == 0
    cached_facts_dict['1.2.3.4'] = {'ansible_facts': {'a': '1', 'b': '2'}}
    assert len(cached_facts_dict) == 1
    cached_facts_dict['2.3.4.5'] = {'ansible_facts': {'a': '3', 'b': '4'}}
    assert len(cached_facts_dict) == 2
    cached_facts_dict['3.4.5.6'] = {'ansible_facts': {'a': '5', 'b': '6'}}
    assert len(cached_facts_dict) == 3


# Generated at 2022-06-21 09:27:41.034106
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fact_cache = FactCache()
    assert fact_cache['non_existing_key'] == KeyError

# Generated at 2022-06-21 09:27:48.151717
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    from ansible.module_utils.facts.system.base import BaseFactCollector
    from ansible.module_utils.facts.virtual.base import BaseFactCollector
    from ansible.plugins.loader import cache_loader
    from ansible.utils.display import Display
    display = Display()
    fact_cache= FactCache()
    assert isinstance(fact_cache, MutableMapping)
    assert isinstance(fact_cache._plugin, BaseFactCollector)

# Generated at 2022-06-21 09:27:59.128399
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    from ansible.module_utils.common._collections_compat import MutableMapping
    import mock

    class plugin_class(MutableMapping):
        def __init__(self, *args, **kwargs):
            self.cache = dict()

        def get(self, key):
            return self.cache.get(key, None)

        def set(self, key, value):
            self.cache[key] = value

        def delete(self, key):
            del self.cache[key]

        def contains(self, key):
            return key in self.cache

        def keys(self):
            return self.cache.keys()

        def flush(self):
            self.cache = dict()

    plugin = plugin_class()

    fact_cache = FactCache()

# Generated at 2022-06-21 09:28:01.808709
# Unit test for constructor of class FactCache
def test_FactCache():
    # C.CACHE_PLUGIN is set to 'jsonfile' in ansible.cfg
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'JsonFile'

# Generated at 2022-06-21 09:28:04.943186
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    factcache = FactCache()
    factcache._plugin = FakeCachePlugin()
    factcache['a'] = 'A'
    factcache['b'] = 'B'
    assert factcache.copy() == {'a': 'A', 'b': 'B'}


# Generated at 2022-06-21 09:28:12.392960
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    data = {
      '_plugin': {
        'keys': [
          'h1',
          'h2',
          'h3'
        ]
      }
    }
    x = FactCache(data)
    x_iter = list(x.__iter__())
    assert x_iter == ['h1', 'h2', 'h3']



# Generated at 2022-06-21 09:28:24.012440
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():

    fact_cache = FactCache()

    fact_cache["Al"] = {
        "firstname": "Al",
        "lastname": "Pacino",
        "age": 74
    }

    fact_cache["Robert"] = {
        "firstname": "Robert",
        "lastname": "De Niro",
        "age": 72
    }

    l = len(fact_cache)

    assert l == 2

    del fact_cache["Al"]

    l = len(fact_cache)

    assert l == 1

    fact_cache["Robert"] = {
        "firstname": "Robert",
        "lastname": "De Niro",
        "age": 72
    }

    l = len(fact_cache)

    assert l == 1

    fact_cache.flush()

    l = len(fact_cache)

# Generated at 2022-06-21 09:28:26.119719
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    facts = FactCache()
    facts["key"] = "value"
    assert facts["key"] == "value"


# Generated at 2022-06-21 09:28:28.682302
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    facts = FactCache()
    assert len(facts) == 0
    facts['some key'] = 'some value'
    assert len(facts) == 1
    assert facts['some key'] == 'some value'

# Generated at 2022-06-21 09:28:33.525341
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    cache = FactCache()
    cache['a'] = 'first'
    assert len(cache) == 1
    cache['b'] = 'second'
    assert len(cache) == 2
    cache.flush()
    assert len(cache) == 0



# Generated at 2022-06-21 09:28:34.947243
# Unit test for constructor of class FactCache
def test_FactCache():
    f = FactCache()
    assert f

# Generated at 2022-06-21 09:28:39.217025
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fact_cache = FactCache()
    fact_cache['1'] = 'one'
    fact_cache['2'] = 'two'
    fact_cache['3'] = 'three'
    for key in fact_cache:
        print(key,fact_cache[key])

test_FactCache___iter__()


# Generated at 2022-06-21 09:28:47.226977
# Unit test for method __getitem__ of class FactCache

# Generated at 2022-06-21 09:28:53.001879
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    from ansible.utils.display import Display
    from ansible.plugins.cache import BaseFileCacheModule
    from ansible.plugins.loader import cache_loader

    display = Display()
    cache_plugin = BaseFileCacheModule()
    cache_loader.add('test_FactCache___delitem__', cache_plugin)

    cache_plugin.set('key', 'value')
    f = FactCache()
    f['key'] = 'value'
    assert 'key' in f
    del f['key']
    assert 'key' not in f

# Generated at 2022-06-21 09:28:58.786770
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    cache = FactCache()
    test_key = 'test_key'
    test_value = 'test_value'
    cache[test_key] = test_value
    assert test_key in cache.keys() and test_key in cache
    assert test_value == cache[test_key]


# Generated at 2022-06-21 09:29:09.094339
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    obj = FactCache()
    assert obj.copy() == {}, "Calling copy when empty returned non-empty dict"

    key = 'test_key'

    obj[key] = 'test_value'
    obj_copy = obj.copy()

    assert obj_copy[key] == 'test_value'
    assert len(obj_copy) == 1

# unit test for non-empty key value pair in cache, then copy, then update

# Generated at 2022-06-21 09:29:13.484591
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    try:
        assert 'ola' in fact_cache, "Failed to run unittest for FactCache class method keys, assertion error"
    except KeyError:
        assert True, "Failed to run unittest for FactCache class method keys, KeyError error"
    except AnsibleError:
        assert True, "Failed to run unittest for FactCache class method keys, AnsibleError error"


# Generated at 2022-06-21 09:29:24.062849
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()

    test_key1 = 'my_key1'
    test_value1_1 = 'my_value1_1'
    test_value1_2 = 'my_value1_2'
    test_value1_3 = 'my_value1_3'

    test_key2 = 'my_key2'
    test_value2_1 = 'my_value2_1'

    # test_key1 have three value
    fact_cache.first_order_merge(test_key1, test_value1_1)
    assert test_value1_1 in fact_cache[test_key1]
    assert test_value1_2 not in fact_cache[test_key1]
    assert test_value1_3 not in fact_cache[test_key1]
    fact

# Generated at 2022-06-21 09:29:32.477946
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    cache = FactCache()
    cache.__setitem__("_ansible_no_log", "True")
    cache.__setitem__("_ansible_verbose_always", "True")
    cache.__setitem__("_ansible_version", "2.4.1.0")
    cache.__setitem__("_ansible_version_full", "2.4.1.0")
    assert len(cache) == 4

# Generated at 2022-06-21 09:29:33.409928
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    assert True


# Generated at 2022-06-21 09:29:43.935540
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = {
        'host1': {
            'fact1': 'v1',
            'fact2': 'v2'
        },
        'host2': {
            'fact3': 'v3',
            'fact4': 'v4'
        }
    }
    fact_cache = FactCache(cache)

    fact_cache.first_order_merge('host1', {'fact2': 'overwritten', 'fact3': 'added'})
    assert fact_cache['host1'] == {
        'fact1': 'v1',
        'fact2': 'overwritten',
        'fact3': 'added'
    }

    fact_cache.first_order_merge('host2', {'fact4': 'overwritten', 'fact5': 'added'})

# Generated at 2022-06-21 09:29:47.363328
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    value = '"value"'

    fact_cache = FactCache()
    fact_cache['key'] = value

    try:
        del fact_cache['key']
    except KeyError:
        pass

    assert 'key' not in fact_cache


# Generated at 2022-06-21 09:29:50.134891
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    test_cache = FactCache()
    assert len(test_cache) == 0


# Generated at 2022-06-21 09:29:52.999731
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    fact_cache["localhost"] = '"something"'
    fact_cache.flush()
    assert not fact_cache["localhost"]


# Generated at 2022-06-21 09:29:53.916376
# Unit test for constructor of class FactCache
def test_FactCache():
    factcache = FactCache()


# Generated at 2022-06-21 09:30:06.078912
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    # 1. Arrange
    cache = FactCache()
    cache["key"] = "value"

    # 2. Act
    actual = cache["key"]

    # 3. Assert
    assert actual == "value"


# Generated at 2022-06-21 09:30:17.985659
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    import pytest
    from ..cacheplugin import FactCache
    from ..cacheplugin import PluginFileCache
    from ansible.plugins.cache import BaseFileCacheModule
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import unwrap_var
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.utils.unsafe_proxy import FailUnsafe
    from ansible.utils.unsafe_proxy import UnsafeProxy

    fact_cache = FactCache()
    base_file_cache_module = BaseFileCacheModule()
    fact_cache._plugin = base_file_cache_module

# Generated at 2022-06-21 09:30:22.715415
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():

    from ansible.plugins.cache.memory import CacheModule as memory_cache_module
    x = memory_cache_module()
    fc = FactCache()

    host = 'host'
    fc[host] = 'value'
    assert "host" in fc



# Generated at 2022-06-21 09:30:26.237391
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fc = FactCache()
    fc['test1'] = 'test2'
    fc['test3'] = 'test4'
    assert fc.keys() == ['test1', 'test3']

# Generated at 2022-06-21 09:30:33.067901
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'fact1': 'fact1_value'})
    assert fact_cache['host1']['fact1'] == 'fact1_value'
    fact_cache.first_order_merge('host1', {'fact1': 'fact1_value_new', 'fact2': 'fact2_value'})
    assert fact_cache['host1']['fact1'] == 'fact1_value_new'
    assert fact_cache['host1']['fact2'] == 'fact2_value'
    fact_cache.flush()

# Generated at 2022-06-21 09:30:34.791604
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fcache = FactCache()
    fcache.__len__()



# Generated at 2022-06-21 09:30:39.215599
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fc = {}
    fc.update(fact_cache = FactCache())
    fc['fact_cache']['localhost'] = 'xyz'
    assert 'localhost' in fc['fact_cache']


# Generated at 2022-06-21 09:30:40.214013
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    pass

# Generated at 2022-06-21 09:30:43.747751
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    fact_cache['key'] = {'fact': 15}
    fact_cache_copy = fact_cache.copy()
    assert fact_cache_copy['key']['fact'] == 15

# Generated at 2022-06-21 09:30:48.219977
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    cache = FactCache()
    cache["a"] = 1
    assert cache.copy() == {"a": 1}
    cache["b"] = 2
    assert cache.copy() == {"a": 1, "b": 2}
    del cache["a"]
    assert cache.copy() == {"b": 2}


# Generated at 2022-06-21 09:30:57.085106
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    plugin = cache_loader.get(C.CACHE_PLUGIN)
    fc = FactCache()
    assert fc is not None


# Generated at 2022-06-21 09:31:01.796070
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fc = FactCache()
    assert hasattr(fc, '__iter__')
    assert isinstance(fc.__iter__(), type(iter([])))

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-21 09:31:06.141237
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    """Test class FactCache method __delitem__"""
    facts_cache = FactCache()
    facts_cache['key'] = 'value'
    assert facts_cache.keys() == ['key']
    assert facts_cache['key'] == 'value'

    del facts_cache['key']
    assert 'key' not in facts_cache.keys()


# Generated at 2022-06-21 09:31:13.828774
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    hostname = 'localhost'
    source_data = {'version': '1.2.3'}
    fact_cache.first_order_merge(hostname, source_data)
    assert fact_cache[hostname] == source_data
    source_data = {'version': '2.3.4'}
    fact_cache.first_order_merge(hostname, source_data)
    assert fact_cache[hostname]['version'] == '1.2.3'

# Generated at 2022-06-21 09:31:16.253680
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    factcache = FactCache()
    factcache['key1'] = 'value1'
    assert factcache.__getitem__('key1') == 'value1'


# Generated at 2022-06-21 09:31:20.776497
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    """
    Tests the method first_order_merge of class FactCache
    """
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_key', 'test_value')
    assert fact_cache.get('test_key') == 'test_value'
    fact_cache.first_order_merge('test_key', 'test_value2')
    assert fact_cache.get('test_key') == 'test_value2'

# Generated at 2022-06-21 09:31:21.867936
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    pass


# Generated at 2022-06-21 09:31:22.328738
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    assert True

# Generated at 2022-06-21 09:31:27.207157
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    cache = FactCache()
    cache_data = {'192.168.1.1': {'version': 1.1, 'distribution': 'Centos'},
                  '192.168.1.2': {'version': 2.2, 'distribution': 'Ubuntu'}}
    cache.update(cache_data)
    assert cache.copy() == cache_data

# Generated at 2022-06-21 09:31:34.662828
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    import time
    import os

    _plugin = cache_loader.get(C.CACHE_PLUGIN)

    if os.path.exists('/tmp/ansible_fact_cache'):
        os.remove('/tmp/ansible_fact_cache')

    fact_cache = FactCache()
    assert not ('127.0.0.1' in fact_cache)

    if hasattr(_plugin, '__init__'):
        # support cache plugins do not have __init__() method
        _plugin.__init__()

    # Initialize cache file
    _plugin.set('127.0.0.1', {"fact": "value"})
    assert '127.0.0.1' in fact_cache

    # Expire the cache file

# Generated at 2022-06-21 09:31:51.664825
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    fact_cache.clear()

    fact_cache["key1"] = {"a":"b"}
    fact_cache["key2"] = {"c":"d"}

    assert fact_cache.keys() == ["key1", "key2"]

    assert fact_cache["key1"]["a"] == "b"
    assert fact_cache["key2"]["c"] == "d"

    assert len(fact_cache) == 2
    assert "key1" in fact_cache

    # Tests the use of 'in' on a non-existing key
    assert "key3" not in fact_cache

    # Tests the use of 'del'
    del fact_cache["key1"]
    assert fact_cache.keys() == ["key2"]

    # Tests the use of 'flush'
    fact_cache

# Generated at 2022-06-21 09:31:56.532612
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():

    from ansible.plugins.cache import jsonfile
    from ansible.errors import AnsibleError
    from ansible.module_utils.common._collections_compat import Sequence
    import json

    fact_cache = FactCache()

    # Test when the plugin is not initialized
    expected = AnsibleError
    actual = fact_cache.__setitem__
    assertRaises(expected, actual, "test_key", "test_value")

    fact_cache._plugin = jsonfile.JSONFileCacheModule()
    fact_cache._plugin.get_cache_file_path = lambda x, y: "/tmp/cache.json"

    fact_cache.__setitem__("test_key", "test_value")

    with open("/tmp/cache.json", "r") as fd:
        data = json.load(fd)

        expected

# Generated at 2022-06-21 09:31:59.416767
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    fact_cache = FactCache()
    key = 'localhost'
    value = dict(a=1,b=2,c=3)

    assert fact_cache[key] == value

# Generated at 2022-06-21 09:32:05.649415
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    # Check for invalid input.
    instance = FactCache()
    with pytest.raises(TypeError) as e:
        instance.__setitem__(1)

    assert e.value.args[0] == "__setitem__() missing 1 required positional argument: 'value'"

    # Check for valid input.
    # __setitem__ should be a success for valid values.
    instance.__setitem__('test_key', 'test_value')
    assert 'test_key' in instance
    instance.flush()



# Generated at 2022-06-21 09:32:07.876587
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fact_cache = FactCache()
    for key in fact_cache:
        assert(False)



# Generated at 2022-06-21 09:32:09.098196
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()


# Generated at 2022-06-21 09:32:10.447102
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert isinstance(cache, FactCache)



# Generated at 2022-06-21 09:32:19.138973
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    import unittest

    class getitem_Test(unittest.TestCase):

        def test_getitem__found(self):
            import pickle
            class MockCacheLoader(object):
                def contains(self, key):
                    return True

# Generated at 2022-06-21 09:32:20.591423
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    assert fact_cache.copy() == {}



# Generated at 2022-06-21 09:32:33.088409
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    from collections import OrderedDict
    from ansible.plugins.cache.memory import CacheModule

    class CacheLoaderTest(object):
        def get(self, opt, *args, **kwargs):
            return CacheModule()

    cache_loader._fact_cache_plugins = OrderedDict()
    cache_loader._fact_cache_plugins['memory'] = CacheLoaderTest()

    fact_cache = FactCache() # create the instance
    assert not fact_cache
    assert 0 == len(fact_cache)

    fact_cache['192.168.0.1'] = 'one'
    fact_cache['192.168.0.2'] = 'two'
    fact_cache['192.168.0.3'] = 'three'

    assert 3 == len(fact_cache)


# Generated at 2022-06-21 09:33:00.836145
# Unit test for constructor of class FactCache
def test_FactCache():
    facts = FactCache()
    assert facts is not None
    assert facts._plugin is not None
    assert len(facts) == 0

# Generated at 2022-06-21 09:33:02.943104
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():

    myfactcache = FactCache()
    assert len(myfactcache) == 0


# Generated at 2022-06-21 09:33:09.154217
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    C.HOST_KEY_CHECKING = False
    C.CACHE_PLUGIN = 'jsonfile'
    C.CACHE_PLUGIN_CONNECTION = False
    cache = FactCache()
    cache["foo"] = "bar"
    assert cache.__contains__("foo")

# Generated at 2022-06-21 09:33:21.000321
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    
    import os
    import json
    import tempfile

    header = '''[
'''
    trailer = '''
]
'''

# Generated at 2022-06-21 09:33:24.372390
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    cache = FactCache()

    # set the cache to contain a single value
    cache["host1"] = {'name': 'host1', 'facts': {'value': 1}}

    assert len(cache.keys()) == 1
    assert cache.keys()[0] == "host1"


# Generated at 2022-06-21 09:33:26.149624
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    a = FactCache()
    a.flush()


# Generated at 2022-06-21 09:33:34.844059
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    host = '127.0.0.1'
    cache = {}
    cache_file = 'test/test_host_cache.fact_cache'
    fact_cache = FactCache(host, cache, cache_file)
    fact_cache['testkey1'] = 'testvalue1'
    fact_cache['testkey2'] = {'testkey1': 'testvalue1', 'testkey2': 'testvalue2'}
    assert set(fact_cache.keys()) == {'testkey1', 'testkey2'}
    assert set(fact_cache.keys()) == set({'testkey1', 'testkey2'})


# Generated at 2022-06-21 09:33:36.031036
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    pass


# Generated at 2022-06-21 09:33:47.675909
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    import os
    import pickle
    from ansible.module_utils.facts.cache import FactCache
    
    test_facts_cache = FactCache()

    # Test if default fact cache is empty
    if os.path.exists(C.DEFAULT_LOCAL_TMP + "/ansible_fact_cache.data"):
        with open(C.DEFAULT_LOCAL_TMP + "/ansible_fact_cache.data", "rb") as f:
            test_facts_cache = pickle.load(f)
    assert(len(test_facts_cache) == 0)
    
    # Test if iterating on the keys of default fact cache is empty
    assert(len(list(iter(test_facts_cache))) == 0)

    # Test if iterating on the keys of default fact cache is empty after adding one value


# Generated at 2022-06-21 09:33:51.463192
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():

    cache = FactCache()

    host = 'localhost'
    fact = 'ansible_fact'
    value = 'True'

    cache[host] = {fact: value}


# Generated at 2022-06-21 09:34:51.373926
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    fact_cache['marco'] = 'polo'
    result = fact_cache.copy()
    assert result['marco'] == 'polo'

# Generated at 2022-06-21 09:34:52.525246
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = FactCache();
    fact_cache["key"] = "value"
    assert fact_cache["key"] == "value"


# Generated at 2022-06-21 09:34:53.533353
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    pass


# Generated at 2022-06-21 09:34:58.980134
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fact_key = 'testkey'
    fact_value = 10
    fc.first_order_merge(fact_key, fact_value)

    assert fc[fact_key] == fact_value

    fc.first_order_merge(fact_key, fact_value)

    assert fc[fact_key] == fact_value

# Generated at 2022-06-21 09:35:01.893321
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    host_list = ['host1', 'host2', 'host3', 'host4', 'host5']
    fact_cache = FactCache(host_list)
    assert host_list == list(iter(fact_cache))

# Generated at 2022-06-21 09:35:02.961484
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    cache = FactCache()
    assert cache.flush


# Generated at 2022-06-21 09:35:05.261912
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fc = FactCache()
    fc['test_key'] = 'test_value'
    result = fc.copy()
    assert 'test_key' in result
    assert result['test_key'] == 'test_value'


# Generated at 2022-06-21 09:35:06.441516
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fact_cache = FactCache()
    iter(fact_cache)


# Generated at 2022-06-21 09:35:17.842033
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    cache_plugin = {'test_key': 'test_value'}

    class _plugin:
        def contains(self, key):
            return key in cache_plugin

        def get(self, key):
            return cache_plugin[key]

        def set(self, key, value):
            cache_plugin[key] = value

        def delete(self, key):
            del cache_plugin[key]

        def flush(self):
            cache_plugin.clear()

    cache = FactCache()
    cache._plugin = _plugin()
    cache.__setitem__('test_key', 'test_value')
    assert isinstance(cache.copy(), dict)
    assert cache.copy() == {'test_key': 'test_value'}

# Generated at 2022-06-21 09:35:20.832356
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    facts_cache = FactCache()
    facts_cache['host'] = {'test': 1, 'key': 'value'}
    assert facts_cache['host'] == {'test': 1, 'key': 'value'}


# Generated at 2022-06-21 09:36:28.239945
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    # TODO: add tests
    pass


# Generated at 2022-06-21 09:36:30.642279
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    factCache = FactCache()
    factCache.__setitem__("foo", "bar")
    if factCache.__contains__("foo"):
        assert(True)
    else:
        assert(False)


# Generated at 2022-06-21 09:36:31.601362
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    obj = FactCache()
    obj.flush()

# Generated at 2022-06-21 09:36:42.480802
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import StringIO
    import pytest

    # create a fact cache object
    fact_cache = FactCache()
    # set some facts
    fact_cache['localhost'] = {'ansible_os_family': 'RedHat'}

    # assert that fact cache contains a fact
    assert fact_cache.__contains__('localhost')
    # assert that fact cache does not contain a fact
    assert not fact_cache.__contains__('domain')

    # set facts with 'contains' method
    assert fact_cache.__contains__('localhost')

    # set facts with 'update' method
    fact_cache.update({'domain': {'ansible_os_family': 'RedHat'}})
    assert fact_cache.__

# Generated at 2022-06-21 09:36:44.569282
# Unit test for constructor of class FactCache
def test_FactCache():
    plugin = cache_loader.get('jsonfile')
    fc = FactCache(plugin=plugin)
    tc = FactCache()

# Generated at 2022-06-21 09:36:48.448020
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    hostvars = {'test_host': {'testvar1': 'testvalue1', 'testvar2': 'testvalue2'}}
    fact_cache = FactCache()
    for host in hostvars.keys():
        fact_cache[host] = hostvars[host]
    fact_cache.flush()
    assert fact_cache.keys() == [], 'fact_cache.keys()'

# Generated at 2022-06-21 09:36:51.430290
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fc = FactCache()
    fc.set("host1", 1)
    fc.set("host2", 2)
    fc.set("host3", 3)
    fc.flush()
    assert len(fc.keys()) == 0

# Generated at 2022-06-21 09:37:00.791877
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    class TestPlugin:
        def contains(self,key):
            if key == "key1":
                return True
            else:
                return False
        def get(self,key):
            return "value1"

    test_plugin = TestPlugin()
    fact_cache = FactCache()
    fact_cache._plugin = test_plugin
    assert fact_cache.__getitem__("key1") == "value1"
    try:
        fact_cache.__getitem__("key2")
    except KeyError:
        assert True


# Generated at 2022-06-21 09:37:02.374979
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    cache = FactCache()
    cache['test'] = 1
    assert cache['test'] == 1


# Generated at 2022-06-21 09:37:06.315564
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    fact_cache["fact1"] = "val1"
    fact_cache["fact2"] = "val2"
    assert dict(fact_cache) == {'fact1': 'val1', 'fact2': 'val2'}

