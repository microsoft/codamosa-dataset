

# Generated at 2022-06-21 09:27:14.532790
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    plugin = FakeCache()
    fact_cache = FactCache()
    fact_cache._plugin = plugin
    assert len(fact_cache) == plugin.get_len()



# Generated at 2022-06-21 09:27:15.272786
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    pass


# Generated at 2022-06-21 09:27:16.790033
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    TestFactsCache = FactCache()
    TestFactsCache["test"] = 1
    assert TestFactsCache["test"] == 1


# Generated at 2022-06-21 09:27:19.737326
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    cache_loader.get()._cache = {'alpha': {'a': 1}, 'beta': {'b': 1}}
    fact_cache = FactCache()
    assert set(fact_cache.keys()) == {'alpha', 'beta'}

# Generated at 2022-06-21 09:27:25.026661
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    """
    This test is to check whether the functionality of the method __setitem__ of class FactCache
    is working properly or not
    """

    fc = FactCache()
    fc['abc']= 'xyz'
    fc['abc']= 'xyz123'
    assert fc['abc'] == 'xyz123'


# Generated at 2022-06-21 09:27:27.285766
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    test_instance = FactCache()
    assert isinstance(test_instance.copy(), dict)


# Generated at 2022-06-21 09:27:29.340215
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    f = FactCache()
    f._plugin.set('h1', 1)
    f._plugin.set('h2', 2)
    assert 1 == f['h1']
    assert 2 == f['h2']
    try:
        f['h3']
    except KeyError:
        pass
    else:
        assert False
    

# Generated at 2022-06-21 09:27:39.500191
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.plugins.cache import BaseFactCacheModule
    from ansible.utils.display import Display
    from unittest.case import TestCase

    class BaseFactCacheModuleMock(BaseFactCacheModule):
        def __iter__(self):
            return ['iter_keys']

    class MutableMappingMock(MutableMapping):
        def __iter__(self):
            return ['iter_keys']

    class TestFactCache(TestCase):
        def test___iter__(self):
            _plugin = BaseFactCacheModuleMock()
            m = FactCache()
            m._plugin = _plugin
            self.assertEqual(list(m), ['iter_keys'])



# Generated at 2022-06-21 09:27:42.850071
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache = FactCache()
    fact_cache['one'] = 'first'
    del fact_cache['one']
    assert 'one' not in fact_cache.keys()


# Generated at 2022-06-21 09:27:51.049973
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fc = FactCache()
    fc['1'] = '1'
    try:
        assert '1' in fc
    except Exception as e:
        print(e)
        raise

    try:
        assert '2' not in fc
    except Exception as e:
        print(e)
        raise

    del fc['1']
    try:
        assert '1' not in fc
    except Exception as e:
        print(e)
        raise


# Generated at 2022-06-21 09:27:55.757717
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.module_utils.facts import is_local_address
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    import sys

    def is_localhost(addresses):
        for address in addresses:
            if is_local_address(address):
                return True
        return False


# Generated at 2022-06-21 09:27:59.084343
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    facts_cache = FactCache()
    facts_cache[(u'localhost',)] = {u'fact': u'value'}
    test_key = (u'localhost',)
    assert test_key in facts_cache

# Generated at 2022-06-21 09:28:02.696047
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fact_cache = FactCache()
    # for idx in range(10):
    #     fact_cache.__setitem__(idx, idx)
    #     fact_cache.__getitem__(idx)

if __name__ == '__main__':
    test_FactCache___getitem__()

# Generated at 2022-06-21 09:28:06.869840
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fc = FactCache()
    fc[0] = 'abc'
    if fc[0] != 'abc':
        return False
    if 'abc' not in fc:
        return False
    if len(fc) != 1:
        return False
    return True


# Generated at 2022-06-21 09:28:12.639487
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    # Add test data to memcached
    fc = FactCache()
    fc.__setitem__('test1','data1')
    fc.__setitem__('test2','data2')

    result = fc.copy()

    # Test copy data
    assert result['test1'] == 'data1'
    assert result['test2'] == 'data2'


# Generated at 2022-06-21 09:28:16.387053
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fac = FactCache()
    fac.__setitem__('test', {'test':'test'})
    assert fac.__contains__('test')


# Generated at 2022-06-21 09:28:18.033940
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    def __len__(self):
        return len(self._plugin.keys(''))

    # Test with invalid value
    len(FactCache())


# Generated at 2022-06-21 09:28:22.360447
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    fact_cache['test_key'] = 'test_value'
    assert fact_cache.get('test_key') == 'test_value'
    fact_cache.flush()
    assert fact_cache.get('test_key') is None


# Generated at 2022-06-21 09:28:28.845698
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    """
    fact_cache_plugin = helpers.mock(
        keys=helpers.mock(return_value=["host1.example.org","host2.example.com"])
    )
    plugin_loader_dict = {
        "fact_cache": fact_cache_plugin
    }

    with mock.patch("__main__.cache_loader", plugin_loader_dict):
        fact_cache = FactCache()

        assert fact_cache.keys() == ["host1.example.org","host2.example.com"]
    """

# Generated at 2022-06-21 09:28:32.348925
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    cache = FactCache()
    cache['foo'] = {'bar': 'baz'}
    assert cache.copy() == {'foo': {'bar': 'baz'}}

# Generated at 2022-06-21 09:28:36.462518
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    #TODO
    pass


# Generated at 2022-06-21 09:28:37.407874
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    factcache = FactCache()
    factcache.flush()

# Generated at 2022-06-21 09:28:43.816910
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    import collections
    import random

    fact_cache = FactCache()

    test_dict = collections.OrderedDict()
    test_list = list('abcdefghijklmnopqrstuvwxyz1234567890')
    random.shuffle(test_list)

    for key in test_list:
        test_dict[key] = random.sample(test_list, random.randint(1, len(test_list)))

    fact_cache.update(test_dict)
    assert fact_cache.copy() == test_dict

# Generated at 2022-06-21 09:28:44.914716
# Unit test for constructor of class FactCache
def test_FactCache():
    factcache = FactCache()
    assert factcache

# Generated at 2022-06-21 09:28:52.639686
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    cache_plugin = cache_loader.get('jsonfile')
    assert isinstance(cache_plugin, cache_loader.JsonFileCacheModule)

    tmp_dir = '/tmp'
    cache_plugin.set_options(dir=tmp_dir)

    fact_cache = FactCache()

    host_info = {}
    host_info['some_key'] = "some_value"
    fact_cache['some_key'] = host_info

    keys = fact_cache.keys()
    assert isinstance(keys, list)
    #assert keys[0] == 'some_key'

    fact_cache.flush()
    assert fact_cache.keys() == []


# Generated at 2022-06-21 09:29:04.491375
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():

    cache = FactCache()
    cache.update({'key1': 'value1'})
    cache.update({'key2': 'value2'})
    cache.update({'key3': 'value3'})

    # raises KeyError because cache is empty
    try:
        cache.__delitem__({'key4': 'value4'})
    except KeyError:
        pass

    cache.__delitem__({'key1': 'value1'})
    assert 'key1' not in cache
    for key in cache.keys():
        if key == 'key2':
            assert 'key2' in cache
        if key == 'key3':
            assert 'key3' in cache


# Generated at 2022-06-21 09:29:11.706994
# Unit test for constructor of class FactCache
def test_FactCache():
    # Arrange
    class CacheLoaderMock(object):
        def __init__(self):
            pass

        def get(self, cache_name):
            if cache_name != C.CACHE_PLUGIN:
                raise AnsibleError('Unable to load the facts cache plugin (%s).' % (C.CACHE_PLUGIN))

    cache_loader.get = CacheLoaderMock().get

    # Act
    fac_cache = FactCache()

    # Assert
    assert(fac_cache._plugin == CacheLoaderMock.get)


# Generated at 2022-06-21 09:29:20.274074
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    """
    Test case for method FactCache.__getitem__
    """
    # Test 1
    test_cache_plugin = TestCache()
    test_facts_cache = FactCache(cache_plugin=test_cache_plugin)
    assert 'foo' in test_facts_cache

    # Test 2
    test_facts_cache = FactCache(cache_plugin=test_cache_plugin)
    try:
        test_facts_cache['bar']
    except Exception as e:
        assert type(e) is KeyError


# Generated at 2022-06-21 09:29:22.350996
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    factCache = FactCache()
    factCache.__delitem__(None)
    assert True

# Generated at 2022-06-21 09:29:23.702675
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert(cache)



# Generated at 2022-06-21 09:29:38.993099
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():

    from copy import copy
    from unittest import TestCase, main
    from ansible.plugins.cache.jsonfile import CacheModule as _CacheModule

    class CacheModule(_CacheModule):

        def flush(self):
            pass
        def get(self, key):
            pass
        def set(self, key, value):
            pass
        def contains(self, key):
            pass
        def delete(self, key):
            pass
        def keys(self):
            return copy(list(self._cache))
        def get_metadata(self, key):
            return {}
        def set_metadata(self, key, data):
            pass

    class TestFactCache(TestCase):

        def setUp(self):
            self.subject = FactCache()


# Generated at 2022-06-21 09:29:44.632277
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    from ansible.module_utils.hashivault import HASHI_VAULT_CACHE_FILE

    if HASHI_VAULT_CACHE_FILE is None:
        display.display('HASHI_VAULT_CACHE_FILE not defined')
    else:
        fact_cache = FactCache()
        for hostname in fact_cache.keys():
            display.display('%s: %s' % (hostname, fact_cache[hostname]))



# Generated at 2022-06-21 09:29:50.835010
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    host_facts1 = {'fact1': 'value1', 'fact2': 'value2'}

    fc.first_order_merge('localhost1', host_facts1)
    assert fc['localhost1'] == host_facts1
    host_facts2 = {'fact1': 'value1-1', 'fact2': 'value2-1'}

    fc.first_order_merge('localhost1', host_facts2)
    assert fc['localhost1'] == {'fact1': 'value1-1', 'fact2': 'value2-1'}

# Generated at 2022-06-21 09:29:53.689896
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    my_FactCache = FactCache()
    assert(my_FactCache['test'] == None)
    assert('test' in my_FactCache)


# Generated at 2022-06-21 09:29:59.464485
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    facts = FactCache()
    # check if facts is instance of FactCache
    assert isinstance(facts, FactCache)
    # check if facts does not contain any keys
    assert facts.keys() == []
    # insert a key value
    facts['key1'] = {'name': 'John'}
    # check if facts contains key
    assert facts.keys() == ['key1']
    # remove the key value
    del facts['key1']
    # check if facts does not contain any keys
    assert facts.keys() == []


# Generated at 2022-06-21 09:30:05.432189
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fixture = FactCache()
    fixture.keys = ['key1', 'key2']

    result = next(iter(fixture))
    assert result == 'key1'
    result = next(iter(fixture))
    assert result == 'key2'
    with pytest.raises(StopIteration):
        result = next(iter(fixture))


# Generated at 2022-06-21 09:30:13.986782
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    host_cache = cache_loader.get(C.CACHE_PLUGIN)
    host_cache.set('localhost', {'foo': {'bar': 'baz'}})
    host_cache.set('localhost', {'foo': {'baz': 'foo'}})
    host_cache.set('localhost', {'foo': {'bar': 'baz'}})
    expected = {'foo': {'bar': 'baz', 'baz': 'foo'}}
    actual = host_cache.get('localhost')
    assert actual == expected

# Generated at 2022-06-21 09:30:14.869926
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    cache = FactCache()
    assert cache['key'] == None


# Generated at 2022-06-21 09:30:16.504477
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    cache = FactCache()

    assert len(cache) == 0


# Generated at 2022-06-21 09:30:23.160977
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fact_cache = FactCache()
    fact_cache.__setitem__('key1', 'value1')
    fact_cache.__setitem__('key2', 'value2')
    fact_cache.__setitem__('key3', 'value3')
    results = [i for i in fact_cache.__iter__()]
    assert results == ['key1', 'key2', 'key3']



# Generated at 2022-06-21 09:30:31.277289
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    cache = FactCache()
    # NOTE: this is just a stub, we do not have a valid cache plugin,
    # so this method always return True.
    assert(cache.__contains__('stubby_key') == True)


# Generated at 2022-06-21 09:30:41.084926
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    import json
    import pytest
    from mock import patch

    keys_return_value = ['10.0.0.1', '10.0.0.2']

    with patch('ansible.plugins.cache.jsonfile.CacheModule.keys', return_value=keys_return_value):
        fact_cache = FactCache()
        fact_cache['10.0.0.1'] = 'host1'
        fact_cache['10.0.0.2'] = 'host2'
        result = fact_cache.copy()
    assert result == {'10.0.0.1': 'host1', '10.0.0.2': 'host2'}



# Generated at 2022-06-21 09:30:44.833250
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    facts_cache = FactCache()

    facts_cache["ABC"] = "ABC_VALUE"
    assert('ABC' in facts_cache.keys())
    facts_cache.__delitem__("ABC")
    assert('ABC' not in facts_cache.keys())

# Generated at 2022-06-21 09:30:48.493716
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fact_cache = FactCache()
    # Test for non existent key
    try:
        fact_cache['test_key']
        assert False
    except KeyError:
        assert True
    else:
        assert True


# Generated at 2022-06-21 09:30:51.148788
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    try:
        fc = FactCache()
        fc[0] = 0
    except Exception:
        raise Exception('FactCache.__setitem__() raised Exception unexpectedly!')
    else:
        pass


# Generated at 2022-06-21 09:30:58.578735
# Unit test for method flush of class FactCache
def test_FactCache_flush():

    class FakePlugin(object):
        def __getattr__(self, name):
            def _noop(*args, **kwargs):
                pass
            return _noop

    class FakeCache(FactCache):
        def __init__(self):
            self._value = {'test': 'data'}
            self._plugin = FakePlugin()
        def copy(self):
            return self._value

    cache = FakeCache()

    cache.flush()
    assert len(cache) == 0

# Generated at 2022-06-21 09:31:03.032912
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    host_facts = {'host_1': {'ansible_distribution': 'Ubuntu'}}
    host_cache = FactCache(host_facts)
    host_cache.__delitem__('host_1')
    assert 'host_1' not in host_cache



# Generated at 2022-06-21 09:31:14.639369
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    from ansible.plugins.cache import FactCache
    from ansible.plugins.cache.fact_cache import FactCachePlugin
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.errors import AnsibleError
    from ansible.module_utils.common.json_utils import _json
    fcp = FactCachePlugin()
    f = FactCache()
    assert type(f) == FactCache
    assert issubclass(FactCache, MutableMapping)
    with pytest.raises(AnsibleError):
        f._plugin = None
        assert f['host']
    assert f._plugin is not None
    assert f['host'] == fcp.get('host')
    fcp._data = None
    assert f['host'] == fcp.get('host')
    fcp

# Generated at 2022-06-21 09:31:16.564811
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fact_cache = FactCache({'arun': 'arun_v'})
    assert list(fact_cache) == ['arun']


# Generated at 2022-06-21 09:31:21.965597
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    from ansible.utils.display import Display
    from ansible.vars.hostvars import HostVars

    display = Display()
    a = HostVars()
    b = dict()
    c = {"3": 33, "4": 44}

    a.update(b)
    a.update(c)
    d = FactCache()
    d.set('test__iter__key1', a)
    assert dict(d) == dict(c)



# Generated at 2022-06-21 09:31:46.176988
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc.first_order_merge(key='key_a', value={'value_a': 'value_a'})
    assert fc.keys() == ['key_a']
    assert fc.first_order_merge(key='key_b', value={'value_b': 'value_b'}) == {'key_a': {'value_a': 'value_a'},
                                                                                'key_b': {'value_b': 'value_b'}}

# Generated at 2022-06-21 09:31:48.260049
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    c = FactCache()
    assert c._plugin.contains('hostname')
    assert c.keys() == c._plugin.keys()

# Generated at 2022-06-21 09:31:49.241978
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():

    assert False, "Not yet implemented"



# Generated at 2022-06-21 09:31:52.726006
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    from collections import Iterable
    obj = FactCache()
    assert isinstance(obj.keys(), Iterable)
    assert "a" in obj.keys()


# Generated at 2022-06-21 09:31:55.332730
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    obj = FactCache()
    # TODO: make this stuff work
    # assert obj.__contains__('foo') == False

# Generated at 2022-06-21 09:31:57.554902
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert isinstance(fc, FactCache)


# Generated at 2022-06-21 09:31:58.980297
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-21 09:32:01.859046
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    """
    Tests for `FactCache.__delitem__` method.
    """
    facts_cache = FactCache()
    test_key = 'test_key'
    test_value = {"test_key": "test_value"}

    facts_cache[test_key] = test_value
    facts_cache.__delitem__(test_key)
    assert test_key not in facts_cache



# Generated at 2022-06-21 09:32:05.052712
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fc1 = FactCache()
    fc1.__setitem__('1', 1)
    assert fc1.__getitem__('1') == 1


# Generated at 2022-06-21 09:32:09.476172
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    cache = FactCache()
    # Case 1: Key 'hostname' is not present, then method __getitem__ of class FactCache should raise KeyError
    try:
        cache.__getitem__('hostname')
    except KeyError:
        pass
    # Case 2: Key 'hostname' is present, then method __getitem__ of class FactCache should return corresponding value
    cache['hostname'] = 'test'
    assert cache.__getitem__('hostname') == 'test'


# Generated at 2022-06-21 09:32:38.160324
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fc = FactCache()
    assert 'ansible_fqdn' not in fc


# Generated at 2022-06-21 09:32:41.303136
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    cache = FactCache(object)
    cache.set('123', {'test': 'passed'})
    assert cache.get('123') == {'test': 'passed'}


# Generated at 2022-06-21 09:32:42.771173
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    a = FactCache()
    a.___len__()

# Generated at 2022-06-21 09:32:43.605387
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    assert True

# Generated at 2022-06-21 09:32:46.220663
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    i=0
    for key,value in C.DEFAULT_CACHE_PLUGIN_CONNECTION.items():
        i+=1

    assert len(FactCache()) == i

# Generated at 2022-06-21 09:32:51.389237
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    test_hostname = 'host1'
    test_facts = {'ansible_net_hostname': test_hostname}

    test_cache = FactCache()
    test_cache.first_order_merge(test_hostname, test_facts)

    assert test_cache[test_hostname] == test_facts


# Generated at 2022-06-21 09:32:56.293452
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    fact_cache['host'] = {'key1': 'value1'}
    len(fact_cache) == 1
    fact_cache.flush()
    len(fact_cache) == 0


# Generated at 2022-06-21 09:32:57.817286
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    cache = FactCache()
    cache.__len__()


# Generated at 2022-06-21 09:33:00.811893
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    cache = FactCache()
    assert cache.copy() == {}
    cache['key'] = 'value'
    assert cache.copy() == {'key': 'value'}

# Generated at 2022-06-21 09:33:02.874573
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fac = FactCache()
    assert not fac.__contains__("a")


# Generated at 2022-06-21 09:34:01.270518
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fact = FactCache()
    fact.__setitem__("name", "age")
    assert fact.__getitem__("name") == "age"


# Generated at 2022-06-21 09:34:06.876151
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    cache_plugin = cache_loader.get(C.CACHE_PLUGIN)
    cache_plugin.set('key_test_keys', 'value_test_keys')
    factcache = FactCache(cache_plugin)
    factcache.keys()
    cache_plugin.flush()



# Generated at 2022-06-21 09:34:16.664802
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fact_cache = FactCache()
    # key -> string, value -> string
    key = 'key'
    value = 'value'
    fact_cache.__setitem__(key, value)
    fact_cache.__contains__(key)
    # key -> integer, value -> string
    key = 1
    fact_cache.__setitem__(key, value)
    fact_cache.__contains__(key)
    # key -> string, value -> list
    key = 'key1'
    value = ['val1', 'val2']
    fact_cache.__setitem__(key, value)
    fact_cache.__contains__(key)


# Generated at 2022-06-21 09:34:23.084712
# Unit test for method __setitem__ of class FactCache

# Generated at 2022-06-21 09:34:24.083956
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()

# Generated at 2022-06-21 09:34:34.821239
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Test empty cache
    fc = FactCache()
    fc.flush()
    assert len(fc) == 0

    # Test with empty values
    res = fc.first_order_merge('key', {})
    assert len(fc) == 0

    # Test with one value
    res = fc.first_order_merge('key', {'fact1': 'value1'})
    assert len(fc) == 1
    assert fc['key'] == {'fact1': 'value1'}

    # Test with another value for the same key
    fc.first_order_merge('key', {'fact2': 'value2'})
    assert len(fc) == 1
    assert fc['key'] == {'fact1': 'value1', 'fact2': 'value2'}

    # Test

# Generated at 2022-06-21 09:34:47.862017
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    """
    Unit test to check the host facts merge happens in the desired order
     - host facts comes first
     - cache value will be updated with host facts
     - finally the cache will be updated with host facts with the updated value
    """
    facts_cache = {}
    # test when host facts comes first
    test_key = "test_key"
    test_value = {"test_key_1": "test_value_1"}
    test_facts_cache = FactCache()
    test_facts_cache.first_order_merge(test_key, test_value)
    facts_cache.update({test_key: test_value})
    assert test_facts_cache.copy() == facts_cache
    # test when host facts comes first and cache value gets updated

# Generated at 2022-06-21 09:34:59.795620
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    from ansible.plugins.cache import BaseFileCacheModule
    from ansible.plugins.loader import cache_loader

    with open('/tmp/mock', 'w') as f:
        f.write('')

    cache_loader._settings = {'/tmp/mock': {}}
    cache_loader._settings['/tmp/mock']['path'] = '/tmp/mock'
    cache_loader._settings['/tmp/mock']['plugin'] = 'BaseFileCacheModule'

    cache_loader._loaded_plugins = {}
    cache_loader._plugins = {}
    cache_loader._plugins['/tmp/mock'] = BaseFileCacheModule
    cache_loader._load_plugin(plugin_type='cache', plugin_name='/tmp/mock')


# Generated at 2022-06-21 09:35:07.119268
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Test when key is not in the cache
    fc = FactCache()
    assert len(fc) == 0
    fc.first_order_merge('localhost', {'test_fact': 'fact_value'})
    assert len(fc) == 1
    assert fc['localhost']['test_fact'] == 'fact_value'

    # Test when key is in the cache
    fc.first_order_merge('localhost', {'test_fact': 'fact_value_new', 'test_fact_2': 'fact_value_2'})
    assert len(fc) == 1
    assert fc['localhost']['test_fact'] == 'fact_value_new'
    assert len(fc['localhost']) == 2

    # Test when key is invalid

# Generated at 2022-06-21 09:35:11.671210
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    c = FactCache()
    cache_content = {}
    for key in c:
        cache_content[key] = c[key]
    assert cache_content == {}, "%r != {}" % cache_content
