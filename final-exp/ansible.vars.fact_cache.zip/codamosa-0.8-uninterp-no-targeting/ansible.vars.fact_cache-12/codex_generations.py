

# Generated at 2022-06-21 09:27:13.819861
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = FactCache()
    fact_cache["foo"] = "bar"
    key = "foo"
    assert fact_cache[key] == "bar"


# Generated at 2022-06-21 09:27:15.633316
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    obj = FactCache()
    #delitem__ is not implemented
    with pytest.raises(NotImplementedError):
        obj.__delitem__()

# Generated at 2022-06-21 09:27:16.661236
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fact_cache = FactCache()
    display.display("Calling __iter__")
    fact_cache.__iter__()


# Generated at 2022-06-21 09:27:18.370112
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    facts = FactCache()
    # TODO: Add to verify flush() method
    facts.flush()

# Generated at 2022-06-21 09:27:19.858564
# Unit test for constructor of class FactCache
def test_FactCache():
    import pytest
    with pytest.raises(AnsibleError):
        assert FactCache()

# Generated at 2022-06-21 09:27:27.228648
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc.first_order_merge('localhost', {'new_fact': 'new_value'})
    assert fc['localhost'] == {'new_fact': 'new_value'}
    fc.first_order_merge('localhost', {'new_fact': 'newer_value'})
    assert fc['localhost'] == {'new_fact': 'new_value', 'new_fact1': 'newer_value'}

# Generated at 2022-06-21 09:27:28.737440
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    assert callable(FactCache.__contains__)


# Generated at 2022-06-21 09:27:35.440462
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    from ansible.module_utils.facts import cache as fact_cache
    test_cache = fact_cache.FactCache()
    test_cache['test_key1'] = 1
    test_cache['test_key2'] = 2
    test_cache['test_key3'] = 3
    assert sorted(test_cache.keys()) == ['test_key1', 'test_key2', 'test_key3'], "All keys should be retrieved with method keys"


# Generated at 2022-06-21 09:27:43.102300
# Unit test for method first_order_merge of class FactCache

# Generated at 2022-06-21 09:27:49.603674
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    cache = FactCache()
    cache['test_getitem'] = 'test_getitem_value'
    assert cache['test_getitem'] == 'test_getitem_value'
    try:
        cache['test_null']
    except KeyError:
        pass
    else:
        raise Exception("Exception should be raised to find non-existing key")


# Generated at 2022-06-21 09:28:00.656831
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    fact_cache.flush()

    fact_cache['test1'] = 'value1'
    assert fact_cache['test1'] == 'value1'

    fact_cache['test2'] = 'value2'
    assert fact_cache['test2'] == 'value2'

    del fact_cache['test1']
    assert 'test1' not in fact_cache

    fact_cache.flush()
    assert 'test2' not in fact_cache


if __name__ == '__main__':
    test_FactCache()

# Generated at 2022-06-21 09:28:06.054218
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc.first_order_merge("test_key",{"a": 1, "b": 2})
    assert fc["test_key"] == {"a": 1, "b": 2}

    fc.first_order_merge("test_key",{"a": 3, "c": 4})
    assert fc["test_key"] == {"a": 3, "b": 2, "c": 4}

    fc.first_order_merge("test_key",{"a": "a", "b": "b"})
    assert fc["test_key"] == {"a": "a", "b": "b", "c": 4}

# Generated at 2022-06-21 09:28:09.240627
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    d = dict()
    f = FactCache(d)
    f['k'] = 'v'
    assert f.copy() == {'k': 'v'}
    

# Generated at 2022-06-21 09:28:10.753658
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = FactCache()
    fact_cache['key']='value'

# Generated at 2022-06-21 09:28:15.036186
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():

    fact_cache = FactCache()

    assert len(fact_cache.keys()) == 0

    fact_cache['test_key'] = 'test_value'

    assert len(fact_cache.keys()) == 1

    del fact_cache['test_key']

    assert len(fact_cache.keys()) == 0


# Generated at 2022-06-21 09:28:18.976342
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fc = FactCache()
    fc['a'] = 1
    fc['b'] = 2
    fc['c'] = 3
    assert set(fc.keys()) == set(['a', 'b', 'c'])

# Generated at 2022-06-21 09:28:27.488373
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    cache.first_order_merge('foo', {'a': 1, 'b': 2})
    cache.first_order_merge('foo', {'b': 3})
    assert cache['foo'] == {'a': 1, 'b': 3}
    # we need to clear the cache before running the next test
    cache.flush()
    assert cache.keys() == []
    cache.first_order_merge('bar', {'c': 4, 'd': 5})
    cache.first_order_merge('bar', {'d': 6})
    assert cache['bar'] == {'c': 4, 'd': 6}

# Generated at 2022-06-21 09:28:30.747079
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fc = FactCache()
    fc['test_key'] = 'test_value'
    assert fc['test_key'] == 'test_value'
    try:
        fc['test_key_1']
        assert True == False
    except KeyError:
        assert True == True


# Generated at 2022-06-21 09:28:37.633107
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    '''
    Unit test for FactCache class
    :return:
    '''
    # Create new instance of FactCache Class
    fact_cache = FactCache()
    # Test first_order_merge method with invalid input
    test_1 = fact_cache.first_order_merge(key=None, value=None)
    assert test_1 is None


if __name__ == "__main__":
    test_FactCache_first_order_merge()

# Generated at 2022-06-21 09:28:38.578178
# Unit test for constructor of class FactCache
def test_FactCache():
    f = FactCache()
    assert f is not None

# Generated at 2022-06-21 09:28:53.104972
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():

    temp_plugin = MockPlugin()
    mock_plugin_container = {C.CACHE_PLUGIN: temp_plugin}
    fake_cache_loader = MockLoader(mock_plugin_container)

    FakeFactCache.initialize(fake_cache_loader)

    temp_plugin.set_return_value = True

    host_cache = FakeFactCache()

    host_cache["inventory_hostname"] = "localhost"
    host_cache["inventory_hostname"] = "localhost"

    assert temp_plugin.call_count == 2
    assert temp_plugin.data["inventory_hostname"] == "localhost"



# Generated at 2022-06-21 09:29:01.129246
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    class cache_plugin:
        def delete(key):
            key_list.append(key)

    key_list = []
    fact_cache = FactCache(plugin=cache_plugin)
    fact_cache["key1"] = "value1"
    fact_cache["key2"] = "value2"
    del fact_cache["key2"]

    assert key_list == ["key2"]
    assert "key1" in fact_cache
    assert "key2" not in fact_cache

# Generated at 2022-06-21 09:29:05.244621
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc
    fc.__setitem__('key1', 'value1')
    assert fc.__getitem__('key1') == 'value1'
    fc.copy()
    fc.flush()

# Generated at 2022-06-21 09:29:12.725677
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    plugin = cache_loader.get(C.CACHE_PLUGIN)
    if not plugin:
        raise AnsibleError('Unable to load the facts cache plugin (%s).' % (C.CACHE_PLUGIN))

    fact_cache = FactCache()
    if fact_cache.__contains__('foo'):
        raise AssertionError
    assert fact_cache.__contains__('foo') == False

    plugin.set('foo', 'bar')
    if not fact_cache.__contains__('foo'):
        raise AssertionError
    assert fact_cache.__contains__('foo') == True


# Generated at 2022-06-21 09:29:17.840397
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():

    # setup
    cache = FactCache()
    cache['key'] = 'value'
    cache['key2'] = 'value'

    # test
    del cache['key']

    # assert
    assert 'key' not in cache
    assert 'key2' in cache


# Generated at 2022-06-21 09:29:20.407708
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    a = FactCache()
    assert len(a) == 0
    a['1'] = 1
    assert len(a) == 1


# Generated at 2022-06-21 09:29:23.661224
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    cache = FactCache()
    assert not cache.__contains__("test")
    cache._plugin.set("test", "1")
    assert cache.__contains__("test")


# Generated at 2022-06-21 09:29:30.154575
# Unit test for constructor of class FactCache
def test_FactCache():
    '''
    Tests the FactCache constructor
    '''
    assert 'FactCache' not in globals(), 'FactCache overwrote existing global'
    try:
        global FactCache
        # Construct FactCache object
        FactCache = FactCache()
    finally:
        # Restore local namespace
        del FactCache



# Generated at 2022-06-21 09:29:31.378648
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    assert 1 == 1


# Generated at 2022-06-21 09:29:42.317004
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
  fc = FactCache()
  test_key = 'localhost'
  test_facts = {'fact1' : 'value1', 'fact2' : 'value2', 'fact3' : 'value3' }
  fc.first_order_merge(test_key, test_facts)

  try:
    host_facts = fc[test_key]
  except KeyError:
    host_facts = None
  assert test_facts == host_facts, \
    'Merge not successful: expected: %s  actual: %s' % ( test_facts, host_facts )

  new_facts = {'fact2' : 'new_value2', 'fact4' : 'value4', 'fact5' :'value5' }
  fc.first_order_merge(test_key, new_facts)


# Generated at 2022-06-21 09:29:57.494311
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    """ Test of correct copy of the keys and values from the cache. """
    cache = FactCache()
    cache['host1'] = {'fact1': 'value1', 'fact2': 'value2'}
    cache['host2'] = {'fact3': 'value3', 'fact4': 'value4'}

    assert len(cache) == 2
    assert cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}
    assert cache['host2'] == {'fact3': 'value3', 'fact4': 'value4'}
    assert len(cache.copy()) == 2

# Generated at 2022-06-21 09:30:05.224056
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    test_fact_cache = FactCache()
    test_fact_cache.__setitem__('key1', 'value1')
    test_fact_cache.__setitem__('key2', 'value2')
    test_copy = test_fact_cache.copy()
    assert isinstance(test_copy, dict)
    assert test_copy['key1'] == 'value1'
    assert test_copy['key2'] == 'value2'


# Generated at 2022-06-21 09:30:11.139663
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    display.verbosity = 3
    my_host_cache = FactCache()
    my_host_cache['ansible_network_os'] = "test1"
    my_host_cache['ansible_network_os'] = "test2"
    my_host_cache['ansible_network_os'] = "test3"
    my_host_cache.flush()

    assert 'ansible_network_os' in my_host_cache.keys()

# Generated at 2022-06-21 09:30:17.241009
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    f = FactCache()
    if 'ansible_eth0' in f:
        del f['ansible_eth0']
    if 'ansible_eth0' in f:
        f['ansible_eth0'] = '10.20.0.0'
    assert f['ansible_eth0'] == '10.20.0.0'

# Generated at 2022-06-21 09:30:26.630432
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    # create a fact cache object to use in the tests
    fact_cache = FactCache()
    fact_cache.flush()

    # tests for the case where the cache is empty
    value = dict(test_fact="test_value")
    fact_cache.first_order_merge("localhost", value)
    result = fact_cache.copy()
    assert result == {'localhost': {'test_fact': 'test_value'}}

    # test an update to the fact cache
    fact_cache.first_order_merge("localhost", dict(test_fact="updated_value"))
    result = fact_cache.copy()
    assert result == {'localhost': {'test_fact': 'updated_value'}}

# Generated at 2022-06-21 09:30:29.297330
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    key = 'localhost'
    fact_cache[key] = {}
    assert fact_cache[key] == {}
    del fact_cache[key]
    assert key not in fact_cache
    fact_cache.flush()

# Generated at 2022-06-21 09:30:30.627728
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache._plugin is not None


# Generated at 2022-06-21 09:30:31.743601
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert isinstance(fc, FactCache)

# Generated at 2022-06-21 09:30:32.221359
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    pass

# Generated at 2022-06-21 09:30:38.539221
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    class cache_plugin:
        def __init__(self):
            self.facts = {'facts': {'facts': 'test'}}

        def contains(self, key):
            return key in self.facts

        def keys(self):
            return self.facts.keys()

    c = FactCache()
    c._plugin = cache_plugin()
    assert len(c) == 1


# Generated at 2022-06-21 09:30:53.897402
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-21 09:30:57.882236
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fcache = FactCache()
    assert len(fcache) == 0
    fcache['a'] = 1
    assert len(fcache) == 1
    del fcache['a']
    assert len(fcache) == 0


# Generated at 2022-06-21 09:31:03.873506
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('hostvars', {'new': '1', 'existing': '1'})
    fact_cache.first_order_merge('hostvars', {'new': '2', 'existing': '2'})
    assert fact_cache['hostvars'] == {'new': '2', 'existing': '2'}

# Generated at 2022-06-21 09:31:05.803835
# Unit test for constructor of class FactCache
def test_FactCache():  # noqa
    fc = FactCache()
    assert not fc

# Generated at 2022-06-21 09:31:07.951413
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    assert fact_cache._plugin
    fact_cache.flush()

# Generated at 2022-06-21 09:31:13.260633
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    host_cache = {'fact_cache': None}
    key = 'host_cache'
    host_cache[key] = FactCache()
    cache = host_cache[key]

    fact_value = 'dummy_fact_value'
    cache.setdefault('fact_1', fact_value)

    assert 'fact_1' in cache
    assert 'fact_2' not in cache

# Generated at 2022-06-21 09:31:17.581425
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    cache = FactCache()
    cache[u'bob'] = u'the builder'
    cache[u'alice'] = u'in wonderland'
    new_copy = cache.copy()
    assert new_copy['alice'] == 'in wonderland'
    assert new_copy['bob'] == 'the builder'
    assert len(new_copy) == 2


# Generated at 2022-06-21 09:31:19.548604
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fact_cache = FactCache()
    assert 'test' not in fact_cache
    fact_cache['test'] = 'test'
    assert 'test' in fact_cache


# Generated at 2022-06-21 09:31:20.845520
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache(C.cache_dir)
    assert len(fact_cache) == 0

# Generated at 2022-06-21 09:31:22.746107
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fc = FactCache()
    keys = []
    for item in fc:
        keys.append(item)
    assert set(keys) == set(['localhost'])


# Generated at 2022-06-21 09:32:01.558871
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache(
        {
            'localhost': {'ansible_architecture': u'x86_64'},
            '127.0.0.1': {u'ansible_distribution': u'Darwin', u'ansible_distribution_version': u'17.6.0', u'ansible_os_family': u'Darwin', u'ansible_system': u'Darwin'}
        }
    )
    assert fc['localhost']['ansible_architecture'] == 'x86_64'
    assert fc['127.0.0.1']['ansible_distribution'] == 'Darwin'

# Generated at 2022-06-21 09:32:06.560278
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fc = FactCache()
    fc['a'] = 1
    fc['b'] = 2
    fc['c'] = 3
    fc['d'] = 4
    test_iter = iter(fc)
    counter = 0
    while True:
        try:
            key = next(test_iter)
            assert key in fc
            counter += 1
        except StopIteration:
            break
    assert counter == len(fc)



# Generated at 2022-06-21 09:32:16.359156
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    import os
    import shutil
    from ansible.errors import AnsibleError

    from ansible.plugins.loader import cache_loader
    from ansible.utils.display import Display

    display = Display()
    # create a cache
    cache_dir_path = 'cache_dir'
    os.mkdir(cache_dir_path)
    CACHE_PLUGIN = 'jsonfile'
    CACHE_PLUGIN_CONNECTION = cache_dir_path

    cache_plugin = cache_loader.get(CACHE_PLUGIN)
    if not cache_plugin:
        raise AnsibleError('Unable to load the facts cache plugin (%s).' % (CACHE_PLUGIN))

    # create a fact_cache
    key = 'test_key'
    value = 'test_value'

   

# Generated at 2022-06-21 09:32:18.687005
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    display.DEBUG("Test the method exists")
    fact = FactCache()
    fact['somekey'] = 'somevalue'
    assert 'somekey' in fact
    assert 'somekey2' not in fact


# Generated at 2022-06-21 09:32:21.918860
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    factcache = FactCache()
    factcache['1'] = '1'
    factcache['2'] = '2'

    assert(list(factcache)) == ['1', '2']


# Generated at 2022-06-21 09:32:25.729515
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    # Initialize FactCache class
    factcache = FactCache()

    # Check the function is iterating on _plugin.keys()
    assert factcache.__iter__() == factcache._plugin.keys()



# Generated at 2022-06-21 09:32:32.202925
# Unit test for constructor of class FactCache
def test_FactCache():
    C._CACHE_PLUGIN = 'memory'
    import ansible.plugins.cache.memory as mem

    from ansible.plugins.cache.memory import CacheModule as mem_cache

    mem_obj = mem_cache()
    assert isinstance(mem_obj, mem_cache)
    fac_obj = FactCache()
    assert isinstance(fac_obj, FactCache)

# Generated at 2022-06-21 09:32:36.153721
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    from ansible.plugins.cache import jsonfile  # pylint: disable=unused-variable

    cache = FactCache()
    cache["test"] = "test"
    cache["test"] = "test1"

    for key in cache:
        assert key in ["test"]



# Generated at 2022-06-21 09:32:38.769078
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    cache = {}
    plugin = FactCache(cache)
    plugin['test'] = 'test'
    assert 'test' in plugin


# Generated at 2022-06-21 09:32:45.040272
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    assert len(fact_cache) == 0
    assert len(fact_cache) == fact_cache.__len__()
    fact_cache['hostname'] = 'localhost.localdomain'
    fact_cache['ansible_processor_count'] = 2
    assert len(fact_cache) == 2
    assert len(fact_cache) == fact_cache.__len__()


# Generated at 2022-06-21 09:33:47.481767
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    result = FactCache()
    assert len(result) == 0


# Generated at 2022-06-21 09:33:52.076202
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    facts_dict = {'ansible_distribution': 'CentOS'}
    fact_cache = FactCache()
    fact_cache['localhost'] = facts_dict
    assert fact_cache.get('localhost') == fact_cache.copy().get('localhost')
    fact_cache.flush()

# Generated at 2022-06-21 09:33:53.079620
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    pass


# Generated at 2022-06-21 09:33:55.545713
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    assert fact_cache
    assert list(fact_cache.keys()) == []


# Generated at 2022-06-21 09:34:01.100711
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    # Test
    fact_cache = FactCache()
    fact_cache.__setitem__('key1', 'value1')
    fact_cache.__setitem__('key2', 'value2')
    copy = fact_cache.copy()
    # Assert
    assert copy == {'key1': 'value1', 'key2': 'value2'}

# Generated at 2022-06-21 09:34:09.756315
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    try:
        fc = FactCache()
        fc['test_FactCache_flush1'] = 'test_FactCache_flush1'
        fc['test_FactCache_flush2'] = 'test_FactCache_flush2'
        fc['test_FactCache_flush3'] = 'test_FactCache_flush3'
        fc.flush()
    except Exception as e:
        assert False, "test_FactCache_flush failed with '%s'" % e
    else:
        assert True

# Generated at 2022-06-21 09:34:13.843591
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    # create a fact cache
    fact_cache = FactCache()
    # add a fact
    key = 'some random fact'
    fact_cache[key] = {'some': 'thing'}
    # test __contains__
    assert key in fact_cache

# Generated at 2022-06-21 09:34:17.422971
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    test_fact_cache = FactCache()
    test_fact_cache["test"] = 0
    assert len(list(test_fact_cache.keys())) == 1
    assert list(test_fact_cache.keys())[0] == "test"

# Generated at 2022-06-21 09:34:20.306937
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    factcache = FactCache()
    factcache.flush()
    assert factcache.copy() == {}
    assert factcache.keys() == []


# Generated at 2022-06-21 09:34:23.798902
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    c1 = FactCache()
    c1['key1'] = 'value1'
    assert 'key1' in c1
    c1.__delitem__('key1')
    assert 'key1' not in c1


# Generated at 2022-06-21 09:36:32.292932
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fact_cache = FactCache()


# Generated at 2022-06-21 09:36:34.122106
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    kw = dict(foo = 'bar')
    fc = FactCache(**kw)
    fc.flush()
    assert len(fc) == 0

# Generated at 2022-06-21 09:36:41.089975
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():

    cache = FactCache()

    def test_contains(key, value, contained):
        cache['test_key'] = value
        assert (key in cache) == contained

    test_contains('test_key', 'value', True)
    test_contains('other_key', 'value', False)
    test_contains('test_key', None, False)  # None values are not supported, similar to a normal dict



# Generated at 2022-06-21 09:36:47.326288
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    obj = cache_loader.get('yaml')
    f = FactCache()
    f._plugin = obj
    obj.delete('test_key')
    obj.delete('test_key_1')
    obj.delete('test_key_2')
    obj.set('test_key', 'test')
    obj.set('test_key_1', 'test_1')
    obj.set('test_key_2', 'test_2')
    assert len(f) == 3
 # Unit test for method copy of class FactCache

# Generated at 2022-06-21 09:36:49.135629
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    cache = FactCache()
    cache['key'] = 5
    assert 'key' in cache.keys()
    assert 'key' in cache
    cache.flush()


# Generated at 2022-06-21 09:36:53.411698
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
        cache = {
            'host1': {
                'ansible_kernel': '4.4.0',
                'ansible_uptime_seconds': '251821',
            },
            'host2': {
                'ansible_kernel': '4.4.0',
                'ansible_uptime_seconds': '251821',
            }
        }
        fact_cache = FactCache()
        fact_cache._plugin = FakeCache(cache)
        assert len(fact_cache) == 2


# Generated at 2022-06-21 09:37:01.188786
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    # verify that __delitem__ return None and successfully deleted the key
    host_cache = FactCache()
    host_cache['172.16.1.1'] = '10.0.0.2'
    assert host_cache['172.16.1.1'] == '10.0.0.2'
    host_cache.__delitem__('172.16.1.1')
    assert host_cache['172.16.1.1'] == None

# Generated at 2022-06-21 09:37:07.571667
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    data = {
        "foo":{
            "bar": "test"
        },
        "qux": "test2"
    }

    cache = FactCache()
    cache.update(data)

    new_data = {
        "foo":{
            "bar": "test",
            "baz": "new"
        },
        "qux": "test2"
    }

    cache.first_order_merge("foo", new_data["foo"])

    result = cache.copy()
    assert result == new_data