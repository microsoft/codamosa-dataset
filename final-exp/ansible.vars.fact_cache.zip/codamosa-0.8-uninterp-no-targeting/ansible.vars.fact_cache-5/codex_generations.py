

# Generated at 2022-06-21 09:27:15.666191
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    # Testing fact cache plugin usage (trivial)
    from ansible.errors import AnsibleError
    from ansible.plugins.loader import cache_loader

    display = Display()
    fact_cache = FactCache()
    key = 'foo'
    value = 'bar'
    fact_cache[key] = value
    assert key in fact_cache
    assert fact_cache[key] == value

# Generated at 2022-06-21 09:27:20.137971
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():

    class FakePlugin():
        def __init__(self, *args, **kwargs):
            self.keys = ['key1', 'key2', 'key3']
        def keys(self):
            return self.keys

    fact_cache = FactCache()
    fact_cache._plugin = FakePlugin()
    fact_cache.keys()

    assert iter(fact_cache) == iter(fact_cache.keys())

# Generated at 2022-06-21 09:27:22.439276
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache._plugin
    assert cache._plugin.__class__.__name__ == 'FactCacheData'

# Generated at 2022-06-21 09:27:34.375390
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    assert len(cache) == 0
    host_cache = {'host_cache': 'host_cache_val'}
    cache.update(host_cache)
    assert len(cache) == 1
    host_facts = {'host_facts': 'host_facts_val'}
    cache.first_order_merge('host_facts',host_facts)
    assert cache['host_facts'] == {'host_facts': 'host_facts_val'}
    cache.first_order_merge('host_facts',host_facts)
    assert cache['host_facts'] == {'host_facts': 'host_facts_val', 'host_cache': 'host_cache_val'}
    assert len(cache) == 2
    #del cache['host_facts']
    #assert len(cache)

# Generated at 2022-06-21 09:27:38.395380
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    import pytest
    my_cache = FactCache("localhost")
    my_cache["localhost"] = {"ansible_facts": {"test_fact" : "bar"}}
    assert my_cache["localhost"]["ansible_facts"]["test_fact"] == "bar"


# Generated at 2022-06-21 09:27:41.167209
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    factcache = FactCache()
    factcache['thekey'] = 'thevalue'
    factcache.flush()
    result = bool(factcache)
    assert result == False


# Generated at 2022-06-21 09:27:46.521413
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    cache = FactCache()
    cache.flush = lambda : None
    cache.keys = lambda : ["1", "2", "3"]
    cache.__contains__ = lambda x : True
    cache.__getitem__ = lambda x, y : x

    for key in cache.keys():
        assert key == cache[key]

# Generated at 2022-06-21 09:27:50.715793
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache1=FactCache("test1","test2")
    fact_cache2=FactCache("test1","test2")
    if(fact_cache1 is fact_cache2):
        raise AssertionError("Test Failed")

# Generated at 2022-06-21 09:27:53.083563
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fc = FactCache()
    fc['key'] = 'value'
    assert fc.copy() == fc.keys()

# Generated at 2022-06-21 09:28:02.765967
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    import os
    import tempfile

    from ansible.config.manager import ConfigManager
    from ansible.utils.display import Display
    from ansible.utils.os import pkexec_run

    display = Display()
    cfg = ConfigManager(display)._read_config_data(filename='/dev/null')
    cfg.caching = True
    cfg.cache_plugin = 'jsonfile'

    with tempfile.NamedTemporaryFile() as tf:
        cache_filepath = os.path.join(tf.name, 'test_cache.json')
        os.mkdir(tf.name)
        pkexec_run(['touch', cache_filepath])

    cache = FactCache(cfg, cache_filepath)

# Generated at 2022-06-21 09:28:13.602411
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()

    # Test with one item
    fc.first_order_merge('first', 1)
    assert fc['first'] == 1
    fc.flush()

    # Test with n items
    n = 100
    for i in range(n):
        fc.first_order_merge('n', i)
    assert fc['n'] == n - 1
    fc.flush()

    # Test with n items and one host
    for i in range(n):
        fc.first_order_merge('host_name', i)
    assert fc['host_name'] == n - 1
    fc.flush()

# Generated at 2022-06-21 09:28:18.679094
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    # Given
    def __init__():
        self.cache = 'in_memory'
        self.flush()
        self.plugin = {}

    # When
    self.plugin.delete = 'some_host'
    # Then
    assert self.plugin.delete == 'some_host'

# Generated at 2022-06-21 09:28:25.432540
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    mock_cache = {}
    fact_cache = FactCache()
    fact_cache.first_order_merge('localhost', {'new_fact': '1'})
    fact_cache.first_order_merge('localhost', {'new_fact': '2'})
    updated_facts = fact_cache._plugin.get('localhost')

    assert updated_facts == {'new_fact': '2'}
    assert fact_cache._plugin.get('localhost') == {'new_fact': '2'}

# Generated at 2022-06-21 09:28:31.053869
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('one', 'A')
    assert fact_cache['one'] == 'A'
    fact_cache.first_order_merge('one', 'B')
    assert fact_cache['one'] == 'B'
    fact_cache.first_order_merge('two', 'A')
    assert fact_cache['two'] == 'A'
    fact_cache.first_order_merge('one', 'C')
    assert fact_cache['one'] == 'C'

# Generated at 2022-06-21 09:28:35.206821
# Unit test for method copy of class FactCache
def test_FactCache_copy():

    fact_cache = FactCache()

    assert fact_cache.copy() == {}

    fact_cache['test_key'] = 'test_value'

    assert fact_cache.copy() == {'test_key': 'test_value'}

# Generated at 2022-06-21 09:28:37.993279
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache
    assert fact_cache.__class__.__name__ == 'FactCache'

#Some unit test for constructor methods in FactCache

# Generated at 2022-06-21 09:28:41.068679
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    result = display.display('Unit test of class FactCache  method test_FactCache___getitem__')
    assert result == 'Unit test of class FactCache  method test_FactCache___getitem__'

# Generated at 2022-06-21 09:28:44.181334
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    factcache = FactCache()
    factcache['remote'] = 'remote-facts'
    factcache['local'] = 'local-facts'
    assert len(factcache) == 2
    factcache.flush()
    assert len(factcache) == 0


# Generated at 2022-06-21 09:28:49.828052
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    if C.CACHE_PLUGIN != 'memory':
        return
    fact_cache = FactCache()
    fact_cache['key1'] = 'value1'
    copy = fact_cache.copy()
    assert copy == {'key1': 'value1'}
    fact_cache['key1'] = 'value2'
    copy = fact_cache.copy()
    assert copy == {'key1': 'value2'}


# Generated at 2022-06-21 09:28:52.253270
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    fact_cache['test1'] = 'test'
    assert 'test1' in fact_cache
    fact_cache.flush()
    assert 'test1' not in fact_cache

# Generated at 2022-06-21 09:29:05.095241
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    """
    Return a primitive copy of the keys and values from the cache.
    """
    fact_cache = FactCache()
    test_data = {'test_key_1': 'test_value_1', 'test_key_2': 'test_value_2'}
    fact_cache.update(test_data)
    copy_data = fact_cache.copy()
    # Result should be equal to test_data, otherwise it is wrong
    assert copy_data == test_data
    # Change value for key test_key_1 to test_value_0
    copy_data['test_key_1'] = 'test_value_0'
    # Result should be not equal to test_data anymore
    assert copy_data != test_data

# Generated at 2022-06-21 09:29:12.891321
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()

    # set empty host_facts
    host_facts = {}
    # set key and value
    key = 'localhost'
    value = {'foo': 'bar'}
    # set facts in factcache
    fc.first_order_merge(key, value)
    # test key-value pair from factcache
    assert fc[key] == value

    # add key-value pair to host_facts
    host_facts[key] = value
    # set facts in factcache
    fc.first_order_merge(key, value)
    # test key-value pair from factcache
    assert fc[key] == host_facts[key]

# Generated at 2022-06-21 09:29:17.052174
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    fact_cache['key1'] = 'value1'
    fact_cache['key2'] = 'value2'
    assert len(fact_cache) == 2


# Generated at 2022-06-21 09:29:21.450692
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache({'host1': {'foo': 'bar'}})
    fact_cache.first_order_merge('host1', {'bar': 'foo'})
    assert fact_cache == {'host1': {'foo': 'bar', 'bar': 'foo'}}

# Generated at 2022-06-21 09:29:27.785616
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache = FactCache()
    cache_plugin = cache_loader.get(C.CACHE_PLUGIN)

    fact_cache['foo'] = 'bar'

    assert fact_cache['foo'] == 'bar'
    assert cache_plugin.keys() == ['foo']

    del fact_cache['foo']

    assert cache_plugin.keys() == []

    try:
        fact_cache['foo']
    except KeyError:
        exc = True
    else:
        exc = False

    assert exc



# Generated at 2022-06-21 09:29:37.725548
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    """
    Test case for `__getitem__` method of class FactCache

    Test case is intended to ensure that `__getitem__` method works as expected.
    """

    # Test case to ensure that `__getitem__` method raises KeyError exception
    # when the fact is not present in the cache.
    with pytest.raises(KeyError) as kerr:
        fc = FactCache()
        fc['foo']

    assert 'foo' in str(kerr.value)

    # Test case to ensure that `__getitem__` method returns the value of fact
    # when the fact is present in the cache.
    fc = FactCache()
    fc['foo'] = 'bar'
    assert fc['foo'] == 'bar'



# Generated at 2022-06-21 09:29:38.972295
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    factcache = FactCache()
    factcache["a"] = "a"
    factcache["b"] = "b"
    assert factcache.keys() == ["a", "b"]

# Generated at 2022-06-21 09:29:43.895731
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    assert not hasattr(fact_cache, 'copy')
    fact_cache._plugin = 'mock_plugin'
    fact_cache._plugin.get = 'mock_get'
    fact_cache._plugin.get.return_value = {'a': 1, 'b': 2}
    assert fact_cache.copy() == {'a': 1, 'b': 2}

# Generated at 2022-06-21 09:29:44.839096
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    pass


# Generated at 2022-06-21 09:29:47.197794
# Unit test for constructor of class FactCache
def test_FactCache():
    c = FactCache()

    assert c is not None
    assert c._plugin is not None
    assert c._plugin.__class__.__name__ == 'DataCache'


# Generated at 2022-06-21 09:29:58.699675
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    print("\nUnit test for method first_order_merge of class FactCache")

    from ansible.module_utils.facts.collector import BaseFactCollector

    class TestCollector(BaseFactCollector):

        def __init__(self, *args, **kwargs):
            super(TestCollector, self).__init__(*args, **kwargs)
            self.data = {
                'test_fact': {'test_key2': 'test_value2', 'test_key1': 'test_value1'},
                'test_fact1': {'test_key3': 'test_value3', 'test_key4': 'test_value4'},
            }

        def populate(self):
            return self.data

    cache_plugin = cache_loader.get(C.CACHE_PLUGIN)

# Generated at 2022-06-21 09:30:00.853697
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fc = FactCache()
    fc.flush()
    assert len(fc.keys()) == 0

# Generated at 2022-06-21 09:30:03.816435
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    FC = FactCache()
    FC['a'] = 1
    FC['b'] = 2
    assert len(FC) == 2


# Generated at 2022-06-21 09:30:08.241800
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    hosts = [ 'foo' ]
    keys_facts = {}
    keys = {}

    cache = FactCache()
    cache['foo'] = hosts
    for key in cache:
        keys_facts[key] = cache[key]
    keys = cache.keys()

    assert keys_facts == {'foo': ['foo']}
    assert keys == ['foo']

# Generated at 2022-06-21 09:30:12.782795
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    factcache = FactCache()

    factcache['a'] = 1
    factcache['b'] = 2
    factcache['c'] = 2

    assert factcache.copy() == {'a': 1, 'b': 2, 'c': 2}

# Generated at 2022-06-21 09:30:15.208664
# Unit test for method flush of class FactCache
def test_FactCache_flush():
     fact = FactCache()
     fact['key'] = 'value'
     fact.flush()
     assert len(fact) == 0

# Generated at 2022-06-21 09:30:21.469575
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fc = FactCache()
    fc["key1"] = "value1"
    fc["key2"] = "value2"
    assert "key1" in fc
    del fc["key1"]
    assert "key1" not in fc
    assert "key2" in fc
    assert fc["key2"] == "value2"


# Generated at 2022-06-21 09:30:22.611155
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    pass


# Generated at 2022-06-21 09:30:25.956829
# Unit test for method flush of class FactCache
def test_FactCache_flush():

    fc = FactCache()
    fc['test'] = 'test1'
    fc['test2'] = 'test2'

    assert len(fc.keys()) == 2
    fc.flush()
    assert len(fc.keys()) == 0



# Generated at 2022-06-21 09:30:34.141800
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    from ansible.module_utils.facts.collector import timeout, get_all_facts
    from ansible.module_utils.facts import callback
    from ansible.config.manager import ensure_type

    display.verbosity = 2
    display.deprecated("The timeout for gathering facts is now set in seconds and not minutes. "
                       "Please update your config to use timeout = 60.", version='2.11')
    all_facts = get_all_facts(callback, timeout=timeout(timeout=ensure_type(timeout, float), per_host=False))
    fact_cache = FactCache()
    fact_cache.first_order_merge("localhost", all_facts)
    assert isinstance(fact_cache.keys(), list)
    assert len(fact_cache.keys()) > 0


# Generated at 2022-06-21 09:30:48.543940
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    from ansible.module_utils.cache import Cache

    class FactsCachePlugin(Cache):

        def contains(self, key):
            return False

        def set(self, key, value):
            return True

        def delete(self, key):
            return True

        def get(self, key):
            raise KeyError()

        def flush(self):
            return True

        def keys(self):
            return []

    cache_loader.clear()
    cache_loader._fact_cache_plugin = 'somename'  # pylint: disable=protected-access,invalid-name
    cache_loader._fact_cache_plugin_options = {}  # pylint: disable=protected-access,invalid-name
    cache_loader._fact_cache_plugin_class = FactsCachePlugin  # pylint: disable=protected-access

# Generated at 2022-06-21 09:30:53.249880
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fc = FactCache()
    fc['key1'] = 'value'
    fc['key2'] = 'value'
    fc['key3'] = 'value'
    keys = fc.keys()
    assert(len(keys) == 3)

# Generated at 2022-06-21 09:30:56.697199
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    result = FactCache()
    result.flush()
    result.first_order_merge('dummy', {'1': '2'})
    assert result.copy()['dummy'] == {'1': '2'}

# Generated at 2022-06-21 09:31:01.377297
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    fact_cache['localhost'] = dict(a=1)
    assert fact_cache.copy()['localhost']['a'] == 1
    fact_cache.flush()
    assert fact_cache.copy() == {}



# Generated at 2022-06-21 09:31:08.599858
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():

    from ansible.plugins.cache.jsonfile import CacheModule as CachePlugin
    from ansible.vars.hostvars import HostVars
    import json

    if CachePlugin is None:
        raise ImportError

    plugin = CachePlugin()
    fact_cache = FactCache()
    fact_cache._plugin = plugin
    host_name = 'myhost.mydomain.com'
    host_facts = HostVars(host_name)
    host_facts.update(
        {
            'ansible_all_ipv4_addresses': ['192.168.1.1', '192.168.1.2'],
            'ansible_all_ipv6_addresses': ['fe80::100:7f:fffe', 'fe80::100:7f:ffff'],
        }
    )
    fact_cache

# Generated at 2022-06-21 09:31:14.968697
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    factcache = FactCache()
    factcache["one"] = 1
    factcache["two"] = 2
    factcache["three"] = 3
    factcache["four"] = 4
    factcache["five"] = 5
    factcache["six"] = 6
    result = []
    for key in factcache:
        result.append(key)
    expected = ["one", "two", "three", "four", "five", "six"]
    assert expected == result



# Generated at 2022-06-21 09:31:19.115704
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    # Test case with empty cache
    fact_cache = FactCache()
    assert fact_cache.__iter__() == []

    # Test case with populated cache
    fact_cache = FactCache()
    fact_cache['item1'] = 'value1'
    fact_cache['item2'] = 'value2'
    assert fact_cache.__iter__() == ['item1', 'item2']


# Generated at 2022-06-21 09:31:21.063334
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    def TestMethod():
        assert (False)  # TODO: implement your test here


# Generated at 2022-06-21 09:31:24.950943
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    value_first = ['ubuntu', 'redhat']
    value_second = ['ubuntu', 'debian']
    fc.first_order_merge('distribution', value_first)
    fc.first_order_merge('distribution', value_second)
    value = {'distribution': ['ubuntu', 'redhat'], 'distribution_system': ['debian']}
    assert fc['distribution'] == value['distribution']

# Generated at 2022-06-21 09:31:30.674216
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    import datetime
    test_fact_cache = FactCache()
    test_fact_cache['test_key'] = 'test_value'
    test_fact_cache['test_key_expiration'] = datetime.datetime.now()

    assert test_fact_cache.copy() == {'test_key': 'test_value', 'test_key_expiration': datetime.datetime.now()}

# Generated at 2022-06-21 09:31:40.814828
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    # test case 1
    cache = FactCache()
    cache['host1'] = {'ansible_host': 'host1.example.org'}

    assert cache['host1'] == {'ansible_host': 'host1.example.org'}


# Generated at 2022-06-21 09:31:42.579763
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    def __len__(self):
        return len(self._plugin.keys())


# Generated at 2022-06-21 09:31:43.889574
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    fact_cache.keys()

# Generated at 2022-06-21 09:31:51.484151
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()

# Generated at 2022-06-21 09:31:56.278930
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    factCache = FactCache();
    factCache['ipv4'] = {
        "interfaces": [
            "em1"
        ],
        "all": [
            "default",
            "lo",
            "em1",
            "em2"
        ],
        "lo": [
            "127.0.0.1"
        ],
        "default": [
            "192.168.122.1"
        ],
        "em1": [
            "192.168.122.160"
        ]
    }

# Generated at 2022-06-21 09:31:57.740658
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    assert len(fact_cache) >= 0

# Generated at 2022-06-21 09:31:59.743369
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fact_cache = FactCache()
    assert len(list(fact_cache)) == 0


# Generated at 2022-06-21 09:32:03.414777
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fc = FactCache()
    fc['test'] = 'test-value'
    assert(fc._plugin.contains('test') is True)
    fc.flush()
    assert(fc._plugin.contains('test') is False)



# Generated at 2022-06-21 09:32:09.839887
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    hostvars = {}
    fc = FactCache(hostvars)
    assert fc._plugin.name == "memory"
    fc['test'] = 5
    assert 'test' in fc
    del fc['test']
    assert 'test' not in fc



# Generated at 2022-06-21 09:32:18.724803
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    host_facts = {'test_FactCache_first_order_merge': {'testkey1': 'testvalue1', 'testkey2': 'testvalue2'}}
    fact_cache.first_order_merge('test_FactCache_first_order_merge', {'testkey1': 'testvalue1', 'testkey2': 'testvalue2'})
    assert fact_cache == host_facts, "first_order_merge doesn't do the merge correctly"
    fact_cache.first_order_merge('test_FactCache_first_order_merge', {'testkey3': 'testvalue3'})

# Generated at 2022-06-21 09:32:30.173033
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    # Pass the right key, check if the function return True
    assert FactCache().__contains__('localhost') == True



# Generated at 2022-06-21 09:32:33.898392
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    facts_cache = FactCache()
    facts_cache['internal_cache'] = {'test_key': 'test_value'}
    assert list(iter(facts_cache)) == ['internal_cache']


# Generated at 2022-06-21 09:32:44.763600
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    from ansible.plugins.cache import memory
    from ansible.utils.display import Display
    from ansible import constants as C

    display = Display()
    cache_loader.add_directory(memory._load_paths)
    factcache = FactCache()

    # Unit test when C.CACHE_PLUGIN is not set.
    del C.CACHE_PLUGIN

    try:
        factcache.__contains__("foo")
        assert False, "Expected AnsibleError exception"
    except AnsibleError as e:
        assert e.message == 'Unable to load the facts cache plugin (None).'

    # Unit test when C.CACHE_PLUGIN is set and contains(key) returns False
    C.CACHE_PLUGIN = 'memory'
    factcache = FactCache()

   

# Generated at 2022-06-21 09:32:49.612239
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fc = FactCache()
    fc.__setitem__('locahost', {'key1': 'value1', 'key2': 'value2'})
    assert 'localhost' in fc
    assert fc['localhost']['key1'] == 'value1'
    assert fc['localhost']['key2'] == 'value2'
    assert isinstance(fc, FactCache)



# Generated at 2022-06-21 09:32:55.580368
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    fact_cache['test_key'] = 'test'
    assert fact_cache['test_key'] == 'test'

    # Flushing the facts cache should remove the key
    fact_cache.flush()
    assert not fact_cache.keys()

# Generated at 2022-06-21 09:32:57.607489
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        f = FactCache()
        assert(False)
    except AnsibleError:
        assert(True)

# Generated at 2022-06-21 09:33:02.110529
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache = FactCache()

    assert fact_cache._plugin is not None

    fact_cache['test_key'] = 'test_value'
    assert fact_cache.__contains__('test_key')
    fact_cache.__delitem__('test_key')
    assert not fact_cache._plugin.contains('test_key')



# Generated at 2022-06-21 09:33:14.845980
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    # Setup
    import mock
    import os
    import tempfile
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.plugins.loader import cache_loader

    mock_dir = os.path.join(tempfile.gettempdir(), 'ansible_test_' + __name__)

    # Mock the cache plugin
    mock_plugin = mock.MagicMock()
    mock_plugin.__name__ = 'jsonfile'

    mock_plugin_name = 'ansible.plugins.cache.%s' % mock_plugin.__name__
    mock_plugin_path = mock_plugin_name.replace('.', '/') + '.py'
    mock_plugin_path = os.path.join(mock_dir, mock_plugin_path)

    mock_plugin_objs

# Generated at 2022-06-21 09:33:16.216047
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    cache = FactCache()
    cache.flush()

# Generated at 2022-06-21 09:33:18.674297
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    keys_list = fact_cache.keys()
    assert(keys_list is not None)

# Generated at 2022-06-21 09:33:39.273123
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    input_variable = []
    # Declare the class
    obj = FactCache()
    status = obj.__contains__(input_variable)


# Generated at 2022-06-21 09:33:47.123597
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    # Init FactCache object
    facct_cache = FactCache()

    # Init FactCache plugin object
    plugin_object = facct_cache._plugin

    # Call method __iter__ of class FactCache
    iter_value = facct_cache.__iter__()

    # Call method keys of class FactCachePluginBase
    plugin_value = plugin_object.func_keys()

    # Comparing values after method __iter__ of class FactCache is called
    assert iter_value == plugin_value


# Generated at 2022-06-21 09:33:49.174002
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    assert len(fact_cache) == 0
    

# Generated at 2022-06-21 09:33:51.175447
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    cache = FactCache()
    if iter(cache):
        pass


# Generated at 2022-06-21 09:33:54.532800
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fc = FactCache()
    fc['key1'] = 'value1'
    fc['key2'] = 'value2'

    for key in fc:
        assert fc[key] is not None

# Generated at 2022-06-21 09:33:59.846647
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    fact_cache["some_fact"] = "some_value"
    assert fact_cache["some_fact"] == "some_value"
    fact_cache.flush()
    assert not fact_cache.keys()
    assert fact_cache.copy() == dict()

# Generated at 2022-06-21 09:34:01.476373
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    """
    Test for `__contains__` of class `FactCache`
    """
    pass



# Generated at 2022-06-21 09:34:05.905525
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    assert len(fact_cache) == 0
    fact_cache["testkey"] = "testvalue"
    assert len(fact_cache) == 1

# Generated at 2022-06-21 09:34:11.448439
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    from ansible.plugins.cache.jsonfile import FactCache as TestFactCache
    _plugin = TestFactCache()
    _plugin.set('host1', {'Foo': 'Bar'})
    assert len(_plugin) == 1
    _plugin.set('host2', {'Foo': 'Bar'})
    assert len(_plugin) == 2

# Generated at 2022-06-21 09:34:12.868994
# Unit test for constructor of class FactCache
def test_FactCache():
    f = FactCache()
    assert isinstance(f, FactCache)

# Generated at 2022-06-21 09:34:44.421911
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    ansible_cache = FactCache()
    assert(len(ansible_cache) == 0)


# Generated at 2022-06-21 09:34:46.534712
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
  c = FactCache()
  assert c.__contains__('test')==False


# Generated at 2022-06-21 09:34:50.408308
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    cache.first_order_merge('host1', {'key1': 'value1'})
    assert cache['host1']['key1'] == 'value1'



# Generated at 2022-06-21 09:34:52.513565
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    # get the length of the fact_cache
    length = len(fact_cache)

# Generated at 2022-06-21 09:34:53.132997
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    pass

# Generated at 2022-06-21 09:34:55.117796
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fact = FactCache()
    assert isinstance(fact.__iter__(), object)


# Generated at 2022-06-21 09:35:01.068377
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    cache = FactCache()
    keys = [1, 2, 3, 4, 5]
    for i in keys:
        cache[i] = 'i'

    summary = 0
    for key in cache:
        summary = summary + key

    if summary == sum(keys):
        print('Test for __iter__ method of FactCache passed')
    else:
        print('Test for __iter__ method of FactCache failed')


# Generated at 2022-06-21 09:35:04.301342
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    cache = FactCache()
    cache["abc"] = 'abc'
    cache["def"] = 'def'
    cache["ghi"] = 'ghi'
    iter_list = []
    iter_list.append(cache)
    assert iter_list == [cache]


# Generated at 2022-06-21 09:35:15.771169
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.plugins.loader import cache_loader
    from ansible.utils.display import Display
    class MyMock(MutableMapping):
        def __init__(self, *args, **kwargs):
            self._plugin={}
            super(MutableMapping, self).__init__()
            super(MyMock, self).__init__()
        def __getitem__(self, key):
            return self._plugin[key]
        def __setitem__(self, key, value):
            self._plugin[key] = value
        def __delitem__(self, key):
            del self._plugin[key]
        def __contains__(self, key):
            return key in self._plugin

# Generated at 2022-06-21 09:35:23.639705
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # GIVEN:
    # A fact cache object,

    # WHEN:
    # I set up a fact cache object.
    fc = FactCache()

    # THEN:
    # I should have a fact cache object.
    assert isinstance(fc, FactCache)

    # GIVEN:
    # A fact cache object, and a hostname and data set.
    # WHEN:
    # I set up a fact cache object.
    # I call the method first_order_merge with hostname as key and data as value.

    fc.first_order_merge('server1', {'name': 'server1', 'ip': '192.168.1.1', 'zone': 'external'})

    # THEN:
    # I should have a fact cache with server1 fact,
    # I should not have a fact cache with

# Generated at 2022-06-21 09:36:39.454950
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    import ansible.plugins.cache
    def _cache_loader_get(arg):
        class TestCache:
            def __init__(self):
                self.dictionary = {'ansible_processor_count': 4}
            def contains(self, arg):
                return arg in self.dictionary
        return TestCache()
    tmp = ansible.plugins.cache.cache_loader.get
    ansible.plugins.cache.cache_loader.get = _cache_loader_get

    a = FactCache()
    assert 'ansible_processor_count' in a
    assert 'not_exist' not in a

    # restore the mocked object and cache_loader
    ansible.plugins.cache.cache_loader.get = tmp


# Generated at 2022-06-21 09:36:41.357193
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    facts = {
        'foo': 'bar',
        'baz': 'qux',
        'quux': 'corge'
    }

    # Create fact cache instance
    fact_cache = FactCache()

    # Update fact cache with facts
    fact_cache.update(facts)

    # Check facts in fact cache
    for fact, value in facts.items():
        assert fact_cache[fact] == value

# Generated at 2022-06-21 09:36:43.750911
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    cache  = FactCache()
    cache["foo"] = "bar"
    del cache["foo"]
    assert "foo" not in cache


# Generated at 2022-06-21 09:36:47.419192
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fc = FactCache()
    value = 'test_value'
    key = 'test_key'
    fc[key] = value
    assert(key in fc)
    assert(fc.first_order_merge(key, 'new_value'))
    fc.flush()
    assert(key not in fc)


# Generated at 2022-06-21 09:36:48.074567
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    return fact_cache

# Generated at 2022-06-21 09:36:52.003878
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    print(">>>>>>>>> test_FactCache___iter__ <<<<<<<<<<")
    obj = FactCache()
    print("obj %s" % obj)
    print("obj.__class__ %s" % obj.__class__)
    print("obj.__iter__() %s" % obj.__iter__())


# Generated at 2022-06-21 09:36:55.326193
# Unit test for constructor of class FactCache
def test_FactCache():
    FACTS_CACHE = FactCache()
    assert FACTS_CACHE._plugin

cache = FactCache()

# Generated at 2022-06-21 09:36:56.846057
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fc = FactCache()
    fc.flush()



# Generated at 2022-06-21 09:37:06.836228
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    import tempfile
    import shutil

    C.CACHE_PLUGIN = 'jsonfile'
    tempdir = tempfile.mkdtemp(dir=C.DEFAULT_LOCAL_TMP)
    C.CACHE_PLUGIN_CONNECTION = tempdir
    test_FactCache = FactCache()

    test_FactCache['test1'] = 'test1'
    test_FactCache['test2'] = 'test2'
    test_FactCache['test3'] = 'test3'

    assert test_FactCache.copy() == {'test1': 'test1', 'test2': 'test2', 'test3': 'test3'}

    test_FactCache.flush()
    shutil.rmtree(tempdir)

# Generated at 2022-06-21 09:37:18.042578
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    from ansible.module_utils.common._collections_compat import MutableMapping

    class FreeMember(MutableMapping):
        def __init__(self, *args, **kwargs):
            pass

        def __getitem__(self, key):
            raise KeyError

        def __setitem__(self, key, value):
            raise NotImplementedError

        def __delitem__(self, key):
            raise NotImplementedError

        def __contains__(self, key):
            raise NotImplementedError

        def __iter__(self):
            raise NotImplementedError

        def __len__(self):
            raise NotImplementedError

    cache = FreeMember()

    fc = FactCache(cache)

    key = 'foo'