

# Generated at 2022-06-21 09:27:09.975780
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    fact_cache["host_name"] = "host_name"
    fact_cache["host_name1"] = "host_name1"
    assert fact_cache.keys() == ["host_name", "host_name1"]


# Generated at 2022-06-21 09:27:12.765793
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():

    fact_cache = FactCache()

    key = 'test_key'
    value = 'test_value'
    
    fact_cache[key] = value

    fact_cache_value = fact_cache[key]

    assert fact_cache_value == value


# Generated at 2022-06-21 09:27:15.001948
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    import pytest
    cache = FactCache()
    cache['a'] = 'A'
    cache['b'] = 'B'
    assert cache.copy() == {'a': 'A', 'b': 'B'}


# Generated at 2022-06-21 09:27:22.117591
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    FACTS_CACHE = FactCache()
    FACTS_CACHE['192.168.0.1'] = dict()
    FACTS_CACHE['192.168.0.1']['disk_space'] = dict()
    FACTS_CACHE['192.168.0.1']['disk_space']['/'] = dict()
    FACTS_CACHE['192.168.0.1']['disk_space']['/']['capacity'] = '100'
    assert FACTS_CACHE['192.168.0.1']['disk_space']['/']['capacity'] == '100'


# Generated at 2022-06-21 09:27:32.919080
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    fact_cache['test1'] = {'test1':'test1.1'}
    fact_cache['test2'] = {'test2':'test2.2'}
    fact_cache['test3'] = {'test3':'test3.3'}
    fact_cache['test4'] = {'test4':'test4.4'}
    fact_cache['test5'] = {'test5':'test5.5'}
    assert fact_cache.keys() == ['test1', 'test2', 'test3', 'test4', 'test5']
    assert len(fact_cache) == 5

# Generated at 2022-06-21 09:27:39.624244
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    host_cache = {
        'fact1': 'value1',
        'fact2': 'value2'
    }
    fact_cache.first_order_merge('host1', host_cache)
    assert fact_cache['host1'] == host_cache
    assert fact_cache['host1']['fact1'] == 'value1'
    assert fact_cache['host1']['fact2'] == 'value2'
    new_value = {'fact1': 'value3'}
    fact_cache.first_order_merge('host1', new_value)
    assert fact_cache['host1'] == host_cache
    assert fact_cache['host1']['fact1'] == 'value3'

# Generated at 2022-06-21 09:27:44.510299
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    cache = FactCache()
    cache.first_order_merge('host1', {})
    assert len(cache) == 1
    assert 'host1' in cache

    cache.first_order_merge('host2', {})
    assert len(cache) == 2
    assert 'host2' in cache

# Generated at 2022-06-21 09:27:51.182823
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    print()
    print("Test FactCache:")
    fact_cache = FactCache()
    fact_cache['host1'] = "host1 facts"
    fact_cache['host2'] = "host2 facts"
    print('Test FactCache.__delitem__:')
    print(fact_cache)
    del fact_cache['host2']
    print(fact_cache)
    print()



# Generated at 2022-06-21 09:28:01.406878
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    """ When the function copy is called, the keys and values of the
    fact cache are returned as a primitive copy.
    Setup:
        Create a factcache and add key, value to cache
    Test:
        Call copy method
    Expected Result:
        Dict returned with key, value
    Test:
        Call copy method
    Expected Result:
        Empty dict returned
    """
    fc = FactCache()

    # Test copying single item
    key = "ansible_eth0"

# Generated at 2022-06-21 09:28:03.949052
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    # create an instance of class FactCache and test if class is MutableMapping
    factcache = FactCache()
    assert issubclass(FactCache, MutableMapping)
    assert issubclass(FactCache, MutableMapping)


# Generated at 2022-06-21 09:28:16.316893
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.cache import FactCacheModule

    cache = FactCache()

    # This is the fake cache file path
    cache._plugin.cache_path = 'file/path'
    cache._plugin.flush()

    if not C.DEFAULT_CACHE_PLUGIN:
        display.warning('Fact caching is disabled, set CACHE_PLUGIN to enable')

        assert cache.flush() == None
    else:
        try:
            # This assert a test to cover the case if the cache plugin not loaded
            assert True
        except AssertionError:
            display.error('Error loading the fact cache plugin %s' % C.DEFAULT_CACHE_PLUGIN)
            raise

# Generated at 2022-06-21 09:28:26.725509
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()

# Generated at 2022-06-21 09:28:29.644740
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    cache = FactCache()
    fake_key = "fake_key"

    try:
        result = cache.__contains__(fake_key)
        print("If the key exists, return True. Otherwise, return False.")
        print("result = %s" % result)
    except Exception as e:
        print("Occur error: %s" % e)


# Generated at 2022-06-21 09:28:36.226369
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    _plugin = None
    cache = FactCache(_plugin)

    # test for empty cache
    assert cache._plugin.contains("host1") == False

    cache._plugin.set("host1", "value")

    # test for host1 key
    assert cache._plugin.contains("host1") == True

    # test for host2 key
    assert cache._plugin.contains("host2") == False



# Generated at 2022-06-21 09:28:45.162901
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.plugins.cache import BaseFileCache, BaseMemCache

    loader = DataLoader()
    variable_manager = VariableManager()
    fact_cache = FactCache()

    # test case: cache stores string
    cache_value = {'hello': 'world'}
    fact_cache._plugin = BaseFileCache('id', 'key', loader=loader, variable_manager=variable_manager)
    fact_cache.flush()  # clear existing cache
    fact_cache._plugin.set('hello', cache_value['hello'])

    assert 'hello' in fact_cache
    assert fact_cache['hello'] == 'world'

    # test case: cache stores dict

# Generated at 2022-06-21 09:28:52.522226
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.cache import FactCache
    from ansible_collections.notstdlib.moveitallout.plugins.cache import JSONFileCachePlugin

    d = {'key1': 'value1', 'key2': 'value2'}
    j = JSONFileCachePlugin('/tmp/test.cache')

    try:
        j.set(d)

        fc = FactCache()
        fc._plugin = j
        assert sorted(fc) == ['key1', 'key2']
    finally:
        j._destroy()



# Generated at 2022-06-21 09:29:05.835010
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    # Setup test data
    fact_cache = FactCache()
    host_facts = {
        "ansible_distribution": "Ubuntu",
        "ansible_distribution_version": "16.04",
        "ansible_product_name": "Ubuntu",
        "ansible_product_version": "16.04",
        "ansible_os_family": "Debian",
        "ansible_pkg_mgr": "apt",
        "ansible_virtualization_role": "guest",
        "ansible_virtualization_type": "docker"
    }

    # Perform test
    fact_cache.first_order_merge("test_host", host_facts)

    # Verify test results
    assert("test_host" in fact_cache)

# Generated at 2022-06-21 09:29:09.749285
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fact_cache = FactCache({"key1" : "value1", "key2" : "value2"})
    assert "key1" in fact_cache
    assert "key2" in fact_cache
    assert "key3" not in fact_cache



# Generated at 2022-06-21 09:29:20.315913
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    factCache = FactCache()
    factCache.__setitem__('ip_address', '192.168.1.1')
    factCache.__setitem__('os', 'Linux')
    assert factCache.__getitem__('ip_address') == '192.168.1.1'
    assert factCache.__getitem__('os') == 'Linux'
    assert factCache.__contains__('ip_address')
    assert factCache.__contains__('os')

    # Verify the primitive copy of keys and values from the cache
    result = {'ip_address': '192.168.1.1', 'os': 'Linux'}
    assert factCache.copy() == result


# Generated at 2022-06-21 09:29:29.364332
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    from ansible.plugins import cache
    from ansible.utils.display import Display
    from ansible.utils.path import makedirs_safe
    from ansible import constants as C
    from tempfile import mkdtemp
    from shutil import rmtree
    from os.path import join

    test_dir = mkdtemp()
    makedirs_safe(join(test_dir, 'plugins'))
    makedirs_safe(join(test_dir, 'plugins', 'cache'))

    old_fact_cache_plugin = C.CACHE_PLUGIN
    old_fact_cache_connection = C.CACHE_PLUGIN_CONNECTION
    old_fact_cache_prefix = C.CACHE_PLUGIN_PREFIX

    C.CACHE_PLUGIN = 'jsonfile'

# Generated at 2022-06-21 09:29:34.574336
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    factcache = FactCache()
    factcache['foo'] = 1
    factcache['bar'] = 2
    assert len(factcache) == 2


# Generated at 2022-06-21 09:29:36.830867
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fact_cache = FactCache()
    # Return iterable
    fact_cache.__iter__()


# Generated at 2022-06-21 09:29:39.692219
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fact_cache = FactCache()
    display.vvv(str(fact_cache.__contains__('name')))
    assert fact_cache.__contains__('name') == False

# Generated at 2022-06-21 09:29:47.149684
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    def assert_equals(expected, actual):
        if expected == actual:
            return
        else:
            raise ValueError("Expected:\n%s\nGot:\n%s\n" % (expected, actual))

    class MockCache(MutableMapping):
        def __init__(self, *args, **kwargs):
            self._store = dict(*args, **kwargs)
        def __len__(self):
            return len(self._store)
        def __getitem__(self, key):
            return self._store[key]
        def __setitem__(self, key, value):
            self._store[key] = value
        def __delitem__(self, key):
            del self._store[key]
        def __contains__(self, key):
            return key in self._store


# Generated at 2022-06-21 09:29:52.728011
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():

    # this is a test setitem and update method

    factcache = FactCache()
    factcache['test_key'] = 'test_value'
    print(factcache['test_key'])
    factcache.update({'test_key': 'test_value'})
    print(factcache['test_key'])

# Generated at 2022-06-21 09:29:56.466715
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    cache = FactCache()
    cache.__setitem__("KEY1","VALUE1")
    cache.__setitem__("KEY2","VALUE2")
    cache.__setitem__("KEY3","VALUE3")
    assert cache.copy() == dict(cache)

# Generated at 2022-06-21 09:30:07.898811
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import tempfile
    import shutil
    import json
    import time
    import os

    _temp_dir = tempfile.mkdtemp()
    C.CACHE_PLUGIN_CONNECTION = "local"
    C.CACHE_PLUGIN = "jsonfile"
    C.CACHE_PLUGIN_PREFIX = _temp_dir
    fc = FactCache()

    facts1 = {"testkey": "testvalue1"}
    facts2 = {"testkey": "testvalue2"}
    fc.flush()
    fc.first_order_merge("test1", facts1)
    fc.first_order_merge("test2", facts2)
    time.sleep(1)
    fc.first_order_merge("test1", facts2)

# Generated at 2022-06-21 09:30:08.647883
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert(fc is not None)

# Generated at 2022-06-21 09:30:13.838635
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    test_fact_cache = FactCache()
    test_fact_cache = {'test_key':'test_value'}
    test_fact_cache['test_key']
    test_fact_cache.__delitem__('test_key')


# Generated at 2022-06-21 09:30:21.859665
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
      # Create an object of class FactCache
      my_factCache = FactCache({'key1': 'value', 'key2': 'value'})

      # Delete an item with index 'key2'
      my_factCache.__delitem__('key2')

      # Check if there are only one item left
      if len(my_factCache) == 1:
         print("Test case for method __delitem__ of class FactCache passed")
      else:
         print("Test case for method __delitem__ of class FactCache failed")

# Generated at 2022-06-21 09:30:30.583442
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    import subprocess

    def invoke_with_output(cmd):
        """
        Execute specified command and return its output as result.
        """
        return subprocess.check_output(cmd, shell=True).decode("utf-8").strip().split('\n')

    fact_cache = FactCache()

    # Test if fact_cache keys were updated
    fact_cache.keys().append('test_key')
    assert 'test_key' not in invoke_with_output('echo -e "keys\nquit" | nc -q 0 localhost 6335')

# Generated at 2022-06-21 09:30:37.064091
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_facts = {'facts': {'a': 1, 'b': 2, 'c': 3}, 'ansible_facts': {'d': 4, 'e': 5, 'f': 6}}
    fact_cache = FactCache()
    fact_cache.first_order_merge('new_host', fact_cache_facts)
    assert fact_cache['new_host'] == fact_cache_facts
    fact_cache_facts.update({'ansible_facts': {'x': 7, 'y': 8, 'z': 9}})
    fact_cache.first_order_merge('new_host', fact_cache_facts)

# Generated at 2022-06-21 09:30:38.082387
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    pass

# Generated at 2022-06-21 09:30:48.811578
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Create a new FactCache obj
    obj = FactCache()
    # Create a dict of facts
    dict_of_facts = dict(ansible_all_ipv4_addresses=['192.168.0.1'],
                         ansible_bios_date='04/01/2014',
                         ansible_bios_version='6.00')

    initial_len = len(obj.keys())
    obj.first_order_merge('key', dict_of_facts)

    assert (len(obj.keys()) - initial_len) == 1
    assert len(obj['key'].keys()) == 3
    assert obj['key']['ansible_bios_date'] == '04/01/2014'

# Generated at 2022-06-21 09:30:52.545688
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    import os
    c = FactCache()
    os.environ['CACHE_PLUGIN'] = 'jsonfile'
    assert c._plugin.flush() is None

# Generated at 2022-06-21 09:30:58.295634
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fact_cache = FactCache()
    try:
        assert fact_cache.keys() == [], "Incorrect keys"
        assert fact_cache.__getitem__(1) == None, "Incorrect getitem"
    except AssertionError as e:
        raise Exception('FactCache___getitem__: %s' % e.args[0])



# Generated at 2022-06-21 09:31:03.497257
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    # If a key is passed to __delitem__ method
    # and cache plugin doesn't contain this key
    # then KeyError is raised
    fact_cache = FactCache()
    fact_cache._plugin = DummyPlugin({'test_key': 'test_value'})
    fact_cache.__delitem__('not_existing_key')

# Generated at 2022-06-21 09:31:05.783301
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fc = FactCache()
    fc.__setitem__('test', 'test')
    assert fc['test'] == 'test'


# Generated at 2022-06-21 09:31:14.594413
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    class Plugin(object):
        def __init__(self, keys):
            self.keys = keys
        def contains(self, key):
            return True
        def get(self, key):
            pass
        def set(self, key, value):
            pass
        def delete(self, key):
            pass
        def keys(self):
            return self.keys
        def flush(self):
            pass

    p = Plugin(['a', 'b', 'c'])
    cache = FactCache(cache_plugin=p)
    assert len([key for key in cache]) == 3
    assert len([key for key in cache]) == 3

# Generated at 2022-06-21 09:31:18.235196
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    key = 'test_key'
    value = {'test_item_1': 'test_item_value_1'}
    fc = FactCache()

    print('Testing if host fact cache contains the key')

    assert key not in fc

    print('Testing first fact merge')


# Generated at 2022-06-21 09:31:27.240349
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    import tempfile

    fact_cache = FactCache()  # With default cache plugin, not using a Docker container
    temporary_file_path = tempfile.mktemp()
    temporary_file = open(temporary_file_path, 'w')
    print('This is a temporary file', file=temporary_file)
    temporary_file.close()
    fact_cache['temporary'] = temporary_file_path
    assert(temporary_file_path in fact_cache.keys())
    del fact_cache['temporary']
    assert(temporary_file_path not in fact_cache.keys())

# Generated at 2022-06-21 09:31:34.690040
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    #
    # test first_order_merge() method of class FactCache
    #

    # test no host_cache
    fact_cache = FactCache()
    host_facts = {'ansible_hostname': 'hostname'}
    fact_cache.first_order_merge('ip', host_facts)
    merged_facts = fact_cache.copy()
    assert_hostname_merged_facts(merged_facts, 'ip', host_facts)

    # test host_cache with no host_facts
    fact_cache = FactCache()
    host_cache = {'ansible_distribution': 'linux'}
    fact_cache.first_order_merge('ip', host_cache)
    merged_facts = fact_cache.copy()

# Generated at 2022-06-21 09:31:40.598600
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fc = FactCache()
    test = {'a': 1, 'b': 2, 'c': 3}
    for (key, value) in test.items():
        fc[key] = value
    assert fc.keys() == ['a', 'b', 'c']


# Generated at 2022-06-21 09:31:49.510076
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    from ansible.config.manager import ConfigManager
    from ansible.plugins.cache import FactCacheModule
    from ansible.plugins.loader import cache_loader

    cache_loader.add_directory(ConfigManager(C).get_config_basedir() + "/cache")
    cache_loader.set_fact_cache(FactCacheModule())
    cache = FactCache()
    import json

    host1_facts = {
        "ansible_architecture": "x86_64",
        "ansible_distribution": "Debian",
    }

    host2_facts = {
        "ansible_architecture": "x86_64",
        "ansible_distribution": "Debian",
    }

    cache.cache_hostvars_from_file(json.dumps(host1_facts))
    cache.cache

# Generated at 2022-06-21 09:31:51.985779
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fact_cache = FactCache()
    assert isinstance(fact_cache, dict)



# Generated at 2022-06-21 09:32:00.910976
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    import os

    # Create an instance of FactCache
    fact_cache = FactCache()

    # Set a key with a value
    fact_cache["host_1"] = "ansible"

    # Assert the key is in the cache
    assert "host_1" in fact_cache.keys()

    # Remove the key and ensure it no longer exists
    del fact_cache["host_1"]
    assert "host_1" not in fact_cache.keys()

    # Assert cache is empty
    assert len(fact_cache.keys()) == 0

    # Flush the cache
    fact_cache.flush()

# Generated at 2022-06-21 09:32:02.787526
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    test_object = FactCache()
    test_object['foo'] = 'bar'
    test_object['bar'] = 'foo'
    test_object.flush()
    assert not test_object


# Generated at 2022-06-21 09:32:03.547842
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    assert True

# Generated at 2022-06-21 09:32:15.391578
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    def contains(self, key):
        return key in self._host_facts['ansible_facts']
    def flush(self):
        self._host_facts['ansible_facts'].clear()
    def get(self, key):
        return self._host_facts['ansible_facts'][key]
    def set(self, key, value):
        self._host_facts['ansible_facts'][key] = value
    def keys(self):
        return self._host_facts['ansible_facts'].keys()
    def delete(self, key):
        del self._host_facts['ansible_facts'][key]
    assert not cache_loader.get(C.CACHE_PLUGIN)

# Generated at 2022-06-21 09:32:19.702317
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    fact_cache.__setitem__('localhost', {'ansible_facts': {'test_key': 'test_value'}})

    assert fact_cache.copy() == {'localhost': {'ansible_facts': {'test_key': 'test_value'}}}

# Generated at 2022-06-21 09:32:32.706411
# Unit test for constructor of class FactCache
def test_FactCache():
    facts_cache = FactCache()
    assert(facts_cache._plugin)

# Generated at 2022-06-21 09:32:42.077353
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Case 1: host_cache is empty
    key = 'host1'
    value = {'test': 1}
    host_facts = {key: value}
    cache = FactCache()
    cache.first_order_merge(key, value)
    assert cache == host_facts

    # Case 2: host_cache is not empty
    key = 'host1'
    value = {'test': 1}
    value_update = {'test': 2}
    host_facts = {key: value_update}
    cache = FactCache()
    cache.first_order_merge(key, value)
    cache.first_order_merge(key, value_update)
    assert cache == host_facts

# Generated at 2022-06-21 09:32:44.081000
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fact_cache = FactCache()
    assert list(fact_cache) == []



# Generated at 2022-06-21 09:32:47.795092
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fc = FactCache()
    fc['test'] = 'testvalue'
    assert 'test' in fc, 'test added to cache'
    del fc['test']
    assert 'test' not in fc, 'test deleted from cache'


# Generated at 2022-06-21 09:32:49.535194
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    assert fact_cache.keys == fact_cache.keys()


# Generated at 2022-06-21 09:32:52.214127
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    result = cache_loader.get(C.CACHE_PLUGIN).keys()
    assert result == ['localhost']

# Generated at 2022-06-21 09:33:02.992090
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    hostname = "127.0.0.1"
    facts = {hostname: {'ansible_facts': {'hostname': hostname}}}
    cache.first_order_merge(hostname, facts)
    assert cache[hostname]['ansible_facts']['hostname'] == "127.0.0.1"

    facts = {hostname: {'ansible_facts': {'fqdn': hostname}}}
    cache.first_order_merge(hostname, facts)
    assert cache[hostname]['ansible_facts']['hostname'] == "127.0.0.1"
    assert cache[hostname]['ansible_facts']['fqdn'] == "127.0.0.1"


# Generated at 2022-06-21 09:33:09.197873
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fc = FactCache()
    (key, value) = ('key123', 'value123')
    fc.__setitem__(key, value)

    assert fc.copy()[key] == value
    assert not fc.copy()['non-existent_key']


# Generated at 2022-06-21 09:33:12.678884
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = FactCache()
    key = 'key'
    value = {'key': 'value'}
    fact_cache.__setitem__(key, value)
    assert fact_cache.__contains__(key)



# Generated at 2022-06-21 09:33:15.523914
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    fact_cache['test1'] = 'test'
    assert fact_cache.keys() == ['test1']


# Generated at 2022-06-21 09:33:46.906545
# Unit test for constructor of class FactCache
def test_FactCache():
    my_fact_cache = FactCache()
    assert my_fact_cache._plugin._plugin_name == 'memory'


# Generated at 2022-06-21 09:33:48.770907
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fc = FactCache()
    assert fc.__getitem__ is not None


# Generated at 2022-06-21 09:34:01.058852
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    import os
    import shutil
    import tempfile

    cache = FactCache()
    cache.flush()

    cache_dir = tempfile.mkdtemp()
    cache_path = os.path.join(cache_dir, 'ansible-facts')

    def cleanup():
        if os.path.isdir(cache_dir):
            shutil.rmtree(cache_dir)

    C.CACHE_PLUGIN = 'jsonfile'
    C.CACHE_PLUGIN_CONNECTION = {'path': cache_path}


# Generated at 2022-06-21 09:34:09.754932
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    # Test if it is a copy of the keys and values from the cache
    test_cache = {'host1': 'value1', 'host2': 'value2', 'host3': 'value3'}
    fake_plugin = FakePlugin(test_cache)
    fact_cache = FactCache()
    fact_cache._plugin = fake_plugin
    fact_cache.keys()
    fact_cache_copy = fact_cache.copy()
    assert fact_cache_copy == test_cache



# Generated at 2022-06-21 09:34:15.014626
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    # create dict that represents cached facts
    cached_facts = {
        'dummy1': {'_ansible_cache_dir': '/tmp/.ansible/tmp', 'test_fact1': 'test_fact1'},
        'dummy2': {'_ansible_cache_dir': '/tmp/.ansible/tmp', 'test_fact2': 'test_fact2'},
    }

    # create and initialize mock object
    class MockFactCachePlugin():
        def get(self, key):
            return cached_facts[key]
    mock_instance = MockFactCachePlugin()
    # initialize FactCache object
    fact_cache = FactCache()
    fact_cache._plugin = mock_instance
    # test keys() method
    assert fact_cache.keys() == ['dummy1', 'dummy2']



# Generated at 2022-06-21 09:34:20.510741
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    # create cache
    cache = FactCache()
    # create hostname
    hostname = "test_host"
    # create facts
    facts = {"ansible_all_ipv4_address": "192.168.1.1"}
    # add fake value to cache
    cache[hostname] = facts
    # ensure that cache contains the new entry
    assert hostname in cache.keys()
    # run the flush method
    cache.flush()
    # ensure that all entries were erased
    assert not cache.keys()

# Generated at 2022-06-21 09:34:31.886284
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()

    host_cache = {'a': 'b'}
    host_facts = {'c': 'd'}

    # test: host_cache not in fact_cache
    fact_cache.first_order_merge('host_cache', host_cache)
    assert fact_cache['host_cache'] == host_cache

    # test: host_cache in fact_cache and 'a' in host_cache
    fact_cache.first_order_merge('host_cache', host_facts)
    assert fact_cache['host_cache'] == {'a': 'b', 'c': 'd'}

    # test: host_cache in fact_cache and 'a' not in host_cache
    host_facts = {'e': 'f'}
    fact_cache.first_order_merge

# Generated at 2022-06-21 09:34:38.735154
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    # ensure that the path to cache dir really exists and create it if not
    if not os.path.isdir(C.CACHE_PLUGIN_CONNECTION_PATH):
        os.mkdir(C.CACHE_PLUGIN_CONNECTION_PATH)
    # create a temporary file there
    tmpfile = tempfile.NamedTemporaryFile(dir=C.CACHE_PLUGIN_CONNECTION_PATH)
    tmpfile.close()
    # create mock cache plugin and verify number of its elements
    plugin = mock.Mock(spec=FactCache)
    assert isinstance(plugin, fact_cache._FactCache)
    plugin.keys.return_value = ['key0', 'key1', 'key2']
    assert len(plugin) == 3
    # remove created temporary file

# Generated at 2022-06-21 09:34:51.831845
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Expected a dict which contains the new key, and if the payload
    # is not a dict, the entry is just the payload, else the payload is
    # merged with the existing cache entry
    # https://github.com/ansible/ansible/pull/23981
    cache = FactCache()
    cache._plugin = {'_plugin_dict': {}}

    # key isn't currently in cache
    payload = 'some data'
    expected = {'test_host': 'some data'}
    cache.first_order_merge('test_host', payload)
    assert cache == expected

    # key is in cache, payload is also dict, should have items merged
    cache = FactCache()
    cache._plugin = {'_plugin_dict': {'test_host': {'a': 1, 'b': 2}}}

# Generated at 2022-06-21 09:34:57.713254
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    cache.first_order_merge('localhost', {'foo': 'bar'})
    cache.first_order_merge('localhost', {'foo': 'not bar', 'baz': 'qux'})
    assert cache['localhost']['foo'] == 'not bar'
    assert cache['localhost']['baz'] == 'qux'
    assert len(cache['localhost']) == 2

# Generated at 2022-06-21 09:36:00.766977
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    obj = FactCache()
    print(obj.keys())


# Generated at 2022-06-21 09:36:03.153776
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    my_cache = FactCache()
    my_cache.set("test_key", "test_value")
    assert my_cache.copy() == {"test_key": "test_value"}



# Generated at 2022-06-21 09:36:05.046108
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    cache = FactCache()
    cache['test'] = 'value'
    assert cache['test'] == 'value'


# Generated at 2022-06-21 09:36:05.817903
# Unit test for constructor of class FactCache
def test_FactCache():
    factcache = FactCache()
    assert factcache

# Generated at 2022-06-21 09:36:10.032121
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache['test_msg'] = "hello"
    fact_cache.first_order_merge('test_msg', 'world')
    assert fact_cache['test_msg'] == 'world'

    fact_cache = FactCache()
    fact_cache['test_msg'] = "hello"
    fact_cache.first_order_merge('test_msg', None)
    assert fact_cache['test_msg'] == None

# Generated at 2022-06-21 09:36:19.450884
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    # create a fact cache object
    facts_cache_obj = cache_loader.get(C.CACHE_PLUGIN)
    # add some fact's to the fact cache
    facts_cache_obj.set('1', 'one')
    facts_cache_obj.set('2', 'two')
    facts_cache_obj.set('3', 'three')
    # start the iterate and check for the keys in the iterated element.
    for z in facts_cache_obj:
        if z == '1':
            break
        else:
            assert False, "iterate all keys of the fact cache"
    # finally delete all the facts from the fact cache
    facts_cache_obj.flush()


# Generated at 2022-06-21 09:36:25.311695
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fcache = FactCache()
    assert len(fcache) == 0
    assert not fcache
    fcache.flush()
    assert len(fcache) == 0
    assert not fcache
    fcache.update({'a':'a'})
    assert len(fcache) == 1
    assert 'a' in fcache
    fcache.flush()
    assert len(fcache) == 0
    assert not fcache

# Generated at 2022-06-21 09:36:26.339723
# Unit test for constructor of class FactCache
def test_FactCache():
    facts = FactCache()
    assert facts is not None

# Generated at 2022-06-21 09:36:29.516269
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fc = FactCache()
    fc['key1'] = ['value1']
    fc['key2'] = ['value2']
    assert list(iter(fc)) == ['key1', 'key2']


# Generated at 2022-06-21 09:36:34.332847
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_obj = FactCache()
    fact_cache_obj.first_order_merge("host1", {"key1":"value1", "key2":"value2"})
    fact_cache_obj.first_order_merge("host1", {"key3":"value3"})
    assert fact_cache_obj == {"host1":{"key1":"value1", "key2":"value2" , "key3":"value3"}}