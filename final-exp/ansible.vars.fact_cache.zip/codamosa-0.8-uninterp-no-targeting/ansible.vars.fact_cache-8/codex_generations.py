

# Generated at 2022-06-21 09:27:16.950446
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = FactCache()
    fact_cache.flush()

    assert len(fact_cache) == 0

    fact_cache["test_key"] = "test_value"

    assert len(fact_cache) == 1
    assert fact_cache["test_key"] == "test_value"

    fact_cache["test_key"] = "test_value2"

    assert len(fact_cache) == 1
    assert fact_cache["test_key"] == "test_value2"


# Generated at 2022-06-21 09:27:19.400742
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    from ansible.plugins.cache import BaseCacheModule
    cache_mock = BaseCacheModule()
    cache = FactCache(**{'CACHE_PLUGIN': cache_mock})
    try:
        assert cache.flush() == cache._plugin.flush()
    except Exception as e:
        print(e)


# Generated at 2022-06-21 09:27:20.262914
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache

# Generated at 2022-06-21 09:27:32.263363
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Initialize the test
    key = "host1"
    cache_value = {'ansible_os_family': 'RedHat', 'ansible_distribution': 'CentOS', 'ansible_distribution_version': '7.5.1804'}
    cache_facts = {"host1": {"ansible_os_family": "RedHat", "ansible_distribution": "CentOS", "ansible_distribution_version": "7.5.1804", "ansible_distribution_major_version": "7", "ansible_architecture": "x86_64", "ansible_machine": "x86_64"}}
    value = {"ansible_architecture": "x86_64", "ansible_distribution_major_version": "7", "ansible_machine": "x86_64"}

   

# Generated at 2022-06-21 09:27:35.340484
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    fact_cache.update({"a":"b", "c":"d"})
    fact_cache.copy()
    fact_cache == {"a":"b", "c":"d"}

# Generated at 2022-06-21 09:27:40.402167
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    ansible = {
        "_ansible_parsed": "True",
        "_ansible_no_log": "True"
    }

    facts = {'test1': 'bar', 'test2': ansible}
    cache = FactCache(facts)

    # Make sure the cache contains all facts in a dict
    assert(len(facts) == len(list(cache)))
    assert(list(facts.keys()) == list(cache))


# Generated at 2022-06-21 09:27:52.731590
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    import json
    import os
    cache_dir = os.path.join(os.path.dirname(__file__), 'cache', 'test_host1')
    if not os.path.exists(cache_dir):
        os.makedirs(cache_dir)

    # This file must exist to "seed" the fact cache.
    with open(os.path.join(cache_dir, 'ansible_facts.json'), 'w') as fd:
        fd.write(json.dumps({'1': '1', '2': '2'}))

    fact_cache = FactCache()
    for key in fact_cache.keys():
        value = fact_cache[key]
        assert value == key

    # Even if an invalid key is given (i.e., a key that doesn't exist in the fact cache),

# Generated at 2022-06-21 09:27:55.897538
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    '''
    Unit test for method __setitem__ of class FactCache
    '''
    myfact_cache = FactCache()
    myfact_cache['testdata'] = ['fake_fact']


# Generated at 2022-06-21 09:28:01.407271
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    # Arrange
    test_loader = TestLoader()
    cache = FactCache()
    cache._plugin.loader = test_loader

    test_key = 'test_key'
    cache[test_key] = {}
    assert len(cache) == 1

    # Act
    del cache[test_key]

    # Assert
    assert len(cache) == 0
    assert test_key not in cache._plugin.cache


# Generated at 2022-06-21 09:28:03.345079
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    factcache = FactCache()
    factcache["test"] = "test"
    del factcache["test"]
    assert "test" not in factcache


# Generated at 2022-06-21 09:28:07.258754
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    assert True

# Generated at 2022-06-21 09:28:12.890409
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    import pytest

    @pytest.mark.parametrize('initial_len', range(10))
    def test(initial_len):
        fact_cache = FactCache()
        for (i, key) in enumerate(range(initial_len)):
            fact_cache.__setitem__(i, key)

        assert fact_cache.__len__() == initial_len

    test()

# Generated at 2022-06-21 09:28:21.291425
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    # set input/output parameters
    data = {'a': 1, 'b': 2, 'c': 3}
    cache_plugin = FakeCachePlugin()
    cache_plugin.set_cache(data)
    fact_cache = FactCache()
    fact_cache._plugin = cache_plugin

    # set expected result
    expected_result = iter(['a', 'b', 'c'])

    # actual result
    actual_result = iter(fact_cache)

    # assert
    assert actual_result == expected_result



# Generated at 2022-06-21 09:28:25.518437
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():

    # !!! NOTE !!!
    # The method FactCache.__contains__ is tested via tests of other methods:
    #   * test_FactCache___delitem__
    #   * test_FactCache___getitem__
    #   * test_FactCache___setitem__
    pass



# Generated at 2022-06-21 09:28:27.567161
# Unit test for constructor of class FactCache
def test_FactCache():
    FC = FactCache()
    assert FC['_plugin'] == cache_loader.get(C.CACHE_PLUGIN)

# Generated at 2022-06-21 09:28:32.603686
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)
    assert isinstance(fact_cache._plugin, dict)
    fact_cache._plugin = {'test': 'mock'}
    assert fact_cache['test'] == 'mock'


# Generated at 2022-06-21 09:28:36.460320
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fc = FactCache()
    fc.__setitem__('a', 'b')
    assert len(fc) == 1
    fc.__setitem__('c', 'd')
    assert len(fc) == 2


# Generated at 2022-06-21 09:28:38.128747
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fc = FactCache()
    assert len(fc) == len(fc._plugin.keys() )


# Generated at 2022-06-21 09:28:40.489930
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    obj = FactCache()
    obj.__setitem__('key1', 'value1')
    assert('key1' in obj)


# Generated at 2022-06-21 09:28:42.805104
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    # Instantiate
    fc = FactCache()

    # Check if the type of key is string
    assert type(fc.__iter__().__next__()) == str

# Generated at 2022-06-21 09:28:53.199410
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    '''
    Test the FactCache class.
    
    :return:
    '''
    print('\n\n##############\nStarting test_FactCache___delitem__\n##############\n')
    # TODO: Solve the next error:
    # AttributeError: 'Config' object has no attribute 'get_plugin_vars'
    #
    # obj = FactCache()
    # try:
    #     obj._plugin
    # except Exception, e:
    #     print(e)
    # else:
    #     pass

    print('\n\n##############\nFinished test_FactCache___delitem__\n##############\n')

# Generated at 2022-06-21 09:29:06.196109
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():

    class TestFactsCache(object):
        def __init__(self):
            self.fact_keys = []
        def keys(self):
            return self.fact_keys
        def set(self, key, value):
            self.fact_keys.append(dict(key=key, value=value))
        def get(self, key):
            for obj in self.fact_keys:
                if obj['key'] == key:
                    return obj['value']
            return None
        def delete(self, key):
            return
        def contains(self, key):
            if not self.get(key):
                return False
            return True

    t = TestFactsCache()
    fact_cache = FactCache(plugin = t)
    assert len(fact_cache) == 0


# Generated at 2022-06-21 09:29:12.028156
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    class CachePlugin:
        def contains(self, key):
            return key
        def get(self, key):
            return key
        def set(self, key, value):
            return
        def delete(self, key):
            return
        def flush(self):
            return
        def keys(self):
            return ['key']

    fact_cache = FactCache()
    fact_cache._plugin = CachePlugin()
    assert fact_cache.copy() == {'key': 'key'}


# Generated at 2022-06-21 09:29:15.401368
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    f = FactCache()
    f['test'] = {'fact1':'val1'}
    assert 'test' in f.keys()
    assert None not in f.keys()

# Generated at 2022-06-21 09:29:22.394484
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    """ Unit test for method keys of class FactCache """
    cache = FactCache()
    cache["name"] = "TEST"
    assert cache.keys() == ["name"]
    assert len(cache) == 1
    cache.flush()
    assert cache.keys() == []
    assert len(cache) == 0


# Generated at 2022-06-21 09:29:31.379877
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    def init(self, *args, **kwargs):
        self.data = {'a': 1, 'b': 2}
        self.keys = self.data.keys()
        return super(TestPlugin, self).__init__(*args, **kwargs)

    def get(self, key):
        return self.data[key]

    def get_all(self):
        return self.data

    def set(self, key, value):
        self.data[key] = value

    def delete(self, key):
        del self.data[key]

    def contains(self, key):
        return key in self.data

    def flush(self):
        self.data = {}
        self.keys = []

    def keys(self):
        return self.keys

    TestPlugin.__init__ = init
    TestPlugin

# Generated at 2022-06-21 09:29:38.084192
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test', {'a': '1'})

    assert fact_cache._plugin.get('test')['a'] == '1'

    fact_cache.first_order_merge('test', {'a': '2'})
    assert fact_cache._plugin.get('test')['a'] == '1'

    fact_cache.first_order_merge('test', {'b': '3'})
    assert fact_cache._plugin.get('test')['b'] == '3'

# Generated at 2022-06-21 09:29:41.490846
# Unit test for method copy of class FactCache
def test_FactCache_copy():

    fact_cache = FactCache()
    fact_cache['localhost'] = {'foo': 'some_value'}

    assert fact_cache.copy() == {'localhost': {'foo': 'some_value'}}



# Generated at 2022-06-21 09:29:45.944795
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    fc = FactCache()
    fc['localhost'] = {'foo': 'bar'}

    assert 'localhost' in fc
    assert fc['localhost'] == {'foo': 'bar'}

    fc.first_order_merge('localhost', {'foo': 'baz'})
    assert fc['localhost'] == {'foo': 'baz'}

# Generated at 2022-06-21 09:29:47.854766
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin
    assert '_plugin' in fact_cache.__dict__

# Generated at 2022-06-21 09:29:56.770041
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    cache = FactCache()

    cache['test1'] = 'value1'
    cache['test2'] = 'value2'

    assert cache.copy() == {'test1': 'value1', 'test2': 'value2'}


# Generated at 2022-06-21 09:30:01.178454
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin == cache_loader.get(C.CACHE_PLUGIN)
    assert isinstance(fc, FactCache)
    assert isinstance(fc, MutableMapping)
    assert isinstance(fc, dict)


# Generated at 2022-06-21 09:30:05.708497
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    cache = FactCache()
    cache.first_order_merge("host", {"test": "success"})
    assert cache["host"]["test"] == "success"
    cache.flush()
    assert len(cache.keys()) == 0


# Generated at 2022-06-21 09:30:10.866843
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    inp = {'host1': {'a':1}, 'host2': {'a':2}, 'host3': {'a':3}}
    fc = FactCache(data=inp)
    print("fc before delitem: ", fc)
    fc.__delitem__("host1")
    print("fc after delitem: ", fc)


# Generated at 2022-06-21 09:30:15.438799
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    cache = FactCache()
    cache['ansible_os_family'] = 'Debian'
    assert 'ansible_os_family' in cache
    cache.flush()
    assert 'ansible_os_family' not in cache


# Generated at 2022-06-21 09:30:16.562184
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    assert False, "Not implemented"



# Generated at 2022-06-21 09:30:18.864260
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    cache_copy = FactCache.copy()
    print(cache_copy)


# Generated at 2022-06-21 09:30:25.386574
# Unit test for method copy of class FactCache
def test_FactCache_copy():

    import mock
    from ansible.module_utils.facts import FactsCacheModulePlugin

    fact_cache = FactCache()
    # Mocking the '_plugin' value with FactsCacheModulePlugin class
    fact_cache._plugin = mock.Mock(spec=FactsCacheModulePlugin)
    fact_cache._plugin.get.return_value = {'key': 'value'}

    assert fact_cache.copy() == {'key': 'value'}


# Generated at 2022-06-21 09:30:27.541692
# Unit test for constructor of class FactCache
def test_FactCache():
    fc_obj = FactCache()
    assert str(fc_obj.__class__) == "<class 'ansible.executor.cache.FactCache'>"

# Generated at 2022-06-21 09:30:28.776636
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fc = FactCache()
    assert list(fc) == []


# Generated at 2022-06-21 09:30:44.501398
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    fact_cache['test'] = 10
    assert len(fact_cache) == 1
    assert 'test' in fact_cache
    fact_cache['test2'] = 20
    assert len(fact_cache) == 2
    assert 'test2' in fact_cache



# Generated at 2022-06-21 09:30:49.557927
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    fact_cache.update({'a': 1, 'b': 2})
    assert fact_cache == {'a': 1, 'b': 2}
    assert fact_cache.keys() == ['a', 'b']
    fact_cache.flush()
    assert fact_cache == {}
    assert fact_cache.keys() == []

# Generated at 2022-06-21 09:31:01.441816
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    from ansible.cache.memory import FactCacheMemory
    from ansible.constants import CACHE_PLUGIN

    C.CACHE_PLUGIN = 'memory'
    cache = FactCache()
    assert len(cache) == 0

    import datetime
    cache.set('foo', {'bar': datetime.datetime.now().isoformat()})
    assert len(cache) == 1

    cache.set('bar', {'bar': datetime.datetime.now().isoformat()})
    assert len(cache) == 2

    cache.set('bar', {'bar': datetime.datetime.now().isoformat()})
    assert len(cache) == 2

    C.CACHE_PLUGIN = 'jsonfile'

# Generated at 2022-06-21 09:31:03.239935
# Unit test for method keys of class FactCache
def test_FactCache_keys():
  fc = FactCache()
  assert fc.keys() == fc._plugin.keys()

# Generated at 2022-06-21 09:31:04.602910
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fc = FactCache()
    fc.flush()

# Generated at 2022-06-21 09:31:06.931520
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache._plugin == cache_loader.get(C.CACHE_PLUGIN)

# Generated at 2022-06-21 09:31:09.331634
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    my_fact_cache = FactCache()
    assert my_fact_cache.keys() == [], 'The FactCache should be empty'

# Generated at 2022-06-21 09:31:18.736453
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.plugins.cache.jsonfile import CacheModule as CacheModuleJson
    from ansible.plugins.cache import FactCache
    class MockCachePlugin(CacheModuleJson):
        def __init__(self, *args, **kwargs):
            self.keys_return_value = ['test_key']
            pass
        def contains(self, *args, **kwargs):
            return self.keys_return_value.__contains__(args[0])
        def keys(self, *args, **kwargs):
            return self.keys_return_value
    fact_cache_plugin = MockCachePlugin()
    fact_cache = FactCache()
    fact_cache._plugin = fact_cache_plugin


# Generated at 2022-06-21 09:31:29.322354
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    import pytest
    from ansible.plugins.cache import memory
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    collection_loader = AnsibleCollectionLoader(None)
    plugin = memory.FactCacheModule(collection_loader=collection_loader, timeout=0)

    fact_cache = FactCache(timeout=0)
    fact_cache._plugin = plugin

    key = "key1"
    value = "value"

    fact_cache[key] = value

    assert fact_cache[key] == value

    # Test that AnsibleUnicode is properly converted to basestring
    unicode_value = AnsibleUnicode('unicode_string')

    fact_cache[key] = unicode_value


# Generated at 2022-06-21 09:31:30.852481
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert(fc is not None)
    # TODO: Complete test

# Generated at 2022-06-21 09:32:00.519730
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    print('Testing __setitem__ of class FactCache')
    factCache_inst = FactCache()
    factCache_inst["key1"] = dict()
    factCache_inst["key1"]["key1-1"] = "value1"
    factCache_inst["key1"]["key1-2"] = "value2"
    print(factCache_inst["key1"])

test_FactCache___setitem__()

# Generated at 2022-06-21 09:32:05.906123
# Unit test for constructor of class FactCache
def test_FactCache():

    # Test for case without plugin for caching
    try:
        fake_plugin = None
        cache = FactCache()
    except AnsibleError as e:
        assert "Unable to load the facts cache plugin" in str(e)

    # Test for case of working __init__
    fake_plugin = { "foo": 1, "bar": 2 }
    cache = FactCache(fake_plugin)
    assert cache['foo'] == 1
    assert cache['bar'] == 2

# Generated at 2022-06-21 09:32:06.987764
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert isinstance(cache, FactCache)

# Generated at 2022-06-21 09:32:15.645936
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    import os
    import shutil
    import tempfile

    # Create temporary directory
    os.environ['ANSIBLE_FACTS_CACHE'] = tempfile.mkdtemp()

    # Create an object of class FactCache
    fact_cache = FactCache()

    # Check method copy before adding new key
    d = fact_cache.copy()
    assert len(d) == 0

    # Add new key-value
    fact_cache['TEST_KEY'] = 'TEST_VALUE'
    d = fact_cache.copy()
    assert len(d) == 1

    # Remove temporary directory
    shutil.rmtree(os.environ.get('ANSIBLE_FACTS_CACHE'))

# Generated at 2022-06-21 09:32:17.877038
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    key = 1
    value = 2
    fc = FactCache()
    fc[key] = value
    assert (list(fc.__iter__()) == [key])

# Generated at 2022-06-21 09:32:30.224304
# Unit test for method copy of class FactCache

# Generated at 2022-06-21 09:32:36.839406
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    # Create cache
    test_cache = FactCache()

    # Test that an empty cache does not contain the key 'test'
    assert 'test' not in test_cache

    # Add a key 'test' and check that it is contained
    test_cache['test'] = 'test'
    assert 'test' in test_cache

    # Delete the key and check that it is not contained
    del test_cache['test']
    assert 'test' not in test_cache


# Generated at 2022-06-21 09:32:40.418515
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    # arrange
    cache = FactCache()

    # act
    cache.__setitem__("test", "test")

    # assert
    assert cache._plugin.get("test") == "test"



# Generated at 2022-06-21 09:32:43.373492
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact = FactCache()
    fact.flush()
    keys = fact.keys()
    for key in keys:
        del fact[key]
    assert len(keys) ==  0

# Generated at 2022-06-21 09:32:47.880060
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc['test'] = {'a': 1, 'b': 2}
    fc.first_order_merge('test', {'a': 3, 'c': 4})
    assert fc['test'] == {'a': 3, 'b': 2, 'c': 4}


# Generated at 2022-06-21 09:33:40.666409
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    cache = FactCache()
    cache['a'] = '1'
    cache['b'] = '2'
    cache['c'] = '3'
    cache.flush()
    assert len(cache) == 0

# Generated at 2022-06-21 09:33:43.095909
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache = FactCache()
    key = "test"
    fact_cache[key] = "test"
    fact_cache.__delitem__(key)
    assert key not in fact_cache


# Generated at 2022-06-21 09:33:49.436679
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    host_cache = {'192.168.1.1': {'ipv4': '192.168.1.1'}}
    cache_loader.cache = host_cache
    fact_cache = FactCache()
    fact_cache.first_order_merge('192.168.1.1', {'ipv4': '192.168.1.1'})
    assert fact_cache.copy() == {'192.168.1.1': {'ipv4': '192.168.1.1'}}


# Generated at 2022-06-21 09:33:55.291083
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    """
    Test that FactCache.copy() returns a primitive copy of the keys and values of the cache.
    """
    facts_cache = FactCache()
    test_key = 'test_key'
    test_value = 'test_value'
    facts_cache[test_key] = test_value
    assert facts_cache.copy() == {test_key: test_value}

# Generated at 2022-06-21 09:34:04.834225
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    from itertools import count
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.plugins.cache.memory import CacheModule
    from ansible.plugins.loader import cache_loader
    from copy import copy
    import pytest
    try:
        from collections import Counter
    except ImportError:
        from ansible.module_utils.six import Counter

    # Create an instance of CacheModule and insert it into cache_loader._fact_cache
    cache_loader._fact_cache[CacheModule.CACHE_NAME] = CacheModule()

    # Create an instance of FactCache with name of cache_loader._fact_cache
    fc = FactCache(cache_name=CacheModule.CACHE_NAME)

# Generated at 2022-06-21 09:34:10.587200
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache = FactCache()
    fact_cache['test_key'] = 'test_value'
    fact_cache['test_key2'] = 'test_value2'
    fact_cache.__delitem__('test_key')
    assert 'test_key2' in fact_cache
    assert fact_cache['test_key2'] == 'test_value2'


# Generated at 2022-06-21 09:34:16.859419
# Unit test for method copy of class FactCache
def test_FactCache_copy():

    from ansible.utils.collection_plugins import FactCache

    key1 = 'key1'
    key2 = 'key2'
    value1 = 'value1'
    value2 = 'value2'

    facts = FactCache()
    facts[key1] = value1
    facts[key2] = value2

    expected_result = {key1: value1, key2: value2}
    assert facts.copy() == expected_result

# Generated at 2022-06-21 09:34:23.189670
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    from ansible.plugins.cache.memory import CacheModule
    from ansible.module_utils.six import iterkeys
    from ansible.module_utils._text import to_text
    from ansible.utils.display import Display
    from ansible.errors import AnsibleError


# Generated at 2022-06-21 09:34:27.535578
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    result = False
    try:
        instance = load_cache_plugin()
        instance.__delitem__([])
        result = True
    except KeyError:
        result = False

    assert result is False


# Generated at 2022-06-21 09:34:33.772663
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    cache = FactCache()

    cache._plugin = MagicMock()
    host = 'test'
    cache._plugin.contains = MagicMock(return_value = True)
    # ansible/plugins/cache/jsonfile.py : class JsonfileCache
    # def contains(self, key):
    #    return os.path.exists(self._prefix_dir + key)
    #assert cache._plugin.contains(host) == True
    assert host in cache


# Generated at 2022-06-21 09:36:27.734535
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    """
    FactCache - __contains__ method
    """
    fc_obj = FactCache()
    assert fc_obj.__contains__(None) == False


# Generated at 2022-06-21 09:36:32.704999
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    host_facts = dict(foo="bar")
    key = "localhost"
    fc.first_order_merge(key, host_facts)
    assert fc[key] == host_facts

    host_facts = dict(foo="baz")
    fc.first_order_merge(key, host_facts)
    assert fc[key]['foo'] == 'baz'

# Generated at 2022-06-21 09:36:34.256728
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    assert len(fact_cache) == 0


# Generated at 2022-06-21 09:36:41.663480
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fact = FactCache(name='Test')
    fact[0] = 0
    fact[1] = 1
    fact[2] = 2
    fact[3] = 3
    fact[4] = 4
    fact[5] = 5
    fact[6] = 6
    fact[7] = 7
    fact[8] = 8
    fact[9] = 9
    count = 0
    for i in fact:
        assert i == count
        count += 1


# Generated at 2022-06-21 09:36:44.213866
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = FactCache()
    fact_cache['test'] = 'test_value'
    assert fact_cache['test'] == 'test_value'


# Generated at 2022-06-21 09:36:47.228344
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    fact_cache['a'] = 'A'
    fact_cache['b'] = 'B'
    fact_cache['c'] = 'C'
    fact_cache.flush()
    assert list(fact_cache) == []

# Generated at 2022-06-21 09:36:52.643036
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fact_cache = FactCache()
    fact_cache['a'] = 'a'
    fact_cache['b'] = 'b'
    fact_cache['c'] = 'c'
    fact_cache['b'] = 'b'
    assert len(fact_cache) == 3
    # pylint: disable=unnecessary-comprehension
    assert sorted(list(fact_cache)) == sorted(['a', 'b', 'c'])
    assert fact_cache['b'] == 'b'

# Generated at 2022-06-21 09:37:01.623925
# Unit test for method copy of class FactCache
def test_FactCache_copy():

    # Create sample data
    sample_data = {
        'sample_key1': 'sample_value1',
        'sample_key2': 'sample_value2',
        'sample_key3': 'sample_value3',
    }
    expected_data = dict(sample_data)

    # Create the object to test
    fc = FactCache(sample_data)

    # Try out the method
    result = fc.copy()

    # How about a nice assert?
    assert result == expected_data

# Generated at 2022-06-21 09:37:04.323856
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = cache_loader.get('memory')
    fact_cache.set('ansible_lsb', {'distcodename': 'focal'})

    fact_cache = FactCache()
    fact_cache['ansible_lsb'] = {'distcodename': 'focal'}
    assert fact_cache.keys() == ['ansible_lsb']


# Generated at 2022-06-21 09:37:11.106056
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    ansible_facts    = {'ansible_distribution': 'Ubuntu', 'ansible_distribution_release': '14.04'}
    ansible_facts_2  = {'ansible_distribution': 'Ubuntu', 'ansible_distribution_release': '15.10'}
    ansible_facts_3  = {'ansible_distribution': 'Ubuntu', 'ansible_distribution_release': '16.04'}
    ansible_facts_4  = {'ansible_distribution': 'Ubuntu', 'ansible_distribution_release': '16.04', 'ansible_machine': 'x86_64'}