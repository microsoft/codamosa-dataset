

# Generated at 2022-06-21 09:27:13.420344
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    import tempfile

    # initialize cache
    fact_cache = FactCache({})

    # set temp file path
    TEMP_FILE = tempfile.gettempdir() + "/" + "test_ansible_cache"

    # set cache file path
    C.CACHE_PLUGIN = "jsonfile"
    C.CACHE_PLUGIN_CONNECTION = TEMP_FILE

    # initialize plugin
    fact_cache._plugin = cache_loader.get(C.CACHE_PLUGIN)

    # check if the plugin has been loaded
    if not fact_cache._plugin:
        raise AnsibleError('Unable to load the facts cache plugin (%s).' % (C.CACHE_PLUGIN))

    # test fact cache

# Generated at 2022-06-21 09:27:17.308506
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    ansible = Ansible()
    fact_cache = FactCache()
    fact_cache.flush()
    fact_cache["key_1"] = "value_1"
    fact_cache["key_2"] = "value_2"
    fact_cache["key_3"] = "value_3"
    fact_cache["key_4"] = "value_4"


    keys = fact_cache.keys()

    assert 4 == len(keys)
    assert "key_1" in keys
    assert "key_2" in keys
    assert "key_3" in keys
    assert "key_4" in keys
    assert "key_5" not in keys



# Generated at 2022-06-21 09:27:28.531573
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    import pytest
    from ansible.errors import AnsibleError
    from ansible.plugins.loader import cache_loader
    from ansible.utils.display import Display

    display = Display()

    def mock_plugin_init(self, *args, **kwargs):
        pass

    def mock_plugin_flush(self):
        self.storage = {}

    def mock_plugin_get(self, key):
        try:
            return self.storage[key]
        except KeyError:
            return {}

    def mock_plugin_set(self, key, value):
        self.storage[key] = value

    def mock_plugin_delete(self, key):
        try:
            del self.storage[key]
        except KeyError:
            pass


# Generated at 2022-06-21 09:27:32.011460
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    factcache = FactCache()

    factcache['key1'] = 'value1'
    assert len(factcache) == 1
    del factcache['key1']
    assert len(factcache) == 0


# Generated at 2022-06-21 09:27:37.744826
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    # http://docs.python.org/2/library/unittest.html#unittest.TestCase.debug
    # http://python-guide-pt-br.readthedocs.io/en/latest/writing/tests/
    display.info('Testing __iter__ method of class FactCache')
    #assertEqual(expected, FactCache.__iter__())
    assert True # TODO: implement your test here


# Generated at 2022-06-21 09:27:43.892188
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    fact_cache['fact1'] = 'var1'
    fact_cache['fact2'] = 'var2'
    fact_cache['fact3'] = 'var3'
    fact_cache['fact2'] = 'var2_updated'
    copied_dict = fact_cache.copy()
    assert copied_dict['fact1'] == 'var1'
    assert copied_dict['fact2'] == 'var2_updated'
    assert copied_dict['fact3'] == 'var3'
    assert 'fact1' in fact_cache
    assert 'fact2' in fact_cache
    assert 'fact3' in fact_cache
    fact_cache.flush()
    assert 'fact1' not in fact_cache
    assert 'fact2' not in fact_cache

# Generated at 2022-06-21 09:27:49.937636
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    # test result of remove key from cache
    fc = FactCache()
    fc['KEY1'] = ['VALUE1']
    fc['KEY2'] = ['VALUE2']
    assert fc.__contains__('KEY1')
    del fc['KEY1']
    assert not fc.__contains__('KEY1')



# Generated at 2022-06-21 09:27:52.772599
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    fact_cache["test_key"] = "test_value"
    assert fact_cache.copy() == {"test_key": "test_value"}

# Generated at 2022-06-21 09:27:55.150109
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    cache = FactCache()
    cache['test'] = 'test'
    del cache['test']
    assert not cache.keys()

# Generated at 2022-06-21 09:27:57.844618
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    c = FactCache()

    c['a'] = 1
    c['b'] = 2
    c['c'] = 3

    assert len(c) == 3



# Generated at 2022-06-21 09:28:00.221750
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    pass


# Generated at 2022-06-21 09:28:03.198238
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    value = {'test_key': 'test_value'}
    fact_cache['test_host'] = value
    assert 'test_host' in fact_cache
    fact_cache.flush()
    assert 'test_host' not in fact_cache

# Generated at 2022-06-21 09:28:12.345701
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    import json
    f = FactCache()
    f['192.168.0.1'] = json.loads('{"192.168.0.1": "a"}')
    f['localhost'] = json.loads('{"localhost": "b"}')
    f['127.0.0.1'] = json.loads('{"127.0.0.1": "c"}')
    assert f.keys() == ["192.168.0.1", "localhost", "127.0.0.1"]
    assert f.copy() == {"192.168.0.1": "a", "localhost": "b", "127.0.0.1": "c"}



# Generated at 2022-06-21 09:28:23.961704
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()

    host_facts = {'ansible_default_ipv4': {'address': '192.168.1.1', 'interface': 'eth0', 'network': '192.168.1.0'},
                  'ansible_machine': 'x86_64', 'ansible_os_family': 'RedHat', 'ansible_distribution': 'CentOS',
                  'ansible_date_time': {'date': '2017-05-18', 'time': '11:57:34', 'timezone': 'Europe/Berlin'}
                  }

    fact_cache.first_order_merge('localhost', host_facts)
    assert fact_cache['localhost'] == host_facts

    # update facts with new facts

# Generated at 2022-06-21 09:28:25.295517
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    assert hasattr(fact_cache, 'keys')

# Generated at 2022-06-21 09:28:26.541615
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fc = FactCache()
    fc.keys()

# Generated at 2022-06-21 09:28:29.398697
# Unit test for constructor of class FactCache
def test_FactCache():
    '''
    CACHE_PLUGIN is set to jsonfile so we can test the fact caching with, for example,
    the dir and jsonfile plugins with the same code.
    '''
    facts_cache = FactCache()
    assert facts_cache

# Generated at 2022-06-21 09:28:33.263681
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    a = FactCache()
    a['1'] = 1
    a['2'] = 2
    a['3'] = 3
    assert sorted(a.keys()) == ['1', '2', '3']

# Generated at 2022-06-21 09:28:36.647604
# Unit test for constructor of class FactCache
def test_FactCache():
    print("Testing constructor of class FactCache")
    try:
        fact_cache = FactCache()
        print("Init for class FactCache is done")
    except:
        raise

test_FactCache()

# Generated at 2022-06-21 09:28:45.454582
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc.first_order_merge('k1', {'foo': 'bar'})
    fc.first_order_merge('k2', {'baz': 'qux'})
    assert fc.keys() == ['k1', 'k2']
    assert fc['k1'] == {'foo': 'bar'}
    assert fc['k2'] == {'baz': 'qux'}
    fc.first_order_merge('k1', {'baz': 'quux'})
    assert fc.keys() == ['k1', 'k2']
    assert fc['k1'] == {'foo': 'bar', 'baz': 'quux'}
    fc.flush()
    assert fc.keys() == []

# Generated at 2022-06-21 09:28:50.268665
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.basic import AnsibleModule

    fc = FactCache()

    m = AnsibleModule(argument_spec={'source': dict(default='system')})
    m.params['gather_subset'] = '!all'
    f = Facts(m)

    assert 'all' not in fc

    fc.first_order_merge('all', f.get_facts())

    assert 'all' in fc

# Generated at 2022-06-21 09:28:55.046336
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fact_cache = FactCache()
    assert '__iter__' in dir(fact_cache)

    fact_cache._plugin = mock_plugin = Mock()
    mock_plugin.keys.return_value = []
    iter(fact_cache)
    mock_plugin.keys.assert_called_with()


# Generated at 2022-06-21 09:28:57.006206
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    myFactCache = FactCache()
    myFactCache['testKey'] = 'testValue'

# Generated at 2022-06-21 09:29:01.624805
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    F_Cache = FactCache()
    F_Cache.update({"host": "hostname"})
    for x in (F_Cache):
        assert x == "host"
    F_Cache.flush()
    for x in (F_Cache):
        assert 0


# Generated at 2022-06-21 09:29:04.441677
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    cache = FactCache()
    cache['test'] = 'test'
    assert cache.copy() == {'test': 'test'}

# Generated at 2022-06-21 09:29:12.794612
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():

    fake_cache_keys = ('key1', 'key2', 'key3')
    fake_cache_get  = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
    fake_cache_plugin = FakeCachePlugin(keys=fake_cache_keys, get=fake_cache_get)
    fake_FactCache = FactCache()
    # For FactCache(), inits the "_plugin" to be a FakeCachePlugin object
    fake_FactCache._plugin = fake_cache_plugin

    for key in fake_FactCache:
        assert key in fake_cache_keys
        assert fake_FactCache[key] == fake_cache_get[key]


# Generated at 2022-06-21 09:29:14.568787
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    cache = FactCache()
    cache.__iter__()


# Generated at 2022-06-21 09:29:20.316440
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    # Create an object of class FactCache
    fact_cache = FactCache()
    # Create a dict
    d = {'a':1}
    # Assign dict to fact_cache object
    fact_cache['a'] = d
    # Check if correct dict is returned
    assert fact_cache['a'] == d


# Generated at 2022-06-21 09:29:23.575145
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = FactCache()
    fact_cache['test_key'] = 'test_value'
    assert fact_cache.get('test_key') == 'test_value'


# Generated at 2022-06-21 09:29:27.675842
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    cache = FactCache()
    key = 'my_key'
    value = 'my_value'
    cache_plugin = cache._plugin
    cache_plugin.set = lambda x, y: None

    cache.__contains__(key)
    assert cache_plugin.contains.called_with(key)


# Generated at 2022-06-21 09:29:33.873868
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    factCache = FactCache()
    factCache["a"] = "b"
    assert factCache["a"] == "b"
    del factCache["a"]
    assert "a" not in factCache["a"]


# Generated at 2022-06-21 09:29:38.042447
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    cache = FactCache()
    assert cache.keys() == []
    cache['host1'] = 1
    cache['host2'] = 2
    assert set(cache.keys()) == {'host1', 'host2'}



# Generated at 2022-06-21 09:29:46.001035
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    from ansible.cache.base import BaseCacheModule
    from ansible.plugins.loader import cache_loader

    class FakeCacheModule(BaseCacheModule):
        def __init__(self):
            self.myfact = {}

        def contains(self, key):
            return key in self.myfact

        def delete(self, key):
            if key in self.myfact:
                del self.myfact[key]

        def get(self, key):
            return self.myfact[key]

        def keys(self):
            return ['key1', 'key2', 'key3']

        def set(self, key, value):
            self.myfact[key] = value

        def flush(self):
            self.myfact = {}

    cache_loader.add('fakecache', FakeCacheModule())
    fac = FactCache

# Generated at 2022-06-21 09:29:57.219060
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    import os
    import sys
    import tempfile
    import warnings

    # Ansible plugins are not on the Python path by default
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../../'))

    # Capture warnings, as deprecation messages are displayed but do not cause
    # the test to fail
    with warnings.catch_warnings():
        warnings.simplefilter('ignore', DeprecationWarning)
        from plugins.cache.jsonfile import Plugin as JsonFilePlugin

    # Create cache plugin
    jsonfile = JsonFilePlugin()

    # Create facts cache
    fact_cache = FactCache()
    fact_cache._plugin = jsonfile

    # Create temporary directory for cache file
    fact_cache_dir = tempfile.mkdtemp()

    # Set fact cache file location

# Generated at 2022-06-21 09:30:08.331965
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    plugin_mock = MagicMock()
    plugin_mock.set.return_value = True

    cache_loader_mock = MagicMock()
    cache_loader_mock.get.return_value = plugin_mock
    setattr(modules.cache_loader, 'get', cache_loader_mock)

    assert C.CACHE_PLUGIN == 'memory'
    cache = FactCache()
    assert cache
    result = cache.__setitem__('testkey', 'testval')
    assert plugin_mock.set.called
    assert 'testkey' == plugin_mock.set.call_args[0][0]
    assert 'testval' == plugin_mock.set.call_args[0][1]
    assert result is True


# Generated at 2022-06-21 09:30:08.869788
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    pass


# Generated at 2022-06-21 09:30:10.867095
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    factcache = FactCache()
    assert len(dict(factcache)) == len(factcache)



# Generated at 2022-06-21 09:30:14.093037
# Unit test for constructor of class FactCache
def test_FactCache():
     factcache = FactCache()

     # The contents of factcache is generated by a plugin ( for example JSONFile )
     # so we can not assert anything about the contents

# Generated at 2022-06-21 09:30:18.498344
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fc = FactCache()
    fc_keys = list(fc.keys())
    fc.flush()
    fc_keys_after = list(fc.keys())
    assert fc_keys != fc_keys_after, "Keys of the cache is not changed after flush"

# Generated at 2022-06-21 09:30:21.911408
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    # Here '__len__' return is 0 and same will be return in factory class
    assert(len(fact_cache) == 0)



# Generated at 2022-06-21 09:30:30.927587
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    from tempfile import mkdtemp
    from os.path import join
    from ansible.plugins.cache import BaseFileCacheModule

    tmp_dir = mkdtemp('', '')
    cache = FactCache(tmp_dir)
    cache.flush()
    expected = {}
    assert cache == expected, "FactCache.flush() failed"


# Generated at 2022-06-21 09:30:32.856285
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, object)
    assert isinstance(fact_cache, MutableMapping)


# Generated at 2022-06-21 09:30:33.773087
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    assert False, "No implemented"


# Generated at 2022-06-21 09:30:46.276280
# Unit test for method __getitem__ of class FactCache

# Generated at 2022-06-21 09:30:47.521339
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    assert False


# Generated at 2022-06-21 09:30:53.003201
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache(dict())
    hostvars = dict()
    hostvars["host1"] = dict(ansible_all_ipv4_addresses=["192.168.50.2", "192.168.50.1"], ansible_default_ipv4=dict(address="192.168.50.2", interface="en0"))
    fact_cache.flush()
    fact_cache["host1"] = hostvars["host1"]
    fact_cache.flush()
    keys = fact_cache.keys()
    assert(keys[0] == "host1")



# Generated at 2022-06-21 09:30:55.987276
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fc = FactCache()
    try:
        fc['test']
    except KeyError:
        assert True
    else:
        assert False

# Generated at 2022-06-21 09:30:59.033222
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    test_object = FactCache()
    test_object["testkey"] = "testvalue"
    test_object.flush()
    assert not test_object["testkey"]

# Generated at 2022-06-21 09:31:00.958300
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    test_fact_cache = FactCache()
    test_fact_cache['test_key'] =  {'test_key': 'test_value'}
    assert test_fact_cache['test_key'] == {'test_key': 'test_value'}


# Generated at 2022-06-21 09:31:03.540372
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    FactCache.__setitem__('test_key', 'test_value')
    assert FactCache.__getitem__('test_key') == 'test_value'


# Generated at 2022-06-21 09:31:22.551985
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    import json
    fc = FactCache()
    # Set some test data

# Generated at 2022-06-21 09:31:24.872160
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    test_fact_cache = FactCache()
    test_fact_cache['x'] = 'y'
    assert  test_fact_cache['x'] == 'y'
    test_fact_cache.flush()
    assert test_fact_cache.keys() == []


# Generated at 2022-06-21 09:31:29.010633
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    assert fact_cache.keys() == []
    fact_cache.__setitem__('key1', 'value1')
    fact_cache.__setitem__('key2', 'value2')
    assert sorted(fact_cache.keys()) == ['key1', 'key2']
    fact_cache.__setitem__('key3', 'value3')
    assert sorted(fact_cache.keys()) == ['key1', 'key2', 'key3']
    fact_cache.__delitem__('key1')
    assert sorted(fact_cache.keys()) == ['key2', 'key3']

# Generated at 2022-06-21 09:31:35.577057
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()

# Generated at 2022-06-21 09:31:41.123490
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache=FactCache()
    fact_cache['key']='value'
    assert fact_cache.__contains__('key')==True
    fact_cache.__delitem__('key')
    assert fact_cache.__contains__('key')==False


# Generated at 2022-06-21 09:31:43.638931
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    facts = FactCache()
    facts['bar'] = 'baz'
    assert 'bar' in facts
    assert 'foo' not in facts


# Generated at 2022-06-21 09:31:45.884302
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fact_cache = FactCache()
    iter_result = fact_cache.__iter__()
    assert type(iter_result) == type(iter([]))

# Generated at 2022-06-21 09:31:49.498941
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fc = FactCache()
    fc['1'] = (1,2)
    fc['2'] = (2,3)
    assert len(fc) == 2
    assert fc.copy() == {'1': (1, 2), '2': (2, 3)}

# Generated at 2022-06-21 09:31:56.931076
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    # Initialize the object FactCache with a empty dict
    fact_cache = FactCache({})
    assert len(fact_cache) == 0

    # Set an item into the object
    fact_cache['test_key'] = 'test_value'
    assert len(fact_cache) == 1

    # Delete an item in the object
    del fact_cache['test_key']
    assert len(fact_cache) == 0


# Generated at 2022-06-21 09:31:58.785567
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():

    # Create the object
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)

    # Return the object's contains key
    assert fact_cache.__contains__('test') == False


# Generated at 2022-06-21 09:32:32.200996
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    try:
        FactCache_keys = FactCache()
        keys = FactCache_keys.keys()
        print(keys)
    except AnsibleError as e:
        print(e.message)
        pass


# Generated at 2022-06-21 09:32:32.812503
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    pass

# Generated at 2022-06-21 09:32:39.125588
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    def __init__(self, *args, **kwargs):
        self.data = {"a": 1, "b": 2}
    cache_loader.get = lambda x: __init__
    assert FactCache().__getitem__("a") == 1
    assert FactCache().__getitem__("b") == 2
    try:
        FactCache().__getitem__("c")
    except KeyError:
        assert True
    else:
        assert False


# Generated at 2022-06-21 09:32:49.308307
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    """Tests the first_order_merge method of the fact cache class to ensure
    that the cache is correctly updated.
    """
    facts = {"name": "Ansible is awesome"}
    cache = FactCache()

    cache.first_order_merge("server1", facts)
    assert cache["server1"] == {"name": "Ansible is awesome"}

    cache.first_order_merge("server1", {"name": "Ansible is even more awesome"},)
    assert cache["server1"] == {"name": "Ansible is even more awesome"}

    cache.first_order_merge("server2", facts)
    assert cache["server2"] == {"name": "Ansible is awesome"}


if __name__ == '__main__':
    import pytest

# Generated at 2022-06-21 09:33:01.586024
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    f = FactCache()

    # Test first host
    key = 'example.com'
    value = {'another_fact': 'value'}
    f.first_order_merge(key, value)
    assert f[key] == value

    # Test second host
    key = 'other.example.com'
    value = {'dummy_fact': 'dummy_value'}
    f.first_order_merge(key, value)
    assert f[key] == value

    # Test merge with first host
    key = 'example.com'
    value = {'another_fact': 'other_value'}
    f.first_order_merge(key, value)
    assert f[key] == {'another_fact': 'other_value', 'dummy_fact': 'dummy_value'}

# Generated at 2022-06-21 09:33:05.283079
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fc = FactCache()
    fc['key'] = {'test': 'value'}
    assert 'key' in fc
    del(fc['key'])


# Generated at 2022-06-21 09:33:10.629815
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    cache = FactCache()
    cache.update({'foo': 'bar1', 'bar': 'foo2'})
    assert len(cache) == 2
    assert len(cache.keys()) == 2
    cache.flush()
    assert len(cache) == 0
    assert len(cache.keys()) == 0


# Generated at 2022-06-21 09:33:12.739568
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()

    assert (
        fc.__class__.__name__ == 'FactCache'
    )

# Generated at 2022-06-21 09:33:17.161769
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.plugins.loader import cache_loader
    from ansible.utils.display import Display

    m = FactCache()
    assert isinstance(m, MutableMapping)

# Generated at 2022-06-21 09:33:20.444148
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fc = FactCache()
    fc.__setitem__("a", "b")
    assert fc.copy().get("a") == "b"

# Generated at 2022-06-21 09:34:31.930977
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    sum_len = 0
    # Initialize the fact cache plugin
    fact_cache._plugin.flush()
    # Add 100 host facts to fact cache
    for i in range(1, 100):
        host_name = "test-%s" % i
        host_cache = {}
        fact_cache.first_order_merge(host_name, host_cache)
    # Calculate the length of the fact cache
    for i in range(1, 100):
        host_name = "test-%s" % i
        host_fact = fact_cache[host_name]
        sum_len += len(host_fact)
    assert (len(fact_cache) == sum_len)


# Generated at 2022-06-21 09:34:33.852353
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    fact_cache['foo'] = 'bar'
    assert len(fact_cache) == 1



# Generated at 2022-06-21 09:34:47.104832
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    import os
    import tempfile

    C.CACHE_PLUGIN = 'jsonfile'
    C.CACHE_PLUGIN_CONNECTION = None
    C.CACHE_PLUGIN_PREFIX = None
    C.DEFAULT_CACHE_PLUGIN_TIMEOUT = 60

    items = {
        '1': {
            'ansible_facts': {
                'a': 1,
                'b': 2
            }
        },

        '2': {
            'ansible_facts': {
                'c': 3,
                'd': 4
            }
        }
    }

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-21 09:34:59.051316
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    display.verbosity = 3
    plugin = cache_loader.get(C.CACHE_PLUGIN)
    plugin.setup()
    path = plugin.get_basedir()
    path = path + "/ansible_facts"
    print("\nbasedir: {}\n".format(path))
    test_object = FactCache()
    for i in range(1, 10):
        test_object.__setitem__("key_{}".format(i), "value_{}".format(i))
    for i in range(1, 10):
        test_object.__contains__("key_{}".format(i))
        test_object.__contains__("wrong_key")
    plugin.flush()
    plugin.teardown()
    print("\nTest __contains__: OK")

# Unit test

# Generated at 2022-06-21 09:34:59.553980
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    pass



# Generated at 2022-06-21 09:35:03.638664
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    fact_cache['host_name'] = "foo"
    assert fact_cache['host_name'] == "foo"
    fact_cache_copy = fact_cache.copy()
    assert fact_cache.__len__() == fact_cache_copy.__len__()
    assert fact_cache_copy['host_name'] == "foo"
    assert fact_cache.copy()['host_name'] == "foo"

# Generated at 2022-06-21 09:35:04.364727
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    FactCache().__len__()



# Generated at 2022-06-21 09:35:07.517254
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fd = FactCache();
    fd['A'] = 'a'
    assert fd['A'] == 'a'
    del fd['A']
    try:
        assert fd['A'] == 'a'
    except KeyError:
        pass



# Generated at 2022-06-21 09:35:19.921743
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    # create the _plugin object for testing
    class _plugin:
        def __init__(self):
            self.cache = {}
            self.keys = []

        def flush(self):
            self.cache = {}
            self.keys = []

        def get(self, key):
            return self.cache[key]

        def set(self, key, value):
            self.cache[key] = value

        def delete(self, key):
            self.cache.pop(key, None)

        def contains(self, key):
            return key in self.cache

        def keys(self):
            return self.cache.keys()

    # mocking the global cache_loader of the cache_plugin.py
    original_cache_loader = cache_loader.__dict__.get('_fact_cache')
    fact_cache = FactCache

# Generated at 2022-06-21 09:35:32.126059
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    from ansible.vars.fact_cache import FactCache
    from ansible.vars.facts import Facts
    fc = FactCache()
    fc_host = FactCache()

    facts = Facts(dict(hostvars=fc))
    facts_host = Facts(dict(hostvars=fc_host))

    gvar = {u"ansible_kernel": u"2.6.32-431.el6.x86_64"}
    gvar_updated = {u"ansible_kernel": u"3.0.0-1025-aws"}