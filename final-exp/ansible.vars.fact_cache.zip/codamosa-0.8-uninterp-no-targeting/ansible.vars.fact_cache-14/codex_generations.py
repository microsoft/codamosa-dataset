

# Generated at 2022-06-21 09:27:14.908959
# Unit test for constructor of class FactCache
def test_FactCache():
    # No cache plugin
    # TODO(akrivoka): Remove the variable check since it will always fail.
    try:
        fact_cache = FactCache()
    except Exception as e:
        assert(isinstance(e, AnsibleError))
        assert(e.message == 'Unable to load the facts cache plugin (memory).')

    # With a valid cache plugin
    C.CACHE_PLUGIN = 'jsonfile'
    fact_cache = FactCache()
    assert(fact_cache._plugin.name == 'JSON file')



# Generated at 2022-06-21 09:27:16.158794
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    hc = FactCache()
    assert hc['h'] == {'h': 'h'}


# Generated at 2022-06-21 09:27:26.441500
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.cache import _facts_cache
    from ansible.utils.path import unfrackpath

    setup_cache = _facts_cache.FactCache()
    setup_cache['test-host'] = {u'a': u'b', u'c': u'd'}
    setup_cache['test-host2'] = {u'a': u'f', u'e': u'g'}

    fc = _facts_cache.FactCache()
    fc[u'test-host'] = {u'a': u'b', u'c': u'e'}

    yaml_path = unfrackpath(u'$HOME/.ansible/facts')

# Generated at 2022-06-21 09:27:28.342469
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    plugin = cache_loader.get(C.CACHE_PLUGIN)
    cache = FactCache(plugin)

    cache['some_key'] = 'some_value'

    assert cache['some_key'] == 'some_value'


# Generated at 2022-06-21 09:27:31.427065
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    obj = FactCache()
    key = "test"
    obj.__contains__(key)
    obj._plugin.contains(key)


# Generated at 2022-06-21 09:27:34.884096
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    cache = FactCache()
    cache['test_key'] = 'test_value'
    assert cache['test_key'] == 'test_value'
    cache.flush()
    assert 'test_key' not in cache

# Generated at 2022-06-21 09:27:36.103906
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():

    from ansible.plugins.cache import FactCache

    fc = FactCache()

    assert fc.__getitem__("test_key") == 'test_value'


# Generated at 2022-06-21 09:27:46.671058
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    # Test case #1:
    #   Test exception raising.
    # Test setup:
    class TestFactCache1(FactCache):
        def __init__(self, *args, **kwargs):
            pass
    test_fact_cache1 = TestFactCache1()

    try:
        # Test action:
        test_fact_cache1.__len__()
        assert False
    except:
        # Test assertion:
        pass

    # Test case #2:
    #   Test exception raising.
    # Test setup:
    class TestFactCache2(FactCache):
        def __init__(self, *args, **kwargs):
            self._plugin = None
    test_fact_cache2 = TestFactCache2()


# Generated at 2022-06-21 09:27:50.414082
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    try:
        fact_cache.keys()
    except NotImplementedError:
        pass
    else:
        raise AssertionError('AnsibleError not raised')

# Generated at 2022-06-21 09:27:52.251246
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    test_factcache = FactCache()
    assert test_factcache.keys() == ["127.0.0.1"]

# Generated at 2022-06-21 09:27:56.499099
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    test_fc = FactCache()
    assert test_fc.keys() == None

# Generated at 2022-06-21 09:28:01.568312
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    def clear_cache():
        cache.flush()

    def test_get_item():
        assert cache['test key'] == 'test value'

    cache = FactCache()
    cache['test key'] = 'test value'
    clear_cache()
    try:
        test_get_item()
        assert False
    except KeyError as e:
        assert isinstance(e, KeyError)



# Generated at 2022-06-21 09:28:03.274051
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    print("")
    print("***Testing***")
    print("test_FactCache___contains__()")
    print("")


# Generated at 2022-06-21 09:28:06.808803
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    from ansible.module_utils.facts.cache import FactCache
    f = FactCache()
    f["test"] = 'test'
    del f['test']
    assert not f._plugin.contains('test')


# Generated at 2022-06-21 09:28:16.668678
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    import tempfile
    import os
    import json
    from ansible.utils.path import unfrackpath

    fixture_json = {
        "ansible_facts": {
            "fact1": "value1",
            "fact2": "value2"
        },
        "ansible_local": {
            "fact3": "value3"
        },
        "ansible_system": {}
    }

    cache = FactCache()

    # create cache file
    cachefile = tempfile.mkstemp()[1]

# Generated at 2022-06-21 09:28:27.019360
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    from ansible.plugins.cache import dummy
    from ansible.module_utils.common._collections_compat import MutableMapping
    import os

    dummy_config = dict(dummy.DummyCacheModule.config_opts, **{'fact_caching': "jsonfile"})
    dummy_config = dict(dummy.DummyCacheModule.config_opts, **{'fact_caching_connection': os.path.join(C.DEFAULT_LOCAL_TMP, 'facts')})
    dummy_config = dict(dummy.DummyCacheModule.config_opts, **{'fact_caching_timeout': 0})
    dummy_config = dict(dummy.DummyCacheModule.config_opts, **{'fact_caching_prefix': 'foo'})

# Generated at 2022-06-21 09:28:32.078619
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fc = FactCache()
    try:
        cache_loader.get('jsonfile')
    except ImportError as e:
        display.warning("Error loading jsonfile cache plugin: {0}".format(e))
        return
    fc._plugin = cache_loader.get('jsonfile')
    from json import dumps
    from tempfile import mkstemp
    from os import remove, close
    from os.path import exists
    from ansible.errors import AnsibleError

    # Create a temporary file in an attempt to cache the facts for a remote host
    fd, temp_path = mkstemp()
    close(fd)
    if exists(temp_path):
        remove(temp_path)
    fc._plugin.set("localhost", dumps({'ansible_facts': {}}))

    # While the temp file exists, delete it

# Generated at 2022-06-21 09:28:36.412298
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    cache = FactCache()
    cache['test'] = 123
    assert 'test' in cache
    assert len(cache) == 1
    cache.__delitem__('test')
    assert 'test' not in cache
    assert len(cache) == 0



# Generated at 2022-06-21 09:28:39.126244
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    fact_cache['test_key'] = 'test_value'
    copy = fact_cache.copy()
    assert copy['test_key'] == 'test_value'

# Generated at 2022-06-21 09:28:41.462083
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)
    assert fact_cache.copy() == {}

# Generated at 2022-06-21 09:28:59.082224
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    # Testing method __contains__ of class FactCache with arguments:
    # args (str), kwargs:
    # Testing with argument args:
    # str arg1 (value unknown)
    cache = FactCache()
    assert not cache._plugin.contains(1)

    dict = {1: "one", 2: "two"}
    assert not cache._plugin.contains(dict)

    assert not cache._plugin.contains(None)

    # Testing with argument args:
    # str arg1 (value known)
    assert not cache._plugin.contains("1")

    # Testing method __contains__ of class CachePlugin with arguments:
    # args (str, str), kwargs:
    # Testing with argument args:
    # str arg1 (value unknown)
    # str arg2 (value unknown)
    assert not cache._

# Generated at 2022-06-21 09:29:09.749228
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    host_key = "host_key"
    host_value = {'key1': 'val1', 'key2': 'val2'}
    host_value1 = {'key2': 'val3', 'key3': 'val4'}
    host_value2 = {'key1': 'val1', 'key2': 'val3', 'key3': 'val4'}

    fact_cache = FactCache()
    fact_cache.first_order_merge(host_key, host_value)
    assert fact_cache[host_key] == host_value

    fact_cache.first_order_merge(host_key, host_value1)
    assert fact_cache[host_key] == host_value2


# Generated at 2022-06-21 09:29:11.955745
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    facts_cache = FactCache()
    hasattr(facts_cache, '__len__')
    len(facts_cache) == 0


# Generated at 2022-06-21 09:29:19.429547
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fc = FactCache()
    fc['key1'] = 'value1'
    fc['key2'] = 'value2'

    assert 'key1' in fc
    assert 'key2' in fc
    assert len(fc) == 2

    fc.flush()

    assert 'key1' not in fc
    assert 'key2' not in fc
    assert len(fc) == 0



# Generated at 2022-06-21 09:29:22.261686
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    assert hasattr(FactCache, 'flush')
    assert callable(getattr(FactCache, 'flush'))


# Generated at 2022-06-21 09:29:24.355321
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    cache = FactCache()
    cache["test"] = 1
    assert cache["test"] == 1


# Generated at 2022-06-21 09:29:32.601143
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fake_plugin = {'ansible_facts':{'ansible_foo':'bar'}}
    test_obj = FactCache()
    test_obj._plugin = fake_plugin
    result = test_obj.__getitem__('ansible_facts')
    assert result == {'ansible_foo':'bar'}
    result = test_obj.__getitem__('ansible_host')
    assert result == Exception


# Generated at 2022-06-21 09:29:36.873413
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    plugin = cache_loader.get('memory')
    cache = FactCache()
    cache._plugin = plugin

    host = 'host'
    plugin.set(host, dict())

    cache_keys = cache.keys()
    assert host in cache_keys

# Generated at 2022-06-21 09:29:39.077687
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    class DummyPlugin:
        def __init__(self):
            self._cache = {"a":"aa", "b":"bb", "c":"cc"}

        def keys(self):
            return self._cache.keys()

    cp = DummyPlugin()
    fc = FactCache(plugin=cp)
    assert 3 == len(fc.keys())



# Generated at 2022-06-21 09:29:41.934896
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    cache = FactCache()
    cache['foo'] = 'bar'
    assert cache['foo'] == 'bar'
    del cache['foo']
    assert cache['foo'] != 'bar'


# Generated at 2022-06-21 09:29:52.727738
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fact_cache = FactCache()

    fact_cache['hostname'] = {'hostname': 'test.example.com'}

    expected_results = {'hostname': {'hostname': 'test.example.com'}}
    assert fact_cache['hostname'] == expected_results


# Generated at 2022-06-21 09:29:55.473032
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    cache = FactCache()
    cache.first_order_merge('example.com', {'key1': 'value1'})
    cache.flush()
    assert 'example.com' not in cache

# Generated at 2022-06-21 09:30:00.798111
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    factCache = FactCache()
    factCache.__setitem__('key1', 'value1')
    factCache.__setitem__('key2', 'value2')
    assert 'key1' in factCache.keys()
    assert 'key2' in factCache.keys()
    assert len(factCache.keys()) == 2


# Generated at 2022-06-21 09:30:10.681711
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts import get_data_loader


    fact_data = get_data_loader()
    fact_data.add_directory(
        os.path.join(os.path.dirname(__file__), 'files'),
        'facts'
    )
    facts = Facts(fact_data, None, [])

    facts.populate()
    keys = list(facts.cache)
    assert keys
    facts.cache._plugin.flush()

    assert not facts.cache.keys()

    # Flush should remove the cache file
    assert not os.path.exists(facts.cache._plugin._cache_file)

# Generated at 2022-06-21 09:30:20.384329
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    facts = {'facts': {'ansible_all_ipv4_addresses': ['172.16.0.4', '172.16.0.5', '172.16.0.7', '10.0.2.15'],
                         'ansible_apparmor': {'status': 'disabled'}}}
    new_obj = FactCache()
    new_obj.update(facts)
    assert 'facts' in dict(new_obj)
    assert '172.16.0.4' in new_obj['facts']["ansible_all_ipv4_addresses"]

# Generated at 2022-06-21 09:30:24.974504
# Unit test for method keys of class FactCache
def test_FactCache_keys():

    faketools = FakeCacheTools()
    fakeplugin = FakePlugin()
    fakeplugin.tools = faketools
    fact_cache = FactCache()
    fact_cache._plugin = fakeplugin

    # Testing with a list of keys that exist
    assert fact_cache.keys() == ['alpha', 'beta']



# Generated at 2022-06-21 09:30:27.796660
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    facts_cache = FactCache()
    fact_cache = facts_cache[('localhost',)]
    fact_cache['test_key'] = 'test_value'
    assert len(facts_cache) == 1


# Generated at 2022-06-21 09:30:30.895166
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    fact_cache['localhost'] = {'1': 'a'}
    fact_cache['host1'] = {'2': 'b'}
    fact_cache['host2'] = {'3': 'c'}
    assert len(fact_cache.keys()) == 3

# Generated at 2022-06-21 09:30:41.574769
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    cache = FactCache()
    assert cache.keys() == []

    # Write a new item
    test_key = 'test_key'
    test_value = 'this is a test'
    cache.__setitem__(test_key, test_value)
    assert cache.keys() == [test_key]
    assert cache.__getitem__(test_key) == test_value

    # Update an existing item
    test_key = 'test_key'
    test_value = 'this is another test'
    cache.__setitem__(test_key, test_value)
    assert cache.keys() == [test_key]
    assert cache.__getitem__(test_key) == test_value


# Generated at 2022-06-21 09:30:45.158852
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fc = FactCache()
    assert fc.copy() == {}
    fc = FactCache({'a': 1, 'b': 2})
    assert fc.copy() == {'a': 1, 'b': 2}


# Generated at 2022-06-21 09:31:02.885955
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    # We need to put something in the cache before we can test it.
    # The easiest way is to use the cache created by Ansible.
    from ansible.module_utils.facts.system.distribution import Distribution
    data = Distribution().get_distribution()
    facts = FactCache()
    facts.first_order_merge('127.0.0.1', data)
    host = '127.0.0.1'
    assert host in facts.keys()

# Generated at 2022-06-21 09:31:05.956417
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    cache = FactCache()
    cache['test'] = 'test'
    del cache['test']
    assert 'test' not in cache

# Generated at 2022-06-21 09:31:16.478515
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    """ Unit test for method __setitem__ of class FactCache """
    f = FactCache()
    assert hasattr(f, '_plugin')
    assert f._plugin.__class__.__name__ == 'FactCacheData'
    assert not f._plugin.contains('host_name')
    f['host_name'] = 'test_host'
    assert f._plugin.contains('host_name')
    val = f._plugin.get('host_name')
    assert val == 'test_host'
    assert f['host_name'] == 'test_host'
    f['host_name'] = 'test_host2'
    assert f._plugin.contains('host_name')
    val = f._plugin.get('host_name')
    assert val == 'test_host2'
    assert f['host_name']

# Generated at 2022-06-21 09:31:19.711154
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    factcache = FactCache()
    factcache['a'] = 1
    factcache['b'] = 2
    assert factcache['a'] == 1 and factcache['b'] == 2
    try:
        factcache['c']
        assert False
    except KeyError:
        assert True


# Generated at 2022-06-21 09:31:26.115863
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():

    fake_cache_key = 'fake.hostname'
    fake_cache_value = 'fake.value'
    fake_fact_cache = FactCache()

    fake_fact_cache.__setitem__(fake_cache_key, fake_cache_value)
    fake_fact_cache.__delitem__(fake_cache_key)

    assert fake_fact_cache.__contains__(fake_cache_key) is False
    assert fake_fact_cache.__contains__(fake_cache_key) == False


# Generated at 2022-06-21 09:31:28.035088
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    factcache = FactCache()
    factcache['host1'] = "host_value"
    assert factcache['host1'] == "host_value"


# Generated at 2022-06-21 09:31:39.437872
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():

    from ansible.plugins.loader import cache_loader
    from ansible.plugins.cache import jsonfile
    from ansible.utils.display import Display
    from ansible.constants import CACHE_PLUGIN

    cache_loader.add(CACHE_PLUGIN, jsonfile.CacheModule())
    display = Display()

    my_facts = FactCache()

    # test that a KeyError is raised if the key is not in the cache
    try:
        my_facts['key']
        assert False
    except KeyError:
        pass

    # test that a KeyError is not raised if the key is in the cache
    my_facts['key'] = 'value'
    assert my_facts['key'] == 'value'


# Generated at 2022-06-21 09:31:47.313737
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    host = '127.0.0.2'
    cache = FactCache()
    cache.flush()

    keys = cache.keys()
    assert keys == []
    # add one fact to cache
    cache[host]={'hello': 'world'}
    keys = cache[host]
    assert keys['hello'] == 'world'
    # get the host key
    keys = cache.keys()
    assert keys[0] == host
    # get the fact
    facts = cache[host]
    assert facts['hello'] == 'world'
    # delete one fact from cache
    del cache[host]
    keys = cache.keys()
    assert keys == []

# Generated at 2022-06-21 09:31:52.391180
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    # Initialize fact_cache key and value
    fact_cache = {'_fact_cache': {'test_key': 'test_value'}}

    # Test if fact_cache is deleted after flushing the cache
    fact_cache['_fact_cache'].flush()
    assert '_fact_cache' not in fact_cache



# Generated at 2022-06-21 09:32:03.628397
# Unit test for method copy of class FactCache

# Generated at 2022-06-21 09:32:27.153201
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    pass


# Generated at 2022-06-21 09:32:31.992325
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    fact_cache['name'] = 'Name1'
    fact_cache['name2'] = 'Name2'

    assert fact_cache.keys() == ['name', 'name2']


# Generated at 2022-06-21 09:32:34.863043
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fc = FactCache()
    fc.update({'a': 1, 'b': 2, 'c': 3})
    assert [k for k in fc] == ['a', 'b', 'c']

# Generated at 2022-06-21 09:32:36.154947
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    mc = FactCache()
    assert mc._plugin.flush.called

# Generated at 2022-06-21 09:32:41.303767
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fc = FactCache()
    fc.flush()
    fc["test"] = 1
    fc.__contains__("test")
    fc.__contains__("test2")
    #assert fc.__contains__("test") == True
    #assert fc.__contains__("test2") == False


# Generated at 2022-06-21 09:32:50.707985
# Unit test for method copy of class FactCache
def test_FactCache_copy():

    # Test set up
    class TestFactCache(FactCache):
        def __init__(self, *args, **kwargs):
            self.dic = dict()
        def __getitem__(self, key):
            return self.dic[key]
        def __setitem__(self, key, value):
            self.dic.update({key:value})
        def __delitem__(self, key):
            del self.dic[key]
        def __contains__(self, key):
            if key in self.dic.keys():
                return True
            else:
                return False
        def __iter__(self):
            return self.dic.__iter__()
        def __len__(self):
            return len(self.dic)

# Generated at 2022-06-21 09:32:51.338501
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    assert True

# Generated at 2022-06-21 09:32:59.207070
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    from ansible.plugins.cache import memory
    cache_plugin = memory.CacheModule()
    fact_cache = FactCache()
    fact_cache._plugin = cache_plugin
    fact_cache['foo'] = 'bar'
    cache_plugin.flush()
    fact_cache['foo'] = 'bar'
    fact_cache['foo'] = 'bar'
    assert cache_plugin.contains('foo') is True
    cache_plugin.flush()


# Generated at 2022-06-21 09:33:02.467023
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache_test = FactCache()
    fact_cache_test['fact_key'] = 'fact_value'
    assert fact_cache_test['fact_key'] == 'fact_value'


# Generated at 2022-06-21 09:33:04.442837
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    assert 0



# Generated at 2022-06-21 09:33:33.566558
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    """Test that the facts cache plugin is loaded"""

    fact_cache_plugin = FactCache()
    fact_cache_plugin['galaxy'] = 'ansible'
    assert fact_cache_plugin == {'galaxy': 'ansible'}



# Generated at 2022-06-21 09:33:39.187272
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():

    # Test with a cache plugin which supports __len__
    display.verbosity = 3
    constants_dict = {'cache_plugin': 'jsonfile'}

    # Save previous C.CACHE_PLUGIN value
    previous_value = getattr(C, 'CACHE_PLUGIN', None)
    C.CACHE_PLUGIN = constan

# Generated at 2022-06-21 09:33:40.084861
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    pass


# Generated at 2022-06-21 09:33:46.795880
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    import json
    from ansible.plugins.cache import test_cache
    from ansible.parsing.yaml import objects

    test_cache_plugin = test_cache.TestCachePlugin()
    test_cache_plugin._options['test_cache_plugin'] = json.dumps(test_cache_plugin._options)

    fact_cache = FactCache()
    fact_cache._plugin = test_cache_plugin

    test_cache_plugin.set('test_fact_key', {'test_fact': 'test_fact_value'})
    assert fact_cache['test_fact_key'] == {'test_fact': objects.AnsibleUnicode('test_fact_value')}


# Generated at 2022-06-21 09:33:49.889833
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    f = FactCache()
    f['1'] = 2
    assert('1' in f)
    del f['1']
    assert('1' not in f)

# Generated at 2022-06-21 09:33:50.624640
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    assert True

# Generated at 2022-06-21 09:34:01.961002
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    my_hosts = ['localhost', 'localhost']
    my_host = 'localhost'
    my_hostvars = dict(ansible_connection='local', ansible_python_interpreter='/usr/bin/python')

    inventory = InventoryManager(loader=None, sources=my_hosts)
    variable_manager = VariableManager(loader=None, inventory=inventory)
    variable_manager._hostvars = my_hostvars

    play_context = PlayContext()
    play_context.network_os = 'default'
    play_context._variable_manager = variable_manager

    display.verbosity = 4


# Generated at 2022-06-21 09:34:05.571542
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    # FIXME: this method is a stub
    # assert False, 'This method is a stub!'
    pass


# Generated at 2022-06-21 09:34:11.056430
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    fact_cache['127.0.0.1'] = ["1","2"]
    fact_cache['127.0.0.2'] = ["3","4"]
    assert fact_cache.keys() == ['127.0.0.2','127.0.0.1']


# Generated at 2022-06-21 09:34:20.329623
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    # Create a copy of the current env vars, so we can restore them later
    save_dict = dict(C.__dict__)

    try:
        # Modify the env vars declared in constants.py
        C.CACHE_PLUGIN = "memory" # Force in-memory cache

        # Create a cache object
        fc = FactCache()
        # Add a few keys
        fc["foo"] = "bar"
        fc["quz"] = "qux"
        fc["number"] = 1
        # Flush it
        fc.flush()

        # Check if the cache is empty
        assert len(fc) == 0
    finally:
        # Restore original env vars
        for key, value in save_dict.items():
            C.__dict__[key] = value

# Unit test

# Generated at 2022-06-21 09:35:18.464996
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    test_case_facts = {'facts': {'first': '1', 'second': '2'}, 'host': 'localhost'}
    test_case_cache = {'host': 'localhost', 'facts': {'first': '1', 'second': '2'}}

    c = FactCache()
    c.first_order_merge(test_case_facts['host'], test_case_facts['facts'])

    assert c.keys() == test_case_cache.keys()
    assert c[test_case_cache['host']] == test_case_cache['facts']
    c.flush()


# Generated at 2022-06-21 09:35:19.211466
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    assert(False)

# Generated at 2022-06-21 09:35:25.354241
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    """Test if python module cache keys are valid."""
    cache = FactCache()
    cache['foo'] = 'bar'
    cache['baz'] = 'qux'
    cache['quux'] = 'corge'

    actual = cache.copy()

    assert actual == {'foo': 'bar', 'baz': 'qux', 'quux': 'corge'}

# Generated at 2022-06-21 09:35:27.210411
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    assert fact_cache.keys() == ['localhost']

# Generated at 2022-06-21 09:35:34.972361
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    key = "hostname"
    value = "myhost"
    fact_cache = FactCache()
    fact_cache[key] = value
    fact_cache_copy = fact_cache.copy()

    assert fact_cache_copy[key] == fact_cache[key], "fact_cache." + key + " and fact_cache_copy." + key + " do not have the same value."
    assert fact_cache_copy == fact_cache, "fact_cache_copy and fact_cache do not have the same elements."

# Generated at 2022-06-21 09:35:38.363385
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    class test_Fact():
        def __init__(self):
            self._plugin = {'a':'b'}
            self._plugin.keys = lambda : ['a', 'b']

    a = test_Fact()
    assert len(a) == 2


# Generated at 2022-06-21 09:35:41.622171
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    cache = FactCache()
    cache.add = lambda a,b: None 
    cache._plugin.keys = lambda a: [1,2,3]
    assert list(cache.__iter__()) == [1,2,3] 


# Generated at 2022-06-21 09:35:44.146855
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    assert len(fact_cache) == 0

    fact_cache['localhost'] = {}
    assert len(fact_cache) == 1



# Generated at 2022-06-21 09:35:49.992981
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    test_plugin = DummyPlugin()
    factcache = FactCache()
    factcache._plugin = test_plugin
    # test with key present
    factcache.__setitem__('key1', 'old value')
    assert 'key1' in factcache
    assert factcache['key1'] == 'old value'
    factcache.flush()
    assert 'key1' not in factcache
    # test without key present
    assert 'key2' not in factcache
    factcache.flush()
    assert 'key2' not in factcache



# Generated at 2022-06-21 09:35:52.582933
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    cache = FactCache()
    cache['test'] = {'1': '2'}
    assert cache['test'] == {'1': '2'}
    assert cache.copy() == {'test': {'1': '2'}}
