

# Generated at 2022-06-21 09:27:14.289919
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache(plugin='memory')

    key_no_nest = 'test_key_no_nest'
    value_no_nest = 'test_value_no_nest'

    first_order_merge_no_nest_input = {key_no_nest: value_no_nest}

    key_nest = 'test_key_nest'
    value_nest = {'test_key1': 'test_value1', 'test_key2': 'test_value2'}
    first_order_merge_nest_input = {key_nest: value_nest}

    result = fc.first_order_merge(key_no_nest, value_no_nest)
    assert result == first_order_merge_no_nest_input

# Generated at 2022-06-21 09:27:15.304848
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    k = FactCache()
    assert isinstance(k.keys(), list)

# Generated at 2022-06-21 09:27:16.399573
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    assert not FactCache().__contains__('whatever')


# Generated at 2022-06-21 09:27:19.578876
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    # Init
    fc = FactCache()
    # Test when the cache is empty
    assert len(fc) == 0

    fc[0] = 'foo'
    # Test when the cache is not empty
    assert len(fc) == 1


# Generated at 2022-06-21 09:27:27.280756
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    # Initialization of the variable used by the test
    key = 'var'
    value = 'value'
    # Initialization of the variable used by the test
    # Call the tested method
    fact_cache = FactCache( )
    fact_cache.__setitem__(key, value)
    # Test that the method called is the one from the AnsibleMock
    # Test that the method called is the one from the AnsibleMock
    assert fact_cache._plugin.set.call_count == 1


# Generated at 2022-06-21 09:27:28.377351
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert(fc)

# Generated at 2022-06-21 09:27:29.611998
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()



# Generated at 2022-06-21 09:27:31.209996
# Unit test for constructor of class FactCache
def test_FactCache():
    fac = FactCache()
    assert not 'localhost' in fac

# Generated at 2022-06-21 09:27:40.651209
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    try:
        import __builtin__
    except ImportError:
        # python3
        import builtins as __builtin__

# Generated at 2022-06-21 09:27:52.901101
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    from ansible.module_utils.facts.utils import FactsDict
    cache = FactCache()
    cache.first_order_merge(
        'localhost',
        FactsDict(
            {
                'fact_1': 'value_1',
                'fact_2': 'value_2',
                'fact_3': 'value_3',
                'fact_4': 'value_4',
            }
        )
    )
    assert cache['localhost']['fact_1'] == 'value_1'
    cache.first_order_merge(
        'localhost',
        FactsDict(
            {
                'fact_1': 'value_1_new',
                'fact_2': 'value_2',
                'fact_3': 'value_3_new',
            }
        )
    )



# Generated at 2022-06-21 09:27:58.241009
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    factcache = FactCache()
    factcache['test'] = 'testvalue'
    assert factcache['test'] == 'testvalue'
    del factcache['test']
    assert len(factcache) == 0
    assert 'test' not in factcache



# Generated at 2022-06-21 09:28:05.583234
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    factcache = FactCache()
    factcache["key1"] = {"x":"x1", "y":"y2", "z":"z3"}
    factcache["key2"] = {"x":"x2", "y":"y2", "z":"z2"}
    factcache.first_order_merge("key1", {"x":"x1", "y":"y3", "z":"z3"})
    factcache.first_order_merge("key2", {"x":"x2", "y":"y3", "z":"z3"})
    assert factcache["key1"] == {"x":"x1", "y":"y3", "z":"z3"}, "First order merge did not work on factcache"

# Generated at 2022-06-21 09:28:08.925608
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    fact_cache.keys = lambda : [1, 2, 3]
    assert len(fact_cache) == 3


# Generated at 2022-06-21 09:28:12.491583
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    ff = FactCache()

    ff['test'] = True
    ff['test2'] = True

    assert True == ff['test']
    assert True == ff['test2']

    ff.flush()

    assert not ff.keys()

# Generated at 2022-06-21 09:28:15.395564
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    # Test expected use
    fact_cache = FactCache()
    fact_cache.__delitem__(None)


# Generated at 2022-06-21 09:28:18.179628
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    m = FactCache()
    m['key'] = 'value'
    assert m['key'] == 'value'



# Generated at 2022-06-21 09:28:28.151158
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    # Test without any arguments
    fact_cache = FactCache()
    assert fact_cache.keys() == []

    # Test with arguments

# Generated at 2022-06-21 09:28:40.102389
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    def _test(self, key, value):
        """
        Unit test for method first_order_merge of class FactCache
        :param self:
        :param key:
        :param value:
        :return:
        """
        #Here we use the redis cache plugin to test the method.
        #In the method,we suppose the cache plugin has method get,set,delete and contains,
        # and it will raise KeyError when key is not exist.
        cache = FactCache(C.CACHE_PLUGIN)

        #use the value replace the old value of host
        cache.__setitem__(key, {'old_key':'old_value'})
        cache.first_order_merge(key, value)
        assert value == cache[key]

        #use the new value instead of the old value to merge

# Generated at 2022-06-21 09:28:41.713539
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fact_cache = FactCache()
    assert fact_cache["a"] == None


# Generated at 2022-06-21 09:28:43.852556
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fc = FactCache()
    fc['foo'] = 'bar'
    assert len(fc) == 1
    fc.flush()
    assert len(fc) == 0

# Generated at 2022-06-21 09:28:54.644453
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    test_FactCache = FactCache()
    test_FactCache._plugin.contains = MagicMock()
    test_FactCache._plugin.contains.return_value = True
    assert test_FactCache.__contains__('ansible_distribution_version') == True


# Generated at 2022-06-21 09:28:59.080457
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    fact_cache['foo'] = 'bar'
    fact_cache['bar'] = 'foo'
    assert fact_cache.copy() == {'foo': 'bar', 'bar': 'foo'}

# Generated at 2022-06-21 09:29:10.427897
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    from ansible.module_utils.common._collections_compat import MutableMapping
    fc = FactCache(a=1, b=2, c=3)
    assert isinstance(fc, MutableMapping)
    assert [x for x in fc] == ["a", "b", "c"]
    assert len(fc) == 3
    assert fc["a"] == 1
    assert fc["b"] == 2
    assert fc["c"] == 3
    assert "a" in fc
    assert "d" not in fc

    # Test updates
    fc["b"] = 42
    assert fc["b"] == 42
    assert 3 in fc.values()
    assert 42 in fc.values()
    fc.update({"c": 4, "d": "foo"})

# Generated at 2022-06-21 09:29:11.607768
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    factcache = FactCache()
    factcache.flush()

# Generated at 2022-06-21 09:29:16.359315
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    class Plugin:
        def keys(self):
            return [1,2,3]

    fact_cache = FactCache()
    fact_cache._plugin = Plugin()
    assert list(fact_cache.__iter__()) == [1,2,3]


# Generated at 2022-06-21 09:29:21.078819
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    import pytest
    from ansible.module_utils.common._collections_compat import MutableMapping

    fc = FactCache()
    with pytest.raises(AnsibleError):
        fc['key']
    assert isinstance(fc, MutableMapping)


# Generated at 2022-06-21 09:29:26.342477
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    '''
    Unit test for method __iter__ of class FactCache
    '''
    fact_cache = FactCache()
    test_values = ['test_value']
    fact_cache.__setitem__("test_key", test_values)

    assert fact_cache.__contains__("test_key") is True
    assert len(list(fact_cache.__iter__())) == 1


# Generated at 2022-06-21 09:29:29.754480
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    test_cache = FactCache()
    try:
        test_cache['test']
        assert False
    except KeyError:
        pass


# Generated at 2022-06-21 09:29:31.018837
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    pass

# Generated at 2022-06-21 09:29:41.931836
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    import os
    import shutil
    import tempfile
    import unittest

    class TestFactCacheKeys(unittest.TestCase):
        """
        Test class to test keys method of class FactCache
        """

        CACHE_DIR = None

        @classmethod
        def setUpClass(cls):
            cls.CACHE_DIR = tempfile.mkdtemp()

        def setUp(self):
            # Create a plugin
            C.CACHE_PLUGIN_CONNECTION = 'local'
            C.CACHE_PLUGIN = 'jsonfile'
            C.CACHE_PLUGIN_PREFIX = 'ansible_fact_'
            C.CACHE_PLUGIN_TIMEOUT = 604800  # One Week
            C.CACHE_PLUGIN

# Generated at 2022-06-21 09:29:56.967097
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    facts_cache = FactCache()
    expected_facts = {'key': {'fact1': True, 'fact2': False, 'fact3': 'new_value'}}
    facts_cache.first_order_merge('key', {'fact1': True, 'fact2': False, 'fact3': 'value'})
    facts_cache.first_order_merge('key', {'fact3': 'new_value'})
    # Do not use assertDictContainsSubset because it is deprecated
    assert expected_facts['key'] == facts_cache['key']

# Generated at 2022-06-21 09:30:01.437020
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    test_fact_cache = FactCache()
    test_fact_cache['test_host'] = {"test": "value"}
    assert len(test_fact_cache) == 1
    test_fact_cache.flush()
    assert len(test_fact_cache) == 0

# Generated at 2022-06-21 09:30:06.293612
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    fact_cache["test_key"] = "test_value"
    assert "test_key" in fact_cache
    assert fact_cache["test_key"] == "test_value"
    del fact_cache["test_key"]
    assert "test_key" not in fact_cache

# Generated at 2022-06-21 09:30:14.965367
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    key = 'test_key'
    value = 'test_value'

    fact_cache = FactCache()

    assert len(fact_cache) == 0
    fact_cache[key] = value

    assert len(fact_cache) == 1
    assert len(fact_cache.keys()) == 1
    assert key in fact_cache.keys()
    assert len([key for key in fact_cache.keys() if key in fact_cache]) == 1

    del fact_cache[key]

    assert len(fact_cache) == 0
    assert len(fact_cache.keys()) == 0

# Generated at 2022-06-21 09:30:20.813243
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    from ansible.plugins.cache import fact_cache
    import ansible
    ansible.constants.CACHE_PLUGIN = 'memory'
    cache = fact_cache.FactCache()
    cache.__setitem__('test_key', 'test_value')
    assert cache.__len__() == 1


# Generated at 2022-06-21 09:30:26.281715
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    key = 'test_key'
    plugin = MockPlugin()
    factcache = FactCache()
    factcache._plugin = plugin
    # Case 1: Plugin contains key
    plugin.contains_return = True
    assert factcache.__contains__(key) == True
    # Case 2: Plugin does not contain key
    plugin.contains_return = False
    assert factcache.__contains__(key) == False


# Generated at 2022-06-21 09:30:28.227919
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fc = FactCache()
    assert 'test' not in fc
    fc['test'] = 'test'
    assert 'test' in fc

# Generated at 2022-06-21 09:30:30.254001
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    try:
        cache = FactCache()
        cache.__getitem__(key=None)
        assert True
    except:
        assert False


# Generated at 2022-06-21 09:30:31.670459
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fc_obj = FactCache()
    fc_obj.__delitem__('key')


# Generated at 2022-06-21 09:30:35.769963
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    class FakePluginWithKeys(object):
        def keys(self):
            return ['key1', 'key2']

    fact_cache = FactCache()
    fact_cache._plugin = FakePluginWithKeys()
    assert ['key1', 'key2'] == fact_cache.keys()


# Generated at 2022-06-21 09:30:58.306845
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()

    cache.first_order_merge('127.0.0.1', {'ansible_facts': {'uptime': 1000, }, })
    cache.first_order_merge('127.0.0.1', {'ansible_facts': {'uptime': 2000, }, })

    assert '127.0.0.1' in cache
    assert cache['127.0.0.1']['ansible_facts']['uptime'] == 1000

# Generated at 2022-06-21 09:31:02.409676
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    f = FactCache()
    f['foo'] = 'bar'
    f['rar'] = 'baz'
    assert len(f.keys()) == 2
    f.flush()
    assert len(f.keys()) == 0

# Generated at 2022-06-21 09:31:05.488636
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    cache = FactCache()
    cache['key'] = 'value'
    assert cache['key'] == 'value'


# Generated at 2022-06-21 09:31:16.092924
# Unit test for constructor of class FactCache
def test_FactCache():
    # Enable the cache
    C.CACHE_PLUGIN = 'jsonfile'
    cache = FactCache()
    cache['a'] = 'hello'
    assert cache['a'] == 'hello'
    cache['a'] = 'something else'
    assert cache['a'] == 'something else'
    cache['a'] = 'hello'
    assert cache['a'] == 'hello'
    del cache['a']
    assert 'a' not in cache
    assert list(iter(cache)) == []
    assert len(cache) == 0
    assert cache.keys() == []
    cache['a'] = 'hello'
    assert cache['a'] == 'hello'
    cache.flush()
    assert list(iter(cache)) == []
    assert cache.keys() == []
    assert len(cache) == 0

# Generated at 2022-06-21 09:31:20.101882
# Unit test for constructor of class FactCache
def test_FactCache():
    cache_path = '/tmp/fact_cache_{}'.format(os.getpid())
    cache_file = '{}/ansible_facts'.format(cache_path)

    cache = FactCache() # pylint: disable=unexpected-keyword-arg
    assert 'localhost' in cache
    os.unlink(cache_file)
    os.rmdir(cache_path)



# Generated at 2022-06-21 09:31:23.488686
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = FactCache()
    fact_cache.__setitem__(key="test_key", value="test_value")
    assert fact_cache._plugin.get("test_key") == "test_value"


# Generated at 2022-06-21 09:31:27.604631
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fc = FactCache()
    # set a key
    fc['testvar'] = 'testvalue'
    # verification key was set
    assert fc._plugin.contains('testvar')
    # flush
    fc.flush()
    # verification key is not set
    assert not fc._plugin.contains('testvar')

# Generated at 2022-06-21 09:31:34.940696
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    import os

    from ansible.plugins.cache import BaseFileCacheModule, BaseDictCacheModule

    # Initialize FactCache with BaseFileCacheModule
    plugin_path = os.path.join(os.path.dirname(__file__), 'cache/test_file_cache.py')
    C.CACHE_PLUGIN = 'TestFileCacheModule'
    C.CACHE_PLUGIN_CONNECTION = plugin_path
    cache_loader.get(C.CACHE_PLUGIN)
    assert isinstance(cache_loader.get(C.CACHE_PLUGIN), BaseFileCacheModule)
    fact_cache = FactCache()
    assert len(fact_cache.keys()) == 0

    # Test keys after add item to FactCache
    fact_cache['test'] = 'test'

# Generated at 2022-06-21 09:31:39.492591
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    """Unit test for method __setitem__ of class FactCache"""
    facts_cache = FactCache()
    facts_cache['a'] = 'b'
    assert facts_cache._plugin._cache['a'] == 'b'

# Generated at 2022-06-21 09:31:42.624634
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    fact_cache['asdf'] = 1
    fact_cache['qwer'] = 2
    assert fact_cache.keys() == ['asdf', 'qwer']

# Generated at 2022-06-21 09:32:16.112531
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    host_facts = {"hostname": "ansible"}
    host_cache = {"hostname": "ansible", "other_fact": "example"}

    fact_cache.first_order_merge("hostname", host_facts)
    assert fact_cache == host_facts

    fact_cache.first_order_merge("hostname", host_facts)
    assert fact_cache == host_cache

# vim: et:sta:bs=2:sw=4:

# Generated at 2022-06-21 09:32:18.756258
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    # create factCache object
    factCache = FactCache()
    # add a fact
    factCache[0] = 0
    # assert __len__ returns 1 for the factCache object
    assert len(factCache) == 1


# Generated at 2022-06-21 09:32:27.877386
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache_plugin = cache_loader.get(C.CACHE_PLUGIN)
    fact_cache_plugin.set('host1', {'foo': 'bar1', 'bar': 'foo1'})
    fact_cache_plugin.set('host2', {'foo': 'bar2', 'bar': 'foo2'})
    fact_cache_plugin.set('host3', {'foo': 'bar3', 'bar': 'foo3'})
    fact_cache = FactCache()
    fact_cache.keys()
    fact_cache.copy()
    fact_cache_plugin.flush()

# Generated at 2022-06-21 09:32:37.620146
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    #Test case 1: passing valid values, expected: no exception should be raised
    import tempfile
    try:
        tempfile.tempdir = '/tmp'
        cache = FactCache()
        cache['a'] = '1'
        cache['b'] = '2'
        cache['c'] = '3'
        for key in cache:
            assert key in cache.keys()
    except Exception as e:
        raise AssertionError('Unexpected Exception raised: {}'.format(e))
    #Test case 2: passing invalid values, expected: exception should be raised
    try:
        cache['a'] = 1/0
    except Exception as e:
        assert 'division by zero' in str(e)


# Generated at 2022-06-21 09:32:48.353264
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    class DictMock(dict):
        def __init__(self, **kwargs):
            super(DictMock, self).__init__(**kwargs)

    class MockCachePlugin:

        def __init__(self):
            self._data = {}

        def contains(self, key):
            return key in self._data

        def get(self, key):
            return self._data[key]

        def set(self, key, value):
            self._data[key] = value

        def delete(self, key):
            del self._data[key]

        def flush(self):
            self._data = {}

        def keys(self):
            return self._data.keys()

    plugin = MockCachePlugin()
    cache = FactCache()
    cache._plugin = plugin


# Generated at 2022-06-21 09:33:00.796175
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    # import pytest to get the parametrize function
    import pytest
    # pytest's parametrize function allows us to generate test data
    # to parametrize the test function
    fct_args = [
        (1, 1),
        (2, 2),
        (3, 3),
        (4, 4),
        (5, 5),
        (6, 6)
    ]

    @pytest.mark.parametrize("input_value,expected_output", fct_args)
    def test_factCache__len__(input_value, expected_output):
        # define class to test
        from ansible.utils.facts import FactCache

        factCache = FactCache()
        assert factCache.__len__() == input_value
    # define function to call
    test_factCache__

# Generated at 2022-06-21 09:33:06.292275
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    test_fact_cache = FactCache()

    test_fact_cache._plugin.keys = lambda : 'test_fact_cache_keys'

    test_result = test_fact_cache.keys()

    assert test_result == 'test_fact_cache_keys'


# Generated at 2022-06-21 09:33:10.881618
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    cache = FactCache()
    assert len(cache) == 0
    assert len(cache._plugin.keys()) == 0
    cache['host1'] = 'host1_facts'
    assert len(cache) == 1
    assert len(cache._plugin.keys()) == 1


# Generated at 2022-06-21 09:33:13.523085
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    c = FactCache()
    c['key1'] = 'value1'
    assert c['key1'] == 'value1'
    c['key1'] = 'value2'
    assert c['key1'] == 'value2'


# Generated at 2022-06-21 09:33:18.426482
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    class Plugin:
        def contains(self, key):
            return True
        def get(self, key):
            return key
    plugin = Plugin()
    fact_cache = FactCache()
    fact_cache._plugin = plugin
    assert fact_cache['test'] == 'test'


# Generated at 2022-06-21 09:34:16.534127
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    pass


# Generated at 2022-06-21 09:34:21.574435
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    __ansible_facts__ = {'test_fact_cache': 1}
    c = FactCache()
    c.__setitem__("test_fact", __ansible_facts__)

    assert("test_fact" in c)
    assert("test_fact" in c.__iter__())
    assert("other_fact" not in c)



# Generated at 2022-06-21 09:34:27.134025
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    cache_plugin = cache_loader.get(C.CACHE_PLUGIN)
    factcache = FactCache()
    cache_plugin.flush()

    assert factcache.__contains__('test') == False

    cache_plugin.set('test', {'test': 'ok'})

    assert factcache.__contains__('test') == True

# Generated at 2022-06-21 09:34:31.651588
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    fact_cache.__setitem__('localhost', {"foo":"bar"})
    fact_cache.__setitem__('127.0.0.1', {"baz":"blah"})
    assert fact_cache.keys() == ['localhost', '127.0.0.1']

# Generated at 2022-06-21 09:34:35.021492
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    # Initialize the object and set up values.
    obj = FactCache()
    obj['key'] = 'value'

    # Test the function
    obj.__delitem__('key')

    # Assert the right value is returned.
    assert_equals(obj, {})


# Generated at 2022-06-21 09:34:47.605118
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    
    fact_cache['host1'] = {'a':1, 'b':2}
    key = 'host1'
    value = {'b':3, 'c':4}
    fact_cache.first_order_merge(key, value)
    assert fact_cache['host1'] == {'a':1, 'b':3, 'c':4}

    fact_cache['host2'] = {'a':1, 'b':2}
    key = 'host2'
    value = {'b':3, 'c':4}
    fact_cache.first_order_merge(key, value)
    assert fact_cache['host2'] == {'a':1, 'b':3, 'c':4}

# Generated at 2022-06-21 09:34:53.134275
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    from ansible.plugins.cache import FactCacheModule
    mObj = FactCacheModule()
    key = "localhost"
    value = {"a": "b"}
    mObj.set(key,value)
    mObj.__delitem__(key)
    assert key not in mObj



# Generated at 2022-06-21 09:34:54.711466
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    assert hasattr(FactCache, '_FactCache__len__')


# Generated at 2022-06-21 09:34:56.782714
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    assert fact_cache.keys(), "should not be empty"


# Generated at 2022-06-21 09:34:58.260991
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    fact_cache.flush()