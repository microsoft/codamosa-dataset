

# Generated at 2022-06-21 09:27:09.264931
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    display.debug("CALLING _contains__ METHOD")
    assert FactCache().__contains__
    assert not FactCache().__contains__


# Generated at 2022-06-21 09:27:12.454284
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    # given an object of class FactCache
    # when we call __getitem__,
    # then an exception should be raised
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_bytes

    cache = FactCache()
    try:
        cache['test']
    except AnsibleError:
        pass
    else:
        raise AssertionError(to_bytes(
            'Expected an exception, got a value instead.'))


# Generated at 2022-06-21 09:27:13.626527
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fc = FactCache()
    assert(iter(fc) == fc._plugin.keys())


# Generated at 2022-06-21 09:27:15.246051
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    # test default
    fc = FactCache()
    fc.data = {'key':'value'}
    assert 'key' in fc


# Generated at 2022-06-21 09:27:20.461832
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    try:
        cache = FactCache()
        cache['a'] = {'a': 'b'}
        cache['b'] = {'a': 'b'}
        cache['c'] = {'a': 'b'}
        assert cache.copy() == {'a': {'a': 'b'}, 'b': {'a': 'b'}, 'c': {'a': 'b'}}
    except KeyError:
        display.display('KeyError', color='red')
        assert False
    except Exception:
        display.display('Exception', color='red')
        assert False
    except:
        display.display('Unknown Error', color='red')
        assert False


if __name__ == '__main__':
    test_FactCache_copy()

# Generated at 2022-06-21 09:27:22.767281
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        test_cache = FactCache()
    except AnsibleError as e:
        print("Error: %s" % e)


# Generated at 2022-06-21 09:27:25.791739
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert isinstance(fc, FactCache)
    assert isinstance(fc, MutableMapping)

# Generated at 2022-06-21 09:27:31.745220
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    assert len(fact_cache) == 0
    fact_cache["1"] = "test"
    assert len(fact_cache) == 1
    fact_cache["2"] = "test1"
    assert len(fact_cache) == 2
    fact_cache.flush()
    assert len(fact_cache) == 0



# Generated at 2022-06-21 09:27:32.837116
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    assert 1 == 1


# Generated at 2022-06-21 09:27:36.672541
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    '''
    Unit test for FactCache.__iter__() method
    '''
    results = FactCache()
    assert isinstance(results, FactCache)

    # Check that __iter__() method returns a list
    assert isinstance(list(results), list)

# Generated at 2022-06-21 09:27:40.093701
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fc = FactCache()
    fc.__setitem__("a", "b")
    assert fc.copy() == {"a": "b"}

# Generated at 2022-06-21 09:27:42.750629
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact = FactCache()
    print('FactCache.__len__: ' + str(fact))
    return fact.__len__()

# Generated at 2022-06-21 09:27:50.511964
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    cache = FactCache()
    try:
        cache_plugin = cache._plugin
    except:
        raise AssertionError('FactCache._plugin is not created correctly')

    try:
        cache["key1"]
        raise AssertionError('Cache key is not existed, it should not return')
    except KeyError:
        pass

    value = "value1"
    cache_plugin.set("key1", value)
    assert cache["key1"] == value


# Generated at 2022-06-21 09:27:51.142333
# Unit test for constructor of class FactCache
def test_FactCache():
    assert FactCache()

# Generated at 2022-06-21 09:27:55.299007
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fc = FactCache()
    fc['host_name_1'] = {'a': 'b'}
    fc['host_name_2'] = {'a': 'b'}
    assert fc.keys() == ['host_name_1', 'host_name_2']

# Generated at 2022-06-21 09:28:02.898984
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    cache_plugin = cache_loader.get(C.CACHE_PLUGIN)
    fc = FactCache()
    fc['a'] = 'A'
    assert fc['a'] == 'A'
    assert len(fc) == 1
    assert 'a' in fc
    assert cache_plugin.contains('a')
    fc.flush()
    assert len(fc) == 0
    assert 'a' not in fc
    assert not cache_plugin.contains('a')

# Generated at 2022-06-21 09:28:04.342486
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fc = FactCache()
    assert fc.__len__() == 0


# Generated at 2022-06-21 09:28:07.565578
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fc = FactCache()
    fc["test"] = {"test": "asd"}
    del fc["test"]
    assert fc.keys() == []



# Generated at 2022-06-21 09:28:10.806009
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fact_cache = FactCache()
    assert True == isinstance(fact_cache, MutableMapping)
    assert True == isinstance(fact_cache.__iter__(), _collections.__iter__)

# Generated at 2022-06-21 09:28:18.690912
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    # Fake in-memory plugin
    class CachePlugin(object):
        def __init__(self):
            self._cache = {}

        def set(self, key, value):
            self._cache[key] = value

        def get(self, key):
            return self._cache[key]

        def delete(self, key):
            del self._cache[key]

        def contains(self, key):
            return key in self._cache

        def keys(self):
            return self._cache.keys()

        def flush(self):
            self._cache.clear()
    fake_plugin = CachePlugin()
    fake_plugin.set('key1', 'value1')
    fake_plugin.set('key2', 'value2')
    fake_plugin.set('key3', 'value3')
    # Stub C.CACHE

# Generated at 2022-06-21 09:28:24.690506
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    key = 'test'
    value = 'test'
    cache.first_order_merge(key, value)

# Generated at 2022-06-21 09:28:32.437246
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    from ansible.errors import AnsibleConnectionFailure
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.connections import NetworkConnection
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.role_include import RoleInclude
    from ansible.utils.path import unfrackpath
    from ansible.vars.manager import VariableManager

    conn = NetworkConnection()

# Generated at 2022-06-21 09:28:38.487960
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    factcache = FactCache()
    factcache['host_01'] = dict(ansible_facts=dict(test_fact=True))
    factcache['host_02'] = dict(ansible_facts=dict(test_fact=False))

    assert factcache.copy() == dict(host_01=dict(ansible_facts=dict(test_fact=True)),
                                    host_02=dict(ansible_facts=dict(test_fact=False)))

# Generated at 2022-06-21 09:28:40.846648
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
  fact_cache = FactCache()
  with pytest.raises(KeyError):
    fact_cache['test_key']


# Generated at 2022-06-21 09:28:42.810365
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fact_cache_obj = FactCache()
    assert fact_cache_obj.__contains__('key') == False


# Generated at 2022-06-21 09:28:47.436568
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    # Test empty cache
    f = FactCache()
    assert f.copy() == {}

    # Test not empty cache
    f.flush()
    f['localhost'] = {'a': 'b'}
    assert f.copy() == {'localhost': {'a': 'b'}}

# Generated at 2022-06-21 09:28:54.114286
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    print('ansible.plugins.cache.jsonfile.__getitem__') # for unittest-trace.py
    factcache = FactCache()
    factcache.__setitem__('key_getitem_test', 'value_getitem_test')
    val = factcache.__getitem__('key_getitem_test')
    assert (val == 'value_getitem_test')
    try:
        assert (factcache.__getitem__('key_getitem_test_not_exists') == 'value_getitem_test_not_exists')
    except KeyError:
        pass
    assert (val == 'value_getitem_test')


# Generated at 2022-06-21 09:29:06.771590
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    '''
    This test case, verifies the behavior of the first_order_merge() function
    of the FactCache class
    '''
    # Creating the FactCache object, to access the first_order_merge method
    fact_cache = FactCache()

    # Verifying the behavior, when the key is not present in the cache
    fact_cache.first_order_merge("/home/user/facts","/home/user/facts2")
    assert fact_cache.get("/home/user/facts") == "/home/user/facts2"

    # Testing the case, when the key is present in the cache
    fact_cache.first_order_merge("/home/user/facts","/home/user/facts3")

# Generated at 2022-06-21 09:29:07.348812
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    pass

# Generated at 2022-06-21 09:29:09.838059
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    cache = FactCache()
    cache['x'] = 1
    assert cache._plugin.contains('x')
    assert cache.keys() == ['x']


# Generated at 2022-06-21 09:29:13.213845
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    pass

# Generated at 2022-06-21 09:29:17.254773
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    fact_cache['foo'] = 'bar'
    fact_cache['bob'] = 'mary'
    assert len(fact_cache) == 2


# Generated at 2022-06-21 09:29:18.234471
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():

    pass


# Generated at 2022-06-21 09:29:21.775762
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    try:
        _plugin = cache_loader.get(C.CACHE_PLUGIN)
        _plugin.flush()
    except Exception as e:
        display.error("Could not flush the cache.\n" + to_text(e))

# Generated at 2022-06-21 09:29:24.573457
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fact_cache = FactCache()
    # TODO: Fix test.
    # self.assertEqual(fact_cache[key], AnsibleError)


# Generated at 2022-06-21 09:29:26.173428
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    pass


# Generated at 2022-06-21 09:29:33.830878
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = FactCache()
    fact_cache['key1'] = ['key1_value1', 'key1_value2']
    fact_cache['key2'] = ['key2_value1', 'key2_value2']
    assert fact_cache.copy() == {'key1': ['key1_value1', 'key1_value2'], 'key2': ['key2_value1', 'key2_value2']}
    

# Generated at 2022-06-21 09:29:40.508369
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():

    cache = FactCache()

    # Case: keys: [], expected: [].
    assert list(cache) == []

    cache['1'] = 'a'
    cache['2'] = 'b'
    cache['3'] = 'c'

    # Case: keys: [1, 2, 3], expected: [1, 2, 3].
    assert list(cache) == ['1', '2', '3']



# Generated at 2022-06-21 09:29:48.051541
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    from ansible.module_utils.facts import CachingModule

    fc = CachingModule._fact_cache()
    fc._plugin.set("key1", 1)
    assert fc["key1"] == 1

    fc._plugin.set("key2", 2)
    assert fc["key2"] == 2

    assert fc._plugin.contains("key1") is True
    del fc["key1"]
    assert fc._plugin.contains("key1") is False
    assert fc._plugin.contains("key2") is True

    with pytest.raises(KeyError):
        del fc["key1"]



# Generated at 2022-06-21 09:29:52.112476
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    plugin = cache_loader.get(C.CACHE_PLUGIN)
    plugin.set('abc', 'def')
    assert 'abc' in FactCache().keys()


# Generated at 2022-06-21 09:30:05.802488
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Setup
    test_cache = FactCache()
    test_cache['test_host'] = {'key1': 'value1'}
    key = 'test_host'
    value = {'key2': 'value2'}

    # Execute
    test_cache.first_order_merge(key, value)

    # Assert
    assert 'test_host' in test_cache
    assert test_cache['test_host'] == {'key1': 'value1', 'key2': 'value2'}

# Generated at 2022-06-21 09:30:17.660621
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    """
    Test method flush of class FactCache, do some initialization and
    delete the cache for a specific host
    :return:
    """
    cache_plugin = cache_loader.get(C.CACHE_PLUGIN)

    # Add some hosts to the cache
    hostname1 = 'host1'
    hostname2 = 'host2'
    hostname3 = 'host3'
    cache_plugin.set(hostname1, {'some' : 'some_info'})
    cache_plugin.set(hostname2, {'some_other' : 'some_other_info'})
    cache_plugin.set(hostname3, {'some_more' : 'some_more_info'})
    all_keys = cache_plugin.keys()
    assert len(all_keys) == 3
    assert hostname

# Generated at 2022-06-21 09:30:27.918877
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():

    # '---\nhosts: localhost'
    # contain 2 elements
    assert len(str(2)) == 2

    # '---\nhosts: localhost'
    # contain 25 characters
    assert len(str(25)) == 25

    # '---\nhosts: localhost'
    # contain 25 characters
    assert len(str(25)) == 25

    # '---\nhosts: localhost'
    # contain 25 characters
    assert len(str(25)) == 25

    # '---\nhosts: localhost'
    # contain 25 characters
    assert len(str(25)) == 25

    # '---\nhosts: localhost'
    # contain 25 characters
    assert len(str(25)) == 25

    # '---\nhosts: localhost'
    # contain 25 characters


# Generated at 2022-06-21 09:30:29.971251
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    host_name = 'test.com'
    cache = FactCache()
    cache.__setitem__(host_name, 'value')
    assert host_name in cache


# Generated at 2022-06-21 09:30:40.757574
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    test_factcache = FactCache()

    assert test_factcache.copy() == {}

    test_factcache['host_1'] = {'host_1_fact_1': 'value_1', 'host_1_fact_2': 'value_2'}
    test_factcache['host_2'] = {'host_2_fact_1': 'value_3', 'host_2_fact_2': 'value_4'}

    assert test_factcache.copy() == {'host_1': {'host_1_fact_1': 'value_1', 'host_1_fact_2': 'value_2'}, 'host_2': {'host_2_fact_1': 'value_3', 'host_2_fact_2': 'value_4'}}

# Generated at 2022-06-21 09:30:50.976993
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    """Unit test for flush method"""
    class TestedFactCache(FactCache):
        def __init__(self):
            self.keys = []

        def __getitem__(self, key):
            if not self.__contains__(key):
                raise KeyError
            return "v"

        def __setitem__(self, key, value):
            self.keys.append(key)

        def __delitem__(self, key):
            self.keys.remove(key)

        def __contains__(self, key):
            return (key in self.keys)

        def __iter__(self):
            return iter(self.keys)

        def __len__(self):
            return len(self.keys)

    fact_cache = TestedFactCache()

# Generated at 2022-06-21 09:30:54.742266
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache = FactCache()
    fact_cache['a'] = 'b'
    del fact_cache['a']
    assert 'a' not in fact_cache._plugin._cache



# Generated at 2022-06-21 09:31:01.126803
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    facts = FactCache()
    key = 'ansible_all_ipv4_addresses'
    value = ['1.1.1.1', '2.2.2.2']
    facts[key] = value
    assert facts['ansible_all_ipv4_addresses'] == ['1.1.1.1', '2.2.2.2']
    facts.flush()



# Generated at 2022-06-21 09:31:05.012636
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = FactCache()
    assert fact_cache
    assert not fact_cache

    fact_cache['localhost'] = {}
    assert fact_cache['localhost'] == {}
    assert fact_cache

    del fact_cache['localhost']
    assert not fact_cache


# Generated at 2022-06-21 09:31:06.350968
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    assert type(fact_cache.keys()) is list


# Generated at 2022-06-21 09:31:23.520356
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    cache = FactCache()
    cache.set("host1", {"key1": "value1"})
    cache.set("host2", {"key1": "value1"})
    assert(len(cache) == 2)
    del cache["host1"]
    assert(len(cache) == 1)


# Generated at 2022-06-21 09:31:26.801672
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    """ Unit test for method __len__ of class FactCache """
    fact_cache = FactCache()
    assert len(fact_cache) == 0
    fact_cache["key"] = "value"
    assert len(fact_cache) == 1

# Generated at 2022-06-21 09:31:29.542600
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    instance = FactCache()
    try:
        assert len(instance) == 0
    except Exception as exc:
        exc.__context__ = None
        raise


# Generated at 2022-06-21 09:31:31.896843
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    ansible_memory = FactCache()
    ansible_memory['key'] = 'value'
    del ansible_memory['key']

    assert 'key' not in ansible_memory

# Generated at 2022-06-21 09:31:34.637401
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    c = FactCache()
    with pytest.raises(KeyError):
        c.__delitem__(0)



# Generated at 2022-06-21 09:31:40.970826
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    cache = FactCache()
    cache["testkey"] = "testvalue"

    # Test iteration of the fact cache
    fact_caches = []
    for key in cache:
        assert key == "testkey"
        fact_caches.append(key)

    assert fact_caches == ["testkey"]


# Generated at 2022-06-21 09:31:41.521896
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    assert True


# Generated at 2022-06-21 09:31:52.536720
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()

    # Save some facts in cache
    fact_cache['_host1'] = dict(
        ansible_facts=dict(
            random_fact_1="value_1",
            random_fact_2="value_2",
            random_fact_3="value_3"
        ),
        timestamp="2018-04-11T10:25:52.944264"
    )
    fact_cache['_host2'] = dict(
        ansible_facts=dict(
            random_fact_4="value_4",
            random_fact_5="value_5",
            random_fact_6="value_6"
        ),
        timestamp="2018-04-11T10:25:52.944264"
    )


# Generated at 2022-06-21 09:32:03.627817
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    #set up the mock cache plugin
    class MockCachePlugin(object):
        def __init__(self):
            self._cache = {}
        def keys(self):
            return self._cache.keys()
        def set(self, key, value):
            self._cache[key] = value
        def get(self, key):
            return self._cache[key]
        def delete(self, key):
            del self._cache[key]
        def contains(self, key):
            return key in self._cache
        def flush(self):
            self._cache = {}

    # set up the mock configuration variables
    class MockConfig(object):
        def __init__(self):
            self.CACHE_PLUGIN = 'test_cache_plugin'

    # set up the mock constants

# Generated at 2022-06-21 09:32:15.391857
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import tempfile
    test_cache_dir = tempfile.mkdtemp()

    cache_plugin = 'jsonfile'
    cache_dir = test_cache_dir

    facts_cache = FactCache()
    facts_cache._plugin = cache_loader.get(cache_plugin)
    facts_cache._plugin.set_options(cache_dir=cache_dir)
    facts_cache._plugin._cache = {}

    host_facts = {u'ansible_facts': {u'ansible_all_ipv4_addresses': [u'192.168.76.128'], u'ansible_all_ipv6_addresses': []}}

    facts_cache.first_order_merge(host_facts.keys()[0], host_facts.values()[0])


# Generated at 2022-06-21 09:32:45.041565
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    cache = FactCache()

    cache['key1'] = 1234
    cache['key2'] = 'value2'

    assert cache['key1'] == 1234
    assert cache['key2'] == 'value2'


# Generated at 2022-06-21 09:32:47.926148
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fact_cache = FactCache()
    key = "test_key"
    value = "test_value"
    fact_cache[key] = value
    assert (key in fact_cache)


# Generated at 2022-06-21 09:32:52.166862
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    mock_plugin = MockPlugin()
    fact_cache = FactCache()
    fact_cache._plugin = mock_plugin
    fact_cache[('test', 'test_host')] = 'test_value'
    assert mock_plugin.set_called



# Generated at 2022-06-21 09:32:54.821131
# Unit test for constructor of class FactCache
def test_FactCache():
    # Test creation of object
    fact_cache = FactCache()
    assert fact_cache

# Generated at 2022-06-21 09:32:55.857055
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    pass



# Generated at 2022-06-21 09:33:03.425355
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    def __init__(self, *args, **kwargs):
        pass
    def keys(self):
        return ['0', '1', '2']
    def __getitem__(self, key):
        return key
    tmp = FactCache()
    tmp._plugin = __init__
    tmp._plugin.keys = keys
    tmp._plugin.get = __getitem__
    for i, val in enumerate(tmp):
        if tmp._plugin.keys()[i] != val:
            raise Exception('_FactCache__iter__() failed')
    print('_FactCache__iter__() passed')

if __name__ == '__main__':
    test_FactCache___iter__()

# Generated at 2022-06-21 09:33:07.314732
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    cache = FactCache()
    cache.__setitem__("cache_key", {"test_data": "test_value"})
    assert list(iter(cache)) == (["cache_key",])


# Generated at 2022-06-21 09:33:19.596674
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge("key1", {"new_fact":"new_value"})
    assert fact_cache["key1"]["new_fact"] == "new_value"
    fact_cache.first_order_merge("key1", {"updated_fact":"value_updated"})
    assert fact_cache["key1"]["new_fact"] == "new_value"
    assert fact_cache["key1"]["updated_fact"] == "value_updated"
    fact_cache.first_order_merge("key1", {"new_fact": "new_value_updated"})
    assert fact_cache["key1"]["new_fact"] == "new_value_updated"

# Generated at 2022-06-21 09:33:22.145536
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    def __delitem__(self, key):
        self._plugin.delete(key)
    assert __delitem__


# Generated at 2022-06-21 09:33:28.031231
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    test_data = {'key1': 'val1', 'key2': 'val2'}
    fact_cache = FactCache()
    for key, value in test_data.items():
        fact_cache[key] = value
    assert len(fact_cache) == 2


# Generated at 2022-06-21 09:34:29.866071
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    # Define required constants
    C.CACHE_PLUGIN = 'jsonfile'

    plugin = cache_loader.get(C.CACHE_PLUGIN)

    cache_content = {'dummy_key': 'dummy_value'}
    plugin.set(host_name='dummy_host', variables=cache_content)

    # Create a factcache object and test
    cache = FactCache()
    assert cache['dummy_key'] == 'dummy_value'

    # Clean up
    plugin.flush()



# Generated at 2022-06-21 09:34:34.266542
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    from ansible.errors import AnsibleError
    from ansible.plugins.loader import cache_loader
    try:
        cache_loader.get("jsonfile").flush()
    except:
        raise AnsibleError("Unable to flush the facts cache plugin (%s)." % (C.CACHE_PLUGIN))



# Generated at 2022-06-21 09:34:37.658225
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fact_cache = FactCache()
    ans = list()
    for i in fact_cache:
        ans.append(i)
    assert ans == []


# Generated at 2022-06-21 09:34:51.242322
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    from ansible.utils.hashs import md5s

    key='host1'
    value={'foo': 'bar'}
    host_facts={key: value}

    fact_cache=FactCache()
    fact_cache.first_order_merge(key, value)

    assert len(fact_cache) == 1
    assert fact_cache[key]== value

    # if we call first_order_merge with the same host and value,
    # the cache will not be incremented
    fact_cache.first_order_merge(key, value)
    assert len(fact_cache) == 1

    # if we call first_order_merge with the same host and different value,
    # the value associated with the key will be replaced with the new one
    value={'foo1': 'bar1'}
    fact_

# Generated at 2022-06-21 09:35:01.052366
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    C.ANSIBLE_CACHE_PLUGIN = ["jsonfile"]
    C.ANSIBLE_CACHE_PLUGIN_CONNECTION = None
    C.ANSIBLE_CACHE_PLUGIN_PREFIX = 'ansible_cache_'
    C.ANSIBLE_CACHE_PLUGIN_TIMEOUT = 3600
    cache = FactCache()
    cache_key = "test_factcache_key"
    cache_value = "test_factcache_value"
    cache[cache_key] = cache_value
    if len(cache) == 1:
        display.vvv("test_FactCache__len__ passed")
    else:
        raise AssertionError("test_FactCache__len__ failed")

# Generated at 2022-06-21 09:35:03.135815
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    cache = FactCache()
    fact_cache_len = cache.__len__()

    assert fact_cache_len == 0



# Generated at 2022-06-21 09:35:04.927034
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    cache = FactCache()
    cache.set('test', 'ok')
    res = cache.copy()
    assert isinstance(res, dict)
    assert res['test'] == 'ok'

# Generated at 2022-06-21 09:35:14.563568
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    import configparser
    import os
    import tempfile

    try:
        # create a temporary file to store the facts in cache
        fd, cache_path = tempfile.mkstemp()
        # close the file as we don't need to actually write to it
        os.close(fd)

        facts = {'ansible_os_family': 'RedHat'}

        fact_cache = FactCache()
        fact_cache.set('localhost', facts)
        cached_facts = fact_cache.get('localhost')

        assert facts == cached_facts
    finally:
        if os.path.exists(cache_path):
            os.unlink(cache_path)



# Generated at 2022-06-21 09:35:16.103018
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache(None)

# Generated at 2022-06-21 09:35:20.228777
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache = FactCache()
    host_key = '10.1.1.1'
    fact_cache[host_key] = '10.1.1.1'
    del fact_cache[host_key]
    for item in fact_cache.keys():
        assert False
