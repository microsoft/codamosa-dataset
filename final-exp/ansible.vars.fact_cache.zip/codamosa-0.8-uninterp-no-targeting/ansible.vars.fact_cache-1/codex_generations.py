

# Generated at 2022-06-21 09:27:12.488932
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fc = FactCache()
    for i in range(20):
        assert fc._plugin.contains(i) == fc.__contains__(i)


# Generated at 2022-06-21 09:27:14.363805
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fact_cache = FactCache()
    fact_cache['test_key'] = 'test_value'
    assert fact_cache['test_key'] == 'test_value'


# Generated at 2022-06-21 09:27:22.485817
# Unit test for method __len__ of class FactCache

# Generated at 2022-06-21 09:27:25.018281
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    cache = FactCache()
    keys = cache.keys()
    assert keys == []
    cache.flush()

# Generated at 2022-06-21 09:27:30.964518
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    assert fact_cache.keys() == []
    fact_cache['x'] = 'x'
    fact_cache['y'] = 'y'
    fact_cache['z'] = 'z'
    keys = fact_cache.keys()
    assert 'x' in keys
    assert 'y' in keys
    assert 'z' in keys


# Generated at 2022-06-21 09:27:34.033667
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact = FactCache()
    fact['hostname'] = 'localhost'
    fact['ansible_os_family'] = 'RedHat'
    assert len(fact) == 2


# Generated at 2022-06-21 09:27:36.672208
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    obj = FactCache(None)
    actual_result = obj.__len__()
    expected_result = None
    assert actual_result == expected_result


# Generated at 2022-06-21 09:27:40.511039
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache = FactCache()
    fact_cache['key1'] = 'value1'
    fact_cache['key2'] = 'value2'
    fact_cache.__delitem__('key1')
    expected_result = {'key2': 'value2'}
    assert fact_cache.copy() == expected_result
    

# Generated at 2022-06-21 09:27:43.952054
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    if not fact_cache:
        raise ValueError
    assert isinstance(fact_cache, FactCache)
    assert isinstance(fact_cache, MutableMapping)

# Generated at 2022-06-21 09:27:50.364633
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    """Test case for class FactCache method copy."""
    fact_cache = FactCache()
    try:
        fact_cache['test_key'] = 'test_value'
        assert fact_cache.copy() == {'test_key': 'test_value'}
    except KeyError:
        assert 'test_key' in fact_cache
    finally:
        fact_cache.flush()

# Generated at 2022-06-21 09:27:58.957679
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    # Create a new instance of FactCache
    fact_cache = FactCache()
    # Set a key and its value in the cache
    fact_cache["Test_Key"] = "Test_Value"
    # Check if the key is available in the cache
    assert "Test_Key" in fact_cache
    # Flush the cache
    fact_cache.flush()
    # Check if the key is available in the cache
    assert "Test_Key" not in fact_cache

# Generated at 2022-06-21 09:28:00.397218
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    cache = FactCache()
    assert len(cache) == 0



# Generated at 2022-06-21 09:28:03.686058
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc
    # key not in cache
    assert fc._plugin.get('invalid-key') is None

# Generated at 2022-06-21 09:28:07.553105
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    fact_cache['a'] = 'a'
    assert 'a' in fact_cache.keys()
    fact_cache.flush()
    assert 'a' not in fact_cache.keys()


# Generated at 2022-06-21 09:28:12.789873
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    key = "test"
    my_fact_cache = FactCache()
    my_fact_cache.__setitem__(key, "value")
    my_fact_cache[key] == "value"
    try:
        my_fact_cache['nofound']
        raise Exception("get item not key error")
    except KeyError:
        pass


# Generated at 2022-06-21 09:28:14.943115
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    a = FactCache()
    print(len(a))


# Generated at 2022-06-21 09:28:16.334601
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    cache = FactCache()
    cache.flush()

# Generated at 2022-06-21 09:28:17.356464
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    facts_cache = FactCache()
    facts_cache.flush()

# Generated at 2022-06-21 09:28:23.420250
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    try:
        cache = FactCache()
        cache['test_FactCache___getitem__'] = 'test_FactCache___getitem___value'
        assert cache['test_FactCache___getitem__'] == 'test_FactCache___getitem___value'
    finally:
        try:
            cache.flush()
        except Exception as e:
            assert False, 'Error: ' + str(e)


# Generated at 2022-06-21 09:28:24.790576
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    assert not FactCache().__getitem__("key_1")


# Generated at 2022-06-21 09:28:33.733533
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    cache = FactCache()
    cache['test_key'] = 'test_value'
    assert 'test_key' in cache
    cache.flush()
    assert not 'test_key' in cache


# Generated at 2022-06-21 09:28:36.526456
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    from ansible.cache import FactCache

    factCache = FactCache()
    factCache.flush()
    factCache.flush()

# Generated at 2022-06-21 09:28:40.668821
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache = FactCache()
    fact_cache['name'] = 'value'
    assert fact_cache['name'] == 'value'
    del fact_cache['name']
    try:
        fact_cache['name']
    except KeyError:
        assert True
    else:
        assert False


# Generated at 2022-06-21 09:28:42.971506
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fact_cache = FactCache()
    assert 'contains' in fact_cache.__dir__()
    assert 'foo' not in fact_cache



# Generated at 2022-06-21 09:28:45.637292
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fc = FactCache({'test': 'test'})
    del fc['test']
    assert 'test' not in list(fc)

# Generated at 2022-06-21 09:28:48.743000
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    mock_plugin = MagicMock()
    test_object = FactCache(mock_plugin)
    test_object.flush()
    mock_plugin.flush.assert_called_once_with()



# Generated at 2022-06-21 09:28:54.104560
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fc = FactCache()
    try:
        fc["some_key"] = "some_value"
        assert len(fc) == 1
        assert fc["some_key"] == "some_value"
        del fc["some_key"]
        assert len(fc) == 0
    finally:
        del fc



# Generated at 2022-06-21 09:29:02.958014
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    old_facts = {'ansible_os_family': 'RedHat', 'ansible_distribution': 'Centos'}
    new_facts = {'ansible_os_family': 'RedHat', 'ansible_distribution': 'Fedora'}
    fc = FactCache()
    fc['127.0.0.1'] = old_facts
    fc.first_order_merge('127.0.0.1', new_facts)
    assert fc['127.0.0.1'] == new_facts

# Generated at 2022-06-21 09:29:04.139386
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    assert True


# Generated at 2022-06-21 09:29:06.339002
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fact_cache = FactCache()
    fact_cache.__getitem__("test_key")


# Generated at 2022-06-21 09:29:14.183396
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fc = FactCache()
    fc["key1"] = "value1"
    assert fc["key1"] == "value1"


# Generated at 2022-06-21 09:29:21.535169
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    display.verbosity = 3
    host_name = 'host1'
    fact_name = 'dir_name'
    fact_value = '/tmp'

    # test with key present
    fc = FactCache()
    fc[host_name] = {fact_name: fact_value}

    assert host_name in fc

    # test with key not present
    fc = FactCache()
    assert host_name not in fc



# Generated at 2022-06-21 09:29:30.152545
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache=FactCache()
    fact_cache.first_order_merge('fact1', {'test1':'test1'})
    assert fact_cache.get('fact1').get('test1') == 'test1'
    fact_cache.first_order_merge('fact1', {'test2':'test2'})
    assert fact_cache.get('fact1').get('test1') == 'test1'
    assert fact_cache.get('fact1').get('test2') == 'test2'
    assert len(list(fact_cache.keys())) == 1
    fact_cache.first_order_merge('fact1', {'test1':'test1_modified'})
    assert fact_cache.get('fact1').get('test1') == 'test1_modified'
    assert fact_

# Generated at 2022-06-21 09:29:33.492480
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    factcache = FactCache()
    factcache['key1'] = 'value1'
    factcache['key2'] = 'value2'
    assert len(factcache) == 2



# Generated at 2022-06-21 09:29:41.975745
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    from ansible.module_utils.facts import get_cache_file

    facts_cache = FactCache()
    facts_cache['test_host1'] = {'fact1': 'first_value'}
    facts_cache['test_host2'] = {'fact2': 'second_value'}

    i = 0
    for host in facts_cache:
        i += 1
        assert host in facts_cache
        assert 'fact1' in facts_cache[host] or 'fact2' in facts_cache[host]

    assert i == 2

    facts_cache.flush()
    assert get_cache_file() is None

# Generated at 2022-06-21 09:29:44.914424
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    cache = FactCache()
    hash = {'a': 'a', 'b': 'b', 'c': 'c'}
    cache['foo'] = hash
    assert cache['foo'] == hash
    assert cache.copy() == hash
    assert cache['foo'] == hash


# Generated at 2022-06-21 09:29:48.236257
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fact_cache = FactCache()

# Generated at 2022-06-21 09:29:58.591352
# Unit test for method copy of class FactCache
def test_FactCache_copy():

    class fakeplugin(object):
        def __init__(self):
            self.data = {}

        def set(self, key, value):
            self.data[key] = value

        def get(self, key):
            return self.data[key]

        def delete(self, key):
            del self.data[key]

        def contains(self, key):
            return key in self.data

        def keys(self):
            return self.data.keys()

        def flush(self):
            self.data = {}

    plugin = fakeplugin()
    cache = FactCache()
    cache._plugin = plugin

    cache['key'] = {'value': 'value'}
    assert 'key' in cache
    assert cache['key'] == {'value': 'value'}

# Generated at 2022-06-21 09:29:59.842766
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache

# Generated at 2022-06-21 09:30:01.436890
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    f = FactCache()
    for k in f:
        print(k)

# Generated at 2022-06-21 09:30:21.963063
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    host_a = 'host_a'
    host_facts = { 'fact_a': 'value_a', 'fact_b': 'value_b' }
    fact_cache.first_order_merge(host_a, host_facts)
    assert len(fact_cache[host_a]) == 2
    assert fact_cache[host_a]['fact_a'] == fact_cache[host_a]['fact_a'] == 'value_a'
    assert fact_cache[host_a]['fact_b'] == fact_cache[host_a]['fact_b'] == 'value_b'

# Generated at 2022-06-21 09:30:23.013281
# Unit test for constructor of class FactCache
def test_FactCache():
    factcache = FactCache()
    assert factcache

# Generated at 2022-06-21 09:30:25.305574
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fc = FactCache()
    fc["test"] = "test"
    del fc["test"]
    assert not fc.__contains__("test")

# Generated at 2022-06-21 09:30:32.589237
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    from ansible.module_utils.facts import FactCache
    from ansible.plugins.cache import BaseCacheModule
    from ansible.module_utils.six.moves import mock
    import ansible.module_utils.facts
    mock_cache = mock.MagicMock(spec=BaseCacheModule)
    mock_cache.add_host.return_value = True
    mock_cache.set_host.return_value = True
    mock_cache.get_host.return_value = [{
        'host1': {
            'test_fact': 'test_value'
        },
        'host2': {}
    }]
    with mock.patch.object(
        ansible.module_utils.facts.cache_loader, 'get', return_value=mock_cache
    ):
        f_cache = FactCache()
       

# Generated at 2022-06-21 09:30:34.157313
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fact_cache = FactCache()

    assert fact_cache['a'] == 1

# Generated at 2022-06-21 09:30:40.651928
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    try:
        cache_loader.get(C.CACHE_PLUGIN)
    except:
        display.warning('Unable to load facts cache plugin (%s). this unit test cannot be run.' % (C.CACHE_PLUGIN))
        return 3
    for key in FactCache():
        display.display('%s' % (key))
    return 0

# Generated at 2022-06-21 09:30:49.713311
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    c = FactCache()
    key = "test_key"
    # reset mocks
    c._plugin.contains.reset_mock()
    c._plugin.contains.return_value = True

    ret = c.__contains__(key)
    assert ret == True
    c._plugin.contains.assert_called_once_with(key)

    # reset mocks
    c._plugin.contains.reset_mock()
    c._plugin.contains.return_value = False

    ret = c.__contains__(key)
    assert ret == False
    c._plugin.contains.assert_called_once_with(key)


# Generated at 2022-06-21 09:30:53.789673
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fac = FactCache()
    assert len(fac) == 0
    fac['foo'] = 'bar'
    assert len(fac) == 1
    fac.flush()
    assert len(fac) == 0


# Generated at 2022-06-21 09:30:54.914023
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    pass


# Generated at 2022-06-21 09:31:05.813872
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    from ansible.plugins.loader import cache_loader
    from ansible.utils.display import Display
    from ansible import constants as C
    from ansible.errors import AnsibleError
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host, Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    vault_secrets = VaultLib()
    display = Display()

    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
   

# Generated at 2022-06-21 09:31:39.116427
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    cache_plugin_key = 'fact_cache'
    display.display(u"Loading %s fact cache plugin" % cache_plugin_key)
    plugin = cache_loader.get(cache_plugin_key)

    assert plugin is not None, u'FactCache plugin not loaded - nothing to test'

    obj = plugin()
    assert obj is not None and isinstance(obj, MutableMapping), u'Failed to instantiate plugin'

    cache = FactCache()
    cache['test_key_1'] = 'test_val_1'
    cache['test_key_2'] = 'test_val_2'

    assert len(cache) == 2, u'Unexpected number of keys in cache: Expected [2] but received [%s]' % len(cache)


# Generated at 2022-06-21 09:31:44.104161
# Unit test for method flush of class FactCache
def test_FactCache_flush():

    # New FactCache object
    factCache = FactCache()

    # Update the cache
    factCache.update({"key": "value"})

    # Get the plugin object
    plugin = factCache._plugin

    # Call the flush method of the plugin object
    plugin.flush()

    # Check that the cache is empty
    assert not iter(factCache)


# Generated at 2022-06-21 09:31:45.276035
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    pass


# Generated at 2022-06-21 09:31:45.890263
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    pass

# Generated at 2022-06-21 09:31:49.500849
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    cache = {'a':{'b':1}}
    plugin = MockPlugin(cache)
    fact_cache = FactCache()
    fact_cache._plugin = plugin
    assert set(cache.keys()) == set(iter(fact_cache))


# Generated at 2022-06-21 09:31:53.576661
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    
    # Test for the method __iter__ with no values
    fc = FactCache()
    assert 0 == len(fc)
    for value in fc:
        assert False


# Generated at 2022-06-21 09:31:57.555634
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    f = FactCache()
    f.first_order_merge('127.0.0.1', {})
    assert f.keys() == ['127.0.0.1']
    f.flush()
    assert f.keys() == []

# Generated at 2022-06-21 09:32:00.526117
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    plugin = cache_loader.get(C.CACHE_PLUGIN)
    if not plugin:
        raise AnsibleError('Unable to load the facts cache plugin (%s).' % (C.CACHE_PLUGIN))
    facts = FactCache()
    facts['example_key'] = plugin.get('example_key')
    facts['example_key1'] = plugin.get('example_key1')
    facts.flush()
    assert len(facts) == 0

# Generated at 2022-06-21 09:32:05.904945
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():

    # Create a FactCache object
    fact_cache = FactCache()

    # Add 10 keys to the cache
    test_keys = []
    for n in range(10):
        test_keys.append('test_key_' + str(n))
        fact_cache[test_keys[n]] = n

    # Test the __iter__ method
    i = 0
    for key in fact_cache:
        assert(key == test_keys[i])
        i += 1


# Generated at 2022-06-21 09:32:08.547167
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    cache = FactCache()
    cache['test_key'] = 'test_value'
    cache.flush()

    assert not cache

# Generated at 2022-06-21 09:33:02.146977
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    host_facts = {
        'ansible_default_ipv4': {
            'address': '172.30.0.2',
            'alias': 'enp0s3',
            'gateway': '172.30.0.1',
            'interface': 'enp0s3',
            'macaddress': '08:00:27:b3:e0:fd',
            'mtu': 1500,
            'netmask': '255.255.255.0',
            'network': '172.30.0.0',
            'type': 'ether'},
        'ansible_default_ipv6': {}
        }

# Generated at 2022-06-21 09:33:06.949306
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    assert fact_cache.copy() == dict()
    fact_cache['key1'] = 'value1'
    assert fact_cache.copy() == dict(key1='value1')
    

# Generated at 2022-06-21 09:33:10.425068
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    # Test for keys method
    fc = FactCache()
    fc.plugin = MockPlugin()
    keys = fc.keys()
    assert isinstance(keys, list)

# Generated at 2022-06-21 09:33:17.578671
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    # Test if missing cache file returns False
    cache = FactCache()
    cache._plugin._cachefile = "missing.cache"
    assert cache.__contains__("abc") == False
    cache._plugin._cachefile = "facts.cache"

    # Test for existing and non-existing hostname
    cache.__setitem__("abc", {})
    assert cache.__contains__("abc") == True
    assert cache.__contains__("def") == False
    cache.flush()



# Generated at 2022-06-21 09:33:22.681367
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    host_cache = {'key1': 'value1', 'key2': 'value2'}
    result = FactCache().__init__(host_cache)
    assert result == host_cache
    result = FactCache().flush()
    assert result == host_cache.clear()


# Generated at 2022-06-21 09:33:28.668174
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    # Set up the FactCache instance
    fact_cache = FactCache()
    # Set up the expected result
    expected_result = None
    # Invoke the method under test
    result = fact_cache.__setitem__("key", "value")
    # The result should be the expected result
    assert expected_result == result


# Generated at 2022-06-21 09:33:33.656597
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fact_cache = FactCache()
    fact_cache['192.168.1.1'] = {'test': 'value'}
    del fact_cache['192.168.1.1']
    try:
        fact_cache['192.168.1.1']
    except KeyError as ke:
        assert True
    

# Generated at 2022-06-21 09:33:37.221417
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Given
    factCache = FactCache()
    key = 'test-host'
    value = {'testKey': 'testValue'}

    # When
    factCache.first_order_merge(key, value)

    # Then
    assert factCache.get(key) == value

# Generated at 2022-06-21 09:33:46.283348
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    factcache = FactCache()

    factcache.first_order_merge("key1", "value1")
    assert factcache["key1"] == "value1"

    factcache.first_order_merge("key1", "value2")
    assert factcache["key1"] == "value2"

    factcache.first_order_merge("key2", {"subkey1": "subvalue1"})
    assert factcache["key2"] == {"subkey1": "subvalue1"}

    # modify subvalue1
    factcache.first_order_merge("key2", {"subkey1": "subvalue2"})
    assert factcache["key2"] == {"subkey1": "subvalue2"}

    # modify subvalue1, add subkey2

# Generated at 2022-06-21 09:33:48.659056
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    print("Test of FactCache Class is successful")
#    print("Test of FactCache Class is %successful", fc)


# Generated at 2022-06-21 09:35:21.765154
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fc = FactCache()
    fc['a'] = dict(key='a')
    assert fc.keys() == ['a']
    assert 'a' in fc


# Generated at 2022-06-21 09:35:24.796454
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    my_object = FactCache(default_cache_plugin=C.CACHE_PLUGIN)
    my_object["test"] = "test"
    for i in my_object:
        assert i == "test"

# Generated at 2022-06-21 09:35:27.908042
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fact_cache = FactCache()
    fact_cache["host1"] = {"hostname": "test1"}
    fact_cache["host2"] = {"hostname": "test2"}
    assert ("host1" in fact_cache) and ("host2" in fact_cache)
    assert ("host3" not in fact_cache)
    assert next(iter(fact_cache)) in ["host1", "host2"]
    assert next(iter(fact_cache)) in ["host1", "host2"]
    assert next(iter(fact_cache)) in ["host1", "host2"]


# Generated at 2022-06-21 09:35:38.176421
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.plugins.cache.jsonfile import CacheModule as JSONFileCacheModule
    import json
    import os

    # Initialize the JSONFileCacheModule class
    cache_plugin = JSONFileCacheModule()

    # Initialize the FactCache class
    fact_cache = FactCache()

    # Example data to be cached
    host1 = "127.0.0.1"
    host2 = "192.168.1.1"
    values1 = {
        "distribution": DistributionFactCollector().collect(None, host1),
        "fqdn": "localhost.localdomain",
        "hostname": "localhost.localdomain"
    }

# Generated at 2022-06-21 09:35:44.107090
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    # Create an instance of FactCache
    factCache = FactCache()

    # Add some data to the FactCache
    factCache["key1"] = "value1"
    factCache["key2"] = "value2"
    factCache["key3"] = "value3"

    # Perform a copy and check if it worked
    copy = factCache.copy()
    assert copy == {"key1": "value1", "key2": "value2", "key3": "value3"}

# Generated at 2022-06-21 09:35:52.400301
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    f = FactCache()
    f.__setitem__('192.168.10.144', dict(a=1))
    f.__setitem__('192.168.10.145', dict(a=1))
    f.__setitem__('192.168.10.146', dict(a=1))
    f.__setitem__('192.168.10.147', dict(a=1))
    assert f.__contains__('192.168.10.144')
    assert not f.__contains__('192.168.10.148')
    assert len(f) == 4
    assert f.__contains__('192.168.10.144')
    assert f.__contains__('192.168.10.145')
    assert f.__contains__('192.168.10.146')


# Generated at 2022-06-21 09:35:54.418467
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    fact_cache.set_plugin(MockFactCachePlugin())
    assert fact_cache.keys() == [u'test_key']

# Generated at 2022-06-21 09:35:56.573550
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    cache = FactCache() # Initialize the cache instance
    cache['key'] = None
    assert ('key' in cache)
    assert ('key1' not in cache)


# Generated at 2022-06-21 09:36:04.274390
# Unit test for method first_order_merge of class FactCache

# Generated at 2022-06-21 09:36:05.375341
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    assert False
