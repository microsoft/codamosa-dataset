

# Generated at 2022-06-21 09:27:11.690658
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_obj = FactCache()
    fact_cache_obj.first_order_merge('host1', {'a': 'b', 'c': 'd'})
    assert fact_cache_obj['host1'] == {"a": "b","c": "d"}
    fact_cache_obj.first_order_merge('host1', {'c': 'd', 'e': 'f'})
    assert fact_cache_obj['host1'] == {"a": "b","c": "d", "e": "f"}


# Generated at 2022-06-21 09:27:14.636584
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    """
    Test if __len__() returns correct length.
    """
    fc = FactCache()
    assert len(fc) == 0
    fc['a'] = 1
    assert len(fc) == 1
    fc['b'] = 2
    assert len(fc) == 2



# Generated at 2022-06-21 09:27:19.144042
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    print('\n---- test_FactCache_first_order_merge ----')
    test_cache = FactCache()
    test_cache.first_order_merge('test_host','test_new_value')
    print(test_cache)
    print('----')
    test_cache.first_order_merge('test_host','test_existing_value')
    print(test_cache)
    print(type(test_cache))
    print('----')


# Generated at 2022-06-21 09:27:25.128918
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():

    # Unit test:
    # Try to delete an item from the cache when plugin is not loaded
    # Expected result:
    #    If a cache plugin has been specified, it should be loaded, otherwise an appropriate exception should be raised
    facts = FactCache()
    try:
        facts['localhost'] = 0
    except:
        pass
    else:
        raise AssertionError('Expected Exception')



# Generated at 2022-06-21 09:27:32.362712
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    data = [
        ('test_host', {'test_fact': 'test_value'}),
        ('test_host2', {'test_fact2': 'test_value2'}),
    ]

    fact_cache = FactCache()
    for key, value in data:
        fact_cache.first_order_merge(key, value)
    assert set(data[0][0], data[1][0]) == set(fact_cache.keys())


# Generated at 2022-06-21 09:27:41.353578
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    """
    Test methods of class FactCache
    """

    #  Fake plugin
    class FakePlugin:
        def __init__(self):
            self._cache = {}

        def set(self, key, value):
            self._cache[key] = value

        def get(self, key):
            try:
                return self._cache[key]
            except KeyError:
                return None

        def delete(self, key):
            try:
                self._cache.pop(key)
            except KeyError:
                pass

        def contains(self, key):
            try:
                return key in self._cache
            except KeyError:
                return False

        def keys(self):
            return self._cache.keys()

        def flush(self):
            self._cache = {}

    #  Fake cache loader

# Generated at 2022-06-21 09:27:44.731127
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fc = FactCache()
    assert fc['test'] == {}
    fc['test'] = {}
    assert fc['test'] == {}


# Generated at 2022-06-21 09:27:48.829616
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    assert len(fact_cache) == 0

    fact_cache['test_key'] = 'test_value'
    assert len(fact_cache) == 1


# Generated at 2022-06-21 09:27:51.590918
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    fact_cache['test_key'] = 'test_value'
    assert fact_cache.copy() == {'test_key': 'test_value'}

# Generated at 2022-06-21 09:27:59.739343
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    fact_cache['localhost'] = {u'ansible_facts': {u'os_family': u'Debian'}}
    fact_cache['192.168.0.1'] = {u'ansible_facts': {u'os_family': u'Debian'}}

    assert fact_cache.copy() == {'localhost': {u'ansible_facts': {u'os_family': u'Debian'}}, '192.168.0.1': {u'ansible_facts': {u'os_family': u'Debian'}}}


# Generated at 2022-06-21 09:28:01.936496
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    assert True


# Generated at 2022-06-21 09:28:08.297380
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    test_key = 'test_key'
    fact_cache[test_key] = {"a": "x", "b": "y", "c": "z"}
    fact_cache.first_order_merge(test_key, {"b": "p", "d": "q"})
    assert fact_cache[test_key] == {"a": "x", "b": "y", "c": "z", "d": "q"}

# Generated at 2022-06-21 09:28:12.289514
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    x = {'a': 1, 'b': 2}
    fact_cache = FactCache()
    for key, val in x.items():
        fact_cache[key] = val
    y = fact_cache.keys()
    assert x.keys() == y


# Generated at 2022-06-21 09:28:20.569315
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    test_cache = FactCache()
    test_cache.first_order_merge('localhost', {'fact_a': 'A'})
    assert 'localhost' in test_cache
    assert test_cache['localhost'] == {'fact_a': 'A'}
    # do it a second time, with merging
    test_cache.first_order_merge('localhost', {'fact_a': 'B'})
    assert 'localhost' in test_cache
    assert test_cache['localhost'] == {'fact_a': 'B'}

# Generated at 2022-06-21 09:28:22.636256
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fact_cache_plugin = FactCache()
    fact_cache_plugin.__contains__('demo-host')


# Generated at 2022-06-21 09:28:25.297730
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    cache = FactCache()

    # setup test data
    cache["localhost"] = dict()

    cache.flush()

    assert len(cache.keys()) == 0


# Generated at 2022-06-21 09:28:26.628216
# Unit test for constructor of class FactCache
def test_FactCache():
    hosts = ["localhost"]
    fact_cache = FactCache(hosts)

# Generated at 2022-06-21 09:28:27.950538
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    assert len(fact_cache) == 0


# Generated at 2022-06-21 09:28:32.107740
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    test_cache = { "key1": "value1", "key2": "value2" }
    test_obj = FactCache(**test_cache)

    assert(test_obj.copy() == test_cache)

# Generated at 2022-06-21 09:28:40.758064
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    # test with no values in cache
    fc = FactCache()
    fc_len = len(fc)
    assert fc_len == 0

    # test with one value in cache and key
    fc['foo'] = 'bar'
    fc_len = len(fc)
    assert fc_len == 1

    # test with two values in cache
    fc['bar'] = 'baz'
    fc_len = len(fc)
    assert fc_len == 2

    fc['foo'] = None
    fc_len = len(fc)
    assert fc_len == 1



# Generated at 2022-06-21 09:28:44.891476
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    fact = dict(welcome='hello',name='ansible')
    fact_cache.update(fact)
    keys = fact_cache.keys()
    assert keys == ['welcome', 'name']


# Generated at 2022-06-21 09:28:53.415443
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fc = FactCache()

    import datetime
    start_time = datetime.datetime.now()
    for i in range(0, 100):
        fc[str(i)] = i

    assert (fc.copy() == {str(x): x for x in range(0, 100)})

    import time
    time.sleep(1)
    end_time = datetime.datetime.now()

    # Confirm that cache is one second old, so that the next call
    # to copy will trigger loading the cache.
    assert (start_time < fc._plugin._cache_time < end_time)

    # Confirm that calling copy will load the cache
    assert (fc.copy() == {str(x): x for x in range(0, 100)})


# Generated at 2022-06-21 09:29:00.332057
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    fact_cache['key1'] = {'key1' : 'item1'}
    fact_cache['key2'] = {'key2' : 'item2'}
    fact_cache['key3'] = {'key3' : 'item3'}

    # Check the keys are stored
    assert fact_cache.keys() == ['key1', 'key2', 'key3']

# Generated at 2022-06-21 09:29:04.441680
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    a = FactCache()
    assert len(a) == 0
    a.first_order_merge('key', 'value')
    assert len(a) == 1
    assert 'key' in a
    assert a['key'] == 'value'

# Generated at 2022-06-21 09:29:05.508543
# Unit test for constructor of class FactCache
def test_FactCache():

    cache = FactCache()
    assert cache is not None

# Generated at 2022-06-21 09:29:07.715448
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = FactCache()
    fact_cache['hostname'] = 'host1'
    assert fact_cache['hostname'] == 'host1'


# Generated at 2022-06-21 09:29:13.361419
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    my_cache = {'a': 1, 'b': 2, 'c': 3}

    keys_cache = {"a": 1, "b": 2, "c": 3}
    keys_cache = list(keys_cache)

    fc = FactCache()
    fc.__setitem__('a', 1)
    fc.__setitem__('b', 2)
    fc.__setitem__('c', 3)

    fc_list = fc.keys()

    assert fc_list.__eq__(keys_cache)

# Generated at 2022-06-21 09:29:20.584918
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge("key", "value1")
    assert fact_cache["key"] == "value1"
    fact_cache.first_order_merge("key", "value2")
    assert fact_cache["key"] == "value2"
    fact_cache.first_order_merge("key", "value3")
    assert fact_cache["key"] == "value3"

# Generated at 2022-06-21 09:29:25.869864
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    class MockPlugin:
        def set(self, x, y):
            self.call = x, y

    class MockHostFactCache(FactCache):
        def __init__(self):
            self._plugin = MockPlugin()

    fact_cache = MockHostFactCache()
    fact_cache['foo'] = 'bar'
    assert fact_cache._plugin.call == ('foo', 'bar')

# Generated at 2022-06-21 09:29:29.940595
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fake_plugin = FakePlugin()
    cache = FactCache()

    cache._plugin = fake_plugin

    assert 'foo' in cache
    assert 'bar' not in cache


# Generated at 2022-06-21 09:29:32.943633
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fact_cache = FactCache()
    assert True


# Generated at 2022-06-21 09:29:39.507379
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    plugin = cache_loader.get(C.CACHE_PLUGIN)

    plugin.flush()

    fact_cache = FactCache()
    fact_cache['key'] = 'value'

    assert fact_cache['key'] == 'value'

    del fact_cache['key']

    try:
        fact_cache['key']
        pytest.fail('AnsibleError expected')
    except KeyError:
        pass



# Generated at 2022-06-21 09:29:40.913303
# Unit test for constructor of class FactCache
def test_FactCache():

    # create instance of class FactCache
    fact = FactCache()
    assert fact is not None

# Generated at 2022-06-21 09:29:41.978728
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert type(fc) is FactCache

# Generated at 2022-06-21 09:29:48.526980
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    # create an instance of FactCache
    fact_cache = FactCache()
    # create a fact cache plugin mock
    
    fact_cache._plugin = Mock()
    
    fact_cache._plugin.configure_mock(**{'contains.return_value': False})
    
    fact_cache._plugin.configure_mock(**{'get.side_effect': KeyError})
    
    fact_cache._plugin.configure_mock(**{'delete.return_value': None})
    
    fact_cache._plugin.configure_mock(**{'keys.return_value': ['foo']})
    
    fact_cache._plugin.configure_mock(**{'flush.return_value': None})
    # call method __delitem__ of fact_cache
    

# Generated at 2022-06-21 09:29:53.323408
# Unit test for constructor of class FactCache
def test_FactCache():
    if cache_loader.all():
        from ansible.plugins.cache.jsonfile import CacheModule as jsonfile
        assert isinstance(FactCache(), jsonfile)
    else:
        from ansible.plugins.cache.memory import CacheModule as memory
        assert isinstance(FactCache(), memory)

# Generated at 2022-06-21 09:30:04.022703
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    class MockPlugin():
        def __init__(self):
            self.keys_result = ["a", "b"]
        def keys(self):
            return self.keys_result

    def mock_get(plugin_name):
        return MockPlugin()

    # Backup the current cache_loader.get
    orig_get = cache_loader.get

    # Mock cache_loader.get method, to return our own MockPlugin for the test
    cache_loader.get = mock_get

    # Create a test instance of the FactCache
    test_cache = FactCache()

    # Test the iteration result
    assert list(test_cache) == ["a", "b"]

    # Restore cache_loader.get
    cache_loader.get = orig_get


# Generated at 2022-06-21 09:30:05.039143
# Unit test for constructor of class FactCache
def test_FactCache():
    assert set(FactCache().keys()) == set([])

# Generated at 2022-06-21 09:30:09.257635
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():

    setattr(C, 'CACHE_PLUGIN', 'jsonfile')

    fc = FactCache()
    
    fc['test'] = 'test'
    assert(len(fc) == 1)

    fc.flush()
    assert(len(fc) == 0)
    
    

# Generated at 2022-06-21 09:30:14.249266
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    """
    Test flush
    """
    fc = FactCache()
    fc.set("test_flush", "test")
    assert len(fc.keys()) == 1
    fc.flush()
    assert len(fc.keys()) == 0


# Generated at 2022-06-21 09:30:22.663557
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    factcache = FactCache()
    factcache["test"] = "hello"
    factcache["test1"] = "hello" 
    factcache["test2"] = "hello"
    factcache.flush()
    assert len(factcache) == 0

if __name__ == "__main__":
    test_FactCache_flush()

# Generated at 2022-06-21 09:30:23.953674
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert isinstance(cache, FactCache)



# Generated at 2022-06-21 09:30:32.845079
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    class MockPlugin:
        def __init__(self):
            self._cache = {'host1': 'facts1', 'host2': 'facts2'}
        
        def contains(self, key):
            return key in self._cache
        
        def get(self, key):
            return self._cache[key]
        
        def set(self, key, value):
            self._cache[key] = value
        
        def delete(self, key):
            if key in self._cache:
                del self._cache[key]
        
        def keys(self):
            return self._cache.keys()
    
    m = MockPlugin()
    cache = FactCache(plugin=m)
    assert cache['host1'] == 'facts1'

# Generated at 2022-06-21 09:30:45.260403
# Unit test for method flush of class FactCache

# Generated at 2022-06-21 09:30:49.202205
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    F = FactCache()
    F['127.0.0.1'] = '127.0.0.1'
    assert ('127.0.0.1' in F)
    assert ('127.0.0.2' not in F)


# Generated at 2022-06-21 09:30:50.611169
# Unit test for constructor of class FactCache
def test_FactCache():
    assert isinstance(FactCache(), MutableMapping)

# Generated at 2022-06-21 09:30:55.066951
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    """
    Ensure that exception is raised when no plugin is loaded
    """
    test_fact_cache = FactCache()
    with pytest.raises(AnsibleError):
        test_fact_cache["test_key"]


# Generated at 2022-06-21 09:30:57.138330
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.module_utils.facts.cache import FactCache
    f = FactCache()


# Generated at 2022-06-21 09:31:06.023992
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    # Create a new cache
    cache = FactCache()
    # Clean the cache to avoid external influence
    cache.flush()
    # Fill the cache with some values
    cache["A"] = 1
    cache["B"] = 2
    cache["C"] = 3
    # Check if everything is good
    assert cache["A"] == 1
    assert cache["B"] == 2
    assert cache["C"] == 3
    assert len(cache) == 3
    # Flush the cache
    cache.flush()
    # Check if everything is good
    assert not "A" in cache
    assert not "B" in cache
    assert not "C" in cache
    assert len(cache) == 0

# Generated at 2022-06-21 09:31:12.588476
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
# init
    facts_cache = cache_loader.get('memory')
    factcache = FactCache()
    factcache._plugin = facts_cache
    factcache['key1'] = 'value1'
    factcache['key2'] = 'value2'

# run
    del factcache['key2']
# verify
    assert not facts_cache.contains('key2')
    assert facts_cache.contains('key1')


# Generated at 2022-06-21 09:31:19.295979
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    cache = FactCache()
    assert len(cache) == 0


# Generated at 2022-06-21 09:31:21.119330
# Unit test for constructor of class FactCache
def test_FactCache():
    fac = FactCache()
    fac['key'] = 'value'
    assert fac['key'] == 'value'
    del fac['key']
    assert 'key' not in fac

# Generated at 2022-06-21 09:31:23.336286
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = FactCache()
    fact_cache['key'] = 'value'
    assert fact_cache['key'] == 'value'


# Generated at 2022-06-21 09:31:26.027270
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    fact_cache['test_key'] = ['test_value']
    assert(fact_cache.keys() == ['test_key'])

# Generated at 2022-06-21 09:31:28.489949
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    cache_plugin_name = 'jsonfile'
    C.CACHE_PLUGIN_NAMES = [cache_plugin_name]
    fact_cache = FactCache()
    print(fact_cache['localhost'])


# Generated at 2022-06-21 09:31:30.724315
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fc = FactCache()
    fc['test'] = {'key':'value'}
    print(fc)


# Generated at 2022-06-21 09:31:34.463323
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    from ansible.cache.memory import FactCache as MemoryFactCache
    cache = MemoryFactCache()
    # Test for flush method to be working for an empty cache
    cache.flush()
    # Test for flush method to be working for a non empty cache
    cache._plugin["key1"] = None
    cache._plugin["key2"] = None
    cache.flush()
    assert len(cache._plugin.keys()) == 0, len(cache._plugin.keys())

# Generated at 2022-06-21 09:31:38.140696
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    with pytest.raises(AnsibleError, match=r".*Unable to load the facts cache plugin.*"):
        cached_facts = FactCache()

# Generated at 2022-06-21 09:31:41.779823
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    cache = FactCache()

    assert 'host1' not in cache
    cache['host1'] = {'fact1':'value1', 'fact2':'value2'}
    assert 'host1' in cache


# Generated at 2022-06-21 09:31:45.842695
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fc = FactCache()
    assert len(fc) == 0
    fc["key1"] = "value1"
    fc["key2"] = "value2"
    assert len(fc) == 2
    fc.flush()
    assert len(fc) == 0


# Generated at 2022-06-21 09:31:59.146454
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    fact_cache["host1"] = "host1 facts"
    fact_cache["host2"] = "host2 facts"
    fact_cache.flush()
    assert "host1" not in fact_cache
    assert "host2" not in fact_cache


# Generated at 2022-06-21 09:32:01.296977
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    factcache = FactCache()
    factcache['key'] = 10
    assert factcache['key'] == 10


# Generated at 2022-06-21 09:32:06.851789
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    try:
        c = FactCache()
    except:
        display.warning("Failed to load plugin")
        return False

    c['goss_top_level'] = 'value'
    if 'goss_top_level' not in c:
        return False

    return True


# Generated at 2022-06-21 09:32:07.920490
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    assert hasattr(FactCache(), 'keys')

# Generated at 2022-06-21 09:32:17.401947
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    """Test if the first_order_merge function of the class FactCache works
    as expected.

    The value of each key in the host_facts dictionary will be updated in the
    host_cache dictionary and returned in the host_facts dictionary.
    If a key is not in the host_cache dictionary, it will be created and will
    not be returned in the host_facts dictionary.

    """
    fact_cache = FactCache()
    host_facts = {
        'first_fact': 'first_value',
        'second_fact': 'second_value',
        'third_fact': 'third_value'
    }
    host_cache = {'first_fact': 'first_value'}

    # test if the host_facts dictionary is returned if the host_cache
    # dictionary is empty
    fact_cache.flush()
    host_

# Generated at 2022-06-21 09:32:29.607514
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    pass
    # cache = FactCache()
    # assert isinstance(cache._plugin, cache_loader.get(C.CACHE_PLUGIN))


# class TestFactCache():
#
#     def setup(self):
#         self.cache = FactCache()
#
#     def test___init__(self):
#         assert isinstance(self.cache._plugin, cache_loader.get(C.CACHE_PLUGIN))
#
#     def test___getitem__(self):
#         with pytest.raises(KeyError):
#             self.cache['test']
#
#         self.cache._plugin.set('test', 'test')
#         value = self.cache['test']
#         assert value == 'test'
#
#     def test___setitem__(self):
#         self

# Generated at 2022-06-21 09:32:35.280391
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fact_cache = FactCache()
    fact_cache.flush = display.debug
    fact_cache['1'] = 'value1'
    fact_cache['2'] = 'value2'
    fact_cache['3'] = 'value3'
    ret = [i for i in fact_cache]
    assert ret == ['1', '2', '3']


# Generated at 2022-06-21 09:32:36.199392
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    pass


# Generated at 2022-06-21 09:32:47.167358
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    import json
    import os
    import sys

    original_dir = os.getcwd()
    os.chdir("test/units/plugins/test_cache")
    cache = FactCache()
    sys.path.append("test/units/plugins/test_cache")
    import test_cache_copy
    output_file = "test_FactCache_copy_output"
    cache.__setattr__("_plugin", test_cache_copy)
    cache['host1'] = {'facts': 'test_facts_1'}
    cache['host2'] = {'facts': 'test_facts_2'}
    copy = cache.copy()
    with open(output_file, 'w') as fd:
        fd.write(json.dumps(copy))
    assert os.path.isfile(output_file)

# Generated at 2022-06-21 09:32:53.776996
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    the_fact_cache = FactCache()
    fake_plugin = MockPlugin()
    the_fact_cache._plugin = fake_plugin

    the_result = 'the_key' in the_fact_cache

    assert the_result is True
    assert fake_plugin.contains_called 
    assert fake_plugin.contains_key == 'the_key'


# Generated at 2022-06-21 09:33:20.252384
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-21 09:33:24.091317
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    f = FactCache()
    f._plugin = mock.MagicMock()
    f._plugin.get = mock.MagicMock()
    f._plugin.get.return_value = {'key': 'value'}
    assert f.copy() == {'key': 'value'}
    f._plugin.get.assert_called_once_with('local')

# Generated at 2022-06-21 09:33:27.009385
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fact_cache = FactCache()
    fact_cache.__setitem__(1,2)
    assert fact_cache.__getitem__(1) == 2


# Generated at 2022-06-21 09:33:30.224280
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    from ansible.module_utils.facts import cache

    c = cache.FactCache()

    tmp = 0
    for i in c:
        tmp += 1

    assert tmp == 0


# Generated at 2022-06-21 09:33:41.242546
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    print("Test if FactCache.__setitem__ works")

    class DummyCachePlugin(object):
        def __init__(self):
            self.cache = {}

        def keys(self):
            return list(self.cache.keys())

        def get(self, key):
            return self.cache[key]

        def set(self, key, value):
            self.cache[key] = value

        def delete(self, key):
            del self.cache[key]

        def contains(self, key):
            return key in self.cache

        def flush(self):
            self.cache = {}

    dummy_cache_plugin = DummyCachePlugin()

    fake_cache = FactCache(plugin=dummy_cache_plugin)

    assert fake_cache.keys()     == []
    assert dummy_cache_plugin.keys

# Generated at 2022-06-21 09:33:49.028604
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache = FactCache()
    fact_cache['key1'] = 'test_value'
    fact_cache['key2'] = 'test_value'
    assert fact_cache['key1'] == 'test_value'
    assert fact_cache['key2'] == 'test_value'
    del fact_cache['key1']
    assert fact_cache['key2'] == 'test_value'
    try:
        fact_cache['key1']
    except Exception as err:
        assert err.__class__.__name__ == 'KeyError'


# Generated at 2022-06-21 09:33:58.164605
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache.__class__.__name__ == 'FactCache'
    cache.__setitem__('test_key', 'test_value')
    assert cache.__getitem__('test_key') == 'test_value'
    assert cache.__contains__('test_key')
    assert len(cache) == 1
    cache.__delitem__('test_key')
    try:
        cache.__getitem__('test_key')
        assert False, 'Should not have been able to get key'
    except KeyError:
        assert True
        pass

# Generated at 2022-06-21 09:33:58.792351
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    cache = FactCache()
    assert cache.keys() == []

# Generated at 2022-06-21 09:34:04.893836
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    class C1(MutableMapping):
        def __init__(self):
            self['a'] = 1
        def keys(self):
            return ['a','b','c']
        def get(self, key):
            return self[key]
        def set(self, key, value):
            self[key] = value
        def delete(self, key):
            pass
        def contains(self, key):
            return key in self

    fact_cache = FactCache()
    fact_cache._plugin = C1()
    assert set(iter(fact_cache))==set(['a', 'b', 'c'])

# Generated at 2022-06-21 09:34:14.917788
# Unit test for constructor of class FactCache
def test_FactCache():
    '''
    Test the constructor of class FactCache   
    '''
    fact1 = {}
    fact2 = {}
    fact3 = {}
    fact_map = {}
    fact_map['1.1.1.1'] = fact1
    fact_map['1.1.1.2'] = fact2
    fact_map['1.1.1.3'] = fact3
    fact_cache = FactCache(fact_map)
    for ip, fact in fact_map.items():
        assert ip in fact_cache
        assert fact == fact_cache[ip]
    for ip, fact in fact_cache.items():
        assert ip in fact_map
        assert fact == fact_map[ip]

# Generated at 2022-06-21 09:35:21.800069
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact = FactCache()
    host_facts = { "name": "test", "ansible_facts": { "ipaddress" : "fake_ipaddress", 'user_one': {'key1': 'val1', 'key2': 'val2'} } }
    fact.first_order_merge("test", host_facts)
    fact.first_order_merge("test", { "name": "test", "ansible_facts": { "ipaddress" : "fake_ipaddress", 'user_one': {'key1': 'val1', 'key3': 'val3'} } })
    # Accessing the fact cache by key should return the expected output
    assert fact["test"]["ansible_facts"]["user_one"]["key1"] == 'val1'

# Generated at 2022-06-21 09:35:26.726065
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    """Test the method that returns an iterator of the list of keys."""
    fact_cache = FactCache()
    fact_cache['key_1'] = 'value_1'
    fact_cache['key_2'] = 'value_2'
    assert set(iter(fact_cache)) == set(['key_1', 'key_2'])

# Generated at 2022-06-21 09:35:31.374907
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    # first the class is instantiated
    fact_cache = FactCache()
    # then the method is called
    key = fact_cache.keys()
    # then the assertion
    assert str(type(key)) == "<class 'list'>"

# Generated at 2022-06-21 09:35:35.972905
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fact_cache = FactCache()
    plugin_dict = {
        'key1': 'value1',
        'key2': 'value2',
    }

    fact_cache._plugin.get = lambda _: plugin_dict
    iterator = iter(fact_cache)
    for key in iterator:
        assert key in plugin_dict

# Generated at 2022-06-21 09:35:41.159309
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():

    fact_cache = FactCache()

    # Set up keys
    fact_cache['one'] = 1
    fact_cache['two'] = 2
    fact_cache['three'] = 3

    assert len(fact_cache) == 3

    fact_cache['one'] = 1
    fact_cache['two'] = 2
    fact_cache['three'] = 3

    assert len(fact_cache) == 3


# Generated at 2022-06-21 09:35:44.644991
# Unit test for method flush of class FactCache
def test_FactCache_flush():
  fc_1 = FactCache()
  fc_1["1"] = "a"
  fc_1["2"] = "b"
  fc_1["3"] = "c"
  fc_1.flush()
  assert len(fc_1) == 0

# Generated at 2022-06-21 09:35:52.934205
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache(dict())

    # Since parser.py creates a FactCache object and uses it as a dictionary
    # (and they are not intended to be used as ordinary dictionaries),
    # we need to check if the FactCache object implements the required interface
    # and behaves like a dictionary:

    assert isinstance(fc, MutableMapping)

    # We will use this dictionary to store some test keys and values:
    fc_dict = {'foo': 'bar', 'baz': 'qux'}

    # Make sure that the FactCache object returns the correct values for keys:
    for key, value in fc_dict.items():
        fc[key] = value
        assert fc[key] == value

    # Make sure we can iterate over the keys of the FactCache object:

# Generated at 2022-06-21 09:35:55.306722
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fact_cache = FactCache()
    fact_cache._plugin = mock.Mock()
    fact_cache._plugin.contains.return_value = True

    assert fact_cache.__contains__("key") is True


# Generated at 2022-06-21 09:36:03.154952
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    import os
    import shutil
    from __main__ import *
    from ansible.utils.display import Display
    display = Display()
    host_list = ['test1-host', 'test2-host', 'test3-host']
    myFactCache = FactCache()
    for host in host_list:
        setattr(hostvars[host], 'output_dir', '/tmp/%s' % host)
        # prepare hostvars
        hostvars[host]['ansible_local'] =  {'facts_cache': myFactCache}
        # create facts_cache directory
        os.makedirs('/tmp/%s/facts_cache' % host)
    assert len(myFactCache) == 3

# Generated at 2022-06-21 09:36:04.475869
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert list(fc.keys()) == []
    assert fc.copy() == {}