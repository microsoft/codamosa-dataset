

# Generated at 2022-06-21 09:27:12.754801
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fc = FactCache()
    fc['guru99'] = "Guru99"
    fc.flush()
    assert bool(fc) == False

# Generated at 2022-06-21 09:27:15.718635
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    # Initialize a key
    key = "testFact"

    # Create a FactCache test object
    factcache = FactCache()

    # We don't know if the key is in the factcache
    assert key not in factcache

    # Set the FactCache key
    factcache[key] = "test"

    # We should have the key in the FactCache
    assert key in factcache

    # Delete the key
    del factcache[key]


# Generated at 2022-06-21 09:27:19.182334
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fc = FactCache()
    fc2 = FactCache()
    assert fc.keys() == []
    fc2['a'] = 'a'
    assert fc.keys() == []
    fc['a'] = 'a'
    assert fc.keys() == fc2.keys()

# Generated at 2022-06-21 09:27:23.185618
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fact_cache = FactCache()
    assert not fact_cache.__contains__('_contains_host')
    fact_cache['_contains_host'] = {'key1': 'value1'}
    assert fact_cache.__contains__('_contains_host')

# Generated at 2022-06-21 09:27:25.845312
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fc = FactCache()
    assert not fc.__contains__('test_key')


# Generated at 2022-06-21 09:27:35.439854
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import sys
    import platform

    display = Display()
    display.columns = 80
    display.verbosity = 99
    display.color = False
    display.vvv = True
    display.verbose = True
    display.debug = True

    fc = FactCache()
    fc.first_order_merge("localhost", {'ansible_python_version': sys.version_info})
    fc.first_order_merge("localhost", {'ansible_system': platform.system()})
    fc.first_order_merge("localhost", {'ansible_distribution': platform.dist()})

    print(fc.copy())



# Generated at 2022-06-21 09:27:36.792245
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    cache = FactCache()
    cache['a'] = 'b'
    assert 'a' in cache

# Generated at 2022-06-21 09:27:47.758987
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    from ansible.module_utils._text import to_text
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VarManager

    loader = DataLoader()
    vars = VarManager()
    fact_cache = FactCache(loader=loader, variable_manager=vars)
    fact_cache.flush()

    hosts = ['localhost', 'example.com']

    for host in hosts:
        host_facts = {host: {'fake_fact': 'fake_value'}}
        fact_cache.update(host_facts)

    all_facts = []

    for host in fact_cache:
        host_facts = fact_cache[host]
        all_facts.append(to_text(host_facts))

    all_facts.sort()

# Generated at 2022-06-21 09:27:48.885512
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    assert True

# Generated at 2022-06-21 09:27:52.024475
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    import ansible.constants
    ansible.constants.CACHE_PLUGIN = "memory"
    cache = FactCache()
    assert isinstance(cache, FactCache)


# Generated at 2022-06-21 09:28:01.407203
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('a', {'b': 'c'})
    assert fact_cache['a'] == {'b': 'c'}

    fact_cache.first_order_merge('a', {'b': 'd'})
    assert fact_cache['a'] == {'b': 'c', 'b': 'd'}

    fact_cache.first_order_merge('a', {'c': 'd'})
    assert fact_cache['a'] == {'b': 'c', 'b': 'd', 'c': 'd'}

# Generated at 2022-06-21 09:28:01.807225
# Unit test for constructor of class FactCache
def test_FactCache():
    assert True

# Generated at 2022-06-21 09:28:12.238832
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact = FactCache()
    host_name = "10.0.0.1"
    value = {u'ansible_distribution': u'Ubuntu', u'ansible_distribution_version': u'16.04'}
    fact[host_name] = value
    ansible_distribution = value[u'ansible_distribution']
    ansible_distribution_version = value[u'ansible_distribution_version']
    ansible_os_family = value[u'ansible_os_family']
    fact[host_name] = value
    ansible_distribution = value[u'ansible_distribution']
    ansible_distribution_version = value[u'ansible_distribution_version']
    ansible_os_family = value[u'ansible_os_family']
    fact

# Generated at 2022-06-21 09:28:17.772145
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    my_cache = FactCache()
    my_cache['192.168.0.1'] = [{'ansible_ssh_host': '192.168.0.1'}]
    my_cache['192.168.0.2'] = [{'ansible_ssh_host': '192.168.0.2'}]

    assert isinstance(my_cache, FactCache)
    for key in my_cache:
        assert key == '192.168.0.1' or key == '192.168.0.2'


# Generated at 2022-06-21 09:28:24.218451
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    host = "test-host"
    value = {"foo": "bar"}
    fact_cache.first_order_merge(host, value)
    assert fact_cache[host]["foo"] == "bar"

    new_value = {"foo": "baz"}
    fact_cache.first_order_merge(host, new_value)
    assert fact_cache[host]["foo"] == "baz"

# Generated at 2022-06-21 09:28:32.187180
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    from ansible.utils.display import Display

    display = Display()
    # replace the real display with our stub
    from ansible.module_utils.facts import cache
    cache.display = display
    # replace the real cache_loader with our stub
    from ansible.module_utils.facts import cache
    from ansible.plugins.loader import cache_loader
    cache_loader_stub = cache_loader
    cache_loader_stub.get = lambda a1: cache_loader_stub
    cache_loader_stub.delete = lambda a1: None
    cache.cache_loader = cache_loader_stub
    # execute code
    o = cache.FactCache({})
    o.__delitem__('a')
    # verify results

# Generated at 2022-06-21 09:28:35.739277
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    cache = FactCache()
    cache.__setitem__('a', '1')
    assert cache.__contains__('a')
    assert not cache.__contains__('b')



# Generated at 2022-06-21 09:28:40.296768
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    fact_cache_keys = fact_cache.keys()
    
    assert fact_cache_keys == []
    
    # Test that the cache is empty with new instance
    fact_cache_keys_flush = fact_cache.flush()
    assert fact_cache_keys_flush == None



# Generated at 2022-06-21 09:28:44.960274
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fc = FactCache()
    assert fc.__len__() == 0
    fc['abc'] = 'abc'
    assert fc.__len__() == 1
    fc['def'] = 'def'
    assert fc.__len__() == 2
    del fc['def']
    assert fc.__len__() == 1
    del fc['abc']
    assert fc.__len__() == 0


# Generated at 2022-06-21 09:28:52.678674
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    import os
    import tempfile
    import random

    # create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # create a temporary key
    key = 'key_' + str(random.randint(1, 10000))
    value = {}
    value['key1'] = 'value1'
    value['key2'] = 'value2'

    # create the FactCache object
    fact_cache = FactCache({})

    # update the cache with a new entry
    fact_cache._plugin.keys()[key] = value
    assert fact_cache[key] == value

    # remove the temporary directory
    os.rmdir(tmp_dir)



# Generated at 2022-06-21 09:29:01.368237
# Unit test for constructor of class FactCache
def test_FactCache():
    import sys
    import os
    sys.path.append(os.path.join(os.path.dirname(__file__), '../../..'))
    import Ansible_test
    ansible_test = Ansible_test.get_ansible_test()
    cache_plugin = ansible_test.get_cache_plugin()
    assert cache_plugin != None
    fact_cache = FactCache(cache_plugin)
    assert fact_cache != None

# Generated at 2022-06-21 09:29:04.587388
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fc = FactCache()
    fc['test'] = 'test'
    assert fc._plugin.get('test') == 'test'


# Generated at 2022-06-21 09:29:13.413926
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    """Test the keys method of class FactCache"""
    import pytest
    from ansible.module_utils.cache import CacheModule, fact_cache
    from ansible.module_utils.facts.ansible_local import AnsibleLocalFactCollector
    from ansible.module_utils.facts.base import BaseFactCollector
    import sys
    import os

    fc = FactCache()
    hostvars = fact_cache._fact_cache.get('_hostvars')
    if not hostvars:
        hostvars = {'_hostvars': {
            'test_host': {
                'test_fact_1': 'test_value_1',
                'test_fact_2': 'test_value_2'
            }
        }}
        fact_cache._fact_cache.update(hostvars)

    keys

# Generated at 2022-06-21 09:29:15.383003
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin != None


# Generated at 2022-06-21 09:29:17.256743
# Unit test for constructor of class FactCache
def test_FactCache():
    # FIXME: add unit tests
    assert False, "FactCache unit test not implemented"

# Generated at 2022-06-21 09:29:21.285332
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fc = FactCache()
    fc['test1'] = 1
    fc['test2'] = 3
    copy_dict = fc.copy()
    assert copy_dict['test1'] == 1
    assert copy_dict['test2'] == 3


# Generated at 2022-06-21 09:29:29.783686
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    """ Tests for FactCache.__contains__() """
    # Create a fake cache
    cache = {
        'host1': {
            'ansible_distribution': 'CentOS',
            'ansible_distribution_major_version': '6',
        },
        'host2': {
            'ansible_distribution': 'CentOS',
            'ansible_distribution_major_version': '7',
        },
        'host3': {
            'ansible_distribution': 'Debian',
            'ansible_distribution_major_version': '8',
        }
    }

    # Create a fact cache
    fact_cache = FactCache()
    fact_cache._plugin = object()
    fact_cache._plugin.contains = lambda host: host in cache

# Generated at 2022-06-21 09:29:32.721541
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    fact_cache.keys()
    assert fact_cache.keys() == None


# Generated at 2022-06-21 09:29:38.408247
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    my_dict = {'key_1': 'value_1', 'key_2': 'value_2'}
    fact_cache.__setitem__('key_1', 'value_1')
    fact_cache.__setitem__('key_2', 'value_2')
    assert fact_cache.keys() == list(my_dict.keys())

# Generated at 2022-06-21 09:29:42.813634
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    class TestPlugin(object):
        def keys(self):
            return ['plugin_key1', 'plugin_key2']

    test_cache = FactCache()
    test_cache._plugin = TestPlugin()
    assert test_cache.keys() == ['plugin_key1', 'plugin_key2']
    test_cache.flush()

# Generated at 2022-06-21 09:29:53.323411
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    import sys
    if sys.version_info[0] < 3:
        from mock import patch, MagicMock
    else:
        from unittest.mock import patch, MagicMock
    mock_plugin = MagicMock()
    with patch.object(cache_loader, 'get', return_value=mock_plugin):
        fc = FactCache()
        fc.__delitem__('test_key')
        mock_plugin.delete.assert_called_once_with('test_key')


# Generated at 2022-06-21 09:29:57.053482
# Unit test for method flush of class FactCache
def test_FactCache_flush():

    fact_cache = FactCache()

    if not fact_cache:
        raise AssertionError("FactCache object is empty.")

    fact_cache.flush()
    if fact_cache:
        raise AssertionError("FactCache object is not empty.")
    else:
        pass


# Generated at 2022-06-21 09:30:02.752546
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache = FactCache()
    fact_cache['test_del_key'] = 'test_del_value'
    assert(fact_cache['test_del_key'] == 'test_del_value')
    del fact_cache['test_del_key']
    assert('test_del_key' not in fact_cache)

# Generated at 2022-06-21 09:30:14.403249
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    def test_exception(cache, key):
        try:
            cache.__getitem__(key)
        except KeyError:
            pass
        except Exception as e:
            raise e

    def test_not_exception(cache, key):
        try:
            cache.__getitem__(key)
        except Exception as e:
            raise e

    class TestCacheClass:
        def __init__(self):
            self.cache = {}
        def contains(self, key):
            return key in self.cache
        def get(self, key):
            return self.cache[key]
        def keys(self):
            return self.cache.keys()

    class TestCacheClassException(TestCacheClass):
        def get(self, key):
            if key in self.cache:
                return self.cache[key]

# Generated at 2022-06-21 09:30:21.571076
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    print('\nRunning unit test for method "__getitem__" of class "FactCache"...\n ')
    fact_cache_test = FactCache()
    try:
        fact_cache_test.__getitem__('test')
    except KeyError:
        print ('test_FactCache___getitem__ success')
        return True
    print ('test_FactCache___getitem__ failed')
    return False


# Generated at 2022-06-21 09:30:30.154405
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    expected_keys = ['ansible_default_ipv4', 'ansible_default_ipv6', 'ansible_facts', 'ansible_system']
    test_facts = dict(ansible_default_ipv4=dict(address="172.16.0.1", alias="lo", interface="lo", type="ether"),
                      ansible_default_ipv6=dict(address="fe80::1", interface="lo"),
                      ansible_facts=dict(contact="johndoe@domain.com", domain="domain.com", fqdn="host.domain.com", hostname="host"),
                      ansible_system=dict(domain="domain.com"))

    test_fact_cache = FactCache(test_facts)
    assert expected_keys == test_fact_cache.keys()
    assert test_facts == test_fact_

# Generated at 2022-06-21 09:30:30.766166
# Unit test for constructor of class FactCache
def test_FactCache():
    pass

# Generated at 2022-06-21 09:30:34.788626
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():

    fact_cache = FactCache()

    test_key = 'test_key'
    test_value = {'test_key': 'test_value'}

    fact_cache.__setitem__(test_key, test_value)

    assert fact_cache.__getitem__(test_key) == test_value


# Generated at 2022-06-21 09:30:47.086992
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    # initialize fact cache as below

# Generated at 2022-06-21 09:30:54.010471
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    from ansible.plugins.cache import base
    import mock
    import json

    class AnsibleCachePlugin(base.BaseCacheModule):
        """ Dummy plugin for testing purpose. """
        def __init__(self):
            self._cache = {}

        def contains(self, key):
            return key in self._cache

        def get(self, key):
            return self._cache[key]

        def set(self, key, value):
            self._cache[key] = value

        def delete(self, key):
            del self._cache[key]

        def flush(self):
            self._cache.clear()

        def keys(self):
            return list(self._cache.keys())


    plugin = AnsibleCachePlugin()
    factcache = FactCache(plugin)


# Generated at 2022-06-21 09:31:06.501694
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():

    # Test case key exists
    fact_cache = FactCache()
    test_key = 'test_key'
    test_value = 'test_value'
    fact_cache[test_key] = test_value
    if fact_cache.__getitem__(test_key) != test_value:
        raise AssertionError('test_case failed')

    # Test case key doesn't exist
    fact_cache2 = FactCache()
    test_key2 = 'test_key2'
    try:
        fact_cache2.__getitem__(test_key2)
        raise AssertionError('test_case failed')
    except KeyError:
        pass


# Generated at 2022-06-21 09:31:13.031962
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    cache = FactCache()
    cache._plugin.keys.return_value =['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','v','u','w','x','y','z']
    array = []
    for key in cache:
        array.append(key)
    assert array == cache._plugin.keys.return_value


# Generated at 2022-06-21 09:31:15.177673
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    assert len(fact_cache) == 0
    fact_cache.flush()


# Generated at 2022-06-21 09:31:18.418233
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    # Arrange
    test_cache = None
    cache_mock = {
        "flush": lambda: None
    }

    # Act
    test_cache = FactCache()
    test_cache._plugin = cache_mock
    test_cache.flush()

    # Assert
    assert True


# Generated at 2022-06-21 09:31:21.240643
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():

    fc = FactCache()
    fc['foo'] = 42
    fc['bar'] = 43

    assert len(fc) == 2



# Generated at 2022-06-21 09:31:31.437731
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    import os
    import sys
    import time

    #from ansible.module_utils.facts import cache as fact_cache

    # create a temp cache dir and set C.CACHE_PLUGIN to a file based plugin
    tmp_dir = os.path.join(os.getcwd(), 'test_dir')
    os.makedirs(tmp_dir)
    file_based_plugin = os.path.join(os.path.dirname(sys.modules[fact_cache.__module__].__file__), 'file_cache.py')
    C.CACHE_PLUGIN = file_based_plugin

    # create a FactCache object
    fact_cache_obj = FactCache()
    assert fact_cache_obj

    # a new cache dir should have no keys

# Generated at 2022-06-21 09:31:33.000844
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    assert len(fact_cache) == 0

# Generated at 2022-06-21 09:31:36.610438
# Unit test for constructor of class FactCache
def test_FactCache():
    """
    This function is used as unit test for the constructor of class FactCache.
    """

    fact_cache = FactCache()
    """ :type: FactCache """

    assert isinstance(fact_cache, FactCache)

# Generated at 2022-06-21 09:31:39.644783
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, MutableMapping)

# Generated at 2022-06-21 09:31:46.856373
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():

    def mock_get(self, key):
        return {'success':'true'}

    def mock_contains(self, key):
        return True

    import collections
    mock_plugin=collections.namedtuple("mock_plugin", ['get', 'contains'])
    mock_plugin.get = mock_get
    mock_plugin.contains = mock_contains

    facts_cache = FactCache()
    facts_cache._plugin = mock_plugin()

    assert facts_cache['test_host'] == {'success':'true'}


# Generated at 2022-06-21 09:32:01.105791
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
	cache = FactCache()
	a = iter(cache)
	assert(a != None)


# Generated at 2022-06-21 09:32:02.545618
# Unit test for constructor of class FactCache
def test_FactCache():
    # test invalid plugin
    FACTCACHE_INSTANCE = FactCache()

# Generated at 2022-06-21 09:32:09.763840
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():

    import os
    import stat
    import json
    import tempfile
    import shutil
    import time

    class FilesystemCache(object):
        def __init__(self, *args, **kwargs):
            self._cache_dir = os.path.join(tempfile.gettempdir(), 'ansible-fact-cache')
            self._create_cache_dir()


# Generated at 2022-06-21 09:32:12.979521
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fc = FactCache()
    fc['x'] = 'y'
    keys = fc.keys()
    assert keys == ['x'], 'FactCache.__setitem__() did not work as expected'



# Generated at 2022-06-21 09:32:16.398555
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    cache = FactCache()
    assert cache.keys() == []
    cache['abc'] = 'def'
    assert cache.keys() == ['abc']
    assert cache['abc'] == 'def'
    del cache['abc']
    assert cache.keys() == []

# Generated at 2022-06-21 09:32:19.166723
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    fact_cache['localhost'] = {'something': 'something'}
    assert 'localhost' in fact_cache.keys()


# Generated at 2022-06-21 09:32:25.935831
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    from ansible.module_utils.facts.cache import FactCache
    from ansible.module_utils.facts.fact_cache_data import FactCacheData
    f = FactCache()
    f.__setitem__('ansible_architecture', FactCacheData(cache_time=1528934782.4001448))
    f.__delitem__('ansible_architecture')
    assert not f.keys()


# Generated at 2022-06-21 09:32:33.549638
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():

    # create a dummy class which has all method of CacheBase
    class cache_dummy(object):
        def __init__(self):
            pass

        def contains(self, key):
            return True

    # create a FactCache class
    factcache = FactCache()

    # assign the cache_dummy class to the _plugin variable of FactCache
    factcache._plugin = cache_dummy()

    # any key should be found into the cache
    assert "test" in factcache

# Generated at 2022-06-21 09:32:35.578412
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    facts = FactCache()
    facts['key'] = "value"
    assert facts['key'] == "value"


# Generated at 2022-06-21 09:32:39.786577
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    fact_cache['192.168.0.1'] = 'test'
    assert list(fact_cache.keys()) == ['192.168.0.1']
    fact_cache.flush()
    assert not fact_cache.keys()


# Generated at 2022-06-21 09:33:07.584598
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = FactCache()
    fact_cache['test'] = 'test'
    pass


# Generated at 2022-06-21 09:33:17.298667
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    class CachePlugin(object):
        def __init__(self, *args, **kwargs):
            pass
        def get(self, key):
            return 'test'
        def set(self, key, value):
            pass
        def delete(self, key):
            pass
        def contains(self, key):
            return True
        def keys(self):
            pass
        def flush(self):
            pass

    cache_loader.set('cache_plugin', CachePlugin)
    c = FactCache()
    return c['x']

# Test __getitem__
assert test_FactCache___getitem__() == 'test'

# Generated at 2022-06-21 09:33:26.595442
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    # Init FactCache class
    f = FactCache()

    # call __contains__ method of FactCache class with sample data

# Generated at 2022-06-21 09:33:37.221728
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    import time
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.plugins.loader import cache_loader
    from ansible.utils.display import Display

    display = Display()


    class MyCache(MutableMapping):

        def __init__(self, *args, **kwargs):
            self.keys = []
            self.values = []
            super(MyCache, self).__init__(*args, **kwargs)

        def __getitem__(self, key):
            try:
                return self.values[self.keys.index(key)]
            except IndexError:
                raise KeyError

        def __setitem__(self, key, value):
            self.keys.append(key)
            self.values.append(value)


# Generated at 2022-06-21 09:33:46.280938
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    display.success("Running test for method __getitem__ of class FactCache")
    # test if it raises AnsibleError without the facts plugin
    try:
        FC_object = FactCache()
    except AnsibleError as e:
        display.success("Method __getitem__ of class FactCache raises a AnsibleError without a facts plugin")
    # test if it raises KeyError if the record does not exist
    hostvars = load_fixture("hostvars")
    FC_object = FactCache()
    # write record to the facts cache
    FC_object.update(hostvars)
    try:
        # read record from facts cache
        FC_object["hostvars"]
    except KeyError as e:
        display.success("Method __getitem__ of class FactCache raises a KeyError if the record does not exist")
    # test

# Generated at 2022-06-21 09:33:49.225192
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    display.quiet(True)

    fc = FactCache()
    results = [i for i in fc]

    display.quiet(False)
    assert(results == [])



# Generated at 2022-06-21 09:33:59.002873
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    key = "foo"
    value = {'a': 1}

    fc.first_order_merge(key, value)
    assert(fc[key] == {'a': 1})

    value = {'a': 2}
    fc.first_order_merge(key, value)
    assert(fc[key] == {'a': 1})

    value = {'b': 2}
    fc.first_order_merge(key, value)
    assert(fc[key] == {'a': 1, 'b': 2})


# Generated at 2022-06-21 09:34:06.055082
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    # create new object
    fact_cache = FactCache()

    # check that it is empty
    assert list(fact_cache) == []

    # add a new key
    fact_cache['new_key'] = "new_value"
    assert list(fact_cache) == ['new_key']

    # flush the cache
    fact_cache.flush()

    # check that it is empty
    assert list(fact_cache) == []

# Generated at 2022-06-21 09:34:09.701919
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():

    cache = FactCache()

    cache['a'] = 1
    assert cache['a'] == 1

    del cache['a']

    try:
        cache['a']
    except KeyError:
        pass


# Generated at 2022-06-21 09:34:17.872576
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_obj = FactCache()
    key = "key1"
    value = "value1"
    if fact_cache_obj.__contains__(key):
        del fact_cache_obj[key]
    fact_cache_obj.first_order_merge(key, value)
    assert key in fact_cache_obj.keys()
    assert key in fact_cache_obj
    assert fact_cache_obj[key] == value
    fact_cache_obj.flush()
    assert not key in fact_cache_obj.keys()
    assert not key in fact_cache_obj

# Generated at 2022-06-21 09:35:18.971440
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():

    fact_cache = FactCache()
    fact_cache['host'] = {'key1': 'value1'}

    actual = fact_cache['host']['key1']
    expected = 'value1'
    assert actual == expected


# Generated at 2022-06-21 09:35:22.331380
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    facts = FactCache()
    facts['testhost'] = {'testkey': 'testvalue'}
    assert facts['testhost']['testkey'] == 'testvalue'
    invalidhost = 'unknownhost'
    try:
        facts[invalidhost]
    except KeyError:
        pass
    else:
        raise ValueError


# Generated at 2022-06-21 09:35:25.505789
# Unit test for constructor of class FactCache
def test_FactCache():
  cache = FactCache()
  print(cache)
  # cache.__setitem__('a', '1')
  # print(cache['a'])

test_FactCache()

# Generated at 2022-06-21 09:35:27.834752
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    cache = FactCache()
    keys = list(cache)
    assert isinstance(keys, list)

# Generated at 2022-06-21 09:35:31.385916
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    cache = FactCache()
    cache['test_key'] = 'test_value'
    assert cache['test_key'] == 'test_value'


# Generated at 2022-06-21 09:35:39.325035
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    """ check if the method provide the iterator of the factcache objects"""
    f = FactCache()
    f.__setitem__('a',1)
    f.__setitem__('b',2)
    f.__setitem__('c',3)
    f.__setitem__('d',4)
    assert 'a' in f
    assert 'b' in f
    assert 'c' in f
    assert 'd' in f
    assert 'e' not in f
    it = iter(f)
    n = 0
    while True:
        try:
            v = next(it)
            n += 1
        except StopIteration:
            break
    print("Number of keys",n)
    assert n == 4


# Generated at 2022-06-21 09:35:42.702748
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    factCache = FactCache()
    factCache[1] = 1
    factCache['1'] = 1
    factCache[(1,)] = 1
    for key in factCache:
        print(key)

test_FactCache___iter__()

# Generated at 2022-06-21 09:35:51.333222
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    host_fact = {'key1': 'value1', 'key2': 'value2'}
    fc.first_order_merge('host1', host_fact)
    assert fc['host1'] == host_fact
    fc.first_order_merge('host1', {'key1': 'value1', 'key2': 'value2'})
    assert fc['host1'] == host_fact
    fc.first_order_merge('host1', {'key1': 'value1', 'key3': 'value3'})
    assert fc['host1'] == host_fact
    fc.first_order_merge('host1', {})
    assert fc['host1'] == host_fact

# Generated at 2022-06-21 09:35:52.697372
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fact_cache = FactCache(dict())
    assert iter(fact_cache) == fact_cache._plugin.keys()

# Generated at 2022-06-21 09:36:00.631337
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    import mock
    import copy
    import ansible

    fact_cache = FactCache()
    fact_cache_copy = copy.copy(fact_cache)
    assert fact_cache_copy == fact_cache.copy()

    fact_cache = FactCache()
    fact_cache['1'] = '1'
    fact_cache['2'] = '2'
    fact_cache['3'] = '3'
    fact_cache_copy = copy.copy(fact_cache)
    assert fact_cache_copy == fact_cache.copy()
