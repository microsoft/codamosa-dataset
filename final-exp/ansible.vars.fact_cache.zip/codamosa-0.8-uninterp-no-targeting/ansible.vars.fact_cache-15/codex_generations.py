

# Generated at 2022-06-21 09:27:15.305410
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():

    cache = FactCache()
    cache['test'] = 'test'
    cache['test1'] = 'test1'
    cache['test2'] = 'test2'
    cache['test3'] = 'test3'
    del cache['test']
    assert cache.keys() == ['test1', 'test2', 'test3']



# Generated at 2022-06-21 09:27:25.024677
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    facts_cache = FactCache()
    # case 1: no facts in cache for a given host
    key = 'test_hostname'
    value = {'ansible_facts': {'test_fact': 'bar'}}
    # flush out any old facts
    facts_cache.flush()
    facts_cache.first_order_merge(key, value)
    assert facts_cache.keys() == [key]
    assert facts_cache[key] == value
    # case 2: facts in cache for a given host
    value = {'ansible_facts': {'test_fact': 'bar', 'test_fact2': 'baz'}}
    facts_cache.first_order_merge(key, value)
    assert facts_cache.keys() == [key]

# Generated at 2022-06-21 09:27:27.698139
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = FactCache()
    fact_cache['key'] = 'value'
    assert fact_cache['key'] == 'value'


# Generated at 2022-06-21 09:27:36.061084
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    display.display('test_FactCache___contains__()')

    facts_cache = FactCache()

    display.display('\t(1) Initialized FactCache object with given items')
    facts_cache_items = {'host1': {'ansible_distribution': 'CentOS'}}
    facts_cache.update(facts_cache_items)

    display.display('\t(2) Check for existing item in FactCache')
    assert 'host1' in facts_cache
    display.display('\t(3) Check for non-existing item in FactCache')
    assert 'host2' not in facts_cache


# Generated at 2022-06-21 09:27:37.985061
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
   # Create an instance of FactCache
   fact_cache = FactCache()

   # Attempt to iterate a empty fact cache
   for k in fact_cache:
       pass

# Generated at 2022-06-21 09:27:50.074425
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    new_cache = {
        "test_host": {
            "test_fact": "test_value"
        }
    }
    expected_cache = {
        "test_host": {
            "test_fact": "test_value",
            "new_fact": "new_value",
        }
    }

    print("\nPerforming unit test for method __setitem__ of class FactCache")

    print("> Create new fact cache object...")
    cache = FactCache()

    print("> Populate new fact cache object...")
    for k, v in new_cache.items():
        cache[k] = v

    for k, v in expected_cache.items():
        print("> Verify fact cache object contains expected key...")
        assert k in cache


# Generated at 2022-06-21 09:27:54.593399
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    assert hasattr(FactCache, '__iter__')
    fact_cache = FactCache()
    try:
        iter(fact_cache)
    except NotImplementedError:
        assert False, "The __iter__ method of FactCache has not been Implemented"
    except Exception:
        assert True


# Generated at 2022-06-21 09:27:56.000106
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    _FactCache = FactCache()
    assert _FactCache.__delitem__()

# Generated at 2022-06-21 09:27:57.891126
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    f = FactCache()
    ret = f.__contains__("test")
    return ret

# Generated at 2022-06-21 09:28:03.133048
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    # Create a cache with a fake plugin
    plugin = FakePlugin()
    cache = FactCache()
    cache._plugin = plugin

    # Populate the cache
    fake_data = {"key1":"value1", "key2":"value2"}
    cache._plugin.populate(fake_data)

    # Delete a key
    cache.__delitem__("key1")

    # Assert item has been deleted
    assert cache._plugin.get("key1") == None


# Generated at 2022-06-21 09:28:13.984728
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    # Create a new FactCache object
    key1 = "key1"
    value1 = "value1"
    key2 = "key2"
    value2 = "value2"
    host_facts = {key1: value1, key2: value2}
    cache = FactCache()
    cache.update(host_facts)

    # Get length of cache
    cache_len = len(cache)

    # Check if cache length is right
    assert cache_len == 2, "Cache length is wrong"

# Generated at 2022-06-21 09:28:18.727025
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fc = FactCache()
    key1 = "1"
    key2 = "2"
    fc[key1] = "1"
    fc[key2] = "2"
    keys = fc.keys()

    assert key1 in keys
    assert key2 in keys

# Generated at 2022-06-21 09:28:20.624989
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    assert isinstance(fact_cache.keys(), list)


# Generated at 2022-06-21 09:28:25.656888
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fc = FactCache()
    fc.flush()
    assert 'test_contains' not in fc
    fc['test_contains'] = 'test_value_contains'
    assert 'test_contains' in fc
    del fc['test_contains']
    assert 'test_contains' not in fc


# Generated at 2022-06-21 09:28:26.768085
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    pass


# Generated at 2022-06-21 09:28:30.240292
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    cache = {
        'host1': {
            '1': 'one',
            '2': 'two'
        },
        'host2': {
            '3': 'three',
            '4': 'four'
        }
    }

    fact_cache = FactCache()
    fact_cache._plugin = TestCachePlugin(cache)
    fact_cache_copy = fact_cache.copy()

    assert fact_cache_copy == cache


# Generated at 2022-06-21 09:28:37.185726
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    display.verbosity = 0
    factCache = FactCache()
    factCache.first_order_merge('test',{'a':1})
    factCache.first_order_merge('test',{'b':2})
    factCache.first_order_merge('test',{'c':3})
    
    assert factCache['test'] == {'a':1,'b':2,'c':3}


# Generated at 2022-06-21 09:28:45.812585
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    from ansible.plugins.cache.jsonfile import CacheModule as jsonfile
    from ansible.module_utils._text import to_text
    import os
    fd, td = mkstemp()  # pylint: disable=unbalanced-tuple-unpacking
    os.close(fd)
    fc = FactCache()
    if os.path.exists(td):
        os.remove(td)

# Generated at 2022-06-21 09:28:47.855406
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    result = fact_cache.copy()
    assert {} == result


# Generated at 2022-06-21 09:28:48.785734
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    pass


# Generated at 2022-06-21 09:28:54.933359
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-21 09:28:58.934977
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    cache = FactCache()
    cache.first_order_merge('127.0.0.1', {'a': 1})
    cache.flush()
    assert len(cache.keys()) == 0

# Generated at 2022-06-21 09:28:59.551536
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    pass

# Generated at 2022-06-21 09:29:00.773543
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    assert False, "Not implemented"


# Generated at 2022-06-21 09:29:02.595899
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fact_cache = FactCache()
    assert iter(fact_cache) == iter(())

# Generated at 2022-06-21 09:29:05.507884
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact = FactCache()
    fact['key'] = 'value'
    if fact['key'] == 'value':
        return True
    else:
        return False

# Generated at 2022-06-21 09:29:06.643625
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    assert isinstance(FactCache().copy(), dict)

# Generated at 2022-06-21 09:29:10.913690
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache = FactCache()
    fact_cache['test_key'] = 'test_value'
    assert len(fact_cache) == 1
    del fact_cache['test_key']
    assert len(fact_cache) == 0

if __name__ == '__main__':
    test_FactCache___delitem__()

# Generated at 2022-06-21 09:29:14.570645
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    cache = FactCache()
    cache['test'] = 'test'
    assert cache['test'] == 'test'
    try:
        cache['not_exist']
        assert False
    except KeyError:
        assert True


# Generated at 2022-06-21 09:29:16.933842
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fact_cache = FactCache()
    assert(hasattr(fact_cache, '__iter__'))


# Generated at 2022-06-21 09:29:36.443316
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert 'localhost' not in fact_cache
    fact_cache['localhost'] = {}
    assert 'localhost' in fact_cache
    fact_cache['otherhost'] = {}
    assert fact_cache.keys() == ['localhost', 'otherhost']
    fact_cache.__delitem__('otherhost')
    assert fact_cache.keys() == ['localhost']
    del fact_cache['localhost']
    assert fact_cache.keys() == []
    assert fact_cache.copy() == {}
    assert 'localhost' not in fact_cache
    fact_cache['localhost'] = {}
    assert fact_cache.first_order_merge('localhost', {'a': 'b'}) == {'localhost': {'a': 'b'}}

# Generated at 2022-06-21 09:29:38.041272
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    # TODO: add some useful test cases
    FactCache_obj = FactCache()
    assert True

# Generated at 2022-06-21 09:29:39.084906
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    # fact_cache = FactCache(self)
    assert False, "Test if the method is implemented."



# Generated at 2022-06-21 09:29:41.032283
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    assert len(fact_cache) == 0
    fact_cache['localhost'] = dict(test='test-value')
    assert len(fact_cache) == 1
    fact_cache.flush()

# Generated at 2022-06-21 09:29:45.047913
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    factcache = FactCache()
    factcache._plugin.set("testkey1", {'testkey1':'testval1'})
    factcache._plugin.set("testkey2", {'testkey2':'testval2'})
    assert len(factcache) == 2
    factcache.flush()
    assert len(factcache) == 0

# Generated at 2022-06-21 09:29:51.853324
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fc = FactCache()
    fc['a'] = 1
    fc['b'] = 2
    fc['c'] = 3
    fc['d'] = 4
    fc['e'] = 5

    # Clear all the keys
    fc.flush()

    # Re-populate some data
    fc['a'] = 1
    fc['b'] = 2
    fc['c'] = 3

    # Run the copy method
    facts = fc.copy()

    # Assert the copy has the same items as the FactCache
    assert len(facts) == len(fc)
    for item in ['a', 'b', 'c']:
        assert item in facts
        assert item in fc

# Generated at 2022-06-21 09:30:00.369143
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    from ansible.plugins.cache import BaseCacheModule

    class MyCache(BaseCacheModule):
        # Class attribute with default implementation of the BaseCacheModule method that must be overriden
        CACHE_PLUGIN_NAMESPACE = 'ansible.test_cache_plugin'

        def __init__(self):
            self.cache = {}

        def get(self, key):
            return self.cache[key]

        def set(self, key, value):
            self.cache[key] = value

        def keys(self):
            return list(self.cache.keys())

        def contains(self, key):
            return key in self.cache

        def delete(self, key):
            del self.cache[key]

        def flush(self):
            self.cache.clear()

    # Create a instance
    cache

# Generated at 2022-06-21 09:30:02.656455
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fact_cache  = FactCache()
    assert 'FactCache' == fact_cache.__class__.__name__

# Generated at 2022-06-21 09:30:07.507402
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    assert len(fact_cache) == 0
    fact_cache['my_key'] = ['my_value', 'my_value2']
    assert len(fact_cache) == 1
    fact_cache['my_key2'] = ['my_value2']
    assert len(fact_cache) == 2

# Generated at 2022-06-21 09:30:11.140845
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    cache_plugin = cache_loader.get(C.CACHE_PLUGIN)
    cache = FactCache()
    cache._plugin = cache_plugin
    cache.__delitem__("192.168.1.1")


# Generated at 2022-06-21 09:30:31.289896
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    cache = FactCache()
    cache['key1'] = 'value1'
    cache['key2'] = 'value2'
    cache['key3'] = 'value3'
    cache['key4'] = {'key5': 'value5'}
    assert cache.copy() == {'key1': 'value1', 'key2': 'value2', 'key3': 'value3', 'key4': {'key5': 'value5'}}


# Generated at 2022-06-21 09:30:40.598786
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    import hashlib
    import datetime

    # Create a new display object to get new show_custom_stats() method
    display = Display()

    # Create a new fact cache
    fact_cache = FactCache()

    # Set a key in the cache
    key = hashlib.sha256('test').hexdigest()
    value = {'test_id': 123}
    fact_cache[key] = value

    # Assert the key is in the cache
    assert key in fact_cache

    # Flush the cache
    fact_cache.flush()

    # Assert the key is not in the cache
    assert key not in fact_cache



# Generated at 2022-06-21 09:30:42.360259
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    c = FactCache()
    c.flush()

# Generated at 2022-06-21 09:30:42.960240
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    pass

# Generated at 2022-06-21 09:30:47.035435
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = FactCache()
    fact_cache.flush()
    fact_cache['key1'] = 'value1'
    assert fact_cache._plugin.get('key1') == 'value1'
    assert fact_cache['key1'] == 'value1'


# Generated at 2022-06-21 09:30:48.060699
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    factcache = FactCache()
    factcache['test'] = 'test'
    assert 'test' in factcache


# Generated at 2022-06-21 09:30:53.863086
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    import tempfile, os
    tmpdir = tempfile.mkdtemp()
    C.CACHE_PLUGIN = 'jsonfile'
    C.CACHE_PLUGIN_CONNECTION = '%s/facts' % tmpdir
    C.CACHE_PLUGIN_PREFIX = ''

    fact_cache = FactCache()
    fact_cache['localhost'] = {'foo': 'bar'}

    assert os.path.exists(C.CACHE_PLUGIN_CONNECTION)

    fact_cache.flush()
    assert not os.path.exists(C.CACHE_PLUGIN_CONNECTION)

    os.removedirs(tmpdir)

# Generated at 2022-06-21 09:30:59.798335
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():

    import json
    a = FactCache()
    a._plugin = cache_loader.get(C.CACHE_PLUGIN)
    a._plugin.set('localhost', json.dumps({'localhost': {'ansible_facts': {'result': False}}}, sort_keys=True))
    assert a['localhost'] == {'ansible_facts': {'result': False}}

# Generated at 2022-06-21 09:31:05.123771
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fact_cache = FactCache()
    assert fact_cache._plugin.__class__.__name__ == 'MemoryCacheModule'
    fact_cache._plugin.set('key1', 1)
    fact_cache._plugin.set('key2', 2)
    assert set(fact_cache.__iter__()) == set(['key1', 'key2'])



# Generated at 2022-06-21 09:31:07.338108
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fc = FactCache()
    key = 'key1'
    value = {'key2': 'value2'}
    fc['key1'] = value
    assert key in fc

# Generated at 2022-06-21 09:31:42.761924
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache1 = FactCache()
    fact_cache1["test"] = "test"
    assert fact_cache1.__contains__("test")
    assert fact_cache1["test"] == "test"
    fact_cache1.__delitem__("test")
    assert not fact_cache1.__contains__("test")



# Generated at 2022-06-21 09:31:47.012191
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    mp_contains = cache_loader.get(C.CACHE_PLUGIN).contains
    cache = FactCache()
    cache._plugin.contains = lambda k: mp_contains(k) and k == '123'
    assert '123' in cache



# Generated at 2022-06-21 09:31:58.024785
# Unit test for constructor of class FactCache
def test_FactCache():
    # Instantiating FactCache class
    fact_cache = FactCache()
    assert(isinstance(fact_cache, MutableMapping))
    # First order merge test
    fact_cache.first_order_merge('test', 'test2')
    fact_cache.copy()
    fact_cache.keys()
    fact_cache.flush()
    fact_cache.__contains__('test')
    # Exception test
    try:
        display.verbosity = 0
        fact_cache.__getitem__('test')
    except KeyError as e:
        print('KeyError exception caught: %s' % str(e))


# FactsCache class unit test
if __name__ == "__main__":
    test_FactCache()

# Generated at 2022-06-21 09:32:05.370107
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    cache.update({"key1": {"a1": "a1", "b1": "b1"}})
    cache.first_order_merge("key1", {"c1": "c1", "d1": "d1"})
    assert len(cache) == 1
    assert cache.get("key1")["a1"] == "a1"
    assert cache.get("key1")["b1"] == "b1"
    assert cache.get("key1")["c1"] == "c1"
    assert cache.get("key1")["d1"] == "d1"

# Generated at 2022-06-21 09:32:09.483386
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fc = FactCache()
    assert len(fc) == 0
    fc['localhost'] = None
    assert len(fc) == 1
    del fc['localhost']
    assert len(fc) == 0


# Generated at 2022-06-21 09:32:18.436067
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    host_cache = {'ansible_distribution': 'CentOS',
                  'ansible_distribution_version': '7.2',
                  'ansible_architecture': 'x86_64',
                  'ansible_os_family': 'RedHat'}
    host_facts = {'ansible_lsb': {'description': 'CentOS Linux release 7.2.1511 (Core)',
                                  'major_release': '7',
                                  'release': '7.2.1511',
                                  'codename': 'Core',
                                  'distributor_id': 'CentOS',
                                  'distributor': 'CentOS'}}
    fact_cache.first_order_merge('localhost', host_facts)
    fact_cache.first_order_merge

# Generated at 2022-06-21 09:32:27.606472
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    # test_model = {'ec2_instance_id': 'i-073e8b38a6cc5d6cf', 'ansible_check_mode': False}
    test_model = {'ansible_check_mode': False, 'ansible_facts': {'ansible_check_mode': False, 'ansible_distribution_version': '16.04', 'ansible_facts': {}, 'ansible_distribution': 'ubuntu'}}
    # cache = FactCache()
    cache = FactCache(test_model)
    print(cache['ec2_instance_id'])


# Generated at 2022-06-21 09:32:28.232068
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc

# Generated at 2022-06-21 09:32:39.389956
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    def test_assert(key, value, expected_value):
        t = FactCache()
        t.first_order_merge(key, value)
        assert t._plugin[key] == expected_value

    test_assert('10.10.10.10', {'a': 1, 'b': 2}, {'a': 1, 'b': 2})
    test_assert('10.10.10.10', {'a': 1, 'b': 3}, {'a': 1, 'b': 3})
    test_assert('10.10.10.10', {'a': 1, 'c': 3}, {'a': 1, 'b': 3, 'c': 3})

# Generated at 2022-06-21 09:32:47.832012
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    fact_cache['test_key'] = ['test_val_1', 'test_val_2', 'test_val_3']
    fact_cache['test_key_2'] = ['test_val_4', 'test_val_5', 'test_val_6']
    new_cache = fact_cache.copy()
    assert(new_cache['test_key'] == ['test_val_1', 'test_val_2', 'test_val_3'])
    assert(new_cache['test_key_2'] == ['test_val_4', 'test_val_5', 'test_val_6'])

# Generated at 2022-06-21 09:34:02.447762
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    plugin = cache_loader.get(C.CACHE_PLUGIN)
    if plugin:
        plugin.flush()
        cache = FactCache()
        cache['key'] = 'value'
        assert len(cache) == 1
        cache['name'] = 'value'
        assert len(cache) == 2
        del cache['name']
        assert len(cache) == 1
        assert 'key' in cache
        cache.flush()


# Generated at 2022-06-21 09:34:09.932716
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    temp_fact_cache = dict([('test_key1', 1), ('test_key2', 2)])
    test_FactCache = FactCache(temp_fact_cache)

    test_FactCache.first_order_merge('test_key1', 2)

    assert test_FactCache['test_key1'] == 2
    assert test_FactCache['test_key2'] == 2

# Generated at 2022-06-21 09:34:13.575817
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache = FactCache()
    fact_cache['1'] = {1, 2}
    assert fact_cache.keys() == ['1']
    fact_cache.__delitem__('1')
    assert fact_cache.keys() == []

# Generated at 2022-06-21 09:34:21.739499
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    ip_address = "192.168.1.2"
    host_name = "test-host"
    fact_cache.first_order_merge(host_name, {'ip_address':ip_address})
    assert fact_cache[host_name]['ip_address'] == ip_address
    # check if the re-run of method first_order_merge will override the above default one.
    ip_address = "192.168.1.3"
    fact_cache.first_order_merge(host_name, {'ip_address':ip_address})
    assert fact_cache[host_name]['ip_address'] == ip_address

    # check if the method get/set can be used in FactCache instance

# Generated at 2022-06-21 09:34:23.982354
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        cache = FactCache()
    except Exception:
        assert False, "Unexpected exception raised when creating a FactCache object"

# Generated at 2022-06-21 09:34:30.013925
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():

    m = FactCache()
    m._plugin.flush()

    m['a'] = 1
    assert 'a' == m._plugin.get('a')

    assert 'a' in m
    assert 'b' not in m

    m['a'] = 2
    assert 'a' == m._plugin.get('a')

    m._plugin.flush()



# Generated at 2022-06-21 09:34:32.113460
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    len(fact_cache)
    pass


# Generated at 2022-06-21 09:34:33.580996
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    #collection = FactCache()
    #assert collection._plugin.contains(key) == None
    pass

# Generated at 2022-06-21 09:34:34.582560
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fc = FactCache()
    fc.flush()

# Generated at 2022-06-21 09:34:35.360176
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    pass