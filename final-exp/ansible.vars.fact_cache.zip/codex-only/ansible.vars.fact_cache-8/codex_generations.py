

# Generated at 2022-06-23 14:59:03.492842
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc._plugin = cache_loader.get(C.CACHE_PLUGIN)
    assert fc._plugin

    fc.first_order_merge("127.0.0.1", dict(key1="value1", key2="value2"))
    
    assert fc["127.0.0.1"]["key1"] == "value1"
    assert fc["127.0.0.1"]["key2"] == "value2"

    fc.first_order_merge("127.0.0.1", dict(key2="value2new", key3="value3"))

    assert fc["127.0.0.1"]["key1"] == "value1"
    assert fc["127.0.0.1"]["key2"]

# Generated at 2022-06-23 14:59:09.368616
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fc = FactCache()
    fc['foo'] = 'bar'
    fc['baz'] = 'blah'

    display.display(fc.keys())
    display.display([x for x in fc])
    display.display(list(fc))

    assert iter(fc) == iter(fc.keys())

# Generated at 2022-06-23 14:59:19.801935
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    from ansible.utils.display import Display
    from ansible.module_utils.common._collections_compat import MutableMapping

    class Plugin:
        def contains(self, key):
            return True

        def get(self, key):
            return True

        def set(self, key, value):
            pass

        def delete(self, key):
            pass

        def keys(self):
            return ['foo', 'bar']

        def flush(self):
            pass

    class FactCache(MutableMapping):
        def __init__(self, *args, **kwargs):
            self._plugin = Plugin()
            super(FactCache, self).__init__(*args, **kwargs)

        def __getitem__(self, key):
            return True


# Generated at 2022-06-23 14:59:20.665519
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    assert True


# Generated at 2022-06-23 14:59:26.070592
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    fact_cache['local'] = 'localhost'
    fact_cache['remote'] = 'remotehost'
    assert fact_cache['local'] == 'localhost'
    assert fact_cache['remote'] == 'remotehost'
    fact_cache.flush()
    assert len(fact_cache) == 0

# Generated at 2022-06-23 14:59:28.739353
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    fact_cache["foo"] = "bar"
    fact_cache.flush()
    assert(len(fact_cache) == 0)

# Generated at 2022-06-23 14:59:30.092076
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    f = FactCache()
    assert f.keys() is None

# Generated at 2022-06-23 14:59:36.078186
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Setup
    c = FactCache()

    # Exercise
    host_facts = {
        'a': {'b': {'c': True}},
    }
    c.first_order_merge('a', host_facts['a'])

    # Verify
    assert 'a' in c
    assert 'b' in c['a']
    assert 'c' in c['a']['b']

    # Teardown
    c.flush()

# Generated at 2022-06-23 14:59:43.385050
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.flush()

    host_key = 'test'
    fact_key = ['foo', 'bar']
    fact_value = ['bar', 'foo']

    fact_cache.first_order_merge(host_key, {fact_key[0]: fact_value[0], fact_key[1]: fact_value[1]})
    assert fact_cache[host_key] == {fact_key[0]: fact_value[0], fact_key[1]: fact_value[1]}

    fact_cache.first_order_merge(host_key, {fact_key[0]: fact_value[1], fact_key[1]: fact_value[0]})

# Generated at 2022-06-23 14:59:45.605536
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    assert len(fact_cache) == 0
    fact_cache["k1"] = "v1"
    assert len(fact_cache) == 1


# Generated at 2022-06-23 14:59:50.635419
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    key = 'key'
    value = 'value'
    fact_cache = FactCache()
    # Test for: keys() method is not defined
    assert not hasattr(fact_cache, 'keys')
    # Test for: keys() method is defined
    # keys() method is created by MappingMixin class
    # MappingMixin class is parent of MutableMapping class
    assert hasattr(fact_cache, 'keys')
    # Test for: keys() method returns correct keys
    fact_cache[key] = value
    assert fact_cache.keys() == [key]
    # Test for: keys() method returns correct keys
    # Test for: keys() method returns list of keys
    key2 = 'key2'
    value2 = 'value2'
    fact_cache[key2] = value2
    keys = fact_cache

# Generated at 2022-06-23 14:59:54.413806
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    '''
    Method __getitem__ of class FactCache
    '''
    plugin = fact_cache._plugin
    if not plugin.contains('key'):
        raise KeyError
    else:
        assert isinstance(plugin.get('key'), dict)


# Generated at 2022-06-23 15:00:02.829748
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    plugin = cache_loader.get(C.CACHE_PLUGIN)
    if not plugin:
        raise AnsibleError('Unable to load the facts cache plugin (%s).' % (C.CACHE_PLUGIN))
    plugin.plugin_name = 'jsonfile'
    plugin.plugin_object.options['fact_caching_connection'] = '/path/to/my'
    plugin.plugin_object.options['fact_caching_prefix'] = ''
    plugin.plugin_object.options['fact_caching_timeout'] = 30
    plugin.plugin_object._base_dir = '/Users/penglei/.ansible/cached_facts'
    fact_cache_test = FactCache('localhost')
    it = fact_cache_test.__iter__()
    print(it)
    # print(plugin.

# Generated at 2022-06-23 15:00:12.552857
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fc = FactCache()
    fc.clear()
    fc['foo'] = 'bar'

    assert fc.__getitem__('foo') == 'bar'
    assert len(fc) == 1

    # Test with empty dict
    fc.clear()
    assert len(fc) == 0

    # Test with a dict containing multiple items
    fc.clear()
    fc.update({'foo': 'bar', 'fizz': 'buzz'})
    assert fc.__getitem__('foo') == 'bar'
    assert fc.__getitem__('fizz') == 'buzz'
    assert len(fc) == 2

    fc.clear()
    fc.update({'foo': 'bar'})
    assert fc.__getitem__('foo') == 'bar'

# Generated at 2022-06-23 15:00:22.004978
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache(
        'dummy',
        'dummy',
        host='dummy',
        port='dummy',
        force_basic_auth='dummy',
        use_ssl='dummy',
        validate_certs='dummy',
        username='dummy',
        password='dummy',
        timeout='dummy',
    )
    assert cache['host'] == 'dummy'
    cache['host'] = 'dummy2'
    assert cache['host'] == 'dummy2'
    del cache['host']
    assert 'host' not in cache.keys()
    assert 'dummy' not in cache.keys()

# Generated at 2022-06-23 15:00:23.457305
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    fact_cache['1'] = 1
    assert fact_cache.keys() == ['1']

# Generated at 2022-06-23 15:00:33.120343
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__(): #$ ansible-test units --python 2.6 --coverage-html
    cache_plugin = {}
    cache_plugin['verbose'] = True
    cache_plugin.contains = lambda x: x in cache_plugin
    cache_plugin.get = lambda x: cache_plugin[x]
    cache_plugin.set = lambda x, y: cache_plugin.__setitem__(x, y)
    cache_plugin.delete = lambda x: cache_plugin.__delitem__(x)
    cache_plugin.keys = lambda: cache_plugin.keys()

    fc = FactCache()
    fc._plugin = cache_plugin

    fc['foo'] = 'bar'
    fc['baz'] = 123

    assert 'foo' in fc
    assert 'bar' not in fc


# Generated at 2022-06-23 15:00:36.871046
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    test_dict = {'key': 'value'}
    fact_cache.update(test_dict)
    assert fact_cache.copy() == test_dict


# Generated at 2022-06-23 15:00:44.726277
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    test_cache = {'a': {'a1': 'v1', 'a2': 'v2'}}
    fact_cache.update(test_cache)

    host_facts = {'a': {'a1': 'v11', 'a2': 'v22', 'a3': 'v3'}}
    fact_cache.first_order_merge('a', host_facts['a'])
    assert fact_cache == {'a': {'a1': 'v11', 'a2': 'v22', 'a3': 'v3'}}

    host_facts = {'b': {'b1': 'v1'}}
    fact_cache.first_order_merge('b', host_facts['b'])

# Generated at 2022-06-23 15:00:51.555436
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    mycache = FactCache()
    mycache['abc'] = {'a': 1, 'b': 2, 'c': 3}
    mycache['def'] = {'d': 4, 'e': 5, 'f': 6}
    assert mycache['abc'] == {'a': 1, 'b': 2, 'c': 3}
    assert mycache['def'] == {'d': 4, 'e': 5, 'f': 6}
    assert 'abc' in mycache
    assert 'def' in mycache


# Generated at 2022-06-23 15:01:01.970620
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    f = FactCache()
    assert f
    f.first_order_merge('test', {'a': 1})
    assert 'test' in f
    assert f['test'] == {'a': 1}
    f.first_order_merge('test', {'b': 2})
    assert 'test' in f
    assert f['test'] == {'a': 1, 'b': 2}
    f.first_order_merge('test', {'a': 1, 'b': 2, 'c': 3})
    assert 'test' in f
    assert f['test'] == {'a': 1, 'b': 2, 'c': 3}
    del f
    f = FactCache()
    assert f

# Generated at 2022-06-23 15:01:11.691986
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    """
    Unit test for method __iter__ of class FactCache.
    """
    # FactCache.__iter__() depends on CACHE_PLUGIN setting,
    # so we need to set it to 'jsonfile' temporarily.
    old_plugin = C.CACHE_PLUGIN
    C.CACHE_PLUGIN = 'jsonfile'

    fact_cache = FactCache()
    fact_cache['a'] = 1
    fact_cache['b'] = 2
    fact_cache['c'] = 3

    assert len(fact_cache) == 3
    assert sorted(list(fact_cache)) == ['a', 'b', 'c']

    # Restore CACHE_PLUGIN setting
    C.CACHE_PLUGIN = old_plugin

# Generated at 2022-06-23 15:01:22.145208
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():

    ansible_facts = {}
    ansible_facts['ansible_os_family'] = 'RedHat'
    ansible_facts['ansible_distribution_major_version'] = '7'
    ansible_facts['ansible_distribution'] = 'CentOS'
    ansible_facts['ansible_distribution_version'] = '7.2.1511'
    ansible_facts['ansible_distribution_release'] = 'Core'
    ansible_facts['ansible_pkg_mgr'] = 'yum'
    ansible_facts['ansible_machine'] = 'x86_64'
    ansible_facts['ansible_all_ipv4_addresses'] = ['192.168.3.10']
    ansible_facts['ansible_architecture'] = 'x86_64'
   

# Generated at 2022-06-23 15:01:23.932558
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fc = FactCache()
    fc.flush()


# Generated at 2022-06-23 15:01:24.866830
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert hasattr(fact_cache, '_plugin')

# Generated at 2022-06-23 15:01:35.407440
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    assert 'localhost' in fact_cache
    assert fact_cache['localhost'] == {}

    def getter(key):
        if key == 'localhost':
            return {'ansible_kernel': 'Linux'}
        raise KeyError

    def setter(key, value):
        pass

    def contains(key):
        if key == 'localhost':
            return True
        return False

    def keys():
        return ['localhost']

    fact_cache._plugin.get = getter
    fact_cache._plugin.set = setter
    fact_cache._plugin.contains = contains
    fact_cache._plugin.keys = keys

    assert fact_cache.copy() == {'localhost': {'ansible_kernel': 'Linux'}}



# Generated at 2022-06-23 15:01:39.548277
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    test_cache = FactCache(None, None)
    # assert_raises_regexp is deprecated since version 3.2
    if C.__version__ < '3.2':
        test_cache.assertRaisesRegexp(AnsibleError, 'Unable to load the facts cache plugin')
    else:
        test_cache.assertRaisesRegex(AnsibleError, 'Unable to load the facts cache plugin')


# Generated at 2022-06-23 15:01:48.532854
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    from ansible.module_utils.common._collections_compat import Mapping
    import os
    import stat

    try:
        os.unlink('/tmp/test_cache.json')
    except OSError:
        pass

    with open('/tmp/test_cache.json', 'w') as f:
        f.write('{}')
    os.chmod('/tmp/test_cache.json', stat.S_IWUSR)

    facts = FactCache()
    assert isinstance(facts.keys(), list)

    os.unlink('/tmp/test_cache.json')

# Generated at 2022-06-23 15:01:58.578051
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import pytest
    fc = FactCache()
    key = '127.0.0.1'
    value = {'foo': 'foovalue'}
    fc.first_order_merge(key, value)
    assert list(fc.keys()) == [key]
    assert fc[key] == value
    new_value = {'foo': 'foovalue_new'}
    fc.first_order_merge(key, new_value)
    assert fc[key] == value
    key_int = 10
    value_int = {'foo_int': 10}
    fc.first_order_merge(key_int, value_int)
    assert list(fc.keys()) == [key, key_int]
    assert fc[key] == value

# Generated at 2022-06-23 15:02:03.164065
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('my-key', 'my-value')
    assert fact_cache._plugin.get('my-key') == 'my-value'
    fact_cache.first_order_merge('my-key', {'secondary-key': 'secondary-value'})
    composed_object = {'my-key': {'secondary-key': 'secondary-value'}}
    assert fact_cache._plugin.get('my-key') == composed_object['my-key']

# Generated at 2022-06-23 15:02:08.661582
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache, "the constructor of class FactCache should return a object"
    assert isinstance(cache, FactCache), "the constructor of class FactCache should return a FactCache object"

# Unit tests for function update

# Generated at 2022-06-23 15:02:11.205586
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fc = FactCache('test_hostname', [{'fact1': 'fact1'}])
    assert fc.keys() == ['fact1']


# Generated at 2022-06-23 15:02:13.274061
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    print(FactCache().keys())

# Generated at 2022-06-23 15:02:15.824239
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    try:
        assert False
    except AssertionError:
        display.error('Test assertions for method __iter__ of class FactCache are failing.')
        raise
    finally:
        pass


# Generated at 2022-06-23 15:02:20.241768
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    my_dict = {'a':1, 'b':2, 'c':3}
    my_fact_cache = FactCache(**my_dict)
    assert 'a' in my_fact_cache
    assert 'd' not in my_fact_cache

# Generated at 2022-06-23 15:02:24.645647
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    print("test_FactCache_first_order_merge: Start")
    cache = FactCache()
    facts = {
        'some-key': 'some-value'
    }
    key = 'some-key'
    cache[key] = {'other-key': 'other-value'}
    cache.first_order_merge(key, facts[key])
    assert key in cache
    assert facts[key] == cache[key]

    print("test_FactCache_first_order_merge: End")

# Generated at 2022-06-23 15:02:26.114445
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    assert True



# Generated at 2022-06-23 15:02:28.344456
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    cache = FactCache()
    assert cache._plugin.contains('127.0.0.1') == False

# Generated at 2022-06-23 15:02:37.054622
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    import os
    import tempfile
    from ansible.module_utils.six import PY2

    if PY2:
        import ConfigParser as configparser
    else:
        import configparser

    config = configparser.ConfigParser()
    config.read(os.path.join(os.path.dirname(__file__), 'cache.ini'))

    tmpdir = tempfile.mkdtemp()

    cache = FactCache()
    cache._plugin = cache_loader.get('jsonfile')
    cache._plugin.set_options(direct=tmpdir)

    cache['testkey'] = 'testvalue'

    assert 'testkey' in cache

    cache.__delitem__('testkey')

    assert 'testkey' not in cache


# Generated at 2022-06-23 15:02:40.283233
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    cache = FactCache()
    cache['test'] = 'test'
    assert cache['test'] == 'test'
    cache.flush()
    assert cache['test'] == 'test'
    cache.flush()
    assert cache['test'] == 'test'

# Generated at 2022-06-23 15:02:50.336030
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars

    MutableMapping.register(HostVars)  
    MutableMapping.register(HostVarsVars)

    test_host = 'myhost000'
    test_var = 'test_var'
    test_value = 'test_value'

    my_fact_cache = FactCache()
    my_fact_cache[test_host] = {}
    my_fact_cache[test_host][test_var] = test_value

    assert my_fact_cache[test_host][test_var] == test_value



# Generated at 2022-06-23 15:02:51.448045
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    cache = FactCache()
    assert 'test' not in cache


# Generated at 2022-06-23 15:02:53.754439
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    cache = FactCache()
    cache.__setitem__("foo", "bar")
    assert cache["foo"] == "bar"


# Generated at 2022-06-23 15:03:00.895982
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    from ansible.plugins.loader import cache_loader
    from ansible.module_utils._text import to_text

    cache_loader.remove_all()

    cache_loader.add('memory', 'ansible.plugins.cache.memory')

    fact_cache = FactCache()
    fact_cache['localhost'] = dict()
    fact_cache['localhost']['ansible_facts'] = dict()
    fact_cache['localhost']['ansible_facts']['hostname'] = 'localhost'

    assert 'localhost' in fact_cache
    assert 'remotehost' not in fact_cache

    cache_loader.remove('memory')



# Generated at 2022-06-23 15:03:09.125426
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    dict1 = {'a':1, 'b':2, 'c':3}
    dict2 = {'x':11, 'y':22, 'z':33}
    fact_cache1 = FactCache(dict1)
    fact_cache2 = FactCache(dict2)
    assert dict1 == fact_cache1.copy()
    assert dict2 == fact_cache2.copy()
    assert dict(dict1) == fact_cache1.copy()
    assert dict(dict2) == fact_cache2.copy()



# Generated at 2022-06-23 15:03:11.532706
# Unit test for constructor of class FactCache
def test_FactCache():
    import ansible.module_utils.facts.cache

    test_instance = ansible.module_utils.facts.cache.FactCache()


# Generated at 2022-06-23 15:03:15.909788
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    cache = FactCache()
    key = "test_key"
    data = {
        "test_key": "test_value"
    }
    cache[key] = data
    assert cache[key] == data



# Generated at 2022-06-23 15:03:26.686029
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    # Create a new empty instance of FactCache
    my_fact_cache=FactCache()
    
    # Create a fake list of facts
    my_facts=["a",1,"b",2]
    my_dict=dict(zip(my_facts[::2], my_facts[1::2]))
    
    # Store facts in the cache
    for (k, v) in my_dict.items():
        my_fact_cache[k] = v
        
    # Test if the item is stored in the cache
    assert "a" in my_fact_cache.keys()
    
    # Delete the item from the cache
    my_fact_cache.__delitem__("a")
    
    # Test that the item has been deleted from the cache
    assert "a" not in my_fact_cache.keys()
    


# Generated at 2022-06-23 15:03:29.375637
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    fact_cache['key'] = 'value'
    copy = fact_cache.copy()
    assert copy['key'] == 'value'

# Generated at 2022-06-23 15:03:36.079387
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    facts = {'1.1.1.1': {'fact': 'value'}, '1.1.1.2': {'fact': 'value'}}
    fact_cache = FactCache(facts)

    fact_cache.first_order_merge('1.1.1.1', {'fact': 'value2'})
    assert fact_cache['1.1.1.1']['fact'] == 'value2'

# Generated at 2022-06-23 15:03:38.143340
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    factCache = FactCache()
    factCache['key1'] = 'value1'
    assert factCache['key1'] == 'value1'
    del factCache['key1']
    try:
        factCache['key1']
    except KeyError:
        assert True


# Generated at 2022-06-23 15:03:39.777654
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fact_cache = FactCache()
    assert '__iter__' in dir(fact_cache)

# Generated at 2022-06-23 15:03:41.276059
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fact = FactCache()
    it = iter(fact)
    assert it is not None


# Generated at 2022-06-23 15:03:44.998469
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    factcache = FactCache()
    factcache['testkey'] = 'testvalue'
    assert 'testkey' in factcache
    assert 'testkey2' not in factcache

# Generated at 2022-06-23 15:03:48.771278
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fc = FactCache()
    fc['test_key'] = 'test_value'
    copy_dict = fc.copy()
    assert copy_dict == {'test_key': 'test_value'}

# Generated at 2022-06-23 15:03:49.763473
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    pass


# Generated at 2022-06-23 15:03:53.152322
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fact_cache = FactCache()
    fact_cache['a'] = 'b'
    fact_cache['c'] = 'd'
    fact_cache['e'] = 'f'
    assert list(fact_cache.__iter__()) == ['a', 'c', 'e']

# Generated at 2022-06-23 15:03:56.335005
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fc = FactCache()
    fc['fact_cache_key'] = 'fact_cache_value'

    assert iter(fc) == iter(['fact_cache_key'])



# Generated at 2022-06-23 15:04:03.535448
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc_plugin = cache_loader.get("jsonfile")
    fc_plugin.set("192.0.2.1", {"hello": "world"})
    fc_plugin.set("192.0.2.2", {"foo": "bar"})
    fc = FactCache()
    fc.first_order_merge("192.0.2.2", {"hello": "universe"})
    assert fc._plugin.get("192.0.2.2") == {"hello": "universe", "foo": "bar"}
    assert fc._plugin.get("192.0.2.1") == {"hello": "world"}

# Entry point for unit test

# Generated at 2022-06-23 15:04:12.507712
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    """ Unit test for method __iter__ of class FactCache """

    # Create an instance of the FactCache class
    fact_cache = FactCache()

    # Test with a populated data set
    fact_cache.__setitem__(key='foo', value=1)
    fact_cache.__setitem__(key='bar', value=2)
    fact_cache.__setitem__(key='baz', value=3)
    data = [k for k in fact_cache]
    assert data == ['foo', 'bar', 'baz']

    # Test with a empty data set
    fact_cache.flush()
    data = [k for k in fact_cache]
    assert data == []



# Generated at 2022-06-23 15:04:18.319085
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache_unit_test = FactCache()
    fact_cache_unit_test["key1"] = "value1"
    assert fact_cache_unit_test["key1"] == "value1"

    del fact_cache_unit_test["key1"]
    with pytest.raises(KeyError):
        fact_cache_unit_test["key1"]


# Generated at 2022-06-23 15:04:21.453546
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    fact_cache['test_key'] = 'test_value'
    assert 'test_key' in fact_cache
    fact_cache.flush()
    assert 'test_key' not in fact_cache

# Generated at 2022-06-23 15:04:22.961572
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    cache = FactCache()
    items = cache.copy()
    assert len(items) == 0


# Generated at 2022-06-23 15:04:25.557072
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    mock_plugin = MockPlugin()
    fact_cache = FactCache()
    fact_cache._plugin = mock_plugin
    assert fact_cache.copy() == {'one': 1, 'two': 2, 'three': 3}


# Generated at 2022-06-23 15:04:28.252866
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    assert len(fact_cache) == 0
    fact_cache["test_key"] = "test_value"
    assert len(fact_cache) == 1
    fact_cache.flush()
    assert len(fact_cache) == 0

# Generated at 2022-06-23 15:04:33.035202
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    store = {
        'webservers': {u'ansible_facts': {u'foo': u'bar'}}}
    FactCache.__len__ = lambda self: len(store)
    FactCache.__iter__ = lambda self: iter(store)

    factcache = FactCache()
    assert len(factcache) == 1


# Generated at 2022-06-23 15:04:37.481727
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    import tempfile
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.plugins.loader import cache_loader
    from ansible.utils.display import Display
    display = Display()
    cache_loader._load_plugins()
    C.CACHE_PLUGIN = 'jsonfile'
    C.CACHE_PLUGIN_CONNECTION
    class Cache(object):
        def __init__(self):
            self._data = {}


# Generated at 2022-06-23 15:04:39.165042
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache
    # import ipdb; ipdb.set_trace()

# Generated at 2022-06-23 15:04:40.408968
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    # TODO: create test
    pass


# Generated at 2022-06-23 15:04:52.867687
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():

    # test the Memcached plugin
    plugin_obj = cache_loader.get('FactCacheMemcache')
    host_name = 'test_host_1'
    key = 'ansible_local'
    value = {'term': 'xterm'}
    plugin_obj.set(host_name, value)
    host_key = 'host:'+host_name
    assert host_key in plugin_obj.keys()

    # test YunJin plugin
    plugin_obj = cache_loader.get('FactCacheYunJin')
    host_name = 'test_host_1'
    key = 'ansible_local'
    value = {'term': 'xterm'}
    plugin_obj.set(host_name, value)
    host_key = 'host:'+host_name
    assert host_key in plugin

# Generated at 2022-06-23 15:04:56.117325
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    """This is a unit test of FactCache.flush() method"""
    cache = FactCache()
    cache['msg'] = "hello"
    cache.flush()
    assert cache.keys() == []

# Generated at 2022-06-23 15:05:04.200560
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    facts = FactCache()

    # case 1:
    # Given an invalid key, should raise KeyError
    # create an invalid key
    key = '0'
    # create a valid value for this key
    # create a valid value for this key
    key_type = 'dict'
    key_value = dict()
    for i in range(0, 3):
        key_value[('key' + str(i))] = ('value' + str(i))
    value = dict()
    value[key_type] = key_value
    # add key, value to cache
    facts._plugin.set(key, value)
    # get item with this key
    try:
        facts[('key' + str(i + 1))]
    except KeyError:
        flag = True
    assert flag

    # case 2:
   

# Generated at 2022-06-23 15:05:11.523053
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    from ansible.plugins.cache.jsonfile import CacheModule
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.path import unfrackpath
    from ansible.utils.vars import combine_vars

    test_colleciton = unfrackpath(
        '/Users/mkim/workspace/ansible_collections/cnos/'
    )
    test_collection_loader = AnsibleCollectionLoader()
    test_collection_loader.filter_collections(
        collections=[test_colleciton]
    )
    test_collection_loader.load(
        collections=[test_colleciton],
        with_dependencies=True,
        collection_list=[]
    )

# Generated at 2022-06-23 15:05:14.213084
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    """ Check the copy method, it should not throw an exception"""
    cache = FactCache()
    assert cache.copy()

# Generated at 2022-06-23 15:05:23.345770
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    from ansible.module_utils.common._collections_compat import MutableMapping
    import mock

    mock_plugin = mock.Mock()
    mock_plugin.contains.return_value=True
    mock_plugin.get.return_value="a"
    mock_plugin_2 = mock.Mock()
    mock_plugin_2.contains.return_value=False
    mock_plugin_2.get.return_value="a"
    mock_plugin_3 = mock.Mock()
    mock_plugin_3.contains.return_value=True
    mock_plugin_3.get.return_value="aa"


# Generated at 2022-06-23 15:05:24.654212
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert(fact_cache._plugin)

# Generated at 2022-06-23 15:05:33.936075
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    facts = {'ansible_facts': {'a': 'b'}}
    facts_merged = {'ansible_facts': {'a': 'b', 'c': 'd'}}

    fc = FactCache()
    fc[u'172.18.0.1'] = facts
    fc.first_order_merge(u'172.18.0.1', {'ansible_facts': {'c': 'd'}})
    assert fc[u'172.18.0.1'] == facts_merged

# Generated at 2022-06-23 15:05:37.967497
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    import os
    os.environ["ANSIBLE_CACHE_PLUGIN"] = "jsonfile"
    fc = FactCache()
    fc[ 'a' ] = 'b'
    assert fc['a'] == 'b'
    del fc[ 'a' ]
    try:
        fc[ 'a' ]
        assert False
    except KeyError:
        assert True


# Generated at 2022-06-23 15:05:39.317312
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    obj1 = FactCache()
    assert len(obj1) == 0


# Generated at 2022-06-23 15:05:49.888997
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    """Test if the sut does what it claims to do"""
    fake_cache_plugin_instance = FakePlugin()
    sut = FactCache()
    sut._plugin = fake_cache_plugin_instance
    host1_facts = {'first': 'host1'}
    host_cache = {'second': 'host2'}

    fake_cache_plugin_instance.cache[host1_facts.keys()[0]] = host_cache

    sut.first_order_merge(host1_facts.keys()[0], host1_facts.get(host1_facts.keys()[0]))

    assert sut[host1_facts.keys()[0]]['first'] == host1_facts.get(host1_facts.keys()[0])

# Generated at 2022-06-23 15:05:54.189111
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    obj = FactCache()
    obj.keys.return_value=['a', 'b']
    display.verbosity= 5
    result = obj.__iter__()
    assert list(result) == ['a', 'b']



# Generated at 2022-06-23 15:05:55.985115
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    factcache = FactCache()
    for x in factcache:
        print(x)


# Generated at 2022-06-23 15:05:59.157194
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    fact_cache['foo'] = 'bar'
    fact_cache['baz'] = 'qux'
    fact_cache.flush()
    assert not fact_cache


# Generated at 2022-06-23 15:05:59.973631
# Unit test for constructor of class FactCache
def test_FactCache():
    pass

# Generated at 2022-06-23 15:06:05.308080
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    factcache_obj=FactCache()
    factcache_obj['mykey']='myval'
    factcache_obj['mykey1']='myval2'
    factcache_copy=factcache_obj.copy()
    assert factcache_copy == {'mykey':'myval','mykey1':'myval2'}

# Generated at 2022-06-23 15:06:11.449121
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import pytest

    print("\n====== test_FactCache_first_order_merge ======")

    # Setup test data
    fact_cache_test = FactCache()
    cache_data = {
        "1.1.1.1": {
            "f1": "v11"
        },
        "2.2.2.2": {
            "f2": "v22"
        },
        "3.3.3.3": {
            "f3": "v23"
        }
    }
    fact_cache_test._plugin._cache = cache_data

    # TODO: this test is not a unit test.
    # It needs to be mocked to work.
    # The plugin needs to be mocked because the _cache variable is a public variable
    # to be able to use it for tests.
   

# Generated at 2022-06-23 15:06:15.641530
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    from ansible.module_utils.facts.cache import FactCache
    import json
    fc = FactCache()
    fc['test'] = 'testfact'
    assert json.dumps(fc['test']) == json.dumps('testfact')
    fc.flush()



# Generated at 2022-06-23 15:06:20.187275
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache = FactCache()
    fact_cache['a'] = '1'
    result = fact_cache['a']
    assert result == '1'
    del fact_cache['a']
    assert 'a' not in fact_cache

# Generated at 2022-06-23 15:06:24.057015
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    fact_cache['a'] = 'b'
    fact_cache['c'] = 'd'
    fact_copy = fact_cache.copy()
    assert fact_copy == {'a': 'b', 'c': 'd'}


# Generated at 2022-06-23 15:06:34.084718
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    pass
#    def __delitem__(self, key):
#        self._plugin.delete(key)
#
#
#def test_FactCache_1():
#    '''
#    Test if delete works when cache is not present
#    '''
#    test_FactCache = FactCache()
#    from ansible.module_utils.common._collections_compat import MutableMapping
#    import mock
#    with mock.patch(MutableMapping.__name__ + ".__delitem__") as mock_delete:
#        mock_delete.return_value = None
#        test_FactCache.__delitem__("non_existing_key")
#        mock_delete.assert_called_once_with("non_existing_key")
#

# Generated at 2022-06-23 15:06:41.642393
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Create a cache object and add 2 keys to it
    cache_obj = FactCache()
    cache_obj["key1"] = {"facts" : {"facts1" : "facts1", "facts2" : "facts2", "facts3" : "facts3"}}
    cache_obj["key2"] = {"facts" : {"facts4" : "facts4", "facts5" : "facts5"}}
    cache_obj["key3"] = {"facts" : {"facts6" : "facts6", "facts7" : "facts7"}}
    # Test merge functionality of method first_order_merge
    new_facts = {"facts1" : "new_facts1", "facts8" : "new_facts8"}
    updated_cache = cache_obj.first_order_merge("key1", new_facts)
    assert updated

# Generated at 2022-06-23 15:06:44.873245
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fact_cache = FactCache()
    assert 'localhost' not in fact_cache
    fact_cache['localhost'] = 'test_data'
    assert 'localhost' in fact_cache

# Generated at 2022-06-23 15:06:46.295386
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    obj = FactCache()
    assert len(obj.keys()) == 0

# Generated at 2022-06-23 15:06:54.635887
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():

    from unittest import TestCase

    class SomeFactsCache(object):

        def contains(self, key):
            return False

        def keys(self):
            return ['a','b','c','d']

    fact_cache = FactCache()
    fact_cache._plugin = SomeFactsCache()
    len_fact_cache = len(fact_cache)
    expected_len_fact_cache = 4
    TestCase().assertEqual(len_fact_cache, expected_len_fact_cache)


# Generated at 2022-06-23 15:07:01.015844
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc.first_order_merge('10.0.0.1', {'foo': 'bar'})
    assert fc['10.0.0.1'] == {'foo': 'bar'}

    fc.first_order_merge('10.0.0.2', {'foo': 'baz'})
    assert fc['10.0.0.2'] == {'foo': 'baz'}

    fc.first_order_merge('10.0.0.1', {'baz': 'qux'})
    assert fc['10.0.0.1'] == {'foo': 'bar', 'baz': 'qux'}

# Generated at 2022-06-23 15:07:06.084836
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    f = FactCache()
    f['key1'] = 'value1'
    f['key2'] = 'value2'
    keys = f.keys()
    assert len(keys) == 2
    assert 'key1' in keys
    assert 'key2' in keys

# Generated at 2022-06-23 15:07:14.357341
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    from ansible.plugins.cache import memory
    from ansible.plugins.loader import cache_loader
    from ansible.plugins.cache.memory import CacheModule as MemoryCacheModule

    C._CACHE_PLUGIN_CALLBACKS['memory'] = memory
    cache_loader.add_directory(C.DEFAULT_CACHE_PLUGIN_PATH)
    cache_loader.set_default_subdir('memory')
    fc = FactCache()
    fact1 = {'name': 'a', 'id': 'b'}
    fact2 = {'name': 'c', 'id': 'd'}
    fc.__setitem__('a', fact1)
    fc.__setitem__('c', fact2)
    fc.__iter__()


# Generated at 2022-06-23 15:07:18.353119
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    cache = FactCache()
    cache['_key1'] = '_value1'
    cache['_key2'] = '_value2'
    cache['_key3'] = '_value3'
    cache.__delitem__('_key2')
    assert  '_key2' not in cache


# Generated at 2022-06-23 15:07:20.176454
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    cache_loader.add("memory", "ansible.plugins.cache.memory")
    factcache = FactCache()
    assert factcache["testkey"] == None



# Generated at 2022-06-23 15:07:30.065918
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    import sys
    if sys.version_info[:2] == (2, 6):
        return True

    from ansible import context
    from ansible.cache.memory import FactCacheModule

    my_cache = dict()
    my_plugin = FactCacheModule(my_cache)
    context.CLIARGS['cache_plugin'] = 'memory'
    context.CLIARGS['fact_caching'] = 'memory'
    fact_cache = FactCache()

    # create a cache object
    fact_cache['localhost'] = dict(ansible_os_family='RedHat')

    # the cache should be populated
    assert 'localhost' in fact_cache


# Generated at 2022-06-23 15:07:35.931218
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    class fact_cache_plugin:
        def contains(self, key):
            assert key == "test_key"
            return True
        def get(self, key):
            assert key == "test_key"
            return "test_value"
    test_cache = FactCache()
    test_cache._plugin = fact_cache_plugin()
    assert test_cache.__getitem__("test_key") == "test_value"


# Generated at 2022-06-23 15:07:39.106046
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    factcache = FactCache()
    factcache['key'] = 'value'
    assert factcache.__contains__('key') == True

# Generated at 2022-06-23 15:07:46.549227
# Unit test for method keys of class FactCache
def test_FactCache_keys():

    from ansible.constants import CACHE_PLUGIN_KEYS_FOR_UNIT_TEST

    test_cache = cache_loader.get(CACHE_PLUGIN)
    for key in CACHE_PLUGIN_KEYS_FOR_UNIT_TEST:
        test_cache.set(key, dict(foo=1))
    fact_cache = FactCache()
    assert set(CACHE_PLUGIN_KEYS_FOR_UNIT_TEST) == set(fact_cache.keys())
    test_cache.flush()

# Generated at 2022-06-23 15:07:48.124978
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    # TODO: Add unit tests for __getitem__
    raise NotImplementedError()



# Generated at 2022-06-23 15:07:50.269581
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    fact_cache['a'] = 'b'
    result = fact_cache.copy()
    assert result == {'a': 'b'}

# Generated at 2022-06-23 15:07:54.595835
# Unit test for method flush of class FactCache
def test_FactCache_flush():

    cache = FactCache()
    cache._plugin = cache_loader.get(C.CACHE_PLUGIN)

    cache['host.localhost'] = {
        "redis_version": "2.8.12",
        "os_family": "RedHat",
        "hostname": "localhost"
    }

    cache.flush()

    # It should not contain any key after flush
    assert cache._plugin.contains('host.localhost') == False


# Generated at 2022-06-23 15:07:58.674765
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    assert len(fact_cache) == 0

    fact_cache._plugin = FakePlugin()
    assert len(fact_cache) == FakePlugin.NUM_KEYS



# Generated at 2022-06-23 15:08:06.417982
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    try:
        from ansible.module_utils.facts import default_collectors
        from ansible.module_utils._text import to_bytes
    except ImportError:
        pass
    else:
        from ansible.module_utils.facts.collectors import _cache as fact_cache
        from ansible.module_utils.facts.collectors.hardware import _cache as hardware_cache

        # Test with empty caches
        fact_cache.flush()
        hardware_cache.flush()
        assert list(fact_cache) == []
        assert list(hardware_cache) == []

        # Test with the fact cache (not the hardware cache) populated, but
        # without a specific key known to exist.
        fact_cache['foo'] = 'bar'
        hardware_cache['foo'] = 'bar'
        assert list(fact_cache)

# Generated at 2022-06-23 15:08:09.442325
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    assert hasattr(FactCache, 'keys'), "Class '%s' does not have method '%s'" % ("FactCache", "keys")
    assert callable(getattr(FactCache, 'keys'))


# Generated at 2022-06-23 15:08:10.536412
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    pass


# Generated at 2022-06-23 15:08:16.570773
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    """
    Test for the instance method __getitem__ of the class FactCache
    """
    obj = FactCache()
    key = "my_key"
    value = {"my_key_value"}
    obj._plugin.set(key, value)
    if not obj._plugin.contains(key):
        raise KeyError
    assert obj.__getitem__(key) == value


# Generated at 2022-06-23 15:08:17.307015
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    assert True

# Generated at 2022-06-23 15:08:22.069748
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fact_cache = FactCache()
    # Success when key exists in plugin
    try:
        fact_cache['key1']
    except KeyError:
        assert False
    # KeyError when key doesn't exist in plugin
    assert KeyError == type(fact_cache['key2'])



# Generated at 2022-06-23 15:08:25.556914
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fc = FactCache()
    fc['a'] = 'A'
    assert fc.keys() == ['a'], 'The key should be a, but got %s' % fc.keys()


# Generated at 2022-06-23 15:08:28.158086
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    test_object = FactCache()
    assert test_object.keys() == [], 'FactCache keys() method failed'


# Generated at 2022-06-23 15:08:32.066706
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    class TestPlugin(object):
        def delete(self, key):
            print("Called delete")
    test_plugin = TestPlugin()

    fc = FactCache()
    fc._plugin = test_plugin
    fc.__delitem__("key")

# Generated at 2022-06-23 15:08:36.781687
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache_object = FactCache()
    test_dict = {'test_key': 'test_value'}
    fact_cache_object._plugin.set('test_key', test_dict)
    result = fact_cache_object.copy()
    assert result == test_dict
    # Test the empty case
    fact_cache_object._plugin.flush()
    result = fact_cache_object.copy()
    assert result == {}

# Generated at 2022-06-23 15:08:39.338262
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
   fact_cache = FactCache()
   assert type(fact_cache.__iter__()).__name__ == 'generator'

# Generated at 2022-06-23 15:08:45.335003
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fake_host = 'host1'
    fake_value = 'value1'
    fake_plugin = FakePlugin()

    cache = FactCache()
    cache._plugin = fake_plugin

    cache[fake_host] = fake_value
    assert cache[fake_host] == fake_value
    assert len(cache) == 1

    cache.flush()
    assert len(cache) == 0


# Generated at 2022-06-23 15:08:48.405108
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    fact_cache['host1'] = {'a': '1', 'b': '2'}
    assert fact_cache.copy() == {'host1': {'a': '1', 'b': '2'}}

# Generated at 2022-06-23 15:08:59.804754
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    host_cache = {}
    ipaddr = '1.1.1.1'
    ansible_eth0 = {'macaddress': '00:00:00:11:11:11'}
    ansible_eth1 = {'macaddress': '00:00:00:22:22:22'}

    # test merge when no cache exists
    cache.first_order_merge(ipaddr, {'ansible_eth0': ansible_eth0})
    assert cache[ipaddr] == {'ansible_eth0': ansible_eth0}

    # test merge with existing cache but same data
    cache.flush()
    cache.first_order_merge(ipaddr, {'ansible_eth0': ansible_eth0})