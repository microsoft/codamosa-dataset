

# Generated at 2022-06-23 14:58:58.470776
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    cache = FactCache()

    cache._plugin = DictCache()
    cache._plugin.set("test1", "value1")
    cache._plugin.set("test2", "value2")

    cache.flush()

    assert not cache._plugin._keys


# Generated at 2022-06-23 14:59:00.455293
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    cache = FactCache()
    cache.__setitem__(key='test', value='test')
    cache.flush()
    assert cache.keys() == []

# Generated at 2022-06-23 14:59:06.702908
# Unit test for constructor of class FactCache
def test_FactCache():
    import ansible.plugins.cache.jsonfile
    from ansible.plugins.cache.jsonfile import CacheModule as CachePlugin
    from ansible import constants as C
    from ansible.utils.display import Display

    display = Display()

    # Case 1: valid cache plugin
    C.CACHE_PLUGIN = 'jsonfile'
    fc = FactCache()
    assert isinstance(fc._plugin, CachePlugin)

    # Case 2: invalid cache plugin
    C.CACHE_PLUGIN = 'invalid'
    try:
        fc = FactCache()
    except AnsibleError:
        pass

# Generated at 2022-06-23 14:59:10.517577
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    host_vars = {'tecmint': 'redhat'}
    fact_cache = FactCache()
    fact_cache.first_order_merge('tecmint', host_vars)
    assert fact_cache.__contains__('tecmint') == True

# Generated at 2022-06-23 14:59:16.720630
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fc = FactCache("foo.cache")
    fc['host1'] = "bar"
    assert fc.keys() == ['host1']
    fc['host2'] = "baz"
    assert fc.keys() == ['host1', 'host2']
    del fc['host1']
    assert fc.keys() == ['host2']
    fc.flush()
    assert fc.keys() == []

# Generated at 2022-06-23 14:59:19.075356
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache.plugin.plugin_name == 'memory'
    assert cache.plugin.config is None

# Generated at 2022-06-23 14:59:29.802202
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc.first_order_merge('127.0.0.1', {'ansible_os_family': 'Debian'})
    assert fc._plugin.get('127.0.0.1') == {'ansible_os_family': 'Debian'}
    assert fc['127.0.0.1'] == {'ansible_os_family': 'Debian'}

    fc.first_order_merge('127.0.0.1', {'ansible_os_family': 'RedHat'})
    assert fc._plugin.get('127.0.0.1') == {'ansible_os_family': 'RedHat'}
    assert fc['127.0.0.1'] == {'ansible_os_family': 'RedHat'}

# Generated at 2022-06-23 14:59:32.230083
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin == cache_loader.get(C.CACHE_PLUGIN)


# Generated at 2022-06-23 14:59:35.606688
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    from datetime import datetime
    cache = FactCache()
    cache['test_value'] = {'key': 'test', 'time': datetime.now()}
    assert cache['test_value'] is not None



# Generated at 2022-06-23 14:59:37.686846
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    """Testing function test_FactCache___contains__"""
    pass


# Generated at 2022-06-23 14:59:40.317221
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fc = FactCache()
    fc["foo"] = "bar"
    assert fc["foo"] == "bar"
    try:
        fc["bar"]
        assert False
    except KeyError as e:
        assert True


# Generated at 2022-06-23 14:59:45.513897
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact = FactCache()
    fact['A'] = {'ip_address': '1.1.1.1'}
    fact['B'] = {'ip_address': '2.2.2.2'}
    assert fact.keys() == ['A', 'B']
    assert len(fact.keys()) == 2
    assert 'A' in fact.keys()
    assert 'B' in fact.keys()

# Generated at 2022-06-23 14:59:49.302067
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    cache = FactCache()
    cache._plugin = MockPlugin()
    cache['key'] = 'value'
    del cache['key']
    assert not cache._plugin.contains('key')


# Generated at 2022-06-23 14:59:52.107193
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fact_cache = FactCache()
    # test that __iter__ returns a iterator object
    assert hasattr(fact_cache.__iter__(), '__next__')


# Generated at 2022-06-23 15:00:01.462242
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    #test key not in cache
    cache = FactCache()
    key = "test_key"
    value = {"test_key2": "test_value2"}
    cache.first_order_merge(key, value)
    assert cache[key] == value

    #test key in cache, value is not updated
    cache = FactCache()
    key = "test_key"
    value = {"test_key2": "test_value2"}
    cache[key] = value
    cache.first_order_merge(key, value)
    assert value == cache[key]

    #test key in cache, value is updated
    cache = FactCache()
    key="test_key"
    value={"test_key2":"test_value2"}
    cache[key] = value

# Generated at 2022-06-23 15:00:06.727010
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fc1 = FactCache()
    fc1['127.0.0.1'] = {'ansible_all_ipv4_addresses': ['192.168.0.1']}
    assert fc1['127.0.0.1'] == {'ansible_all_ipv4_addresses': ['192.168.0.1']}


# Generated at 2022-06-23 15:00:11.129659
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache = FactCache()
    key = 'key'
    value = {'key_1': 1}
    fact_cache[key] = value
    assert fact_cache[key] == value
    del fact_cache[key]
    assert fact_cache._plugin.contains(key) == False


# Generated at 2022-06-23 15:00:12.300357
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache.__len__() == 0

# Generated at 2022-06-23 15:00:15.703678
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    cache = FactCache()

    cache['test_host'] = {'key': 'value'}

    assert cache['test_host'] == {'key': 'value'}



# Generated at 2022-06-23 15:00:19.937127
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    """ Unit test for __contains__ of class FactCache """
    display.display("test_FactCache___contains__")

    fact_cache = FactCache()
    actual_result = "test" in fact_cache
    assert actual_result == False


# Generated at 2022-06-23 15:00:22.890680
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    f = FactCache("ansible_facts")
    f._plugin.set("ansible_facts", {"test": "test"})
    f.flush()
    assert not f._plugin.get("ansible_facts")

# Generated at 2022-06-23 15:00:32.138232
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    class Plugin:
        def __init__(self):
            self._cache = {1:1, 2:2}
        def contains(self, key):
            return key in self._cache.keys()
        def get(self, key):
            return self._cache.get(key)
        def set(self, key, value):
            self._cache[key] = value
        def delete(self, key):
            del self._cache[key]
        def keys(self):
            return self._cache.keys()
        def flush(self):
            self._cache.clear()
    # Setup
    cache_loader.plugin_class = Plugin
    cache = FactCache()
    # Test
    assert 1 in cache
    assert 10 not in cache


# Generated at 2022-06-23 15:00:34.277577
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    m = FactCache()
    assert m.__getitem__("") == ""


# Generated at 2022-06-23 15:00:38.741355
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    """ Should return True for defined key and False for undefined key """
    fact_cache = FactCache()
    fact_cache['test_key'] = 1
    assert 'test_key' in fact_cache
    assert not 'fake_key' in fact_cache


# Generated at 2022-06-23 15:00:41.036755
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    factcache = FactCache()
    factcache._plugin.keys.return_value = ["localhost"]
    assert factcache.keys() == ["localhost"]


# Generated at 2022-06-23 15:00:50.571437
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    import sys
    import os
    import tempfile
    import shutil
    import getpass
    import datetime

    uid = getpass.getuser()
    cache = os.path.join(tempfile.mkdtemp(prefix='ansible-test-%s-' % uid), 'cache')

# Generated at 2022-06-23 15:00:52.466440
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    my_cache = FactCache()
    my_cache['key'] = 'value'
    del my_cache['key']
    assert 'key' not in my_cache


# Generated at 2022-06-23 15:00:55.636877
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()

    # test for empty cache
    assert fact_cache.copy() == {}

    k = 'key_1'
    v = 'value_1'

    fact_cache[k] = v
    assert fact_cache.copy() == {k: v}

# Generated at 2022-06-23 15:00:59.021990
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    # create object
    fc = FactCache()

    # invoke __len__ and check result
    test_len = len(fc)
    assert test_len is not None
    assert type(test_len) == int



# Generated at 2022-06-23 15:01:00.898122
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fact_cache = FactCache()
    assert fact_cache['ansible_local'] == None


# Generated at 2022-06-23 15:01:04.542706
# Unit test for method copy of class FactCache
def test_FactCache_copy():

    cache = FactCache()

    # empty cache
    assert dict() == cache.copy()

    # sample key and value for test
    key = "foo"
    value = "bar"

    # full cache
    cache[key] = value
    assert { key: value } == cache.copy()


# Generated at 2022-06-23 15:01:10.386757
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    cache.first_order_merge("host1", {"newfact1":"newval1", "fact2":"val2"})

    assert cache["host1"] == {"newfact1":"newval1", "fact2":"val2"}

    # host1 is already in cache, then once more merge
    cache.first_order_merge("host1", {"newfact1":"newval1", "fact2":"newval2"})

    assert cache["host1"] == {"newfact1":"newval1", "fact2":"newval2"}

# Generated at 2022-06-23 15:01:12.076071
# Unit test for constructor of class FactCache
def test_FactCache():
    assert C.CACHE_PLUGIN == 'jsonfile'
    assert not FactCache()

# Generated at 2022-06-23 15:01:15.570009
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    cache = FactCache()
    cache['1'] = 'abc'
    cache['2'] = 'def'
    cache['3'] = 'ghi'
    assert cache.copy() == {u'1': u'abc', u'2': u'def', u'3': u'ghi'}



# Generated at 2022-06-23 15:01:17.343707
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache = FactCache()
    fact_cache.__delitem__("key")


# Generated at 2022-06-23 15:01:22.663270
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    cont_ = Cont()
    c = FactCache({'a': 'a'}, {'b': 'b'})
    c._plugin = cont_
    c.__delitem__('a')

    try:
        assert cont_['a'] == {}
    except:
        raise Exception('AssertionError: {}'.format(cont_['a']))

    c.__delitem__('b')


# Generated at 2022-06-23 15:01:30.666336
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    assert fact_cache.keys() == []

    fact_cache['foo.example.org'] = {'test': 'bar'}
    assert fact_cache.keys() == ['foo.example.org']

    fact_cache['bar.example.net'] = {'test': 'foo'}
    assert sorted(fact_cache.keys()) == ['bar.example.net', 'foo.example.org']


if __name__ == "__main__":
    import pytest
    pytest.main(['-xrs', __file__])

# Generated at 2022-06-23 15:01:31.465495
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    assert True

# Generated at 2022-06-23 15:01:34.581011
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    fact_cache["fake_key"] = {"fake": "facts"}
    assert(fact_cache.copy() == {"fake_key": {"fake": "facts"}})

# Generated at 2022-06-23 15:01:35.889238
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    c = FactCache()
    assert c.__len__() == 0


# Generated at 2022-06-23 15:01:37.777601
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fc = FactCache()
    fc['test'] = 'testvalue'
    assert fc['test'] == 'testvalue'


# Generated at 2022-06-23 15:01:42.286667
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    theFacts = dict()
    theFacts['host'] = dict()
    theFacts['host']['ansible_nodename'] = 'myhostname'

    the_cache = cache_loader.get(C.CACHE_PLUGIN)
    the_cache.set('myhostname', theFacts)

    fc = FactCache()
    assert 'ansible_nodename' in fc



# Generated at 2022-06-23 15:01:52.718120
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    # Instantiate a FactCache object
    factcache = FactCache()
    # Declare test values for keys and values
    key1 = 'testkey1'
    key2 = 'testkey2'
    key3 = 'testkey3'
    value1 = 'testvalue1'
    value2 = 'testvalue2'
    value3 = 'testvalue3'
    # Add test key/value pairs to the fact cache
    factcache[key1] = value1
    factcache[key2] = value2
    factcache[key3] = value3
    # Test __len__
    if len(factcache) != 3:
        raise Exception("FactCache object method __len__() failed")


# Generated at 2022-06-23 15:02:01.442504
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    """
    Test case to check the proper merge of facts from 2 hosts
    """

    cache = FactCache()

    host_facts = dict(
        ansible_all_ipv4_addresses=["192.168.0.2", "10.0.2.15"],
        ansible_default_ipv4=dict(address="192.168.0.2"),
        ansible_hostname="foo.example.org"
    )

    cache.first_order_merge('foo.example.org', host_facts)

    assert cache['foo.example.org'] == host_facts


# Generated at 2022-06-23 15:02:03.104153
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = FactCache()
    fact_cache['key1'] = 'value1'


# Generated at 2022-06-23 15:02:05.286763
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = FactCache()
    fact_cache['localhost'] = 'localhost'
    result = fact_cache.keys()

    assert 'localhost' in result


# Generated at 2022-06-23 15:02:11.025207
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fc = FactCache()
    fc['host1'] = {'key1': 'val1'}
    fc['host2'] = {'key2': 'val2'}
    assert set(['host1', 'host2']) == set(fc)


# Generated at 2022-06-23 15:02:14.513614
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    # Init
    cache = FactCache()
    key = 'key'
    value = 'value'

    cache[key] = value
    assert cache[key] == value

# Generated at 2022-06-23 15:02:15.337389
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    assert True    


# Generated at 2022-06-23 15:02:20.952356
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    from ansible.plugins.cache import memory

    cache = FactCache()
    cache._plugin = memory.FactCachePlugin()
    cache._plugin._data = dict(a=1, b=2, c=3)
    keys = cache.keys()
    assert len(keys) == 3
    assert 'a' in keys
    assert 'b' in keys
    assert 'c' in keys

# Generated at 2022-06-23 15:02:25.774230
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    '''
    This test verifies that the del operator (which invokes __delitem__)
    works as intended. This is the easier of the two delete methods,
    since it delegates to the plugin's delete method.
    '''
    key = "testkey"
    plugin = cache_loader.get(C.CACHE_PLUGIN)
    plugin.set(key, "the value")
    factcache = FactCache()
    del factcache[key]

    assert not plugin.contains(key)



# Generated at 2022-06-23 15:02:31.402778
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    f = FactCache()
    f[1] = 1
    f[2] = 2
    f[3] = 3
    assert f[1] == 1 and f[2] == 2 and f[3] == 3
    del f[2]
    del f[3]
    assert f[1] == 1 and len(f) == 1


# Generated at 2022-06-23 15:02:39.895197
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # initialize data
    old_host_cache = dict()
    old_host_cache['key1'] = 'value1'
    old_host_cache['key2'] = 'value2'
    host_facts = {'key3': 'value3'}

    # mock of cache_loader.get
    cache_plugin = CachePlugin()
    cache_plugin.set_keys(old_host_cache)
    cache_loader.get = lambda x: cache_plugin

    # mock of FactCache.update
    update_called = False
    def mock_update(x):
        nonlocal update_called
        assert x == {'key3': {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}}
        update_called = True
    FactCache.update = mock_update

    #

# Generated at 2022-06-23 15:02:43.146966
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    cache = FactCache()
    cache['test_item'] = 'test_value'
    assert 'test_item' in cache
    cache.flush()
    assert 'test_item' not in cache

# Generated at 2022-06-23 15:02:48.209086
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    fact_cache['hostname'] = 'host-1'
    fact_cache['key1'] = 'val1'
    fact_cache['key2'] = 'val2'

    assert (fact_cache.keys() == ['hostname', 'key1', 'key2'])


# Generated at 2022-06-23 15:02:50.757642
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    with pytest.raises(AnsibleError) as excinfo:
        FactCache()
    assert 'Unable to load the facts cache plugin' in str(excinfo.value)



# Generated at 2022-06-23 15:02:54.626785
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    # FactCache.__iter__() -> FactCache_iterator

    fc = FactCache()
    # print("\nfc = ", fc)
    assert isinstance(fc, FactCache)

    fi = iter(fc)
    # print("\nfi = ", fi)
    assert isinstance(fi, FactCache_iterator)

    # print("\nfc = ", fc)
    # print("\nfi = ", fi)


# Generated at 2022-06-23 15:02:56.788449
# Unit test for constructor of class FactCache
def test_FactCache():
    factCache = FactCache()
    assert factCache
    assert factCache._plugin
    assert factCache._plugin.get_plugin_class()

# Generated at 2022-06-23 15:03:00.906665
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    f = FactCache()
    data = {}
    f._plugin = data
    assert( f.__contains__("not") == False )
    data['contains'] = lambda key : True
    assert( f.__contains__("not") == True )


# Generated at 2022-06-23 15:03:05.625647
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache = FactCache()
    fact_cache.load_fact_cache = "test"
    fact_cache.__delitem__("load_fact_cache")
    assert len(fact_cache) == 0


# Generated at 2022-06-23 15:03:08.614750
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fc = FactCache()
    fc._plugin = FakeCachePlugin()
    assert fc.__contains__("key1")
    assert not fc.__contains__("key2")


# Generated at 2022-06-23 15:03:10.912560
# Unit test for method keys of class FactCache
def test_FactCache_keys():

    # Keys of the object FactCache
    cache = FactCache()
    keys = cache.keys()
    assert keys is not None


# Generated at 2022-06-23 15:03:16.445728
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

        fc = FactCache()

        host_cache = {u'foo': 'bar'}
        fc['test'] = host_cache

        new_facts = {u'foo': 'bar', u'foo2': 'bar2'}
        fc.first_order_merge('test', new_facts)

        result = fc['test']

        # print(result)
        # {'foo': 'bar', 'foo2': 'bar2'}

        assert result == {'foo': 'bar', 'foo2': 'bar2'}

# Generated at 2022-06-23 15:03:18.685137
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    new_cache = FactCache()
    new_cache['new_cache'] = {'new_cache':'cache'}
    assert len(new_cache) > 0
    new_cache.flush()
    assert len(new_cache) == 0

# Generated at 2022-06-23 15:03:20.522371
# Unit test for constructor of class FactCache
def test_FactCache():
    """This is a placeholder for when we add unit tests."""
    pass

# Generated at 2022-06-23 15:03:22.375581
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    cache = FactCache()
    assert not cache
    cache['testkey'] = 'testvalue'
    assert 'testkey' in cache
    cache.__delitem__('testkey')
    assert not cache


# Generated at 2022-06-23 15:03:25.027531
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fc = FactCache()
    l = len(fc)
    #Should be length 0
    if l != 0:
        raise AssertionError()


# Generated at 2022-06-23 15:03:29.118884
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache = FactCache()
    fact_cache['key_1'] = 'val_1'
    fact_cache['key_2'] = 'val_2'
    del fact_cache['key_1']
    assert fact_cache.keys() == ['key_2']

# Generated at 2022-06-23 15:03:30.887735
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    cache = FactCache()
    assert not cache.__contains__("any_key")


# Generated at 2022-06-23 15:03:35.681066
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    assert len(FactCache().keys()) == 0
    _fc = FactCache({'arg1': 'arg1_value', 'arg2': 'arg2_value'})
    assert len(_fc.keys()) == 2
    _fc.flush()
    assert len(_fc.keys()) == 0

# Generated at 2022-06-23 15:03:43.915174
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    from ansible.plugins.cache import BaseFileCacheModule
    from ansible.utils.display import Display
    # setup test
    display = Display()
    cache_loader.add('test__len__', BaseFileCacheModule, 'ansible.plugins.cache.test_cache', display)
    cache = FactCache()
    path = cache._plugin._cache_dir
    import os
    if os.path.exists(path):
        import shutil
        shutil.rmtree(path)
    os.mkdir(path)
    # test
    assert len(cache) == 0
    cache['test__len__'] = {'test__len__': 0}
    assert len(cache) == 1
    # cleanup test
    if os.path.exists(path):
        import shutil

# Generated at 2022-06-23 15:03:46.467990
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fact_cache = FactCache()
    assert(fact_cache.__iter__ == iter(fact_cache))



# Generated at 2022-06-23 15:03:55.813999
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    assert not FactCache().__contains__('')

if __name__ == '__main__':
    print('Testing Ansible')
    print('================')
    print('Please wait ...')
    import collections
    fc = FactCache()
    print('Test Results')
    print('------------')
    print('Test object: {} --'.format(type(fc).__name__))
    test_types = (collections.Callable, collections.Mapping)
    for ttype in test_types:
        print('  Is {} a subclass of {}? {}'.format(
            type(fc).__name__, ttype.__name__, issubclass(type(fc), ttype)))
    del fc
    print('Test functions: --')

# Generated at 2022-06-23 15:04:00.270297
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    f = FactCache()
    f['test'] = 'test_value'
    if 'test' in f:
        print('exist')
    else:
        print('not exist')
    del f['test']
    if 'test' in f:
        print('exist')
    else:
        print('not exist')


# Generated at 2022-06-23 15:04:03.828938
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    print("Test __len__")
    my_factcache = FactCache()

    my_factcache['test'] = "testy"
    assert(len(my_factcache) == 1)


# Generated at 2022-06-23 15:04:11.104472
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    cache = FactCache()
    cache.__setitem__('host', 'ansible1')
    cache.__setitem__('host', 'ansible2')

    assert cache.__contains__('host')
    assert 'host' in cache
    assert isinstance(cache.__iter__(), type(iter([])))
    assert isinstance(iter(cache), type(iter([])))
    assert list(cache.__iter__()) == ['host']
    assert list(iter(cache)) == ['host']


# Generated at 2022-06-23 15:04:13.289716
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    cache = FactCache()
    cache._plugin.data = {'test': 'test'}
    assert len(cache) == 1


# Generated at 2022-06-23 15:04:17.511255
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    obj = FactCache()
    ansible_facts_dict = dict({"foo": "bar"})
    obj["localhost"] = ansible_facts_dict
    assert obj["localhost"] == {"foo": "bar"}


# Generated at 2022-06-23 15:04:24.633699
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact = FactCache()
    fact['key1'] = {'key1': 1, 'key2': 2, 'key3': 3}
    fact['key2'] = {'key1': 1, 'key2': 2, 'key3': 3}
    fact['key3'] = {'key1': 1, 'key2': 2, 'key3': 3}

    assert fact.copy() == {'key1': {'key1': 1, 'key2': 2, 'key3': 3}, 'key3': {'key1': 1, 'key2': 2, 'key3': 3}, 'key2': {'key1': 1, 'key2': 2, 'key3': 3}}


# Generated at 2022-06-23 15:04:32.063945
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    test_cache = FactCache()
    assert len(test_cache) == 0

    test_cache['192.168.1.1'] = {
        'ansible_ssh_host': '192.168.1.1',
        'ansible_ssh_port': 22
    }

    assert len(test_cache) == 1

    test_cache.flush()
    assert len(test_cache) == 0


# Generated at 2022-06-23 15:04:34.920690
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    cache = FactCache()
    cache['value1'] = "value1"
    assert (cache['value1'] == "value1")
    del cache['value1']
    assert (cache.get('value1') == None)


# Generated at 2022-06-23 15:04:37.013673
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fact_cache = FactCache()
    for key in fact_cache:
        print(key)

# Generated at 2022-06-23 15:04:42.914214
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    cache_key = 'my_fact'
    cache_data = {'a': 'b'}
    fact_cache.__setitem__(cache_key, cache_data)
    assert(len(fact_cache) == 1)
    assert(fact_cache.__contains__(cache_key))
    fact_cache.flush()
    assert(len(fact_cache) == 0)
    assert(not fact_cache.__contains__(cache_key))

# Generated at 2022-06-23 15:04:53.197660
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six.moves import cPickle as pickle

    cache = FactCache()
    cache._plugin.set(to_bytes('host1'), pickle.dumps({'a': 1}))
    assert len(cache) == 1

    cache._plugin.set(to_bytes('host2'), pickle.dumps({'b': 2}))
    assert len(cache) == 2

    cache._plugin.delete(to_bytes('host2'))
    assert len(cache) == 1

    cache._plugin.flush()
    assert len(cache) == 0


# Generated at 2022-06-23 15:04:56.472447
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache=FactCache()
    ret=fact_cache.__len__()
    assert ret==len(fact_cache)

#Unit test for method __iter__ of class FactCache

# Generated at 2022-06-23 15:04:58.048373
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fc = FactCache()

    #should not raise any exception
    fc.flush()

# Generated at 2022-06-23 15:05:05.165372
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    my_dict = {'ansible_eth0': {}}
    my_fact_cache = None
    my_name = 'test_host'

    # This code is used to force a plugin to return a specific result by
    # calling __contains__
    try:
        my_plugin = cache_loader.get(C.CACHE_PLUGIN)
        my_plugin.mocked_get = my_dict
        my_fact_cache = FactCache()
        assert my_name in my_fact_cache
    finally:
        pass
    if my_fact_cache:
        my_fact_cache.flush()
    # End code used to force a plugin to return a specific result by
    # calling __contains__

    # Test if the mocked plugin is used when needed and if it is not used
    # when not needed

   

# Generated at 2022-06-23 15:05:09.540138
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    '''Unit test for method __getitem__ of class FactCache'''

    # Initialize FactCache
    fact_cache = FactCache()
    

    # Run __getitem__() method
    result = fact_cache.__getitem__()

    # Test process
    #assert result == expected



# Generated at 2022-06-23 15:05:18.314550
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    old_plugin = C.CACHE_PLUGIN
    C.CACHE_PLUGIN = 'jsonfile'
    fact_cache = FactCache()
    assert fact_cache
    assert fact_cache.__setitem__('test_key', 'test_value')
    assert fact_cache.__contains__('test_key')
    assert fact_cache.__getitem__('test_key') == 'test_value'
    assert fact_cache.__delitem__('test_key')
    assert not fact_cache.__contains__('test_key')
    C.CACHE_PLUGIN = old_plugin


# Generated at 2022-06-23 15:05:24.364557
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = FactCache()

    # test empty fact cache
    fact_cache['host1'] = {'var1': 'value1', 'var2': 'value2'}
    assert fact_cache['host1'] == {'var1': 'value1', 'var2': 'value2'}

    # test non-empty fact cache
    fact_cache['host2'] = {'var1': 'value1', 'var2': 'value2'}
    assert fact_cache['host2'] == {'var1': 'value1', 'var2': 'value2'}



# Generated at 2022-06-23 15:05:32.032524
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    import os
    os.environ["ANSIBLE_CACHE_PLUGIN"] = "jsonfile"
    os.environ["ANSIBLE_CACHE_PLUGIN_CONNECTION"] = "/tmp/ansible_jasonfile"
    fc = FactCache()
    fc["key"] = "value"
    fc.flush()
    os.remove("/tmp/ansible_jasonfile")


# Generated at 2022-06-23 15:05:32.863996
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    pass

# Generated at 2022-06-23 15:05:36.777655
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    fact_cache["test"] = "test"
    fact_cache["test1"] = "test1"
    assert fact_cache.copy() == {"test": "test", "test1": "test1"}

# Generated at 2022-06-23 15:05:47.575404
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    from ansible.plugins.cache import BaseFactCacheModule
    from ansible.plugins.loader import cache_loader

    class TestFactCacheModule(BaseFactCacheModule):
        def get_cache_path(self, host):
            pass

        def __getitem__(self, key):
            pass

        def __setitem__(self, key, value):
            pass

        def __delitem__(self, key):
            pass

        def __contains__(self, key):
            return True

        def keys(self):
            return ['1', '2']

        def flush(self):
            pass

    cache_loader.add('test_fact_cache', TestFactCacheModule)
    cache_loader.get('test_fact_cache')

    fact_cache = FactCache()

    assert len(fact_cache) == 2

# Generated at 2022-06-23 15:05:53.722212
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    fact_cache['1'] = 'one'
    fact_cache['2'] = 'two'
    fact_cache['3'] = 'three'
    fact_cache['4'] = 'four'

    assert fact_cache.copy() == {'1': 'one', '2': 'two', '3': 'three', '4': 'four'}

# Generated at 2022-06-23 15:06:04.139287
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    """ This test takes a while to run because it actually updates the factcache """
    print("Testing FactCache.__getitem__()")
    if C.CACHE_PLUGIN == 'memory':
        # The memory cache plugin does not persist facts between runs, so we need
        # to populate the factcache ourselves in this test.
        fact_cache = FactCache()
        # It is important that we set facts for multiple hosts, in both possible
        # cases (multiple facts for one host, and multiple facts for multiple hosts)
        fact_cache["192.168.0.1"] = {"kernel": "Linux", "os": "Ubuntu"}
        fact_cache["192.168.0.2"] = {"kernel": "Linux", "os": "RedHat"}

# Generated at 2022-06-23 15:06:08.798583
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    #fact_cache = FactCache()
    fact_cache = FactCache()
    key = "test"
    fact_cache[key] = 'test'
    assert fact_cache[key] == 'test'
    del fact_cache[key]
    assert not fact_cache.__contains__(key)


# Generated at 2022-06-23 15:06:17.963886
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    from ansible.errors import AnsibleError
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.plugins.loader import cache_loader
    from ansible.utils.display import Display
    from ansible.utils.path import unfrackpath

    # creating an instance of the class FactCache
    fc = FactCache()
    assert isinstance(fc, FactCache)

    # Test if the object is an instance of the class MutableMapping
    assert isinstance(fc, MutableMapping)

    # Test if the attribute _plugin is an instance of the class cache_loader
    assert isinstance(fc._plugin, cache_loader)

    # Test if the instance of the class has the attribute _plugin
    assert hasattr(fc, '_plugin')

    # Test if the class has the attribute _

# Generated at 2022-06-23 15:06:19.821483
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    assert fact_cache.keys()

# Generated at 2022-06-23 15:06:20.725412
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    assert True

# Generated at 2022-06-23 15:06:25.175851
# Unit test for constructor of class FactCache
def test_FactCache():
    def __init__(self, *args, **kwargs):
        super(Facts, self).__init__(*args, **kwargs)  
    FactCache()

# Generated at 2022-06-23 15:06:25.819412
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    assert True

# Generated at 2022-06-23 15:06:35.819695
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.flush()
    assert not fact_cache
    key = 'localhost'
    value = {
        'gather_subset': ['min'],
        'gather_timeout': 10,
        'ansible_facts': {
            'ansible_all_ipv4_addresses': ['127.0.0.1'],
            'ansible_os_family': 'Debian'
        }
    }
    fact_cache.first_order_merge(key, value)
    assert fact_cache[key] == value

# Generated at 2022-06-23 15:06:38.623778
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Unit tests to verify the _plugin

# Generated at 2022-06-23 15:06:39.573550
# Unit test for constructor of class FactCache
def test_FactCache():
    f = FactCache()
    assert f

# Generated at 2022-06-23 15:06:40.988563
# Unit test for constructor of class FactCache
def test_FactCache():

    with pytest.raises(AnsibleError):
        fc = FactCache()

# Generated at 2022-06-23 15:06:45.563475
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fc = FactCache()
    fc["host1"] = "value"
    fc["host2"] = "value"
    fc["host3"] = "value"

    count = 0
    for key in fc:
        count += 1
    assert count == len(fc)



# Generated at 2022-06-23 15:06:55.945093
# Unit test for method flush of class FactCache
def test_FactCache_flush():
  class FakePlugin:
    def __init__(self):
      self.keys = []

    def contains(self, key):
      return True

    def set(self, key, value):
      self.keys.append(key)

    def get(self, key):
      return self.keys

    def delete(self, key):
      self.keys.remove(key)

    def flush(self):
      self.keys = []

  f = FactCache()
  f._plugin = FakePlugin()
  f['fact'] = {'fact': 'fact'}
  assert f['fact'] == {'fact': 'fact'}
  f.flush()
  assert f._plugin.keys == []

# Generated at 2022-06-23 15:07:07.676955
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fc = FactCache()
    # Test 1: test __iter__ with none cache
    assert fc.__iter__() is not None
    # Test 2: test __iter__ with none cache
    fc._plugin.set('test1', 'test1')
    fc._plugin.set('test2', 'test2')
    iter_value = fc.__iter__()
    assert len(iter_value) == 2

    # Test 3: test __iter__ with all keys
    fc._plugin.delete('test1')
    fc._plugin.delete('test2')
    iter_value = fc.__iter__()
    assert len(iter_value) == 0


# Generated at 2022-06-23 15:07:12.154256
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    display.display('Test __iter__')

    facts_cache = FactCache()

    facts_cache['test_hostname'] = dict()
    facts_cache['test_hostname']['facts'] = {'test_key': 'test_value'}

    for key, value in facts_cache.items():
        display.display(key, value)



# Generated at 2022-06-23 15:07:13.943339
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fact_cache = FactCache()
    assert "test" not in fact_cache



# Generated at 2022-06-23 15:07:17.000432
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    # Set default value in cache_loader
    C.CACHE_PLUGIN = "jsonfile"
    assert fact_cache.__len__() == 0

# Generated at 2022-06-23 15:07:20.424689
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
	
	fc = FactCache()
	assert(fc._plugin.get("testKey") == None)

	fc["testKey"]="testValue"
	assert(fc._plugin.get("testKey") == "testValue")



# Generated at 2022-06-23 15:07:31.237343
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    try:
        ansible_facts = FactCache()
    except AnsibleError as e:
        assert False, e.message

    assert set(ansible_facts.keys()) == set()

    ansible_facts['localhost'] = {
        'ansible_facts': {
            'k1': 'v1',
            'k2': 'v2'
        }
    }
    ansible_facts['127.0.0.1'] = {
        'ansible_facts': {
            'k3': 'v3'
        }
    }

    keys = ansible_facts.keys()
    assert isinstance(keys, list) and len(keys) == 2 and set(keys) == set(['localhost', '127.0.0.1'])

# Generated at 2022-06-23 15:07:36.468976
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    current_facts = {'a': 1}
    new_facts = {'a': 2, 'b': 2}
    expected_facts = {'a': 2, 'b': 2}

    fac = FactCache()
    fac.first_order_merge('foo', current_facts)
    fac.first_order_merge('foo', new_facts)
    assert fac['foo'] == expected_facts

# Generated at 2022-06-23 15:07:39.617903
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fc = FactCache(None)
    assert fc == {}
    assert fc.keys() == []


# Generated at 2022-06-23 15:07:44.389171
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    my_plugin = cache_loader.get(C.CACHE_PLUGIN)
    my_plugin.set("test", "testfact")
    fact_cache = FactCache()
    result = fact_cache.__getitem__("test")
    if result == "testfact":
        assert True
    else:
        assert False


# Generated at 2022-06-23 15:07:52.810691
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    import json
    import sys
    import tempfile
    from ansible.module_utils.six import StringIO
    from ansible.plugins.cache import jsonfile

    cache_dir = tempfile.mkdtemp(prefix='ansible-fact-cache-test')
    fact_cache = FactCache(plugin=jsonfile.JsonfileCacheModule(cache_dir=cache_dir))

    fact_vars = {
        'var1': 1,
        'var2': 2,
        'var3': {'var4': 3, 'var5': 4},
        'var6': [5, 6],
    }

    # Test
    ref_stdout = sys.stdout
    out = StringIO()
    sys.stdout = out

    fact_cache['test_FactCache___setitem__.domain.com'] = fact_

# Generated at 2022-06-23 15:07:59.348379
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    factcache = FactCache()
    factcache[1] = "hello"
    factcache[2] = "world"
    assert factcache.__len__() == 2
    assert factcache[1] == "hello"
    assert factcache[2] == "world"
    factcache.flush()
    assert factcache.__len__() == 0


# Generated at 2022-06-23 15:08:04.467404
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    #arrange
    fact_cache = FactCache()

    #assert
    assert hasattr(fact_cache, '__iter__')

    #arrange
    fact_cache = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
    fact_cache = FactCache(fact_cache)

    #act
    for i in fact_cache:
        #assert
        assert i in fact_cache


# Generated at 2022-06-23 15:08:05.842043
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()

# Generated at 2022-06-23 15:08:08.682411
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    f = FactCache()
    f['a'] = 1
    f['b'] = 2
    if f.keys() == ['a', 'b']:
        print('Pass')
    else:
        print('Failed')


# Generated at 2022-06-23 15:08:18.145642
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    from copy import copy
    fact_cache = FactCache()
    # A new fact cache must be empty
    assert sum(1 for fact in fact_cache) == 0
    # Add some facts
    fact_cache['test_fact'] = 1
    fact_cache['test_fact2'] = 2
    # Check they can be found
    assert sum(1 for fact in fact_cache) == 2
    assert 'test_fact' in fact_cache
    assert 'test_fact2' in fact_cache
    # Ensure the iterator is not a reference
    iterator = iter(fact_cache)
    assert 'test_fact' in iterator


# Generated at 2022-06-23 15:08:19.589657
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    f = FactCache()

    # no tests yet
    pass


# Generated at 2022-06-23 15:08:28.017878
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    resource_facts = {'192.168.1.1':{'version':'1.0.0'}, '192.168.1.2':{'version':'1.0.1'}}
    new_cache = FactCache()
    # New cache is empty, so the iteration result is []
    assert [i for i in new_cache] == []

    new_cache.update(resource_facts)
    # The iteration result of new_cache is ['192.168.1.1', '192.168.1.2']
    assert [i for i in new_cache] == ['192.168.1.1', '192.168.1.2']


# Generated at 2022-06-23 15:08:37.011713
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    factcache = FactCache()

    factcache.first_order_merge("host", {'fact1': 'ansible', 'fact2': 'is cool'})
    assert factcache.keys() == ['host']

    host_facts = {'host': {'fact1': 'ansible', 'fact2': 'is cool'}}
    assert factcache.copy() == host_facts

    factcache.first_order_merge("host", {'fact1': 'brian', 'fact3': 'is cooler'})
    assert factcache.keys() == ['host']

    host_facts['host'].update({'fact1': 'brian', 'fact3': 'is cooler'})
    assert factcache.copy() == host_facts

    factcache.flush()
    assert factcache.keys() == []



# Generated at 2022-06-23 15:08:40.128796
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = FactCache()
    fact_cache["test1"] = "value1"
    assert fact_cache["test1"] == "value1"



# Generated at 2022-06-23 15:08:43.682355
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    
    #
    # The first test
    #
    print("test_FactCache___len__ ok!")

test_FactCache___len__()


# Generated at 2022-06-23 15:08:51.638144
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    import os
    import shutil
    import tempfile

    # Create test directory and files
    cache_dir = tempfile.mkdtemp()
    host_file = os.path.join(cache_dir, 'test_host_file')
    with open(host_file, 'w') as host_file_object:
        host_file_object.write('{"test_key": "test_value"}')

    # Resolve CACHE_PLUGIN to file based cache
    CACHE_PLUGIN = os.path.join(os.path.dirname(__file__),
                                '..',
                                'plugins',
                                'cache',
                                'jsonfile.py')

    # Testing __contains__ method

# Generated at 2022-06-23 15:08:52.836660
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    assert True


# Generated at 2022-06-23 15:09:01.521876
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    try:
        cache['']
        assert False, 'Cache should not have any elements'
    except KeyError:
        assert True, 'Cache should not have any elements'

    cache['test'] = 'test_value'
    assert len(cache.keys()) == 1
    try:
        cache.copy()
        assert False, 'Should not be able to copy from cache'
    except TypeError:
        assert False, 'Should not be able to copy from cache'
    except NotImplementedError:
        assert True, 'Should not be able to copy from cache'
    cache.flush()
    try:
        cache['test']
        assert False, 'Cache should not have any elements'
    except KeyError:
        assert True, 'Cache should not have any elements'