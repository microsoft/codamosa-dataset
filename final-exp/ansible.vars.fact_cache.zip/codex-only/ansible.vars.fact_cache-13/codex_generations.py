

# Generated at 2022-06-23 14:59:01.544204
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    factCache = FactCache()
    factCache.set( 'host1', { 'existing_host_fact': 'value' } )

    factCache.first_order_merge( 'host1', { 'new_host_fact': 'value' } )

    assert 'existing_host_fact' in factCache
    assert 'new_host_fact' in factCache

    factCache.first_order_merge( 'host2', { 'host_fact': 'value' } )
    assert 'host_fact' in factCache

# Tests for method copy of class FactCache

# Generated at 2022-06-23 14:59:04.507398
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    '''
        If key is found in the fact cache, __contains__ returns True.
    '''
    fact_cache = FactCache()
    fact_cache['key'] = 'value'
    assert 'key' in fact_cache

# Generated at 2022-06-23 14:59:07.774372
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = FactCache()
    fact_cache['key1'] = {'name1': 'value1'}
    assert fact_cache['key1'] == {'name1': 'value1'}

    fact_cache['key1'] = {'name2': 'value2'}
    assert fact_cache['key1'] == {'name1': 'value1', 'name2': 'value2'}



# Generated at 2022-06-23 14:59:10.751841
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    fact_cache['localhost'] = {}
    assert fact_cache.copy() == {'localhost': {}}


# Generated at 2022-06-23 14:59:11.350571
# Unit test for constructor of class FactCache
def test_FactCache():
    assert FactCache()

# Generated at 2022-06-23 14:59:17.144134
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    cache_plugins = [
        'memory',
        'jsonfile',
    ]

    original_cache_plugin = C.CACHE_PLUGIN
    for cache_plugin in cache_plugins:
        C.CACHE_PLUGIN = cache_plugin

        try:
            cache = FactCache()

            cache['foo'] = 'bar'
            assert cache['foo'] == 'bar'
            del cache['foo']
            assert not cache.keys()
        finally:
            C.CACHE_PLUGIN = original_cache_plugin



# Generated at 2022-06-23 14:59:24.446884
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    factcache = FactCache()
    factcache[u'1'] = 1
    factcache[2] = 2
    factcache[3.0] = 3.0
    factcache[u'4'] = u'4'
    factcache[u'5'] = [1, 2]
    factcache[u'6'] = {'a': 1, 'b': 2}

    d = factcache.copy()
    assert d == factcache
    assert d is not factcache

# Generated at 2022-06-23 14:59:26.214320
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache=FactCache()
    fact_cache.__delitem__('key')
    pass

# Generated at 2022-06-23 14:59:35.795410
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    import os
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cPickle as pickle

    if PY3:
        import sys
        pickle.HIGHEST_PROTOCOL = sys.version_info[0]

    test_fact_dict = {'fact_1': 'fact_value_1', 'fact_2': 'fact_value_2', 'fact_3': 'fact_value_3'}

    fc = FactCache()
    fc.update(test_fact_dict)
    fc.flush()

    assert not os.path.exists(fc._plugin.cache_file)

# Generated at 2022-06-23 14:59:46.276842
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Instantiation of FactCache class
    fc = FactCache()
    # Adding the value of 'foo' with key='hostname'
    fc.first_order_merge('hostname', 'foo')

    # If the merge was successfull, then the following test should pass
    assert fc['hostname'] == 'foo'

    # Case 2
    # Values from ansible_default.yaml

# Generated at 2022-06-23 14:59:51.167814
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'key1': 'value1'}})
    assert fact_cache['localhost']['ansible_facts']['key1'] == 'value1'



# Generated at 2022-06-23 15:00:00.877003
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    from copy import deepcopy
    from ansible.module_utils.facts.collector import CacheHandler
    from ansible.plugins.cache import memory
    from ansible.plugins.loader import cache_loader

    # Create memory cache object
    cache_loader.add(memory.CacheModule(), 'memory')
    # Create fact cache object
    fact_cache = FactCache()
    # Create cache handler
    cache_handler = CacheHandler(memory.CacheModule())

    # Set fact cache to True
    C.CACHE_LOAD_FACTS = True

    # test_dict is the dict to use in the test

# Generated at 2022-06-23 15:00:05.380649
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    # Test with fact_caching as jsonfile
    fc = FactCache()
    fc['testkey'] = 'testval'

    # Test with fact_caching as memory
    fc2 = FactCache()
    fc2['testkey'] = 'testval'

# Generated at 2022-06-23 15:00:08.751354
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    _plugin = {'ansible_distribution': 'CentOS', 'ansible_distribution_major_version': '7', 'ansible_distribution_version': '7.7.1908', 'ansible_os_family': 'RedHat', 'ansible_pkg_mgr': 'yum'}
    fact_cache = FactCache()
    fact_cache._plugin = _plugin
    val = fact_cache.__iter__()
    assert tuple(val) == ('ansible_distribution', 'ansible_distribution_major_version', 'ansible_distribution_version', 'ansible_os_family')


# Generated at 2022-06-23 15:00:18.549076
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    from ansible.plugins.cache import RedisCacheModule
    import time
    import uuid
    import six

    def random_str():
        return str(uuid.uuid4())

    fact_cache = FactCache()
    key = random_str()
    value = random_str()

    fact_cache[key] = value
    fact_data = fact_cache._plugin.get(key)

    assert fact_cache._plugin.__class__ == RedisCacheModule
    assert fact_data["value"] == value
    assert six.PY3
    assert isinstance(fact_data["expire_seconds"], int)
    assert isinstance(fact_data["metadata"], dict)
    assert fact_data["timestamp"] is not None



# Generated at 2022-06-23 15:00:29.525556
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    # GIVEN
    from ansible.plugins.cache.memory import CacheModule as memory
    from ansible.plugins.cache.redis import CacheModule as redis
    from ansible.plugins.cache.jsonfile import CacheModule as jsonfile
    from ansible.plugins.cache.yaml import CacheModule as yaml
    cache_plugins = {"memory": memory, "jsonfile": jsonfile, "yaml": yaml, "redis": redis}
    host = "test_host"

    # WHEN
    fact_cache = FactCache()
    fact_cache.__setitem__(host, {"test_fact": "test_value"})
    for cache_plugin in cache_plugins:
        fact_cache._plugin = cache_plugins[cache_plugin]()
        assert host in fact_cache.keys()

    # THEN
    fact

# Generated at 2022-06-23 15:00:31.774368
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    plugin = cache_loader.get('memory')
    plugin.set('value', 1)
    assert plugin.contains('value')
    assert not plugin.contains('not_value')

# Generated at 2022-06-23 15:00:36.188866
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    # 
    test_c = FactCache()
    assert len(test_c) == 0
    # 
    test_c._plugin = 'plugin'
    test_c._plugin.keys_cache = 'keys_cache'
    assert len(test_c) == 0

# Generated at 2022-06-23 15:00:41.118537
# Unit test for constructor of class FactCache
def test_FactCache():

    from ansible.utils.display import Display
    display = Display()

    cache_plugin = "jsonfile"
    display.display(u'CACHE_PLUGIN = %s' % cache_plugin)
    factcache = FactCache(cache_plugin=cache_plugin)
    factcache.display.display(u'fact cache = %s' % factcache)

# Generated at 2022-06-23 15:00:41.704409
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    pass

# Generated at 2022-06-23 15:00:50.529870
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()

    # Test initial state of the cache
    assert len(cache) == 0
    assert cache.keys() == []

    # Test update with a missing key
    cache.first_order_merge("test_key", {"hello": "world"})
    assert len(cache) == 1
    assert cache.keys() == ["test_key"]
    assert cache["test_key"] == {"hello": "world"}

    # Test update with an existing key
    cache.first_order_merge("test_key", {"test": "value"})
    assert len(cache) == 1
    assert cache.keys() == ["test_key"]
    assert cache["test_key"] == {"hello": "world", "test": "value"}

# Generated at 2022-06-23 15:00:53.352497
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    c = FactCache()
    c[1] = "one"
    try:
        print(c[1])
        print(c[2])
    except KeyError:
        print("key error")
    except Exception as e:
        print(e)


# Generated at 2022-06-23 15:00:57.664531
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    from ansible.plugins.cache import memory
    from ansible.utils.display import Display
    from fact_cache import FactCache
    fact_cache = FactCache()
    cache_plugin = memory.FactCacheModule()
    cache_plugin.flush()
    key = 'test_key'
    assert fact_cache._plugin.contains(key) == False
    FactCache._FactCache__contains__(fact_cache, key) == fact_cache._plugin.contains(key)
    return


# Generated at 2022-06-23 15:01:02.759835
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fcache = FactCache()

    host_name = 'cc'
    fcache.first_order_merge(host_name, {'defaults': {'lang': 'en_US'}})
    fcache.first_order_merge(host_name, {'defaults': {'lang': 'en_GB'}})

    assert fcache[host_name] == {'lang': 'en_GB'}

# Generated at 2022-06-23 15:01:05.878899
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    from mock import Mock, patch

    cache_plugin = Mock()
    facts_cache = FactCache()
    facts_cache._plugin = cache_plugin

    facts_cache.flush()

    cache_plugin.flush()

# Generated at 2022-06-23 15:01:12.074232
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    # check __len__ with empty cache
    try:
        fact_cache = FactCache(dict())
        fact_cache._plugin = FakeCachePlugin()
        length = len(fact_cache)
    except:
        assert False

    # check __len__ with non empty cache
    try:
        fact_cache = FactCache(dict())
        fact_cache._plugin = FakeCachePlugin()
        fact_cache['a'] = "a"
        length = len(fact_cache)
    except:
        assert False


# Generated at 2022-06-23 15:01:14.853427
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    # Create a object of class FactCache
    fact_cache = FactCache()

    # Test __getitem__ with non-existing keys
    assert fact_cache['test_key'] == None

    # Test __getitem__ with existing keys
    fact_cache['test_key'] = 'test_item'
    assert fact_cache['test_key'] == 'test_item'


# Generated at 2022-06-23 15:01:17.710859
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    print('Testing __getitem__')
    fact_cache = FactCache()
    fact_cache['fact'] = True
    assert fact_cache['fact'] is True


# Generated at 2022-06-23 15:01:21.346590
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    factCache = FactCache()
    factCache['a'] = 1
    factCache['b'] = 2
    factCache['c'] = 3

    for key in factCache:
        assert factCache[key] == factCache.__getitem__(key)



# Generated at 2022-06-23 15:01:24.377361
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    TestCache = FactCache()

    TestCache["a"] = "b"
    TestCache["c"] = "d"

    assert len(TestCache) == 2


# Generated at 2022-06-23 15:01:26.440342
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = FactCache()

    host = 'fakehost'
    facts = {'a': 1, 'b': 2}
    fact_cache[host] = facts

    assert fact_cache[host] == facts


# Generated at 2022-06-23 15:01:34.005496
# Unit test for constructor of class FactCache
def test_FactCache():
    assert C.CACHE_PLUGIN == 'memory'
    assert isinstance(FactCache(), dict)

    # Create the fact cache
    fact_cache = FactCache()

    # Create a fact
    fact1 = {'name':  'test_value'}

    # Set the fact in the cache
    fact_cache.first_order_merge('test_key', fact1)

    # Get the fact from the cache
    fact2 = fact_cache.get('test_key')

    # Compare the original fact and the fact from the cache
    assert fact1 == fact2

# Generated at 2022-06-23 15:01:36.169740
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    '''Unit tests for method __iter__ of class Ansible.FactCache'''
    facts = FactCache()
    assert isinstance(iter(facts),iter)

# Generated at 2022-06-23 15:01:43.450345
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    class TestFactCache(FactCache):
        def __init__(self, *args, **kwargs):
            pass

        def __getitem__(self, key):
            return 1

        def __setitem__(self, key, value):
            pass

        def __delitem__(self, key):
            pass

        def __iter__(self):
            return iter([1, 2, 3])

        def keys(self):
            return [1, 2, 3]

    test1 = TestFactCache()
    count = 0
    for _ in test1:
        count += 1
    assert count == 3
    test2 = TestFactCache()
    assert len(test2) == 3


# Generated at 2022-06-23 15:01:45.316604
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fact_cache = FactCache()
    result = fact_cache.__iter__()
    assert result



# Generated at 2022-06-23 15:01:51.628724
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    plugin = Mock()
    plugin.keys.return_value = ImmutableDict(foo = 1, bar = 2).keys()
    f = FactCache(plugin)
    result = f.__len__()
    assert result is 2


# Generated at 2022-06-23 15:02:00.765045
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    ansible_facts = {}
    ansible_facts[u'ansible_distribution'] = u'CentOS'
    ansible_facts[u'ansible_distribution_major_version'] = u'7'
    ansible_facts[u'ansible_distribution_version'] = u'7.4.1708'
    ansible_facts[u'ansible_fqdn'] = u'localhost.localdomain'
    ansible_facts[u'ansible_hostname'] = u'localhost'
    ansible_facts[u'ansible_interfaces'] = [u'lo']
    ansible_facts[u'ansible_kernel'] = u'3.10.0-693.21.1.el7.x86_64'
    ansible_facts[u'ansible_machine_id']

# Generated at 2022-06-23 15:02:11.557445
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Create an empty fact cache
    fact_cache = FactCache()

    # Prepare some test data
    key = 'test_host'
    value_1 = {'test_key_one': 'test_value_one'}
    value_2 = {'test_key_two': 'test_value_two'}

    # First merge, new host
    fact_cache.first_order_merge(key, value_1)
    assert fact_cache[key] == value_1

    # Second merge, existing host
    fact_cache.first_order_merge(key, value_2)
    assert fact_cache[key] == {'test_key_one': 'test_value_one', 'test_key_two': 'test_value_two'}

    # Third merge, existing host, but no new facts
    fact

# Generated at 2022-06-23 15:02:16.290449
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fc = FactCache()
    assert len(fc) == 0
    fc.update({'tmsh_ver': {'running': '15.0.0'}})
    assert len(fc) == 1
    fc.flush()
    assert len(fc) == 0



# Generated at 2022-06-23 15:02:17.405615
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    assert True


# Generated at 2022-06-23 15:02:18.501516
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    pass


# Generated at 2022-06-23 15:02:22.712643
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    first_fact = {'test1': 'a'}
    second_fact = {'test1': 'b'}
    fc.first_order_merge('test1', first_fact)
    fc.first_order_merge('test1', second_fact)
    assert fc['test1'] == second_fact

# Generated at 2022-06-23 15:02:34.584154
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    ''' Test the proper functionality of the first_order_merge method '''

    # Test that first_order_merge does not overwrite an existing fact cache
    fc1 = FactCache()
    fc1_test = {'test_cache': {'test': 'python'}}
    fc1.update(fc1_test)
    assert fc1_test == fc1.copy()

    fc1_test2 = {'test_cache': {'test2': 'python2'}}
    fc1.first_order_merge('test_cache', fc1_test2['test_cache'])
    fc1_test['test_cache'].update(fc1_test2['test_cache'])
    assert fc1_test == fc1.copy()

    # Test that first_order_

# Generated at 2022-06-23 15:02:37.605082
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    cache_loader.clear()
    display.verbosity = 4
    C.CACHE_PLUGIN = 'jsonfile'
    FC = FactCache()
    len(FC)
    return FC


# Generated at 2022-06-23 15:02:44.664359
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    factcache = FactCache()
    assert factcache.__getitem__('a') is None
    assert factcache.__getitem__('b') is None

    factcache.set('a', 1)
    factcache.set('b', 2)
    assert factcache.__getitem__('a') == 1
    assert factcache.__getitem__('b') == 2

    factcache.set('b', 3)
    assert factcache.__getitem__('b') == 3



# Generated at 2022-06-23 15:02:50.217116
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    # Test for dalete an existing key.
    fact_cache = FactCache()
    fact_cache['key'] = 'value'
    fact_cache.__delitem__('key')
    assert not fact_cache.__contains__('key')

    # Test for delete a non-existing key.
    fact_cache.__delitem__('key')
    assert not fact_cache.__contains__('key')



# Generated at 2022-06-23 15:02:59.541054
# Unit test for method __getitem__ of class FactCache

# Generated at 2022-06-23 15:03:07.304839
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    ''' Check if facts cache flushes the data in plugin '''
    # Create cache object
    fact_cache = FactCache()
    custom_fact = {'custom_key': [{'custom_value': 'custom_value'}]}
    fact_cache._plugin.set('test_key', custom_fact)
    assert fact_cache['test_key'] == custom_fact
    fact_cache.flush()
    assert len(fact_cache) == 0


# Generated at 2022-06-23 15:03:08.304377
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    pass


# Generated at 2022-06-23 15:03:12.765147
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    my_cache = FactCache()
    my_cache["key1"] = "value1"
    my_cache["key2"] = "value2"
    my_cache["key3"] = "value3"
    my_cache["key4"] = "value4"
    my_cache.flush()
    assert len(my_cache) == 0

# Generated at 2022-06-23 15:03:24.270915
# Unit test for constructor of class FactCache
def test_FactCache():
    class TCPlugin():
        def __init__(self):
            self.cache = {'test': 'hello world'}

        def contains(self, key):
            return True if key in self.cache else False

        def get(self, key):
            return self.cache.get(key, {})

        def set(self, key, value):
            self.cache[key] = value

        def delete(self, key):
            del self.cache[key]

        def flush(self):
            self.cache = {}

        def keys(self):
            return self.cache.keys()

    tc_plugin = TCPlugin()
    import ansible.plugins.cache.memory
    ansible.plugins.cache.memory.clear_cache()
    ansible.plugins.cache.memory.FACT_CACHE = tc_plugin
   

# Generated at 2022-06-23 15:03:29.560530
# Unit test for constructor of class FactCache
def test_FactCache():
    hostvars = {
        'host1': {'time': 1.0},
        'host2': {'time': 2.0}
    }
    fact_cache = FactCache(hostvars)

    assert fact_cache.flush() is None
    assert fact_cache.keys() == ['host1', 'host2']
    assert fact_cache.first_order_merge(key='host1', value={'bob': 'bob'}) is None

# Generated at 2022-06-23 15:03:33.553177
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    test_factcache = FactCache()
    test_factcache._plugin = {"k1": "v1", "k2": "v2"}
    assert(len(test_factcache.keys()) == 2)

# Generated at 2022-06-23 15:03:35.356773
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    assert (isinstance(fact_cache.keys(), list))


# Generated at 2022-06-23 15:03:37.998805
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    fact_cache['test'] = 'test'
    fact_cache.flush()
    assert not fact_cache.keys()


# Generated at 2022-06-23 15:03:44.073948
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    facts_cache = FactCache()

    my_facts = {'test_fact': True}

    facts_cache.first_order_merge('test_host', my_facts)

    assert 'test_host' in facts_cache
    assert 'test_fact' in facts_cache['test_host']

    my_facts = {'test_fact': False}

    facts_cache.first_order_merge('test_host', my_facts)

    assert 'test_host' in facts_cache
    assert 'test_fact' in facts_cache['test_host']

    assert facts_cache['test_host']['test_fact'] == False

# Generated at 2022-06-23 15:03:52.782823
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    import pytest
    from ansible.module_utils.common._collections_compat import MutableMapping
    tmp_fact_cache = FactCache()
    fact_cache = FactCache()
    key = "key_value"
    value = "value_value"
    with pytest.raises(AnsibleError):
        tmp_fact_cache.__getitem__(key)
    fact_cache.__setitem__(key,value)
    assert fact_cache.__getitem__(key) == value
    assert key in fact_cache
    del fact_cache[key]
    assert fact_cache == MutableMapping()


# Generated at 2022-06-23 15:03:56.380574
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fact_cache = FactCache()
    fact_cache._plugin.cache = {'some_key': 'some_value'}
    assert 'some_key' in fact_cache
    assert 'some_key' not in fact_cache


# Generated at 2022-06-23 15:03:58.600113
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    cache = FactCache()
    # Test if the iterator returned is iterable
    iter(cache.__iter__())


# Generated at 2022-06-23 15:04:02.033679
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    assert len(fact_cache) == 0
    fact_cache['test1'] = 'test1'
    assert len(fact_cache) == 1
    fact_cache['test2'] = 'test2'
    assert len(fact_cache) == 2


# Generated at 2022-06-23 15:04:04.745023
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    cache = FactCache()
    cache['x'] = 'y'
    assert cache['x'] == 'y'
    cache.flush()
    assert len(cache) == 0

# Generated at 2022-06-23 15:04:06.475348
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert True



# Generated at 2022-06-23 15:04:15.329999
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    facts = FactCache()
    # This function will not add a new entry in a cache,
    # if there is one with that key
    facts["key1"] = "value1"
    facts.first_order_merge("key1", "value2")
    assert facts["key1"] == "value2"

    # As well as if there's key in cache, even if value is None
    facts["key2"] = None
    facts.first_order_merge("key2", "value3")
    assert facts["key2"] == "value3"

    # If there's no key, a new key is added with this value
    facts.first_order_merge("key3", "value3")
    assert facts["key3"] == "value3"

# Generated at 2022-06-23 15:04:24.896329
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    """Unit test for FactCache.first_order_merge."""

    # Create a FactCache object and mock the method "_plugin.get"
    factcache = FactCache()
    factcache._plugin = MockFactCachePlugin()
    factcache._plugin.get = MockFactCachePlugin().get

    # Create a dict with fact data

# Generated at 2022-06-23 15:04:28.904861
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():

    fact_cache = FactCache()
    fact_cache['hostname'] = 'hostname'
    assert fact_cache['hostname'] == 'hostname'



# Generated at 2022-06-23 15:04:31.771084
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    factcache = FactCache()
    factcache['test_key'] = 'test_value'
    assert(factcache.__len__() == 1)


# Generated at 2022-06-23 15:04:41.038098
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    facts = FactCache()
    host_a_facts = {"a_fact": "foo"}
    host_b_facts = {"b_fact": "bar"}

    facts.first_order_merge("host_a", host_a_facts)
    facts.first_order_merge("host_b", host_b_facts)
    facts.first_order_merge("host_a", host_b_facts)

    assert(facts["host_a"]["b_fact"] == "bar")
    assert(facts["host_b"]["b_fact"] == "bar")

    facts.first_order_merge("host_a", {"b_fact": "baz"})
    assert(facts["host_a"]["b_fact"] == "baz")

# Generated at 2022-06-23 15:04:45.798536
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    test_fact_cache = FactCache()
    test_fact_cache['test'] = 'value'
    assert test_fact_cache['test'] == 'value'
    # Test behaviour with keys provided by the plugin
    assert test_fact_cache['global_cache.index_counter'] == 0


# Generated at 2022-06-23 15:04:51.838643
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache = FactCache()
    fact_cache['some_key'] = 'some value'
    fact_cache['some_other_key'] = 'some other value'
    key_to_delete = 'some_key'
    del fact_cache[key_to_delete]
    assert not fact_cache.__contains__(key_to_delete)

# Generated at 2022-06-23 15:04:58.844895
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    key = 'localhost'
    first_value = {
        'a': 'b'
    }
    second_value = {
        'c': 'd'
    }
    expected_value = {
        'a': 'b',
        'c': 'd'
    }
    cache.first_order_merge(key, first_value)
    cache.first_order_merge(key, second_value)
    result = cache[key]
    assert result == expected_value

# Generated at 2022-06-23 15:04:59.557465
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    assert len(FactCache()) == 0

# Generated at 2022-06-23 15:05:01.884216
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    from ansible.utils.display import Display
    display = Display()


# Generated at 2022-06-23 15:05:13.498349
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    import sys
    if sys.version_info >= (3, 0):
        import unittest.mock as mock
    else:
        import mock

    mock_cache_loader = mock.patch('ansible.plugins.loader.cache_loader')
    mock_cache_loader.start()

    mock_get = mock.MagicMock()
    mock_get.keys = mock.MagicMock(return_value=['a', 'b', 'c'])

    mock_plugin = mock.MagicMock()
    mock_plugin.get = mock.MagicMock(return_value=mock_get)

    mock_cache_loader.get.return_value = mock_plugin

    fact_cache = FactCache()
    assert fact_cache.keys() == ['a', 'b', 'c']

# Generated at 2022-06-23 15:05:16.190648
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc is not None
    assert fc._plugin is not None


fact_cache = FactCache()

# Generated at 2022-06-23 15:05:19.785653
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc.first_order_merge('key', 'value')
    assert fc['key'] == 'value'
    fc.first_order_merge('key', 'value2')
    assert fc['key'] == 'value2'


# Generated at 2022-06-23 15:05:25.768730
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    # Testing Method keys of Class FactCache

    fac = FactCache()
    assert isinstance(fac, FactCache)

    assert 'FACTS_HASH' in fac
    assert isinstance(fac['FACTS_HASH'], dict)

    assert 'FACTS_CACHE' in fac
    assert isinstance(fac['FACTS_CACHE'], dict)

    assert 'FACTS_CACHE_TIMEOUT' in fac
    assert isinstance(fac['FACTS_CACHE_TIMEOUT'], int)
    assert fac['FACTS_CACHE_TIMEOUT'] == 86400  #default

# Generated at 2022-06-23 15:05:29.040010
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fact_cache = FactCache()
    fact_cache['cisco'] = {'hello': 'world'}
    assert 'cisco' in fact_cache


# Generated at 2022-06-23 15:05:32.517572
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    plugin = 'memory'
    cache = FactCache()

    # Test for a cache plugin that does not exist
    with pytest.raises(AnsibleError):
        assert cache._plugin == None


# Generated at 2022-06-23 15:05:34.044540
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    try:
        cache = FactCache()
        cache['foo'] = 'bar'
        cache.flush()
        if cache.__len__() != 0:
            raise Exception('Unit test failed')
    except Exception:
        raise Exception('Unit test failed')

# Generated at 2022-06-23 15:05:39.317732
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    from ansible.module_utils.facts.cache.memory import MemoryFactCache
    if not isinstance(C.CACHE_PLUGIN, str):
        C.CACHE_PLUGIN = 'memory'
    memory_cache_plugin = cache_loader.get(C.CACHE_PLUGIN)
    if not memory_cache_plugin:
        raise Exception("unable to load the facts cache plugin")
    fact_cache = FactCache()
    fact_cache._plugin = memory_cache_plugin
    assert fact_cache.keys() == [], "keys always return a list"

# Generated at 2022-06-23 15:05:44.591781
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache_dict = {'fact1': 'value1', 'fact2': 'value2', 'fact3': 'value3'}
    fact_cache = FactCache()
    fact_cache.update(fact_cache_dict)
    assert fact_cache.copy() == fact_cache_dict, 'FactCache.copy() does not return correct values'

# Generated at 2022-06-23 15:05:48.408867
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    FC = FactCache()
    FC['a'] = 1
    FC['b'] = 2
    assert FC['a'] == 1
    assert FC['b'] == 2
    try:
        FC['c']
    except KeyError:
        pass


# Generated at 2022-06-23 15:05:48.914444
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    pass

# Generated at 2022-06-23 15:05:50.753141
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():

    FactCache()



# Generated at 2022-06-23 15:06:01.315048
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fc = {'host1': {'var1': 'val1', 'var2': 'val2'},
          'host2': {'var1': 'val1'},
          'host3': {'var1': 'val1', 'var2': 'val2', 'var3': 'val3'}}
    fc['host4'] = {'var4': 'val4', 'var1': 'val1'}
    fc['host5'] = {'var1': 'val1', 'var3': 'val3', 'var4': 'val4'}

    copied = fc.copy()
    assert copied == fc  # If copied, then it is another object

    copied['host1']['var1'] = 'val5'
    assert copied['host1']['var1'] == 'val5'


# Generated at 2022-06-23 15:06:12.752468
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():

    import random
    class Local_cache_loader:
        def __init__(self):
            self._cache = {}
        def contains(self,key):
            return (key in self._cache)
        def get(self,key):
            return self._cache[key]
        def set(self,key,value):
            self._cache[key] = value
        def delete(self,key):
            del self._cache[key]
        def keys(self):
            return self._cache.keys()
        def flush(self):
            self._cache = {}

    #  Initialize cache
    global cache_loader
    cache_loader._CACHE = {}
    cache_loader.get = lambda x: Local_cache_loader()

    #  Define test object
    m = FactCache()
    
    #  Define test

# Generated at 2022-06-23 15:06:14.032954
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    print("test_FactCache___setitem__")



# Generated at 2022-06-23 15:06:15.559000
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    c = FactCache()
    c['foo'] = 'bar'
    assert 'foo' in c



# Generated at 2022-06-23 15:06:17.387826
# Unit test for constructor of class FactCache
def test_FactCache():
    f = FactCache()


# Generated at 2022-06-23 15:06:21.637284
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    s = FactCache()
    assert not s.__contains__(1)
    s.__setitem__(1, 'a')
    assert s.__contains__(1)
    s.__delitem__(1)
    assert not s.__contains__(1)

# Generated at 2022-06-23 15:06:24.716727
# Unit test for constructor of class FactCache
def test_FactCache():
    display.display("FactCache")
    display.display('')

# Generated at 2022-06-23 15:06:26.948865
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    cache = FactCache()
    cache._plugin.delete = None
    cache.__delitem__('key')


# Generated at 2022-06-23 15:06:28.691134
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    cache = FactCache()
    cache.flush()
    assert cache.keys() == []


# Generated at 2022-06-23 15:06:30.110547
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc is not None


# Generated at 2022-06-23 15:06:33.993881
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        import collections
        collections.MutableMapping.register(FactCache)
    except AttributeError:
        pass # Not required on Py3

    fc = FactCache()
    assert isinstance(fc, CollectionsABC)
    assert isinstance(fc, FactCache)

# Generated at 2022-06-23 15:06:37.129742
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact = FactCache()
    fact.first_order_merge('localhost', {'ansible_facts': {'a': 1}})
    assert fact.copy()  == {'localhost': {'a': 1}}
    assert fact.copy() is not fact

# Generated at 2022-06-23 15:06:40.543356
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    from ansible.cache import FactCache
    class MockCachePlugin:
      def flush(self):
        return None
    mockCache = MockCachePlugin()
    factCache = FactCache(mockCache)
    factCache.flush()

# Generated at 2022-06-23 15:06:45.282682
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fc = FactCache()
    hostname = "localhost"
    key = ("localhost", "__ansible_facts")
    new_facts = { 'ansible_os_family': 'redhat' }
    fc[key] = new_facts
    assert new_facts == fc[key]



# Generated at 2022-06-23 15:06:49.800957
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache = FactCache()
    fact_cache['test_key'] = 'test_value'
    fact_cache.__delitem__('test_key')
    assert 'test_key' not in fact_cache


# Generated at 2022-06-23 15:06:54.636939
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    facts_cache = {'192.168.0.1': {'ansible_os_family': 'RedHat', 'ansible_distribution': 'CentOS'}}
    fact_cache = FactCache(dict(facts_cache))
    assert len(fact_cache) == len(facts_cache)


# Generated at 2022-06-23 15:06:55.834183
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    cache = FactCache()
    cache['host'] = 'value'
    assert len(cache) == 1


# Generated at 2022-06-23 15:07:03.677489
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
 
    key = 'key'
    key_other = 'key_other'
    value = 'value'
    value_other = 'value_other'
    cache_args = {key : value, key_other : value_other}
    
    factcache = FactCache(cache_args)

    assert factcache[key] == value
    assert factcache[key_other] == value_other


# Generated at 2022-06-23 15:07:11.499253
# Unit test for method copy of class FactCache
def test_FactCache_copy():

    # Initialize a new class instance for testing
    fact_cache = FactCache()

    # Set arbitrary key/values
    fact_cache['foo'] = 'bar'
    fact_cache['baz'] = 'quux'

    # Make sure that the expected key/values were set
    assert fact_cache['foo'] == 'bar'
    assert fact_cache['baz'] == 'quux'

    # Test the primitive copy of key/values
    copied_facts = fact_cache.copy()
    assert copied_facts['foo'] == 'bar'
    assert copied_facts['baz'] == 'quux'

# Generated at 2022-06-23 15:07:14.566203
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    d = {'foo': 'bar'}
    c = FactCache(d)
    del c['foo']
    assert 'foo' not in c


# Generated at 2022-06-23 15:07:15.718264
# Unit test for constructor of class FactCache
def test_FactCache():
    # Check if it was created without error
    FactCache()

# Generated at 2022-06-23 15:07:19.377363
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    test_instance = FactCache()
    try:
        test_instance.flush()
        test_instance._plugin.flush()
        assert True
    except Exception:
        assert False


# Generated at 2022-06-23 15:07:21.791583
# Unit test for constructor of class FactCache
def test_FactCache():
    f = FactCache()
    assert f
    assert isinstance(f, FactCache)



# Generated at 2022-06-23 15:07:24.241738
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    """ test_FactCache___delitem__ method of class FactCache """

    # set parameterized inputs
    key = None



# Generated at 2022-06-23 15:07:31.129417
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = FactCache(
        {
            'localhost':
                {
                    'test_fact': 'test_value'
                }
        }
    )

    assert fact_cache == {'localhost': {'test_fact': 'test_value'}}
    fact_cache['localhost'] = {'test_fact2': 'test_value2'}
    assert fact_cache == {'localhost': {'test_fact2': 'test_value2'}}

# Generated at 2022-06-23 15:07:39.945546
# Unit test for constructor of class FactCache
def test_FactCache():

    # Test default construction
    fcache = FactCache()

    # Test without any keys
    assert not any(fcache)

    # Test with some keys
    fcache.update({'a': 1, 'b': 2})
    assert 'a' in fcache
    assert 'b' in fcache
    assert fcache['a'] == 1
    assert fcache['b'] == 2

    # Test with more keys
    fcache.update({'c': 3, 'd': 4})
    assert 'c' in fcache
    assert 'd' in fcache
    assert fcache['c'] == 3
    assert fcache['d'] == 4

    # Test with some old keys
    fcache.update({'a': 5, 'b': 6})
    assert 'a' in fcache
    assert 'b' in fcache

# Generated at 2022-06-23 15:07:44.737284
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    cache_loader.cache_plugins['test'] = {
        'cache_plugin_class': 'Ansible.Test.test_fact_cache'
    }
    cache_loader.cache_plugin_count['test'] = 0
    fc = FactCache()
    assert fc.copy() == {'test':'OK'}


# Generated at 2022-06-23 15:07:45.829321
# Unit test for constructor of class FactCache
def test_FactCache():
    f = FactCache()
    assert f


# Generated at 2022-06-23 15:07:47.120568
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    ''' ansible.executor.fact_cache.FactCache.__setitem__ '''
    pass

# Generated at 2022-06-23 15:07:54.675579
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    # Arrange
    import datetime as dt
    import time
    import random
    from ansible.utils.display import Display
    from ansible.errors import AnsibleError
    from ansible.plugins.loader import cache_loader
    from ansible.module_utils.common._collections_compat import MutableMapping

    # Plugins to be tested
    class mock_redis(object):
        def set(self, key, value):
            return
    class mock_jsonfile(object):
        def set(self, key, value):
            return
    class mock_reserved_keynames(object):
        def set(self, key, value):
            return

    # temporary cache_loader
    mock_cache_loader = {"mock_redis": mock_redis, "mock_jsonfile": mock_jsonfile}

# Generated at 2022-06-23 15:08:04.660844
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    import os
    import shutil
    import sys
    import tempfile

    # Get the configuration file
    cache_config_file = os.path.join(os.path.dirname(__file__),
                                     '../../../../../', 'ansible.cfg')

    # Get a temporary file and temporary directory.

# Generated at 2022-06-23 15:08:12.347466
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    assert fact_cache == {}
    assert fact_cache.copy() == {}

    fact_cache.first_order_merge(key='localhost', value={'foo': 'bar'})
    assert fact_cache == {'localhost': {'foo': 'bar'}}
    assert fact_cache.copy() == {'localhost': {'foo': 'bar'}}

    fact_cache.first_order_merge(key='localhost', value={'bar': 'baz'})
    assert fact_cache == {'localhost': {'foo': 'bar', 'bar': 'baz'}}
    assert fact_cache.copy() == {'localhost': {'foo': 'bar', 'bar': 'baz'}}

# Generated at 2022-06-23 15:08:13.818382
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fc = FactCache()
    fc.flush()
    assert len(fc) == 0


# Generated at 2022-06-23 15:08:16.632185
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    cache = FactCache()
    cache['key1'] = {'a': 'A'}
    cache['key2'] = {'b': 'B'}
    cache['key3'] = {'c': 'C'}

    assert cache.keys() == ['key1', 'key2', 'key3']

    cache.flush()

# Generated at 2022-06-23 15:08:25.361578
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test', {'test': {'key1': 'val1', 'key2': 'val2'}})
    assert fact_cache == {'test': {'test': {'key1': 'val1', 'key2': 'val2'}}}
    fact_cache.first_order_merge('test', {'test': {'key1': 'val1', 'key2': 'val2'}})
    assert fact_cache == {'test': {'test': {'key1': 'val1', 'key2': 'val2'}}}
    fact_cache.first_order_merge('test', {'test': {'key1': 'val1'}})

# Generated at 2022-06-23 15:08:35.588865
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    # Test case 1:

# Generated at 2022-06-23 15:08:39.581915
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fc = FactCache()
    value = 'test'
    fc['test'] = value
    assert(isinstance(fc, FactCache))
    assert(fc['test'] == value)


# Generated at 2022-06-23 15:08:43.932070
# Unit test for method keys of class FactCache
def test_FactCache_keys(): # IGNORE:C01111
    """ test_FactCache_keys
    should return the keys of the fact cache
    """
    cache = FactCache()
    cache['host1'] = []
    cache['host2'] = []
    assert cache.keys() == ['host1', 'host2']

# Generated at 2022-06-23 15:08:50.259207
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    host_name = 'test_host'
    facts = {'fact1': 'value1', 'fact2': 'value2'}

    fc.first_order_merge(host_name, facts)
    assert fc[host_name] == facts
    # After a second call first_order_merge with the same host and facts
    # the facts of the cache have to be the same than before
    fc.first_order_merge(host_name, facts)
    assert fc[host_name] == facts


# Generated at 2022-06-23 15:08:51.880240
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    assert FactCache.__delitem__('key') is None


# Generated at 2022-06-23 15:08:57.069285
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    from ansible.plugins.loader import cache_loader
    fact_cache = FactCache()
    fact_cache._plugin.set('test', 'True')
    assert fact_cache._plugin.contains('test'), 'test not present in fact cache'
    assert len(fact_cache) == 1, 'length of fact cache is not 1'