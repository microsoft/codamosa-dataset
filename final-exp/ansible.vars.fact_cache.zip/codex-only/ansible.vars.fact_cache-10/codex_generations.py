

# Generated at 2022-06-23 14:58:59.284274
# Unit test for constructor of class FactCache
def test_FactCache():

    host = '127.0.0.1'
    data = {}

    fc = FactCache()
    fc[host] = data

    print(fc)

    print(fc[host])

    return fc

# Generated at 2022-06-23 14:59:00.611441
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-23 14:59:04.245344
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    cache = FactCache()
    foo = {
        'one': 'foo',
        'two': 'bar'
    }
    cache._plugin.set('localhost', foo)
    cache._plugin.set('localhost2', foo)
    for key in cache:
        assert key in ['localhost', 'localhost2']

# Generated at 2022-06-23 14:59:14.876837
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    from ansible.plugins.loader import cache_loader
    from ansible import constants as C
    from ansible.errors import AnsibleError
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.utils.display import Display
    import pytest

    display = Display()

    # When the host_cache is empty
    cache_result = {'test2': 3}
    test_key = 'test'
    test_value = {'test':1, 'test2': 2}
    test_FactCache = FactCache()
    test_FactCache.first_order_merge(test_key, test_value)
    assert cache_result == test_FactCache[test_key]

    # When the host_cache is not empty

# Generated at 2022-06-23 14:59:20.207784
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    fact_cache["key"] = "value"
    fact_cache["key1"] = "value1"
    facts = fact_cache.copy()
    assert len(facts) == len(fact_cache)
    for key, value in facts.items():
        assert key in fact_cache
        assert fact_cache[key] == value
    for key in fact_cache:
        assert key in facts

# Generated at 2022-06-23 14:59:25.970070
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    plugin = cache_loader.get('memory')
    plugin.set('192.168.1.1', 'some_fact')

    fact_cache = FactCache()

    assert '192.168.1.1' in fact_cache
    assert '192.168.1.2' not in fact_cache

    plugin.delete('192.168.1.1')



# Generated at 2022-06-23 14:59:29.389858
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fact_cache = FactCache()
    assert 'test' not in fact_cache
    fact_cache['test'] = 'test'
    assert 'test' in fact_cache
    del fact_cache['test']
    assert 'test' not in fact_cache

# Generated at 2022-06-23 14:59:39.282450
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    test_hosts = [{'hostname': 'localhost', 'port': 22}]
    test_conn = {'network_os': 'linux', 'become': False, 'become_method': 'sudo', 'become_user': 'root', 'become_pass': None}
    test_connection = Connection(test_hosts[0], test_conn, play_context=None)

    # Create a test module with sentinel value
    test_module = AnsibleModule(argument_spec=dict(test='test'), supports_check_mode=True)

    # Create a test fact cache
    test_fact_cache = FactCache(test_module)

    # Add a sentinel value for test_hosts[0] to test fact cache
    test_fact_cache['localhost'] = 'sentinel'


# Generated at 2022-06-23 14:59:42.574658
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    facts = FactCache()
    facts['test_fact'] = 'test'
    assert 'test_fact' in facts
    del facts['test_fact']
    assert 'test_fact' not in facts


# Generated at 2022-06-23 14:59:43.483472
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache

# Generated at 2022-06-23 14:59:44.917297
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    from _unittest import skip_test
    skip_test('__len__ not implemented')


# Generated at 2022-06-23 14:59:46.143683
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fc = FactCache()
    assert len(fc) == 0


# Generated at 2022-06-23 14:59:48.208159
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache
    assert cache._plugin

# Generated at 2022-06-23 14:59:58.615488
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    '''
    unit test function:
        FactCache.__delitem__
    '''

    class TestFactCachePlugin(MutableMapping):

        def __init__(self):
            self.dict_ = {}
            self.deleted = {}

        def __getitem__(self, key):
            return self.dict_[key]

        def __setitem__(self, key, value):
            self.dict_[key] = value

        def __delitem__(self, key):
            self.deleted[key] = self.dict_[key]
            del self.dict_[key]

        def __contains__(self, key):
            return key in self.dict_

        def __iter__(self):
            return iter(self.dict_)

        def __len__(self):
            return len

# Generated at 2022-06-23 14:59:59.642596
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    return fact_cache

# Generated at 2022-06-23 15:00:05.072578
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    f = FactCache()
    try:
        key = "a"
        value = "b"
        fact_cache = f._plugin.get(key)
        if fact_cache:
            assert True
        else:
            assert False
    except:
        assert False
    print("test FactCache __contains__ is OK")


# Generated at 2022-06-23 15:00:08.998890
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    test_fact_cache = FactCache()
    self._plugin._fact_cache = {'ansible_facts': {'test1': 'test'}}
    test_fact_cache.flush()
    assert not self._plugin._fact_cache

# Generated at 2022-06-23 15:00:13.355971
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    '''
    this function is used to test __delitem__ function of class FactCache
    '''
    fact_cache = FactCache()
    fact_cache['test'] = 'test'
    del fact_cache['test']


# Generated at 2022-06-23 15:00:13.987338
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    assert True

# Generated at 2022-06-23 15:00:18.913889
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fact_cache = FactCache()
    ansible_os_family = ["Redhat"]
    fact_cache.__setitem__("ansible_os_family", ansible_os_family)
    assert fact_cache.__getitem__("ansible_os_family") == ansible_os_family


# Generated at 2022-06-23 15:00:24.950121
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    old_env = dict(C.__dict__)
    C.CACHE_PLUGIN = 'memory'
    fc = FactCache()
    fc['test_key'] = 'test_value'
    assert len(fc) == 1
    fc.flush()
    assert len(fc) == 0
    C.__dict__ = old_env

# Generated at 2022-06-23 15:00:27.125595
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fact_cache = FactCache()
    key = 'test'
    fact_cache[key] = 1
    assert key in fact_cache


# Generated at 2022-06-23 15:00:30.837878
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    import mock
    cache_plugin = mock.MagicMock()
    fact_cache = FactCache()
    fact_cache._plugin = cache_plugin
    fact_cache['key'] = 'value'
    cache_plugin.set.assert_called_with('key', 'value')


# Generated at 2022-06-23 15:00:33.757138
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    cache_plugin = {}
    cache_plugin["keys"] = lambda: [1, 2, 3]

    fact_cache = FactCache()
    fact_cache._plugin = cache_plugin
    assert fact_cache.keys() == [1, 2, 3]

# Generated at 2022-06-23 15:00:40.996493
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():

    class FooPlugin(object):
        def __init__(self):
            pass
        def contains(self, key):
            return True
        def get(self, key):
            return True
        def set(self, key, value):
            pass
        def delete(self, key):
            pass
        def keys(self):
            return ['a', 'b']
        def flush(self):
            pass

    C.CACHE_PLUGIN = 'FooPlugin'

    assert len(FactCache()) == 2

# Generated at 2022-06-23 15:00:48.126788
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():

    import pytest
    from ansible.plugins.loader import cache_loader as cache_loader
    from ansible import constants as C
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.errors import AnsibleError

    fact_cache = FactCache()

    fact_cache['a'] = 'A'
    fact_cache['b'] = 'B'

    assert len(fact_cache) == 2

    fact_cache['c'] = 'C'
    fact_cache['d'] = 'D'

    assert len(fact_cache) == 4

# Generated at 2022-06-23 15:00:48.795453
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache

# Generated at 2022-06-23 15:00:55.727673
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():

    # Test for no keys
    fact_cache_1 = FactCache()
    iter_1 = iter(fact_cache_1)
    assert not next(iter_1, None)
    with pytest.raises(StopIteration):
        next(iter_1)

    # Test for keys
    fact_cache_1['key1'] = 'value1'
    fact_cache_1['key2'] = 'value2'
    iter_1 = iter(fact_cache_1)
    assert iter_1.next() == 'key1'
    assert iter_1.next() == 'key2'
    with pytest.raises(StopIteration):
        next(iter_1)



# Generated at 2022-06-23 15:00:58.466073
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fc = FactCache()
    fc['foo'] = {'bar': 'baz'}

    assert list(iter(fc)) == ['foo']


# Generated at 2022-06-23 15:00:59.383513
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    pass



# Generated at 2022-06-23 15:01:02.718353
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    key = "hostname"
    value = "hostname"

    cache.first_order_merge(key, value)
    host_cache = cache._plugin.get(key)
    assert host_cache == value

# Generated at 2022-06-23 15:01:04.238265
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    test = FactCache()
    result = test.__getitem__('a')
    assert result is None


# Generated at 2022-06-23 15:01:04.806849
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    pass

# Generated at 2022-06-23 15:01:09.757973
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.plugins.cache.redis import FactCache as redis_FactCache

    test_fact_cache = FactCache()
    assert isinstance(test_fact_cache, redis_FactCache)
    # assert test_fact_cache.__class__.__name__ == "FactCache"

# Generated at 2022-06-23 15:01:14.557888
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    facts = {
        'ansible_ssh_host': '127.0.0.2',
        'ansible_ssh_port': 22,
        'ansible_ssh_user': 'user'
    }
    fact_cache = FactCache()
    fact_cache['hostvars'] = facts

    hosts = [
        'host1',
        'host2',
        'host3'
    ]
    fact_cache['hosts'] = hosts

    assert(sorted(hosts) == sorted(list(fact_cache)))
    assert(sorted(hosts) == sorted(list(fact_cache.keys())))

# Generated at 2022-06-23 15:01:21.478941
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    global display
    display = Display() # global isn't enough apparently
    fc = FactCache()
    myKey = "myKey"
    value1 = {"foo": "bar"}
    value2 = {"bar": "baz"}
    fc.first_order_merge(myKey, value1)
    assert fc.copy() == {myKey: value1}
    fc.first_order_merge(myKey, value2)
    assert fc.copy() == {myKey: {**value1, **value2}}

# Generated at 2022-06-23 15:01:26.378758
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    factCache = FactCache()
    factCache["key1"] = "value1"
    factCache["key2"] = "value2"

    assert "key1" in factCache
    assert "key2" in factCache
    assert len(factCache) == 2
    factCache.flush()
    assert len(factCache) == 0

# Generated at 2022-06-23 15:01:30.170100
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    my_fact_cache = FactCache()
    my_fact_cache['test'] = 1
    assert my_fact_cache.keys() == ['test']



# Generated at 2022-06-23 15:01:36.315533
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    """ Test Del Item in Class FactCache."""
    mock_ansible_version = '2.1.1.0'
    mock_fact_cache = FactCache()
    mock_fact_cache['ansible_version'] = mock_ansible_version
    del mock_fact_cache['ansible_version']
    assert mock_fact_cache['ansible_version'] != mock_ansible_version


# Generated at 2022-06-23 15:01:38.464293
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert isinstance(fc, FactCache)

# Unit tests for copy method of class FactCache

# Generated at 2022-06-23 15:01:45.054719
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    # Stub for test_module.__delitem__
    def test_module___delitem__(key):
        # AssertionError: 'my key' not found in the cache
        assert False, ("'%s' not found in the cache" % (key))

    # Stub for test_module.contains
    def test_module_contains(key):
        return True

    # Stub for test_module.keys
    def test_module_keys():
        return ['my key']

    # Stub for test_module.get
    def test_module_get(key):
        return {'my key': 'my value'}

    # Stub for test_module.set
    def test_module_set(key, value):
        pass

    # Stub for test_module.delete
    def test_module_delete(key):
        pass

# Generated at 2022-06-23 15:01:49.267179
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    mock_plugin = MockPlugin()
    fact_cache = FactCache()
    fact_cache._plugin = mock_plugin
    fact_cache.__delitem__('')
    assert mock_plugin.delete_call_flag


# Generated at 2022-06-23 15:01:51.578899
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    """ test_FactCache___setitem__() """
    fc = FactCache()
    fc.__setitem__('test', None)

# Generated at 2022-06-23 15:01:54.479436
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    cache = FactCache()
    cache.__setitem__("test1", "testvalue")
    assert cache.__getitem__("test1") == "testvalue"


# Generated at 2022-06-23 15:02:02.338649
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():

    import tempfile, shutil, os

    test_var_name = 'test_var'
    test_var_value = {'a': 1}
    test_dir = tempfile.mkdtemp()


# Generated at 2022-06-23 15:02:04.569545
# Unit test for constructor of class FactCache
def test_FactCache():
    plugin_name = "fact_cache.plugins.file"
    fc = FactCache(plugin_name)
    assert isinstance(fc, FactCache)


# Generated at 2022-06-23 15:02:07.014256
# Unit test for constructor of class FactCache
def test_FactCache():
    # TODO: need use mock to replace the plugin
    fact_cache = FactCache()

    try:
        # TODO: need use mock to replace the plugin
        fact_cache.__contains__('key')
    except KeyError:
        pass

# Generated at 2022-06-23 15:02:08.094874
# Unit test for constructor of class FactCache
def test_FactCache():
    pass

# Generated at 2022-06-23 15:02:08.718308
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    pass

# Generated at 2022-06-23 15:02:17.529554
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    from ansible.module_utils.common._collections_compat import MutableMapping
    
    host_name = "localhost"
    host_ipaddress = "127.0.0.1"
    host_fact_dict = {'ipaddress': host_ipaddress}
    cached_facts = {'ansible_facts': host_fact_dict}
    fact_cache = FactCache()
    
    fact_cache[host_name] = host_fact_dict
    assert fact_cache[host_name] == host_fact_dict
    assert fact_cache._plugin.get(host_name) == host_fact_dict
    assert 'ipaddress' in fact_cache[host_name]
    assert 'ipaddress' in fact_cache._plugin.get(host_name)

# Generated at 2022-06-23 15:02:20.832468
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fc = FactCache()
    assert fc.keys() == []

    fc['foo'] = 'bar'
    assert 'foo' in fc.keys()

    fc.clear()
    assert fc.keys() == []


# Generated at 2022-06-23 15:02:27.782562
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    from ansible.plugins.cache import BaseCacheModule
    from ansible.plugins.cache.memcache import CacheModule as MemcacheCacheModule
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    class DummyCacheModule(MemcacheCacheModule):

        def __init__(self):
            super(DummyCacheModule, self).__init__()
            self._cache = {}

        def get(self, key):
            return self._cache[key]

        def set(self, key, value):
            self._cache[key] = value

        def contains(self, key):
            return key in self._cache

        def delete(self, key):
            if key in self._cache:
                del self._cache[key]

        def flush(self):
            self._cache = {}


# Generated at 2022-06-23 15:02:30.088596
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    factcache = FactCache()
    res = factcache.__iter__()
    assert isinstance(res, iter)


# Generated at 2022-06-23 15:02:30.788506
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    pass

# Generated at 2022-06-23 15:02:34.370826
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    key = "localhost"
    value = dict(a=1)
    cache = FactCache()
    cache.set(key, value)

    it = iter(cache)
    assert next(it) == key
    assert next(it, None) == None


# Generated at 2022-06-23 15:02:38.105626
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    factCache = FactCache()

    factCache["foo"] = "bar"
    assert factCache["foo"] == "bar"

    del factCache["foo"]
    try:
        _ = factCache["foo"]
        assert False
    except KeyError:
        assert True

# Generated at 2022-06-23 15:02:40.964228
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fc = FactCache()
    fc['a'] = 1
    fc['b'] = 2
    fc['c'] = 3
    assert set(fc.__iter__()) == {'a', 'b', 'c'}

# Generated at 2022-06-23 15:02:42.232688
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    pass



# Generated at 2022-06-23 15:02:47.318235
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    """
    Test when key is found.
    """
    import ansible.plugins.cache

    cache = FactCache()
    cache._plugin = ansible.plugins.cache.DictCacheModule()

    key, value = 'key', 'value'
    cache[key] = value

    assert cache[key] == value



# Generated at 2022-06-23 15:02:51.832177
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    f = FactCache()
    f["host1"] = { 'f1': 1, 'f2': 2, 'f3': 3 }

    f.first_order_merge("host1", { 'f1': 2, 'f4': 4 })

    assert f["host1"] == { 'f1': 2, 'f2': 2, 'f3': 3, 'f4': 4 }


# Generated at 2022-06-23 15:02:52.627768
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    #TODO: implement this unit test
    pass

# Generated at 2022-06-23 15:02:55.994696
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    cache = FactCache()
    cache['mykey'] = 'myvalue'
    assert cache.copy() == {'mykey': 'myvalue'}



# Generated at 2022-06-23 15:03:00.962713
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    key = "key1"
    value = {"A": "a", "B": "b"}
    fact_cache[key] = value
    assert fact_cache[key] == value
    new_fact_cache = fact_cache.copy()
    assert new_fact_cache == value

# Generated at 2022-06-23 15:03:06.995763
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fc = FactCache()

    fc['key1'] = 'val1'
    fc['key2'] = 'val2'

    assert len(fc) == 2

    fc.flush()

    assert len(fc) == 0

    assert 'key1' not in fc
    assert 'key2' not in fc

# Generated at 2022-06-23 15:03:10.028336
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fact_cache = FactCache()
    assert not fact_cache.__contains__('test')
    fact_cache.__setitem__('test', 'test')
    assert fact_cache.__contains__('test')


# Generated at 2022-06-23 15:03:12.593064
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    cache = FactCache()
    cache['test'] = {'test': 'test'}
    assert cache['test'] == {'test': 'test'}


# Generated at 2022-06-23 15:03:19.013565
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    import plugin_cache
    class CacheMock():
        def get(self, key):
            return key
        def contains(self, key):
            if key == 'test_key':
                return True
            else:
                return False
    fact_cache = FactCache()
    fact_cache._plugin = CacheMock()
    
    assert fact_cache['test_key'] == 'test_key'


# Generated at 2022-06-23 15:03:23.041084
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache = FactCache()
    fact_cache['test_key'] = 12345
    assert 'test_key' in fact_cache
    del fact_cache['test_key']
    assert 'test_key' not in fact_cache

# Generated at 2022-06-23 15:03:25.197066
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    # Create the test object
    fact_cache = FactCache()

    # Check that the method keys returns something
    assert fact_cache.keys()

# Generated at 2022-06-23 15:03:28.208813
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    facts = FactCache()
    try:
        facts['test']
    except KeyError:
        assert True
    else:
        assert False


# Generated at 2022-06-23 15:03:33.192515
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fact_cache = FactCache()
    fact_cache.__setitem__("key", "value")
    assert fact_cache.__getitem__("key") == "value"
    try:
        fact_cache.__getitem__("key1")
    except KeyError:
        pass


# Generated at 2022-06-23 15:03:33.916920
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    pass

# Generated at 2022-06-23 15:03:42.881096
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    key = "key"
    value = { "key1": "value1" }
    fc.first_order_merge(key, value)
    assert fc['key'] == { "key1": "value1" }

    key = "key"
    value = { "key2": "value2" }
    fc.first_order_merge(key, value)
    assert fc['key'] == { "key1": "value1", "key2": "value2" }

    key = "key"
    value = { "key1": "value3" }
    fc.first_order_merge(key, value)
    assert fc['key'] == { "key1": "value3", "key2": "value2" }

    key = "key"


# Generated at 2022-06-23 15:03:46.641433
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    obj = FactCache()
    try:
        obj.__getitem__('key')
    except Exception as e:
        assert True, "__getitem__ method of class FactCache raised exception for parameter key: {}".format(str(e))


# Generated at 2022-06-23 15:03:48.250438
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    cache = FactCache()
    cache.flush()
    assert len(cache) == 0


# Generated at 2022-06-23 15:03:54.786441
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    import json
    from ansible.cache.memory import FactCache, FactCacheItem

    facts = {'foo': 'bar', 'hostname': 'testhost'}
    cache = FactCache()
    cache_item = cache.pop('testhost', None)
    if cache_item is not None:
        cache_item.delete()
    cache_item = FactCacheItem(
        'testhost',
        json.dumps(facts).encode('utf-8'))
    cache_item.save()

    item = cache['testhost']
    assert item == facts


# Generated at 2022-06-23 15:03:55.385772
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    pass

# Generated at 2022-06-23 15:03:58.513279
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fc = FactCache()
    fc['a'] = 1
    fc['b'] = 2
    assert fc.copy() == {'a': 1, 'b': 2}


# Generated at 2022-06-23 15:04:01.650171
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    # Given fact cache
    fact_cache = FactCache()
    # When copy fact_cache
    fact_cache_copy = fact_cache.copy()
    # Then the fact_cache_copy should be equal fact_cache
    assert fact_cache_copy == fact_cache

# Generated at 2022-06-23 15:04:10.018504
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    f = FactCache()
    f.flush()

    test_key = 'test_key'
    test_value = 'test_value'

    f.__setitem__(test_key, test_value)
    f.__getitem__(test_key) # should check that the key exists in the dict

    f.__delitem__(test_key)
    try:
        f.__getitem__(test_key) # should check that the key deos not exist in the dict
    except KeyError as e:
        pass


# Generated at 2022-06-23 15:04:14.747555
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fc = FactCache()
    fc['key1'] = 'value1'
    fc['key2'] = 'value2'
    assert len(fc.keys()) == 2
    assert 'key1' in fc.keys() and 'key2' in fc.keys()


# Generated at 2022-06-23 15:04:15.151224
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    assert True

# Generated at 2022-06-23 15:04:17.161417
# Unit test for constructor of class FactCache
def test_FactCache():
    fixture = FactCache()
    assert fixture


# Generated at 2022-06-23 15:04:23.310697
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache=FactCache()
    host_facts = dict()
    # Test 1 - key not in cache - straight insert
    cache._plugin.set=lambda x,y: host_facts.update({x:y})
    cache.first_order_merge(key="key1",value="value1")
    assert host_facts["key1"] == "value1"
    # Test 2 - key already in cache - no straight insert, instead update
    cache.first_order_merge(key="key1",value="value1")
    assert host_facts["key1"] == "value1"

# Generated at 2022-06-23 15:04:24.752048
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    if not cache:
        raise AssertionError("FactCache object is not created")

# Generated at 2022-06-23 15:04:29.105401
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():

    # initialize
    test = FactCache()
    test._plugin = cache_loader.get('memory')
    test['test'] = 'testvalue'
    assert test['test'] == 'testvalue'
    


# Generated at 2022-06-23 15:04:34.649627
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    plugin = "jsonfile"
    C.CACHE_PLUGIN = cache_loader.get(plugin)
    fact = FactCache()
    fact["ansible_os_family"] = "RedHat"
    fact["ansible_distribution_version"] = "7.4"
    len_result = len(fact)
    expected_result = 2
    assert len_result == expected_result


# Generated at 2022-06-23 15:04:44.965326
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    key = "192.168.1.1"

# Generated at 2022-06-23 15:04:49.234561
# Unit test for method copy of class FactCache
def test_FactCache_copy():
  fact_cache = FactCache()
  fact_cache['a'] = 1
  fact_cache['b'] = 2
  assert fact_cache.copy() == {'a': 1, 'b': 2}


# Generated at 2022-06-23 15:04:53.908686
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    # This test checks that __getitem__ returns a value when the key exists.
    d = {"ansible_python_version": "3.6.6"}
    fc = FactCache()
    fc.set(d)
    assert(fc.get({})) == "3.6.6"


# Generated at 2022-06-23 15:04:54.987077
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    pass


# Generated at 2022-06-23 15:04:55.752487
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    assert True

# Generated at 2022-06-23 15:05:04.004955
# Unit test for constructor of class FactCache
def test_FactCache():
    mycache = FactCache()
    mycache['1.1.1.1'] = 1
    assert mycache['1.1.1.1'] == 1
    mycache['1.1.1.1'] = 2
    assert mycache['1.1.1.1'] == 2
    del mycache['1.1.1.1']
    assert '1.1.1.1' not in mycache
    assert mycache.keys() == []
    mycache['1.1.1.1'] = 2
    assert mycache['1.1.1.1'] == 2
    assert mycache.keys() == ['1.1.1.1']
    len(mycache) == 1
    assert mycache.copy() == {'1.1.1.1': 2}
    mycache.flush()
    assert my

# Generated at 2022-06-23 15:05:09.418683
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    import os
    import tempfile
    import json

    fd, path = tempfile.mkstemp()
    os.close(fd)

    _plugin = cache_loader.get(C.CACHE_PLUGIN)
    _plugin.set_options({'cache_connection': '{0}'.format(path)})
    c = FactCache()
    c['foo'] = {'baz': 'bar'}

    with open(path) as f:
        data = json.load(f)

    assert data['foo']['baz'] == 'bar'

# Generated at 2022-06-23 15:05:11.127866
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fc = FactCache()
    fc['test'] = 'test'
    assert fc['test'] == 'test'


# Generated at 2022-06-23 15:05:21.261223
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    assert 0 == len(FactCache().first_order_merge("x", "y"))
    assert 0 == len(FactCache().first_order_merge("foo", {"bar": "baz"}))
    assert 0 == len(FactCache().first_order_merge("foo", {}))
    assert 0 == len(FactCache().first_order_merge("foo", {"bar": "baz", "qux": "xyzzy"}))
    assert 0 == len(FactCache().first_order_merge("foo", {"bar": "baz", "qux": {}}))
    assert 0 == len(FactCache().first_order_merge("foo", {"bar": "baz", "qux": {"plugh": "xyzzy"}}))

# Generated at 2022-06-23 15:05:26.858413
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    cache_loader.cls = None
    cache_loader._fact_cache = None

    # Key not present in cache
    cache_loader.get = lambda self, key: None
    cache_loader.set = lambda self, key, value: None
    cache_loader.contains = lambda self, key: False
    cache_loader.keys = lambda self: ['foo']
    cache_loader.delete = lambda self, key: None
    cache_loader.flush = lambda self: None

    # Test
    fact_cache = FactCache()
    assert 'foo' not in fact_cache
    fact_cache.flush()

# Generated at 2022-06-23 15:05:31.740309
# Unit test for constructor of class FactCache
def test_FactCache():
    cachedir=r'test.cache'
    c = FactCache(cachedir)
    if c._plugin is None:
        raise AssertionError()
    c = FactCache(cachedir, 'jsonfile')
    if c._plugin is None:
        raise AssertionError()


# Generated at 2022-06-23 15:05:39.793030
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    """
    Test to check if it is returning only the primitive copy of the keys and values from the cache.
    Return: boolean
    """
    # Test to check if it is returning the primitive copy of the keys and values from the cache
    factory = FactCache()
    ansible_facts = {'hostvars': {'host1': {'ansible_architecture': "x86_64"}}}
    factory.update(ansible_facts)
    assert len(factory) == 1
    factory.flush()
    assert len(factory) == 0


# Generated at 2022-06-23 15:05:40.924789
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    cache = FactCache()
    cache.flush()

# Generated at 2022-06-23 15:05:50.124723
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    # Creation of an object of type FactCache
    fact_cache_obj = FactCache()
    # Mock attribute '_plugin' of our FactCache object
    mock_plugin = MockCachePluginClass()
    fact_cache_obj._plugin = mock_plugin
    # Method "__delitem__" should be called on the _plugin object
    expected_call_list = [call.__delitem__('key1')]
    # Performing the test
    fact_cache_obj.__delitem__('key1')
    # Asserting that "__delitem__" method was called on the _plugin object
    assert_equal(expected_call_list, mock_plugin.method_calls)



# Generated at 2022-06-23 15:06:00.878792
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
  # An instance of
  fact_cache = FactCache()
  # Should not raise an exception with
  # len(FactCache()) > 0
  assert(len(fact_cache) > 0)
  # Should not raise an exception with
  # 1 < len(FactCache())
  assert(1 < len(fact_cache))
  # Should not raise an exception with
  # 2 in FactCache()
  assert(2 in fact_cache)
  # Should not raise an exception with
  # '3' in FactCache()
  assert('3' in fact_cache)
  # Should not raise an exception with
  # True in FactCache()
  assert(True in fact_cache)
  # Should not raise an exception with
  # False in FactCache()
  assert(False in fact_cache)
  # Should not raise an exception with
 

# Generated at 2022-06-23 15:06:02.568971
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    assert len(fact_cache) == 0

# Generated at 2022-06-23 15:06:03.690645
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    raise Exception("Unimplemented")


# Generated at 2022-06-23 15:06:05.231775
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    test_cache = FactCache()
    keys = test_cache.keys()
    assert isinstance(keys, list)


# Generated at 2022-06-23 15:06:15.441225
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    import mock
    import os
    os.environ['ANSIBLE_INVENTORY_PLUGINS'] = 'tests/unit/plugins/inventory'
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/unit/plugins/inventory/test_inventory.yml'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-23 15:06:17.100265
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    assert True == True



# Generated at 2022-06-23 15:06:19.148146
# Unit test for constructor of class FactCache
def test_FactCache():

    fact_cache = FactCache()

    assert fact_cache['localhost'] == None


# Generated at 2022-06-23 15:06:24.294753
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.plugins.loader import cache_loader
    c = cache_loader.get('memory')
    c.set('test', 'test')
    assert c.get('test') == 'test'
    return True

test_FactCache___setitem__()



# Generated at 2022-06-23 15:06:34.477715
# Unit test for method copy of class FactCache
def test_FactCache_copy():

    class CacheTest(object):
        def __init__(self, data=None, flush_data=None, contains_data=None, set_data=None, delete_data=None):
            self.data = data if data else {}
            self.flush_data = flush_data if flush_data else {}
            self.contains_data = contains_data if contains_data else []
            self.set_data = set_data if set_data else []
            self.delete_data = delete_data if delete_data else []

            def get(self, key): return self.data[key]
            def set(self, key, value): self.data[key] = value
            def delete(self, key): del self.data[key]
            def flush(self): self.data = self.flush_data
            def keys(self): return

# Generated at 2022-06-23 15:06:40.305326
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    facts = {'host1': {'fact1': 'value1', 'fact2': 'value2'}, 'host2': {'fact1': 'value1', 'fact2': 'value2', 'fact3': 'value3'}}
    fact_cache = FactCache()
    fact_cache.update(facts)
    assert list(fact_cache.__iter__()) == ['host1', 'host2']


# Generated at 2022-06-23 15:06:44.036120
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    temp = FactCache()
    temp._plugin = MockPlugin()
    temp._plugin.keys = []
    expected = {}
    result = temp.__delitem__("foo")
    assert expected == result



# Generated at 2022-06-23 15:06:48.862086
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    cache = FactCache()
    assert cache["192.168.1.1"] is None
    cache["192.168.1.1"] = {"success": True}
    assert cache["192.168.1.1"] == {"success": True}
    assert cache["192.168.1.2"] is None

# Generated at 2022-06-23 15:06:50.844682
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fc = FactCache()
    assert fc.__iter__() != None


# Generated at 2022-06-23 15:06:53.256640
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    fact_cache_copy = fact_cache.copy()
    assert fact_cache == fact_cache_copy

# Generated at 2022-06-23 15:06:55.493125
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    from ansible.utils.display import Display
    from ansible.plugins.loader import cache_loader

    display = Display()
    fact_cache = FactCache()
    fact_cache._plugin = cache_loader.get(C.CACHE_PLUGIN)
    key = 'test'
    fact_cache[key] = 'test'
    fact_cache._plugin.delete = lambda x: display.display('test')
    # test
    fact_cache.__delitem__(key)


# Generated at 2022-06-23 15:06:59.223847
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    """
    Test of method __delitem__ of class FactCache
    """
    # TODO: will complete in future
    assert True


# Generated at 2022-06-23 15:07:04.725380
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fc = FactCache()
    assert fc.keys() == []

    fc['host_a'] = {'host_a': 1}
    fc['host_b'] = {'host_b': 2}
    assert sorted(fc.keys()) == ['host_a', 'host_b']


# Generated at 2022-06-23 15:07:13.569168
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    test_cache = {
        'test_host_0' : {'ansible_facts' : {'first' : 'old', 'second' : 'old'},
                         'ansible_local' : {'first_local' : 'old', 'second_local' : 'old'}
                         },
        'test_host_1' : {'ansible_facts' : {'first' : 'old', 'second' : 'old'},
                         'ansible_local' : {'first_local' : 'old', 'second_local' : 'old'}
                         }
    }

# Generated at 2022-06-23 15:07:17.644562
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    '''
    Unit test for method __setitem__ of class FactCache
    '''
    cache = FactCache()
    cache.__setitem__('test_key', 'test_value')
    assert cache.__getitem__('test_key') == 'test_value'



# Generated at 2022-06-23 15:07:23.087484
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    f = FactCache()
    facts = {'a': 1, 'b': 2, 'c': 3}
    f.update(facts)
    assert f['b'] == 2
    del f['b']
    try:
        f['b']
        assert False
    except KeyError:
        assert True


# Generated at 2022-06-23 15:07:24.497912
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fc = FactCache()
    assert len(fc) == 0


# Generated at 2022-06-23 15:07:27.231989
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    assert not fact_cache
    fact_cache['key'] = {'key1': 'value1'}
    assert fact_cache.copy() == {'key': {'key1': 'value1'}}
    del fact_cache['key']
    assert not fact_cache

# Generated at 2022-06-23 15:07:32.267426
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache['1.1.1.1'] = {'a': 1}
    fact_cache.first_order_merge('1.1.1.1', {'b': 2})

    assert fact_cache['1.1.1.1'] == {'a': 1, 'b': 2}

# Generated at 2022-06-23 15:07:36.164892
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    test_fact_cache = FactCache()
    test_fact_cache['host1'] = {'x': 1}
    test_fact_cache.first_order_merge('host1', {'y': 2})

    assert test_fact_cache.get('host1') == {'x': 1, 'y': 2}

# Generated at 2022-06-23 15:07:45.891011
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    # 1. If cache is empty, len() should return 0
    c = FactCache()
    assert c.__len__() == 0

    # 2. If cache contains few keys, len() should return correct length
    c['key1'] = 'value1'
    c['key2'] = 'value2'
    c['key3'] = 'value3'
    c['key4'] = 'value4'
    assert c.__len__() == 4

    # 3. If cache contains 1 key, len() should return 1
    c = FactCache()
    c['key1'] = 'value1'
    assert c.__len__() == 1


# Generated at 2022-06-23 15:07:53.865309
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import os
    import tempfile
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_bytes

    fd, path = tempfile.mkstemp()
    os.close(fd)

    fact_cache = FactCache(plugin='jsonfile', fact_cache=path)
    fact_cache.clear()

    key = 'test'
    orig = {'a': 1, 'b': 2}
    replacement = {'c': 3, 'd': 4}

    fact_cache.first_order_merge(key, orig)

    if not isinstance(fact_cache[key], Mapping):
        raise ValueError("value for key {0} is not a mapping".format(key))

    if fact_cache[key] != orig:
        raise

# Generated at 2022-06-23 15:07:58.868680
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    c = cache_loader.get(C.CACHE_PLUGIN)
    c._flush()
    caches_dir = c.get_cache_files_dir()
    assert len(os.listdir(caches_dir)) == 0

# Generated at 2022-06-23 15:08:00.644481
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fact_cache = FactCache()
    assert isinstance(fact_cache.__iter__(), type(iter(list())))

# Generated at 2022-06-23 15:08:03.220729
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    key = 'test_key'
    value = 'test_value'
    test_object = FactCache()
    test_object[key] = value
    assert len(test_object) == 1

# Generated at 2022-06-23 15:08:04.425812
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    assert len(FactCache()) == 0


# Generated at 2022-06-23 15:08:07.891243
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    cache = FactCache()
    cache["test"] = {"test": "test"}
    assert cache.__len__() == 1
    cache["test2"] = {"test": "test"}
    assert cache.__len__() == 2


# Generated at 2022-06-23 15:08:11.541366
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fact_cache = FactCache()
    fact_cache['key']='value'
    assert fact_cache.__contains__('key') == True
    assert fact_cache.__contains__('key1') == False

# Generated at 2022-06-23 15:08:14.311555
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():

    cache = FactCache()
    cache['test_key'] = 'test_value'

    assert 'test_key' in cache


# Generated at 2022-06-23 15:08:19.308629
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    # Testing argument 'key' with a string value.
    fact_cache = FactCache()
    fact_cache.first_order_merge('testkey1', 'testvalue1')
    assert fact_cache.get('testkey1') == 'testvalue1'

    # Testing argument 'key' with an int value.
    fact_cache = FactCache()
    fact_cache.first_order_merge(123, 'testvalue1')
    assert fact_cache.get(123) == 'testvalue1'

    # Testing argument 'key' with a list value.
    fact_cache = FactCache()
    fact_cache.first_order_merge([1, 2, 3], 'testvalue1')
    assert fact_cache.get([1, 2, 3]) == 'testvalue1'

    # Testing argument 'key' with a tuple

# Generated at 2022-06-23 15:08:24.671857
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    # Create ansible.v2.cache.FactCache.FactCache object
    fc = FactCache()
    # Check if fc contains key
    if "ansible_all_ipv4_addresses" in fc:
        # Delete item ansible_all_ipv4_addresses
        del fc["ansible_all_ipv4_addresses"]


# Generated at 2022-06-23 15:08:32.219105
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    # Test invalid key
    invalid_key = 'invalid_key'
    with pytest.raises(KeyError):
        FactCache().__getitem__(invalid_key)

    # Test valid key
    valid_key = 'valid_key'
    cache_loader.get(C.CACHE_PLUGIN).fact_cache[valid_key] = 'valid_key'
    assert cache_loader.get(C.CACHE_PLUGIN).fact_cache[valid_key] == 'valid_key'


# Generated at 2022-06-23 15:08:33.768105
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fc = FactCache()
    return fc.copy()

# Generated at 2022-06-23 15:08:41.342587
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    key = '127.0.0.1'
    fc.first_order_merge(key, {'a': 1, 'b': 2})
    assert fc[key] == {'a': 1, 'b': 2}
    fc.first_order_merge(key, {'a': 2, 'c': 3})
    assert fc[key] == {'a': 2, 'b': 2, 'c': 3}

# Generated at 2022-06-23 15:08:45.523827
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    class FakeCache:
        def keys(self):
            return [1, 2, 3]

    facts_cache = FactCache()
    facts_cache._plugin = FakeCache()
    assert facts_cache.keys() == [1, 2, 3]



# Generated at 2022-06-23 15:08:46.132622
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    assert True


# Generated at 2022-06-23 15:08:50.603973
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    
    from ansible.utils import context_objects as co

    def fake_get(self, key):
        return key

    def fake_set(self, key, value):
        return key, value

    def fake_delete(self, key):
        return key

    def fake_contains(self, key):
        return key

    def fake_flush(self):
        return "flush"

    def fake_keys(self):
        return "keys"

    cache = FactCache()
    cache.display = display


# Generated at 2022-06-23 15:08:55.377074
# Unit test for constructor of class FactCache
def test_FactCache():
    # construct empty
    fc_1 = FactCache()
    assert len(fc_1) == 0

    # construct with key and value
    fc_2 = FactCache(**{"key": "value"})
    assert len(fc_2) == 1
    assert fc_2["key"] == "value"

# Generated at 2022-06-23 15:08:58.329906
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    fact_cache['key1'] = 'val1'
    fact_cache['key2'] = 'val2'
    assert len(fact_cache) == 2
