

# Generated at 2022-06-23 14:58:59.368458
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    test_factcache = FactCache()
    test_factcache['key'] = 'value'
    assert len(test_factcache) == 1


# Generated at 2022-06-23 14:59:04.528072
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()

    # Test hostname in the cache
    host = 'host1'
    value1 = {'var1': 'value1.1', 'var2': 'value1.2'}
    value2 = {'var1': 'value2.1', 'var2': 'value2.2'}
    value_merged = {'var1': 'value2.1', 'var2': 'value2.2'}
    fact_cache.first_order_merge(host, value1)
    assert fact_cache.get(host) == value1

    # Test hostname not in the cache
    host = 'host2'
    fact_cache.first_order_merge(host, value2)
    assert fact_cache.get(host) == value2

    # Test hostname already in the

# Generated at 2022-06-23 14:59:07.218967
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    factcache = FactCache()
    factcache._plugin._data = {'ansible_system': 'Linux', 'ansible_processor': ['Intel64 Family 6 Model 62 Stepping 4, GenuineIntel']}
    factcache._plugin._keys = {'ansible_system', 'ansible_processor'}
    length = len(factcache)
    assert length == 2

# Generated at 2022-06-23 14:59:13.472660
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    from pprint import pprint
    from pytest import raises
    fact_cache = FactCache()
    with raises(KeyError):
        fact_cache.__getitem__('foo')
    fact_cache.update({'foo': 'bar'})
    assert fact_cache.__getitem__('foo') == 'bar'
    del fact_cache['foo']
    with raises(KeyError):
        fact_cache.__getitem__('foo')


# Generated at 2022-06-23 14:59:16.129102
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache._plugin == cache_loader.get(C.CACHE_PLUGIN)

# Generated at 2022-06-23 14:59:17.480063
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    assert fact_cache.keys() == []

# Generated at 2022-06-23 14:59:24.163972
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    t_key = '10.0.0.1'
    t_value = {'ansible_os_family': 'RedHat'}
    t_plugin = MockCache()
    t_plugin.set(t_key, {'ansible_distribution': 'CentOS'})

    t_fact_cache = FactCache()
    t_fact_cache._plugin = t_plugin

    t_fact_cache.first_order_merge(t_key, t_value)
    assert t_fact_cache[t_key] == {'ansible_distribution': 'CentOS', 'ansible_os_family': 'RedHat'}



# Generated at 2022-06-23 14:59:28.227469
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fc = FactCache()
    assert len(fc) == 0
    fc['foo'] = 5
    assert len(fc) == 1
    fc['bar'] = 42
    assert len(fc) == 2
    del fc['bar']
    assert len(fc) == 1
    fc.flush()
    assert len(fc) == 0


# Generated at 2022-06-23 14:59:30.326390
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    cache = FactCache()
    cache.__setitem__("test",1)
    assert cache.__getitem__("test") == 1


# Generated at 2022-06-23 14:59:33.140577
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    cache = FactCache()
    cache['localhost'] = 'localhost'
    copy = cache.copy()
    assert copy == { 'localhost' : 'localhost' }


# Generated at 2022-06-23 14:59:34.213313
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():

    fact_cache = FactCache()
    print(fact_cache.__contains__("cisco"))

# Generated at 2022-06-23 14:59:34.901439
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    pass


# Generated at 2022-06-23 14:59:36.669543
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    from ansible.module_utils.facts import module_cache
    assert module_cache.keys() == None


# Generated at 2022-06-23 14:59:43.138335
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    # arrange
    from ansible.plugins.cache.memory import CacheModule as MemoryCache
    test_response = {'test_key': 'test_value'}
    MemoryCache.set(test_response)

    fact_cache = FactCache()
    expected = list(test_response.keys())
    actual = fact_cache.keys()

    # assert
    assert expected == actual


# Generated at 2022-06-23 14:59:47.041689
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    factCache = FactCache()
    factCache['test_key'] = 'test_value'
    assert factCache['test_key'] == 'test_value'


if __name__ == "__main__":
    # Run unit tests for this module
    import pytest
    pytest.main(['-rsx', __file__])

# Generated at 2022-06-23 14:59:51.666841
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    obj = FactCache()
    obj['mock-key'] = 'mock-value'
    assert obj.__contains__('mock-key')
    assert not obj.__contains__('non-mock-key')

# Generated at 2022-06-23 14:59:56.429707
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    # Creating a new instance of fact cache
    fact_cache = FactCache()
    # Adding a key value pair to fact cache
    fact_cache['localhost'] = 'localhost'
    # Checking if the fact cache contains the key
    assert 'localhost' in fact_cache
    # Deleting the key
    del fact_cache['localhost']


# Generated at 2022-06-23 15:00:04.712287
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    import os.path

    fc = FactCache()
    assert 'ansible_architecture' not in fc
    fc['ansible_architecture'] = 'armv8l'
    assert 'ansible_architecture' in fc

    fc.flush()
    assert 'ansible_architecture' not in fc

    os.environ['FACTCACHEFILE'] = './testcontent'
    fc['ansible_architecture'] = 'armv8l'
    assert 'ansible_architecture' in fc

# Generated at 2022-06-23 15:00:06.139291
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    l = len(FactCache())
    assert l == 0


# Generated at 2022-06-23 15:00:12.058038
# Unit test for method keys of class FactCache
def test_FactCache_keys():

    class MockCache(object):
        def __init__(self):
            self._keys = {'a', 'b', 'c'}
        def keys(self):
            return self._keys

    factcache = FactCache()
    factcache._plugin = MockCache()
    self.assertEqual(type(factcache.keys()), set)
    self.assertEqual(factcache.keys(), {'a', 'b', 'c'})


# Generated at 2022-06-23 15:00:17.829816
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    keys = ['key1', 'key2']
    for key in keys:
        for method_name in ['contains', '__contains__']:
            cache = FactCache()
            method = getattr(cache, method_name)
            assert not method(key)

            cache._plugin.set(key, 'value')

            assert method(key)

            cache._plugin.delete(key)

# Generated at 2022-06-23 15:00:22.794910
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    cache=FactCache()
    assert cache.keys == cache._plugin.keys
    assert cache.get == cache._plugin.get
    assert cache.set == cache._plugin.set
    assert cache.delete == cache._plugin.delete
    assert cache.contains == cache._plugin.contains
    assert cache.flush == cache._plugin.flush


# Generated at 2022-06-23 15:00:25.743572
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    '''This unit test for fact cache method __contains__'''
    obj = FactCache()
    assert obj.__contains__('_plugin') == True
    assert obj.__contains__('_another_key') == False


# Generated at 2022-06-23 15:00:34.281640
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    host = 'localhost'
    fact_cache = FactCache()
    fact_cache.first_order_merge(host, {'test_fact': 'test_value', 'test_fact_2': 'test_value_2'})
    assert fact_cache[host] == {'test_fact': 'test_value', 'test_fact_2': 'test_value_2'}

    fact_cache.first_order_merge(host, {'test_fact': 'updated_test_value', 'test_fact_3': 'test_value_3'})
    assert fact_cache[host] == {'test_fact': 'updated_test_value', 'test_fact_2': 'test_value_2', 'test_fact_3': 'test_value_3'}



# Generated at 2022-06-23 15:00:36.087286
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    cache = FactCache()
    assert cache.keys() == None

# Generated at 2022-06-23 15:00:41.666231
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    key = 'test_key'
    value = {'a':1}
    fact_cache.first_order_merge(key, value)
    assert fact_cache[key] == value
    value_new = {'b':2}
    fact_cache.first_order_merge(key, value_new)
    assert fact_cache[key] == value_new
    fact_cache.flush()

# Generated at 2022-06-23 15:00:46.604483
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.plugins.cache.memory import CacheModule as memoryCache
    from ansible.plugins.loader import cache_loader

    cache_loader.add('memory_test', memoryCache())

    # Test constructor
    fc = FactCache()

    assert fc._plugin == cache_loader.get('memory_test'), 'Plugin should be memory_test'


# Generated at 2022-06-23 15:00:54.290237
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    """
    This test makes sure the __iter__ method of the FactCache class
    works correctly.
    """

    factcache = FactCache()
    factcache['host_one'] = {'test_value':'foo'}
    factcache['host_two'] = {'test_value':'bar'}

    host_dict = {'host_two': {'test_value': 'bar'}, 'host_one': {'test_value': 'foo'}}
    for host in factcache:
        assert host in host_dict.keys()
        assert factcache[host] == host_dict[host]




# Generated at 2022-06-23 15:00:56.681056
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fc = FactCache()
    fc.flush()
    assert not fc



# Generated at 2022-06-23 15:00:59.372749
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    display.verbosity = 3
    inp_dict = {}
    cls_instance = FactCache()
    cls_instance.__getitem__(inp_dict)


# Generated at 2022-06-23 15:01:03.725991
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    # Call keys method with no parameters
    # Result should be list of keys
    cache = FactCache()
    cache['foo'] = 1
    cache['bar'] = 2
    # Make sure keys are returned in the same order they were set
    cache['baz'] = 3
    assert cache.keys() == ['foo', 'bar', 'baz']

# Generated at 2022-06-23 15:01:04.840263
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    pass



# Generated at 2022-06-23 15:01:13.655770
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    #
    # Testcase 1_1
    #
    # Create and initialize a fact cache plugin
    fact_cache_plugin = cache_loader.get(C.CACHE_PLUGIN)
    fact_cache_plugin.set('FooTcpSslPort', '8443')
    fact_cache_plugin.set('FooTcpPort', '443')
    #
    # Create a new fact cache
    fact_cache = FactCache()
    #
    # Try to retrieve a key from the cache
    try:
        port = fact_cache['FooTcpSslPort']
    except:
        port = None
    #
    # Assert that the given key is found in the cache and its value is as expected
    assert port == '8443', "testcase 1_1 failed"
    #
    #
   

# Generated at 2022-06-23 15:01:17.272317
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    fact_cache.__setitem__("key1", "value1")
    assert "key1" in fact_cache.keys()
    assert len(fact_cache.keys()) == 1


# Generated at 2022-06-23 15:01:18.466065
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    print()


# Generated at 2022-06-23 15:01:20.597537
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    cache = FactCache()
    cache['test'] = 'test'
    assert cache['test'] == 'test'



# Generated at 2022-06-23 15:01:24.377015
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    factcache=FactCache()
    factcache['127.0.0.1']="test"
    factcache.flush()
    if factcache._plugin.contains('127.0.0.1'):
        assert True
    else:
        assert False

# Generated at 2022-06-23 15:01:35.250377
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    test_input = {'cache_key': {'subkey': 'subkey_value'}}
    test_input2 = {'cache_key': {'subkey2': 'subkey_value2'}}
    fact_cache.first_order_merge('cache_key', test_input['cache_key'])
    assert fact_cache == test_input, "There is one item in the cache, did not pass"
    before_update = dict(fact_cache)
    fact_cache.first_order_merge('cache_key', test_input2['cache_key'])
    before_update['cache_key'].update(test_input2['cache_key'])
    assert fact_cache == before_update, "Cache item was updated, did not pass"

# Generated at 2022-06-23 15:01:43.616124
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    from ansible import constants as C
    from ansible.errors import AnsibleError
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.plugins.loader import cache_loader
    from ansible.utils.display import Display

    display = Display()


    class FactCache(MutableMapping):

        def __init__(self, *args, **kwargs):

            self._plugin = cache_loader.get(C.CACHE_PLUGIN)
            if not self._plugin:
                raise AnsibleError('Unable to load the facts cache plugin (%s).' % (C.CACHE_PLUGIN))

            super(FactCache, self).__init__(*args, **kwargs)


# Generated at 2022-06-23 15:01:48.220367
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache = FactCache()
    key = {"foo": "bar"}
    fact_cache[key] = {"foo": "bar"}
    del fact_cache[key]
    assert fact_cache != {"foo": "bar"}
    assert len(fact_cache) == 0

# Generated at 2022-06-23 15:01:50.562178
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    F = FactCache()
    F['x'] = 1
    assert 'x' in F
    assert 'y' not in F


# Generated at 2022-06-23 15:01:52.394823
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    assert 0 == len(fact_cache)


# Generated at 2022-06-23 15:02:01.253551
# Unit test for constructor of class FactCache
def test_FactCache():
    # fail loading fact cache plugin
    constants.CACHE_PLUGIN = 'foo'
    try:
        cache_loader.get(constants.CACHE_PLUGIN)
    except AnsibleError:
        with pytest.raises(AnsibleError) as excinfo:
            cache = FactCache()
        excinfo.match('Unable to load the facts cache plugin (foo).')
    # success loading fact cache plugin
    constants.CACHE_PLUGIN = 'jsonfile'
    cache = FactCache()
    # add some data to the cache
    cache['fake_host'] = 'fake_value'
    # test the data
    assert cache['fake_host'] == 'fake_value'
    # test contains
    assert 'foo' not in cache
    assert 'fake_host' in cache
    # test

# Generated at 2022-06-23 15:02:04.604058
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    factcache = FactCache()
    factcache["hostname"] = "test1"
    factcache["hostname1"] = "test2"
    factcache["hostname2"] = "test3"
    keys = factcache.keys()
    assert "hostname" in keys
    assert "hostname1" in keys
    assert "hostname2" in keys

# Generated at 2022-06-23 15:02:10.368455
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():

    class LazyLoader:
        calls = 0
        def get(self, key):
            if self.calls == 0:
                self.calls += 1
                return 2
            else:
                return 3

        def set(self, key, value):
            pass

        def delete(self, key):
            pass

        def contains(self, key):
            return True

        def keys(self):
            return ['key1', 'key2']

    cache_loader.set_plugin('unittest_LazyLoader', LazyLoader())
    fact_cache = FactCache()
    fact_cache['key1'] = 'value'
    assert len(fact_cache) == 2
    assert 'key1' in fact_cache
    assert 'key2' in fact_cache
    del fact_cache['key1']

# Generated at 2022-06-23 15:02:14.156838
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    ob = FactCache()
    ob['test'] =  'value'
    assert ob['test'] == 'value'
    assert ob.copy() == {'test': 'value'}

# Generated at 2022-06-23 15:02:21.032386
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    _plugin = cache_loader.get(C.CACHE_PLUGIN)
    if not _plugin:
        raise AnsibleError('Unable to load the facts cache plugin (%s).' % (C.CACHE_PLUGIN))

    _plugin.set('key', {'fact': 'fact-value'})
    value_got = _plugin.get('key')
    assert value_got == {'fact': 'fact-value'}
    _plugin.delete('key')


# Generated at 2022-06-23 15:02:22.521420
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    instance = FactCache()
    assert isinstance(iter(instance), (iter, type(self)))


# Generated at 2022-06-23 15:02:25.699789
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    # Test NOPs
    fact_cache = FactCache()

    assert fact_cache.copy() == {}

# Generated at 2022-06-23 15:02:29.988043
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    print('\nIn method "test_FactCache___contains__" of "test_facts_cache.py"')
    c = FactCache()
    c['new_cache'] = 'new_data'
    assert('new_cache' in c)
    del c

# Generated at 2022-06-23 15:02:38.043994
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    from ansible.plugins.cache import FactCache
    from collections import Iterable
    import json

    class FakePlugin(object):
        def __init__(self):
            self._cache = {}

        def contains(self, key):
            return key in self._cache

        def get(self, key):
            return self._cache.get(key)

        def set(self, key, value):
            self._cache[key] = value

        def delete(self, key):
            try:
                del self._cache[key]
            except KeyError:
                pass

        def keys(self):
            return self._cache.keys()

        def flush(self):
            self._cache.clear()

    p = FakePlugin()
    fc = FactCache()
    fc._plugin = p


# Generated at 2022-06-23 15:02:39.367711
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fc = FactCache()
    fc.__delitem__("Test")

# Generated at 2022-06-23 15:02:40.393338
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    pass


# Generated at 2022-06-23 15:02:43.229999
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = FactCache()
    assert fact_cache == {}
    fact_cache['abc'] = 'def'
    assert fact_cache == {'abc': 'def'}


# Generated at 2022-06-23 15:02:52.700581
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.flush()
    fact_cache.first_order_merge('host1', {'test': 1})
    assert fact_cache['host1'] == {'test': 1}
    fact_cache.first_order_merge('host2', {'test': 2})
    assert fact_cache['host2'] == {'test': 2}
    fact_cache.first_order_merge('host1', {'test': 1, 'test2': 1})
    assert fact_cache['host1'] == {'test': 1, 'test2': 1}
    fact_cache.first_order_merge('host1', {'test': 2})
    assert fact_cache['host1'] == {'test': 2, 'test2': 1}
    fact_cache.first_order

# Generated at 2022-06-23 15:03:01.530756
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()

    # check the initial empty cache
    cache.flush()
    assert len(cache) == 0

    # initial value
    value0 = {'values': [1, 2, 3]}
    cache.first_order_merge('first.example.com', value0)
    assert len(cache) == 1
    assert cache['first.example.com'] == value0

    # value with no new values, should be ignored
    value1 = {'values': [1, 2, 3]}
    cache.first_order_merge('first.example.com', value1)
    assert len(cache) == 1
    assert cache['first.example.com'] == value0

    # value with new values, should be merged
    value2 = {'values': [4, 5, 6]}
    cache.first_order_

# Generated at 2022-06-23 15:03:02.198187
# Unit test for constructor of class FactCache
def test_FactCache():
    assert FactCache

# Generated at 2022-06-23 15:03:05.219479
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    import pytest

    facts_cache = FactCache()
    facts_cache['hostname'] = {'key1': 'value1'}
    hostname_facts = facts_cache['hostname']

    assert isinstance(hostname_facts, dict)
    assert hostname_facts == {'key1': 'value1'}

    with pytest.raises(KeyError):
        facts_cache['unset_key']


# Generated at 2022-06-23 15:03:09.374870
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():

    display.verbosity = 3
    display.deprecated('This is a deprecated warning')

    factcache = FactCache()
    factcache.__setitem__('key', 'value')

    assert factcache.__getitem__('key') == 'value'
    print(factcache)



# Generated at 2022-06-23 15:03:11.411238
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
	fact_cache = FactCache()
	print(len(fact_cache))


# Generated at 2022-06-23 15:03:17.192820
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    try:
        fact_cache = FactCache()
    except:
        assert False
    fact_cache['1'] = {'1':1, '2':2}
    fact_cache['2'] = {'3':3, '4':4}
    fact_cache['3'] = {'5':5, '6':6}
    fact_cache_copy = fact_cache.copy()
    assert fact_cache_copy['1'] == fact_cache['1']
    assert fact_cache_copy['2'] == fact_cache['2']
    assert fact_cache_copy['3'] == fact_cache['3']

# Generated at 2022-06-23 15:03:23.180461
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    pl_mock = {
        'flush': lambda: True,
        'get': lambda key: None,
        'set': lambda key, value: True,
        'delete': lambda key: True,
        'contains': lambda key: True,
        'keys': lambda: True
    }

    fcache = FactCache(**pl_mock)
    fcache.flush()



# Generated at 2022-06-23 15:03:28.330221
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    cache_loader_get = cache_loader.get
    def mock_cache_loader_get(plugin_name):
        if plugin_name == 'plugin':
            return {'plugin': ''}
        raise AnsibleError()
    # Inject mock
    cache_loader.get = mock_cache_loader_get

    facts = FactCache()
    assert 'plugin' in facts

    # Restore real cache_loader
    cache_loader.get = cache_loader_get

# Generated at 2022-06-23 15:03:35.451609
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    data = {'development.example.com': {'myfact': 'myvalue'}}
    my_plugin = cache_loader.get(C.CACHE_PLUGIN)
    my_plugin.flush()

    # Test that the __setitem__ method works correctly
    fact_cache = FactCache()
    fact_cache.__setitem__('development.example.com', data['development.example.com'])
    assert fact_cache.copy() == data
    my_plugin.flush()

# Generated at 2022-06-23 15:03:36.948409
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    cache = FactCache()
    assert not cache.__contains__('key1')
    cache['key1'] = 'value1'
    assert cache.__contains__('key1')

# Generated at 2022-06-23 15:03:40.616797
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    from ansible.module_utils.facts.system.system import SystemFacts

    fact_cache = FactCache()
    fact_cache['localhost'] = SystemFacts()

    assert 'localhost' in fact_cache
    assert fact_cache['localhost'].all() == SystemFacts().all()


# Generated at 2022-06-23 15:03:47.415032
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():

    from ansible.plugins.cache.memory import FactCache as MemFactCache
    fact_cache = FactCache()
    fact_cache._plugin = MemFactCache()
    fact_cache._plugin.set('key1', 'value1')

    assert fact_cache.__getitem__('key1') == 'value1'



# Generated at 2022-06-23 15:03:49.614868
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache = FactCache()

    assert fact_cache.__delitem__('this_is_a_test_key') == None



# Generated at 2022-06-23 15:03:50.655143
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    pass


# Generated at 2022-06-23 15:03:58.036504
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fact_cache = FactCache()

    key = ""
    if fact_cache.__contains__(key):
        fact_cache.__setitem__(key, "mocked_value")
        assert fact_cache.__getitem__(key) == "mocked_value"
    else:
        with pytest.raises(KeyError):
            fact_cache.__getitem__(key)



# Generated at 2022-06-23 15:04:05.014568
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    a = {'a':'a'}
    b = {'b':'b'}
    c = {'c':'c'}
    d = {'d':'d'}
    e = {'e':'e'}
    f = {'f':'f'}
    g = {'g':'g'}
    h = {'h':'h'}
    i = {'i':'i'}
    j = {'j':'j'}

    assert sorted(FactCache(a).keys()) == sorted(['a'])
    assert sorted(FactCache(a, b).keys()) == sorted(['a', 'b'])
    assert sorted(FactCache(a, b, c).keys()) == sorted(['a', 'b', 'c'])

# Generated at 2022-06-23 15:04:07.734339
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    assert False, "No test for FactCache.__iter__"


# Generated at 2022-06-23 15:04:13.290954
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fact_cache_obj = FactCache()
    fact_cache_obj._plugin = fact_cache_obj_plugin
    fact_cache_obj_plugin.remove_expired.return_value = True
    fact_cache_obj_plugin.contains.return_value = True
    fact_cache_obj_plugin.get.return_value = 'test'
    res = fact_cache_obj.__getitem__('test')
    assert res == 'test'


# Generated at 2022-06-23 15:04:16.713068
# Unit test for constructor of class FactCache
def test_FactCache():
    a = FactCache()
    assert a._plugin.__class__.__name__ == 'MemoryCacheModule', "Initialisation of class FactCache failed"


# Generated at 2022-06-23 15:04:17.312684
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    pass

# Generated at 2022-06-23 15:04:21.577158
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():

    c = FactCache()

    try:
        c['test']
    except KeyError:
        pass
    else:
        raise AssertionError('Failed to raise KeyError when key "test" not in fact cache.')

    c['test'] = 'test_value'
    assert c['test'] == 'test_value'

# Generated at 2022-06-23 15:04:22.146532
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    pass

# Generated at 2022-06-23 15:04:32.759807
# Unit test for method __delitem__ of class FactCache

# Generated at 2022-06-23 15:04:39.269507
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    assert len(fact_cache) == 0

    fact_cache['192.168.0.1'] = {'ansible': 'is awesome'}
    fact_cache['192.168.0.2'] = {'ansible': 'is awesome'}
    cached_keys = fact_cache.keys()
    assert len(cached_keys) == 2
    assert '192.168.0.1' in cached_keys
    assert '192.168.0.2' in cached_keys



# Generated at 2022-06-23 15:04:45.772587
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('key1', {'k': 'v'})
    assert fact_cache['key1']['k'] == 'v'
    fact_cache.first_order_merge('key2', {'k': 'v'})
    assert fact_cache['key2']['k'] == 'v'
    fact_cache.first_order_merge('key1', {'j': 'j'})
    assert fact_cache['key1']['k'] == 'v'
    assert fact_cache['key1']['j'] == 'j'

# Generated at 2022-06-23 15:04:54.444230
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():

    fact_cache = FactCache()

    # Test set fact
    fact_cache['fact1'] = 'value1'
    assert fact_cache['fact1'] == 'value1'

    # Test modify fact
    fact_cache['fact1'] = 'value2'
    assert fact_cache['fact1'] == 'value2'

    # Test update fact
    fact_cache['fact2'] = 'value2'
    assert fact_cache['fact1'] == 'value2'
    assert fact_cache['fact2'] == 'value2'


# Generated at 2022-06-23 15:04:57.009024
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    cache = FactCache()
    key = 0x10
    cache.update({0x10: {"1": "1"} })
    assert key in cache

# Generated at 2022-06-23 15:05:02.163532
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    cache = FactCache()

    class MockPlugin:
        def __init__(self):
            self.keys_calls = 0
            self.keys_return = []
        def keys(self):
            self.keys_calls += 1
            return self.keys_return

    plugin = MockPlugin()
    cache._plugin = plugin

    assert 0 == cache.__len__()
    assert 1 == plugin.keys_calls

    plugin.keys_return = [1, 2, 3]
    assert 3 == cache.__len__()
    assert 2 == plugin.keys_calls

# Generated at 2022-06-23 15:05:04.235148
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact = FactCache()
    fact['test_key'] = 'test_value'
    fact.__delitem__('test_key')
    assert 'test_key' not in fact.keys()


# Generated at 2022-06-23 15:05:05.833118
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    cache = FactCache()
    keys = cache.keys()
    assert keys == None, "FactCache key should be None"

# Generated at 2022-06-23 15:05:11.866901
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    # 1. Define infos
    args = ()
    kwargs = {}
    # 2. create object
    fc = FactCache(*args, **kwargs)

    ############################################################
    # 3. Check method __contains__ for normal conditions
    ############################################################
    assert not fc.__contains__("_plugin")
    assert not fc.__contains__("_plugin_")


# Generated at 2022-06-23 15:05:18.400989
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    fact_cache["127.0.0.1"] = "fact1"
    assert fact_cache["127.0.0.1"] == "fact1"
    assert fact_cache.keys() == ["127.0.0.1"]
    fact_cache["127.0.0.1"] = "fact2"
    del fact_cache["127.0.0.1"]
    assert not fact_cache.keys()
    fact_cache.first_order_merge("127.0.0.1", "first order")
    assert fact_cache.keys() == ["127.0.0.1"]
    fact_cache.first_order_merge("127.0.0.1", "second order")
    assert fact_cache["127.0.0.1"] == "second order"

# Generated at 2022-06-23 15:05:23.609338
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    # This is the initial cache
    test_fc = FactCache()
    assert test_fc._plugin.contains('_plugin') is False
    # Keys method returns a list of cache keys.
    # Initially there is no cache, so it should be empty.
    assert len(test_fc.keys()) == 0
    test_fc._plugin.set('test_key', 'test_value')
    assert len(test_fc.keys()) == 1
    assert 'test_key' in test_fc.keys()

# Generated at 2022-06-23 15:05:28.932931
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = FactCache()
    fact_cache.__setitem__("test_key", "test_value")
    assert fact_cache._plugin.get("test_key") == "test_value"

# Unit test method __getitem__ of class FactCache

# Generated at 2022-06-23 15:05:34.823895
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    cache._plugin.set("key", "value")

    cache.first_order_merge("key", {"a": 1})
    assert cache._plugin.get("key") == {"a": 1}
    cache.first_order_merge("key", {"b": 2})
    assert cache._plugin.get("key") == {"a": 1, "b": 2}

# Generated at 2022-06-23 15:05:39.607126
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    cache = FactCache()
    assert len(cache) == 0

    cache[1] = "one"
    cache[2] = "two"
    assert len(cache) == 2
    cache.__delitem__(1)
    assert len(cache) == 1
    cache.__delitem__(2)
    assert len(cache) == 0

# Generated at 2022-06-23 15:05:50.164208
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    hostvars = {
        'test_host1': {'ansible_facts': {'a': 'b', 'c': 'd'}},
        'test_host2': {'ansible_facts': {'e': 'f', 'g': 'h'}}
    }

    fact_cache = FactCache()
    fact_cache.flush()  # ensure fact cache is empty

    # ensure hostvars are populated in fact cache
    for host in hostvars:
        fact_cache.first_order_merge(host, hostvars[host]['ansible_facts'])

    # ensure hostvars are in fact cache
    assert 'test_host1' in fact_cache.keys()
    assert 'test_host2' in fact_cache.keys()


# Generated at 2022-06-23 15:05:55.540882
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc.first_order_merge("foo", {"bar": "baz"})
    assert(fc["foo"]["bar"] == "baz")
    fc.first_order_merge("foo", {"bar": "quux"})
    assert(fc["foo"]["bar"] == "quux")

# Generated at 2022-06-23 15:06:01.065120
# Unit test for method copy of class FactCache
def test_FactCache_copy():

    fc1 = FactCache()
    fc1['key'] = 'value'
    fc1['key2'] = 'value2'

    fc2 = fc1.copy()
    assert len(fc2) == 2
    assert 'key' in fc2
    assert 'key2' in fc2
    assert fc2['key'] == 'value'
    assert fc2['key2'] == 'value2'


# Generated at 2022-06-23 15:06:03.741519
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():

    f = FactCache()
    f['a'] = 'b'
    assert f['a'] == 'b'


# Generated at 2022-06-23 15:06:08.087329
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fc = FactCache()
    fc['key1'] = 'a'
    fc['key2'] = 'b'
    fc['key3'] = 'c'
    assert list(fc) == ['key1', 'key2', 'key3']


# Generated at 2022-06-23 15:06:11.080050
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    cache = FactCache()
    cache['host1'] = 'data1'
    cache['host2'] = 'data2'
    assert len(cache) == 2


# Generated at 2022-06-23 15:06:16.149172
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    item = {'test': 'test'}
    plugin = cache_loader.get(C.CACHE_PLUGIN)
    if not plugin:
        raise AnsibleError('Unable to load the facts cache plugin (%s).' % (C.CACHE_PLUGIN))
    plugin.set('test', item)
    factory = FactCache()
    assert factory.__getitem__('test') == item

# Generated at 2022-06-23 15:06:18.122950
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    assert False, "No tests for __contains__"


# Generated at 2022-06-23 15:06:25.300390
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    fact_cache = FactCache()

    host = 'test_host'
    key = 'fact_key'
    value = 'fact_value'

    fact_cache.first_order_merge(host, {key: value})

    assert fact_cache[host][key] == value

    fact_cache[host][key] = value + '_updated'

    fact_cache.first_order_merge(host, {key: value})

    assert fact_cache[host][key] != value
    assert fact_cache[host][key] == value + '_updated'

# Generated at 2022-06-23 15:06:25.886065
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    assert 0 == 0

# Generated at 2022-06-23 15:06:27.586109
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    assert len(fact_cache) == 0


# Generated at 2022-06-23 15:06:33.380731
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    cache_plugin = cache_loader.get('memory')
    cache_plugin.set("key1", "value1")
    cache_plugin.set("key2", "value2")
    cache_plugin.set("key3", "value3")
    cache_plugin.set("key4", "value4")

    fact_cache = FactCache()
    fact_cache.flush()
    assert len(fact_cache) == 0


# Generated at 2022-06-23 15:06:38.528128
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fact_cache = FactCache()
    fact_cache.flush()
    assert "test_fact" not in fact_cache
    fact_cache["test_fact"] = "test_value"
    assert "test_fact" in fact_cache
    fact_cache.flush()
    assert "test_fact" not in fact_cache


# Generated at 2022-06-23 15:06:41.372464
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    fact_cache['1'] = 'value1'
    fact_cache['2'] = 'value2'
    assert fact_cache.keys() == ['1', '2']

# Generated at 2022-06-23 15:06:49.640491
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.loader import cache_loader

    cache = FactCache()

    # Construct a module pretend to be a cache plugin
    cache_plugin = type('FakeCachePlugin', (object,), dict(
        get=lambda self, key: {'test': 'value'}.get(key, None),
    ))

    # Replace a cache plugin with the fake one
    cache_loader.CACHE_PLUGINS[C.CACHE_PLUGIN] = cache_plugin()

    # Test if it works
    assert cache['test'] == 'value'

    # Test error handling
    try:
        cache['not_exist']
        assert False
    except KeyError:
        assert True

# Generated at 2022-06-23 15:06:53.737560
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact = FactCache()
    fact['test_key'] = 'test_value'
    assert 'test_key' in fact
    fact.flush()
    with pytest.raises(KeyError):
        fact['test_key']

# Generated at 2022-06-23 15:06:56.652139
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    fact_cache['a'] = 'a'
    fact_cache['b'] = 'b'
    length = len(fact_cache)
    assert length == 2


# Generated at 2022-06-23 15:07:00.090406
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fc = FactCache()
    fc['a'] = 1
    fc['b'] = 2
    assert fc.copy() == {'a': 1, 'b': 2}

# Generated at 2022-06-23 15:07:01.204608
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    pass


# Generated at 2022-06-23 15:07:08.224507
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    """
     Unit test for method __len__ of class FactCache
    """

    cache_plugin = cache_loader.get("memory")
    cache = FactCache(plugin=cache_plugin)
    cache['host1'] = {"fact1": "val1", "fact2": "val2"}
    cache['host2'] = {"fact1": "val3", "fact2": "val4"}

    assert len(cache) == 2


# Generated at 2022-06-23 15:07:14.701884
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    ''' Unit test for method first_order_merge of class FactCache '''
    fact_cache = FactCache()
    fact_cache.flush()
    fact_cache.first_order_merge('ipv4', {'ipv4': '10.0.0.1'})
    assert fact_cache['ipv4']['ipv4'] == '10.0.0.1'
    fact_cache.first_order_merge('ipv4', {'ipv4': '10.0.0.2'})
    assert fact_cache['ipv4']['ipv4'] == '10.0.0.2'
    fact_cache.flush()

# Generated at 2022-06-23 15:07:23.335973
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    from ansible.plugins.cache import _memory
    from ansible.plugins.loader import become_loader
    from ansible.constants import CACHE_PLUGIN, CACHE_PLUGIN_CONNECTION, BECOME_PASS
    from ansible.errors import AnsibleError

    _memory.CacheModule._cache = {
        'myhost': {
            'my_fact': 'a_value'
        }
    }

    # Test if plugin is loaded
    become_loader.get(CACHE_PLUGIN)

    cache = become_loader.get(CACHE_PLUGIN)

    CACHE_PLUGIN = CACHE_PLUGIN_CONNECTION
    fact_cache = FactCache()
    assert len(fact_cache) == 0


# Generated at 2022-06-23 15:07:26.472458
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    # create an instance of FactCache and call __len__
    my_FactCache = FactCache()
    return my_FactCache.__len__()


# Generated at 2022-06-23 15:07:31.233196
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fact_cache = FactCache(plugin_class='memory')
    fact_cache['key1'] = {'fact1': 'value1'}
    fact_cache['key2'] = {'fact2': 'value2'}
    assert fact_cache.__iter__() == iter(fact_cache._plugin.keys())


# Generated at 2022-06-23 15:07:35.477221
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    cache = FactCache()
    cache['localhost'] = dict(ansible_facts={'some_fact': 'some_value'})

    ref_value = dict(ansible_facts={'some_fact': 'some_value'})

    assert cache['localhost'] == ref_value


# Generated at 2022-06-23 15:07:39.416441
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache(CACHE_PLUGIN=C.CACHE_PLUGIN)
    assert fc._plugin.__class__.__name__ == C.CACHE_PLUGIN

# Generated at 2022-06-23 15:07:43.404894
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fc = FactCache()
    fc["test_item1"] = "test_value1"
    fc["test_item2"] = "test_value2"
    fc.flush()
    keys = list(fc.keys())
    assert len(keys) == 0

# Generated at 2022-06-23 15:07:51.805903
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():

    # Create a new instance of the FactCache class
    fact_cache = FactCache()

    # Create new data to be stored in the Cache
    new_data = {'test_key': 'test_value'}

    # Call the method __setitem__ and store the data in the Cache
    fact_cache.__setitem__(key=new_data.keys()[0], value=new_data[new_data.keys()[0]])

    # ------------------------------------------------------------------------------------------------------------------
    # NOTE:
    #   The method __setitem__ is not tested because it has been implemented by the class MutableMapping and therefore
    #   cannot be tested again on the inherited class FactCache.
    # ------------------------------------------------------------------------------------------------------------------
"""
Unit test for method __getitem__ of class FactCache
"""

# Generated at 2022-06-23 15:07:59.498506
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()

    # input values
    key = "localhost"
    value = {
        'fact': 'value',
        'fact_too': 'value_too',
    }

    # expected output
    expected_host_facts = {
        key: {
            'fact': 'value',
            'fact_too': 'value_too',
        }
    }

    cache.first_order_merge(key, value)

    assert cache == expected_host_facts

# Generated at 2022-06-23 15:08:00.502102
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    print(fc)

# Generated at 2022-06-23 15:08:02.486703
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = FactCache(MutableMapping)
    fact_cache.__setitem__('test_key', 'test_value')


# Generated at 2022-06-23 15:08:06.888396
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    cache_plugin = cache_loader.get('memory')
    fact_cache=FactCache()
    fact_cache._plugin=cache_plugin
    fact_cache['a']=1
    assert fact_cache['a']==1


# Generated at 2022-06-23 15:08:12.099749
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    from ansible.vars.fact_cache import FactCache
    fact_cache = FactCache()
    my_key = 'key'
    my_value = 'value'
    fact_cache[my_key] = my_value
    result = fact_cache[my_key]
    assert(result == my_value)


# Generated at 2022-06-23 15:08:15.213547
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    cache_loader._cache_instances.clear()
    fact_cache = FactCache()
    assert fact_cache.keys() == []

    fact_cache['one'] = 1
    assert fact_cache.keys() == ['one']
    del fact_cache
    cache_loader._cache_instances.clear()

# Generated at 2022-06-23 15:08:23.365957
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    try:
        with open('test/test_file.json', 'w') as f:
            f.write("""{"test":{ "test_str": "Ansible"}}""")

        m = FactCache()
        m._plugin.options = {'fact_caching': 'jsonfile', 'fact_caching_connection': 'test/test_file.json'}
        assert("test" in m)
    except:
        assert(False)
    finally:
        import os
        os.remove('test/test_file.json')


# Generated at 2022-06-23 15:08:25.213067
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    assert len(fact_cache) == 0


# Generated at 2022-06-23 15:08:30.772081
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():

    # Arrange
    test_obj = FactCache()
    test_obj["test1key"] = "test1value"
    test_obj["test2key"] = "test2value"

    # Assert
    assert(test_obj["test1key"] == "test1value")
    assert(test_obj["test2key"] == "test2value")


# Generated at 2022-06-23 15:08:38.072967
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()

    host_value_1 = {'var1':'value1', 'var2':'value2'}
    host_value_2 = {'var1':'value1_updated', 'var3':'value3'}
    host_value_merged = {'var1':'value1_updated', 'var2':'value2', 'var3':'value3'}

    fact_cache.first_order_merge(key='localhost', value=host_value_1)
    host_cache = fact_cache.get('localhost')
    assert host_cache == host_value_1

    fact_cache.first_order_merge(key='localhost', value=host_value_2)
    host_cache = fact_cache.get('localhost')
    assert host_cache == host_value

# Generated at 2022-06-23 15:08:40.082008
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache_obj = FactCache()
    print(fact_cache_obj.copy())  # None

# Generated at 2022-06-23 15:08:49.687851
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    class Fake_get(object):
        def __init__(self):
            self.was_called = False

        def get(self, key):
            self.was_called = True

    class Fake_flush(object):
        def __init__(self):
            self.was_called = False

        def flush(self):
            self.was_called = True

    fake_get_object = Fake_get()
    fake_flush_object = Fake_flush()

    fact_cache_object = FactCache({'test1':'test2'})
    fact_cache_object._plugin = fake_get_object
    fact_cache_object._plugin = fake_flush_object
    fact_cache_object.flush()
    assert fake_flush_object.was_called == True

# Generated at 2022-06-23 15:08:53.932003
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    cache = FactCache()
    cache['key'] = 'value'
    cache['key2'] = 'value2'
    assert cache.copy() == {'key': 'value', 'key2': 'value2'}


# Generated at 2022-06-23 15:08:57.206742
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fc = FactCache()
    fc['some_key'] = 'some_value'
    assert len(fc.keys()) == 1
    fc.flush()
    assert len(fc.keys()) == 0