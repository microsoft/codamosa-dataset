

# Generated at 2022-06-23 14:58:58.725006
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    key1 = "key1"
    cache = FactCache()
    assert key1 not in cache
    cache[key1] = "value1"
    assert key1 in cache


# Generated at 2022-06-23 14:59:07.009004
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import iteritems
    from ansible.plugins.loader import cache_loader

    class TestCachePlugin(object):
        """docstring for TestCachePlugin"""
        def __init__(self):
            self.cache = {}

        def contains(self, key):
            return key in self.cache

        def get(self, key):
            return self.cache[key]

        def set(self, key, value):
            self.cache[key] = value

        def delete(self, key):
            del self.cache[key]

        def flush(self):
            self.cache = {}

        def keys(self):
            return self.cache.keys()


# Generated at 2022-06-23 14:59:08.304929
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    fact_cache.keys()

# Generated at 2022-06-23 14:59:12.791374
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    cache = FactCache()
    cache['test_key'] = 'test_value'
    returned_copy = cache.copy()
    assert returned_copy['test_key'] == 'test_value'
    assert returned_copy == {'test_key': 'test_value'}


# Generated at 2022-06-23 14:59:16.421906
# Unit test for constructor of class FactCache
def test_FactCache():
    # setup fact cache to run unit tests
    fact_cache = FactCache()
    assert fact_cache._plugin.name == 'jsonfile'
    assert 'master.example.com' not in fact_cache


# Generated at 2022-06-23 14:59:17.374111
# Unit test for constructor of class FactCache
def test_FactCache():

    fact_cache = FactCache()

    assert fact_cache

# Generated at 2022-06-23 14:59:22.715026
# Unit test for constructor of class FactCache
def test_FactCache():
    global display
    display = Display()
    factcache = FactCache(display=display)
    print("\nTest FactCache: \n%s\n" % factcache.keys())


if __name__ == '__main__':
    test_FactCache()

# Generated at 2022-06-23 14:59:31.836322
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.network import NetworkFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    from ansible.module_utils.facts.virtual import VirtualFactCollector
    cache = FactCache()

    for fc in [DistributionFactCollector(), NetworkFactCollector(), PlatformFactCollector(), VirtualFactCollector()]:
        for fact_key in fc.collect():
            cache.first_order_merge(fact_key, fc.collect()[fact_key])

    assert 'distribution' in cache

    cache.flush()


# Generated at 2022-06-23 14:59:34.827529
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    cache = FactCache()
    cache['foobar'] = {'a': 'b'}

    assert 'foobar' in cache
    del cache['foobar']
    assert 'foobar' not in cache


# Generated at 2022-06-23 14:59:38.999055
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    # Test setup
    fact_cache = FactCache()
    fact_cache['test_key'] = 'test_value'
    # Testing the copy() method of FactCache
    result = fact_cache.copy()
    assert result == dict(fact_cache)
    # Resetting the class attributes
    fact_cache.flush()



# Generated at 2022-06-23 14:59:42.313821
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fc = FactCache()
    setattr(fc, "_plugin", MockCachePlugin())
    with pytest.raises(KeyError):
        del fc["test_key"]


# Generated at 2022-06-23 14:59:46.919860
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    fact_cache['test_key'] = 'test_value'
    # Calling the copy method on the fact_cache object
    fact_cache_copy = fact_cache.copy()
    # Asserting the fact_cache_copy with the actual data in the fact_cache
    assert fact_cache_copy == {'test_key': 'test_value'}


# Generated at 2022-06-23 14:59:50.723165
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fc = FactCache()
    fc = {'test_key': 'test_value'}
    assert 'test_key' in fc.keys()


# Generated at 2022-06-23 14:59:52.108617
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-23 14:59:53.473738
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    facts = FactCache()
    assert len(facts) == 0



# Generated at 2022-06-23 14:59:54.984566
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache=FactCache()
    fact_cache.flush()

# Generated at 2022-06-23 15:00:03.036153
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.facts.cache import FactCache

    a = FactCache()
    a['b'] = {'a': 1}
    assert a['b'] == {'a': 1}, \
        'FactCache class was not correctly initialized'

    a = FactCache()
    a['b'] = VaultLib("123")

# Generated at 2022-06-23 15:00:06.678184
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.errors import AnsibleError

    # Test when getting plugin failed
    with pytest.raises(AnsibleError, match='Unable to load the facts cache plugin'):
        FactCache(cache_plugin='fake_cache')

# Generated at 2022-06-23 15:00:12.364654
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.cache import fact_cache

    vault_password = 'secret'

    def get_vault_secret(key=None):
        return vault_password

    vault_secrets = {'vault_password': get_vault_secret}

    fact_cache = fact_cache.FactCache(vault_secrets=vault_secrets)
    assert isinstance(fact_cache.vault, VaultLib)

# Generated at 2022-06-23 15:00:23.669581
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    display.verbosity = 3

    # Test for an existing cache
    fc = FactCache()
    fc['hostname'] = {'hostname': 'host1'}
    fc.first_order_merge('hostname', {'hostname': 'host2'})
    assert len(fc) == 1
    assert fc['hostname']['hostname'] == 'host2'

    # Test for a cache that does not exist
    fc['hostname'] = {'hostname': 'host3'}
    fc.first_order_merge('hostname', {'hostname': 'host4'})
    assert len(fc) == 1
    assert fc['hostname']['hostname'] == 'host4'

    # Test for cache that does not exist and a KeyError
    fc.flush()

# Generated at 2022-06-23 15:00:25.447078
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    pass


# Generated at 2022-06-23 15:00:30.068087
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    fact_cache["localhost"] = dict(a='a')
    fact_cache["127.0.0.1"] = dict(b='b')

    display.display(fact_cache.keys())

    assert 'localhost' in fact_cache.keys()
    assert '127.0.0.1' in fact_cache.keys()


# Generated at 2022-06-23 15:00:34.378083
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():

    from collections import namedtuple
    import pytest

    FakeCache = namedtuple('FakeCache', ['contains', 'get'])
    fake_cache = FakeCache(lambda x: True, lambda x: True)
    factcache = FactCache(plugin=fake_cache)

    assert factcache['foo'] is True



# Generated at 2022-06-23 15:00:39.598090
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    # Test for __len__ with empty cache
    fc = FactCache({})
    assert len(fc) == 0

    # Add elements to cache
    fc['test_key'] = 'test_value'
    assert len(fc) == 1

    # Clear (empty cache)
    fc.flush()
    assert len(fc) == 0

# Generated at 2022-06-23 15:00:41.933974
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fc = FactCache()
    fc['a'] = 1
    assert 'a' in fc
    assert 'b' not in fc


# Generated at 2022-06-23 15:00:43.901070
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    cache.first_order_merge("foo", "bar")
    assert cache["foo"] == "bar"

# Generated at 2022-06-23 15:00:46.188853
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fc = FactCache()
    fc.__setitem__('test', 'check')

    assert fc['test'] == 'check'



# Generated at 2022-06-23 15:00:47.769316
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    cache = FactCache()
    import ansible
    cache['foo'] = {'ansible_version': ansible.__version__}
    assert len(cache) == 1


# Generated at 2022-06-23 15:00:49.599562
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    cache = FactCache()
    cache['foo'] = 'bar'
    assert cache['foo'] == 'bar'



# Generated at 2022-06-23 15:00:51.310742
# Unit test for method keys of class FactCache
def test_FactCache_keys():

    factcache = FactCache()
    fact_cache = factcache.keys()
    try:
        assert fact_cache
    except KeyError:
        pass



# Generated at 2022-06-23 15:00:58.661413
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    import json

    # create an empty fact cache
    fCache = FactCache()

    # set a first variable
    fCache['first'] = "value1"
    assert fCache['first'] == "value1"

    # set a second variable
    fCache['second'] = "value2"
    assert fCache['second'] == "value2"

    # set a third variable
    fCache['third'] = "value3"
    assert fCache['third'] == "value3"

    # we should now have three items in our cache
    assert len(fCache) == 3

    # test for the two first variables
    assert fCache['second'] == "value2"
    assert fCache['first'] == "value1"

    # test for the two remaining variables
    assert fCache['third'] == "value3"
    assert fCache

# Generated at 2022-06-23 15:01:01.211442
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    FactCache().flush() 
    FactCache()[("a", "b", "c")] = "abc"
    assert "abc" in FactCache()


# Generated at 2022-06-23 15:01:04.198329
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    fact_cache['foo'] = 'bar'
    assert(fact_cache['foo'] == 'bar')
    fact_cache.flush()
    assert(not fact_cache.keys())


# Generated at 2022-06-23 15:01:10.417283
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    assert len(fact_cache) == 0
    fact_cache['key1'] = 'value1'
    assert len(fact_cache) == 1
    fact_cache['key2'] = 'value2'
    assert len(fact_cache) == 2
    del fact_cache['key2']
    assert len(fact_cache) == 1
    fact_cache.flush()
    assert len(fact_cache) == 0

# Generated at 2022-06-23 15:01:14.132503
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    from ansible.cache.memory import FactMemoryCache
    test_cache = FactCache()
    test_cache._plugin = FactMemoryCache()
    test_cache._plugin.set('test_key', 'test_value')
    len(test_cache) == 1


# Generated at 2022-06-23 15:01:19.610880
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('localhost', {'foo': 'bar'})

    assert fact_cache == {'localhost': {'foo': 'bar'}}

    fact_cache.first_order_merge('localhost', {'foo': 'baz'})

    assert fact_cache == {'localhost': {'foo': 'baz'}}

# Generated at 2022-06-23 15:01:24.524450
# Unit test for constructor of class FactCache
def test_FactCache():
    factcache_1 = FactCache()
    assert factcache_1._plugin is not None

    factcache_2 = FactCache(1,2)
    assert factcache_2._plugin is not None

    factcache_3 = FactCache(a=1,b=2)
    assert factcache_3._plugin is not None



# Generated at 2022-06-23 15:01:35.442432
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    from collections import OrderedDict
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils.common.collections import ImmutableDict
    m_cache = cache_loader.get('jsonfile')
    # test for cache
    cache = FactCache()._plugin
    m_cache.set('a', 'b')
    assert cache.__len__() == 1
    m_cache.set('b', 'c')
    assert cache.__len__() == 2
    # test for empty cache
    m_cache.flush()
    assert cache.__len__() == 0
    # test for another cache
    cache = cache_loader.get('jsonfile').__new__(object)

# Generated at 2022-06-23 15:01:37.876931
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fact = 'ansible_os_family'
    fact_value = {'Debian'}
    cache = FactCache()
    cache[fact] = fact_value
    assert fact in cache


# Generated at 2022-06-23 15:01:40.979849
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    my_fact_cache = FactCache()
    my_fact_cache['a'] = 'b'
    my_fact_cache['b'] = 'c'

    assert sorted(dict(my_fact_cache)) == ['a', 'b']

# Generated at 2022-06-23 15:01:52.866461
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    """
    Test __getitem__ of FactCache

    Precondition:
        cache_loader.get must return a valid cache plugin

    Test cases:
        Cache plugin contains the key

    Expected:
        The value should be returned

    Test cases:
        Cache plugin does not contain the key

    Expected:
        KeyError is raised
    """

    # Precondition
    display.display(u'test_FactCache___getitem__: ENTER')
    class Cache:
        def __init__(self, *args, **kwargs):
            pass

        def contains(self, key):
            return True

        def get(self, key):
            return 'value'

    cache_loader.get = Cache

    # Test cases:
    # Cache plugin contains the key
    c = FactCache()
    assert c['key'] == 'value'

# Generated at 2022-06-23 15:01:56.061729
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    cache = FactCache()
    cache['test'] = {'foo': 'bar'}
    cache.flush()

    cache_keys = cache.keys()
    assert len(cache_keys) == 0



# Generated at 2022-06-23 15:02:00.628554
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    cache = FactCache()

    cache['key1'] = "value1"
    cache['key2'] = "value2"

    # Testing equality of dictionaries created by FactCache.copy()
    assert (cache.copy() == {"key1": "value1", "key2": "value2"})



# Generated at 2022-06-23 15:02:08.430857
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache_obj = FactCache()
    # Dummy value for 'set_cache' because it is not used.
    fact_cache_obj.set_cache = dict()
    # Dummy value for 'cache_key' and 'value'.
    fact_cache_obj.cache_key = "test-key"
    fact_cache_obj.value = "test-value"
    assert fact_cache_obj._plugin.set(fact_cache_obj.cache_key, fact_cache_obj.value) == fact_cache_obj.set_cache.__setitem__(fact_cache_obj.cache_key, fact_cache_obj.value)
    fact_cache_obj.value = "test-value-1"

# Generated at 2022-06-23 15:02:14.629404
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fac = FactCache()
    host_facts = {'ipv4': {'address': '192.168.0.1'}}
    facts = {'ipv4': {'address': '192.168.0.1', 'netmask': '255.255.255.0'}}
    fac.update(host_facts)
    fac.first_order_merge('ipv4', {'netmask': '255.255.255.0'})
    assert fac == facts

# Generated at 2022-06-23 15:02:24.194541
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.plugins.cache.jsonfile import CacheModule as jsonfile
    
    # prepare test data
    cache_filename = '/home//.ansible/tmp/ansible-local/ansible_facts_cache.fact_cache'
    client_identifier = 'localhost'
    key = 'test-key'
    value = 'test-value'
    
    # initialize expected and actual
    expected = 0
    actual = None
    
    # initialize FactCache
    cache_plugin = jsonfile()
    fact_cache = FactCache(plugin=cache_plugin)
    
    # try expected value with exception handling

# Generated at 2022-06-23 15:02:34.414664
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Tests that a key/value is inserted in cache if not existing in cache
    fact_cache = FactCache()
    assert 'key' not in fact_cache
    fact_cache.first_order_merge('key', {'k1': 1, 'k2': 2})
    assert fact_cache['key']['k1'] == 1
    assert fact_cache['key']['k2'] == 2
    # Tests that the value is updated in cache if the key is already in cache
    fact_cache.first_order_merge('key', {'k1': 10})
    assert fact_cache['key']['k1'] == 10
    assert fact_cache['key']['k2'] == 2

# Generated at 2022-06-23 15:02:42.342967
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    cache.first_order_merge("testhost", {"testfact": "testvalue"})
    assert cache.get("testhost") == {"testfact": "testvalue"}
    assert cache.get("testhost") != {"testfact": "testvalue", "testfact2": "testvalue2"}
    assert cache.get("testhost")["testfact"] == "testvalue"
    cache.first_order_merge("testhost", {"testfact2": "testvalue2"})
    assert cache.get("testhost") == {"testfact": "testvalue", "testfact2": "testvalue2"}

# Generated at 2022-06-23 15:02:44.521648
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    facts = FactCache()
    result = facts.copy()
    assert isinstance(result, dict)

# Generated at 2022-06-23 15:02:49.476160
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    fact_cache['test'] = 'test'
    fact_cache['test1'] = 'test1'
    fact_cache['test2'] = 'test2'
    assert fact_cache.copy() == {'test': 'test', 'test1': 'test1', 'test2': 'test2'}


# Generated at 2022-06-23 15:02:59.477697
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():

    class FakeAnsibleError:
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            return

        def __str__(self):
            return str(self.args) + str(self.kwargs)

    class FakeCachePlugin:
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

            return

        def __str__(self):
            return str(self.args) + str(self.kwargs)

        def contains(self, key):
            return key == "contains_true"

        def get(self, key):
            return key

        def set(self, key, value):
            return

        def delete(self, key):
            return



# Generated at 2022-06-23 15:03:02.903583
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    factCache = FactCache()
    factCache['localhost'] = 'localhost'
    assert factCache['localhost'] == 'localhost'
    del factCache['localhost']
    assert factCache['localhost'] == KeyError


# Generated at 2022-06-23 15:03:11.706572
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    # Arbitrary host
    test_host = '192.168.1.1'

    # Create a fact cache instance
    fact_cache = FactCache()

    # Create an arbitrary fact
    arbitrary_fact = {'foo': 'bar'}

    # Set arbitrary fact in fact cache
    fact_cache[test_host] = arbitrary_fact

    # Check fact cache contains arbitrary fact
    assert test_host in fact_cache

    # Delete arbitrary fact from fact cache
    del fact_cache[test_host]

    # Check arbitrary fact was deleted from fact cache
    assert test_host not in fact_cache

    # Check arbitrary fact was deleted from fact cache
    assert len(fact_cache) == 0

# Generated at 2022-06-23 15:03:15.486855
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact = {'a': 1, 'b': 2, 'c': 3}
    factcache = FactCache()
    factcache['a'] = fact
    factcache['b'] = fact
    factcache['c'] = fact
    assert factcache.copy() == {'a': fact, 'b': fact, 'c': fact}


# Generated at 2022-06-23 15:03:23.470716
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    # create a fact_cache object
    fact_cache = FactCache()

    # Assert that key is not present in fact_cache object
    assert 'key' not in fact_cache

    # set value for key
    fact_cache['key'] = 'value'

    # Assert that key is now present in fact_cache object
    assert 'key' in fact_cache

    # Remove key from fact_cache object
    del fact_cache['key']

    # Assert that key is now removed from fact_cache object
    assert 'key' not in fact_cache

# Generated at 2022-06-23 15:03:31.551376
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    from ansible.plugins.cache.jsonfile import CacheModule as jsonfile
    from ansible.plugins.cache.memory import CacheModule as memory

    def getPlugin(plugin):
        plugin_cache = cache_loader.get(plugin)
        if not plugin_cache:
            raise AnsibleError('Unable to load the facts cache plugin (%s).' % (plugin))
        return plugin_cache

    json_plugin = jsonfile()
    mem_plugin = memory()

    json_plugin.set("test_fact", 42)

    json_plugin_init = FactCache(plugin=json_plugin)
    mem_plugin_init = FactCache(plugin=mem_plugin)


# Generated at 2022-06-23 15:03:40.416251
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    import unittest.mock as mock

    mock_plugin = mock.MagicMock()
    mock_plugin.keys.return_value = ['a', 'b', 'c']
    mock_plugin.contains.return_value = True
    mock_plugin.get.return_value = 'value'
    mock_plugin.set.return_value = None
    mock_plugin.delete.return_value = None
    mock_plugin.flush.return_value = None

    fact_cache = FactCache(plugin=mock_plugin)

    iter(fact_cache)

    mock_plugin.keys.assert_called_once_with()

# Generated at 2022-06-23 15:03:42.648764
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    c = FactCache()
    c["key1"] = "value1"
    assert c.__contains__("key1")
    assert not c.__contains__("key2")


# Generated at 2022-06-23 15:03:44.960361
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    factCache = FactCache()
    factCache['test'] = 'test'
    result = factCache['test']
    assert result == 'test'

# Generated at 2022-06-23 15:03:47.979118
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    cache = FactCache()
    cache['test'] = 'test'
    del cache['test']
    assert 'test' not in cache


# Generated at 2022-06-23 15:03:51.290465
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fact_cache = FactCache()
    assert len(list(fact_cache)) == 0

    try:
        next(fact_cache)
        assert False, "Expected exception not raised"
    except StopIteration:
        return True

# Generated at 2022-06-23 15:03:58.121919
# Unit test for method keys of class FactCache
def test_FactCache_keys():

    cache = FactCache()

    assert cache.keys() == []

    cache._plugin.set("foo", [1,2,3])

    assert cache.keys() == ['foo']

    cache._plugin.set("bar", [1,2,3])

    assert sorted(cache.keys()) == ['bar', 'foo']

    cache._plugin.delete("foo")

    assert sorted(cache.keys()) == ['bar']

# Generated at 2022-06-23 15:04:00.982290
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fake_file_cache = {"test_cache_file": {"test_cache_key": "test_cache_val"}}
    _plugin = cache_loader.get("jsonfile")

# Generated at 2022-06-23 15:04:06.473361
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache = FactCache()
    fact_cache['a'] = 1
    assert fact_cache['a']==1
    del fact_cache['a']
    try:
        x = fact_cache['a']
    except KeyError:
        assert fact_cache.keys()==[]
    else:
        assert False



# Generated at 2022-06-23 15:04:08.653054
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fc = FactCache()

    # Test with empty facts cache
    assert fc.keys() == []

    # Set a key-value pair in the facts cache
    fc["192.168.0.1"] = ("ansible_hosts", "localhost")

    # Test non-empty facts cache
    assert fc.keys() == ["192.168.0.1"]

# Generated at 2022-06-23 15:04:13.102261
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache = FactCache()

    test_key = 'test_key'
    test_value = 'test_value'
    fact_cache[test_key] = test_value

    assert test_key in fact_cache

    del fact_cache[test_key]

    assert test_key not in fact_cache


# Generated at 2022-06-23 15:04:15.139359
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    result = fact_cache.copy()
    assert isinstance(result, dict)

# Generated at 2022-06-23 15:04:17.158332
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    fact_cache['a'] = 'b'
    assert fact_cache['a'] == 'b'
    assert fact_cache.copy() == {'a': 'b'}
    fact_cache.flush()

# Generated at 2022-06-23 15:04:25.789766
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    play_context = {
        "network_os": "ios",
        "remote_addr": "10.0.0.1",
        "remote_user": "admin",
        "become_method": "enable",
        "become": True,
        "become_user": "enable_user",
        "become_pass": "enable_pass",
        "connection": "network_cli",
        "become_exe": "conf t",
        "verbosity": 4,
        "check_mode": True
    }

    # init FactCache object
    fact_cache = FactCache()

    # init test values
    test_key = "10.0.0.1"

# Generated at 2022-06-23 15:04:28.704260
# Unit test for constructor of class FactCache
def test_FactCache():
    result = FactCache()
    assert result
    assert result._plugin


# Generated at 2022-06-23 15:04:38.691261
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    # Create an empty cache
    facache = FactCache()

    # Set a cache value (hexadecimal IPv6 address) to an host (an arbitrary UUID)
    facache["e00f709d8b8c4c16b7f2a4ece1689d4e"] = {"ansible_all_ipv6_addresses": "2001:db8:85a3:8d3:1319:8a2e:370:7348"}

    # Check if the host_cache is correctly set
    assert facache["e00f709d8b8c4c16b7f2a4ece1689d4e"]["ansible_all_ipv6_addresses"] == "2001:db8:85a3:8d3:1319:8a2e:370:7348"

# Generated at 2022-06-23 15:04:44.895626
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fc = FactCache()

    # Check that keys() returns an empty list if fact cache is empty
    assert isinstance(fc.keys(), list)
    assert len(fc.keys()) == 0

    # Set some keys
    fc['test1'] = 'dummy'
    fc['test2'] = 'dummy'
    fc['test3'] = 'dummy'

    # Check keys
    keys = fc.keys()
    assert len(keys) == 3
    assert 'test1' in keys
    assert 'test2' in keys
    assert 'test3' in keys

# Generated at 2022-06-23 15:04:46.046881
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    pass



# Generated at 2022-06-23 15:04:49.495530
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    a = FactCache()
    assert a['b'] == ('Failed to get item with key', 'b')


# Generated at 2022-06-23 15:04:50.548917
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fc = FactCache()
    fc.copy()

# Generated at 2022-06-23 15:04:52.099590
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()

    assert(fact_cache._plugin)

# Generated at 2022-06-23 15:04:55.434275
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fc = FactCache()
    fc['foo'] = 'bar'
    assert fc.__contains__('foo') == True
    assert fc.__contains__('bar') == False


# Generated at 2022-06-23 15:05:02.305572
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    print( 'Start unit test FactCache.flush')

    fact_cache = FactCache()
    fact_cache.__setitem__('localhost', 'blah')
    try:
        print('got value for localhost!')
    except KeyError:
        print('key not found')
    fact_cache.flush()
    try:
        print('got value for localhost!')
    except KeyError:
        print('key not found')
    try:
        print( fact_cache.keys())
    except KeyError:
        print('key not found')

    print( 'End unit test FactCache.flush')



# Generated at 2022-06-23 15:05:14.108805
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    key = 'gopi.ansible.com'

# Generated at 2022-06-23 15:05:23.269613
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.cache.memory import FactMemoryCacheModule

    class test_FactMemoryCacheModule(FactMemoryCacheModule):
        def __init__(self, *args, **kwargs):
            self._cache = ImmutableDict()
            super(test_FactMemoryCacheModule, self).__init__(*args, **kwargs)

    cache_loader.add("test_fact_memory_cache_module", test_FactMemoryCacheModule)

    C.ANSIBLE_CACHE_PLUGIN = "test_fact_memory_cache_module"
    C.CACHE_PLUGIN_CONNECTION = "memory"

    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)

# Generated at 2022-06-23 15:05:24.962291
# Unit test for constructor of class FactCache
def test_FactCache():
    ansible_facts = FactCache()
    assert ansible_facts._plugin.name == 'jsonfile'

# Generated at 2022-06-23 15:05:28.931685
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fc = FactCache()
    fc['test_key'] = 'test_value'
    assert fc['test_key'] == 'test_value'


# Generated at 2022-06-23 15:05:35.680949
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    from ansible.executor.process.result import Result
    from ansible.module_utils.facts.system.distribution import Distribution
    facts = Distribution()
    result = Result(host=None, task=None)
    result._host = 'localhost'
    result._result['ansible_facts'] = facts.get_facts()
    cache = FactCache()
    cache[result._host] = result

    assert cache[result._host] == result

# Generated at 2022-06-23 15:05:38.522002
# Unit test for constructor of class FactCache
def test_FactCache():
    f = FactCache()
    assert(type(f) == FactCache)

# Unit test to make sure getitem throws an exception when key is not present in cache

# Generated at 2022-06-23 15:05:49.237332
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():

    _plugin = cache_loader.get(C.CACHE_PLUGIN)

    # creating an object of class FactCache
    c = FactCache()
    # creating an object of class FactCache
    c1 = FactCache()
    # creating an object of class FactCache
    c2 = FactCache()
    # creating an object of class FactCache
    c3 = FactCache()

    if _plugin.contains("ansible_local"):
        temp = _plugin.get("ansible_local")
        data = temp
    else:
        data = {}

    # setting the value for key ansible_local
    c.__setitem__("ansible_local", data)
    # setting the value for key ansible_local
    c1.__setitem__("ansible_local", data)
    # setting the value for key

# Generated at 2022-06-23 15:05:55.257005
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    factCache = FactCache()
    factCache["192.168.0.1"] = { 'test': 'passed' }
    factCache["192.168.0.2"] = { 'test': 'passed' }
    assert factCache.keys() == ['192.168.0.1', '192.168.0.2']


# Generated at 2022-06-23 15:05:58.037037
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    factcache = FactCache()
    factcache["test_key"] = "test_value"

    assert factcache["test_key"] == "test_value"


# Generated at 2022-06-23 15:06:03.936652
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fc_test = FactCache()
    keys_test = fc_test.keys()
    assert "test_key" not in fc_test
    fc_test["test_key"] = "test_value"
    assert "test_key" in fc_test
    fc_test.flush()


# Generated at 2022-06-23 15:06:07.325481
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    cache = FactCache()
    cache['key1'] = 'value1'
    assert cache['key1'] == 'value1'

#Unit test for method __setitem__ of class FactCache

# Generated at 2022-06-23 15:06:11.185887
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()

    display.vvvv("fact_cache is {}".format(fact_cache))
    display.vvvv("len(fact_cache) is {}".format(len(fact_cache)))


# Generated at 2022-06-23 15:06:12.839366
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    from ansible.module_utils.facts.collector import FactCache
    fact_cache = FactCache()


# Generated at 2022-06-23 15:06:14.117894
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    assert len(fact_cache) == 0

# Generated at 2022-06-23 15:06:20.876877
# Unit test for method __iter__ of class FactCache

# Generated at 2022-06-23 15:06:24.428422
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    assert isinstance(fact_cache.__len__(), int)


# Generated at 2022-06-23 15:06:26.341400
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fc = FactCache()
    fc['foo'] = 'bar'



# Generated at 2022-06-23 15:06:28.387983
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    cache = FactCache()
    cache['test_key'] = 'test_value'
    assert 'test_key' in cache


# Generated at 2022-06-23 15:06:29.429379
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    pass



# Generated at 2022-06-23 15:06:30.803516
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    assert len(fact_cache) == 0

# Generated at 2022-06-23 15:06:37.205216
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    # create a host
    host = "localhost"
    # create a FactCache
    fc = FactCache()
    # add a key-value pair to the FactCache
    fc["ansible_os_family"] = "Debian"
    # assert that the host is within the FactCache
    assert host in fc
    # delete the host from the FactCache
    del fc[host]
    # assert that the host is NOT within the FactCache
    assert host not in fc



# Generated at 2022-06-23 15:06:40.543227
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    import sys
    import types
    it = iter(FactCache())
    assert isinstance(it, types.GeneratorType) or sys.version_info[0] < 3
    assert len(list(it)) == 0


# Generated at 2022-06-23 15:06:43.644867
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    test_FactCache = FactCache()
    assert test_FactCache.__contains__('test') == False


# Generated at 2022-06-23 15:06:44.896478
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    assert 'test' in FactCache.__iter__('test')


# Generated at 2022-06-23 15:06:56.738465
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.module_utils import basic
    from io import StringIO
    from ansible.utils.display import Display
    from ansible.errors import AnsibleError

    # Sample output for load plugin
    load_output = basic.basic.AnsibleModule(
        argument_spec={}
    ).jsonify(
        {'plugin_name': 'fact_cache', 'plugin_paths': ['ansible/plugins'], 'plugin_type': 'cache', 'plugins': ['fact_cache'], 'redis': [], 'yaml': [], 'jsonfile': [], 'fact_cache': ['memory']}
    )

    # Sample output for get plugin

# Generated at 2022-06-23 15:07:06.184975
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    cache = {}
    fact_cache = FactCache(cache)

    # Test with existing value
    fact_cache['test_FactCache___delitem__'] = 'test_FactCache___delitem__'
    fact_cache.__delitem__('test_FactCache___delitem__')
    assert 'test_FactCache___delitem__' not in fact_cache

    # Test with non existing value
    try:
        fact_cache.__delitem__('test_FactCache___delitem__')
    except KeyError:
        assert True
    else:
        assert False


# Generated at 2022-06-23 15:07:07.877227
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache_instance = FactCache()
    fact_cache_instance[""] = ""



# Generated at 2022-06-23 15:07:11.723274
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    test_instance = FactCache()
    test_key = 'TestKey'
    test_value = 'TestValue'
    test_instance.__setitem__(test_key, test_value)
    assert test_instance._plugin.get(test_key) == test_value


# Generated at 2022-06-23 15:07:14.610022
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache=FactCache()
    fact_cache['a']=1
    fact_cache['b']=2
    assert len(fact_cache)==2

# Generated at 2022-06-23 15:07:17.263136
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fact_cache = FactCache()
    fact_cache['test_key'] = 'test_value'
    assert fact_cache['test_key'] == 'test_value'


# Generated at 2022-06-23 15:07:19.024071
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    foo = FactCache()


# Generated at 2022-06-23 15:07:24.447119
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    test_key = 'test_key'
    test_value = 'test_value'
    fact_cache[test_key] = test_value
    assert test_key in fact_cache.keys()
    fact_cache.flush()
    assert test_key not in fact_cache.keys()

# Generated at 2022-06-23 15:07:35.394823
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import json
    test_cache = FactCache()
    # test key not in cache
    test_cache.first_order_merge('test_key',{'a':1})
    assert test_cache['test_key'] == {'a': 1}
    # test key in cache
    test_cache.first_order_merge('test_key',{'a':2})
    assert test_cache['test_key'] == {'a': 2}
    # test key in cache and value is dict
    test_cache.first_order_merge('test_key',{'a':3})
    assert test_cache['test_key'] == {'a': 3}
    # test key in cache and value is not dict
    test_cache.first_order_merge('test_key','abcd')
    assert test_cache

# Generated at 2022-06-23 15:07:46.593914
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    """ Unit tests for method __delitem__ in class FactCache. """

    # valid test
    fact_cache = FactCache()
    fact_cache.flush()
    display.display('Call method __delitem__ of class FactCache, key is test.')
    fact_cache.__setitem__('test', 'test1')
    fact_cache.__delitem__('test')
    result = fact_cache.__contains__('test')
    display.display('result: ' + str(result))
    assert result

    # invalid test
    fact_cache = FactCache()
    fact_cache.flush()
    display.display('Call method __delitem__ of class FactCache, key is test1.')
    fact_cache.__delitem__('test1')
    result = fact_cache.__contains__('test1')


# Generated at 2022-06-23 15:07:54.336517
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    import os
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.plugins.loader import cache_loader
    from ansible.errors import AnsibleError

    class CachePlugin(MutableMapping):
        def __init__(self, *args, **kwargs):
            self.file_name = "some_filename"
            self.fact_dict = {}

        def __getitem__(self, key):
            if not self.contains(key):
                raise KeyError
            return self.fact_dict[key]

        def __setitem__(self, key, value):
            self.fact_dict[key] = value

        def __delitem__(self, key):
            try:
                del self.fact_dict[key]
            except KeyError:
                pass

# Generated at 2022-06-23 15:07:56.262360
# Unit test for constructor of class FactCache
def test_FactCache():
    fac_test = FactCache()
    assert(fac_test._plugin is not None)

# Generated at 2022-06-23 15:07:59.497378
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fc = FactCache()
    fc.__setitem__("One", 1)
    assert fc.__getitem__("One") == 1


# Generated at 2022-06-23 15:08:01.592062
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    f = FactCache()
    f['a'] = 'b'
    assert f.copy() == {'a': 'b'}


# Generated at 2022-06-23 15:08:08.824989
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    fact_cache['example.com'] = {'ansible_distribution': 'Ubuntu', 'ansible_facts_cacheable': True}
    assert 'example.com' in fact_cache
    assert fact_cache['example.com'] == {'ansible_distribution': 'Ubuntu', 'ansible_facts_cacheable': True}

    # flush facts cache
    fact_cache.flush()
    assert 'example.com' not in fact_cache


# Generated at 2022-06-23 15:08:12.595258
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fc = FactCache()
    fc['test'] = {}
    assert 'test' in fc
    del fc['test']
    assert 'test' not in fc



# Generated at 2022-06-23 15:08:23.687778
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge(key="test_host", value={'fact_one': 'fact_one'})
    assert fact_cache.keys() == ['test_host']
    assert fact_cache['test_host']['fact_one'] == 'fact_one'

    fact_cache.first_order_merge(key="test_host", value={'fact_two': 'fact_two'})
    assert fact_cache.keys() == ['test_host']
    assert fact_cache['test_host']['fact_one'] == 'fact_one'
    assert fact_cache['test_host']['fact_two'] == 'fact_two'


# Generated at 2022-06-23 15:08:26.470967
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    test = FactCache()
    test['1'] = {}
    test['2'] = {}
    test['3'] = {}
    assert len(test.keys()) == 3
    test.flush()
    assert len(test.keys()) == 0

# Generated at 2022-06-23 15:08:28.764175
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    instance = FactCache()
    assert isinstance(instance, MutableMapping)
    with pytest.raises(AnsibleError):
        instance.__len__()

# Generated at 2022-06-23 15:08:35.077870
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    import mock
    import pytest

    class MockFactCache(FactCache):
        def __init__(self):
            self._plugin = mock.Mock()

    fc = MockFactCache()
    fc._plugin.contains.return_value = True

    assert "key" in fc

    assert fc._plugin.contains.call_count == 1
    assert fc._plugin.contains.call_args_list[0][0][0] == "key"


# Generated at 2022-06-23 15:08:40.082662
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    fact_cache._plugin = FactCachePlugin()
    assert len(fact_cache) == 0

    fact_cache._plugin.set('test_key', 'test_value')
    assert len(fact_cache) == 1


# Generated at 2022-06-23 15:08:47.438412
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    class Cache:
        def set(self, key, val):
            pass
        def get(self, key):
            return "someValue"
        def keys(self):
            return ["someKey"]
        def contains(self, key):
            return True
    cache = Cache()

    try:
        factCache = FactCache()
        factCache._plugin = cache
        factCache.__delitem__("someKey")
        assert("someKey" not in factCache)
    except Exception as e:
        raise e


# Generated at 2022-06-23 15:08:59.254503
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # case 1
    # merge two dicts
    # expected new merged dict
    expected_result_dict = dict(ansible_all_ipv4_addresses=["10.0.0.1", "10.0.0.2", "10.0.0.3"],
                                ansible_default_ipv4=dict(address="10.0.0.1",
                                                          alias="eth0",
                                                          gateway="10.0.0.254",
                                                          interface="eth0",
                                                          macaddress="11:22:33:44:55:66",
                                                          mtu=1500,
                                                          netmask="255.255.255.0",
                                                          network="10.0.0.0"))

    # original dict
    original_dict = dict