

# Generated at 2022-06-23 14:59:00.050344
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fc = FactCache()
    fc['key1'] = 'value1'
    fc['key2'] = 'value2'
    fc['key3'] = 'value3'
    assert set(fc.keys()) == set(['key1', 'key2', 'key3'])

# Generated at 2022-06-23 14:59:00.968913
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    result = FactCache().__iter__()
    assert result is not None



# Generated at 2022-06-23 14:59:05.128078
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()

    fact_cache['a'] = 'apple'
    fact_cache['b'] = 'banana'

    fact_cache_copy = fact_cache.copy()

    assert len(fact_cache_copy) == 2
    assert fact_cache_copy['a'] == 'apple'
    assert fact_cache_copy['b'] == 'banana'

# Generated at 2022-06-23 14:59:09.347509
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    FACTS_CACHE_PLUGIN = C.CACHE_PLUGIN
    C.CACHE_PLUGIN = 'memory'  # force using in-memory plugin

    fc = FactCache()
    assert len(fc) == 0
    fc['a'] = 'a'
    assert len(fc) == 1
    fc._plugin.flush()
    assert len(fc) == 0

    C.CACHE_PLUGIN = FACTS_CACHE_PLUGIN



# Generated at 2022-06-23 14:59:11.250441
# Unit test for constructor of class FactCache
def test_FactCache():

    fact_cache = FactCache()

    assert fact_cache._plugin.__class__.__name__ == 'FactCachePlugin'

# Generated at 2022-06-23 14:59:14.544443
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    import pytest
    from ansible.module_utils.common._collections_compat import MutableMapping
    key = "localhost"
    fact_cache = FactCache()
    with pytest.raises(AnsibleError):
        fact_cache.__contains__(key)

# Generated at 2022-06-23 14:59:17.746360
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fc = FactCache()
    fc["a"] = "1"
    assert len(fc) == 1
    fc.flush()
    assert len(fc) == 0


# Generated at 2022-06-23 14:59:26.505168
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    """
    Method keys: Unit Test
    """

    from ansible.module_utils.facts import AnsibleFactCacheModule
    class TestCache(AnsibleFactCacheModule):
        def keys(self):
            return ["1"]

        def contains(self, key):
            return True

        def flush(self):
            pass

        def get(self, key):
            pass

        def set(self, key, value):
            pass

        def delete(self, key):
            pass
    fc = FactCache()
    fc._plugin = TestCache()
    assert fc.keys() == ["1"]

# Generated at 2022-06-23 14:59:29.528227
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    fact_cache['ansible_facts'] = {'value': 'test value'}
    assert fact_cache.copy()['ansible_facts'] == {'value': 'test value'}

# Generated at 2022-06-23 14:59:39.396019
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    ''' Test to test if retrieving a cache plugin is successful '''
    ''' Test that if the cache plugin contains the key it will return True '''
    ''' Test that if the cache plugin does not contain the key it will return False'''
    plugin = cache_loader.get(C.CACHE_PLUGIN)
    if not plugin:
        ''' Cannot find the cache plugin in the cache_loader '''
        ''' Perform test on a built in cache plugin'''
        import ansible.plugins.cache as cache
        plugin = cache.BaseCacheModule()
    plugin.set('foo', 'bar')
    fc = FactCache()
    assert fc.__contains__('foo') == True
    assert fc.__contains__('does_not_exist_in_cache') == False


# Generated at 2022-06-23 14:59:40.344820
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    pass


# Generated at 2022-06-23 14:59:44.841927
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = FactCache()
    fact_cache['host1'] = {'ansible_os_family': 'RedHat'}
    fact_cache['host2'] = {'ansible_os_family': 'Debian'}
    assert fact_cache['host1'] == {'ansible_os_family': 'RedHat'}


# Generated at 2022-06-23 14:59:45.723183
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    pass


# Generated at 2022-06-23 14:59:54.522283
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    import pytest
    from ansible.module_utils.six.moves.mock import patch
    from ansible.plugins.loader import cache_loader

    with patch.object(cache_loader, 'get', return_value='plugin'):
        with patch('ansible.plugins.cache.FactCache._plugin', new_callable=property) as mock_plugin:
            mock_plugin.keys.return_value = ['foo', 'bar']
            fact_cache = FactCache()
            assert fact_cache._plugin == 'plugin'
            assert sorted(fact_cache) == ['bar', 'foo']



# Generated at 2022-06-23 14:59:58.653333
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    cache = FactCache()
    cache['foo'] = 'bar'
    cache['baz'] = 'baz'
    copy = cache.copy()
    assert copy['foo'] == 'bar'
    assert copy['baz'] == 'baz'
    assert len(copy) == 2


# Generated at 2022-06-23 15:00:05.279794
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    # Create a sample cache
    c = FactCache()
    c['foo'] = {'bar': {'baz': ['bop']}}
    c['foo']['bar']['baz'].append('bop2')

    # Delete it
    c.__delitem__('foo')

    # Check the cache does not exists anymore
    if c.__contains__('foo'):
        raise AssertionError



# Generated at 2022-06-23 15:00:12.029124
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    # Initialize the class
    fact_cache = FactCache()
    key = "testkey"
    value = "testvalue"
    # Insert the value for the key
    fact_cache[key] = value
    # Fetch the value for the key
    assert fact_cache[key] == "testvalue"
    # Fetch the length of the cache
    length = len(fact_cache)
    assert length == 1
    # Delete the key from the cache
    del fact_cache[key]
    assert key not in fact_cache


# Generated at 2022-06-23 15:00:23.260084
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    initial_len = len(fact_cache)

    fact_cache['test_key'] = 'test_value'
    fact_cache['test_key2'] = 'test_value2'
    fact_cache['test_key3'] = 'test_value3'

    assert len(fact_cache) == initial_len + 3
    assert 'test_key' in fact_cache
    assert 'test_key2' in fact_cache
    assert 'test_key3' in fact_cache

    fact_cache.flush()
    assert len(fact_cache) == initial_len

    fact_cache.__setitem__('test_key4', 'test_value4')
    assert len(fact_cache) == initial_len + 1
    assert 'test_key4' in fact_cache

    fact

# Generated at 2022-06-23 15:00:25.900588
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fc = FactCache()
    fc.__delitem__("key")
    assert True


# Generated at 2022-06-23 15:00:27.268627
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    len(fact_cache)



# Generated at 2022-06-23 15:00:28.598092
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    assert False, "No test for method __setitem__"


# Generated at 2022-06-23 15:00:32.658827
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    # Write in the cache
    fact_cache['host1'] = {'foo': 'bar'}
    # Check that cache is not empty
    assert len(fact_cache.keys()) > 0
    # Check that flush method remowe all entries
    fact_cache.flush()
    assert len(fact_cache.keys()) == 0

# Generated at 2022-06-23 15:00:34.378673
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert(fact_cache is not None)

# Generated at 2022-06-23 15:00:37.543002
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    cache = FactCache()
    cache['test'] = 'test'
    res = cache.copy()
    assert res == {'test': 'test'}



# Generated at 2022-06-23 15:00:40.791665
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache = FactCache()
    fact_cache['test'] = 'test'
    assert fact_cache.keys() == ['test']
    del fact_cache['test']
    assert fact_cache.keys() != ['test']


# Generated at 2022-06-23 15:00:50.325306
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    assert fc.keys() == []
    fc.first_order_merge('localhost', {'ansible_facts': {}})
    assert fc.keys() == ['localhost']
    assert fc['localhost']['ansible_facts'] == {}

    # Test that facts are merged, but not overwritten.
    fc.first_order_merge('localhost', {'ansible_facts': {'key1': 'value1'}})
    assert fc.keys() == ['localhost']
    assert fc['localhost']['ansible_facts'] == {'key1': 'value1'}

    # Test that facts are merged, but not overwritten.

# Generated at 2022-06-23 15:00:55.937903
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    # Preparation
    import os

    class mock_cache_loader:

        def get(self, arg):
            return {'fact1': 'value1'}

    cache_loader.get = mock_cache_loader()

    # Test
    fc = FactCache()
    assert len(fc) == 1

    # Make sure the cache is empty again
    if os.path.exists(os.path.join(C.CACHE_DIR, 'facts')):
        os.remove(os.path.join(C.CACHE_DIR, 'facts'))


# Generated at 2022-06-23 15:01:05.303184
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    the_cache = {'test_host':
                 {'ansible_eth0':
                  {'ipv4': {'address': '10.0.0.1', 'network': '10.0.0.0',
                            'netmask': '255.255.255.0', 'broadcast': '10.0.0.255'},
                   'ipv6': [{'address': 'fe80::250:56ff:fe8d:ec1',
                             'prefix': '64', 'scope': 'link'}],
                   'macaddress': '00:50:56:8d:0e:c1', 'module': 'e1000', 'mtu': 1500,
                   'type': 'ether', 'active': True, 'device': 'eth0'}}}
    cached = FactCache()
    cached.first_order

# Generated at 2022-06-23 15:01:07.451304
# Unit test for constructor of class FactCache
def test_FactCache():
    mock_settings = {'CACHE_PLUGIN': 'memory'}
    f = FactCache(mock_settings)
    return f

# Generated at 2022-06-23 15:01:12.062333
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    import unittest2
    import mock

    class MockPlugin(object):
        def contains(self, key):
            return True

    class TestAnsibleCache(unittest2.TestCase):

        def setUp(self):
            self.plugin = MockPlugin()
            self.cache = FactCache(self.plugin)

        def test_True(self):
            self.assertTrue(self.cache.__contains__('foo'))

# Generated at 2022-06-23 15:01:15.012265
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    cache = FactCache()
    cache["a"] = "b"
    cache_copy = cache.copy()
    cache["a"] = "d"
    assert cache_copy["a"] == "b"

# Generated at 2022-06-23 15:01:17.806379
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fact_cache = factCache()
    result = fact_cache.__getitem__("test_key")
    print(result)


# Generated at 2022-06-23 15:01:24.570753
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    class PluginMock(object):
        def __init__(self):
            self.cache = dict()
            self.set_invoked = False
            pass

        def set(self, key, value):
            self.cache[key] = value
            self.set_invoked = True

    mock = PluginMock()
    fact_cache = FactCache(mock)
    fact_cache["key"] = "value"
    assert mock.cache["key"] == "value"
    assert mock.set_invoked == True

# Generated at 2022-06-23 15:01:29.143545
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    import pytest
    my_fact_cache = FactCache()
    my_fact_cache['my'] = 'my'
    assert my_fact_cache.copy() == {'my': 'my'}

# Generated at 2022-06-23 15:01:38.464053
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    plugin = cache_loader.get('jsonfile')
    plugin.flush()
    try:
        fc = FactCache()
        fc.keys()
        fc['key1'] = 'value1'
        fc['key2'] = 'value2'
        fc['key3'] = 'value3'
        fc['key4'] = 'value4'
        assert 'key1' in fc.keys()
        assert 'key2' in fc.keys()
        assert 'key3' in fc.keys()
        assert 'key4' in fc.keys()
        assert 'key5' not in fc.keys()
    finally:
        plugin.flush()

# Generated at 2022-06-23 15:01:41.688186
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    """
    FactCache.__getitem__()
    """
    try:
        cache_loader.get(C.CACHE_PLUGIN)
    except AnsibleError as error:
        module.fail_json(msg=error.message)


# Generated at 2022-06-23 15:01:43.332065
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    pass


# Generated at 2022-06-23 15:01:44.069434
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    pass

# Generated at 2022-06-23 15:01:45.564308
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    cache = FactCache()
    #assert cache.keys() == []



# Generated at 2022-06-23 15:01:48.123176
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache._plugin, type({}))

# Generated at 2022-06-23 15:01:52.089244
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():

    class MyPlugin(object):
        def contains(self, key):
            return key == 'foo'

        def delete(self, key):
            assert key == 'foo'

    p = MyPlugin()
    c = FactCache(plugin=p)
    del c['foo']

# Generated at 2022-06-23 15:01:53.818409
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    assert FactCache().keys() == fact_cache._plugin.keys()


# Generated at 2022-06-23 15:01:54.830125
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    pass


# Generated at 2022-06-23 15:02:01.596165
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    from ansible.plugins.loader import cache_loader
    from ansible.module_utils._text import to_text

    class FakePlugin:
        def contains(self, key):
            return key == 'key1'

        def get(self, key):
            return 'value1'

        def set(self, key, value):
            return

        def delete(self, key):
            return

        def keys(self):
            return

    cache_loader.plugin_class = FakePlugin
    cache = FactCache()

    assert to_text(cache['key1']) == 'value1'
    assert 'key1' in cache
    assert 'key2' not in cache



# Generated at 2022-06-23 15:02:10.346511
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    key = 'key'
    key_value = {'foo': 'bar'}
    host_facts = {key: key_value}

    mock_plugin = FakePlugin()
    mock_plugin.set(key, key_value)

    fact_cache = FactCache()
    fact_cache._plugin = mock_plugin

    new_value = {'new': 'value'}
    fact_cache.first_order_merge(key, new_value)

    expected_value = {'foo': 'bar', 'new': 'value'}
    assert fact_cache['key'] == expected_value



# Generated at 2022-06-23 15:02:14.434567
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    f = FactCache()
    datas = {
        'key1' : 'value1',
        'key2' : 'value2',
    }
    f.update(datas)
    assert f.copy() == datas

# Generated at 2022-06-23 15:02:18.551977
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    factcache = FactCache()
    factcache._plugin.set('testkey', 'testvalue')
    factcache._plugin.contains('testkey') == True
    assert factcache._plugin.get('testkey') == 'testvalue'


# Generated at 2022-06-23 15:02:21.264331
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    a_facts_cache = FactCache()
    assert 'a' not in a_facts_cache
    a_facts_cache['a'] = 1
    assert 'a' in a_facts_cache
    a_facts_cache.flush()

# Generated at 2022-06-23 15:02:25.908915
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    fact_cache['foo'] = 'bar'
    assert fact_cache.copy() == {"foo": "bar"}


# Generated at 2022-06-23 15:02:36.083270
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    try:
        import json
        import pytest
        from ansible.module_utils.common.collections import ImmutableDict
    except ImportError:
        pytestmark = pytest.mark.skip("fact_cache_copy test requires json, pytest, ImmutableDict imports")

    class CachePlugin:
        def __init__(self):
            self._cache = {'foo': {'bar': 'baz'}}

        def contains(self, key):
            return key in self._cache

        def delete(self, key):
            del self._cache[key]

        def flush(self):
            self._cache = {}

        def get(self, key):
            return self._cache[key]

        def keys(self):
            return self._cache.keys()

        def set(self, key, value):
            self

# Generated at 2022-06-23 15:02:43.510177
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    import os
    from ansible.plugins.loader import cache_loader

    if 'ANSIBLE_FACT_CACHE' in os.environ:
        del os.environ['ANSIBLE_FACT_CACHE']

    facts_cache = FactCache()

    plugin = cache_loader.get(C.CACHE_PLUGIN)
    assert plugin.contains("some_key") == False
    facts_cache['some_key'] = "some_value"
    assert plugin.contains("some_key") == True
    del facts_cache['some_key']
    assert plugin.contains("some_key") == False



# Generated at 2022-06-23 15:02:48.960835
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    f=FactCache()
    # if no key is in cache,  __delitem__ should raise KeyError
    with pytest.raises(KeyError):
        del f["key"]
    f["key"]="value"
    assert f["key"]=="value"
    del f["key"]
    with pytest.raises(KeyError):
        f["key"]



# Generated at 2022-06-23 15:02:50.490621
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fc = FactCache()
    fc['a']='a'
    del fc['a']


# Generated at 2022-06-23 15:02:52.585634
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    cache = FactCache()
    cache["key1"] = "value1"
    assert cache.copy() == {"key1": "value1"}



# Generated at 2022-06-23 15:02:54.254239
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = FactCache()
    fact_cache.__setitem__("key", "value")
    fact_cache.__setitem__("key", "value")


# Generated at 2022-06-23 15:02:58.254462
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    cache = FactCache()
    cache['test_1'] = 1
    cache['test_2'] = 2

    cache_copy = cache.copy()
    assert cache_copy.get('test_1') == 1
    assert cache_copy.get('test_2') == 2

    cache.flush()


# Generated at 2022-06-23 15:03:04.023367
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    cache = FactCache()
    cache["key1"] = "value1"
    cache["key2"] = "value2"
    cache["key3"] = "value3"
    cache["key4"] = "value4"
    cache["key5"] = "value5"
    assert cache

    cache.flush()
    assert not cache

# Generated at 2022-06-23 15:03:12.948234
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    key = "test_node1"
    value = {'ansible_os_family': 'RedHat', 'ansible_distribution': 'CentOS'}
    cache.first_order_merge(key, value)
    assert cache['test_node1'] == {'ansible_os_family': 'RedHat', 'ansible_distribution': 'CentOS'}

    key = "test_node1"
    value = {'ansible_os_family': 'Debian', 'ansible_distribution': 'Ubuntu'}
    cache.first_order_merge(key, value)
    assert cache['test_node1'] == {'ansible_os_family': 'Debian', 'ansible_distribution': 'Ubuntu'}

# Generated at 2022-06-23 15:03:16.131246
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fc = FactCache()
    name = 'test'
    fc[name] = ''
    del fc[name]
    assert not fc.__contains__(name)

    try:
        del fc[name]
    except KeyError:
        assert True



# Generated at 2022-06-23 15:03:17.926684
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)

# Generated at 2022-06-23 15:03:20.521313
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin == cache_loader.get(C.CACHE_PLUGIN)


# Generated at 2022-06-23 15:03:22.091523
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fact_cache = FactCache(None)
    fact_cache['blabla'] = 42
    assert fact_cache['blabla'] == 42


# Generated at 2022-06-23 15:03:24.310280
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fact_cache_instance = FactCache()
    assert fact_cache_instance['test_key'] is not None


# Generated at 2022-06-23 15:03:26.322389
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fc = FactCache()
    assert(fc[0] is not 0) # fc[0] raises KeyError


# Generated at 2022-06-23 15:03:29.300435
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    try:
        fac = FactCache()
        # checke nonexiste key
        a = fac["a"]
        return False
    except KeyError:
        return True


# Generated at 2022-06-23 15:03:30.310969
# Unit test for constructor of class FactCache
def test_FactCache():

    fact_cache = FactCache()
    assert fact_cache

# Generated at 2022-06-23 15:03:32.037452
# Unit test for constructor of class FactCache
def test_FactCache():
    """
    Unit test for constructor of class FactCache
    """
    fact_cache = FactCache()
    assert fact_cache is not None
    assert isinstance(fact_cache, FactCache)

# Generated at 2022-06-23 15:03:37.831630
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    factcache = FactCache()
    factcache.first_order_merge("key", {"a": "1"})
    assert factcache == {"key": {"a": "1"}}
    factcache.first_order_merge("key", {"b": "2"})
    assert factcache == {"key": {"a": "1", "b": "2"}}
    factcache.first_order_merge("key", {"c": "3"})
    assert factcache == {"key": {"a": "1", "b": "2", "c": "3"}}
    factcache.first_order_merge("key", {"a": "4"})
    assert factcache == {"key": {"a": "1", "b": "2", "c": "3"}}
    factcache.flush()


# Generated at 2022-06-23 15:03:39.105976
# Unit test for constructor of class FactCache
def test_FactCache():
    assert isinstance(FactCache(None, None), MutableMapping)

# Generated at 2022-06-23 15:03:40.035308
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    pass


# Generated at 2022-06-23 15:03:43.363560
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    # init instance to test:
    cache = FactCache()
    # mock a cache plugin with a key in it
    cache._plugin = MockFactCachePlugin()
    # check that the key exists in the cache's mock plugin
    assert 'test_key' in cache
    assert not 'not_in_there' in cache


# Generated at 2022-06-23 15:03:47.209525
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache = FactCache()
    fact_cache['test_key'] = 'test_value'
    del fact_cache['test_key']
    assert 'test_key' not in fact_cache


# Generated at 2022-06-23 15:03:51.027732
# Unit test for method copy of class FactCache
def test_FactCache_copy():

    myFactCache = FactCache()
    test_dict = {'test1': 'test1'}
    myFactCache['test1'] = test_dict
    ret = myFactCache.copy()
    assert ret['test1'] is test_dict


# Generated at 2022-06-23 15:04:02.029949
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    import pytest
    from ansible.plugins.loader import cache_loader

    cache_plugin = cache_loader.get(C.CACHE_PLUGIN)

    cache = FactCache()
    cache['test_FactCache_1'] = '1'
    cache['test_FactCache_2'] = '2'
    cache['test_FactCache_3'] = '3'

    cache_plugin.flush()

    def test_keys():
        keys = cache.keys()
        assert len(keys) == 3
        assert 'test_FactCache_1' in keys
        assert 'test_FactCache_2' in keys
        assert 'test_FactCache_3' in keys

    def test_iter():
        keys = []
        for key in cache:
            keys += [key]
        assert len(keys) == 3
       

# Generated at 2022-06-23 15:04:05.899345
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    print('Function: test_FactCache_flush')
    fc = FactCache()
    fc['foo'] = 'bar'
    fc['baz'] = 'foo'
    assert len(fc) == 2
    fc.flush()
    assert len(fc) == 0

# Generated at 2022-06-23 15:04:08.905388
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    f = FactCache()
    for key in f.keys():
        assert key in f


# Generated at 2022-06-23 15:04:10.624743
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fc = FactCache()
    fc['name'] = 'value'
    assert fc['name'] == 'value'


# Generated at 2022-06-23 15:04:12.814913
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    # TODO: Implement unit test for method FactCache.__delitem__
    assert False


# Generated at 2022-06-23 15:04:17.013852
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    cache = FactCache()
    cache._plugin = {'_plugin': {'_plugin': 'test_get'}, 
            'get': lambda key: 'test_get'}
    assert cache['_plugin'] == 'test_get'


# Generated at 2022-06-23 15:04:20.229175
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    # Return a list of all the values ever set on the cache.
    cache = FactCache()
    try:
        cache.__iter__()
    except Exception as e:
        print('Exception:', e)



# Generated at 2022-06-23 15:04:22.997306
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    facts = FactCache()
    assert isinstance(facts, FactCache)
    facts['ansible_distribution'] = 'debian'
    assert 'ansible_distribution' in facts.keys()

# Generated at 2022-06-23 15:04:23.475456
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    pass

# Generated at 2022-06-23 15:04:24.325791
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    assert False

# Generated at 2022-06-23 15:04:25.118789
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()

# Generated at 2022-06-23 15:04:28.384636
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = FactCache()
    fact_cache['test'] = 'test value'
    assert 'test' in fact_cache
    assert fact_cache['test'] == 'test value'
    fact_cache['test'] = 'new test value'
    assert fact_cache['test'] == 'new test value'


# Generated at 2022-06-23 15:04:30.469582
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    # The test FactCache plugin doesn't return a value for some keys
    fact_cache = FactCache()
    assert "ansible_all_ipv4_addresses" not in fact_cache


# Generated at 2022-06-23 15:04:40.337940
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    ''' Test flush method of FactCache class '''

    from ansible.plugins.loader import fact_cache_loader
    fact_cache_loader.add(u'test_plugin', DummyPlugin)
    my_cache = FactCache(plugin=u'test_plugin')

    # =========================
    # CASE 1: cache is empty
    # =========================
    result = my_cache.flush()
    assert result is None
    assert my_cache._plugin.data == {}

    # =========================
    # CASE 2: cache is not empty
    # =========================
    my_cache.set(u'my_host', 42)
    my_cache.set(u'my_host_2', 43)
    my_cache.set(u'my_host_3', 44)

# Generated at 2022-06-23 15:04:52.815327
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    cache = FactCache()
    cache._plugin = {}

    def contains(key):
        return key in cache._plugin

    cache._plugin.contains = contains
    assert ('ansible_processor_vcpus' not in cache)

    def set(key, value):
        cache._plugin[key] = value

    cache._plugin.set = set
    test_value = "8"
    cache._plugin.set('ansible_processor_vcpus', test_value)
    assert ('ansible_processor_vcpus' in cache)

    def get(key):
        return cache._plugin[key]

    cache._plugin.get = get
    assert (cache['ansible_processor_vcpus'] == test_value)

    # Should raise exception here

# Generated at 2022-06-23 15:04:55.088557
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    fact_cache.flush()
    expected_result = True
    assert expected_result == True



# Generated at 2022-06-23 15:04:58.684394
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    my_fact_cache = FactCache()
    assert not my_fact_cache.__iter__()
    my_fact_cache['foo'] = 'bar'
    assert 'foo' in my_fact_cache.__iter__()


# Generated at 2022-06-23 15:05:00.942852
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    assert isinstance(FactCache().keys(), list)
    assert isinstance(FactCache().keys(), list)

# Generated at 2022-06-23 15:05:07.755801
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    new_key = 'sample_key'
    new_value = 'sample_value'
    test_fact = {}
    test_fact.update({new_key : new_value})

    # Initialize the cache
    cache = FactCache()
    cache.first_order_merge(new_key, new_value)

    assert cache['sample_key'] == test_fact['sample_key']

# Generated at 2022-06-23 15:05:18.516093
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    from ansible.module_utils.facts import FactsCache
    facts_cache = FactsCache()

# Generated at 2022-06-23 15:05:19.344733
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    pass


# Generated at 2022-06-23 15:05:21.884194
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    cache = FactCache()
    cache['name'] = 'Ansible'
    cache['value'] = 1
    cache['value'] = 2
    assert len(cache) == 2


# Generated at 2022-06-23 15:05:22.965985
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    f = FactCache()
    assert len(f) == 0


# Generated at 2022-06-23 15:05:24.570352
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fact_cache = FactCache()
    items = fact_cache.keys()
    assert len(items) == 0


# Generated at 2022-06-23 15:05:27.348624
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    factcache = FactCache()
    factcache['key1'] = 'value1'
    factcache['key2'] = 'value2'
    assert factcache['key1'] == 'value1'
    assert factcache['key2'] == 'value2'
    factcache.flush()
    assert factcache.keys() == []


# Generated at 2022-06-23 15:05:38.568647
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    """ Test case for method FactCache.__iter__  """
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars

    # Test hostvars with default value
    hostvars = HostVars()
    hostvars.add_host('host1')
    assert list(hostvars) == ['host1']

    # Test hostvars with custom value
    hostvarsVars = HostVarsVars()
    hostvarsVars.add_host('host1')
    hostvarsVars.add_host('host2')
    hostvarsVars.add_host('host3')
    assert list(hostvarsVars) == ['host1', 'host2', 'host3']

# Generated at 2022-06-23 15:05:42.456629
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    fact_cache['key'] = 'value'
    fact_dict = fact_cache.copy()
    assert isinstance(fact_dict, dict)
    assert fact_dict['key'] == fact_cache['key']

# Generated at 2022-06-23 15:05:46.061153
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    cache = FactCache()
    cache['foo'] = 'bar'
    cache['baz'] = 'qux'
    assert 'foo' in cache
    assert 'baz' in cache
    assert 'bad' not in cache


# Generated at 2022-06-23 15:05:52.136560
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    host_facts = {"ansible_product_name": "VMware vCenter Server"}
    cache.first_order_merge('host1', host_facts)
    assert cache['host1']['ansible_product_name'] == 'VMware vCenter Server'
    host_facts = {"ansible_product_name": "VMware ESXi"}
    cache.first_order_merge('host1', host_facts)
    assert cache['host1']['ansible_product_name'] == 'VMware ESXi'
    cache.flush()

# Generated at 2022-06-23 15:05:54.803624
# Unit test for constructor of class FactCache
def test_FactCache():
    '''Test for constructor of FactCache'''
    cache = FactCache()
    assert cache is not None
    assert cache._plugin is not None

# Generated at 2022-06-23 15:05:56.580344
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fact_cache = FactCache()

    assert (fact_cache['test-fact'] == 'test-value')

# Generated at 2022-06-23 15:06:03.859886
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('example.com', {'foo': 1})
    assert fact_cache['example.com']['foo'] == 1
    fact_cache.first_order_merge('example.com', {'bar': 2})
    assert fact_cache['example.com']['bar'] == 2
    fact_cache.first_order_merge('example.com', {'foo': 3})
    assert fact_cache['example.com']['foo'] == 3


# Generated at 2022-06-23 15:06:12.136201
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    host = 'test.example.org'
    test_facts = {u'system': 'test system', u'os': 'test os'}
    test_facts_2 = {u'system': 'test system', u'os': 'test os', u'fact1': 'test fact1'}
    fc = FactCache()
    fc.first_order_merge(host, test_facts)
    assert fc[host] == test_facts
    fc.first_order_merge(host, test_facts_2)
    assert fc[host] == test_facts_2

# Generated at 2022-06-23 15:06:15.750016
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    c = FactCache()

    host_cache = c._plugin.get('test')
    if host_cache:
        c.set('test', host_cache)

    test = c.__getitem__('test')
    assert isinstance(test, dict)
    assert test


# Generated at 2022-06-23 15:06:26.030797
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    """
    Test that first_order_merge works when:
        - on a cache miss (no host)
        - on a cache miss (host exists but not the cache key)
        - on a cache hit (host and key exists)
    """
    # First initialize the fact cache plugin
    fact_cache_inst = FactCache()

    # Set some values in the cache
    fact_cache_inst.first_order_merge('test_host', {'test_key': 'test_value'})
    fact_cache_inst.first_order_merge('test_host', {'test_key2': 'test_value2'})
    fact_cache_inst.first_order_merge('test_host2', {'test_key': 'test_value'})

    # First test the case where the cache miss
    assert fact_

# Generated at 2022-06-23 15:06:26.993785
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    pass


# Generated at 2022-06-23 15:06:30.316856
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fc = FactCache()
    fc['test'] = {'value':'test'}
    assert 'test' in fc
    del fc['test']
    assert 'test' not in fc


# Generated at 2022-06-23 15:06:33.008665
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    cache = {'test': 'item'}
    fact_cache = FactCache(cache)
    assert fact_cache['test'] ==  cache['test']


# Generated at 2022-06-23 15:06:36.655736
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    facts = FactCache()
    facts["foo"] = "bar"
    facts["bar"] = "baz"
    copied_facts = facts.copy()
    assert copied_facts["foo"] == "bar"
    assert copied_facts["bar"] == "baz"

# Generated at 2022-06-23 15:06:45.038500
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    def _plugin_contains(key):
        if key == 'test_key': return True
        raise KeyError

    def _plugin_delete(key):
        if key in _items: del _items[key]

    _items = {'test_key': 'test_value'}

    factcache = FactCache()
    factcache._plugin.contains = _plugin_contains
    factcache._plugin.delete = _plugin_delete

    factcache.__delitem__('test_key')
    assert 'test_key' not in factcache._plugin._items


# Generated at 2022-06-23 15:06:45.989287
# Unit test for constructor of class FactCache
def test_FactCache():
    foo = FactCache()
    assert foo

# Generated at 2022-06-23 15:06:57.638790
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    import shutil
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils._text import to_bytes, to_native
    from tempfile import mkdtemp

    _cache_dir = mkdtemp()

    C.CACHE_PLUGIN = 'jsonfile'
    C.CACHE_PLUGIN_CONNECTION = to_bytes(_cache_dir)

    fact_cache = FactCache()

    # It should be empty
    assert fact_cache == {}

    # It should be mutable
    fact_cache['some_key'] = 'some_value'
    assert fact_cache == {'some_key': 'some_value'}

    # It should contain only the first_order_merge of facts
    fact_cache.first_order_merge

# Generated at 2022-06-23 15:07:00.912175
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    factcache_test_data = {}
    assert not factcache_test_data
    test_factcache = FactCache(factcache_test_data)
    assert test_factcache


# Generated at 2022-06-23 15:07:10.705270
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    myFactCache = FactCache()
    host_facts = {"ansible_system": "Linux", "ansible_distribution": "CentOS"}
    myFactCache.first_order_merge("localhost", host_facts)
    assert "localhost" in myFactCache
    assert "ansible_system" in myFactCache["localhost"]
    assert "ansible_distribution" in myFactCache["localhost"]
    assert myFactCache["localhost"]["ansible_system"] == "Linux"
    assert myFactCache["localhost"]["ansible_distribution"] == "CentOS"

if __name__ == '__main__':
    test_FactCache_first_order_merge()

# Generated at 2022-06-23 15:07:19.823016
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fc = FactCache()
    assert fc.flush() == None

    fc = FactCache()
    fc['foo'] = {'bar': 'baz'}
    assert fc.flush() == None
    assert 'foo' not in fc

    fc = FactCache()
    fc['foo'] = {'bar': 'baz'}
    fc['foo2'] = {'bar2': 'baz2'}
    fc['foo3'] = {'bar3': 'baz3'}
    assert fc.flush() == None
    assert 'foo' not in fc
    assert 'foo2' not in fc
    assert 'foo3' not in fc


# Generated at 2022-06-23 15:07:28.591815
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    a = FactCache()
    assert len(a) == 0
    a['test'] = 'testdata'
    assert len(a) == 1
    a['test1'] = 'testdata1'
    assert len(a) == 2
    a['test1'] = 'testdata2'
    assert len(a) == 2
    del a['test1']
    assert len(a) == 1
    assert len(a) == 1
    a['test1'] = 'testdata1'
    assert len(a) == 2
    assert len(FactCache()) == 0


# Generated at 2022-06-23 15:07:32.319295
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fc = FactCache()
    k = 'key'
    v = 'value'
    fc[k] = v
    assert fc[k] == v
    fc.flush()
    assert not fc.keys()

# Generated at 2022-06-23 15:07:35.226979
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    from ansible_collections.ansible.community.plugins.module_utils.network.common.fact_cache import FactCache
    fc=FactCache()
    assert fc.__len__()==0


# Generated at 2022-06-23 15:07:39.564321
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():

    key = 'test_key'
    value = 'test_value'

    fact_cache = FactCache()
    fact_cache[key] = value
    assert key in fact_cache
    assert fact_cache[key] == value


# Generated at 2022-06-23 15:07:49.321920
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    print("Testing test_FactCache___delitem__")
    import os
    import sys
    import unittest
    from io import StringIO
    path1 = os.getcwd() + '/test_file/ansible/plugins/cache/jsonfile.py'
    path2 = os.getcwd() + '/test_file/ansible/plugins/cache/yaml.py'
    sys.path.insert(0, path1)
    sys.path.insert(0, path2)
    from yaml import YAMLInventoryCachePlugin

    yaml = YAMLInventoryCachePlugin()

    C.CACHE_PLUGIN = 'yaml'
    inventory = FactCache()
    inventory['key'] = 'value'

# Generated at 2022-06-23 15:07:50.346231
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    assert True

# Generated at 2022-06-23 15:08:00.185112
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import sys
    import os
    ansible_basedir = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, os.pardir))
    sys.path.append(os.path.join(ansible_basedir, 'lib', 'ansible'))

    from ansible.constants import C
    from ansible.utils.display import Display

    display = Display()
    C.CACHE_PLUGIN = 'jsonfile'

    assert FactCache(path="test/test_cache.fact").first_order_merge("foo", "bar") == {'foo': 'bar'}

# Generated at 2022-06-23 15:08:02.197655
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    f = FactCache()
    f['test_key'] = 'test_value'
    f.flush()
    assert 'test_key' not in f

# Generated at 2022-06-23 15:08:04.374106
# Unit test for constructor of class FactCache
def test_FactCache():
    facts_cache = FactCache()
    assert facts_cache
    assert facts_cache._plugin

# Generated at 2022-06-23 15:08:08.469180
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    a = {}
    a = FactCache(**a)
    print(type(a))
    for k, v in a.items():
        print('key:{}, value:{}'.format(k, v))

if __name__ == '__main__':
    test_FactCache___iter__()

# Generated at 2022-06-23 15:08:20.299603
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    import doctest
    from ansible.module_utils.common._collections_compat import MutableMapping

# Generated at 2022-06-23 15:08:29.359158
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    # FactCache._plugin.keys() returns ['host1', 'host2']
    def test_keys():
        return ['host1', 'host2']
    # FactCache._plugin.get() returns a dict with key host2
    def test_get(key):
        if key == 'host2':
            return {'host2': 'host2'}
        raise KeyError
    # FactCache._plugin.__contains__() returns True if key is in ['host1', 'host2']
    def test_contains(key):
        return key in ['host1', 'host2']

    cache = FactCache()
    cache._plugin = type('', (), {'keys': test_keys, 'get': test_get, '__contains__': test_contains})
    assert 'host1' in cache

# Generated at 2022-06-23 15:08:32.311547
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    fact_cache['key1'] = 'value'
    fact_cache['key2'] = 'value'
    assert 'key1' in fact_cache
    assert 'key2' in fact_cache
    fact_cache.flush()
    assert 'key1' not in fact_cache
    assert 'key2' not in fact_cache


# Generated at 2022-06-23 15:08:39.085838
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    new_cache = FactCache()
    assert new_cache.copy() == {}
    new_cache["a"] = '1'
    assert new_cache.copy() == {"a": '1'}
    new_cache["b"] = '2'
    new_cache["c"] = '3'
    assert new_cache.copy() == {"a": '1', "b": '2', "c": '3'}

# Generated at 2022-06-23 15:08:46.548838
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache(dict())
    host_cache = {'test_fact': "test_value"}
    cache._plugin.set("test_host", host_cache)
    new_facts = {'new_fact': "new_value"}
    cache.first_order_merge("test_host", new_facts)
    facts_copy = cache._plugin.get("test_host")
    assert facts_copy['test_fact'] == host_cache['test_fact']
    assert facts_copy['new_fact'] == new_facts['new_fact']

# Generated at 2022-06-23 15:08:53.000987
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    from ansible.module_utils.facts import cache
    import pytest
    mock_ansible_vars = {
        'ansible_facts': {
            'aaa': {
                'bbb': {
                    'ccc': 'ddd'
                }
            },
            'eee': 'fff'
        }
    }
    mock_ansible_vars_copy = mock_ansible_vars.copy()
    mock_fact_cache = cache.FactCache(mock_ansible_vars)

    assert mock_fact_cache['aaa'] == {'bbb': {'ccc': 'ddd'}}
    assert mock_fact_cache['bbb'] == {'ccc': 'ddd'}
    assert mock_fact_cache['ccc'] == 'ddd'
    assert mock_ansible

# Generated at 2022-06-23 15:08:54.189016
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    assert(True)



# Generated at 2022-06-23 15:08:58.464731
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    dict = {'1': {'a':'a'}, '2':{'b':'b'}}
    fact_cache = FactCache()
    fact_cache._plugin.set_hostvars(dict)
    assert(iter(fact_cache) == dict.keys())

