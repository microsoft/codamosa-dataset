

# Generated at 2022-06-23 14:58:57.156520
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    cache = FactCache()
    for key in cache:
        display.display(key)


# Generated at 2022-06-23 14:59:00.663663
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    obj = FactCache()
    fc = FactCache()
    fc._plugin = {'test': {'test': 'test'}}
    assert fc._plugin == {'test': {'test': 'test'}}
    obj.__delitem__('test1')
    assert obj._plugin == fc._plugin


# Generated at 2022-06-23 14:59:03.505713
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    from ansible.module_utils.common._collections_compat import Mapping
    d = C
    if not isinstance(d, Mapping):
        d = dict(d)
    c = FactCache(d)
    c['a'] = 'A'
    assert 'a' in c
    assert 'a1' not in c
    c.flush()
    assert 'a' not in c


# Generated at 2022-06-23 14:59:12.968835
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc.first_order_merge('host_a', {'foo': 'bar'})
    fc.first_order_merge('host_a', {'baz': 'qux'})
    assert fc['host_a'] == {'foo': 'bar', 'baz': 'qux'}
    fc.first_order_merge('host_b', {'foo': 'bar', 'baz': 'qux'})
    assert fc['host_b'] == {'foo': 'bar', 'baz': 'qux'}

# Generated at 2022-06-23 14:59:19.420195
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    facts_cache = FactCache()
    facts_cache['test_key'] = {'a':'b'}
    assert facts_cache._plugin.contains('test_key') == True
    assert facts_cache._plugin.get('test_key') == {'a':'b'}
    facts_cache.flush()
    assert facts_cache._plugin.contains('test_key') == False
    assert facts_cache._plugin.get('test_key') == {}

# Generated at 2022-06-23 14:59:24.219301
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    try:
        fc = FactCache()
        assert fc.keys() == list()
    except Exception as e:
        print (e)

# Generated at 2022-06-23 14:59:28.017539
# Unit test for constructor of class FactCache
def test_FactCache():
    cache_plugin = C.CACHE_PLUGIN
    C.CACHE_PLUGIN = 'memory'
    try:
        fc = FactCache()
    except:
        assert False, 'Cannot instantiate FactCache class'
    finally:
        C.CACHE_PLUGIN = cache_plugin


# Generated at 2022-06-23 14:59:29.959263
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fc = FactCache()
    assert len(fc) == 0
    fc['a'] = 1
    assert len(fc) == 1
    fc['b'] = 2
    assert len(fc) == 2


# Generated at 2022-06-23 14:59:32.376708
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    cache = FactCache()
    keys = cache.keys()

    assert len(cache) == len(keys)


# Generated at 2022-06-23 14:59:36.932105
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    test_object = FactCache()
    test_object._plugin.set('one', 1)
    test_object._plugin.set('two', 2)
    test_object._plugin.set('three', 3)
    result = test_object.__iter__()
    assert result == iter(test_object._plugin.keys())


# Generated at 2022-06-23 14:59:38.684684
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    assert not FactCache.copy()


# Generated at 2022-06-23 14:59:49.262919
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.plugins.cache import BaseCacheModule
    from ansible.plugins.cache.jsonfile import CacheModule as JsonfileCacheModule
    cache_plugin = BaseCacheModule(JsonfileCacheModule())
    assert isinstance(cache_plugin, BaseCacheModule)
    assert isinstance(cache_plugin._cache, JsonfileCacheModule)
    assert isinstance(cache_plugin.keys(), list)
    assert isinstance(cache_plugin.get("test"), dict)
    assert isinstance(cache_plugin.set("test", {"test":"test"}), None)
    assert isinstance(cache_plugin.delete("test"), None)
    assert isinstance(cache_plugin.contains("test"), bool)
    assert isinstance(cache_plugin.flush(), None)
    assert isinstance(cache_plugin.reset(), None)
    assert isinstance

# Generated at 2022-06-23 14:59:50.471456
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    pass


# Generated at 2022-06-23 15:00:00.387366
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    # 
    print("---------- UNIT TEST FOR class FactCache, method __contains__() ----------")
    # 
    fc = FactCache()
    # 
    fc['asd'] = '45'
    print(fc in {'asd': '45'})
    fc['asd'] = '89'
    print(fc in {'asd': '45'})
    # 
    fc['asd'] = '45'
    print(fc in {'asd': '45'})
    fc['asd'] = '89'
    print(fc in {'asd': '89'})
    # 
    fc['asd'] = '45'
    print(fc in {'asd': '45'})
    fc['asd'] = '89'
    print

# Generated at 2022-06-23 15:00:08.414485
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    factcache_obj = FactCache()
    factcache_obj['a'] = 'a1'
    factcache_obj['b'] = 'b1'
    factcache_obj['c'] = 'c1'
    assert factcache_obj.keys() == ['a', 'b', 'c']
    assert len(factcache_obj.keys()) == 3
    factcache_obj.flush()
    assert not factcache_obj.keys()
    assert not len(factcache_obj.keys())


# Generated at 2022-06-23 15:00:18.978105
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    # An empty key is not valid since it's the host name
    assert fc.first_order_merge('', {'server_ip': '192.0.2.1'}) is None

    # A None value is not valid
    assert fc.first_order_merge('server1', None) is None

    # A fact cache is created
    assert fc.first_order_merge('server1', {'server_ip': '192.0.2.1'}) is None
    assert fc['server1']['server_ip'] == '192.0.2.1'

    # Add some more facts to the fact cache
    assert fc.first_order_merge('server1', {'server_name': 'server_A'}) is None

# Generated at 2022-06-23 15:00:19.636064
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    pass


# Generated at 2022-06-23 15:00:23.349184
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    cache = FactCache()
    cache.set('1', '1')
    cache.set('2', '2')
    cache.set('3', '3')
    assert cache.copy() == {'1': '1', '2': '2', '3': '3'}

# Generated at 2022-06-23 15:00:27.936423
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    # given
    fact_cache = FactCache()

    # the cache is empty
    assert len(fact_cache) == 0

    # when
    fact_cache.flush()

    # then
    # flush doesn't change anything
    assert len(fact_cache) == 0



# Generated at 2022-06-23 15:00:30.102238
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fact_cache = FactCache()
    assert fact_cache.__getitem__("key") == "value"


# Generated at 2022-06-23 15:00:32.167296
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    import pytest
    f = FactCache()
    assert isinstance(f, MutableMapping)
    assert hasattr(f, '__iter__')


# Generated at 2022-06-23 15:00:35.875478
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    cache = FactCache()
    cache['foo'] = 'bar'
    cache['baz'] = 'faz'
    assert cache.copy() == {'foo': 'bar', 'baz': 'faz'}

# Generated at 2022-06-23 15:00:36.505354
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    pass

# Generated at 2022-06-23 15:00:44.586971
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    host_cache_facts = {
        "testkey1": {
            "testkey2": {
                "testkey3": "testvalues"
            }
        }
    }
    host_facts = {
        "testkey1": {
            "newtestkey": "testvalues"
        }
    }
    fact_cache.first_order_merge("testkey1", host_facts["testkey1"])
    merged_facts = fact_cache.copy()
    merged_facts_values = merged_facts["testkey1"]
    assert("newtestkey" in merged_facts_values)
    assert("testkey2" not in merged_facts_values)
    fact_cache.first_order_merge("testkey1", host_cache_facts["testkey1"])


# Generated at 2022-06-23 15:00:47.078645
# Unit test for constructor of class FactCache
def test_FactCache():
    # Check that class returns an object with the same type as super
    assert isinstance(FactCache(), MutableMapping)


# Generated at 2022-06-23 15:00:49.344482
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = FactCache()
    fact_cache['foo'] = 'bar'
    assert 'foo' in fact_cache
    assert fact_cache['foo'] == 'bar'

# Generated at 2022-06-23 15:00:53.086389
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    from ansible.module_utils.common._collections_compat import MutableMapping
    class Test(FactCache):
        def __init__(self):
            pass

    t = Test()
    t.__setitem__("key", "value")
    assert t.__contains__("key") == True
    print("__contains__ success")


test_FactCache___contains__()

# Generated at 2022-06-23 15:01:03.273171
# Unit test for method __contains__ of class FactCache

# Generated at 2022-06-23 15:01:05.336218
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fc = FactCache()
    assert not fc.__contains__('key')
    fc['key'] = 'value'
    assert fc.__contains__('key')

# Generated at 2022-06-23 15:01:09.137891
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.plugins.loader import cache_loader
    facts = FactCache()
    print("factcache type: %s" % type(facts))
    print("cache type: %s" % type(facts._plugin))
    print("FactCache: %s" % facts)
    print("_plugin: %s" % facts._plugin)



# Generated at 2022-06-23 15:01:11.558185
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    display.display("Testing FactCache method keys")

    test_cache = FactCache()

    try:
        test_cache.keys()
    except AttributeError:
        display.display("Keys failed: Method not implemented")

# Generated at 2022-06-23 15:01:14.538155
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fc = FactCache()
    fc['word'] = 'dog'
    fc['num'] = 42
    cpy = fc.copy()

# Generated at 2022-06-23 15:01:19.661090
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    fact_cache["key1"] = "value1"
    fact_cache["key2"] = "value2"
    fact_cache["key3"] = "value3"
    assert len(fact_cache.keys()) == 3
    fact_cache.flush()
    assert len(fact_cache.keys()) == 0

# Generated at 2022-06-23 15:01:22.954249
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache = FactCache()
    fact_cache.keys.return_value = ['key1', 'key2', 'key3']
    fact_cache.__delitem__('key2')
    assert len(fact_cache.keys()) == 2


# Generated at 2022-06-23 15:01:27.191816
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    class FakeCache:
        def keys(self):
            return ['a', 'b', 'c']

    fc = FactCache()
    fc._plugin = FakeCache()
    assert list(fc.__iter__()) == ['a', 'b', 'c']


# Generated at 2022-06-23 15:01:38.046167
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    # FactCache.__len__()
    import os
    import pickle
    from tempfile import TemporaryDirectory
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.module_utils.common.text.converters import to_bytes

    fact_cache = FactCache()
    with TemporaryDirectory(prefix='ansible_fact_cache.') as tempdir:
        os.environ['ANSIBLE_CACHE_PLUGIN_CONNECTION'] = tempdir
        fact_cache['a'] = 1
        fact_cache['c'] = 3
        fact_cache['e'] = 5
        fact_cache['d'] = 4
        fact_cache['b'] = 2
        assert len(fact_cache) == 5
        del fact_cache['c']

# Generated at 2022-06-23 15:01:40.017403
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    facts_cache = FactCache()
    len(facts_cache)
    facts_cache.flush()


# Generated at 2022-06-23 15:01:46.768245
# Unit test for constructor of class FactCache
def test_FactCache():
    class fake_class(object):
        def __init__(self):
            self._plugin = 'test'

        def contains(self, key):
            return True

        def get(self, key):
            return 'test'

        def set(self, key, value):
            setattr(self, key, value)

        def delete(self, key):
            del self, key
            return True

        def keys(self):
            return ['test']

        def flush(self):
            return True

    fake_plugin = fake_class()
    cache = FactCache(fake_plugin)
    assert cache['test'] == 'test'
    assert len(cache) == 1
    cache['test'] = 'test'
    assert cache['test'] == 'test'
    assert cache._plugin == 'test'
    cache.flush()

# Generated at 2022-06-23 15:01:57.437576
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    try:
        from ansible.plugins.cache import memory
    except ImportError:
        memory = None
        skip("unable to import memory")

    class Display:

        class DisplayOptions:

            verbosity = 0

        verbosity = 0
        display_ok = 'ok'
        display_failed = 'failed'
        display_skipped = 'skipped'
        display_unreachable = 'unreachable'
        display_changed = 'changed'
        use_color = False
        verbosity = 0
        debug = 'debug'
        info = 'info'
        warning = 'warning'
        error = 'error'

    # Case 1: all_keys_true, then return element without exception
    if memory:
        c = FactCache(memory, Display)

        host = 'user@localhost'

# Generated at 2022-06-23 15:02:03.453923
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    from collections import Mapping
    from os import path

    from ansible.plugins.cache import memory
    from ansible.plugins.loader import cache_loader

    cache_loader.add_directory(path.join(path.dirname(__file__), 'fixtures', 'test_cache_plugin'))
    cache_loader.all()

    # simulate a successfully loaded plugin
    memory.CacheModule._cache = Mapping()

    fact_cache = FactCache()

    assert 'test' in fact_cache


# Generated at 2022-06-23 15:02:09.187222
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():

    import sys
    import tempfile

    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 4
    temp_dir = tempfile.mkdtemp()
    fact_cacher = FactCache(**{'_plugin': 'memory', 'cache_dir': temp_dir})
    fact_cacher['test_FactCache___iter__'] = 1
    for x in fact_cacher:
        assert x == 'test_FactCache___iter__'
    fact_cacher.flush()
    try:
        import shutil
        shutil.rmtree(temp_dir)
    except (IOError, OSError):
        pass

# Generated at 2022-06-23 15:02:10.934858
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fc = FactCache()
    result = fc.copy()
    assert result == dict()

# Generated at 2022-06-23 15:02:17.029581
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    cache = FactCache()
    try:
        assert len(cache) == 0
        cache['host_a'] = {'ansible_distribution': 'Debian'}
        cache['host_b'] = {'ansible_distribution': 'Debian'}
        assert len(cache) == 2
    finally:
        cache.flush()


# Generated at 2022-06-23 15:02:22.638400
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    print("Test: FactCache.__iter__()")

    class Plugin1:
        def keys(self):
            return ['k1', 'k2', 'k3']

    fc = FactCache()
    fc._plugin = Plugin1()

    assert set(fc.keys()) == {'k1', 'k2', 'k3'}
    assert set(fc.__iter__()) == {'k1', 'k2', 'k3'}

# Generated at 2022-06-23 15:02:25.765322
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    cache = FactCache()
    result = cache.__len__()

    assert (result >= 0)


# Generated at 2022-06-23 15:02:29.687828
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache = FactCache()
    assert not fact_cache
    fact_cache["test"] = "test_value"
    assert "test" in fact_cache
    del fact_cache["test"]
    assert not fact_cache

# Generated at 2022-06-23 15:02:37.872078
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    try:
        cache_loader.get('jsonfile')
    except AnsibleError:
        # skip test
        return
    import tempfile
    import os
    from ansible.config.manager import ConfigManager
    from ansible.module_utils._text import to_bytes
    from ansible.utils.display import Display

    def create_tempfile():
        (fd, path) = tempfile.mkstemp()
        os.close(fd)
        return path

    config_manager = ConfigManager(
        [],
        display
    )
    path_cache = create_tempfile()
    args = config_manager.get_configuration_definition()
    args['fact_caching'] = 'jsonfile'
    args['fact_caching_connection'] = path_cache
    config = config_manager.get_config(args)

# Generated at 2022-06-23 15:02:39.458016
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    cache = FactCache()
    assert isinstance(len(cache), int)


# Generated at 2022-06-23 15:02:43.440413
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    import ansible.plugins.cache.memory
    fact_cache = FactCache()
    fact_cache.flush()
    assert isinstance(fact_cache._plugin, ansible.plugins.cache.memory.CacheModule)
    assert fact_cache._plugin.dump() == {}

# Generated at 2022-06-23 15:02:45.695155
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    f=FactCache()
    assert isinstance(f.__iter__(), iter)


# Generated at 2022-06-23 15:02:52.716706
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    test_data = {'foo': 'bar'}

    class MockPlugin:
        def __init__(self, test_data=None):
            self._data = test_data

        def keys(self):
            return self._data.keys()

    m = MockPlugin(test_data=test_data)
    fc = FactCache()
    fc._plugin = m

    e = len(fc)
    a = 1
    assert e == a, 'test __len__ - expect: %s, actual: %s' % (e, a)



# Generated at 2022-06-23 15:02:55.609699
# Unit test for constructor of class FactCache
def test_FactCache():
    # Test whether the constructor of class FactCache is called without any error
    fact_cache = FactCache()
    return fact_cache


# Generated at 2022-06-23 15:03:00.747856
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    from ansible.tests.unit.plugins.loader.cache_loader import TestCachePlugin
    from ansible.plugins.cache import FactCache

    t = TestCachePlugin()
    f = FactCache()
    assert '__contains__' in f
    assert not f.__contains__('foo')

    # Test content of __contains__ method
    key = 'foo'
    value = 'bar'
    t.set(key, value)
    assert f.__contains__(key)


# Generated at 2022-06-23 15:03:07.149308
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    host_name = 'test'
    fact_cache = FactCache()
    fact_cache[host_name] = {'fact': 'test'}
    assert fact_cache[host_name] == {'fact': 'test'}

    fact_cache.__delitem__(host_name)
    assert fact_cache.keys() == []



# Generated at 2022-06-23 15:03:14.414081
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    host= '127.0.0.1'
    old_facts = {'ansible_facts': {'eth0': {'ipv4': {'address': '127.0.0.1'}}}}
    new_facts = {'ansible_facts': {'eth0': {'ipv4': {'address': '127.0.0.2'}}}}
    cache.first_order_merge(host, old_facts)
    assert cache.keys() == [host]
    assert cache[host]['ansible_facts']['eth0']['ipv4']['address'] == '127.0.0.1'
    cache.first_order_merge(host, new_facts)
    assert cache.keys() == [host]

# Generated at 2022-06-23 15:03:23.180365
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    """
    Tests first_order_merge function.
    """
    import json
    import ansible.module_utils.common._collections_compat as collections

    test_cache = FactCache()

    test_cache.set_plugin(MockCache())

    facts_dict = collections.MutableMapping()
    facts_dict['test'] = {'key': 'test value'}
    test_cache.first_order_merge('host', facts_dict)

    out_dict = json.loads(test_cache.dump())
    assert out_dict['host']['key'] == 'test value'



# Generated at 2022-06-23 15:03:24.983174
# Unit test for constructor of class FactCache
def test_FactCache():
  fc = FactCache()
  assert fc._plugin.cache_dir == '/tmp/ansible/facts'

# Generated at 2022-06-23 15:03:34.407952
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    display.current_screen = 'max'
    # Tests setting factcache variable
    plugins = cache_loader.all()
    assert plugins, plugins
    if plugins:
        cache_plugin_name = C.CACHE_PLUGIN
        plugin = cache_loader.get(cache_plugin_name)
        assert plugin, plugin
        if plugin:
            factcache = FactCache()
            facts = {'test': 'this'}
            factcache.__setitem__(cache_plugin_name, facts)
            assert factcache._plugin.get(cache_plugin_name), ('Could not retrieve cached value for {0}'.format(cache_plugin_name))

# Generated at 2022-06-23 15:03:37.913606
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    cache = FactCache()
    assert len(cache.keys()) == 0
    cache['one'] = 1
    assert len(cache.keys()) == 1
    cache.flush()
    assert len(cache.keys()) == 0


# Generated at 2022-06-23 15:03:39.551008
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    assert len(fact_cache) == 0


# Generated at 2022-06-23 15:03:44.977198
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    cache_test = FactCache()
    cache_test.__setitem__('test', 'test')
    cache_test.__setitem__('test2', 'test2')
    cache_test.__setitem__('test3', 'test3')

    has_test = False
    has_test2 = False
    has_test3 = False

    for item in cache_test:
        if item == 'test':
            has_test = True
        if item == 'test2':
            has_test2 = True
        if item == 'test3':
            has_test3 = True

    assert has_test
    assert has_test2
    assert has_test3

# Generated at 2022-06-23 15:03:48.373672
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    cache = FactCache()
    assert isinstance(cache, FactCache), "cache must be a FactCache"
    assert len(cache) == 0, "cache must be empty"


# Generated at 2022-06-23 15:03:56.747002
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    from ansible.module_utils.facts.collector import CollectedFactMetaClass
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from copy import deepcopy

    # create an instance of class FactCache
    cache = FactCache()

    def my_init(self):
        self.data = {'a': 1, 'b': 2, 'c': 3}
    deep_copied_data = {'a': 1, 'b': 2, 'c': 3}

    # create an instance of class DistributionFactCollector and add it to the FactCache
    DistributionFactCollector.__init__ = my_init
    collector = DistributionFactCollector()
    cache['host1'] = collector
    cache['host2'] = collector

    # Check that the primitive copy of the keys and values from the cache matches the original

# Generated at 2022-06-23 15:04:03.772223
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    """ Unit tests that the flush method of class FactCache works correctly"""

    def get_temp_path():
        import shutil
        import tempfile
        import os
        tmp = tempfile.mkdtemp()
        assert tmp.startswith(os.path.sep)
        shutil.rmtree(tmp)
        return tmp

    cache = FactCache()
    C.CACHE_PLUGIN = 'jsonfile'
    C.CACHE_PLUGIN_CONNECTION = get_temp_path()
    cache.keys()
    cache['test'] = 'test'
    assert cache['test'] == 'test'
    cache.flush()
    assert 'test' not in cache

# Generated at 2022-06-23 15:04:09.116512
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    def __contains__(self, key):
        return "__contains__"
    cache = FactCache()
    cache._plugin.__contains__ = __contains__
    result = cache.__contains__("test")
    assert result == "__contains__"


# Generated at 2022-06-23 15:04:18.573802
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():

    import mock
    import json

    fc = FactCache()
    fc._plugin = mock.MagicMock()

    facts = {
        "test1": {
            "key": "value"
        },
        "test2": {
            "key": "value"
        },
        "test3": {
            "key": "value"
        }
    }

    fc._plugin.keys.return_value = facts.keys()
    fc._plugin.get = facts.get

    actual_keys = []
    for key in iter(fc):
        actual_keys.append(key)

    assert (facts.keys() == actual_keys)


# Generated at 2022-06-23 15:04:21.327339
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    facts = {'a': 1, 'b': 2, 'c': {}}
    fact_cache = FactCache()
    fact_cache['localhost'] = facts
    assert fact_cache.copy() == facts

# Generated at 2022-06-23 15:04:23.658973
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    fact_cache['foo'] = 'bar'
    assert 'foo' in fact_cache
    fact_cache.flush()
    assert 'foo' not in fact_cache

# Generated at 2022-06-23 15:04:27.633144
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    from ansible.plugins.cache.memory import CacheModule as module

    plugin = cache_loader.get(C.CACHE_PLUGIN)
    if not plugin:
        raise AnsibleError('Unable to load the facts cache plugin (%s).' % (C.CACHE_PLUGIN))

    plugin.set('key', 'value')
    assert 'key' in plugin
    plugin.flush()

# Generated at 2022-06-23 15:04:31.401060
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    # Unsupported cache plugin
    C.CACHE_PLUGIN='memory'
    # Intialize fact cache object
    fact_cache = FactCache()
    # Check False
    if fact_cache.__contains__('a'):
        raise Exception
    # Check True
    fact_cache.__setitem__('a', 'a')
    if not fact_cache.__contains__('a'):
        raise Exception



# Generated at 2022-06-23 15:04:32.392613
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    pass


# Generated at 2022-06-23 15:04:42.229138
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    cache = FactCache()

    try:
        cache["test_key1"] = "test_value1"
    except Exception as e:
        assert False, "Unexpected exception raised: " + str(e)

    try:
        cache["test_key2"] = "test_value2"
    except Exception as e:
        assert False, "Unexpected exception raised: " + str(e)

    try:
        del cache["test_key1"]
    except Exception as e:
        assert False, "Unexpected exception raised: " + str(e)

    try:
        del cache["test_key2"]
    except Exception as e:
        assert False, "Unexpected exception raised: " + str(e)

    assert len(cache) == 0



# Generated at 2022-06-23 15:04:54.108724
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    import os
    import tempfile
    from ansible.utils.unsafe_proxy import wrap_var

    tdir = tempfile.mkdtemp()

    def _delete_dir(dir_):
        for root, dirs, files in os.walk(dir_, topdown=False):
            for name in files:
                os.remove(os.path.join(root, name))
            for name in dirs:
                os.rmdir(os.path.join(root, name))

    # Test directory:
    #    tdir/
    #        'a'
    #            'b'
    #                'my_cache'
    #                    'fact_cache_a.json'
    #        'my_cache/fact_cache_b.json'

    # Setup

# Generated at 2022-06-23 15:04:55.697978
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    assert len(fact_cache) == 0

# Generated at 2022-06-23 15:05:00.114457
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fail_msg = 'AnsibleError exception not raised'
    try:
        FactCache()
    except AnsibleError:
        pass
    except Exception as e:
        raise AssertionError('Unexpected exception raised: %s' % e) from e
    else:
        raise AssertionError(fail_msg) from None

# Generated at 2022-06-23 15:05:01.964832
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
  #TODO: write this test
  pass


# Generated at 2022-06-23 15:05:05.396760
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    tmp_facts = FactCache()
    assert(tmp_facts.__contains__('test') == False)


# Generated at 2022-06-23 15:05:12.283629
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fc = FactCache()
    assert fc.keys() == set()
    fc['key'] = 'value'
    assert fc.keys() == set(['key'])
    try:
        fc['key1'] = 'value1'
    except Exception:
        display.display('Unable to save the key, key1 value1')
    assert fc.keys() == set(['key', 'key1'])
    fc.flush()
    assert fc.keys() == set()

# Generated at 2022-06-23 15:05:17.822310
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fact_cache = FactCache()
    fact_cache.__setitem__("key_1", "value_1")
    fact_cache.__setitem__("key_2", "value_2")
    result = list()
    for fact in fact_cache.__iter__():
        result += [fact]
    assert result == ['key_1', 'key_2']



# Generated at 2022-06-23 15:05:21.062104
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    keys = ['x1', 'x2', 'x3']
    cache = FactCache()
    for x in keys:
        cache[x] = x
    keys_result = cache.keys()
    for x in keys:
        assert x in keys_result


# Generated at 2022-06-23 15:05:28.023940
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import json
    import os
    import shutil
    import tempfile

    class MockCachePlugin:
        def __init__(self, path):
            self._path = path

        def get(self, key):
            try:
                with open(os.path.join(self._path, key), 'r') as f:
                    return json.load(f)
            except IOError:
                return None

        def set(self, key, value):
            with open(os.path.join(self._path, key), 'w') as f:
                json.dump(value, f)

        def delete(self, key):
            try:
                os.remove(os.path.join(self._path, key))
            except OSError:
                pass


# Generated at 2022-06-23 15:05:30.989274
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = FactCache()
    fact_cache["mykey"] = "myvalue"
    assert fact_cache["mykey"] == "myvalue"


# Generated at 2022-06-23 15:05:37.722928
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    cache = FactCache()
    from ansible.module_utils.common._collections_compat import MutableMapping
    assert isinstance(cache, MutableMapping)
    cache['a'] = 'b'
    assert len(cache) == 1
    cache['b'] = 'c'
    assert len(cache) == 2
    cache['c'] = 'd'
    assert len(cache) == 3


# Generated at 2022-06-23 15:05:40.356760
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache = FactCache()
    fact_cache['test'] = 1
    del fact_cache['test']
    assert 'test' not in fact_cache


# Generated at 2022-06-23 15:05:45.087744
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    c = FactCache()
    assert c.copy() == {}
    c._plugin = MockCachePlugin()
    c['a'] = 'aaa'
    c['b'] = 'bbb'
    assert c.copy() == {'a': 'aaacopy', 'b': 'bbbcopy'}


# Generated at 2022-06-23 15:05:48.856516
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fc = FactCache()
    assert fc.keys() == []
    fc["test_key"] = "test_value"
    assert fc.keys() == ["test_key"]
    fc.flush()
    assert fc.keys() == []


# Generated at 2022-06-23 15:05:55.495091
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    dict_facts = dict()
    dict_facts['key1'] = 1
    dict_facts['key2'] = 2
    dict_facts['key3'] = 3

    fact_cache = FactCache()
    fact_cache['key1'] = dict_facts

    if set(fact_cache.keys()) != set(dict_facts.keys()):
        raise AssertionError()

# Generated at 2022-06-23 15:05:56.136691
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    pass

# Generated at 2022-06-23 15:06:01.205819
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    fact_cache['key0'] = "value0"
    fact_cache['key1'] = "value1"
    assert len(fact_cache) == 2
    fact_cache['key2'] = "value2"
    assert len(fact_cache) == 3
    fact_cache['key3'] = "value3"
    assert len(fact_cache) == 4


# Generated at 2022-06-23 15:06:03.486439
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert(fact_cache.__class__.__name__ == "FactCache")

# Generated at 2022-06-23 15:06:05.193124
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache(plugin='jsonfile')
    assert fact_cache is not None

# Generated at 2022-06-23 15:06:06.640642
# Unit test for constructor of class FactCache
def test_FactCache():
    instance = FactCache()
    assert(isinstance(instance, FactCache))

# Generated at 2022-06-23 15:06:07.270464
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    pass

# Generated at 2022-06-23 15:06:11.544202
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    import time
    fact_cache = FactCache()
    fact_cache.flush()
    assert len(fact_cache) == 0
    fact_cache['aaa'] = {'now': time.time()}
    assert len(fact_cache) == 1


# Generated at 2022-06-23 15:06:13.193416
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    #print(len(fact_cache))


# Generated at 2022-06-23 15:06:24.228049
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    from ansible.plugins.cache.jsonfile import CacheModule as CacheModuleJson
    from ansible.plugins.cache.redis import CacheModule as CacheModuleRedis
    from ansible.plugins.cache.memcache import CacheModule as CacheModuleMemcache
    from ansible.plugins.cache.memory import CacheModule as CacheModuleMemory
    from ansible.plugins.cache.picklefile import CacheModule as CacheModulePickle
    from ansible.plugins.cache.fact_cache import CacheModule as CacheModuleFactCache

    # Test case 1
    # Test __getitem__ function when the key do exist
    # Create an instance of FactCache
    fact_cache = FactCache()
    # Create an instance of CacheModuleJson
    cache_module_json = CacheModuleJson()
    # Set the cache_module_json to plugin of the fact_cache


# Generated at 2022-06-23 15:06:34.434070
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    try:
        import test.test_utils.units
    except ImportError:
        display.warning('Unable to import Ansible units library')
        return None

    import test.test_utils.modules as test_params

    # mock data to be returned by cache plugin
    # during the test
    mock_cache_data_contains_key_key = {
        'ansible_facts': {
            'Foo': 'Bar'
        }
    }
    mock_cache_data_contains_key_key2 = {
        'ansible_facts': {
            'Foo': 'Bar'
        }
    }

    # mock data to be returned by cache plugin
    # during the test

# Generated at 2022-06-23 15:06:36.859776
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    cache = FactCache()
    cache['test_key'] = 'test_value'
    cache.flush()
    assert not cache.keys()


# Generated at 2022-06-23 15:06:39.802008
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fc = FactCache()
    # test for normal case use in Ansible
    c = cache_loader.get(C.CACHE_PLUGIN)()
    c.set('test_host_001', {'ansible_host': 'test_host_001'})
    c.set('test_host_002', {'ansible_host': 'test_host_002'})
    fc._plugin = c
    assert len(fc) == 2
    fc.__delitem__('test_host_001')
    assert len(fc) == 1


# Generated at 2022-06-23 15:06:40.710913
# Unit test for constructor of class FactCache
def test_FactCache():
    p=FactCache()
    print(p)

# Generated at 2022-06-23 15:06:45.960822
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    from ansible.plugins.cache.yaml import CacheModule as yaml
    cache = yaml()

    fc = FactCache()
    fc._plugin = cache
    cache.set('/tmp/etc/hosts', {'key1': 'value1'})

    assert '/tmp/etc/hosts' in fc
    assert '/tmp/etc/hosts1' not in fc

# Generated at 2022-06-23 15:06:47.925174
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    factcache = FactCache()
    assert not factcache["test"]



# Generated at 2022-06-23 15:06:58.737748
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    from ansible.plugins.cache import BaseCacheModule
    from ansible.module_utils.six import iteritems

    # Preparation
    # The cache mockup has to return an Iterator in the keys() method
    # See https://docs.python.org/2/library/collections.html#collections.MutableMapping
    cache_plugin_mockup = BaseCacheModule()
    cache_plugin_mockup.cache = {'foo': 'bar', 'baz': 'qux'}
    cache_plugin_mockup.keys = lambda: iteritems(cache_plugin_mockup.cache)

    fact_cache = FactCache()
    fact_cache._plugin = cache_plugin_mockup

    # Test
    assert fact_cache.keys() == ['foo', 'baz']

# Generated at 2022-06-23 15:07:07.492947
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    cache.flush()
    assert cache == {}
    cache.first_order_merge('key1', 'val1')
    assert cache == {'key1': 'val1'}
    cache.first_order_merge('key1', 'val2')
    assert cache == {'key1': 'val2'}
    cache.first_order_merge('key2', 'val1')
    assert cache == {'key1': 'val2', 'key2': 'val1'}
    cache.flush()
    assert cache == {}

# Generated at 2022-06-23 15:07:10.462945
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    fact_cache['host1'] = 1
    fact_cache['host2'] = 2
    assert fact_cache.copy() == {'host1': 1, 'host2': 2}

# Generated at 2022-06-23 15:07:17.855697
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fact_cache = FactCache()
    fact_cache['hostname'] = 'localhost'
    fact_cache['domain'] = 'localdomain'
    test_dict = {'hostname': 'localhost', 'domain': 'localdomain'}
    for k,v in test_dict.items():
        assert k in fact_cache
        assert v == fact_cache[k]
    assert 'localhost' in fact_cache
    assert 'localdomain' in fact_cache


# Generated at 2022-06-23 15:07:19.729245
# Unit test for constructor of class FactCache
def test_FactCache():
    display.verbosity = 0
    cache = FactCache()
    assert cache


# Generated at 2022-06-23 15:07:23.589325
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fact_cache = FactCache()
    assert len(fact_cache) == 0
    fact_cache['hostname'] = '127.0.0.1'
    assert len(fact_cache) == 1


# Generated at 2022-06-23 15:07:26.090937
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    # Verify the object behavior
    cache_object = FactCache()
    assert cache_object.__contains__('test_key') == False


# Generated at 2022-06-23 15:07:28.859041
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    f = FactCache()
    display.vvvv("flush: %s" % f.flush())
    display.vvvv("flush: %s" % f.flush())

# Generated at 2022-06-23 15:07:29.494703
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    assert True

# Generated at 2022-06-23 15:07:39.008896
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():

    import unittest
    import shutil, tempfile, os
    from ansible.module_utils.six.moves.urllib.parse import quote

    class TestFactCache(unittest.TestCase):

        def setUp(self):
            self.fact_cache = FactCache()

        def tearDown(self):
            self.fact_cache.flush()
            self.fact_cache = None

        def test_contains(self):
            key = 'TestHost'
            self.fact_cache[key] = 'Some known value'
            self.assertTrue(key in self.fact_cache)
            self.assertFalse('OtherHost' in self.fact_cache)

    tests = TestFactCache()
    tests.setUp()
    tests.test_contains()
    tests.tearDown()


# Unit

# Generated at 2022-06-23 15:07:41.845301
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    factCache = FactCache()
    factCache["test"] = "foo"
    copied_dict = factCache.copy()
    assert copied_dict == {"test": "foo"}

# Generated at 2022-06-23 15:07:45.296702
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    obj = FactCache(name="ansible-cache")
    obj['a'] = 'b'
    obj_copied = obj.copy()
    assert obj_copied == {'a': 'b'}


# Generated at 2022-06-23 15:07:51.766640
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    plugin = cache_loader.get(C.CACHE_PLUGIN)
    if plugin:
       plugin.set('127.0.0.1', {'ansible_kernel': 'Linux', 'test': None})
       assert plugin.get('127.0.0.1') == {'ansible_kernel': 'Linux', 'test': None}
       plugin.set('192.168.1.1', {'ansible_kernel': 'Linux', 'test': None})
       assert plugin.get('192.168.1.1') == {'ansible_kernel': 'Linux', 'test': None}


# Generated at 2022-06-23 15:07:56.003462
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
	a=FactCache()
	x=a.__len__()
	assert x == 0
	a.__setitem__("a",1)
	x=a.__len__()
	assert x == 1


# Generated at 2022-06-23 15:08:02.235946
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    """
    Method:
    fact_cache.keys()

    Expected result:
    a list of keys, at least containing the keys for the host and for localhost
    """
    fc = FactCache()
    keys = fc.keys()
    assert isinstance(keys, list)
    assert len(keys) >= 2
    assert C.DEFAULT_HOST_LIST[0] in keys
    assert 'localhost' in keys


# Generated at 2022-06-23 15:08:05.986142
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    display.display = lambda x: x
    f = FactCache()
    f['a'] = 'b'
    f.flush()
    assert len(f) == 0

# Generated at 2022-06-23 15:08:06.686893
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    pass


# Generated at 2022-06-23 15:08:17.938846
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    test_key = 'test_key'
    test_value1 = {'key1': 'value1'}
    test_value2 = {'key2': 'value2'}
    test_value3 = {'key1' : 'value3'}

    fact_cache.first_order_merge(test_key, test_value1)
    assert(fact_cache[test_key] == test_value1)

    fact_cache.first_order_merge(test_key, test_value2)
    assert(fact_cache[test_key] == {'key1':'value1', 'key2':'value2'})

    fact_cache.first_order_merge(test_key, test_value3)

# Generated at 2022-06-23 15:08:21.420405
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    try:
        FactCache().__getitem__(None)
    except Exception as e:
        assert type(e) == KeyError
    assert FactCache().__getitem__('localhost') == {}



# Generated at 2022-06-23 15:08:25.681712
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    """
    Test to check if iterator work correctly on FactCache
    """
    fc = FactCache()
    fc.set("foo", "bar")
    count = 0
    for i in fc:
        assert isinstance(i, str)
        assert i == "foo"
        count += 1
    assert count == 1


# Generated at 2022-06-23 15:08:34.910749
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    plugin = cache_loader.get(C.CACHE_PLUGIN)
    if not plugin:
        raise AnsibleError('Unable to load the facts cache plugin (%s).' % (C.CACHE_PLUGIN))

    plugin.set('localhost', {'ansible_all_ipv4_addresses': [u'10.10.10.10']})
    plugin.set('10.10.10.11', {'ansible_all_ipv4_addresses': [u'10.10.10.11']})

    fact_cache = FactCache()
    assert fact_cache.keys() == ['10.10.10.10', '10.10.10.11']

# Generated at 2022-06-23 15:08:44.139569
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    fc = FactCache()
    assert fc.first_order_merge('localhost', {'f1': 'v1', 'f2': 'v2'}) == {'localhost': {'f1': 'v1', 'f2': 'v2'}}
    assert fc.first_order_merge('localhost', {'f1': 'v1', 'f2': 'v2', 'f3': 'v3'}) == {'localhost': {'f1': 'v1', 'f2': 'v2', 'f3': 'v3'}}

# Generated at 2022-06-23 15:08:49.307236
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc.first_order_merge('127.0.0.1', {'ansible_facts': {'a': 1}})
    fc.first_order_merge('127.0.0.1', {'ansible_facts': {'b': 2}})
    assert fc['127.0.0.1']['ansible_facts'] == {'a': 1, 'b': 2}

# Generated at 2022-06-23 15:08:54.561685
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fact_cache = FactCache()
    assert fact_cache == {}
    fact_cache['localhost'] = {'a': 1, 'b': 2, 'c': 3}
    assert fact_cache['localhost'] == {'a': 1, 'b': 2, 'c': 3}


# Generated at 2022-06-23 15:09:02.506209
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    from collections import UserDict
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.plugins.loader import cache_loader

    class MockCache(UserDict):
        def __init__(self):
            super().__init__()

        def set(self, key, value):
            self.data[key] = value

        def get(self, key):
            return self.data[key]

        def keys(self):
            return self.data.keys()

    class MockCacheLoader(object):
        def get(self, plugin_name):
            return MockCache()

    mock_cache_loader = MockCacheLoader()
    cache_loader.get = lambda x: mock_cache_loader.get(x)

    fact_cache = FactCache()