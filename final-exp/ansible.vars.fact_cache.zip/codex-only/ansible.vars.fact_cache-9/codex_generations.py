

# Generated at 2022-06-23 14:58:56.517717
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = FactCache()
    fact_cache['key'] = 'value'
    assert fact_cache['key'] == 'value'


# Generated at 2022-06-23 14:58:58.898868
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = FactCache()

    fact_cache['test_key'] = 'test_value'
    assert fact_cache['test_key'] == 'test_value'


# Generated at 2022-06-23 14:59:01.510565
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    plugin = cache_loader.get(C.CACHE_PLUGIN)

    test_cache = FactCache()
    test_cache['foo'] = 'bar'
    assert plugin.contains('foo')

    test_cache.flush()
    assert not plugin.contains('foo')

# Generated at 2022-06-23 14:59:03.781915
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    cache = FactCache()
    cache['host1'] = {'test': 'value'}
    assert cache.copy() == dict(host1=dict(test='value'))

# Generated at 2022-06-23 14:59:05.816662
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    """
    get the len of object.

    :return: 0
    :rtype: int
    """
    obj = FactCache()
    value = obj.__len__()

    return value


# Generated at 2022-06-23 14:59:08.026567
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fCacheObj = FactCache()
    fCacheObj_len = fCacheObj.__len__()

    # Test for integer
    assert isinstance(fCacheObj_len, int)

# Generated at 2022-06-23 14:59:11.001732
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fake_plugin = FakePlugin()
    fact_cache = FactCache()
    fact_cache._plugin = fake_plugin
    assert len(fact_cache) == 10



# Generated at 2022-06-23 14:59:15.512060
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    ''' test __len__ of class FactCache '''
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.plugins.cache.memory import MemoryCacheModule
    plugin = MemoryCacheModule()
    plugin.set('a', 1)
    cache = FactCache()
    cache._plugin = plugin

    assert 1 == cache.__len__()


# Generated at 2022-06-23 14:59:17.169447
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    fc = FactCache()
    assert iter([]) == fc.__iter__()

# Generated at 2022-06-23 14:59:19.141727
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    fact_cache.flush()

# Generated at 2022-06-23 14:59:22.795203
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fc = FactCache()
    fc["test"] = "test"
    assert fc["test"] == "test"
    fc.flush()
    assert len(fc) == 0


# Generated at 2022-06-23 14:59:30.066107
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    import os
    import tempfile
    import shutil
    import json


# Generated at 2022-06-23 14:59:31.287288
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    pass



# Generated at 2022-06-23 14:59:40.486257
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    def clear_cache():
        FC.flush()

    def set_cache(key, value):
        FC[key] = value

    def get_cache(key):
        return FC[key]

    def test_fact_cache_empty():
        pass

    def test_fact_cache_single_host():
        set_cache(host_key, host_value)
        assert get_cache(host_key) == host_value

    def test_fact_cache_multi_host():
        set_cache(host2_key, host2_value)
        assert get_cache(host2_key) == host2_value

    def test_fact_cache_merge():
        set_cache(host_key, host_value)
        assert len(FC) == 1

# Generated at 2022-06-23 14:59:48.649558
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    plugin = cache_loader.get(C.CACHE_PLUGIN)
    cache = FactCache()
    plugin.set('127.0.0.1', {
        'ansible_facts': {
            'host1': {
                'first_fact': 'value1'
            }
        }}
    )
    plugin.set('127.0.0.2', {
        'ansible_facts': {
            'host2': {
                'second_fact': 'value2'
            }
        }}
    )
    assert sorted(list(iter(cache))) == sorted(plugin.keys())

# Generated at 2022-06-23 14:59:50.624266
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fc = FactCache()
    assert fc.__contains__('foo') == False


# Generated at 2022-06-23 14:59:53.225050
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    factcache = FactCache()
    factcache._plugin = list()
    assert isinstance(factcache.__iter__(), type(iter([])))


# Generated at 2022-06-23 14:59:57.194594
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = FactCache()
    fact_cache["1"] = "a"
    fact_cache["2"] = "b"
    assert fact_cache["1"] == "a"
    assert fact_cache["2"] == "b"


# Generated at 2022-06-23 14:59:57.769760
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    assert False

# Generated at 2022-06-23 15:00:04.350006
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    cache = FactCache()
    assert len(cache.keys()) == 0
    assert cache.keys() == []

    cache['test'] = 'testdata'

    assert len(cache.keys()) == 1
    assert cache.keys() == ['test']

    cache['test2'] = 'testdata2'

    assert len(cache.keys()) == 2
    assert cache.keys() == ['test', 'test2']


# Generated at 2022-06-23 15:00:09.470600
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = FactCache()
    fact_cache["f1"] = "v1"
    assert fact_cache.__getitem__("f1") == "v1"
    fact_cache.__setitem__("f1", "x1")
    assert fact_cache.__getitem__("f1") == "x1"


# Generated at 2022-06-23 15:00:19.160100
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    class MockFactCachePlugin:
        def __init__(self, cache=None):
            self._cache = cache
            self._path = None

        def set(self, key, value):
            if not self._cache.get(key):
                self._cache[key] = {}
            self._cache[key].update(value)

        def get(self, key):
            return self._cache.get(key)

        def delete(self, key):
            if self._cache.get(key):
                del self._cache[key]

        def contains(self, key):
            return key in self._cache

        def keys(self):
            return list(self._cache.keys())

        def flush(self):
            self._cache = {}

    cache_data = {}


# Generated at 2022-06-23 15:00:21.852312
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fc = FactCache()
    fc['key1'] = 'value1'
    assert fc['key1'] == 'value1'


# Generated at 2022-06-23 15:00:24.873011
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    # setup
    class CacheStub(object):
        def flush(self): pass
    cache = CacheStub()
    fact_cache = FactCache()
    fact_cache._plugin = cache

    # test
    fact_cache.flush()



# Generated at 2022-06-23 15:00:27.836412
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    plugin = cache_loader.get(C.CACHE_PLUGIN)
    plugin.set('example', 'example')
    assert plugin.get('example') == 'example'


# Generated at 2022-06-23 15:00:30.921596
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():

    fc = FactCache()
    try:
        fc['test_fact'] = 'test_value'
        assert len(fc) == 1
        del fc['test_fact']
    finally:
        fc.flush()


# Generated at 2022-06-23 15:00:32.312296
# Unit test for constructor of class FactCache
def test_FactCache():

    cache = FactCache()

    assert True

# Unit test to test the first order merge functionality

# Generated at 2022-06-23 15:00:38.271120
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    facts = {}
    test_key = 'test_key'
    test_value = 'test_value'
    facts[test_key] = test_value
    fact_cache = FactCache()
    fact_cache.first_order_merge(test_key, test_value)
    assert fact_cache[test_key] == test_value


# Generated at 2022-06-23 15:00:45.664689
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    '''
    test_FactCache_first_order_merge method of FactCache class
    Tests the first_order_merge method of the FactCache class
    '''
    fact_cache = FactCache()
    fact_cache.first_order_merge("host", {'val1':'value1'})
    assert fact_cache['host'] == {'val1':'value1'}
    fact_cache.first_order_merge("host", {'val2':'value2'})
    assert fact_cache['host'] == {'val1':'value1', 'val2':'value2'}

# Generated at 2022-06-23 15:00:50.769968
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    fact_cache['host1'] = {'hostname': 'host1'}
    fact_cache['host2'] = {'hostname': 'host2'}

    assert set(['host1', 'host2']) == set(fact_cache.keys())
    fact_cache.flush()
    assert set() == set(fact_cache.keys())



# Generated at 2022-06-23 15:00:52.329505
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache_obj = FactCache()
    assert fact_cache_obj.__delitem__(0) == None


# Generated at 2022-06-23 15:00:55.995743
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    # Test that the method __contains__ of class FactCache return True
    # for a key that is in the cache
    hostname = 'test_host'
    fact_cache = FactCache(host=hostname)
    assert fact_cache._plugin.contains(hostname)
    assert hostname in fact_cache



# Generated at 2022-06-23 15:01:03.846665
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    # Test adding key value pair to empty cache
    sub_key = "ansible_facts"
    sub_value = {"ansible_facts": {"hello": "world"}}
    fc.first_order_merge(sub_key, sub_value)
    assert sub_key in fc
    assert sub_value == fc[sub_key]
    # Test adding key value pair to non-empty cache
    fc.first_order_merge(sub_key, {"ansible_facts": {"good": "bye"}})
    assert {"hello": "world", "good": "bye"} == fc[sub_key]

# Generated at 2022-06-23 15:01:12.704211
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    class FactCacheTester(FactCache):
        def __init__(self, config, *args, **kwargs):
            super(FactCacheTester, self).__init__(*args, **kwargs)
            self.setted_key = None
            self.setted_value = None

        def set(self, key, value):
            self.setted_key = key
            self.setted_value = value

    config = {'basedir': '/tmp'}

    fact_cache = FactCacheTester(config)
    fact_cache['test_key'] = 'test_value'
    assert fact_cache.setted_key == 'test_key'
    assert fact_cache.setted_value == 'test_value'


# Generated at 2022-06-23 15:01:23.236559
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    try:
        fact_cache = FactCache()
    except Exception as e:
        print("Failed to initialize FactCache class: %s" % str(e))
        assert False

    # Test when the cache is empty
    host = 'testhost'
    host_facts = {'os': {'distribution': 'Ubuntu'}}
    try:
        fact_cache.first_order_merge(host, host_facts)
    except Exception as e:
        print("Failed to merge data into empty fact cache: %s" % str(e))
        assert False

    # Test when the host is in cache
    host_facts = {'os': {'codename': 'xenial'}}

# Generated at 2022-06-23 15:01:31.797058
# Unit test for method flush of class FactCache
def test_FactCache_flush():

    # Arrange
    objects = [{'key1': 'value1'},
               {'key2': 'value2'}]

    cache_loader.get(C.CACHE_PLUGIN).set('key1', 'value1')
    cache_loader.get(C.CACHE_PLUGIN).set('key2', 'value2')

    # Act
    cache_loader.get(C.CACHE_PLUGIN).flush()

    # Assert
    assert len(cache_loader.get(C.CACHE_PLUGIN).keys()) == 0

# Generated at 2022-06-23 15:01:41.219772
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
  #Test without initializing the fact cache
  fact_cache = FactCache()
  try:
    len_fact_cache = len(fact_cache)
    assert len_fact_cache == 0
  except AnsibleError:
    #Expected exception for un-intialized fact_cache
    pass

  #Test after initializing the fact cache
  fact_cache._plugin = cache_loader.get("jsonfile")
  try:
    len_fact_cache = len(fact_cache)
    assert len_fact_cache == 0
  except AnsibleError:
    #Expected exception as jsonfile might not be initialized
    pass

  #Test after initializing the fact cache
  fact_cache._plugin = cache_loader.get("redis")

# Generated at 2022-06-23 15:01:44.580143
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    tcache = FactCache()
    tcache['key'] = "value"
    assert 'key' in tcache
    tcache.flush()
    assert 'key' not in tcache

# Generated at 2022-06-23 15:01:48.425091
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():

    fc = FactCache()
    fc["aaaa"] = 123

    for k in fc:
        assert k == "aaaa"
        assert fc[k] == 123


# Generated at 2022-06-23 15:01:51.119884
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    factCache = FactCache()
    factCache['myKey'] = 'myValue'

    assert factCache._plugin.get('myKey') == 'myValue'


# Generated at 2022-06-23 15:01:52.202685
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    cache = FactCache()
    cache.keys()

# Generated at 2022-06-23 15:01:55.874734
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    facts = FactCache()
    facts['a'] = 'b'
    facts['a']   # this will create an entry
    del facts['a']
    # test that key 'a' is indeed deleted from fact cache
    assert facts.keys() != ['a']

# Generated at 2022-06-23 15:01:58.149902
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache = FactCache()
    fact_cache['name'] = 'Hasan'

    del fact_cache['name']
    assert fact_cache is not None

# Generated at 2022-06-23 15:02:00.625841
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    display.verbosity = 4

    fc = FactCache()
    fc["test"] = "test"

    assert fc["test"] == 'test'



# Generated at 2022-06-23 15:02:05.630697
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('some_key', {'some': 'value'})
    assert fact_cache['some_key'] == {'some': 'value'}

    fact_cache.first_order_merge('some_key', {'other': 'value'})
    assert fact_cache['some_key'] == {'some': 'value', 'other': 'value'}

# Generated at 2022-06-23 15:02:11.468840
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fact_cache = FactCache()
    fact_cache.set(fact_cache, 'key_test', 'value_test')
    assert fact_cache.__contains__(fact_cache, 'key_test')
    fact_cache.__delitem__('key_test')


# Generated at 2022-06-23 15:02:22.214638
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    from ansible.plugins.cache.jsonfile import CacheModule as CacheModule_jsonfile
    import os
    import tempfile
    temp = tempfile.mkdtemp()
    cachedir = os.path.join(temp, 'ansible-fact-cache')
    os.mkdir(cachedir)
    C.CACHE_PLUGIN = 'jsonfile'
    C.CACHE_PLUGIN_CONNECTION = cachedir
    display.verbosity = 3
    cache = FactCache()
    cache['key'] = {'hostname':'server'}
    assert cache['key'] == {'hostname':'server'}
    C.CACHE_PLUGIN = 'jsonfile'
    C.CACHE_PLUGIN_CONNECTION = cachedir
    display.verbosity = 3
    cache

# Generated at 2022-06-23 15:02:34.430551
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    import json
    import os
    import tempfile

    temp_dir = tempfile.mkdtemp()
    facts = {
        "foo": "bar",
        "baz": {
            "faz": "baz"
        }
    }

    def mock_set(key, value):
        if not os.path.isdir(temp_dir):
            os.makedirs(temp_dir)
        with open(os.path.join(temp_dir, key), 'w') as f:
            f.write(json.dumps(value))

    def mock_get(key):
        with open(os.path.join(temp_dir, key), 'r') as f:
            return json.loads(f.read())


# Generated at 2022-06-23 15:02:45.063298
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import os
    import random
    import tempfile
    import pytest
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.plugins.loader import cache_loader

    facts = dict(
        test_value='test_value',
        test_dict=dict(k1='v1', k2='v2'),
        test_list=['foo', 'bar', 'baz'],
    )

    class MockCache(MutableMapping):
        def __init__(self, *args, **kwargs):
            self.store = dict()

        def __getitem__(self, key):
            return self.store[key]

        def __setitem__(self, key, value):
            self.store[key] = value


# Generated at 2022-06-23 15:02:46.219564
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    pass



# Generated at 2022-06-23 15:02:54.255083
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    """ Unit test for flush method of FactCache class """
    def test_func():
        return "test_func"

    # Create dummy fact cache plugin class
    class dummy_fact_cache(object):
        """ Dummy fact cache plugin class """
        def __init__(self):
            self.calls = 0
            self.contains_calls = 0
            self.get_calls = 0
            self.delete_calls = 0
            self.keys_calls = 0
            self.flush_calls = 0

        def contains(self, key):
            self.contains_calls += 1
            return self.contains_calls <= 4

        def get(self, key):
            self.get_calls += 1
            return test_func()

        def delete(self, key):
            self.delete_c

# Generated at 2022-06-23 15:02:55.212525
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fc = FactCache()
    assert fc.keys() == fc._plugin.keys()

# Generated at 2022-06-23 15:03:02.409845
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    fixture = {"a": 1}
    cache.first_order_merge("a", 9)
    assert cache["a"] == 9
    cache.first_order_merge("a", 9)
    assert cache["a"] == 9
    cache.first_order_merge("b", 10)
    assert cache["b"] == 10
    cache.flush()
    fixture = {"a": 1, "b": 2, "c": 3}
    cache.first_order_merge("a", 9)
    assert cache["a"] == 9
    cache.first_order_merge("a", 9)
    assert cache["a"] == 9
    cache.first_order_merge("a", 9)
    assert cache["a"] == 9
    cache.first_order_merge("b", 10)

# Generated at 2022-06-23 15:03:12.500858
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fc = FactCache()
    fc["h1"] = {"ansible_distribution":"CentOS", "other_fact":"foo" }
    fc["h2"] = {"ansible_distribution":"CentOS", "other_fact":"bar" }
    fc["h3"] = {"ansible_distribution":"CentOS", "other_fact":"baz" }
    fc2 = fc.copy()
    assert "h1" in fc2
    assert "h2" in fc2
    assert "h3" in fc2
    assert len(fc2) == 3
    assert fc2["h1"]["ansible_distribution"] == "CentOS"
    assert fc2["h2"]["ansible_distribution"] == "CentOS"

# Generated at 2022-06-23 15:03:14.993912
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    cache = FactCache()
    assert cache.keys() == []

    cache['a'] = 'b'
    assert cache.keys() == ['a']
    assert cache['a'] == 'b'


# Generated at 2022-06-23 15:03:16.920076
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    # TODO: implement test
    pass


# Generated at 2022-06-23 15:03:21.569312
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    factcache = FactCache()
    factcache['test_key_flush'] = 'test_value_flush'
    assert factcache['test_key_flush'] == 'test_value_flush'
    factcache.flush()
    assert 'test_key_flush' not in factcache


# Generated at 2022-06-23 15:03:23.835128
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    f = FactCache()
    f['a'] = 'A'
    assert f['a'] == 'A'



# Generated at 2022-06-23 15:03:25.499522
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fact_cache = FactCache()
    with pytest.raises(KeyError):
        fact_cache.__getitem__('foo')


# Generated at 2022-06-23 15:03:28.541803
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fake_cache_plugin = FakeCachePlugin([])
    f = FactCache(cache_plugin=fake_cache_plugin)
    assert 'aa' in f


# Generated at 2022-06-23 15:03:39.462692
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    from ansible.cache import BaseFactCacheModule
    from ansible.module_utils.six.moves import mock
    from test.unit.utils.ansible_module_runner import AnsibleModule

    class MockBaseFactCacheModule(BaseFactCacheModule):
        def flush(self):
            pass

        def set(self, key, value):
            pass

        def get(self, key):
            pass

        def contains(self, key):
            pass

        def delete(self, key):
            pass

        def keys(self):
            pass

    m = MockBaseFactCacheModule()
    with mock.patch.object(cache_loader, 'get', return_value=m) as mock_get:
        fc = FactCache()
        fc.display = AnsibleModule._AnsibleModule__display

# Generated at 2022-06-23 15:03:42.448865
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    fact_cache['test1'] = 'test1'
    fact_cache['test2'] = 'test2'
    assert fact_cache.copy() == {'test1': 'test1', 'test2': 'test2'}

# Generated at 2022-06-23 15:03:53.249957
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    key_to_cache = 'test_key'
    value_to_cache1 = dict({'first': 'first_value'})
    value_to_cache2 = dict({'second': 'second_value'})
    value_to_cache3 = dict({'third': 'third_value'})

    # Case when key is cached for first time
    fact_cache.first_order_merge(key_to_cache, value_to_cache1)
    assert fact_cache[key_to_cache] == value_to_cache1

    # Case when key is cached for second time
    fact_cache.first_order_merge(key_to_cache, value_to_cache2)

# Generated at 2022-06-23 15:03:55.247420
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    facts_cache = FactCache()
    facts_cache.copy()
    assert True



# Generated at 2022-06-23 15:04:03.338243
# Unit test for method copy of class FactCache
def test_FactCache_copy():

    # Inits the Class and test the copy method
    fact_cache = FactCache()
    fact_cache.flush()

    # Inits the class and test the copy method
    fact_cache = FactCache()
    fact_cache.flush()
    fact_cache['gather_subset'] = ['!all', 'network']
    fact_cache['gather_timeout'] = 0

    # Copy the content of the fact_cache
    res = fact_cache.copy()

    assert 'gather_subset' in res
    assert 'gather_timeout' in res
    assert res['gather_subset'] == ['!all', 'network']
    assert res['gather_timeout'] == 0

# Unit tests for the method keys of class FactCache

# Generated at 2022-06-23 15:04:10.017553
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    fact_cache.__setitem__('key1', 'value1')
    fact_cache.__setitem__('key2', 'value2')

    assert len(fact_cache.keys()) == 2
    assert 'key1' in fact_cache.keys()
    assert 'key2' in fact_cache.keys()
    assert 'key3' not in fact_cache.keys()


# Generated at 2022-06-23 15:04:21.058377
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    from ansible.errors import AnsibleError
    from ansible.plugins.loader import cache_loader

    plugin = cache_loader.get('memory')
    if not plugin:
        raise AnsibleError('Unable to load the facts cache plugin (memory).')

    fact_cache = FactCache(plugin)

    assert fact_cache.__contains__('/home/user/.ssh/id_rsa.pub') is False

    fact_cache.__setitem__('/home/user/.ssh/id_rsa.pub', 'ssh-rsa AAAA')
    assert fact_cache.__contains__('/home/user/.ssh/id_rsa.pub') is True

    fact_cache.__delitem__('/home/user/.ssh/id_rsa.pub')

# Generated at 2022-06-23 15:04:28.675284
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    import os
    import shutil
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.plugins.cache.jsonfile import CacheModule as JsonfileCacheModule

    temp_path = os.path.realpath(os.path.join(
        os.path.dirname(__file__), '..', '..', '..', '..', 'temp'
    ))

    first_key = 'first_key'
    second_key = 'second_key'
    first_value = {'first_value': 'value'}
    second_value = {'second_value': 'value'}

    plugin = JsonfileCacheModule()


# Generated at 2022-06-23 15:04:30.522545
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    result = FactCache()
    result2 = result.__len__()
    assert result2 == 0


# Generated at 2022-06-23 15:04:32.529761
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    cache = FactCache()
    cache['a'] = 1
    assert len(cache) == 1


# Generated at 2022-06-23 15:04:40.627372
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = FactCache()

    # delete the existing cache file
    from ansible.module_utils._text import to_bytes
    fact_cache._plugin._pc.delete(to_bytes(''))

    # set the cache file
    fact_cache['some_key'] = 'some_value'

    # get the cache file
    fact_cache_get = fact_cache['some_key']

    assert(fact_cache_get == 'some_value')

    # delete the cache file
    del fact_cache['some_key']

    # check if the cache file is deleted
    with pytest.raises(KeyError):
        fact_cache['some_key']


# Generated at 2022-06-23 15:04:44.236570
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fact_cache = FactCache()
    fact_cache['localhost'] = {'username': 'michael'}
    assert fact_cache['localhost'] == {'username': 'michael'}


# Generated at 2022-06-23 15:04:47.468794
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    host_cache = {1: 1, 2: 2, 3: 3}
    host_cache = FactCache(host_cache)
    host_cache.__iter__()


# Generated at 2022-06-23 15:04:51.786541
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    facts_cache = FactCache()
    facts_cache['test_copy'] = 'test_copy'
    cache_copy = facts_cache.copy()
    assert cache_copy.get('test_copy') == 'test_copy'


# Generated at 2022-06-23 15:04:57.308088
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    FAKE_CACHE_PLUGIN = {}
    fact_cache = FactCache()
    fact_cache._plugin = FAKE_CACHE_PLUGIN
    fact_cache["key"] = "value"
    fact_cache.__delitem__("key")
    assert len(FAKE_CACHE_PLUGIN) == 0


# Generated at 2022-06-23 15:04:58.422322
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-23 15:05:01.702924
# Unit test for constructor of class FactCache
def test_FactCache():
    print('Testing constructor of class FactCache')
    assert('cache' in dir(FactCache))
    assert('_plugin' in dir(FactCache))
    assert(isinstance(FactCache._plugin, object))


# Generated at 2022-06-23 15:05:05.602654
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    fact_cache['hostname'] = 'test'
    assert fact_cache.copy() == {'hostname': 'test'}



# Generated at 2022-06-23 15:05:07.440610
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    fact_cache.flush()

    assert len(fact_cache) == 0

# Generated at 2022-06-23 15:05:17.225171
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    from ansible.module_utils.six.moves.mock import MagicMock

    fact_cache = FactCache()
    fact_cache._plugin = MagicMock()

    key = 'localhost'
    value = {'os_facts': {'facts1': 1}}
    fact_cache.first_order_merge(key, value)

    assert fact_cache[key]['os_facts'] == {'facts1': 1}

    value = {'os_facts': {'facts1': 2, 'facts2': 2}}
    fact_cache.first_order_merge(key, value)

    assert fact_cache[key]['os_facts'] == {'facts1': 2, 'facts2': 2}

# Generated at 2022-06-23 15:05:19.565503
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    fact_cache['foo'] = 'bar'
    fact_cache.flush()
    assert 'foo' not in fact_cache


# Generated at 2022-06-23 15:05:24.597581
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    # 1. Define test case inputs
    key_list = ['1', '2', '3']
    plugin = MockPlugin(key_list)

    # 2. Create the object
    fact_cache = FactCache()
    fact_cache._plugin = plugin

    # 3. Run the test
    result = sorted(list(iter(fact_cache)))

    # 4. Verify the results
    assert result == ['1', '2', '3']
    assert plugin.keys_called



# Generated at 2022-06-23 15:05:27.300012
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    fact_cache.flush()

# Generated at 2022-06-23 15:05:36.234860
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    expected_key = 'fact_cache_key'
    expected_val = 'fact_cache_val'
    c = FactCache()
    c[expected_key] = expected_val
    # make sure we have correct key and value stored
    assert c[expected_key] == expected_val
    # make sure the copied dict has the same key and value as _cache
    assert c.copy() == dict(c)
    # make sure the key exists in _cache
    assert expected_key in c
    # make sure the key does not exist in the copy of _cache
    assert expected_key not in c.copy()

# Generated at 2022-06-23 15:05:39.415723
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fc = FactCache()
    fc.__setitem__('test_FactCache___contains__', True)
    assert 'test_FactCache___contains__' in fc



# Generated at 2022-06-23 15:05:41.692483
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    cache = FactCache()
    cache["foo"] = "bar"
    del cache["foo"]
    return cache

# Generated at 2022-06-23 15:05:44.541837
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    key = 'localhost'
    value = None
    fc = FactCache(key, value)
    assert isinstance(iter(fc), iter)


# Generated at 2022-06-23 15:05:45.527530
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    assert len(FactCache()) == 0

# Generated at 2022-06-23 15:05:48.177650
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    fc = FactCache()
    assert '_plugin' in fc
    assert '_plugin_error' in fc
    assert '_cache' not in fc


# Generated at 2022-06-23 15:05:50.980911
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()

    assert isinstance(fact_cache, FactCache)
    assert isinstance(fact_cache, MutableMapping)
    assert fact_cache.copy() == {}
    assert fact_cache.keys() == []

# Generated at 2022-06-23 15:05:52.152513
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    assert len(FactCache()) == 0


# Generated at 2022-06-23 15:05:55.206253
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    f = FactCache()
    f["localhost"] = {"free_memory": "128M"}
    assert f["localhost"]["free_memory"] == "128M"

# Generated at 2022-06-23 15:06:00.191088
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    cache_loader.set_fact_cache({'foo': 'bar'})
    cache_loader.set_fact_cache({'fizz': 'buzz'})
    assert len(cache_loader.fact_cache) == 2
    assert 'foo' in cache_loader.fact_cache
    assert 'fizz' in cache_loader.fact_cache



# Generated at 2022-06-23 15:06:07.781953
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    from collections import OrderedDict

    fact_cache = FactCache()
    fact_cache.__setitem__('localhost', OrderedDict())
    fact_cache.__setitem__('127.0.0.1', OrderedDict())

    fact_cache_copy = fact_cache.copy()

    expected_results = {'localhost': OrderedDict(), '127.0.0.1': OrderedDict()}
    assert fact_cache_copy == expected_results


# Generated at 2022-06-23 15:06:17.271466
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    plugin = FactCache()

# Generated at 2022-06-23 15:06:26.390532
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.loader import module_loader
    from ansible.vars.manager import VariableManager

    #This is needed for calling the _write_facts method in the plugin
    variable_manager = VariableManager()

    pb_executor = PlaybookExecutor(
        playbooks=[], inventory=InventoryManager(loader=DataLoader(), sources=['localhost,']), variable_manager=variable_manager, loader=DataLoader(),
        passwords={})


# Generated at 2022-06-23 15:06:32.407494
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    f = FactCache()
    f.__setitem__('key1', 'value1')
    f.__setitem__('key2', 'value2')
    f.__setitem__('key3', 'value3')
    f.__delitem__('key2')
    display.display(f)
    f.__delitem__('key3')
    f.__delitem__('key1')
    display.display(f)


# Generated at 2022-06-23 15:06:38.442578
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    # GIVEN
    test_facts = {"test_key": "test_value"}
    test_cache_plugin = FakeCache(test_facts)
    cache = FactCache()
    cache._plugin = test_cache_plugin
    # WHEN
    del cache["test_key"]
    # THEN
    assert cache["test_key"] is None


# Generated at 2022-06-23 15:06:40.986168
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    # test__contains__
    # test__contains__
    # TODO: implement your test here
    assert True # TODO: implement your test here


# Generated at 2022-06-23 15:06:44.582910
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache = FactCache()
    fact_cache["web001"] = "sample value"
    del fact_cache["web001"]
    assert not "web001" in fact_cache


# Generated at 2022-06-23 15:06:50.457023
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    global display
    display = mock.Mock()
    plugin_mock = mock.Mock()
    global_cache = FactCache(plugin=plugin_mock)
    global_cache['key'] = 'value'
    global_cache.__delitem__('key')
    plugin_mock.delete.assert_called_once_with('key')

# Generated at 2022-06-23 15:06:53.015360
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    cache = FactCache()
    cache['test'] = "test"
    assert(cache.copy() == {'test': 'test'})


# Generated at 2022-06-23 15:06:56.081295
# Unit test for method __iter__ of class FactCache
def test_FactCache___iter__():
    a = FactCache()
    a['1'] = '1'
    a['2'] = '2'
    a['3'] = '3'

    print(list(a))


# Generated at 2022-06-23 15:07:08.043833
# Unit test for method __contains__ of class FactCache
def test_FactCache___contains__():
    """ Unit test for method __contains__ of class FactCache. """

    # Create a new instance of FactCache.
    my_cache = FactCache()

    # Create a new instance of AnsibleModule.
    my_module = AnsibleModule()

    # Add one variable to the module
    my_module.params['my_key'] = 'my_value'

    # Add the variable from the module to the fact cache instance.
    my_cache[my_module.params['my_key']] = my_module

    # Test, if the key is in the fact cache instance
    my_cache__contains__ = my_cache.__contains__(my_module.params['my_key'])

    assert my_cache__contains__ is True



# Generated at 2022-06-23 15:07:12.153545
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    fact_cache = FactCache()
    fact_cache['key1'] = {'val1' : 1, 'val2' : 2}
    assert fact_cache.__contains__('key1')
    fact_cache.__delitem__('key1')
    assert not fact_cache.__contains__('key1')


# Generated at 2022-06-23 15:07:14.297791
# Unit test for constructor of class FactCache
def test_FactCache():
    facts = FactCache()
    assert isinstance(facts, FactCache)
    assert isinstance(facts, MutableMapping)


# Generated at 2022-06-23 15:07:18.019235
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    fact_cache = FactCache()
    fact_cache["key1"] = "value1"
    fact_cache["key2"] = "value2"
    fact_cache.flush()
    print(fact_cache["key1"])

test_FactCache_flush()

# Generated at 2022-06-23 15:07:21.741244
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    fact_cache = FactCache()
    assert fact_cache.keys() == None
    fact_cache['testing'] = 1
    assert fact_cache.keys() == ['testing']


# Generated at 2022-06-23 15:07:31.690556
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    fcache = FactCache()
    fcache['ansible_architecture'] = 'x86_64'
    if 'ansible_architecture' != fcache['ansible_architecture']:
        display.display('FAIL: fact ansible_architecture was not found in the fact cache.')
        return False

    fcache['ansible_architecture'] = 'i386'
    if 'i386' != fcache['ansible_architecture']:
        display.display('FAIL: fact ansible_architecture was not overwritten in the fact cache.')
        return False
    display.display('PASS: facts are overwriting in the fact cache.')
    return True


# Generated at 2022-06-23 15:07:32.640063
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    path = '/tmp/a/b/c'
    cache = FactCache(path)
    cache.flush()

# Generated at 2022-06-23 15:07:34.796890
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    cache = FactCache()
    cache['a']='test'
    del cache['a']
    assert cache['a'] == KeyError


# Generated at 2022-06-23 15:07:38.899348
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    fact_cache = FactCache()
    fact_cache['host'] = 'ansible'
    assert fact_cache.copy() == {'host': 'ansible'}
    assert fact_cache.copy() != {'host': 'ansible1'}

# Generated at 2022-06-23 15:07:42.903377
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    cache = FactCache({"host": {"val": 1}})
    value = cache["host"]
    cache["host"] = {"val": 2}
    new_value = cache["host"]

    assert new_value["val"] == 2
    assert value == new_value


# Generated at 2022-06-23 15:07:51.765727
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()

    test_host = 'hostname'

    # test no host
    assert fact_cache[test_host] == {}

    # test single host
    test_facts = {'fact_a': 'value_a'}
    fact_cache.first_order_merge(test_host, test_facts)
    assert fact_cache[test_host] == test_facts

    # test host merge
    more_facts = {'fact_b': 'value_b'}
    fact_cache.first_order_merge(test_host, more_facts)
    assert fact_cache[test_host] == {'fact_a': 'value_a', 'fact_b': 'value_b'}

    # test host update

# Generated at 2022-06-23 15:07:59.108508
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    # verify keys are returned in the same order as set
    fact_cache = FactCache()
    fact_cache["host1"] = {"a":1,"b":2}
    fact_cache["host2"] = {"a":2,"b":3}
    keys = fact_cache.keys()
    assert "host1" == keys[0]
    assert "host2" == keys[1]
    assert 2 == len(keys)


# Generated at 2022-06-23 15:08:02.606783
# Unit test for constructor of class FactCache
def test_FactCache():

    # set class variable to test for failure
    FactCache._plugin = None

    # test exception
    try:
        fact_cache = FactCache()
    except AnsibleError as e:
        err = e.__str__()
        assert 'Unable to load the facts cache plugin' in err

# Generated at 2022-06-23 15:08:09.687275
# Unit test for method __setitem__ of class FactCache
def test_FactCache___setitem__():
    from ansible.plugins.cache.jsonfile import CacheModule as jsonfile

    def test_jsonfile_set(self, key, value):
        self._data = {key: value}

    jsonfile.set = test_jsonfile_set

    try:
        my_fact_cache = FactCache()
        my_fact_cache['test_key'] = 'test_value'
        assert my_fact_cache['test_key'] == 'test_value'

    finally:
        # restore set
        jsonfile.set = jsonfile._set



# Generated at 2022-06-23 15:08:21.152268
# Unit test for method __delitem__ of class FactCache
def test_FactCache___delitem__():
    import pytest
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.plugins.loader import cache_loader

    class TestClass(cache_loader):
        def get(self, key):
            return TestClass.get(key)
        def set(self, key, value):
            TestClass.set(key, value)
        def delete(self, key):
            TestClass.delete(key)
        def contains(self, key):
            return TestClass.contains(key)
        def flush(self):
            TestClass.flush()

    class MutableMapping(MutableMapping):
        items = {}
        def __getitem__(self, key):
            return self.items[key]

# Generated at 2022-06-23 15:08:22.639630
# Unit test for constructor of class FactCache
def test_FactCache():

    myCache = FactCache()
    assert isinstance(myCache, FactCache)

# Generated at 2022-06-23 15:08:33.419426
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    host_cache = FactCache()
    host_facts = {'key1': {'fact1': 1, 'fact2': 2}, 'key2': {'fact1': 3, 'fact2': 4}}
    host_cache.update(host_facts)
    assert host_cache['key1'] == host_facts['key1']
    assert host_cache['key2'] == host_facts['key2']
    host_cache['key1']['fact3'] = 5
    assert host_cache['key1']['fact3'] == 5
    host_cache['key2']['fact3'] = 7
    assert host_cache['key2']['fact3'] == 7
    values = host_cache['key1']
    assert len(values) == 3
    assert values['fact1'] == 1

# Generated at 2022-06-23 15:08:36.916061
# Unit test for method copy of class FactCache
def test_FactCache_copy():
    cache = {
        'test1': {
            'a': 'b'
        }
    }
    f_cache = FactCache(cache)
    assert f_cache.copy() == cache

# Generated at 2022-06-23 15:08:39.731009
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    # Instantiate a new FactCache object and invoke it
    fact_cache = FactCache()
    fact_cache.flush()



# Generated at 2022-06-23 15:08:44.492210
# Unit test for method __len__ of class FactCache
def test_FactCache___len__():
    fc = FactCache()
    assert len(fc) == 0
    fc['host1'] = {'ansible_facts': {'foo': 'bar'}}
    assert len(fc) == 1
    fc.__delitem__('host1')
    assert len(fc) == 0


# Generated at 2022-06-23 15:08:46.234386
# Unit test for method keys of class FactCache
def test_FactCache_keys():
    cache = FactCache()
    assert isinstance(cache.keys(), list) or isinstance(cache.keys(), tuple)

# Generated at 2022-06-23 15:08:48.220660
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    '''
    Unit test for method __getitem__ of class FactCache
    '''
    FactCache = FactCache('test', 'test')

    assert False


# Generated at 2022-06-23 15:08:52.041479
# Unit test for method flush of class FactCache
def test_FactCache_flush():
    try:
        _FactCache = FactCache()
        _FactCache.flush()
    except Exception:
        raise AssertionError("flush method of class FactCache failed")


# Generated at 2022-06-23 15:09:01.365452
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Test case #1: key does not exist in fact_cache
    fact_cache = FactCache()
    key="ansible_lsb"
    value = {'distcodename': 'trusty', 'distdescription': 'Ubuntu 14.04.5 LTS', 'distid': 'Ubuntu', 'distrelease': '14.04', 'majdistrelease': '14.04'}
    fact_cache.first_order_merge(key, value)
    assert fact_cache["ansible_lsb"] == {'distcodename': 'trusty', 'distdescription': 'Ubuntu 14.04.5 LTS', 'distid': 'Ubuntu', 'distrelease': '14.04', 'majdistrelease': '14.04'}

    # Test case #2: key exist in fact_cache
    fact_cache = FactCache