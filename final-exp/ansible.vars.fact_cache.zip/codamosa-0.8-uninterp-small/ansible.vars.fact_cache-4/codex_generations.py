

# Generated at 2022-06-25 14:05:22.850972
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()


# Generated at 2022-06-25 14:05:24.324147
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    return fc


# Generated at 2022-06-25 14:05:27.453651
# Unit test for constructor of class FactCache
def test_FactCache():
  from ansible.plugins.cache.jsonfile import CacheModule as jsonfile
  from ansible.plugins.cache import FactCache
  fact_plugin = jsonfile()
  fact_cache = FactCache(plugin = fact_plugin)
  assert fact_cache._plugin == fact_plugin


# Generated at 2022-06-25 14:05:34.965453
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    test_fact_cache_1 = FactCache()

    test_fact_cache_1.first_order_merge('test_host',{'a':123})
    assert test_fact_cache_1['test_host']['a'] == 123

    test_fact_cache_1.first_order_merge('test_host',{'b':456})

    assert test_fact_cache_1['test_host']['a'] == 123
    assert test_fact_cache_1['test_host']['b'] == 456


# Generated at 2022-06-25 14:05:44.533845
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge('key_0', 'value_0')
    assert 'key_0' in fact_cache_0
    assert fact_cache_0['key_0'] == 'value_0'

    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge('key_1', 'value_1')
    assert 'key_1' in fact_cache_1
    assert fact_cache_1['key_1'] == 'value_1'

    fact_cache_2 = FactCache()
    fact_cache_2.first_order_merge('key_2', 'value_2')
    assert 'key_2' in fact_cache_2

# Generated at 2022-06-25 14:05:48.029972
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    # First define test arguments
    # Second define expected results

    key = "key"
    value = "value"
    test_result = None

    fact_cache = FactCache()
    result = fact_cache.first_order_merge(key, value)


# Generated at 2022-06-25 14:05:49.859720
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    return fact_cache_0


# Generated at 2022-06-25 14:05:52.401171
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0

# Unit tests for '__getitem__' method of class FactCache

# Generated at 2022-06-25 14:05:56.278248
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge("key", "value")
    assert fact_cache_1["key"] == "value"


# Generated at 2022-06-25 14:05:59.336282
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
  # This test should initialize a new instance of class FactCache
  # then call the first_order_merge method of that instance
  # and check the return value against the expected value
  print("Test not implemented")


# Generated at 2022-06-25 14:06:04.297258
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
# Validate that 'plugin' member of class FactCache is correctly set
    test_case_0()
    if(fact_cache_0._plugin):
        pass
    else:
        raise AssertionError()

# Generated at 2022-06-25 14:06:13.172551
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import os.path
    import sys
    import unittest

    try:
        import __main__ as main
    except ImportError:
        main = sys.modules['__main__']

    main.__file__ = os.path.abspath(__file__)

    import ansible.plugins.cache.fact_cache

    fact_cache_0 = FactCache()
    key_0 = ""
    value_0 = ""

    with unittest.mock.patch.object(ansible.plugins.cache.fact_cache.FactCache, 'first_order_merge') as mock_method:

        # Call method
        return_value = fact_cache_0.first_order_merge(key_0, value_0)

        # Check return value
        assert return_value is None

        # Check if method was called


# Generated at 2022-06-25 14:06:14.076830
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

# Generated at 2022-06-25 14:06:20.146447
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge("a.example.com", {"ansible_os_family": "Debian"})
    result = fact_cache_0.keys()
    assert result == ["a.example.com"]
    assert fact_cache_0["a.example.com"] == {"ansible_os_family":"Debian"}

# Generated at 2022-06-25 14:06:23.385994
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert(isinstance(fact_cache_0, MutableMapping))


# Generated at 2022-06-25 14:06:27.261965
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    # Method invocation without params
    fact_cache = FactCache()
    fact_cache.first_order_merge('key', 'value')

    # Method invocation with params
    key = 'key'
    value = 'value'
    fact_cache.first_order_merge(key, value)



# Generated at 2022-06-25 14:06:28.601733
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache


# Generated at 2022-06-25 14:06:32.287457
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache._plugin, cache_loader.get(C.CACHE_PLUGIN))
    assert len(fact_cache._plugin.keys()) == 0
    assert fact_cache._plugin.flush() is None

# Generated at 2022-06-25 14:06:34.487589
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    test_case_0()
    FactCache_obj = FactCache()
    FactCache_obj.first_order_merge(key="foo",value="bar")


# Generated at 2022-06-25 14:06:36.630143
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    my_key = 'localhost'
    my_value = 'ansible'
    host_cache = {'localhost': 'ansible'}
    fact_cache.first_order_merge(my_key, my_value)
    assert fact_cache._plugin._cache[my_key] == host_cache

# Generated at 2022-06-25 14:06:46.243228
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    a = FactCache()

    # test_case_1
    a['a'] = 1
    b = {'x': 2, 'y': 3}
    a.first_order_merge('a', b)
    assert a['a'] == {'x': 2, 'y': 3, 'a': 1}
    del a['a']

    # test_case_2
    a['a'] = 1
    b = {'a': 2}
    a.first_order_merge('a', b)
    assert a['a'] == {'a': 2}
    del a['a']

    # test_case_3
    a['a'] = 1
    b = {'a': {'b': 'c'}}
    a.first_order_merge('a', b)
    assert a['a']

# Generated at 2022-06-25 14:06:52.519349
# Unit test for constructor of class FactCache
def test_FactCache():
    # Create object of FactCache
    fc = FactCache()

    # Create object of FactCache
    fc2 = FactCache()

    # If the FactCache object is mutable, comparing the original and copy should fail
    assert fc == fc2


if __name__ == '__main__':
    test_FactCache()
    test_case_0()

# Generated at 2022-06-25 14:06:54.503084
# Unit test for constructor of class FactCache
def test_FactCache():

    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)



# Generated at 2022-06-25 14:07:00.605349
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    my_fact_cache = FactCache()

    my_fact_cache.first_order_merge("key1","value1")
    my_fact_cache.first_order_merge("key1","value1")
    my_fact_cache.first_order_merge("key2","value2")
    assert my_fact_cache.first_order_merge("key2","value2")[key1]=="value1"

# Generated at 2022-06-25 14:07:01.436125
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()


# Generated at 2022-06-25 14:07:03.574576
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        test_case_0()
    except Exception as e:
        display.error(str(e))

if __name__ == "__main__":
    test_FactCache()

# Generated at 2022-06-25 14:07:13.603007
# Unit test for constructor of class FactCache
def test_FactCache():
    display.display('--- TEST: Constructor of class FactCache ---')
    display.display('initialize fact_cache_0.')
    fact_cache_0 = FactCache()
    value = {}
    display.display('update key: 10.10.10.11 with value: {}'.format(value))
    fact_cache_0['10.10.10.11'] = value
    display.display('update key: 10.10.10.11 with value: {}'.format(value))
    fact_cache_0['10.10.10.11'] = value
    display.display(fact_cache_0.keys())


# Generated at 2022-06-25 14:07:16.238433
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0._plugin == None
    assert fact_cache_0._plugin == None
    assert fact_cac

# Generated at 2022-06-25 14:07:17.222264
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()

# Generated at 2022-06-25 14:07:19.087226
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, MutableMapping)


# Generated at 2022-06-25 14:07:24.213720
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    host_cache = {'a': 'apple', 'b': 'banana'}
    fact_cache_0.first_order_merge('localhost', host_cache)
    assert fact_cache_0['localhost'] == host_cache

# Generated at 2022-06-25 14:07:30.414197
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge('test_key', 'test_value')
    fact_cache_0.first_order_merge('test_key', 'test_value_0')
    fact_cache_0.first_order_merge('test_key_0', 'test_value_0')


# Generated at 2022-06-25 14:07:31.454185
# Unit test for constructor of class FactCache
def test_FactCache():

    test_case_0()
    print('OK')

# Generated at 2022-06-25 14:07:41.558318
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Create a new instance of a FactCache
    fact_cache_1 = FactCache()
    # Check the number of known keys in the FactCache
    assert len(fact_cache_1) == 0
    # Add a new key/value pair to the FactCache
    fact_cache_1.first_order_merge("test_key_0", "test_value_0")
    # Check that the key was added successfully
    assert fact_cache_1["test_key_0"] == "test_value_0"
    # Check that the FactCache length was updated
    assert len(fact_cache_1) == 1
    # Add a new key/value pair to the FactCache
    fact_cache_1.first_order_merge("test_key_1", "test_value_1")
    # Check that the key was added successfully


# Generated at 2022-06-25 14:07:42.506774
# Unit test for constructor of class FactCache
def test_FactCache():
    assert fact_cache_0 != None


# Generated at 2022-06-25 14:07:44.637147
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        fact_cache_0 = FactCache()
    except Exception as e:
        print(e)


# Generated at 2022-06-25 14:07:51.281491
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge(key='myhost', value={'ansible_distribution': 'RedHat', 'ansible_distribution_version': '7.6', 'ansible_kernel': '3.10.0-957.el7.x86_64', 'ansible_machine': 'x86_64', 'ansible_os_family': 'RedHat'})

# Generated at 2022-06-25 14:08:01.643451
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    display.display("Test of method first_order_merge of class FactCache")
    fact_cache = FactCache()
    fact_cache.first_order_merge("1.1.1.1", {'foo': 'bar'})
    if not "1.1.1.1" in fact_cache:
        exit("Test failed: missing host_cache for 1.1.1.1")
    if not fact_cache["1.1.1.1"]['foo'] == 'bar':
        exit("Test failed: host_cache for 1.1.1.1 should be {'foo': 'bar'}, but was : " + str(fact_cache["1.1.1.1"]))
    fact_cache.flush()

# Generated at 2022-06-25 14:08:04.468090
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # given
    fact_cache = FactCache()
    data = {"hello": "world"}

    # when
    fact_cache.first_order_merge('1', data)

    # then
    assert '1' in fact_cache
    assert fact_cache['1']['hello'] == 'world'


# Generated at 2022-06-25 14:08:06.037803
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)

# Generated at 2022-06-25 14:08:17.686913
# Unit test for constructor of class FactCache
def test_FactCache():

    from ansible.module_utils._text import to_text

    # Constructor test case 0
    test_case_0()

    # Constructor test case 1
    fact_cache_1 = FactCache(plugin_name='jsonfile')
    assert fact_cache_1

    # Constructor test case 2
    fact_cache_2 = FactCache(plugin_name='redis')
    assert fact_cache_2

    # Constructor test case 3
    fact_cache_3 = FactCache(plugin_name='yaml')
    assert fact_cache_3

    assert isinstance(fact_cache_3.keys(), list)
    assert isinstance(fact_cache_3[u'localhost'], dict)

# Generated at 2022-06-25 14:08:18.795256
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert isinstance(fc, FactCache)

# Generated at 2022-06-25 14:08:26.334183
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    key = "ABCDEFG-hostname-0"
    value = {"ansible_os_family": "RedHat"}
    fact_cache_0.first_order_merge(key, value)
    assert fact_cache_0["ABCDEFG-hostname-0"]["ansible_os_family"] == "RedHat"


# Generated at 2022-06-25 14:08:29.115957
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        fact_cache_0 = FactCache()
        display.display('Passed: test_FactCache')
    except:
        display.display('Failed: test_FactCache')


# Generated at 2022-06-25 14:08:32.247742
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        fact_cache = FactCache()
    except AnsibleError as e:
        assert 'Unable to load the facts cache' in e.message


# Generated at 2022-06-25 14:08:33.616615
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()


# Generated at 2022-06-25 14:08:35.610056
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge('localhost', {})


# Generated at 2022-06-25 14:08:37.528877
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()
    assert fact_cache_1._plugin.contains('local') == False
    assert fact_cache_1._plugin.contains('network') == False
    assert fact_cache_1._plugin.contains('system') == False


# Generated at 2022-06-25 14:08:38.402069
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache != None


# Generated at 2022-06-25 14:08:40.393013
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0._plugin is not None
    assert isinstance(fact_cache_0._plugin, cache_loader.get(C.CACHE_PLUGIN))


# Generated at 2022-06-25 14:08:48.127752
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)
    print("Test of FactCache constructor passed")


# Generated at 2022-06-25 14:08:49.906182
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)


# Generated at 2022-06-25 14:08:59.452261
# Unit test for constructor of class FactCache
def test_FactCache():
   fact = FactCache()

   # Test the constructor
   try:
      fact = FactCache()
   except:
      pass
   # Test the method __getitem__
   try:
      fact.__getitem__("key1")
   except:
      pass

   # Test the method __setitem__
   try:
      fact.__setitem__("key1", "value1")
   except:
      pass

   # Test the method __delitem__
   try:
      fact.__delitem__("key1")
   except:
      pass

   # Test the method __contains__
   try:
      fact.__contains__("key1")
   except:
      pass

   # Test the method __iter__
   try:
      fact.__iter__()
   except:
      pass

   # Test the

# Generated at 2022-06-25 14:09:04.550198
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        test_case_0()
    except (AnsibleError) as e:
        display.display('Error: %s' % str(e), color='red')
        display.display('Failed to create an instance of class FactCache', color='red')
        return False

    return True

# Generated at 2022-06-25 14:09:10.871271
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # AnsibleFacts({"ip_addresses": ["192.168.1.100","192.168.1.101"] , "my_value" : "my_text"})
    input0 = {
        "ip_addresses": ["192.168.1.100", "192.168.1.101"],
        "my_value": "my_text"
    }
    expected_output = {
        "ip_addresses": ["192.168.1.100", "192.168.1.101"],
        "my_value": "my_text"
    }
    assert FactCache.first_order_merge("ip_addresses", input0) == expected_output

# Generated at 2022-06-25 14:09:21.976087
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge('some_key', 'some_value')
    fact_cache_0.first_order_merge('another_key', 'another_value')
    fact_cache_0.first_order_merge('some_key', 'some_value')

    # Asserting that second occurrence of key does not overwrite
    # first one's value
    assert(fact_cache_0.get('some_key') == 'some_value')
    assert(fact_cache_0.get('another_key') == 'another_value')


if __name__ == '__main__':
    import sys
    if sys.argv[1] == 'test_case_0':
        test_case_0()

# Generated at 2022-06-25 14:09:25.164760
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    host_facts = 'test'
    key = 'test'
    value = 'test'
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge(key, value)


# Generated at 2022-06-25 14:09:26.709280
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache1 = FactCache()
    print(fact_cache1)


# Generated at 2022-06-25 14:09:29.004174
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    d = {'test_fact': 'test_value'}
    fc.first_order_merge('host0', d)
    assert fc['host0'] == d

# Generated at 2022-06-25 14:09:30.771359
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        result = True
    except Exception as e:
        result = False
    assert result == True


# Generated at 2022-06-25 14:09:46.887894
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        test_case_0()
    except:
        # TODO: catch specific exception
        raise AssertionError()

# Generated at 2022-06-25 14:09:48.459349
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()
    assert fact_cache_1._plugin == 'jsonfile'


# Generated at 2022-06-25 14:09:53.197523
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    CACHE_PLUGIN = 'memory'
    fact_cache_0 = FactCache()
    key_0 = 'key'
    value_0 = 'value'
    fact_cache_0.first_order_merge(key_0,value_0)
    fact_cache_0.set('key','value')
    assert fact_cache_0.get('key') == 'value'
    fact_cache_0.delete('key')
    assert fact_cache_0.get('key') is None

# Generated at 2022-06-25 14:09:56.044360
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.flush()
    fact_cache_0.first_order_merge('key_0', 'value_0')

if __name__ == '__main__':
    test_FactCache_first_order_merge()

# Generated at 2022-06-25 14:09:58.563491
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    fact_cache.flush()
    fact_cache.flush()
    fact_cache.flush()


# Generated at 2022-06-25 14:09:59.429183
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()

# Generated at 2022-06-25 14:10:08.901398
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    fact_cache_1= FactCache()
    test_input_key = 'test_key'
    test_input_value1 = 'test_value1'
    test_input_value2 = 'test_value2'
    test_value_expected = {'test_key': {'test_key': 'test_value2'}}

    # Before adding a key value pair to the fact cache,
    # the first_order_merge shold raise KeyError exception.
    try:
        fact_cache_1.first_order_merge(test_input_key, test_input_value1)
    except KeyError:
        pass

    # Add a Key-value pair in the fact cache.
    fact_cache_1.update({test_input_key:test_input_value1})

    # Test first_order_merge

# Generated at 2022-06-25 14:10:09.618620
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

# Generated at 2022-06-25 14:10:11.200772
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache,MutableMapping)


# Generated at 2022-06-25 14:10:12.488826
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache(('key', 'val'))


# Generated at 2022-06-25 14:10:45.945855
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    """
    Asserts for an empty cache, the value is stored without any changes
    """
    fact_cache = FactCache()
    fact_cache.first_order_merge("x", "y")
    assert fact_cache.get("x") == "y"


# Generated at 2022-06-25 14:10:47.070771
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache(**{"": {}})


# Generated at 2022-06-25 14:10:48.470820
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert len(fact_cache) == 0


# Generated at 2022-06-25 14:10:53.925297
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        from ansible.vars.fact_cache import FactCache
        fact_cache = FactCache()
        print("fact_cache: %s" % fact_cache)
        print("fact_cache.keys(): %s" % fact_cache.keys())
        print("fact_cache.copy(): %s" % fact_cache.copy())
    except Exception as e:
        print("Unable to test_FactCache: %s" % e)



# Generated at 2022-06-25 14:10:55.085997
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_test = FactCache()
    assert fact_cache_test is not None

# Generated at 2022-06-25 14:10:59.674402
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    hostname = "some_host"
    key = "ansible_local.test"
    value = "Hello World"
    fact_cache_0.first_order_merge(key=key, value=value)
    fact_cache_0.first_order_merge(key=key, value="foo")
    assert fact_cache_0._plugin.contains("cache_path") == False


# Generated at 2022-06-25 14:11:00.260554
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

# Generated at 2022-06-25 14:11:04.450496
# Unit test for constructor of class FactCache
def test_FactCache():

    result = True
    try:
        fact_cache_1 = FactCache()
    except Exception as e:
        print(e.message)
        result = False

    if result:
        print('{0} passed'.format(test_case_0.__name__))
    else:
        print('{0} failed'.format(test_case_0.__name__))

if __name__ == '__main__':
    test_FactCache()

# Generated at 2022-06-25 14:11:15.042019
# Unit test for method first_order_merge of class FactCache

# Generated at 2022-06-25 14:11:15.691716
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    test_case_0()



# Generated at 2022-06-25 14:12:21.495085
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()

    assert fact_cache_0 is not None


# Generated at 2022-06-25 14:12:29.374585
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    values = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    for key in values:
        fact_cache_0[key] = values[key]

    # check if len returns correct number of elements in the dictionary
    assert len(fact_cache_0) == len(values)

    # check if contains returns True for every key
    for key in values:
        assert key in fact_cache_0

    # check if __getitem__ returns the item corresponding to the key
    for key in values:
        assert fact_cache_0[key] == values[key]

    # check if __setitem__ sets the value for the key

# Generated at 2022-06-25 14:12:30.498991
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert True


# Generated at 2022-06-25 14:12:34.903577
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge('hostname', {'an integer': 1, 'a float': 3.14159265358979,
                                                'a list': [1, 2, 3, 4], 'a dict': {'key_1': 'a string',
                                                                                 'key_2': 'another string'}})

    fact_cache_2 = FactCache()

# Generated at 2022-06-25 14:12:36.684117
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    key = DataObject()
    value = DataObject()
    fact_cache_0.first_order_merge(key, value)


# Generated at 2022-06-25 14:12:37.452665
# Unit test for constructor of class FactCache
def test_FactCache():
    assert not test_case_0()

# Generated at 2022-06-25 14:12:40.904709
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    print("testing first_order_merge")

    fact_cache_1 = FactCache()
    host_facts = {"localhost": {"ansible_all_ipv4_addresses": ["10.0.2.15", "192.168.8.18"]}}
    fact_cache_1.first_order_merge("ansible_all_ipv4_addresses", host_facts)
    fact_cache_1["ansible_all_ipv4_addresses"]

    fact_cache_2 = FactCache()
    host_facts = {"localhost": {"ansible_all_ipv4_addresses": ["10.0.2.15", "192.168.8.18"]}}
    fact_cache_2.first_order_merge("ansible_all_ipv4_addresses", host_facts)
   

# Generated at 2022-06-25 14:12:41.895776
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0.__class__ == FactCache


# Generated at 2022-06-25 14:12:42.894514
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        fact_cache_0 = FactCache()
    except:
        assert False



# Generated at 2022-06-25 14:12:49.914224
# Unit test for constructor of class FactCache
def test_FactCache():

    # Invalid cache plugin
    try:
        cache_loader.get('not_a_plugin')
    except AnsibleError as e:
        msg = "Unable to load the facts cache plugin (not_a_plugin)."
        assert str(e) == msg

    # Default cache plugin
    assert cache_loader.get(C.CACHE_PLUGIN)

    f = FactCache()

    assert 'host' in f
    try:
        assert 'host2' in f
    except KeyError as e:
        assert str(e) == 'host2'
    assert 'host' in f.keys()
    assert 'host' in f.copy()
    assert 'host' in f.copy().keys()
    assert len(f) == 1
    assert len(f.keys()) == 1

# Generated at 2022-06-25 14:15:25.302602
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    from ansible.module_utils.facts.virtual import VirtualFactCollector
    from ansible.module_utils.facts.system import SystemFactCollector

    fact_cache_1 = FactCache()
    value_1 = dict()
    key_1 = 'test_value_1'
    fact_cache_1.first_order_merge(key_1, value_1)
    assert fact_cache_1.get(key_1) == value_1

    value_2 = dict()
    key_2 = 'test_value_2'
    fact_cache_1.first_order_merge(key_2, value_2)
    assert fact_cache_1.get(key_2) == value_2

    value_3 = dict()
    key_3 = 'test_value_3'
    fact_cache_