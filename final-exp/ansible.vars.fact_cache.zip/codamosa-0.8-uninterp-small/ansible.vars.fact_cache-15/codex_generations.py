

# Generated at 2022-06-25 14:05:20.657846
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()

# Generated at 2022-06-25 14:05:22.049337
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    assert fact_cache_0.first_order_merge('key_0', 'value_0') == None



# Generated at 2022-06-25 14:05:25.694108
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('1.2.3.4', {'ansible_os_family': 'Redhat'})
    assert fact_cache['1.2.3.4']['ansible_os_family'] == 'Redhat'


# Generated at 2022-06-25 14:05:35.355451
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()

# Generated at 2022-06-25 14:05:44.864185
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0 == {}
    fact_cache_0['ansible_local'] = {'a': '1', 'b': '2', 'c': '3'}
    assert fact_cache_0['ansible_local'] == {'a': '1', 'b': '2', 'c': '3'}
    assert fact_cache_0.keys() == ['ansible_local']
    fact_cache_0.flush()
    assert fact_cache_0.keys() == []
    assert fact_cache_0 == {}
    fact_cache_1 = FactCache()
    fact_cache_1['ansible_local'] = {'a': '1', 'b': '2'}

# Generated at 2022-06-25 14:05:46.552216
# Unit test for constructor of class FactCache
def test_FactCache():

    fc = {}
    fact_cache_1 = FactCache(fc)



# Generated at 2022-06-25 14:05:57.816517
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()

    # Test with existing facts
    fact_cache['host0'] = {'ansible_facts': {'one': 'one_fact', 'two': 'two_fact'}}
    fact_cache.first_order_merge('host0', {'ansible_facts': {'one': 'one_test', 'three': 'three_test'}})
    assert fact_cache['host0']['ansible_facts']['one'] == 'one_test'
    assert fact_cache['host0']['ansible_facts']['two'] == 'two_fact'
    assert fact_cache['host0']['ansible_facts']['three'] == 'three_test'

    # Test with non existing facts

# Generated at 2022-06-25 14:05:59.622454
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)


# Generated at 2022-06-25 14:06:00.614334
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()

# Generated at 2022-06-25 14:06:02.205183
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:06:06.153776
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()

# Generated at 2022-06-25 14:06:07.128244
# Unit test for constructor of class FactCache
def test_FactCache():
    assert callable(FactCache)


# Generated at 2022-06-25 14:06:08.096467
# Unit test for constructor of class FactCache
def test_FactCache():
  test_cache = FactCache()


# Generated at 2022-06-25 14:06:09.063018
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

# Generated at 2022-06-25 14:06:12.577487
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    # Test case for first_order_merge method of class FactCache
    fact_cache_0.first_order_merge("hostname", {"ansible_all_ipv4_addresses": ["::", "127.0.1.1"]})


# Generated at 2022-06-25 14:06:14.204931
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

if __name__ == '__main__':
    test_FactCache()

# Generated at 2022-06-25 14:06:15.116345
# Unit test for constructor of class FactCache
def test_FactCache():
    FactCache()


# Generated at 2022-06-25 14:06:19.964931
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('kallithea.ansible.com', {'ansible_env': {'HOME': '/root', 'PATH': '/usr/bin:/opt/bin'}, 'ansible_check_mode': False})


# Generated at 2022-06-25 14:06:24.913482
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge('testkey', {'testkey': 'nginx'})
    assert fact_cache_0['testkey']['testkey'] == 'nginx'


# Generated at 2022-06-25 14:06:27.305949
# Unit test for constructor of class FactCache
def test_FactCache():
    """
    test_FactCache: Tests for the constructor of class FactCache

    :return:
    """
    assert test_case_0() == None



# Generated at 2022-06-25 14:06:33.832501
# Unit test for constructor of class FactCache
def test_FactCache():
    assert FactCache().__init__()

# Generated at 2022-06-25 14:06:35.631899
# Unit test for constructor of class FactCache
def test_FactCache():
    # Call the constructor of class FactCache
    fact_cache = FactCache()
    assert bool(fact_cache)


# Generated at 2022-06-25 14:06:36.533909
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()

# Generated at 2022-06-25 14:06:38.878569
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert len(fact_cache) == 0
    display.display('test_FactCache constructor PASSED.')


# Generated at 2022-06-25 14:06:43.217260
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge('192.0.2.1', {'ansible_facts': {'foo': 'bar'}})
    assert(fact_cache_1['192.0.2.1'] == {'ansible_facts': {'foo': 'bar'}})


# Generated at 2022-06-25 14:06:50.183866
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()

# Generated at 2022-06-25 14:06:51.192363
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

# Generated at 2022-06-25 14:06:55.089962
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge('key_0', 'value_0')
    assert fact_cache_0['key_0'] == 'value_0'


# Generated at 2022-06-25 14:06:57.953857
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    assert fact_cache_0.first_order_merge('foobar', 'foobar') == None


# Generated at 2022-06-25 14:06:58.724013
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:07:22.351626
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Test two empty caches
    fact_cache_0 = FactCache()
    fact_cache_1 = FactCache()
    host_cache = {'hostname': 'testhost0'}
    fact_cache_0.first_order_merge('testhost0', host_cache)
    assert fact_cache_0['testhost0'] == host_cache
    fact_cache_1.first_order_merge('testhost0', host_cache)
    assert fact_cache_1['testhost0'] == host_cache
    fact_cache_0.flush()
    fact_cache_1.flush()

    # Test first empty cache and second cache with data
    fact_cache_0 = FactCache()
    fact_cache_1 = FactCache()
    host_cache = {'hostname': 'testhost1'}
    fact

# Generated at 2022-06-25 14:07:26.878541
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        test_case_0()

    except Exception as e:
        display.display('%s' % (type(e)))
        display.display('%s' % (e))
        raise

if __name__ == '__main__':
    test_FactCache()

# Generated at 2022-06-25 14:07:36.979740
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        import pylint
        from pylint import interfaces
        from pylint import checkers
        from pylint.reporters import text
    except:
        print("SKIP: pylint not available")
        return
    linter = pylint.lint.PyLinter()
    linter.register_checker(checkers.BaseChecker)
    linter.set_reporter(text.ParseableTextReporter())
    linter.set_option('output-format', 'parseable')
    linter.load_plugin_modules(['pylint_ansible.checks'])
    linter.load_default_plugins()
    linter.set_option('reports', False)

# Generated at 2022-06-25 14:07:38.843808
# Unit test for constructor of class FactCache
def test_FactCache():
   fact_cache_obj = FactCache()
   assert fact_cache_obj._plugin.cache_name == 'memory'


# Generated at 2022-06-25 14:07:47.893878
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    '''
    Unit test for method first_order_merge of class FactCache
    '''
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge("aaa", {"a":"b"})
    fact_cache_1.first_order_merge("aaa", {"c":"d"})
    fact_cache_1.first_order_merge("aaa", {"a":"b"})
    fact_cache_1.first_order_merge("bbb", {"a":"c"})
    assert fact_cache_1["aaa"] == {"a":"b", "c":"d"}
    assert fact_cache_1["bbb"] == {"a":"c"}

# Generated at 2022-06-25 14:07:51.922955
# Unit test for constructor of class FactCache
def test_FactCache():
    '''Test constructor of FactCache'''

    # test with existing data in the fact cache
    fact_cache = FactCache()
    fact_cache.flush()
    fact_cache['name'] = 'fact_cache'
    assert fact_cache['name'] == 'fact_cache'



# Generated at 2022-06-25 14:07:55.665182
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge('foo', {'vagrant': 'vagrant'})
    assert fact_cache_0.get('foo')['vagrant'] == 'vagrant'

# Generated at 2022-06-25 14:08:00.850817
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    # Assign target_host a value
    target_host = "target_host"
    # Assign target_facts a value
    target_facts = {}
    # Call first_order_merge of fact_cache_0 with args target_host and target_facts
    fact_cache_0.first_order_merge(target_host, target_facts)



# Generated at 2022-06-25 14:08:09.545360
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    fact_cache_1 = FactCache()

    # This is a test case to check how well it merges

    fact_cache_1['host_0'] = {'test': 'host_0_data'}
    fact_cache_1['host_0'].update({'test2': 'host_0_data2'})

    fact_cache_1.first_order_merge('host_0', {'test': 'new_data'})
    assert fact_cache_1['host_0']['test'] == 'new_data'

    fact_cache_1.first_order_merge('host_0', {'test3': 'new_data3'})
    assert fact_cache_1['host_0']['test3'] == 'new_data3'

    fact_cache_1.first_order_mer

# Generated at 2022-06-25 14:08:10.937176
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert len(fact_cache) == 0


# Generated at 2022-06-25 14:08:38.805251
# Unit test for constructor of class FactCache
def test_FactCache():
    input0 = dict()
    expected_result = dict()
    # Note the empty dict(\{\}) ensures that fact_cache_0 is a variable with type FactCache, thus an instance of class FactCache.
    fact_cache_0 = FactCache(input0)
    actual_result = fact_cache_0
    assert(actual_result == expected_result)


# Generated at 2022-06-25 14:08:39.442689
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()

# Generated at 2022-06-25 14:08:40.618811
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)


# Generated at 2022-06-25 14:08:45.945685
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    key_1 = 'localhost'
    value_1 = 'foo'
    fact_cache_1.first_order_merge(key_1, value_1)

    from math import pow
    fact_cache_2 = FactCache()
    key_2 = 'localhost'
    value_2 = pow
    fact_cache_2.first_order_merge(key_2, value_2)


# Generated at 2022-06-25 14:08:47.599055
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

if __name__ == '__main__':
    test_FactCache()

# Generated at 2022-06-25 14:08:50.864657
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    key_1 = 'hostname'
    value_1 = 'ansible-controller'
    fact_cache_1.first_order_merge(key_1, value_1)



# Generated at 2022-06-25 14:08:53.011367
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge('key', 'value')


# Generated at 2022-06-25 14:09:03.687547
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()

# Generated at 2022-06-25 14:09:06.332616
# Unit test for constructor of class FactCache
def test_FactCache():
    from collections import MutableMapping
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)
    assert isinstance(fact_cache, MutableMapping)


# Generated at 2022-06-25 14:09:07.812770
# Unit test for constructor of class FactCache
def test_FactCache():

    # Make sure the object does not raise any exceptions
    obj = FactCache()
    display.display(obj)

# Generated at 2022-06-25 14:09:59.056744
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()

# Generated at 2022-06-25 14:10:08.595244
# Unit test for constructor of class FactCache
def test_FactCache():
    print('json_path = ',C.CACHE_PLUGIN)
    fact_cache = FactCache()
    hosts = ['172.16.1.1','172.16.1.2','172.16.1.3','172.16.1.4','172.16.1.5','172.16.1.6','172.16.1.7','172.16.1.8']
    for host in hosts:
        fact_cache[host] = host
    fact_cache['172.16.1.1'] = 'out2-default'
    print('fact_cache.keys() = ',fact_cache.keys())
    print('fact_cache[\'172.16.1.1\'] = ',fact_cache['172.16.1.1'])
    fact_cache.flush()

# Generated at 2022-06-25 14:10:09.321759
# Unit test for constructor of class FactCache
def test_FactCache():
    obj = FactCache()


# Generated at 2022-06-25 14:10:18.999932
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()
# for the first time there is no data in cache
    assert(len(fact_cache_1) == 0)
    assert(not fact_cache_1.__contains__('host1'))
# make sure that data that is not present raises KeyError
    try:
        fact_cache_1.__getitem__('host1')
    except KeyError:
        print('KeyError raised')
# put some data into cache
    fact_cache_1.__setitem__('host1', 'host1_data')
    assert(fact_cache_1.__contains__('host1'))
    assert(fact_cache_1.__getitem__('host1') == 'host1_data')
# put more data into cache

# Generated at 2022-06-25 14:10:23.670544
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    host_0 = "host_0"
    host_facts_0 = {"hostvars_0": "hostvars_0"}
    fact_cache_0.first_order_merge(host_0, host_facts_0)

# Generated at 2022-06-25 14:10:26.720073
# Unit test for constructor of class FactCache
def test_FactCache():    
    # fact_cache_0 = FactCache()
    print('Test case 0:  instance of fact cache is created')
    print('fact_cache: ', fact_cache_0)
    print('###########################')
    print('###########################')


# Generated at 2022-06-25 14:10:34.326431
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    import os
    import tempfile
    # Test to see is Ansible can find/load the plugin.
    plugin_path = os.path.join(C.DEFAULT_LOCAL_TMP, "ansible_fact_cache.cache")
    if fact_cache._plugin is None:
        assert False, "Could not loa the plugin."
    # Test the constructor, it should not overwrite the data file.
    datafile = tempfile.NamedTemporaryFile()
    fact_cache._plugin.set_datafile(datafile.name)
    fact_cache._plugin.set("test", "value")
    fact_cache = FactCache()
    assert fact_cache._plugin.get("test") != "value", "Should not overwrite the data file."
    # Test the constructor, it should not overwrite the data

# Generated at 2022-06-25 14:10:35.411420
# Unit test for constructor of class FactCache
def test_FactCache():

    fact_cache = FactCache()
    assert type(fact_cache) == FactCache


# Generated at 2022-06-25 14:10:36.171987
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

# Generated at 2022-06-25 14:10:40.552910
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge('192.168.0.1', {'foo': 'bar'})
    fact_cache_1.first_order_merge('192.168.0.1', {'foo': 'dar'})
    fact_cache_1.first_order_merge('192.168.0.2', {'foo': 'bar'})



# Generated at 2022-06-25 14:12:47.232390
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()
    assert fact_cache_1
    assert fact_cache_1._plugin
    assert (C.CACHE_PLUGIN == "memory")
    

# Generated at 2022-06-25 14:12:54.005615
# Unit test for constructor of class FactCache
def test_FactCache():
    localhost = {'localhost': {
                        'ansible_python_version': 2.7,
                        'ansible_ssh_host': 'localhost',
                        'ansible_ssh_port': 2222,
                        'ansible_ssh_user': 'ansible'
                    }
                }

    uncacheable_test_server_1 = {'test_server_1': {
                                    'ansible_python_version': 3.5,
                                    'ansible_ssh_host': 'test_server_1',
                                    'ansible_ssh_port': 2222,
                                    'ansible_ssh_user': 'ansible',
                                    'raise_error': True,
                                }
                              }


# Generated at 2022-06-25 14:12:57.363404
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc.first_order_merge("one","two")
    fc.first_order_merge("one","three")
    assert (fc.get("one") == "three") | (fc.get("one") == "two")
    fc.flush()

# Generated at 2022-06-25 14:12:59.331594
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0._plugin == cache_loader.get(C.CACHE_PLUGIN)


# Generated at 2022-06-25 14:13:00.546356
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, MutableMapping) is True

# Generated at 2022-06-25 14:13:08.581944
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    fc['test@test.com'] = {"test1": "test1"}
    assert fc['test@test.com']['test1'] == "test1"
    assert fc.keys() == ['test@test.com']
    assert len(fc) == 1
    assert fc.copy() == {'test@test.com': {'test1': 'test1'}}
    fc['test@test.com'] = {"test1": "test", "test2": "test2"}
    assert fc['test@test.com']['test2'] == 'test2'
    assert fc.keys() == ['test@test.com']
    assert len(fc) == 1

# Generated at 2022-06-25 14:13:14.558590
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge("10.35.1.85", {'version': '2.0', 'ansible_python_version': '3.5.0', 'ansible_python_interpreter': 'python3', 'ansible_os_family': 'RedHat', 'ansible_os_release': '7.5'})


# Generated at 2022-06-25 14:13:16.709698
# Unit test for constructor of class FactCache
def test_FactCache():
    display.display("Constructor of class FactCache")
    fact_cache = FactCache()
    fact_cache_0 = FactCache()
    assert fact_cache == fact_cache_0


# Generated at 2022-06-25 14:13:19.739269
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    display.display("\nUnit Test for method first_order_merge of FactCache class")
    fact_cache_0 = FactCache()
    display.display(fact_cache_0.first_order_merge(key=10, value=20))

# Generated at 2022-06-25 14:13:26.443755
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert not fact_cache._plugin, "Failed to initialize _plugin."
    assert fact_cache.plugin is None, "Failed to initialize plugin."
    assert fact_cache.contains is None, "Failed to initialize contains."
    assert fact_cache.get is None, "Failed to initialize get."
    assert fact_cache.set is None, "Failed to initialize set."
    assert fact_cache.delete is None, "Failed to initialize delete."
    assert fact_cache.keys is None, "Failed to initialize keys."
    assert fact_cache.flush is None, "Failed to initialize flush."
    assert fact_cache.update is None, "Failed to initialize update."
    assert fact_cache.copy is None, "Failed to initialize copy."

# Generated at 2022-06-25 14:15:16.750795
# Unit test for constructor of class FactCache
def test_FactCache():
    result = FactCache()
    assert isinstance(result, FactCache)
