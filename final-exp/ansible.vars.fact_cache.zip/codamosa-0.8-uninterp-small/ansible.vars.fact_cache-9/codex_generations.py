

# Generated at 2022-06-25 14:05:17.782070
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    key_0 = 'test'
    value_0 = dict()
    var_0 = fact_cache_0.first_order_merge(key_0, value_0)

# Generated at 2022-06-25 14:05:18.833254
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        FactCache()
    except Exception:
        assert False


# Generated at 2022-06-25 14:05:25.764978
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    var_0 = fact_cache_0.flush()
    var_1 = fact_cache_0.flush()
    var_2 = fact_cache_0.keys()
    var_3 = fact_cache_0.flush()
    var_4 = fact_cache_0.keys()
    var_5 = fact_cache_0.flush()
    var_6 = fact_cache_0.flush()
    var_7 = fact_cache_0.keys()
    var_8 = fact_cache_0.flush()
    var_9 = fact_cache_0.flush()
    var_10 = fact_cache_0.keys()
    var_11 = fact_cache_0.flush()
    var_12 = fact_cache_0.keys()
    var_13 = fact

# Generated at 2022-06-25 14:05:26.545356
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    test_case_0()

# Generated at 2022-06-25 14:05:27.642143
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:05:31.890703
# Unit test for constructor of class FactCache
def test_FactCache():
    # fact_cache_0 = FactCache()
    try:
        fact_cache_0 = FactCache()
    except Exception:
        assert False

    # fact_cache_1 = FactCache()
    try:
        fact_cache_1 = FactCache()
    except Exception:
        assert False

# Generated at 2022-06-25 14:05:34.146759
# Unit test for constructor of class FactCache
def test_FactCache():
    # Case 0
    fact_cache_0 = FactCache()
    var_0 = fact_cache_0.flush()



# Generated at 2022-06-25 14:05:37.243128
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)
    assert isinstance(fact_cache._plugin, MutableMapping)


# Generated at 2022-06-25 14:05:38.597709
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:05:39.684619
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    cache.flush()

# Generated at 2022-06-25 14:05:43.208123
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    host_facts = {"key": "value"}
    key = "key"
    value = "value"
    fact_cache_0.first_order_merge(key, value)


# Generated at 2022-06-25 14:05:44.042802
# Unit test for constructor of class FactCache
def test_FactCache():
    factCache = FactCache()
    assert factCache != None

# Generated at 2022-06-25 14:05:50.027304
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge('test_host', {'fact0': 'test'})
    fact_cache_1.first_order_merge('test_host', {'fact0': 'test', 'fact1': 'test'})
    fact_cache_1.first_order_merge('test_host', {'fact0': 'test', 'fact1': 'test', 'fact2': 'test'})
    fact_cache_1.first_order_merge('test_host', {'fact0': 'test', 'fact1': 'different', 'fact2': 'test', 'fact3': 'test'})
    print(fact_cache_1['test_host']['fact3'])


# Generated at 2022-06-25 14:05:54.979318
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('127.0.0.1', {'ansible_facts': {'version': 2.7}})
    assert fact_cache.__contains__('127.0.0.1')

# Generated at 2022-06-25 14:06:02.154609
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    assert fact_cache._plugin.cache == {}
    fact_cache.first_order_merge('host0',{'ansible_kernel': 'Linux', 'ansible_processor_vcpus': 1, 'ansible_partition_max_primary': 15})
    assert fact_cache._plugin.cache == {'host0': {'ansible_kernel': 'Linux', 'ansible_processor_vcpus': 1, 'ansible_partition_max_primary': 15}}


# Generated at 2022-06-25 14:06:11.475340
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
  # Initializations
  fact_cache_0 = FactCache()
  key = "key"
  value = {}

# Generated at 2022-06-25 14:06:13.013838
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()

# Generated at 2022-06-25 14:06:22.828232
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    path_to_yaml = "/etc/ansible/facts/test.fact"

# Generated at 2022-06-25 14:06:25.847919
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge("hostname", "host.name.tld")
    return fact_cache_0

# Generated at 2022-06-25 14:06:34.728952
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1['localhost']={'localvar1':'localvalue1','localvar2':'localvalue2'}
    fact_cache_1.first_order_merge('localhost',{'localvar1':'localvalue1','localvar2':'localvalue2'})
    fact_cache_1.first_order_merge('localhost',{'localvar3':'localvalue3','localvar4':'localvalue4'})
    print('test_FactCache_first_order_merge: fact_cache_1:', fact_cache_1)
    fact_cache_1.flush()


if __name__ == '__main__':
    test_case_0()
    test_FactCache_first_order_merge()

# Generated at 2022-06-25 14:06:45.022491
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()

    host_facts = {'test_host': {'a': 'a', 'b': 'b', 'c': 'c'}}
    host_facts_0 = {'test_host': {'a': 'd', 'd': 'd'}}
    host_facts_1 = {'test_host': {'e': 'e', 'f': 'f'}}

    fact_cache.first_order_merge(**host_facts)
    fact_cache.first_order_merge(**host_facts_0)
    fact_cache.first_order_merge(**host_facts_1)

    assert fact_cache.get('test_host').get('a') == 'd'
    assert fact_cache.get('test_host').get('b') == 'b'

# Generated at 2022-06-25 14:06:46.053774
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 14:06:58.177446
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge('key', 'value')
    fact_cache_0.first_order_merge('key', {'key': 'value'})
    fact_cache_0.first_order_merge('key', {'key1': 'value1'})
    fact_cache_0.first_order_merge('key', 'value')
    fact_cache_0.first_order_merge('key', ['value', 'value'])
    fact_cache_0.first_order_merge('key', {'key': 'value'})
    fact_cache_0.first_order_merge('key', ['value', 'value'])
    fact_cache_0.first_order_merge('key', 'value')

# Generated at 2022-06-25 14:07:05.358729
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Test case 1
    fact_cache_1 = FactCache()
    
    fact_cache_1.first_order_merge('key_0', {})
    
    # Test case 2
    fact_cache_2 = FactCache()

# Generated at 2022-06-25 14:07:17.318867
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge('hostA',{'ansible_fact1': 'val1', 'ansible_fact2': 'val2'})
    if 'hostA' not in fact_cache_1:
        raise AssertionError()
    try:
        fact_cache_1.first_order_merge('hostA',{'ansible_fact1': 'val1'})
    except Exception as e:
        raise AssertionError(e)
    fact_cache_1.first_order_merge('hostB',{'ansible_fact1': 'val1'})
    if 'hostB' not in fact_cache_1:
        raise AssertionError()


# Generated at 2022-06-25 14:07:21.593724
# Unit test for constructor of class FactCache
def test_FactCache():
    """
    Args:
      None
    Returns:
      None
    """
    # try to initialize an instance of class FactCache
    fact_cache = FactCache()

    # check if initialization was successful
    assert(isinstance(fact_cache, FactCache))


# Generated at 2022-06-25 14:07:31.977756
# Unit test for constructor of class FactCache
def test_FactCache():
    hostname1 = 'testhost.example.org'
    test_case_0()
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge(
        key=hostname1,
        value={'testfact': True}
        )
    if fact_cache_1[hostname1] == {'testfact': True}:
        display.display('test_FactCache, test_case_1: passed')
    else:
        display.display('test_FactCache, test_case_1: failed')
    fact_cache_1[hostname1]['testfact'] = False
    if fact_cache_1[hostname1] == {'testfact': False}:
        display.display('test_FactCache, test_case_2: passed')

# Generated at 2022-06-25 14:07:33.724559
# Unit test for constructor of class FactCache
def test_FactCache():
    fc=FactCache()
    assert fc._plugin.cache_name == "jsonfile"

# Generated at 2022-06-25 14:07:35.159598
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()



# Generated at 2022-06-25 14:07:36.890348
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()
    assert isinstance(fact_cache_1, FactCache)


# Generated at 2022-06-25 14:07:42.718825
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()
    assert isinstance(fact_cache_1, MutableMapping) == True
    display.info("Successfully unit tested constructor for class FactCache")


# Generated at 2022-06-25 14:07:44.249738
# Unit test for constructor of class FactCache
def test_FactCache():
    fcache = FactCache()
    assert isinstance(fcache, MutableMapping)

# Generated at 2022-06-25 14:07:46.308947
# Unit test for constructor of class FactCache
def test_FactCache():
    host_facts = {'cache_key': 'cache_value'}
    fact_cache = FactCache(host_facts)
    assert fact_cache == host_facts

# Generated at 2022-06-25 14:07:49.416605
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    key = "key"
    value = "value"
    fact_cache_0.first_order_merge(key, value)


# Generated at 2022-06-25 14:07:50.595639
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.plugin_name == 'memory'


# Generated at 2022-06-25 14:08:00.574691
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    host_facts = dict()
    host_facts['cache0.example.com'] = dict()
    host_facts['cache0.example.com']['ansible_facts'] = dict()
    host_facts['cache0.example.com']['ansible_facts']['distribution'] = 'Debian'
    host_facts['cache0.example.com']['ansible_facts']['distribution_version'] = 'wheezy'
    fact_cache_0.first_order_merge('cache0.example.com', host_facts['cache0.example.com']['ansible_facts'])
    assert 'cache0.example.com' in fact_cache_0


# Reset the cache plugin to the default, in case we had changed it
C.C

# Generated at 2022-06-25 14:08:09.358212
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()

    # Create a dict
    d1 = dict()
    d1['key1'] = {'key2': {'key3': 'value1'}}
    d1['key4'] = 'value2'

    # Create a dict
    d2 = dict()
    d2['key1'] = {'key2': {'key5': 'value3'}}

    # Merge the two dicts using first_order_merge method
    fact_cache.first_order_merge('key', d1)
    fact_cache.first_order_merge('key', d2)

    # The result of the merge should be the same as result of merging
    # d1 and d2 using first_order_merge.

# Generated at 2022-06-25 14:08:15.464422
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert ('keys' in dir(fact_cache))
    assert ('values' in dir(fact_cache))
    assert ('items' in dir(fact_cache))
    assert ('copy' in dir(fact_cache))
    assert ('update' in dir(fact_cache))
    assert ('clear' in dir(fact_cache))
    assert ('get' in dir(fact_cache))
    assert ('set' in dir(fact_cache))
    assert ('delete' in dir(fact_cache))
    assert ('contains' in dir(fact_cache))
    assert ('flush' in dir(fact_cache))
    assert ('first_order_merge' in dir(fact_cache))


# Generated at 2022-06-25 14:08:17.439185
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge("test_hostname", { "fact_name": "fact_value"})
    assert fact_cache._plugin.get("test_hostname") == { "fact_name": "fact_value"}


# Generated at 2022-06-25 14:08:22.502291
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()
    assert type(fact_cache_1) == FactCache
    '''
    def __init__(self, *args, **kwargs):

        self._plugin = cache_loader.get(C.CACHE_PLUGIN)
        if not self._plugin:
            raise AnsibleError('Unable to load the facts cache plugin (%s).' % (C.CACHE_PLUGIN))

        super(FactCache, self).__init__(*args, **kwargs)
    '''
    
    

# Generated at 2022-06-25 14:08:33.029376
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache0 = FactCache()

    assert(len(fact_cache0) == 0)
    assert(not fact_cache0)

    fact_cache0['foo'] = 'bar'
    assert(fact_cache0['foo'] == 'bar')
    assert(len(fact_cache0) == 1)
    assert(fact_cache0)

    assert('foo' in fact_cache0)
    assert('bar' not in fact_cache0)

    list_keys = ['foo']
    assert(list(fact_cache0) == list_keys)

    assert(fact_cache0.copy() == {'foo': 'bar'})

    fact_cache0.flush()
    assert(len(fact_cache0) == 0)

    assert(fact_cache0.keys() == [])


# Generated at 2022-06-25 14:08:36.472977
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    test_key = "test"
    test_value = "test_value"
    fact_cache.first_order_merge(test_key, test_value)
    assert fact_cache[test_key] == test_value

# Generated at 2022-06-25 14:08:43.134123
# Unit test for constructor of class FactCache
def test_FactCache():
    assert len(fact_cache_0) == 0, "Expected '0' got '%s' for length of fact cache" % len(fact_cache_0)
    assert "key_1" not in fact_cache_0, "Expected 'key_1' to not be in fact cache"
    try:
        fact_cache_0.__getitem__("key_1")
    except KeyError as e:
        pass
    else:
        assert False, "Expected KeyError exception to be raised"
    try:
        fact_cache_0.__getitem__("key_2")
    except KeyError as e:
        pass
    else:
        assert False, "Expected KeyError exception to be raised"

# Generated at 2022-06-25 14:08:43.913049
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()



# Generated at 2022-06-25 14:08:44.660607
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()


# Generated at 2022-06-25 14:08:46.523024
# Unit test for constructor of class FactCache
def test_FactCache():
    # fact_cache = fact_cache.FactCache()
    fact_cache_0 = FactCache()
    assert fact_cache_0 is not None



# Generated at 2022-06-25 14:08:48.206402
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        test_case_0()
    finally:
        pass


# Generated at 2022-06-25 14:08:49.574684
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    print(fact_cache)


# Generated at 2022-06-25 14:08:51.219132
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache.keys() == []



# Generated at 2022-06-25 14:08:52.520591
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert len(cache) == 0


# Generated at 2022-06-25 14:09:05.245232
# Unit test for constructor of class FactCache
def test_FactCache():

    print("\nTest 1: Testing constructor of class FactCache")
    try:
        test_case_0()
        print("\nTest 1: successful")
    except Exception as e:
        print(e)
        print("\nTest 1: failed")



# Generated at 2022-06-25 14:09:06.825521
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()

if __name__ == '__main__':
    test_FactCache()

# Generated at 2022-06-25 14:09:08.372773
# Unit test for constructor of class FactCache
def test_FactCache():
    #test_case_0()
    pass


# Generated at 2022-06-25 14:09:10.022545
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    display.display("test FactCache() constructor")
    print(fact_cache)



# Generated at 2022-06-25 14:09:11.434394
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None



# Generated at 2022-06-25 14:09:13.414453
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

if __name__ == "__main__":
    test_FactCache()

# Generated at 2022-06-25 14:09:14.339421
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

# Generated at 2022-06-25 14:09:15.280582
# Unit test for constructor of class FactCache
def test_FactCache():
    assert(callable(FactCache))

# Generated at 2022-06-25 14:09:18.572944
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        fact_cache = FactCache()
    except:
        assert 0, "Unexpected error: could not instance FactCache()"
    assert isinstance(fact_cache, FactCache)


# Generated at 2022-06-25 14:09:25.886050
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge('localhost', dict(a=1, b=2, c=3))
    assert fact_cache_1['localhost'] == dict(a=1, b=2, c=3)
    fact_cache_1.first_order_merge('localhost', dict(c=4, d=5))
    assert fact_cache_1['localhost'] == dict(a=1, b=2, c=4, d=5)


# Generated at 2022-06-25 14:09:39.219766
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    key_0 = "value"
    value_0 = "key"
    fact_cache_0.first_order_merge(key_0, value_0)


# Generated at 2022-06-25 14:09:40.903743
# Unit test for constructor of class FactCache
def test_FactCache():
    assert type(test_case_0()) == FactCache

# Generated at 2022-06-25 14:09:42.592851
# Unit test for constructor of class FactCache
def test_FactCache():
    # test_case_0()
    pass

if __name__ == '__main__':
    test_FactCache()

# Generated at 2022-06-25 14:09:46.929408
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    assert fact_cache.__contains__(hostname) == False
    fact_cache.first_order_merge(hostname, uptime)
    assert fact_cache.__contains__(hostname) == True
    assert fact_cache.__getitem__(hostname) == uptime

# Generated at 2022-06-25 14:09:52.834297
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0['127.0.0.1'] == {'ansible_facts': {'ansible_all_ipv4_addresses': ['127.0.0.1']}}
    assert fact_cache_0['localhost'] == {'ansible_facts': {'ansible_all_ipv4_addresses': ['127.0.0.1']}}
    assert len(fact_cache_0) == 2
    assert fact_cache_0.keys() == ['127.0.0.1', 'localhost']



# Generated at 2022-06-25 14:09:55.149849
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    host = 'host'
    fact_cache = {host: 'ansible'}
    factCache = FactCache()
    factCache.first_order_merge(host, fact_cache)


# Generated at 2022-06-25 14:09:59.016843
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    host = '192.168.1.1'
    facts = {'ansible_os_family': 'Linux', 'ansible_distribution': 'Ubuntu'}

    fact_cache.first_order_merge(host, facts)

    assert fact_cache[host] == facts

# Generated at 2022-06-25 14:10:08.563585
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    key_0 = 'key_0'
    value_0 = 'value_0'
    fact_cache_0.first_order_merge(key_0, value_0)
    fact_cache_1 = FactCache()
    key_1 = 'key_1'
    value_1 = 'value_1'
    fact_cache_1.first_order_merge(key_1, value_1)
    fact_cache_2 = FactCache()
    key_2 = 'key_2'
    value_2 = 'value_2'
    fact_cache_2.first_order_merge(key_2, value_2)
    fact_cache_3 = FactCache()
    key_3 = 'key_3'

# Generated at 2022-06-25 14:10:09.808845
# Unit test for constructor of class FactCache
def test_FactCache():
    assert(not test_case_0())

# Test for the first order merge in class FactCache

# Generated at 2022-06-25 14:10:19.638947
# Unit test for constructor of class FactCache
def test_FactCache():
    # test if fact_cache has items in dict
    fact_cache = {'test_key': 'test_value'}

    test_cache_obj = FactCache()
    assert isinstance(test_cache_obj,FactCache)
    test_cache_obj.__getitem__('test_key')
    test_cache_obj.__setitem__('test_key', 'test_value')
    test_cache_obj.__contains__('test_key')
    test_cache_obj.__iter__()
    test_cache_obj.__len__()
    test_cache_obj.first_order_merge('test_key', 'test_value')
    test_cache_obj.keys()
    test_cache_obj.flush()

    test_cache_obj_2 = FactCache(fact_cache)

# Generated at 2022-06-25 14:10:49.542145
# Unit test for constructor of class FactCache
def test_FactCache():
    #default values of constructor
    fact_cache_0 = FactCache()
    del fact_cache_0
    #default values of constructor
    fact_cache_1 = FactCache()
    del fact_cache_1
    #default values of constructor
    fact_cache_2 = FactCache()
    del fact_cache_2
    #default values of constructor
    fact_cache_3 = FactCache()
    del fact_cache_3
    #default values of constructor
    fact_cache_4 = FactCache()
    del fact_cache_4
    #default values of constructor
    fact_cache_5 = FactCache()
    del fact_cache_5
    #default values of constructor
    fact_cache_6 = FactCache()
    del fact_cache_6
    #default values of constructor
    fact_cache_7 = FactCache()

# Generated at 2022-06-25 14:10:51.419301
# Unit test for constructor of class FactCache
def test_FactCache():

    # Testing the constructor
    fact_cache_0 = FactCache()
    assert fact_cache_0



# Generated at 2022-06-25 14:10:54.945487
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    key = '127.0.0.1'
    value = 'test_value'
    fact_cache_1.first_order_merge(key, value)
    result = fact_cache_1._plugin.get(key)
    assert result == str(value)


# Generated at 2022-06-25 14:10:57.184560
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge("some_key", "some_value")
    assert(fact_cache["some_key"] == "some_value")


# Generated at 2022-06-25 14:11:03.645012
# Unit test for constructor of class FactCache
def test_FactCache():

    def test_case_0():
        fact_cache_0 = FactCache()

    def test_case_1():
        fact_cache_0 = FactCache()
        with pytest.raises(TypeError) as __e:
            _ = fact_cache_0.keys()
        assert ("'NoneType' object is not callable" in str(__e.value))

    def test_case_2():
        fact_cache_0 = FactCache()
        assert fact_cache_0._plugin.contains(None) is False

    def test_case_3():
        fact_cache_0 = FactCache()
        with pytest.raises(TypeError) as __e:
            _ = fact_cache_0.first_order_merge(None, None)

# Generated at 2022-06-25 14:11:05.436079
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()
    assert fact_cache_1 is not None

# Generated at 2022-06-25 14:11:06.980038
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()


# Generated at 2022-06-25 14:11:09.334751
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0._plugin is not None


# Generated at 2022-06-25 14:11:17.022762
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('key_0', 'value_0')
    assert fact_cache.keys() == ['key_0']
    assert fact_cache['key_0'] == 'value_0'
    fact_cache.first_order_merge('key_0', 'value_1')
    assert fact_cache.keys() == ['key_0']
    assert fact_cache['key_0'] == 'value_1'
    fact_cache.first_order_merge('key_1', 'value_1')
    assert fact_cache.keys() == ['key_0', 'key_1']
    assert fact_cache['key_1'] == 'value_1'


# Generated at 2022-06-25 14:11:19.219487
# Unit test for constructor of class FactCache
def test_FactCache():
	# Test create object
	fact_cache_0 = FactCache()
	if (fact_cache_0 is not None):
		print("Test FactCache: PASSED")
	else:
		print("Test FactCache: FAILED")

# Generated at 2022-06-25 14:12:04.869147
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()

# Generated at 2022-06-25 14:12:06.340839
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0


# Generated at 2022-06-25 14:12:07.438354
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()


FactCache = FactCache()

# Generated at 2022-06-25 14:12:12.670554
# Unit test for constructor of class FactCache
def test_FactCache():
    print('')
    print('Testing constructor of class FactCache...')
    print('----------------------------------------')

    try:
        print('Creating an instance of class FactCache')
        fact_cache = FactCache()
        print('--> Successfully created an instance of class FactCache!')
    except Exception as e:
        print('--> Failed to create an instance of class FactCache!')
        print('    Here is the exception:')
        print(str(e))


# Generated at 2022-06-25 14:12:16.923482
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    key = "test_key"
    value = "test_value"
    fact_cache.first_order_merge(key, value)
    assert fact_cache[key] == value

if __name__ == '__main__':
    #test_case_0()
    test_FactCache_first_order_merge()

# Generated at 2022-06-25 14:12:17.977558
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()


# Generated at 2022-06-25 14:12:20.186192
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        FactCache()
    except Exception as e:
        print('[test_FactCache]', '[Fail]')
        print(e)
        return
    print('[test_FactCache]', '[OK]')

# Generated at 2022-06-25 14:12:23.746438
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()

    key = 'TEST_CASE1'
    value = {'test_key': 'test_value'}
    fact_cache_1.first_order_merge(key, value)
    assert fact_cache_1[key] == value



# Generated at 2022-06-25 14:12:31.634689
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge('ansible_os_family', {'ansible_architecture': 'amd64', 'ansible_distribution': 'CentOS', 'ansible_distribution_major_version': '7', 'ansible_distribution_release': 'Core', 'ansible_distribution_version': '7.6.1810', 'ansible_kernel': '3.10.0-957.1.3.el7.x86_64', 'ansible_memtotal_mb': 3764.8, 'ansible_os_family': 'RedHat'})

# Generated at 2022-06-25 14:12:32.918910
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0=FactCache()
    return fact_cache_0


# Generated at 2022-06-25 14:14:24.382877
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    #assert fact_cache_0._plugin.contains("foo") == False
    #assert fact_cache_0._plugin.contains("baz") == False
    #assert fact_cache_0._plugin.get("foo") == None
    #assert fact_cache_0._plugin.get("baz") == None
    #assert fact_cache_0._plugin.set("foo", "baz") == None
    #assert fact_cache_0._plugin.get("foo") == "baz"
    #assert fact_cache_0._plugin.contains("foo") == True
    #assert fact_cache_0.keys() == None
    #assert fact_cache_0._plugin.keys() == None
    if __name__ == '__main__':
        test_FactCache()

# Generated at 2022-06-25 14:14:26.302945
# Unit test for constructor of class FactCache
def test_FactCache():
    # Create an object of the class FactCache
    fact_cache = FactCache()
    # Assert that the object is an instance of the class FactCache
    assert isinstance(fact_cache, FactCache)


# Generated at 2022-06-25 14:14:27.211909
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0


# Generated at 2022-06-25 14:14:28.106992
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:14:32.193923
# Unit test for constructor of class FactCache
def test_FactCache():
    import unittest
    from ansible.parsing.vault import VaultLib

    class TestFactCache(unittest.TestCase):

        def test_case_0(self):
            fact_cache_0 = FactCache()
            assert fact_cache_0.__class__.__name__ == 'FactCache'


    results = unittest.main()
    print("\n\nRecap of FactCache:\n")
    for test in results.result.tests:
        print(test)

if __name__ == '__main__':
    test_case_0()
    test_FactCache()

# Generated at 2022-06-25 14:14:33.286116
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    assert FactCache.first_order_merge('key', 'value') == {'key': 'value'}

# Generated at 2022-06-25 14:14:39.156382
# Unit test for method first_order_merge of class FactCache

# Generated at 2022-06-25 14:14:40.181820
# Unit test for constructor of class FactCache
def test_FactCache():

    test_case_0()


# Generated at 2022-06-25 14:14:47.139416
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    ipv4 = {'en0': {'ipv4': {'address': 'fe80::a00:27ff:fe7a:f875', 'netmask': 'ffff:ffff:ffff:ffff::', 'network': 'fe80::'}}}
    expected_ipv4_value = {'address': 'fe80::a00:27ff:fe7a:f875', 'netmask': 'ffff:ffff:ffff:ffff::', 'network': 'fe80::'}

    fact_cache = FactCache()
    assert not fact_cache.keys()

    fact_cache.first_order_merge('ipv4', ipv4)

    # Check the cache contained keys
    assert len(fact_cache.keys()) == 1
    # Check the cached value for key 'ipv4' is correct

# Generated at 2022-06-25 14:14:49.219593
# Unit test for constructor of class FactCache
def test_FactCache():
    # unit test for constructor of class FactCache
    print(FactCache())
    