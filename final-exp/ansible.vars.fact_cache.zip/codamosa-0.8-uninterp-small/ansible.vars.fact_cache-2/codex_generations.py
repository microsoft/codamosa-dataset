

# Generated at 2022-06-25 14:05:19.484497
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache


# Generated at 2022-06-25 14:05:21.355548
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    # Test cases
    key_0 = 'key_0'
    value_0 = 'value_0'
    fact_cache_0.first_order_merge(key_0, value_0)

# Generated at 2022-06-25 14:05:24.045418
# Unit test for constructor of class FactCache
def test_FactCache():

    # Initialize an instance of the FactCache class
    fact_cache = FactCache()

    # Constructor raises RuntimeError if no cache has been defined
    with pytest.raises(RuntimeError):
        FactCache()




# Generated at 2022-06-25 14:05:25.741962
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin != None


# Generated at 2022-06-25 14:05:28.946741
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    key = 'key'
    value = 'value'
    #Calling function first_order_merge with arguments key and value.
    fact_cache_0.first_order_merge(key, value)
    assert True


# Generated at 2022-06-25 14:05:31.530867
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0._plugin.__class__.__name__ == 'DictFileCacheModule'


# Generated at 2022-06-25 14:05:32.610795
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    key = 'key'
    value = 'value'
    fact_cache_1.first_order_merge(key, value)

# Generated at 2022-06-25 14:05:33.583792
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case = FactCache()
    assert test_case

# Generated at 2022-06-25 14:05:43.624556
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    """ Test that the first_order_merge works as expected """
    host_cache = {'success': True, 'fail_count': 0}
    host_facts = {'success': False, 'fail_count': 1}
    fact_cache_0 = FactCache()

    try:
        # Call the method with invalid inputs
        fact_cache_0.first_order_merge('test', None)
        raise AssertionError("Expected AnsibleError was not raised")
    except AnsibleError as e:
        # Assert that the error message is what we expect
        assert e.message == 'Invalid fact cache key type, should be string'


# Generated at 2022-06-25 14:05:45.416324
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    assert fact_cache_0.first_order_merge('foo', 'bar')


# Generated at 2022-06-25 14:05:48.612755
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert type(fc) == FactCache


# Generated at 2022-06-25 14:06:00.091474
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()

    cache_key = "master_0"

# Generated at 2022-06-25 14:06:06.474025
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    host = "test_host"
    key = "ansible_local"
    value = { "test_key": "data" }
    fact_cache_0.first_order_merge(host, key, value)
    fact_cache_0.flush()
    assert fact_cache_0.keys().contains("test_host") == False


if __name__ == '__main__':
    import pytest
    pytest.main(['-s', __file__])

# Generated at 2022-06-25 14:06:08.568045
# Unit test for constructor of class FactCache
def test_FactCache():
    display.banner(u"START test_FactCache")
    test_case_0()
    display.banner(u"END test_FactCache")

# Generated at 2022-06-25 14:06:14.466929
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge("192.168.1.1", {"ansible_os_family": "RedHat","ansible_local": {"my_var": "foo"}})
    fact_keys = fact_cache.keys()
    assert fact_keys[0] == "192.168.1.1"
    assert fact_cache["192.168.1.1"]["ansible_os_family"] == "RedHat"
    assert fact_cache["192.168.1.1"]["ansible_local"]["my_var"] == "foo"

# Generated at 2022-06-25 14:06:16.655805
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, MutableMapping)

# Generated at 2022-06-25 14:06:20.747736
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    host_facts_0 = dict()
    fact_cache_0.first_order_merge(key='key_0', value=host_facts_0)
    #TODO: add method to compare two dicts



# Generated at 2022-06-25 14:06:25.005391
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge("test_key_0", "test_value_0")
    assert fact_cache_0.get("test_key_0") == "test_value_0"

# Generated at 2022-06-25 14:06:25.980881
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    test_case_0()

# Generated at 2022-06-25 14:06:28.741810
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()

    fact_cache_0.first_order_merge('key', 'value')

    assert fact_cache_0['key'] == 'value'


# Generated at 2022-06-25 14:06:33.595511
# Unit test for constructor of class FactCache
def test_FactCache():
    # Constructor doesn't take any parameters
    fact_cache_1 = FactCache()


# Generated at 2022-06-25 14:06:36.301635
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        test_case_0()
    except Exception as e:
        display.vv(e)
        display.error("Failed to create the object of class FactCache.")
        return False
    else:
        display.vv("Successfully created the object of class FactCache.")
        return True

# Generated at 2022-06-25 14:06:45.095937
# Unit test for method first_order_merge of class FactCache

# Generated at 2022-06-25 14:06:56.805128
# Unit test for constructor of class FactCache
def test_FactCache():
    pass
#    key_0 = None
#    value_0 = None
#    fact_cache_1 = FactCache()
#    fact_cache_1.__setitem__(key_0, value_0)
#    key_1 = None
#    value_1 = None
#    fact_cache_2 = FactCache()
#    fact_cache_2.__setitem__(key_1, value_1)
#    key_2 = None
#    value_2 = None
#    fact_cache_3 = FactCache()
#    fact_cache_3.__setitem__(key_2, value_2)
#    key_3 = None
#    value_3 = None
#    fact_cache_4 = FactCache()
#    fact_cache_4.__setitem__(key_3, value

# Generated at 2022-06-25 14:07:04.710042
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge("test_key", "test_value")
    assert fact_cache_1["test_key"] == "test_value"

    fact_cache_2 = FactCache()
    fact_cache_2.first_order_merge("key_2", "value_2")
    assert fact_cache_2["key_2"] == "value_2"
    fact_cache_2.first_order_merge("key_2", "value_3")
    assert fact_cache_2["key_2"] == "value_3"

    fact_cache_3 = FactCache()
    fact_cache_3.first_order_merge("key_3", {"dict": "value"})

# Generated at 2022-06-25 14:07:07.683454
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

test_FactCache()
test_case_0()

# Generated at 2022-06-25 14:07:19.176396
# Unit test for constructor of class FactCache
def test_FactCache():
    import pytest
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import mock

    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.plugins.loader import cache_loader
    from ansible.utils.display import Display

    @pytest.mark.skipif(PY3, reason="Test not implemented on Python 3")
    @pytest.mark.parametrize(
        'an_error, a_value', [
            (True, 'Unable to load the facts cache plugin ()'),
            (False, 'Unable to load the facts cache plugin (foo plugin).')
        ]
    )
    def test_case_1(an_error, a_value):
        fact_cache_0 = FactCache()

# Generated at 2022-06-25 14:07:26.654626
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    fact_cache = FactCache()

    # duplicate entries shouldn't matter
    fact_cache.first_order_merge("test_hostname", {"test_key": "test_value", "test_key2": "test_value2"})
    fact_cache.first_order_merge("test_hostname", {"test_key": "test_value", "test_key2": "test_value2"})
    assert fact_cache["test_hostname"] == {"test_key": "test_value", "test_key2": "test_value2"}

    # ensure non-duplicate entries aren't overwritten
    fact_cache.first_order_merge("test_hostname", {"test_key": "test_value", "test_key3": "test_value3"})

# Generated at 2022-06-25 14:07:29.315919
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge("ansible_architecture", "None")


# Generated at 2022-06-25 14:07:39.003457
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()

# Generated at 2022-06-25 14:07:44.208066
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    factCache = FactCache()
    key = 'localhost'
    value = {'gathered_by': 'setup'}
    factCache.first_order_merge(key, value)

test_FactCache_first_order_merge()

# Generated at 2022-06-25 14:07:51.419537
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    for key in fact_cache:
        assert(key != None)
        assert(fact_cache[key] != None)
    assert(fact_cache.keys() != None)
    assert(fact_cache.flush() != None)
    assert(fact_cache.copy() != None)
    assert(fact_cache.__contains__(None) == False)
    assert(fact_cache.__getitem__(None) == False)
    assert(fact_cache.__setitem__(None, None) == False)
    assert(fact_cache.__delitem__(None) == False)
    assert(fact_cache.__iter__() != None)
    assert(fact_cache.__len__() != None)

# Generated at 2022-06-25 14:07:52.625142
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache


# Generated at 2022-06-25 14:08:00.760865
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = test_case_0()
    assert len(fact_cache_1) == 0
    fact_cache_1.first_order_merge("key0", "value0")
    fact_cache_1.first_order_merge("key1", "value1")
    assert len(fact_cache_1) == 2
    assert fact_cache_1.__contains__("key0")
    assert fact_cache_1.__contains__("key1")


if __name__ == "__main__":
    test_FactCache_first_order_merge()

# Generated at 2022-06-25 14:08:09.485136
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    fact_cache.set('a', '1')
    assert fact_cache.get('a') == '1'
    fact_cache.delete('a')
    assert fact_cache.contains('a') == False
    fact_cache.set('1', 'a')
    assert fact_cache.get('1') == 'a'
    fact_cache.set('2', 'b')
    assert fact_cache.get('2') == 'b'
    fact_cache.set('3', 'c')
    assert fact_cache.get('3') == 'c'
    fact_cache.keys()
    assert len(fact_cache.keys()) == 3
    fact_cache.flush()
    assert len(fact_cache.keys()) == 0
    fact_cache.set('a', '1')

# Generated at 2022-06-25 14:08:10.833523
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()

# Generated at 2022-06-25 14:08:11.816117
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:08:16.675822
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()

    # Testing if fact_cache is an instance of FactCache
    assert isinstance(fact_cache, FactCache)
    assert isinstance(fact_cache, dict)
    # Testing if fact_cache is empty
    assert not fact_cache

if __name__ == '__main__':
    # Test FactCache
    test_FactCache()

    print("All tests passed")

# Generated at 2022-06-25 14:08:21.374870
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    key_0 = 'l??_^x'
    value_0 = 'I|'
    fact_cache_0.first_order_merge(key_0, value_0)
    key_1 = 'e'
    value_1 = -1.9
    fact_cache_0.first_order_merge(key_1, value_1)

# Generated at 2022-06-25 14:08:23.840561
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert len(fact_cache) == 0
    assert fact_cache._plugin is not None


# Generated at 2022-06-25 14:08:35.225083
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge('foo', 'bar')
    assert fact_cache_1['foo'] == 'bar'

    fact_cache_2 = FactCache()
    fact_cache_2.first_order_merge('foo', 'bar')
    assert fact_cache_2['foo'] == 'bar'
    fact_cache_2.first_order_merge('foo', 'baz')
    assert fact_cache_2['foo'] == 'baz'


# Generated at 2022-06-25 14:08:36.828785
# Unit test for constructor of class FactCache
def test_FactCache():
    with pytest.raises(AnsibleError) as excinfo:
        fact_cache = FactCache()
        assert 'Unable to load the facts cache plugin.' in str(excinfo.value)


# Generated at 2022-06-25 14:08:41.674722
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()

    fact_cache_1.first_order_merge('test1', {'name': 'test_name'})
    fact_cache_1.first_order_merge('test1', {'name': 'test_name_2'})

    assert fact_cache_1['test1']['name'] == 'test_name_2'

if __name__ == '__main__':
    test_case_0()
    test_FactCache_first_order_merge()

# Generated at 2022-06-25 14:08:47.204882
# Unit test for constructor of class FactCache
def test_FactCache():

    fact_cache_0 = FactCache()
    assert fact_cache_0._plugin
    #assert fact_cache_0._plugin.name() == 'jsonfile'

    fact_cache_1 = FactCache()
    assert fact_cache_1._plugin
    #assert fact_cache_1._plugin.name() == 'jsonfile'

    fact_cache_2 = FactCache()
    assert fact_cache_2._plugin
    #assert fact_cache_2._plugin.name() == 'jsonfile'



# Generated at 2022-06-25 14:08:49.085579
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        test_case_0()
    except Exception:
        display.error('Failed to test class FactCache')

# Generated at 2022-06-25 14:08:50.273903
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:08:59.120971
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import json
    import os
    import shutil
    import tempfile


    def _get_temp_dir():
        tempdir = tempfile.mkdtemp(dir='/tmp')
        return tempdir


    # Create a temporary directory
    C.DEFAULT_LOCAL_TMP = _get_temp_dir()

    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge('a', 'b')

    assert fact_cache_0 == {'a': 'b'}

    shutil.rmtree(C.DEFAULT_LOCAL_TMP, True)


if __name__ == "__main__":
    import pytest
    pytest.main(['-x', __file__])

# Generated at 2022-06-25 14:09:09.082100
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    fact_cache_item = {'hostname': {'foo': 'bar'}}
    fact_cache_item_keys = ['hostname']
    fact_cache_item_value = {'foo': 'bar'}
    fact_cache_flush_item = {'key1': 'val1'}
    fact_cache_first_order_merge = {'key1': 'val1'}
    fact_cache_get_item = {'key1': 'val1'}

    # __init__() method
    test_case_0()

    # __getitem__() method
    try:
        fact_cache[fact_cache_item_keys[0]]
    except KeyError:
        print("KeyError")
    else:
        print("Success")

    # __setitem__

# Generated at 2022-06-25 14:09:10.480543
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    print (fact_cache_0)


# Generated at 2022-06-25 14:09:12.533507
# Unit test for constructor of class FactCache
def test_FactCache():
    """
      This tests the constructor of class FactCache.
    """
    fc = FactCache()
    assert fc is not None


# Generated at 2022-06-25 14:09:28.853149
# Unit test for constructor of class FactCache
def test_FactCache():
    import pytest
    from collections import Iterable
    from collections import Mapping
    from collections import MutableMapping
    from ansible import constants as C
    from ansible.errors import AnsibleError
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.plugins.loader import cache_loader
    from ansible.utils.display import Display

    fact_cache_0 = FactCache()
    with pytest.raises(AnsibleError):
        fact_cache_0 = FactCache()
    hasattr(fact_cache_0,"_cache")



# Generated at 2022-06-25 14:09:30.162877
# Unit test for constructor of class FactCache
def test_FactCache():
    with pytest.raises(AnsibleError):
        fact_cache = FactCache()


# Generated at 2022-06-25 14:09:30.878142
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()

# Generated at 2022-06-25 14:09:32.209462
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        FactCache()
    except Exception as e:
        assert True


# Generated at 2022-06-25 14:09:34.004537
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    print(fact_cache)

test_FactCache()

# Generated at 2022-06-25 14:09:37.238795
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    fact_cache_1 = FactCache()
    assert fact_cache == fact_cache_1



# Generated at 2022-06-25 14:09:38.241554
# Unit test for constructor of class FactCache
def test_FactCache():
  test_case_0()

# Generated at 2022-06-25 14:09:46.363800
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        fp = open('/tmp/ansible_test/test_case_0','w')
        fp.write('PYTHON PATH: ' + str(sys.path) + '\n')
        fp.write('CWD: ' + os.getcwd() + '\n')
        test_case_0()
        fp.write('test_case_0 ok\n')
    except:
        fp.write('test_case_0 exception\n')
        pass
    finally:
        fp.close()

if __name__ == '__main__':
    test_FactCache()

# Generated at 2022-06-25 14:09:49.911736
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    # Test for the following corner cases:
    # no arguments, one argument
    fact_cache_0.first_order_merge()
    # multiple arguments
    fact_cache_0.first_order_merge(fact_cache_0, 'arg_0')

# Generated at 2022-06-25 14:09:51.654679
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()
    assert fact_cache_1._plugin


# Generated at 2022-06-25 14:10:20.902923
# Unit test for constructor of class FactCache
def test_FactCache():

    fc = FactCache()
    assert fc._plugin is not None


# Generated at 2022-06-25 14:10:30.317374
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    value_0 = {
        'ansible_check_mode': True,
        'ansible_ubuntu_os_version': {
            'major': '18',
            'minor': '04',
            'revision': '0'
        },
        'ansible_virtualization_type': 'kvm'
    }
    key_0 = '192.168.244.1'
    fact_cache_0.first_order_merge(key_0, value_0)
    # Test case 0:
    assert key_0 in fact_cache_0
    # Test case 1:

# Generated at 2022-06-25 14:10:33.660167
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge('localhost', {'key_A': 'value_A'})
    assert fact_cache_1['localhost'] == {'key_A': 'value_A'}
    fact_cache_1.first_order_merge('localhost', {'key_B': 'value_B'})
    assert fact_cache_1['localhost'] == {'key_A': 'value_A', 'key_B': 'value_B'}

# Generated at 2022-06-25 14:10:35.056412
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge('example.com', 'value_0')


# Generated at 2022-06-25 14:10:44.704662
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Setup...
    fact_cache_0 = FactCache()
    key_0 = '/etc/passwd'
    key_1 = '/etc/hosts'
    key_2 = '/etc/shadow'
    key_3 = '/etc/group'

    value_0 = {'key_0': key_0, 'key_1': key_1, 'key_2': key_2, 'key_3': key_3}
    value_1 = {'key_2': key_2, 'key_3': key_3}

    # Exercise...
    fact_cache_0.first_order_merge(key_0, value_0)
    fact_cache_0.first_order_merge(key_1, value_0)

# Generated at 2022-06-25 14:10:46.331728
# Unit test for constructor of class FactCache
def test_FactCache():
    '''
    :return:
    '''
    fact_cache_0 = FactCache()

# Generated at 2022-06-25 14:10:49.821998
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('somehost', {'ansible_os_family': 'RedHat'})
    fact_cache.first_order_merge('somehost', {'ansible_os_family': 'Debian'})

# Generated at 2022-06-25 14:10:51.108134
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

# Generated at 2022-06-25 14:10:53.713756
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0._plugin

    with pytest.raises(AnsibleError):
        fact_cache_0 = FactCache(C.CACHE_PLUGIN, '')


# Generated at 2022-06-25 14:10:56.916189
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0._plugin = 'TestPlugin'
    fact_cache_0.first_order_merge('foo', ['bar'])
    fact_cache_0.first_order_merge('foo', ['baz'])


# Generated at 2022-06-25 14:12:06.142171
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('192.168.1.1', {'a': 33, 'b': 44})
    fact_cache.first_order_merge('192.168.1.1', {'b': 55, 'c': 66})
    fact_cache.first_order_merge('192.168.1.2', {'d': 77, 'e': 88})
    fact_cache.first_order_merge('192.168.1.2', {'e': 99, 'f': 100})


# Generated at 2022-06-25 14:12:12.867579
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # This test rootfs is initialized with the content of a test file.
    # We initialize with a test file.
    fact_cache_0 = FactCache()
    # Check if the inventory has a value for hostname myserver1.mydomain.com
    fact_cache_0.first_order_merge('ansible_local', {
        'mysterious_fact': False
    })

    # Check if the inventory has a value for hostname myserver2.mydomain.com
    fact_cache_0.first_order_merge('ansible_local', {
        'mysterious_fact': False
    })



# Generated at 2022-06-25 14:12:14.355078
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:12:22.307673
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    key = 'key_test'

# Generated at 2022-06-25 14:12:23.416655
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert(fact_cache)


# Generated at 2022-06-25 14:12:27.241649
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    a_key = 'a'
    a_value = 'A'
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge(a_key, a_value)
    assert fact_cache_0[a_key] == a_value
    assert fact_cache_0.keys() == [a_key]


# Generated at 2022-06-25 14:12:28.329473
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache != None


# Generated at 2022-06-25 14:12:29.443519
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()


# test for copy() method of class FactCache

# Generated at 2022-06-25 14:12:30.234294
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()


# Generated at 2022-06-25 14:12:37.070545
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    fact_cache = FactCache()

    # Test with HostVars as key and facts as value
    # Update the host_cache if host_cache already exists
    fact_cache.first_order_merge(key="host_vars_0", value={"ansible_hostname": "host_0"})
    assert fact_cache["host_vars_0"]["ansible_hostname"] == "host_0"

    # Test with HostVars as key and facts as value
    # Update the host_cache if host_cache already exists
    fact_cache.first_order_merge(key="host_vars_0", value={"ansible_hostname": "host_0_new"})
    assert fact_cache["host_vars_0"]["ansible_hostname"] == "host_0_new"



# Generated at 2022-06-25 14:15:07.537442
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        fact_cache = FactCache(
            '/Me/Path/', '**.wrong', 'whatever')
        assert fact_cache.__init__('/Me/Path/', '**.wrong', 'whatever')
        assert fact_cache.__init__('/Me/Path/', '**.wrong')
        assert fact_cache.__init__('/Me/Path/')
        assert fact_cache.__init__()
    except Exception as e:
        print(e)
        print('Exception in test_FactCache')
        raise Exception(e)



# Generated at 2022-06-25 14:15:08.543333
# Unit test for constructor of class FactCache
def test_FactCache():
    assert(len(fact_cache_0) == 0)


# Generated at 2022-06-25 14:15:11.271318
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        test_case_0()
    except Exception as e:
        print("Failed")
        print("test_case_0()")
        print(e)
        raise e


if __name__ == '__main__':
    test_FactCache()

# Generated at 2022-06-25 14:15:19.186143
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge('test_string', 'test_value')
    assert fact_cache_1.keys() == ['test_string']

    fact_cache_2 = FactCache()
    fact_cache_2.first_order_merge('test_string', 'test_value')
    fact_cache_2.first_order_merge('test_string', 'test_value_new')
    assert fact_cache_2.keys() == ['test_string']
    assert fact_cache_2['test_string'] == 'test_value_new'

    fact_cache_3 = FactCache()
    fact_cache_3.first_order_merge('test_dict', {'key_1': 1, 'key_2': 2})
    assert fact