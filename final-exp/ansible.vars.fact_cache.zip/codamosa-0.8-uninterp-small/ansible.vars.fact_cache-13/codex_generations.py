

# Generated at 2022-06-25 14:05:22.048807
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge('example_key_1', 'example_value_1')
    fact_cache_0.first_order_merge('example_key_1', 'example_value_2')


# Generated at 2022-06-25 14:05:24.286452
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    assert fact_cache_0.first_order_merge(key='foo', value='bar') == None


# Generated at 2022-06-25 14:05:33.673124
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    test_case_0()
    test_host = "host2"

    fact_cache_1 = FactCache()
    fact_cache_1[test_host] = {'ansible_host': 'host2'}

    fact_cache_1.first_order_merge(test_host, {'ansible_lsb': {'codename': 'trusty', 'description': 'Ubuntu 14.04.3 LTS', 'id': 'Ubuntu', 'major_release': '14.04', 'release': '14.04.3 LTS'}})

    # verify cache status
    assert len(fact_cache_1) == 1
    assert test_host in fact_cache_1
    assert isinstance(fact_cache_1[test_host], dict)


# Generated at 2022-06-25 14:05:36.119209
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge('key', 'value')


# Generated at 2022-06-25 14:05:40.992457
# Unit test for constructor of class FactCache
def test_FactCache():

    fact_cache = {}
    fact_cache.update({"192.168.1.11": {"foo": "bar", "hello": "world"}})
    fact_cache.update({"192.168.1.12": {"foo": "bar", "hello": "world"}})

    assert len(fact_cache) == 2


# Generated at 2022-06-25 14:05:48.315963
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    new_fact = {
        "ansible_processor_cores": 2,
        "ansible_processor_count": 4,
        "ansible_processor_threads_per_core": 2,
    }
    host_name = "fake-host"
    fact_cache.first_order_merge(host_name, new_fact)
    host_cache = fact_cache["fake-host"]
    assert host_cache == new_fact
    new_fact = {
        "ansible_processor_cores": 4,  # This value should not be reverted
        "ansible_processor_count": 4,
        "ansible_processor_threads_per_core": 2,
    }
    fact_cache.first_order_merge(host_name, new_fact)
   

# Generated at 2022-06-25 14:05:49.759064
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()


# Generated at 2022-06-25 14:05:55.134696
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        test_case_0()
        display.display('OK: %s' % ('FactCache()'))
    except Exception as e:
        display.display('ERROR: %s' % ('test case: %s' % ('test_case_0')))
        display.display(e)

# Generated at 2022-06-25 14:05:57.003860
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()
    print("FactCache() ---> Successful")


# Generated at 2022-06-25 14:06:00.371143
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge('localhost', {'localhost': 'localhost'})
    assert fact_cache_1['localhost'] == {'localhost': 'localhost'}


# Generated at 2022-06-25 14:06:11.258135
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_test = FactCache()
    dict = {'ansible_test_key': 'ansible_test_value',
            'ansible_test_key2': 'ansible_test_value2'}
    fact_cache_test.update(dict)
    assert fact_cache_test == dict
    assert fact_cache_test['ansible_test_key'] == 'ansible_test_value'
    assert fact_cache_test['ansible_test_key1'] == None
    assert fact_cache_test['ansible_test_key2'] == 'ansible_test_value2'
    key = dict.keys()[1]
    fact_cache_test[key] = 'ansible_test_value3'

# Generated at 2022-06-25 14:06:14.516535
# Unit test for constructor of class FactCache
def test_FactCache():
    host_facts = {}
    host_cache = {}
    value = {}
    key = 'test'
    fact_cache = FactCache()
    assert fact_cache.first_order_merge(key, value) == 0

# Generated at 2022-06-25 14:06:18.007032
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0.__class__ is FactCache
    assert isinstance(fact_cache_0, dict)


# Generated at 2022-06-25 14:06:19.347961
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:06:20.620608
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:06:25.752549
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Create an instance of the object to be tested
    fact_cache = FactCache()

    # Set up the test inputs
    key = "key"
    value = "value"

    # Call the method under test
    fact_cache.first_order_merge(key, value)

    # Check the results
    assert fact_cache[key] == value

# Generated at 2022-06-25 14:06:32.669739
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()
    # Unit test for copy of class FactCache
    fact_cache_2 = fact_cache_1.copy()
    # Unit test for flush of class FactCache
    fact_cache_1.flush()
    # Unit test for keys of class FactCache
    fact_cache_1.keys()
    # Unit test for first_order_merge of class FactCache
    fact_cache_1.first_order_merge('key', 'value')
    fact_cache_1['key'] = 'value'
    del fact_cache_1['key']

# Generated at 2022-06-25 14:06:33.650291
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:06:37.505523
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge('localhost', {'ansible_facts': {'a': 'b'}})
    fact_cache_1.first_order_merge('localhost', {'ansible_facts': {'a': 'c'}})
    ansible_facts = fact_cache_1['localhost'].pop('ansible_facts')
    assert ansible_facts == {'a': 'c'}

# Generated at 2022-06-25 14:06:39.917234
# Unit test for constructor of class FactCache
def test_FactCache():
    display.display('test: constructor of class FactCache')
    test_case_0()

# unit test for def __getitem__(self, key):

# Generated at 2022-06-25 14:06:45.564168
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.module_utils.six import PY3
    import __builtin__
    if PY3:
        import builtins
        builtins.__dict__['__loader__'] = 'foo'
    else:
        __builtin__.__dict__['__loader__'] = 'foo'
    test_case_0()

# Generated at 2022-06-25 14:06:46.911355
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)


# Generated at 2022-06-25 14:06:49.380728
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

# Generated at 2022-06-25 14:07:00.193626
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert(len(fc) == 0)
    for i in range(5):
        fc[i] = i*10
    assert(str(fc) == "{0: 0, 1: 10, 2: 20, 3: 30, 4: 40}")
    assert(str(fc.keys()) == "[0, 1, 2, 3, 4]")
    assert(str(fc.flush()) == None)
    assert(str(fc[0]) == "0")
    del fc[4]
    assert(len(fc) == 4)
    fc.first_order_merge('newKey', 20)
    assert(len(fc) == 5)
    assert(fc.__contains__('newKey') == True)

# Generated at 2022-06-25 14:07:01.080643
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

# Generated at 2022-06-25 14:07:02.470875
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        FactCache()
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-25 14:07:04.137597
# Unit test for constructor of class FactCache
def test_FactCache():

    # Init
    fact_cache_0 = FactCache()

    # Test attribute __plugin
    assert fact_cache_0._plugin == fact_cache_0.__plugin



# Generated at 2022-06-25 14:07:16.289727
# Unit test for constructor of class FactCache
def test_FactCache():
    arg0 = 'host1'
    arg1 = {}
    arg1['ansible_distribution'] = 'Ubuntu'
    arg1['ansible_distribution_release'] = '18.04'
    arg1['ansible_distribution_version'] = '18.04'
    arg1['ansible_userspace_bits'] = '64'
    arg1['ansible_machine_id'] = '3d1ddd1425adca54b9adbd2b81f7b73e'
    arg1['ansible_product_name'] = 'Ubuntu'
    arg1['ansible_product_serial'] = '1234-5678-abcd'
    arg1['ansible_machine'] = 'x86_64'
    arg1['ansible_system'] = 'Linux'

# Generated at 2022-06-25 14:07:22.720243
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    assert fact_cache._plugin.keys() == []
    fact_cache.first_order_merge("test_host01", {"test_fact": "test_value"})
    assert len(fact_cache._plugin.keys()) == 1
    assert fact_cache._plugin.keys() == ["test_host01"]
    assert fact_cache._plugin.get("test_host01") == {"test_fact": "test_value"}



# Generated at 2022-06-25 14:07:24.725811
# Unit test for constructor of class FactCache
def test_FactCache():
    # Test with no arg.
    try:
        test_case_0()
    except NotImplementedError:
        pass
    except:
        raise



# Generated at 2022-06-25 14:07:33.603561
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0.__class__.__name__ == 'FactCache'
    assert fact_cache_0.__class__.__module__ == 'ansible.cache'


# Generated at 2022-06-25 14:07:36.141894
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        test_case_0()
    except Exception as e:
        print("Failed to initialize class FactCache: " + str(e))


test_FactCache()

# Generated at 2022-06-25 14:07:37.102092
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()


# Generated at 2022-06-25 14:07:41.472253
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    from ansible.errors import AnsibleError
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.plugins.loader import cache_loader
    from ansible.utils.display import Display


    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:07:49.277964
# Unit test for constructor of class FactCache
def test_FactCache():

    # Create two FactCache instances
    fc0 = FactCache()
    fc1 = FactCache()

    # Populate the caches
    fc0['foo'] = 'bar'
    fc1['foo'] = 'baz'
    fc0['bar'] = 'baz'
    fc1['baz'] = 'qux'

    # Verify that the keys are unique between the instances
    assert set(fc0.keys()) == set(['foo', 'bar'])
    assert set(fc1.keys()) == set(['foo', 'baz'])

    # Verify that the values are unique between the instances
    assert fc0['foo'] == 'bar'
    assert fc1['foo'] == 'baz'
    assert fc1['baz'] == 'qux'

# Generated at 2022-06-25 14:07:51.504910
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()
    assert fact_cache_1 != None, "FactCache constructor is broken"

# test the set() method

# Generated at 2022-06-25 14:08:01.912724
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    host_cache_0 = {
        '0': '1',
        '1': '2',
        '2': '3',
    }
    host_facts_0 = {
        '0': '1',
        '1': '2',
        '2': '3',
    }
    host_cache_1 = {
        '3': '4',
        '4': '5',
        '5': '6',
    }
    host_facts_1 = {
        '3': '7',
        '4': '5',
        '5': '6',
    }

# Generated at 2022-06-25 14:08:09.095689
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    display.debug('TESTING first_order_merge')

    fc = FactCache()
    fc.first_order_merge('key1', 'value1')

    got = fc.copy()
    assert got['key1'] == 'value1'

    fc.first_order_merge('key1', 'value2')
    got = fc.copy()
    assert got['key1'] == 'value2'

    fc.first_order_merge('key2', 'value3')
    got = fc.copy()
    assert got['key1'] == 'value2'
    assert got['key2'] == 'value3'

# Generated at 2022-06-25 14:08:10.787764
# Unit test for constructor of class FactCache
def test_FactCache():
    assert isinstance(FactCache(), FactCache)


# Generated at 2022-06-25 14:08:14.209817
# Unit test for constructor of class FactCache
def test_FactCache():
    assert isinstance(FactCache(),MutableMapping)
    assert isinstance(FactCache(),object)
    assert issubclass(FactCache(),MutableMapping)
    assert issubclass(FactCache(),object)

# Generated at 2022-06-25 14:08:28.415067
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        newfactcache = FactCache()
    except ImportError:
        # No plugin cache available
        pass


# Generated at 2022-06-25 14:08:34.960472
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.plugins.loader import cache_loader
    from ansible.plugins.cache import memory
    import pytest

    test_FactCache = FactCache()

    # plugin
    assert test_FactCache._plugin == memory
    assert isinstance(test_FactCache._plugin, cache_loader.CacheModule)

    test_FactCache.__init__()
    # plugin
    assert test_FactCache._plugin == memory
    assert isinstance(test_FactCache._plugin, cache_loader.CacheModule)


# Generated at 2022-06-25 14:08:36.372329
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)
    assert isinstance(fact_cache, MutableMapping)

# Generated at 2022-06-25 14:08:43.664282
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_1 = FactCache()
    FACT_CACHE_KEYS = ['a','b']
    FACT_KEYS = ['c','d']
    fact_cache_0.first_order_merge({'hostname':FACT_CACHE_KEYS[0]},
                                   {'hostname':FACT_KEYS[0],
                                    'groupnames':FACT_KEYS[1]})
    fact_cache_1.first_order_merge({'hostname':FACT_CACHE_KEYS[1]},
                                   {'hostname':FACT_KEYS[0],
                                    'groupnames':FACT_KEYS[1]})
    # The two FactCache objects now contains two keys, one for each host. 


# Generated at 2022-06-25 14:08:47.862843
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    """
    Unit test for method first_order_merge of class FactCache
    """
    # setup
    cache = FactCache()
    cache.update({'fact': 'dict'})

    # test
    cache.first_order_merge('fact', [])

    assert 'fact' in cache
    assert isinstance(cache['fact'], list)



# Generated at 2022-06-25 14:08:49.372301
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc == {}


# Generated at 2022-06-25 14:08:53.252315
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    current_host = 'test_host_0'
    fact_cache_entry = {'test_key_0': 'test_value_0'}
    fact_cache.first_order_merge(current_host, fact_cache_entry)


# Generated at 2022-06-25 14:08:55.019304
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()
    assert fact_cache_1
    print("FactCache test case passed!")


# Generated at 2022-06-25 14:08:56.862096
# Unit test for constructor of class FactCache
def test_FactCache():
    print("Constructor of class FactCache")
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:08:59.927611
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    key = 'localhost'
    value = {'foo': 'bar'}
    fact_cache_1.first_order_merge(key, value)

# Generated at 2022-06-25 14:09:27.283843
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert(fact_cache is not None)
    assert(fact_cache.keys() == [])


# Generated at 2022-06-25 14:09:29.846009
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge("test_key", {"key1":"value1"})
    assert(fact_cache["test_key"] == {"key1":"value1"})


# Generated at 2022-06-25 14:09:30.691841
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

# Generated at 2022-06-25 14:09:33.122715
# Unit test for constructor of class FactCache
def test_FactCache():
    display.display("Test2 - method test_FactCache()")
    test_case_0()
    display.display("Test2 - method test_FactCache() passed :)")

if __name__ == '__main__':
    test_FactCache()

# Generated at 2022-06-25 14:09:36.731772
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge(u'key_string', u'value_string')



# Generated at 2022-06-25 14:09:38.613178
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

if __name__ == '__main__':
    test_FactCache()

# Generated at 2022-06-25 14:09:42.511991
# Unit test for constructor of class FactCache
def test_FactCache():
    # Create a FactCache object
    fact_cache_0 = FactCache()
    # Attempting to access a member variable or function of an object raises AttributeError
    with pytest.raises(AttributeError):
        fact_cache_0.does_not_exist


# Generated at 2022-06-25 14:09:47.887947
# Unit test for constructor of class FactCache
def test_FactCache():
    cache_loader.set(C.CACHE_PLUGIN, "memory")
    fact_cache = FactCache()
# assert fact_cache.__getitem__("example")
# assert fact_cache.__setitem__("example", "test")
    assert fact_cache.__setitem__("example", "test")
# assert fact_cache.__setitem__("example", "test")
    assert fact_cache.__delitem__("example")

# Generated at 2022-06-25 14:09:49.118983
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache


# Generated at 2022-06-25 14:09:54.813974
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    print('Testing first_order_merge of class FactCache')
    test_fact_cache = FactCache()
    test_host = 'host'
    test_value = {'key_1': 'value_1', 'key_2': 'value_2'}
    test_fact_cache.first_order_merge(test_host, test_value)
    assert test_fact_cache['host']['key_1'] == 'value_1'
    assert test_fact_cache['host']['key_2'] == 'value_2'



# Generated at 2022-06-25 14:10:59.525333
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Create a new instance of class FactCache
    fact_cache = FactCache()
    # Create a new instance of class _LowLevelCache
    _low_level_cache = cache_loader.get(C.CACHE_PLUGIN)()

    # Set value for 'dict'
    facts = {'first': 'value'}
    host = 'hostname'
    fact_cache._plugin = _low_level_cache
    fact_cache.first_order_merge(host, facts)

    # Get value for 'dict'
    expected = {'first': 'value'}
    actual = fact_cache.get(host)
    assert expected == actual

# Generated at 2022-06-25 14:11:00.742312
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)


# Generated at 2022-06-25 14:11:02.533973
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        assert fact_cache_0
    except NameError:
        assert False, "Unable to find expected object 'fact_cache_0'"
# Test for set() function

# Generated at 2022-06-25 14:11:05.392938
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()

    # no keys in the cache
    value = fact_cache_0.keys()
    assert len(value) == 0


# Generated at 2022-06-25 14:11:08.851013
# Unit test for constructor of class FactCache
def test_FactCache():
    display.info("Running test_FactCache")
    test_case_0()
    display.info("Done running test_FactCache")


# Generated at 2022-06-25 14:11:17.124559
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Create an instance of class FactCache
    fact_cache = FactCache()
    fact_cache.flush()

    fact_cache._plugin.set('1', {'ansible_proc_cpuinfo': {'processor': 4}})
    fact_cache._plugin.set('2', {'ansible_proc_cpuinfo': {'processor': 4}})

    assert fact_cache._plugin.contains('1') == True
    assert fact_cache._plugin.contains('2') == True
    assert fact_cache._plugin.get('1') == {'ansible_proc_cpuinfo': {'processor': 4}}
    assert fact_cache._plugin.get('2') == {'ansible_proc_cpuinfo': {'processor': 4}}

    # Merge host fact cache (host_facts) with the existing cache

# Generated at 2022-06-25 14:11:23.474543
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    fact_cache_0['localhost'] = dict(ansible_facts = dict(ansible_all_ipv4_addresses = ['10.0.0.1']))
    assert fact_cache_0['localhost']['ansible_facts']['ansible_all_ipv4_addresses'][0] == '10.0.0.1'
    assert len(fact_cache_0) == 1
    assert fact_cache_0.keys()[0] == 'localhost'
    fact_cache_0.flush()
    assert fact_cache_0.keys() == []

if __name__ == "__main__":
    test_FactCache()

# Generated at 2022-06-25 14:11:27.181502
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    host_0 = 'host_0'
    value_0 = {}
    fact_cache_0.first_order_merge(host_0, value_0)


# Generated at 2022-06-25 14:11:28.802306
# Unit test for constructor of class FactCache

# Generated at 2022-06-25 14:11:36.934178
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge('host_0', {'pkg_mgr': 'yum'})
    fact_cache_1.first_order_merge('host_0', {'pkg_mgr': 'yum', 'a': 'b'})
    fact_cache_1.first_order_merge('host_0', {'c': 'd'})
    fact_cache_1.first_order_merge('host_1', {'pkg_mgr': 'apt', 'e': 'f'})
    fact_cache_1.first_order_merge('host_1', {'g': 'h'})
    assert isinstance(fact_cache_1, FactCache)

# Generated at 2022-06-25 14:12:43.775677
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache.__class__.__name__ == 'FactCache'


# Generated at 2022-06-25 14:12:45.118092
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    print(type(fact_cache))


# Generated at 2022-06-25 14:12:46.307155
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)


# Generated at 2022-06-25 14:12:50.750366
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge("key_1", {"fact_1": "fact_1_value"})
    fact_cache_1.first_order_merge("key_1", {"fact_1": "fact_1_new_value"})
    fact_cache_1.first_order_merge("key_2", {"fact_1": "fact_1_value"})

# Generated at 2022-06-25 14:12:57.820721
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc.first_order_merge('some_host', {'new_fact': 'new_value'})
    assert fc['some_host']['new_fact'] == 'new_value'
    fc.first_order_merge('some_host', {'newer_fact': 'newer_value'})
    assert fc['some_host']['newer_fact'] == 'newer_value'
    assert fc['some_host']['new_fact'] == 'new_value'
    fc.first_order_merge('some_host', {'new_fact': 'updated_value'})
    assert fc['some_host']['new_fact'] == 'updated_value'

# Generated at 2022-06-25 14:13:00.483830
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge('host1', {'a': 'b'})

# Generated at 2022-06-25 14:13:03.847351
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0._plugin == cache_loader.get(C.CACHE_PLUGIN)
    assert fact_cache_0._plugin.keys() == []


# Generated at 2022-06-25 14:13:05.353119
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert(fact_cache_0.keys() == [])


# Generated at 2022-06-25 14:13:06.111186
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()
    return fact_cache_1.flush()


# Generated at 2022-06-25 14:13:12.142904
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache['localhost'] = {'ansible_env': {'LANG': 'en_US.UTF-8'}}
    fact_cache.first_order_merge('localhost', {'ansible_env': {'HOME': '/home/user'}})
    assert fact_cache['localhost']['ansible_env']['LANG'] == 'en_US.UTF-8'