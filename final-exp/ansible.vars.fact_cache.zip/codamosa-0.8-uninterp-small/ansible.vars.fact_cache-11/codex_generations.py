

# Generated at 2022-06-25 14:05:24.323163
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    key_0 = ''
    value_0 = ''
    assert fact_cache_0.first_order_merge(key_0, value_0) == None


# Generated at 2022-06-25 14:05:25.976051
# Unit test for constructor of class FactCache
def test_FactCache():
    int_0 = -1250
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:05:29.357484
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    fact_cache_0 = FactCache()
    str_0 = 'f4F9D]|q8d:Z'
    int_0 = -2539
    assert fact_cache_0.first_order_merge(str_0, int_0) == None


# Generated at 2022-06-25 14:05:31.890344
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    int_0 = -1250
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge('test',{})


# Generated at 2022-06-25 14:05:42.251439
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # fact_cache_0 is an instance of FactCache
    fact_cache_0 = FactCache()
    # key_0 is a key in fact_cache_0 keyset

# Generated at 2022-06-25 14:05:46.314596
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    fact_cache_0 = FactCache()
    assert fact_cache_0 == {}
    
    fact_cache_0.first_order_merge("a", "b")
    assert fact_cache_0 == {"a": "b"}
    
    fact_cache_0.first_order_merge("d", "b")
    assert fact_cache_0 == {"a": "b", "d": "b"}

# Generated at 2022-06-25 14:05:57.621366
# Unit test for constructor of class FactCache
def test_FactCache():
    int_0 = -1250
    fact_cache_0 = FactCache()
    #assert fact_cache_0.__repr__() == "$plugin: $plugin"
    int_1 = -1299
    str_2 = "fds"
    assert fact_cache_0[str_2] == fact_cache_0.get(str_2)
    int_1 = -1291
    str_2 = "fds"
    fact_cache_0[str_2] = fact_cache_0.get(str_2)
    int_1 = -1303
    str_2 = "fds"
    fact_cache_0[str_2] = fact_cache_0.get(str_2)
    int_1 = -1305
    str_2 = "fds"
    fact_cache_

# Generated at 2022-06-25 14:06:07.504680
# Unit test for constructor of class FactCache
def test_FactCache():
    int_0 = -863735781
    int_1 = -1219386852
    int_2 = -928191792
    int_3 = -83466044
    fact_cache_0 = FactCache()
    fact_cache_0.clear()
    assert(len(fact_cache_0) == 0)
    fact_cache_0.clear()
    assert(len(fact_cache_0) == 0)
    assert(not fact_cache_0)
    fact_cache_0 = FactCache()
    fact_cache_0.clear()
    assert(len(fact_cache_0) == 0)
    fact_cache_0.clear()
    assert(len(fact_cache_0) == 0)
    assert(not fact_cache_0)
    fact_cache_0 = FactCache

# Generated at 2022-06-25 14:06:10.586864
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    fact_cache_1 = FactCache()
    t_0 = fact_cache_0 is fact_cache_1
    t_0 = not t_0
    t_1 = t_0


# Generated at 2022-06-25 14:06:16.034108
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    key_0 = "Sf<"
    value_0 = {key_0: [0.36297847623582457, -0.037283762913961376, "Nil"]}
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge(key_0, value_0)



# Generated at 2022-06-25 14:06:25.302412
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    assert fact_cache_0._plugin == cache_loader.get(C.CACHE_PLUGIN) == cache_loader.get('memory')
    # And now we'll check that it indeed is an instance of the memory cache
    from ansible.plugins.cache.memory import CacheModule as CM
    assert isinstance(fact_cache_0._plugin, CM)
    # And now we can test the first_order_merge method
    host="test_host_0"
    key="key_0"
    value="value_0"
    fact_cache_0.first_order_merge(host, {key: value})
    # We can check that it is indeed in the cache
    assert fact_cache_0[host][key] == value
    # And now we'll update the value


# Generated at 2022-06-25 14:06:28.411167
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        test_case_0()
    except (AnsibleError) as e:
        display.display('fact_cache.py: Exception thrown: %s' % e, color='red')
        return False

    return True

# Generated at 2022-06-25 14:06:30.646045
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0.__class__.__name__ == 'FactCache'

# Generated at 2022-06-25 14:06:39.419556
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()

    # Test with host_facts being dictionary
    fact_cache_1.first_order_merge(host="host1", value={'host_id': '2'})
    if fact_cache_1['host1'] != {'host_id': '2'}:
        raise AssertionError()
    fact_cache_1.first_order_merge(host="host2", value={'host_id': '1'})
    if fact_cache_1['host2'] != {'host_id': '1'}:
        raise AssertionError()

    # Test for runtime error for host_facts not being dictionary type

# Generated at 2022-06-25 14:06:45.873643
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge("host_0", {'ansible_facts': {'test_fact_0': ['value_0']}})
    fact_cache_1.first_order_merge("host_1", {'ansible_facts': {'test_fact_1': ['value_1']}})
    fact_cache_1.first_order_merge("host_2", {'ansible_facts': {'test_fact_2': ['value_2']}})
    fact_cache_1.flush()

# Generated at 2022-06-25 14:06:57.954402
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    ansible_hostname1 = "Test"
    ansible_hostname2 = "Test1"
    ansible_hostname3 = "Test2"

    fact_cache.first_order_merge('Test', {'ansible_hostname': ansible_hostname1})
    print(fact_cache['Test'])
    print(fact_cache._plugin._cache[0]['Test']['ansible_hostname'])
    fact_cache.first_order_merge('Test', {'ansible_hostname': ansible_hostname2})
    print(fact_cache['Test'])
    print(fact_cache._plugin._cache[0]['Test']['ansible_hostname'])

# Generated at 2022-06-25 14:07:01.081071
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    key = "key"
    value = "value"
    fact_cache_0.first_order_merge(key, value)
    assert 1 == len(fact_cache_0)


# Generated at 2022-06-25 14:07:02.786538
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    key = "123"
    value = "456"

    fact_cache_1.first_order_merge(key, value)

    assert fact_cache_1[key] == value

# Generated at 2022-06-25 14:07:03.539364
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:07:07.938121
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0['var_1'] = 'val_1'
    try:
        assert fact_cache_0['var_1'] == 'val_1'
    except:
        assert False


# Generated at 2022-06-25 14:07:11.973428
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert isinstance(fc, FactCache)

# Generated at 2022-06-25 14:07:15.477492
# Unit test for constructor of class FactCache
def test_FactCache():
    # Test for method __init__(self)
    assert_exists(FactCache, '__init__')
    test_case_0()



# Generated at 2022-06-25 14:07:18.022249
# Unit test for constructor of class FactCache
def test_FactCache():
    with pytest.raises(AnsibleError):
        fact_cache_0 = FactCache()
        assert fact_cache_0.__class__.__name__  == "FactCache"

# Generated at 2022-06-25 14:07:24.504544
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    key = 'hostname'
    value = {'a':1,'b':2,'c':"hello"}
    fact_cache = FactCache()

    # Before setting, the key is not in the fact_cache
    assert key not in fact_cache

    # Try to set the values
    fact_cache.first_order_merge(key, value)

    # The key should be there in the fact_cache
    assert key in fact_cache

    # test the key, value pair
    assert fact_cache.get(key) == value

# Generated at 2022-06-25 14:07:29.402392
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        fact_cache = FactCache()
    except Exception as e:
        print(e)
        assert 0, "Unexpected error when creating class FactCache: " + str(e)
    else:
        assert 1, "Class FactCache created successfully"



# Generated at 2022-06-25 14:07:34.387113
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge('var_a', 1)
    fact_cache_1.first_order_merge('var_a', 2)
    fact_cache_1.first_order_merge('var_a', 3)

    assert fact_cache_1['var_a'] == 3


# Generated at 2022-06-25 14:07:36.520496
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    test_case_0()

if __name__ == "__main__":
    test_FactCache()

# Generated at 2022-06-25 14:07:37.735958
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:07:39.292956
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

if __name__ == '__main__':
    test_FactCache()

# Generated at 2022-06-25 14:07:41.342740
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache


# Generated at 2022-06-25 14:07:47.093048
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    key = 'example.com'
    value = {"ansible_connection": "local", "ansible_host": "localhost"}
    fact_cache_1.first_order_merge(key, value)
    assert fact_cache_1[key] == value
    fact_cache_1.first_order_merge(key, value)
    assert fact_cache_1[key] == value


# Generated at 2022-06-25 14:07:49.601923
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc

if __name__ == '__main__':
    test_case_0()
    test_FactCache()

# Generated at 2022-06-25 14:07:51.462008
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()


if __name__ == '__main__':
    test_FactCache()

# Generated at 2022-06-25 14:07:54.085263
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    key = 'localhost'
    value = '127.0.0.1'
    assert fact_cache_0.first_order_merge(key, value)

# Generated at 2022-06-25 14:08:04.577723
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:08:08.095955
# Unit test for constructor of class FactCache
def test_FactCache():
    '''
    Test case 0: Testing constructor
    '''
    print('Testing constructor')
    test_case_0()
    print('Constructor test successful')


if __name__ == "__main__":
    test_FactCache()

# Generated at 2022-06-25 14:08:18.306563
# Unit test for constructor of class FactCache
def test_FactCache():
    from importlib import reload
    import ansible.plugins.loader
    reload(ansible.plugins.loader)
    from ansible.plugins.loader import cache_loader
    from ansible.plugins.cache.jsonfile import CacheModule as CacheJsonfile

    class TestCache(CacheJsonfile):
        def __init__(self, *args, **kwargs):
            pass

    reload(cache_loader)

    cache_loader.fact_cache = cache_loader._fact_cache = None
    cache_loader.get_all.cache_clear()
    cache_loader.get.cache_clear()
    cache_loader.set.cache_clear()
    cache_loader.delete.cache_clear()
    cache_loader.flush.cache_clear()
    cache_loader.contains.cache_clear()

    reload(cache_loader)

# Generated at 2022-06-25 14:08:23.167310
# Unit test for constructor of class FactCache
def test_FactCache():
    """ Unit test for the constructor of class FactCache """

    # Test the constructor of class FactCache
    hosts = [
        'localhost',
        '127.0.0.1'
    ]
    fact_cache_0 = FactCache()
    fact_cache_1 = FactCache(hosts)


# Generated at 2022-06-25 14:08:24.043988
# Unit test for constructor of class FactCache
def test_FactCache():
    assert fact_cache_0 is not None



# Generated at 2022-06-25 14:08:30.637720
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    """
    :param key: The name of the host to update facts for.
    :param value: A dict of fact names and values.
    :return: None
    """

    # Case - 1
    # Input:
    # fact_cache = {'a': {'x': 'y'}}
    # key = 'a', value = {'z': 'w'}
    # Expected output:
    # updated_fact_cache = {'a': {'x': 'y', 'z': 'w'}}

    expected_output = {'a': {'x': 'y', 'z': 'w'}}

    fact_cache = {'a': {'x': 'y'}}
    fact_cache_object = FactCache(fact_cache)

    key = 'a'
    value = {'z': 'w'}

# Generated at 2022-06-25 14:08:34.680357
# Unit test for constructor of class FactCache
def test_FactCache():
    """
    FactCache Class is instantiated and tested called with default
    """
    FactCache()


if __name__ == '__main__':
    test_case_0()
    test_FactCache()

# Generated at 2022-06-25 14:08:35.436522
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0

# Generated at 2022-06-25 14:08:36.980566
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    fact_cache_1 = FactCache()
    assert fact_cache_0 == fact_cache_1, "__eq__ does not work"


# Generated at 2022-06-25 14:08:38.402987
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    print("in class FactCache")
    fact_cache_1 = FactCache()
    assert fact_cache_0 == fact_cache_1

# Generated at 2022-06-25 14:08:40.361226
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    key = 'localhost'
    value = {'a': 'b', 'c': 'd'}
    fact_cache_0.first_order_merge(key, value)


# Generated at 2022-06-25 14:08:41.516817
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:08:45.873429
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    host_cache_1 = {'first_order': 'merged'}
    host_facts_1 = {'first_order': 'merged'}
    fact_cache_1.first_order_merge('host_cache_1', host_cache_1)
    assert host_facts_1 == fact_cache_1


# Generated at 2022-06-25 14:08:53.774780
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    fact_cache['key'] = 'value'
    fact_cache.setdefault('key', 'value')
    host_facts = fact_cache.copy()
    fact_cache.flush()
    fact_cache.first_order_merge('key', 'value')
    host_cache = fact_cache.get('key')
    host_cache = fact_cache.get('key', 'value')
    contains = fact_cache.has_key('key')
    fact_cache.update({'key': 'value'})
    fact_cache.update({'key': 'value'}, {'key2': 'value2'})
    fact_cache.values()

# Generated at 2022-06-25 14:09:04.548852
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_2 = FactCache()
    fact_cache_3 = FactCache()
    fact_cache_4 = FactCache()
    fact_cache_5 = FactCache()
    fact_cache_6 = FactCache()
    fact_cache_7 = FactCache()
    fact_cache_8 = FactCache()

    # Case 1 - successful test case
    value1 = [1, 2, 3]
    value2 = [4, 5, 6]
    host1 = 'host1'
    fact_cache_1.first_order_merge(host1, value1)
    fact_cache_1.first_order_merge(host1, value2)
    assert(fact_cache_1[host1] == [1, 2, 3, 4, 5, 6])



# Generated at 2022-06-25 14:09:06.513167
# Unit test for constructor of class FactCache
def test_FactCache():
    # test 0: constructor
    test_case_0()

if __name__ == "__main__":
    test_FactCache()

# Generated at 2022-06-25 14:09:12.394760
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    # key: moka
    # value: mario
    fact_cache_1 = FactCache()
    fact_cache_1["moka"] = "mario"
    assert fact_cache_1["moka"] == "mario"


# Generated at 2022-06-25 14:09:19.316988
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1['localhost'] = { fact_cache_1: ['localhost', '127.0.0.1'] }
    fact_cache_1.first_order_merge('localhost', {'foo': 'bar'})
    # Display.display('%s' % fact_cache_1)
    assert {'localhost': {'foo': 'bar', 'localhost': ['localhost', '127.0.0.1']}} == fact_cache_1


# Generated at 2022-06-25 14:09:21.931310
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()


if __name__ == "__main__":
    test_FactCache()

# Generated at 2022-06-25 14:09:22.860441
# Unit test for constructor of class FactCache
def test_FactCache():
    assert len(FactCache()) == 0

# Generated at 2022-06-25 14:09:31.019865
# Unit test for constructor of class FactCache

# Generated at 2022-06-25 14:09:33.098041
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    keys_0 = fact_cache_0.keys()
    assert keys_0 == [], 'keys() returns the keys in the object'


# Generated at 2022-06-25 14:09:36.287044
# Unit test for constructor of class FactCache
def test_FactCache():
    f = FactCache(a=1, b=2)
    assert(f == {'a':1, 'b':2})


# Generated at 2022-06-25 14:09:46.415868
# Unit test for constructor of class FactCache
def test_FactCache():
    """ This test will create a FactCache object and use it to test the
    methods add, copy, and clear.
    """
    fact_cache = FactCache()
    # Initialize the value to be a dictionary
    value = {"a": "b"}
    fact_cache['test_1'] = value
    assert fact_cache['test_1']['a'] == "b"
    # Add a new value to the existing dictionary
    fact_cache['test_1']['c'] = "d"
    assert fact_cache['test_1']['c'] == "d"
    # create a copy of the dictionary
    copy_value = fact_cache.copy()
    assert copy_value['test_1']['a'] == "b"
    assert copy_value['test_1']['c'] == "d"
   

# Generated at 2022-06-25 14:09:54.477518
# Unit test for constructor of class FactCache
def test_FactCache():

    #set AUTH_PASS parameter
    C.ANSIBLE_CACHE_PLUGIN_CONNECTION = "dummy"
    C.ANSIBLE_CACHE_PLUGIN = "jsonfile"
    C.ANSIBLE_CACHE_PLUGIN_PREFIX = "ansible_fact_"
    C.ANSIBLE_CACHE_PLUGIN_TIMEOUT = 3600

    #load module
    C.DEFAULT_MODULE_PATH = 'namespace'
    C.MODULE_PATH = C.DEFAULT_MODULE_PATH

    #get an instance of class FactCache
    fact_cache = FactCache()
    assert fact_cache != None

    #get an instance of class CacheModule
    cache_module = cache_loader.get(C.CACHE_PLUGIN)
    assert cache_module

# Generated at 2022-06-25 14:09:55.238508
# Unit test for constructor of class FactCache
def test_FactCache():
    assert test_case_0() != None

# Generated at 2022-06-25 14:10:07.574203
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()

    # test case 1
    new_facts = {}
    fact_cache_0.first_order_merge('server1', new_facts)

    # test case 2
    new_facts = {'version': '1.4.4'}
    fact_cache_0.first_order_merge('server1', new_facts)

    # test case 3
    new_facts = {'version': '1.4.0'}
    fact_cache_0.first_order_merge('server2', new_facts)


# Generated at 2022-06-25 14:10:10.042896
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert(fact_cache_0.flush() == 'None')
    assert(fact_cache_0.first_order_merge('key', 'value') == 'None')


# Generated at 2022-06-25 14:10:15.163240
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    assert fact_cache_0._plugin.name == 'memory'
    assert fact_cache_0._plugin.methods == {'get': 'get', 'set': 'set', 'flush': 'flush', 'delete': 'delete', 'keys': 'keys', 'contains': 'contains'}
    fact_cache_0.first_order_merge('key_123', 'val_123')
    fact_cache_0.flush()
    assert fact_cache_0._plugin.name == 'memory'
    assert fact_cache_0._plugin.methods == {'get': 'get', 'set': 'set', 'flush': 'flush', 'delete': 'delete', 'keys': 'keys', 'contains': 'contains'}

# Generated at 2022-06-25 14:10:17.511568
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    assert fact_cache_0.first_order_merge("key1", "value1") == None


# Generated at 2022-06-25 14:10:20.712844
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin == cache_loader.get(C.CACHE_PLUGIN)


# Generated at 2022-06-25 14:10:30.169972
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge('myhost', {u'foo': u'bar', u'fie': u'baz'})
    fact_cache_1.first_order_merge('yourhost', {u'foo': u'bar2', u'fie': u'baz2'})

    assert fact_cache_1._plugin.get('myhost') == {u'foo': u'bar', u'fie': u'baz'}
    assert fact_cache_1._plugin.get('yourhost') == {u'foo': u'bar2', u'fie': u'baz2'}

if __name__ == '__main__':
    test_case_0()
    test_FactCache_first_order_merge()

# Generated at 2022-06-25 14:10:34.272207
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()

    # Check for facts plugin file
    assert C.CACHE_PLUGIN == "jsonfile"

    # Check for the existence of plugin in cache
    assert hasattr(cache_loader, "get")

    # Check for the existence of contents in the plugin
    assert fact_cache is not None

    # Check for the existence of plugin keys() method
    assert hasattr(fact_cache._plugin, "keys")

# Generated at 2022-06-25 14:10:35.171094
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()
    # Only error test case is that the plugin is not available

# Generated at 2022-06-25 14:10:41.091152
# Unit test for constructor of class FactCache
def test_FactCache():
    assert fact_cache_0.__getitem__(key) == {"ansible_machine": "x86_64"}
    assert fact_cache_0.__setitem__(key, value) == {"ansible_machine": "x86_64"}
    assert fact_cache_0.__delitem__(key) == KeyError
    assert fact_cache_0.__contains__(key) == True
    assert fact_cache_0.__iter__() == iter(fact_cache_0._plugin.keys())
    assert fact_cache_0.__len__() == len(fact_cache_0._plugin.keys())
    assert fact_cache_0.copy() == dict(fact_cache_0)

    assert fact_cache_0.keys() == fact_cache_0._plugin.keys()
    fact_cache_0.flush

# Generated at 2022-06-25 14:10:48.022380
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    # Test with a valid value
    fact_cache = FactCache()
    fact_cache.first_order_merge('host', {'a': 'val for a', 'b': 'val for b'})
    assert fact_cache['host']['a'] == 'val for a'

    # Test with a non-dict value
    fact_cache = FactCache()
    fact_cache.first_order_merge('host', 'not a dict')
    assert not fact_cache['host']


# Generated at 2022-06-25 14:10:58.846234
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache
    assert fact_cache._plugin


# Generated at 2022-06-25 14:11:00.161343
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge(key=None, value=None)

# Generated at 2022-06-25 14:11:02.130652
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        test_case_0()
    except Exception as e:
        display.error('exception: %s' % str(e))
    else:
        display.display('ok')

# Generated at 2022-06-25 14:11:03.951706
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    assert fact_cache_1.first_order_merge("foo", "bar") is None


# Generated at 2022-06-25 14:11:08.605744
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert isinstance(fact_cache_0, MutableMapping)
    assert isinstance(fact_cache_0, FactCache)


# Generated at 2022-06-25 14:11:12.589186
# Unit test for constructor of class FactCache

# Generated at 2022-06-25 14:11:14.050266
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None


# Generated at 2022-06-25 14:11:19.028638
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    test_case_id = 0  # Change this value to run a specific test case
    # Setup
    fact_cache_0 = FactCache()
    key_0 = 'test'
    value_0 = 'test'

    # Exercise
    fact_cache_0.first_order_merge(key_0, value_0)

    # Verify
    #assert_called_with(fact_cache_0.__setitem__, key_0, value_0)

    # Cleanup
    del fact_cache_0


# Generated at 2022-06-25 14:11:24.050765
# Unit test for constructor of class FactCache
def test_FactCache():
    """
    test_FactCache
    """

    try:
        """ 
        There is no real way to test the actual cache lookup.
        We do know that the constructor of the FactCache class will raise an AnsibleError if no plugin is found.
        This should not happen in this test case as the lookup is always provided by the plugin loader.
        """
        fact_cache_0 = FactCache()
    except Exception as e:
        raise AssertionError("An error occurred constructing the object, FactCache.")
    return True


# Generated at 2022-06-25 14:11:28.872359
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()
    assert fact_cache_1._plugin.DEFAULT_CACHE_PLUGIN == 'jsonfile'
    fact_cache_1._plugin.__init__(path='test_json.json')
    assert fact_cache_1._plugin == {'test_key': 'test_value'}


# Generated at 2022-06-25 14:11:48.482574
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()


# Generated at 2022-06-25 14:11:53.328395
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    f = FactCache()
    fact_cache_0 = FactCache()
    f.first_order_merge("host",{"hostname" : "host-2", "ip" : "192.168.1.100" })
    host_cache_dict = f.copy()
    assert host_cache_dict["host"]["ip"] == "192.168.1.100", "Host cache is not updated for ip"

# Generated at 2022-06-25 14:12:01.379280
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()

    tst_key = "localhost"
    if (tst_key in fact_cache):
        raise Exception("Test case 1.1 failed")

    tst_values = {"testing_key": "testing_value", "testing_key2": "testing_value2"}
    fact_cache.first_order_merge(tst_key, tst_values)

    # check cache contains the key
    if (tst_key not in fact_cache):
        raise Exception("Test case 1.2 failed")

    # check cache element is the same object
    if (fact_cache[tst_key] is not tst_values):
        raise Exception("Test case 1.3 failed")

    # add a second element to cache

# Generated at 2022-06-25 14:12:04.713067
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    host = ''
    data = ''
    fact_cache_1.first_order_merge(host, data)

# Generated at 2022-06-25 14:12:06.497003
# Unit test for constructor of class FactCache
def test_FactCache():
    from collections import MutableMapping
    fc = FactCache()

    assert isinstance(fc, MutableMapping)



# Generated at 2022-06-25 14:12:12.590719
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    assert not fact_cache_0.contains('hostname')
    fact_cache_0.first_order_merge('hostname', 'host-0')
    assert fact_cache_0.contains('hostname')
    assert fact_cache_0['hostname'] == 'host-0'

    fact_cache_0.first_order_merge('hostname', 'host-1')
    assert fact_cache_0.contains('hostname')
    assert fact_cache_0['hostname'] == 'host-1'

# Generated at 2022-06-25 14:12:13.969990
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache != None


# Generated at 2022-06-25 14:12:21.717540
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    '''testing the first_order_merge method of the FactCache class'''

    # see: https://github.com/ansible/ansible/issues/29388
    # try to update the fact cache with some data
    fact_cache = FactCache()
    key = 'foo'
    value = {'a': 1, 'b': 2, 'c': 3}
    fact_cache.first_order_merge(key, value)

    assert key in fact_cache
    assert fact_cache[key] == value

    # Update the fact cache with new data
    key = 'foo'
    value = {'a': 4, 'b': 5}
    fact_cache.first_order_merge(key, value)

    assert fact_cache[key] == {'a': 4, 'b': 5, 'c': 3}

# Generated at 2022-06-25 14:12:23.894395
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge("ansible_lsb.codename", "cosmic")


# Generated at 2022-06-25 14:12:31.784472
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    from ansible.plugins.loader import cache_loader
    from ansible.vars.manager import VariableManager
    from ansible.vars import HostVars
    test_host = '127.0.0.1'

    # setup the empty fact cache
    fact_cache = FactCache()

    # add host facts to the cache
    hostvars = HostVars(hostname=test_host)
    hostvars.vars = {'ansible_os_family': 'Debian'}
    fact_cache.first_order_merge(test_host, hostvars.vars)

    # read facts from the cache
    h = fact_cache.get(test_host)
    assert h is not None
    assert h['ansible_os_family'] == 'Debian'

# Generated at 2022-06-25 14:12:58.179867
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache
    assert isinstance(fact_cache, FactCache)

# Generated at 2022-06-25 14:13:01.583426
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge('foo', 'bar')
    assert fact_cache_1['foo'] == 'bar'
    fact_cache_1.first_order_merge('foo', 'baz')
    assert fact_cache_1['foo'] == 'baz'


# Generated at 2022-06-25 14:13:08.582070
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    case_data = [
        {
            "input": {
                "key": "test_key",
                "value": "test_value"
            },
            "output": {
                "test_key": "test_value"
            }
        }
    ]
    fact_cache = FactCache()
    for case in case_data:
        fact_cache.first_order_merge(case["input"]["key"], case["input"]["value"])
        assert fact_cache.copy() == case["output"]

if __name__ == '__main__':
    # test_case_0()
    test_FactCache_first_order_merge()

# Generated at 2022-06-25 14:13:18.313167
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache_data =  {
            "ansible_facts":{
                "test_key1": "test_data1",
                "test_key2": "test_data2",
            },
            "ttl": 7200
    }
    instance = FactCache()
    instance.first_order_merge('test_key1', cache_data)
    assert instance.__contains__('test_key1')
    assert len(instance.keys()) == 1
    assert instance.get('test_key1') == cache_data
    assert instance.get('test_key1').get('ansible_facts').get('test_key1') == cache_data.get('ansible_facts').get('test_key1')

# Generated at 2022-06-25 14:13:21.385562
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()

    # Test for expected exception (AnsibleError)
    try:
        fact_cache.first_order_merge("", "")
    except AnsibleError:
        pass
    else:
        assert False, "AnsibleError not raised as expected"



# Generated at 2022-06-25 14:13:23.754246
# Unit test for constructor of class FactCache
def test_FactCache():
    # TODO: construct a object of FactCache
    # TODO: make sure it is a instance of __class__
    fact_cache_0 = FactCache()
    assert isinstance(fact_cache_0, __class__)


# Generated at 2022-06-25 14:13:24.635564
# Unit test for constructor of class FactCache
def test_FactCache():
    assert_fact_cache = FactCache(test_case_0())


# Generated at 2022-06-25 14:13:26.753894
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge(): 
    fact_cache_0 = FactCache()
    key_1 = String()
    value_1 = String()
    fact_cache_0.first_order_merge(key_1, value_1)


# Generated at 2022-06-25 14:13:28.202509
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        test_case_0()
    except Exception as e:
        print("INIT FAILED")
        print(e)


# Generated at 2022-06-25 14:13:29.653719
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()
    assert fact_cache_1
    assert isinstance(fact_cache_1, MutableMapping)



# Generated at 2022-06-25 14:14:43.500075
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:14:45.440343
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        fact_cache_0 = FactCache()
        assert True
    except:
        assert False


# Generated at 2022-06-25 14:14:46.677774
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()
    global FactCache
    del FactCache

# Generated at 2022-06-25 14:14:54.698999
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    # check that it is a subclass of MutableMapping
    assert isinstance(fact_cache, MutableMapping)
    # check that the object's superclass is MutableMapping
    assert issubclass(type(fact_cache), MutableMapping)
    # check that get plugin method is called
    fact_cache.__getitem__
    # check that the copy method returns a dictionary
    assert isinstance(fact_cache.copy(), dict)
    # check that the flush method returns a dictionary
    assert isinstance(fact_cache.flush(), dict)
    # check that the keys method returns a list
    assert isinstance(fact_cache.keys(), list)
    # check that the first order merge method returns a dictionary

# Generated at 2022-06-25 14:14:57.210327
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0 is not None


# Generated at 2022-06-25 14:15:00.134938
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge("fqdn", {"test": "testing"})


test_case_0()
test_FactCache_first_order_merge()

# Generated at 2022-06-25 14:15:01.638638
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    is_instance = isinstance( fact_cache, FactCache)
    assert is_instance
    

# Generated at 2022-06-25 14:15:03.585339
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0 is not None
    assert isinstance(fact_cache_0, MutableMapping)


# Generated at 2022-06-25 14:15:04.773124
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:15:06.499059
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    display.display('test_FactCache')
    assert (isinstance(fact_cache, FactCache))