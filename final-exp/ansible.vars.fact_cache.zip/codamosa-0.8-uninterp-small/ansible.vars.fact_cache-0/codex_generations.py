

# Generated at 2022-06-25 14:05:21.987811
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    # instantiate
    fact_cache_1 = FactCache()
    # define test data
    fact_cache_1[''] = ['']
    var_1 = fact_cache_1.__getitem__('')


# Generated at 2022-06-25 14:05:24.455404
# Unit test for method __getitem__ of class FactCache
def test_FactCache___getitem__():
    fact_cache_0 = FactCache()
    assert fact_cache_0.__contains__("id")
    result = fact_cache_0.__getitem__("id")
    assert result != None


# Generated at 2022-06-25 14:05:29.063844
# Unit test for constructor of class FactCache
def test_FactCache():
    # Create test object from class FactCache.
    myFactCache = FactCache()
    # Check whether __init__() raises any exceptions
    try:
        # Display the created object for testing.
        print(myFactCache)
    except Exception as inst:
        # Display the exception if any.
        print('Exception encountered during testing of __init__()')
        print(type(inst))
        print(inst)


# Generated at 2022-06-25 14:05:32.038184
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        FactCache_obj = FactCache()
    except Exception as exception:
        print("Exception in constructor: %s" % str(exception))
        raise AssertionError("Exception in constructor")

# Generated at 2022-06-25 14:05:37.578988
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    key = 'foo'
    value = 'bar'
    host_facts = {key: value}
    cache_plugin_instance = cache_loader.get(C.CACHE_PLUGIN)
    cache_plugin_instance.set(key, value)

    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge(key, value)

# Generated at 2022-06-25 14:05:41.247844
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    key_0 = "ansible_env"
    value_0 = dict()
    result_0 = fact_cache_0.first_order_merge(key_0, value_0)
    assert result_0 is None


# Generated at 2022-06-25 14:05:43.431538
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    """ Test case for first_order_merge of class FactCache """
    tpl = Template()
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge("host_0", tpl)

# Generated at 2022-06-25 14:05:46.244273
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    key = "key"
    value = "value"
    fact_cache_0.first_order_merge(key, value)


if __name__ == '__main__':
    test_FactCache_first_order_merge()

# Generated at 2022-06-25 14:05:47.696348
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge(0, 0)


# Generated at 2022-06-25 14:05:48.612765
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()


# Generated at 2022-06-25 14:05:54.824294
# Unit test for constructor of class FactCache
def test_FactCache():
    # test 0 - positive test case
    test_case_0()

if __name__ == '__main__':
    test_FactCache()

# Generated at 2022-06-25 14:06:02.019389
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    key_0 = {}
    fact_cache_0.first_order_merge(key_0, {})

__test__ = {"test_case_0":test_case_0, "test_FactCache_first_order_merge":test_FactCache_first_order_merge}
if __name__ == "__main__":
    from ansible.module_utils.basic import AnsibleModule
    AnsibleModule(argument_spec={}).exit_json(changed=False)

# Generated at 2022-06-25 14:06:05.223345
# Unit test for constructor of class FactCache
def test_FactCache():
    print("########## Test FactCache ##########")
    fact_cache_0 = FactCache()
    fact_cache_0.flush()
    test_case_0()
    print("########## Test FactCache Finished ##########\n")

# Generated at 2022-06-25 14:06:06.946613
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0 is not None


# Generated at 2022-06-25 14:06:07.928498
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()


# Generated at 2022-06-25 14:06:11.297798
# Unit test for constructor of class FactCache
def test_FactCache():
    f = FactCache()

    # This is for coverage of the __contains__() and keys() methods.
    assert 'test' not in f
    assert f.keys() == []

    f['test'] = 1
    assert 'test' in f
    assert f.keys() == ['test']

# Generated at 2022-06-25 14:06:14.441040
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    fact_cache = FactCache()

    fact_cache.first_order_merge("test_key1","test_value1")
    fact_cache.first_order_merge("test_key1","test_value1_updated")

    assert fact_cache["test_key1"] == "test_value1_updated"


# Generated at 2022-06-25 14:06:16.251673
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache == {}


# Generated at 2022-06-25 14:06:23.281586
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    # Setup
    fact_cache = FactCache()
    key        = "key"
    value      = "value"

    # Test 1: run with no preexisting data in the cache
    fact_cache_0.flush()
    fact_cache.first_order_merge(key, value)

    assert(fact_cache["key"] == value)

    # Test 2: run with preexisting data in the cache
    value_new = "value new"
    fact_cache.first_order_merge(key, value_new)
    assert(fact_cache["key"] == value_new)


# Generated at 2022-06-25 14:06:26.470986
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge("One", "Two")
    fact_cache_0.first_order_merge("One", "Three")


# Generated at 2022-06-25 14:06:29.592141
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()
    assert fact_cache_1 is not None

# Generated at 2022-06-25 14:06:30.777130
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache

# Generated at 2022-06-25 14:06:31.726268
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()

# Generated at 2022-06-25 14:06:40.481912
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge('host1', {'var1': 'val1'})
    assert 'host1' in fact_cache_1
    assert len(fact_cache_1) == 1
    assert fact_cache_1.copy() == {'host1': {'var1': 'val1'}}
    assert len(fact_cache_1.keys()) == 1
    assert list(fact_cache_1.keys()) == ['host1']
    fact_cache_1.first_order_merge('host1', {'var2': 'val2'})
    assert 'host1' in fact_cache_1
    assert len(fact_cache_1) == 1

# Generated at 2022-06-25 14:06:43.380964
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge("host1", {'a': 'b'})
    assert fact_cache_1["host1"]['a'] == 'b'



# Generated at 2022-06-25 14:06:49.330092
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    ansible_facts = {'a': 1, 'b': 2, 'c': 3}
    fc.first_order_merge('localhost', ansible_facts)
    assert 'localhost' in fc
    assert fc['localhost'] == ansible_facts
    for key, val in ansible_facts.items():
        assert key in fc['localhost']
        assert fc['localhost'][key] == val


# Generated at 2022-06-25 14:06:52.415402
# Unit test for constructor of class FactCache
def test_FactCache():
    f = FactCache()
    f.flush()  # check if it can flush
    # check if it can set and get items
    # f['key'] = 'value'
    # assert f['key'] == 'value'

# Generated at 2022-06-25 14:06:56.907034
# Unit test for constructor of class FactCache
def test_FactCache():
    display.debug("Test FactCache()")
    try:
        test_case_0()
    except (AnsibleError, Exception) as e:
        display.display("Exception raised in test_case_0: " + str(e))
        return False
    return True

# Generated at 2022-06-25 14:06:57.908712
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

test_FactCache()

# Generated at 2022-06-25 14:06:59.293559
# Unit test for constructor of class FactCache
def test_FactCache():
    # Test 0
    test_case_0()


# Generated at 2022-06-25 14:07:03.699869
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0 is not None

# Generated at 2022-06-25 14:07:05.291316
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()


if __name__ == '__main__':
    test_FactCache()

# Generated at 2022-06-25 14:07:17.600914
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()

# Generated at 2022-06-25 14:07:25.926505
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    # In this test we will directly insert into the _plugin (dict)
    # object so that we can populate it with specific values for
    # testing purposes.
    #
    # Given a dictionary of facts for a host:
    facts = dict(ansible_distribution_version="16.10", ansible_lsb_version_major=16, ansible_lsb_version_release=10)
    # And the plugins first_order_merge() method is called with the
    # host and facts
    fact_cache._plugin['test_host'] = dict(ansible_distribution_version="16.04")
    fact_cache._plugin['test_host'].update(facts)
    fact_cache.first_order_merge('test_host', facts)
    # Then the plugins cache should contain the

# Generated at 2022-06-25 14:07:27.761220
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:07:29.598728
# Unit test for constructor of class FactCache
def test_FactCache():
    global display
    display.display("test_FactCache:")
    test_case_0()


test_FactCache()

# Generated at 2022-06-25 14:07:39.213051
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fcache = FactCache()
    key = "127.0.0.1"
    value = {'a': 2}
    fcache.first_order_merge(key, value)
    assert (fcache[key] == value)
    fcache.first_order_merge(key, {'a': 1}) # dict value should overrule
    assert (fcache[key]['a'] == 1)
    assert (fcache[key]['b'] == 2)
    fcache.first_order_merge(key, {'c': 1})
    fcache.first_order_merge(key, {'c': 2}) # value should be preserved
    assert (fcache[key]['c'] == 1)

# Generated at 2022-06-25 14:07:48.215926
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.get('key') == None
    fact_cache._plugin.set('key', 'value')
    assert fact_cache._plugin.contains('key') == True
    assert fact_cache._plugin.get('key') == 'value'
    fact_cache._plugin.delete('key')
    assert fact_cache._plugin.contains('key') == True
    fact_cache._plugin.flush()
    assert fact_cache._plugin.contains('key') == False
    fact_cache._plugin.set('key', 'value')
    assert fact_cache._plugin.contains('key') == True
    fact_cache._plugin.set('key2', 'value')
    assert fact_cache._plugin.contains('key') == True
    assert fact_cache._plugin.contains

# Generated at 2022-06-25 14:07:49.562482
# Unit test for constructor of class FactCache
def test_FactCache():
    with pytest.raises(AnsibleError):
        test_case_0()

# Generated at 2022-06-25 14:07:50.827870
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:07:56.651848
# Unit test for constructor of class FactCache
def test_FactCache():
      fact_cache = FactCache()
      assert(isinstance(fact_cache,FactCache))


# Generated at 2022-06-25 14:07:58.386462
# Unit test for constructor of class FactCache
def test_FactCache():
    print("Testing constructor of class FactCache")
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:08:00.395551
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0._plugin.__class__.__name__ == 'FactCache'


# Generated at 2022-06-25 14:08:02.308080
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0.keys() == []


# Generated at 2022-06-25 14:08:04.375094
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()

    if fact_cache_0._plugin != None:
        del fact_cache_0._plugin

# Generated at 2022-06-25 14:08:12.617208
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0_dict = FactCache()
    fact_cache_0_dict['foo'] = 'bar'
    fact_cache_0_dict['foo'] = 'baz'
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge('foo', 'bar')
    assert fact_cache_0 == fact_cache_0_dict
    fact_cache_0.first_order_merge('foo', 'baz')
    assert fact_cache_0 == fact_cache_0_dict

# Generated at 2022-06-25 14:08:13.947835
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    return fact_cache


# Generated at 2022-06-25 14:08:21.738139
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()

# Generated at 2022-06-25 14:08:25.444456
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    # assert fact_cache_0
    fact_cache_0.flush()
    assert not fact_cache_0
#

# Generated at 2022-06-25 14:08:28.064656
# Unit test for constructor of class FactCache
def test_FactCache():
    # Initialize an instance of the FactCache class
    fact_cache = FactCache()

    # Assert that the instance is initialized.
    assert fact_cache



# Generated at 2022-06-25 14:08:37.187295
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    fact_cache.keys()
    fact_cache.flush()
    fact_cache.first_order_merge('some_key', 'some_value')


# Generated at 2022-06-25 14:08:44.247089
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.flush()

# Generated at 2022-06-25 14:08:53.492196
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    assert "localhost" not in cache
    cache.first_order_merge("localhost", {
        "ansible_facts": {
            "fact1": "value1",
            "fact2": "value2",
        }
    })
    assert "localhost" in cache
    assert "fact1" in cache["localhost"]["ansible_facts"]
    assert "fact2" in cache["localhost"]["ansible_facts"]
    assert "value1" == cache["localhost"]["ansible_facts"]["fact1"]
    assert "value2" == cache["localhost"]["ansible_facts"]["fact2"]


# Generated at 2022-06-25 14:08:54.632590
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache != None



# Generated at 2022-06-25 14:08:56.366131
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    myFactCache = FactCache()
    myFactCache.first_order_merge("fact_name", "fact_value")

# Generated at 2022-06-25 14:08:59.449436
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        # Uncomment the following line to test your implementation
        test_case_0()
    except Exception as e:
        print(e)
        print("Fail")



# Generated at 2022-06-25 14:09:02.654774
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert 'FactCache' in str(type(fact_cache_0))


# Generated at 2022-06-25 14:09:04.366982
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache0 = FactCache()
    assert fact_cache0 is not None


# Generated at 2022-06-25 14:09:06.669223
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        fact_cache_0 = FactCache()
    except AnsibleError as result:
        print(result)
        return False

    return True



# Generated at 2022-06-25 14:09:09.009404
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        test_case_0()
    except Exception:
        display.display("Failed constructor test case for FactCache")
        raise AssertionError('Failed constructor test case for FactCache')


# Generated at 2022-06-25 14:09:26.419713
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        test_case_0()
    except Exception as e:
        print("Exception at Line: " + str(e.__traceback__.tb_lineno) + ", Error: " + str(e))
        raise


if __name__ == "__main__":
    test_FactCache()

# Generated at 2022-06-25 14:09:27.855031
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()
    assert fact_cache_1
    fact_cache_1.flush()

# Generated at 2022-06-25 14:09:29.450594
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert isinstance(fc, FactCache)

# Generated at 2022-06-25 14:09:31.141244
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()

    fact_cache_1.first_order_merge({"key": "value"})

# Generated at 2022-06-25 14:09:36.101937
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()

    # Test __getitem__(), __contains__()
    key = '192.168.1.34'
    fact_cache[key] = {'foo': 'bar'}
    value = fact_cache[key]
    assert value == {'foo': 'bar'}
    assert key in fact_cache
    assert '192.168.1.35' not in fact_cache

    # Test __setitem__()
    fact_cache[key] = {'abc': 'def'}
    assert fact_cache[key] == {'abc': 'def'}

    # Test __delitem__()
    del fact_cache[key]
    try:
        value = fact_cache[key]
        assert False
    except KeyError:
        assert True

    # Test __len__()


# Generated at 2022-06-25 14:09:37.937851
# Unit test for constructor of class FactCache
def test_FactCache():
    array = [1, 2, 3, 4]
    fact_cache_1 = FactCache(array)


# Generated at 2022-06-25 14:09:42.301336
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache['foo'] = {'a': 'b', 'c': 'd'}
    fact_cache.first_order_merge('foo', {'e': 'f'})
    assert fact_cache['foo']['e'] == 'f'


# Generated at 2022-06-25 14:09:51.185065
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    fact_cache_1 = FactCache()
    fact_cache_1['myhost'] = dict(foo='bar')
    fact_cache_1['myhost'].update(dict(jumpy='frog'))
    fact_cache_1['myhost'].update(dict(myx='fox'))
    fact_cache_1['myhost'].update(dict(foo='baz'))

    fact_cache_2 = FactCache()
    fact_cache_2.first_order_merge('myhost', dict(foo='bar'))
    fact_cache_2.first_order_merge('myhost', dict(jumpy='frog'))
    fact_cache_2.first_order_merge('myhost', dict(myx='fox'))

# Generated at 2022-06-25 14:09:53.199062
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()

    assert fact_cache_0 is not None

# Note: this sample test doesn't have assertions that would fail the test upon
# failure

# Generated at 2022-06-25 14:09:55.520449
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    value = fact_cache_1.first_order_merge('key', 'value')
    assert value == {'key': 'value'}



# Generated at 2022-06-25 14:10:29.521807
# Unit test for constructor of class FactCache
def test_FactCache():
    # Test for:
    # * existence of class variable __name__ (it must exist)
    # * value of class variable __name__ (it must be "FactCache")
    assert hasattr(FactCache, "__name__"), "Expected class variable '__name__' to be set."
    assert FactCache.__name__ == "FactCache", "Expected FactCache.__name__ to be 'FactCache', found '%s'." % FactCache.__name__

    # Test for:
    # * fact_cache_0 is an instance of FactCache
    # * fact_cache_1 is an instance of FactCache
    fact_cache_0 = FactCache()
    fact_cache_1 = FactCache()

# Generated at 2022-06-25 14:10:30.546839
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0._plugin._errors == []


# Generated at 2022-06-25 14:10:31.350741
# Unit test for constructor of class FactCache
def test_FactCache():
    f = FactCache()
    assert f != None


# Generated at 2022-06-25 14:10:33.639608
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge("test_key", "test_facts")
    assert "test_facts" in fact_cache_0.values()


# Generated at 2022-06-25 14:10:37.846031
# Unit test for constructor of class FactCache
def test_FactCache():

    fact_cache = FactCache()

    # test load plugin
    assert fact_cache._plugin is not None

    # test __setitem__
    assert 'key' not in fact_cache
    fact_cache['key'] = {'data_1': 1}
    assert 'key' in fact_cache

    # test __getitem__
    assert fact_cache['key'] == {'data_1': 1}

    # test keys
    assert 'key' in fact_cache.keys()

    # test __contains__
    assert fact_cache.__contains__('key')

    # test __delitem__
    del fact_cache['key']
    assert 'key' not in fact_cache



if __name__ == "__main__":
    import pytest

# Generated at 2022-06-25 14:10:39.980268
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0._plugin is not None
    assert isinstance(fact_cache_0._plugin, object)


# Generated at 2022-06-25 14:10:50.718350
# Unit test for constructor of class FactCache
def test_FactCache():

    # Create new instance with no arguments
    fact_cache = FactCache()

    return fact_cache


if __name__ == "__main__":

    fact_cache = test_FactCache()

    # ********* TEST FUNCTIONS **********

    print("Test: make sure new instance is a dict")
    assert isinstance(fact_cache, dict) == True

    print("Test: make sure new instance is a MutableMapping")
    assert isinstance(fact_cache, MutableMapping) == True

    # ********* TEST METHODS **********

    # Test __init__()
    print("Testing: __init__()")

    # Test copy()
    print("Testing: copy()")

    # Test flush()
    print("Testing: flush()")

    # Test keys()
    print("Testing: keys()")



# Generated at 2022-06-25 14:10:58.374963
# Unit test for constructor of class FactCache
def test_FactCache():
    # Test for empty constructor
    fact_cache_1 = FactCache()
    # Test for constructor with params (dict(hostname) => dict(host_facts))
    fact_cache_2 = FactCache({'hostname': {'fact1': "value1"}})
    assert fact_cache_2['hostname']['fact1'] == "value1", "Unexpected value"
    # Test for constructor with params (dict(hostname) => dict(host_facts))
    fact_cache_3 = FactCache({'hostname': {}})
    # Test for constructor with params (dict(hostname) => dict(host_facts))
    fact_cache_4 = FactCache({'hostname': {'fact1': "value1"}, 'hostname2': {'fact2': "value2"}})
    assert fact_cache_4

# Generated at 2022-06-25 14:11:04.379863
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()

    # Test if assertion 'isinstance(self, collections.Mapping)'
    # raises the correct exception
    try:
        isinstance(fact_cache_0, collections.Mapping)
    except AssertionError as e:
        assert type(e) == AssertionError

    # Test if assertion 'issubclass(collections.MutableMapping, collections.Mapping)'
    # raises the correct exception
    try:
        issubclass(collections.MutableMapping, collections.Mapping)
    except AssertionError as e:
        assert type(e) == AssertionError

    # Test if assertion 'isinstance(self._plugin, AnsibleCacheModule)'
    # raises the correct exception

# Generated at 2022-06-25 14:11:09.336769
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()
    assert True
    #TODO: Check for correct behaviour
    #assert fact_cache_1.get_plugin() == "ansible.plugins.cache.jsonfile"


# Generated at 2022-06-25 14:12:15.515281
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()
    print('done')

if __name__ == "__main__":
    test_FactCache()

# Generated at 2022-06-25 14:12:17.226340
# Unit test for constructor of class FactCache
def test_FactCache():
    ansible_cache = FactCache()
    assert ansible_cache
    assert isinstance(ansible_cache, MutableMapping)


# Generated at 2022-06-25 14:12:18.014079
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()


# Generated at 2022-06-25 14:12:20.224689
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_thing = FactCache()

    assert fact_cache_thing is not None

# UNit test for method __contains__ of class FactCache
# @pytest.mark.skip(reason="")

# Generated at 2022-06-25 14:12:24.372798
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        fact_cache = FactCache()
        fact_cache.set("test_key", "test_value")
        assert fact_cache.get("test_key") == "test_value"
        fact_cache.delete("test_key")
        fact_cache.flush()
    except Exception:
        assert False, 'Unable to create instance of class FactCache'

# Generated at 2022-06-25 14:12:25.541965
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()


# Generated at 2022-06-25 14:12:29.300149
# Unit test for constructor of class FactCache
def test_FactCache():
    assert hasattr(FactCache, '_FactCache__init__'), "You have not implemented '__init__' method in 'FactCache' class."
    assert inspect.isfunction(getattr(FactCache, '_FactCache__init__')), "'__init__' should be a function."
    print("You have successfully implemented '__init__' method in 'FactCache' class.")


# Generated at 2022-06-25 14:12:30.469433
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:12:31.738141
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

# Test for keys method of class FactCache

# Generated at 2022-06-25 14:12:33.271344
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()
    test_case_1()

if __name__ == "__main__":
    test_FactCache()

# Generated at 2022-06-25 14:15:06.876946
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc.first_order_merge('1', {'a': 'b'})
    assert(fc == {'1': {'a': 'b'}})
    fc.first_order_merge('2', {'c': 'd'})
    assert(fc == {'1': {'a': 'b'}, '2': {'c': 'd'}})
    fc.first_order_merge('2', {'a': 'b'})
    assert(fc == {'1': {'a': 'b'}, '2': {'c': 'd', 'a': 'b'}})

# Generated at 2022-06-25 14:15:10.201985
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # input
    key = "some_key"
    value = {"some_value_key": "some_value_val"}

    # act
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge(key, value)

    # assert
    assert isinstance(fact_cache_1, FactCache)


# Generated at 2022-06-25 14:15:13.234304
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        with pytest.raises(AnsibleError):
            fact_cache_0 = FactCache()
    except Exception as e:
        print("Failed to raise AnsibleError on undefined CACHE_PLUGIN")
        print(e)


# Generated at 2022-06-25 14:15:14.579616
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()

# Queries the ansible fact cache plugin and returns the size of it

# Generated at 2022-06-25 14:15:19.265669
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0._plugin.flush() == None
    assert fact_cache_0._plugin.get("localhost") == None
    assert fact_cache_0._plugin.set("localhost", {}) == None
    assert fact_cache_0._plugin.delete("localhost") == None
    assert fact_cache_0._plugin.contains("localhost") == False
    return

