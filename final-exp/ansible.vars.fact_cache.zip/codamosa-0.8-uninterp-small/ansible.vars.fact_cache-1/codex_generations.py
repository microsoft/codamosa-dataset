

# Generated at 2022-06-25 14:05:22.205546
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    key = 'test_key'
    host_facts = {
        'test_key': {'test_key_0': 0, 'test_key_1': 1, 'test_key_2': 2},
    }
    fact_cache = FactCache()
    fact_cache._plugin.set(key, host_facts[key])
    for i in range(3):
        fact_cache.first_order_merge(key, {'test_key_%d' % i: i})
    assert fact_cache._plugin.get(key) == {'test_key_0': 2, 'test_key_1': 1, 'test_key_2': 2}
    fact_cache._plugin.delete(key)
    assert fact_cache._plugin.get(key) == None

# Generated at 2022-06-25 14:05:26.441841
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()

    fact_cache_0.first_order_merge("ansible_processor_cores", 56)
    fact_cache_0.first_order_merge("ansible_processor_cores", 56)
    result = dict(fact_cache_0)
    assert result == {"ansible_processor_cores": 56}


# Generated at 2022-06-25 14:05:27.857906
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    fact_cache_0.disconnect()


# Generated at 2022-06-25 14:05:29.438760
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None


# Generated at 2022-06-25 14:05:30.325667
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()

# Generated at 2022-06-25 14:05:32.617398
# Unit test for constructor of class FactCache
def test_FactCache():

    test_case_0()
    print('unit test ok')

if __name__ == '__main__':
    test_FactCache()

# Generated at 2022-06-25 14:05:33.585244
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

# Generated at 2022-06-25 14:05:34.828094
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

# Generated at 2022-06-25 14:05:38.547153
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()

    # Test for no arguments passed
    try:
        key = ''
        value = ''
        fact_cache_0.first_order_merge()

    except TypeError:
        pass


# Generated at 2022-06-25 14:05:40.022722
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None


# Generated at 2022-06-25 14:05:46.745232
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # test_cache is a FactCache object
    test_cache = FactCache()
    setattr(test_cache, '_plugin', None)
    # test_key is an arbitrary string
    test_key = 'test_key'
    # test_value is a dictionary
    test_value = {'test_value_key': 'test_value_value'}
    # No exception raised.
    test_cache.first_order_merge(test_key, test_value)

    # TODO: implement more unit test code
    #raise Exception("Test not implemented!")



# Generated at 2022-06-25 14:05:54.721840
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Initialize a new FactCache with a tmp cache path
    fact_cache = FactCache()

    # Define test data
    key = 'testhost'
    value = {'foo': 'bar'}

    fact_cache.first_order_merge(key, value)
    # The following code should not raise a KeyError
    cached_value = fact_cache[key]
    # Verify data was cached correctly
    assert cached_value == value

    # Cleanup and flush the fact cache
    fact_cache.flush()


# Generated at 2022-06-25 14:05:58.625965
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import tempfile
    fact_cache_1 = FactCache()
    key_1 = tempfile.mkstemp()
    value_1 = 'value'
    fact_cache_1.first_order_merge(key_1, value_1)


# Generated at 2022-06-25 14:05:59.999401
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache.plugin == 'memory'

# Generated at 2022-06-25 14:06:09.726537
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    display.display("Test 1: Test a positive case.")
    # Positive case
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge("localhost", {"local_value": "value"})
    assert fact_cache_0.get("localhost") == {"local_value": "value"}

    display.display("Test 2: Test a negative case.")
    # Negative case
    fact_cache_0 = FactCache()
    local_host = "localhost"
    fact_cache_0.first_order_merge(local_host, {"local_value": "value"})

# Generated at 2022-06-25 14:06:11.262257
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()


# Generated at 2022-06-25 14:06:18.507875
# Unit test for constructor of class FactCache
def test_FactCache():

    # Try calling constructor on class FactCache with an argument
    # Fail expected
    try:
        fact_cache = FactCache("foo")
    except TypeError as exc:
        pass
    else:
        raise Exception('ExpectedException not raised')

    # Test 1: Create an instance of class FactCache
    try:
        test_case_0()
    except Exception as exc:
        pass
    else:
        raise Exception("ExpectedException not raised")



# Generated at 2022-06-25 14:06:24.624328
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    host_facts = {'host1': {'lease_expiry_time': 'sun sep  2 08:06:43 2018'}}
    assert fact_cache.keys() == ['host1']
    assert fact_cache['host1'] == {'lease_expiry_time': 'sun sep  2 08:06:43 2018'}

if __name__ == '__main__':
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'lease_expiry_time': 'sun sep  2 08:06:43 2018'})
    test_FactCache_first_order_merge()

# Generated at 2022-06-25 14:06:25.566974
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()



# Generated at 2022-06-25 14:06:33.847696
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    old_data = {'key1': 'old_value1', 'key2': 'old_value2'}
    new_data = {'key1': 'new_value1', 'key3': 'new_value3'}
    expected_data = {'key1': 'new_value1', 'key2': 'old_value2', 'key3': 'new_value3'}
    fact_cache.first_order_merge('hostname', old_data)
    assert fact_cache['hostname'] == old_data
    fact_cache.first_order_merge('hostname', new_data)
    assert fact_cache['hostname'] == expected_data

# Generated at 2022-06-25 14:06:37.063478
# Unit test for constructor of class FactCache
def test_FactCache():
    FactCache.first_order_merge(0, 0)


# Generated at 2022-06-25 14:06:40.530099
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    given_key = 'localhost'
    given_value = {'a': 1, 'b': 2}
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge(given_key, given_value)


# Generated at 2022-06-25 14:06:41.429461
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()


# Generated at 2022-06-25 14:06:48.948313
# Unit test for constructor of class FactCache
def test_FactCache():

    # test case 1:
    # -> no exceptions raised.
    #
    # test case 2:
    # exception handling
    # -> raise exception when the fact cache plugin is not loaded
    #
    # test case 3:
    # exception handling
    # -> raise exception when the fact cache plugin is not a valid plugin
    #
    # test case 4:
    # exception handling
    # -> raise exception when the fact cache plugin is a valid plugin
    #
    # test case 5:
    # exception handling
    # -> raise exception when the fact cache plugin is not a valid plugin
    #
    import sys
    import os
    from ansible.plugins.loader import fact_cache_loader
    from ansible.utils.display import Display
    from ansible.plugins.cache.memory import CacheModule as memory_plugin

# Generated at 2022-06-25 14:06:51.419831
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge("item1", "item2")


# Generated at 2022-06-25 14:06:55.301752
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    key = 'test_key'
    value = dict(test_value='test_value')
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge(key, value)


# Generated at 2022-06-25 14:06:58.954513
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    fact_cache.copy()
    fact_cache.keys()
    fact_cache.flush()
    fact_cache.first_order_merge("10.10.10.1", "Linux")

# Generated at 2022-06-25 14:07:00.241547
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    print(fact_cache)



# Generated at 2022-06-25 14:07:06.260938
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    value_0 = 'g-2N[%(|h.|A,{}'
    value_1 = 'Y;pL7n'
    fact_cache_0.first_order_merge(0, value_0)
    fact_cache_0.first_order_merge(0, value_1)
    try:
        host = fact_cache_0.items()
        assert host == [(0, 'g-2N[%(|h.|A,{}Y;pL7n')]
    except AssertionError:
        raise



# Generated at 2022-06-25 14:07:14.067806
# Unit test for constructor of class FactCache
def test_FactCache():
    '''
    Constructor for FactCache.
    :return:
    '''
    fact_cache_0 = FactCache()
    # Check `display.vvvvv` calls in `FactCache.__init__`
    # No idea how to test those:
    #   display.vvvvv('LOADING CACHE PLUGIN: %s' % self._plugin)
    # Since there's no way to get the plugin from the instance.


# Generated at 2022-06-25 14:07:19.261256
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0._plugin.__class__.__name__ == 'FactCache'
    #assert fact_cache_0.plugin.__class__.__name__ == 'FactCache'


# Generated at 2022-06-25 14:07:26.283744
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge("test_fact_cache.test_host", {"test_fact_1": "test_value_1", "test_fact_2": "test_value_2"})

    if "test_fact_cache.test_host" not in fact_cache_1.keys():
        assert False
    else:
        if fact_cache_1["test_fact_cache.test_host"]["test_fact_1"] != "test_value_1" or fact_cache_1["test_fact_cache.test_host"]["test_fact_2"] != "test_value_2":
            assert False
        else:
            assert True


# Generated at 2022-06-25 14:07:26.986527
# Unit test for constructor of class FactCache
def test_FactCache():
    pass

# Generated at 2022-06-25 14:07:32.464648
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc.first_order_merge("hostname0",{"fact0":0})
    assert fc["hostname0"]["fact0"] == 0
    fc.first_order_merge("hostname0",{"fact1":1})
    assert fc["hostname0"]["fact1"] == 0
    #assert fc.contains("hostname0")

# Generated at 2022-06-25 14:07:34.244457
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()

    assert(not fact_cache is None)


# Generated at 2022-06-25 14:07:36.759062
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge('foo', 'bar')

fact_cache = FactCache()

# Generated at 2022-06-25 14:07:38.255954
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    if fact_cache == None:
        return False
    else:
        return True

# Generated at 2022-06-25 14:07:39.292963
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache

# Generated at 2022-06-25 14:07:41.695563
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert isinstance(fact_cache_0, FactCache)

# Generated at 2022-06-25 14:07:42.580196
# Unit test for constructor of class FactCache
def test_FactCache():
    assert fact_cache_0

# Generated at 2022-06-25 14:07:49.956214
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.flush()
    fact_cache_1.first_order_merge('test_hostname', 'test_host.com')
    fact_cache_1.first_order_merge('test_hostname', 'test_host.com')
    assert fact_cache_1['test_hostname'] == 'test_host.com'

# Generated at 2022-06-25 14:07:52.145016
# Unit test for constructor of class FactCache
def test_FactCache():
    fact = FactCache()
    assert fact == fact_cache_0


fact_cache_1 = FactCache()

# Generated at 2022-06-25 14:08:02.610547
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()

    # Testing the method get()
    assert fact_cache.get("TestKey") is None
    assert isinstance(fact_cache.get("TestKey", "TestValue"), str)
    assert fact_cache.get("TestKey", "TestValue") == "TestValue"

    # Testing the method update()
    fact_cache.update({"TestKey": "TestValue"})
    assert fact_cache.get("TestKey") == "TestValue"

    # Testing the method __setitem__()
    fact_cache["TestKey1"] = "TestValue1"
    assert fact_cache.get("TestKey") == "TestValue"
    assert fact_cache.get("TestKey1") == "TestValue1"

    # Testing the method pop()
    fact_cache.pop("TestKey")

# Generated at 2022-06-25 14:08:03.552579
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()


# Generated at 2022-06-25 14:08:06.305536
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()


# Generated at 2022-06-25 14:08:10.171525
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()

    fact_cache_1.first_order_merge("something",{'a': 'b'})
    assert fact_cache_1["something"]['a'] == 'b'

# Generated at 2022-06-25 14:08:13.992029
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    fact_cache_0 = FactCache()

    fact_cache_0.first_order_merge(0, 'test_value')

    display.test_verbose('Starting test_FactCache_first_order_merge')
    return True



# Generated at 2022-06-25 14:08:21.770652
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    testcase = [
        {'key': 'test', 'value': 'test'},
        {'key': 'test', 'value': 'test1'},
        {'key': 'test', 'value': 'test2'}
    ]
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge(testcase[0]['key'], testcase[0]['value'])
    fact_cache_0.first_order_merge(testcase[1]['key'], testcase[1]['value'])
    fact_cache_0.first_order_merge(testcase[2]['key'], testcase[2]['value'])
    assert fact_cache_0[testcase[0]['key']] == testcase[0]['value']
    assert fact

# Generated at 2022-06-25 14:08:31.312750
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge('foo', {'bar': 'baz'})
    assert list(fact_cache_1.keys()) == ['foo']
    assert fact_cache_1['foo'] == {'bar': 'baz'}

    fact_cache_2 = FactCache() # reset to empty cache
    fact_cache_2.first_order_merge('foo', {'bar': 'baz'})
    assert list(fact_cache_2.keys()) == ['foo']
    assert fact_cache_2['foo'] == {'bar': 'baz'}
    assert fact_cache_2['foo'] == {'bar': 'baz'}

    fact_cache_3 = FactCache() # reset to empty cache

# Generated at 2022-06-25 14:08:37.024593
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        fact_cache_0 = FactCache()
    except Exception as e:
        print(e)
        display.display("TEST: FactCache() method, constructor", color='red')
        display.display("TEST RESULT: FAILED", color='red')
    else:
        display.display("TEST: FactCache() method, constructor", color='green')
        display.display("TEST RESULT: PASSED", color='green')



# Generated at 2022-06-25 14:08:45.508583
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc.first_order_merge('test_0',dict(my_fact='old'))
    assert fc['test_0'] == dict(my_fact='old')

    fc.first_order_merge('test_0',dict(my_fact='new'))
    assert fc['test_0'] == dict(my_fact='new')

# Generated at 2022-06-25 14:08:46.343127
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

# Generated at 2022-06-25 14:08:48.038777
# Unit test for constructor of class FactCache
def test_FactCache():
    print("In test_FactCache()")
    fact_cache = FactCache()


# Generated at 2022-06-25 14:08:51.302598
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    key0 = 'SEremote_hosts'
    value0 = {u'foo': u'bar'}
    fact_cache0 = FactCache()
    fact_cache0.first_order_merge(key0, value0)

# Generated at 2022-06-25 14:09:02.009961
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    assert len(fact_cache_0.keys()) == 0
    fact_cache_0.first_order_merge('ansible_facts', {'ansible_facts': {}})
    fact_cache_0.first_order_merge('key0', 'value0')
    assert len(fact_cache_0.keys()) == 2
    assert fact_cache_0['key0'] == 'value0'
    fact_cache_0.first_order_merge('ansible_facts', {'ansible_facts': {'key1': 'value1'}})
    fact_cache_0.first_order_merge('ansible_facts', {'ansible_facts': {'key2': 'value2'}})

# Generated at 2022-06-25 14:09:03.052813
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()

# Generated at 2022-06-25 14:09:04.419501
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache


# Generated at 2022-06-25 14:09:06.016299
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()
    assert fact_cache_1 != None


# Generated at 2022-06-25 14:09:09.321964
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    test_key = 'test_key'
    test_value = {'test_value': 0}
    fact_cache.first_order_merge(test_key, test_value)

    assert fact_cache[test_key] == test_value


# Generated at 2022-06-25 14:09:11.214911
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    if fact_cache is None:
        raise Exception("Cannot create variable of type FactCache")


# Generated at 2022-06-25 14:09:20.686601
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    key = '127.0.0.1'
    value = {'foo': 'bar'}
    fact_cache_1.first_order_merge(key, value)

# Generated at 2022-06-25 14:09:24.574464
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    fact_cache_0.keys()
    fact_cache_0.first_order_merge('foo', 'bar')
    fact_cache_0.copy()
    fact_cache_0.flush()


# Generated at 2022-06-25 14:09:26.455459
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge('key0',{'key1':'value1'})

# Generated at 2022-06-25 14:09:28.342013
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    host_cache_0 = {'key': 'value'}
    assert fact_cache_0.first_order_merge('localhost', host_cache_0) == None


# Generated at 2022-06-25 14:09:29.757321
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache

# Generated at 2022-06-25 14:09:30.775847
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()
    print('Function test_FactCache finished')



# Generated at 2022-06-25 14:09:31.788456
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:09:34.559925
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    key = 'ansible_os_family'
    value = 'RedHat'

    fact_cache_1.first_order_merge(key, value)

    if fact_cache_1.__contains__(key) and fact_cache_1.__getitem__(key) == value:
        return True


# Generated at 2022-06-25 14:09:45.822156
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:09:47.061151
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
# Done.


# Generated at 2022-06-25 14:10:24.916665
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    key = 'x'
    value = {}
    fact_cache_0.first_order_merge(key, value)
    exp_0 = dict()
    assert fact_cache_0.copy() == exp_0
    assert fact_cache_0.keys() == exp_0.keys()
    fact_cache_1 = FactCache()
    key = 'x'
    value = {}
    fact_cache_1.first_order_merge(key, value)
    exp_1 = dict()
    assert fact_cache_1.copy() == exp_1
    assert fact_cache_1.keys() == exp_1.keys()
    fact_cache_2 = FactCache()
    key = 'x'
    value = {}
    fact_cache_2.first_order

# Generated at 2022-06-25 14:10:26.197231
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc != None


# Generated at 2022-06-25 14:10:29.680429
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    fact_cache['1'] = '1'
    fact_cache.get('1')
    fact_cache.keys()
    fact_cache['2'] = '2'
    fact_cache.keys()
    fact_cache.flush()



# Generated at 2022-06-25 14:10:30.262067
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache("")


# Generated at 2022-06-25 14:10:30.854133
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache



# Generated at 2022-06-25 14:10:32.309312
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()

# test_main()

# Generated at 2022-06-25 14:10:33.784820
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    print("test_FactCache")


# Generated at 2022-06-25 14:10:36.476325
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge( 'test_key', 'test_value' )
    assert 'test_key' in fact_cache
    assert fact_cache['test_key'] == 'test_value'
    print('test_FactCache_first_order_merge')


# Generated at 2022-06-25 14:10:41.667556
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    fact_cache_1 = FactCache()
    fact_cache_1.update({})
    assert fact_cache_1 == {}

    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge('key0', {'key1': 'value1'})
    fact_cache_1.first_order_merge('key0', {'key2': 'value2'})

    assert fact_cache_1 == {'key0': {'key1': 'value1', 'key2': 'value2'}}

    fact_cache_2 = FactCache()
    fact_cache_2.first_order_merge('key0', {'key1': 'value1', 'key2': 'value2'})

# Generated at 2022-06-25 14:10:46.601827
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        test_case_0()
        print('Unit test OK - test_case_0')
    except AssertionError as e:
        print('Unit test ERROR - test_case_0')
        print(str(e))
        sys.exit(1)

# Run tests for class FactCache
test_FactCache()

# Generated at 2022-06-25 14:11:53.155083
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        fact_cache_0 = FactCache()
        assert fact_cache_0
    except ImportError:
        print("ImportError! Probably unable to load the facts cache plugin (%s)." % (C.CACHE_PLUGIN))



# Generated at 2022-06-25 14:11:54.450778
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_test = FactCache()
    assert fact_cache_test._plugin.get("test") is None

# Generated at 2022-06-25 14:11:55.193262
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

# Generated at 2022-06-25 14:11:55.920404
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert True

# Generated at 2022-06-25 14:11:58.171293
# Unit test for constructor of class FactCache
def test_FactCache():
    display.warning('TESTING FACT CACHE')
    fact_cache = FactCache()
    test_case_0()
#
# Main Function
#
if __name__ == "__main__":
    test_FactCache()

# Generated at 2022-06-25 14:12:00.082849
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge('192.168.1.1', {'foo': 'bar'})

# Generated at 2022-06-25 14:12:00.868770
# Unit test for constructor of class FactCache
def test_FactCache():
  fact_cache = FactCache()
  assert fact_cache

# Generated at 2022-06-25 14:12:01.637309
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()

# Generated at 2022-06-25 14:12:02.912734
# Unit test for constructor of class FactCache
def test_FactCache():
  test_case_0()

# Generated at 2022-06-25 14:12:04.587196
# Unit test for constructor of class FactCache
def test_FactCache():
    assert test_case_0() == None

# Generated at 2022-06-25 14:14:33.329695
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()


from ansible.playbook.play import Play
from ansible.playbook.task import Task
from ansible.plugins.loader import lookup_loader
from ansible.plugins.loader import module_loader
from ansible.template import Templar
from ansible.vars.clean import strip_internal_keys
from ansible.vars.manager import VariableManager


display = Display()



# Generated at 2022-06-25 14:14:34.787838
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert isinstance(fact_cache_0, FactCache)


# Generated at 2022-06-25 14:14:38.412895
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    key = "test"
    value = "test"
    fact_cache_1 = fact_cache_0.first_order_merge(key, value)
    assert fact_cache_1 is None
    assert fact_cache_0["test"] == {"test": "test"}

# Generated at 2022-06-25 14:14:41.822783
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.plugins.cache import memory

    C.CACHE_PLUGIN = 'memory'
    C.CACHE_PLUGIN_CONNECTION = {}
    fact_cache_0 = FactCache()
    assert isinstance(fact_cache_0, FactCache)
    assert isinstance(fact_cache_0._plugin, memory.CacheModule)


# Generated at 2022-06-25 14:14:42.868920
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    if fact_cache is None:
        assert False


# Generated at 2022-06-25 14:14:43.682170
# Unit test for constructor of class FactCache
def test_FactCache():
    f = FactCache()
    print(f)


# Generated at 2022-06-25 14:14:48.855984
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge('remote_ip', '127.0.0.1')
    fact_cache_1.first_order_merge('port', 22)
    assert fact_cache_1['remote_ip'] == '127.0.0.1'
    assert fact_cache_1['port'] == 22


# Generated at 2022-06-25 14:14:50.378408
# Unit test for constructor of class FactCache
def test_FactCache():
    # Unit tests for constructor
    test_case_0()


if __name__ == '__main__':
    test_FactCache()

# Generated at 2022-06-25 14:14:51.394508
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin


# Generated at 2022-06-25 14:14:53.978388
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()
    assert fact_cache_1

    try:
        FactCache()
    except AnsibleError:
        assert True
    else:
        assert False, 'Expected AnsibleError'
