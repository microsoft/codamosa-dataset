

# Generated at 2022-06-25 14:05:24.011437
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    # Desired return: {'test_key': 'test_value'}
    fact_cache_0.first_order_merge(key='test_key', value='test_value')


# Generated at 2022-06-25 14:05:25.375495
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()


# Generated at 2022-06-25 14:05:26.724591
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        _FactCache = FactCache()
    except:
        pass


# Generated at 2022-06-25 14:05:34.828266
# Unit test for constructor of class FactCache
def test_FactCache():
    hash_0 = {
        'a': 'b',
        'c': 'd',
        'e': 'f',
    }
    fact_cache_0 = FactCache(hash_0)

    hash_1 = {
        'a': 'b',
        'c': 'd',
        'e': 'f',
    }
    fact_cache_1 = FactCache(**hash_1)

    list_0 = [
        'abc',
        'def',
        'ghi',
        'jkl',
        'mno',
    ]
    fact_cache_2 = FactCache(list_0)


# Generated at 2022-06-25 14:05:38.160991
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    var_1 = FactCache()
    var_2 = "key"
    var_3 = "value"
    var_1.first_order_merge(var_2, var_3)


# Generated at 2022-06-25 14:05:46.546740
# Unit test for constructor of class FactCache
def test_FactCache():
    var_1 = FactCache()
    var_2 = fact_cache_0.__len__()
    fact_cache_0.update({'ansible_local': {'ansible_facts': {'facts_cache': {'CachePlugins': {'facts': {}}}}}})
    fact_cache_0 = FactCache({'ansible_local': {'ansible_facts': {'facts_cache': {'CachePlugins': {'facts': {}}}}}})
    fact_cache_0 = FactCache({'ansible_local': {'ansible_facts': {'facts_cache': {'CachePlugins': {'facts': {}}}}}})
    var_1.__delitem__('ansible_local')
    var_3 = fact_cache_0.__len__()
    var_3 = fact_cache

# Generated at 2022-06-25 14:05:48.525282
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('a', 'b')



# Generated at 2022-06-25 14:05:50.830777
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc is not None
    assert fc.__len__() == 0


# Generated at 2022-06-25 14:06:02.394774
# Unit test for constructor of class FactCache
def test_FactCache():
    struct_0 = {'_plugin': '', }
    fact_cache_0 = FactCache(struct_0)

    struct_1 = {'_plugin': '', 'display': 'test_value_2', }
    fact_cache_1 = FactCache(struct_1)
    display_0 = fact_cache_1.display

    struct_2 = {'_plugin': '', 'display': 'test_value_3', 'C': 'test_value_4', }
    fact_cache_2 = FactCache(struct_2)
    display_1 = fact_cache_2.display

    struct_3 = {'_plugin': '', 'display': 'test_value_5', 'C': 'test_value_6', '__metaclass__': 'test_value_7', }
    fact_cache_3 = Fact

# Generated at 2022-06-25 14:06:04.438164
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    var_0 = fact_cache_0.__len__()


# Generated at 2022-06-25 14:06:07.459493
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert len(fact_cache_0) == 0


# Generated at 2022-06-25 14:06:10.557285
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    fact_cache['test_key'] = 'test_value'
    fact_cache.first_order_merge('test_key', 'test_value')
    fact_cache.flush()


# Generated at 2022-06-25 14:06:15.719999
# Unit test for constructor of class FactCache
def test_FactCache():
    # test_case_0 not needed.  This test case always raises error
    # test_case_0()                 # test constructor
    test_case_1()                 # test contains()
    test_case_2()                 # test get()
    test_case_3()                 # test set()
    test_case_4()                 # test delete()
    test_case_5()                 # test keys()
    test_case_6()                 # test flush()
    test_case_7()                 # test copy()
    test_case_8()                 # test first_order_merge()
    test_case_9()                 # test copy()



# Generated at 2022-06-25 14:06:24.434363
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()                                                                                                         # __init__
    fact_cache_1.first_order_merge(key='test_key',value='test_value')                                                                  # first_order_merge
    assert 'test_key' in fact_cache_1.keys()                                                                                           # __iter__ + __contains__
    fact_cache_2 = FactCache()                                                                                                         # __init__
    fact_cache_1.first_order_merge(key='test_key',value='test_value')                                                                  # first_order_merge
    assert fact_cache_1.get(key='test_key') == fact_cache_2.get(key='test_key')                                                        # __getitem__
    fact_cache_2.first_

# Generated at 2022-06-25 14:06:25.384336
# Unit test for constructor of class FactCache
def test_FactCache():
    FactCache()
    return True

# Generated at 2022-06-25 14:06:26.336871
# Unit test for constructor of class FactCache
def test_FactCache():
    assert FactCache.__init__



# Generated at 2022-06-25 14:06:28.734358
# Unit test for constructor of class FactCache
def test_FactCache():
    display.display("Test constructor")
    fact_cache_0 = FactCache()
    assert fact_cache_0 is not None
    display.display("\n")


# Generated at 2022-06-25 14:06:30.278583
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:06:32.287737
# Unit test for constructor of class FactCache
def test_FactCache():
    print('Test: Test the constructor of class FactCache ...')
    test_case_0()
    print('Test: Done')


# Generated at 2022-06-25 14:06:34.622942
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()

    fact_cache_0.first_order_merge('key_0', 'value_0')
    assert fact_cache_0['key_0'] == 'value_0'



# Generated at 2022-06-25 14:06:37.634433
# Unit test for constructor of class FactCache
def test_FactCache():
    ansible_0 = FactCache()
    assert ansible_0.keys() == [], "The expected answer is '[]'"


# Generated at 2022-06-25 14:06:38.608450
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()

# Generated at 2022-06-25 14:06:39.916796
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:06:44.794844
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert len(fact_cache_0) == 0
    assert fact_cache_0.keys() == []
    assert fact_cache_0.has_key("key") == False
    fact_cache_0["key"] = "value"
    assert fact_cache_0["key"] == "value"
    assert fact_cache_0.has_key("key") == True
    fact_cache_0.flush()

# Generated at 2022-06-25 14:06:46.641861
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        test_case_0()
    except Exception as ex:
        print(ex)
        assert False


# Generated at 2022-06-25 14:06:49.832861
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert type(fact_cache_0) == FactCache


# Generated at 2022-06-25 14:06:53.058791
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        fact_cache = FactCache()
        assert(isinstance(fact_cache, FactCache))
    except:
        assert(False)

#   Unit test for update method of class FactCache

# Generated at 2022-06-25 14:06:54.555391
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache != None

# Generated at 2022-06-25 14:07:03.776815
# Unit test for constructor of class FactCache
def test_FactCache():
    # Creation of an object
    fact_cache = FactCache()
    # Check if the object is of the correct type
    assert isinstance(fact_cache, FactCache) == True
    # Check if the object is not empty
    assert bool(fact_cache) == True
    # Check if the object has the correct number of elements
    assert len(fact_cache) == 0
    # Put an element in
    fact_cache['foo'] = 'bar'
    # Put another element in
    fact_cache['kung'] = 'fu'
    # Check if the object has the correct number of elements
    assert len(fact_cache) == 2
    # Assert that certain keys are in the cache
    assert 'foo' in fact_cache
    assert 'kung' in fact_cache
    # Assert that certain keys aren't in the cache

# Generated at 2022-06-25 14:07:05.425804
# Unit test for constructor of class FactCache
def test_FactCache():

    fact_cache = FactCache()

    # test member variable plugin
    assert fact_cache._plugin is not None

# Generated at 2022-06-25 14:07:08.845366
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert(fact_cache)

# Generated at 2022-06-25 14:07:20.709202
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge("test_key", "test_value")
    fact_cache_0.first_order_merge("test_key", "test_value")
    fact_cache_0.first_order_merge("test_key", "test_value")
    fact_cache_0.first_order_merge("test_key", "test_value")
    fact_cache_0.first_order_merge("test_key1", "test_value")
    fact_cache_0.first_order_merge("test_key1", "test_value")
    fact_cache_0.first_order_merge("test_key1", "test_value")

# Generated at 2022-06-25 14:07:26.607753
# Unit test for constructor of class FactCache
def test_FactCache():
    host_a = {u'a': 'A'}
    host_b = {u'b': 'B'}
    host_c = {u'c': 'C'}
    key_a = u'localhost'
    key_b = u'127.0.0.1'
    fact_cache_0 = FactCache()
    fact_cache_0[key_a] = host_a
    fact_cache_0[key_b] = host_b

    # test that assigning a value returns the same value when reading it back
    # test that reading a value returns the same value when it was assigned
    assert fact_cache_0[key_a] == host_a


# Generated at 2022-06-25 14:07:28.065767
# Unit test for constructor of class FactCache
def test_FactCache():
    assert test_case_0() is None


# Generated at 2022-06-25 14:07:34.625633
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    with open(os.getcwd() + "/tests/test_fact_cache.txt", "r") as f:
        for line in f:
            a, b = line.split('\t')
            print(a)
            print(b)


if __name__ == '__main__':
    import os
    import sys
    import pytest

    pytest.main(sys.argv)
    test_case_0()
    test_FactCache_first_order_merge()

# Generated at 2022-06-25 14:07:43.678291
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge(key='127.0.0.1', value={'ansible_env':{'HOME': '/home/user', 'LANG': 'en_US.UTF-8'}, 'ansible_facts':{'vendor': 'Ubuntu', 'operatingsystem': 'Ubuntu', 'distribution': 'Ubuntu', 'distribution_version': '18.04', 'distribution_release': 'bionic', 'os_family': 'Debian', 'hostname': 'ubuntu-bionic', 'ip_address': '127.0.0.1'}})
    assert fact_cache_1.keys == ['127.0.0.1']

# Generated at 2022-06-25 14:07:46.129922
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    cache["test"] = "test"
    assert(cache["test"] == "test")


# Generated at 2022-06-25 14:07:47.478910
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

# Generated at 2022-06-25 14:07:55.915741
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    host_facts = dict()
    host_cache = dict()
    def _plugin_get(key):
        return host_cache
    def _plugin_set(key, value):
        host_facts[key] = value
    fc = FactCache()
    fc._plugin.get = _plugin_get
    fc._plugin.set = _plugin_set
    key = 'localhost'
    key2 = 'localhost2'
    value = {'ansible_other': {'foobar': 'baz'}}
    host_cache = {'ansible_other': {'bar': 'baz'}}
    fc.first_order_merge(key, value)
    assert host_facts['localhost']['ansible_other'] == {'foobar': 'baz', 'bar': 'baz'}, host_facts

# Generated at 2022-06-25 14:08:01.911117
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    key = "key_str_0"
    value = "value_str_0"
    fact_cache_0.first_order_merge(key, value)
    output_str =  fact_cache_0.copy()
    output_str.pop('ansible_facts', None)
    print(output_str)
    print("Test Success")

# run the test
test_FactCache_first_order_merge()

# Generated at 2022-06-25 14:08:08.285240
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-25 14:08:13.034096
# Unit test for constructor of class FactCache
def test_FactCache():
    print('*** start test_FactCache() ***')
    #print(json.dumps(FactCache, indent=4))
    assert FactCache
    print('*** end test_FactCache() ***')


if __name__ == "__main__":
    test_FactCache()

# Generated at 2022-06-25 14:08:15.045896
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()

if __name__ == "__main__":
    test_case_0()
    test_FactCache()

# Generated at 2022-06-25 14:08:15.969855
# Unit test for constructor of class FactCache
def test_FactCache():
    FactCache()


# Generated at 2022-06-25 14:08:17.485159
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()

if __name__ == "__main__":
    test_FactCache()

# Generated at 2022-06-25 14:08:19.435325
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    key = 'key_10'
    value = dict()
    fact_cache_0.first_order_merge(key, value)


# Generated at 2022-06-25 14:08:21.230305
# Unit test for constructor of class FactCache
def test_FactCache():
    f = FactCache()


# Generated at 2022-06-25 14:08:31.058908
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    fact_cache_0 = FactCache()

    new_facts = {'a_fact': 'some_value'}
    fact_cache_0.first_order_merge('some_host', new_facts)
    assert fact_cache_0['some_host'] == new_facts

    new_facts = {'a_fact': 'some_value', 'another_fact': 'another_value'}
    fact_cache_0.first_order_merge('some_host', new_facts)
    assert fact_cache_0['some_host'] == new_facts

    new_facts = {'a_fact': 'OVERRIDE', 'another_fact': 'another_value'}
    fact_cache_0.first_order_merge('some_host', new_facts)

# Generated at 2022-06-25 14:08:32.665394
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:08:36.128348
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        test_case_0()
        print("all tests passed for FactCache")
    except AssertionError as e:
        print("tests failed for FactCache")
        raise(e)

if __name__ == "__main__":
    test_FactCache()

# Generated at 2022-06-25 14:08:52.972010
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    # This is the comparison value (first_order_merge() of class FactCache)
    fact_cache_1.first_order_merge('10.0.0.1', {'a': True})
    expected = {'10.0.0.1': {'a': True}}
    assert fact_cache_1.copy() == expected
    assert fact_cache_1.keys() == ['10.0.0.1']
    assert fact_cache_1['10.0.0.1'] == {'a': True}
    fact_cache_1.flush()
    expected = {}
    assert fact_cache_1.copy() == expected
    assert fact_cache_1.keys() == []

# Generated at 2022-06-25 14:08:55.058294
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge('key', 'value')
    assert fact_cache_1['key'] == 'value'

# Generated at 2022-06-25 14:08:57.573315
# Unit test for constructor of class FactCache
def test_FactCache():
    display.display("Test - FactCache - constructor")

    fact_cache_0 = FactCache()

    assert fact_cache_0 is not None



# Generated at 2022-06-25 14:08:59.121873
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None


# Generated at 2022-06-25 14:09:02.261632
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0 is not None, "Unable to create object for class FactCache"


# Generated at 2022-06-25 14:09:03.687330
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:09:05.339999
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()
    assert isinstance(fact_cache_1, FactCache)


# Generated at 2022-06-25 14:09:06.905811
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert type(fact_cache_0) is FactCache


# Generated at 2022-06-25 14:09:08.346959
# Unit test for constructor of class FactCache
def test_FactCache():
    a = FactCache()
    assert isinstance(a, MutableMapping)


# Generated at 2022-06-25 14:09:10.704310
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    print('Testing method FactCache.first_order_merge')
    fact_cache = FactCache()
    fact_cache.first_order_merge('key_0', 'value_0')


# Generated at 2022-06-25 14:09:25.918513
# Unit test for constructor of class FactCache
def test_FactCache():
    assert FactCache is not None


# Generated at 2022-06-25 14:09:26.902415
# Unit test for constructor of class FactCache
def test_FactCache():
    assert isinstance(FactCache(), FactCache)


# Generated at 2022-06-25 14:09:34.077489
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    fact_cache['first_fact_key'] = ["first_fact_value"]
    fact_cache['second_fact_key'] = ["second_fact_value"]

    # Test keys method in class FactCache
    assert fact_cache.keys() == ['first_fact_key', 'second_fact_key']

    # Test copy method in class FactCache
    assert fact_cache.copy() == {'first_fact_key': ['first_fact_value'], 'second_fact_key': ['second_fact_value']}

    # Test first_order_merge method in class FactCache
    fact_cache.first_order_merge('third_fact_key', ["third_fact_value"])

# Generated at 2022-06-25 14:09:37.339582
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()
    test_case_0()

if __name__ == '__main__':
    test_FactCache()

# Generated at 2022-06-25 14:09:39.175072
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

if __name__ == '__main__':
    test_FactCache()

# Generated at 2022-06-25 14:09:42.385003
# Unit test for constructor of class FactCache
def test_FactCache():
    cache_obj = FactCache()
    print(type(cache_obj))
    cache_obj.flush()
    print(type(cache_obj))

test_FactCache()
test_case_0()

# Generated at 2022-06-25 14:09:46.363632
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    key = ansible_host_name
    value = ansible_all_ipv4_addresses
    fact_cache_0.first_order_merge(key, value)

test_FactCache_first_order_merge()


# Generated at 2022-06-25 14:09:48.624312
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.plugins import cache
    from ansible.plugins.cache.memory import FactCache

    fact_cache = FactCache()
    assert fact_cache is not None


# Generated at 2022-06-25 14:09:55.145497
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache(val=None)
    fact_cache_1 = FactCache(val='key')
    keys = fact_cache_0.keys()
    res = fact_cache_0.copy()
    fact_cache_0.first_order_merge('key', 'value')
    res = fact_cache_0['key']
    fact_cache_0['key'] = 'value'
    del fact_cache_0['key']
    res = 'key' in fact_cache_0
    res = len(fact_cache_0)
    lst = list(fact_cache_0)
    fact_cache_0.flush()
    res = fact_cache_0.copy()


if __name__ == "__main__":
    import sys

# Generated at 2022-06-25 14:10:04.870230
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    fact_cache_0['var_0'] = 'value_0'
    assert len(fact_cache_0) == 1
    assert fact_cache_0['var_0'] == 'value_0'
    assert 'var_0' in fact_cache_0
    assert 'var_1' not in fact_cache_0
    fact_cache_0['var_2'] = 'value_2'
    assert fact_cache_0['var_2'] == 'value_2'
    fact_cache_0['var_3'] = 'value_3'
    assert fact_cache_0['var_3'] == 'value_3'
    del fact_cache_0['var_2']
    assert fact_cache_0['var_3'] == 'value_3'
    assert fact

# Generated at 2022-06-25 14:10:36.753711
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:10:46.776484
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    # test for object of class FactCache
    assert isinstance(fact_cache, FactCache)
    # test for keys method of class FactCache
    assert isinstance(fact_cache.keys(), list)
    assert len(fact_cache.keys()) == 0
    assert "key1" in fact_cache.keys() is False
    # test for __getitem__, __setitem__ and __contains__ methods of class FactCache
    fact_cache["key1"] = "value1"
    assert fact_cache["key1"] == "value1"
    assert "key1" in fact_cache
    assert "key2" in fact_cache is False
    # test for __delitem__ method of class FactCache
    del fact_cache["key1"]
    assert "key1" in fact_cache is False

# Generated at 2022-06-25 14:10:53.689184
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    localhost = 'host0'
    result = fact_cache.first_order_merge(localhost, {"a": 1, "c": 3})
    print("result: ", result)
    result = fact_cache.first_order_merge(localhost, {"a": 2, "b": 3})
    print("result: ", result)
    result = fact_cache.first_order_merge(localhost, {"a": 2, "b": 3})
    print("result: ", result)


if __name__ == '__main__':
    test_FactCache_first_order_merge()

# Generated at 2022-06-25 14:11:01.064426
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()


# Generated at 2022-06-25 14:11:03.690928
# Unit test for constructor of class FactCache
def test_FactCache():
    with pytest.raises(AnsibleError) as exec_info:
        fact_cache_0 = FactCache()
    assert 'Unable to load the facts cache plugin' in str(exec_info.value)


# Generated at 2022-06-25 14:11:06.817291
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert_equals(fact_cache_0.__init__(), None)


# Generated at 2022-06-25 14:11:08.522045
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()


# Generated at 2022-06-25 14:11:16.861380
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()

    #
    # Initialize facts to first order facts
    #
    test_case_0_0_facts = {'ansible_os_family': 'RedHat'}
    #
    # Initialize facts to second order facts
    #
    test_case_0_1_facts = {'ansible_distribution': 'Fedora', 'ansible_distribution_version': '23'}
    #
    # Initialize facts to second order facts
    #
    test_case_0_2_facts = {'ansible_distribution_major_version': '28', 'ansible_distribution_release': 'Fedora'}
    #
    # Initialize facts to third order facts
    #

# Generated at 2022-06-25 14:11:18.789244
# Unit test for constructor of class FactCache
def test_FactCache():
    # The purpose of this unit test is to test the constructor of class FactCache
    try:
        fact_cache_0 = FactCache()
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-25 14:11:19.684186
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0 != None

# Generated at 2022-06-25 14:12:37.764585
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    host_facts = {'hostvars': {}}
    host_fact_cache = {'hostvars': {}}

    # Test when host_fact_cache is not empty
    host_facts['hostvars']['test_host_0'] = {'fact_0': [1, 2, 3]}
    host_facts['hostvars']['test_host_1'] = {'fact_1': [1, 2, 3]}

    host_fact_cache['hostvars']['test_host_0'] = {'fact_2': [4, 5, 6]}
    host_fact_cache['hostvars']['test_host_2'] = {'fact_3': [7, 8, 9]}

    fact_cache = FactCache()


# Generated at 2022-06-25 14:12:38.945137
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    key = 'test_key'
    value = {}
    fact_cache_0.first_order_merge(key, value)


# Generated at 2022-06-25 14:12:40.116420
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None, 'Failed to create instance of FactCache class'

# Generated at 2022-06-25 14:12:42.563046
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, MutableMapping)
    assert fact_cache
    assert fact_cache.keys() == []


# Generated at 2022-06-25 14:12:45.977611
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Setup
    fact_cache_0 = FactCache()
    fact_cache_0.flush()
    key = "k"
    value = {}
    # Run target
    fact_cache_0.first_order_merge(key, value)
    # Verify
    verified = False
    if key in fact_cache_0:
        verified = True
    else:
        verified = False
    assert verified

# Generated at 2022-06-25 14:12:53.081782
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    hostvars_dict = {}
    ansible_facts_dict = {"var1": "value1"}
    host_cache_dict = {}
    host_facts_dict = {}
    fact_cache_0 = FactCache()
    hostvars_dict.update({"var1": "value1"})
    ansible_facts_dict.update({'var1': 'value1'})
    host_cache_dict.update({'var1': 'value1'})
    fact_cache_0.update(ansible_facts_dict)
    host_facts_dict.update({'var1': 'value1'})
    expected_hostvars_dict = {"var1": "value1"}
    expected_ansible_facts_dict = {'var1': 'value1'}

# Generated at 2022-06-25 14:13:00.165078
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Tests a case where the host cache is not in the cache
    fact_cache_0 = FactCache()
    assert '' not in fact_cache_0
    # Call the method
    fact_cache_0.first_order_merge('foo', 'bar')
    # Verify that the specified key is within the cache
    assert 'foo' in fact_cache_0
    assert fact_cache_0.get('foo') == 'bar'
    # Flush the fact cache
    fact_cache_0.flush()

# Test fact_cache.first_order_merge which merges the host facts into the host cache
# in the fact_cache with the host cache.
# With a key and value that are not in the fact_cache,
# and with an existing host_cache.

# Generated at 2022-06-25 14:13:02.260839
# Unit test for constructor of class FactCache
def test_FactCache():
    # Tests for instantiation
    test_case_0()
    print('UnitTest success for testing constructor of class FactCache')

'''
if __name__ == '__main__':
    main()
'''

# Generated at 2022-06-25 14:13:06.707499
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    key = 'localhost'
    value = {'ansible_distribution': 'CentOS'}
    fact_cache_1.first_order_merge(key, value)
    assert fact_cache_1['localhost']['ansible_distribution'] == 'CentOS'


# Generated at 2022-06-25 14:13:07.183905
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    pass