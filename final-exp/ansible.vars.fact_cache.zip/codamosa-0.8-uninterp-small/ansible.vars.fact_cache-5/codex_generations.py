

# Generated at 2022-06-25 14:05:21.165573
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('key1', 'value1')
    fact_cache.first_order_merge('key2', 'value2')
    fact_cache.first_order_merge('key3', 'value3')


# Generated at 2022-06-25 14:05:25.594311
# Unit test for constructor of class FactCache
def test_FactCache():
    print('In test_FactCache()')
    fact_cache_1 = FactCache()
    assert fact_cache_1._plugin == cache_loader.get(C.CACHE_PLUGIN)
    assert fact_cache_1._plugin.contains('hostname') == False 
    assert len(fact_cache_1) == 0
    assert fact_cache_1.keys() == []


# Generated at 2022-06-25 14:05:26.655303
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache


# Generated at 2022-06-25 14:05:37.102500
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    """ Test if the host_cache is updated with the new facts """
    # remove any existing cache file
    fact_cache_file = '/tmp/facts_test_case_1'
    try:
        os.remove(fact_cache_file)
    except OSError:
        pass

    fact_cache_1 = FactCache(plugin='jsonfile', timeout=0, expire=5, fact_path=fact_cache_file)

# Generated at 2022-06-25 14:05:39.783494
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    print(fact_cache)
    print(fact_cache._plugin)
    print(fact_cache._plugin.contains())



# Generated at 2022-06-25 14:05:41.034868
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache


# Generated at 2022-06-25 14:05:42.572235
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert(fact_cache is not None)


# Generated at 2022-06-25 14:05:45.468344
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    facts = dict(a=1, b=2, c=3)
    fact_cache.first_order_merge('atest', facts)
    assert fact_cache['atest']['a'] == 1


# Generated at 2022-06-25 14:05:47.648127
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge("test_key", {})

# Generated at 2022-06-25 14:05:49.019411
# Unit test for constructor of class FactCache
def test_FactCache():
    factcache = FactCache()
    assert factcache



# Generated at 2022-06-25 14:05:55.600503
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('key', 'value')
    assert fact_cache['key'] == 'value'


# Generated at 2022-06-25 14:05:56.506789
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()
    assert fact_cache_1._plugin._cache_prefix == 'ansible_facts'


# Generated at 2022-06-25 14:06:06.520421
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    key = "localhost-172-24-7-133"

# Generated at 2022-06-25 14:06:08.235208
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    c0 = FactCache()
    c0.first_order_merge("test0", {"test0": True})

# Generated at 2022-06-25 14:06:10.886299
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    display.display("test_FactCache: assert isinstance(fact_cache, MutableMapping)")
    assert isinstance(fact_cache, MutableMapping)


# Generated at 2022-06-25 14:06:13.204435
# Unit test for constructor of class FactCache
def test_FactCache():

    # fact_cache_0 constructor
    # Should print a single line:
    #   Unable to load the facts cache plugin (redis).
    test_case_0()

test_FactCache()

# Generated at 2022-06-25 14:06:20.992847
# Unit test for constructor of class FactCache
def test_FactCache():

    cache = FactCache()

    assert not cache

    data = {'foo': 'bar'}

    cache.first_order_merge('data', data)

    assert 'data' in cache
    assert cache['data']['foo'] == data['foo']
    assert cache.copy() == {'data': {'foo': 'bar'}}

    cache.__setitem__('data2', {'baz': 'bat'})

    assert cache['data2']['baz'] == 'bat'

    cache.flush()
    assert not cache


# Generated at 2022-06-25 14:06:22.111551
# Unit test for constructor of class FactCache
def test_FactCache():
    factcache = FactCache()


# Generated at 2022-06-25 14:06:28.554029
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test', {'a': 1, 'b': 2})
    fact_cache.flush()

    assert len(fact_cache) == 0

    fact_cache.first_order_merge('test', {'a': 1, 'b': 2})
    fact_cache.first_order_merge('test', {'b': 3, 'c': 4})

    assert fact_cache['test']['b'] == 3

# Generated at 2022-06-25 14:06:32.920514
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()

    # Case 0: attributes are created
    assert hasattr(fact_cache, '_plugin')

    # Case 1: _plugin is instanceof PluginLoader
    assert isinstance(fact_cache._plugin, pluginloader)

    # Case 2: _plugin is initialized from CACHE_PLUGIN



# Generated at 2022-06-25 14:06:39.731231
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()

# Generated at 2022-06-25 14:06:44.947077
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    fact_cache_1 = FactCache()
    fact_cache_2 = FactCache()
    fact_cache_3 = FactCache()
    fact_cache_4 = FactCache()
    fact_cache_5 = FactCache()
    fact_cache_6 = FactCache()
    fact_cache_8 = FactCache()
    fact_cache_9 = FactCache()
    fact_cache_10 = FactCache()



# Generated at 2022-06-25 14:06:46.854359
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        fact_cache_0 = FactCache()
    except AnsibleError:
        fact_cache_0 = None
    assert fact_cache_0 is None


# Generated at 2022-06-25 14:06:53.547326
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge('test_key', 'test_value')
    fact_cache_0.first_order_merge('test_key', 'test_value')
    fact_cache_0.first_order_merge('test_key', 'test_value')


# Generated at 2022-06-25 14:06:56.293777
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0._plugin.__class__.__name__ == 'JsonFileCacheModule'

# Generated at 2022-06-25 14:06:58.918294
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)
    assert isinstance(fact_cache, MutableMapping)


# Generated at 2022-06-25 14:07:01.134727
# Unit test for constructor of class FactCache
def test_FactCache():
    print('*'*80)
    print('Unit test for constructor of class FactCache')
    try:
        fact_cache_0 = FactCache()
    except Exception as e:
        print(e)
    else:
        print('Passed unit test for constructor of class FactCache')


# Generated at 2022-06-25 14:07:02.209939
# Unit test for constructor of class FactCache
def test_FactCache():
   # constructor for class FactCache
   fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:07:13.546881
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()
    # test keys
    assert fact_cache_1.keys() == []
    # test copy method
    assert fact_cache_1.copy() == {}
    # test flush method
    fact_cache_1.flush()
    # test first_order_merge method
    fact_cache_1.first_order_merge('node0', {})
    # test __getitem__
    assert fact_cache_1['node0'] == {}
    # test __setitem__
    fact_cache_1['node1'] = {}
    # test __delitem__
    del fact_cache_1['node1']
    # test __len__
    assert len(fact_cache_1) == 1
    assert fact_cache_1['node0'] == {}
    assert fact_cache_1

# Generated at 2022-06-25 14:07:15.375958
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

if __name__ == '__main__':
    test_FactCache()

# Generated at 2022-06-25 14:07:22.193030
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0

# Generated at 2022-06-25 14:07:24.461487
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    # Check the type of fact_cache_0 is FactCache
    if not isinstance(fact_cache_0, FactCache):
        return False

    return True


# Generated at 2022-06-25 14:07:26.935545
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache() 


# Unit tests for class FactCache

# Generated at 2022-06-25 14:07:28.012404
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

# Generated at 2022-06-25 14:07:29.846296
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0 != None



# Generated at 2022-06-25 14:07:36.758877
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge('os', {'os_version': '7.1', 'name': 'aix'})
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge('os', {'distribution_version': '7.1', 'name': 'aix'})

if __name__ == "__main__":
    test_case_0()
    test_FactCache_first_order_merge()

# Generated at 2022-06-25 14:07:37.617451
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

# Generated at 2022-06-25 14:07:42.038986
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc.keys() == []
    fc['p1']='p1_val'
    assert fc.keys() == ['p1']
    assert fc['p1'] == 'p1_val'
    fc.flush()
    assert fc.keys() == []

# Generated at 2022-06-25 14:07:47.017890
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        test_case_0()
    except Exception as e:
        print("Exception in user code:")
        print("-"*60)
        traceback.print_exc(file=sys.stdout)
        print("-"*60)
        raise(e)
    else:
        pass
    finally:
        pass

# Unit test execution
if __name__ == '__main__':
    import traceback
    import sys
    test_FactCache()

# Generated at 2022-06-25 14:07:48.347875
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    fact_cache.__init__()


# Generated at 2022-06-25 14:08:02.308602
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert(True)


# Generated at 2022-06-25 14:08:09.967407
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache['test_case'] = {'value': {'l2_load': 1, 'l3_load': 2}}
    fact_cache.first_order_merge('test_case', {'value': {'l3_load': 3, 'l4_load': 4}, 'index': 1})
    fact_cache.first_order_merge('test_case', {'value': {'l3_load': 5, 'l5_load': 6}, 'index': 2})
    assert fact_cache['test_case'] == {'value': {'l2_load': 1, 'l3_load': 5, 'l4_load': 4, 'l5_load': 6}, 'index': 2}

# Generated at 2022-06-25 14:08:16.553850
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    key = "localhost"
    value = {"ansible_os_family": "Debian", "ansible_distribution": "Debian", "ansible_distribution_version": "wheezy/sid", "ansible_distribution_release": "wheezy/sid", "ansible_all_ipv4_addresses": ["127.0.0.1"]}
    fact_cache_1.first_order_merge(key, value)
    assert fact_cache_1[key] == value

# Generated at 2022-06-25 14:08:22.402892
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    display.display("test case 1")
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge("test", {"newkey": "newvalue"})
    print(fact_cache_1["test"])
    fact_cache_1.first_order_merge("test", {"newkey1": "newvalue1"})
    print(fact_cache_1["test"])

if __name__ == "__main__":
    test_case_0()
    test_FactCache_first_order_merge()

# Generated at 2022-06-25 14:08:31.572750
# Unit test for constructor of class FactCache
def test_FactCache():
    C.CACHE_PLUGIN = 'jsonfile'
    fact_cache1 = FactCache()
    fact_cache1["1.1.1.1"] = { "key1":"value1", "key2":"value2" }
    assert fact_cache1["1.1.1.1"]["key1"] == "value1"
    assert fact_cache1["1.1.1.1"]["key2"] == "value2"
    fact_cache1["1.1.1.1"]["key2"] = "value2"
    assert fact_cache1["1.1.1.1"]["key2"] == "value2"
    fact_cache1["1.1.1.2"] = { "key1":"value1", "key2":"value2" }
    assert fact_cache1

# Generated at 2022-06-25 14:08:32.318541
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None


# Generated at 2022-06-25 14:08:33.244612
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()


# Generated at 2022-06-25 14:08:39.991825
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    local_hostname = "localhost"
    local_factoids = {"stack": "java", "language": "python"}
    fact_cache_0 = FactCache()
    # Check that the local facts are not in the cache yet
    assert(not local_hostname in fact_cache_0)
    fact_cache_0.first_order_merge(local_hostname, local_factoids)
    # Check that the local facts are now in the cache
    assert(local_hostname in fact_cache_0)
    # Check that the local facts are correct
    assert(local_factoids == fact_cache_0[local_hostname])



# Generated at 2022-06-25 14:08:42.709573
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge('127.0.0.1', {'test_key': 'test_value'})


# Generated at 2022-06-25 14:08:46.343690
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Initialize the cache
    fact_cache_1 = FactCache()
    assert fact_cache_1 is not None

    # Test first_order_merge
    fact_cache_1.first_order_merge(key="foo", value="bar")
    assert fact_cache_1.has_key("foo")


# Generated at 2022-06-25 14:09:18.986568
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    try:
        fact_cache_1 = FactCache()
        fact_cache_1.first_order_merge(None, None)
    except Exception as e:
        display.error('Caught exception: %s' % repr(e))
        assert False

#TODO: test_case_1
#TODO: test_case_2
#TODO: test_case_3
#TODO: test_case_4
#TODO: test_case_5


# Generated at 2022-06-25 14:09:22.681999
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()

    # Testing if constructor sets _plugin as expected
    assert fact_cache_0._plugin == cache_loader.get(C.CACHE_PLUGIN)



# Generated at 2022-06-25 14:09:24.134544
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:09:25.037873
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

# Generated at 2022-06-25 14:09:26.269607
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache != None

# Generated at 2022-06-25 14:09:27.100459
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

# Generated at 2022-06-25 14:09:28.357796
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0._plugin == fact_cache_0._plugin


# Generated at 2022-06-25 14:09:30.704600
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Test#0
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge('key0', 'value0')

# Generated at 2022-06-25 14:09:31.509799
# Unit test for constructor of class FactCache
def test_FactCache():
    print(FactCache)

    test_case_0()

# Generated at 2022-06-25 14:09:36.314956
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge(key = 'key_0', value = 'value_0')
    fact_cache_0.first_order_merge(key = 'key_1', value = 'value_1')
    assert fact_cache_0.keys != None


# Generated at 2022-06-25 14:10:34.598482
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge("localhost", {"a": "b", "c": "d"})
    fact_cache_1.first_order_merge("localhost", {"b": "b", "c": "d"})



# Generated at 2022-06-25 14:10:43.858648
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import json
    import os

    cwd = os.getcwd()
    ansible_fact_cache = FactCache()
    cache_dir = os.path.join(cwd, '..', '..', '..', 'test', 'units', 'cache')
    cache_filename = os.path.join(cache_dir, 'setup_ansible_local.cache')

    with open(cache_filename, 'r') as cache_file:
        ansible_facts = json.load(cache_file)
        for key, value in ansible_facts.items():
            ansible_fact_cache.first_order_merge(key, value)

    assert ansible_fact_cache['localhost']['ansible_facts']['os_family'] == 'OpenBSD'

# Generated at 2022-06-25 14:10:52.739532
# Unit test for method first_order_merge of class FactCache

# Generated at 2022-06-25 14:10:54.363720
# Unit test for constructor of class FactCache
def test_FactCache():
    display.info("Unit test for constructor of class FactCache(1)")
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:10:56.331157
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()
    #print fact_cache_1
    #print '-------------------------'
    assert fact_cache_1 != None

# Generated at 2022-06-25 14:10:57.412987
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc


# Generated at 2022-06-25 14:11:00.157199
# Unit test for constructor of class FactCache
def test_FactCache():
    facts = {
        'Continent': 'North America',
        'Country': 'Canada',
        'Region': 'Quebec'
    }
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge('localhost', facts)
    assert len(fact_cache_1) == 1, "len(fact_cache_1) == 1"

# Generated at 2022-06-25 14:11:02.130535
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge("key0", "value0")
    assert(fact_cache_1["key0"] == "value0")



# Generated at 2022-06-25 14:11:03.609039
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, MutableMapping)

# Generated at 2022-06-25 14:11:05.726954
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()
    assert fact_cache_1.__eq__(dict())


# Generated at 2022-06-25 14:13:30.162471
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge('localhost', {'fact_1': 'value_1'})
    assert fact_cache_1['localhost']['fact_1'] == 'value_1'
    fact_cache_1.first_order_merge('localhost', {'fact_1': 'value_2'})
    assert fact_cache_1['localhost']['fact_1'] == 'value_2'
    fact_cache_1.first_order_merge('localhost', {'fact_2': 'value_1'})
    assert fact_cache_1['localhost']['fact_2'] == 'value_1'
    fact_cache_1.first_order_merge('localhost_2', {'fact_1': 'value_1'})
   

# Generated at 2022-06-25 14:13:37.365020
# Unit test for constructor of class FactCache
def test_FactCache():
    # Generate an instance of class FactCache
    fact_cache_0 = FactCache()
    assert isinstance(fact_cache_0, FactCache)

    # Generate an instance of class FactCache
    fact_cache_1 = FactCache()
    assert isinstance(fact_cache_1, FactCache)

    # Generate an instance of class FactCache
    fact_cache_2 = FactCache()
    assert isinstance(fact_cache_2, FactCache)

    # Generate an instance of class FactCache
    fact_cache_3 = FactCache()
    assert isinstance(fact_cache_3, FactCache)

    # Generate an instance of class FactCache
    fact_cache_4 = FactCache()
    assert isinstance(fact_cache_4, FactCache)

    # Generate an instance of class FactCache
    fact_

# Generated at 2022-06-25 14:13:38.236353
# Unit test for constructor of class FactCache
def test_FactCache():
	test_case_0()

test_FactCache()

# Generated at 2022-06-25 14:13:40.013112
# Unit test for constructor of class FactCache
def test_FactCache():
    f = FactCache()
    assert f._plugin is not None, 'FactCache() failed'


# Generated at 2022-06-25 14:13:48.176302
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    test_Facts_0  = { 'host_collect_facts': True }
    test_Facts_1  = { 'ansible_version': '2.7.6' }
    fact_cache_1.first_order_merge('test_host_0', test_Facts_0)
    assert( fact_cache_1['test_host_0'] == test_Facts_0 )
    fact_cache_1.first_order_merge('test_host_0', test_Facts_1)
    assert( fact_cache_1['test_host_0'] == { 'host_collect_facts': True,
                                             'ansible_version': '2.7.6' } )

if __name__ == '__main__':
    test_case_

# Generated at 2022-06-25 14:13:49.141651
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:13:50.200507
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache



# Generated at 2022-06-25 14:13:57.896627
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Initialize the fact_name to fact_value of type string
    fact_name = "testing"
    fact_value = "abc"

    # Get the object of class FactCache
    fact_cache = FactCache()

    # Initialize the host name
    host = 'test-host-0'

    # Add the fact to the host cache
    fact_cache[host] = {'ansible_facts': {fact_name: fact_value}}

    # The fact which is to be merged
    fact_name = "testing"
    fact_value = "abcd"

    fact_cache.first_order_merge(host, {'ansible_facts': {fact_name: fact_value}})

    assert fact_cache[host]['ansible_facts']['testing'] == 'abcd'

# Generated at 2022-06-25 14:13:58.790429
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

# Generated at 2022-06-25 14:14:05.690327
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'test_var_0': 42}})
    if fact_cache['localhost']['ansible_facts']['test_var_0'] != 42:
        raise Exception('Unexpected value for test_var_0.')
    fact_cache['localhost']['ansible_facts']['test_var_1'] = 43
    fact_cache.first_order_merge('localhost', {'ansible_facts': {'test_var_1': 44}})
    if fact_cache['localhost']['ansible_facts']['test_var_1'] != 44:
        raise Exception('Unexpected value for test_var_1 after merging.')

