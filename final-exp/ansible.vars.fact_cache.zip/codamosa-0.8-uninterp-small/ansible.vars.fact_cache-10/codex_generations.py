

# Generated at 2022-06-25 14:05:22.818508
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('foo', 'bar')
    expected = {'foo': 'bar'}
    assert fact_cache == expected

    fact_cache.first_order_merge('foo', 'baz')
    expected = {'foo': 'baz'}
    assert fact_cache == expected

    fact_cache.first_order_merge('foo', {'bar': 'baz'})
    expected = {'foo': {'bar': 'baz'}}
    assert fact_cache == expected

    fact_cache.first_order_merge('foo', {'baz': 'qux'})
    expected = {'foo': {'bar': 'baz', 'baz': 'qux'}}
    assert fact_cache == expected

# Generated at 2022-06-25 14:05:29.439268
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.flush()
    fact_cache_0.first_order_merge('localhost', {'foo': 'bar'})
    fact_cache_0.first_order_merge('localhost', {'baz': 'qux'})
    if fact_cache_0['localhost'] != {'baz': 'qux', 'foo': 'bar'}:
        raise AssertionError("'localhost': {} does not match {'baz': 'qux', 'foo': 'bar'}")



# Generated at 2022-06-25 14:05:31.139427
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0 != None



# Generated at 2022-06-25 14:05:41.679140
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_1 = FactCache()
    fact_cache_0.first_order_merge("key_03", "value_04")
    fact_cache_1.first_order_merge("key_06", "value_07")
    fact_cache_0.first_order_merge("key_09", "value_10")
    fact_cache_1.first_order_merge("key_12", "value_13")
    fact_cache_0.first_order_merge("key_15", "value_16")
    fact_cache_1.first_order_merge("key_18", "value_19")
    fact_cache_0.first_order_merge("key_21", "value_22")
    fact_cache_1.first_

# Generated at 2022-06-25 14:05:43.550895
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    # test result of first_order_merge method
    fact_cache_0.first_order_merge('test', 'test')
    assert True



# Generated at 2022-06-25 14:05:46.472673
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge('localhost', {u'foo': u'bar'})

test_case_0()
test_FactCache_first_order_merge()

# Generated at 2022-06-25 14:05:47.812414
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()


# Generated at 2022-06-25 14:05:50.014605
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    test_object = FactCache()
    test_object.first_order_merge(key="any_key", value="any_value")

# Generated at 2022-06-25 14:06:01.349044
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    import sys
    # python2 only
    if sys.version_info[0] == 2:
        # test syntax
        fact_cache_1 = FactCache()
        fact_cache_2 = FactCache()
        fact_cache_3 = FactCache()
        fact_cache_1.first_order_merge("localhost", {"ansible_os_family": "RedHat"})
        fact_cache_2.first_order_merge("localhost", {"ansible_os_family": "RedHat"})
        fact_cache_3.first_order_merge("localhost", {"ansible_os_family": "RedHat"})
        fact_cache_2.first_order_merge("localhost", {"ansible_os_family": "Debian"})
        # Test for sequential value changes

# Generated at 2022-06-25 14:06:10.969499
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import os
    import tempfile

    cache_dir = tempfile.mkdtemp()
    cache_file = os.path.join(cache_dir, 'facts.cache')
    cache = FactCache()
    cache._plugin.filename = cache_file

    # Test that an entry is created if it doesn't exist
    cache.first_order_merge('host1', {'key': 'value'})
    assert cache['host1'] == {'key': 'value'}

    # Test that an old entry is overwritten
    cache.first_order_merge('host1', {'key': 'value', 'key2': 'value2'})
    assert cache['host1'] == {'key': 'value', 'key2': 'value2'}

    # Test that unrelated entries are untouched

# Generated at 2022-06-25 14:06:13.488515
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert isinstance(fact_cache_0, FactCache)


# Generated at 2022-06-25 14:06:15.115392
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        test_case_0()
    except:
        return False

    return True


# Unit test

# Generated at 2022-06-25 14:06:18.849823
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    # Test properties
    assert fact_cache._plugin == cache_loader.get(C.CACHE_PLUGIN)
    # Test methods



# Generated at 2022-06-25 14:06:23.684700
# Unit test for constructor of class FactCache
def test_FactCache():
    host_name = "localhost"
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge(host_name, {"test_case": 0})
    value = fact_cache_0[host_name]["test_case"]
    print("check the constructor of the class FactCache")
    print("value:", value)
    assert value == 0
    print("check the constructor of the class FactCache---pass!")


# Generated at 2022-06-25 14:06:25.004748
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-25 14:06:34.332932
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    host = "localhost"
    host_facts = dict()
    host_facts = {"hostname": "localhost1", "ansible_distribution": "RedHat", "ansible_distribution_version": "7.4"}
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge(host, host_facts)
    host_facts = {"hostname": "localhost1", "ansible_distribution": "RedHat", "ansible_distribution_version": "7.4",
                  "ansible_distribution_major_version": "7",
                  "ansible_distribution_release": "RedHat Enterprise Linux Server", "ansible_os_family": "RedHat"}
    fact_cache_0.first_order_merge(host, host_facts)

# Generated at 2022-06-25 14:06:35.158724
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

# Generated at 2022-06-25 14:06:37.418400
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()
    cache = FactCache()
    cache.first_order_merge('test_host', {'test_fact': 'fact_value'})

# Generated at 2022-06-25 14:06:38.745120
# Unit test for constructor of class FactCache
def test_FactCache():
    global fact_cache_0
    test_case_0()


# Generated at 2022-06-25 14:06:40.746334
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        test_case_0()
    except Exception as e:
        print("Test Case error: " + str(e))
        raise e

# Generated at 2022-06-25 14:06:43.358941
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()


if __name__ == "__main__":
    test_FactCache()

# Generated at 2022-06-25 14:06:50.257093
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.flush()
    key_1 = ['key_str']
    value_1 = [{'dst_ip': '192.168.0.111', 'bytes_sent': 1546, 'icmp_type': 8, 'packet_sent': 1, 'packet_received': 1,
         'dst_port': '0', 'bytes_received': 60, 'protocol': 'ICMP', 'icmp_code': 0, 'ttl': 64, 'src_ip': '192.168.0.222',
         'src_port': '0'}]
    fact_cache_1.first_order_merge(key_1, value_1)

# Generated at 2022-06-25 14:06:52.162513
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()
# test_FactCache - END


# Generated at 2022-06-25 14:06:55.194025
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        test_case_0()
    except Exception as e:
        display.error('Caught exception in test case: ' + str(e))
        raise e

# Generated at 2022-06-25 14:06:56.856490
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_2 = FactCache()


# Generated at 2022-06-25 14:06:59.376692
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()
    assert fact_cache_1._plugin == cache_loader.get(C.CACHE_PLUGIN)


# Generated at 2022-06-25 14:07:00.686602
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:07:01.954149
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    print('Success: test_FactCache')


# Generated at 2022-06-25 14:07:04.462619
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        fact_cache_1 = FactCache()
        display.display("#### Constructor of class FactCache is working ####")
    except Exception:
        display.display("#### Constructor of class FactCache is not working ####")


# Generated at 2022-06-25 14:07:06.114955
# Unit test for constructor of class FactCache
def test_FactCache():
     fact_cache_1 = FactCache()
     assert fact_cache_1



# Generated at 2022-06-25 14:07:10.966601
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        test_case_0()
    except Exception as ex:
        print(ex)


if __name__ == "__main__":
    test_FactCache()

# Generated at 2022-06-25 14:07:12.308924
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()

# Generated at 2022-06-25 14:07:18.731245
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge("localhost", {"a":"b"})
    assert fact_cache_1["localhost"] == {"a":"b"}

    fact_cache_2 = FactCache()
    fact_cache_2.first_order_merge("localhost", {"a":"b"})
    assert fact_cache_2["localhost"] == {"a":"b"}

# Generated at 2022-06-25 14:07:20.909536
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert (fact_cache_0 is not None)


# Generated at 2022-06-25 14:07:29.089515
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin == cache_loader.get(C.CACHE_PLUGIN)

    fact_cache[1] = 1
    assert fact_cache[1] == 1
    assert fact_cache.keys() == [1]
    assert fact_cache.copy() == {1: 1}
    del fact_cache[1]
    assert not fact_cache.keys()
    fact_cache.flush()
    fact_cache.first_order_merge(1, 1)
    assert fact_cache[1] == {1: 1}

# Generated at 2022-06-25 14:07:34.101537
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    key = "127.0.0.1"
    value = {"ansible_distribution": "CentOS", "ansible_distribution_version": "7.2.1511"}
    fact_cache.first_order_merge(key, value)
    assert len(fact_cache) == 1
    assert key in fact_cache


# Generated at 2022-06-25 14:07:42.210544
# Unit test for constructor of class FactCache
def test_FactCache():

    # test case from test_case_0
    fact_cache_0 = FactCache()
    keys = fact_cache_0.keys()

    if not keys:
        assert(True)
    else:
        assert(False)

    fact_cache_0['ec2_instance_id'] = 'i-09e5f2dac653286ca'
    fact_cache_0['ec2_instance_type'] = 'm4.large'
    fact_cache_0['ec2_tags'] = {'Server': 'Pipeline_01', 'Environment': 'Production'}

    fact_cache_0.flush()


# Generated at 2022-06-25 14:07:48.576249
# Unit test for constructor of class FactCache
def test_FactCache():
    fact = FactCache()
    # print(fact)
    # print(fact.__getitem__())
    # print(fact.__setitem__())
    # print(fact.__delitem__())
    # print(fact.__contains__())
    # print(fact.__iter__())
    # print(fact.__len__())
    # print(fact.copy())
    # print(fact.keys())
    # print(fact.flush())
    # print(fact.first_order_merge())
    # print(fact.get_plugin())

if __name__ == '__main__':
    test_FactCache()

# Generated at 2022-06-25 14:07:49.909424
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc is not None


# Generated at 2022-06-25 14:07:51.844125
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    if fact_cache:
        print("Testcase passed")
    else:
        raise Exception("Testcase failed")



# Generated at 2022-06-25 14:07:57.358885
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

# Generated at 2022-06-25 14:07:59.362472
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge("foo", {"bar":"baz"})

# Generated at 2022-06-25 14:08:03.776009
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_key', {'test_key_0': 0})
    if 'test_key' in fact_cache:
        display.display('test_key exists in fact_cache')
    else:
        raise AnsibleError('test_key doesn\'t exist in fact_cache')

# Generated at 2022-06-25 14:08:05.176851
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:08:06.752186
# Unit test for constructor of class FactCache
def test_FactCache():
    assert test_case_0() == None, "test_case_0()"


# Generated at 2022-06-25 14:08:09.021971
# Unit test for constructor of class FactCache
def test_FactCache():
    # Simple test to ascertain that class FactCache can be constructed

    # Create a test object
    fact_cache = FactCache()



# Generated at 2022-06-25 14:08:10.742435
# Unit test for constructor of class FactCache
def test_FactCache():

    test_case_0()

# Generated at 2022-06-25 14:08:13.437117
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    assert fact_cache_1.first_order_merge('key_1', 'value_1') is None


# Generated at 2022-06-25 14:08:16.346718
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Create a new instance of the 'FactCache' class
    fact_cache_0 = FactCache()

    # Call method first_order_merge with parameters
    # This method has no return value
    fact_cache_0.first_order_merge("The key", "The value")

test_case_0()
test_FactCache_first_order_merge()

# Generated at 2022-06-25 14:08:17.124341
# Unit test for constructor of class FactCache
def test_FactCache():
    factcache = FactCache()
    assert factcache != None


# Generated at 2022-06-25 14:08:30.636143
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        foo = FactCache()
    except KeyError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 14:08:32.247271
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()


# Generated at 2022-06-25 14:08:39.295919
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    fact_cache["penguin"] = "linux"
    fact_cache["bad_guy"] = "windows"
    fact_cache["dolphin"] = "mac"
    assert  'penguin' in fact_cache
    assert fact_cache['penguin'] == "linux"
    assert  'bad_guy' in fact_cache
    assert fact_cache['bad_guy'] == "windows"
    assert  'dolphin' in fact_cache
    assert fact_cache['dolphin'] == "mac"
    del fact_cache['dolphin']
    assert 'dolphin' not in fact_cache



# Generated at 2022-06-25 14:08:40.728252
# Unit test for constructor of class FactCache
def test_FactCache():
    # Test if the constructor can be invoked
    fact_cache_1 = FactCache()
    assert fact_cache_1 is not None



# Generated at 2022-06-25 14:08:43.513061
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact = 'foo'
    value = 'bar'
    fact_cache.first_order_merge(fact, value)
    assert fact_cache._plugin.get(fact) == value

# Generated at 2022-06-25 14:08:49.989397
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    key = u'my_host'
    value = {'foo': 123, 'bar': 456}
    fc.first_order_merge(key, value)
    assert fc[key] == {'foo': 123, 'bar': 456}
    value2 = {'foo': 789, 'baz': 876}
    fc.first_order_merge(key, value2)
    assert fc[key] == {'foo': 789, 'bar': 456, 'baz': 876}

# Generated at 2022-06-25 14:08:50.945081
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

# Generated at 2022-06-25 14:08:53.091293
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    # test variables
    assert fact_cache_0._plugin is None


# Generated at 2022-06-25 14:09:03.001702
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()

    fact_cache.first_order_merge('127.0.0.1', {'ansible_fact': 'value'})
    assert '127.0.0.1' in fact_cache
    assert 'ansible_fact' in fact_cache['127.0.0.1']

    # TODO:
    # Test result when '127.0.0.1' is already in fact cache
    # Test result when 'ansible_fact' is already in fact_cache['127.0.0.1']
    # Test result when 'ansible_fact' is already in fact_cache['127.0.0.1'] but fact_cache['127.0.0.1']['ansible_fact'] != 'value'

# Generated at 2022-06-25 14:09:09.187011
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    # Initialize test key and value
    key = 'dummy_key'
    value = {'key1': 'val1', 'key2': 'val2'}

    # Initialize test object and then add the key-value pair
    fact_cache = FactCache()
    fact_cache.first_order_merge(key, value)

    # Get the value for the key
    value_retrieved = fact_cache[key]

    # Assert
    assert value_retrieved == value
    assert value_retrieved == fact_cache[key]



# Generated at 2022-06-25 14:09:47.792364
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    assert fact_cache._plugin.cache == {}
    fact_cache.first_order_merge(key="localhost_0", value={"ansible_facts": {"discovered_interpreter_python": "/usr/bin/python"}})
    assert fact_cache._plugin.cache == {"localhost_0": {"ansible_facts": {"discovered_interpreter_python": "/usr/bin/python"}}}
    fact_cache.first_order_merge(key="localhost_0", value={"ansible_facts": {"discovered_interpreter_python": "/usr/bin/python2.7"}})
    assert fact_cache._plugin.cache == {"localhost_0": {"ansible_facts": {"discovered_interpreter_python": "/usr/bin/python2.7"}}}


# Generated at 2022-06-25 14:09:49.309073
# Unit test for constructor of class FactCache
def test_FactCache():
    f = FactCache()
    assert (isinstance(f, FactCache))



# Generated at 2022-06-25 14:09:51.957886
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert False
    else:
        assert True

if __name__ == '__main__':
    test_FactCache()

# Generated at 2022-06-25 14:09:53.210405
# Unit test for constructor of class FactCache
def test_FactCache():
    display.display(test_case_0.__doc__)
    test_case_0()


# Generated at 2022-06-25 14:09:54.925806
# Unit test for constructor of class FactCache
def test_FactCache():
    # Test for constructor of class FactCache
    f = FactCache()
    assert isinstance(f, FactCache)


# Generated at 2022-06-25 14:09:56.149507
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    fact_cache_1 = FactCache()

# Generated at 2022-06-25 14:09:58.344139
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0.flush() == None


# Generated at 2022-06-25 14:09:59.566750
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    print(fact_cache_0)

# Generated at 2022-06-25 14:10:00.418248
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()


# Generated at 2022-06-25 14:10:04.163129
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    display.display("testing constructor FactCache()", color='yellow')
    test_case_0()
    display.display("passed test_case_0()", color='green')


# Generated at 2022-06-25 14:11:16.601557
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    # print("Type of FactCache is:", type(fact_cache_0)) # prints: Type of FactCache is: <class '__main__.FactCache'>
    # print("Type of FactCache._plugin is:", type(fact_cache_0._plugin)) # prints: Type of FactCache._plugin is: <class 'ansible.plugins.cache.base.BaseCacheModule'>
    # print("Type of FactCache._plugin.keys() is:", type(fact_cache_0._plugin.keys())) # prints: Type of FactCache._plugin.keys() is: <class 'list'>
    # print("Type of FactCache.keys() is:", type(fact_cache_0.keys())) # prints: Type of FactCache.keys() is: <class 'list'>
    # print("Type of

# Generated at 2022-06-25 14:11:19.453059
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        test_case_0()
        display.display('test_case_0 passed')
    except (AnsibleError, KeyError) as e:
        display.display('test_case_0 failed: ' + str(e))
        exit(1)

if __name__ == '__main__':
    test_FactCache()

# Generated at 2022-06-25 14:11:26.023722
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()

    # test if fact cache is empty and does not contain the given key
    key = 'key_1'
    value = 'value_1'
    assert fact_cache_1._plugin.keys() == []
    assert fact_cache_1.__contains__(key) == False
    fact_cache_1.first_order_merge(key, value)
    # test if fact cache contains the given key and value
    assert fact_cache_1.__contains__(key) == True
    assert fact_cache_1.__getitem__(key) == 'value_1'

    # test if the given key and its updated value is copied to the fact cache
    key = 'key_2'
    value = 'value_2'
    fact_cache_1.first_order_merge

# Generated at 2022-06-25 14:11:33.285456
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    from ansible.module_utils.facts.collector import FactsCollector
    factcache = FactCache()
    facts = {"ansible_facts": {'fake_fact1': 'fake_value1'}}
    fc = FactsCollector()
    fc.populate_facts(from_cache=False, cache=factcache, connection='fake_connection', ansible_facts=facts)
    fc.gather_subset('all', factcache, connection='fake_connection')
    assert factcache['fake_connection'] == {'fake_fact1': 'fake_value1'}


# Generated at 2022-06-25 14:11:40.085302
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge('key', 'value')

    fact_cache_2 = FactCache()
    fact_cache_2.first_order_merge('key', 'value')

    assert fact_cache_1 == fact_cache_2

    fact_cache_3 = FactCache()
    fact_cache_3.first_order_merge('key', 'value')

    fact_cache_4 = FactCache()
    fact_cache_4.first_order_merge('key', 'value')

    assert fact_cache_3 == fact_cache_4

    fact_cache_5 = FactCache()
    fact_cache_5.first_order_merge('key', {'a': 'A', 'b': 'B'})

    fact_cache_

# Generated at 2022-06-25 14:11:43.329980
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert(fact_cache_0 != None)


# Generated at 2022-06-25 14:11:52.635026
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge("ansible_architecture", "x86_64")

# Generated at 2022-06-25 14:12:00.201603
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    # test getitem
    # key is not in fact cache
    try:
        fact_cache_0.__getitem__('key')
    except KeyError as err:
        print("Failed as expected KeyError: %s" % err)
    # key is in fact cache
    fact_cache_0.__setitem__('key', 1)
    print(fact_cache_0.__getitem__('key'))
    # Test setitem
    fact_cache_0.__setitem__('key', 2)
    # Test delitem
    fact_cache_0.__delitem__('key')
    # Test contains
    print(fact_cache_0.__contains__('key'))
    # Test iter
    print(fact_cache_0.__iter__())


# Generated at 2022-06-25 14:12:02.675191
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache=FactCache()
    var = "test"
    fact_cache[var] = "test"
    assert fact_cache[var]=="test"


# Generated at 2022-06-25 14:12:11.789582
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    # FactCache.first_order_merge(key='192.168.1.2', value={'ansible_facts': {'fqdn': 'centos7.example.com', 'ipv4': {'address': '192.168.1.2', 'netmask': '255.255.255.0', 'broadcast': '192.168.1.255'}, 'kernel': '3.10.0-327.el7.x86_64', 'processor': [{'flags': ['fpu', 'vme', 'de', 'pse', 'tsc', 'msr', 'pae', 'mce', 'cx8', 'apic', 'sep', 'mtrr', 'pge', 'mca', 'cmov', 'pat', 'pse36', 'clflush

# Generated at 2022-06-25 14:14:51.602094
# Unit test for constructor of class FactCache
def test_FactCache():
    FactCache()


# Generated at 2022-06-25 14:15:00.701974
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.plugins.cache import BaseFileCache
    from mock import patch
    from ansible.plugins.loader import cache_loader
    from ansible import constants as C
    
    # Test case 1: Basic test case
    #   test_case_0()
    fact_cache = fact_cache_0()
    fact_cache = fact_cache_0()

    # Test case 2: Test return type
    #   test_case_1()
    assert isinstance(fact_cache, FactCache)

    # Test case 3: Test behaviour of __contains__ method
    #   test_case_2()
    with patch.object(BaseFileCache, '__contains__', return_value=True):
        with patch.object(BaseFileCache, 'contains', return_value=True):
            assert fact_cache.__contains__

# Generated at 2022-06-25 14:15:01.930772
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert type(fact_cache_0) is FactCache


# Generated at 2022-06-25 14:15:07.125605
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()

    first_facts = {'val': 'old_val'}
    another_facts = {'val': 'new_val'}
    key = 'key'
    fact_cache.first_order_merge(key, first_facts)
    assert fact_cache[key] == first_facts

    fact_cache.first_order_merge(key, another_facts)
    assert fact_cache[key] == another_facts

if __name__ == "__main__":
    import sys
    test_FactCache_first_order_merge()
    sys.exit()

# Generated at 2022-06-25 14:15:08.672508
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert type(fact_cache_0.keys()) is list
    assert True



# Generated at 2022-06-25 14:15:09.404955
# Unit test for constructor of class FactCache
def test_FactCache():
    assert len(FactCache()) == 0


# Generated at 2022-06-25 14:15:11.630454
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_hostname', 'test_value')

    assert fact_cache['test_hostname'] == "test_value"


# Generated at 2022-06-25 14:15:16.750525
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_2 = FactCache()
    fact_cache_1.first_order_merge('test_key', 'test_value')
    assert fact_cache_1['test_key'] == 'test_value'
    fact_cache_2.first_order_merge('test_key', 'test_value')
    assert fact_cache_2['test_key'] == 'test_value'


if __name__ == '__main__':
    test_case_0()
    test_FactCache_first_order_merge()