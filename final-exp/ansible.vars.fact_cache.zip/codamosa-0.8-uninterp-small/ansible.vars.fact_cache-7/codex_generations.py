

# Generated at 2022-06-25 14:05:27.570263
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    host_facts_0 = dict()
    assert fact_cache_0.keys() == list()
    fact_cache_0.first_order_merge("key_0", host_facts_0)
    assert fact_cache_0.keys() == list(['key_0'])


# Generated at 2022-06-25 14:05:30.512720
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_object = FactCache()
    fact_cache_object.first_order_merge('test_key', 'test_value')
    assert 'test_key' in fact_cache_object

# Generated at 2022-06-25 14:05:41.219784
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()

# Generated at 2022-06-25 14:05:44.570396
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    # Test with 0 arguments
    fact_cache_0 = FactCache()
    # Test with 1 argument
    fact_cache_1 = FactCache([])
    # Test with 2 arguments
    fact_cache_2 = FactCache([], [])


# Generated at 2022-06-25 14:05:50.013281
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge('host', {'a': 1})
    fact_cache_1.first_order_merge('host', {'b': 2})
    fact_cache_1.first_order_merge('host', {'c': 3})
    assert fact_cache_1 == {'host': {'a': 1, 'b': 2, 'c': 3}}

# Generated at 2022-06-25 14:06:01.349468
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge("foo", "bar")
    assert len(fact_cache) == 1
    assert fact_cache["foo"] == "bar"
    fact_cache.first_order_merge("foo", "bar2")
    assert len(fact_cache) == 1
    assert fact_cache["foo"] == "bar2"
    fact_cache.first_order_merge("foo", ["bar", "baz"])
    assert len(fact_cache) == 1
    assert fact_cache["foo"] == ["bar", "baz"]
    fact_cache.first_order_merge("foo", {"bar": "baz"})
    assert len(fact_cache) == 1
    assert fact_cache["foo"] == {"bar": "baz"}
    fact

# Generated at 2022-06-25 14:06:03.697506
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    # Testing declare instance variables
    assert hasattr(fact_cache_0, '_plugin')


# Generated at 2022-06-25 14:06:12.723184
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0.copy() == {}, "The method copy() of class FactCache failed"
    assert fact_cache_0.keys() == [], "The method keys() of class FactCache failed"
    fact_cache_0.flush()
    fact_cache_0.__setitem__("test_0", "test_1")
    fact_cache_0.__setitem__("test_1", "test_2")
    assert fact_cache_0.keys() == ["test_0", "test_1"], "The method keys() of class FactCache failed"
    assert fact_cache_0.__getitem__("test_1") == "test_2", "The method __getitem__(my_key) of class FactCache failed"
    assert fact_cache_0.copy

# Generated at 2022-06-25 14:06:22.608078
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    data = {}
    cache = FactCache()
    # Testing if an exception is raised for invalid (empty key) parameter
    try:
        cache.first_order_merge('', data)
    except Exception as exception:
        if str(exception) != 'Empty data key passed to first_order_merge':
            print('Empty data key passed to first_order_merge')
            return

    # Testing if an exception is raised for invalid (empty data) parameter
    try:
        cache.first_order_merge('key', data)
    except Exception as exception:
        if str(exception) != 'Empty data passed to first_order_merge':
            print('Empty data passed to first_order_merge')
            return

    data['key_foo'] = 'value_foo'

# Generated at 2022-06-25 14:06:32.414428
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    from ansible.plugins.loader import cache_loader
    from ansible.utils.display import Display; display = Display()
    z = FactCache()

    z.first_order_merge('testhost', {'ansible_facts': {}})
    z._plugin.set('testhost', {'test': 'foo'})
    z.first_order_merge('testhost', {'test': 'bar'})
    assert z._plugin.get('testhost').get('test') == 'bar'
    assert z._plugin.contains('testhost')
    z._plugin.delete('testhost')
    assert not z._plugin.contains('testhost')
    display.warning('test_FactCache_first_order_merge() passed')
    return True


if __name__ == '__main__':
    test_Fact

# Generated at 2022-06-25 14:06:40.394824
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge('test_host.example.com',
                                   {'hostname': 'test_host.example.com'})
    assert fact_cache_1['test_host.example.com']['hostname'] == 'test_host.example.com'


# Generated at 2022-06-25 14:06:41.758044
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0._plugin.__class__.__name__ == 'MemoryCacheModule'

# Generated at 2022-06-25 14:06:42.859263
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)


# Generated at 2022-06-25 14:06:44.805911
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0._plugin.flush() == True
    assert fact_cache_0._plugin.get("key") == None
    assert fact_cache_0._plugin.set("key", "value") == True

# Generated at 2022-06-25 14:06:45.764343
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()


# Generated at 2022-06-25 14:06:47.056855
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    #assert fact_cache_0.first_order_merge() == "foo!"
    pass

# Generated at 2022-06-25 14:06:51.204383
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    fact_cache_1 = FactCache()
    assert fact_cache_0 == fact_cache_1


# Generated at 2022-06-25 14:06:52.786583
# Unit test for constructor of class FactCache
def test_FactCache():
    assert test_case_0() == None


# Generated at 2022-06-25 14:07:01.858438
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    hostname = ['localhost']
    new = {'ansible_facts': {'xyz': '123', '123': 'xyz'}}
    new2 = {'ansible_facts': {'abc': 'def'}}

    facts_0 = {hostname[0]: new}
    fact_cache_0 = FactCache(facts_0)
    fact_cache_0.first_order_merge(hostname[0], new2)
    assert fact_cache_0 == {'localhost': {'ansible_facts': {'xyz': '123', '123': 'xyz', 'abc': 'def'}}}


if __name__ == '__main__':
    test_FactCache_first_order_merge()

# Generated at 2022-06-25 14:07:09.706357
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    host_facts_0 = dict()
    host_facts_0['test_key'] = 'test_value'
    host_cache_0 = dict()

    host_cache_0['test_key'] = host_facts_0['test_key']
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge('test_key', 'test_value')
    assert fact_cache_0['test_key'] == host_cache_0


if __name__ == '__main__':
    # Unit tests for FactCache class
    test_case_0()
    test_FactCache_first_order_merge()

# Generated at 2022-06-25 14:07:15.072844
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)


# Generated at 2022-06-25 14:07:16.877039
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert isinstance(fact_cache_0, FactCache)


# Generated at 2022-06-25 14:07:25.563116
# Unit test for constructor of class FactCache
def test_FactCache():

    fact_cache_0 = FactCache()
    assert fact_cache_0._plugin.cache_type == 'memory'

    # test __getitem__
    fact_cache_0['key_0'] = 'value_0'
    assert fact_cache_0['key_0'] == 'value_0'

    # test __contains__
    assert 'key_0' in fact_cache_0
    assert 'key_1' not in fact_cache_0

    # test __len__
    assert len(fact_cache_0) == 1

    # test __delitem__
    del fact_cache_0['key_0']
    assert len(fact_cache_0) == 0

    # test keys
    fact_cache_0['key_0'] = 'value_0'
    fact_cache_0['key_1']

# Generated at 2022-06-25 14:07:27.712332
# Unit test for constructor of class FactCache
def test_FactCache():
	fact_cache = FactCache()
	assert 1==1



# Generated at 2022-06-25 14:07:37.619375
# Unit test for constructor of class FactCache
def test_FactCache():

    # Check for if the object is instantiated correctly
    def test_instance():
        fact_cache_0 = FactCache()
        assert isinstance(fact_cache_0, FactCache)


    # Check for adding and retrieving the data
    def test_setitem():
        fact_cache_1 = FactCache()
        fact_cache_1['host_name'] = {'foo': 'bar'}
        assert fact_cache_1['host_name'] == {'foo': 'bar'}

    # Check for if the methods are overridden correctly

# Generated at 2022-06-25 14:07:41.694893
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_3 = FactCache()
    fact_cache_3.first_order_merge("test", {'test_facts': 'test'})
    assert fact_cache_3._plugin.get("test") == {'test_facts': 'test'}


# Generated at 2022-06-25 14:07:49.425413
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge('foo','bar')
    assert fact_cache_0.copy() == {'foo':'bar'}
    fact_cache_0.first_order_merge('foo','baz')
    assert fact_cache_0.copy() == {'foo':{'bar':'bar', 'baz':'baz'}}
    fact_cache_0.first_order_merge('foo','baz')
    assert fact_cache_0.copy() == {'foo':{'bar':'bar', 'baz':'baz'}}
    fact_cache_0.first_order_merge('foo','baz')

# Generated at 2022-06-25 14:07:51.631815
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge("key0", "value0")


# Generated at 2022-06-25 14:07:58.243055
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0._plugin == 'memory'

# Generated at 2022-06-25 14:08:07.584132
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    f=FactCache()
    test_merge_host1 = { "ansible_host": "10.10.10.10" }
    f.first_order_merge('test_host1', test_merge_host1)

    test_merge_host2 = { "ansible_host": "192.168.x.x" }
    f.first_order_merge('test_host2', test_merge_host2)

    assert f.keys() == ['test_host1', 'test_host2']
    assert f.get('test_host1') == { "ansible_host": "10.10.10.10" }
    assert f.get('test_host2') == { "ansible_host": "192.168.x.x" }



# Generated at 2022-06-25 14:08:11.864309
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()


# Generated at 2022-06-25 14:08:18.608640
# Unit test for constructor of class FactCache
def test_FactCache():
    print("\nTesting normal conditions:")
    print("\nCreating object of FactCache:")
    fc = FactCache()
    print("\nDisplaying object of FactCache:")
    print (fc)
    print("\nTesting constructor with keyword arguments:")
    fact_cache_0 = FactCache(hosts=['host0', 'host1', 'host2'],
                             port=100,
                             ip='127.0.0.1',
                             db=0)
    print("\nDisplaying object of FactCache:")
    print (fact_cache_0)


# Generated at 2022-06-25 14:08:30.097759
# Unit test for constructor of class FactCache
def test_FactCache():

    fact_cache_1 = FactCache()

    # test for the constructor
    assert isinstance(fact_cache_1, FactCache)

    # test for the save method
    assert callable(fact_cache_1.copy)
    assert callable(fact_cache_1.flush)
    assert callable(fact_cache_1.first_order_merge)
    assert callable(fact_cache_1.__delitem__)
    assert callable(fact_cache_1.__getitem__)
    assert callable(fact_cache_1.__setitem__)
    assert callable(fact_cache_1.__len__)
    assert callable(fact_cache_1.__iter__)
    assert callable(fact_cache_1.__contains__)

# Generated at 2022-06-25 14:08:31.690828
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    FactCache.first_order_merge()

# Generated at 2022-06-25 14:08:35.955875
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_2 = FactCache('key', 'value')

    fact_cache_1.first_order_merge('127.0.0.1', 'value')
    fact_cache_2.first_order_merge('127.0.0.1', 'value')


# Generated at 2022-06-25 14:08:36.922615
# Unit test for constructor of class FactCache
def test_FactCache():
    c = FactCache()
    assert c != None, 'constructor of class FactCache failed'


# Generated at 2022-06-25 14:08:37.894628
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert 1 == len(fact_cache_0)


# Generated at 2022-06-25 14:08:45.407392
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    f = FactCache()
    f.first_order_merge('localhost', {'key': 'value'})
    assert f.get('localhost').get('key') == 'value'

    f.first_order_merge('localhost', {'key1': 'value1'})
    assert f.get('localhost').get('key') == 'value'
    assert f.get('localhost').get('key1') == 'value1'

    f.first_order_merge('localhost', {'key': 'another_value'})
    assert f.get('localhost').get('key') == 'another_value'
    assert f.get('localhost').get('key1') == 'value1'

    f.first_order_merge('localhost', {'key': 'another_value'})

# Generated at 2022-06-25 14:08:46.921620
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)


# Generated at 2022-06-25 14:08:48.918658
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)


# Generated at 2022-06-25 14:09:06.584997
# Unit test for method first_order_merge of class FactCache

# Generated at 2022-06-25 14:09:08.695460
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0.__init__ is not None, "__init__ method of class FactCache not found"


# Generated at 2022-06-25 14:09:10.394078
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        import pytest
        pytest.fail('CachePluginError not raised')
    except AnsibleError:
        pass


# Generated at 2022-06-25 14:09:11.740624
# Unit test for constructor of class FactCache
def test_FactCache():
    cache_constructor_0 = FactCache()


# Generated at 2022-06-25 14:09:14.760668
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    key = 'hostvars'
    value = {}
    fact_cache_0.first_order_merge(key, value)


# Generated at 2022-06-25 14:09:25.637033
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.flush()

# Generated at 2022-06-25 14:09:27.595410
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    _fact_cache = FactCache()
    _key = None
    _value = None
    fact_cache = _fact_cache.first_order_merge(key=_key, value=_value)



# Generated at 2022-06-25 14:09:28.008295
# Unit test for constructor of class FactCache
def test_FactCache():
    assert FactCache()

# Generated at 2022-06-25 14:09:29.654335
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()


# Generated at 2022-06-25 14:09:30.499444
# Unit test for constructor of class FactCache
def test_FactCache():
    assert test_case_0() == None

# Generated at 2022-06-25 14:09:46.975962
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    fact_cache_1 = FactCache()
    assert fact_cache_0 != fact_cache_1


# Generated at 2022-06-25 14:09:47.877775
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

# Generated at 2022-06-25 14:09:53.469791
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # host_name = 'ubuntu16.04'
    # key = 'key1'
    # value = 'value1'
    # host_facts = {key: value}
    #
    # host_cache = {'key2': 'value2'}
    # host_facts1 = fact_cache_0.first_order_merge(host_name, host_cache)
    # host_facts2 = fact_cache_0.first_order_merge(host_name, host_facts)
    #
    # assert host_facts1 == host_facts2
    pass


# Generated at 2022-06-25 14:09:55.483551
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)
    assert isinstance(fact_cache, MutableMapping)



# Generated at 2022-06-25 14:10:05.414847
# Unit test for constructor of class FactCache
def test_FactCache():
    print("Test FactCache")
    fact_cache_0 = FactCache()

    # adding key(test_key_0)
    fact_cache_0['test_key_0'] = 'test_value_0_0'
    print ('test_key_0: %s' % fact_cache_0['test_key_0'])

    # adding key(test_key_1)
    fact_cache_0['test_key_1'] = 'test_value_1_0'
    print ('test_key_1: %s' % fact_cache_0['test_key_1'])

    # adding key(test_key_2)
    fact_cache_0['test_key_2'] = 'test_value_2_0'

# Generated at 2022-06-25 14:10:07.120383
# Unit test for constructor of class FactCache
def test_FactCache():
    print('Test: Constructor of class FactCache')
    test_case_0()


# Generated at 2022-06-25 14:10:09.278198
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        result = not(FactCache)
    except Exception as e:
        if (e == "__init__() missing 1 required positional argument: 'self'") or (e == "'FactCache' object is not callable"):
            assert True
        else:
            assert False


# Generated at 2022-06-25 14:10:18.948477
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge("", "")
    assert fact_cache_0.size() == 1

    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge("key1", "value1")
    fact_cache_1.first_order_merge("key2", "value2")
    fact_cache_1.first_order_merge("key3", "value3")
    fact_cache_1.first_order_merge("key4", "value4")
    assert fact_cache_1.size() == 4

    fact_cache_2 = FactCache()
    fact_cache_2.first_order_merge("key1", "value1")
    fact_cache_2.first_order_mer

# Generated at 2022-06-25 14:10:29.102526
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Test each of the known fact cache plugins
    plugins = cache_loader.all(class_only=True)
    for plugin in plugins:
        fact_cache = FactCache()
        key = 'test_host'
        value_a = {'key_a': 'value_a'}
        value_b = {'key_b': 'value_b'}

        fact_cache.first_order_merge(key, value_a)
        if not fact_cache._plugin.contains(key):
            raise Exception(
                'Plugin (%s) should have fact (%s)' % (plugin, key))
        fact = fact_cache._plugin.get(key)

# Generated at 2022-06-25 14:10:32.885699
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    assert fact_cache_1.first_order_merge == FactCache.first_order_merge
    fact_cache_1.first_order_merge('the_key', {'the_key': 'the_value'})
    assert fact_cache_1['the_key'] == {'the_key': 'the_value'}


# Generated at 2022-06-25 14:11:06.887724
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)


# Generated at 2022-06-25 14:11:08.974017
# Unit test for constructor of class FactCache
def test_FactCache():
    print(test_case_0())

test_FactCache()

# Generated at 2022-06-25 14:11:16.073062
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Setup a test_FactCache object as fact_cache_0
    test_case_0()

    # Setup a test dictionary object as dict_0
    dict_0 = {'foo': 'bar', 'baz': 'rab'}

    # Setup a test dictionary object as dict_1
    dict_1 = {'foo': 'bar'}

    # Store the value of dict_0 in the fact cache with key dict_1
    fact_cache_0.first_order_merge(dict_1, dict_0)

    # Assert that the value of key dict_1 in the fact cache equals dict_0
    assert dict_0 == fact_cache_0[dict_1]

# Generated at 2022-06-25 14:11:18.348775
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        print("[FAILED] Test case 0")
        return -1

    print("[SUCCESS] Test passed")
    return 0

test_FactCache()

# Generated at 2022-06-25 14:11:19.693964
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    #assert_equal(fact_cache_0.__init__(), None)

# Generated at 2022-06-25 14:11:22.158426
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0._plugin == cache_loader.get(C.CACHE_PLUGIN)



# Generated at 2022-06-25 14:11:31.350680
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    facts = {'local': {}, 'global': {'key': 'value'}, 'local_and_global': {'key': 'value'}}
    key = 'hostname'
    fact_cache = FactCache()
    fact_cache.first_order_merge(key, facts)
    assert fact_cache[key]['global'] == {}
    assert fact_cache[key]['local'] == {}
    assert fact_cache[key]['local_and_global'] == {'key': 'value'}

    facts = {'local': {}, 'global': {'key': 'new_value'}, 'local_and_global': {'key': 'new_value'}}
    fact_cache.first_order_merge(key, facts)
    assert fact_cache[key]['global'] == {}
    assert fact_cache

# Generated at 2022-06-25 14:11:33.165275
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache.keys() == []


# Generated at 2022-06-25 14:11:38.706020
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    c = FactCache()
    c.first_order_merge("test_host", {"data": {"test": "value"}})
    assert c["test_host"]["data"]["test"] == "value"

    c.first_order_merge("test_host", {"data": {"test2": "value2"}})
    assert c["test_host"]["data"]["test"] == "value"
    assert c["test_host"]["data"]["test2"] == "value2"


# Generated at 2022-06-25 14:11:39.580001
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()



# Generated at 2022-06-25 14:12:52.661383
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache.copy() == {}
    assert fact_cache.keys() == None
    assert fact_cache.flush() == None
    fact_cache['foo'] = 'bar'
    fact_cache['baz'] = 42
    fact_cache.flush()
    fact_cache.flush()
    fact_cache.flush()
    fact_cache.flush()
    fact_cache.flush()
    fact_cache.flush()
    fact_cache.flush()
    fact_cache.flush()
    fact_cache.flush()
    fact_cache.flush()
    fact_cache.flush()
    fact_cache.flush()
    fact_cache.flush()

if __name__ == "__main__":
    fact_cache = FactCache()

# Generated at 2022-06-25 14:12:54.060444
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    if fact_cache_0 != {}:
        raise RuntimeError("FactCache() != {}")


# Generated at 2022-06-25 14:12:56.142821
# Unit test for constructor of class FactCache
def test_FactCache():
    display.info(">>> Start test for FactCache.__init__")
    test_case_0()

test_FactCache()

# Generated at 2022-06-25 14:13:04.116064
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0.__init__()
    fact_cache_1 = FactCache()
    assert fact_cache_1.__init__()
    fact_cache_2 = FactCache()
    assert fact_cache_2.__init__()
    fact_cache_3 = FactCache()
    assert fact_cache_3.__init__()
    fact_cache_4 = FactCache()
    assert fact_cache_4.__init__()
    fact_cache_5 = FactCache()
    assert fact_cache_5.__init__()
    fact_cache_6 = FactCache()
    assert fact_cache_6.__init__()
    fact_cache_7 = FactCache()
    assert fact_cache_7.__init__()


# Generated at 2022-06-25 14:13:08.443607
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    """Unit test for method first_order_merge of class FactCache"""
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge('a', {'1': '2'})
    fact_cache_0.first_order_merge('a', {'3': '4'})
    assert fact_cache_0.copy() == {'a': {'1': '2', '3': '4'}}


# Generated at 2022-06-25 14:13:12.279060
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0=FactCache()
    key='key'
    value='value'
    fact_cache_0.first_order_merge(key,value)



# Generated at 2022-06-25 14:13:13.505648
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    print(fact_cache)



# Generated at 2022-06-25 14:13:21.250576
# Unit test for constructor of class FactCache
def test_FactCache():
    # Create an instance of FactCache
    fact_cache = FactCache()

    # Check if it is a MutableMapping
    assert(isinstance(fact_cache, MutableMapping))

    # Check if it has no keys
    assert(len(fact_cache) == 0)

    # Check if the error KeyError is raised when fact_cache does not contain the key
    try:
        fact_cache['test']
        assert(False)
    except KeyError:
        pass

    # Check if fact_cache contains the key
    fact_cache['test'] = 'value'
    assert('test' in fact_cache)

    # Check if the value is exactly the one we added
    assert(fact_cache['test'] == 'value')

    # Check if the length is same as number of keys added

# Generated at 2022-06-25 14:13:23.166467
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    assert fact_cache_0.first_order_merge(key="key-value", value="key-value") == None


# Generated at 2022-06-25 14:13:24.393558
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

if __name__ == "__main__":
    test_FactCache()