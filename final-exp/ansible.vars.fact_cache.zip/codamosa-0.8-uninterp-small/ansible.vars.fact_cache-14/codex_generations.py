

# Generated at 2022-06-25 14:05:25.411093
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    # Test case 0
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge(
        "test_hostname_0", {
            "ansible_facts": {
                "test_fact_0": "test_value_0",
                "test_fact_1": "test_value_1"
            }
        }
    )


# Generated at 2022-06-25 14:05:27.075049
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    if not fact_cache:
        raise AssertionError("__init__ returns None")


# Generated at 2022-06-25 14:05:28.531775
# Unit test for constructor of class FactCache
def test_FactCache():
    global fact_cache_1
    fact_cache_1 = FactCache()


# Generated at 2022-06-25 14:05:30.430298
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_object = FactCache()
    assert fact_cache_object is not None


# Generated at 2022-06-25 14:05:38.795858
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    host_facts=['a.1','a.2','a.3']
    key='test_case'
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge(key, host_facts)
    assert fact_cache_0.__contains__(key) is True, "first_order_merge failed to insert new item"
    fact_cache_0.first_order_merge(key, host_facts)
    assert fact_cache_0.__contains__(key) is True, "first_order_merge failed to update existing item"

# Generated at 2022-06-25 14:05:40.606726
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        test_case_0()
    except Exception as e:
        print(e)

# Generated at 2022-06-25 14:05:46.348678
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    # initialize fact cache using 'first_order_merge' method of FactCache
    fact_cache.first_order_merge('key', {'name': 'split'})
    fact_cache.first_order_merge('key', {'name': 'split'})
    fact_cache.first_order_merge('key', {'name': 'split'})

if __name__ == '__main__':
    import doctest

    doctest.testmod()
    test_FactCache_first_order_merge()

# Generated at 2022-06-25 14:05:48.029628
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None


# Generated at 2022-06-25 14:05:49.462595
# Unit test for constructor of class FactCache
def test_FactCache():
    assert(isinstance(FactCache(), FactCache))



# Generated at 2022-06-25 14:05:52.455804
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert_equals(fact_cache._plugin, cache_loader.get(C.CACHE_PLUGIN))


# Generated at 2022-06-25 14:06:04.209151
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    key = "localhost"
    value = {"ansible_lsb": {"distrib_id": "",
                             "distrib_release": "",
                             "distrib_codename": "",
                             "distrib_description": ""},
             "ansible_distribution": "RedHat",
             "ansible_distribution_version": "7.1",
             "ansible_processor_cores": 4,
             "ansible_architecture": "x86_64",
             "ansible_virtualization_role": "guest",
             "ansible_virtualization_type": "KVM"}
    fact_cache_0.first_order_merge(key, value)
    assert isinstance(fact_cache_0, FactCache)


# Generated at 2022-06-25 14:06:13.106134
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    test_host_fact = {'host_fact': 'test_host_fact'}
    test_host_fact_cache = {'host_fact': 'test_host_fact', 'host_fact_cache': 'test_host_fact_cache'}

    test_case_0()
    test_cache = FactCache()
    test_cache.first_order_merge('test_key', test_host_fact)

    assert test_cache['test_key'] == test_host_fact
    assert len(test_cache) == 1
    assert len(test_cache.keys()) == 1

    test_cache.first_order_merge('test_key', test_host_fact)
    assert test_cache['test_key'] == test_host_fact
    assert len(test_cache) == 1

# Generated at 2022-06-25 14:06:20.191223
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    key = "test_key"
    value = "test_value"
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge(key, value)
    assert fact_cache_1[key] == "test_value"

    # Test if update fails when value is not dict
    value = "test_value_"
    fact_cache_1.first_order_merge(key, value)
    assert fact_cache_1[key] == "test_value"

# Generated at 2022-06-25 14:06:24.960167
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()
    fact_cache_1["192.168.33.10"] = dict(a=1, b=2)
    assert fact_cache_1["192.168.33.10"] == dict(a=1, b=2)

# Generated at 2022-06-25 14:06:27.717103
# Unit test for constructor of class FactCache
def test_FactCache():
    result = test_case_0()
    assert result == None
    print("Result1: test_case_0 is passed")
    print("Result2: test_FactCache is passed")


# Generated at 2022-06-25 14:06:31.461723
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge('host1', {'random_fact': 'hello'})
    assert fact_cache_1['host1'] == {'random_fact': 'hello'}


# Generated at 2022-06-25 14:06:33.045812
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin != None


# Generated at 2022-06-25 14:06:33.928715
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()



# Generated at 2022-06-25 14:06:36.135017
# Unit test for constructor of class FactCache
def test_FactCache():

    fc = FactCache()
    assert fc._plugin.name == "JSONFile"  # default

    fc = FactCache(plugin="Memory")
    assert fc._plugin.name == "Memory"

    fc = FactCache(plugin="Dict")
    assert fc._plugin.name == "Dict"



# Generated at 2022-06-25 14:06:44.959180
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
  fact_cache_0 = FactCache()
  value_0 = {'gid': '2753', 'group': 'test', 'groups': 'test adm dialout cdrom sudo audio dip plugdev lpadmin netdev bluetooth vboxusers fuse'}
  key_0 = '127.0.0.1'
  fact_cache_0.first_order_merge(key_0, value_0)

  assert fact_cache_0['127.0.0.1']['groups'].split() == ['test', 'adm', 'dialout', 'cdrom', 'sudo', 'audio', 'dip', 'plugdev', 'lpadmin', 'netdev', 'bluetooth', 'vboxusers', 'fuse']
  assert fact_cache_0['127.0.0.1']['group'] == 'test'

# Generated at 2022-06-25 14:06:57.049893
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    facts_0 = {
        "ansible_facts": {
            "some_fact": "value",
            "some_other_fact": "value"
        }
    }
    expected_facts_0 = {
        "hostvars": {
            "localhost": {
                "some_fact": "value",
                "some_other_fact": "value"
            }
        }
    }

    fact_cache.first_order_merge("localhost", facts_0)
    assert fact_cache == expected_facts_0


# Generated at 2022-06-25 14:07:04.856097
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible import constants as C
    from ansible.errors import AnsibleError
    from ansible.plugins.loader import cache_loader
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.utils.display import Display


    display = Display()


    class FactCache(MutableMapping):

        def __init__(self, *args, **kwargs):

            self._plugin = cache_loader.get(C.CACHE_PLUGIN)
            if not self._plugin:
                raise AnsibleError('Unable to load the facts cache plugin (%s).' % (C.CACHE_PLUGIN))

            super(FactCache, self).__init__(*args, **kwargs)


# Generated at 2022-06-25 14:07:17.080710
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()

# Generated at 2022-06-25 14:07:19.305687
# Unit test for constructor of class FactCache
def test_FactCache():
    test = FactCache()
    assert test._plugin.__class__.__name__ == 'MemoryCacheModule'


# Generated at 2022-06-25 14:07:20.612030
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()

# Generated at 2022-06-25 14:07:23.542521
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()
    assert fact_cache_1._plugin.cache_plugin_name == 'memory'
    assert fact_cache_1._plugin.cache_plugin_path == 'ansible.plugins.cache.memory'



# Generated at 2022-06-25 14:07:25.029746
# Unit test for constructor of class FactCache
def test_FactCache():
    # assert that the constructor creates an instance of the class
    assert isinstance(FactCache(), FactCache)



# Generated at 2022-06-25 14:07:28.898951
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()

    fact_cache.flush()
    # test_case_0()


if __name__ == "__main__":
    test_FactCache()

# Generated at 2022-06-25 14:07:35.063253
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge('key_0', 'value_0')
    # Test assertion for if host_cache is set and present in cache
    try:
        if fact_cache_0.__getitem__('key_0'):
            fact_cache_0.update({'key_0': 'value_0'})
    except KeyError:
        display.error(' KeyError exception raised as expected')


# Generated at 2022-06-25 14:07:39.451885
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    key = 'key'
    value = 'value'
    fact_cache.first_order_merge(key, value)
    assert key in fact_cache.keys()
    assert fact_cache[key] == value


if __name__ == '__main__':
    test_FactCache_first_order_merge()

# Generated at 2022-06-25 14:07:51.421418
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    """
        fact_cache.first_order_merge(key, value)

        This method merges two dictionaries, except that where keys appear in both
        dictionaries, the values from the latter take precedence.

        Parameters:
            * key
                The key for the first order merge.
            * value
                The value for the first order merge.

        Returns:
            This method does *NOT* return anything.
    """

    fact_cache = FactCache()
    host_facts = {'test1': {'a': 100, 'b': 200}}
    fact_cache.first_order_merge('test1', {'b': 500, 'c': 400})
    fact_cache.update(host_facts)

# Generated at 2022-06-25 14:07:52.930408
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0 != None



# Generated at 2022-06-25 14:07:57.108403
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    host_facts = {'localhost': {'c': 'd', 'a': 'b'}}
    fc.first_order_merge('localhost', host_facts['localhost'])
    assert fc == host_facts

# Generated at 2022-06-25 14:07:59.812245
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge("test_host", {"fact_key_1": "value_1"})


# Generated at 2022-06-25 14:08:08.260977
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    print('Testing first_order_merge')
    f = FactCache()
    f.first_order_merge("host1", "value1")
    assert f["host1"] == "value1"
    f.first_order_merge("host2", "value2")
    assert f["host2"] == "value2"
    f.first_order_merge("host1", "value11")
    assert f["host1"] == "value11"
    f.first_order_merge("host1", "value1")
    assert f["host1"] == "value1"
    f.first_order_merge("host3", "value3")
    assert f["host3"] == "value3"


# Generated at 2022-06-25 14:08:12.248038
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    fact_cache.__init__()
    assert(fact_cache._plugin == cache_loader.get(C.CACHE_PLUGIN))


# Generated at 2022-06-25 14:08:13.622547
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc is not None


# Generated at 2022-06-25 14:08:15.217328
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()
    assert len(fact_cache_1) == 0


# Generated at 2022-06-25 14:08:17.765009
# Unit test for constructor of class FactCache
def test_FactCache():
    display.display("starting test_FactCache()")
    test_case_0()
    display.display("completed test_FactCache()")

if __name__ == "__main__":
    test_FactCache()

# Generated at 2022-06-25 14:08:29.074444
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Create the object
    fact_cache_0 = FactCache()
    fact_cache_0.flush()
    # Add a new key "test_key" with value "test_value"
    fact_cache_0.first_order_merge("test_key", "test_value")
    # Get the value of the added key
    assert fact_cache_0.get("test_key") == "test_value"
    # Update the value of the added key
    fact_cache_0.update({"test_key": "test_value_1"})
    # Get the value of the updated key
    assert fact_cache_0.get("test_key") == "test_value_1"
    # Delete the added key
    del fact_cache_0["test_key"]
    # Verifying the deletion of the key

# Generated at 2022-06-25 14:08:44.349781
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    host_facts = {}
    fact_cache = FactCache()
    fact_cache.first_order_merge(host_facts, 'test', 'value')
    assert host_facts['test'] == 'value'

# Generated at 2022-06-25 14:08:45.723436
# Unit test for constructor of class FactCache
def test_FactCache():
    # Test 1.1: All items are present
    test_case_0()

# unit tests for both get and contains method

# Generated at 2022-06-25 14:08:50.276423
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible import constants as C
    from ansible.plugins.loader import cache_loader
    from ansible.utils.display import Display
    import ansible.errors
    try:
        fact_cache = FactCache()
    except:
        pass
    assert True


# Generated at 2022-06-25 14:08:53.172251
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)
    assert fact_cache._plugin == cache_loader.get(C.CACHE_PLUGIN)


# Generated at 2022-06-25 14:08:55.563603
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        test_case_0()
    except:
        display.error("Failed to test class FactCache")
        raise
    else:
        display.display("Tested class FactCache")

# Generated at 2022-06-25 14:08:58.839516
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None
    assert isinstance(fact_cache, FactCache)
    if __name__ == '__main__':
        test_case_0()

# Generated at 2022-06-25 14:09:02.802427
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert not fact_cache.keys()
    assert not fact_cache
    assert len(fact_cache) == 0
    assert not fact_cache.copy()


# Generated at 2022-06-25 14:09:06.284797
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    fact_cache["test"] = {1, 2, 4}
    assert fact_cache is not None
    assert fact_cache["test"] is not None
    assert fact_cache["test"] == {1, 2, 4}


# Generated at 2022-06-25 14:09:12.322582
# Unit test for constructor of class FactCache
def test_FactCache():

    fact_cache_0 = FactCache()
    fact_cache_1 = FactCache()
    assert fact_cache_0 == fact_cache_1
    fact_cache_0.flush()
    assert fact_cache_0 == fact_cache_1
    fact_cache_0['test_key'] = 'test_value'
    assert fact_cache_0 != fact_cache_1
    fact_cache_1['test_key'] = 'test_value'
    assert fact_cache_0 == fact_cache_1
    fact_cache_1['test_key'] = 'test_value2'
    assert fact_cache_0 != fact_cache_1
    fact_cache_1.flush()
    assert fact_cache_0 != fact_cache_1


# Generated at 2022-06-25 14:09:13.958469
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None


# Generated at 2022-06-25 14:09:42.426491
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None


# Generated at 2022-06-25 14:09:51.298551
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge("test/test1", "test_value1")
    fact_cache.first_order_merge("test/test2", "test_value2")
    # test for set operation
    assert fact_cache["test/test1"] == "test_value1"
    assert fact_cache["test/test2"] == "test_value2"
    # test for dictionary
    fact_cache._plugin.get("test/test1").update({"test_key1": "test_value1"})
    assert fact_cache["test/test1"]["test_key1"] == "test_value1"

    # test for set operation again
    fact_cache.first_order_merge("test/test1", "test_value3")
    assert fact

# Generated at 2022-06-25 14:09:54.816115
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        assert FactCache
    except NameError:
        sys.exit(1)
    else:
        sys.exit(0)

try:
    if __name__ == '__main__':
        test_FactCache()
except NameError:
    sys.exit(1)
except SystemExit:
    sys.exit(0)

# Generated at 2022-06-25 14:09:56.923775
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    fact_cache.__contains__('')
    fact_cache.__delitem__('')
    assert fact_cache.__getitem__('') == None

# Generated at 2022-06-25 14:10:07.279323
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Given
    fact_cache_0 = FactCache()

    key0 = "ansible_facts"

    value0 = {
        "fact_cache": {
            "fact_no": 0,
            "fact_text": "Fantastic fact"
        },
        "other": {
            "fact_no": 1,
            "fact_text": "Fabulous fact"
        }
    }

    fact_cache_0 = FactCache()

    fact_cache_0.first_order_merge(key0, value0)

    # Then
    assert fact_cache_0[key0] == value0


# Generated at 2022-06-25 14:10:13.406982
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    fact_cache_1 = FactCache()

    # Test case 1
    fact_cache_0['test_0'] = 'test'
    fact_cache_0.flush()

    # Test case 2
    fact_cache_0['test_1'] = 'test'
    fact_cache_0.flush()
    fact_cache_0.copy()

    # Test case 3
    fact_cache_0['test_2'] = 'test'
    fact_cache_0.flush()
    fact_cache_0.first_order_merge('test_2', 'test_0')
    fact_cache_0.first_order_merge('test_2', 'test_1')

    # Test case 4
    fact_cache_0.flush()

# Generated at 2022-06-25 14:10:19.448691
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    if fact_cache_0:
        print("OK")
    else:
        print("ERROR")
    fact_cache_0.first_order_merge("processorcount", 2)
    assert fact_cache_0.get('processorcount') == 2
    print("OK")

if __name__ == '__main__':
    test_FactCache_first_order_merge()

# Generated at 2022-06-25 14:10:21.972886
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0
    assert fact_cache_0._plugin



# Generated at 2022-06-25 14:10:22.760776
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

# Generated at 2022-06-25 14:10:26.885061
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    test_host = 'localhost'
    test_facts = {'foo': 'bar'}
    fact_cache_0 = test_case_0()
    fact_cache_0.first_order_merge(test_host, test_facts)
    results = fact_cache_0.copy()
    assert results['localhost']['foo'] == 'bar'

# Generated at 2022-06-25 14:11:33.517722
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    fact_cache_0 = FactCache()
    key_0 = "mykey"
    value_0 = dict(random=42)

    fact_cache_0.first_order_merge(key_0, value_0)
    assert fact_cache_0[key_0]['random'] == 42

# Generated at 2022-06-25 14:11:39.577260
# Unit test for constructor of class FactCache
def test_FactCache():
    # Instantiate class
    fact_cache = FactCache()

    # Check for inheritence
    assert isinstance(fact_cache, MutableMapping)

    # Check for implemented methods
    for method in ('__getitem__', '__setitem__', '__delitem__', '__contains__',
                   '__iter__', '__len__', 'copy', 'keys'):
        assert callable(getattr(fact_cache, method))

    # Check own methods
    assert callable(fact_cache.flush)
    assert callable(fact_cache.first_order_merge)

    # Check for variables
    assert '_FactCache__plugin' in dir(fact_cache)



# Generated at 2022-06-25 14:11:50.655132
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    fact_cache_1 = FactCache()
    remote_host = {'ansible_hostname': 'test_hostname_0'}

    fact_cache_1.first_order_merge('test_hostname_0', remote_host)
    assert fact_cache_1.__contains__('test_hostname_0') is True
    assert fact_cache_1['test_hostname_0']['ansible_hostname'] == 'test_hostname_0'
    assert fact_cache_1.__len__() == 1

    remote_host_1 = {'ansible_distribution': 'CentOS'}
    fact_cache_1.first_order_merge('test_hostname_1', remote_host_1)

# Generated at 2022-06-25 14:11:53.192525
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        test_case_0()
    except:
        display.display(
            "Failed executing test_case_0",
            color='red',
        )
        assert False


# Generated at 2022-06-25 14:11:55.025126
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    # In the case, the C.CACHE_PLUGIN is not determined
    if fact_cache:
        assert False

# Generated at 2022-06-25 14:11:56.511827
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    print (fact_cache_0)
    print ('\n')



# Generated at 2022-06-25 14:11:58.513022
# Unit test for constructor of class FactCache
def test_FactCache():
    display.display("Testing FactCache constructor", color='blue')
    test_case_0()

test_FactCache()

# Generated at 2022-06-25 14:12:07.548978
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    ip_address = '172.31.0.1'
    temp = '35'
    fact_cache.first_order_merge(ip_address, temp)

# Generated at 2022-06-25 14:12:08.790421
# Unit test for constructor of class FactCache
def test_FactCache():
    pass


test_cases = [
    test_case_0,
]



# Generated at 2022-06-25 14:12:11.638173
# Unit test for constructor of class FactCache
def test_FactCache():
   fact_cache = FactCache()
   try:
     display.run_tests(
        [
         test_case_0
        ],
        display_options={}
     )
   finally:
      fact_cache.flush()

# Generated at 2022-06-25 14:13:25.307435
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge("key", "value")

# Generated at 2022-06-25 14:13:32.360179
# Unit test for constructor of class FactCache
def test_FactCache():
    display.display("Test: constructor", color='blue')
    fc = FactCache()
    assert fc, "fail: constructor"
    display.display("pass", color='green')

    display.display("Test: __getitem__()", color='blue')
    fc['test'] = 'testval'
    assert 'test' in fc, "fail: __getitem__()"
    assert fc['test'] == 'testval', "fail: __getitem__()"
    display.display("pass", color='green')

    display.display("Test: __setitem__()", color='blue')
    fc['test'] = 'testval'
    assert 'test' in fc, "fail: __setitem__()"
    display.display("pass", color='green')


# Generated at 2022-06-25 14:13:34.044196
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache.__class__.__name__ == "FactCache"


# Generated at 2022-06-25 14:13:40.527023
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge("test_hostname", {"new_fact": "new fact value"})
    assert len(fact_cache_1.keys()) == 1
    fact_cache_1.first_order_merge("test_hostname", {"new_fact": "new fact value"})
    assert len(fact_cache_1.keys()) == 1
    fact_cache_1.first_order_merge("test_hostname", {"another_new_fact": "another new fact value"})
    assert len(fact_cache_1.keys()) == 1

# Generated at 2022-06-25 14:13:48.535120
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # setup
    fact_cache_1 = FactCache()
    key = "testing key"
    value = "testing value"
    expected_ret = None
    # this code block is required to set up a variable before the assert block
    try:
        del fact_cache_1[key]
    except KeyError:
        pass
    # assert
    fact_cache_1.first_order_merge(key, value)
    assert (fact_cache_1.__getitem__(key) == value)
    # assert that getitem passed successfully 
    try:
        assert fact_cache_1.__contains__(key)
        # assert that the key was successfully added
    except AssertionError:
        raise AssertionError("key was not added successfully")
    # tear down
    fact_cache_1.__delitem

# Generated at 2022-06-25 14:13:54.808820
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.flush()

    fact_cache.first_order_merge('first_key', 'first_value')
    assert fact_cache['first_key'] == 'first_value'

    fact_cache.first_order_merge('first_key', 'updated_value')
    assert fact_cache['first_key'] == 'updated_value'

    fact_cache.first_order_merge('second_key', 'second_value')
    assert fact_cache['second_key'] == 'second_value'

    fact_cache.flush()
    assert fact_cache.keys() == []


# Generated at 2022-06-25 14:14:02.944829
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    host_name = "test_server"

# Generated at 2022-06-25 14:14:04.808854
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        test_case_0()
    except TypeError:
        assert False

# Generated at 2022-06-25 14:14:13.685647
# Unit test for constructor of class FactCache
def test_FactCache():

    fact_cache = FactCache()

    host_data = {}

# Generated at 2022-06-25 14:14:20.153002
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Define test data
    data = {'a': 1, 'b': 2}
    key = 'my_key'
    host_cache = {'a': 1, 'b': 2}
    host_facts = {'my_key': {'a': 1, 'b': 2}}

    # Initialize test environment
    fact_cache = FactCache()

    # Run method
    result = fact_cache.first_order_merge(key, host_cache)

    # Verify expected output
    assert result == None
    assert fact_cache == host_facts