

# Generated at 2022-06-25 14:05:22.394033
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()
    assert type(fact_cache_1) == FactCache


# Generated at 2022-06-25 14:05:25.799081
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    # test with non-existing key
    key = "key"
    value = "value"
    fact_cache.first_order_merge(key, value)
    assert key in fact_cache
    assert fact_cache[key] == value



# Generated at 2022-06-25 14:05:26.891890
# Unit test for constructor of class FactCache
def test_FactCache():
    assert 'plugin' in dir(FactCache())


# Generated at 2022-06-25 14:05:30.429922
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge('{}'.format('key_0'), '{}'.format('value_0'))
    assert fact_cache_0['{}'.format('key_0')] == 'value_0'

# Generated at 2022-06-25 14:05:41.124573
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    fact_cache_0['192.168.0.1'] = {'ansible_hostname': 'host0',
                                   'ansible_ssh_host': '192.168.0.1'}
    # Unit test: __getitem__
    ansible_hostname_0 = fact_cache_0['192.168.0.1']['ansible_hostname']
    ansible_ssh_host_0 = fact_cache_0['192.168.0.1']['ansible_ssh_host']
    # Unit test: __setitem__
    fact_cache_0['192.168.0.1'] = {'ansible_hostname': 'host1',
                                   'ansible_ssh_host': '192.168.0.1'}
    #

# Generated at 2022-06-25 14:05:43.272608
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    if fact_cache_0._plugin:
        display.display('SUCC: test_FactCache()')


# Generated at 2022-06-25 14:05:44.590779
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    return fact_cache_0


# Generated at 2022-06-25 14:05:45.716212
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0


# Generated at 2022-06-25 14:05:47.164470
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:05:48.160617
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

# Generated at 2022-06-25 14:05:54.567084
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache,MutableMapping)
    try:
        fact_cache_0 = FactCache()
        assert fact_cache_0
    except:
        assert False


#

# Generated at 2022-06-25 14:05:59.286417
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge("test_key", 1)
    fact_cache_1.first_order_merge("test_key2", 2)
    assert list(fact_cache_1.keys()) == ["test_key", "test_key2"]

# Generated at 2022-06-25 14:06:02.019478
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache=FactCache()
    cache.first_order_merge("mykey", "myvalue")
    assert cache['mykey'] == "myvalue"


# Generated at 2022-06-25 14:06:03.742380
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert(isinstance(fact_cache, FactCache))


# Generated at 2022-06-25 14:06:08.427572
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    key = 'foo'
    host_facts = {'vars': {key: 'foo'}}
    host_cache = host_facts[key]
    fact_cache_0.first_order_merge(key, host_cache)
    assert fact_cache_0[key] == host_cache

# Generated at 2022-06-25 14:06:11.380013
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge('localhost', 'localhost_facts')


if __name__ == "__main__":
    test_FactCache_first_order_merge()

# Generated at 2022-06-25 14:06:22.024609
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    # call __getitem__()
    assert fact_cache_0.__getitem__('127.0.0.1')
    # call __setitem__()
    assert fact_cache_0.__setitem__('127.0.0.1', 'chocolate')
    # call __delitem__()
    assert fact_cache_0.__delitem__('127.0.0.1')
    # call __contains__()
    assert fact_cache_0.__contains__('127.0.0.1')
    # call __iter__()
    assert fact_cache_0.__iter__()
    # call __len__()
    assert fact_cache_0.__len__()
    # call copy()
    assert fact_cache_0.copy()
   

# Generated at 2022-06-25 14:06:25.182493
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    fact_cache_0 = FactCache()
    value = {}
    fact_cache_0.first_order_merge('key_0', value)


test_FactCache_first_order_merge()

# Generated at 2022-06-25 14:06:27.175421
# Unit test for constructor of class FactCache
def test_FactCache():
    assert hasattr(FactCache, '__init__')
    assert callable(FactCache.__init__)


# Generated at 2022-06-25 14:06:28.507591
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:06:31.550435
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()
    print('FactCache constructor test case passed')

# Generated at 2022-06-25 14:06:33.127069
# Unit test for constructor of class FactCache
def test_FactCache():
   fact_cache_0 = FactCache()

   assert fact_cache_0 is not None


# Generated at 2022-06-25 14:06:36.580316
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    facts = {}
    fact_cache_0.first_order_merge("inventory_hostname", facts)
    assert(fact_cache_0.keys() == ['inventory_hostname'])
    print("Passed all tests")

test_FactCache()

# Generated at 2022-06-25 14:06:38.166032
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        test_case_0()
    except Exception as e:
        print(e)



# Generated at 2022-06-25 14:06:39.869231
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        fact_cache = FactCache()
    except AnsibleError:
        pass


# Generated at 2022-06-25 14:06:47.841153
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts.collector import BaseFactCollector
    fc=FactCache()
    import copy
    addr=copy.deepcopy(fc)
    fc.first_order_merge("test","test")
    import collections
    d=collections.OrderedDict()
    fc.copy()
    fc.flush()
    fc.keys()
    print(fc["test"])
    fc["test"]="test"
    print(fc["test"])
    del fc["test"]
    assert isinstance(fc,dict)
    assert isinstance(fc,cache.FactCache)
    assert isinstance(fc,collections.MutableMapping)
    assert not isinstance(fc,BaseFactCollector)
    print

# Generated at 2022-06-25 14:06:59.787827
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    # Test for 'unknown' option for plugin cache
    C.CACHE_PLUGIN = 'unknown'
    try:
        fact_cache_0 = FactCache()
    except AnsibleError:
        pass
    #Test for 'memory' plugin
    C.CACHE_PLUGIN = 'memory'
    fact_cache_0 = FactCache()
    assert fact_cache_0
    # Test for 'redis' plugin
    C.CACHE_PLUGIN = 'redis'
    fact_cache_0 = FactCache()
    assert fact_cache_0
    # Test for 'jsonfile' plugin
    C.CACHE_PLUGIN = 'jsonfile'
    fact_cache_0 = FactCache()
    assert fact_cache_0

# Unit

# Generated at 2022-06-25 14:07:01.122786
# Unit test for constructor of class FactCache
def test_FactCache():

    display.display('Test_FactCache')
    test_case_0()

# Generated at 2022-06-25 14:07:01.933100
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

# Generated at 2022-06-25 14:07:02.655403
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

# Generated at 2022-06-25 14:07:11.069042
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    '''
    Test first_order_merge function of class FactCache.
    '''
    fact_cache = FactCache()
    test_key = "test_key_0"
    test_value = "test_value_0"
    fact_cache.first_order_merge(test_key, test_value)
    assert fact_cache[test_key] == test_value

test_FactCache_first_order_merge()


# Generated at 2022-06-25 14:07:14.874319
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert False
    else:
        assert True



# Generated at 2022-06-25 14:07:19.174370
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_2 = FactCache()
    previous = {'foo': 'bar'}
    result = fact_cache_2.first_order_merge('test', previous)
    assert {'foo': 'bar'} in fact_cache_2
    assert 'foo' in fact_cache_2['test']


# Generated at 2022-06-25 14:07:24.196363
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache_file = fact_cache.first_order_merge("localhost", {"a": 1})
    fact_cache[fact_cache_file] = {"b": 1}
    fact_cache.first_order_merge("localhost", {"c": 1})
    assert fact_cache["localhost"] == {"a": 1, "b": 1, "c": 1}


# Generated at 2022-06-25 14:07:29.089392
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache
    try:
        FactCache(1)
    except TypeError:
        pass
    try:
        FactCache(1, 2)
    except TypeError:
        pass

#

# Generated at 2022-06-25 14:07:31.001793
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()

    assert fact_cache_0._plugin.name == 'jsonfile'

# Generated at 2022-06-25 14:07:32.416706
# Unit test for constructor of class FactCache
def test_FactCache():
    obj = FactCache()
    return obj


# Generated at 2022-06-25 14:07:33.822055
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:07:40.894422
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    fact_cache["test1"] = "content"
    result = fact_cache["test1"]
    fact_cache.flush()
    fact_cache.__delitem__("test1")
    result_keys = fact_cache.keys()
    result_copy = fact_cache.copy()
    result_length = len(fact_cache)
    assert result == "content"
    assert result_keys == []
    assert result_copy == result_copy
    assert result_length == 0


# Generated at 2022-06-25 14:07:42.506667
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

if __name__ == '__main__':
    test_FactCache()

# Generated at 2022-06-25 14:07:47.676570
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)
    assert issubclass(type(fact_cache), MutableMapping)
    assert not fact_cache


# Generated at 2022-06-25 14:07:55.954794
# Unit test for method first_order_merge of class FactCache

# Generated at 2022-06-25 14:07:58.110316
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()
    assert fact_cache_1 is not None, 'An instance of class FactCache is not created'


# Generated at 2022-06-25 14:07:59.039160
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    pass


# Generated at 2022-06-25 14:07:59.991726
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()

# Generated at 2022-06-25 14:08:06.950205
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    key_0 = "test_facts"
    value_0 = {"test_fact1": "test_value1", "test_fact2": "test_value2"}
    fact_cache_0.first_order_merge(key_0, value_0)
    assert fact_cache_0.first_order_merge(key_0, value_0) is None, \
        "Expected None but got %s" % repr(fact_cache_0.first_order_merge(key_0, value_0))


# Generated at 2022-06-25 14:08:07.999758
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()


# Generated at 2022-06-25 14:08:10.265372
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()

# Testcase with sample inputs and outputs

# Generated at 2022-06-25 14:08:11.074222
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()

    if fact_cache_0 is not None:
        print("Print from test_FactCache()")



# Generated at 2022-06-25 14:08:12.261101
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc is not None and isinstance(fc, FactCache)

# Generated at 2022-06-25 14:08:16.064512
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

# Generated at 2022-06-25 14:08:18.796658
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    key = 'job_start'
    value = '1397695531'
    assert fact_cache_0.first_order_merge(key,value) == None

# Test for the constructor

# Generated at 2022-06-25 14:08:25.064087
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()

    # First order merge
    fact_cache.first_order_merge("test_key", {"k1": "v1"})
    assert fact_cache["test_key"] == {"k1": "v1"}

    # Second order merge
    fact_cache.first_order_merge("test_key", {"k2": "v2"})
    assert fact_cache["test_key"] == {"k1": "v1", "k2": "v2"}

    # Third order, merged keys should be replaced by the new keys
    fact_cache.first_order_merge("test_key", {"k1": "v1_2", "k2": "v2_2"})

# Generated at 2022-06-25 14:08:27.122724
# Unit test for constructor of class FactCache
def test_FactCache():
    result_0 = test_case_0()
    return result_0

print(test_FactCache())

# Generated at 2022-06-25 14:08:29.923865
# Unit test for constructor of class FactCache
def test_FactCache():
    import pytest

    with pytest.raises(AnsibleError) as err:
        test_case_0()

    assert (str(err.value) == 'Unable to load the facts cache plugin (memory).')



# Generated at 2022-06-25 14:08:32.620835
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge('key', 'value')


# Generated at 2022-06-25 14:08:34.680052
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache_0 = FactCache()
    cache_1 = cache_0.first_order_merge('testKey', 1)


# Generated at 2022-06-25 14:08:35.241679
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()


# Generated at 2022-06-25 14:08:36.040952
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)

# Generated at 2022-06-25 14:08:36.611591
# Unit test for constructor of class FactCache
def test_FactCache():
    assert True

# Generated at 2022-06-25 14:08:47.083421
# Unit test for constructor of class FactCache
def test_FactCache():
    # This is the test case for case when fact_cache is not cache
    fact_cache_1 = FactCache()
    assert fact_cache_1 == {}
    # This is the test case for case when fact_cache is cache
    fact_cache_2 = FactCache()
    fact_cache_2['foo'] = 'bar'
    assert fact_cache_2['foo'] == 'bar'



# Generated at 2022-06-25 14:08:56.555527
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Create an instance of FactCache
    fact_cache_1 = FactCache()
    # Add "host_0" as key to the fact_cache_1
    fact_cache_1.first_order_merge("host_0", "ip")
    # Add "host_0" to the fact_cache_1
    fact_cache_1.first_order_merge("host_1", "ip")
    # Add "host_2" to the fact_cache_1
    fact_cache_1.first_order_merge("host_2", "ip")
    assert fact_cache_1["host_0"] == "ip"
    assert fact_cache_1["host_1"] == "ip"
    assert fact_cache_1["host_2"] == "ip"

# Generated at 2022-06-25 14:08:57.467955
# Unit test for constructor of class FactCache
def test_FactCache():
    assert len(FactCache()) == 0


# Generated at 2022-06-25 14:09:00.906002
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_obj = FactCache()


# in case of __main__, call the function directly
if __name__ == '__main__':
    test_FactCache()

# Generated at 2022-06-25 14:09:03.401605
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    fact_cache['foo.bar'] = 'yes'
    assert fact_cache['foo.bar'] == 'yes'

# Generated at 2022-06-25 14:09:04.014885
# Unit test for constructor of class FactCache
def test_FactCache():
    assert FactCache()

# Generated at 2022-06-25 14:09:11.364947
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    test_host_name = 'test_host_0'
    fact_cache_0 = FactCache()
    assert test_host_name not in fact_cache_0.keys()
    fact_cache_0.first_order_merge(test_host_name, {'key0': 'val0'})
    assert test_host_name in fact_cache_0.keys()
    assert 'key0' in fact_cache_0[test_host_name]
    assert fact_cache_0[test_host_name]['key0'] == 'val0'
    fact_cache_0.first_order_merge(test_host_name, {'key1': 'val1'})
    assert test_host_name in fact_cache_0.keys()

# Generated at 2022-06-25 14:09:14.041859
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

    fact_cache = FactCache()
    assert fact_cache is not None


# Generated at 2022-06-25 14:09:24.573481
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()

    fact_cache_0.first_order_merge("a", { "a": 1 })
    assert fact_cache_0.copy() == { "a": { "a": 1 } }

    fact_cache_0.first_order_merge("b", { "b": 2 })
    assert fact_cache_0.copy() == { "a": { "a": 1 }, "b": { "b": 2 } }

    fact_cache_0.first_order_merge("a", { "b": 2 })
    assert fact_cache_0.copy() == { "a": { "a": 1, "b": 2 }, "b": { "b": 2 } }

test_FactCache_first_order_merge()

# Generated at 2022-06-25 14:09:26.890908
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    fact_cache_0['key'] = "value"
    for key in fact_cache_0.keys():
        print(fact_cache_0[key])
    fact_cache_0.flush()

# Generated at 2022-06-25 14:09:40.675329
# Unit test for constructor of class FactCache
def test_FactCache():
    # test fact_cache_0
    test_case_0()

# Generated at 2022-06-25 14:09:41.694560
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

# Generated at 2022-06-25 14:09:48.376562
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    test_cache = FactCache()
    key = 'first_order_merge_v_1'
    test_cache.first_order_merge(key, {'key1': 'val1'})
    assert(test_cache[key] == {'key1': 'val1'})
    test_cache.first_order_merge(key, {'key2': 'val2'})
    assert(test_cache[key] == {'key1': 'val1', 'key2': 'val2'})
    del test_cache[key]


# Generated at 2022-06-25 14:09:56.108572
# Unit test for method first_order_merge of class FactCache

# Generated at 2022-06-25 14:09:57.279264
# Unit test for constructor of class FactCache
def test_FactCache():
    # Create a FactCache object
    fc = FactCache()


# Generated at 2022-06-25 14:09:59.576958
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0._plugin is not None



# Generated at 2022-06-25 14:10:02.513507
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        test_case_0()
    except Exception as e:
        print("Test case 0 - constructor test failed: " + str(e))

test_FactCache()

# Generated at 2022-06-25 14:10:04.551263
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        fact_cache = FactCache()
    except:
        assert 0, "Unexpected failure"

test_FactCache()

# Generated at 2022-06-25 14:10:07.323661
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge("foo", {"bar": 1})
    fact_cache_0.first_order_merge("foo", {"bar": 2})

# Generated at 2022-06-25 14:10:08.998173
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    print(fact_cache_0)
    return fact_cache_0


# Generated at 2022-06-25 14:10:43.374763
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache_0 = FactCache()
    cache_0.first_order_merge('/home/vagrant/ansible/test/test_FactCache.py', {'fact_cache_0': 'test_0'})
    cache_1 = cache_0.copy()
    cache_2 = cache_0.copy()
    cache_2.update(dict(ansible_facts='test_1'))

    reference_cache = {
                        'ansible_facts' : 'test_1',
                        '/home/vagrant/ansible/test/test_FactCache.py' : {
                            'fact_cache_0' : 'test_0'
                        }
    }
    assert cache_0['ansible_facts'] == reference_cache['ansible_facts']

# Generated at 2022-06-25 14:10:46.849911
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    key = "test"
    value = {"a": "1"}
    expected_cache = {"test": {"a": "1"}}
    cache.first_order_merge(key, value)
    assert cache == expected_cache



# Generated at 2022-06-25 14:10:47.621669
# Unit test for constructor of class FactCache
def test_FactCache():
    assert test_case_0() == None

# Generated at 2022-06-25 14:10:49.897392
# Unit test for constructor of class FactCache
def test_FactCache():

    assert isinstance(test_case_0, object)
    assert hasattr(test_case_0, '__init__')
    assert callable(test_case_0.__init__)

# Generated at 2022-06-25 14:10:51.808377
# Unit test for constructor of class FactCache
def test_FactCache():
    """ Test constructor of class FactCache """

    factcache = FactCache()
    assert factcache is not None

# Generated at 2022-06-25 14:10:53.171563
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, MutableMapping)


# Generated at 2022-06-25 14:10:53.971809
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

# Generated at 2022-06-25 14:10:54.827262
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

# Generated at 2022-06-25 14:10:57.043390
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()
    try:
        assert fact_cache_1._plugin is None
    except AssertionError:
        display.display("Failed to initialize _plugin.")


# Generated at 2022-06-25 14:11:03.136624
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Try to add two values which are not in the fact_cache
    facts_0 = FactCache()
    facts_0.first_order_merge("localhost", "test0")
    facts_0.first_order_merge("test.com", "test1")

    # Try to add a value in the fact_cache
    facts_0.first_order_merge("localhost", "test2")
    assert "test2" == facts_0["localhost"]

    # Try to add a value in the fact_cache which is not in the fact_cache
    facts_0.first_order_merge("test2.com", "test3")
    assert "test3" == facts_0["test2.com"]


# Generated at 2022-06-25 14:12:09.695442
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    host_facts_1 = {
        'test_host_1': {
            'test_fact_1': 'fact_value_1',
            'test_fact_2': 'fact_value_2',
            'test_fact_3': 'fact_value_3',
        }
    }
    host_facts_2 = {
        'test_host_2': {
            'test_fact_1': 'fact_value_1',
            'test_fact_2': 'fact_value_2',
            'test_fact_3': 'fact_value_3',
        }
    }
    fact_cache_1.first_order_merge(host_facts_1.keys()[0], host_facts_1.values()[0])
    fact_cache_

# Generated at 2022-06-25 14:12:16.237917
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    new_cache = FactCache()
    new_cache.first_order_merge("host", {"hostvars": {"local": "test"}})
    new_cache.first_order_merge("host", {"hostvars": {"new": "test2"}})
    assert new_cache._plugin.get("host")["hostvars"]["local"] == "test"
    assert new_cache._plugin.get("host")["hostvars"]["new"] == "test2"


if __name__ == '__main__':
    test_FactCache_first_order_merge()

# Generated at 2022-06-25 14:12:17.424812
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    test_FactCache = FactCache()
    # Call method
    test_FactCache.first_order_merge('key', 'value')


# Generated at 2022-06-25 14:12:21.231084
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    if not isinstance(fact_cache_0, FactCache):
        print("Testcase 0 Failed")
        return
    fact_cache_0 = FactCache()
    if not isinstance(fact_cache_0, FactCache):
        print("Testcase 1 Failed")
        return
    print("Testcase 2 Passed")
    return


# Generated at 2022-06-25 14:12:24.336021
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    display.info('in test_FactCache_first_order_merge()')
    fact_cache_1 = FactCache()
    result = fact_cache_1.first_order_merge(key=None,value=None)
    assert result == None



# Generated at 2022-06-25 14:12:32.147122
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    key_0 = 'test_key'
    value_0 = 'test_value'

    fact_cache_0.first_order_merge(key_0, value_0)
    fact_cache_0[key_0] = value_0
    fact_cache_0[key_0] == value_0
    fact_cache_0[key_0]
    fact_cache_0[key_0]
    fact_cache_0.first_order_merge(key_0, value_0)
    fact_cache_0.keys()
    fact_cache_0.flush()
    fact_cache_0.copy()
    fact_cache_0.keys()
    fact_cache_0.first_order_merge(key_0, value_0)
   

# Generated at 2022-06-25 14:12:33.233395
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        test_case_0()
    except Exception as e:
        print(e)

# Generated at 2022-06-25 14:12:35.404214
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()
    fact_cache_2 = FactCache()
    assert fact_cache_1.__class__.__name__ == 'FactCache'
    assert fact_cache_2.__class__.__name__ == 'FactCache'


# Generated at 2022-06-25 14:12:36.420562
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert True


# Generated at 2022-06-25 14:12:37.708387
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache != None, "constructor of class FactCache failed"


# Generated at 2022-06-25 14:14:52.899087
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:15:01.931109
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()

# Generated at 2022-06-25 14:15:03.618630
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        FactCache()
    except:
        raise AssertionError('Unable to create instance.')


# Generated at 2022-06-25 14:15:04.738998
# Unit test for constructor of class FactCache
def test_FactCache():
    assert type(FactCache(1,2,3)) == FactCache

# Generated at 2022-06-25 14:15:07.807133
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_key', {'test_key': 'test_value'})
    fact = fact_cache.get('test_key')
    assert fact == {'test_key': 'test_value'}


# Generated at 2022-06-25 14:15:08.796025
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:15:14.021647
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    my_cache = FactCache()
    my_cache.first_order_merge('foo', {'bar': 'baz'})
    assert my_cache['foo']['bar'] == 'baz'

    my_cache.first_order_merge('foo', {'bar': 'baz2'})
    assert my_cache['foo']['bar'] == 'baz2'

    my_cache.flush()


if __name__ == '__main__':

    test_FactCache_first_order_merge()

# Generated at 2022-06-25 14:15:15.003362
# Unit test for constructor of class FactCache
def test_FactCache():
    import pytest
    test_case_0()

# Generated at 2022-06-25 14:15:24.825946
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    fc['key1'] = 'value1'
    assert fc['key1'] == 'value1'
    fc['key1'] = 'value2'
    assert fc['key1'] == 'value2'
    assert 'key1' in fc
    assert 'key2' not in fc
    del fc['key1']
    assert 'key1' not in fc
    assert len(fc) == 0
    assert fc.keys() == []
    fc.first_order_merge('key1', {'k1': 'v2', 'k2': 'v2'})
    assert fc['key1'] == {'k1': 'v2', 'k2': 'v2'}