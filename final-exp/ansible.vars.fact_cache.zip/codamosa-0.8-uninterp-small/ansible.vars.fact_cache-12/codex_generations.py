

# Generated at 2022-06-25 14:05:21.836671
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache('testing')
    assert len(fc) == 1
    fc.flush()
    assert len(fc) == 0


# Generated at 2022-06-25 14:05:23.095020
# Unit test for constructor of class FactCache
def test_FactCache():
    fc_class_instance = FactCache()
    assert fc_class_instance is not None


# Generated at 2022-06-25 14:05:25.410334
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0.__class__.__name__ == "FactCache"


# Generated at 2022-06-25 14:05:29.697846
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge('foo', {'a': '1'})
    fact_cache_0.first_order_merge('foo', {'b': '2'})
    assert fact_cache_0['foo'] == {'a': '1', 'b': '2'}


# Generated at 2022-06-25 14:05:40.394821
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    key = "localhost"

# Generated at 2022-06-25 14:05:42.292112
# Unit test for constructor of class FactCache
def test_FactCache():
    print("Testing fact_cache constructor")
    test_case_0()
    print("Done testing fact_cache constructor")



# Generated at 2022-06-25 14:05:45.456334
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    test_host = 'localhost'
    test_fact = {'test_fact': 'test_val'}
    fc.first_order_merge(test_host, test_fact)
    assert fc[test_host]['test_fact'] == test_fact['test_fact']


# Generated at 2022-06-25 14:05:47.249226
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    assert isinstance(fact_cache_0.first_order_merge("key", "value"), dict)


# Generated at 2022-06-25 14:05:48.614115
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None


# Generated at 2022-06-25 14:05:51.265359
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    key = str()
    value = dict()
    fact_cache_0.first_order_merge(key, value)


# Generated at 2022-06-25 14:06:03.608067
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge('test_host', {})
    assert 'test_host' in fact_cache_1.keys()
    assert fact_cache_1['test_host'] == {}

    fact_cache_1.first_order_merge('test_host', {'answer': 42})
    assert fact_cache_1['test_host'].get('answer') == 42

    fact_cache_1.first_order_merge('test_host', {'answer': 42, 'new_fact': 'value'})
    assert fact_cache_1['test_host'].get('answer') == 42
    assert fact_cache_1['test_host'].get('new_fact') == 'value'


# Generated at 2022-06-25 14:06:06.428230
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('key1', 'value1')
    assert fact_cache['key1'] == 'value1'


# Generated at 2022-06-25 14:06:13.858435
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    key = '192.168.56.101'
    value = {'hello': 'world'}
    fact_cache.first_order_merge(key, value)

    print(fact_cache.keys())
    assert key in fact_cache.keys()
    assert fact_cache[key] == value

    key = '192.168.56.102'
    value = {'hello': 'ansible'}
    fact_cache.first_order_merge(key, value)

    print(fact_cache.keys())
    assert key in fact_cache.keys()
    assert fact_cache[key] == value

    fact_cache.flush()



# Generated at 2022-06-25 14:06:20.280199
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_first_order_merge_0 = FactCache()
    fact_cache_first_order_merge_1 = {'dummy_0': 'dummy_0'}
    fact_cache_first_order_merge_0.first_order_merge('dummy_0', fact_cache_first_order_merge_1)

test_case_0()
test_FactCache_first_order_merge()

# Generated at 2022-06-25 14:06:28.203331
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()
    print("Type of object: ",type(fact_cache_1))
    print("Dir of object: ",dir(fact_cache_1))
    print("Representation of object: ",repr(fact_cache_1))
    for item in fact_cache_1:
        print("Item: ",item)

TEST_CASES = [
    [0, test_case_0],
    [1, test_FactCache],
]

TEST_CASES = [
    [1, test_FactCache],
]


# Generated at 2022-06-25 14:06:30.107013
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()


if __name__ == '__main__':
    test_FactCache()

# Generated at 2022-06-25 14:06:32.456740
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    fact_cache_0 = FactCache()
    assert fact_cache_0.first_order_merge('testkey', 'testvalue') == None


# Generated at 2022-06-25 14:06:41.218389
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache({'success': False})
    assert not fact_cache['success']
    fact_cache['success'] = True
    assert fact_cache['success']
    assert 'success' in fact_cache
    assert len(fact_cache) == 1
    fact_cache['0'] = 'zero'
    fact_cache['1'] = 'one  '
    assert '1' in fact_cache
    assert fact_cache['0'] == 'zero'
    fact_cache['0'] = 'zwei'
    assert fact_cache['0'] == 'zwei'
    del fact_cache['0']
    assert '0' not in fact_cache
    assert len(fact_cache) == 2
    fact_cache.flush()
    assert len(fact_cache) == 0

# Generated at 2022-06-25 14:06:41.975163
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin == "jsonfile"

# Generated at 2022-06-25 14:06:43.787541
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge("key_0", "value_0")


# Generated at 2022-06-25 14:06:58.307920
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('127.0.0.1', {'ansible_ssh_host': '127.0.0.1', 'ansible_host': '127.0.0.1'})
    # a primitive copy of the keys and values from the cache
    assert fact_cache.copy() == {'127.0.0.1': {'ansible_ssh_host': '127.0.0.1', 'ansible_host': '127.0.0.1'}}
    # a primitive copy of the keys and values from the cache
    assert fact_cache.copy()['127.0.0.1']['ansible_ssh_host'] == '127.0.0.1'



# Generated at 2022-06-25 14:07:03.142588
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge("host1", {"value1": "host1_value1", "value2": "host1_value2"})

    try:
        value = fact_cache["host1"]
        assert value["value1"] == "host1_value1"
        assert value["value2"] == "host1_value2"
    except Exception:
        assert False


# Generated at 2022-06-25 14:07:07.137187
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    ansible_facts_0 = {}
    ansible_facts_0 = fact_cache_0.first_order_merge(ansible_facts_0)
    assert ansible_facts_0 is None


# Generated at 2022-06-25 14:07:08.395134
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()


# Generated at 2022-06-25 14:07:19.632259
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()

    # Test the '__delitem__' method
    assert fact_cache.__delitem__("") == None
    # Test the '__getitem__' method
    #assert fact_cache.__getitem__("") == ""
    # Test the '__setitem__' method
    assert fact_cache.__setitem__("", "") == None
    # Test the 'copy' method
    assert fact_cache.copy() == {}
    # Test the 'flush' method
    assert fact_cache.flush() == None
    # Test the 'first_order_merge' method
    assert fact_cache.first_order_merge("", "") == None
    # Test the 'keys' method
    assert fact_cache.keys() == []

# Generated at 2022-06-25 14:07:22.368942
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge("default", {"test1": 1})
    fact_cache_0.first_order_merge("default", {"test2": 2})
    assert fact_cache_0["default"] == {"test1": 1, "test2": 2}


# Generated at 2022-06-25 14:07:32.989575
# Unit test for constructor of class FactCache
def test_FactCache():
    
    print("In FactCache constructor")

    # initialize an instance of the class
    cache= FactCache()
    #print("Value of the cache is ", cache)

    # calls the flush function
    cache.flush()
    
    

if __name__ == '__main__':
    
    print("\n UNIT TEST FOR FACT CACHE MODULE")
    print("\n TEST CASE 1")
    print("\n Testing the constructor for the class")
    print(" Calling the constructor")
    print("\n The value of fact_cache_0 is ")
    test_FactCache()

    print("\n TEST CASE 2")
    print("\n Testing the 'copy' function")
    print(" Calling the function")
    print("\n The value of fact_cache_1 is ")
    test_copy()

    print

# Generated at 2022-06-25 14:07:34.720069
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    print("FactCache initialized: %s" % fc)


# Generated at 2022-06-25 14:07:38.516543
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0.copy()=={}
    assert isinstance(fact_cache_0, MutableMapping)
    assert fact_cache_0._plugin.__class__.__name__ == 'FactCache'
    return fact_cache_0

# Generated at 2022-06-25 14:07:42.292902
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge(key='key_0', value='value_0')

    assert fact_cache_0 == {'key_0': 'value_0'}

# Generated at 2022-06-25 14:07:55.904297
# Unit test for constructor of class FactCache

# Generated at 2022-06-25 14:07:57.670326
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    key='instance-id'
    value='i-07fb738e'
    fact_cache_1.first_order_merge(key, value)

# Generated at 2022-06-25 14:08:02.088725
# Unit test for constructor of class FactCache
def test_FactCache():
    # Create a temporary file to store the cache
    tmp_file = '/tmp/fact_cache.yml'

    # Test constructor
    # Create a fact cache using the constructor
    fact_cache = FactCache(tmp_file)

    # Test if the fact cache is initialized
    if fact_cache:
        print('FactCache is initialized')


# Generated at 2022-06-25 14:08:03.147794
# Unit test for constructor of class FactCache
def test_FactCache():
    if C.CACHE_PLUGIN:
        test_case_0()
        pass

# Generated at 2022-06-25 14:08:10.970982
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()
    assert fact_cache_1._plugin is not None
    assert fact_cache_1.__str__ is not None
    assert fact_cache_1.__getitem__ is not None
    assert fact_cache_1.__setitem__ is not None
    assert fact_cache_1.__delitem__ is not None
    assert fact_cache_1.__contains__ is not None
    assert fact_cache_1.__iter__ is not None
    assert fact_cache_1.__len__ is not None
    assert fact_cache_1.copy is not None
    assert fact_cache_1.keys is not None
    assert fact_cache_1.flush is not None
    assert fact_cache_1.first_order_merge is not None

# Generated at 2022-06-25 14:08:14.426558
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge("test_key_1", "test_value_1")
    fact_cache_0.first_order_merge("test_key_2", "test_value_2")
    assert fact_cache_0.keys() == ["test_key_1", "test_key_2"]


# Generated at 2022-06-25 14:08:16.053770
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()
    assert fact_cache_1


# Generated at 2022-06-25 14:08:25.657066
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Try initializing the cache
    fact_cache = FactCache()

    # Check the content at the beginning
    if fact_cache.keys():
        raise AssertionError('The cache should be empty')

    # First key and value pair pushed
    fact_cache.first_order_merge('foo', {'a': 1, 'b': 2, 'c': 3})

    # The cache should have the new content
    if not 'foo' in fact_cache:
        raise AssertionError('The key should be present in the cache')
    elif fact_cache['foo'] != {'a': 1, 'b': 2, 'c': 3}:
        raise AssertionError('The content of the key does not match')

    # Second key and value pair pushed

# Generated at 2022-06-25 14:08:26.684137
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

# Generated at 2022-06-25 14:08:29.668221
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    host_facts = {}
    host_cache = {}
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge({'hostvars':host_cache},{'hostvars':host_facts})

# Generated at 2022-06-25 14:08:42.660200
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None


# Generated at 2022-06-25 14:08:43.804224
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:08:49.291030
# Unit test for constructor of class FactCache
def test_FactCache():
    # Test with invalid cache plugin name
    try:
        fact_cache_1 = FactCache(cache_plugin='invalid')
        raise AssertionError('AnsibleError was not raised')
    except AnsibleError:
        pass

    fact_cache_2 = FactCache(cache_plugin='jsonfile')

    fact_cache_3 = FactCache(cache_plugin='jsonfile')
    host_cache_3 = fact_cache_3.get('all')


# Generated at 2022-06-25 14:08:51.260199
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    keys = fact_cache.keys()
    assert(len(keys) == 0)


# Generated at 2022-06-25 14:08:52.731496
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache


# Generated at 2022-06-25 14:08:56.364696
# Unit test for constructor of class FactCache
def test_FactCache():
    '''
    Unit test for constructor of class FactCache
    '''
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert False
    else:
        assert True

if __name__ == "__main__":
    test_FactCache()

# Generated at 2022-06-25 14:09:04.979462
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0._plugin == cache_loader.get(C.CACHE_PLUGIN)
    assert fact_cache_0._plugin == cache_loader.get(C.CACHE_PLUGIN)
    assert fact_cache_0._plugin == cache_loader.get(C.CACHE_PLUGIN)
    assert fact_cache_0._plugin == cache_loader.get(C.CACHE_PLUGIN)
    assert fact_cache_0._plugin == cache_loader.get(C.CACHE_PLUGIN)


# Generated at 2022-06-25 14:09:05.888448
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()


# Generated at 2022-06-25 14:09:07.112977
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:09:12.660080
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    # Test with valid ansible_facts and ansible_facts_cache
    fact_cache_1.first_order_merge('127.0.0.1', {'ansible_os_family': 'RedHat', 'ansible_distribution': 'CentOS'})
    print(fact_cache_1)
    # Test with valid ansible_facts and invalid ansible_facts_cache
    fact_cache_2 = FactCache()
    try:
        fact_cache_2.first_order_merge('127.0.0.2', {'ansible_os_family': 'RedHat', 'ansible_distribution': 'CentOS'})
    except KeyError as e:
        print(e)



# Generated at 2022-06-25 14:09:42.760641
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.clear()
    key = 'test_key'
    value = {'test_key_value':'test_value'}
    fact_cache.first_order_merge(key, value)

# Generated at 2022-06-25 14:09:45.593741
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        fact_cache_0 = FactCache()
        print("Constructor of class FactCache works correctly")
    except:
        print("Constructor of class FactCache does not work correctly")
        raise


# Generated at 2022-06-25 14:09:51.071588
# Unit test for constructor of class FactCache
def test_FactCache():
    # Test for empty constructor
    fact_cache_0 = FactCache()
    # Test for input as key and value
    fact_cache_1 = FactCache({'key1': 'value1'})
    # Test for input as key and value
    fact_cache_2 = FactCache(('key1', 'value1'))
    # Test for a key and value list
    fact_cache_3 = FactCache([['key1', 'value1'], ['key2', 'value2']])



# Generated at 2022-06-25 14:09:55.708037
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    display.banner('Unit test for method first_order_merge of class FactCache')
    fact_cache = fact_cache_0
    print('1st call:')
    host_facts = fact_cache.first_order_merge()
    print(host_facts)
    print('2nd call:')
    host_facts = fact_cache.first_order_merge()
    print(host_facts)

# Unit tests for method set and get of class FactCache

# Generated at 2022-06-25 14:09:57.041852
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert type(fact_cache_0) == FactCache


# Generated at 2022-06-25 14:10:07.488254
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    fact_cache = FactCache()

    # test_0
    fact_cache.first_order_merge('test', {'a': 1, 'b': 2})
    assert fact_cache['test'] == {'a': 1, 'b': 2}

    # test_1
    fact_cache.first_order_merge('test', {'a': 3, 'b': 4})
    assert fact_cache['test'] == {'a': 3, 'b': 4}

    # test_2
    fact_cache.first_order_merge('test', {'a': 5})
    assert fact_cache['test'] == {'a': 5}

    # test_3
    #fact_cache.first_order_merge('test', {'a': 6, 'c': 7})
    #assert fact_cache['test

# Generated at 2022-06-25 14:10:12.304001
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()

    # Test with no facts initially in the cache
    fact_cache.first_order_merge(u'localhost', {u'hello': u'world'})
    assert fact_cache[u'localhost'].get(u'hello', None) == u'world'

    # Test with different facts already in the cache
    fact_cache.first_order_merge(u'localhost', {u'hello': u'universe'})
    assert fact_cache[u'localhost'].get(u'hello', None) == u'universe'

    # Test with no new facts
    fact_cache.first_order_merge(u'localhost', {})
    assert fact_cache[u'localhost'].get(u'hello', None) == u'universe'

# Generated at 2022-06-25 14:10:13.526574
# Unit test for constructor of class FactCache
def test_FactCache():
    assert test_case_0() is None



# Generated at 2022-06-25 14:10:14.549801
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()



# Generated at 2022-06-25 14:10:15.596866
# Unit test for constructor of class FactCache
def test_FactCache():
    FactCache()


# Generated at 2022-06-25 14:11:16.932159
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache(C.CACHE_PLUGIN)


# Generated at 2022-06-25 14:11:18.127791
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0 != None


# Generated at 2022-06-25 14:11:22.206427
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0._plugin == cache_loader.get(C.CACHE_PLUGIN)
    try:
        assert fact_cache_0._plugin != cache_loader.get('some_Nonexistent_plugin_name')
    except Exception:
        pass
    else:
        raise RuntimeError("AnsibleError was not raised")


# Generated at 2022-06-25 14:11:31.774952
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    assert fc.keys() == []
    fc.first_order_merge("test_host", {"ansible_distribution": "Fedora"})
    assert fc.keys() == ["test_host"]
    assert fc.get("test_host")["ansible_distribution"] == "Fedora"
    fc.first_order_merge("test_host", {"ansible_distribution_major_version": "27"})
    assert fc.get("test_host")["ansible_distribution_major_version"] == "27"
    fc.first_order_merge("test_host", {"ansible_distribution": "CentOS"})
    assert fc.get("test_host")["ansible_distribution"] == "CentOS"
    fc.first

# Generated at 2022-06-25 14:11:33.151081
# Unit test for constructor of class FactCache
def test_FactCache():
    obj = FactCache()
    assert obj.__class__.__name__ == 'FactCache'


# Generated at 2022-06-25 14:11:35.723023
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        test_case_0()
    except Exception as e:
        print('FAILED: test_case_0: ' + repr(e))
        raise e
    else:
        print('SUCCESS: test_case_0')


# Generated at 2022-06-25 14:11:46.858424
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Test 1
    fact_cache_1 = FactCache()
    host_fact_1 = {'location': 'southsea'}
    fact_cache_1.first_order_merge('test01', host_fact_1)
    assert fact_cache_1.keys() == ['test01'], "Failed testing method first_order_merge()"
    
    # Test 2
    fact_cache_2 = FactCache()
    host_fact_2 = {'location': 'southsea'}
    fact_cache_2.first_order_merge('test02', host_fact_2)
    assert fact_cache_2['test02']['location'] == 'southsea', "Failed testing method first_order_merge()"
    

# Unit test entry point

# Generated at 2022-06-25 14:11:47.970227
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()
    print("Testing complete")

test_FactCache()

# Generated at 2022-06-25 14:11:51.472609
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert isinstance(fact_cache_0, MutableMapping)
    assert fact_cache_0._plugin.__class__.__name__ == 'FactCachePlugin'
# End test_FactCache



# Generated at 2022-06-25 14:11:55.690966
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    host_facts_obj = {"hostname": "localhost"}

    try:
        display.display(fact_cache_0.first_order_merge("localhost", host_facts_obj))
    except AnsibleError:
        pass

if __name__ == '__main__':
    test_case_0()
    test_FactCache_first_order_merge()

# Generated at 2022-06-25 14:14:23.449733
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    fact_cache_0.flush()
    assert len(fact_cache_0) == 0
    host1 = 'a'
    value1 = {'full': {'facts': 'TEST_FACTS'}, 'facts': {'facts': 'TEST_FACTS'}}
    fact_cache_0.first_order_merge(host1, value1)
    assert len(fact_cache_0) == 1




# Generated at 2022-06-25 14:14:29.548963
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import json
    import pytest

    fact_cache_1 = FactCache()

    # test: update empty cache
    host_facts_1 = {u'ansible_local': {u'first_order_merge_test': {u'key_u': u'test'}}}
    fact_cache_1.first_order_merge(u'ansible_local', host_facts_1[u'ansible_local'])

    # test: update non-empty cache
    host_facts_2 = {u'ansible_local': {u'first_order_merge_test': {u'key_u': u'test2'}}}
    fact_cache_1.first_order_merge(u'ansible_local', host_facts_2[u'ansible_local'])

    # test: keyerror
   

# Generated at 2022-06-25 14:14:34.820800
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    display.banner('Test #1: FactCache class first_order_merge method - case 0: test with fact_cache_0')

    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge('test_case_0', {})

    display.display('Test #1: FactCache class first_order_merge method - case 0: test with fact_cache_0')
    display.display('    Expected: {}')
    display.display('    Actual: %s' % (fact_cache_0))



# Generated at 2022-06-25 14:14:41.790080
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    display.vvvv(u"TESTING: test_FactCache_first_order_merge")
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge(u"host1", {u"fact1": u"foo", u"fact2": u"bar"})

    assert fact_cache_1[u"host1"][u"fact1"] == u"foo", u"expected fact1 to be foo"
    assert fact_cache_1[u"host1"][u"fact2"] == u"bar", u"expected fact2 to be bar"


if __name__ == u'__main__':
    test_case_0()
    test_FactCache_first_order_merge()

# Generated at 2022-06-25 14:14:42.842891
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert isinstance(fact_cache_0, FactCache)


# Generated at 2022-06-25 14:14:51.018646
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge(key='host_1', value={'b': '1', 'g': '2'})
    fact_cache_1.first_order_merge(key='host_1', value={'c': '3', 'd': '4'})
    fact_cache_1.first_order_merge(key='host_1', value={'c': '5'})
    fact_cache_1.first_order_merge(key='host_2', value={'b': '1'})
    fact_cache_1.first_order_merge(key='host_2', value={'c': '3', 'd': '4'})

# Generated at 2022-06-25 14:14:53.166103
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        FC = FactCache()
        print("[PASS]: Constructor of class FactCache")
    except:
        print("[FAIL]: Constructor of class FactCache")


# Generated at 2022-06-25 14:15:02.115392
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    ctx = {'ANSIBLE_CACHE_ENABLED': False}
    ctx['ANSIBLE_CACHE_PLUGIN'] = 'memory'
    ctx['ANSIBLE_CACHE_PLUGIN_CONNECTION'] = ''
    fact_cache_obj = FactCache(ctx=ctx)
    fact_cache_obj.flush()
    key = 'hostname.example.com'

# Generated at 2022-06-25 14:15:03.552510
# Unit test for constructor of class FactCache
def test_FactCache():
    cache0 = FactCache()
    assert cache0.flush() is None # cache0.flush()

# Generated at 2022-06-25 14:15:05.180341
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert isinstance(fc, FactCache)
    assert isinstance(fc, MutableMapping)
