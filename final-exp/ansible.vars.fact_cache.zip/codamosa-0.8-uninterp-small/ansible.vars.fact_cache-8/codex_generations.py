

# Generated at 2022-06-25 14:05:23.976753
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    var_0 = fact_cache_0.__len__()

# Generated at 2022-06-25 14:05:25.907503
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        fact_cache_0 = FactCache()
    except ValueError or TypeError:
        pass


# Generated at 2022-06-25 14:05:35.622575
# Unit test for constructor of class FactCache
def test_FactCache():

    fact_cache_0 = FactCache()
    var_0 = fact_cache_0._plugin
    var_1 = fact_cache_0.__len__()
    fact_cache_0.__setitem__('key_0', 'value_0')
    var_2 = fact_cache_0.__getitem__('key_0')
    fact_cache_0.__delitem__('key_0')
    var_3 = fact_cache_0.__contains__('key_0')
    var_4 = fact_cache_0.__iter__()
    var_5 = fact_cache_0.keys()
    fact_cache_0.flush()
    var_6 = fact_cache_0.copy()
    fact_cache_0.first_order_merge('key_1', 'value_1')



# Generated at 2022-06-25 14:05:37.484351
# Unit test for constructor of class FactCache
def test_FactCache():
    FactCache()
    #assert True # TODO: implement your test here


# Generated at 2022-06-25 14:05:38.843296
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache



# Generated at 2022-06-25 14:05:39.925026
# Unit test for constructor of class FactCache
def test_FactCache():
    pass


# Generated at 2022-06-25 14:05:40.864946
# Unit test for constructor of class FactCache
def test_FactCache():
    var_0 = FactCache()


# Generated at 2022-06-25 14:05:42.415333
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0 is not None


# Generated at 2022-06-25 14:05:47.987747
# Unit test for constructor of class FactCache
def test_FactCache():
    #self ._plugin = CacheLoader (self).get(CACHE_PLUGIN)
    #if not self ._plugin:
        #raise AnsibleError('Unable to load the facts cache plugin (%s).' % (CACHE_PLUGIN))
    #super(FactCache, self).__init__(*args, **kwargs)
    fact_cache_1 = FactCache()
    var_1 = fact_cache_1.__len__()
    # FactCache::FactCache()
    #
    #assert(var_1 == 0)


# Generated at 2022-06-25 14:05:50.234894
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    var_0 = fact_cache_0.__len__()


# Generated at 2022-06-25 14:05:57.569704
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        test_case_0()
        print(Display.display_ok("passed test case: test_case_0"))
    except Exception as e:
        print(Display.display_error("failed test case: test_case_0: " + str(e)))

if __name__ == '__main__':
    test_FactCache()

# Generated at 2022-06-25 14:06:04.115843
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    host_key = 'localhost'
    host_value = {'ansible_os_family': 'RedHat', 'ansible_architecture': 'x86_64', 'ansible_distribution': 'CentOS', 'ansible_pkg_mgr': 'yum', 'ansible_distribution_major_version': '7'}
    fact_cache_0.first_order_merge(host_key, host_value)


# Generated at 2022-06-25 14:06:05.451490
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:06:07.177014
# Unit test for constructor of class FactCache
def test_FactCache():
    # Test for no parameter
    print('Start unit test for FactCache')
    test_case_0()

# Generated at 2022-06-25 14:06:08.882342
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache
    assert not fact_cache._plugin

# Generated at 2022-06-25 14:06:10.502056
# Unit test for constructor of class FactCache
def test_FactCache():
    with pytest.raises(AnsibleError):
        fact_cache = FactCache()


# Generated at 2022-06-25 14:06:12.314734
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    assert not fact_cache_0.first_order_merge(key='key', value='value')

# Generated at 2022-06-25 14:06:14.474720
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cachem_obj = FactCache()
    fact_cachem_obj.first_order_merge("key_value","value_value")

# Generated at 2022-06-25 14:06:17.010063
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge("key", "value")


# Generated at 2022-06-25 14:06:25.210739
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    key = '192.168.1.1'
    ansible_architecture = 'x86_64'
    ansible_machine = 'x86_64'
    ansible_machine_id = 'e2a1a2c2f367a80a33cd8c0b6fecb28a'
    ansible_os_family = 'RedHat'
    ansible_os_name = 'CentOS'
    ansible_os_version = '7.3.1611'
    ansible_pkg_mgr = 'yum'
    ansible_userspace_bits = '64'

# Generated at 2022-06-25 14:06:30.106671
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0 != None

# Generated at 2022-06-25 14:06:32.487607
# Unit test for constructor of class FactCache
def test_FactCache():
    import sys
    sys.path.append("..")
    from ansible.module_utils.facts.facts import FactCache
    fact_cache_0 = FactCache()
    assert fact_cache_0.copy() == {}, "Check if function returns empty dict for a new cache object"



# Generated at 2022-06-25 14:06:33.747667
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        FactCache()
    except NameError:
        assert True
    else:
        assert False

# Generated at 2022-06-25 14:06:35.501083
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        from pytest import raises
        assert raises(AnsibleError, test_case_0)
    except ImportError:
        # pytest not installed
        pass

# Generated at 2022-06-25 14:06:37.064962
# Unit test for constructor of class FactCache
def test_FactCache():
    result_0 = test_case_0()
    assert type(result_0) == FactCache



# Generated at 2022-06-25 14:06:39.109355
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0.__class__.__name__ == 'FactCache'


# Generated at 2022-06-25 14:06:47.022399
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    """ Test case to test first_order_merge method of class FactCache """
    fact_cache_0 = FactCache()
    list1 = [1,2,3,4]
    fact_cache_0.first_order_merge("list",list1)
    fact_cache_0.first_order_merge("dict",{'a':1})
    assert len(fact_cache_0.keys()) == 2
    assert fact_cache_0.keys()[0] == "list"
    assert fact_cache_0.keys()[1] == "dict"
    assert fact_cache_0['list'] == [1,2,3,4]
    assert fact_cache_0['dict']["a"] == 1
    print("test case passed")


# Generated at 2022-06-25 14:06:51.537408
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert hasattr(cache, '_plugin')
    assert hasattr(cache, '__getitem__')
    assert hasattr(cache, '__setitem__')
    assert hasattr(cache, '__delitem__')
    assert hasattr(cache, '__contains__')
    assert hasattr(cache, '__iter__')
    assert hasattr(cache, '__len__')
    assert hasattr(cache, 'copy')
    assert hasattr(cache, 'keys')
    assert hasattr(cache, 'flush')
    assert hasattr(cache, 'first_order_merge')

# Generated at 2022-06-25 14:07:01.896972
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_2 = FactCache()
    fact_cache_3 = FactCache()
    fact_cache_4 = FactCache()
    fact_cache_5 = FactCache()
    fact_cache_6 = FactCache()
    fact_cache_7 = FactCache()
    fact_cache_8 = FactCache()
    fact_cache_9 = FactCache()
    fact_cache_10 = FactCache()
    fact_cache_11 = FactCache()
    fact_cache_12 = FactCache()
    fact_cache_13 = FactCache()
    fact_cache_14 = FactCache()
    fact_cache_15 = FactCache()
    fact_cache_16 = FactCache()
    fact_cache_17 = FactCache()
    fact_cache_18 = FactCache()
   

# Generated at 2022-06-25 14:07:03.998179
# Unit test for constructor of class FactCache
def test_FactCache():
    # module_utils.common.cache_utils.FactCache.__init__()
    FactCache_obj = FactCache()
    print("Returning: {}".format(FactCache_obj))


# Generated at 2022-06-25 14:07:10.795148
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()

# Generated at 2022-06-25 14:07:15.834025
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    key = '192.168.0.1'
    value = dict()
    fact_cache.first_order_merge(key, value)
    assert fact_cache.get('192.168.0.1') == dict()



# Generated at 2022-06-25 14:07:25.013372
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    # Test 1
    display.banner(u"Test 1: Basic execution")
    local_facts = dict(fact0=u"value0", fact1=u"value1")
    new_facts = dict(fact0=u"new_value0", fact2=u"new_value1")
    expected_result = dict(fact0=u"new_value0", fact1=u"value1", fact2=u"new_value1")
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge(u"host0", local_facts)
    fact_cache_1.first_order_merge(u"host0", new_facts)
    assert fact_cache_1 == expected_result


if __name__ == u'__main__':
    test_FactCache_first

# Generated at 2022-06-25 14:07:28.065545
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache,MutableMapping) == True


# Generated at 2022-06-25 14:07:33.083631
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Create an instance of class FactCache with argument
    factCache = FactCache()
    # Create a tuple with two elements
    tup = ('key', 'val')

    # Create a dictionary
    d = {'key', 'val'}

    # Test method first_order_merge of class FactCache
    factCache.first_order_merge(tup)

# Generated at 2022-06-25 14:07:35.998147
# Unit test for constructor of class FactCache
def test_FactCache():
    display.info('')
    display.info('TEST: FactCache')
    fact_cache_0 = FactCache()
    display.info('SUCCESS: FactCache')


# Generated at 2022-06-25 14:07:37.298188
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()


# Generated at 2022-06-25 14:07:46.534093
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.setdefault('test_key', {})
    fact_cache_1.get('test_key').setdefault('test_key1', {})
    fact_cache_1.get('test_key').get('test_key1').setdefault('test_key2', 'test_value2')
    fact_cache_1.get('test_key').get('test_key1').setdefault('test_key3', 'test_value3')
    fact_cache_1.get('test_key').setdefault('test_key4', 'test_value4')

# Generated at 2022-06-25 14:07:48.729939
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()

    assert type(fact_cache) == FactCache
    assert fact_cache != None


# Generated at 2022-06-25 14:07:49.996656
# Unit test for constructor of class FactCache
def test_FactCache():
    # Test for constructor
    fact_cache = FactCache()

# Test for contains

# Generated at 2022-06-25 14:08:02.134200
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    return fact_cache


# Generated at 2022-06-25 14:08:10.423833
# Unit test for constructor of class FactCache
def test_FactCache():
    '''
    class FactCache(MutableMapping)
      |  A mutable mapping for storing fact cache data for hosts.
      |
      |  Method resolution order:
      |      FactCache
      |      MutableMapping
      |      BuiltinMapping
      |      abc.MutableMapping
      |      abc.Mapping
      |      abc.Container
      |      abc.Hashable
      |      abc.Iterable
      |      abc.Sized
      |      abc.Collection
      |      abc.InstrumentedAttribute
      |      object
      |
      |  Data and other attributes inherited from MutableMapping:
      |
      |  __hash__ = None

    '''

    fc0 = FactCache()

    assert fc0 == {}

# Generated at 2022-06-25 14:08:11.590811
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()


# Generated at 2022-06-25 14:08:12.617095
# Unit test for constructor of class FactCache
def test_FactCache():
    factCache = FactCache()


# Generated at 2022-06-25 14:08:18.260349
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    display.display("Unit test for method first_order_merge of class FactCache")
    fact_cache_1 = FactCache()
    assert fact_cache_1.__len__() == 0
    fact_cache_1.first_order_merge("gavin", {'ansible_facts': {'interfaces': ['br0', 'eth0']}})
    assert fact_cache_1.__len__() == 1

#test_case_0()
test_FactCache_first_order_merge()

# Generated at 2022-06-25 14:08:20.651071
# Unit test for constructor of class FactCache
def test_FactCache():
    facts_file = 'example.fact'
    assert FactCache.__init__(facts_file)

# Generated at 2022-06-25 14:08:21.675254
# Unit test for constructor of class FactCache
def test_FactCache():
    assert FactCache


# Generated at 2022-06-25 14:08:29.223293
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge('host1', {'a': '1'})
    fact_cache_1.first_order_merge('host1', {'b': '2'})
    fact_cache_1.first_order_merge('host1', {'c': '3'})

    assert fact_cache_1['host1'] == {'a': '1', 'b': '2', 'c': '3'}

# Generated at 2022-06-25 14:08:30.195777
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

# Generated at 2022-06-25 14:08:32.576363
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache

test_FactCache()
test_case_0()

# Generated at 2022-06-25 14:08:59.449090
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache
    assert isinstance(fact_cache, MutableMapping)

# Unit tests for set, get, delete methods of class FactCache

# Generated at 2022-06-25 14:09:04.186894
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()
    assert fact_cache_1._plugin.get_name() == "FactCacheBase"
    fact_cache_2 = FactCache()
    assert fact_cache_2._plugin.get_name() == "FactCacheBase"


# Generated at 2022-06-25 14:09:06.501831
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()

    # check for the content of is_valid_cache
    assert isinstance(fact_cache_1, FactCache)



# Generated at 2022-06-25 14:09:09.151369
# Unit test for constructor of class FactCache
def test_FactCache():
    # test constructor
    fact_cache_obj = FactCache()
    assert fact_cache_obj
    assert isinstance(fact_cache_obj, FactCache)
    assert isinstance(fact_cache_obj, MutableMapping)


# Generated at 2022-06-25 14:09:10.603298
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()
    print ("TEST OF FACT CACHE CLASS Successful")

# Generated at 2022-06-25 14:09:13.285564
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()
    test = dict(a = 1)
    fact_cache = FactCache(test)
    assertCachedFacts(fact_cache, test)


# Generated at 2022-06-25 14:09:14.884788
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()


if __name__ == '__main__':
    test_FactCache()

# Generated at 2022-06-25 14:09:19.363916
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Create a FactCache object
    fact_cache_0 = FactCache()
    # Call the method first_order_merge of the object
    try:
        result = fact_cache_0.first_order_merge()
    except NotImplementedError:
        result = None
    assert result is None

# Generated at 2022-06-25 14:09:21.390773
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()

    assert fact_cache_0 is not None

# Generated at 2022-06-25 14:09:23.179163
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache,FactCache)


# Generated at 2022-06-25 14:10:14.108903
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_0 = FactCache()
    assert isinstance(fact_cache_0, FactCache)

# Generated at 2022-06-25 14:10:19.001022
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    '''Test method first_order_merge in class FactCache'''
    # Init required params
    # Initialize class instance
    fact_cache_0 = FactCache()

    # Invoke method
    fact_cache_0.first_order_merge('hostvars')

    # Test member variables and methods
    assert(False)


# Generated at 2022-06-25 14:10:21.587815
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        fact_cache_1 = FactCache()
        assert 1
    except AssertionError:
        assert 0


# Generated at 2022-06-25 14:10:23.892602
# Unit test for constructor of class FactCache
def test_FactCache():
    test_case_0()

if __name__ == '__main__':
    test_FactCache()

# Generated at 2022-06-25 14:10:25.882527
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        fact_cache_0 = FactCache()
    except Exception:
        assert False
    else:
        assert True



# Generated at 2022-06-25 14:10:28.449549
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0._plugin == cache_loader.get(C.CACHE_PLUGIN) and fact_cache_0._plugin != None


# Generated at 2022-06-25 14:10:32.369366
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    key = ['hostname', '10.0.0.1']
    value = {'key1': 'value1', 'key2': 'value2'}

    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge(key, value)

    import pdb; pdb.set_trace()
    assert fact_cache_0[key] == value



# Generated at 2022-06-25 14:10:33.284785
# Unit test for constructor of class FactCache
def test_FactCache():
    assert False, 'Not Implemented'


# Generated at 2022-06-25 14:10:37.804685
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    fact_cache_1.first_order_merge('hostname', {'key1': 'value1', 'key2': 'value2'})
    fact_cache_1.first_order_merge('hostname2', {'key1': 'value1', 'key2': 'value2'})
    fact_cache_1.first_order_merge('hostname', {'key1': 'value1', 'key2': 'value2'})
    assert fact_cache_1['hostname'] != None


# Generated at 2022-06-25 14:10:39.909801
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_0 = FactCache()
    assert fact_cache_0._plugin is not None
    fact_cache_0._plugin.flush()


# Generated at 2022-06-25 14:12:32.315665
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Create object of class FactCache
    fact_cache = FactCache()
    fact_cache.first_order_merge(key = 'test_key', value = 'test_value')
    assert fact_cache.first_order_merge(key = 'test_key', value = 'test_value') == {'test_key': 'test_value'}

# Generated at 2022-06-25 14:12:34.106066
# Unit test for constructor of class FactCache
def test_FactCache():
    # Constructing tests -------
    retval = FactCache()
    # Testing with expected values -----------
    assert retval.keys() == None


test_FactCache()
test_case_0()

# Generated at 2022-06-25 14:12:35.441399
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_1 = FactCache()
    assert isinstance(fact_cache_1, FactCache)
    assert isinstance(fact_cache_1, MutableMapping)


# Generated at 2022-06-25 14:12:36.173401
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    test_case_0()


# Generated at 2022-06-25 14:12:37.966750
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # test case 0
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge(key='key_0', value='value_0')


# Generated at 2022-06-25 14:12:38.595310
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    test_case_0()

# Generated at 2022-06-25 14:12:39.594787
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None, "No object"


# Generated at 2022-06-25 14:12:40.012548
# Unit test for constructor of class FactCache
def test_FactCache():
    f = FactCache()

# Generated at 2022-06-25 14:12:43.775946
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    host_ip = "127.0.0.1"
    host_facts = {"ipv4": "192.168.0.10", "ipv6": "2001:db8::1"}
    fact_cache = FactCache()
    fact_cache.first_order_merge(host_ip, host_facts)
    assert fact_cache[host_ip] == host_facts

# Generated at 2022-06-25 14:12:46.133275
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        test_case_0()
        print("Test Case 0: Passed!")
    except:
        print("Test Case 0: Failed!")

if __name__ == "__main__":
    test_FactCache()

# Generated at 2022-06-25 14:15:13.585544
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    try:
        fact_cache['test_item'] = 'test_value'
        assert (fact_cache['test_item'] == 'test_value')
    finally:
        fact_cache.flush()

# Generated at 2022-06-25 14:15:14.319466
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()


# Generated at 2022-06-25 14:15:16.330675
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    display.info("TESTING: FactCache.first_order_merge")
    fact_cache_0 = FactCache()
    fact_cache_0.first_order_merge("foo", "bar")

# Generated at 2022-06-25 14:15:24.338312
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_1 = FactCache()
    # setup test
    fact_cache_1.flush()
    key_1 = 'key'
    value_1 = [1, 2, 3, 4]
    # call method
    fact_cache_1.first_order_merge(key_1, value_1)
    # assert results
    keys = list(fact_cache_1.keys())
    values = list(fact_cache_1.values())
    assert keys[0] == key_1
    assert list(values[0]) == value_1
#