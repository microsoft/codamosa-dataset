

# Generated at 2022-06-11 18:52:31.160122
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert isinstance(fc, FactCache)

# Generated at 2022-06-11 18:52:40.106367
# Unit test for constructor of class FactCache
def test_FactCache():
    import os
    import tempfile
    os.path.isfile = lambda filename: True
    os.path.isdir = lambda filename: True

    display.verbosity = 3
    display.color = 'black'
    display.pager = ''

    display.verbosity = 3
    display.color = 'black'
    display.pager = ''

    display.verbosity = 3
    display.color = 'black'
    display.pager = ''
    C.CACHE_PLUGIN = 'jsonfile'

    cache_loader.get('jsonfile')
    test_dir = tempfile.mkdtemp()
    C.DEFAULT_LOCAL_TMP = test_dir
    test_facts_cache = FactCache()
    key_1 = "test_key_1"

# Generated at 2022-06-11 18:52:41.186727
# Unit test for constructor of class FactCache
def test_FactCache():
    fc=FactCache()

# Generated at 2022-06-11 18:52:48.204000
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    key = "group1"
    first_value = {"var1": "hello"}
    fact_cache.__setitem__(key, first_value)
    second_value = {"var2": "world"}
    fact_cache.first_order_merge(key, second_value)
    final_cache = fact_cache.copy()
    assert final_cache[key]["var1"] == "hello"
    assert final_cache[key]["var2"] == "world"
    #TODO: test that the cache was also updated

# Generated at 2022-06-11 18:52:49.483443
# Unit test for constructor of class FactCache
def test_FactCache():
    factory = FactCache()
    assert factory != None

# Generated at 2022-06-11 18:52:52.240297
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None
    assert C.DEFAULT_CACHE_PLUGIN == 'memory'
    assert fact_cache._plugin is not None

# Generated at 2022-06-11 18:53:00.906509
# Unit test for constructor of class FactCache
def test_FactCache():
    from test.units.plugins.cache.test_module_utils.module_utils_fact_cache \
        import ModuleUtilsCachePlugin
    cache_plugin_config = {
        'CACHE_PLUGIN': 'test.units.plugins.cache.test_module_utils.module_utils_fact_cache.ModuleUtilsCachePlugin'
    }
    fact_cache = FactCache(
        config=cache_plugin_config,
        config_file='/tmp/ansible.cfg')
    assert fact_cache
    assert fact_cache._plugin
    assert isinstance(fact_cache._plugin, ModuleUtilsCachePlugin)


# Generated at 2022-06-11 18:53:07.393498
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    data = {'key_1': {'sub_key_1': 'sub_value_1'}}
    new_key = 'key_2'
    new_value = {'sub_key_1': 'sub_value_1'}
    obj = FactCache(data)
    obj.first_order_merge(new_key, new_value)
    assert obj.copy()[new_key] == new_value

# Generated at 2022-06-11 18:53:15.772616
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    z = {'a': 1, 'b': 2}
    y = {'c': 3, 'd': 4}
    x = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    fc = FactCache()
    fc.set('z', z)
    fc.first_order_merge('z', y)
    assert fc['z'] == x
    #assert fc['z'] = fc.get('z')
    #assert fc.get('z') == {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    #assert fc.get('z') == {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    fc.flush()
    assert not fc.__contains

# Generated at 2022-06-11 18:53:23.966901
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    test_fact_cache = FactCache()
    test_fact_cache.first_order_merge("localhost", {"key":"value"})
    assert test_fact_cache["localhost"] == {"key":"value"}

    test_fact_cache.first_order_merge("localhost", {"key":"value2"})
    assert test_fact_cache["localhost"] == {"key":"value2"}

    test_fact_cache.first_order_merge("localhost", {"key2":"value2"})
    assert test_fact_cache["localhost"] == {"key":"value2", "key2":"value2"}

# Generated at 2022-06-11 18:53:32.746852
# Unit test for constructor of class FactCache
def test_FactCache():
    key = 'localhost'
    value = {'ansible_architecture': 'x86_64'}
    fact_cache = FactCache()
    fact_cache.__setitem__(key, value)
    with fact_cache as fc:
        dict_copy = fc.copy()

    assert dict_copy['localhost']['ansible_architecture'] == 'x86_64'
    fact_cache.__delitem__(key)
    try:
        dict_copy = fact_cache.copy()
    except KeyError:
        assert True

    fact_cache.flush()

# Generated at 2022-06-11 18:53:35.043181
# Unit test for constructor of class FactCache
def test_FactCache():
    """
    Loads the module and asserts that the running objects are
    as expected.
    """

    # Get a simple cache object
    cache = FactCache()
    assert cache is not None

    # Get the plugin
    assert cache._plugin is not None
    assert cache._plugin.name == C.CACHE_PLUGIN

# Generated at 2022-06-11 18:53:38.041007
# Unit test for constructor of class FactCache
def test_FactCache():
    success = False

    try:
        fact_cache = FactCache()
    except:
        fact_cache = None

    if fact_cache is not None:
        success = True

    return success

# Generated at 2022-06-11 18:53:41.311317
# Unit test for constructor of class FactCache
def test_FactCache():

    fact_cache = FactCache()

    assert fact_cache


# Generated at 2022-06-11 18:53:46.409606
# Unit test for constructor of class FactCache
def test_FactCache():
    import pytest
    from ansible.plugins.cache import BaseCacheModule

    assert hasattr(FactCache, '__init__')
    assert hasattr(FactCache, '_plugin')

    with pytest.raises(AnsibleError) as exception_info:
        FactCache(cache_plugin=None)

    with pytest.raises(AnsibleError) as exception_info:
        class cache_plugin(BaseCacheModule):
            pass
        FactCache(cache_plugin=cache_plugin)


# Generated at 2022-06-11 18:53:57.253061
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # all host facts are merged except ansible_env which is overwritten
    # ansible_env is present in "value" and "host_facts".
    # ansible_env is not present in "host_cache"
    # ansible_env is not present in "self"
    # assert that ansible_env is overwritten with the value of "value"
    # and not merged with the value of "host_cache"

    class Plugin:
        def contains(self, key):
            return True

        def get(self, key):
            return {"ansible_facts": {"ansible_env": {"PATH": "/usr/local/bin"}}}

        def set(self, key, value):
            pass

        def delete(self, key):
            pass

        def keys(self):
            return []

        def flush(self):
            pass

# Generated at 2022-06-11 18:54:00.576176
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert isinstance(cache, FactCache)
    try:
        cache = FactCache('localhost', port=1111)
    except AnsibleError as e:
        assert e

# Generated at 2022-06-11 18:54:05.406085
# Unit test for constructor of class FactCache
def test_FactCache():

    try:
        cache = FactCache()
        assert cache
    except AnsibleError:
        display.error("Unable to load the fact cache plugin (%s)." % (C.CACHE_PLUGIN))



# Generated at 2022-06-11 18:54:06.723207
# Unit test for constructor of class FactCache
def test_FactCache():
    fcache = FactCache()
    assert isinstance(fcache, FactCache)

# Generated at 2022-06-11 18:54:08.981414
# Unit test for constructor of class FactCache
def test_FactCache():
    C.CACHE_PLUGIN = 'jsonfile'
    fact_cache = FactCache()
    assert(isinstance(fact_cache._plugin, cache_loader.get('jsonfile')))

# Generated at 2022-06-11 18:54:13.192352
# Unit test for constructor of class FactCache
def test_FactCache():
    # Set the cache plugin to be redis
    C.CACHE_PLUGIN = 'redis'
    # Create an instance of FactCache
    cache = FactCache()
    assert(cache.__class__.__name__ == 'FactCache')

# Generated at 2022-06-11 18:54:14.601642
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-11 18:54:17.570777
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    fc["test"] = '{"test": "test"}'
    assert fc.keys()
    fc.flush()
    assert not fc

# Generated at 2022-06-11 18:54:18.941653
# Unit test for constructor of class FactCache
def test_FactCache():
    f = FactCache()
    assert f

# Generated at 2022-06-11 18:54:29.117230
# Unit test for constructor of class FactCache
def test_FactCache():

    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultLib

    from io import BytesIO

    display_fd = BytesIO()
    display.display = lambda msg, *args, **kwargs: display_fd.write(to_bytes(msg, errors='strict'))

    basic._ANSIBLE_ARGS = None
    import ansible.config.manager

    conf_manager = ansible.config.manager.ConfigManager(basic._ANSIBLE_ARGS)
    conf_manager.load()

    vault_secret = 'test_Fixture__Vault__Secret'
    vault_password_file = 'test_Fixture__Vault__Password_File'
    vault_id = 'test_Fixture__Vault__Id'

# Generated at 2022-06-11 18:54:36.281592
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    key1 = "key1"
    key2 = "key2"
    val1 = "val1"
    val2 = "val2"
    cache.first_order_merge(key1, val1)
    assert cache.get(key1) == val1, "Test case for dict with key not present failed"
    cache.first_order_merge(key1, val2)
    assert cache.get(key1) == val2, "Test case for dict with key present failed"
    assert cache.get(key2) == None, "Test case for unseen key failed"

test_FactCache_first_order_merge()

# Generated at 2022-06-11 18:54:42.984195
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    host_facts = {"ansible_lsb_distrib_release": "14.04", "ansible_distribution": "Ubuntu"}
    host_facts_update = {"ansible_lsb_distrib_id": "Ubuntu", "ansible_distribution_release": "trusty", "ansible_distribution_version": "14.04"}
    expected_host_facts = {"ansible_lsb_distrib_release": "14.04", "ansible_distribution": "Ubuntu", "ansible_distribution_release": "trusty", "ansible_distribution_version": "14.04"}
    test_cache = FactCache()
    test_cache.first_order_merge("ubuntu", host_facts)
    test_cache.first_order_merge("ubuntu", host_facts_update)

# Generated at 2022-06-11 18:54:51.846891
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    class FakePlugin():
        def __init__(self, cache={}):
            self.cache = cache

        def keys(self):
            return self.cache.keys()

        def get(self, key):
            return self.cache[key]

        def set(self, key, value):
            self.cache[key] = value

        def delete(self, key):
            del self.cache[key]

        def contains(self, key):
            return key in self.cache

        def flush(self):
            self.cache = {}

    cache = {
        'foo': {
            'a': 1,
            'b': 2,
            'c': 3
        }
    }

    plugin = FakePlugin(cache=cache)
    facts = FactCache(plugin=plugin)

# Generated at 2022-06-11 18:55:00.970504
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    facts_cache = FactCache()

# Generated at 2022-06-11 18:55:03.685284
# Unit test for constructor of class FactCache
def test_FactCache():
    C.CACHE_PLUGIN = 'memory'
    fact_cache = FactCache()
    return fact_cache


# Generated at 2022-06-11 18:55:07.382055
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert(fc is not None)

# Generated at 2022-06-11 18:55:08.395098
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()

    assert fact_cache is not None

# Generated at 2022-06-11 18:55:18.324415
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    key = "host1"
    c = FactCache()
    c.flush()
    assert not c.__contains__(key)
    assert key not in c
    assert len(c) == 0

    first_value = {"a": 1, "b": 2}
    c.first_order_merge(key, first_value)
    assert c.__contains__(key)
    assert key in c
    assert len(c) == 1

    second_value = {"b": 10, "c": 30}
    c.first_order_merge(key, second_value)
    assert c.__contains__(key)
    assert key in c
    assert len(c) == 1
    merged = c[key]
    assert len(merged) == 3
    assert merged["a"] == 1

# Generated at 2022-06-11 18:55:22.652991
# Unit test for constructor of class FactCache
def test_FactCache():

    """
        Unit test for constructor of class FactCache.
        Checks that an error is raised when a non existing plugin is given as parameter.
    """

    try:
        facts_cache = FactCache(C.CACHE_PLUGIN)
    except AnsibleError:
        assert True

# Generated at 2022-06-11 18:55:24.219341
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.plugins.cache import base

    base.BaseCache()

# Generated at 2022-06-11 18:55:30.742395
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    dict1 = dict()
    dict2 = dict()
    fc = FactCache(dict1)
    fc.first_order_merge('host1', dict2)
    assert dict1 == {'host1': dict2}
    dict2['var1'] = 'value1'
    dict1 = dict()
    dict1['host1'] = dict()
    fc = FactCache(dict1)
    fc.first_order_merge('host1', dict2)
    assert dict1['host1'] == dict2


# Generated at 2022-06-11 18:55:32.288438
# Unit test for constructor of class FactCache
def test_FactCache():
    fcache = FactCache()
    assert fcache is not None

# Generated at 2022-06-11 18:55:42.960306
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    def test_fact_cache_merge_host_cache_exists():
        host_facts = {u'ansible_facts': {u'fact1': u'value1'}}
        host_cache = {u'ansible_facts': {u'fact2': u'value2'}}
        test_host_name = u'hostname'
        test_cache = {test_host_name: host_cache}
        cache_loader._fact_cache = test_cache

        actual_fact_cache = FactCache()
        actual_fact_cache.first_order_merge(test_host_name, host_facts)
        expected_fact_cache = {test_host_name: {u'fact1': u'value1', u'fact2': u'value2'}}

        assert actual_fact_cache == expected_fact_

# Generated at 2022-06-11 18:55:43.453420
# Unit test for constructor of class FactCache
def test_FactCache():
    print(FactCache)

# Generated at 2022-06-11 18:55:52.697804
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    factcache = FactCache()
    factcache.first_order_merge('host1', {'fact1': 'value1'})
    factcache.first_order_merge('host2', {'fact2': 'value2'})
    factcache.first_order_merge('host2', {'fact2': 'value22', 'fact3': 'value3'})

    assert factcache.__len__() == 2
    assert factcache.__getitem__('host1') == {'fact1': 'value1'}
    assert factcache.__getitem__('host2') == {'fact2': 'value22', 'fact3': 'value3'}

if __name__ == '__main__':
    test_FactCache_first_order_merge()

# Generated at 2022-06-11 18:55:57.816624
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache

# Generated at 2022-06-11 18:55:58.795378
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()


# Generated at 2022-06-11 18:56:00.654968
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache


# Unit tests for class FactCache

# Generated at 2022-06-11 18:56:02.207456
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()


# Generated at 2022-06-11 18:56:10.298021
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    # Prepare a fact cache
    fact_cache = FactCache()
    host_facts = {
        'test_host': {
            'test_fact1': 'test_value1',
            'test_fact2': 'test_value2',
            'test_fact3': 'test_value3'
        }
    }

    # Update the fact cache with original data
    fact_cache.update(host_facts)

    # Change a value and update the fact cache again
    host_facts_upd = {
        'test_host': {
            'test_fact1': 'test_value1_upd',
            'test_fact4': 'test_value4'
        }
    }
    fact_cache.update(host_facts_upd)

    # Expected output after the first_order_merge
    host

# Generated at 2022-06-11 18:56:10.994562
# Unit test for constructor of class FactCache
def test_FactCache():
    assert isinstance(FactCache(), FactCache)



# Generated at 2022-06-11 18:56:13.122830
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache

# Generated at 2022-06-11 18:56:13.847676
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert isinstance(fc, MutableMapping)

# Generated at 2022-06-11 18:56:16.377620
# Unit test for constructor of class FactCache
def test_FactCache():
    results = {}
    fact_cache = FactCache()
    fact_cache["localhost"] = results
    # Check that the value was added
    assert fact_cache["localhost"] == results


# Generated at 2022-06-11 18:56:19.930793
# Unit test for constructor of class FactCache
def test_FactCache():
    # set a plugin
    C.CACHE_PLUGIN = 'memory'
    assert C.CACHE_PLUGIN == 'memory'

    # create an instance of class FactCache
    me = FactCache()

    assert C.CACHE_PLUGIN == me._plugin.get_name()

# Generated at 2022-06-11 18:56:36.053433
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_obj = FactCache()

    host_name = "host_name"
    value1 = {"key1": "value1"}
    value2 = {"key2": "value2"}
    fact_cache_obj.first_order_merge(host_name, value1)
    assert host_name in fact_cache_obj
    assert fact_cache_obj[host_name].get('key1') == value1.get('key1')
    fact_cache_obj.first_order_merge(host_name, value2)
    assert host_name in fact_cache_obj
    assert fact_cache_obj[host_name].get('key2') == value2.get('key2')

# Generated at 2022-06-11 18:56:36.954137
# Unit test for constructor of class FactCache
def test_FactCache():
    x = FactCache()
    assert x

# Generated at 2022-06-11 18:56:40.199124
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('key', {'fact': 'value'})
    assert fact_cache['key']['fact'] == 'value'

# Generated at 2022-06-11 18:56:47.959620
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    host1_facts = {'fact1': 'val1', 'fact2': 'val2'}
    host2_facts = {'fact3': 'val3', 'fact4': 'val4'}
    host3_facts = {'fact1': 'val1', 'fact2': 'val2', 'fact3': 'val3', 'fact4': 'val4'}

    fact_cache.first_order_merge('host1', host1_facts)
    fact_cache.first_order_merge('host2', host2_facts)
    fact_cache.first_order_merge('host3', host3_facts)
    fact_cache.flush()

    assert 'host1' in fact_cache
    assert 'host2' in fact_cache
    assert 'host3'

# Generated at 2022-06-11 18:56:49.403548
# Unit test for constructor of class FactCache
def test_FactCache():
    assert FactCache is not None

if __name__ == '__main__':
    print(test_FactCache())

# Generated at 2022-06-11 18:56:50.338910
# Unit test for constructor of class FactCache
def test_FactCache():
    FactCache()

# Generated at 2022-06-11 18:56:52.230001
# Unit test for constructor of class FactCache
def test_FactCache():

    cache_plugin = cache_loader.get('jsonfile')
    cache = FactCache(cache_plugin)

    assert cache._plugin == cache_plugin

# Generated at 2022-06-11 18:56:53.778625
# Unit test for constructor of class FactCache
def test_FactCache():
    a_fact_cache = FactCache()
    assert a_fact_cache is not None


# Generated at 2022-06-11 18:57:01.374478
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('key', {'a': 'foo'})
    assert fact_cache.get('key') == {'a': 'foo'}
    fact_cache.first_order_merge('key', {'b': 'bar'})
    assert fact_cache.get('key') == {'a': 'foo', 'b': 'bar'}
    fact_cache.first_order_merge('key1', {'c': 'baz'})
    assert fact_cache.get('key1') == {'c': 'baz'}

# Generated at 2022-06-11 18:57:11.164665
# Unit test for constructor of class FactCache
def test_FactCache():
    import unittest
    import os
    import shutil
    import tempfile
    import json

    class TestFactCache(unittest.TestCase):

        @classmethod
        def setUpClass(self):
            self.under_test = FactCache()
            self.under_test["localhost"] = {"ansible_test": 1}

        @classmethod
        def tearDownClass(self):
            self.under_test.flush()

        def test_FactCache_keys(self):
            self.assertTrue("localhost" in self.under_test.keys())
            self.assertFalse("unknown" in self.under_test.keys())

        def test_FactCache_getitem(self):
            self.assertTrue("localhost" in self.under_test)

        def test_FactCache_delitem(self):
            del self

# Generated at 2022-06-11 18:57:41.358366
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.module_utils.facts.virtual import VirtualCollector
    my_cache = FactCache()
    print(my_cache.copy())
    keys = my_cache.keys()
    print(keys)
    my_cache['test'] = 'test'
    print(my_cache.copy())
    my_cache.flush()
    print(my_cache.copy())
    virtual = VirtualCollector()
    virtual.populate()
    display.display(virtual.facts['virtualization_type'])
    display.display(virtual.facts['virtualization_role'])


# Generated at 2022-06-11 18:57:43.372090
# Unit test for constructor of class FactCache
def test_FactCache():
    FactCache()

# Generated at 2022-06-11 18:57:44.304487
# Unit test for constructor of class FactCache
def test_FactCache():
    assert isinstance(FactCache(), FactCache)

# Generated at 2022-06-11 18:57:45.890643
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert(isinstance(fact_cache, FactCache))


# Generated at 2022-06-11 18:57:48.766013
# Unit test for constructor of class FactCache
def test_FactCache():
    cache_dir = '/home/foo/.ansible/fact_cache/'
    cache = FactCache(cache_dir)

# Unit tests for methods setitem, getitem, and len of class FactCache

# Generated at 2022-06-11 18:57:54.198966
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    fact_cache['localhost'] = {'fact1': 'fact1'}
    assert fact_cache['localhost'] == {'fact1': 'fact1'}
    del fact_cache['localhost']
    assert not 'localhost' in fact_cache
    assert len(fact_cache) == 0
    assert fact_cache.keys() == []

# Generated at 2022-06-11 18:58:01.740254
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_native

    fact_cache = FactCache()
    try:
        from importlib import reload
    except ImportError:
        # PY2
        reload(basic)

    # Create an instance of a module_utils.basic.AnsibleModule
    # to patch the correct methods with our test methods.
    tmp = basic.AnsibleModule(argument_spec={}, supports_check_mode=True)
    tmp.fail_json = lambda *args, **kw: [(args, kw)]

    # Update this function with tmp.fail_json
    basic.AnsibleModule.fail_json = tmp.fail_json

    # Wrap basic.AnsibleModule.get_bin_path
    get_bin_path = tmp.get_bin_

# Generated at 2022-06-11 18:58:02.643399
# Unit test for constructor of class FactCache
def test_FactCache():
    assert isinstance(FactCache(), FactCache)

# Generated at 2022-06-11 18:58:03.189991
# Unit test for constructor of class FactCache
def test_FactCache():
    pass

# Generated at 2022-06-11 18:58:03.724156
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    pass

# Generated at 2022-06-11 18:59:02.004604
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
     """ Using values from the Ansible inventory, test if calling
     method first_order_merge has the desired effect.
     """

     # Create a fact_cache object
     fact_cache = FactCache()

     # The test data is taken from the Ansible inventory for the
     # first 3 hosts

# Generated at 2022-06-11 18:59:02.865174
# Unit test for constructor of class FactCache
def test_FactCache():
    pass

# Generated at 2022-06-11 18:59:04.138997
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache(None, None, None)
    assert fact_cache._plugin

# Generated at 2022-06-11 18:59:05.236259
# Unit test for constructor of class FactCache
def test_FactCache():
    assert FactCache(foo='bar') == {'foo':'bar'}

# Generated at 2022-06-11 18:59:07.806839
# Unit test for constructor of class FactCache
def test_FactCache():
    loader = cache_loader.get(C.CACHE_PLUGIN)
    fact = FactCache()
    assert fact._plugin == loader

# Generated at 2022-06-11 18:59:09.582855
# Unit test for constructor of class FactCache
def test_FactCache():
    """ Test for constructor for class FactCache """
    fact_cache = FactCache()
    assert fact_cache is not None


# Generated at 2022-06-11 18:59:10.038617
# Unit test for constructor of class FactCache
def test_FactCache():
    pass

# Generated at 2022-06-11 18:59:12.491891
# Unit test for constructor of class FactCache
def test_FactCache():
    """
    Test function to validate the constructor
    :return:
    """

    factcache_obj = FactCache()
    assert factcache_obj is not None

# Generated at 2022-06-11 18:59:16.810489
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    # In order to avoid false-negative results, the assertion below should
    # be updated as soon as the code of the plugin is truly tested.
    # See https://github.com/ansible/ansible/issues/34406
    assert fact_cache._plugin

# Generated at 2022-06-11 18:59:25.672711
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.plugins.cache.memory import CacheModule as MemoryCacheModule
    from ansible.plugins.cache.redis import CacheModule as RedisCacheModule
    from ansible.plugins.cache.jsonfile import CacheModule as JsonfileCacheModule
    from ansible.plugins.cache.yaml import CacheModule as YamlCacheModule
    import pytest
    import sys

    C.CACHE_PLUGIN = 'memory'
    if sys.version_info < (3, 0):
        reload(cache_loader)
    else:
        import importlib
        importlib.reload(cache_loader)
    fact_cache = FactCache()
    assert isinstance(fact_cache._plugin, MemoryCacheModule)
    fact_cache.flush()

    C.CACHE_PLUGIN = 'redis'

# Generated at 2022-06-11 19:01:19.523012
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        fact_cache = FactCache()
    except Exception as e:
        assert 0, "fact_cache constructor call failed with error {}".format(str(e))

# Generated at 2022-06-11 19:01:20.349042
# Unit test for constructor of class FactCache
def test_FactCache():
    assert 'FactCache' in globals()

# Generated at 2022-06-11 19:01:28.958380
# Unit test for constructor of class FactCache
def test_FactCache():
    def get(self):
        return self
    def contains(self, key):
        return True
    def set(self, key, value):
        return True
    def delete(self, key):
        return True
    def flush(self):
        return True
    def keys(self):
        return True
    # mock api
    C.CACHE_PLUGIN = 'Test'
    cache_loader.__cache[C.CACHE_PLUGIN] = [get, contains, set, delete, flush, keys]
    f = FactCache()
    assert f.contains(True) == True

# Generated at 2022-06-11 19:01:30.660207
# Unit test for constructor of class FactCache
def test_FactCache():
    # Given
    C.CACHE_PLUGIN = "test"

    # When
    fact_cache = FactCache()

    # Then


# Generated at 2022-06-11 19:01:32.067775
# Unit test for constructor of class FactCache
def test_FactCache():
    obj = FactCache()


# Generated at 2022-06-11 19:01:33.597844
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None
    assert isinstance(fact_cache, MutableMapping)

# Generated at 2022-06-11 19:01:34.635939
# Unit test for constructor of class FactCache
def test_FactCache():

    fact_cache = FactCache()

    assert fact_cache

    assert fact_cache._plugin is not None


# Generated at 2022-06-11 19:01:35.015805
# Unit test for constructor of class FactCache
def test_FactCache():
    FactCache()

# Generated at 2022-06-11 19:01:39.506057
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        cache = FactCache()
        raise Exception("Failed to get fact cache plugin")
    except AnsibleError as e:
        print(e)
        if e.message == 'Unable to load the facts cache plugin (jsonfile).':
            C.CACHE_PLUGIN = "jsonfile"
        else:
            raise e
    cache = FactCache()
    print("Successfully got fact cache plugin")

# Generated at 2022-06-11 19:01:43.260388
# Unit test for constructor of class FactCache
def test_FactCache():
    factCache = FactCache()
