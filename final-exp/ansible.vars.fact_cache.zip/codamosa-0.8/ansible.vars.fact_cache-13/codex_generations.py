

# Generated at 2022-06-11 18:52:39.751282
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    test_fact_cache = FactCache({"test_key": "test_value"})
    assert "test_key" in test_fact_cache
    assert test_fact_cache["test_key"] == "test_value"
    test_fact_cache.first_order_merge("test_key", "new_value")
    assert test_fact_cache["test_key"] == "new_value"
    test_fact_cache.first_order_merge("new_key", "new_value")
    assert test_fact_cache["new_key"] == "new_value"
    test_fact_cache.flush()
    assert not test_fact_cache

# Generated at 2022-06-11 18:52:46.132342
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc.first_order_merge('h1',{'f1':'v1', 'f2':'v2'})
    fc.first_order_merge('h1',{'f3':'v3', 'f4':'v4'})
    assert fc['h1'] == {'f1':'v1', 'f2':'v2','f3':'v3', 'f4':'v4'}

# Generated at 2022-06-11 18:52:47.700423
# Unit test for constructor of class FactCache
def test_FactCache():
    pass

# Generated at 2022-06-11 18:52:51.336172
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc.first_order_merge('host1', {'a': 1})
    fc.first_order_merge('host1', {'b': 2})

    assert fc['host1'] == {'a': 1, 'b': 2}

# Generated at 2022-06-11 18:52:55.119154
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None
    fact_cache.flush()
    fact_cache['key'] = 'value'
    assert fact_cache['key'] == 'value'
    fact_cache.flush()

# Generated at 2022-06-11 18:52:57.847425
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache(cache_plugin='memory')
    assert 'memory' == fact_cache._plugin._plugin_name


# Generated at 2022-06-11 18:53:01.714073
# Unit test for constructor of class FactCache
def test_FactCache():
    import ansible.plugins.cache.jsonfile
    cache_loader.cache_basedir = None
    cache_loader.cache_files = None
    facts = FactCache()
    assert isinstance(facts, FactCache)
    assert facts._plugin is not None
    assert isinstance(facts._plugin, ansible.plugins.cache.jsonfile.CacheModule)

# Generated at 2022-06-11 18:53:12.299568
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import os
    import tempfile

    from ansible.plugins.loader import cache_loader
    from ansible.plugins.cache import fact_cache

    plugin = cache_loader.get("jsonfile")
    path = os.path.join(tempfile.mkdtemp(prefix='ansible_fact_cache-'), 'facts.json')

    os.mkdir(os.path.dirname(path))
    cache = fact_cache.FactCache(*[], **{'_plugin': plugin(**{'_cache_dir': os.path.dirname(path)})})
    assert 'test_host' not in cache

    cache.first_order_merge('test_host', {'existing_fact': 'value'})
    assert cache['test_host']['existing_fact'] == 'value'

    cache.first_order_mer

# Generated at 2022-06-11 18:53:23.523534
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    mock_host_cache = { 'key' : 'value' }
    mock_host_facts = { 'key2' : 'value2' }

    mock_fact_cache = FactCache()
    mock_fact_cache._plugin = MagicMock(autospec=True)

    # Test when fact cache doesn't already have host cache
    mock_fact_cache._plugin.contains.return_value = False
    mock_fact_cache._plugin.get.return_value = None
    mock_fact_cache._plugin.set.return_value = True
    mock_fact_cache.update = MagicMock()

    mock_fact_cache.first_order_merge(mock_host_facts.keys()[0], mock_host_facts.values()[0])

    mock_fact_cache._plugin.get.assert_called_

# Generated at 2022-06-11 18:53:32.939416
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    fact_cache = FactCache()

    host_cache = {
        'currently': {
            'in': {
                'the': 'nested',
                'dictionary': 'we',
                'expect': 'to see'
            },
            'in': {
                'the': 'top-level',
                'dictionary': 'a',
                'new': 'value'
            }
        }
    }

    fact_cache._plugin.set('currently', host_cache['currently'])

    host_facts = {
        'currently': {
            'in': {
                'the': 'top-level',
                'dictionary': 'a',
                'new': 'value'
            }
        }
    }

    fact_cache.first_order_merge('currently', host_facts['currently'])

    expected

# Generated at 2022-06-11 18:53:36.832352
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache, "FactCache object is not created."

# Generated at 2022-06-11 18:53:46.725668
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Create new FactCache object, to be tested
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_key', {'test_value': 'test_value'})

    # Assert test_value is in fact_cache
    assert fact_cache['test_key']['test_value'] == 'test_value'

    # Merge a list into the fact_cache
    fact_cache.first_order_merge('test_key', {'test_list': ['a', 'b']})

    # assert that the test_list is set in the fact_cache and contains two elements
    assert fact_cache['test_key']['test_list'] == ['a', 'b']
    assert len(fact_cache['test_key']['test_list']) == 2

    # Merge a list into

# Generated at 2022-06-11 18:53:50.104828
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    display.verbosity = 3
    facts_cache_info = FactCache()
    facts_cache_info.first_order_merge('192.168.0.12', {'foo': 'bar'})
    print(facts_cache_info)



# Generated at 2022-06-11 18:53:52.187129
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        f = FactCache()
    except:
        print('Constructor test failed')

# Generated at 2022-06-11 18:53:53.140307
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache

# Generated at 2022-06-11 18:53:58.817068
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    factcache = FactCache()
    factcache.first_order_merge('host1', {u'foo': u'bar'})
    factcache.first_order_merge('host1', {u'bar': u'foo'})
    assert factcache['host1']['foo'] == u'bar'
    assert factcache['host1']['bar'] == u'foo'
    assert len(factcache['host1']) == 2



# Generated at 2022-06-11 18:54:09.278629
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    facts = {
        "items": {
            "0": {
                "a": 1,
                "b": 2,
            },
            "1": {
                "a": 3,
                "b": 4,
            },
        }
    }

    # Initialize cache with first facts object
    fact_cache.first_order_merge("localhost", facts)

    # Prepare second facts object, which has one item more
    # in the fact but with same keys as before

# Generated at 2022-06-11 18:54:19.990064
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Test 1: Adding facts that do not overlap with an already existing entry
    factcache = FactCache()
    existing_cache = {'test': 'a', 'test2': 'b'}
    new_cache = {'test2': 'b', 'test3': 'c'}
    factcache._plugin = MockFactCachePlugin(existing_cache)
    factcache.first_order_merge('hostname', new_cache)
    # Verify that _plugin.set is called with the correct host and facts
    assert factcache._plugin._set_arg == ('hostname', {'test': 'a', 'test2': 'b', 'test3': 'c'})
    # Verify that _plugin.set is called exactly once
    assert factcache._plugin._set_count == 1
    # Reset counters

# Generated at 2022-06-11 18:54:23.159748
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()

    if not isinstance(cache, FactCache):
        raise AssertionError("Type of the cache is not the expected one")



# Generated at 2022-06-11 18:54:33.122434
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.flush()
    assert len(fact_cache.keys()) == 0

    # Test add facts
    fact_cache.first_order_merge('foo.example.com', {'ansible_facts': {'foo': 'bar'}})
    assert len(fact_cache.keys()) == 1
    assert fact_cache['foo.example.com']['ansible_facts']['foo'] == 'bar'

    # Test update facts
    fact_cache.first_order_merge('foo.example.com', {'ansible_facts': {'foo': 'baz'}})
    assert len(fact_cache.keys()) == 1
    assert fact_cache['foo.example.com']['ansible_facts']['foo'] == 'baz'

    # Test

# Generated at 2022-06-11 18:54:45.829299
# Unit test for constructor of class FactCache
def test_FactCache():
    from collections import MutableMapping
    from ansible.errors import AnsibleError
    import ansible.constants as C
    from ansible.plugins.loader import cache_loader

    class TestCachePlugin:
        def __init__(self, *args, **kwargs):
            pass

        def contains(self, key):
            return True

        def get(self, key):
            return 'test'

        def set(self, key, value):
            pass

        def delete(self, key):
            pass

        def flush(self):
            pass

        def keys(self):
            return ['key']

    try:
        cache_loader.get(C.CACHE_PLUGIN)
    except AnsibleError:
        cache_loader.add(C.CACHE_PLUGIN, TestCachePlugin)

    fact

# Generated at 2022-06-11 18:54:48.649129
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    CACHE = dict()
    KEY = "key"
    VALUE = "value"

    fact_cache = FactCache()
    fact_cache._plugin = MockCache()
    fact_cache.first_order_merge(KEY, VALUE)

    assert CACHE[KEY] == VALUE


# Generated at 2022-06-11 18:54:51.175761
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, MutableMapping)
    assert fact_cache._plugin
    assert fact_cache._plugin.keys() == []
    fact_cache = None


# Generated at 2022-06-11 18:54:52.884351
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    display.display('FactCache: ' + str(fc))

# Generated at 2022-06-11 18:54:55.052666
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        FactCache()
        assert False
    except AnsibleError as e:
        assert 'the facts cache plugin' in str(e)

# Generated at 2022-06-11 18:54:57.639850
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert isinstance(cache, FactCache)
    assert cache._plugin.name == C.CACHE_PLUGIN

# Generated at 2022-06-11 18:54:58.556216
# Unit test for constructor of class FactCache
def test_FactCache():
    f = FactCache()
    assert f._plugin is not None
    assert f._plugin

# Generated at 2022-06-11 18:54:59.480069
# Unit test for constructor of class FactCache
def test_FactCache():
    # Constructor
    fact_cache = FactCache()
    assert fact_cache

# Generated at 2022-06-11 18:55:03.753528
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    """ Test first_order_merge for { 'host': { 'key': 'value' } } """
    expected = {'host': {'key': 'value'}}
    actual = FactCache()
    actual.first_order_merge("host", {'key': 'value'})
    assert expected == actual

# Generated at 2022-06-11 18:55:10.303926
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    factcache = False
    try:
        from ansible.plugins.loader import cache_loader
        factcache = cache_loader.get(C.CACHE_PLUGIN)
    except:
        pass
    if not factcache:
        raise Exception('Unable to load the facts cache plugin (%s).' % (C.CACHE_PLUGIN))

    factcache.flush()
    factcache_obj = FactCache()

    assert 'test-host' not in factcache_obj
    assert 'test-host' not in factcache
    assert factcache_obj.first_order_merge('test-host', {'ansible_facts': 'bar'}) == None
    assert factcache_obj['test-host']['ansible_facts'] == 'bar'
    assert 'test-host' in factcache
    assert fact

# Generated at 2022-06-11 18:55:17.697792
# Unit test for constructor of class FactCache
def test_FactCache():
    facts = FactCache()
    assert isinstance(facts, MutableMapping)


# Generated at 2022-06-11 18:55:18.149917
# Unit test for constructor of class FactCache
def test_FactCache():
    pass

# Generated at 2022-06-11 18:55:20.158962
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin, "Unable to load the FactsCache"

# Generated at 2022-06-11 18:55:21.596774
# Unit test for constructor of class FactCache
def test_FactCache():
    FactCache()


# Generated at 2022-06-11 18:55:23.973985
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None


# Unit test to see if first_order_merge works

# Generated at 2022-06-11 18:55:25.178045
# Unit test for constructor of class FactCache
def test_FactCache():
    # Create an instance of FactCache
    f = FactCache()

# Generated at 2022-06-11 18:55:27.914394
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc.get("local1") is None
    assert fc.get("local2") is None


# Generated at 2022-06-11 18:55:34.331094
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible import constants as C
    from ansible.plugins.loader import cache_loader
    from ansible.utils.display import Display

    # Create an instance of Display class
    display = Display()

    fact_cache = FactCache()

    # Create an instance of class cache_loader
    plugin = cache_loader.get(C.CACHE_PLUGIN)
    if not plugin:
        raise AnsibleError('Unable to load the facts cache plugin (%s).' % (C.CACHE_PLUGIN))

    # Create a dictionary

# Generated at 2022-06-11 18:55:44.116304
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    keys = []
    host_facts = []
    key = '172.16.1.2'
    keys.append(key)
    value = {u'hostname': u'host1.example.org', u'fqdn': u'host1.example.org'}
    host_facts.append(value)
    key = '172.16.1.3'
    keys.append(key)
    value = {u'hostname': u'host2.example.org', u'fqdn': u'host2.example.org'}
    host_facts.append(value)
    fact_cache.first_order_merge(keys[0], host_facts[0])
    fact_cache.first_order_merge(keys[1], host_facts[1])


# Generated at 2022-06-11 18:55:44.900311
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin

# Generated at 2022-06-11 18:56:06.549341
# Unit test for constructor of class FactCache
def test_FactCache():
    assert hasattr(FactCache, "__init__")
    assert hasattr(FactCache, "__getitem__")
    assert hasattr(FactCache, "__setitem__")
    assert hasattr(FactCache, "__delitem__")
    assert hasattr(FactCache, "__contains__")
    assert hasattr(FactCache, "__iter__")
    assert hasattr(FactCache, "__len__")
    assert hasattr(FactCache, "flush")
    assert hasattr(FactCache, "keys")
    assert hasattr(FactCache, "first_order_merge")


# Generated at 2022-06-11 18:56:07.661612
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        FactCache()
    except AnsibleError:
        pass

# Generated at 2022-06-11 18:56:17.006155
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    key = 'ansible_hostname'
    value = 'foo'
    host_facts = {key: value}
    fact_cache.update(host_facts)
    assert fact_cache.get(key) == value
    new_value = {'ansible_os_family': 'CentOS',
                 'ansible_distribution': 'CentOS',
                 'some_key': 'some_value'}
    fact_cache.first_order_merge(key, new_value)
    new_value['ansible_hostname'] = value
    assert fact_cache.get(key) == new_value

# Generated at 2022-06-11 18:56:23.697019
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    test_instance = FactCache()
    test_instance.first_order_merge("host_a", {"fact1": 1, "fact2": 2})

    assert(test_instance.keys() == ["host_a"])
    assert(test_instance["host_a"] == {"fact1": 1, "fact2": 2})

    test_instance.first_order_merge("host_a", {"fact1": 3})
    assert(test_instance.keys() == ["host_a"])
    assert(test_instance["host_a"] == {"fact1": 3, "fact2": 2})

# Generated at 2022-06-11 18:56:30.216232
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    # fake the plugin behavior
    fact_cache._plugin = {
        'host1': {},
        'host2': {}
    }

    # test two scenarios: first host is in cache, second is not
    # (for behavior of method update of class dict)
    fact_cache.first_order_merge('host1', {'fact1': 'value1'})
    assert fact_cache.get('host1')['fact1'] == 'value1'
    fact_cache.first_order_merge('host1', {'fact1': 'new_value1'})
    assert fact_cache.get('host1')['fact1'] == 'value1'

    fact_cache.first_order_merge('host2', {'fact2': 'value2'})
    assert fact_cache

# Generated at 2022-06-11 18:56:37.300403
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.inventory.host import Host
    from ansible.plugins.action.copy import ActionModule as CopyModule
    from ansible.plugins.cache import memory

    # mock __init__ of class Host
    def mock_init(self, inventory, hostname):
        self._ds = {}

    Host.__init__ = mock_init

    # mock __init__ of class CopyModule
    def mock_init(self, task, connection, play_context, loader, templar, shared_loader_obj):
        self.task = task
        self.connection = connection
        self.play_context = play_context
        self.loader = loader
        self.templar = templar
        self.shared_loader_obj = shared_loader_obj
        self.aliases = {}
    CopyModule.__init__ = mock_init



# Generated at 2022-06-11 18:56:38.016112
# Unit test for constructor of class FactCache
def test_FactCache():
   assert FactCache()

# Generated at 2022-06-11 18:56:46.760942
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    class DummyCache(object):

        def __init__(self):
            self.storage = dict()

        def set(self, key, value):
            self.storage[key] = value

        def get(self, key):
            return self.storage[key]

        def contains(self, key):
            return key in self.storage

        def keys(self):
            return self.storage.keys()

        def delete(self, key):
            del self.storage[key]

        def flush(self):
            self.storage.clear()

    otp = '{{ lookup("pipe", "echo 123") }}'

# Generated at 2022-06-11 18:56:48.139167
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc is not None
    assert fc._plugin is not None



# Generated at 2022-06-11 18:56:49.145080
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin
    assert fc.copy()

# Generated at 2022-06-11 18:57:26.228528
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fake_facts = {'fact1': 'value1',
                  'fact2': 'value2',
                  'fact3': {'k1': 'v1', 'k2': 'v2'}}

    an_object = FactCache()
    an_object.first_order_merge('host01', fake_facts)
    an_object.first_order_merge('host01', {'fact4': 'value4', 'fact3': {'k3': 'v3'}})

    assert 'host01' in an_object
    assert an_object['host01']['fact1'] == 'value1'
    assert an_object['host01']['fact2'] == 'value2'

# Generated at 2022-06-11 18:57:29.144711
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    foo = FactCache()
    foo.first_order_merge("foo", {"foo": "bar"})
    assert foo["foo"]["foo"] == "bar"

# Generated at 2022-06-11 18:57:35.420417
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    key = 'test_key'
    value = {'nested': {'more_nested': 'value'}}
    expected = {'test_key': {'nested': {'more_nested': 'value'}}}

    fact_cache = FactCache()
    fact_cache.first_order_merge(key, value)

    actual = fact_cache.copy()
    assert actual == expected

# Generated at 2022-06-11 18:57:42.117914
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()

# Generated at 2022-06-11 18:57:46.482484
# Unit test for constructor of class FactCache
def test_FactCache():

    # check error thrown if plugin not available
    success = False
    try:
        cache = FactCache('old_plugin')
        success = True
    except:
        assert False

    # check no error thrown when plugin is available
    try:
        cache = FactCache('jsonfile')
    except:
        assert success is False

# Generated at 2022-06-11 18:57:49.103961
# Unit test for constructor of class FactCache
def test_FactCache():
    import os

    os.environ[C.CACHE_PLUGIN] = 'jsonfile'
    cache_loader.get(C.CACHE_PLUGIN)

    FactCache()

    return 0

# Generated at 2022-06-11 18:57:49.854756
# Unit test for constructor of class FactCache
def test_FactCache():
    assert isinstance(FactCache(), FactCache)

# Generated at 2022-06-11 18:57:59.846418
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()

    host_cache = dict()
    host_facts = dict()
    key = 'hostvars'
    value = dict()

    #test1: hostvars not set
    assert not fact_cache.__contains__(key)
    assert len(host_facts) == 0
    assert len(host_cache) == 0

    fact_cache.first_order_merge(key, value)

    assert fact_cache.__contains__(key)
    host_facts = {key: value}
    assert fact_cache.get(key) is host_facts[key]
    assert len(host_facts) == 1
    assert len(host_cache) == 0
    assert len(fact_cache) == 1

    #test2: hostvars set, host cache exists
    assert fact_

# Generated at 2022-06-11 18:58:06.957089
# Unit test for constructor of class FactCache
def test_FactCache():
    import os
    import tempfile
    os.environ["ANSIBLE_CACHE_PLUGIN"] = "jsonfile"
    os.environ["ANSIBLE_CACHE_PLUGIN_CONNECTION"] = tempfile.mkdtemp()
    cache = FactCache()
    assert cache._plugin.__class__.__name__ == "JsonFile"
    assert cache._plugin.get_cache_connection_info() == os.environ["ANSIBLE_CACHE_PLUGIN_CONNECTION"]

# Generated at 2022-06-11 18:58:07.963085
# Unit test for constructor of class FactCache
def test_FactCache():

    cache = FactCache()

    assert cache is not None

# Generated at 2022-06-11 18:59:11.538123
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Create a FactCache object
    fact_cache = FactCache()

    # First call to first_order_merge
    # This call should create an entry in the cache with key = "host1"
    fact_cache.first_order_merge("host1", {"facts": {"a": "1"}})

    # Get the value for the cache entry with key = "host1"
    host1_facts = fact_cache["host1"]

    # The "facts" entry of the cache with key = "host1" should have
    # the value {"a": "1"}
    assert host1_facts["facts"] == {"a": "1"}

    # Second call to first_order_merge
    # This call should update the "facts" entry of the cache with key = "host1"
    fact_cache.first_order_merge

# Generated at 2022-06-11 18:59:18.728881
# Unit test for constructor of class FactCache
def test_FactCache():
    # there is not enough information to create a fact cache without a cache plugin
    fact_cache = FactCache()
    assert not hasattr(fact_cache, 'flush')
    assert not hasattr(fact_cache, 'first_order_merge')

    # cache plugin must be configured before fact cache can be tested
    C.CACHE_PLUGIN = 'memory'
    fact_cache = FactCache()
    assert hasattr(fact_cache, 'flush')
    assert hasattr(fact_cache, 'first_order_merge')



# Generated at 2022-06-11 18:59:20.820378
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache  # assert is not none



# Generated at 2022-06-11 18:59:26.045150
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache.__getitem__ != {}
    assert fact_cache.__setitem__ != {}
    assert fact_cache.__delitem__ != {}
    assert fact_cache.__contains__ != {}
    assert fact_cache.__iter__ != {}
    assert fact_cache.__len__ != {}
    assert fact_cache.copy != {}
    assert fact_cache.keys != {}
    assert fact_cache.flush != {}
    assert fact_cache.first_order_merge != {}

# Generated at 2022-06-11 18:59:35.389978
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host_1', {'fact1': 'value1', 'fact2': 'value2'})
    assert fact_cache['host_1'] == {'fact1': 'value1', 'fact2': 'value2'}

    fact_cache.first_order_merge('host_1', {'fact3': 'value3', 'fact4': 'value4'})
    assert fact_cache['host_1'] == {'fact1': 'value1', 'fact2': 'value2', 'fact3': 'value3', 'fact4': 'value4'}

    fact_cache.flush()
    assert len(fact_cache) == 0

# Generated at 2022-06-11 18:59:43.079135
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    value = {"random": "other", "a": "b"}
    key = "b"
    fact_cache.first_order_merge(key, value)
    assert fact_cache["b"]["random"] == "other"

    value = {"random": "other", "a": "b"}
    key = "a"
    fact_cache.first_order_merge(key, value)
    assert fact_cache["b"]["random"] == "other"

    value = {"random": "other", "a": "b"}
    key = "a"
    fact_cache.first_order_merge(key, value)
    assert fact_cache["b"]["random"] == "other"
    assert fact_cache["a"]["random"] == "other"

# Generated at 2022-06-11 18:59:45.808272
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
  fc = FactCache()
  fc.first_order_merge("key", "val")
  assert fc["key"] == "val"
  fc.first_order_merge("key", "val2")
  assert fc["key"] == "val2"
  fc.flush()

# Generated at 2022-06-11 18:59:46.738191
# Unit test for constructor of class FactCache
def test_FactCache():
    actual = FactCache()
    assert not actual



# Generated at 2022-06-11 18:59:53.707605
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    host_cache = {'host_name': 'host1'}
    cache['host1'] = host_cache
    cache['host2'] = {'host_name': 'host2'}

    # Case where host is already in cache. 'host_name' key must be updated
    cache.first_order_merge('host1', {'host_name': 'host1_updated'})
    assert cache['host1']['host_name'] == 'host1_updated'
    assert cache['host2']['host_name'] == 'host2'

    # Case where host is NOT in cache. A new entry must be added
    cache.first_order_merge('host3', {'host_name': 'host3'})

# Generated at 2022-06-11 19:00:00.417695
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    my_loader = DataLoader()
    my_inventory = Inventory(loader=my_loader, variable_manager=None, host_list='localhost')
    my_host = my_inventory.get_host('localhost')
    my_host.reload_vars()
    # check if memory backend is loaded
    assert my_host.get_vars()['ansible_fact_cache_plugin'] == 'memory'
    # check if host is in the cache
    assert my_host.name in my_host.get_vars()['ansible_local']['fact_cache']
    # fact cache is empty

# Generated at 2022-06-11 19:01:57.950872
# Unit test for constructor of class FactCache
def test_FactCache():
    factCache = FactCache()
    assert factCache
    assert not factCache.keys()
    assert len(factCache) == 0


# Generated at 2022-06-11 19:01:59.211830
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    print('FactCache module created')

# Generated at 2022-06-11 19:02:05.961993
# Unit test for constructor of class FactCache
def test_FactCache():

    factcache = FactCache()
    factcache._plugin.set("a","b")
    assert factcache._plugin.get("a")=="b"
    assert factcache._plugin.contains("a")
    factcache._plugin.delete("a")
    assert not factcache._plugin.contains("a")
    factcache._plugin.set("a","b")
    factcache._plugin.flush()
    assert not factcache._plugin.contains("a")

# Generated at 2022-06-11 19:02:07.721611
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin



# Generated at 2022-06-11 19:02:08.776034
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache

# Generated at 2022-06-11 19:02:16.256714
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc1 = FactCache()
    fc1['local'] = {}
    fc1['local']['test_fact'] = 'test_fact_value1'
    fc1.first_order_merge('local', {'test_fact': 'test_fact_value2'})
    assert fc1['local']['test_fact'] == 'test_fact_value2'

# Generated at 2022-06-11 19:02:17.253069
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-11 19:02:18.689481
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin is not None

# Generated at 2022-06-11 19:02:30.203976
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()

# Generated at 2022-06-11 19:02:37.465376
# Unit test for constructor of class FactCache
def test_FactCache():
    # Assert that when the plugin returns None, it will raise AnsibleError
    def return_none():
        return None
    plugin_loader_cache_loader_mock = {'get': return_none}
    with patch.dict(cache_loader.__dict__, plugin_loader_cache_loader_mock):
        with pytest.raises(AnsibleError):
            fact_cache = FactCache()
    # Assert that when the plugin returns a valid plugin, no exception is raised
    def return_valid_plugin():
        return ReturnValues(
            {
                'contains': return_true,
                'get': return_true,
                'set': return_true,
                'delete': return_true,
                'flush': return_true,
                'keys': return_true
            }
        )

    plugin_loader