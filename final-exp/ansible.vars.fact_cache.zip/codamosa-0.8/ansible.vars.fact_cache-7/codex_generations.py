

# Generated at 2022-06-11 18:52:35.017926
# Unit test for constructor of class FactCache
def test_FactCache():
    facts_cache = FactCache()

# Generated at 2022-06-11 18:52:41.856939
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()

    host_cached_facts = {'sub1': {'value_sub1_1': 'test_value_sub1_1', 'value_sub1_2': 'test_value_sub1_2'}}
    host_new_facts = {'value_sub1_1': 'test_value_sub1_1', 'value_sub1_2': 'test_value_sub1_2', 'value_sub1_3': 'test_value_sub1_3'}

    # Empty cache, host_new_facts is appended to host_cached_facts
    fact_cache.first_order_merge(cache_key='sub1', value=host_new_facts)

# Generated at 2022-06-11 18:52:47.391331
# Unit test for constructor of class FactCache
def test_FactCache():

    plugin = cache_loader.get(C.CACHE_PLUGIN)
    if not plugin:
        raise AnsibleError('Unable to load the facts cache plugin (%s).' % (C.CACHE_PLUGIN))

    cache = FactCache()

    # Unit tests for assertEqual instances
    assertEqual(cache._plugin, plugin)

    # Unit tests for assertNotEqual instances
    assertNotEqual(cache._plugin, "")

# Generated at 2022-06-11 18:52:58.240879
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import json

    import pytest

    display.verbosity = 2
    C.cache_dir = '/tmp/facts_cachetest'
    import os
    if os.path.exists(C.cache_dir):
        os.rmdir(C.cache_dir)
    C.CACHE_PLUGIN = 'jsonfile'
    C.CACHE_PLUGIN_CONNECTION = ''

    fact_cache = FactCache()

    host_facts = {'a': 1, 'b': 2, 'c': 3}
    key = 'host1'
    fact_cache.first_order_merge(key, host_facts)

    assert fact_cache[key] == host_facts

    host_facts = {'a': 4, 'b': 5, 'c': 6}
    fact_cache

# Generated at 2022-06-11 18:52:59.070717
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc

# Generated at 2022-06-11 18:53:03.658083
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('fact1', 'value1')
    fact_cache.first_order_merge('fact2', 'value2')
    fact_cache.first_order_merge('fact1', 'value3')
    fact_cache.first_order_merge('fact1', 'value4')

    assert fact_cache['fact1'] == 'value4'
    assert fact_cache['fact2'] == 'value2'

# Generated at 2022-06-11 18:53:12.515630
# Unit test for constructor of class FactCache
def test_FactCache():

    # Mock the display object
    display_object = Display()
    display_object.display('fakedisplay', color='green')

    # Mock the method of display object
    display_object.debug = lambda msg, host=None: msg

    # Mock C.CACHE_PLUGIN
    C.CACHE_PLUGIN = 'memory'

    # Mock cache_loader.get so that it does not throw an error
    cache_loader.get = lambda cache_plugin: 'memory'


    fact_cache_object = FactCache()

    assert fact_cache_object
    assert fact_cache_object._plugin == 'memory'
    assert fact_cache_object.__init__()

# Generated at 2022-06-11 18:53:14.147338
# Unit test for constructor of class FactCache
def test_FactCache():
    factcache = FactCache(1)
    assert factcache._plugin


# Generated at 2022-06-11 18:53:19.337728
# Unit test for constructor of class FactCache
def test_FactCache():
    assert(hasattr(FactCache(), '__getitem__'))
    assert(hasattr(FactCache(), '__setitem__'))
    assert(hasattr(FactCache(), '__delitem__'))
    assert(hasattr(FactCache(), '__contains__'))
    assert(hasattr(FactCache(), '__iter__'))
    assert(hasattr(FactCache(), '__len__'))
    assert(hasattr(FactCache(), 'copy'))
    assert(hasattr(FactCache(), 'keys'))
    assert(hasattr(FactCache(), 'flush'))
    assert(hasattr(FactCache(), 'first_order_merge'))

# Generated at 2022-06-11 18:53:22.090127
# Unit test for constructor of class FactCache
def test_FactCache():
    with pytest.raises(AnsibleError) as excinfo:
        FactCache()
    assert excinfo.match("Unable to load the facts cache plugin")


# Generated at 2022-06-11 18:53:32.938760
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    f = FactCache()
    host_facts = {'fact': 'old', 'fact2': 'old'}
    host_cache = {'fact': 'cache', 'fact2': 'cache'}
    host_value = {'fact': 'new', 'fact3': 'new'}
    f._plugin.set('host_cache', host_cache)
    f.first_order_merge('host_facts', host_value)
    host_facts.update(host_value)
    assert host_facts == f['host_facts']


if __name__ == "__main__":
    # If run as a script, do a basic test
    f = FactCache()
    f.first_order_merge('host_facts', {'fact': 'old', 'fact2': 'old'})
    f['host_cache']

# Generated at 2022-06-11 18:53:33.595767
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()



# Generated at 2022-06-11 18:53:40.371325
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    """
        this unit test is to validate that a host cache is re-used when it has been loaded from the cache
        if the cache previously contained a dictionary for the given key, it is updated with the new value
    """
    from ansible.plugins.loader import cache_loader

    C.CACHE_PLUGIN = 'memory'
    cache = FactCache()

    foo_dict = {'foo': 'bar'}
    bar_dict = {'bar': 'foo'}

    # update cache with foo_dict
    cache.first_order_merge('host1', foo_dict)
    cached_dict = cache_loader.get(C.CACHE_PLUGIN).get('host1')
    assert cached_dict == {'foo': 'bar'}

    # update cache with bar_dict
    cache.first_order_

# Generated at 2022-06-11 18:53:41.173660
# Unit test for constructor of class FactCache
def test_FactCache():
    pass

# Generated at 2022-06-11 18:53:48.212767
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import os
    import tempfile

    # check for required dependencies
    try:
        from jinja2 import Template
    except ImportError:
        print('Skipping because jinja2 is not installed')
        return

    from ansible.module_utils.facts import cache as fact_cache

    cache_file = tempfile.NamedTemporaryFile(delete=False)

    plugin = fact_cache.BaseFactCacheModule()
    if hasattr(plugin, "FACT_CACHE_PLUGIN"):
        plugin_name = plugin.FACT_CACHE_PLUGIN
    else:
        plugin_name = 'memory'
    tmpl_var = dict(
        plugin=plugin_name,
        file=cache_file.name,
    )

# Generated at 2022-06-11 18:53:57.486934
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    factcachekey = 'ansible_test'
    key1 = 'test_key1'
    key2 = 'test_key2'
    valuekey1 = 111
    valuekey2 = 222
    factcache = FactCache()

    factcache.first_order_merge(factcachekey, {key1: valuekey1})
    assert factcache[factcachekey][key1] == valuekey1
    factcache.first_order_merge(factcachekey, {key2: valuekey2})
    assert factcache[factcachekey][key1] == valuekey1
    assert factcache[factcachekey][key2] == valuekey2

# Generated at 2022-06-11 18:54:08.576725
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    """
    Unit test for method first_order_merge of class FactCache
    """

    fact_cache = FactCache()
    host_name = 'localhost'
    host_facts = {'host_name': 'localhost', 'cpu_count': 4}
    fact_cache.first_order_merge(host_name, host_facts)
    # Verify the host_facts are cached in the fact_cache
    assert host_facts == fact_cache.get('localhost')

    # update the facts cached in the fact_cache
    host_facts = {'host_name': 'localhost', 'cpu_count': 2}
    fact_cache.first_order_merge(host_name, host_facts)
    # Verify the facts in the fact_cache are updated
    assert host_facts == fact_cache.get('localhost')



# Generated at 2022-06-11 18:54:11.042058
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert(fact_cache)

# Generated at 2022-06-11 18:54:16.771491
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('host1', {'a': 'b', 'd': {'e': 'f'}})
    fact_cache.first_order_merge('host1', {'c': 'b', 'd': {'g': 'h'}})
    assert fact_cache['host1'] == {'a': 'b', 'c': 'b', 'd': {'e': 'f', 'g': 'h'}}

# Generated at 2022-06-11 18:54:23.906517
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    key = 'test'
    first_value = {'os':'linux'}
    first_order_merge_fact = FactCache()
    first_order_merge_fact.first_order_merge(key, first_value)

    assert key in first_order_merge_fact
    assert first_value == first_order_merge_fact[key]

    second_value = {'os':'windows'}
    first_order_merge_fact.first_order_merge(key, second_value)

    assert key in first_order_merge_fact
    assert {'os':'linux'} == first_order_merge_fact[key]


# Generated at 2022-06-11 18:54:32.634947
# Unit test for constructor of class FactCache
def test_FactCache():
    from collections import MutableMapping
    from ansible.module_utils._text import to_bytes
    fc = FactCache()
    assert isinstance(fc, MutableMapping)
    assert to_bytes(fc.__class__.__name__) == b'FactCache'
    assert to_bytes(str(fc)) == b"{}"
    return fc


if __name__ == "__main__":
    print('===TEST:test_FactCache===')
    fc = test_FactCache()
    print('===TEST:test_FactCache:PASS===')

# Generated at 2022-06-11 18:54:33.092902
# Unit test for constructor of class FactCache
def test_FactCache():
    pass

# Generated at 2022-06-11 18:54:41.376191
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Create a fake in-memory facts cache plugin (implemented below).
    def create_instance(conf):
        return MemCachePlugin(conf)

    cache_loader.register('memory', create_instance)
    cache_loader.set('memory')

    # Create our in-memory facts cache.
    cache = FactCache()

    # We need to set a setting so that the facts cache plugin does not just
    # replace any cached facts with facts it finds for a host.
    C.CACHE_PLUGIN_CONNECTION = 'local'

    # We are using a fake in-memory facts cache plugin. This plugin keeps
    # a dictionary of host keys and their cached facts.
    expected_cache = {}
    # Populate the cache with initial values for three different hosts.

# Generated at 2022-06-11 18:54:42.795513
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert isinstance(fc, FactCache)

# Generated at 2022-06-11 18:54:44.657527
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache
    return


# Generated at 2022-06-11 18:54:52.402513
# Unit test for constructor of class FactCache
def test_FactCache():
    display.verbosity = 3
    fc = FactCache
    test_host_name = 'test_host'
    test_host_facts = 'test_host_facts'
    assert True == fc.__contains__(test_host_name)
    fc.__setitem__(test_host_name, test_host_facts)
    assert test_host_facts == fc.__getitem__(test_host_name)
    assert True == fc.__contains__(test_host_name)
    fc.__delitem__(test_host_name)
    assert False == fc.__contains__(test_host_name)
    assert 0 == len(fc)
    fc.flush()
    assert 0 == len(fc)
    assert 0 == display.verbosity

# Generated at 2022-06-11 18:55:01.208028
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    facts_cache = FactCache()
    host = 'my_host'
    facts = {'fact1': 1, 'fact2': 2, 'fact3': 3}
    facts_cache.first_order_merge(host, facts)

    assert host in facts_cache
    assert facts_cache[host] == facts

    # try to merge with the same facts to ensure our cache works
    facts_cache.first_order_merge(host, facts)

    assert host in facts_cache
    assert facts_cache[host] == facts

    # Now merge with slightly different facts and ensure it merges
    new_facts = {'fact1': 1, 'fact2': 2, 'fact3': 3, 'fact4': 4}
    facts_cache.first_order_merge(host, new_facts)

    assert host in facts_cache

# Generated at 2022-06-11 18:55:08.110314
# Unit test for constructor of class FactCache
def test_FactCache():
    fact = FactCache()
    fact['host1'] = {'a': '1'}
    fact['host2'] = {'b': '2'}
    assert fact['host1'] == {'a': '1'}
    assert fact['host2'] == {'b': '2'}
    assert len(fact) == 2
    assert fact.keys() == ['host1', 'host2']
    assert fact.copy() == {'host1': {'a': '1'}, 'host2': {'b': '2'}}
    fact.flush()
    assert len(fact) == 0

# Generated at 2022-06-11 18:55:08.973104
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()

# Generated at 2022-06-11 18:55:16.686721
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    ansible_facts = {'test_key': {'test_key1': 'test_value1', 'test_key2': 'test_value2'}}
    cache = FactCache()
    assert len(cache) == 0
    cache.first_order_merge('test_key', ansible_facts['test_key'])
    assert len(cache) == 1
    assert cache['test_key']['test_key1'] == 'test_value1'
    assert cache['test_key']['test_key2'] == 'test_value2'

# Generated at 2022-06-11 18:55:21.723113
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    print('test_FactCache')


# Generated at 2022-06-11 18:55:24.068968
# Unit test for constructor of class FactCache
def test_FactCache():
    """Unit test for constructor of class FactCache"""
    fact_cache = FactCache()
    assert fact_cache._plugin is not None



# Generated at 2022-06-11 18:55:26.650871
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin
    assert isinstance(fact_cache._plugin, cache_loader.get(C.CACHE_PLUGIN))

# Generated at 2022-06-11 18:55:30.546827
# Unit test for constructor of class FactCache
def test_FactCache():
    facts_cache = FactCache()
    # since this method was added in Ansible 2.1, we have to make sure we're running on a newer version to test it
    if not hasattr(facts_cache, 'copy'):
        raise AnsibleError('test_FactCache: can not test this method on older versions.')

# Generated at 2022-06-11 18:55:31.946699
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert hasattr(fact_cache, 'flush')

# Generated at 2022-06-11 18:55:40.541829
# Unit test for constructor of class FactCache
def test_FactCache():
    import json
    import pprint
    import sys

    temp = FactCache()

    # Test read of fact cache
    with open("/home/ubuntu/devops/ansible/fact-cache/ansible_facts.json", "r") as json_file:
        fact_cache = json.load(json_file)
        pprint.pprint(fact_cache)

#    pprint.pprint(vars(temp))

#    print("\n***JSON***\n")
#    json.dumps(temp.keys(), sys.stdout, indent=4)


if __name__ == "__main__":
    test_FactCache()

# Generated at 2022-06-11 18:55:42.032371
# Unit test for constructor of class FactCache
def test_FactCache():
    display.vvvvv('testing')
    instance = FactCache()
    assert(instance is not None)

# Generated at 2022-06-11 18:55:43.261475
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache

# Generated at 2022-06-11 18:55:44.604417
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache({"test": "test"})
    assert fc is not None


# Generated at 2022-06-11 18:55:45.567809
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache

# Generated at 2022-06-11 18:55:53.377884
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache != None

# Generated at 2022-06-11 18:55:55.518830
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, MutableMapping)

# Generated at 2022-06-11 18:55:57.908790
# Unit test for constructor of class FactCache
def test_FactCache():
    import pytest
    with pytest.raises(AnsibleError):
        assert FactCache() is not None


# Generated at 2022-06-11 18:55:58.874991
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc

# Generated at 2022-06-11 18:56:05.393226
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache(None)
    hosts = {
        'a': {'foo': 'bar'},
        'b': {'foo': 'foo', 'bar': 'foo'},
        'c': {'foo': 'foo', 'bar': 'foo', 'asd': 'ads'}
    }

    for host, value in hosts.items():
        fact_cache.first_order_merge(host, value)

    assert fact_cache.keys() == ['a', 'b', 'c']

# Generated at 2022-06-11 18:56:07.186969
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache._plugin.__class__.__name__ == 'FactCache'

# Generated at 2022-06-11 18:56:15.613882
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache._plugin = {}
    fact_cache._plugin['key'] = {}
    print(fact_cache._plugin['key'])
    fact_cache.first_order_merge('key', {'foo': 'bar'})
    print(fact_cache._plugin['key'])
    fact_cache.first_order_merge('key', {'foo': 'boo'})
    print(fact_cache._plugin['key'])

if __name__ == "__main__":
    test_FactCache_first_order_merge()

# Generated at 2022-06-11 18:56:18.460869
# Unit test for constructor of class FactCache
def test_FactCache():

    # test exception case
    try:
        fact_cache = FactCache()
    except AnsibleError as e:
        pass

    assert e
    assert e.message.startswith('Unable to load the facts cache plugin')



# Generated at 2022-06-11 18:56:23.020493
# Unit test for constructor of class FactCache
def test_FactCache():

    from mock import patch, MagicMock

    with patch.object(cache_loader, "get", return_value=None):
        try:
            FactCache()
            raise AssertionError("AnsibleError not raised")
        except AnsibleError:
            pass

    with patch.object(cache_loader, "get", return_value=MagicMock()):
        FactCache()

# Generated at 2022-06-11 18:56:29.725481
# Unit test for constructor of class FactCache
def test_FactCache():
    # Check that AnsibleError is raised if CACHE_PLUGIN is not configured
    old_plugin = C.CACHE_PLUGIN
    C.CACHE_PLUGIN = None
    try:
        fc = FactCache()
        assert False, "Expected AnsibleError to be raised"
    except AnsibleError:
        pass
    finally:
        C.CACHE_PLUGIN = old_plugin

    # Check for plugin loading
    fc = FactCache()
    fc['foo'] = 'bar'
    assert 'foo' in fc

    # Check that KeyError is raised
    try:
        an_element = fc['non_existent_key']
        assert False, "Expected KeyError to be raised"
    except KeyError:
        pass

    # Check update
    fc

# Generated at 2022-06-11 18:56:48.387531
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    host_facts = {'os_family': 'RedHat', 'ansible_bios_date': '05/19/2014'}
    expected_host_facts = {'os_family': 'RedHat', 'ansible_bios_date': '05/19/2014', 'ansible_distribution': 'RedHat'}
    host_facts_cache = {'os_family': 'RedHat', 'ansible_distribution': 'RedHat'}
    fact_cache._plugin.set('host_facts', host_facts_cache)
    fact_cache.first_order_merge('host_facts', host_facts)
    assert fact_cache == expected_host_facts

# Generated at 2022-06-11 18:56:57.486347
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()

    fc.flush()
    assert len(fc) == 0

    # A key does not exist in the cache yet
    fc.first_order_merge('key', 'value')
    assert len(fc) == 1
    assert 'key' in fc
    assert fc['key'] == 'value'

    # The key is already stored in the cache
    fc.first_order_merge('key', 'value')
    assert len(fc) == 1
    assert 'key' in fc
    assert fc['key'] == 'value'

    # Test the merging of two dicts
    fc.first_order_merge('key', {'a':1, 'b':2})
    assert len(fc) == 1
    assert 'key' in fc

# Generated at 2022-06-11 18:57:04.800896
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    import ansible.plugins.cache.memory
    fact_cache._plugin = ansible.plugins.cache.memory.FactCacheModule()
    host_facts1 = {'a': 1, 'b': 2}
    host_facts2 = {'a': 3, 'c': 4}
    assert(fact_cache.first_order_merge('h1', host_facts1) is None)
    assert(fact_cache.first_order_merge('h1', host_facts2) is None)
    assert fact_cache['h1'] == {'a': 3, 'b': 2, 'c': 4}

# Generated at 2022-06-11 18:57:09.171063
# Unit test for constructor of class FactCache
def test_FactCache():
    cachedir = '/var/tmp/ansible/'
    cache_plugin = 'jsonfile/'

    fact_cache = FactCache(cachedir, cache_plugin)
    assert fact_cache._plugin
    assert fact_cache._plugin.cachedir == cachedir
    assert fact_cache._plugin.plugin == cache_plugin

# Generated at 2022-06-11 18:57:16.013347
# Unit test for constructor of class FactCache
def test_FactCache():
    import os
    import shutil
    from ansible.module_utils._text import to_bytes

    test_dir = C.DEFAULT_LOCAL_TMP + '/ansible-test-facts-cache'

    def init_fact_cache():
        if os.path.exists(test_dir):
            shutil.rmtree(test_dir)
        os.makedirs(test_dir)
        C.CACHE_PLUGIN_CONNECTION = "localFile"
        C.CACHE_PLUGIN_PREFIX = 'ansible_facts'
        C.CACHE_PLUGIN_TIMEOUT = 3600
        C.CACHE_PLUGIN_DIR = test_dir

        fact_cache = FactCache()
        return fact_cache

    fact_cache = init_fact_

# Generated at 2022-06-11 18:57:18.375520
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc
    assert C.CACHE_PLUGIN == 'memory'

# Generated at 2022-06-11 18:57:19.950522
# Unit test for constructor of class FactCache
def test_FactCache():
    temp = FactCache()
    assert temp._plugin.CACHE_PLUGIN == "memory"

# Generated at 2022-06-11 18:57:21.568585
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        FactCache()
    except Exception as e:
        raise AssertionError(e)

# Generated at 2022-06-11 18:57:27.257361
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # test for a single key
    cache = FactCache()
    key = 'localhost'
    cache[key] = {'I': 1, 'am': 2, 'you': 3}
    cache.first_order_merge(key, {'I': 2, 'am': 3, 'me': 3})
    assert cache[key] == {'I': 2, 'am': 3, 'me': 3, 'you': 3}
    cache.flush()

# Generated at 2022-06-11 18:57:34.735246
# Unit test for constructor of class FactCache
def test_FactCache():

    # Initialise an instance of class FactCache
    fact_cache = FactCache()

    # Initialise an instance of class CachePlugin
    cache_plugin_from_loader = cache_loader.get(C.CACHE_PLUGIN)

    # Check if the instance fact_cache has attribute plugin
    assert hasattr(fact_cache, '_plugin')

    # Check if the instance fact_cache.plugin is instance of class CachePlugin
    assert fact_cache._plugin is cache_plugin_from_loader

# Generated at 2022-06-11 18:58:01.880116
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert len(fact_cache.keys()) == 0

# Generated at 2022-06-11 18:58:11.354956
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    # Initialize the cache with dummy facts
    fact_cache['dummy_host_1'] = {'cache_fact_1': 'initial_value_1', 'cache_fact_2': 'initial_value_2'}
    fact_cache['dummy_host_2'] = {'cache_fact_1': 'initial_value_1', 'cache_fact_2': 'initial_value_2'}
    fact_cache['dummy_host_3'] = {'cache_fact_1': 'other_initial_value_1', 'cache_fact_2': 'other_initial_value_2'}

    host_facts = {'cache_fact_1': 'new_value_1', 'cache_fact_2': 'new_value_2'}
    fact_cache.first_order

# Generated at 2022-06-11 18:58:12.106664
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        _ = FactCache()
    except:
        assert False


# Generated at 2022-06-11 18:58:19.249080
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    # When host fact cache is empty
    fc = FactCache()
    key = 'host1'
    value = {'foo': 'foo'}
    expected = value.copy()
    fc.first_order_merge(key, value)

    assert expected == fc[key], "Facts not merged for host %s" % key

    # When host fact cache has old facts
    key = 'host2'
    value = {'foo': 'foo2'}
    expected = value.copy()
    fc.first_order_merge(key, value)

    assert expected == fc[key], "Facts not merged for host %s" % key

# Generated at 2022-06-11 18:58:31.182210
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    # some random facts

# Generated at 2022-06-11 18:58:37.053053
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    factCache = FactCache()
    factCache.first_order_merge('host1', {'ansible_facts': {'a_fact': 'the_value'}})
    assert factCache['host1'] == {'ansible_facts': {'a_fact': 'the_value'}}

    factCache = FactCache()
    factCache.first_order_merge('host1', {'ansible_facts': {'a_fact': 'the_value'}})
    factCache.first_order_merge('host1', {'ansible_facts': {'a_fact': 'another_value'}})
    assert factCache['host1'] == {'ansible_facts': {'a_fact': 'another_value'}}

# Generated at 2022-06-11 18:58:38.022165
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-11 18:58:43.732402
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import os
    from ansible.module_utils.six import PY3

    assert PY3, "Test is intended to run only in Python3"

    cache_file = os.path.join(os.path.dirname(__file__), 'sample_facts.cache')
    os.environ["ANSIBLE_CACHE_PLUGIN"] = "jsonfile"
    os.environ["ANSIBLE_CACHE_PLUGIN_CONNECTION"] = cache_file
    os.environ["ANSIBLE_CACHE_PLUGIN_PREFIX"] = ""
    os.environ["ANSIBLE_CACHE_PLUGIN_TIMEOUT"] = "30"

    fact_cache = FactCache()


# Generated at 2022-06-11 18:58:54.289293
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    value = {'facts': {'a': 1, 'b': 2}, 'task_uuid': '1234'}
    fc.first_order_merge('testhost', value)
    assert 'testhost' in fc
    assert fc['testhost'] == value
    fc.first_order_merge('testhost', {'facts': {'c': 3, 'a': 4}, 'task_uuid': '5678'})
    assert 'testhost' in fc
    assert fc['testhost'] == {'facts': {'a': 4, 'b': 2, 'c': 3}, 'task_uuid': '5678'}

# Generated at 2022-06-11 18:58:55.325882
# Unit test for constructor of class FactCache
def test_FactCache():
    f = FactCache()
    return f


# Generated at 2022-06-11 18:59:51.584312
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache
    assert isinstance(cache, FactCache)

# Generated at 2022-06-11 18:59:55.945322
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None
    fact_cache['test_fact'] = 'test_value'
    fact_cache['test_fact']
    fact_cache.keys()
    fact_cache.flush()

# Generated at 2022-06-11 19:00:05.231768
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    fact_cache = FactCache()

    # test that no facts exist and first_order_merge puts the fact in the cache.
    key = "test_hostname"
    facts = {"test_key": "test_value"}
    fact_cache.first_order_merge(key, facts)
    assert fact_cache.get(key) == facts

    # test that the hostname exists, but the fact does not exist, and first_order_merge adds the fact to the cache.
    key = "test_hostname"
    facts = {"test_key_1": "test_value_1"}
    fact_cache.first_order_merge(key, facts)
    host_cache = fact_cache.get(key)
    assert host_cache["test_key"] == "test_value"

# Generated at 2022-06-11 19:00:07.448731
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)

# Generated at 2022-06-11 19:00:10.275013
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.plugins.loader import cache_loader
    C.CACHE_PLUGIN = 'jsonfile'
    plugin = cache_loader.get(C.CACHE_PLUGIN)
    assert plugin is not None
    c = FactCache()
    assert c is not None

# Generated at 2022-06-11 19:00:12.850855
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None


# Generated at 2022-06-11 19:00:16.917234
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    key = 'host1'
    value_1 = {'key': 'value'}
    fact_cache.first_order_merge(key, value_1)
    value_2 = {'key': 'value_2'}
    fact_cache.first_order_merge(key, value_2)
    assert fact_cache[key]['key'] == 'value_2'

# Generated at 2022-06-11 19:00:23.653332
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.utils.display import Display
    from ansible.plugins.loader import cache_loader
    from ansible.module_utils.common._collections_compat import MutableMapping
    plugin = cache_loader.get(C.CACHE_PLUGIN)
    try:
        assert not plugin
    except AssertionError:
        print('Unable to load the facts cache plugin (%s).' % (C.CACHE_PLUGIN))
        raise

# Generated at 2022-06-11 19:00:29.695840
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    test_key = 'test_host.example.com'
    test_value1 = {'foo': 1, 'bar': 2}
    test_value2 = {'foo': 3, 'baz': 4}
    test_value_expected = {'foo': 3, 'bar': 2, 'baz': 4}
    fact_cache = FactCache()
    fact_cache.first_order_merge(test_key, test_value1)
    fact_cache.first_order_merge(test_key, test_value2)
    assert fact_cache == {test_key: test_value_expected}

# Generated at 2022-06-11 19:00:31.369993
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()

# Generated at 2022-06-11 19:02:28.071973
# Unit test for constructor of class FactCache
def test_FactCache():
    f = FactCache()
    assert f is not None

# Generated at 2022-06-11 19:02:33.254677
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc.first_order_merge('127.0.0.1', {'foo': 'bar'})
    assert fc['127.0.0.1']['foo'] == 'bar'

    # verify that the cache is updated to reflect the value from the ansible.cfg setting
    C.CACHE_PLUGIN = 'memory'
    new_fc = FactCache()
    assert isinstance(new_fc._plugin, type(cache_loader.get(C.CACHE_PLUGIN)))