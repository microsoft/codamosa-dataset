

# Generated at 2022-06-11 18:52:31.223813
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert isinstance(fc, FactCache)


# Generated at 2022-06-11 18:52:40.133891
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    storage = {'_plugin': cache_loader}
    fact_cache.__dict__.update(storage)

    assert isinstance(fact_cache, FactCache)
    assert len(fact_cache) == 0
    assert '_plugin' in fact_cache
    assert fact_cache['_plugin'] == cache_loader

    key = 'key1'
    value = 'value1'
    assert key not in fact_cache
    fact_cache.first_order_merge(key, value)
    assert key in fact_cache
    assert fact_cache[key] == value

    key = 'key1'
    value = 'value2'
    assert key in fact_cache
    fact_cache.first_order_merge(key, value)
    assert key in fact_cache
    assert fact_

# Generated at 2022-06-11 18:52:50.162765
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    class FakePlugin(object):
        def __init__(self, facts):
            self._facts = facts
        def keys(self):
            return self._facts.keys()
        def get(self, key):
            return self._facts[key]
        def set(self, key, value):
            self._facts[key] = value
        def delete(self, key):
            del self._facts[key]
        def contains(self, key):
            return key in self._facts
        def flush(self):
            pass
    factCache = FactCache()

    factCache._plugin = FakePlugin({})
    factCache.first_order_merge(key='host_1', value={'fact_1': 'value_1'})
    assert factCache['host_1'] == {'fact_1': 'value_1'}



# Generated at 2022-06-11 18:52:56.082757
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # test for key exists in cache
    test_cache = FactCache()
    test_cache['host_one'] = {'ansible_ssh_host': '192.168.1.1'}
    test_cache.first_order_merge('host_one', {'test': 'test'})
    assert test_cache['host_one'] == {'test': 'test', 'ansible_ssh_host': '192.168.1.1'}

    # test for key doesn't exists in cache
    test_cache = FactCache()
    test_cache.first_order_merge('host_one', {'test': 'test'})
    assert test_cache['host_one'] == {'test': 'test'}

# Generated at 2022-06-11 18:52:58.005118
# Unit test for constructor of class FactCache
def test_FactCache():

    facts_cache = FactCache()
    assert isinstance(facts_cache, FactCache)

    return facts_cache

# Generated at 2022-06-11 18:52:58.516817
# Unit test for constructor of class FactCache
def test_FactCache():
    assert FactCache()

# Generated at 2022-06-11 18:53:01.168125
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin is not None
    assert isinstance(fc._plugin, cache_loader.get(C.CACHE_PLUGIN))


# Generated at 2022-06-11 18:53:07.272066
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    facts = {'foo': ['bar']}
    test_fact = 'test_fact'
    test_value = 'test_value'
    f = FactCache()
    f.update(facts)
    f.first_order_merge(test_fact, test_value)
    assert f['foo'] == ['bar']
    assert f[test_fact] == test_value

# Generated at 2022-06-11 18:53:13.505269
# Unit test for constructor of class FactCache
def test_FactCache():
    factcache = FactCache()
    factcache['key1'] = 'value1'
    factcache['key2'] = 'value2'
    assert len(factcache) == 2
    assert factcache['key1'] == 'value1'
    assert factcache['key2'] == 'value2'
    del factcache['key2']
    assert 'key2' not in factcache
    for key in factcache:
        assert factcache[key] == 'value1'
    factcache.flush()
    assert len(factcache) == 0

# Generated at 2022-06-11 18:53:19.780741
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Initialize fact cache
    fact_cache = FactCache()
    assert not fact_cache

    # Initialize a fact cache key
    host_cache_key = "test-host"

    # Initialize a fact cache value
    host_cache_value = {"foo": "bar"}

    # Initialize host facts with the cache key and value
    host_facts = {host_cache_key: host_cache_value}

    # Test update of facts cache with a single cache entry, then check that
    # the facts cache has been updated
    fact_cache.update(host_facts)
    assert fact_cache.copy() == host_facts

    # Test update of facts cache with a first-order cache merge, then check
    # that the facts cache has been updated
    new_host_cache_value = {"baz": "bar"}
    host_

# Generated at 2022-06-11 18:53:23.634506
# Unit test for constructor of class FactCache
def test_FactCache():
    d = FactCache()
    assert d._plugin is not None
    assert d._plugin is cache_loader.get(C.CACHE_PLUGIN)

# Generated at 2022-06-11 18:53:33.088093
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # We are creating an instance of MockingCache for cache plugin which has
    # required methods for cache plugin.
    class MockingCache(object):
        def __init__(self, *args, **kwargs):
            self.cache = {}

        def get(self, key):
            return self.cache.get(key, None)

        def set(self, key, value):
            self.cache[key] = value

        def delete(self, key):
            if self.cache.get(key):
                del self.cache[key]

        def contains(self, key):
            return self.cache.get(key) is not None

        def keys(self):
            return self.cache.keys()

        def flush(self):
            self.cache = {}

    C.CACHE_PLUGIN = 'jsonfile'


# Generated at 2022-06-11 18:53:33.954078
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, dict)

# Generated at 2022-06-11 18:53:40.372063
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    key = 'host.name'
    value = 'host.value'
    fc.first_order_merge(key, value)
    assert fc[key] == value
    assert fc.__len__() == 1


# Generated at 2022-06-11 18:53:44.901753
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import json

    cache = FactCache()
    cache.first_order_merge('localhost', {'helloworld': 'ok'})
    assert cache['localhost'] == {'helloworld': 'ok'}

    cache.first_order_merge('localhost', {'helloworld': 'new ok'})
    assert cache['localhost'] == {'helloworld': 'new ok'}

# Generated at 2022-06-11 18:53:54.709761
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    def test_verify(key, value, expected):
        fact_cache = FactCache()
        fact_cache.first_order_merge(key, value)
        assert fact_cache[key] == expected

    # create simple key => value; check if it is stored
    test_verify('key1', 'value1', 'value1')

    # create complex key => value; check if it is stored
    test_verify('key2', {'elem1': 'value1', 'elem2': 'value2'}, {'elem1': 'value1', 'elem2': 'value2'})

    # update value of existing key
    fact_cache = FactCache()
    fact_cache.first_order_merge('key1', 'value1')

# Generated at 2022-06-11 18:54:01.829605
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    cache = FactCache()

    host_facts = {'test':{'a':'foo','b':'baz'}}
    cache['test'] = host_facts['test']

    new = {'a':'foo', 'b':'bar'}
    cache.first_order_merge('test', new)

    assert cache['test']['a'] == 'foo'
    assert cache['test']['b'] == 'bar'

# Generated at 2022-06-11 18:54:07.905133
# Unit test for constructor of class FactCache
def test_FactCache():
    facts = FactCache()
    assert facts._plugin is not None
    assert facts._plugin.contains("") is False
    try:
        value = facts._plugin.get("")
    except KeyError:
        assert True
    else:
        assert False
    try:
        value = facts.__getitem__("")
    except KeyError:
        assert True
    else:
        assert False

# Generated at 2022-06-11 18:54:11.356374
# Unit test for constructor of class FactCache
def test_FactCache():
    new_cache = FactCache(fact_caching=True)
    assert new_cache._plugin._plugin.name == 'jsonfile'

# Generated at 2022-06-11 18:54:13.359407
# Unit test for constructor of class FactCache
def test_FactCache():
    mock_plugin = cache_loader.get(C.CACHE_PLUGIN)
    fact_cache = FactCache()
    assert mock_plugin == fact_cache._plugin

# Generated at 2022-06-11 18:54:22.180668
# Unit test for constructor of class FactCache
def test_FactCache():

    plugin_name = C.CACHE_PLUGIN
    assert plugin_name == 'memory', 'TEST FAILED: Cache plugin name was not "memory"'

    try:
        test_cache = FactCache()
    except AnsibleError as err:
        assert False, 'TEST FAILED: %s' % err.message

    assert test_cache._plugin, 'TEST FAILED: test_cache._plugin is empty'



# Generated at 2022-06-11 18:54:24.185189
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert isinstance(fc, FactCache)

# Generated at 2022-06-11 18:54:33.716493
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    """ Example of the unit test for method first_order_merge of class FactCache
    """
    import os
    import tempfile
    import json
    import time

    # Instantiate FactCache class and prepare cache filename
    fact_cache = FactCache()
    temp_name = tempfile.mkdtemp()
    fact_cache._plugin.load(fact_cache._plugin._validate_cache_options({'fact_caching': 'jsonfile',
                                                                        'fact_caching_connection': temp_name}))

    # Set some data in cache
    facts = {'name': 'Ansible', 'kind': 'Automation'}
    fact_cache.first_order_merge("1.1.1.1", facts)

    # Calculate name of cache file

# Generated at 2022-06-11 18:54:41.875290
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    import tempfile

    cache_plugin = C.CACHE_PLUGIN
    display.verbosity = 4

    with tempfile.NamedTemporaryFile(delete=False) as cache_file:
        C.CACHE_PLUGIN = "jsonfile"
        C.CACHE_PLUGIN_CONNECTION = cache_file.name

        fc = FactCache()

        # update the cache and assert that first_order_merge returns expected dict
        fc.update({
            "host1": {
                "foo": "a",
                "bar": "x",
                "baz": "1",
            },
            "host2": {
                "foo": "b",
                "bar": "y",
                "baz": "2",
            },
        })
        assert fc.first_

# Generated at 2022-06-11 18:54:42.960200
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()

# Generated at 2022-06-11 18:54:50.629318
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # get an instance of FactCache
    fact_cache = FactCache()

    # update with a new fact
    fact_cache.first_order_merge('test_host', {'test_fact': 'test_value'})
    assert 'test_host' in fact_cache.keys()
    assert 'test_fact' in fact_cache['test_host']

    # update with another fact for the same host
    fact_cache.first_order_merge('test_host', {'test_fact2': 'test_value2'})
    assert 'test_fact2' in fact_cache['test_host']


# Generated at 2022-06-11 18:54:58.360985
# Unit test for constructor of class FactCache
def test_FactCache():
    cache_plugin = cache_loader.get(C.CACHE_PLUGIN)
    if not cache_plugin:
        raise 'error: cannot initialize the fact cache plugin'

    cache_plugin.set('test_key', 'test_value')
    try:
        assert cache_plugin.contains('test_key')
        assert cache_plugin.get('test_key') == 'test_value'
        cache_plugin.delete('test_key')
        assert not cache_plugin.contains('test_key')
    finally:
        cache_plugin.flush()

# Generated at 2022-06-11 18:55:00.548108
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    if fact_cache is None:
        raise Exception("Failed to create an instance of the class FactCache")
    else:
        print("Successfully created an instance of the class FactCache")


# Generated at 2022-06-11 18:55:09.146732
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.plugins.cache import BaseFileCacheModule
    from copy import deepcopy
    from tempfile import mkdtemp
    test_facts = {'test_fact': 'test_value'}

    # initialize a dynamic fact cache (default)
    cache_plugin = BaseFileCacheModule(tmp_dir=mkdtemp(), fact_cache=True)
    fact_cache = FactCache()

    # test that facts can be added to cache
    fact_cache['test_hostname'] = test_facts.copy()
    assert fact_cache == test_facts

    # test that facts can be deleted from the cache
    del fact_cache['test_hostname']
    assert not fact_cache

    # test that the fact cache is an ordered dictionary
    fact_cache['test_hostname'] = test_facts.copy()

# Generated at 2022-06-11 18:55:11.302945
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_obj = FactCache()
    assert fact_cache_obj._plugin == 'memory'

# Generated at 2022-06-11 18:55:24.524279
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    key = "localhost"
    value = {"ansible_facts": {"a": 1}}

    fact_cache = FactCache()
    fact_cache._plugin.set(key, value)
    fact_cache.first_order_merge(key, {"ansible_facts": {"b": 2}})
    assert fact_cache._plugin.get(key) == {"ansible_facts": {"a": 1, "b": 2}}


# Generated at 2022-06-11 18:55:26.724893
# Unit test for constructor of class FactCache
def test_FactCache():
    ansible = C
    facts = FactCache()
    assert facts
    assert ansible.CACHE_PLUGIN

# Generated at 2022-06-11 18:55:32.014077
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    cache.first_order_merge('test_host', {'test_fact': 42})
    assert cache['test_host']['test_fact'] == 42

    cache.first_order_merge('test_host', {'test_fact': 43, 'other_fact': 'test'})
    assert cache['test_host']['test_fact'] == 43
    assert cache['test_host']['other_fact'] == 'test'



# Generated at 2022-06-11 18:55:42.658199
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.flush()

    fact_cache.first_order_merge('test_key', {'test_key': 'test_value'})
    assert fact_cache['test_key'] == {'test_key': 'test_value'}

    fact_cache.first_order_merge('test_key', {'test_key': 'test_value2'})
    assert fact_cache['test_key'] == {'test_key': 'test_value2'}

    fact_cache.first_order_merge('test_key', {'test_key2': 'test_value2'})
    assert fact_cache['test_key'] == {'test_key': 'test_value2', 'test_key2': 'test_value2'}

    fact_cache.flush

# Generated at 2022-06-11 18:55:52.117178
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Scenario 1: Cache entry exists and there is some overlap between new and old fact(s)
    test_cache = FactCache()
    test_cache.first_order_merge("test_host1", {"test_fact1": "test_value1"})
    test_cache.first_order_merge("test_host1", {"test_fact1": "test_value2", "test_fact2": "test_value3"})
    assert test_cache["test_host1"] == {"test_fact1": "test_value2", "test_fact2": "test_value3"}

    # Scenario 2: Cache entry does not exist and new facts are added
    test_cache = FactCache()
    test_cache.first_order_merge("test_host2", {"test_fact1": "test_value1"})

# Generated at 2022-06-11 18:55:53.640786
# Unit test for constructor of class FactCache
def test_FactCache():
    factcache = FactCache()
    assert factcache
    assert isinstance(factcache, MutableMapping)

# Generated at 2022-06-11 18:55:55.931876
# Unit test for constructor of class FactCache
def test_FactCache():
    cache_obj = FactCache()
    assert isinstance(cache_obj, FactCache)


# Generated at 2022-06-11 18:56:04.017641
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    test_factcache = FactCache()
    hostname = 'testhost'    
    test_factcache.first_order_merge(hostname, {"initial": "value"})
    assert test_factcache["testhost"]["initial"] == "value"
    test_factcache.first_order_merge(hostname, {"initial": "changed_value"})
    assert test_factcache["testhost"]["initial"] == "changed_value"
    test_factcache.first_order_merge(hostname, {"new": "value"})
    assert test_factcache["testhost"]["new"] == "value"

# Generated at 2022-06-11 18:56:10.949885
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert len(fc) == 0
    fc.update({'HOSTANSIBLE': 'localhost'})
    assert len(fc) == 1

    fc['HOSTANSIBLE'] = 'localhost'
    assert len(fc) == 1
    assert fc['HOSTANSIBLE'] == 'localhost'

    def test_get(key):
        try:
            fc.get(key)
        except KeyError:
            pass

    test_get('LOCALHOST')
    test_get('HOSTANSIBLE')
    fc.flush()
    assert len(fc) == 0
    assert fc.keys() == []


if __name__ == '__main__':
    test_FactCache()

# Generated at 2022-06-11 18:56:21.469586
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('server1', {'a': 1, 'b': 2})
    assert fact_cache.get('server1') == {'a': 1, 'b': 2}
    fact_cache.first_order_merge('server1', {'b': 3, 'c': 4})
    assert fact_cache.get('server1') == {'a': 1, 'b': 3, 'c': 4}
    # Test first_order_merge with replacing existing value
    fact_cache.first_order_merge('server1', {'a': 1, 'b': 2, 'c': 3}, replace=True)
    assert fact_cache.get('server1') == {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-11 18:56:35.712194
# Unit test for constructor of class FactCache
def test_FactCache():
    assert True

# Generated at 2022-06-11 18:56:36.990016
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert isinstance(cache, FactCache)

# Generated at 2022-06-11 18:56:38.197925
# Unit test for constructor of class FactCache
def test_FactCache():
    factCache = FactCache()

# Generated at 2022-06-11 18:56:44.367197
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    cache.first_order_merge("test", {"1":"2"})
    assert "test" in cache
    cache.first_order_merge("test", {"3":"4"})
    assert "test" in cache
    assert cache["test"] == {"1":"2", "3":"4"}
    cache.first_order_merge("test", {"3":"6"})
    assert "test" in cache
    assert cache["test"] == {"1":"2", "3":"6"}

# Generated at 2022-06-11 18:56:45.981997
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)
    assert 'CACHE_PLUGIN' in C

# Generated at 2022-06-11 18:56:55.010917
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()

    new_facts = {'foo': 'bar'}
    cache.first_order_merge('host1', new_facts)
    # First order merge with set cache should return None
    assert not cache.first_order_merge('host1', new_facts)

    cache = FactCache()
    new_facts = {'foo': 'bar'}
    cache.first_order_merge('host2', new_facts)
    # First order merge with reset cache should return updated cache
    assert cache.first_order_merge('host2', new_facts) == {'host2': {'foo': 'bar'}}
    # First order merge with reset cache should return None
    assert not cache.first_order_merge('host2', new_facts)

# Generated at 2022-06-11 18:56:57.346517
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, MutableMapping) is True
    assert isinstance(fact_cache._plugin, cache_loader) is True


# Generated at 2022-06-11 18:57:05.847344
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    class FakePlugin:
        def __init__(self):
            self.cache = {}

        def contains(self, key):
            return key in self.cache

        def get(self, key):
            if key not in self.cache:
                raise KeyError
            return self.cache[key]

        def set(self, key, value):
            self.cache[key] = value

        def delete(self, key):
            del self.cache[key]

        def flush(self):
            self.cache = {}

        def keys(self):
            return self.cache.keys()

    def log_error(msg):
        raise Exception(msg)

    plugin = FakePlugin()
    fact_cache = FactCache()
    fact_cache._plugin = plugin
    fact_cache._plugin.log_error = log_error

    #

# Generated at 2022-06-11 18:57:14.473277
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    cache = FactCache()
    cache.first_order_merge('hostname.example.com', {'foo': 'bar'})
    assert len(cache) == 1 and cache['hostname.example.com']['foo'] == 'bar'

    cache = FactCache()
    cache['hostname.example.com'] = {'boo': 'far'}
    cache.first_order_merge('hostname.example.com', {'foo': 'bar'})
    assert len(cache) == 1 and cache['hostname.example.com']['boo'] == 'far'

    cache = FactCache()
    cache['hostname.example.com'] = {'boo': 'far'}
    cache.first_order_merge('hostname.example.com', {'boo': 'far'})

# Generated at 2022-06-11 18:57:15.586996
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert isinstance(cache, FactCache)

# Generated at 2022-06-11 18:57:30.495447
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert type(fc) is FactCache



# Generated at 2022-06-11 18:57:35.525626
# Unit test for constructor of class FactCache
def test_FactCache():
    if cache_loader is not None:
        assert cache_loader.all()
        for plugin in cache_loader.all():
            print(plugin)
            assert plugin
    fc = FactCache()
    print(fc)

if __name__ == "__main__":
    test_FactCache()

# Generated at 2022-06-11 18:57:39.087979
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert len(fact_cache) == 0
    fact_cache['foo'] = 'bar'
    assert len(fact_cache) == 1
    assert fact_cache['foo'] == 'bar'
    fact_cache.flush()

# Generated at 2022-06-11 18:57:49.497367
# Unit test for constructor of class FactCache
def test_FactCache():
    import json
    import mock
    import os

    from ansible.plugins.cache import fact_cache
    from ansible.plugins.loader import cache_loader

    cache_plugin_list = fact_cache.__all__
    test_dir = os.path.join(os.path.dirname(__file__), "test_fact_cache")
    display.vvvv = mock.MagicMock()

    for cache_plugin in cache_plugin_list:
        # Setup mock environment variables
        os.environ['ANSIBLE_CACHE_PLUGIN'] = cache_plugin
        os.environ['ANSIBLE_CACHE_PLUGIN_CONNECTION'] = 'local'
        os.environ['ANSIBLE_CACHE_PLUGIN_PREFIX'] = test_dir

        # Check if the plugin is available and

# Generated at 2022-06-11 18:57:51.782831
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-11 18:57:52.768975
# Unit test for constructor of class FactCache
def test_FactCache():
    cache_dict = FactCache()
    assert cache_dict

# Generated at 2022-06-11 18:58:00.931308
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    """ Unit test for method first_order_merge of class FactCache
    """
    cache = FactCache()
    host_facts = {'myhost_facts': {'a': '1', 'b': '2'}}
    cache.first_order_merge('myhost_facts', host_facts['myhost_facts'])
    assert cache == host_facts
    new_facts = {'myhost_facts': {'c': '3', 'd': '4'}}
    cache.first_order_merge('myhost_facts', new_facts['myhost_facts'])
    assert new_facts == {'myhost_facts': {'c': '3', 'd': '4'}}
    new_facts['myhost_facts'].update(host_facts['myhost_facts'])
    assert cache == new_

# Generated at 2022-06-11 18:58:04.196747
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None
    key = 'test_key'
    fact_cache[key] = 'test_value'
    assert key in fact_cache
    assert fact_cache[key] == 'test_value'

# Generated at 2022-06-11 18:58:06.264225
# Unit test for constructor of class FactCache
def test_FactCache():
    factCache = FactCache()
    assert factCache._plugin.name == C.CACHE_PLUGIN

# Generated at 2022-06-11 18:58:16.595681
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.plugins.cache import BaseCacheModule
    class MyCache(BaseCacheModule):
        def __init__(self):
            pass

        def set(self, key, value):
            pass

        def get(self, key):
            pass

        def contains(self, key):
            return True

        def keys(self):
            return ['foo']

        def flush(self):
            pass

        def delete(self, key):
            pass

    cache_loader.set('foo', MyCache)
    fact_cache = FactCache()
    assert len(fact_cache) == 1

    cache_loader.set('bar', None)
    try:
        fact_cache = FactCache()
    except AnsibleError:
        pass
    else:
        assert False



# Generated at 2022-06-11 18:58:44.857749
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache.plugins_dir is None

# Generated at 2022-06-11 18:58:49.092293
# Unit test for constructor of class FactCache
def test_FactCache():
    """
    Test case for verifying that the FactCache class is correctly initialized.
    """

    try:
        FactCache()
    except Exception as e:
        raise AnsibleError("Unable to initialize the FactCache class. Exception: %s" % to_text(e))


# Generated at 2022-06-11 18:58:50.784826
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc
    assert fc.copy() == {}
    assert not fc

# Generated at 2022-06-11 18:58:58.781489
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.plugins.cache.jsonfile import CacheModule
    # create a fake CacheModule class
    class test_CacheModule(CacheModule):
        def __init__(self):
            self.cache = dict()
        def contains(self, key):
            return key in self.cache
        def get(self, key):
            if key in self.cache:
                return self.cache[key]
            raise KeyError
        def set(self, key, value):
            self.cache[key] = value
        def delete(self, key):
            if key in self.cache:
                del self.cache[key]
                return True
            return False
        def flush(self):
            self.cache.clear()
        def keys(self):
            return self.cache.keys()

# Generated at 2022-06-11 18:59:05.344307
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    cache.first_order_merge('host', {'a': 1, 'b': 2})
    assert(cache['host'] == {'a': 1, 'b': 2})

    cache = FactCache()
    cache._plugin.set('host', {'a': 1, 'b': 2})
    cache.first_order_merge('host', {'a': 3, 'c': 4})
    assert(cache['host'] == {'a': 3, 'b': 2, 'c': 4})

# Generated at 2022-06-11 18:59:10.672645
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('hostname', {'a': 1})
    assert fact_cache['hostname'] == {'a': 1}

    # 'value' of the second-call has higher priority.
    fact_cache.first_order_merge('hostname', {'a': 0, 'b': 2})
    assert fact_cache['hostname'] == {'a': 0, 'b': 2}

# Generated at 2022-06-11 18:59:21.268762
# Unit test for constructor of class FactCache
def test_FactCache():

    from ansible.module_utils.facts import cache
    with cache.plugin() as pc:
        pc.set(u'{}', 'ansible/facts/foo.fact', [u'{}'])
        pc.set(u'{}', 'ansible/facts/bar.fact', [u'{}'])
        pc.set(u'{}', 'ansible/facts/baz.fact', [u'{}'])
        pc.set(u'{}', 'ansible/facts/qux.fact', [u'{}'])
        pc.set(u'{}', 'ansible/facts/quuz.fact', [u'{}'])
        pc.set(u'{}', 'ansible/facts/corge.fact', [u'{}'])
        pc.set

# Generated at 2022-06-11 18:59:22.464793
# Unit test for constructor of class FactCache
def test_FactCache():
    factCache = FactCache()
    assert factCache



# Generated at 2022-06-11 18:59:24.760879
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    hostname = "hostname-1"
    ipaddress = "10.10.10.10"
    fact_cache = FactCache()
    fact_cache.first_order_merge(hostname, ipaddress)

# Generated at 2022-06-11 18:59:26.457756
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        FactCache()
    except AnsibleError:
        return True
    return False


# Generated at 2022-06-11 19:00:23.594401
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()

    # Test with valid C.CACHE_PLUGIN
    assert fact_cache._plugin, 'Unable to load the facts cache plugin (%s).' % (C.CACHE_PLUGIN)

# Generated at 2022-06-11 19:00:25.651360
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)
    assert fact_cache._plugin

# Generated at 2022-06-11 19:00:26.274368
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc is not None


# Generated at 2022-06-11 19:00:29.612035
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache._plugin = FakeCachePlugin()
    fact_cache._plugin.set("{'foo'}", "{'bar'}")
    fact_cache.first_order_merge("{'foo'}", "{'bar'}")
    assert fact_cache.get("{'foo'}") == "{'bar'}"
    assert fact_cache['{foo}'] == "{'bar'}"


# Generated at 2022-06-11 19:00:34.126768
# Unit test for constructor of class FactCache
def test_FactCache():
    import tempfile
    tempdir = tempfile.gettempdir()
    cache_plugin = 'jsonfile'
    test_cache = FactCache(plugin=cache_plugin, timeout=120, fact_path=tempdir)
    assert test_cache._plugin.__class__.__name__ == 'JsonfileCacheModule'

# Generated at 2022-06-11 19:00:40.267918
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    host_facts = {
        'fact': 'something'
    }
    fc.first_order_merge('host', host_facts)
    assert fc['host'] == host_facts

    host_facts = {
        'fact': 'something else'
    }
    fc.first_order_merge('host', host_facts)
    assert fc['host'] == {
        'fact': 'something else'
    }

    host_facts = {
        'fact': 'something else',
        'another_fact': 'something true'
    }
    fc.first_order_merge('host', host_facts)
    assert fc['host'] == {
        'fact': 'something else',
        'another_fact': 'something true'
    }

# Generated at 2022-06-11 19:00:48.060172
# Unit test for constructor of class FactCache
def test_FactCache():
    #
    # check parametrized constructor
    #
    fc = FactCache(key1='value1')
    assert 'key1' in fc

    fc = FactCache(key1='value1' , key2='value2')
    assert 'key1' in fc
    assert 'key2' in fc

    fc = FactCache([('key1','value1')])
    assert 'key1' in fc

    fc = FactCache([('key1','value1') , ('key2','value2')])
    assert 'key1' in fc
    assert 'key2' in fc

    fc = FactCache(dict(key1='value1'))
    assert 'key1' in fc


# Generated at 2022-06-11 19:00:49.113697
# Unit test for constructor of class FactCache
def test_FactCache():
    f = FactCache()
    return f

# Generated at 2022-06-11 19:00:59.180853
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fs = FactCache()

    collection = {}
    fs.first_order_merge('host_name', collection)
    assert len(fs) == 1

    collection = {
                   'key_a': 'value_a',
                   'key_b': 'value_b',
               }
    fs.first_order_merge('host_name', collection)
    assert len(fs) == 1
    assert len(fs['host_name']) == 2
    assert fs['host_name']['key_a'] == 'value_a'
    assert fs['host_name']['key_b'] == 'value_b'

    collection = {
                   'key_a': 'value_a_new',
                   'key_c': 'value_c',
               }

# Generated at 2022-06-11 19:01:07.862706
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = {}
    cache_plugin = {}
    cache_plugin['contains'] = lambda x: True
    cache_plugin['get'] = lambda x: "test"
    cache_plugin['set'] = lambda x, y: cache.update({x: y})
    cache_plugin['delete'] = lambda x: cache.__delitem__(x)
    cache_plugin['flush'] = lambda: cache.clear()
    cache_plugin['keys'] = lambda: cache.keys()

    cache_loader.plugin_replace(C.CACHE_PLUGIN, cache_plugin)
    fact_cache = FactCache()

    fact_cache['test_key'] = 'test_value'
    assert fact_cache['test_key'] == 'test_value'
    assert fact_cache['test_key'] == cache['test_key']
   