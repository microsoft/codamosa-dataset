

# Generated at 2022-06-11 18:52:38.741712
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    display.verbosity = 3
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch, Mock
    plugin = Mock()
    plugin.contains.return_value = True
    plugin.get.return_value = {'uptime_seconds': '600'}
    plugin.set.return_value = None
    plugin.delete.return_value = None
    plugin.flush.return_value = None
    plugin.keys.return_value = []
    with patch('ansible.plugins.loader.cache_loader.get', return_value = plugin):
        fc = FactCache()
        fc.first_order_merge('localhost',{'uptime_seconds': '100'})
        assert fc['localhost']['uptime_seconds'] == '100'
        fc.first

# Generated at 2022-06-11 18:52:49.770622
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    facts_cache = FactCache()
    host_name = "dummy_host"
    facts = {'test_fact1': 'test_fact1_value', 'test_fact2': 'test_fact2_value'}
    facts1 = {'test_fact1': 'test_fact1_value_new', 'test_fact2': 'test_fact2_value'}
    facts2 = {'test_fact2': 'test_fact2_value_new', 'test_fact3': 'test_fact3_value'}

    # Add facts
    facts_cache.first_order_merge(host_name, facts)
    assert(facts_cache[host_name]['test_fact1'] == facts['test_fact1'])

    # Add same facts, fact value should not change
    facts_cache.first_

# Generated at 2022-06-11 18:52:51.913465
# Unit test for constructor of class FactCache
def test_FactCache():
    f=FactCache()
    assert f
    #assert_raises(AnsibleError, f.__init__, plugin = "badcache")

# Generated at 2022-06-11 18:52:57.138856
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    cache.first_order_merge('hostname', {'fact1': '1', 'fact2': '2'})
    assert cache['hostname']['fact1'] == '1'
    assert cache['hostname']['fact2'] == '2'


# Generated at 2022-06-11 18:53:04.512613
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    plugin = cache_loader.get(C.CACHE_PLUGIN)
    plugin.flush()
    fact_cache = FactCache()
    fact_cache.first_order_merge('127.0.0.1', {'foo': 'bar'})
    assert fact_cache['127.0.0.1']['foo'] == 'bar'
    fact_cache.first_order_merge('127.0.0.1', {'foo': 'baz'})
    assert fact_cache['127.0.0.1']['foo'] == 'baz'
    fact_cache.first_order_merge('127.0.0.1', {'other': 'value'})
    assert fact_cache['127.0.0.1']['other'] == 'value'



# Generated at 2022-06-11 18:53:10.794049
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge("localhost", {"ansible_os_family": "RedHat"})
    fact_cache.first_order_merge("localhost", {"ansible_distribution": "CentOS"})
    assert fact_cache['localhost']['ansible_os_family'] == 'RedHat'
    assert fact_cache['localhost']['ansible_distribution'] == 'CentOS'

# Generated at 2022-06-11 18:53:12.802128
# Unit test for constructor of class FactCache
def test_FactCache():
    cache_plugin = {'Plugin': 'jsonfile'}
    cache = FactCache(plugin=cache_plugin)
    assert cache

# Generated at 2022-06-11 18:53:23.670508
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import json
    """
    Testing that first_order_merge is able to update facts on a host
    """

    # This is to make sure the test is idempotent.
    # If this test is working, the delete call to flush() will not fail
    factcache2 = FactCache()
    factcache2.flush()

    # create an instance of FactCache
    factcache1 = FactCache()

    # test data for ansible_facts
    hostvars = {
        'ansible_facts': {
            'key1': {
                'key1_1': 'value1_1',
                'key1_2': 'value1_2'
            },
            'key2': 'value2'
        }
    }

    # test data for fact_caching

# Generated at 2022-06-11 18:53:27.036707
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    c = {'a': {'b': 'c'}}
    d = {'c': 'd'}
    c.update(d)
    assert c == {'a': {'b': 'c'}, 'c': 'd'}
    assert c is not d

# Generated at 2022-06-11 18:53:29.468302
# Unit test for constructor of class FactCache
def test_FactCache():
    test_instance = FactCache()
    assert(isinstance(test_instance, FactCache))

if __name__ == "__main__":
    test_FactCache()

# Generated at 2022-06-11 18:53:38.772645
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Define mock object for class FactCache
    class MockFactCache(FactCache):
        def __init__(self, *args, **kwargs):
            self.fom_d = {}
            super(MockFactCache, self).__init__(*args, **kwargs)

        def __getitem__(self, key):
            return self.fom_d[key]

        def __setitem__(self, key, value):
            self.fom_d.update({key: value})

        def __delitem__(self, key):
            del self.fom_d[key]

        def __contains__(self, key):
            return key in self.fom_d

        def __iter__(self):
            return iter(self.fom_d)


# Generated at 2022-06-11 18:53:45.735230
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.plugins.loader import cache_loader

    assert isinstance(cache_loader, dict)
    assert 'memory' in cache_loader.keys()
    assert 'jsonfile' in cache_loader.keys()
    assert 'yaml' in cache_loader.keys()
    assert 'redis' in cache_loader.keys()
    assert 'memcache' in cache_loader.keys()
    assert 'sqlite' in cache_loader.keys()
    assert 'zk' in cache_loader.keys()

# Generated at 2022-06-11 18:53:47.349913
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_chache_obj = FactCache()
    assert fact_chache_obj
    del fact_chache_obj

# Generated at 2022-06-11 18:53:47.825351
# Unit test for constructor of class FactCache
def test_FactCache():
    pass

# Generated at 2022-06-11 18:53:48.365994
# Unit test for constructor of class FactCache
def test_FactCache():
    assert FactCache()

# Generated at 2022-06-11 18:53:49.482726
# Unit test for constructor of class FactCache
def test_FactCache():
    assert isinstance(FactCache(), FactCache)

# Generated at 2022-06-11 18:53:58.252451
# Unit test for constructor of class FactCache
def test_FactCache():
    """Unit test for constructor of class FactCache"""

    from unittest import TestCase, mock

    with mock.patch('ansible.plugins.loader.cache_loader.get'):
        cache_loader.get = mock.MagicMock()
        cache_loader.get.side_effect = lambda x: None

        with TestCase.assertRaises(TestCase, AnsibleError):
            FactCache()

    with mock.patch('ansible.plugins.loader.cache_loader.get'):
        cache_loader.get = mock.MagicMock()
        cache_loader.get.side_effect = lambda x: 'dummy'

        FactCache()

# Generated at 2022-06-11 18:54:08.952408
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    my_fact_cache = FactCache()

    my_fact_cache.first_order_merge("localhost", {'ansible_processor': [2, 'Intel(R) Core(TM) i7-6700HQ CPU @ 2.60GHz']})
    my_fact_cache.first_order_merge("localhost", {'fact_key_three': 'first_value_three'})
    my_fact_cache.first_order_merge("localhost", {'fact_key_one': 'first_value_one'})
    my_fact_cache.first_order_merge("localhost", {'fact_key_one': 'second_value_one'})

    assert my_fact_cache['localhost']['fact_key_one'] == 'second_value_one'

    assert 'localhost' in my_fact_cache



# Generated at 2022-06-11 18:54:11.449282
# Unit test for constructor of class FactCache
def test_FactCache():
    '''Test for constructor'''
    fact_cache = FactCache()
    return fact_cache


# Generated at 2022-06-11 18:54:12.557576
# Unit test for constructor of class FactCache
def test_FactCache():
    assert isinstance(FactCache(), FactCache)


# Generated at 2022-06-11 18:54:21.944934
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    c = FactCache()
    c.first_order_merge('key1', {'a':1, 'b':2})
    c.first_order_merge('key1', {'a':3, 'd':2})
    c.first_order_merge('key2', {'a':1, 'b':2})
    c.first_order_merge('key2', {'a':3, 'd':2})
    assert c.copy() == {'key1': {'a': 3, 'b': 2, 'd': 2}, 'key2': {'a': 3, 'b': 2, 'd': 2}}
    c.flush()

# Generated at 2022-06-11 18:54:24.185148
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache
    assert fact_cache._plugin

# Generated at 2022-06-11 18:54:32.335717
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    hostvars = {}
    hostvars['localhost'] = {'priority': 1000, 'ansible_facts': {"ansible_distribution_version": "11", "ansible_distribution": "Ubuntu"}}
    host_facts = {'ansible_facts': {"ansible_distribution_version": "12", "ansible_distribution": "RedHat"}}
    hostvars['localhost'].update(host_facts)

    hostvars_cache = FactCache()
    hostvars_cache.first_order_merge("localhost", host_facts['ansible_facts'])

    assert hostvars == hostvars_cache

# Generated at 2022-06-11 18:54:40.805199
# Unit test for constructor of class FactCache
def test_FactCache():
    import os
    import tempfile

    with tempfile.TemporaryDirectory() as tmp_dir:
        cache_path = os.path.join(tmp_dir, 'ansible-facts')
        C.CACHE_PLUGIN = 'jsonfile'
        C.CACHE_PLUGIN_CONNECTION = cache_path
        fact_cache = FactCache()
        assert fact_cache._plugin.__class__.__name__ == 'JsonfileCacheModule'
        assert {'SomeHost': {'some_fact': 'value'}} == fact_cache.copy()
        assert [] == fact_cache.keys()
        assert {'SomeHost': {'some_fact': 'value'}} == fact_cache.copy()

        # Before adding anything in fact_cache, its length should be 0
        assert len(fact_cache)

# Generated at 2022-06-11 18:54:42.417533
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()

# Generated at 2022-06-11 18:54:44.066037
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)

# Generated at 2022-06-11 18:54:45.788246
# Unit test for constructor of class FactCache
def test_FactCache():
    result = FactCache()
    assert result == '{}'

# Generated at 2022-06-11 18:54:49.391777
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    c = FactCache()
    c.first_order_merge('test1', {'key1': 'value1'})
    assert c['test1'] == {'key1': 'value1'}
    c.first_order_merge('test1', {'key2' : 'value2'})
    assert c['test1'] == {'key1': 'value1', 'key2' : 'value2'}



# Generated at 2022-06-11 18:54:59.557112
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    print("\nTest started in function test_FactCache_first_order_merge()")
    obj = FactCache()

    # Check if the value for 'key' is added to the cache, if that key does not exist in the cache.
    hostname = "host1"
    payload = {'ansible_distribution': 'ubuntu'}
    obj[hostname] = payload

    assert obj[hostname] == payload

    # Check if the value for 'key' is updated in the cache, if that key exists in the cache.
    hostname = "host1"
    old_payload = {'ansible_distribution': 'ubuntu'}
    new_payload = {'ansible_distribution': 'fedora'}
    obj[hostname] = new_payload

    assert obj[hostname] == new_payload


# Generated at 2022-06-11 18:55:07.270642
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.config.manager import ConfigManager
    from ansible.constants import DEFAULT_CACHE_PLUGIN_NAME

    config_manager = ConfigManager.get_instance()
    cache_plugin = config_manager.get_cache_plugin_options(DEFAULT_CACHE_PLUGIN_NAME)
    print(cache_plugin)

    fac = FactCache(cache_plugin)
    fac['key1'] = 'value1'
    fac['key2'] = 'value2'

    print(fac.keys())

    fac.flush()


if __name__ == '__main__':
    test_FactCache()

# Generated at 2022-06-11 18:55:19.106157
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    facts = {'foo': 'bar'}
    # Update facts
    fact_cache.first_order_merge('host', facts)
    assert fact_cache == {'host': facts}
    # Add new fact
    new_facts = {'bar': 'baz'}
    fact_cache.first_order_merge('host', new_facts)
    assert fact_cache == {'host': {'foo': 'bar', 'bar': 'baz'}}
    # Update existing fact
    fact_cache.first_order_merge('host', {'foo': 'baz'})
    assert fact_cache == {'host': {'foo': 'baz', 'bar': 'baz'}}
    # Add new host/fact

# Generated at 2022-06-11 18:55:20.401323
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache.__getitem__

# Generated at 2022-06-11 18:55:25.839580
# Unit test for constructor of class FactCache
def test_FactCache():
    display.verbosity = 0
    plugin = cache_loader.get(C.CACHE_PLUGIN)
    if not plugin:
        raise AnsibleError('Unable to load the facts cache plugin (%s).' % (C.CACHE_PLUGIN))
    fact_cache = FactCache()
    assert fact_cache is not None


# Generated at 2022-06-11 18:55:27.698150
# Unit test for constructor of class FactCache
def test_FactCache():
    a = FactCache()
    a['1'] = 1


# Generated at 2022-06-11 18:55:33.417366
# Unit test for constructor of class FactCache
def test_FactCache():
    test_var = {'hoge': 'fuga'}
    test_cache = FactCache()
    test_cache.flush()
    assert 'hoge' not in test_cache
    test_cache['hoge'] = 'fuga'
    assert 'hoge' in test_cache
    assert test_var == test_cache.copy()
    assert 'hoge' in test_cache.keys()
    test_cache.__delitem__('hoge')
    assert 'hoge' not in test_cache
    test_cache.flush()
    assert 'hoge' not in test_cache.keys()
    assert 'hoge' not in test_cache


fact_cache = FactCache()

# Generated at 2022-06-11 18:55:34.786632
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache is not None
    cache.flush()

# Generated at 2022-06-11 18:55:44.567055
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    facts_cache = FactCache()
    facts_cache.flush()

    display.display("Testing: first_order_merge of class FactCache")
    display.display("...expected results: ")
    display.display("{'test': {'var1': 'value1', 'var2': 'value2'}}")

    host_facts = {'var1': 'value1'}
    # No facts in cache
    facts_cache.first_order_merge('test', host_facts)
    # Facts in cache
    host_facts = {'var2': 'value2'}
    facts_cache.first_order_merge('test', host_facts)
    # Check cache
    host_cache = facts_cache['test']
    display.display("...actual results:")
    display.display(host_cache)
   

# Generated at 2022-06-11 18:55:48.702756
# Unit test for constructor of class FactCache
def test_FactCache():
    facts = FactCache()
    assert type(facts) == FactCache
    #assert not facts._plugin.contains("test_fact_cache")
    #facts._plugin.set("test_fact_cache", "test_value")
    #assert facts._plugin.contains("test_fact_cache")



# Generated at 2022-06-11 18:55:55.236905
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    host_cache = {'host_cache_key': 'host_cache_value'}
    host_facts = {'host_facts_key': 'host_facts_value'}
    fact_cache.update({'host_a': host_cache})

    fact_cache.first_order_merge('host_a', host_facts)
    assert fact_cache['host_a']['host_cache_key'] == 'host_cache_value'
    assert fact_cache['host_a']['host_facts_key'] == 'host_facts_value'

# Generated at 2022-06-11 18:56:02.925903
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible import context
    context.CLIARGS = lambda: None
    context.CLIARGS.cache_plugin = 'jsonfile'

    _plugin = cache_loader.get(C.CACHE_PLUGIN)
    if not _plugin:
        raise AnsibleError('Unable to load the facts cache plugin (%s).' % (C.CACHE_PLUGIN))

    fact_cache = FactCache()
    assert isinstance(fact_cache, MutableMapping)
    assert fact_cache._plugin


# Generated at 2022-06-11 18:56:18.041997
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact = FactCache()
    key = 'ansible_facts'
    assert len(fact) == 0
    assert key not in fact

    value = {'f1':1, 'f2':2, 'f3':3}
    fact.first_order_merge(key, value)
    print(fact)
    assert len(fact) == 1
    assert key in fact
    assert fact[key] == value

    value2 = {'f4':4}
    fact.first_order_merge(key, value2)
    print(fact)
    assert len(fact) == 1
    assert key in fact
    assert fact[key] == {'f1':1, 'f2':2, 'f3':3, 'f4':4}
    fact.flush()

# Generated at 2022-06-11 18:56:21.800569
# Unit test for constructor of class FactCache
def test_FactCache():
    import pytest
    if not C.CACHE_PLUGIN:
        pytest.skip("cache_loader not present")
    else:
        try:
            assert isinstance(FactCache(), FactCache)
        except Exception:
            pytest.fail("Unable to load the fact cache plugin.")

# Generated at 2022-06-11 18:56:24.731726
# Unit test for constructor of class FactCache
def test_FactCache():
    import os
    tmp_file = os.path.join(C.DEFAULT_LOCAL_TMP, "test.cache")
    cache = FactCache({'__fact_cache__': tmp_file})

    assert cache is not None


# Generated at 2022-06-11 18:56:25.860417
# Unit test for constructor of class FactCache
def test_FactCache():

    fact_cache = FactCache()

    assert fact_cache is not None

# Generated at 2022-06-11 18:56:27.264715
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)

# Generated at 2022-06-11 18:56:28.889958
# Unit test for constructor of class FactCache
def test_FactCache():
    factcache = FactCache()
    assert factcache.__class__ == FactCache

# Generated at 2022-06-11 18:56:35.162453
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    assert not fact_cache.keys()

    host_facts = {'foo': 'bar'}
    fact_cache.first_order_merge('localhost', host_facts)

    assert fact_cache.keys() == ['localhost']
    assert fact_cache['localhost'] == host_facts

    new_host_facts = {'foo': 'baz'}
    fact_cache.first_order_merge('localhost', new_host_facts)

    assert fact_cache.keys() == ['localhost']
    assert fact_cache['localhost'] == new_host_facts

# Generated at 2022-06-11 18:56:36.490828
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-11 18:56:39.334813
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    fc["foo"] = dict(my_fact=123)
    assert fc["foo"]["my_fact"] == 123

# Generated at 2022-06-11 18:56:47.390966
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Init
    host_key = "host1"
    new_host_facts = {
        "cache": {
            "key1": "value1",
            "key2": "value2"
        }
    }
    cached_host_facts = {
        "cache": {
            "key3": "value3",
            "key4": "value4"
        }
    }

    host_fact_cache = FactCache()
    host_fact_cache[host_key] = cached_host_facts

    # Test without cached facts
    # Set test variable
    host_fact_cache = FactCache()
    # Run code
    host_fact_cache.first_order_merge(host_key, new_host_facts)
    # Check result

# Generated at 2022-06-11 18:57:01.816350
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.module_utils.facts import cache as fact_cache
    if fact_cache.CACHE_PLUGIN == 'memory':
        test = fact_cache.FactCache()
        assert(test)
    else:
        assert(True)

# Generated at 2022-06-11 18:57:07.260103
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc._plugin = 'dummy'
    fc.update = {}
    key = 'host_name'
    value = {'fact1': 'value1'}
    expected = {key: {'fact1': 'value1'}}
    fc.first_order_merge(key, value)

    assert fc.first_order_merge(key, value) == expected

# Generated at 2022-06-11 18:57:07.988153
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    return fact_cache

# Generated at 2022-06-11 18:57:09.859464
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    # TODO: a better test?

# Generated at 2022-06-11 18:57:19.042539
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache_obj = FactCache()
    fact_cache_obj.first_order_merge({'test': {'test1': "test1", 'test2': "test2"}}, {'test': {'test1': "test1", 'test2': "test2"}})
    assert dict(fact_cache_obj.plugin.cache) == {'test': {'test1': "test1", 'test2': "test2"}}
    fact_cache_obj.first_order_merge({'test': {'test1': "test1", 'test2': "test2"}}, {'test': {'test1': "test1", 'test3': "test3"}})

# Generated at 2022-06-11 18:57:19.689537
# Unit test for constructor of class FactCache
def test_FactCache():
    assert FactCache()

# Generated at 2022-06-11 18:57:21.031637
# Unit test for constructor of class FactCache
def test_FactCache():
    v = FactCache()
    assert 'localhost' == v.keys()[0]

# Generated at 2022-06-11 18:57:31.071761
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    host_cache = {"interfaces": [{"interface": "ens33"}]}
    fact_cache['host1'] = host_cache
    host_value = {"interfaces": [{"interface": "ens35"}]}
    fact_cache.first_order_merge('host1', host_value)

    assert fact_cache['host1']['interfaces'][0]['interface'] == 'ens35'

    host_cache = {"interfaces": [{"interface": "ens33"}]}
    fact_cache['host2'] = host_cache
    host_value = {"interfaces": [{"interface": "ens35", "ipv4": {}}]}
    fact_cache.first_order_merge('host2', host_value)


# Generated at 2022-06-11 18:57:40.585497
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    key = "localhost"

    # Initialize FactCache object
    fc = FactCache()

    # First call to first_order_merge with key and value which is not in facts cache

# Generated at 2022-06-11 18:57:42.783478
# Unit test for constructor of class FactCache
def test_FactCache():
    assert CacheLoader() is not None

# Generated at 2022-06-11 18:58:08.506896
# Unit test for constructor of class FactCache
def test_FactCache():
    fake = FactCache()

# Generated at 2022-06-11 18:58:09.280194
# Unit test for constructor of class FactCache
def test_FactCache():
    c = FactCache()
    assert c is not None

# Generated at 2022-06-11 18:58:10.554220
# Unit test for constructor of class FactCache
def test_FactCache():
    assert (FactCache is not None)



# Generated at 2022-06-11 18:58:19.493076
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    cache = FactCache()

    key = 'host_key'
    value = {'first_key': 'first_value'}
    cache.first_order_merge(key, value)
    assert {key: value} == cache.copy()

    key = 'host_key2'
    value = {'second_key': 'second_value'}
    cache[key] = value
    assert {key: value} == cache.copy()

    key = 'host_key'
    value = {'second_key': 'second_value'}
    cache.first_order_merge(key, value)
    assert {'host_key': {'first_key': 'first_value', 'second_key': 'second_value'}, 'host_key2': {'second_key': 'second_value'}} == cache.copy

# Generated at 2022-06-11 18:58:24.139439
# Unit test for constructor of class FactCache
def test_FactCache():
    plugin = cache_loader.get('memory')
    plugin.cache = { 'host': {'ANSIBLE_FACTS': {'foo': 'bar'}}}
    fc = FactCache()
    assert('host' in fc)
    assert(fc['host'] == {'foo': 'bar'})

# Generated at 2022-06-11 18:58:26.531581
# Unit test for constructor of class FactCache
def test_FactCache():
    fake_plugin = FakePlugin()
    factcache = FactCache(plugin=fake_plugin)
    return factcache



# Generated at 2022-06-11 18:58:29.674771
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    # Test that constructor returns a FactCache object
    assert isinstance(fact_cache, FactCache)


# Generated at 2022-06-11 18:58:31.550989
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache._plugin is not None

# Generated at 2022-06-11 18:58:33.525969
# Unit test for constructor of class FactCache
def test_FactCache():
    """
    This unit test only check the code coverage for constructor of class FactCache
    """
    display.set_verbosity(2)
    facts = FactCache()
    display.set_verbosity(0)

# Generated at 2022-06-11 18:58:42.045532
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # define mock plugin
    cached_ansible_facts = None
    class MockPlugin:
        def set(self, key, value):
            global cached_ansible_facts
            cached_ansible_facts = value
        def get(self, key):
            global cached_ansible_facts
            return cached_ansible_facts
        def flush(self):
            global cached_ansible_facts
            cached_ansible_facts = None
        def contains(self, key):
            return False
        def keys(self):
            global cached_ansible_facts
            if cached_ansible_facts:
                return cached_ansible_facts.keys()
            else:
                return []
    # define local fact cache
    fact_cache = FactCache(MockPlugin())
    # test first_order_merge adding new key
    fact

# Generated at 2022-06-11 18:59:38.778604
# Unit test for constructor of class FactCache
def test_FactCache():
    facts = FactCache()
    assert isinstance(facts, FactCache)
    facts['test'] = 'test2'
    assert facts['test'] == 'test2'
    assert 'test' in facts
    facts.flush()
    assert 'test' not in facts


# Generated at 2022-06-11 18:59:39.770165
# Unit test for constructor of class FactCache
def test_FactCache():
    c = FactCache()
    assert c._plugin == 'memory'

# Generated at 2022-06-11 18:59:41.422934
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert isinstance(fc, FactCache)

# Generated at 2022-06-11 18:59:44.806235
# Unit test for constructor of class FactCache
def test_FactCache():
    ret = FactCache()
    assert ret._plugin.cache_name == C.CACHE_PLUGIN

# Generated at 2022-06-11 18:59:52.954403
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    assert fc.keys() == []
    assert fc.copy() == {}
    assert fc.get('foo') == None
    assert fc.get('foo', default='bar') == 'bar'

    fc['foo'] = {}
    assert fc.get('foo') == {}

    fc.first_order_merge('foo', {'key1': 'value1'})
    assert fc.get('foo') == {'key1': 'value1'}

    fc.first_order_merge('foo', {'key2': 'value2'})
    assert fc.get('foo') == {'key1': 'value1', 'key2': 'value2'}

# Generated at 2022-06-11 19:00:00.358046
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    fact_cache = FactCache()
    host_name = "host1"

    facts = {
        'first_fact': "1"
    }

    # test new entry
    fact_cache.first_order_merge(host_name, facts)
    assert fact_cache[host_name] == facts

    # test updating new entry
    facts = {
        'first_fact': "1",
        'second_fact': "2"
    }
    fact_cache.first_order_merge(host_name, facts)
    assert fact_cache[host_name] == facts

    # test updating existing entry
    facts = {
        'first_fact': "3"
    }
    fact_cache.first_order_merge(host_name, facts)
    assert fact_cache[host_name] == facts



# Generated at 2022-06-11 19:00:08.608091
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('test_key', {'test_value1': 1, 'test_value2': 2})
    assert fact_cache['test_key'] == {'test_value1': 1, 'test_value2': 2}
    fact_cache.first_order_merge('test_key', {'test_value2': 3, 'test_value3': 4})
    assert fact_cache['test_key'] == {'test_value1': 1, 'test_value2': 3, 'test_value3': 4}
    assert fact_cache.keys() == ['test_key']



# Generated at 2022-06-11 19:00:09.116714
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()

# Generated at 2022-06-11 19:00:10.169642
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert(fact_cache)

# Generated at 2022-06-11 19:00:13.285341
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    cache['1'] = 1
    cache['2'] = 2
    assert cache['1'] == 1
    assert cache['2'] == 2


# Generated at 2022-06-11 19:02:08.273597
# Unit test for constructor of class FactCache
def test_FactCache():
    """
    FactCache class testing
    This is for the constructor of the FactCache class
    """
    test = FactCache()
    assert isinstance(test, FactCache)



# Generated at 2022-06-11 19:02:12.432845
# Unit test for constructor of class FactCache
def test_FactCache():
    #Constructor of FactCache
    fc = FactCache(test=1)
    assert fc._plugin.name == C.CACHE_PLUGIN
    assert fc['test'] == 1


# Generated at 2022-06-11 19:02:13.143206
# Unit test for constructor of class FactCache
def test_FactCache():
    pass

# Generated at 2022-06-11 19:02:21.075984
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    cache.first_order_merge("host1", {"ansible_os_family":"RedHat", "ansible_architecture":"x86_64"})
    host_cache = cache.copy()["host1"]
    assert "ansible_os_family" in host_cache
    assert "ansible_architecture" in host_cache
    assert host_cache["ansible_os_family"] == "RedHat"
    assert host_cache["ansible_architecture"] == "x86_64"
    assert "ansible_distribution" not in host_cache
    cache.first_order_merge("host1", {"ansible_os_family":"RedHat", "ansible_architecture":"x86_64", "ansible_distribution":"CentOS"})

# Generated at 2022-06-11 19:02:24.106952
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    print(cache)
    cache['key'] = 'value'
    print(cache)
    del cache['key']
    print(cache)


# Generated at 2022-06-11 19:02:32.930802
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    class FO_Mock(object):
        def __init__(self):
            self.facts = {}

        def get(self, key):
            return self.facts.get(key)

        def contains(self, key):
            return key in self.facts

        def set(self, key, value):
            self.facts[key] = value

        def delete(self, key):
            self.facts.pop(key)

        def flush(self):
            self.facts = {}

        def keys(self):
            return self.facts.keys()

    fc = FactCache()
    fc._plugin = FO_Mock()

    fc.first_order_merge("host1", {"foo": "bar"})
    assert fc["host1"] == {"foo": "bar"}
    fc.first_order_