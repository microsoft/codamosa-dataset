

# Generated at 2022-06-11 18:52:38.309840
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import json

    fact_cache = FactCache()
    _key = "host.example.com"
    _value = {"some":{"data":{"to":{"cache":"here"}}}}

    # Test first time caching this value for this key
    fact_cache.first_order_merge(_key, _value)
    cache_copy = fact_cache.copy()
    assert _key in cache_copy
    assert cache_copy[_key] == _value

    # Test when updating this value for this key
    _new_value = {"some":{"new":"data","to":{"cache":"here"}}}
    fact_cache.first_order_merge(_key, _new_value)
    cache_copy = fact_cache.copy()
    assert cache_copy[_key] == {"some":{"new":"data","data":{"to":{"cache":"here"}}}}

#

# Generated at 2022-06-11 18:52:49.693686
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import os
    import json
    import tempfile

    _,cache_file = tempfile.mkstemp()
    os.environ['ANSIBLE_CACHE_PLUGIN'] = 'jsonfile'
    os.environ['ANSIBLE_CACHE_PLUGIN_CONNECTION'] = cache_file

    cache = FactCache()
    value = {'fact1': 'value1'}
    cache.first_order_merge('host1', value)
    assert 'host1' in cache.keys()

    value = {'fact2': 'value2'}
    cache.first_order_merge('host1', value)
    assert 'fact1' in cache['host1'] and 'fact2' in cache['host1']

    os.unlink(cache_file)

# Generated at 2022-06-11 18:52:55.998208
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    key = "localhost"
    value = {"a": 1, "b": 2}

    fc.first_order_merge(key, value)
    assert fc[key] == value

    fc.first_order_merge(key, {"c": 3})
    assert fc[key] == {"a": 1, "b": 2, "c": 3}, \
        "Failed to merge the new value"

# Generated at 2022-06-11 18:53:04.097963
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import json
    import tempfile

    expectation_key = "test_cache_key"
    expectation_value = {
        "a" : 1,
        "b" : 2,
        "c" : 3
    }

    # Create the test cache and first_order_merge the expectation
    tmp_path = tempfile.mkdtemp()

# Generated at 2022-06-11 18:53:11.700474
# Unit test for constructor of class FactCache
def test_FactCache():
    # Test empty constructor
    fc = FactCache()

    # Test with a fake plugin
    class FooPlugin:
        def __init__(self):
            pass

        def contains(self, key):
            return False

        def get(self, key):
            raise KeyError

        def set(self, key, value):
            pass

        def delete(self, key):
            pass

        def keys(self):
            return []

        def flush(self):
            pass

    fc = FactCache(plugin_type=FooPlugin())



# Generated at 2022-06-11 18:53:19.053663
# Unit test for constructor of class FactCache
def test_FactCache():

    try:
        # test the case where the plugin is invalid
        f = FactCache(CACHE_PLUGIN='not_a_valid_plugin')
    except AnsibleError:
        pass
    else:
        raise Exception('The plugin was invalid but FactCache accepted it.')
    finally:
        # reset the cache plugin to the default
        f._plugin = cache_loader.get(C.CACHE_PLUGIN)


# Generated at 2022-06-11 18:53:28.580244
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.plugins.loader import cache_loader
    from ansible.utils.display import Display

    assert isinstance(FactCache(), MutableMapping)

    # Check that AnsibleError is raised if cache_loader cannot load the facts cache plugin
    cache_loader_get = cache_loader.get

    try:
        def cache_loader_get_mock(plugin_name):
            if plugin_name == C.CACHE_PLUGIN:
                return None
            return cache_loader_get(plugin_name)

        cache_loader.get = cache_loader_get_mock
        assert FactCache()
    except AnsibleError as e:
        assert "Unable to load the facts cache plugin (memory)." in str(e)
   

# Generated at 2022-06-11 18:53:30.312139
# Unit test for constructor of class FactCache
def test_FactCache():
    factcache = FactCache()
    assert factcache is not None

# Generated at 2022-06-11 18:53:36.426747
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fake_cache = {'a':{'b':1}}
    assert(fake_cache['a']['b'] == 1)

    fc = FactCache()
    # insert a test value into the cache to check if it gets updated correctly
    fc._plugin.set('a',{'b':1})
    fc.first_order_merge('a', {'c':2})

    assert(fc['a']['b'] == 1)
    assert(fc['a']['c'] == 2)

# Generated at 2022-06-11 18:53:45.795113
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache['first_key'] = {'sub-key': 'previous_value'}
    fact_cache.first_order_merge('first_key', {'sub-key': 'new_value'})
    assert fact_cache['first_key'] == {'sub-key': 'new_value'}

    fact_cache['second_key'] = {'sub-key': 'original_value'}
    fact_cache.first_order_merge('second_key', {'new_key': 'new_value'})
    assert fact_cache['second_key'] == {'sub-key': 'original_value', 'new_key': 'new_value'}

# Generated at 2022-06-11 18:53:49.595454
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)


# Generated at 2022-06-11 18:53:56.839254
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    key = 'key'
    value = {'nested_key': 'value'}
    cache = FactCache()
    cache.first_order_merge(key, value)
    assert cache.get(key) == value
    value = {'nested_key': 'new_value'}
    cache.first_order_merge(key, value)
    assert cache.get(key)['nested_key'] == 'new_value'


# Generated at 2022-06-11 18:54:05.205741
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.plugins.cache import BaseFileCacheModule
    from ansible.cache.memory import FactMemoryCacheModule
    from ansible.plugins.cache.jsonfile import FactCacheModule as JSONFactCacheModule

    assert isinstance(FactCache(), BaseFileCacheModule)

# Generated at 2022-06-11 18:54:12.669601
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    fqdn = 'testhost.example.com'
    host_facts = {'ansible_fqdn': fqdn, 'ansible_python_version': '2.7.5'}
    cache.first_order_merge(fqdn, host_facts)
    assert 'ansible_python_version' in cache[fqdn]
    assert cache['ansible_python_version'] is None
    assert cache[fqdn]['ansible_python_version'] == '2.7.5'
    assert 'ansible_fqdn' not in cache

# Generated at 2022-06-11 18:54:14.684220
# Unit test for constructor of class FactCache
def test_FactCache():
    '''
    This is to test the initialization of class FactCache
    '''
    c=FactCache()
    assert c._plugin

# Generated at 2022-06-11 18:54:19.275746
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc.first_order_merge("test", "value")
    assert fc["test"] == "value"

    fc.first_order_merge("test", "newvalue")
    assert fc["test"] == "newvalue"

# Generated at 2022-06-11 18:54:29.670201
# Unit test for constructor of class FactCache
def test_FactCache():
    import pytest
    cache = FactCache()
    assert isinstance(cache, MutableMapping)

    # cache_plugin should be set
    assert cache._plugin

    # test __getitem__
    with pytest.raises(KeyError):
        cache['test_key']

    # test __setitem__
    cache['test_key'] = 'test_value'
    assert cache['test_key'] == 'test_value'

    # test __delitem__
    del cache['test_key']
    with pytest.raises(KeyError):
        cache['test_key']

    # test copy
    cache['test_key'] = 'test_value'
    copy = cache.copy()
    assert copy['test_key'] == 'test_value'

    # test flush
    cache.flush()

# Generated at 2022-06-11 18:54:37.895148
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import os
    import json
    import tempfile
    import shutil
    import unittest
    from nose.plugins.skip import SkipTest
    from ansible.module_utils._text import to_bytes

    from ansible.module_utils.facts import cache

    class TestFactCache_first_order_merge(unittest.TestCase):
        ''' Unit tests for Ansible facts cache method first_order_merge '''

        def setUp(self):
            self.test_dir = tempfile.mkdtemp(prefix='ansible_test_cache_dir')
            self.cwd = os.getcwd()
            self.user_cache_dir = os.path.expanduser(C.CACHE_PLUGIN_CONNECTION)

# Generated at 2022-06-11 18:54:38.759368
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()

# Generated at 2022-06-11 18:54:42.587497
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc['key'] = {'a':1, 'b':2}
    fc.first_order_merge('key', {'a':2, 'c':3})
    assert fc['key'] == {'a':2, 'b':2, 'c':3}

# Generated at 2022-06-11 18:54:52.421094
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    from unittest import mock

    fact_cache = FactCache()

    host_facts = {'val1': 'value1', 'val2': 'value2'}
    host_facts_with_update = {'val1': 'value1', 'val2': 'value2', 'val3': 'value3'}

    with mock.patch.object(fact_cache._plugin, 'get', return_value=host_facts):
        fact_cache.first_order_merge('hostname', host_facts)
        assert fact_cache['hostname'] == host_facts

    with mock.patch.object(fact_cache._plugin, 'get', return_value=host_facts_with_update):
        fact_cache.first_order_merge('hostname', host_facts)
        assert fact_cache['hostname'] == host_

# Generated at 2022-06-11 18:55:01.208306
# Unit test for constructor of class FactCache
def test_FactCache():
  import os
  import tempfile
  # To test the constructor, we need to set the environment variable
  # ANSIBLE_CACHE_PLUGIN to a known-working plugin
  os.environ['ANSIBLE_CACHE_PLUGIN'] = 'jsonfile'
  # We need to set ANSIBLE_CACHE_PLUGIN_CONNECTION to a temporary path
  # that will not be used by anything else
  oldpath = os.environ.get('ANSIBLE_CACHE_PLUGIN_CONNECTION', None)
  ansible_var = tempfile.mkdtemp()
  os.environ['ANSIBLE_CACHE_PLUGIN_CONNECTION'] = ansible_var
  assert FactCache()
  # We need to clean up the temporary directory

# Generated at 2022-06-11 18:55:03.124541
# Unit test for constructor of class FactCache
def test_FactCache():
    test = FactCache()
    assert test



# Generated at 2022-06-11 18:55:07.568652
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc.first_order_merge("localhost", {"ansible_distribution_version": "0.9"})
    fc.first_order_merge("localhost", {"ansible_distribution": "Ubuntu"})
    assert fc["localhost"] == {"ansible_distribution": "Ubuntu", "ansible_distribution_version": "0.9"}

# Generated at 2022-06-11 18:55:08.360837
# Unit test for constructor of class FactCache
def test_FactCache():
    ansible_cache_facts = FactCache()

# Generated at 2022-06-11 18:55:18.327491
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    t = FactCache()
    t.first_order_merge('test', {'foo': 'bar'})
    assert t.get('test') == {'foo': 'bar'}

    t['test'] = {'foo': 'bar'}
    t.first_order_merge('test', {'foo': 'bar'})
    assert t.get('test') == {'foo': 'bar'}

    t['test'] = {'foo': 'bar'}
    t.first_order_merge('test', {'foobar': 'bar'})
    assert t.get('test') == {'foo': 'bar', 'foobar': 'bar'}

    t = FactCache()
    t.first_order_merge

# Generated at 2022-06-11 18:55:29.254565
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    display.display("Output: " + cache)

test_FactCache()

# Generated at 2022-06-11 18:55:30.066459
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin



# Generated at 2022-06-11 18:55:31.245906
# Unit test for constructor of class FactCache
def test_FactCache():
    with pytest.raises(AnsibleError):
        fact_cache = FactCache()


# Generated at 2022-06-11 18:55:33.726927
# Unit test for constructor of class FactCache
def test_FactCache():
    facts_cache = FactCache()
    assert facts_cache.__class__.__base__ == MutableMapping

# Generated at 2022-06-11 18:55:41.005576
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None
    fact_cache.flush()

# Generated at 2022-06-11 18:55:43.413631
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    print('fact_cache:' + str(fact_cache))

if __name__ == "__main__":
    test_FactCache()

# Generated at 2022-06-11 18:55:44.464262
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
     
    assert fc is not None

# Generated at 2022-06-11 18:55:47.714340
# Unit test for constructor of class FactCache
def test_FactCache():

    C.CACHE_PLUGIN = "jsonfile"
    cache = FactCache()
    print(cache)
    cache["key1"] = "value1"
    print(cache)
    cache.flush()
    print(cache)

# Generated at 2022-06-11 18:55:56.023119
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import json

    cache = FactCache()

    cache.first_order_merge(
        "localhost",
        {
            "ansible_facts": {
                "a": {
                    "b": {
                        "c": "d",
                    },
                    "e": "f",
                },
                "g": {
                    "__ansible_uuid__": "34b8051e-e4a8-4a25-9fa1-d2b08c7d2387",
                },
            },
        }
    )

    # assert the new value is correct

# Generated at 2022-06-11 18:55:58.096320
# Unit test for constructor of class FactCache
def test_FactCache():
    """ This is to test the constructor of FactCache class."""
    fc = FactCache()
    assert None != fc

# Generated at 2022-06-11 18:56:02.408970
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.plugins import cache_loader
    from ansible.cache.memory import FactMemoryCacheModule

    cache_loader.add_directory('./lib/ansible/plugins/cache')
    cache = FactCache()
    assert isinstance(cache._plugin, FactMemoryCacheModule)

# Generated at 2022-06-11 18:56:03.551179
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()

    assert isinstance(cache, FactCache)

# Generated at 2022-06-11 18:56:11.036432
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    factcache = FactCache()

    # Test when data isn't cached yet
    value = {
        "test_key": "test_value"
    }
    key = "localhost"
    factcache.first_order_merge(key, value)
    assert "localhost" in factcache
    localhost_data = factcache["localhost"]
    assert localhost_data["test_key"] == "test_value"

    # Assign new data to same key and verify
    value = {
        "new_test_key": "new_test_value"
    }
    factcache.first_order_merge(key, value)
    assert "localhost" in factcache
    localhost_data = factcache["localhost"]
    assert localhost_data["new_test_key"] == "new_test_value"
    assert localhost

# Generated at 2022-06-11 18:56:16.271472
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    for k, v in dict(a='1', b='2').items():
        fc[k] = v
    for k, v in fc.items():
        print(k, v)

    fc2 = FactCache()
    for k, v in dict(a='1', b='2', c='3', d='4').items():
        fc2[k] = v
    for k, v in fc2.items():
        print(k, v)

    #print(fc2['z'])
    del fc2['a']
    print(fc2['a'])
    print(fc2['b'])
    '''
    if 'z' not in fc2:
        print('Do not have the key:z')
    '''

# Generated at 2022-06-11 18:56:31.275996
# Unit test for constructor of class FactCache
def test_FactCache():

    fc = FactCache()
    assert fc._plugin

    fc2 = FactCache()
    assert fc2._plugin

# Generated at 2022-06-11 18:56:37.228917
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    from ansible import constants
    constants.CACHE_PLUGIN = 'jsonfile'

    fact_cache = FactCache()
    fact_cache.first_order_merge('127.0.0.1', {'hello': 'world'})
    fact_cache.first_order_merge('127.0.0.1', {'foo': 'bar'})
    fact_cache.first_order_merge('127.0.0.1', {'foo': 'baz'})

    assert fact_cache['127.0.0.1']['hello'] == 'world'
    assert fact_cache['127.0.0.1']['foo'] == 'baz'



# Generated at 2022-06-11 18:56:40.114728
# Unit test for constructor of class FactCache
def test_FactCache():
    import os
    fc = FactCache('test_cache', 'data', 'data.cache')
    fc.flush()
    os.remove('data.cache')

# Generated at 2022-06-11 18:56:40.915929
# Unit test for constructor of class FactCache
def test_FactCache():
    assert isinstance(FactCache(), FactCache)

# Generated at 2022-06-11 18:56:42.646107
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-11 18:56:47.026051
# Unit test for constructor of class FactCache
def test_FactCache():
    # Arrange
    cache_plugin = 'jsonfile'
    C.CACHE_PLUGIN = cache_plugin
    key = 'cache'
    value = 'cachevalue'
    args = []
    kwargs = {}
    fact_cache = FactCache(*args, **kwargs)

    # Act
    fact_cache[key] = value
    result = fact_cache[key]

    # Assert
    assert key in fact_cache
    assert result == 'cachevalue'

# Generated at 2022-06-11 18:56:47.588460
# Unit test for constructor of class FactCache
def test_FactCache():
    FactCache()

# Generated at 2022-06-11 18:56:48.827806
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc.__class__.__name__ == 'FactCache'

# Generated at 2022-06-11 18:56:55.843111
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    display.verbosity = 3
    f = FactCache()
    test_facts = {'foo': 'bar'}
    cache_key = 'localhost'
    f.first_order_merge(cache_key, test_facts)
    # Testing that method first_order_merge uses method __setitem__
    f.first_order_merge = lambda cache_key, test_facts: object()
    f.first_order_merge(cache_key, test_facts)

if __name__ == "__main__":
    test_FactCache_first_order_merge()

# Generated at 2022-06-11 18:56:56.645939
# Unit test for constructor of class FactCache
def test_FactCache():
    assert FactCache._plugin == 'memory'

# Generated at 2022-06-11 18:57:28.995551
# Unit test for constructor of class FactCache
def test_FactCache():
    # Test correct init
    fc = FactCache()

    # Test init with error
    def empty_get(self):
        raise AnsibleError("TEST")
    import mock
    with mock.patch('ansible.plugins.cache.facts.BaseFileCache.get', empty_get):
        try:
            fc = FactCache()
            fc.get("test")
            raise AssertionError("Expected error")
        except AnsibleError as e:
            assert str(e) == "TEST"

# Generated at 2022-06-11 18:57:34.333541
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.plugins.cache.jsonfile import Plugin as jsonfile
    cache_plugin = jsonfile()
    assert cache_plugin.keys() is None
    assert cache_plugin.flush() is None
    assert cache_plugin.get('localhost') is None
    assert cache_plugin.set('localhost', None) is None

# Generated at 2022-06-11 18:57:39.354460
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache({"foo": "bar"})
    assert len(fc) == 1
    assert fc["foo"] == "bar"
    assert "foo" in fc
    assert "bar" not in fc
    assert len(list(fc.keys())) == 1
    assert list(fc.keys())[0] == "foo"

    fc.flush()
    assert len(fc) == 0



# Generated at 2022-06-11 18:57:49.646614
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import pytest
    from ansible.module_utils.common._collections_compat import MutableMapping
    from collections import MutableMapping as abc_MutableMapping

    cached_facts_pre = {'host01': {'cache1': 'cache1'}, 'host02': {'cache2': 'cache2'}}
    new_facts = {'host01': {'cache1': 'cache1', 'new': 'new'}, 'host02': {'cache2': 'cache2', 'new': 'new'}, 'host03': {'cache3': 'cache3', 'new': 'new'}}

# Generated at 2022-06-11 18:57:59.700189
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible import context
    from ansible.plugins.loader import cache_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.utils.display import Display
    from ansible.utils.hashes import md5s
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    ctx = context.CLIARGS
    ctx._options['force_color'] = True
    ctx.become_method = 'sudo'
    ctx.become_user = 'root'
    ctx.become = True
    ctx.connection = 'ssh'
    ctx.check = False
    ctx.diff = False

# Generated at 2022-06-11 18:58:10.243408
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    """unit test - test_FactCache_first_order_merge"""
    cache = FactCache()
    cache.flush()

    assert not cache

    # Simulate the first time we run on a host and load the cache
    cache.first_order_merge('test_host', {'foo': 'bar'})

    # Validate that our key is set as expected
    cache_value = cache.get('test_host', {})
    assert cache_value == {'foo': 'bar'}

    # Now validate that the cache is not overridden when we run
    # on the same host again
    cache.first_order_merge('test_host', {'foo': 'zap'})

    # Validate that our key is set as expected
    cache_value = cache.get('test_host', {})
    assert cache_value

# Generated at 2022-06-11 18:58:11.032929
# Unit test for constructor of class FactCache
def test_FactCache():
    fact = FactCache()
    assert fact

# Generated at 2022-06-11 18:58:18.566362
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    display.verbosity = 4
    cache = FactCache()

    cache.first_order_merge("test_1", {"a": 1, "b": 2})

    assert cache["test_1"] == {"a": 1, "b": 2}

    cache.first_order_merge("test_1", {"b": 3})

    assert cache["test_1"] == {"a": 1, "b": 3}

    cache.first_order_merge("test_1", {"c": 4})

    assert cache["test_1"] == {"a": 1, "b": 3, "c": 4}

    cache.flush()

# Generated at 2022-06-11 18:58:21.303832
# Unit test for constructor of class FactCache
def test_FactCache():
    c = FactCache()
    assert c is not None

# unit test for set

# Generated at 2022-06-11 18:58:31.556914
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    f1 = {'ipv4': {'address': '10.0.0.1'}}
    f2 = {'ipv6': {'address': 'fe80::1'}}
    f3 = {'ipv4': {'address': '10.0.0.3'}}

    # Test merge with existing facts
    cache = FactCache()
    cache._plugin = {'ansible_facts': {'p1': f1, 'p2': f2}}
    cache.first_order_merge('p1', f3)

    assert cache['p1'] == {'ipv4': {'address': '10.0.0.3'}, 'ipv6': {'address': 'fe80::1'}}

# Generated at 2022-06-11 18:59:25.591692
# Unit test for constructor of class FactCache
def test_FactCache():
    assert isinstance(FactCache(), FactCache)

# Generated at 2022-06-11 18:59:27.067947
# Unit test for constructor of class FactCache
def test_FactCache():
    factcache = FactCache()

    try:
        factcache.flush()
    except:
        assert(False)
    else:
        assert(True)

# Generated at 2022-06-11 18:59:29.582610
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert isinstance(cache, MutableMapping)



# Generated at 2022-06-11 18:59:38.224977
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    display.display('FactCache organization: %s' % cache)
    assert len(cache) == 0
    assert cache.keys() == []
    cache['this'] = 1
    display.display('FactCache organization after adding \'this\': %s' % cache)
    assert cache.keys() == ['this']
    cache['that'] = 2
    display.display('FactCache organization after adding \'that\': %s' % cache)
    assert cache.keys() == ['this', 'that']
    cache.flush()
    display.display('FactCache organization after flushing: %s' % cache)
    assert cache.keys() == []

# Generated at 2022-06-11 18:59:39.839322
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert isinstance(cache, FactCache)
    assert isinstance(cache, MutableMapping)

# Generated at 2022-06-11 18:59:41.072951
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc

# Generated at 2022-06-11 18:59:45.168214
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        f = FactCache()
        assert True
    except:
        assert False

# Test if FactCache of class FactCache has method first_order_merge

# Generated at 2022-06-11 18:59:48.279180
# Unit test for constructor of class FactCache
def test_FactCache():
    display.debug("FactCache.py, cache_plugin: %s" % C.CACHE_PLUGIN)
    assert 'FactCache' in [ x for x in vars(FactCache).keys() if not x.startswith('_') ]

# Generated at 2022-06-11 18:59:50.761201
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        cache = FactCache()
    except AnsibleError:
        pass
    else:
        assert False, "AnsibleError exception should've been raised"

# Generated at 2022-06-11 18:59:51.662674
# Unit test for constructor of class FactCache
def test_FactCache():
    FactCache()


# Generated at 2022-06-11 19:01:50.757149
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.cache import fact_cache
    from ansible.plugins.cache.jsonfile import CacheModule as jsonfilecache

    test_args = ('localhost', 'test-module')
    # instantiate cache object
    fc = fact_cache.FactCache()
    # default ansible config
    fc.init(*test_args)
    assert isinstance(fc, FactCache)

    # custom jsonfile cache module
    fc_json = FactCache(plugin=jsonfilecache)
    fc_json.init(*test_args)
    assert isinstance(fc_json, FactCache)

    # invalid cache module
    error_msg = 'Unable to load the facts cache plugin (dummy).'

# Generated at 2022-06-11 19:01:51.635538
# Unit test for constructor of class FactCache
def test_FactCache():
    facts = FactCache()
    assert isinstance(facts, FactCache)

# Generated at 2022-06-11 19:01:52.667883
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache
    assert isinstance(fact_cache, FactCache)

# Generated at 2022-06-11 19:02:03.050111
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert isinstance(cache, MutableMapping)

    # GET
    assert cache['localhost'] is None

    # SET
    cache['localhost'] = {'a': 1}

    # GET
    assert cache['localhost']['a'] == 1

    # DELETE
    del cache['localhost']
    assert cache['localhost'] is None

    # UPDATE
    cache.update({'localhost': None})
    cache.update({'localhost': {'a': 1}})
    assert cache['localhost']['a'] == 1

    # FIRST_ORDER_MERGE
    cache.first_order_merge('localhost', {'b': 2})
    assert cache['localhost']['b'] == 2
    cache.first_order_merge('localhost', {'a': 3})

# Generated at 2022-06-11 19:02:08.188413
# Unit test for constructor of class FactCache

# Generated at 2022-06-11 19:02:10.054871
# Unit test for constructor of class FactCache
def test_FactCache():
    fact = FactCache()
    assert fact != None

# Generated at 2022-06-11 19:02:19.819539
# Unit test for constructor of class FactCache
def test_FactCache():
    import os
    import tempfile
    from ansible.plugins.cache import FactCacheModule

    if 'FACTS_CACHE_PLUGIN' in os.environ:
        del os.environ['FACTS_CACHE_PLUGIN']

    with tempfile.NamedTemporaryFile() as tf:
        os.environ['FACTS_CACHE_PLUGIN'] = tf.name
        try:
            fc = FactCache()
            assert isinstance(fc._plugin, FactCacheModule)
        finally:
            os.environ.pop('FACTS_CACHE_PLUGIN')

    #As this file name and path depend on the runtime environment, it is not possible to test with a normal file
    #However, we can test that the initialization logic of the FactCache class works as intended without


# Generated at 2022-06-11 19:02:30.688743
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import tempfile, shutil
    from ansible.plugins.cache import jsonfile

    facts_cache = FactCache()

    class Config:
        CACHE_PLUGIN = 'jsonfile'
        CACHE_PLUGIN_CONNECTION = tempfile.mkdtemp(prefix='ansible_test_fact_cache_')
        CACHE_PLUGIN_PREFIX = 'prefix'

    def _make_plugin(config):
        return jsonfile.JSONFile(config)

    jsonfile.JSONFile._make_plugin = _make_plugin

    # Set a cache entry and verify that 'first_order_merge' updates it
    facts_cache.__setitem__('myhost', {'foo': 'bar'})
    assert facts_cache['myhost'] == {'foo': 'bar'}
    facts_