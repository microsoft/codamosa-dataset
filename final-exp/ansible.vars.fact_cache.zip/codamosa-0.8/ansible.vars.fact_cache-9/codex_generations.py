

# Generated at 2022-06-11 18:52:31.872192
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert isinstance(fc, FactCache)
    assert isinstance(fc, MutableMapping)
    assert len(fc) == 0
    assert fc._plugin.name == "jsonfile"


# Generated at 2022-06-11 18:52:40.389088
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    def getter(key):
        return {'test': {'test2': 'test_v1'}}

    def setter(key, value):
        self.assertEqual(key, 'test')
        self.assertEqual(value.keys(), ['test'])
        self.assertEqual(value['test']['test2'], 'test_v2')
        self.assertEqual(value['test']['test3'], 'test_v3')


    with patch('ansible.plugins.cache.FactCache._plugin.get', getter), patch('ansible.plugins.cache.FactCache._plugin.set', setter):
        fact_cache = FactCache()

# Generated at 2022-06-11 18:52:44.659605
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    host_facts = {
        'host_facts': {
            'kernel': 'Linux',
            'os': 'CentOS'
        }
    }

    fc.first_order_merge("host_facts", host_facts)

    assert host_facts == fc

# Generated at 2022-06-11 18:52:46.316429
# Unit test for constructor of class FactCache
def test_FactCache():
    testfactcache = FactCache()
    assert testfactcache, "Unable to initialize the Factcache object"

# Generated at 2022-06-11 18:52:54.151955
# Unit test for constructor of class FactCache
def test_FactCache():
    host = '127.0.0.1'

# Generated at 2022-06-11 18:52:55.772008
# Unit test for constructor of class FactCache
def test_FactCache():
    assert len(FactCache()) == 0


# Generated at 2022-06-11 18:52:59.070855
# Unit test for constructor of class FactCache
def test_FactCache():

    cache_plugin_name = "jsonfile"
    fact_cache = FactCache()

    assert cache_plugin_name == fact_cache._plugin.PLUGIN_NAME
    assert fact_cache._plugin.get("/") == None

# Generated at 2022-06-11 18:53:06.458103
# Unit test for constructor of class FactCache
def test_FactCache():
    c = FactCache()
    assert c
    assert not c
    c[1] = 1
    c[2] = 2
    c[3] = 3
    assert c
    assert len(c) == 3
    assert 1 in c
    assert 2 in c
    assert 3 in c
    assert 4 not in c
    assert c[1] == 1
    assert c[2] == 2
    assert c[3] == 3
    del c[1]
    assert 1 not in c
    assert len(c) == 2
    del c[2]
    del c[3]
    assert len(c) == 0
    assert not c
    c[1] = 2
    assert len(c) == 1
    assert 1 in c
    assert c[1] == 2
    del c[1]

# Generated at 2022-06-11 18:53:08.585715
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache(None)
    assert 'loader' in fc._plugin.__class__.__name__

# Generated at 2022-06-11 18:53:15.578196
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    key = 'host_name'
    value = {'fact_key': 'fact_value'}
    fact_cache.first_order_merge(key, value)

    assert fact_cache.keys() == ['host_name']
    assert fact_cache['host_name'] == {'fact_key': 'fact_value'}
    value2 = {'fact_key2': 'fact_value2'}
    fact_cache.first_order_merge(key, value2)
    assert fact_cache['host_name'] == {'fact_key': 'fact_value', 'fact_key2': 'fact_value2'}

# Generated at 2022-06-11 18:53:24.826693
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    """ Test that facts are properly merged. """
    fact_cache = FactCache()
    value = { 'a': '1', 'b': '2' }

    fact_cache.first_order_merge('localhost', value)
    assert fact_cache['localhost'] == value

    value = { 'b': '3', 'c': '4' }
    fact_cache.first_order_merge('localhost', value)
    assert fact_cache['localhost'] == { 'a': '1', 'b': '3', 'c': '4' }


# Generated at 2022-06-11 18:53:34.789725
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible import context
    from ansible.utils.path import unfrackpath
    from ansible.vars.hostvars import HostVars
    context.CLIARGS = {}
    context.CLIARGS['fact_cache_type'] = u'jsonfile'
    context.CLIARGS['fact_cache_connection'] = unfrackpath(u'/home/nonexistent/a/.ansible/caches/ansiballz')
    context.CLIARGS['fact_cache_timeout'] = u'30'
    from ansible.executor.task_queue_manager import TaskQueueManager

# Generated at 2022-06-11 18:53:44.865740
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    cache.first_order_merge('127.0.0.1', {'uname': 'linux'})
    assert '127.0.0.1' in cache
    assert 'uname' in cache['127.0.0.1']
    assert cache['127.0.0.1']['uname'] == 'linux'
    cache.first_order_merge('127.0.0.1', {'uname': 'darwin'})
    assert '127.0.0.1' in cache
    assert 'uname' in cache['127.0.0.1']
    assert cache['127.0.0.1']['uname'] == 'darwin'

# Generated at 2022-06-11 18:53:54.626190
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():


    # Case 1
    host_facts1 = {'ansible_os_family': 'RedHat'}
    host_facts2 = {'ansible_os_family': 'Debian'}

    cache = FactCache()
    cache.first_order_merge('host1', host_facts1)
    cache.first_order_merge('host1', host_facts2)

    assert cache['host1']['ansible_os_family'] == 'Debian'

    # Case 2
    host_facts1 = {
        'ansible_all_ipv4_addresses': ['10.1.1.1'],
        'ansible_all_ipv6_addresses': ['::1']
    }

# Generated at 2022-06-11 18:53:55.277399
# Unit test for constructor of class FactCache
def test_FactCache():
    assert FactCache()

# Generated at 2022-06-11 18:53:56.993394
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache is not None
    cache.flush()

# Generated at 2022-06-11 18:54:07.165788
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    host_facts = {'python': {'version': {'major': '2', 'minor': '7'}}}
    host_facts_new = {'python': {'version': {'major': '3', 'minor': '7'}}}
    fact_cache.first_order_merge('localhost', host_facts)
    fact_cache.first_order_merge('localhost', host_facts_new)
    assert fact_cache['localhost']['python']['version']['major'] == '3'
    assert fact_cache['localhost']['python']['version']['minor'] == '7'

# Generated at 2022-06-11 18:54:08.539112
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache  # nosec

# Generated at 2022-06-11 18:54:12.631751
# Unit test for constructor of class FactCache
def test_FactCache():
     fact_cache = FactCache()
     assert isinstance(fact_cache, cache_loader.get(C.CACHE_PLUGIN))
     assert isinstance(fact_cache, MutableMapping)
     fact_cache.flush()

# Generated at 2022-06-11 18:54:19.069727
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    hosts = ['host1', 'host2', 'host3', 'host4']
    facts = {}
    for h in hosts:
        facts[h] = {'foo': 'bar', 'baz': 'qux'}

    cache = FactCache()
    for h in hosts:
        cache.first_order_merge(h, facts[h])

    for h in hosts:
        assert cache[h] == facts[h]

# Generated at 2022-06-11 18:54:32.636349
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    cache = FactCache()

    # Tests with an empty cache
    host_facts = cache.first_order_merge("localhost", {"test": "value"})
    assert host_facts['localhost']['test'] == 'value'

    host_facts = cache.first_order_merge("localhost", {"test": "value2"})
    assert host_facts['localhost']['test'] == 'value2'

    cache.flush()

    # Tests with a cache full of facts

# Generated at 2022-06-11 18:54:37.942994
# Unit test for constructor of class FactCache
def test_FactCache():
    c = FactCache()
    assert c
    assert c._plugin is not None
    from ansible.plugins.cache.jsonfile import CacheModule as jsonfile_cache_module
    assert isinstance(c._plugin, jsonfile_cache_module)
    assert c._plugin._cachefile is not None
    assert c._plugin._cachefile == '~/.ansible/fact_cache/ansible_fact_cache'


# Unit test constructor of class FactCache

# Generated at 2022-06-11 18:54:39.296087
# Unit test for constructor of class FactCache
def test_FactCache():

    from ansible.plugins.cache import jsonfile

    cache = FactCache()

    assert cache._plugin == jsonfile

# Generated at 2022-06-11 18:54:41.403574
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache
    try:
        assert fc
    except:
        print("Test failed: FactCache")
        raise
    else:
        print("Test passed: FactCache")



# Generated at 2022-06-11 18:54:42.795507
# Unit test for constructor of class FactCache
def test_FactCache():

    f = FactCache()

    return f


# Generated at 2022-06-11 18:54:51.720500
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.utils.path import makedirs_safe
    from ansible.plugins.loader import cache_loader
    from ansible.errors import AnsibleError
    makedirs_safe('./test/cache_plugin', 0o755)

# Generated at 2022-06-11 18:55:00.514247
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge("host1", {'ansible_hostname': 'host1', 'ansible_fact_a': 1})
    fact_cache.first_order_merge("host2", {'ansible_hostname': 'host2', 'ansible_fact_a': 1, 'ansible_fact_b': 2})

    assert len(fact_cache) == 2
    assert fact_cache['host1'] == {'ansible_hostname': 'host1', 'ansible_fact_a': 1}
    assert fact_cache['host2'] == {'ansible_hostname': 'host2', 'ansible_fact_a': 1, 'ansible_fact_b': 2}

# Generated at 2022-06-11 18:55:07.167600
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    host_facts = {'foo': 'bar'}
    host_cache = {'foo': 'bar', 'baz': 'baz'}
    fc.first_order_merge('host1', host_facts)
    fc.first_order_merge('host1', host_facts)
    fc.first_order_merge('host2', host_cache)
    assert fc['host1'] == host_facts
    assert fc['host2'] == host_cache

# Generated at 2022-06-11 18:55:07.817101
# Unit test for constructor of class FactCache
def test_FactCache():
    f = FactCache()
    pass

# Generated at 2022-06-11 18:55:08.948385
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache != None



# Generated at 2022-06-11 18:55:19.400857
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    facts_cache_obj = FactCache()
    facts_cache_obj.first_order_merge("test_key", {"test_sub_key": "test_sub_value"})
    assert("test_key" in facts_cache_obj)
    assert("test_sub_key" in facts_cache_obj["test_key"])
    assert(facts_cache_obj["test_key"]["test_sub_key"] == "test_sub_value")

# Generated at 2022-06-11 18:55:22.061947
# Unit test for constructor of class FactCache
def test_FactCache():
    c = FactCache()
    c['localhost'] = {'ansible_facts': {'foo': 'bar'}}



# Generated at 2022-06-11 18:55:30.743546
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.plugins.cache import plugin_loader
    #super(FactCache, self).__init__(*args, **kwargs)
    #1. test __init__ success
    _plugin = plugin_loader.get(C.CACHE_PLUGIN)
    factCache = FactCache()
    factCache._plugin = _plugin
    assert(factCache)
    #2. test __init__ failed
    _plugin = plugin_loader.get(C.CACHE_PLUGIN)
    _plugin = None
    try:
        factCache = FactCache()
    except Exception as e:
        assert(str(e) == 'Unable to load the facts cache plugin (memory).')


# Generated at 2022-06-11 18:55:41.370388
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    host_name = 'test_host'

# Generated at 2022-06-11 18:55:45.790293
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    with open('ansible/plugins/cache/test_data/test_cache.json', 'r') as testcache_file:
        import json
        testcache = json.load(testcache_file)
        fc = FactCache()
        for key, value in testcache.items():
            fc.first_order_merge(key, value)

    print(fc)

# Generated at 2022-06-11 18:55:46.897318
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert not fc._plugin.contains('localhost')

# Generated at 2022-06-11 18:55:50.821713
# Unit test for constructor of class FactCache
def test_FactCache():
    data = {'test': {'test1': 'test1'}}
    f = FactCache()
    f.flush()
    assert len(f) == 0
    f.update(data)
    assert len(f) == 1
    assert 'test' in f

# Generated at 2022-06-11 18:56:02.248823
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge(key="one", value={'name1':"val1"})
    assert fact_cache.get("one") is not None
    fact_cache.first_order_merge(key="one", value={'name1':"val1"})
    assert fact_cache.get("one") is not None
    fact_cache.first_order_merge(key="one", value={'name1':"val2"})
    assert fact_cache.get("one") is not None
    fact_cache.first_order_merge(key="one", value={'name2':"val2"})
    assert fact_cache.get("one") is not None
    assert fact_cache.get("one").get("name1") == "val2"
   

# Generated at 2022-06-11 18:56:09.539150
# Unit test for constructor of class FactCache
def test_FactCache():
    class testPluigin():
        def get(self, key):
            return 'testKey'

        def set(self, key, value):
            pass

        def delete(self, key):
            pass

        def contains(self, key):
            return True

        def keys(self):
            return ['key1', 'key2']

        def flush(self):
            pass

    cache_loader.plugins = {'test': testPluigin()}
    cache = FactCache()
    assert cache['key1'] == 'testKey'
    cache['key1'] = 'testValue'
    assert 'key1' in cache
    assert len(cache) == 2
    cache.flush()

# Generated at 2022-06-11 18:56:16.342509
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin is not None
    fc.flush()
    assert fc._plugin.flush() is None
    assert fc._plugin.keys() == []
    assert fc._plugin.get('gundhoo') is None

# Unit test to check first order merge in fact cache

# Generated at 2022-06-11 18:56:28.553390
# Unit test for constructor of class FactCache
def test_FactCache():
    FactCache()

# Generated at 2022-06-11 18:56:36.379105
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()

# Generated at 2022-06-11 18:56:37.205195
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()


# Generated at 2022-06-11 18:56:39.794755
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    # Assert True if we create a new instance of FactCache
    assert isinstance(cache, FactCache)

# Generated at 2022-06-11 18:56:46.513252
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    cache = FactCache()
    assert not cache
    hostname = 'localhost'
    facts = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
    cache.first_order_merge(hostname, facts)
    assert hostname in cache

    cache.first_order_merge(hostname, {'key4': 'value4'})
    cache.first_order_merge(hostname, {'key4': 'value4_new', 'key5': 'value5'})
    assert cache[hostname]['key4'] == 'value4_new'

    cache.flush()

# Generated at 2022-06-11 18:56:55.657562
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    temp_fact_cache_items = {
        u'hostname1': {
            u'a': 1,
            u'b': 2,
            u'c': 3,
        },
        u'hostname2': {
            u'a': 4,
            u'b': 5,
            u'c': 6,
        },
        u'hostname3': {
            u'a': 7,
            u'b': 8,
            u'c': 9,
        },
    }
    temp_fact_cache = FactCache(temp_fact_cache_items)

    input_test_params = {u'a': 10, u'b': 20, u'c': 30}
    hostname = u'hostname'


# Generated at 2022-06-11 18:56:56.759909
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-11 18:56:58.876792
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache.__class__.__name__ == 'FactCache'

# Generated at 2022-06-11 18:57:00.722055
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    fc._plugin = {'key':'value'}
    fc['key']

# Generated at 2022-06-11 18:57:02.431147
# Unit test for constructor of class FactCache
def test_FactCache():
    test_instance = FactCache()
    assert test_instance._plugin is not None


# Generated at 2022-06-11 18:57:29.871378
# Unit test for constructor of class FactCache
def test_FactCache():
    fn = FactCache()
    assert(fn is not None)

# Generated at 2022-06-11 18:57:30.807242
# Unit test for constructor of class FactCache
def test_FactCache():
    # Test the constructor
    fact_cache = FactCache()

# Generated at 2022-06-11 18:57:33.069749
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache  = FactCache()

# Generated at 2022-06-11 18:57:39.728560
# Unit test for constructor of class FactCache
def test_FactCache():
    def initialize_cache():
        cache = FactCache()
        return cache
    def mock_plugin():
        class MockPlugin():
            def __init__(self):
                self.contains = lambda x: True
                self.get = lambda x : None
        return MockPlugin()
    mock_contains = lambda x, y: True
    mock_get = lambda x, y : None
    old_get = cache_loader.get
    cache_loader.get = mock_plugin
    cache = FactCache()
    cache_loader.get = old_get
    assert isinstance(cache, FactCache)



# Generated at 2022-06-11 18:57:49.854903
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # This is all we need for a simple test. I don't want to add a yaml test dependency
    class CachePlugin:
        def __init__(self):
            self._dict = {}

        def set(self, key, value):
            self._dict[key] = value

        def get(self, key):
            return self._dict[key]

        def contains(self, key):
            return key in self._dict

        def delete(self, key):
            del self._dict[key]

        def flush(self):
            self._dict = {}

        def keys(self):
            return self._dict.keys()

    fact_cache = FactCache()

    fact_cache._plugin = CachePlugin()

    assert 'key' not in fact_cache

    fact_cache.first_order_merge('key', {})
   

# Generated at 2022-06-11 18:57:59.845982
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    facts = FactCache()
    # Test with no existing cache
    value = {"ansible_hostname": "arbitrary_host_1"}
    facts.first_order_merge("arbitrary_host_1", value)
    assert facts["arbitrary_host_1"] == value
    # Test with existing cache
    value = {"ansible_facts": "arbitrary"}
    facts.first_order_merge("arbitrary_host_1", value)
    assert facts["arbitrary_host_1"] == {'ansible_facts': 'arbitrary', 'ansible_hostname': 'arbitrary_host_1'}
    # Test with existing cache
    value = {"ansible_facts": {"realm": {"realm": "arbitrary"}}}

# Generated at 2022-06-11 18:58:10.244106
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import os
    import shutil
    import tempfile

    tempdir = tempfile.mkdtemp()


# Generated at 2022-06-11 18:58:11.319840
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert not fact_cache

# Generated at 2022-06-11 18:58:12.561333
# Unit test for constructor of class FactCache
def test_FactCache():
    global display
    display._verbosity = 1
    fc = FactCache()
    assert isinstance(fc, FactCache)
    assert fc._plugin.name == C.CACHE_PLUGIN
    display.verbosity = 0

# Generated at 2022-06-11 18:58:12.834289
# Unit test for constructor of class FactCache
def test_FactCache():
    assert FactCache()

# Generated at 2022-06-11 18:59:13.204831
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()

    # The cache plugin should be able to be used as a dictionary
    fact_cache.update({'ansible_all_ipv4_addresses': ['192.168.254.2']})
    fact_cache.update({'ansible_all_ipv4_addresses': ['192.168.254.3']})
    assert fact_cache['ansible_all_ipv4_addresses'] == ['192.168.254.2', '192.168.254.3']

    assert len(fact_cache) == 1
    assert 'ansible_all_ipv4_addresses' in fact_cache
    fact_cache.flush()
    assert 'ansible_all_ipv4_addresses' not in fact_cache
    assert len(fact_cache) == 0
    fact_cache

# Generated at 2022-06-11 18:59:23.767372
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.plugins.cache import memory
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_text
    cache_fact = FactCache()

    cache_fact['test'] = 'test_value'

    assert isinstance(cache_fact['test'], (str)) if PY3 else isinstance(cache_fact['test'], (str, unicode)) == True
    assert cache_fact['test'] == 'test_value'

    if isinstance(memory, to_bytes):
        assert isinstance(list(cache_fact.keys())[0], (str)) if PY3 else isinstance(list(cache_fact.keys())[0], (str, unicode)) == True

# Generated at 2022-06-11 18:59:33.248827
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    my_facts_cache = FactCache()
    my_facts_cache.flush()

    my_facts_cache.first_order_merge(key="localhost", value={"ansible_distribution": "CentOS"})
    if my_facts_cache["localhost"] != {"ansible_distribution": "CentOS"}:
        raise AssertionError

    my_facts_cache.first_order_merge(key="localhost", value={"ansible_os_family": "RedHat"})
    if my_facts_cache["localhost"] != {"ansible_distribution": "CentOS", "ansible_os_family": "RedHat"}:
        raise AssertionError

    my_facts_cache.flush()

# Generated at 2022-06-11 18:59:34.970799
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc is not None

# Generated at 2022-06-11 18:59:35.359179
# Unit test for constructor of class FactCache
def test_FactCache():
    pass

# Generated at 2022-06-11 18:59:43.053694
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    def test_data():
        data = {'fact1': 'value1',
                'fact2': {
                    'fact3': 'value3',
                    'fact4': ['value4']
                    }
                }
        return data

    def test1():
        fact_cache = FactCache()

        data = test_data()
        host_name = 'host1'
        fact_cache.first_order_merge(host_name, data)
        expected = {host_name: {'fact1': 'value1',
                                'fact2': {
                                    'fact3': 'value3',
                                    'fact4': ['value4']
                                    }
                                }
                    }
        assert fact_cache == expected


# Generated at 2022-06-11 18:59:44.619610
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin

# Generated at 2022-06-11 18:59:46.090719
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert(isinstance(fact_cache, FactCache))

# Generated at 2022-06-11 18:59:53.393800
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    factcache = FactCache()
    test_facts = {'a': 1, 'b': 2, 'c': 3}
    key = 'test_host'
    factcache.first_order_merge(key, test_facts)
    assert factcache[key]['a'] == 1
    assert factcache[key]['b'] == 2
    assert factcache[key]['c'] == 3
    new_facts = {'a': 10, 'd': 4}
    factcache.first_order_merge(key, new_facts)
    assert factcache[key]['a'] == 10
    assert factcache[key]['b'] == 2
    assert factcache[key]['c'] == 3
    assert factcache[key]['d'] == 4
    another_facts = {'e': 5}

# Generated at 2022-06-11 19:00:00.377933
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()

    host_a_facts = {
        'test': 'this is a test'
    }

    host_b_facts = {
        'cached': 'this is a test'
    }

    fact_cache.first_order_merge('host_a', host_a_facts)
    fact_cache.first_order_merge('host_b', host_b_facts)

    assert fact_cache['host_a'] == host_a_facts
    assert fact_cache['host_b'] == host_b_facts

    host_b_facts_merged = {
        'cached': 'this is a test',
        'test': 'this is a test'
    }
    fact_cache.first_order_merge('host_b', host_a_facts)

# Generated at 2022-06-11 19:01:00.288719
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        fc = FactCache()
    except AnsibleError as e:
        if "Unable to load the facts cache plugin" in e.message:
            raise AnsibleError("Unable to load the facts cache plugin, "
                               "please check the CACHE_PLUGIN setting.")
        else:
            raise e

# Generated at 2022-06-11 19:01:01.741878
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_obj = FactCache()
    assert fact_cache_obj is not None


# Generated at 2022-06-11 19:01:03.592955
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.plugins.loader import cache_loader

    try:
        FactCache()
    except AnsibleError as e:
        assert e.message == 'Unable to load the facts cache plugin (memory).'
        display.display('Successfully covered AnsibleError in class FactCache')

# Generated at 2022-06-11 19:01:14.287631
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache_manager = FactCache()
    test_cache = {
        'cache_file': 'test_fact_cache',
        'cache_plugin': 'jsonfile',
        '_plugin': 'jsonfile', # for test purpose, we assume it's initialized
    }
    cache_manager.__dict__.update(test_cache)
    key = 'host1'
    value = {'a': 1}
    cache_manager.first_order_merge(key, value)
    assert cache_manager[key] == value
    value = {'a': 2}
    cache_manager.first_order_merge(key, value)
    assert cache_manager[key] == {'a': 2}
    value = {'b': 2}
    cache_manager.first_order_merge(key, value)
    assert cache

# Generated at 2022-06-11 19:01:15.083894
# Unit test for constructor of class FactCache
def test_FactCache():
    facts = FactCache()
    assert facts

# Generated at 2022-06-11 19:01:17.506641
# Unit test for constructor of class FactCache
def test_FactCache():
    file_cache = FactCache()

    assert isinstance(file_cache, MutableMapping)

# Generated at 2022-06-11 19:01:19.316328
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)

# Generated at 2022-06-11 19:01:21.878137
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin.__class__.__name__ == 'Memory'



# Generated at 2022-06-11 19:01:22.409102
# Unit test for constructor of class FactCache
def test_FactCache():
    assert True

# Generated at 2022-06-11 19:01:32.545688
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # prepare data
    a = {'a': 1, 'b': 2}
    b = {'b': 3, 'c': 4}
    c = {'c': 5, 'd': 6}

    # prepare object
    fact_obj = FactCache()

    # test 1
    fact_obj.first_order_merge('host1', a)
    fact_obj.first_order_merge('host1', b)
    assert fact_obj == {'host1': {'a': 1, 'b': 3, 'c': 4}}

    # test 2
    fact_obj.first_order_merge('host2', b)
    fact_obj.first_order_merge('host2', c)