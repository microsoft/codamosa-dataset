

# Generated at 2022-06-11 18:52:34.326372
# Unit test for constructor of class FactCache
def test_FactCache():
    """ Unit test to check FactCache initialisation """
    display.verbosity = 0
    cache_obj = FactCache()
    assert cache_obj.keys() == []
    assert not cache_obj.copy()

# Generated at 2022-06-11 18:52:35.476205
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin

# Generated at 2022-06-11 18:52:36.859453
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)


# Generated at 2022-06-11 18:52:43.878237
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc['key'] = {
        'key1': 'value1',
        'key2': 'value2'
    }
    fc.first_order_merge('key', {'key2': 'value3'})
    assert fc['key']['key1'] == 'value1'
    assert fc['key']['key2'] == 'value3'

# Generated at 2022-06-11 18:52:54.046843
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # all keys in dict value are new
    factCache_1 = FactCache()
    host_1 = 'dummyHost'
    key_1 = 'ansible_facts'
    value_1_1 = {'a': 1, 'b': 2}
    factCache_1.first_order_merge(key_1, value_1_1)
    assert factCache_1[host_1][key_1] == value_1_1

    # not all keys in dict value are new
    factCache_2 = FactCache()
    host_2 = 'dummyHost'
    key_2 = 'ansible_facts'
    value_2_1 = {'a': 1, 'b': 2}

# Generated at 2022-06-11 18:52:56.201709
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert isinstance(fc, FactCache) == True

# Generated at 2022-06-11 18:53:04.177296
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.flush()

    fact_cache.first_order_merge('key1', {'a': 'a', 'b': 'b', 'c': 'c'})
    assert fact_cache['key1'] == {'a': 'a', 'b': 'b', 'c': 'c'}

    fact_cache.first_order_merge('key1', {'d': 'd', 'e': 'e', 'f': 'f'})
    assert fact_cache['key1'] == {'a': 'a', 'b': 'b', 'c': 'c', 'd': 'd', 'e': 'e', 'f': 'f'}

    fact_cache.flush()

# Generated at 2022-06-11 18:53:05.985201
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        fact_cache = FactCache()
        assert fact_cache is not None
    except Exception as err:
        assert False, 'unexpected exception raised when constructing a FactCache object: %s' % str(err)


# Generated at 2022-06-11 18:53:09.163752
# Unit test for constructor of class FactCache
def test_FactCache():
    test_cache = FactCache()
    assert isinstance(test_cache, FactCache)
    # check that it contains a valid plugin
    assert isinstance(test_cache._plugin, MutableMapping)


# Generated at 2022-06-11 18:53:11.125818
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert isinstance(fc._plugin, cache_loader.get(C.CACHE_PLUGIN))


# Generated at 2022-06-11 18:53:13.899657
# Unit test for constructor of class FactCache
def test_FactCache():
    sut = FactCache()


# Generated at 2022-06-11 18:53:20.022247
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # create a fact cache
    fact_cache = FactCache()

    # key and value pair to be inserted or merged with existing cache

# Generated at 2022-06-11 18:53:21.876507
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache is not None
    assert cache._plugin == 'memory'

# Generated at 2022-06-11 18:53:23.597109
# Unit test for constructor of class FactCache
def test_FactCache():

    # Empty args and kwargs
    fc = FactCache(None)
    return True


# Generated at 2022-06-11 18:53:24.717829
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-11 18:53:31.638040
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    """
    def __init__(self, *args, **kwargs):
        self._plugin = cache_loader.get(C.CACHE_PLUGIN)
        if not self._plugin:
            raise AnsibleError('Unable to load the facts cache plugin (%s).' % (C.CACHE_PLUGIN))
        super(FactCache, self).__init__(*args, **kwargs)
    """
    assert fact_cache
    assert fact_cache._plugin


# Generated at 2022-06-11 18:53:37.154619
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc.first_order_merge('host1', {'c': 'd'})
    assert fc['host1'] == {'c': 'd'}

    fc.flush()
    fc.first_order_merge('host1', {'a': 'b'})
    assert fc['host1'] == {'a': 'b'}
    fc.first_order_merge('host1', {'c': 'd'})
    assert fc['host1'] == {'a': 'b', 'c': 'd'}


# Generated at 2022-06-11 18:53:41.358036
# Unit test for constructor of class FactCache
def test_FactCache():
    print("Testing FactCache")
    fact_cache = FactCache()
    assert fact_cache

if __name__ == "__main__":
    test_FactCache()

# Generated at 2022-06-11 18:53:42.417874
# Unit test for constructor of class FactCache
def test_FactCache():
    assert FactCache


# Generated at 2022-06-11 18:53:51.868577
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    hostvars = {'ansible_eth0': {'macaddress': '00:00:00:00'}}
    cache.first_order_merge('hostvars', hostvars)
    assert hostvars['hostvars']['ansible_eth0']['macaddress'] == '00:00:00:00'
    hostvars = {'ansible_eth0': {'inet': '00.000.000.000'}}
    cache.first_order_merge('hostvars', hostvars)
    assert hostvars['hostvars']['ansible_eth0']['inet'] == '00.000.000.000'
    hostvars = {'ansible_eth0': {'inet': '00.000.000.001'}}
    cache

# Generated at 2022-06-11 18:53:56.334169
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert isinstance(cache, MutableMapping)
    # here we are not testing the plugin
    assert cache._plugin is not None

# Generated at 2022-06-11 18:53:58.817494
# Unit test for constructor of class FactCache
def test_FactCache():
    fact = FactCache()
    if bool(fact) is False:
        display.display("FactCache constructor is working")
        return True

# Generated at 2022-06-11 18:54:09.273627
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    if not fact_cache['test_key_1']:
        fact_cache['test_key_1'] = {}
    fact_cache['test_key_1'] = {'key_1_1': 'value_1_1', 'key_1_2': 'value_1_2'}
    fact_cache.first_order_merge('test_key_1', {'key_1_2': 'value_1_2_2', 'key_1_3': 'value_1_3'})
    assert fact_cache['test_key_1'] == {'key_1_1': 'value_1_1', 'key_1_2': 'value_1_2_2', 'key_1_3': 'value_1_3'}

# Generated at 2022-06-11 18:54:13.517660
# Unit test for constructor of class FactCache
def test_FactCache():
    # Create a fact cache without an argument
    fc = FactCache()
    # Get the item of the cache
    fc_item = fc['localhost']
    print("Fact cache: Implemented as %s" % (fc_item))


if __name__ == '__main__':
    test_FactCache()

# Generated at 2022-06-11 18:54:16.141094
# Unit test for constructor of class FactCache
def test_FactCache():
    factcache = FactCache()
    factcache['192.168.1.1'] = {"hello":"world"}
    assert factcache['192.168.1.1'] == {"hello":"world"}


# Generated at 2022-06-11 18:54:18.805793
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc


# Generated at 2022-06-11 18:54:28.922131
# Unit test for constructor of class FactCache
def test_FactCache():
    '''Unit test for contructor of class FactCache'''
    def _mock_get(mocker_obj, key):
        return {'key1': 'val1', 'key2': 'val2'}

    mocker_obj = mocker.patch('ansible.plugins.loader.cache_loader.get')
    mocker_obj.side_effect = _mock_get

    mocker_obj_has_key1 = mocker.patch.object(FactCache, '__contains__')
    mocker_obj_has_key1.return_value = True

    mocker_obj_has_key2 = mocker.patch.object(FactCache, '__contains__')
    mocker_obj_has_key2.return_value = False

    fact = FactCache()
    assert fact.__contains__

# Generated at 2022-06-11 18:54:31.738698
# Unit test for constructor of class FactCache
def test_FactCache():
    #create a new instance of the class FactCache
    test_instance = FactCache()
    assert test_instance.__class__.__name__ == 'FactCache'


# Generated at 2022-06-11 18:54:33.315461
# Unit test for constructor of class FactCache
def test_FactCache():
    a1=FactCache()


if __name__ == '__main__':
    test_FactCache()

# Generated at 2022-06-11 18:54:39.176000
# Unit test for constructor of class FactCache
def test_FactCache():
    # TODO This is only a first order smoke test.  It could be improved, but
    # currently it only tests the initializer.  If the initializer works, this
    # test will pass.  That's a good thing, and it's better than nothing.
    try:
        fact_cache = FactCache()
    except Exception as e:
        assert False, 'Failed to create object of class FactCache, e={}'.format(e)
    else:
        assert True, 'Sucessfully created object of class FactCache'

# Generated at 2022-06-11 18:54:50.548180
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    value_1 = {
        "foo": {
            "bar": True
            }
        }
    value_2 = {
        "baz": {
            "buz": True
            }
        }
    test_key = "test_key"
    fact_cache.flush()
    fact_cache.first_order_merge(test_key, value_1)
    fact_cache.first_order_merge(test_key, value_2)
    assert test_key in fact_cache
    assert fact_cache[test_key]["baz"]["buz"] is True
    assert fact_cache[test_key]["foo"]["bar"] is True

# Generated at 2022-06-11 18:55:00.275992
# Unit test for constructor of class FactCache
def test_FactCache():
    plugin = cache_loader.get(C.CACHE_PLUGIN)
    facts = {'test_facts': {'key1' : 'value1'}}

    # constructor
    FC = FactCache(facts)
    if not FC:
        raise AssertionError("Failure: object constructor is not working")

    # first_order_merge
    FC.first_order_merge("test", {"key1": "value1"})
    if not ("test" in FC):
        raise AssertionError("Failure: first_order_merge is not working")

    # keys
    FC_keys = FC.keys()
    if len(FC_keys) != 2:
        raise AssertionError("Failure: keys test is not working")

    # flush
    FC.flush()

# Generated at 2022-06-11 18:55:08.955739
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    class myplugin_1(object):
        def __init__(self, *args, **kwargs):
            pass
        def contains(self, key):
            return True
        def get(self, key):
            return {'ansible_eth0': {'macaddress': '00:0c:29:2b:8a:e1', 'ipv4': {'address': '192.168.0.128', 'netmask': '255.255.255.0', 'network': '192.168.0.0'}, 'ipv6': [{'address': 'fe80::20c:29ff:fe2b:8ae1'}, {'address': 'fd00::172:16:0:1', 'prefix': '64', 'scope': 'global'}]}}

# Generated at 2022-06-11 18:55:18.779049
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache._plugin == cache_loader.get(C.CACHE_PLUGIN)

    # test __getitem__
    cache._plugin.set("foo", "bar")
    assert cache.__getitem__("foo") == "bar"

    # test __setitem__
    cache.__setitem__("foo", "baz")
    assert cache.__getitem__("foo") == "baz"

    # test __contains__
    assert "foo" in cache

    # test __delitem__
    del cache["foo"]
    assert cache.__contains__("foo") == False

    # test __len__
    cache._plugin.set("one", 1)
    cache._plugin.set("two", 2)
    assert len(cache) == 2

    # test keys

# Generated at 2022-06-11 18:55:22.105587
# Unit test for constructor of class FactCache
def test_FactCache():
    factcache = FactCache()
    assert factcache._plugin is not None
    assert isinstance(factcache._plugin, cache_loader.get(C.CACHE_PLUGIN))


# Generated at 2022-06-11 18:55:22.785266
# Unit test for constructor of class FactCache
def test_FactCache():
    assert not FactCache()

# Generated at 2022-06-11 18:55:25.026812
# Unit test for constructor of class FactCache
def test_FactCache():
    # test with plugin
    fact_cache = FactCache()
    assert isinstance(fact_cache, MutableMapping)
    assert fact_cache._plugin

# Generated at 2022-06-11 18:55:26.036016
# Unit test for constructor of class FactCache
def test_FactCache():
    factcache = FactCache()

# Generated at 2022-06-11 18:55:33.645886
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    cache = FactCache()
    assert cache.keys() == []

    _host = 'kimba'

    # first fill
    cache.first_order_merge(_host, {
        'ui_version': '1.2.0',
        'command': 'ansible-playbook',
        'python_version': 2.7
    })
    assert cache.keys() == [_host]
    assert cache[_host] == {
        'ui_version': '1.2.0',
        'command': 'ansible-playbook',
        'python_version': 2.7
    }

    # second fill

# Generated at 2022-06-11 18:55:43.717110
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    """Get facts for the host "test" and store in the inventory cache"""
    fact_cache = FactCache()
    fact_cache.first_order_merge('test', {'ansible_os_family': 'RedHat'})
    assert fact_cache['test']['ansible_os_family'] == 'RedHat'
    fact_cache.first_order_merge('test', {'ansible_os_family': 'Debian'})
    assert fact_cache['test']['ansible_os_family'] == 'Debian'
    fact_cache.first_order_merge('test', {'ansible_distribution': 'Ubuntu'})
    assert fact_cache['test']['ansible_distribution'] == 'Ubuntu'

    # Ansible 2.1:

# Generated at 2022-06-11 18:55:57.387683
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()

    # Test empty fact
    host_cache = {}
    key = 'hostname'
    value = 'host1'
    host_facts = {key: value}

    fact_cache.first_order_merge(key, value)
    assert fact_cache == host_facts, 'Assert first order merge with empty fact'

    # Test merge with new facts
    key = 'facts'
    new_value = {'fact1': 'value1', 'fact2': 'value2'}
    host_facts = {'hostname': value, 'facts': new_value}

    fact_cache.first_order_merge(key, new_value)
    assert fact_cache == host_facts, 'Assert first order merge with new fact'

    # Test merge with existing facts

# Generated at 2022-06-11 18:56:07.781011
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    host_1 = 'host_1'
    value_1 = {'ansible_os_family': 'RedHat'}
    fact_cache.first_order_merge(host_1, value_1)
    assert fact_cache[host_1] == value_1
    value_2 = {'ansible_os_family': 'Debian'}
    fact_cache.first_order_merge(host_1, value_2)
    assert fact_cache[host_1] == {'ansible_os_family': 'Debian'}
    host_2 = 'host_2'
    value_3 = {'ansible_os_family': 'RedHat'}
    fact_cache.first_order_merge(host_2, value_3)
    assert fact_

# Generated at 2022-06-11 18:56:18.732409
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    f1 = {'ssh_host_key_ecdsa_public': 'abc'}
    fact_cache.first_order_merge('server1',f1)
    assert fact_cache['server1'] == f1
    f2 = {'ssh_host_key_ecdsa_public': 'xyz'}
    fact_cache.first_order_merge('server2',f2)
    assert fact_cache['server2'] == f2
    f3 = {'ssh_host_key_ecdsa_public': 'xyz', 'ssh_host_key_rsa_public': 'xyz2'}
    fact_cache.first_order_merge('server2',f3)
    assert fact_cache['server2'] == f3

# Generated at 2022-06-11 18:56:20.513526
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache
    assert callable(fact_cache.__getitem__)

# Generated at 2022-06-11 18:56:24.015002
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.plugins.cache.memory import CacheModule as memory_cache
    from ansible.plugins.loader import cache_loader
    cache_loader.add_directory(cache_loader._get_path_to_directory('memory'))
    fc = FactCache()
    assert fc._plugin == memory_cache()

# Generated at 2022-06-11 18:56:30.462080
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    factcache = FactCache()
    key="my.key"
    value={'fact1': 1}
    factcache.first_order_merge(key, value)
    assert key in factcache.keys()
    assert factcache[key]['fact1'] == 1


    value={'fact1': 2, 'fact2': 3}
    factcache.first_order_merge(key, value)
    assert factcache[key]['fact1'] == 2
    assert factcache[key]['fact2'] == 3

    value={'fact1': 2, 'fact3': 3}
    factcache.first_order_merge(key, value)
    assert factcache[key]['fact1'] == 2
    assert factcache[key]['fact2'] == 3

# Generated at 2022-06-11 18:56:31.598638
# Unit test for constructor of class FactCache
def test_FactCache():
    myFactCache = FactCache({'localhost': {'foo': 'bar' }})

# Generated at 2022-06-11 18:56:37.942307
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    factsCache = FactCache()
    factsCache.flush()
    host = "host01"
    fact_value = {
        "ansible_local": {
            "test_cache1": "test_value1"
        }
    }
    # First call to set value
    factsCache.first_order_merge(host, fact_value)
    assert factsCache[host]["ansible_local"]["test_cache1"] == fact_value["ansible_local"]["test_cache1"]
    # Second call to set value
    fact_value = {
        "ansible_local": {
            "test_cache2": "test_value2"
        }
    }
    factsCache.first_order_merge(host, fact_value)

# Generated at 2022-06-11 18:56:40.881263
# Unit test for constructor of class FactCache
def test_FactCache():
    plugin = cache_loader.get('jsonfile')
    assert (plugin)
    plugin_class_name = 'JsonFileFactCacheModule'
    assert (plugin.__class__.__name__ == plugin_class_name)

# Generated at 2022-06-11 18:56:42.068078
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()

# Generated at 2022-06-11 18:56:56.266348
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert type(cache) is FactCache

# Generated at 2022-06-11 18:57:00.970097
# Unit test for constructor of class FactCache
def test_FactCache():
    host_facts = {'fact_dict': {'fact_key': 'fact_val'}}
    cache_plugin = {'key': 'fact_dict',
                    'value': host_facts}
    fact_cache = FactCache(cache_plugin)
    assert fact_cache['fact_dict'] == host_facts['fact_dict']


# Generated at 2022-06-11 18:57:07.798044
# Unit test for constructor of class FactCache
def test_FactCache():
    factCache = FactCache()
    testKey1 = 'key1'
    testValue1 = 'value1'
    testKey2 = 'key2'
    testValue2 = 'value2'

    # unit test for __setitem__ function of class FactCache
    factCache[testKey1] = testValue1
    factCache[testKey2] = testValue2

    # unit test for __getitem__ function of class FactCache
    if factCache[testKey1] == testValue1:
        assert True
    else:
        assert False

    if factCache[testKey2] == testValue2:
        assert True
    else:
        assert False

    # unit test for __contains__ function of class FactCache
    if testKey1 in factCache:
        assert True
    else:
        assert False

    # unit test

# Generated at 2022-06-11 18:57:09.829262
# Unit test for constructor of class FactCache
def test_FactCache():

    factcache = FactCache()
    assert isinstance(factcache, FactCache)

# Generated at 2022-06-11 18:57:10.439061
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache

# Generated at 2022-06-11 18:57:12.059359
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache(**{})
    assert fc.first_order_merge()

# Generated at 2022-06-11 18:57:15.633320
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.plugins.cache import CacheModule
    from ansible.utils.display import Display
    from ansible import constants as C

    display = Display()

    cache_loader.add(
        'memory',
        'ansible.plugins.cache.memory',
        'CacheModule'
    )
    fact_cache = FactCache()
    assert isinstance(fact_cache._plugin, CacheModule)
    fact_cache.flush()



# Generated at 2022-06-11 18:57:26.124304
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    factcache1 = FactCache()

    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    # Create the host facts to add to the cache
    host_facts_1 = DistributionFactCollector.collect(None, None)

    # Create a copy of the host facts
    host_facts_2 = dict(host_facts_1)

    # Modify the claims field of the copy
    host_facts_2['ansible_facts']['distribution']['claims'] = {
        'again': 'The claims field is changed'
    }

    factcache1.first_order_merge("my.host.example.com", host_facts_1)

    assert factcache1.__contains__("my.host.example.com")

# Generated at 2022-06-11 18:57:37.578763
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    cache.first_order_merge('testkey', {'fact1': 'value1'})
    assert 'testkey' in cache
    assert cache['testkey']['fact1'] == 'value1'

    cache.first_order_merge('testkey', {'fact2': ['value21', 'value22']})
    assert 'testkey' in cache
    assert 'fact1' in cache['testkey']
    assert 'fact2' in cache['testkey']
    assert cache['testkey']['fact2'] == ['value21', 'value22']

    cache.first_order_merge('testkey', {'fact2': 'value2'})
    assert cache['testkey']['fact2'] == 'value2'


# Generated at 2022-06-11 18:57:48.196857
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    dict_yaml = {'host1': {'foo': 'bar', 'baz': 'test'}, 'host2': {'x': 1, 'y': 2}}
    with open('data.yaml', 'w') as f:
        f.write(yaml.dump(dict_yaml))
    dict_yaml_2 = {'host1': {'foo': 'BAR', 'baz': 'TEST'}, 'host2': {'x': 1, 'y': 2}}
    with open('data2.yaml', 'w') as f:
        f.write(yaml.dump(dict_yaml_2))

    fc = FactCache(plugin_name='yaml')
    fc.first_order_merge('host1', {'foo': 'bar', 'baz': 'test'})

# Generated at 2022-06-11 18:58:20.841459
# Unit test for constructor of class FactCache
def test_FactCache():
    cache1 = FactCache()
    cache2 = FactCache()
    assert cache1 == cache2
    keys1 = cache1.keys()
    keys2 = cache2.keys()
    assert keys1 == keys2
    cache1['HOST1'] = {'a':100, 'b':200}
    cache1['HOST2'] = {'c':300, 'd':400}
    cache2['HOST1'] = {'a':100, 'c':300}
    cache2['HOST2'] = {'b':200, 'd':400}
    assert len(cache1) == len(cache2) == 4
    assert len(keys1) == len(keys2) == 4
    assert cache1 == cache2
    keys3 = cache1.keys()
    keys4 = cache2.keys()
    assert keys

# Generated at 2022-06-11 18:58:22.510339
# Unit test for constructor of class FactCache
def test_FactCache():
    assert issubclass(FactCache, MutableMapping)


# Generated at 2022-06-11 18:58:24.345862
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc
    assert fc._plugin.name == C.CACHE_PLUGIN



# Generated at 2022-06-11 18:58:29.838698
# Unit test for constructor of class FactCache
def test_FactCache():
    import tempfile
    from ansible.plugins.cache import BaseCacheModule
    tmpdir = tempfile.mkdtemp(prefix='ansible_facts_')
    C.CACHE_PLUGIN = "json"
    C.CACHE_PLUGIN_CONNECTION = '{0}/ansible-facts'.format(tmpdir)
    fact_c = FactCache()
    assert isinstance(fact_c, FactCache)
    assert isinstance(fact_c._plugin, BaseCacheModule)
    assert fact_c._plugin._cache._basedir == '{0}/ansible-facts'.format(tmpdir)
    fact_c._plugin.flush()


# Generated at 2022-06-11 18:58:30.612607
# Unit test for constructor of class FactCache
def test_FactCache():
    pass

# Generated at 2022-06-11 18:58:36.156192
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    for key, value in {'a':1, 'b':2}.items():
        cache[key] = value

    assert len(cache) == 2

    assert cache['a'] == 1
    assert cache['b'] == 2

    assert 'a' in cache
    assert 'b' in cache
    assert 'c' not in cache

    cache['a'] = 3
    assert cache['a'] == 3

    del cache['b']
    assert len(cache) == 1

    for key in cache:
        assert key == 'a'

    for key in cache.keys():
        assert key == 'a'

# Generated at 2022-06-11 18:58:41.531546
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.flush()
    value1 = dict()
    value1['fact1'] = 1
    value1['fact2'] = 2
    fact_cache.first_order_merge('localhost',value1)
    value2 = dict()
    value2['fact1'] = 3
    value2['fact3'] = 4
    fact_cache.first_order_merge('localhost',value2)
    host_cache = fact_cache._plugin.get('localhost')
    assert(host_cache['fact1'] == 3)
    assert(host_cache['fact2'] == 2)
    assert(host_cache['fact3'] == 4)

# Generated at 2022-06-11 18:58:42.568547
# Unit test for constructor of class FactCache
def test_FactCache():
    factcache = FactCache()
    assert factcache is not None

# Generated at 2022-06-11 18:58:45.122920
# Unit test for constructor of class FactCache
def test_FactCache():
    ''' Test that the constructor of FactCache class
    can be executed by 'ansible-test sanity --test fact_cache'
    '''
    FactCache()

# Generated at 2022-06-11 18:58:45.969158
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    return fact_cache

# Generated at 2022-06-11 18:59:46.878202
# Unit test for constructor of class FactCache
def test_FactCache():
    ansible_facts = {
        'localhost':
        {'ansible_facts': {
            'system_info': {'system_version': '1.0'},
            'some_plugin_fact': {'some_key': 'some_value'}
        }
        }
    }
    fact_cache = FactCache()
    fact_cache.update(ansible_facts)
    assert 'localhost' in fact_cache
    fact_cache.flush()
    assert 'localhost' not in fact_cache

# Generated at 2022-06-11 18:59:52.530164
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    key = 'foo'
    value = 5

    # Cache is empty so value should be set to cache.
    fact_cache.first_order_merge(key, value)
    assert key in fact_cache
    assert fact_cache[key] == value

    # Update cache with key=foo and a different value
    value = 10
    fact_cache.first_order_merge(key, value)
    assert key in fact_cache
    assert fact_cache[key] == value



# Generated at 2022-06-11 18:59:59.031169
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    cache.first_order_merge('localhost', {'ansible_local': {'test1': '1'}})
    cache.first_order_merge('localhost', {'ansible_local': {'test1': '2'}})
    assert cache['localhost']['ansible_local']['test1'] == '2'
    cache.first_order_merge('localhost', {'ansible_local': {'test2': '2'}})
    assert cache['localhost']['ansible_local']['test2'] == '2'

# Generated at 2022-06-11 19:00:03.707847
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        fc = FactCache()
        fc.flush()
        fc['test'] = dict(testkey = 'testvalue')
        assert fc['test']['testkey'] == 'testvalue'
    except Exception as e:
        raise Exception('Failed to construct or flush FactCache object: %s' %(str(e)))

# Generated at 2022-06-11 19:00:07.500832
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    class TestPlugin:
        def __init__(self):
            self.host_cache = None

        def contains(self, key):
            return self.host_cache is not None

        def get(self, key):
            return self.host_cache

        def set(self, key, value):
            self.host_cache = value

        def delete(self, key):
            self.host_cache = None

    plugin = TestPlugin()
    fact_cache = FactCache()
    fact_cache._plugin = plugin

    # Test one: `host_cache` does not exist
    key_value = 'host name'
    value_1 = {'ansible_kernel': 'Linux'}
    value_2 = {'ansible_distribution_version': '7.5.1804'}
    fact_cache.first_order_

# Generated at 2022-06-11 19:00:13.505117
# Unit test for constructor of class FactCache
def test_FactCache():

    test_facts = {
        'ansible_eth0': {
            'ipv4': {
                'address': '192.168.1.102',
                'netmask': '255.255.255.0',
                'network': '192.168.1.0',
                'broadcast': '192.168.1.255'
            }
        }
    }

    fact_cache = FactCache(test_facts)
    assert fact_cache._plugin is not None



# Generated at 2022-06-11 19:00:16.016838
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        C.CACHE_PLUGIN = "memory"
        fact_cache = FactCache()
    except:
        assert False
    else:
        assert True



# Generated at 2022-06-11 19:00:20.459894
# Unit test for constructor of class FactCache
def test_FactCache():
    import json
    import unittest
    class TestFactCache(unittest.TestCase):
        def test_constructor_success(self):
            cache = FactCache()
            self.assertEqual(cache._plugin.__name__, "memory")
        def test_constructor_error(self):
            with self.assertRaises(AnsibleError) as context:
                C.CACHE_PLUGIN = ""
                cache = FactCache()
                self.assertIn('Unable to load the facts cache plugin', str(context.exception))
    test = TestFactCache()
    test.test_constructor_success()
    test.test_constructor_error()


# Generated at 2022-06-11 19:00:28.941312
# Unit test for constructor of class FactCache
def test_FactCache():
    display.display('unit tests for FactCache')
    facts_cache = FactCache()
    facts_cache['test_host'] = {'host': 'test_host', 'fqdn': 'test_host.example.com', 'facter_macaddress': '00:11:22:33:44:55', 'ansible_ssh_host': 'test_host.example.com'}
    assert dict(facts_cache['test_host']) == {'host': 'test_host', 'fqdn': 'test_host.example.com', 'facter_macaddress': '00:11:22:33:44:55', 'ansible_ssh_host': 'test_host.example.com'}

# Generated at 2022-06-11 19:00:37.727065
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    def mock_get(self, key):
        return {'value':'original'}

    def mock_set(self, key, value):
        return True

    def mock_keys(self):
        return [1,2,4]

    def mock_flush(self):
        return True

    cache_loader.get = lambda a: Mock()
    cache_loader.get.contains = lambda b: True
    cache_loader.get.get = lambda c: Mock()
    cache_loader.get.get.get = mock_get
    cache_loader.get.set = mock_set
    cache_loader.get.keys = mock_keys
    cache_loader.get.flush = mock_flush

    fact_cache = FactCache()
    fact_cache.first_order_merge('key', {'value':'updated'})