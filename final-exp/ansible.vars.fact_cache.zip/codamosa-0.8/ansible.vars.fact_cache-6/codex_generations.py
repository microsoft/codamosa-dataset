

# Generated at 2022-06-11 18:52:32.524626
# Unit test for constructor of class FactCache
def test_FactCache():
    f = FactCache()
    assert type(f) == FactCache
    assert f is not None

# Generated at 2022-06-11 18:52:40.509404
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()

    # Value is a string
    fact_cache.first_order_merge('key', 'string')
    assert fact_cache.copy() == {'key': 'string'}

    # Cache is empty
    fact_cache.flush()
    assert fact_cache.copy() == {}

    # Value is a dictionary
    fact_cache.first_order_merge('key', {'subkey': ['subsubkey1', 'subsubkey2']})
    assert fact_cache.copy() == {'key': {'subkey': ['subsubkey1', 'subsubkey2']}}

    # Cache is not empty anymore
    fact_cache.first_order_merge('key', {'subkey2': 'subsubkey3'})

# Generated at 2022-06-11 18:52:42.731257
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    print(fact_cache)

if __name__ == '__main__':
    test_FactCache()

# Generated at 2022-06-11 18:52:43.964184
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache_obj = FactCache()
    assert fact_cache_obj is not None

# Generated at 2022-06-11 18:52:54.045357
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    # Test case 1
    fact_cache = FactCache()
    fact_cache.first_order_merge('test01', {'ansible_facts': {'test01': {'a': 1}}})
    assert fact_cache.get('test01') == fact_cache.get('test01')
    assert fact_cache.get('test01').get('ansible_facts').get('test01').get('a') == 1

    # Test case 2
    fact_cache = FactCache()
    fact_cache.first_order_merge('test02', {'ansible_facts': {'test02': {'a': 2}}})
    fact_cache.first_order_merge('test02', {'ansible_facts': {'test02': {'b': 3}}})

# Generated at 2022-06-11 18:53:03.369552
# Unit test for method first_order_merge of class FactCache

# Generated at 2022-06-11 18:53:10.980977
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    data = FactCache()
    data.first_order_merge('host1', {'ansible_fact1': 1, 'ansible_fact2': 2})
    assert data.get('host1') == {'ansible_fact1': 1, 'ansible_fact2': 2}
    data.first_order_merge('host1', {'ansible_fact2': 3, 'ansible_fact3': 4})
    assert data.get('host1') == {'ansible_fact1': 1, 'ansible_fact2': 3, 'ansible_fact3': 4}

# Generated at 2022-06-11 18:53:18.134691
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # check with empty cache
    f = FactCache()
    old_facts = f.copy()
    new_facts = {
        "ansible_all_ipv4_addresses": [
            "10.20.30.40",
            "192.168.100.100"
        ]
    }
    f.first_order_merge('localhost.localdomain', new_facts)
    new_facts["localhost.localdomain"] = new_facts
    assert f.copy() == new_facts

    # check with non-empty cache
    f = FactCache()
    f['localhost.localdomain'] = old_facts

# Generated at 2022-06-11 18:53:19.888547
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, MutableMapping)

# Generated at 2022-06-11 18:53:27.114136
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge("test_host", {"key": "value"})
    assert fact_cache["test_host"]["key"] == "value"
    fact_cache.first_order_merge("test_host", {"key": "value_updated"})
    assert fact_cache["test_host"]["key"] == "value_updated"
    fact_cache.first_order_merge("test_host2", {"key": "value"})
    assert fact_cache["test_host2"]["key"] == "value"

# Generated at 2022-06-11 18:53:38.547090
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()

    # Test when no host_facts has previous value in cache.
    host_facts = {'key1': 'value1'}
    host_facts_cached = {'key1': 'value1'}
    fact_cache.first_order_merge(key='host_facts', value=host_facts)
    assert fact_cache.get('host_facts') == host_facts_cached

    # Test when host_facts has a previous value in cache
    # and the new value has the old values plus new values.
    host_facts = {'key1': 'value1', 'key2': 'value2'}
    host_facts_cached = {'key1': 'value1', 'key2': 'value2'}

# Generated at 2022-06-11 18:53:42.694934
# Unit test for constructor of class FactCache
def test_FactCache():
    fc=FactCache()
    fc.__setitem__('system_facts', {})
    assert fc.__getitem__('system_facts') == {}

# Generated at 2022-06-11 18:53:48.634469
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    key = 'test'
    fact_cache[key] = {'foo': 1}
    value = {'bar': 2}
    fact_cache.first_order_merge(key, value)
    assert fact_cache[key] == {'foo': 1, 'bar': 2}
    value = {'bar': 3, 'foo': 4}
    fact_cache.first_order_merge(key, value)
    assert fact_cache[key] == {'foo': 4, 'bar': 3}

# Generated at 2022-06-11 18:53:49.796316
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache

# Generated at 2022-06-11 18:53:54.014619
# Unit test for constructor of class FactCache
def test_FactCache():
    cache_plugin = cache_loader.get(C.CACHE_PLUGIN)
    fact_cache = FactCache(sources=cache_plugin)

    fact_cache.flush()

    return

if __name__ == '__main__':
    test_FactCache()

# Generated at 2022-06-11 18:53:55.541566
# Unit test for constructor of class FactCache
def test_FactCache():
    FC = FactCache()
    assert FC is not None

# Generated at 2022-06-11 18:53:58.897981
# Unit test for constructor of class FactCache
def test_FactCache():
    plugin = cache_loader.get('jsonfile')
    assert plugin is not None

    cache_plugin = FactCache()
    assert cache_plugin is not None, "Expect to create cache instance"

# Generated at 2022-06-11 18:54:00.938653
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    # TODO: write some test cases, test_FactCache should be documented
    assert cache._plugin.flush() == None

# Generated at 2022-06-11 18:54:11.081372
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    my_cache = FactCache()
    my_cache.first_order_merge('hostA', {'a': 'A', 'b': 'B'})
    assert my_cache['hostA'] == {'a': 'A', 'b': 'B'}
    my_cache.first_order_merge('hostA', {'b': 'Z', 'c': 'C'})
    assert my_cache['hostA'] == {'a': 'A', 'b': 'Z', 'c': 'C'}

    my_facts = {'hostB': {'a': 'A', 'b': 'B'}, 'hostC': {'a': 'A', 'b': 'B'}}
    my_cache.first_order_merge('hostB', {'b': 'Z', 'c': 'C'})
   

# Generated at 2022-06-11 18:54:11.616637
# Unit test for constructor of class FactCache
def test_FactCache():
    pass

# Generated at 2022-06-11 18:54:16.103438
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()

    assert fact_cache
    assert fact_cache._plugin

# Generated at 2022-06-11 18:54:18.326042
# Unit test for constructor of class FactCache
def test_FactCache():
    f = FactCache()
    assert f is not None

# Generated at 2022-06-11 18:54:19.306174
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-11 18:54:21.139910
# Unit test for constructor of class FactCache
def test_FactCache():
    """ Constructor test for FactCache class """
    cache = FactCache()
    assert cache is not None, \
        'Failed to create FactCache object'


# Generated at 2022-06-11 18:54:32.336532
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    # set up
    class MockCache:
        def __init__(self, *args, **kwargs):
            self.host_cache = {'ansible_lsb':{'distcodename':'buster'}}
        def contains(self, hostname):
            return True
        def get(self, key):
            return self.host_cache.get(key)
        def set(self, key, value):
            self.host_cache[key] = value
        def delete(self, key):
            del self.host_cache[key]
        def flush(self):
            self.host_cache = {}
        def keys(self):
            return self.host_cache.keys()

    class MockLoader:
        def get(self, plugin):
            return MockCache()

    # test
    cache_loader.loader = Mock

# Generated at 2022-06-11 18:54:35.441132
# Unit test for constructor of class FactCache
def test_FactCache():
    from collections import Mapping
    from ansible.plugins.loader import cache_loader

    assert isinstance(cache_loader.get(C.CACHE_PLUGIN), Mapping)


# Generated at 2022-06-11 18:54:38.947263
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.plugins.loader import cache_loader
    from ansible.utils.display import Display

    # Create object of class Display
    display = Display()

    # Create object of class FactCache
    fact_cache = FactCache()

    # Create object of class cache_loader
    cache_loader.get(C.CACHE_PLUGIN)

# Generated at 2022-06-11 18:54:48.810394
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge("host1", {"ansible_os_family": "RedHat", "ansible_distribution": "CentOS"})
    fact_cache.first_order_merge("host2", {"ansible_os_family": "RedHat", "ansible_distribution": "Fedora"})
    fact_cache.first_order_merge("host3", {"ansible_os_family": "Debian", "ansible_distribution": "Debian"})
    fact_cache.first_order_merge("host4", {"ansible_os_family": "Debian", "ansible_distribution": "Ubuntu"})
    assert len(fact_cache.copy()) == 4
    # host1 has information about ansible_distribution and ansible_os

# Generated at 2022-06-11 18:54:51.294926
# Unit test for constructor of class FactCache
def test_FactCache():
    # Constructor of class FactCache is success
    try:
        fact = FactCache([])
        assert isinstance(fact, FactCache)
    # Constructor of class FactCache raised the exception
    except:
        assert True


# Generated at 2022-06-11 18:54:52.884664
# Unit test for constructor of class FactCache
def test_FactCache():
    x = FactCache()
    assert isinstance(x, FactCache)

# Generated at 2022-06-11 18:55:08.242459
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Initialize
    initial_facts_cache = {
        'host1': {
            'key1': 'val1',
            'key2': 'val2',
        },
    }
    new_facts_cache = {
        'host1': {
            'key1': 'val1',
            'key2': 'val3',
            'key3': 'val4',
        },
    }
    expected_facts_cache = {
        'host1': {
            'key1': 'val1',
            'key2': 'val3',
            'key3': 'val4',
        },
    }

    # Create a class instance
    fcache = FactCache(initial_facts_cache)

    # Test

# Generated at 2022-06-11 18:55:18.230064
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    host_cache_db = {
        'localhost': {
            'ansible_os_family': 'RedHat',
            'ansible_distribution': 'CentOS',
            'ansible_distribution_version': '7.5.1804',
            'ansible_distribution_release': 'Core',
            'ansible_distribution_major_version': '7',
            'ansible_architecture': 'x86_64',
            'ansible_machine_id': '',
            'ansible_selinux': 'disabled'
        }
    }
    fact_cache = FactCache(host_cache_db)
    fact_cache.first_order_merge('localhost', {'ansible_os_family': 'RedHat'})

# Generated at 2022-06-11 18:55:29.252867
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Test case 1:
    # Purpose: Overwrite an existing key with a new value
    cache = FactCache()
    host_cache = {'a.b.c': 'value1'}
    cache.update(host_cache)

    new_key = {'a.b.c': 'value2'}
    cache.first_order_merge('host1', new_key)
    assert cache['host1'] == new_key

    # Test case 2:
    # Purpose: Overwrite an existing key with a new value
    cache = FactCache()
    host_cache = {'a.b.c': 'value1'}
    cache.update(host_cache)

    new_key = {'a.b.c': 'value2', 'd.e.f': 'value3'}
    cache.first_order

# Generated at 2022-06-11 18:55:30.770882
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    # Check if the FactCache is an instance of MutableMapping
    assert isinstance(fact_cache, MutableMapping)


# Generated at 2022-06-11 18:55:37.777338
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.errors import AnsibleError

    fact_cache = FactCache.__new__(FactCache)
    # Check if exception is raised when cache_plugin is None
    try:
        fact_cache._plugin = None
        fact_cache.__init__()
    except AnsibleError:
        pass

    # Check if exception is raised when cache_plugin is empty string
    try:
        fact_cache._plugin = ""
        fact_cache.__init__()
    except AnsibleError:
        pass

# Generated at 2022-06-11 18:55:42.549034
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    key = "192.168.1.1"
    cache = FactCache()
    cache.first_order_merge(key, dict(value=1))
    assert cache[key]['value'] == 1
    cache.first_order_merge(key, dict(value=2))
    assert cache[key]['value'] == 2

# Generated at 2022-06-11 18:55:44.499756
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache(C.CACHE_PLUGIN)
    assert cache._plugin.__name__ == C.CACHE_PLUGIN


# Generated at 2022-06-11 18:55:45.499512
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    print(cache)

# Generated at 2022-06-11 18:55:54.782523
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()

    host = 'host'
    fact_1 = 'fact_1'
    fact_2 = 'fact_2'
    host_facts = {
        host: None,
    }
    new_host_facts = {
        host: {
            fact_1: None,
        },
    }
    updated_host_facts = {
        host: {
            fact_1: None,
            fact_2: None,
        },
    }

    # Host not cached
    fact_cache.first_order_merge(host, {fact_1: None})
    assert fact_cache.copy() == new_host_facts

    # Host cached
    fact_cache.first_order_merge(host, {fact_2: None})
    assert fact_cache.copy() == updated_

# Generated at 2022-06-11 18:56:05.217611
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import os
    import sys
    import tempfile
    import shutil
    import json

    my_temp_dir = tempfile.mkdtemp()
    #print("temp_dir = %s" %my_temp_dir)

    # create the cache
    from ansible.config.manager import ConfigManager
    config_manager = ConfigManager()
    config_manager._setup_config_files()
    config_manager._find_vault_password()

    from ansible.config.manager import set_module_defaults
    set_module_defaults()

    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(inventory=None, variable_manager=None, loader=None, options=config_manager.options, passwords=None)

    my_fact_cache = tqm.fact

# Generated at 2022-06-11 18:56:24.635823
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    from ansible.module_utils import common as module_common
    from ansible.module_utils.facts import ansible_virtual_facts
    from ansible.module_utils.facts import Facts as module_facts
    from ansible.module_utils.facts import collector as module_collector

    facts = module_facts(module_common)
    facts.populate()
    all_facts = facts.all_facts
    all_facts['ansible_virtual_facts'].update(ansible_virtual_facts(all_facts))

    facts = module_collector.collect(module_common, all_facts)

    # Generate the facts cache key and value
    key = module_common.get_cache_remote_key(module_common)
    value = facts

    # Create the fact cache object
    fact_cache = FactCache()

    #

# Generated at 2022-06-11 18:56:25.752415
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache._plugin._plugin is not None

# Generated at 2022-06-11 18:56:27.073598
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc is not None

# Generated at 2022-06-11 18:56:35.667791
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    key = "host1"
    value = {"value1": 'a', "value2": 'b'}

    class fake_plugin (object):
        def __init__(self):
            self.value_dict = dict()

        def contains(self, key):
            return key in self.value_dict

        def get(self, key):
            return self.value_dict[key]

        def set(self, key, value):
            self.value_dict[key] = value

        def delete(self, key):
            self.value_dict.pop(key)

        def keys(self):
            return self.value_dict.keys()

        def flush(self):
            self.value_dict = dict()

    # Test if the method merges the new value if the key not exists
    fake_fact_cache = FactCache

# Generated at 2022-06-11 18:56:36.626070
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache

# Generated at 2022-06-11 18:56:37.132472
# Unit test for constructor of class FactCache
def test_FactCache():
    c = FactCache()

# Generated at 2022-06-11 18:56:39.715423
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None, 'Failed to create FactCache'


# Generated at 2022-06-11 18:56:47.609241
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    test_fact_cache = FactCache()
    
    host_item = {
        "ansible_hostname": "test_host",
        "ansible_facts": {
            "network": {
                "interfaces": {
                    "enp0s8": {
                        "ipv4": {
                            "address": "192.168.88.222",
                            "netmask": "255.255.255.0",
                            "network": "192.168.88.0"
                        }
                    }
                }
            }
        }
    }

    test_fact_cache.first_order_merge('test_host', host_item)
    

# Generated at 2022-06-11 18:56:51.075783
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.plugins.cache import memory
    memory.CACHE = {}
    try:
        cache = FactCache()
        assert(cache._plugin == memory)
    finally:
        # Clear cache for other tests
        memory.CACHE = {}


# Generated at 2022-06-11 18:56:52.983619
# Unit test for constructor of class FactCache
def test_FactCache():
    test_FactCache = FactCache()
    assert test_FactCache is not None, 'Unable to create object of FactCache class'

# Generated at 2022-06-11 18:57:28.602581
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    facts = dict()
    # Test with empty cache
    cache = FactCache()
    cache.first_order_merge('example', {'a': 1, 'b': 2})
    facts = cache.copy()
    assert facts == {'example': {'a': 1, 'b': 2}}

    # Test with filled cache
    cache.flush()
    cache.update({'example': {'b': 5, 'c': 6}})
    cache.first_order_merge('example', {'a': 1, 'b': 2})
    facts = cache.copy()
    assert facts == {'example': {'b': 5, 'c': 6, 'a': 1}}

# Generated at 2022-06-11 18:57:39.178452
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import os
    import mock
    import pytest
    from ansible.cache.base import BaseCacheModule
    from ansible.plugins.cache import jsonfile
    from ansible.plugins.cache.yaml import CacheModule as yamlCacheModule

    class TestCache(BaseCacheModule):
        def get(self, key):
            return self.data[key]

        def set(self, key, value):
            self.data[key] = value

        def contains(self, key):
            return key in self.data

        def delete(self, key):
            self.data.pop(key, None)

        def keys(self):
            return self.data.keys()

        def flush(self):
            self.data = {}

    facts = {'test1': 'test1', 'test2': 'test2'}

    host

# Generated at 2022-06-11 18:57:49.530853
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.update({'host1': {'first_fact': 'value1'}})
    fact_cache.update({'host2': {'first_fact': 'value2'}})
    # update FactCache without merge
    fact_cache.update({'host1': {'second_fact': 'value3'}})
    # update FactCache with merge
    fact_cache.first_order_merge('host1', {'second_fact': 'value4'})
    assert fact_cache['host1']['first_fact'] == 'value1'
    assert fact_cache['host2']['first_fact'] == 'value2'
    assert fact_cache['host1']['second_fact'] == 'value3'


# Generated at 2022-06-11 18:57:59.582420
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Create a new instance of this class
    fact_cache = FactCache()

    # Set a value for the key 'test' and assert that the key is present in the fact_cache
    fact_cache['test'] = 'my_test_value'
    assert 'test' in fact_cache.keys()

    # Test the 'first_order_merge' method with a new value for key 'test'
    fact_cache.first_order_merge('test', 'my_new_test_value')
    assert fact_cache['test'] == 'my_new_test_value'

    # Test the 'first_order_merge' method with a dictionary for key 'test'
    fact_cache.first_order_merge('test', {'new_key': 'some value'})

# Generated at 2022-06-11 18:58:02.131234
# Unit test for constructor of class FactCache
def test_FactCache():
    data = {'a': 'b'}
    cache = FactCache(data)

    assert data == cache

# Generated at 2022-06-11 18:58:02.953599
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache

# Generated at 2022-06-11 18:58:13.769619
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    fact_cache = FactCache()
    host = 'host'
    facts = {'a': 1, 'b': 2}

    fact_cache.first_order_merge(host, facts)

    # 1st time, no prior host_cache - new fact cache entry created
    assert fact_cache[host] == {'a': 1, 'b': 2}
    assert isinstance(fact_cache[host], dict)
    assert len(fact_cache[host]) == 2
    assert fact_cache[host]['a'] == 1
    assert fact_cache[host]['b'] == 2

    # 2nd time, host_cache exists - host_cache updated, fact update requires new host_cache
    value = {'a': 0, 'b': 2, 'c': 3}

# Generated at 2022-06-11 18:58:20.534960
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    host_facts = {'fact_1': 'value_1', 'fact_2': 'value_2', 'fact_3': 'value_3'}
    fact_cache.first_order_merge('host_1', host_facts)

    host_facts = {'fact_2': 'new_value_2', 'fact_3': 'value_3', 'fact_4': 'value_4'}
    fact_cache.first_order_merge('host_1', host_facts)

    assert fact_cache['host_1']['fact_1'] == 'value_1'
    assert fact_cache['host_1']['fact_2'] == 'new_value_2'
    assert fact_cache['host_1']['fact_3'] == 'value_3'

# Generated at 2022-06-11 18:58:22.202538
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache._plugin
    cache.flush()

# Generated at 2022-06-11 18:58:23.192380
# Unit test for constructor of class FactCache
def test_FactCache():
    assert FactCache()


# Generated at 2022-06-11 18:58:51.778458
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    print(fact_cache)

# Generated at 2022-06-11 18:58:56.405487
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    data = {'key': 'value'}
    fact_cache.first_order_merge('host1', data)
    fact_cache.first_order_merge('host2', data)
    assert(len(fact_cache) == 2 and 'key' in fact_cache['host1'] and 'key' in fact_cache['host2'])

# Generated at 2022-06-11 18:58:57.817409
# Unit test for constructor of class FactCache
def test_FactCache():
    plugin = cache_loader.get(C.CACHE_PLUGIN)
    assert plugin
    fc = FactCache()
    assert fc

# Generated at 2022-06-11 18:58:58.564181
# Unit test for constructor of class FactCache
def test_FactCache():
    test_FactCache = FactCache()


# Generated at 2022-06-11 18:59:02.716535
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    fact_cache = FactCache()

    key = "test_key"
    value = {"test_key_value": "test_value"}

    fact_cache.first_order_merge(key, value)

    assert fact_cache == {"test_key": {"test_key_value": "test_value"}}

# Generated at 2022-06-11 18:59:04.718558
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache(data=dict(host1=dict(key1="value1")))
    assert fact_cache is not None

# Generated at 2022-06-11 18:59:05.956422
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc is not None

# Generated at 2022-06-11 18:59:12.766520
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()

    # First, let us test the method on an empty cache
    key = 'key1'
    value = {'a': 1, 'b': 2}
    cache.first_order_merge(key, value)
    assert cache[key] == value

    # Now test with a cache which has one key and value
    key1 = 'key1'
    value1 = {'a': 1, 'b': 2}
    key2 = 'key2'
    value2 = {'c': 3, 'd': 4}
    cache.first_order_merge(key1, value1)
    cache.first_order_merge(key2, value2)
    assert cache[key1] == value1
    assert cache[key2] == value2

    # Now test with a cache which has the same

# Generated at 2022-06-11 18:59:20.626290
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    mem = {'MemTotal': '3000', 'MemFree': '1000'}
    swap = {'SwapTotal': '4096', 'SwapFree': '1000'}
    fact_cache.first_order_merge('mem', mem)
    fact_cache.first_order_merge('mem', swap)
    assert fact_cache['mem'] == {'MemTotal': '3000', 'MemFree': '1000', 'SwapTotal': '4096', 'SwapFree': '1000'}

# Generated at 2022-06-11 18:59:27.586240
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Initialize fact_cache object
    fact_cache = FactCache()

    # Add 1st host fact of 'host_1' to fact_cache
    host_1_fact = {'host_1': {'fact_01': 'value_01', 'fact_02': 'value_02'}}
    fact_cache.first_order_merge('host_1', host_1_fact['host_1'])

    # Add 2nd host fact of 'host_1' to fact_cache
    host_1_fact['host_1']['fact_03'] = 'value_03'
    fact_cache.first_order_merge('host_1', host_1_fact['host_1'])

    # Add 1st host fact of 'host_2' to fact_cache

# Generated at 2022-06-11 19:00:23.737556
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, MutableMapping) == True


# Generated at 2022-06-11 19:00:27.118951
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()

    # Check that the fact cache is created with the correct plugin
    assert fact_cache._plugin == cache_loader.get(C.CACHE_PLUGIN)

# Generated at 2022-06-11 19:00:35.975659
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    host_list = ['a', 'b']
    for host in host_list:
        fact_cache[host] = {'foo': 'bar'}
        assert fact_cache[host] == {'foo': 'bar'}
    assert len(fact_cache) == len(host_list)
    assert iter(fact_cache) == iter(host_list)
    assert list(fact_cache.keys()) == host_list
    assert fact_cache.copy() == {'a': {'foo': 'bar'}, 'b': {'foo': 'bar'}}
    fact_cache['a'] = {'foo': 'baz'}
    assert fact_cache.copy() == {'a': {'foo': 'baz'}, 'b': {'foo': 'bar'}}

# Generated at 2022-06-11 19:00:37.028159
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin



# Generated at 2022-06-11 19:00:40.957491
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    key = 'localhost'
    cache_value = {'ansible_env': 'local_environment'}
    cache[key] = cache_value

    original_value = {'ansible_env': 'test_environment'}
    cache.first_order_merge(key, original_value)

    assert cache_value == {'ansible_env': 'test_environment'}

# Generated at 2022-06-11 19:00:45.532986
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert not fc.keys()
    fc['key'] = 'value'
    assert fc.keys() == ['key']
    assert fc['key'] == 'value'
    fc['key'] = 'new_value'
    assert fc['key'] == 'new_value'
    del fc['key']
    assert not fc.keys()

# Generated at 2022-06-11 19:00:46.227009
# Unit test for constructor of class FactCache
def test_FactCache():
    assert FactCache()


# Generated at 2022-06-11 19:00:52.300970
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    """Test that first_order_merge method works properly"""

    key = 'localhost'
    value = {}
    value2 = {}
    value3 = {}
    test_cache = FactCache()

    # If fact_cache for key is empty, fact cache is updated with
    # {key: value} and first_order_merge returns None
    assert test_cache.first_order_merge(key, value) is None

    # If fact_cache for key is not empty, value and cached  dict are
    # merged and first_order_merge returns merged dict
    value.update({'fact1':'value1'})
    test_cache.__setitem__(key, {'fact2':'value2'})

# Generated at 2022-06-11 19:01:02.137814
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    new_value = {'test': 'test_value'}
    fc.first_order_merge('test', new_value)
    assert 'test' in fc

    new_value = {'test': 'test_value2'}
    fc.first_order_merge('test', new_value)
    assert 'test' in fc
    assert fc['test']['test'] == 'test_value2'

    new_value = {'test': 'test_value3'}
    fc.first_order_merge('test1', new_value)
    assert 'test1' in fc
    assert fc['test1']['test'] == 'test_value3'

    fc.flush()
    assert len(fc.keys()) == 0

# Generated at 2022-06-11 19:01:12.974092
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    host_facts = {'foo': 'bar'}
    host_cache = {'foo': 'foo'}

    # update cache with host_cache
    cache[host_cache] = host_cache

    # test host_facts are updated with host_cache
    cache.first_order_merge(host_facts, host_facts)
    assert host_facts == {'foo': 'bar'}

    # test host_facts are updated with host_cache
    cache.first_order_merge(host_cache, host_facts)
    assert host_facts == {'foo': 'bar', 'foo': 'bar'}

    # test host_cache is merge succesfully into host_facts
    host_facts.update({'foo': 'bar'})