

# Generated at 2022-06-11 18:52:36.067500
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    """ Unit test for method first_order_merge of class FactCache """
    fc = FactCache()
    fc.first_order_merge(key = "a", value = { "b": 1, "c": 2 })
    assert fc["a"] == { "b": 1, "c": 2 }
    fc.first_order_merge(key = "a", value = { "c": 3, "d": 4 })
    assert fc["a"] == { "b": 1, "c": 3, "d": 4 }

# Generated at 2022-06-11 18:52:47.716444
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    test_cache = FactCache(dict())
    test_cache['test_key'] = dict()

    test_cache.first_order_merge('test_key', dict())
    assert(test_cache['test_key'] == dict())
    test_cache.first_order_merge('test_key', {'test_dict': 'test'})
    assert(test_cache['test_key'] == {'test_dict': 'test'})
    # test that updating the facts does not change the cached facts
    test_cache['test_key'].update({'new_key': 'test'})
    assert(test_cache['test_key'] == {'test_dict': 'test', 'new_key': 'test'})

# Generated at 2022-06-11 18:52:53.235170
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.plugins.cache.jsonfile import CacheModule
    import json
    import sys
    import os
    import tempfile
    import shutil

    cache_dir = tempfile.mkdtemp(prefix='ansible_test_cache_json_')
    open(cache_dir + "/test_host", 'w').close()
    cache = CacheModule(cache_dir)
    fc = FactCache()

# Generated at 2022-06-11 18:52:55.998519
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fc.__class__.__name__ == 'FactCache'


# Generated at 2022-06-11 18:53:01.354105
# Unit test for constructor of class FactCache
def test_FactCache():
  # test valid constructor
  try:
    fc = FactCache()
  except Exception as ex:
    raise AssertionError('Unexpected Exception on valid constructor:' + str(ex))

  # test invalid constructor
  try:
    with display.override_display(False):
      fc = FactCache('bla', 'bla')
    raise AssertionError('Missing Exception on invalid constructor')
  except TypeError:
    pass

# Generated at 2022-06-11 18:53:09.940008
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    test_key = '127.0.0.1'
    new_value = {"simulator": "simulator_value"}
    fact_cache.first_order_merge(test_key, new_value)
    assert new_value == fact_cache[test_key]
    old_value = {"simulator": "old_simulator_value"}
    new_value = {"simulator": "simulator_value"}
    fact_cache.first_order_merge(test_key, old_value)
    assert new_value == fact_cache[test_key]

# Generated at 2022-06-11 18:53:16.663358
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    host_cache = {'ipaddress': '10.0.0.1', 'otherfact': 'value2'}
    host_facts = {'ipaddress': '10.0.0.2', 'thirdfact': 'value3'}
    fact_cache['hostname'] = host_cache
    fact_cache.first_order_merge('hostname', host_facts)
    expected_fact_cache = {
        'hostname': {
            'ipaddress': '10.0.0.2',
            'otherfact': 'value2',
            'thirdfact': 'value3'
        }
    }
    assert(fact_cache == expected_fact_cache)

# Generated at 2022-06-11 18:53:27.114520
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import tempfile
    import os
    import shutil

    # Create test factcache dir
    temp_dir = tempfile.mkdtemp()
    test_dir = os.path.join(temp_dir, "test_FactCache_first_order_merge")
    if not os.path.exists(test_dir):
        os.makedirs(test_dir)

    # Initialize factcache with test dir
    factcache_init = FactCache()
    factcache_init._plugin.directory = test_dir

    # Create a test fact cache

# Generated at 2022-06-11 18:53:27.889703
# Unit test for constructor of class FactCache
def test_FactCache():
    factcache = FactCache()
    assert factcache

# Generated at 2022-06-11 18:53:34.709136
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    key = 'foo'
    value = 'bar'
    host_cache = {}
    host_facts = {key: value}
    cache_plugin = MockCachePlugin()
    cache_plugin.set(key, host_cache)
    cache = FactCache()
    cache._plugin = cache_plugin
    cache.first_order_merge(key, value)
    assert cache[key] == host_facts
    assert host_cache == host_facts

# Mock implementation of the cache plugin object

# Generated at 2022-06-11 18:53:37.561733
# Unit test for constructor of class FactCache
def test_FactCache():
    obj = FactCache()
    assert obj is not None

# Generated at 2022-06-11 18:53:40.481805
# Unit test for constructor of class FactCache
def test_FactCache():
    assert FactCache
    try:
        assert FactCache()
    except:
        assert False

# Generated at 2022-06-11 18:53:44.685337
# Unit test for constructor of class FactCache
def test_FactCache():
    # Constructor
    fc = FactCache()
    # Get keys
    k = fc.keys()
    # Get items
    i = fc.copy()
    # Get flush
    fc.flush()
    # Get first_order_merge
    fc.first_order_merge('key1', 'val1')

# Generated at 2022-06-11 18:53:47.238905
# Unit test for constructor of class FactCache
def test_FactCache():
    plugin = 'memory'
    C.CACHE_PLUGIN = plugin
    fc = FactCache()
    assert fc._plugin.__class__.__name__ == plugin.capitalize() + 'FactCache'


# Generated at 2022-06-11 18:53:58.054443
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # initialize a fact cache object
    fact_cache = FactCache()
    fact_cache.flush()

    # Add a data to fact cache
    fact_cache.first_order_merge('1.1.1.1',{'file': '/etc/hosts', 'file_content': ['1.1.1.1', 'host_name']})
    assert fact_cache.keys() == ['1.1.1.1']
    assert fact_cache['1.1.1.1'].keys() == ['file', 'file_content']
    assert fact_cache['1.1.1.1']['file'] == '/etc/hosts'
    assert fact_cache['1.1.1.1']['file_content'] == ['1.1.1.1', 'host_name']

    # Add new facts to

# Generated at 2022-06-11 18:54:00.499414
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    try:
        cache2 = FactCache(cache)
    except:
        raise Exception('cannot pass cache object to FactCache constructor')

# Generated at 2022-06-11 18:54:09.190011
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    key = "testhost"
    value = {"testitem": "testvalue"}

    fact_cache.first_order_merge(key, value)
    # This should not throw KeyError
    fact_cache[key]

    fact_cache.flush()
    fact_cache.first_order_merge(key, {"newitem": "newvalue"})

    fact_cache.flush()
    fact_cache.first_order_merge(key, {})
    fact_cache[key]["newitem"]

# Backwards compatibility for playbook code written before Ansible 2.5
FactCache = FactCache()

# Generated at 2022-06-11 18:54:13.360712
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin == cache_loader.get(C.CACHE_PLUGIN)
    assert fact_cache._plugin.contains('localhost') == False
    assert len(fact_cache) == 0
    assert 'localhost' not in fact_cache


# Generated at 2022-06-11 18:54:20.617184
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import pytest
    factcache = FactCache()
    factcache._plugin = MemoryFactCache()
    factcache.flush()
    factcache._plugin.flush()
    factcache._plugin['localhost'] = dict(a=1, b=2, baz='silly')
    factcache.first_order_merge('localhost', dict(a=1, b=3, foo='bar'))

    assert factcache['localhost'] == {'a': 1, 'b': 3, 'baz': 'silly', 'foo': 'bar'}


# Generated at 2022-06-11 18:54:31.900885
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Test for method first_order_merge of class FactCache
    import copy
    from ansible.plugins.cache import memory as memory_cache
    fact_cache = FactCache(plugin=memory_cache)

    # Empty cache, non-existent host
    key = 'i_do_not_exist'
    value = dict(fact1='fact1')
    before_merge = copy.deepcopy(value)
    fact_cache.first_order_merge(key, value)
    assert fact_cache[key]['fact1'] == 'fact1'
    assert fact_cache[key] is before_merge

    # Initialize cache
    key = 'i_exist'
    value = dict(fact1='fact1')
    before_merge = copy.deepcopy(value)
    fact_cache.first_order_mer

# Generated at 2022-06-11 18:54:37.109185
# Unit test for constructor of class FactCache
def test_FactCache():
    cache_plugin = MockCachePlugin()
    assert cache_plugin is not None
    cache = FactCache(cache_plugin)
    assert cache is not None
    assert cache._plugin == cache_plugin


# Generated at 2022-06-11 18:54:38.096846
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert (not cache)

# Generated at 2022-06-11 18:54:39.208538
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache._plugin is not None


# Generated at 2022-06-11 18:54:39.808356
# Unit test for constructor of class FactCache
def test_FactCache():
    factcache = FactCache()

# Generated at 2022-06-11 18:54:40.270112
# Unit test for constructor of class FactCache
def test_FactCache():
    assert FactCache()

# Generated at 2022-06-11 18:54:41.760859
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()


# Generated at 2022-06-11 18:54:44.498074
# Unit test for constructor of class FactCache
def test_FactCache():
    #Unit test for constructor of class FactCache
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)


# Generated at 2022-06-11 18:54:51.947982
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    """
    Test that first_order_merge updates the fact cache with the given value for the given key,
    only if the cache does not already contain the given key.
    """

    host = 'foo'
    test_facts = {'bar': 'baz'}

    fact_cache = FactCache()
    fact_cache.first_order_merge(host, test_facts)

    assert fact_cache[host] == test_facts
    assert fact_cache.keys() == [host]

    test_facts['qux'] = 'quux'
    fact_cache.first_order_merge(host, test_facts)

    assert fact_cache[host] == test_facts
    assert fact_cache.keys() == [host]

# Generated at 2022-06-11 18:54:53.554078
# Unit test for constructor of class FactCache
def test_FactCache():
    # TODO: Add unit test for constructor of class FactCache
    assert False is False

# Generated at 2022-06-11 18:55:01.665289
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import mock

    class mock_plugin(object):
        def __init__(self):
            self.data = {'a': {'b': 'c'}}

        def get(self, key):
            return self.data[key]

        def keys(self):
            return self.data.keys()

        def contains(self, key):
            return key in self.data

    p = mock_plugin()
    with mock.patch('ansible.plugins.cache.FactCache.cache_loader.get') as get:
        get.return_value = p
        cache = FactCache()
        cache.first_order_merge(key='a', value={'b': 'z', 'd': 'e'})
        assert(cache['a'] == {'b': 'z', 'd': 'e'})

    p = mock_

# Generated at 2022-06-11 18:55:05.320608
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache is not None

# Generated at 2022-06-11 18:55:06.584205
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert not fact_cache

# Generated at 2022-06-11 18:55:08.156531
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert hasattr(fact_cache,'_plugin')


# Generated at 2022-06-11 18:55:18.162601
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    # Test with empty key
    fc._plugin.flush()
    fc._plugin.set("", {'a': 1})
    fc.first_order_merge('', {'a': 2})
    fc.first_order_merge('', {'b': 1})
    assert fc == {'': {'a': 2, 'b': 1}}

    # Test with valid keys
    fc._plugin.flush()
    fc._plugin.set("foo", {'a': 1})
    fc.first_order_merge('foo', {'a': 2})
    fc.first_order_merge('foo', {'b': 1})
    assert fc == {'foo': {'a': 2, 'b': 1}}

    # Test with different keys


# Generated at 2022-06-11 18:55:21.850462
# Unit test for constructor of class FactCache
def test_FactCache():
    # setup
    args = []
    kwargs = {}
    fc = FactCache(*args, **kwargs)

    # testing
    assert fc
    assert fc['minSize']


# Generated at 2022-06-11 18:55:31.336528
# Unit test for constructor of class FactCache
def test_FactCache():
    host_1 = "127.0.0.1"
    host_2 = "127.0.0.2"
    host_3 = "127.0.0.3"
    fc = FactCache()
    fc[host_1] = {"msg1": "hello", "msg2": "world", "msg3": "ansible"}
    print(fc[host_1])
    assert fc[host_1] == {"msg1": "hello", "msg2": "world", "msg3": "ansible"}
    fc[host_2] = {"msg1": "my", "msg2": "name", "msg3": "jerry"}
    print(fc[host_2])

# Generated at 2022-06-11 18:55:33.505627
# Unit test for constructor of class FactCache
def test_FactCache():
    fact = FactCache()
    assert fact._plugin

# Generated at 2022-06-11 18:55:38.009247
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.plugins.cache.jsonfile import CacheModule as JSONFile
    cache_loader.add("test_fact_cache", JSONFile)

    facts = FactCache()

    assert isinstance(facts, FactCache)
    assert isinstance(facts._plugin, JSONFile)

    cache_loader.remove("test_fact_cache")



# Generated at 2022-06-11 18:55:46.173974
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    key = "host"
    value = {'a':1}

    # test cases for method first_order_merge
    assert fact_cache.first_order_merge(key, value) == {key: {'a':1}} # There is no key in cache, should return value
    assert fact_cache.first_order_merge(key, value) == {key: {'a':1}} # There is a key in cache, should return {key: {'a':1}}
    assert fact_cache.first_order_merge(key, value) == {key: {'a':1}} # There is a key in cache, should return {key: {'a':1}}

# Generated at 2022-06-11 18:55:47.759976
# Unit test for constructor of class FactCache
def test_FactCache():
    f = FactCache()
    assert f._plugin is not None

# Generated at 2022-06-11 18:55:53.529668
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache=FactCache()
    fact_cache.__init__()


# Generated at 2022-06-11 18:56:04.160617
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    '''Unit test for method first_order_merge of class FactCache'''

    cache = FactCache()
    host_facts = {'ansible_all_ipv4_addresses': ['10.1.1.2', '10.1.1.3'],
                  'ansible_all_ipv6_addresses': ['ff02::1', 'fe80::1'],
                  'ansible_default_ipv4': {'interface': 'bond0', 'address': '10.1.1.2'},
                  'ansible_default_ipv6': {'interface': 'bond0',
                                           'address': 'fe80::1', 'gateway': '::1'}
                  }

# Generated at 2022-06-11 18:56:07.311632
# Unit test for constructor of class FactCache
def test_FactCache():

    cache = FactCache()

    if not isinstance(cache, FactCache):
        raise AssertionError("The constructor of class FactCache should return an instance of that class")

# Generated at 2022-06-11 18:56:07.762124
# Unit test for constructor of class FactCache
def test_FactCache():
    a = FactCache()

# Generated at 2022-06-11 18:56:18.679569
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    # Object to be tested
    factcache = FactCache()

    # Reference object
    dict_value = {}
    dict_value['key'] = 'value'
    factcache1 = FactCache()
    factcache1.update(dict_value)

    # Test all cases
    assert factcache1.keys() == factcache.keys(), "test_FactCache_first_order_merge 1 failed !"
    assert factcache1.keys() == factcache.keys(), "test_FactCache_first_order_merge 2 failed !"
    factcache.update(dict_value)
    assert factcache1.keys() == factcache.keys(), "test_FactCache_first_order_merge 3 failed !"
    factcache.first_order_merge('key', 'value')

# Generated at 2022-06-11 18:56:20.748912
# Unit test for constructor of class FactCache
def test_FactCache():
    my_cache = FactCache()
    assert isinstance(my_cache, MutableMapping)
    assert '_plugin' in my_cache.__dict__

# Generated at 2022-06-11 18:56:28.084410
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    # check for various methods of FactCache
    assert hasattr(fact_cache, '__init__')
    assert hasattr(fact_cache, '__getitem__')
    assert hasattr(fact_cache, '__setitem__')
    assert hasattr(fact_cache, '__delitem__')
    assert hasattr(fact_cache, '__contains__')
    assert hasattr(fact_cache, '__iter__')
    assert hasattr(fact_cache, '__len__')
    assert hasattr(fact_cache, 'copy')
    assert hasattr(fact_cache, 'keys')
    assert hasattr(fact_cache, 'flush')
    assert hasattr(fact_cache, 'first_order_merge')

# Generated at 2022-06-11 18:56:29.935910
# Unit test for constructor of class FactCache
def test_FactCache():
    '''
    ensure the module can be loaded and the constructor works
    '''
    cache = FactCache()
    assert(cache is not None)

# Generated at 2022-06-11 18:56:32.015320
# Unit test for constructor of class FactCache
def test_FactCache():
    my_cache = FactCache()
    assert isinstance(my_cache, FactCache)
    assert isinstance(my_cache, dict)

# Generated at 2022-06-11 18:56:38.175673
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    try:
        from ansible.module_utils.facts.collector import BaseFactCollector
    except ImportError:
        return

    fact_cache = FactCache()

    import datetime
    # build fact_cache content
    fact_cache['localhost'] = {'a': 1,
                               'b': 1,
                               'c': {'a': 1,
                                     'b': 1,
                                     'c': 1},
                               'update_cache_at': datetime.datetime.utcnow()}

    value = {'a': 2,
             'c': {'a': 2,
                   'b': 3,
                   'd': 1},
             'update_cache_at': datetime.datetime.utcnow()}

    fact_cache.first_order_merge('localhost', value)
   

# Generated at 2022-06-11 18:56:50.122297
# Unit test for constructor of class FactCache
def test_FactCache():
    c = FactCache()
    assert c._plugin is not None


# Generated at 2022-06-11 18:56:59.420983
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    a = FactCache()

    a.setdefault('test_key', dict())
    assert a.keys() == ['test_key']

    a.first_order_merge('test_key', {'test_key_1': 1})
    assert a['test_key']['test_key_1'] == 1

    a.first_order_merge('test_key', {'test_key_1': 2, 'test_key_2': 2})
    assert a['test_key']['test_key_1'] == 2
    assert a['test_key']['test_key_2'] == 2

    # Setting a value to None (for example, with the yaml plugin) deletes the
    # key from the fact_cache and prevents the second_order_merge from working.
    # This patch restores the key and

# Generated at 2022-06-11 18:57:02.039765
# Unit test for constructor of class FactCache
def test_FactCache():
    # Unit test the constructor
    factcache_object = FactCache()
    assert isinstance(factcache_object, FactCache)
    assert isinstance(factcache_object, MutableMapping)

# Generated at 2022-06-11 18:57:07.221855
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc.first_order_merge('localhost', {'my-foo': 'hello'})

    assert fc['localhost']['my-foo'] == 'hello'

    fc.first_order_merge('localhost', {'my-bar': 'world'})

    assert fc['localhost']['my-bar'] == 'world'

# Generated at 2022-06-11 18:57:12.116138
# Unit test for constructor of class FactCache
def test_FactCache():
    # Clear the fact cache
    fact_cache = FactCache()
    fact_cache.flush()

    # Test the constructor
    fact_cache = FactCache()
    # CACHE_PLUGIN may be changed when testing ansible.constants
    ansible_cache_plugin = C.CACHE_PLUGIN
    # Disable loading a cache plugin from a configuration file
    C.CACHE_PLUGIN = "jsonfile"
    fact_cache = FactCache()
    C.CACHE_PLUGIN = ansible_cache_plugin

    # Clear the fact cache
    fact_cache.flush()

# Generated at 2022-06-11 18:57:17.650229
# Unit test for constructor of class FactCache
def test_FactCache():

    fact_cache = FactCache()

    # Check for MutableMapping functionality 
    fact_cache["key"] = "value"
    fact_cache["key"] = "value"
    fact_cache["key"] = "value"
    fact_cache["key"] = "value"
    fact_cache["key"] = "value"
    fact_cache["key"] = "value"
    fact_cache["key"] = "value"
    fact_cache["key"] = "value"
    fact_cache["key"] = "value"
    fact_cache["key"] = "value"
    fact_cache["key"] = "value"
    del fact_cache["key"]

    fact_cache.flush()
    fact_cache.copy()
    fact_cache.keys()


# Generated at 2022-06-11 18:57:18.680336
# Unit test for constructor of class FactCache
def test_FactCache():
    ansible_test_cache = FactCache()
    assert ansible_test_cache._plugin


# Generated at 2022-06-11 18:57:28.680581
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    from collections import Mapping

    class MockCachePlugin(Mapping):

        def __init__(self):
            self.store = {'a': {'b': 1}}

        def __getitem__(self, key):
            return self.store[key]

        def __len__(self):
            return len(self.store)

        def __iter__(self):
            return iter(self.store)

        def contains(self, key):
            return True

        def get(self, key):
            return self.store[key]

        def set(self, key, value):
            self.store[key] = value

        def delete(self, key):
            del self.store[key]

        def flush(self):
            self.store = {}

        def keys(self):
            return self.store.keys()



# Generated at 2022-06-11 18:57:38.468609
# Unit test for constructor of class FactCache
def test_FactCache():
    # Here, we test the constructor of the class FactCache that
    # as of now only has a call to the constructor of the
    # super class.
    #
    # In order to test this function, one needs to mock the
    # constructor of the super class to not fail the unit test
    # for the class FactCache if the constructor of the super
    # class does not work as expected.
    #
    # As of now, we simply call the super class constructor if
    # it is necessary.
    #
    # In the future, we may need to mock the super class constructor
    # with a specific function to test the constructor of the class
    # FactCache
    fact_cache = FactCache()
    return True


# Generated at 2022-06-11 18:57:40.048861
# Unit test for constructor of class FactCache
def test_FactCache():
    factCache = FactCache()
    assert type(factCache) == FactCache

# Generated at 2022-06-11 18:58:06.572153
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    # TODO: add a unit test

# Generated at 2022-06-11 18:58:07.383752
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()


# Generated at 2022-06-11 18:58:13.277299
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    cache.first_order_merge('hostname', {'key': 'value'})
    assert cache['hostname'] == {'key': 'value'}
    cache.first_order_merge('hostname', {'key': 'other-value'})
    assert cache['hostname'] == {'key': 'other-value'}

# Generated at 2022-06-11 18:58:17.933704
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    ''' This method is used to test the first_order_merge method of FactCache class '''
    old_value = {'old': 'old'}
    new_value = {'old': 'new'}
    cache = FactCache()
    cache.update({'cache': old_value})
    cache.first_order_merge('cache', new_value)
    assert cache['cache'] == new_value

# Generated at 2022-06-11 18:58:22.404436
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.errors import AnsibleError

    try:
        fact_cache = FactCache()
    except AnsibleError:
        pass
    else:
        raise Exception("AnsibleError expected")

# Generated at 2022-06-11 18:58:32.837380
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    display.verbosity = 3
    display.debug("TEST: test_FactCache_first_order_merge()")
    
    fact_cache_obj = FactCache()

    display.debug("TEST: test_FactCache_first_order_merge(): Set the key 'somename'= 'somemac'")
    somemac = {'macaddress': 'somemac'}
    fact_cache_obj.first_order_merge('somename', somemac)
    display.debug("TEST: test_FactCache_first_order_merge(): fact_cache_obj['somename']= {0}".format(fact_cache_obj['somename']))


# Generated at 2022-06-11 18:58:37.607262
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.plugins.loader import cache_loader
    from ansible.errors import AnsibleError
    import pytest

    cache_loader.add('DummyCache', 'dummy')

    cache = FactCache()
    assert isinstance(cache, FactCache)

    cache_loader.remove('DummyCache')

    with pytest.raises(AnsibleError):
        FactCache()

# Generated at 2022-06-11 18:58:44.503108
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    """Returns a copy of the cache for testing purposes"""
    hostvars = dict({"awesome_fact": True})
    cache = FactCache(hostvars)

    host = "test_host"
    facts = dict({"other_fact": False})
    cache.first_order_merge(host, facts)

    # Make sure the initial values are still in the cache
    assert cache['awesome_fact'] is True
    # Make sure new values are in the cache
    assert cache[host]['other_fact'] is False

    cached_facts = cache.copy()
    assert cached_facts == dict({'awesome_fact': True, 'test_host': {'other_fact': False}})

# Generated at 2022-06-11 18:58:54.990651
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    """Test the first_order_merge method of the FactCache class."""
    fact_cache = FactCache()
    host_cache = dict(
        ansible_facts=dict(
            collect_facter_facts_plugins=dict(
                generic_facts=dict(
                    timezone="EDT",
                )
            )
        )
    )
    fact_cache.first_order_merge("test_host", host_cache)
    assert fact_cache["test_host"]["ansible_facts"]["collect_facter_facts_plugins"]["generic_facts"]["timezone"] == "EDT"


# Generated at 2022-06-11 18:59:00.735086
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    from ansible.module_utils.common._collections_compat import MutableMapping

    class MockCache(MutableMapping):

        def __init__(self, *args, **kwargs):
            self._cache = {}
            super(MockCache, self).__init__(*args, **kwargs)

        def __getitem__(self, key):
            return self._cache[key]

        def keys(self):
            return self._cache.keys()

        def __setitem__(self, key, value):
            self._cache[key] = value

        def __delitem__(self, key):
            del self._cache[key]

        def __contains__(self, key):
            return key in self._cache

        def __iter__(self):
            return iter(self._cache.keys())

       

# Generated at 2022-06-11 18:59:55.538870
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert(isinstance(fact_cache, FactCache))


# Generated at 2022-06-11 19:00:04.726714
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    host_name = 'test_host'
    host_facts_1 = {
        'test_fact': 'test_fact_value_1',
        'test_fact_1': 'test_fact_value_1'
    }
    host_facts_2 = {
        'test_fact': 'test_fact_value_2',
        'test_fact_2': 'test_fact_value_2'
    }
    host_facts_merged = {
        'test_fact': 'test_fact_value_2',
        'test_fact_1': 'test_fact_value_1',
        'test_fact_2': 'test_fact_value_2'
    }
    fact_cache = FactCache()
    fact_cache.first_order_merge(host_name, host_facts_1)

# Generated at 2022-06-11 19:00:06.120536
# Unit test for constructor of class FactCache
def test_FactCache():
    assert(isinstance(FactCache(), FactCache))



# Generated at 2022-06-11 19:00:11.417999
# Unit test for constructor of class FactCache
def test_FactCache():
    cache_plugin = cache_loader.get(C.CACHE_PLUGIN)
    if not cache_plugin:
        raise AnsibleError("Unable to load the facts cache plugin (%s)." % (C.CACHE_PLUGIN))
    # contructor of class FactCache
    fact_cache = FactCache()
    if fact_cache is None:
        raise AnsibleError("Unable to construct fact cache.")

# Generated at 2022-06-11 19:00:16.628801
# Unit test for constructor of class FactCache
def test_FactCache():
    #
    #  Creating an object
    #
    f = FactCache()
    #
    #  Writing test data
    #
    f[1] = 'abc'
    f[2] = 'def'
    f[3] = 'ghi'
    #
    #  Iterating over data
    #
    for x in f:
        print(x)
    #
    #  Calculating length
    #
    print(len(f))

test_FactCache()

# Generated at 2022-06-11 19:00:26.521434
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    cache_loader.get.assert_called_with(C.CACHE_PLUGIN)
    assert fc._plugin == 'test_plugin'
    assert fc.__getitem__.called is False
    assert fc.__setitem__.called is False
    assert fc.__delitem__.called is False
    assert fc.__contains__.called is False
    assert fc.__iter__.called is False
    assert fc.__len__.called is False
    assert fc.copy.called is False
    assert fc.keys.called is False
    assert fc.flush.called is False


# Generated at 2022-06-11 19:00:27.709474
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None
    fact_cache.flush()

# Generated at 2022-06-11 19:00:29.139450
# Unit test for constructor of class FactCache
def test_FactCache():
    # Create object of class FactCache
    fact_cache = FactCache()

    # Check object of class FactCache
    assert fact_cache is not None

# Generated at 2022-06-11 19:00:37.042014
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Testing first_order_merge of FactCache class
    # The first_order_merge is similar to update method of dict but update is
    # not used here because it is not a copy-on-write operation

    # Arrange
    a_fact_cache = FactCache()
    a_fact_cache["test_host"] = {"test_fact": "test_value"}

    # Act
    a_fact_cache.first_order_merge("test_host", {"new_fact": "new_value"})

    # Assert
    assert(a_fact_cache["test_host"] == {"test_fact": "test_value",
        "new_fact": "new_value"})

# Generated at 2022-06-11 19:00:38.948658
# Unit test for constructor of class FactCache
def test_FactCache():
    """Setup and return class instance"""
    cache_loader.get(C.CACHE_PLUGIN)
    fact_cache = FactCache()
    return fact_cache
