

# Generated at 2022-06-11 18:52:36.362267
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    facts = {'test': {'test1':'test2'}}
    fc.first_order_merge('test', facts)
    assert fc['test'] == {'test1':'test2'}
    facts1 = {'test':{'test1':'test3'}}
    fc.first_order_merge('test', facts1)
    assert fc['test'] == {'test1':'test3'}

# Generated at 2022-06-11 18:52:38.356967
# Unit test for constructor of class FactCache
def test_FactCache():
    parameters = dict()
    fact_cache = FactCache(parameters)
    assert isinstance(fact_cache, FactCache)

# Generated at 2022-06-11 18:52:41.005464
# Unit test for constructor of class FactCache
def test_FactCache():
    assert isinstance(FactCache(), FactCache)


# Generated at 2022-06-11 18:52:42.512356
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc is not None

# Generated at 2022-06-11 18:52:52.311380
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()

    host_facts_1 = {'ansible_os_family': 'RedHat', 'ansible_distribution': 'CentOS', 'ansible_distribution_version': '7.0'}
    host_facts_2 = {'ansible_os_family': 'RedHat', 'ansible_distribution': 'CentOS', 'ansible_distribution_version': '6.8'}
    host_facts_3 = {'ansible_os_family': 'RedHat', 'ansible_distribution': 'Fedora', 'ansible_distribution_version': '26'}
    host_facts_4 = {'ansible_os_family': 'RedHat', 'ansible_distribution': 'Fedora', 'ansible_distribution_version': '27'}

# Generated at 2022-06-11 18:52:53.853125
# Unit test for constructor of class FactCache
def test_FactCache():
    facts = FactCache()
    assert isinstance(facts, FactCache)

# Generated at 2022-06-11 18:52:57.693697
# Unit test for constructor of class FactCache
def test_FactCache():
    f = FactCache()
    assert f
    assert isinstance(f._plugin, cache_loader.get(C.CACHE_PLUGIN).__class__)
    return

# Generated at 2022-06-11 18:53:04.855381
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    k1 = 'key1'
    k2 = 'key2'
    k3 = 'key3'
    v1 = 'value1'
    test_cache = {}

    fact_cache = FactCache()
    fact_cache.first_order_merge(k1, v1)
    fact_cache.first_order_merge(k2, v1)
    fact_cache.first_order_merge(k3, v1)

    # Verify the cache in memory is correct after calling first_order_merge
    test_cache[k1] = v1
    test_cache[k2] = v1
    test_cache[k3] = v1
    assert test_cache == fact_cache

    # Verify the values in the cache under key k1 and k3 are merged

# Generated at 2022-06-11 18:53:09.977739
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.errors import AnsibleError
    from ansible.plugins.loader import cache_loader
    try:
        cache = FactCache()
    except AnsibleError as e:
        print(e)
    cache_loader.set('memory', 'memory')
    cache = FactCache()
    assert(cache._plugin.name == 'memory'), "Can't load memory cache plugin."

# Generated at 2022-06-11 18:53:10.500538
# Unit test for constructor of class FactCache
def test_FactCache():
    FactCache()

# Generated at 2022-06-11 18:53:18.404309
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.errors import AnsibleError
    from ansible.plugins.loader import plugins
    from ansible.plugins.loader import cache_loader
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.collection_loader import AnsibleCollectionRef

    # config
    config_data = {
        "fact_caching": "jsonfile",
        "fact_caching_connection": "/tmp"
    }

    config_dict = {}
    for k, v in config_data.items():
        config_dict[k] = v

    # collection_loader
    collection_loader = AnsibleCollectionLoader()
    invalid_coll_data = { "name": "", "version": 1, "main": {}}

# Generated at 2022-06-11 18:53:24.570404
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    assert not fact_cache

    fact_cache.first_order_merge("host1", dict(a=dict(b=1), c=2))
    assert fact_cache["host1"] == dict(a=dict(b=1), c=2)

    fact_cache.first_order_merge("host1", dict(a=dict(c=3)))
    assert fact_cache["host1"] == dict(a=dict(b=1, c=3), c=2)

# Generated at 2022-06-11 18:53:25.357743
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()

# Generated at 2022-06-11 18:53:29.293049
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin is not None
    assert fc._plugin.keys() == []


# Generated at 2022-06-11 18:53:38.156641
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.flush()
    assert fact_cache == {}
    #test for simple host facts
    host_facts = {'127.0.0.1': {'ansible_distribution': 'CentOS'}}
    fact_cache.first_order_merge('127.0.0.1', host_facts['127.0.0.1'])
    assert fact_cache == host_facts
    #test for nested host facts
    host_facts['127.0.0.1']['ansible_lsb'] = {'major': 6, 'minor': 8, 'codename': 'Ultimate Edition'}
    fact_cache.first_order_merge('127.0.0.1', host_facts['127.0.0.1'])
    assert fact_cache == host

# Generated at 2022-06-11 18:53:41.030692
# Unit test for constructor of class FactCache
def test_FactCache():
    f = FactCache()
    assert f

# Generated at 2022-06-11 18:53:48.164347
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.utils.path import makedirs_safe
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_bytes
    import os
    import shutil

    # create a test file
    cache_dir = u"/tmp/ansible_test_cache"
    makedirs_safe(cache_dir)
    cache_file = cache_dir + u"/facts_cache"

    test_facts = {u"test_fact": u"test_fact_value"}

    # create a fact cache instance
    cache = FactCache()

    # test that the fact cache contains no keys
    assert len(cache) == 0
    assert list(cache.keys()) == []
    assert not cache.__contains__(u"test_host")

    #

# Generated at 2022-06-11 18:53:58.590510
# Unit test for constructor of class FactCache
def test_FactCache():

    display.verbosity = 4
    C.CACHE_PLUGIN = 'memory'
    display.verbosity = 4

    class MockArgs(object):
        def __init__(self):
            self.cache_type = ''
            self.cache_plugin = 'memory'
            self.cache_connection = None
            self.force_handlers = False

    class MockCachePlugin(object):
        def __init__(self):
            self.cache_dir = None
            self._plugin_options = {}

        def contains(self, key):
            fc = FactCache()
            if key in fc:
                return True
            else:
                return False

        def get(self, key):
            fc = FactCache()
            if key in fc:
                return fc[key]
            else:
                raise

# Generated at 2022-06-11 18:53:59.694343
# Unit test for constructor of class FactCache
def test_FactCache():
   assert isinstance(FactCache(), MutableMapping)

# Generated at 2022-06-11 18:54:00.938490
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)

# Generated at 2022-06-11 18:54:04.922316
# Unit test for constructor of class FactCache
def test_FactCache():
    obj = FactCache()
    assert isinstance(obj, FactCache)


# Generated at 2022-06-11 18:54:13.517817
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc.first_order_merge("host01", {"ansible_host": "127.0.0.1", "ansible_os_family": "RedHat"})
    fc.first_order_merge("host01", {"ansible_host": "127.0.0.1", "ansible_os_family": "RedHat"})
    fc.first_order_merge("host01", {"ansible_host": "127.0.0.1", "ansible_os_family": "Debian"})
    assert fc["host01"] == {"ansible_host": "127.0.0.1", "ansible_os_family": "Debian"}

# Generated at 2022-06-11 18:54:14.004504
# Unit test for constructor of class FactCache
def test_FactCache():
    assert True

# Generated at 2022-06-11 18:54:19.441266
# Unit test for constructor of class FactCache
def test_FactCache():                             # pragma: no cover
    from ansible.cache import FactCache
    from ansible.module_utils.facts import cache as FactCacheFile
    fact_cache_file = FactCacheFile()
    fact_cache = FactCache()
    assert fact_cache._plugin == fact_cache_file
    return fact_cache, fact_cache_file


# Generated at 2022-06-11 18:54:20.159222
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()

# Generated at 2022-06-11 18:54:31.294230
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc.first_order_merge("test.host", dict(foo=1, bar=2, baz='zoo'))
    if not fc.first_order_merge("test.host", dict(foo=2)):
        assert fc['test.host']['foo'] == 2
    if not fc.first_order_merge("test.host", dict(bar=3, baz='noo', zoo='blah')):
        assert fc['test.host']['bar'] == 3
        assert fc['test.host']['baz'] == 'noo'
        assert fc['test.host']['zoo'] == 'blah'

# Generated at 2022-06-11 18:54:32.760800
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)

# Generated at 2022-06-11 18:54:41.113514
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import pytest

    fc = FactCache()
    fc["localhost"] = {"a": 1, "b": 2, "c": 3}

    # Tests
    fc.first_order_merge("localhost", {"a": 1, "b": 2, "c": 3})
    assert fc["localhost"] == {"a": 1, "b": 2, "c": 3}

    fc.first_order_merge("localhost", {"b": 2, "c": 4, "d": 4})
    assert fc["localhost"] == {"a": 1, "b": 2, "c": 4, "d": 4}

    fc.first_order_merge("localhost", {"b": 2, "c": 4, "d": 4, "e": 5})

# Generated at 2022-06-11 18:54:41.513812
# Unit test for constructor of class FactCache
def test_FactCache():
    assert FactCache

# Generated at 2022-06-11 18:54:50.963145
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()

    # create a dictionary to be passed to fact_cache.first_order_merge
    data1 = {'a': 1}
    data2 = {'b': 1}
    data3 = {'c': 1, 'e': 1}

    def run_test():
        """ Runs the test and asserts the results, if the assert fails a KeyError is raised """

        # the key cache_key will not be in the cache at first
        # first_order_merge will add the value of data1 to the cache
        fact_cache.first_order_merge('cache_key', data1)
        assert(fact_cache['cache_key'] == data1)

        # first_order_merge should merge the value of data2 into data1 and add the result to the cache
        fact_cache.first_

# Generated at 2022-06-11 18:55:01.452794
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import os
    import json
    import pytest
    from ansible.cache.fact_cache import FactCache
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.utils.display import Display

    class TestCache(MutableMapping):
        def __init__(self, *args, **kwargs):
            self._data = {}
        def __getitem__(self, key):
            return self._data[key]
        def __setitem__(self, key, value):
            self._data[key] = value
        def __delitem__(self, key):
            del self._data[key]
        def __contains__(self, key):
            return key in self._data
        def __iter__(self):
            return iter(self._data)
       

# Generated at 2022-06-11 18:55:07.201125
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    value = {'key1': 'value1'}
    fact_cache.first_order_merge('test_host', value)
    assert fact_cache['test_host'] == value
    value = {'key2': 'value2'}
    fact_cache.first_order_merge('test_host', value)
    assert fact_cache['test_host'] == {'key1': 'value1', 'key2': 'value2'}

# Generated at 2022-06-11 18:55:13.201147
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    # create object
    fact_cache = FactCache()

    # create sample input
    key = 'localhost'
    value = {'localhost_fact': 'localhost_value', 'other_fact': 'other_value'}
    host_facts = {'localhost': {'localhost_fact': 'localhost_value', 'other_fact': 'other_value'}}

    # get result
    fact_cache.first_order_merge(key, value)

    # compare
    assert(host_facts == fact_cache.copy())

# Generated at 2022-06-11 18:55:20.839211
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    # create a dummy plugin for testing
    class DummyPlugin(object):
        def __init__(self):
            self._cache = {}

        def contains(self, key):
            return key in self._cache

        def get(self, key):
            return self._cache.get(key)

        def set(self, key, value):
            self._cache.update({key: value})

        def delete(self, key):
            del self._cache[key]

        def flush(self):
            self._cache = {}

        def keys(self):
            return self._cache.keys()

    dummy_plugin = DummyPlugin()

    # create a cache object that uses the dummy plugin
    cache = FactCache()
    cache._plugin = dummy_plugin

    # create two keys with the same hostname

# Generated at 2022-06-11 18:55:22.498327
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)

# Generated at 2022-06-11 18:55:24.386250
# Unit test for constructor of class FactCache
def test_FactCache():
    # Constructor of class FactCache
    # Test with no arguments
    fact_cache = FactCache()
    assert fact_cache

# Generated at 2022-06-11 18:55:26.612697
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert isinstance(fc, FactCache)
    assert isinstance(fc, MutableMapping)

# Generated at 2022-06-11 18:55:28.367578
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert isinstance(cache, FactCache)

# Generated at 2022-06-11 18:55:34.561001
# Unit test for constructor of class FactCache
def test_FactCache():
    import json
    from ansible.module_utils.facts import ansible_facts

    facts_cache = FactCache()

    # cache the facts
    facts_cache['host1'] = ansible_facts.get_facts()
    facts_cache['host2'] = ansible_facts.get_facts()

    # retrieve the facts from cache
    result = facts_cache['host1']
    assert result == ansible_facts.get_facts()

    # update the facts
    facts_cache['host1']['ansible_distribution_file_parsed'] = {'release': 'A', 'name': 'A'}

    # retrieve the facts from cache
    result = facts_cache['host1']
    assert result == facts_cache['host1']

    # delete the facts
    del facts_cache['host1']

# Generated at 2022-06-11 18:55:44.326608
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Test 1 - check update of host_cache with host_facts if host_cache is available
    cache = FactCache()
    host_cache = {'test1': 'test1', 'test2': 'test2'}
    host_facts = {'test3': 'test3'}
    cache._plugin.set('test.cache', host_cache)
    cache.first_order_merge('test.cache', host_facts)
    assert cache._plugin.get('test.cache') == {'test1': 'test1', 'test2': 'test2', 'test3': 'test3'}

    # Test 2 - check update of host_facts with host_cache if host_cache is unavailable
    cache = FactCache()
    host_cache = {'test1': 'test1', 'test2': 'test2'}
    host

# Generated at 2022-06-11 18:55:50.221829
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, MutableMapping)

# Generated at 2022-06-11 18:55:57.544474
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    class FakePlugin:

        def __init__(self, data):
            self._data = data

        def get(self, key):
            return self._data.get(key)

        def flush(self):
            self._data.clear()

        def set(self, key, value):
            self._data[key] = value

        def delete(self, key):
            self._data.pop(key, None)

        def contains(self, key):
            return key in self._data

        def keys(self):
            return self._data.keys()

    fake_data = {'a': {'c': 0, 'd': 2}}
    fake_plugin = FakePlugin(fake_data)

    fact_cache = FactCache()
    fact_cache._plugin = fake_plugin

    # a(c) + b(c)

# Generated at 2022-06-11 18:55:59.119388
# Unit test for constructor of class FactCache
def test_FactCache():

    # Act
    fc = FactCache()

    # Assert
    assert fc.__dict__['_plugin'].__class__.__name__ == 'FactCacheData'

# Generated at 2022-06-11 18:56:00.545559
# Unit test for constructor of class FactCache
def test_FactCache():
    facts_cache = FactCache()
    assert facts_cache is not None


# Generated at 2022-06-11 18:56:04.557606
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    host = '127.0.0.1'
    facts = {'firstkey' : 'firstvalue'}
    fc = FactCache()
    fc.first_order_merge(host, facts)

    assert fc.keys(), [host]

    assert fc.get(host) == facts

# Generated at 2022-06-11 18:56:10.207936
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    # Setup
    plugin = C.CACHE_PLUGIN
    C.CACHE_PLUGIN = "jsonfile"
    fact_cache = FactCache()
    fact_cache.flush()

    key = "localhost"
    value = {"ansible_kernel": "Linux"}

    # Exercise
    fact_cache.first_order_merge(key, value)

    # Verify
    assert fact_cache[key] == value

    # Teardown
    C.CACHE_PLUGIN = plugin

# Generated at 2022-06-11 18:56:13.053618
# Unit test for constructor of class FactCache
def test_FactCache():
    assert FactCache()


# Generated at 2022-06-11 18:56:14.524167
# Unit test for constructor of class FactCache
def test_FactCache():
    assert isinstance(FactCache(), FactCache)

# Generated at 2022-06-11 18:56:17.085590
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    cache.first_order_merge('test.example.com', {'test': 'foo'})
    assert cache['test.example.com'] == {'test': 'foo'}

# Generated at 2022-06-11 18:56:18.186044
# Unit test for constructor of class FactCache
def test_FactCache():
    obj = FactCache()
    assert isinstance(obj, MutableMapping)

# Generated at 2022-06-11 18:56:30.967052
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin.name == 'memory'

# Generated at 2022-06-11 18:56:33.548669
# Unit test for constructor of class FactCache
def test_FactCache():

    fc = FactCache()
    assert fc
    assert isinstance(fc, MutableMapping)
    assert len(fc) == 0
    assert fc._plugin
    assert isinstance(fc._plugin, cache_loader.cache_mgr())

# Generated at 2022-06-11 18:56:35.014831
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert '_plugin' in dir(cache)

# Generated at 2022-06-11 18:56:42.860033
# Unit test for constructor of class FactCache
def test_FactCache():
    import tempfile
    from ansible.module_utils._text import to_bytes

    fd, tfn = tempfile.mkstemp(prefix='ansible_')
    cache = FactCache(plugin='jsonfile', expire=60, conn_info={'dir': to_bytes(tfn)})

    cache['test'] = 'test'

    # Now read it
    cache = FactCache(plugin='jsonfile', expire=60, conn_info={'dir': to_bytes(tfn)})

    assert cache.keys() == ['test']
    assert cache['test'] == 'test'
    cache.flush()

# Generated at 2022-06-11 18:56:44.197842
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.name == 'jsonfile'

# Generated at 2022-06-11 18:56:50.029408
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import json
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.plugins import cache_loader
    from ansible.utils.display import Display

    class Plugin(MutableMapping):

        def contains(self, key):
            return key in self._data

        def delete(self, key):
            del self._data

        def get(self, key):
            return self._data[key]

        def keys(self):
            return self._data.keys()

        def set(self, key, value):
            self._data[key] = value

    display = Display()

    test_data = {"test":"data"}
    test_key = "test_key"

    cache = FactCache()
    cache._plugin = Plugin()
    cache._plugin._data = {}

    cache

# Generated at 2022-06-11 18:56:59.383009
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    f = FactCache()
    f.flush()

    key_str = '192.168.1.1'
    value_str = {'somestring': 'somestringvalue'}
    f.first_order_merge(key_str, value_str)

    key_dict = '192.168.1.2'
    value_dict = {'somedict': {'somekey': 'somevalue'}}
    f.first_order_merge(key_dict, value_dict)

    key_list = '192.168.1.3'
    value_list = {'somelist': ['item1', 'item2']}
    f.first_order_merge(key_list, value_list)

    # Test if the facts cache was updated
    assert f[key_str] == value

# Generated at 2022-06-11 18:57:02.431797
# Unit test for constructor of class FactCache
def test_FactCache():
    dataList = {'foo':'bar'}
    factCache = FactCache(dataList)

    print(factCache)
    # print(factCache.get('foo'))

# test_FactCache()

# Generated at 2022-06-11 18:57:02.962306
# Unit test for constructor of class FactCache
def test_FactCache():
    FactCache()

# Generated at 2022-06-11 18:57:07.551821
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    from ansible.module_utils.facts import cache as fact_cache
    fact_cache.flush()
    fact_cache.first_order_merge('aa', {'a': 'b'})
    assert(fact_cache['aa']['a'] == 'b')
    fact_cache.flush()


# Generated at 2022-06-11 18:57:35.455399
# Unit test for constructor of class FactCache
def test_FactCache():
    plugin = cache_loader.get(C.CACHE_PLUGIN)
    fact_cache = FactCache()
    assert fact_cache._plugin == plugin



# Generated at 2022-06-11 18:57:37.178110
# Unit test for constructor of class FactCache
def test_FactCache():
    test = FactCache()
    assert isinstance(test, FactCache)

# Generated at 2022-06-11 18:57:39.871372
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.module_utils.facts.cache import FactCache
    import os
    cache = FactCache()

    assert isinstance(cache, FactCache)
    assert cache._plugin is not None
    assert os.path.exists(cache._plugin.cache.cache_dir)

# Generated at 2022-06-11 18:57:48.848346
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    facts_to_cache = {'ansible_distribution_version': '17.10', 'ansible_distribution': 'Ubuntu', 'ansible_lsb': {'codename': 'artful', 'major_release': '17', 'description': 'Ubuntu 17.10', 'id': 'Ubuntu', 'release': '17.10'}, 'ansible_hostname': 'host1', 'ansible_machine': 'x86_64', 'ansible_architecture': 'x86_64'}
    cache = FactCache()
    cache.first_order_merge('host1', facts_to_cache)
    assert cache.__len__() == 1

# Generated at 2022-06-11 18:57:58.983838
# Unit test for method first_order_merge of class FactCache

# Generated at 2022-06-11 18:58:05.057643
# Unit test for constructor of class FactCache

# Generated at 2022-06-11 18:58:10.387596
# Unit test for constructor of class FactCache
def test_FactCache():
    print("Test constructor of class FactCache")
    fact_cache = FactCache()
    facts = {"a": 1, "b": 2}
    fact_cache["h1"] = facts
    #print(fact_cache.keys())
    #print(fact_cache["x1"])


if __name__ == '__main__':
    test_FactCache()

# Generated at 2022-06-11 18:58:16.125880
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    factCache = FactCache()
    factCache.first_order_merge('192.168.10.11', {'name': 'test'})
    factCache.first_order_merge('192.168.10.11', {'name': 'test11'})
    print(factCache)
    assert factCache['192.168.10.11']['name'] == 'test11'

# Generated at 2022-06-11 18:58:17.186266
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc


# Generated at 2022-06-11 18:58:25.252435
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    test_data = {'test1': 'data1'}
    fc.update(test_data)
    assert fc['test1'] == 'data1'
    fc['test2'] = 'data2'
    assert fc['test2'] == 'data2'
    del fc['test2']
    assert 'test2' not in fc
    print(fc.keys())
    fc.flush()
    assert 'test1' not in fc

if __name__ == '__main__':
    test_FactCache()

# Generated at 2022-06-11 18:59:26.132523
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    from collections import OrderedDict

    cache = FactCache()
    cache.first_order_merge('hostvars', OrderedDict([('hello', 1), ('world', 2)]))
    cache.first_order_merge('hostvars', OrderedDict([('foo', 3), ('bar', 4)]))

    assert cache['hostvars'] == OrderedDict([('hello', 1), ('world', 2), ('foo', 3), ('bar', 4)]), \
        'cache has wrong content'


# Create a singleton instance of this class
# The reference is stored in the fact module
# so it can be passed as an argument of the setup module
fact_cache = FactCache()

# Generated at 2022-06-11 18:59:29.649453
# Unit test for constructor of class FactCache
def test_FactCache():
    test_cache = FactCache(['host1','host2','host3'])
    # Initialisation of plugin to None as it is not set in constructor
    assert test_cache._plugin == None


# Unit Tests for __getitem__ of class FactCache

# Generated at 2022-06-11 18:59:33.876929
# Unit test for constructor of class FactCache
def test_FactCache():
    # test if it's a subclass of MutableMapping ==> True
    assert issubclass(FactCache, MutableMapping)

    # create an instance of FactCache
    fac = FactCache()

    # test if it's an instance of FactCache ==> True
    assert isinstance(fac, FactCache)

# Generated at 2022-06-11 18:59:42.381982
# Unit test for constructor of class FactCache
def test_FactCache():
    ansible_facts = { "fact1": "foo", "fact2": "bar" }
    fact_cache = FactCache()
    test_success = False
    try:
        # Fill in the fact cache with facts
        fact_cache[ansible_facts["fact1"]] = ansible_facts["fact2"]
        # Now check if the facts are in the fact cache with a contains
        if ansible_facts["fact1"] in fact_cache:
            # Now check if the facts are in the fact cache with a getitem
            if fact_cache[ansible_facts["fact1"]] == ansible_facts["fact2"]:
                test_success = True
    except KeyError:
        print("Failed adding or retrieving facts from fact cache")

    # unlock the fact cache plugin
    fact_cache._plugin.unlock()

   

# Generated at 2022-06-11 18:59:48.156711
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    # Cache has a value for the key
    cache = FactCache()
    cache['key1'] = {'key2': {'key3': 'value3'}}

    value = {'key2': {'key4': 'value4'}}
    cache.first_order_merge('key1', value)

    assert cache['key1'] == {'key2': {'key3': 'value3', 'key4': 'value4'}}

    # Cache does not have a value for the key
    cache = FactCache()
    value = {'key2': {'key4': 'value4'}}
    cache.first_order_merge('key1', value)

    assert cache['key1'] == value

# Generated at 2022-06-11 18:59:49.495830
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache

# Generated at 2022-06-11 18:59:51.836589
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache._plugin.__class__.__name__ == 'FactCache'


# Unit tests for __init__ method of class FactCache

# Generated at 2022-06-11 18:59:54.169187
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-11 18:59:56.029844
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache
    assert len(fact_cache) == 0

# Generated at 2022-06-11 18:59:59.119005
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    f = FactCache()
    f[None] = {"a": 1}
    f.first_order_merge(None, {"b": 1})
    assert f[None] == {"a": 1, "b": 1}



# Generated at 2022-06-11 19:01:52.603446
# Unit test for constructor of class FactCache
def test_FactCache():
    assert isinstance(FactCache(), FactCache)


# Generated at 2022-06-11 19:01:57.018214
# Unit test for constructor of class FactCache
def test_FactCache():
    import os
    import tempfile

    try:
        fd, path = tempfile.mkstemp(prefix='fact_cache')
        cache = FactCache(path=path, plugin='jsonfile')
    finally:
        os.close(fd)
        os.unlink(path)
        pass

# Generated at 2022-06-11 19:02:03.756282
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge(key='test_host', value={'a':1, 'b':2})
    assert fact_cache['test_host'] == {'a':1, 'b':2}, 'Error when setting a host fact'
    fact_cache.first_order_merge(key='test_host', value={'c':3})
    assert fact_cache['test_host'] == {'c':3, 'a':1, 'b':2}, 'Error when updating a host fact'

# Generated at 2022-06-11 19:02:08.297682
# Unit test for constructor of class FactCache
def test_FactCache():
    mocked_plugin_get = 'ansible.plugins.cache.jsonfile.CacheModule'
    fact_cache = FactCache(mocked_plugin_get)
    fact_cache.set("foo", "bar")
    assert fact_cache.get("foo") == "bar"


# Generated at 2022-06-11 19:02:09.113628
# Unit test for constructor of class FactCache
def test_FactCache():
    assert FactCache()

# Generated at 2022-06-11 19:02:19.629684
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    init_fact_cache = FactCache()

    first_data = {"localhost": {"a": 1}}
    init_fact_cache.first_order_merge(first_data.keys()[0], first_data.values()[0])
    assert first_data == init_fact_cache


    second_data = {"localhost": {"a": 2}}
    init_fact_cache.first_order_merge(second_data.keys()[0], second_data.values()[0])
    assert first_data != init_fact_cache
    assert second_data == init_fact_cache


    third_data = {"localhost": {"a": 2, "b": 2}}
    init_fact_cache.first_order_merge(third_data.keys()[0], third_data.values()[0])
    assert first_

# Generated at 2022-06-11 19:02:30.659961
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Test case 1: fact cache is empty
    # Expectation: only host is added to the fact cache
    fact_cache = FactCache()
    host_facts = {'ip_address': '192.168.1.10', 'hostname': 'host-name'}
    fact_cache.first_order_merge('host1', host_facts)
    assert fact_cache.keys() == ['host1']
    assert fact_cache['host1'] == {'ip_address': '192.168.1.10', 'hostname': 'host-name'}

    # Test case 2: facts of host 1 is stored in the fact cache
    # Expectation: new facts of host 1 is merged with the old facts and update the fact cache;
    #              host 2 is added to the fact cache