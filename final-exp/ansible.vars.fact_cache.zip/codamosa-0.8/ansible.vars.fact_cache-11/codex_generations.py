

# Generated at 2022-06-11 18:52:39.476732
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.flush()
    fact_cache.first_order_merge('127.0.0.1', {'ansible_os_family': 'RedHat'})
    fact_cache.first_order_merge('127.0.0.1', {'ansible_os_family': 'RedHat', 'ansible_distribution': 'CentOS'})
    assert fact_cache['127.0.0.1'] == {'ansible_os_family': 'RedHat', 'ansible_distribution': 'CentOS'}

# Generated at 2022-06-11 18:52:46.144326
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    test_fact_cache = FactCache()
    test_fact_cache.first_order_merge('localhost', {"test_fact":"test_value"})
    assert test_fact_cache["localhost"]["test_fact"] == "test_value"
    test_fact_cache.first_order_merge('localhost', {"test_fact":"test_value2"})
    assert test_fact_cache["localhost"]["test_fact"] == "test_value2"

# Generated at 2022-06-11 18:52:57.218668
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc.first_order_merge('nIp',{'wins': 'true', 'ipv4': '192.168.0.2', 'ipv6': ['fe80::9898:d0ff:fe21:67cf']})
    # fc.first_order_merge('niP',{'wins': 'true', 'ipv4': '192.168.0.3', 'ipv6': ['fe80::9898:d0ff:fe21:67cf']})
    # fc.first_order_merge('nIp',{'wins': 'false', 'ipv4': '192.168.0.4', 'ipv6': ['fe80::9898:d0ff:fe21:67cf']})
    fc.first_order

# Generated at 2022-06-11 18:53:01.992109
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    key = 'key'
    value = {'key':'value'}

    # First call - no exception
    fact_cache.first_order_merge(key, value)

    # Second call - KeyError exception
    class test_FactCache_first_order_merge:
        def contains(self, key):
            return value
        def get(self, key):
            raise KeyError


# Generated at 2022-06-11 18:53:09.272819
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    f = FactCache()
    hostvars = f.first_order_merge('host', {'hostvars': {'key': 'value'}})
    assert hostvars == {'key': 'value'}

    f.flush()
    hostvars = f.first_order_merge('host', {'hostvars': {'newkey': 'newvalue'}})
    assert hostvars == {'key': 'value', 'newkey': 'newvalue'}


# Generated at 2022-06-11 18:53:13.261210
# Unit test for constructor of class FactCache
def test_FactCache():
    print('Testing FactCache')
    fc = FactCache()
    assert fc
    assert fc._plugin
    assert isinstance(fc, dict)
    assert isinstance(fc._plugin, dict)
    assert len(fc) == len(fc._plugin)
    assert fc.keys() == fc._plugin.keys()


# Generated at 2022-06-11 18:53:17.132412
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc.first_order_merge(dict(a=1, b=2))
    assert fc['a'] == 1
    assert fc['b'] == 2

    fc.first_order_merge(dict(a=3, c=4))
    assert fc['a'] == 3
    assert fc['b'] == 2
    assert fc['c'] == 4

    fc._plugin.flush()

# Generated at 2022-06-11 18:53:26.089179
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    factcache = FactCache()
    factcache.first_order_merge('host1', {'foo': 'bar'})
    # assert that the key goes into the facts cache
    assert factcache['host1']['foo'] == 'bar'

    # assert that the same key does not merge the same value
    factcache.first_order_merge('host1', {'foo': 'bar'})
    assert factcache['host1']['foo'] == 'bar'
    factcache.first_order_merge('host1', {'foo': 'notbar'})
    assert factcache['host1']['foo'] == 'notbar'



# Generated at 2022-06-11 18:53:26.887176
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()


# Generated at 2022-06-11 18:53:33.710350
# Unit test for constructor of class FactCache
def test_FactCache():
    data = {
        "hostvars": {
            "host1": {},
            "host2": {},
            "host3": {"cache": {}}
        }
    }

    try:
        from ansible.utils.plugin_docs import get_docstring
    except ImportError:
        from ansible.utils.docstring import get_docstring

    doc = get_docstring(data)
    assert doc is not None
    assert doc is not ''
    assert doc.startswith("{")
    assert doc.endswith("}")

    FactCache()

# Generated at 2022-06-11 18:53:37.339985
# Unit test for constructor of class FactCache
def test_FactCache():
    with pytest.raises(AnsibleError):
        my_fact_cache = FactCache()

# Generated at 2022-06-11 18:53:47.108494
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc.first_order_merge('host_1' , {'ipaddr': '192.168.0.1'})
    assert fc['host_1']['ipaddr'] == '192.168.0.1'

    fc.first_order_merge('host_1' , {'mem': '4G'})
    assert fc['host_1']['mem'] == '4G'

    fc.first_order_merge('host_1' , {'ipaddr': '192.168.0.2'})
    assert fc['host_1']['ipaddr'] == '192.168.0.2'
    assert fc['host_1']['mem'] == '4G'


# Generated at 2022-06-11 18:53:57.002449
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    test_key = "test_key"
    test_value = {"test_value1": "test_value1"}
    fact_cache.first_order_merge(test_key, test_value)
    assert fact_cache[test_key] == test_value, "The value returned by FactCache.first_order_merge is not correct"

    test_value2 = {"test_value2": "test_value2"}
    fact_cache.first_order_merge(test_key, test_value2)
    assert fact_cache[test_key] == test_value2, "The value returned by FactCache.first_order_merge is not correct after updated"

# Generated at 2022-06-11 18:54:08.402302
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    # run this test only if the cache plugin is defined
    if C.CACHE_PLUGIN:

        # create cache object
        cache = FactCache()

        # dict for testing
        test_dict = {'key': 'value'}

        # test if the cache is empty before the insert
        assert not cache.keys()

        # first insertion
        cache.first_order_merge('first_order_merge', test_dict)

        # test if the dict was inserted into the cache
        assert cache.keys() == ['first_order_merge']
        assert cache.keys() != ['first_order_merge_2']

        # test if the dict is inserted into cache and the value is the same
        assert cache['first_order_merge'] == test_dict

        # second insertion with same key but different value to test update


# Generated at 2022-06-11 18:54:14.759365
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    _FactCache_instance = FactCache()
    _FactCache_instance.first_order_merge('key1', 'value1')
    _FactCache_instance.first_order_merge('key2', 'value2')
    _FactCache_instance.first_order_merge('key1', 'value3')
    assert _FactCache_instance == {'key1': 'value3', 'key2': 'value2'}

# Generated at 2022-06-11 18:54:23.275225
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    class CacheMock(object):

        def __init__(self):
            self.keys = ["A", "B", "C", "D"]
            self.values = {"A": {"key1": "val1", "key2": "val2"},
                           "B": {"key3": "val3", "key4": "val4"},
                           "C": {"key5": "val5", "key6": "val6"}}

        def contains(self, key):
            # If key 'D' is in our FactCache, _plugin.get() will raise a KeyError
            return key != "D"

        def get(self, key):
            # KeyError is raised when key 'D' is tested
            if key == "D":
                raise KeyError
            return self.values[key]


# Generated at 2022-06-11 18:54:33.191874
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Dict 'value' has newer values for the fields:
    #   'kernel' and 'ssh_host_keys'
    key = "192.168.1.10"

# Generated at 2022-06-11 18:54:35.738537
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = None
    try:
        fc = FactCache()
    except AnsibleError:
        pass
    assert fc is not None

# Generated at 2022-06-11 18:54:42.650616
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import json
    import tempfile
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.cache import jsonfile
    from ansible.module_utils.six import PY3

    if PY3:
        unicode = str
    temp_dir = tempfile.mkdtemp()
    plugin = jsonfile.Jsonfile(temp_dir)
    plugin.flush()
    fact_cache = FactCache()
    fact_cache._plugin = plugin
    for key in ['hello', 'ansible']:
        fact_cache.first_order_merge(key, {key: 'world'})
    for key in ['hello', 'ansible']:
        assert key in fact_cache
        if PY3:
            assert to_bytes(key) in fact_cache

# Generated at 2022-06-11 18:54:46.546155
# Unit test for constructor of class FactCache
def test_FactCache():

    def __init__(self, *args, **kwargs):
        super(FactCache, self).__init__(*args, **kwargs)

    assert __init__.__doc__ == FactCache.__init__.__doc__



# Generated at 2022-06-11 18:54:51.747443
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    fact_cache['foo'] = 'bar'
    fact_cache['blah'] = 'mah'
    assert fact_cache['foo'] == 'bar'
    assert fact_cache['blah'] == 'mah'
    assert fact_cache['foo'] != 'mah'

    fact_cache.flush()
    assert not fact_cache.keys()

# Generated at 2022-06-11 18:54:54.570913
# Unit test for constructor of class FactCache
def test_FactCache():
    facts_cache = FactCache()
    assert isinstance(facts_cache, MutableMapping)
    assert isinstance(facts_cache._plugin, MutableMapping)

# Generated at 2022-06-11 18:55:01.407028
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge("key1", {"field1": 1, "field2": 2})
    assert fact_cache["key1"].get("field1") == 1
    assert fact_cache["key1"].get("field2") == 2
    fact_cache.first_order_merge("key1", {"field1": 10, "field2": 20, "field3": 3})
    assert fact_cache["key1"].get("field1") == 10
    assert fact_cache["key1"].get("field2") == 20
    assert fact_cache["key1"].get("field3") == 3

# Generated at 2022-06-11 18:55:04.681953
# Unit test for constructor of class FactCache
def test_FactCache():
    """
    This is used by the following tests to create a new
    FactCache object.

    :return: FactCache
    """
    return FactCache()


# Generated at 2022-06-11 18:55:08.830368
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()

    cache.first_order_merge('my_key', {'a': 1, 'b': 2})
    cache.first_order_merge('my_key', {'c': 3, 'd': 4})

    assert cache['my_key'] == {'a': 1, 'b': 2, 'c': 3, 'd': 4}

# Generated at 2022-06-11 18:55:11.260123
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache.__class__.__name__ == "FactCache"


# Generated at 2022-06-11 18:55:17.825255
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('key', dict(a=1, b=2))
    assert fact_cache.keys() == ['key']
    assert fact_cache['key'] == dict(a=1, b=2)

    fact_cache.first_order_merge('key', dict(b=3, c=4))
    assert fact_cache['key'] == dict(a=1, b=3, c=4)



# Generated at 2022-06-11 18:55:28.945524
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    """
    This test will test update (first_order_merge) operation of FactCache
    In this test, we will try to overwrite the key of FactCache with a new value
    """

    # Itterate over every cache plugin
    for cache_plugin in C.CACHE_PLUGIN_NAMES:
        # Create a FactCache Object
        fc = FactCache()

        # Set cache plugin for this object
        fc._plugin = cache_loader.get(cache_plugin)

        # Set a key in FactCache
        fc["key1"] = value1 = {"key1_1", "key1_2"}

        # Set same key in FactCache
        fc["key1"] = value2 = {"key1_3", "key1_4"}

        # Check if the key is actually updated in cache
        assert fc

# Generated at 2022-06-11 18:55:30.580895
# Unit test for constructor of class FactCache
def test_FactCache():
    c = FactCache()
    assert c._plugin.__class__.__name__ == 'FactCacheModule'



# Generated at 2022-06-11 18:55:41.188147
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.flush()
    # 1. host1 no cache
    # 1.1 host1's value don't include 'ansible_facts'
    key1 = 'host1'
    value1 = {'key1': 'value1'}
    fact_cache.first_order_merge(key1, value1)
    assert fact_cache[key1] == {'key1': 'value1'}
    # 1.2 host1's value include 'ansible_facts'
    key1 = 'host1'
    value1 = {'ansible_facts': {'key1': 'value1'}}
    fact_cache.first_order_merge(key1, value1)
    assert fact_cache[key1] == {'key1': 'value1'}

    #

# Generated at 2022-06-11 18:55:44.289928
# Unit test for constructor of class FactCache
def test_FactCache():

    assert isinstance(FactCache(), FactCache)

# Generated at 2022-06-11 18:55:52.658903
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge("host1", {"ansible_kernel": "Linux"})
    assert "host1" in fact_cache
    assert fact_cache["host1"].get("ansible_kernel") == "Linux"
    fact_cache.first_order_merge("host1", {"ansible_distribution": "CentOS"})
    assert fact_cache["host1"].get("ansible_kernel") == "Linux"
    assert fact_cache["host1"].get("ansible_distribution") == "CentOS"
    fact_cache.flush()
    assert not len(fact_cache)

# Generated at 2022-06-11 18:55:54.840481
# Unit test for constructor of class FactCache
def test_FactCache():
    factcache = FactCache()
    factcache.__init__()


# Generated at 2022-06-11 18:55:56.606838
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert isinstance(cache, FactCache)

# Generated at 2022-06-11 18:55:57.215724
# Unit test for constructor of class FactCache
def test_FactCache():
    f = FactCache()

# Generated at 2022-06-11 18:55:58.955517
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, dict)

# Generated at 2022-06-11 18:56:08.883625
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()

    # non existing host
    cache.first_order_merge(key='myhost', value={'ansible_facts': {'a': 1}})
    assert cache['myhost'] == {'ansible_facts': {'a': 1}}

    # existing host, different value for a key
    cache.first_order_merge(key='myhost', value={'ansible_facts': {'b': 2}})
    assert cache['myhost'] == {'ansible_facts': {'a': 1, 'b': 2}}

    # existing host, same value for a key
    cache.first_order_merge(key='myhost', value={'ansible_facts': {'a': 1}})

# Generated at 2022-06-11 18:56:10.196206
# Unit test for constructor of class FactCache
def test_FactCache():
    factcache = FactCache()
    assert factcache


# Generated at 2022-06-11 18:56:21.433358
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Create a fact cache instance.
    fact_cache = FactCache()
    # Create the key and value to be merged into the fact cache.
    key = 'ansible_local'
    value = {
        "changed": False,
        "module_stderr": "",
        "module_stdout": "",
        "msg": "",
        "rc": 0
    }

# Generated at 2022-06-11 18:56:26.446826
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.module_utils.facts import cache as fact_cache
    
    # Test for constructor with only one argument
    try:
        fact_cache.FactCache()
        assert False
    except TypeError:
        assert True
    except:
        assert False

    # Test for constructor with more than one argument
    try:
        fact_cache.FactCache(1, 2)
        assert False
    except TypeError:
        assert True
    except:
        assert False

# Generated at 2022-06-11 18:56:32.355380
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc != None


# Generated at 2022-06-11 18:56:32.968965
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    print(cache)

# Generated at 2022-06-11 18:56:35.223175
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache(plugin='memory')

    assert cache is not None
    assert hasattr(cache, '_plugin')
    assert cache._plugin is not None


# Generated at 2022-06-11 18:56:42.476500
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc.first_order_merge("host_a", {"key1": "value1", "key2": "value2"})
    assert fc["host_a"] == {"key1": "value1", "key2": "value2"}
    fc.first_order_merge("host_a", {"key1": "value1", "key2": "new_value2"})
    assert fc["host_a"] == {"key1": "value1", "key2": "new_value2"}

# Generated at 2022-06-11 18:56:43.554113
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc.__class__ == FactCache

# Generated at 2022-06-11 18:56:44.365015
# Unit test for constructor of class FactCache
def test_FactCache():
    c = FactCache()
    assert c

# Generated at 2022-06-11 18:56:45.982130
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert('dict' == type(fact_cache).__name__) 


# Generated at 2022-06-11 18:56:55.307852
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()

    top_facts = {"a": "A_VAL", "b":"B_VAL"}
    local_facts = {"c": "C_VAL", "d": "D_VAL"}

    fact_cache.first_order_merge("top", top_facts)
    merged_facts = fact_cache._plugin.get("top")
    assert "A_VAL" == merged_facts["a"]
    assert "B_VAL" == merged_facts["b"]

    fact_cache.first_order_merge("top", local_facts)
    merged_facts = fact_cache._plugin.get("top")
    assert "C_VAL" == merged_facts["c"]
    assert "D_VAL" == merged_facts["d"]

    assert "A_VAL" == merged_facts["a"]

# Generated at 2022-06-11 18:57:04.217247
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    """Test first_order_merge of class FactCache"""

    cache = FactCache()
    assert len(cache) == 0

    host_key_1 = 'testhost1'
    value_1 = {'test_facts': {'testkey1': 'testvalue1', 'testkey2': 'testvalue2'}}
    fact_cache = {host_key_1: value_1}
    cache.update(fact_cache)
    assert len(cache) == 1 and host_key_1 in cache

    key_1 = 'test_facts'
    new_value_1 = {'testkey1': 'testvalue1', 'testkey2': 'testvalue2',
                   'testkey3': 'testvalue3'}
    cache.first_order_merge(host_key_1, new_value_1)
   

# Generated at 2022-06-11 18:57:13.477990
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Create an instance of class FactCache
    fact_cache = FactCache()
    # Create a dictionary as first_order_merge argument
    key = "test_key"
    value = {"a": "dict_a_value", "b": "dict_b_value"}
    fact_cache.first_order_merge(key, value)
    assert isinstance(fact_cache, FactCache)
    assert fact_cache[key] == value
    # Create a string as first_order_merge argument
    value = "test_value"
    fact_cache.first_order_merge(key, value)
    assert fact_cache[key] == value
    # Create a list as first_order_merge argument
    value = ["1", "2", "3"]

# Generated at 2022-06-11 18:57:33.394895
# Unit test for constructor of class FactCache
def test_FactCache():
    example_module = {'module_name': 'facts', 'module_args': {'gather_subset': 'all'}}
    cache = FactCache('example_host')
    cache['example_host'] = {'inventory_hostname': 'example_host', 'ansible_facts': {'ansible_hostname': 'example_host'}, 'all': {'ansible_env': {'HOME': '/home/user'}, 'ansible_python_version': '2.7.5'}, 'changed': False}
    cache.flush()


test_FactCache()

# Generated at 2022-06-11 18:57:41.101916
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Test includes a test case of each possible value in host_cache.
    # The expected result is based on whether the key is already in the
    # cache and whether the value is already in the cache.

    # Test setup
    factcache = FactCache()
    factcache['foo'] = 'bar'
    value = 'baz'
    key = 'foo'
    host_cache = {}

    expected = 'baz'
    result = factcache.first_order_merge(key, value)
    assert result == expected, "Expected: %s, Result: %s" % (expected, result)

    host_cache['baz'] = 'qux'
    expected = 'qux'
    result = factcache.first_order_merge(key, host_cache)

# Generated at 2022-06-11 18:57:43.682319
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()

    assert isinstance(fc, FactCache)

# Generated at 2022-06-11 18:57:53.817475
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    host_facts = {'ansible_facts': {}}
    cached_facts = {'ansible_facts': {'Cached_Facts_1': 'Cache_Value_1'}}
    host_facts['ansible_facts'].update({'Facts_1': 'Value_1'})
    host_facts['ansible_facts'].update({'Facts_2': 'Value_2'})

    host_cache = FactCache()
    host_cache['test_host'] = cached_facts
    host_cache.first_order_merge('test_host', host_facts)

    assert len(host_cache) == 1
    assert host_cache['test_host']['ansible_facts']['Facts_2'] == 'Value_2'

# Generated at 2022-06-11 18:57:55.451225
# Unit test for constructor of class FactCache
def test_FactCache():

    test_cache = FactCache()

    assert test_cache._plugin is not None


# Generated at 2022-06-11 18:57:56.681333
# Unit test for constructor of class FactCache
def test_FactCache():

    cache = FactCache()

    assert isinstance(cache, FactCache)

# Generated at 2022-06-11 18:58:03.144934
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    test_key = 'www.example.com'
    test_dict = dict(foo='bar', ansible_facts=dict(test_key=test_key))

    fact_cache.first_order_merge(test_key, test_dict)
    assert test_key in fact_cache
    assert 'foo' not in fact_cache[test_key]
    assert 'ansible_facts' in fact_cache[test_key]
    assert 'test_key' in fact_cache[test_key]['ansible_facts']
    assert fact_cache[test_key]['ansible_facts']['test_key'] == test_key

    new_dict = dict(foo='bar', ansible_facts=dict(test_key='new.example.com'))

# Generated at 2022-06-11 18:58:10.205241
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    key = 'foo'
    host_facts = {'bar': 'baz'}
    fc.first_order_merge(key, host_facts)
    results = fc[key]
    assert results == {'bar': 'baz'}

    host_facts = {'bar': 'new_baz'}
    fc.first_order_merge(key, host_facts)
    results = fc[key]
    assert results == {'bar': 'new_baz'}

# Generated at 2022-06-11 18:58:11.285290
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)

# Generated at 2022-06-11 18:58:14.193095
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert isinstance(fc, MutableMapping)
    assert fc._plugin

# Generated at 2022-06-11 18:58:45.123172
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    fact_cache = FactCache()
    key = 'test-key'
    value = dict(a=1,  b=2)

    cache_before = fact_cache.copy()
    cache_before.update({key: value})
    fact_cache.first_order_merge(key, value)

    assert fact_cache.copy() == cache_before

# Generated at 2022-06-11 18:58:50.821467
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert hasattr(fact_cache, '__getitem__')
    assert hasattr(fact_cache, '__setitem__')
    assert hasattr(fact_cache, '__delitem__')
    assert hasattr(fact_cache, '__contains__')
    assert hasattr(fact_cache, '__iter__')
    assert hasattr(fact_cache, '__len__')

# Generated at 2022-06-11 18:58:51.673532
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()

# Generated at 2022-06-11 18:58:55.694864
# Unit test for constructor of class FactCache
def test_FactCache():
    factCache = FactCache()
    factCache["hostname"] = "test.ansible.com"
    print(factCache["hostname"])
    factCache2 = factCache.copy()
    for key in factCache2:
        print(key, factCache[key])
    factCache.flush()

# Generated at 2022-06-11 18:59:01.179876
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    """ Test for method first_order_merge of class FactCache """

    class TestCacheLoader(cache_loader.BaseCacheModule):

        """ Test Cache Loader Module """

        def __init__(self):
            self.facts = dict()

        def contains(self, key):
            return key in self.facts

        def delete(self, key):
            del self.facts[key]

        def set(self, key, value):
            self.facts[key] = value

        def get(self, key):
            return self.facts[key]

        def keys(self):
            return self.facts.keys()

        def flush(self):
            self.facts = dict()

    C.CACHE_PLUGIN = 'TestCacheLoader'
    test_fact_cache = FactCache()
    test_fact_cache.first

# Generated at 2022-06-11 18:59:02.989911
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-11 18:59:04.920916
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, MutableMapping)
    assert fact_cache != None

# Generated at 2022-06-11 18:59:05.422961
# Unit test for constructor of class FactCache
def test_FactCache():
    print(FactCache())

# Generated at 2022-06-11 18:59:12.541256
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()

    # Test cases
    # 1. Test with already populated data
    expected_result = {'a': 2, 'b': 1, 'c': 3}
    fc.update({'a': 1, 'b': 1, 'c': 3, 'd': 1})
    fc.first_order_merge('a', 2)
    assert fc['a'] == expected_result['a']
    assert fc['b'] == expected_result['b']
    assert fc['c'] == expected_result['c']

    # 2. Test without data
    expected_result = {'a': 1, 'b': 2}
    fc.first_order_merge('a', 1)
    fc.first_order_merge('b', 2)
    assert fc['a'] == expected

# Generated at 2022-06-11 18:59:22.925338
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import json

    def json_loads(data, **kwargs):
        return json.loads(data, **kwargs)

    fact_cache = FactCache()
    host_fact_file = "tests/integration/targets/fact-cache/host_fact_file.json"
    with open(host_fact_file) as f:
        host_fact = json_loads(f.read())

    fact_cache.first_order_merge('host_fact_file', host_fact)
    assert fact_cache.get('host_fact_file') is not None
    assert fact_cache.get('host_fact_file').get('ansible_facts').get('ansible_local') is not None
    assert fact_cache.get('host_fact_file').get('ansible_facts').get('ansible_local').get

# Generated at 2022-06-11 19:00:21.901191
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.errors import AnsibleError
    from ansible.plugins.loader import cache_loader

    try:
        cache_plugin = cache_loader.get(C.CACHE_PLUGIN)
        fact_cache = FactCache(cache_plugin)
        assert fact_cache is not None
    except AnsibleError as e:
        assert False

# Generated at 2022-06-11 19:00:23.564817
# Unit test for constructor of class FactCache
def test_FactCache():
    fcache = FactCache()
    fcache['data'] = {'a':1, 'b':2}
    assert fcache.keys() == ['data']

# Generated at 2022-06-11 19:00:26.730720
# Unit test for constructor of class FactCache
def test_FactCache():
    '''
    Test the constructor of class FactCache.
    '''
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)


# Generated at 2022-06-11 19:00:31.629543
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    localhost = '127.0.0.1'
    fact_cache = FactCache()
    fact_cache.flush()
    fact_cache.first_order_merge(localhost, {'fact1': 'value1'})
    assert fact_cache.keys() == [u'127.0.0.1']
    assert fact_cache.get(localhost) == {u'fact1': u'value1'}

    # Testing value update
    fact_cache.first_order_merge(localhost, {'fact2': 'value2'})
    assert fact_cache.keys() == [u'127.0.0.1']
    assert fact_cache.get(localhost) == {u'fact2': u'value2', u'fact1': u'value1'}

    # Testing value update for the same key
    fact

# Generated at 2022-06-11 19:00:36.157322
# Unit test for constructor of class FactCache
def test_FactCache():
    # pylint: disable=unused-variable

    display.verbosity = 4
    cache = FactCache()

    key = 'localhost'
    value = {'test_key': 'test_value'}
    cache.first_order_merge(key, value)

    assert cache.get(key).get("test_key") == 'test_value'

# Generated at 2022-06-11 19:00:44.417952
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    facts = FactCache()

    # test1: set facts
    hostname = 'test1'
    host_facts = {'a': 1}
    host_cache = {}

    facts.first_order_merge(hostname, host_facts)
    host_cache = facts._plugin.get(hostname)
    assert host_cache == host_facts

    # test2: update facts
    host_facts = {'a': 2}
    facts.first_order_merge(hostname, host_facts)
    host_cache = facts._plugin.get(hostname)
    assert host_cache == {'a': 2}

    # test3: new facts
    host_facts = {'b': 1}
    facts.first_order_merge(hostname, host_facts)

# Generated at 2022-06-11 19:00:50.915354
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.plugins.cache.jsonfile import CacheModule as jsonfile
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.compat.tests import unittest

    class TestException(Exception):
        pass

    class TestJsonfile(jsonfile):
        def _load(self):
            raise TestException()

        def _dump(self, data):
            raise TestException()

    class TestFactCache(unittest.TestCase):
        def setUp(self):
            self.display = Display()
            self.display.display = self.orig_display

        def test_constructor_exception(self):
            plugin = TestJsonfile()
            with self.assertRaises(TestException):
                FactCache()


# Generated at 2022-06-11 19:00:54.386510
# Unit test for constructor of class FactCache
def test_FactCache():
    # Arrange
    # Act
    fact_cache = FactCache()
    fact_cache["key"] = "value"

    # Assert
    assert fact_cache["key"] == "value"

# Generated at 2022-06-11 19:00:56.621155
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache._plugin
    assert cache.cache

# Generated at 2022-06-11 19:01:04.891525
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    host_facts = {'hostname': 'test_host'}