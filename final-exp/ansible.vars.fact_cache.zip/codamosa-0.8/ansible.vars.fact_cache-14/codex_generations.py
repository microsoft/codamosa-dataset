

# Generated at 2022-06-11 18:52:40.576797
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()

    data = {'ansible_facts': {'fact1': 'value1', 'fact2': 'value2'}}
    data2 = {'ansible_facts': {'fact1': 'value3', 'fact3': 'value4'}}

    cache.first_order_merge('hostname', 'host1')
    cache.first_order_merge('hostname', data['ansible_facts'])
    cache.first_order_merge('hostname', data2['ansible_facts'])

    assert cache['hostname'] == {'fact1': 'value3', 'fact2': 'value2', 'fact3': 'value4'}

    data = {'ansible_facts': 'value1'}
    data2 = {'ansible_facts': 'value3'}

    cache

# Generated at 2022-06-11 18:52:48.080893
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Create a fake fact in cache
    factCache = FactCache()
    factCache["test_key"] = {"test": "value"}

    # Update the fact in cache
    test_value = {"test": "new_value", "test2": "value2"}
    factCache.first_order_merge("test_key", test_value)

    # Check the new value in cache
    cached_value = factCache["test_key"]
    assert cached_value["test"] == "new_value"
    assert cached_value["test2"] == "value2"

    # Flush the cache
    factCache.flush()

# Generated at 2022-06-11 18:52:50.045228
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.cache import FactCache
    fact_cache = FactCache()
    assert len(fact_cache) == 0

# Generated at 2022-06-11 18:52:51.558112
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)
    assert isinstance(fact_cache, MutableMapping)

# Generated at 2022-06-11 18:52:57.494546
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    host_cache = {'a': 1, 'b': 1}
    host_facts = {'a': 1, 'b': 1, 'c': 2}
    fact_cache.first_order_merge(host_cache, host_facts)
    assert fact_cache.keys() == ['a', 'b', 'c']

# Generated at 2022-06-11 18:53:04.330401
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    assert 'test_key' not in cache
    cache.first_order_merge('test_key', {'foo': 'bar'})
    assert 'test_key' in cache
    assert cache['test_key']['foo'] == 'bar'
    cache.first_order_merge('test_key', {'foo': 'baz'})
    assert cache['test_key']['foo'] == 'baz'
    cache.first_order_merge('test_key', {'bar': 'baz'})
    assert 'foo' in cache['test_key']
    assert 'bar' in cache['test_key']
    assert cache['test_key']['bar'] == 'baz'

# Generated at 2022-06-11 18:53:06.686436
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc.first_order_merge("a", {"b": "c"})
    assert fc["a"] == {"b": "c"}
    fc.first_order_merge("a", {"d": "e"})
    assert fc["a"] == {"b": "c", "d": "e"}

# Generated at 2022-06-11 18:53:08.319898
# Unit test for constructor of class FactCache
def test_FactCache():
    temp_fact_cache = FactCache()
    assert temp_fact_cache

# Generated at 2022-06-11 18:53:08.941857
# Unit test for constructor of class FactCache
def test_FactCache():
    pass

# Generated at 2022-06-11 18:53:13.260596
# Unit test for constructor of class FactCache
def test_FactCache():

    assert isinstance(FactCache(), FactCache)

    FactCache().flush()
    assert FactCache() == {}

    assert FactCache().keys() == []

    fact = {"key1": "value1"}
    fact_cache = FactCache()
    fact_cache.update(fact)
    assert fact_cache == fact

    assert fact_cache.keys() == ["key1"]

# Generated at 2022-06-11 18:53:25.082093
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Test 1
    fc = FactCache()
    key = 'test1'
    value = {
        'newkey1': True,
        'newkey2': 'newvalue2',
    }
    expected_host_facts = {
        key: value.copy(),
    }
    fc.first_order_merge(key, value)
    super(FactCache, fc).__setitem__.assert_called_once_with(key, value.copy())

    # Test 2
    fc.reset_mock()
    fc.flush()
    value = {
        'newkey3': 'newvalue3',
        'newkey4': 4,
    }
    expected_host_facts[key].update(value)
    fc.first_order_merge(key, value)

# Generated at 2022-06-11 18:53:26.924414
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert(fact_cache)

# Unit test to check __getitem__()

# Generated at 2022-06-11 18:53:30.851744
# Unit test for constructor of class FactCache
def test_FactCache(): 
    fc = FactCache()
    assert fc._plugin == 'jsonfile'
    try:
        fa = FactCache('a')
    except AnsibleError as e:
        assert str(e) == 'Unable to load the facts cache plugin (jsonfile).'

# Generated at 2022-06-11 18:53:36.751504
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    host_cache = {"expire": 5}
    facts = {"fact1": "value1"}
    fact_cache.first_order_merge("localhost", facts)
    assert fact_cache["localhost"]["fact1"] == "value1"
    fact_cache._plugin.set("localhost", host_cache)
    fact_cache.first_order_merge("localhost", facts)
    assert fact_cache["localhost"]["fact1"] == "value1"

# Generated at 2022-06-11 18:53:44.358195
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import ansible.plugins.cache.jsonfile
    cache_loader.add('jsonfile', ansible.plugins.cache.jsonfile.CacheModule)
    cache_loader.get('jsonfile')
    fact_cache = FactCache()
    key = '127.0.0.1'
    value = {'key': 'value'}
    fact_cache.first_order_merge(key, value)
    assert fact_cache[key] == {'key': 'value'}
    assert key in fact_cache


# Generated at 2022-06-11 18:53:52.925773
# Unit test for constructor of class FactCache
def test_FactCache():
    # Initialize a cache object
    cache = FactCache()

    # Test with invalid cache_plugin
    try:
        cache_loader.cache_plugin = None
        cache1 = FactCache()
        assert False, "Expected cache plugin not found fatal error"
    except AnsibleError:
        pass

    # Test with valid cache_plugin
    cache_plugin = 'jsonfile'
    cache_loader.cache_plugin = cache_plugin
    cache2 = FactCache()

    # Check if cache object is created
    assert type(cache2) is FactCache , "Expected cache object instance"

    # Check if plugin is loaded
    assert cache_loader.get(cache_plugin) is not None, "Expected cache plugin instance"



# Generated at 2022-06-11 18:53:59.361588
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    cache.first_order_merge("localhost", {"ansible_distribution_version": "1", "ansible_distribution": "CentOS"})
    cache.first_order_merge("localhost", {"ansible_distribution_version": "1", "ansible_distribution": "CentOS"})
    cache.first_order_merge("localhost", {"ansible_distribution_version": "2", "ansible_distribution": "CentOS"})
    assert cache["localhost"]["ansible_distribution_version"] == "2"



# Generated at 2022-06-11 18:54:04.184420
# Unit test for constructor of class FactCache
def test_FactCache():
    print("Testing FactCache")
    try:
        fc = FactCache()
        print("\tSuccess")
    except:
        print("\tFailure")
        exit(1)
    return fc


# Generated at 2022-06-11 18:54:12.627395
# Unit test for constructor of class FactCache
def test_FactCache():
    import os
    import shutil
    import tempfile
    import unittest
    class TestFactCache(unittest.TestCase):
        def setUp(self):
            self.directory = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.directory)

        def test_1_setUp(self):
            CACHE_PLUGIN = 'jsonfile'
            CACHE_PLUGIN_CONNECTION = self.directory
            CACHE_PLUGIN_PREFIX = ''
            C.CACHE_PLUGIN_CONNECTION = CACHE_PLUGIN_CONNECTION
            facts_cache = FactCache()
            self.assertTrue(facts_cache)

            C.CACHE_PLUGIN = None
            C.CAC

# Generated at 2022-06-11 18:54:18.705402
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    factcache = FactCache()
    factcache.first_order_merge('host1', {'version': '3.4'})
    assert factcache == {'host1': {'version': '3.4'}}
    factcache.first_order_merge('host1', {'version': '2.4'})
    assert factcache == {'host1': {'version': '3.4'}}

# Generated at 2022-06-11 18:54:26.551462
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    print(cache.keys)
    print(cache.copy)
    print(cache.flush)
    print(cache.first_order_merge)
    print(cache.keys)
    print(len(cache))
    print(cache.keys)


if __name__ == '__main__':
    test_FactCache()

# Generated at 2022-06-11 18:54:28.191968
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc
    # assert fc._plugin.get_options()



# Generated at 2022-06-11 18:54:32.597028
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert isinstance(fc, FactCache)
    assert len(fc) == 0
    assert not fc.keys()
    fc['foo'] = 'bar'
    assert fc['foo'] == 'bar'
    fc.flush()
    assert len(fc) == 0
    assert not fc.keys()

# Generated at 2022-06-11 18:54:33.820848
# Unit test for constructor of class FactCache
def test_FactCache():
    facts_cache = FactCache()
    assert facts_cache is not None
    assert isinstance(facts_cache, FactCache)

# Generated at 2022-06-11 18:54:41.681953
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    print('test_FactCache_first_order_merge')
    fcache = FactCache()
    fcache['key1'] = { 'fact': 'fact1' }
    fcache['key2'] = { 'fact': 'fact2' }

    new_fact = { 'fact': 'newfact1' }
    fcache.first_order_merge('key1', new_fact)
    assert new_fact == fcache['key1']

    fcache.update(key1={ 'fact': 'newfact2'}, key2={ 'fact': 'newfact3'})
    new_fact = { 'fact': 'newfact3' }
    fcache.first_order_merge('key2', new_fact)
    assert new_fact == fcache['key2']

# Generated at 2022-06-11 18:54:42.755353
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache._plugin

# Generated at 2022-06-11 18:54:47.616755
# Unit test for constructor of class FactCache
def test_FactCache():
    cache_plugin = cache_loader.get(C.CACHE_PLUGIN)
    if not cache_plugin:
        raise AnsibleError('Unable to load the facts cache plugin (%s).' % (C.CACHE_PLUGIN))
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)

# Generated at 2022-06-11 18:54:49.394721
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_obj = FactCache()
    assert isinstance(fact_obj,MutableMapping)
    return True


# Generated at 2022-06-11 18:54:50.756997
# Unit test for constructor of class FactCache
def test_FactCache():
    f = FactCache()
    f['key'] = 'value'
    assert f['key'] == 'value'

# Generated at 2022-06-11 18:55:00.079987
# Unit test for constructor of class FactCache
def test_FactCache():
    # Given
    cache = FactCache()

    # When
    cache[u'foo'] = u'bar'

    # Then
    assert cache[u'foo'] == u'bar'
    assert cache.keys() == [u'foo']

    # And When
    cache[u'foo2'] = u'bar2'

    # Then
    assert cache[u'foo2'] == u'bar2'
    assert cache.keys() == [u'foo', u'foo2']

    # And When
    del cache[u'foo2']

    # Then
    assert u'foo2' not in cache
    assert cache.keys() == [u'foo']

    # And Given
    cache.flush()

    # Then
    assert cache.keys() == []

# Generated at 2022-06-11 18:55:10.281723
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    print("=> test_FactCache_first_order_merge() started")
    test_key = 'test'
    fc = FactCache()
    fc.flush()
    # first insert
    value = {'key1': 'val1'}
    fc.first_order_merge(test_key, value)
    assert(fc[test_key] ==  {'key1': 'val1'})
    # second insert new key
    value = {'key2': 'val2'}
    fc.first_order_merge(test_key, value)
    assert(fc[test_key] ==  {'key1': 'val1', 'key2': 'val2'})
    # third insert existing key
    value = {'key1': 'val3'}
    fc.first_order

# Generated at 2022-06-11 18:55:13.121245
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    if not isinstance(fc, FactCache):
        raise AssertionError('Constructor of class FactCache did not return FactCache')


# Generated at 2022-06-11 18:55:20.256054
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    factcache = FactCache()
    key1 = 'localhost'
    value1 = {'ansible_facts': {'random_fact_1': 'return1'}}
    factcache.first_order_merge(key1, value1)
    key2 = 'localhost_1'
    value2 = {'ansible_facts': {'random_fact_2': 'return2'}}
    factcache.first_order_merge(key2, value2)
    factcache.first_order_merge(key1, value2)
    assert factcache[key1] == {'ansible_facts': {'random_fact_1': 'return1', 'random_fact_2': 'return2'}}

# Generated at 2022-06-11 18:55:30.582097
# Unit test for constructor of class FactCache
def test_FactCache():
    def test_init(mocker):
        mocker.patch('ansible.plugins.cache.FactCache.__getitem__', __getitem__)
        mocker.patch('ansible.plugins.cache.FactCache.__setitem__', __setitem__)
        mocker.patch('ansible.plugins.cache.FactCache.__delitem__', __delitem__)
        mocker.patch('ansible.plugins.cache.FactCache.__contains__', __contains__)
        mocker.patch('ansible.plugins.cache.FactCache.__iter__', __iter__)
        mocker.patch('ansible.plugins.cache.FactCache.__len__', __len__)
        mocker.patch('ansible.plugins.cache.FactCache.copy', copy)

# Generated at 2022-06-11 18:55:40.763198
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    host_key = 'host_1'
    host_facts = {'fact1': 'value1', 'fact2': 'value2'}
    fact_cache.first_order_merge(host_key, host_facts)
    assert host_key in fact_cache
    assert fact_cache.__getitem__(host_key).get('fact1') == 'value1'
    assert fact_cache.__getitem__(host_key).get('fact2') == 'value2'
    fact_cache.first_order_merge(host_key, {'fact1': 'new_value1'})
    assert fact_cache.__getitem__(host_key).get('fact1') == 'new_value1'

# Generated at 2022-06-11 18:55:49.919975
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    '''
    FactCache class's first_order_merge method should merge facts in two dicts
    '''
    # create a instance of FactCache
    f = FactCache()
    # the host_facts
    key = 'localhost'
    value = {'fact1': 'value1', 'fact2': 'value2'}
    # the host_cache
    host_cache = {'fact2': 'cache2', 'fact3': 'cache3'}
    # call method first_order_merge
    f.first_order_merge(key, value)
    # merge the dict
    # the dict returned by first_order_merge
    result = {'fact2': 'value2', 'fact3': 'cache3', 'fact1': 'value1'}
    # the dict in cache

# Generated at 2022-06-11 18:55:57.177778
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    cache = FactCache()

    keys = ['a', 'b', 'c', 'd', 'e']
    values = ['1', '2', '3', '4', '5']

    cache.first_order_merge(keys[0], values[0])
    assert cache[keys[0]] == values[0]

    cache.first_order_merge(keys[1], values[1])
    assert cache[keys[1]] == values[1]

    cache.copy()

    cache.first_order_merge(keys[1], values[0])
    assert cache[keys[1]] == values[1]

    cache.first_order_merge(keys[0], values[1])
    assert cache[keys[0]] == values[1]


# Generated at 2022-06-11 18:55:58.916230
# Unit test for constructor of class FactCache
def test_FactCache():

    fact_cache = FactCache()
    assert fact_cache is not None

    assert fact_cache._plugin is not None

# Generated at 2022-06-11 18:56:00.471497
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_obj = FactCache()
    assert fact_obj.__class__ is FactCache

# Generated at 2022-06-11 18:56:02.408278
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert(fact_cache._plugin is not None)

# Generated at 2022-06-11 18:56:21.558795
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Test 1:
    # Test when there is no key in cache.
    cache = FactCache()
    cache.flush()
    key = '127.0.0.1'

# Generated at 2022-06-11 18:56:26.274667
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    cache.first_order_merge('my_key', {'k': 1})
    cache.first_order_merge('my_key', {'k': 2})

    assert cache.get('my_key') == {'k': 2}

    cache.first_order_merge('my_key', {'m': 1})
    assert cache.get('my_key') == {'k': 2, 'm': 1}

# Generated at 2022-06-11 18:56:28.995838
# Unit test for constructor of class FactCache
def test_FactCache():
    class ExampleCachePlugin:
        def contains(self, key):
            return False

    example = ExampleCachePlugin()
    cache = FactCache()
    cache._plugin = example

# Generated at 2022-06-11 18:56:31.761116
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge("host", {"fact_cache_test": "passed"})
    assert fact_cache["host"] == {"fact_cache_test": "passed"}
    fact_cache.first_order_merge("host", {"fact_cache_test": "failed"})
    assert fact_cache["host"] == {"fact_cache_test": "failed"}

# Generated at 2022-06-11 18:56:35.633458
# Unit test for constructor of class FactCache
def test_FactCache():
    fcache = FactCache()
    assert fcache.keys() == []
    fcache['testkey'] = 'testval'
    assert fcache['testkey'] == 'testval'
    assert 'testkey' in fcache
    assert len(fcache) == 1
    del fcache['testkey']
    assert len(fcache) == 0
    fcache.flush()
    assert len(fcache) == 0

# Generated at 2022-06-11 18:56:36.581664
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()

# Generated at 2022-06-11 18:56:39.834258
# Unit test for constructor of class FactCache
def test_FactCache():
    # instantiate display class
    display.verbosity = 0

    try:
        # instantiate class FactCache
        fact_cache = FactCache()
    except Exception as e:
        raise e
    return fact_cache

# Generated at 2022-06-11 18:56:40.673441
# Unit test for constructor of class FactCache
def test_FactCache():
    f = FactCache()
    assert f

# Generated at 2022-06-11 18:56:43.624660
# Unit test for constructor of class FactCache
def test_FactCache():

    # the following line makes this code only run when the
    # Ansible execution environment is being initialized
    if not C.DEFAULT_MODULE_NAME:
        return

    fc = FactCache()
    assert fc

# Generated at 2022-06-11 18:56:45.842657
# Unit test for constructor of class FactCache
def test_FactCache():
    '''
    Unit test to construct class FactCache
    '''
    fact_cache = FactCache()
    assert fact_cache is not None
    assert isinstance(fact_cache, FactCache)



# Generated at 2022-06-11 18:57:15.627450
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    display.verbosity = 1

    fc = FactCache()
    key = 'localhost'
    value = {'foo': 'bar'}
    fact = {'foo': 'bar', 'baz': 'buz'}
    fc[key] = fact

    print(fc[key])

    fc.first_order_merge(key, value)
    print(fc[key])

# Generated at 2022-06-11 18:57:16.766397
# Unit test for constructor of class FactCache
def test_FactCache():
    pass

# Generated at 2022-06-11 18:57:21.030092
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.plugins.cache.redis import CacheModule
    from ansible.plugins.loader import cache_loader
    cache_loader.add("redis", CacheModule)

    fact_cache = FactCache()
    assert "redis" == fact_cache._plugin.get_name()

# Generated at 2022-06-11 18:57:23.465385
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache,MutableMapping)
    assert fact_cache._plugin

# Generated at 2022-06-11 18:57:28.337411
# Unit test for constructor of class FactCache
def test_FactCache():
    # Setup constant values and variables
    CACHE_PLUGIN = C.CACHE_PLUGIN
    display.verbosity = 0

    # test fails
    assert CACHE_PLUGIN == "memory"
    assert display.verbosity == 0

    # test passes
    assert CACHE_PLUGIN == "memory"
    assert display.verbosity == 0

# Generated at 2022-06-11 18:57:38.962658
# Unit test for constructor of class FactCache
def test_FactCache():
    # Dummy module to test init method
    class MyFactCache:
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
        def get(self, *args, **kwargs):
            pass
        def set(self, *args, **kwargs):
            pass
        def contains(self, *args, **kwargs):
            pass
        def keys(self, *args, **kwargs):
            pass
        def delete(self, *args, **kwargs):
            pass

    cache_loader.plugin_dir = '.'

# Generated at 2022-06-11 18:57:48.847183
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    key = '127.0.0.1'
    value = {'test1': {'123.123.123.123': 1}}
    fact_cache.first_order_merge(key=key, value=value)
    value = {'test1': {'111.111.111.111': 1}}
    fact_cache.first_order_merge(key=key, value=value)
    result = fact_cache[key]
    display.display(result)
    assert result['test1']['123.123.123.123'] == 1, 'Should be 1'
    assert result['test1']['111.111.111.111'] == 1, 'Should be 1'

# Generated at 2022-06-11 18:57:59.015597
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    hostvars = {
        'host1': {
            'ansible_facts': {
                'first_fact': 'value-1',
                'second_fact': 'value-2',
                'third_fact': 'value-3',
            },
        },
        'host2': {
            'ansible_facts': {
                'first_fact': 'value-1-2',
                'second_fact': 'value-2-2',
                'third_fact': 'value-3-2',
                'fourth_fact': 'value-4-2',
            },
        },
    }
    hosts_in_batch = ['host1', 'host2']

    # Test stage one, we have fresh facts and should get a fresh cache
    fact_cache = FactCache()


# Generated at 2022-06-11 18:58:01.164081
# Unit test for constructor of class FactCache
def test_FactCache():
    h = FactCache()
    assert isinstance(h, FactCache)

# Generated at 2022-06-11 18:58:06.214494
# Unit test for constructor of class FactCache
def test_FactCache():

    try:
        import __main__  # pylint: disable=import-error,no-name-in-module
    except ImportError:
        import sys
        __main__ = sys.modules['__main__']

    obj_FactCache = FactCache()
    _display = obj_FactCache._display
    print(_display)
    assert "Display" in str(_display)



# Generated at 2022-06-11 18:59:09.814036
# Unit test for constructor of class FactCache
def test_FactCache():
    # Test creation of FactCache object
    test_fch = FactCache()
    assert test_fch is not None
    assert test_fch

    test_key = 'test'
    test_value = {'test': 'test'}
    assert test_key not in test_fch
    test_fch[test_key] = test_value

    assert test_key in test_fch
    assert test_fch[test_key] == test_value

    test_fch.flush()
    assert test_key not in test_fch

    test_host_cache = {'hostname': 'localhost'}
    assert test_key not in test_fch
    test_fch.first_order_merge(test_key, test_host_cache)


# Generated at 2022-06-11 18:59:18.446779
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    hostname = 'test_host'
    facts = {'fact_a': 'val1', 'fact_b': 'val2'}
    fact_cache.first_order_merge(hostname, facts)
    assert fact_cache[hostname] == facts
    new_facts = {'fact_a': 'val3', 'fact_c': 'val4'}
    fact_cache.first_order_merge(hostname, new_facts)
    assert fact_cache[hostname] == {'fact_a': 'val3', 'fact_b': 'val2', 'fact_c': 'val4'}

# Generated at 2022-06-11 18:59:20.506833
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc is not None, 'Unable to create instance of FactCache'

# Generated at 2022-06-11 18:59:27.520808
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    host_cache = {
        'a': 1,
        'b': 2,
        'c': {
            'd': 3
        }
    }

    fact_cache.first_order_merge('test_host', host_cache)
    assert fact_cache['test_host'] == host_cache
    host_cache_new = {
        'a': 2,
        'c': {
            'd': 4
        },
        'e': 5
    }
    fact_cache.first_order_merge('test_host', host_cache_new)
    assert fact_cache['test_host'] == {
        'a': 2,
        'b': 2,
        'c': {
            'd': 4
        },
        'e': 5
    }
   

# Generated at 2022-06-11 18:59:29.962800
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache
    return fact_cache


# Generated at 2022-06-11 18:59:31.286799
# Unit test for constructor of class FactCache
def test_FactCache():
    f = FactCache()
    print(f)



# Generated at 2022-06-11 18:59:32.615249
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)

# Generated at 2022-06-11 18:59:35.385778
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin == fact_cache.__class__.cache_plugin


# Generated at 2022-06-11 18:59:36.473222
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    return fact_cache


# Generated at 2022-06-11 18:59:38.027838
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    return fc

# Generated at 2022-06-11 19:01:31.658246
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()

# Generated at 2022-06-11 19:01:37.557489
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    for key in ["test_a", "test_b", "test_c", "test_d"]:
        assert key not in cache._plugin.dict

    cache.first_order_merge("test_a", {"a": "b"})
    assert cache._plugin.get("test_a") == {"a": "b"}

    cache.first_order_merge("test_b", {"b": "c"})
    assert "test_b" in cache._plugin.dict

    cache.first_order_merge("test_c", {"b": "c"})
    assert cache._plugin.get("test_c") == {"b": "c"}

    cache.first_order_merge("test_d", {"d": "e"})

# Generated at 2022-06-11 19:01:39.653843
# Unit test for constructor of class FactCache
def test_FactCache():

    c = FactCache()

    assert c.__class__.__name__ == 'FactCache'
    assert isinstance(c, MutableMapping)
    assert hasattr(c, '_plugin')

# Generated at 2022-06-11 19:01:43.731209
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache.keys() == None


# Generated at 2022-06-11 19:01:51.524515
# Unit test for constructor of class FactCache
def test_FactCache():
    # Initializes an object of class FactCache
    fact_cache_obj = FactCache()
    # set the value of the key in fact_cache_obj
    fact_cache_obj['test_key'] = 'test_value'
    # tests if the value of the key has been updated in fact_cache_obj
    assert fact_cache_obj['test_key'] == 'test_value'
    # tests if the keys in fact_cache_obj is not empty
    assert fact_cache_obj.keys() is not None
    # tests if the length is not 0
    assert len(fact_cache_obj.keys()) != 0
    # tests if the key was set correctly earlier
    assert 'test_key' in fact_cache_obj
    # tests if the value is correctly returned by get function

# Generated at 2022-06-11 19:01:52.640367
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc


# Generated at 2022-06-11 19:01:54.677924
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin.name == 'jsonfile'

# Generated at 2022-06-11 19:01:56.313131
# Unit test for constructor of class FactCache
def test_FactCache():

    # constructor
    cache = FactCache()
    assert cache


# Generated at 2022-06-11 19:02:06.977906
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    key = 'key'

    value = {'key1': 'value1'}
    value_expected = {'key1': 'value1'}
    f = FactCache()
    f.first_order_merge(key, value)
    assert f[key] == value_expected

    value = {'key2': 'value2'}
    value_expected = {'key1': 'value1', 'key2': 'value2'}
    f.first_order_merge(key, value)
    assert f[key] == value_expected

    value = {'key1': 'value1_modified'}
    value_expected = {'key1': 'value1_modified', 'key2': 'value2'}
    f.first_order_merge(key, value)
    assert f[key] == value

# Generated at 2022-06-11 19:02:07.476390
# Unit test for constructor of class FactCache
def test_FactCache():
    FactCache()