

# Generated at 2022-06-11 18:52:35.291536
# Unit test for constructor of class FactCache
def test_FactCache():
    pass

# Generated at 2022-06-11 18:52:39.386478
# Unit test for constructor of class FactCache
def test_FactCache():
    cache_plugin_obj = cache_loader.get(C.CACHE_PLUGIN)
    cache_obj = FactCache(cache_plugin_obj)
    assert cache_obj is not None, 'FactCache object is None'

# Generated at 2022-06-11 18:52:50.084844
# Unit test for constructor of class FactCache
def test_FactCache():
    import sys
    import os
    import pytest

    tempdir = os.path.join(os.path.dirname(__file__), "tmp")
    if not os.path.exists(tempdir):
        os.makedirs(tempdir)

    cache_plugin = C.CACHE_PLUGIN
    cache_plugin_path = C.CACHE_PLUGIN_CONNECTION
    cache_plugin_timeout = C.CACHE_PLUGIN_TIMEOUT

    C.CACHE_PLUGIN = 'jsonfile'
    C.CACHE_PLUGIN_TIMEOUT = 300
    if sys.version_info >= (3, 0):
        C.CACHE_PLUGIN_CONNECTION = ':memory:'
    else:
        C.CACHE_PLUGIN

# Generated at 2022-06-11 18:52:51.581200
# Unit test for constructor of class FactCache
def test_FactCache():
    cache_loader.get(C.CACHE_PLUGIN)
    cache_loader.get(C.CACHE_PLUGIN)

# Generated at 2022-06-11 18:53:01.785734
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import unittest
    import mock

    class Test_FactCache_first_order_merge(unittest.TestCase):

        def setUp(self):
            self.mock_hostvars_cache = {'host1': {}}
            self.mock_plugin = mock.MagicMock()
            self.mock_plugin.keys.return_value = ['host1', 'host2']
            self.mock_plugin.get.return_value = {'var': 'hoge'}
            self.mock_plugin.contains.return_value = True

        def test_when_key_in_hostvars(self):
            self.mock_hostvars_cache['host1']['var'] = 'hoge'
            fact_cache = FactCache()

# Generated at 2022-06-11 18:53:08.623275
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge("host1", {"ansible_kernel": "Linux"})
    assert fact_cache.get("host1").get("ansible_kernel") == "Linux"
    fact_cache.first_order_merge("host2", {"ansible_kernel": "BSD"})
    assert fact_cache.get("host2").get("ansible_kernel") == "BSD"


# Generated at 2022-06-11 18:53:09.575206
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache=FactCache()


# Generated at 2022-06-11 18:53:12.658973
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache

    empty_plugins = {}
    try:
        fact_cache = FactCache(empty_plugins)
        assert fact_cache
    except KeyError:
        assert True


# Generated at 2022-06-11 18:53:23.599005
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    host_facts = {'hostname': 'localhost1', 'fact': 'myfact1'}
    fact_cache.first_order_merge(host_facts['hostname'], host_facts)
    assert fact_cache[host_facts['hostname']] == host_facts

    host_facts = {'hostname': 'localhost1', 'fact': 'myfact2'}
    fact_cache.first_order_merge(host_facts['hostname'], host_facts)
    assert fact_cache[host_facts['hostname']] != host_facts
    assert fact_cache[host_facts['hostname']]['fact'] == 'myfact1'

    host_facts = {'hostname': 'localhost2', 'fact': 'myfact1'}
    fact_cache.first

# Generated at 2022-06-11 18:53:25.008948
# Unit test for constructor of class FactCache
def test_FactCache():
    display.verbosity = 4
    fc = FactCache()
    assert type(fc) == FactCache

# Generated at 2022-06-11 18:53:31.760576
# Unit test for constructor of class FactCache
def test_FactCache():
    assert hasattr(FactCache(), 'keys')
    assert hasattr(FactCache(), 'first_order_merge')
    assert hasattr(FactCache(), 'flush')

    my_cache = FactCache()
    my_cache['test'] = 'test'
    assert my_cache['test'] == 'test'
    assert len(my_cache) == 1

    assert 'test' in my_cache

# Generated at 2022-06-11 18:53:36.950624
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc.first_order_merge("127.0.0.1", {"ansible_os_family": "RedHat", "ansible_distribution_version": "7.1"})
    fc.first_order_merge("127.0.0.1", {"ansible_os_family": "RedHat", "ansible_distribution_version": "7.2"})
    assert fc["127.0.0.1"]["ansible_distribution_version"] == "7.2"
    fc.flush()

# Generated at 2022-06-11 18:53:46.812285
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch

    with patch.object(cache_loader, 'get', return_value=None) as mock_get:
        with unittest.mock.patch('ansible_collections.notstdlib.moveitallout.plugins.cache.FactCache.__init__', lambda s: None):
            obj = FactCache()
        mock_get.assert_called_with('memory')


# Generated at 2022-06-11 18:53:57.392995
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    facts_cache = FactCache()
    facts_cache.first_order_merge("test_host_1", {"ansible_distribution_version":"14.04"})
    assert "test_host_1" in facts_cache
    assert "ansible_distribution_version" in facts_cache["test_host_1"]

    facts_cache.first_order_merge("test_host_1", {"ansible_uname":"Linux test_host_1 3.13.0-24-generic #46-Ubuntu SMP Thu Apr 10 19:11:08 UTC 2014 x86_64 x86_64 x86_64 GNU/Linux"})
    assert "test_host_1" in facts_cache
    assert "ansible_uname" in facts_cache["test_host_1"]

# Generated at 2022-06-11 18:54:04.272477
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('hostname', {'test': 'test'})
    assert fact_cache['hostname']['test'] == 'test'
    fact_cache.first_order_merge('hostname', {'test': 'test1'})
    assert fact_cache['hostname']['test'] == 'test'

# Generated at 2022-06-11 18:54:05.981974
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    cache_plugin = fact_cache._plugin
    assert cache_plugin is not None

# Generated at 2022-06-11 18:54:08.360594
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.errors import AnsibleError
    try:
        fc = FactCache()
        assert False
    except Exception as e:
        assert isinstance(e, AnsibleError)


# Generated at 2022-06-11 18:54:10.968916
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert type(fc) == FactCache


# Generated at 2022-06-11 18:54:19.645490
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    kwargs = {'host': 'host1'}
    factcache = FactCache(**kwargs)
    factcache.first_order_merge(host='host1', fact='fact1')
    assert factcache['host1']['fact'] == 'fact1'
    factcache.first_order_merge(host='host1', fact='fact2')
    assert factcache['host1']['fact'] == 'fact2'
    factcache.first_order_merge(host='host2', fact='fact3')
    assert factcache['host1']['fact'] == 'fact2'
    assert factcache['host2']['fact'] == 'fact3'

# Generated at 2022-06-11 18:54:25.630589
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.plugins.cache.memory import MemoryCacheModule

    # Test that a successful constructor returns an object with a correct plugin
    cache_plugin = 'memory'
    memory_cache = MemoryCacheModule()
    fact_cache = FactCache()

    assert fact_cache._plugin.__class__.__name__ == memory_cache.__class__.__name__
    assert fact_cache._plugin.file == memory_cache.file

# Generated at 2022-06-11 18:54:35.003923
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    """
    Unit test for method first_order_merge of class FactCache
    """
    fact_cache = FactCache()
    test_key = 'test_key'
    test_value = {'foo': 'bar'}
    fact_cache.first_order_merge(test_key, test_value)
    assert fact_cache[test_key] == test_value
    new_value = {'foo': 'bar', 'baz': 'baz'}
    fact_cache.first_order_merge(test_key, new_value)
    assert fact_cache[test_key] == new_value

# Generated at 2022-06-11 18:54:42.188187
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    fact_cache = FactCache()
    host = "localhost"
    fact_cache.first_order_merge(host, {"ansible_os_family": "Debian"})
    assert fact_cache[host]["ansible_os_family"] == "Debian"

    fact_cache.first_order_merge(host, {"ansible_os_family": "RedHat"})
    assert fact_cache[host]["ansible_os_family"] == "RedHat"

    fact_cache.first_order_merge(host, {"ansible_os_family": "Debian", "foo": "bar"})
    assert fact_cache[host]["ansible_os_family"] == "Debian"
    assert fact_cache[host]["foo"] == "bar"

    fact_cache.flush()

# Generated at 2022-06-11 18:54:50.861428
# Unit test for constructor of class FactCache
def test_FactCache():
    # mock file_name and mtime
    file_name = '/tmp/ansible_test_file.json'
    mtime = '9999999999'

    # create a new instance of FactCache
    factCache = FactCache(file_name, mtime)
    assert factCache

    # confirm contents of the factCache
    factCache.set('ansible', 'awesome')
    assert factCache.get('ansible') == 'awesome'
    assert len(factCache) == 1
    factCache.set('ansible', 'rocks')
    assert len(factCache) == 1
    assert factCache.get('ansible') == 'rocks'
    factCache.delete('ansible')
    assert len(factCache) == 0


# Generated at 2022-06-11 18:55:00.384238
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    hosts = ["a.example.com","b.example.com","c.example.com"]
    keys = ["a", "b", "c"]
    value = {"a": "1", "b": "b", "c": "III"}
    fact_cache = FactCache()
    for host in hosts:
        fact_cache.first_order_merge(host, value)
    for host in hosts:
        assert host in fact_cache
    fact_cache["a.example.com"] = {"a": "1", "b": "b", "c": "III"}
    fact_cache["b.example.com"] = {"a": "1", "b": "b", "c": "III"}
    fact_cache["c.example.com"] = {"a": "1", "b": "b", "c": "III"}


# Generated at 2022-06-11 18:55:02.332833
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc

# Generated at 2022-06-11 18:55:09.505781
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    key = '127.0.0.10'
    value = {'ipv4': {u'address': u'127.0.0.10', u'netmask': u'255.255.255.0', u'network': u'127.0.0.0'}}
    fact_cache.first_order_merge(key, value)
    assert fact_cache['127.0.0.10'] == value

    key = '127.0.0.10'

# Generated at 2022-06-11 18:55:10.206242
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()

# Generated at 2022-06-11 18:55:19.455279
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    from collections import namedtuple
    MockedPlugin = namedtuple('mocked_plugin', ['keys', 'contains', 'get', 'set', 'delete', 'flush'])
    mocked_plugin = MockedPlugin(
        keys=lambda: ['localhost'],
        contains=lambda key: key == 'localhost',
        get=lambda key: {'key': 'value'},
        set=lambda key, value: None,
        delete=lambda key: None,
        flush=lambda: None
    )
    fact_cache = FactCache()
    fact_cache._plugin = mocked_plugin
    ret = fact_cache.first_order_merge('localhost', {'key': 'new_value'})
    assert ret == {'localhost': {'key': 'new_value'}}
    ret = fact_cache.get('localhost')
   

# Generated at 2022-06-11 18:55:23.881515
# Unit test for constructor of class FactCache
def test_FactCache():
    import ansible_collections.ansible.community.plugins.module_utils.facts.cache as cache
    f = cache.FactCache()
    if not isinstance(f, cache.FactCache):
        raise Exception("Failed to instantiate FactCache")



# Generated at 2022-06-11 18:55:25.102917
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache


# Generated at 2022-06-11 18:55:38.772653
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache_key = 'test_key'
    fact_cache_value = {'test_fact_key_0': 0}

    fact_cache.first_order_merge(fact_cache_key, fact_cache_value)

    # Check that the key is present
    assert fact_cache_key in fact_cache

    # Check that the value at key is the same as the value added
    assert fact_cache[fact_cache_key] == fact_cache_value


# Generated at 2022-06-11 18:55:40.134844
# Unit test for constructor of class FactCache
def test_FactCache():
    display.verbosity = 2
    assert FactCache()
    display.verbosity = 0

# Generated at 2022-06-11 18:55:41.618453
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    return fc.__class__.__name__ == 'FactCache'


# Generated at 2022-06-11 18:55:44.045456
# Unit test for constructor of class FactCache
def test_FactCache():

    fact_cache = FactCache()

    assert fact_cache._plugin.__class__.__name__ == C.CACHE_PLUGIN



# Generated at 2022-06-11 18:55:45.601982
# Unit test for constructor of class FactCache
def test_FactCache():
    '''
    This unit test is testing for the constructor of class FactCache
    '''
    pass

# Generated at 2022-06-11 18:55:54.811197
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()

    key = 'localhost'

# Generated at 2022-06-11 18:55:57.725126
# Unit test for constructor of class FactCache
def test_FactCache():
    f = FactCache()


# This is a duplicate of the method in action_plugins/cache.py
# It wont be needed once we move to the plugin system.

# Generated at 2022-06-11 18:56:00.737001
# Unit test for constructor of class FactCache
def test_FactCache():
    # pylint: disable=protected-access
    fact_cache = FactCache()
    assert not fact_cache._plugin is None
    fact_cache.flush()
    assert len(fact_cache) == 0

# Generated at 2022-06-11 18:56:09.799376
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc.first_order_merge("host1", {"var1": "value1"})
    assert "host1" in fc
    assert fc["host1"]["var1"] == "value1"
    fc.first_order_merge("host1", {"var2": "value2"})
    assert "var1" in fc["host1"]
    assert "var2" in fc["host1"]
    assert fc["host1"]["var1"] == "value1"
    assert fc["host1"]["var2"] == "value2"
    fc.first_order_merge("host1", {"var1": "value1-overridden"})
    assert "var1" in fc["host1"]

# Generated at 2022-06-11 18:56:13.660825
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert 'localhost' in fact_cache


# Generated at 2022-06-11 18:56:27.142045
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin

# Generated at 2022-06-11 18:56:28.450234
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache() # noqa

# Generated at 2022-06-11 18:56:31.972503
# Unit test for constructor of class FactCache
def test_FactCache():
    # Load the plugin
    cache_loader.load_plugin('jsonfile')

    temp_config = 2

    # Load the plugin and call the constructor of class FactCache
    FactCache()

    C.CACHE_PLUGIN_TIMEOUT = temp_config


# Generated at 2022-06-11 18:56:33.652323
# Unit test for constructor of class FactCache
def test_FactCache():

    cache = FactCache()

    assert isinstance(cache, FactCache)
    assert isinstance(cache, MutableMapping)



# Generated at 2022-06-11 18:56:34.429181
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache

# Generated at 2022-06-11 18:56:40.844445
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Setup
    C.CACHE_PLUGIN = "jsonfile"
    cache = FactCache()
    cache.flush()
    assert len(cache) == 0
    key = "192.168.0.1"
    value = {"mykey": "myvalue"}

    # When
    cache.first_order_merge(key, value)

    # Then
    assert len(cache) == 1
    assert cache[key] == {"mykey": "myvalue"}



# Generated at 2022-06-11 18:56:42.647420
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache('test')
    assert fact_cache is not None

# Generated at 2022-06-11 18:56:49.079348
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc._plugin = Mock_Cache()
    key = "localhost"
    old_value = {"old_value": "old"}
    new_value = {"new_value": "new"}

    # When the plugin does not return a value, we do not update the cache
    fc._plugin.get.return_value = None
    fc.first_order_merge(key, old_value)
    assert fc._plugin.get.call_count == 1
    assert fc._plugin.set.call_count == 0
    fc._plugin.get.reset_mock()

    # When the plugin return a value, we update the cache
    fc._plugin.get.return_value = old_value
    fc.first_order_merge(key, new_value)
    assert f

# Generated at 2022-06-11 18:56:50.473944
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()

# Generated at 2022-06-11 18:56:59.833591
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    from ansible.plugins.cache.jsonfile import CacheModule as CacheModuleJson
    from ansible.plugins.cache.redis import CacheModule as CacheModuleRedis
    from ansible.plugins.cache.yaml import CacheModule as CacheModuleYaml
    import tempfile
    import shutil

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-11 18:57:24.723910
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    pass

# Generated at 2022-06-11 18:57:25.990229
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert isinstance(cache, FactCache)

# Generated at 2022-06-11 18:57:26.981875
# Unit test for constructor of class FactCache
def test_FactCache():
    c = FactCache()
    assert c

# Generated at 2022-06-11 18:57:30.984587
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache.copy() is not None
    assert fact_cache.keys() is not None
    fact_cache.flush()
    fact_cache.first_order_merge('127.0.0.1', 'test')

# Generated at 2022-06-11 18:57:33.331368
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin

# Generated at 2022-06-11 18:57:36.171848
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.errors import AnsibleError
    from ansible.plugins.loader import cache_loader

    try:
        cache_loader.get(None)
        assert(False), "This should not happen"
    except AnsibleError:
        pass

# Generated at 2022-06-11 18:57:37.981159
# Unit test for constructor of class FactCache
def test_FactCache():
    host_facts = FactCache()
    test = host_facts == host_facts

# Generated at 2022-06-11 18:57:39.023956
# Unit test for constructor of class FactCache
def test_FactCache():
  fact_cache = FactCache()

# Generated at 2022-06-11 18:57:49.463177
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import os
    import shutil
    import tempfile

    dirname = tempfile.mkdtemp()
    tmpfact = os.path.join(dirname, 'ansible_fact_cache.db')

    cls = FactCache()
    cls._plugin = cache_loader.get(C.CACHE_PLUGIN)
    cls._plugin.set_database_path(tmpfact)

    key = 'test_key'
    value = {'foo': 'bar'}

    # merge should work fine if file is not present
    cls.first_order_merge(key, value)
    assert cls[key]['foo'] == 'bar'

    # merge should update existing values
    another_value = {'foo': 'somebar'}

# Generated at 2022-06-11 18:57:52.886420
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        cache = FactCache()
    except Exception as e:
        print('FactCache init error:%s' % str(e))
        assert False
    assert True

# Generated at 2022-06-11 18:58:44.343782
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None


# Generated at 2022-06-11 18:58:45.934907
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    fact_cache['test'] = True
    assert fact_cache['test'] == True

# Generated at 2022-06-11 18:58:56.117158
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    '''
    test_FactCache_first_order_merge checks the merging logic part of the method first_order_merge
    It creates an object for FactCache and calls the method first_order_merge with two values
    This does not check the persistence to cache plugin part of the method
    It is assumed that the caching part will be tested from the underlying cache plugin class
    '''

# Generated at 2022-06-11 18:59:01.357233
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()

    host_cache = {'ec2_metadata': {'placement': {'availability-zone': 'eu-west-1a'}}}

    # Test update of a non existing key
    fact_cache.first_order_merge('FACT_CACHE_TEST_HOST_1', host_cache)
    assert 'ec2_metadata' in fact_cache['FACT_CACHE_TEST_HOST_1']

    # Test update of an existing key
    fact_cache.first_order_merge('FACT_CACHE_TEST_HOST_1', host_cache)

# Generated at 2022-06-11 18:59:03.959948
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin
    assert fact_cache._plugin.cache_type() == "memory"

# Generated at 2022-06-11 18:59:11.723558
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc._plugin = {}

    first_result = {'ipv4': {'address': '10.0.0.1'}}
    fc.first_order_merge('localhost', {'ipv4': {'address': '10.0.0.1'}})
    assert fc == first_result

    second_result = {'ipv4': {'address': '10.0.0.1', 'network': '10.0.0.0'}}
    fc.first_order_merge('localhost', {'ipv4': {'network': '10.0.0.0'}})
    assert fc == second_result


# Generated at 2022-06-11 18:59:12.840513
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()

    assert isinstance(cache, MutableMapping) is True

# Generated at 2022-06-11 18:59:21.766265
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible_collections.ansible.community.plugins.cache import MemoryFactCache
    from ansible_collections.ansible.community.plugins.cache import PickleFactCache
    from ansible_collections.ansible.community.plugins.cache import YamlFactCache

    fact_cache = FactCache()

    assert (fact_cache._plugin.__class__ == MemoryFactCache)

    C.CACHE_PLUGIN = 'picklefile'
    fact_cache = FactCache()

    assert (fact_cache._plugin.__class__ == PickleFactCache or fact_cache._plugin.__class__ == YamlFactCache)

# Generated at 2022-06-11 18:59:22.857536
# Unit test for constructor of class FactCache
def test_FactCache():
    a = FactCache()
    assert a
    return a


# Generated at 2022-06-11 18:59:28.785371
# Unit test for constructor of class FactCache
def test_FactCache():
    print('\n*****UNIT TEST FOR FactCache.py*****\n')

    try:
        # 'ansible_fact_cache' is the key in memory.
        # 'ansible_facts' is the key in the file.
        fc = FactCache('ansible_facts', 'test/test_FactCache.yml')
        assert isinstance(fc, FactCache)
        assert isinstance(fc, MutableMapping)
    except KeyError:
        print('KeyError')

    # FactCache.__setitem__
    fc.__setitem__('sun', 'red')
    assert fc.__getitem__('sun') == 'red'

    # FactCache.__delitem__
    fc.__delitem__('sun')

# Generated at 2022-06-11 19:01:17.898877
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    print(fc)
    assert fc is not None

# Generated at 2022-06-11 19:01:28.801419
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    from ansible.cache import FactCache
    from ansible.template import Templar
    fact_cache = FactCache()

    host = 'test_host'
    test_key = 'test_key'
    test_value = 'test_value'
    templar = Templar()
    templar.set_available_variables({'inventory_hostname': host, 'inventory_hostname_short': host})
    fact_cache.first_order_merge(host, {})
    # assert cache does not contain the key
    assert test_key not in fact_cache
    # call _fact_cache_first_order_merge with a single key value pair
    fact_cache.first_order_merge('{{ inventory_hostname }}', {test_key: test_value})
    # assert cache contains the key
    assert test_key

# Generated at 2022-06-11 19:01:36.150281
# Unit test for constructor of class FactCache
def test_FactCache():
    factcache = FactCache(test='test')
    factcache['test'] = 'test'
    assert factcache['test'] == 'test'
    assert factcache.__getitem__('test') == 'test'
    factcache.__setitem__('test2', 'test2')
    assert factcache['test2'] == 'test2'
    factcache.__delitem__('test2')
    with pytest.raises(KeyError): assert factcache['test2']
    assert factcache.__contains__('test') is True
    assert factcache.__contains__('test2') is False
    assert factcache.copy() == {'test': 'test'}
    assert factcache.keys() == ['test']
    factcache.flush()
    assert factcache.__contains__('test') is False

# Generated at 2022-06-11 19:01:37.245781
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert isinstance(fact_cache, FactCache)


# Generated at 2022-06-11 19:01:44.872727
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    facts_cache = FactCache(None, None)
    facts_cache.first_order_merge('127.0.0.1', {'test': 'works!'})
    assert facts_cache['127.0.0.1'] == {'test': 'works!'}
    facts_cache.first_order_merge('127.0.0.1', {'test': 'runs'})
    assert facts_cache['127.0.0.1'] == {'test': 'runs'}

# Generated at 2022-06-11 19:01:45.861498
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-11 19:01:53.059990
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.errors import AnsibleError
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.plugins.loader import cache_loader
    from ansible.utils.display import Display
    display = Display()

    def test_init():
        fact_cache = FactCache()
        assert isinstance(fact_cache, MutableMapping)
        
    def test_init_with_args():
        fact_cache = FactCache(hostname='localhost', a=1, b=2)
        assert fact_cache.keys() == ['hostname']
        assert fact_cache['hostname'] == 'localhost'

    def test_init_with_kwargs():
        fact_cache = FactCache(hostname='localhost', a=1, b=2)
        assert fact_cache.keys()

# Generated at 2022-06-11 19:02:03.279465
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    import unittest

    import ansible
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.plugins.loader import cache_loader

    class Test(unittest.TestCase):

        def test_first_order_merge(self):

            cache_plugin = cache_loader.get('memory')
            fact_cache = FactCache()
            fact_cache._plugin = cache_plugin
            key = '127.0.0.1'
            value = {'fact1': 'val1', 'fact2': {'fact2a': 'val2a'}}
            fact_cache.first_order_merge(key, value)
            assert fact_cache[key]['fact1'] == 'val1'

# Generated at 2022-06-11 19:02:09.213872
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.plugins.cache.jsonfile import CacheModule as jsonfile
    C.CACHE_PLUGIN = 'jsonfile'
    # Case1: cache plugin is loaded successfully
    fact_cache = FactCache()
    assert isinstance(fact_cache._plugin, jsonfile)
    # Case2: cache plugin is not loaded successfully
    C.CACHE_PLUGIN = 'NoPlugin'
    try:
        fact_cache = FactCache()
        assert False
    except AnsibleError:
        assert True

# Generated at 2022-06-11 19:02:19.630248
# Unit test for constructor of class FactCache
def test_FactCache():
    import os
    from ansible.config.manager import ConfigManager

    env = {
        'ANSIBLE_CACHE_PLUGIN': 'jsonfile',
        'ANSIBLE_CACHE_PLUGIN_CONNECTION': 'tests/output/ansible_test.cache',
        'ANSIBLE_LOCALHOST_WARNING': 'False'
    }

    config_manager = ConfigManager()
    config_manager.load_config_file()
    config_manager.update_config(env)

    cache = FactCache()

    assert os.path.exists('tests/output/ansible_test.cache')

    # On every object creation the cache is flushed by default
    assert not cache.keys()

    # Test for non-existent key
    assert 'unittest_key' not in cache

    # Test for setitem()