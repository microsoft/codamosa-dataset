

# Generated at 2022-06-11 18:52:38.576951
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    _plugin = cache_loader.get(C.CACHE_PLUGIN)
    if not _plugin:
        raise AnsibleError(
            'Unable to load the facts cache plugin (%s).' % (C.CACHE_PLUGIN))

    _plugin.set('192.168.1.1', {'new_cache1': 'new_cache1', 'new_cache2': 'new_cache2'})
    _plugin.set('192.168.1.2', {'new_cache1': 'new_cache1', 'new_cache2': 'new_cache2'})
    _plugin.set('192.168.1.3', {'new_cache1': 'new_cache1', 'new_cache2': 'new_cache2'})

    fc = FactCache()
    fc.first_

# Generated at 2022-06-11 18:52:49.769488
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()

    # If the cache is empty and key is not present then update the cache with new value
    assert len(fact_cache) == 0
    fact_cache.first_order_merge("key", "value")
    assert len(fact_cache) == 1 and fact_cache["key"] == "value"

    # If the cache is not empty and key is present then update the value of the key in cache
    # with new value
    fact_cache.first_order_merge("key", "value1")
    assert len(fact_cache) == 1 and fact_cache["key"] == "value1"

    # If the cache is not empty and key is not present then update the cache with new value
    fact_cache.first_order_merge("key1", "value2")
    assert len(fact_cache)

# Generated at 2022-06-11 18:52:54.233637
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    test_cache = {}

    test = FactCache()
    test_key = "test_key"
    test_value = "test_value"
    test["test_key"] = test_cache
    test.first_order_merge(test_key, test_value)
    assert test_value == test[test_key]

# Generated at 2022-06-11 18:53:03.514503
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None
    assert fact_cache._plugin is not None
    assert fact_cache._plugin.contains("some_key") == False
    with pytest.raises(KeyError):
        fact_cache["some_key"]
    fact_cache["some_key"] = "some_value"
    assert fact_cache._plugin.contains("some_key") == True
    assert fact_cache["some_key"] == "some_value"
    assert fact_cache.keys() == ["some_key"]
    assert fact_cache.copy() == {"some_key":"some_value"}
    assert len(fact_cache) == 1
    fact_cache["some_other_key"] = "some_other_value"

# Generated at 2022-06-11 18:53:13.501068
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    facts_cache = FactCache()

    facts_cache.first_order_merge('localhost', {'ansible_kernel': 'Linux', 'ansible_processor': ['Intel', 'AMD']})
    assert facts_cache.get('localhost') == {'ansible_kernel': 'Linux', 'ansible_processor': ['Intel', 'AMD']}

    # test basic key update
    facts_cache.first_order_merge('localhost', {'ansible_processor': ['Intel']})
    assert facts_cache.get('localhost') == {'ansible_kernel': 'Linux', 'ansible_processor': ['Intel']}

    # test cache update
    facts_cache.first_order_merge('localhost', {'ansible_processor': ['Intel', 'AMD']})

# Generated at 2022-06-11 18:53:14.262134
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()

# Generated at 2022-06-11 18:53:24.935355
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    class DummyPlugin:

        def __init__(self):
            self.cache = {}

        def get(self, key):
            return self.cache[key]

        def contains(self, key):
            return self.cache.has_key(key)

        def set(self, key, value):
            self.cache[key] = value

        def flush(self):
            self.cache = {}

        def delete(self, key):
            del self.cache[key]

        def keys(self):
            return self.cache.keys()

    fac = FactCache(plugin=DummyPlugin())

    # test initial cache empty
    assert len(fac.keys()) == 0

    # add facts to cache
    fac.first_order_merge(key="host1", value={"fact1": "value1"})

# Generated at 2022-06-11 18:53:34.593167
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    facts = { "kernel": "Linux" }
    host = "test_host_aa"

    fact_cache = FactCache()
    fact_cache.first_order_merge(host, facts)

    assert(fact_cache["test_host_aa"]["kernel"])
    assert(fact_cache["test_host_aa"]["kernel"] == "Linux")

    # test if no host facts are not cached
    host = "test_host_bb"
    host_facts = None
    fact_cache.first_order_merge(host, host_facts)
    assert(host in fact_cache)

    host_facts = {}
    fact_cache.first_order_merge(host, host_facts)
    assert(host in fact_cache)

# Generated at 2022-06-11 18:53:39.532867
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('ip', '10.0.0.1')
    fact_cache.first_order_merge('key', 'value')

    assert fact_cache.keys() == ['ip', 'key']
    assert fact_cache['ip'] == '10.0.0.1'
    assert fact_cache['key'] == 'value'

    # Set the same key and check if it updates the value
    fact_cache.first_order_merge('key', 'new_value')
    assert fact_cache['key'] == 'new_value'

# Generated at 2022-06-11 18:53:47.834348
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    key = '127.0.0.1'
    value = {'ansible_facts':{'some_fact': 'some_fact_value'}}
    fact_cache.first_order_merge(key,value)
    assert fact_cache[key]['ansible_facts']['some_fact'] == 'some_fact_value'
    value = {'ansible_facts':{'some_other_fact': 'some_other_fact_value'}}
    fact_cache.first_order_merge(key,value)
    assert fact_cache[key]['ansible_facts']['some_fact'] == 'some_fact_value'

# Generated at 2022-06-11 18:53:59.190480
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    cache_mock = MockFactCache()
    fact_cache = FactCache()
    cache_loader.cache_plugin = cache_mock

    # test creating a new element into the cache
    fact_cache.first_order_merge('localhost', {'test1_key': 'test1_value'})
    assert cache_mock.cache_contains_key('localhost')
    assert cache_mock.cache['localhost'] == {'test1_key': 'test1_value'}

    # test updating a cache key
    fact_cache.first_order_merge('localhost', {'test2_key': 'test2_value'})
    assert cache_mock.cache_contains_key('localhost')

# Generated at 2022-06-11 18:54:00.826175
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    if not cache:
        raise AssertionError("unable to create a valid instance of Cache")

# Generated at 2022-06-11 18:54:07.993114
# Unit test for constructor of class FactCache
def test_FactCache():
    # AnsibleError expected
    try:
        facts_cache = FactCache()
    except AnsibleError as e:
        assert type(e) == AnsibleError

    # Assign another cache plugin
    C.CACHE_PLUGIN = 'memory'
    facts_cache = FactCache()
    # Assert instance is created successfully
    assert type(facts_cache) == FactCache

    # Test call the flush method
    facts_cache.flush()


# Generated at 2022-06-11 18:54:11.003958
# Unit test for constructor of class FactCache
def test_FactCache():
    test_fact_cache = FactCache()
    assert isinstance(test_fact_cache, FactCache)


# Generated at 2022-06-11 18:54:12.151035
# Unit test for constructor of class FactCache
def test_FactCache():
    try:
        FactCache()
    except:
        assert False
    assert True

# Generated at 2022-06-11 18:54:12.808900
# Unit test for constructor of class FactCache
def test_FactCache():
    f = FactCache()

# Generated at 2022-06-11 18:54:18.151929
# Unit test for constructor of class FactCache
def test_FactCache():
    cache=FactCache()
    assert cache._plugin.name() =='yaml'
    assert cache._plugin.get_options() =={'fact_caching_timeout': 3600, 'fact_caching': 'yaml', 'fact_caching_connection': '', 'fact_caching_prefix': 'fact_'}

# Generated at 2022-06-11 18:54:28.197300
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    import pytest

    class MockCache:

        def __init__(self):
            self.facts = {}

        def set(self, key, value):
            self.facts[key] = value

        def get(self, key):
            return self.facts[key]

        def keys(self):
            return self.facts.keys()

        def contains(self, key):
            return key in self.facts.keys()

        def flush(self):
            self.facts = {}

    mock_cache = MockCache()
    host = 'localhost'
    cached_facts = {'host': {host: 'value1'}}

    # Cached facts already exists
    mock_cache.facts = cached_facts
    fact_cache = FactCache(mock_cache)

# Generated at 2022-06-11 18:54:36.582716
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
        key = '1.2.3.4'
        value = {'fact1': 'value1', 'fact2': 'value2'}
        display.display('Before updating key ' + key + ': ' + str(value), color='blue')
        fact_cache = FactCache()
        fact_cache.first_order_merge(key, value)
        host_cache = fact_cache[key]
        display.display('After updating key ' + key + ': ' + str(host_cache), color='blue')
        # Second time, key already exists, so fact cache is updated
        value2 = {'fact1': 'value2', 'fact3': 'value3'}
        display.display('Before updating key ' + key + ': ' + str(value2), color='blue')
        fact_cache.first_order_mer

# Generated at 2022-06-11 18:54:37.733942
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin is not None

# Generated at 2022-06-11 18:54:50.828152
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import pytest

    # Test for case where the cache entry is not present
    fact_cache = FactCache()
    key = 'key'
    value = {key: 'value'}
    expected = {key: {key: 'value'}}
    fact_cache.first_order_merge(key, value)
    assert fact_cache._plugin._cache == expected

    # Test for case where the cache entry is present
    value = {key: 'new_value'}
    expected[key] = {key: 'new_value'}
    fact_cache.first_order_merge(key, value)
    assert fact_cache._plugin._cache == expected

    # Test for case where another key is present
    key2 = 'key2'
    value = {key2: 'value2'}

# Generated at 2022-06-11 18:54:52.302141
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache, "Constructor of fact cache failed"

# Generated at 2022-06-11 18:54:57.843558
# Unit test for constructor of class FactCache
def test_FactCache():
    from ansible.cache import CacheModule
    from ansible.cache.memory import FactCache
    from ansible.module_utils.common._collections_compat import Mapping, MutableMapping
    f = FactCache()
    assert isinstance(f, FactCache)
    assert isinstance(f, CacheModule)
    assert isinstance(f, MutableMapping)

# Generated at 2022-06-11 18:55:00.173695
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    plugin= {}
    fc = FactCache()
    fc._plugin= plugin
    key= "mykey"
    value= "myvalue"
    fc.first_order_merge(key, value)
    plugin[key] = value
    assert fc[key] == value

# Generated at 2022-06-11 18:55:01.838934
# Unit test for constructor of class FactCache
def test_FactCache():
    x = FactCache()
    print(x)

# Generated at 2022-06-11 18:55:03.288822
# Unit test for constructor of class FactCache
def test_FactCache():
    facts = FactCache()
    assert isinstance(facts, FactCache)



# Generated at 2022-06-11 18:55:09.942775
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('key1', 'value1')
    fact_cache.first_order_merge('key2', 'value2')
    fact_cache.first_order_merge('key3', {'k3.1': 'v3.1'})
    assert fact_cache['key1'] == 'value1'
    assert fact_cache['key2'] == 'value2'
    assert len(fact_cache['key3']) == 1
    assert fact_cache['key3']['k3.1'] == 'v3.1'

    fact_cache['key1'] = 'value1'
    fact_cache.first_order_merge('key1', 'value2')
    assert fact_cache['key1'] == 'value2'

    fact

# Generated at 2022-06-11 18:55:16.800735
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    test_cache = {'test_host': {'test_var': 'old_value'}}
    test_facts = {'test_host': {'test_var': 'new_value'}}
    test_cache_obj = FactCache(test_cache)
    test_cache_obj.first_order_merge('test_host', test_facts['test_host'])
    assert test_cache_obj['test_host']['test_var'] == 'new_value'

# Generated at 2022-06-11 18:55:18.175098
# Unit test for constructor of class FactCache
def test_FactCache():
    f = FactCache()
    assert isinstance(f, FactCache)
    assert isinstance(f, MutableMapping)

# Generated at 2022-06-11 18:55:20.668074
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert(cache._plugin.__class__.__name__ == 'FactCachePlugin')
    cache.flush()



# Generated at 2022-06-11 18:55:28.823619
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache
    assert not fact_cache.keys()

# Generated at 2022-06-11 18:55:34.781155
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache._plugin = MemoryCache()
    fact_cache.first_order_merge('hostname', {'hostname': 'host1'})
    assert fact_cache._plugin.get('hostname') == {'hostname': 'host1'}
    fact_cache.first_order_merge('hostname', {'other_fact': 'other_fact_value'})
    assert fact_cache._plugin.get('hostname') == {'hostname': 'host1', 'other_fact': 'other_fact_value'}
    fact_cache.first_order_merge('hostname2', {'hostname': 'host2'})
    assert fact_cache._plugin.get('hostname2') == {'hostname': 'host2'}

# Generated at 2022-06-11 18:55:36.299610
# Unit test for constructor of class FactCache
def test_FactCache():
    import pytest
    with pytest.raises(AnsibleError):
        FactCache()

# Generated at 2022-06-11 18:55:46.106133
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import json
    import os
    import sys
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    prefix = "cache"
    infile = tempfile.NamedTemporaryFile(dir=tmpdir, prefix=prefix, delete=False)
    outfile = tempfile.NamedTemporaryFile(dir=tmpdir, prefix=prefix, delete=False)

    # Initialize the environment
    current_dir = os.path.dirname(os.path.realpath(os.path.join(__file__, os.pardir)))
    sys.path.insert(1, os.path.dirname(current_dir))
    C.CACHE_PLUGIN = "jsonfile"
    C.CACHE_PLUGIN_CONN

# Generated at 2022-06-11 18:55:55.237061
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    import mock
    import os
    import stat

    from ansible.errors import AnsibleError
    from ansible.module_utils.facts.cache import FactCache
    from ansible.plugins.loader import cache_loader

    mock_plugin = mock.MagicMock()
    mock_plugin.contains.side_effect = [False, True]
    mock_plugin.get.side_effect = [AnsibleError, {'sample': 'value'}]

    cache_loader.get = mock.MagicMock()
    cache_loader.get.return_value = mock_plugin

    cache = FactCache()
    cache.first_order_merge('hostname', 'hostname.sample')
    assert cache.__getitem__('hostname') == 'hostname.sample'

    cache = FactCache()
    cache.first_order_

# Generated at 2022-06-11 18:55:56.647726
# Unit test for constructor of class FactCache
def test_FactCache():
    result = FactCache()
    assert result

# Generated at 2022-06-11 18:56:07.280921
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()

    # case 1
    result = {
        "ansible_processor_cores": 4,
        "ansible_processor_vcpus": 4,
        "ansible_processor_threads_per_core": 4,
        "ansible_processor_count": 4,
        "ansible_processor": "ARMv8 Processor rev 1 (v8l)"
    }
    value = {
        "ansible_processor_cores": 4,
        "ansible_processor_vcpus": 4,
        "ansible_processor_threads_per_core": 4,
        "ansible_processor_count": 4,
        "ansible_processor": "ARMv8 Processor rev 1 (v8l)"
    }

# Generated at 2022-06-11 18:56:07.989670
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()

# Generated at 2022-06-11 18:56:08.690260
# Unit test for constructor of class FactCache
def test_FactCache():
    factcache = FactCache()
    print(factcache)

# Generated at 2022-06-11 18:56:19.754245
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    # Test first_order_merge() with None as key
    fact_cache = FactCache()
    host_a_facts = {'a':1, 'b':2}
    fact_cache.first_order_merge(None, host_a_facts)
    assert host_a_facts == fact_cache.get(None)

    # Test first_order_merge() with key as None
    fact_cache = FactCache()
    host_b_facts = {'c':3, 'd':4}
    fact_cache.first_order_merge('host_b', None)
    assert fact_cache.first_order_merge('host_b', host_b_facts) == fact_cache.get('host_b')

    # Test first_order_merge() happy path
    fact_cache = FactCache()

# Generated at 2022-06-11 18:56:33.414149
# Unit test for constructor of class FactCache
def test_FactCache():
    assert FactCache()

# Generated at 2022-06-11 18:56:33.870974
# Unit test for constructor of class FactCache
def test_FactCache():
    f = FactCache()

# Generated at 2022-06-11 18:56:37.025236
# Unit test for constructor of class FactCache
def test_FactCache():
    import ansible.plugins
    cache_plugin = ansible.plugins.lookup.get_cache_plugin()
    test_fact_cache = FactCache()
    assert test_fact_cache._plugin == cache_plugin

# Generated at 2022-06-11 18:56:38.259147
# Unit test for constructor of class FactCache
def test_FactCache():
    assert FactCache(), "Something went wrong !"

# Generated at 2022-06-11 18:56:39.834602
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache is not None

# Generated at 2022-06-11 18:56:47.687780
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    host_facts = dict(
        ansible_all_ipv4_addresses=['10.0.0.1', '10.0.0.2'],
        ansible_all_ipv6_addresses=['dead:beef::1', 'dead:beef::2'],
    )
    host_facts_cache = dict(
        ansible_all_ipv4_addresses=['10.0.0.3'],
        ansible_all_ipv6_addresses=['dead:beef::3'],
    )

# Generated at 2022-06-11 18:56:56.343603
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    class testplugin(object):
        def get(self, key):
            return {'test_key': {'test_sub_key': 'test_sub_value'}}
        def set(self, key, value):
            pass

    fc = FactCache()
    fc._plugin = testplugin()
    new_value = {'test_key': { 'test_sub_key2': 'test_sub_value2' }}
    fc.first_order_merge('test_host', new_value)
    assert fc['test_host']['test_key']['test_sub_key'] == 'test_sub_value'
    assert fc['test_host']['test_key']['test_sub_key2'] == 'test_sub_value2'

# Generated at 2022-06-11 18:57:05.075004
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    # Create an instance of FactCache and a mock instance of the Config class
    fact_cache = FactCache()
    config = type('Config', (object,), {})()

    # Set the config.namespace to the current namespace, otherwise AnsibleError will be raised
    # when calling fact_cache.__init__
    config.namespace = __name__

    # Create some variables to be merged with
    key = 'key'
    old_value = {'old_value': 'old_value'}
    new_value = {'new_value': 'new_value'}

    # Set the key of the dictionary to the old value
    fact_cache[key] = old_value
    # Merge the new value with the old value
    fact_cache.first_order_merge(key, new_value)

    # Assert that the new

# Generated at 2022-06-11 18:57:06.445615
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    if not cache:
        cache.flush()
    return cache

# Generated at 2022-06-11 18:57:12.605872
# Unit test for constructor of class FactCache
def test_FactCache():
    model_cache = FactCache()
    # the class does not have a __last_read and a __last_write attribute
    assert not hasattr(model_cache, '__last_read')
    assert not hasattr(model_cache, '__last_write')

    # the class does not have a _plugin attribute
    assert not hasattr(model_cache, '_plugin')

    # the class does not have a has_expired method
    assert not hasattr(model_cache, 'has_expired')

# Generated at 2022-06-11 18:57:49.216811
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.flush()

    # Case 1: Cache doesn't exist
    sys_hostname = 'host1.example.com'
    fact_cache.first_order_merge(sys_hostname, dict(a='b'))
    assert fact_cache.get(sys_hostname) == dict(a='b')

    # Case 2: Cache exists
    fact_cache.first_order_merge(sys_hostname, dict(a='c', d='e'))
    assert fact_cache.get(sys_hostname) == dict(a='c', d='e')

    # Case 3: Cache exists, but is empty
    fact_cache.flush()
    fact_cache[sys_hostname] = dict()

# Generated at 2022-06-11 18:57:50.646177
# Unit test for constructor of class FactCache
def test_FactCache():
    # Test constructor
    fact_cache = FactCache()
    assert fact_cache

# Generated at 2022-06-11 18:57:55.563773
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    print(" fact cache is---->", fact_cache)
    try:
        assert fact_cache is not None
        print("FactCache('test') pass!")
    except Exception as e:
        print("FactCache('test') fail!")
        print(e)


FACT_CACHE = FactCache()

# Generated at 2022-06-11 18:57:56.190124
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()

# Generated at 2022-06-11 18:58:02.811359
# Unit test for constructor of class FactCache
def test_FactCache():
    """ Unit testing for constructors of class FactCache"""
    class FakePlugin:
        def __init__(self, plugin_name):
            self.plugin_name = plugin_name

        def contains(self, cache_key):
            return True

        def get(self, cache_key):
            return {}

        def delete(self, cache_key):
            pass

        def keys(self):
            return ['ansible_facts']

        def flush(self):
            pass

        def set(self, cache_key, cache_data):
            pass

    # test for __init__
    fp = FakePlugin('FakePlugin')
    cache_loader.set(fp.plugin_name, fp)
    fac = FactCache()

    # test for __setitem__ and __getitem__
    fac['Test'] = 'Test'
   

# Generated at 2022-06-11 18:58:03.680558
# Unit test for constructor of class FactCache
def test_FactCache():
    f = FactCache()
    assert True

# Generated at 2022-06-11 18:58:06.074365
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    c = FactCache()
    assert c.first_order_merge('a', {'b': 1}) == {'a': {'b': 1}}

# Generated at 2022-06-11 18:58:13.216789
# Unit test for constructor of class FactCache
def test_FactCache():
    a = FactCache()
    assert a.__class__.__name__ == 'FactCache', "FactCache is a class"
    assert isinstance(a, FactCache), "a is an instance of class FactCache"
    assert isinstance(a, MutableMapping), "a is an instance of class MutableMapping"
    assert a._plugin.__class__.__name__ == 'CachePlugins', "FactCache._plugin is a CachePlugins"

if __name__ == '__main__':
    test_FactCache()

# Generated at 2022-06-11 18:58:19.988601
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fact_cache = FactCache()
    fact_cache.first_order_merge('1.1.1.1', {'a': 'test'})
    assert fact_cache['1.1.1.1'] == {'a': 'test'}
    fact_cache.first_order_merge('1.1.1.1', {'b': 'test'})
    assert fact_cache['1.1.1.1'] == {'a': 'test', 'b': 'test'}
    fact_cache.first_order_merge('1.1.1.1', {'a': 'test2'})
    assert fact_cache['1.1.1.1'] == {'a': 'test2', 'b': 'test'}

# Generated at 2022-06-11 18:58:21.798707
# Unit test for constructor of class FactCache
def test_FactCache():

    fact_cache = FactCache()
    assert fact_cache != None

# Generated at 2022-06-11 18:59:18.551203
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache._plugin

# Generated at 2022-06-11 18:59:19.105765
# Unit test for constructor of class FactCache
def test_FactCache():
    f = FactCache()

# Generated at 2022-06-11 18:59:21.153912
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert cache
    assert dict(cache) == {}



# Generated at 2022-06-11 18:59:22.114952
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache

# Generated at 2022-06-11 18:59:23.277690
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    assert fact_cache != None

# Generated at 2022-06-11 18:59:25.429752
# Unit test for constructor of class FactCache
def test_FactCache():
    cache = FactCache()
    assert 'gather_subset' in cache
    cache['test'] = 'test'
    assert cache['test'] == 'test'
    cache.flush()

# Generated at 2022-06-11 18:59:26.172927
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin

# Generated at 2022-06-11 18:59:27.137451
# Unit test for constructor of class FactCache
def test_FactCache():
    facts = FactCache()
    assert len(facts.keys()) == 0


# Generated at 2022-06-11 18:59:30.818590
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    keys = fact_cache.keys()
    if keys:
        print('keys:', keys)
    else:
        print('empty')
    fact_cache.flush()

# Generated at 2022-06-11 18:59:38.305753
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    facts_cache = FactCache()
    facts_cache.flush()

    value = {u'foo': 'bar'}
    key = u'localhost'

    # Cache empty
    facts_cache.first_order_merge(key, value)
    assert facts_cache[key] == value

    value = {u'foo': 'new_bar'}
    key = u'localhost'

    # Cache not empty
    facts_cache.first_order_merge(key, value)
    assert facts_cache[key] == value

# Generated at 2022-06-11 19:01:33.392647
# Unit test for constructor of class FactCache
def test_FactCache():
    fact = FactCache()
    assert fact._plugin is not None

# Generated at 2022-06-11 19:01:38.625659
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    test_value = {
        "some_fact": "some_value",
        "some_list": [1, 2, 3],
        "some_none": None,
        "some_dict": {
            "nested_fact": "nested_value",
            "nested_list": [4, 5, 6],
            "nested_dict": {
                "deep_fact": "deep_value",
                "deep_list" : [7, 8, 9]
            }
        }
    }
    test_fact_name = "test_fact"
    cache.first_order_merge(test_fact_name, test_value)
    assert test_value == cache.copy()[test_fact_name]
    assert test_value == cache[test_fact_name]
   

# Generated at 2022-06-11 19:01:49.345889
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    plugin = FactCache()

    # Test when cache is empty
    host_facts = {'key1': 'value1', 'key2': 'value2'}
    plugin.first_order_merge('host1', host_facts)
    assert plugin['host1']['key1'] == 'value1'
    assert plugin['host1']['key2'] == 'value2'

    # Test when host entry exists in cache
    host_facts = {'key1': 'value1.1', 'key3': 'value3'}
    plugin.first_order_merge('host1', host_facts)
    assert plugin['host1']['key1'] == 'value1.1'
    assert plugin['host1']['key2'] == 'value2'

# Generated at 2022-06-11 19:01:50.140279
# Unit test for constructor of class FactCache
def test_FactCache():
    fact_cache = FactCache()
    fact_cache.flush()

# Generated at 2022-06-11 19:01:52.668151
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    cache = FactCache()
    test_data = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}

    cache.first_order_merge('my-host', test_data)
    assert cache['my-host'] == test_data
    cache.flush()

# Generated at 2022-06-11 19:01:58.279666
# Unit test for constructor of class FactCache
def test_FactCache():
    fc = FactCache()
    assert fc._plugin
    assert fc._plugin.contains == fc.__contains__
    assert fc._plugin.get == fc.__getitem__
    assert fc._plugin.set == fc.__setitem__
    assert fc._plugin.delete == fc.__delitem__
    assert fc._plugin.keys() == fc.__iter__()


# Generated at 2022-06-11 19:02:08.778525
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():

    class FakeCachePlugin:
        def __init__(self, data):
            self.data = data

        def contains(self, key):
            return key in self.data

        def set(self, key, value):
            self.data[key] = value

        def get(self, key):
            if key in self.data:
                return self.data[key]
            raise KeyError

        def delete(self, key):
            if key in self.data:
                del self.data[key]

        def keys(self):
            return self.data.keys()

        def flush(self):
            return self.data.clear()


    fact_cache = FactCache()
    fact_cache._plugin = FakeCachePlugin({'A': {'a': 1}})

    # test with key is not in self.data
   

# Generated at 2022-06-11 19:02:19.511385
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    """ Unit test for method first_order_merge of class FactCache """

    fact_cache = FactCache()

    test_facts = {'first': 'value1', 'second': 'value2', 'third': 'value3'}

    fact_cache.first_order_merge('hostname', test_facts)

    result = fact_cache.first_order_merge('hostname', test_facts)
    assert result == fact_cache['hostname']
    assert result.keys() == test_facts.keys()
    assert result.values() == test_facts.values()

    fact_cache['hostname']['first'] = "changed"
    result = fact_cache.first_order_merge('hostname', test_facts)
    assert result != fact_cache['hostname']
    assert result.keys() == test_facts

# Generated at 2022-06-11 19:02:27.539216
# Unit test for method first_order_merge of class FactCache
def test_FactCache_first_order_merge():
    fc = FactCache()
    fc.first_order_merge(key='test_facts_cache', value={'foo': 'bar'})
    assert fc['test_facts_cache']['foo'] == 'bar'
    fc.first_order_merge(key='test_facts_cache', value={'foo': 'baz'})
    assert fc['test_facts_cache']['foo'] == 'baz'