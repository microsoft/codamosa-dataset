

# Generated at 2022-06-17 19:39:39.780779
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--json', '{"key": "value"}', 'http://httpbin.org/post'])
    assert args.json == {"key": "value"}
    assert args.url == 'http://httpbin.org/post'
    assert args.method == 'POST'
    assert args.headers == [('Content-Type', 'application/json')]
    assert args.data == b'{"key": "value"}'
    assert args.files == {}
    assert args.params == {}
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.download == False
    assert args.download_res

# Generated at 2022-06-17 19:39:41.924569
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO: Add unit test for method parse_args of class HTTPieArgumentParser
    pass


# Generated at 2022-06-17 19:39:48.680041
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.files == None
    assert args.params == None
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.timeout == None
    assert args.check_status == False
    assert args.follow == False
    assert args.follow_redirects == True
    assert args.max_redirects == 10
    assert args.method == None
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.pretty == None

# Generated at 2022-06-17 19:40:01.093215
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args([])
    assert args.output_options == 'HhB'
    assert args.output_options_history == 'HhB'
    assert args.prettify == 'all'
    assert args.download == False
    assert args.download_resume == False
    assert args.format_options == PARSED_DEFAULT_FORMAT_OPTIONS
    assert args.auth_plugin == None
    assert args.auth_type == None
    assert args.auth == None
    assert args.ignore_netrc == False
    assert args.ignore_stdin == False
    assert args.method == None
    assert args.request_items == []
    assert args.headers == []
    assert args.data == None
    assert args.files == {}
    assert args

# Generated at 2022-06-17 19:40:09.489178
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:40:18.706969
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == None
    assert args.data == None
    assert args.files == None
    assert args.params == None
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.cert == None
    assert args.timeout == None
    assert args.max_redirects == None
    assert args.follow == False
    assert args.session == None
    assert args.session_read_only == False
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args

# Generated at 2022-06-17 19:40:29.842844
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url is None
    assert args.method is None
    assert args.headers == []
    assert args.data == []
    assert args.files == []
    assert args.params == []
    assert args.output_file is None
    assert args.output_options is None
    assert args.output_options_history is None
    assert args.prettify is None
    assert args.download is False
    assert args.download_resume is False
    assert args.max_redirects is None
    assert args.follow_redirects is False
    assert args.timeout is None
    assert args.check_status is False
    assert args.verify is False
    assert args.ssl is None
    assert args.proxy is None
   

# Generated at 2022-06-17 19:40:42.547961
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    parser = HTTPieArgumentParser()
    args = parser.parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.files == None
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.follow == False
    assert args.max_redirects == 5
    assert args.timeout == None
    assert args.check_status == False
    assert args.headers_off == False
    assert args.body_off == False
    assert args.style == None
    assert args.style_off == False
   

# Generated at 2022-06-17 19:40:47.639495
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:40:56.589402
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.files == None
    assert args.params == None
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.download == False
    assert args.download_resume == False
    assert args.download_all_urls == False
    assert args.download_with_context == False
    assert args.download_all_urls_with_context == False
    assert args.download_all_urls_with_context == False
    assert args.download_all_urls_with_context == False

# Generated at 2022-06-17 19:41:57.332438
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == None
    assert args.data == None
    assert args.files == None
    assert args.params == None
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.output_file == None
    assert args.output_file_specified == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.prettify == None
    assert args.download == None
    assert args.download_resume == None
    assert args.session == None
    assert args.session_read_only == None
    assert args.timeout == None


# Generated at 2022-06-17 19:42:05.037966
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == []
    assert args.files == []
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.max_redirects == None
    assert args.follow == False
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.prettify == None
    assert args.download == False
    assert args.download

# Generated at 2022-06-17 19:42:06.630060
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help


# Generated at 2022-06-17 19:42:13.717587
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:42:23.266053
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == []
    assert args.files == []
    assert args.params == []
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.download == False
    assert args.download_resume == False
    assert args.download_all_urls == False
    assert args.download_all_urls_file == None
    assert args.download_all_urls_stdout == False
    assert args.download_all_urls_follow_redirects == True
    assert args.download_all_urls_ignore_stdin

# Generated at 2022-06-17 19:42:31.946048
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:42:43.090180
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:42:50.060764
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--json', '{"a": "b"}', 'http://httpbin.org/get'])
    assert args.json == {'a': 'b'}
    assert args.headers == {}
    assert args.data == {}
    assert args.files == {}
    assert args.params == {}
    assert args.method == 'GET'
    assert args.url == 'http://httpbin.org/get'
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_netrc == False
    assert args.verify == True
    assert args.verify_ssl == True
    assert args.cert == None
    assert args.cert_key == None
    assert args.output_file == None
    assert args.output

# Generated at 2022-06-17 19:43:00.005999
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help
    args = parser.parse_args(['--version'])
    assert args.version
    args = parser.parse_args(['--debug'])
    assert args.debug
    args = parser.parse_args(['--traceback'])
    assert args.traceback
    args = parser.parse_args(['--check-status'])
    assert args.check_status
    args = parser.parse_args(['--follow'])
    assert args.follow
    args = parser.parse_args(['--max-redirects', '10'])
    assert args.max_redirects == 10
    args = parser.parse_args(['--timeout', '10'])
    assert args.timeout

# Generated at 2022-06-17 19:43:09.951766
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--json', '{"a": 1}', 'http://httpbin.org/post'])
    assert args.json == {"a": 1}
    assert args.url == 'http://httpbin.org/post'
    assert args.headers == []
    assert args.data == []
    assert args.files == []
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.download == False
    assert args.download_resume == False
    assert args.output_options == 'Hhb'

# Generated at 2022-06-17 19:44:44.960203
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO: implement
    pass


# Generated at 2022-06-17 19:44:56.792131
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url is None
    assert args.method is None
    assert args.headers == []
    assert args.data == []
    assert args.files == []
    assert args.params == []
    assert args.output_file is None
    assert args.output_options is None
    assert args.output_options_history is None
    assert args.download is False
    assert args.download_resume is False
    assert args.download_all is False
    assert args.download_all_resume is False
    assert args.download_all_urls is False
    assert args.download_all_urls_resume is False
    assert args.download_all_urls_file is None
    assert args.download_all_urls_

# Generated at 2022-06-17 19:45:06.177944
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == []
    assert args.files == []
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.max_redirects == None
    assert args.follow == False
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.download == False
    assert args.download_resume == False

# Generated at 2022-06-17 19:45:15.539625
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == None
    assert args.data == None
    assert args.params == None
    assert args.files == None
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_netrc == False
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.download == False
    assert args.download_resume == False
    assert args.download_as_file == False
    assert args.download_as_file_specified == False
    assert args.download_all == False
   

# Generated at 2022-06-17 19:45:25.850718
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == None
    assert args.data == None
    assert args.files == None
    assert args.params == None
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.allow_redirects == True
    assert args.max_redirects == 10
    assert args.follow_redirects == True
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.output_options == None
    assert args.output_options

# Generated at 2022-06-17 19:45:35.552263
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help
    args = parser.parse_args(['--version'])
    assert args.version
    args = parser.parse_args(['--traceback'])
    assert args.traceback
    args = parser.parse_args(['--debug'])
    assert args.debug
    args = parser.parse_args(['--download'])
    assert args.download
    args = parser.parse_args(['--download-resume'])
    assert args.download_resume
    args = parser.parse_args(['--offline'])
    assert args.offline
    args = parser.parse_args(['--verbose'])
    assert args.verbose

# Generated at 2022-06-17 19:45:47.297878
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http://example.com'])
    assert args.url == 'http://example.com'
    assert args.method == 'GET'
    assert args.headers == []
    assert args.data == []
    assert args.params == []
    assert args.files == []
    assert args.output_file == None
    assert args.output_options == 'H'
    assert args.output_options_history == 'H'
    assert args.download == False
    assert args.download_resume == False
    assert args.download_all_urls == False
    assert args.download_all_urls_file == None
    assert args.download_all_urls_glob == None
    assert args.download_all_urls_regex == None


# Generated at 2022-06-17 19:45:58.162716
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:46:08.365965
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--version'])
    assert args.version == True
    args = parser.parse_args(['--help'])
    assert args.help == True
    args = parser.parse_args(['--traceback'])
    assert args.traceback == True
    args = parser.parse_args(['--debug'])
    assert args.debug == True
    args = parser.parse_args(['--download'])
    assert args.download == True
    args = parser.parse_args(['--download-resume'])
    assert args.download_resume == True
    args = parser.parse_args(['--download-resume'])
    assert args.download_resume == True

# Generated at 2022-06-17 19:46:19.092580
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http://httpbin.org/get'])
    assert args.url == 'http://httpbin.org/get'
    assert args.method == 'GET'
    assert args.headers == []
    assert args.data == []
    assert args.params == []
    assert args.files == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.cert == None
    assert args.timeout == None
    assert args.max_redirects == 30
    assert args.follow_redirects == True
    assert args.output_file == None
    assert args.output_file_specified == False