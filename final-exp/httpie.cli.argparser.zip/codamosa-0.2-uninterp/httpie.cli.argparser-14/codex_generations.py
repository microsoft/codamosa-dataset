

# Generated at 2022-06-17 19:39:47.771473
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:39:59.988959
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.params == []
    assert args.files == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.max_redirects == None
    assert args.follow == False
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.download == False
    assert args.download_resume == False

# Generated at 2022-06-17 19:40:08.767892
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help
    args = parser.parse_args(['--version'])
    assert args.version
    args = parser.parse_args(['--traceback'])
    assert args.traceback
    args = parser.parse_args(['--ignore-stdin'])
    assert args.ignore_stdin
    args = parser.parse_args(['--default-scheme=https'])
    assert args.default_scheme == 'https'
    args = parser.parse_args(['--timeout=10'])
    assert args.timeout == 10
    args = parser.parse_args(['--check-status'])
    assert args.check_status
    args = parser.parse_args(['--follow'])

# Generated at 2022-06-17 19:40:18.050197
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.files == {}
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.max_redirects == 30
    assert args.follow == False
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.download == False
    assert args.download_resume == False

# Generated at 2022-06-17 19:40:29.067398
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == None
    assert args.data == None
    assert args.files == None
    assert args.params == None
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.verify_ssl_certs == True
    assert args.cert == None
    assert args.cert_key == None
    assert args.cert_key_passphrase == None
    assert args.proxy == None
    assert args.proxy_auth == None
    assert args.proxy_auth_type == None
    assert args.proxy_

# Generated at 2022-06-17 19:40:41.374357
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--json', '{"foo": "bar"}', 'http://httpbin.org/post'])
    assert args.json == {"foo": "bar"}
    assert args.url == 'http://httpbin.org/post'
    assert args.headers == []
    assert args.data == []
    assert args.params == []
    assert args.files == []
    assert args.output_file == None
    assert args.output_options == 'H'
    assert args.output_options_history == 'H'
    assert args.prettify == 'all'
    assert args.download == False
    assert args.download_resume == False
    assert args.format_options == PARSED_DEFAULT_FORMAT_OPTIONS
    assert args.method

# Generated at 2022-06-17 19:40:48.772297
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.files == None
    assert args.params == None
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.max_redirects == None
    assert args.follow == False
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.download == False
    assert args.download_resume == False

# Generated at 2022-06-17 19:40:57.173429
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:41:07.210241
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help
    args = parser.parse_args(['--version'])
    assert args.version
    args = parser.parse_args(['--traceback'])
    assert args.traceback
    args = parser.parse_args(['--ignore-stdin'])
    assert args.ignore_stdin
    args = parser.parse_args(['--timeout', '10'])
    assert args.timeout == 10
    args = parser.parse_args(['--max-redirects', '10'])
    assert args.max_redirects == 10
    args = parser.parse_args(['--check-status'])
    assert args.check_status

# Generated at 2022-06-17 19:41:08.703972
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help


# Generated at 2022-06-17 19:42:42.716610
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == None
    assert args.data == None
    assert args.files == None
    assert args.params == None
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.output_file == None
    assert args.output_file_specified == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.prettify == None
    assert args.download == None
    assert args.download_resume == None
    assert args.max_redirects == None
    assert args.timeout == None

# Generated at 2022-06-17 19:42:52.901544
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == []
    assert args.files == []
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.max_redirects == 30
    assert args.follow == False
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.verbose == False
    assert args.debug == False
    assert args.traceback

# Generated at 2022-06-17 19:43:03.374830
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http://httpbin.org/get'])
    assert args.url == 'http://httpbin.org/get'
    assert args.method == 'GET'
    assert args.headers == {}
    assert args.data == {}
    assert args.params == {}
    assert args.files == {}
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.output_options == 'Hhb'
    assert args.output_options_history == 'Hhb'
    assert args.prettify == True
    assert args.download == False
    assert args.download_resume == False


# Generated at 2022-06-17 19:43:13.052862
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help
    args = parser.parse_args(['--version'])
    assert args.version
    args = parser.parse_args(['--traceback'])
    assert args.traceback
    args = parser.parse_args(['--ignore-stdin'])
    assert args.ignore_stdin
    args = parser.parse_args(['--pretty', 'all'])
    assert args.prettify == 'all'
    args = parser.parse_args(['--style', 'solarized'])
    assert args.style == 'solarized'
    args = parser.parse_args(['--print', 'h'])
    assert args.output_options == 'h'

# Generated at 2022-06-17 19:43:22.911577
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.files == None
    assert args.params == None
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.allow_redirects == True
    assert args.max_redirects == 10
    assert args.follow_redirects == True
    assert args.check_status == True
    assert args.headers_off == False
    assert args.body_off == False
    assert args.verbose == False


# Generated at 2022-06-17 19:43:28.465131
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test for method parse_args of class HTTPieArgumentParser
    #
    # This method is a wrapper for the argparse.ArgumentParser.parse_args()
    # method. It also performs some additional processing of the parsed
    # arguments.
    #
    # The method takes no arguments. It returns the parsed arguments.
    #
    # The method can raise a ParseError exception.
    #
    # This method is not directly tested by the unit tests.
    pass


# Generated at 2022-06-17 19:43:39.287112
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:43:49.245358
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help
    args = parser.parse_args(['--version'])
    assert args.version
    args = parser.parse_args(['--debug'])
    assert args.debug
    args = parser.parse_args(['--traceback'])
    assert args.traceback
    args = parser.parse_args(['--check-status'])
    assert args.check_status
    args = parser.parse_args(['--follow'])
    assert args.follow
    args = parser.parse_args(['--max-redirects', '10'])
    assert args.max_redirects == 10
    args = parser.parse_args(['--max-headers', '10'])
    assert args

# Generated at 2022-06-17 19:43:58.818665
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help == True
    args = parser.parse_args(['--version'])
    assert args.version == True
    args = parser.parse_args(['--traceback'])
    assert args.traceback == True
    args = parser.parse_args(['--debug'])
    assert args.debug == True
    args = parser.parse_args(['--verbose'])
    assert args.verbose == True
    args = parser.parse_args(['--output-file', 'output.txt'])
    assert args.output_file == 'output.txt'
    args = parser.parse_args(['--download'])
    assert args.download == True

# Generated at 2022-06-17 19:44:06.824464
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.files == None
    assert args.params == None
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.max_redirects == None
    assert args.follow == False
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.verbose == False
    assert args.debug == False

# Generated at 2022-06-17 19:45:48.858405
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == None
    assert args.data == None
    assert args.files == None
    assert args.params == None
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.max_redirects == None
    assert args.follow == False
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.download == False
    assert args.download_resume == False

# Generated at 2022-06-17 19:45:59.120433
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.parse_args(['--version'])
    parser.parse_args(['--help'])
    parser.parse_args(['--traceback'])
    parser.parse_args(['--debug'])
    parser.parse_args(['--download'])
    parser.parse_args(['--download-resume'])
    parser.parse_args(['--offline'])
    parser.parse_args(['--output-file'])
    parser.parse_args(['--output-options'])
    parser.parse_args(['--output-options-history'])
    parser.parse_args(['--verbose'])
    parser.parse_args(['--pretty'])
    parser.parse_args(['--style'])
    parser.parse_args

# Generated at 2022-06-17 19:46:08.598868
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:46:19.292101
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http', 'httpbin.org/get'])
    assert args.url == 'httpbin.org/get'
    assert args.method == 'GET'
    assert args.headers == []
    assert args.data == []
    assert args.files == []
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.output_options == 'H'
    assert args.output_options_history == 'H'
    assert args.download == False
    assert args.download_resume == False
    assert args.prettify == 'all'
    assert args

# Generated at 2022-06-17 19:46:27.436850
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:46:38.199365
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help
    assert not args.version
    assert not args.debug
    assert not args.traceback
    assert not args.check_status
    assert not args.follow
    assert not args.follow_redirects
    assert not args.max_redirects
    assert not args.timeout
    assert not args.verify
    assert not args.cert
    assert not args.headers
    assert not args.ignore_stdin
    assert not args.output_file
    assert not args.output_file_specified
    assert not args.download
    assert not args.download_resume
    assert not args.download_as_post
    assert not args.download_all_urls
    assert not args.download_with_

# Generated at 2022-06-17 19:46:45.781246
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help
    args = parser.parse_args(['--version'])
    assert args.version
    args = parser.parse_args(['--traceback'])
    assert args.traceback
    args = parser.parse_args(['--ignore-stdin'])
    assert args.ignore_stdin
    args = parser.parse_args(['--pretty', 'all'])
    assert args.prettify == 'all'
    args = parser.parse_args(['--style', 'solarized'])
    assert args.style == 'solarized'
    args = parser.parse_args(['--print', 'hb'])
    assert args.output_options == 'hb'

# Generated at 2022-06-17 19:46:58.746683
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:47:09.435539
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test for method parse_args of class HTTPieArgumentParser
    # This method tests the parse_args method of the HTTPieArgumentParser class
    # It creates an instance of the class and then calls the method with the
    # arguments to be parsed.
    # It then checks if the parsed arguments are the same as the expected
    # arguments
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:47:20.419010
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http', 'httpbin.org'])
    assert args.url == 'http://httpbin.org'
    assert args.method == 'GET'
    assert args.headers == []
    assert args.data == []
    assert args.params == []
    assert args.files == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.ignore_netrc == False
    assert args.timeout == None
    assert args.check_status == False
    assert args.check_ssl == False
    assert args.follow == False
    assert args.max_redirects == None
    assert args.method == 'GET'
    assert args.output_file == None