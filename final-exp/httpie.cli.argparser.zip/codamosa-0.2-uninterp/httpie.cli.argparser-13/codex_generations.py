

# Generated at 2022-06-17 19:39:45.647536
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:39:56.549223
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:40:06.556370
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:40:16.424213
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == []
    assert args.files == []
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.max_redirects == None
    assert args.follow == False
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.download == False
    assert args.download_resume == False

# Generated at 2022-06-17 19:40:24.379661
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help
    args = parser.parse_args(['--version'])
    assert args.version
    args = parser.parse_args(['--traceback'])
    assert args.traceback
    args = parser.parse_args(['--ignore-stdin'])
    assert args.ignore_stdin
    args = parser.parse_args(['--default-scheme=https'])
    assert args.default_scheme == 'https'
    args = parser.parse_args(['--max-redirects=5'])
    assert args.max_redirects == 5
    args = parser.parse_args(['--timeout=5'])
    assert args.timeout == 5
    args = parser.parse

# Generated at 2022-06-17 19:40:34.463012
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args([])
    assert args.headers == []
    assert args.data == []
    assert args.files == []
    assert args.params == []
    assert args.output_file == None
    assert args.output_options == 'H'
    assert args.output_options_history == 'H'
    assert args.download == False
    assert args.download_resume == False
    assert args.method == 'GET'
    assert args.url == None
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.json == False
    assert args.form == False
    assert args.pretty == 'all'
    assert args.style == None
    assert args.style_sheet == None
   

# Generated at 2022-06-17 19:40:45.420451
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help
    args = parser.parse_args(['--version'])
    assert args.version
    args = parser.parse_args(['--debug'])
    assert args.debug
    args = parser.parse_args(['--traceback'])
    assert args.traceback
    args = parser.parse_args(['--check-status'])
    assert args.check_status
    args = parser.parse_args(['--follow'])
    assert args.follow
    args = parser.parse_args(['--max-redirects', '10'])
    assert args.max_redirects == 10
    args = parser.parse_args(['--timeout', '10'])
    assert args.timeout

# Generated at 2022-06-17 19:40:54.820543
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with empty args
    args = []
    parser = HTTPieArgumentParser()
    assert parser.parse_args(args) == parser.parse_args(args)
    # Test with args
    args = ['--help']
    parser = HTTPieArgumentParser()
    assert parser.parse_args(args) == parser.parse_args(args)
    # Test with args
    args = ['--version']
    parser = HTTPieArgumentParser()
    assert parser.parse_args(args) == parser.parse_args(args)
    # Test with args
    args = ['--traceback']
    parser = HTTPieArgumentParser()
    assert parser.parse_args(args) == parser.parse_args(args)
    # Test with args
    args = ['--debug']
    parser = HTTPieArgumentParser()


# Generated at 2022-06-17 19:40:59.325575
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO: fix this test
    # parser = HTTPieArgumentParser()
    # args = parser.parse_args(['http://example.com'])
    # assert args.url == 'http://example.com'
    pass


# Generated at 2022-06-17 19:41:09.279297
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help == True
    args = parser.parse_args(['--version'])
    assert args.version == True
    args = parser.parse_args(['--traceback'])
    assert args.traceback == True
    args = parser.parse_args(['--debug'])
    assert args.debug == True
    args = parser.parse_args(['--check-status'])
    assert args.check_status == True
    args = parser.parse_args(['--follow'])
    assert args.follow == True
    args = parser.parse_args(['--follow-redirects'])
    assert args.follow_redirects == True

# Generated at 2022-06-17 19:42:10.866328
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help
    assert not args.version
    assert not args.check_updates
    assert not args.debug
    assert not args.traceback
    assert not args.download
    assert not args.download_resume
    assert not args.ignore_stdin
    assert not args.ignore_netrc
    assert not args.offline
    assert not args.output_file_specified
    assert not args.output_options
    assert not args.output_options_history
    assert not args.prettify
    assert not args.print_headers
    assert not args.print_body
    assert not args.print_status
    assert not args.print_cookies
    assert not args.print_history

# Generated at 2022-06-17 19:42:12.936821
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = HTTPieArgumentParser().parse_args(['--help'])
    assert args.help


# Generated at 2022-06-17 19:42:22.805718
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.files == None
    assert args.params == None
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.follow == False
    assert args.max_redirects == None
    assert args.timeout == None
    assert args.check_status == False
    assert args.headers_only == False
    assert args.body_only == False
    assert args.verbose == False
    assert args.output_file == None

# Generated at 2022-06-17 19:42:31.667721
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help
    args = parser.parse_args(['--version'])
    assert args.version
    args = parser.parse_args(['--traceback'])
    assert args.traceback
    args = parser.parse_args(['--debug'])
    assert args.debug
    args = parser.parse_args(['--ignore-stdin'])
    assert args.ignore_stdin
    args = parser.parse_args(['--timeout', '10'])
    assert args.timeout == 10
    args = parser.parse_args(['--check-status'])
    assert args.check_status
    args = parser.parse_args(['--follow'])
    assert args.follow
    args = parser

# Generated at 2022-06-17 19:42:42.908809
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:42:49.854300
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.files == None
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.max_redirects == 30
    assert args.follow == False
    assert args.output_file == None
    assert args.download == False
    assert args.download_resume == False
    assert args.output_options == None
    assert args.output_options_history == None

# Generated at 2022-06-17 19:42:59.981696
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:43:01.081536
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO: implement test
    pass

# Generated at 2022-06-17 19:43:10.865643
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:43:20.801605
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url is None
    assert args.method is None
    assert args.headers == []
    assert args.request_items == []
    assert args.data is None
    assert args.files == {}
    assert args.params == {}
    assert args.auth is None
    assert args.auth_type is None
    assert args.auth_plugin is None
    assert args.output_file is None
    assert args.output_file_specified is False
    assert args.download is False
    assert args.download_resume is False
    assert args.output_options is None
    assert args.output_options_history is None
    assert args.prettify is None
    assert args.format is None
    assert args.style is None

# Generated at 2022-06-17 19:44:56.970403
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Arrange
    parser = HTTPieArgumentParser()
    # Act
    args = parser.parse_args(['--help'])
    # Assert
    assert args.help == True

# Generated at 2022-06-17 19:45:06.275215
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:45:15.610392
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help
    args = parser.parse_args(['--version'])
    assert args.version
    args = parser.parse_args(['--traceback'])
    assert args.traceback
    args = parser.parse_args(['--debug'])
    assert args.debug
    args = parser.parse_args(['--ignore-stdin'])
    assert args.ignore_stdin
    args = parser.parse_args(['--timeout', '10'])
    assert args.timeout == 10
    args = parser.parse_args(['--verify', 'no'])
    assert args.verify == False
    args = parser.parse_args(['--cert', 'cert.pem'])
   

# Generated at 2022-06-17 19:45:23.749625
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--json', '{"foo": "bar"}', 'httpbin.org/post'])
    assert args.json == {"foo": "bar"}
    assert args.url == 'httpbin.org/post'
    assert args.headers == []
    assert args.data == []
    assert args.files == {}
    assert args.params == []
    assert args.method == 'GET'
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.output_options == 'Hhb'
    assert args.output_options_history == 'Hhb'
    assert args.download == False

# Generated at 2022-06-17 19:45:34.831705
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.parse_args(['http', 'http://httpbin.org/get'])
    assert parser.args.url == 'http://httpbin.org/get'
    assert parser.args.method == 'GET'
    assert parser.args.headers == []
    assert parser.args.data == []
    assert parser.args.files == []
    assert parser.args.params == []
    assert parser.args.output_file == None
    assert parser.args.output_options == 'Hhb'
    assert parser.args.output_options_history == 'Hhb'
    assert parser.args.prettify == 'all'
    assert parser.args.download == False
    assert parser.args.download_resume == False

# Generated at 2022-06-17 19:45:47.223180
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.files == {}
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.follow == False
    assert args.max_redirects == None
    assert args.timeout == None
    assert args.check_status == False
    assert args.headers_off == False
    assert args.body_off == False
    assert args.style == None
    assert args.style_off == False
    assert args.print_headers

# Generated at 2022-06-17 19:45:58.058274
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http://httpbin.org/get'])
    assert args.url == 'http://httpbin.org/get'
    assert args.method == 'GET'
    assert args.headers == []
    assert args.data == []
    assert args.params == []
    assert args.files == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.ignore_stdin == False
    assert args.ignore_netrc == False
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.output_options == 'H'
    assert args.output_options_history == 'H'
    assert args.download == False
    assert args

# Generated at 2022-06-17 19:46:08.244144
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http://httpbin.org/get'])
    assert args.url == 'http://httpbin.org/get'
    assert args.method == 'GET'
    assert args.headers == {}
    assert args.data == {}
    assert args.params == {}
    assert args.files == {}
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.output_options == 'HhBb'
    assert args.output_options_history == 'HhBb'
    assert args.prettify == 'all'
    assert args.download == False
    assert args.download_res

# Generated at 2022-06-17 19:46:19.023840
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--json', '{"a":1}', 'http://httpbin.org/get'])
    assert args.json == {"a":1}
    assert args.url == 'http://httpbin.org/get'
    assert args.headers == []
    assert args.data == []
    assert args.files == []
    assert args.params == []
    assert args.method == 'GET'
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.verify_ssl_certs == True
    assert args.ssl == None
    assert args.output_file == None
    assert args.output_file_specified == False

# Generated at 2022-06-17 19:46:27.370854
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no argument
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.files == None
    assert args.params == None
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.max_redirects == None
    assert args.follow == False
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.download == False
    assert args.download_resume == False