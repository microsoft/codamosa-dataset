

# Generated at 2022-06-17 19:39:36.911314
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == 'https://httpie.org'
    assert args.method == 'GET'
    assert args.headers == []
    assert args.data == []
    assert args.params == []
    assert args.files == []
    assert args.output_file == None
    assert args.output_options == 'H'
    assert args.output_options_history == 'H'
    assert args.prettify == 'all'
    assert args.download == False
    assert args.download_resume == False
    assert args.format_options == PARSED_DEFAULT_FORMAT_OPTIONS
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args

# Generated at 2022-06-17 19:39:48.327812
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == ''
    assert args.method == 'GET'
    assert args.headers == []
    assert args.data == []
    assert args.files == []
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.max_redirects == None
    assert args.follow_redirects == True
    assert args.output_file == None
    assert args.output_options == 'Hhb'
    assert args.output_options_history == 'Hhb'
    assert args.download == False
   

# Generated at 2022-06-17 19:40:00.750008
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.files == None
    assert args.params == None
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.allow_redirects == True
    assert args.max_redirects == 10
    assert args.follow_redirects == True
    assert args.check_status == True
    assert args.headers_off == False
    assert args.body_off == False
    assert args.style == None
   

# Generated at 2022-06-17 19:40:09.267379
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help
    args = parser.parse_args(['--version'])
    assert args.version
    args = parser.parse_args(['--traceback'])
    assert args.traceback
    args = parser.parse_args(['--debug'])
    assert args.debug
    args = parser.parse_args(['--json'])
    assert args.json
    args = parser.parse_args(['--form'])
    assert args.form
    args = parser.parse_args(['--pretty'])
    assert args.pretty
    args = parser.parse_args(['--style'])
    assert args.style
    args = parser.parse_args(['--print'])

# Generated at 2022-06-17 19:40:18.597508
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['https://httpbin.org/get'])
    assert args.url == 'https://httpbin.org/get'
    assert args.method == 'GET'
    assert args.headers == {}
    assert args.data == {}
    assert args.params == {}
    assert args.files == {}
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.ignore_netrc == False
    assert args.verify == True
    assert args.verify_ssl == True
    assert args.cert == None
    assert args.cert_key == None
    assert args.cert_key_password == None
    assert args.output_file == None

# Generated at 2022-06-17 19:40:19.650933
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO: implement
    pass


# Generated at 2022-06-17 19:40:30.726302
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:40:43.225318
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:40:57.943810
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:41:07.744435
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:42:02.152299
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:42:11.392803
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.files == []
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.allow_redirects == True
    assert args.max_redirects == 10
    assert args.follow == False
    assert args.output_file == None
    assert args.download == False
    assert args.download_resume == False
    assert args.output_options == None

# Generated at 2022-06-17 19:42:21.616643
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:42:30.836912
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.files == None
    assert args.params == None
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.timeout == None
    assert args.check_status == True
    assert args.follow == False
    assert args.max_redirects == None
    assert args.verify == True
    assert args.cert == None
    assert args.proxy == None
    assert args.allow_redirects == True
    assert args.stream == False
    assert args.download == False

# Generated at 2022-06-17 19:42:42.760969
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Arrange
    parser = HTTPieArgumentParser()
    args = ['http', 'http://httpbin.org/get']
    # Act
    result = parser.parse_args(args)
    # Assert
    assert result.url == 'http://httpbin.org/get'
    assert result.method == 'GET'
    assert result.headers == []
    assert result.data == []
    assert result.files == []
    assert result.params == []
    assert result.auth == None
    assert result.auth_type == None
    assert result.auth_plugin == None
    assert result.output_file == None
    assert result.output_file_specified == False
    assert result.output_options == 'HhBb'
    assert result.output_options_history == 'HhBb'
    assert result.pre

# Generated at 2022-06-17 19:42:52.928050
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:43:03.463464
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == []
    assert args.files == []
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.max_redirects == None
    assert args.follow == False
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.download == False
    assert args.download_resume == False

# Generated at 2022-06-17 19:43:13.710866
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:43:21.207602
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help
    args = parser.parse_args(['--version'])
    assert args.version
    args = parser.parse_args(['--traceback'])
    assert args.traceback
    args = parser.parse_args(['--ignore-stdin'])
    assert args.ignore_stdin
    args = parser.parse_args(['--timeout', '10'])
    assert args.timeout == 10
    args = parser.parse_args(['--max-redirects', '10'])
    assert args.max_redirects == 10
    args = parser.parse_args(['--check-status'])
    assert args.check_status

# Generated at 2022-06-17 19:43:30.415353
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--json', '{"name": "value"}', 'http://httpbin.org/post'])
    assert args.json == {"name": "value"}
    assert args.url == 'http://httpbin.org/post'
    assert args.headers == []
    assert args.data == []
    assert args.files == {}
    assert args.params == []
    assert args.method == 'GET'
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.verify_ssl_certs == True
    assert args.cert == None
    assert args.cert_key == None
    assert args.output_file == None

# Generated at 2022-06-17 19:45:11.598284
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:45:21.621587
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--json', '{"a": "b"}', 'http://httpbin.org/post'])
    assert args.json == {"a": "b"}
    assert args.url == 'http://httpbin.org/post'
    assert args.headers == []
    assert args.data == []
    assert args.files == {}
    assert args.params == []
    assert args.method == 'POST'
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.verify_ssl_certs == True
    assert args.cert == None
    assert args.cert_key == None
    assert args.output_file == None

# Generated at 2022-06-17 19:45:28.666465
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.files == None
    assert args.params == None
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.max_redirects == 30
    assert args.follow == False
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.download == False
    assert args.download_resume == False

# Generated at 2022-06-17 19:45:30.592364
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test HTTPieArgumentParser.parse_args()
    # TODO: Implement
    pass


# Generated at 2022-06-17 19:45:35.223621
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--json', '{"a": 1}', 'http://httpbin.org/post'])
    assert args.json == {"a": 1}
    assert args.url == 'http://httpbin.org/post'
    assert args.headers == []
    assert args.data == []
    assert args.files == {}
    assert args.params == []
    assert args.method == 'POST'
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.download == False
    assert args.download_resume == False
    assert args.output_options == 'H'

# Generated at 2022-06-17 19:45:43.012146
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--json', '{"a": "b"}', 'http://httpbin.org/post'])
    assert args.json == {"a": "b"}
    assert args.url == 'http://httpbin.org/post'

test_HTTPieArgumentParser_parse_args()


# Generated at 2022-06-17 19:45:50.004275
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == []
    assert args.files == []
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.max_redirects == None
    assert args.follow == False
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.verbose == False
    assert args.debug == False

# Generated at 2022-06-17 19:45:59.771259
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['-h'])
    assert args.help
    args = parser.parse_args(['--help'])
    assert args.help
    args = parser.parse_args(['--version'])
    assert args.version
    args = parser.parse_args(['--debug'])
    assert args.debug
    args = parser.parse_args(['--traceback'])
    assert args.traceback
    args = parser.parse_args(['--ignore-stdin'])
    assert args.ignore_stdin
    args = parser.parse_args(['--timeout', '10'])
    assert args.timeout == 10
    args = parser.parse_args(['--check-status'])
    assert args.check_status
    args = parser

# Generated at 2022-06-17 19:46:01.893524
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help


# Generated at 2022-06-17 19:46:03.892235
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO: implement
    pass
