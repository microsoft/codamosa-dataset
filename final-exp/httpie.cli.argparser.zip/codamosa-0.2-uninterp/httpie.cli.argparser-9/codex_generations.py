

# Generated at 2022-06-17 19:39:39.808922
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.files == []
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.allow_redirects == True
    assert args.max_redirects == 10
    assert args.follow_redirects == True
    assert args.check_status == True
    assert args.headers_off == False
    assert args.body_off == False
    assert args.style == None
   

# Generated at 2022-06-17 19:39:45.468687
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:39:56.244846
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:40:06.292897
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http', 'http://httpbin.org/get'])
    assert args.url == 'http://httpbin.org/get'
    assert args.method == 'GET'
    assert args.headers == {}
    assert args.data == {}
    assert args.files == {}
    assert args.params == {}
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.output_options == 'Hhb'
    assert args.output_options_history == 'Hhb'
    assert args.prettify == 'all'
    assert args.download == False
    assert args.download_

# Generated at 2022-06-17 19:40:16.251010
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help
    args = parser.parse_args(['--version'])
    assert args.version
    args = parser.parse_args(['--debug'])
    assert args.debug
    args = parser.parse_args(['--traceback'])
    assert args.traceback
    args = parser.parse_args(['--check-status'])
    assert args.check_status
    args = parser.parse_args(['--follow'])
    assert args.follow
    args = parser.parse_args(['--max-redirects', '10'])
    assert args.max_redirects == 10
    args = parser.parse_args(['--timeout', '10'])
    assert args.timeout

# Generated at 2022-06-17 19:40:24.252763
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.files == None
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.max_redirects == None
    assert args.follow == False
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.download == False
    assert args.download_resume == False
    assert args.output_options == None

# Generated at 2022-06-17 19:40:27.279707
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help


# Generated at 2022-06-17 19:40:36.147510
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:40:38.308718
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--traceback', '--debug'])
    assert args.traceback
    assert args.debug


# Generated at 2022-06-17 19:40:47.031711
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:41:37.453444
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.request_items == []
    assert args.headers == {}
    assert args.data == None
    assert args.files == {}
    assert args.params == {}
    assert args.multipart_data == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.ignore_netrc == False
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.download == False
    assert args.download_resume == False
    assert args.download

# Generated at 2022-06-17 19:41:47.739906
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:41:58.455561
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:42:00.421611
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test HTTPieArgumentParser.parse_args()
    # TODO: Implement
    pass


# Generated at 2022-06-17 19:42:06.737264
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help
    args = parser.parse_args(['--version'])
    assert args.version
    args = parser.parse_args(['--verbose'])
    assert args.verbose
    args = parser.parse_args(['--debug'])
    assert args.debug
    args = parser.parse_args(['--traceback'])
    assert args.traceback
    args = parser.parse_args(['--pretty', 'all'])
    assert args.prettify == 'all'
    args = parser.parse_args(['--style', 'solarized'])
    assert args.style == 'solarized'
    args = parser.parse_args(['--print', 'hb'])

# Generated at 2022-06-17 19:42:13.787626
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http', 'httpbin.org/get'])
    assert args.url == 'httpbin.org/get'
    assert args.method == 'GET'
    assert args.headers == []
    assert args.data == []
    assert args.params == []
    assert args.files == {}
    assert args.output_file == None
    assert args.output_options == 'H'
    assert args.output_options_history == 'H'
    assert args.prettify == 'all'
    assert args.download == False
    assert args.download_resume == False
    assert args.format == 'json'
    assert args.format_options == {}
    assert args.style == 'solarized'
    assert args.style_variables == {}


# Generated at 2022-06-17 19:42:23.302877
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.params == []
    assert args.files == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.download == False
    assert args.download_resume == False
    assert args.download_as_file == False
    assert args.download_all == False
    assert args.download_all_resume == False
    assert args

# Generated at 2022-06-17 19:42:31.971121
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--json', '{"a": "b"}', 'http://httpbin.org/get'])
    assert args.json == {"a": "b"}
    assert args.url == 'http://httpbin.org/get'
    assert args.headers == {}
    assert args.method == 'GET'
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.ignore_netrc == False
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.output_options == 'H'
    assert args.output_options_history == 'H'
    assert args.output_options_download == 'H'
    assert args.output_

# Generated at 2022-06-17 19:42:43.128615
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:42:53.025271
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--json', '{"a":1}', 'http://httpbin.org/get'])
    assert args.json == {"a":1}
    assert args.url == 'http://httpbin.org/get'
    assert args.method == 'GET'
    assert args.headers == []
    assert args.data == []
    assert args.files == {}
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.ignore_netrc == False
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.download == False
    assert args.download_resume == False
    assert args.output_

# Generated at 2022-06-17 19:43:32.289486
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == ''
    assert args.method == 'GET'
    assert args.headers == []
    assert args.data == []
    assert args.files == []
    assert args.params == []
    assert args.output_file == None
    assert args.output_options == 'Hhb'
    assert args.output_options_history == 'Hhb'
    assert args.prettify == 'all'
    assert args.download == False
    assert args.download_resume == False
    assert args.format == 'json'
    assert args.format_options == PARSED_DEFAULT_FORMAT_OPTIONS
    assert args.style == 'solarized'
    assert args.style_options == {}

# Generated at 2022-06-17 19:43:36.289128
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--json', '--pretty=all', 'http://httpbin.org/get'])
    assert args.json == True
    assert args.pretty == 'all'
    assert args.url == 'http://httpbin.org/get'
 

# Generated at 2022-06-17 19:43:44.695949
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:43:57.340571
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:44:04.904047
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == None
    assert args.data == None
    assert args.files == None
    assert args.params == None
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.allow_redirects == True
    assert args.max_redirects == 10
    assert args.follow_redirects == True
    assert args.check_status == True
    assert args.headers_off == False
    assert args.body_off == False
    assert args.style == None
   

# Generated at 2022-06-17 19:44:11.626252
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http', '--help'])
    assert args.help
    assert not args.version
    assert not args.debug
    assert not args.traceback
    assert not args.check_status
    assert not args.download
    assert not args.download_resume
    assert not args.ignore_stdin
    assert not args.ignore_netrc
    assert not args.offline
    assert not args.output_file_specified
    assert not args.output_options
    assert not args.output_options_history
    assert not args.prettify
    assert not args.session
    assert not args.session_read_only
    assert not args.stream
    assert not args.timeout
    assert not args.verify
    assert not args.verify_ssl

# Generated at 2022-06-17 19:44:19.340479
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.files == None
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.allow_redirects == True
    assert args.max_redirects == 10
    assert args.follow_redirects == True
    assert args.check_status == True
    assert args.headers_off == False
    assert args.body_off == False
    assert args.verbose == False


# Generated at 2022-06-17 19:44:20.769339
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO: Add unit tests
    pass


# Generated at 2022-06-17 19:44:30.872565
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """
    Test HTTPieArgumentParser.parse_args()
    """
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == None
    assert args.data == None
    assert args.files == None
    assert args.params == None
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.ignore_stdin == False
    assert args.ignore_netrc == False
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.download == False
    assert args.download_resume == False
    assert args.output_options == None
    assert args.output_options_history

# Generated at 2022-06-17 19:44:33.903539
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help


# Generated at 2022-06-17 19:46:08.373091
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == None
    assert args.data == None
    assert args.files == None
    assert args.params == None
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.allow_redirects == True
    assert args.max_redirects == 10
    assert args.follow_redirects == True
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.download == False

# Generated at 2022-06-17 19:46:19.058639
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args([])
    assert args.auth is None
    assert args.auth_type is None
    assert args.auth_plugin is None
    assert args.body is None
    assert args.body_from_file is None
    assert args.check_status is False
    assert args.compress is False
    assert args.config_dir is None
    assert args.config_file is None
    assert args.data is None
    assert args.download is False
    assert args.download_resume is False
    assert args.download_as is None
    assert args.download_all is False
    assert args.download_all_resume is False
    assert args.download_all_as is None
    assert args.download_all_to_dir is None
    assert args.download

# Generated at 2022-06-17 19:46:24.038010
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test case 1
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http', '--help'])
    assert args.help == True

    # Test case 2
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http', '--version'])
    assert args.version == True

    # Test case 3
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http', '--traceback'])
    assert args.traceback == True

    # Test case 4
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http', '--debug'])
    assert args.debug == True

    # Test case 5
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:46:31.249056
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:46:36.298166
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.files == None
    assert args.params == None
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.allow_redirects == True
    assert args.max_redirects == 10
    assert args.follow_redirects == True
    assert args.check_status == True
    assert args.headers_off == False
    assert args.body_off == False
    assert args.verbose == False


# Generated at 2022-06-17 19:46:44.779388
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == []
    assert args.files == []
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.follow == False
    assert args.max_redirects == 5
    assert args.timeout == None
    assert args.check_status == False
    assert args.headers_off == False
    assert args.body_off == False
    assert args.style == None
    assert args.style_off == False
    assert args.print_headers

# Generated at 2022-06-17 19:46:58.273257
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help
    assert not args.debug
    assert not args.traceback
    assert not args.check_status
    assert not args.follow
    assert not args.download
    assert not args.download_resume
    assert not args.download_as_file
    assert not args.download_as_file_resume
    assert not args.download_as_file_name
    assert not args.download_as_file_name_resume
    assert not args.download_as_file_name_append_number
    assert not args.download_as_file_name_append_number_resume
    assert not args.download_as_file_name_append_number_max_count
    assert not args.download_as

# Generated at 2022-06-17 19:47:01.161956
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help == True

# Generated at 2022-06-17 19:47:10.455793
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help == True
    args = parser.parse_args(['--version'])
    assert args.version == True
    args = parser.parse_args(['--traceback'])
    assert args.traceback == True
    args = parser.parse_args(['--debug'])
    assert args.debug == True
    args = parser.parse_args(['--verbose'])
    assert args.verbose == True
    args = parser.parse_args(['--json'])
    assert args.json == True
    args = parser.parse_args(['--form'])
    assert args.form == True
    args = parser.parse_args(['--pretty'])
    assert args.pretty == 'all'

# Generated at 2022-06-17 19:47:20.756865
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--version'])
    assert args.version