

# Generated at 2022-06-17 19:39:49.043820
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.files == {}
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.max_redirects == 30
    assert args.follow == False
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.download == False
    assert args.download_resume == False

# Generated at 2022-06-17 19:40:01.435122
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help
    args = parser.parse_args(['--version'])
    assert args.version
    args = parser.parse_args(['--traceback'])
    assert args.traceback
    args = parser.parse_args(['--debug'])
    assert args.debug
    args = parser.parse_args(['--ignore-stdin'])
    assert args.ignore_stdin
    args = parser.parse_args(['--download'])
    assert args.download
    args = parser.parse_args(['--download-resume'])
    assert args.download_resume
    args = parser.parse_args(['--output', 'file'])

# Generated at 2022-06-17 19:40:09.701056
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:40:18.745818
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == None
    assert args.data == None
    assert args.files == None
    assert args.params == None
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.cert == None
    assert args.timeout == None
    assert args.max_redirects == None
    assert args.follow == False
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.download == False
    assert args.download_resume == False

# Generated at 2022-06-17 19:40:21.026475
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help


# Generated at 2022-06-17 19:40:31.940664
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args([])
    assert args.headers == []
    assert args.data == []
    assert args.files == []
    assert args.params == []
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.prettify == None
    assert args.download == False
    assert args.download_resume == False
    assert args.download_all_urls == False
    assert args.download_all_urls_file == None
    assert args.download_all_urls_glob == None
    assert args.download_all_urls_no_overwrite == False
    assert args.download_all_urls_no_skip == False
    assert args.download_

# Generated at 2022-06-17 19:40:34.399583
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help


# Generated at 2022-06-17 19:40:45.418658
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:40:47.545412
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http', '--help'])
    assert args.help


# Generated at 2022-06-17 19:40:58.986374
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.params == []
    assert args.files == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.max_redirects == None
    assert args.follow == False
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.output_options_session == None
    assert args.output_options_session_read

# Generated at 2022-06-17 19:42:30.703603
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:42:42.757374
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.files == None
    assert args.params == None
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.max_redirects == None
    assert args.follow == False
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.download == False
    assert args.download_resume == False

# Generated at 2022-06-17 19:42:49.749718
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:42:59.931703
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:43:09.900376
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help
    args = parser.parse_args(['--version'])
    assert args.version
    args = parser.parse_args(['--traceback'])
    assert args.traceback
    args = parser.parse_args(['--debug'])
    assert args.debug
    args = parser.parse_args(['--download'])
    assert args.download
    args = parser.parse_args(['--download-resume'])
    assert args.download_resume
    args = parser.parse_args(['--download-resume', '--download'])
    assert args.download_resume

# Generated at 2022-06-17 19:43:19.942585
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:43:22.382869
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help


# Generated at 2022-06-17 19:43:30.580232
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:43:40.138830
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help
    args = parser.parse_args(['--version'])
    assert args.version
    args = parser.parse_args(['--traceback'])
    assert args.traceback
    args = parser.parse_args(['--debug'])
    assert args.debug
    args = parser.parse_args(['--pretty', 'all'])
    assert args.prettify == 'all'
    args = parser.parse_args(['--style', 'solarized'])
    assert args.style == 'solarized'
    args = parser.parse_args(['--style', 'solarized', '--style', 'solarized'])
    assert args.style == 'solarized'


# Generated at 2022-06-17 19:43:47.376158
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--json', '{"a": "b"}', 'https://httpbin.org/post'])
    assert args.json == {"a": "b"}
    assert args.url == 'https://httpbin.org/post'
    assert args.method == 'POST'
    assert args.headers == [('Content-Type', 'application/json')]
    assert args.data == b'{"a": "b"}'
    assert args.files == {}
    assert args.params == {}
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.ignore_netrc == False
    assert args.output_file == None
    assert args.output_file_specified == False

# Generated at 2022-06-17 19:46:36.360065
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO: implement
    pass


# Generated at 2022-06-17 19:46:44.518386
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == 'https://httpie.org'
    assert args.method == 'GET'
    assert args.headers == []
    assert args.data == []
    assert args.params == []
    assert args.files == {}
    assert args.output_file == None
    assert args.output_options == 'H'
    assert args.output_options_history == 'H'
    assert args.download == False
    assert args.download_resume == False
    assert args.max_redirects == 5
    assert args.follow_redirects == True
    assert args.timeout == None
    assert args.check_status == True
    assert args.verify == True
    assert args.cert == None

# Generated at 2022-06-17 19:46:58.140913
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:47:08.999002
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--json', '{"hello": "world"}', 'http://httpbin.org/post'])
    assert args.json == {"hello": "world"}
    assert args.url == "http://httpbin.org/post"
    assert args.headers == []
    assert args.method == "POST"
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.cert == None
    assert args.ssl == None
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.output_options == "H"

# Generated at 2022-06-17 19:47:16.235690
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:47:25.081441
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test HTTPieArgumentParser.parse_args()
    # Create a mock object for the class HTTPieArgumentParser
    mock_HTTPieArgumentParser = mock.create_autospec(HTTPieArgumentParser)
    # Create a mock object for the class argparse.ArgumentParser
    mock_argparse_ArgumentParser = mock.create_autospec(argparse.ArgumentParser)
    # Set the return value of the mock object mock_argparse_ArgumentParser
    # when its method parse_args is called
    mock_argparse_ArgumentParser.parse_args.return_value = 'parse_args'
    # Set the return value of the mock object mock_HTTPieArgumentParser
    # when its method __init__ is called
    mock_HTTPieArgumentParser.__init__.return_value = None
    #

# Generated at 2022-06-17 19:47:35.200704
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:47:46.196243
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:47:56.400946
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--json', '{"foo": "bar"}', 'http://httpbin.org/post'])
    assert args.json == {"foo": "bar"}
    assert args.url == 'http://httpbin.org/post'
    assert args.headers == []
    assert args.data == []
    assert args.files == {}
    assert args.params == []
    assert args.method == 'POST'
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.download == False
    assert args.download_resume == False
    assert args.output_options == 'H'

# Generated at 2022-06-17 19:48:05.710113
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = ['http', '--json', '--headers', 'http://httpbin.org/get']
    parser = HTTPieArgumentParser()
    parser.parse_args(args)
    assert parser.args.json == True
    assert parser.args.headers == True
    assert parser.args.url == 'http://httpbin.org/get'
    assert parser.args.method == 'GET'
    assert parser.args.request_items == []
    assert parser.args.output_file == None
    assert parser.args.output_file_specified == False
    assert parser.args.download == False
    assert parser.args.download_resume == False
    assert parser.args.output_options == 'H'
    assert parser.args.output_options_history == 'H'