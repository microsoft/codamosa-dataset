

# Generated at 2022-06-17 19:39:37.844840
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http://httpbin.org/get'])
    assert args.url == 'http://httpbin.org/get'
    assert args.method == 'GET'
    assert args.headers == []
    assert args.data == []
    assert args.params == []
    assert args.files == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.output_options == 'Hhb'
    assert args.output_options_history == 'Hhb'
    assert args.prettify == 'all'
    assert args.download == False
    assert args.download_resume

# Generated at 2022-06-17 19:39:48.852642
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help
    args = parser.parse_args(['--version'])
    assert args.version
    args = parser.parse_args(['--traceback'])
    assert args.traceback
    args = parser.parse_args(['--debug'])
    assert args.debug
    args = parser.parse_args(['--download'])
    assert args.download
    args = parser.parse_args(['--download-resume'])
    assert args.download_resume
    args = parser.parse_args(['--download-resume'])
    assert args.download_resume
    args = parser.parse_args(['--download-resume'])
    assert args.download_resume
   

# Generated at 2022-06-17 19:39:49.886927
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO: implement
    pass


# Generated at 2022-06-17 19:40:02.454134
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--json', '{"a": "b"}', 'http://httpbin.org/post'])
    assert args.json == {"a": "b"}
    assert args.url == 'http://httpbin.org/post'
    assert args.headers == []
    assert args.data == []
    assert args.files == {}
    assert args.params == []
    assert args.method == 'POST'
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.verify_ssl_certs == True
    assert args.cert == None
    assert args.cert_key == None
    assert args.timeout == None
    assert args.max_

# Generated at 2022-06-17 19:40:09.992123
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:40:19.063197
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.request_items == []
    assert args.data == None
    assert args.files == {}
    assert args.params == {}
    assert args.multipart_data == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.ignore_stdin == False
    assert args.ignore_netrc == False
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.download == False
    assert args.download_resume == False
    assert args.output_options == None
    assert args.output_

# Generated at 2022-06-17 19:40:30.214991
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args([])
    assert args.headers == []
    assert args.params == []
    assert args.data == []
    assert args.files == []
    assert args.output_file == None
    assert args.output_options == 'HhBb'
    assert args.output_options_history == 'HhBb'
    assert args.prettify == 'all'
    assert args.style == 'solarized'
    assert args.style_variant == 'light'
    assert args.verbose == False
    assert args.download == False
    assert args.download_resume == False
    assert args.download_output_directory == None
    assert args.download_output_file_hashing == 'md5'
    assert args.download_output_file

# Generated at 2022-06-17 19:40:42.635103
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == 'https://httpie.org'
    assert args.method == 'GET'
    assert args.headers == []
    assert args.data == []
    assert args.files == []
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.output_options == 'H'
    assert args.output_options_history == 'H'
    assert args.prettify == 'all'
    assert args.download == False
    assert args.download_resume == False
    assert args.follow == False
    assert args.ignore

# Generated at 2022-06-17 19:40:52.823282
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.params == []
    assert args.files == {}
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.max_redirects == 30
    assert args.follow == False
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.download == False
    assert args.download_resume == False

# Generated at 2022-06-17 19:41:03.201990
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == None
    assert args.data == None
    assert args.params == None
    assert args.files == None
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.output_file == None
    assert args.output_file_specified == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.timeout == None
    assert args.check_status == None
    assert args.check_ssl == None
    assert args.follow == None
    assert args.max_redirects == None
    assert args.stream == None
   

# Generated at 2022-06-17 19:41:57.599414
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.parse_args(['--json', '{"a":1}', 'http://example.com'])
    assert parser.args.json == {'a': 1}
    assert parser.args.url == 'http://example.com'
    assert parser.args.method == 'GET'
    assert parser.args.headers == {}
    assert parser.args.data == {}
    assert parser.args.params == {}
    assert parser.args.files == {}
    assert parser.args.multipart_data == []
    assert parser.args.output_file == None
    assert parser.args.output_file_specified == False
    assert parser.args.download == False
    assert parser.args.download_resume == False
    assert parser.args.output_options == 'Hhb'


# Generated at 2022-06-17 19:42:01.298248
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--json', 'https://httpbin.org/get'])
    assert args.json
    assert args.url == 'https://httpbin.org/get'

# Generated at 2022-06-17 19:42:10.742331
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:42:20.769040
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:42:31.572958
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help
    args = parser.parse_args(['--version'])
    assert args.version
    args = parser.parse_args(['--traceback'])
    assert args.traceback
    args = parser.parse_args(['--debug'])
    assert args.debug
    args = parser.parse_args(['--pretty', 'all'])
    assert args.prettify == 'all'
    args = parser.parse_args(['--style', 'solarized'])
    assert args.style == 'solarized'
    args = parser.parse_args(['--print', 'hb'])
    assert args.output_options == 'hb'

# Generated at 2022-06-17 19:42:42.870996
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == []
    assert args.files == []
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.max_redirects == None
    assert args.follow == False
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.verbose == False
    assert args.debug == False
    assert args.traceback

# Generated at 2022-06-17 19:42:52.977648
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http://httpbin.org/get'])
    assert args.url == 'http://httpbin.org/get'
    assert args.method == 'GET'
    assert args.headers == []
    assert args.data == []
    assert args.files == []
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.output_options == 'Hhb'
    assert args.output_options_history == 'Hhb'
    assert args.download == False
    assert args.download_resume == False
    assert args.download_all == False


# Generated at 2022-06-17 19:42:58.949681
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:43:08.762949
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help is True
    assert args.version is False
    assert args.traceback is False
    assert args.check_status is True
    assert args.check_ssl is True
    assert args.download is False
    assert args.download_resume is False
    assert args.download_all_urls is False
    assert args.download_with_context is False
    assert args.download_output_directory is None
    assert args.download_output_file_hashing is None
    assert args.download_output_file_prefix is None
    assert args.download_output_file_suffix is None
    assert args.download_output_file_name_hashing is None
    assert args.download_output_file_name_

# Generated at 2022-06-17 19:43:18.852012
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = ['http', '--json', 'http://httpbin.org/get']
    parser = HTTPieArgumentParser()
    parser.parse_args(args)
    assert parser.args.json == True
    assert parser.args.url == 'http://httpbin.org/get'
    assert parser.args.method == 'GET'
    assert parser.args.headers == []
    assert parser.args.data == []
    assert parser.args.files == []
    assert parser.args.params == []
    assert parser.args.multipart_data == []
    assert parser.args.output_file == None
    assert parser.args.output_options == 'HhbB'
    assert parser.args.output_options_history == 'HhbB'
    assert parser.args.output_file_specified == False
   

# Generated at 2022-06-17 19:45:00.286113
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:45:12.196089
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:45:21.988445
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http://httpbin.org/get'])
    assert args.url == 'http://httpbin.org/get'
    assert args.method == 'GET'
    assert args.headers == []
    assert args.data == []
    assert args.files == []
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.output_options == 'H'
    assert args.output_options_history == 'H'
    assert args.prettify == 'all'
    assert args.download == False
    assert args.download_resume == False

# Generated at 2022-06-17 19:45:28.820445
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.files == None
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.max_redirects == None
    assert args.follow == False
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.pretty == None
    assert args.style == None
    assert args.download == False

# Generated at 2022-06-17 19:45:36.835125
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:45:47.401025
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.files == None
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.allow_redirects == True
    assert args.max_redirects == 10
    assert args.follow_redirects == True
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.download == False

# Generated at 2022-06-17 19:45:58.224314
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test case 1
    args = ['--json', '{"foo": "bar"}', 'https://httpbin.org/get']
    parser = HTTPieArgumentParser()
    args = parser.parse_args(args)
    assert args.json == '{"foo": "bar"}'
    assert args.url == 'https://httpbin.org/get'
    assert args.headers == []
    assert args.data == []
    assert args.files == {}
    assert args.params == []
    assert args.output_file is None
    assert args.output_options is None
    assert args.output_options_history is None
    assert args.download is False
    assert args.download_resume is False
    assert args.download_as_file is False
    assert args.download_as_file_name is None

# Generated at 2022-06-17 19:46:01.117702
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help == True

# Generated at 2022-06-17 19:46:09.835129
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help
    args = parser.parse_args(['--version'])
    assert args.version
    args = parser.parse_args(['--debug'])
    assert args.debug
    args = parser.parse_args(['--traceback'])
    assert args.traceback
    args = parser.parse_args(['--ignore-stdin'])
    assert args.ignore_stdin
    args = parser.parse_args(['--verify=no'])
    assert args.verify == 'no'
    args = parser.parse_args(['--verify=no'])
    assert args.verify == 'no'
    args = parser.parse_args(['--verify=no'])


# Generated at 2022-06-17 19:46:20.123266
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--version'])
    assert args.version is True
    assert args.debug is False
    assert args.traceback is False
    assert args.check_status is False
    assert args.download is False
    assert args.download_resume is False
    assert args.download_as_file is False
    assert args.download_all is False
    assert args.download_all_resume is False
    assert args.download_all_as_file is False
    assert args.download_all_as_file_name is None
    assert args.download_all_as_file_name_template is None
    assert args.download_all_as_file_name_template_escape is False
    assert args.download_all_as_file_name_template_separ