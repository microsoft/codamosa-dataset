

# Generated at 2022-06-17 19:39:48.933074
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--version'])
    assert args.version
    assert args.debug
    assert args.traceback
    assert args.check_ssl
    assert args.verify
    assert args.verify_all
    assert args.verify_none
    assert args.ignore_netrc
    assert args.ignore_stdin
    assert args.timeout
    assert args.download
    assert args.download_resume
    assert args.output_file
    assert args.output_file_specified
    assert args.output_options
    assert args.output_options_history
    assert args.prettify
    assert args.format_options
    assert args.method
    assert args.url
    assert args.request_items
    assert args.headers
    assert args.data

# Generated at 2022-06-17 19:40:01.335910
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test for method parse_args of class HTTPieArgumentParser
    # This method tests the parse_args method of the HTTPieArgumentParser class.
    # It tests the method by passing in a list of arguments and checking whether
    # the method returns the correct output.
    #
    # Input to the method:
    #     args: A list of arguments to be parsed.
    #
    # Expected output from the method:
    #     A Namespace object containing the parsed arguments.

    # Test 1: Test the method with a list of arguments containing the --json
    # option.
    args = ['--json']
    parser = HTTPieArgumentParser()
    output = parser.parse_args(args)
    assert output.json == True

    # Test 2: Test the method with a list of arguments containing the --form
    # option.
   

# Generated at 2022-06-17 19:40:09.995047
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--json', '{"a": 1}', 'https://httpbin.org/get'])
    assert args.json == {"a": 1}
    assert args.url == 'https://httpbin.org/get'
    assert args.headers == []
    assert args.data == []
    assert args.files == {}
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.download == False
    assert args.download_resume == False
    assert args.output_options == 'Hhb'

# Generated at 2022-06-17 19:40:19.138767
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test HTTPieArgumentParser.parse_args()
    # Test HTTPieArgumentParser.parse_args() with no arguments
    parser = HTTPieArgumentParser()
    args = parser.parse_args([])
    assert args.url == 'https://httpie.org'
    assert args.method == 'GET'
    assert args.headers == []
    assert args.data == []
    assert args.files == []
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.ignore_netrc == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.max_redirects == None
    assert args.follow == False
    assert args.output

# Generated at 2022-06-17 19:40:30.300063
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help
    args = parser.parse_args(['--version'])
    assert args.version
    args = parser.parse_args(['--traceback'])
    assert args.traceback
    args = parser.parse_args(['--debug'])
    assert args.debug
    args = parser.parse_args(['--download'])
    assert args.download
    args = parser.parse_args(['--download-resume'])
    assert args.download_resume
    args = parser.parse_args(['--download-resume', '--download'])
    assert args.download_resume

# Generated at 2022-06-17 19:40:38.217128
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == []
    assert args.files == []
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.follow == False
    assert args.timeout == None
    assert args.max_redirects == None
    assert args.check_status == False
    assert args.headers_off == False
    assert args.body_off == False
    assert args.style == None
    assert args.style_off == False
    assert args.download == False

# Generated at 2022-06-17 19:40:44.081452
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == 'https://httpie.org'
    assert args.method == 'GET'
    assert args.headers == []
    assert args.data == []
    assert args.params == []
    assert args.files == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.output_options == 'Hb'
    assert args.output_options_history == 'Hb'
    assert args.prettify == 'all'
    assert args.download == False
    assert args.download_resume == False
    assert args.follow == False
    assert args

# Generated at 2022-06-17 19:40:58.305760
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:41:07.988015
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:41:19.118854
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.files == None
    assert args.params == None
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.allow_redirects == True
    assert args.max_redirects == 10
    assert args.follow_redirects == True
    assert args.check_status == True
    assert args.headers_off == False
    assert args.body_off == False
    assert args.style == None
   

# Generated at 2022-06-17 19:42:41.732274
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--json', '{"key": "value"}', 'http://example.com/'])
    assert args.json == {"key": "value"}
    assert args.url == 'http://example.com/'

# Generated at 2022-06-17 19:42:48.907226
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help == True
    args = parser.parse_args(['--version'])
    assert args.version == True
    args = parser.parse_args(['--traceback'])
    assert args.traceback == True
    args = parser.parse_args(['--debug'])
    assert args.debug == True
    args = parser.parse_args(['--download'])
    assert args.download == True
    args = parser.parse_args(['--download-resume'])
    assert args.download_resume == True
    args = parser.parse_args(['--offline'])
    assert args.offline == True
    args = parser.parse_args(['--ignore-stdin'])


# Generated at 2022-06-17 19:42:59.665762
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:43:09.665364
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:43:16.412513
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.files == {}
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.max_redirects == None
    assert args.follow == False
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.download == False
    assert args.download_resume == False

# Generated at 2022-06-17 19:43:26.416210
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http://httpbin.org/get'])
    assert args.url == 'http://httpbin.org/get'
    assert args.method == 'GET'
    assert args.headers == []
    assert args.data == []
    assert args.params == []
    assert args.files == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.output_options == 'Hhb'
    assert args.output_options_history == 'Hhb'
    assert args.prettify == 'all'
    assert args.download == False

# Generated at 2022-06-17 19:43:37.897017
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == 'https://httpie.org'
    assert args.method == 'GET'
    assert args.headers == []
    assert args.data == []
    assert args.files == []
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.verify_ssl_certs == True
    assert args.cert == None
    assert args.cert_key == None
    assert args.cert_key_password == None
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.output_

# Generated at 2022-06-17 19:43:48.525946
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http', 'http://httpbin.org/get'])
    assert args.url == 'http://httpbin.org/get'
    assert args.method == 'GET'
    assert args.headers == {}
    assert args.data == {}
    assert args.params == {}
    assert args.files == {}
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.output_options == 'H'
    assert args.output_options_history == 'H'
    assert args.prettify == 'all'
    assert args.download == False
    assert args.download_resume == False

# Generated at 2022-06-17 19:43:58.472091
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:44:00.275134
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help == True


# Generated at 2022-06-17 19:46:58.593860
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:47:09.318115
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args()
    assert args.headers == {}
    assert args.data == {}
    assert args.params == {}
    assert args.files == {}
    assert args.output_file == None
    assert args.output_options == 'H'
    assert args.output_options_history == 'H'
    assert args.prettify == 'all'
    assert args.download == False
    assert args.download_resume == False
    assert args.method == 'GET'
    assert args.url == None
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.ignore_netrc == False
    assert args.ignore_stdin == False
    assert args.timeout == None

# Generated at 2022-06-17 19:47:16.323270
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.params == []
    assert args.files == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.cert == None
    assert args.timeout == None
    assert args.max_redirects == 30
    assert args.follow == False
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.download == False
    assert args.download_resume == False

# Generated at 2022-06-17 19:47:25.163670
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:47:35.270351
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:47:46.228549
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:47:56.400698
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == []
    assert args.params == []
    assert args.files == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.max_redirects == None
    assert args.follow == False
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.download == False
    assert args.download_resume == False

# Generated at 2022-06-17 19:48:05.650725
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:48:15.158967
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.params == []
    assert args.files == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.allow_redirects == True
    assert args.max_redirects == 10
    assert args.follow_redirects == True
    assert args.check_status == True
    assert args.headers_off == False
    assert args.body_off == False
    assert args.verbose == False


# Generated at 2022-06-17 19:48:21.717894
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with the default arguments
    args = HTTPieArgumentParser().parse_args()
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.output_options == 'H'
    assert args.output_options_history == 'H'
    assert args.prettify == 'all'
    assert args.download == False
    assert args.download_resume == False
    assert args.format == 'json'
    assert args.headers == []
    assert args.ignore_stdin == False
    assert args.method == 'GET'
    assert args.output_options == 'H'
    assert args.output_options_history == 'H'
    assert args.params == []
    assert args.prettify == 'all'
    assert args.print_body == True
    assert args