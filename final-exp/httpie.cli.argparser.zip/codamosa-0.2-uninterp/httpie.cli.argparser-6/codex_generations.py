

# Generated at 2022-06-17 19:39:49.282359
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.files == {}
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.max_redirects == None
    assert args.follow == False
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.download == False
    assert args.download_resume == False

# Generated at 2022-06-17 19:40:01.725404
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:40:02.897904
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO: implement
    pass


# Generated at 2022-06-17 19:40:10.152491
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:40:19.181039
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:40:26.960307
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = HTTPieArgumentParser().parse_args(['http', 'httpbin.org'])
    assert args.url == 'httpbin.org'
    assert args.method == 'GET'
    assert args.headers == []
    assert args.data == []
    assert args.files == []
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.output_options == 'H'
    assert args.output_options_history == 'H'
    assert args.prettify == 'all'
    assert args.download == False
    assert args.download_resume == False
    assert args.format_options == PARSED_DE

# Generated at 2022-06-17 19:40:35.925501
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--version'])
    assert args.version == True
    args = parser.parse_args(['--traceback'])
    assert args.traceback == True
    args = parser.parse_args(['--debug'])
    assert args.debug == True
    args = parser.parse_args(['--pretty'])
    assert args.pretty == 'all'
    args = parser.parse_args(['--style'])
    assert args.style == 'all'
    args = parser.parse_args(['--print'])
    assert args.print == 'hb'
    args = parser.parse_args(['--print'])
    assert args.print == 'hb'
    args = parser.parse_args(['--download'])
   

# Generated at 2022-06-17 19:40:40.564426
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:40:48.336848
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:40:50.842349
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help


# Generated at 2022-06-17 19:41:45.461386
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:41:48.771672
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help


# Generated at 2022-06-17 19:41:56.916005
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:42:03.301668
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help
    args = parser.parse_args(['--version'])
    assert args.version
    args = parser.parse_args(['--traceback'])
    assert args.traceback
    args = parser.parse_args(['--debug'])
    assert args.debug
    args = parser.parse_args(['--ignore-stdin'])
    assert args.ignore_stdin
    args = parser.parse_args(['--timeout', '10'])
    assert args.timeout == 10
    args = parser.parse_args(['--check-status'])
    assert args.check_status
    args = parser.parse_args(['--follow'])
    assert args.follow
    args = parser

# Generated at 2022-06-17 19:42:11.891046
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == 'https://httpie.org'
    assert args.method == 'GET'
    assert args.headers == []
    assert args.data == []
    assert args.files == []
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.output_options == 'H'
    assert args.output_options_history == 'H'
    assert args.prettify == 'all'
    assert args.download == False
    assert args.download_resume == False
    assert args.format == 'json'
    assert args

# Generated at 2022-06-17 19:42:21.942626
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:42:30.944281
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http', 'httpbin.org', 'get'])
    assert args.url == 'http://httpbin.org/get'
    assert args.method == 'GET'
    assert args.headers == {}
    assert args.data == {}
    assert args.files == {}
    assert args.params == {}
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.output_options == 'Hhb'
    assert args.output_options_history == 'Hhb'
    assert args.prettify == 'all'
    assert args.download == False
    assert args.download_res

# Generated at 2022-06-17 19:42:42.759693
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--json', '{"foo": "bar"}', 'httpbin.org/post'])
    assert args.json == {"foo": "bar"}
    assert args.url == 'httpbin.org/post'
    assert args.headers == {}
    assert args.method == 'POST'
    assert args.data == {}
    assert args.files == {}
    assert args.params == {}
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.cert == None
    assert args.timeout == None
    assert args.max_redirects == None
    assert args.follow_redirects == True
    assert args.output_file == None


# Generated at 2022-06-17 19:42:47.050765
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--json', '--headers', '--pretty=all', '--output=output.txt', 'http://httpbin.org/get'])
    assert args.json == True
    assert args.headers == True
    assert args.pretty == 'all'
    assert args.output == 'output.txt'
    assert args.url == 'http://httpbin.org/get'

# Generated at 2022-06-17 19:42:59.034369
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == None
    assert args.data == None
    assert args.params == None
    assert args.files == None
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.output_file == None
    assert args.output_file_specified == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.prettify == None
    assert args.download == None
    assert args.download_resume == None
    assert args.timeout == None
    assert args.max_redirects == None

# Generated at 2022-06-17 19:44:29.001588
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == 'https://httpbin.org/'
    assert args.method == 'GET'
    assert args.headers == {}
    assert args.data == {}
    assert args.params == {}
    assert args.files == {}
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.ignore_stdin == False
    assert args.timeout == None
    assert args.max_redirects == None
    assert args.check_status == False
    assert args.follow_redirects == True
    assert args.stream == False
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.download == False


# Generated at 2022-06-17 19:44:36.388567
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:44:44.598097
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.files == None
    assert args.params == None
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.follow == False
    assert args.timeout == None
    assert args.max_redirects == None
    assert args.check_status == False
    assert args.headers_off == False
    assert args.body_off == False
    assert args.style == None
    assert args.style_off == False
    assert args.download == False

# Generated at 2022-06-17 19:44:56.667403
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.request_items == []
    assert args.headers == []
    assert args.data == None
    assert args.files == {}
    assert args.params == []
    assert args.multipart_data == []
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.output_file_specified == False
    assert args.download == False
    assert args.download_resume == False
    assert args.download_output_file_specified == False
    assert args.download_output_file == None
    assert args.download_output_dir == None
    assert args.download_

# Generated at 2022-06-17 19:45:06.109633
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:45:08.290853
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help


# Generated at 2022-06-17 19:45:12.576898
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--json', '{"foo": "bar"}', 'http://httpbin.org/post'])
    assert args.json == {"foo": "bar"}
    assert args.url == 'http://httpbin.org/post'

# Generated at 2022-06-17 19:45:22.455050
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == 'https://httpie.org'
    assert args.method == 'GET'
    assert args.headers == []
    assert args.data == []
    assert args.files == []
    assert args.params == []
    assert args.output_file == None
    assert args.output_options == 'H'
    assert args.output_options_history == 'H'
    assert args.prettify == 'all'
    assert args.download == False
    assert args.download_resume == False
    assert args.format == 'json'
    assert args.format_options == {}
    assert args.style == 'solarized'
    assert args.style_options == {}
    assert args.verbose == False

# Generated at 2022-06-17 19:45:29.019335
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test for method parse_args of class HTTPieArgumentParser
    # This method tests the parse_args method of the HTTPieArgumentParser class
    # It creates an instance of the HTTPieArgumentParser class and then calls the parse_args method
    # on it. It then checks the values of the attributes of the instance to ensure that they are
    # correct.
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:45:36.861139
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == []
    assert args.files == []
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.max_redirects == None
    assert args.follow == False
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.download == False
    assert args.download_resume == False

# Generated at 2022-06-17 19:48:46.589750
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == 'https://httpbin.org/'
    assert args.method == 'GET'
    assert args.headers == []
    assert args.data == []
    assert args.files == []
    assert args.params == []
    assert args.output_file == None
    assert args.output_options == 'H'
    assert args.output_options_history == 'H'
    assert args.verbose == False
    assert args.all == False
    assert args.check_status == False
    assert args.download == False
    assert args.download_resume == False
    assert args.follow == False
    assert args.ignore_stdin == False
    assert args.offline == False
    assert args.output_file_specified

# Generated at 2022-06-17 19:48:52.565923
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--json', '{"a": "b"}', 'http://httpbin.org/post'])
    assert args.json == {"a": "b"}
    assert args.url == "http://httpbin.org/post"
    assert args.headers == []
    assert args.data == []
    assert args.files == {}
    assert args.params == []
    assert args.method == "POST"
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.cert == None
    assert args.timeout == None
    assert args.max_redirects == 30
    assert args.follow_redirects == True
    assert args.output_