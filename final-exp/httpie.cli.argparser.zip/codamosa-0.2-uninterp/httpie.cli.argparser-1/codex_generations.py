

# Generated at 2022-06-17 19:39:49.561123
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.files == None
    assert args.params == None
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.allow_redirects == True
    assert args.max_redirects == 10
    assert args.follow_redirects == True
    assert args.check_status == True
    assert args.headers_off == False
    assert args.body_off == False
    assert args.style == None
   

# Generated at 2022-06-17 19:40:02.039187
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help
    args = parser.parse_args(['--version'])
    assert args.version
    args = parser.parse_args(['--traceback'])
    assert args.traceback
    args = parser.parse_args(['--debug'])
    assert args.debug
    args = parser.parse_args(['--verbose'])
    assert args.verbose
    args = parser.parse_args(['--output', 'file'])
    assert args.output_file == 'file'
    args = parser.parse_args(['--output-file', 'file'])
    assert args.output_file == 'file'

# Generated at 2022-06-17 19:40:10.002124
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.files == None
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.follow == False
    assert args.max_redirects == None
    assert args.timeout == None
    assert args.check_status == False
    assert args.headers_off == False
    assert args.body_off == False
    assert args.style == None
    assert args.style_off == False
    assert args.print_headers

# Generated at 2022-06-17 19:40:19.020366
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.files == None
    assert args.params == None
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.max_redirects == None
    assert args.follow == False
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.verbose == False
    assert args.debug == False

# Generated at 2022-06-17 19:40:21.246990
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help


# Generated at 2022-06-17 19:40:32.105545
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help == True
    args = parser.parse_args(['--version'])
    assert args.version == True
    args = parser.parse_args(['--traceback'])
    assert args.traceback == True
    args = parser.parse_args(['--debug'])
    assert args.debug == True
    args = parser.parse_args(['--pretty'])
    assert args.pretty == 'all'
    args = parser.parse_args(['--style'])
    assert args.style == 'all'
    args = parser.parse_args(['--print'])
    assert args.print == 'hb'
    args = parser.parse_args(['--print'])

# Generated at 2022-06-17 19:40:38.063372
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--json', '{"foo": "bar"}', 'http://httpbin.org/get'])
    assert args.json == {"foo": "bar"}
    assert args.url == 'http://httpbin.org/get'

# Generated at 2022-06-17 19:40:39.528184
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test HTTPieArgumentParser.parse_args
    # TODO: implement this test
    raise NotImplementedError()


# Generated at 2022-06-17 19:40:47.820344
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == None
    assert args.data == None
    assert args.files == None
    assert args.params == None
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.ignore_netrc == False
    assert args.ignore_stdin == False
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.download == False
    assert args.download_resume == False
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.prettify == None

# Generated at 2022-06-17 19:40:56.651511
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.files == None
    assert args.params == None
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.allow_redirects == True
    assert args.max_redirects == 10
    assert args.follow == False
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.download == False
    assert args

# Generated at 2022-06-17 19:41:58.223322
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.params == []
    assert args.files == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.max_redirects == None
    assert args.follow == False
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.verbose == False
    assert args.debug == False

# Generated at 2022-06-17 19:42:05.167454
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == 'https://httpie.org'
    assert args.method == 'GET'
    assert args.headers == []
    assert args.data == []
    assert args.files == []
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.output_options == 'H'
    assert args.output_options_history == 'H'
    assert args.prettify == 'all'
    assert args.download == False
    assert args.download_resume == False
    assert args.format == 'json'
    assert args

# Generated at 2022-06-17 19:42:06.501857
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = HTTPieArgumentParser().parse_args(['--help'])
    assert args.help


# Generated at 2022-06-17 19:42:13.663845
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:42:23.233940
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:42:31.919453
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == 'https://httpbin.org/'
    assert args.method == 'GET'
    assert args.headers == []
    assert args.data == []
    assert args.files == []
    assert args.params == []
    assert args.output_file == None
    assert args.output_options == 'H'
    assert args.output_options_history == 'H'
    assert args.prettify == 'all'
    assert args.download == False
    assert args.download_resume == False
    assert args.format == 'json'
    assert args.format_options == PARSED_DEFAULT_FORMAT_OPTIONS
    assert args.style == 'solarized'

# Generated at 2022-06-17 19:42:43.124239
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args()
    assert args.url == 'https://httpie.org'
    assert args.method == 'GET'
    assert args.headers == []
    assert args.data == []
    assert args.files == []
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.max_redirects == None
    assert args.follow == False
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.output_options == 'Hhb'

# Generated at 2022-06-17 19:42:57.423798
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:43:06.823361
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Create a mock argument parser
    parser = HTTPieArgumentParser()
    # Create a mock argument list

# Generated at 2022-06-17 19:43:08.658519
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help

# Generated at 2022-06-17 19:44:44.401696
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http://httpbin.org/get'])
    assert args.url == 'http://httpbin.org/get'
    assert args.method == 'GET'
    assert args.headers == []
    assert args.data == []
    assert args.params == []
    assert args.files == {}
    assert args.output_file == None
    assert args.output_options == 'H'
    assert args.output_options_history == 'H'
    assert args.prettify == 'all'
    assert args.download == False
    assert args.download_resume == False
    assert args.format_options == {'style': 'default', 'colors': '256', 'format': 'pretty'}
    assert args.auth == None

# Generated at 2022-06-17 19:44:47.952215
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help


# Generated at 2022-06-17 19:44:57.660404
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == None
    assert args.data == None
    assert args.params == None
    assert args.files == None
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.output_file == None
    assert args.output_file_specified == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.prettify == None
    assert args.download == None
    assert args.download_resume == None
    assert args.form == None
    assert args.ignore_stdin == None

# Generated at 2022-06-17 19:44:59.600688
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO: Implement unit test for method parse_args of class HTTPieArgumentParser
    pass


# Generated at 2022-06-17 19:45:11.598891
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help
    args = parser.parse_args(['--version'])
    assert args.version
    args = parser.parse_args(['--traceback'])
    assert args.traceback
    args = parser.parse_args(['--ignore-stdin'])
    assert args.ignore_stdin
    args = parser.parse_args(['--pretty', 'all'])
    assert args.prettify == 'all'
    args = parser.parse_args(['--print', 'hb'])
    assert args.output_options == 'hb'
    args = parser.parse_args(['--print', 'hb', '--print-resume'])
    assert args.output_options_history

# Generated at 2022-06-17 19:45:21.621621
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http://httpbin.org/get', '--json'])
    assert args.json
    assert args.url == 'http://httpbin.org/get'
    assert args.method == 'GET'
    assert args.headers == {}
    assert args.data == {}
    assert args.files == {}
    assert args.params == {}
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.ssl == None
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.download == False
    assert args.download_resume == False

# Generated at 2022-06-17 19:45:27.048781
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help
    assert not args.version
    assert not args.traceback
    assert not args.check_status
    assert not args.download
    assert not args.download_resume
    assert not args.download_all
    assert not args.download_all_resume
    assert not args.download_all_prefer
    assert not args.download_all_prefer_insecure
    assert not args.download_all_insecure
    assert not args.download_all_verify
    assert not args.download_all_verify_insecure
    assert not args.download_all_verify_prefer
    assert not args.download_all_verify_prefer_insecure
    assert not args.download_

# Generated at 2022-06-17 19:45:35.757749
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http://httpbin.org/get'])
    assert args.url == 'http://httpbin.org/get'
    assert args.method == 'GET'
    assert args.headers == {}
    assert args.data == {}
    assert args.files == {}
    assert args.params == {}
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.output_options == 'Hhb'
    assert args.output_options_history == 'Hhb'
    assert args.prettify == 'all'
    assert args.download == False

# Generated at 2022-06-17 19:45:47.297857
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:45:58.199034
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.parse_args(['--help'])
    parser.parse_args(['--version'])
    parser.parse_args(['--debug'])
    parser.parse_args(['--traceback'])
    parser.parse_args(['--ignore-stdin'])
    parser.parse_args(['--download'])
    parser.parse_args(['--download-resume'])
    parser.parse_args(['--offline'])
    parser.parse_args(['--verbose'])
    parser.parse_args(['--all'])
    parser.parse_args(['--form'])
    parser.parse_args(['--pretty'])
    parser.parse_args(['--style'])

# Generated at 2022-06-17 19:47:56.880218
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url is None
    assert args.method is None
    assert args.headers == []
    assert args.data == []
    assert args.files == []
    assert args.params == []
    assert args.auth is None
    assert args.auth_type is None
    assert args.auth_plugin is None
    assert args.output_file is None
    assert args.output_file_specified is False
    assert args.download is False
    assert args.download_resume is False
    assert args.output_options is None
    assert args.output_options_history is None
    assert args.prettify is None
    assert args.style is None
    assert args.style_sheet is None
    assert args.verbose is False
   

# Generated at 2022-06-17 19:48:05.997516
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == []
    assert args.files == []
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.max_redirects == None
    assert args.follow == False
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.download == False
    assert args.download_resume == False

# Generated at 2022-06-17 19:48:15.330691
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:48:16.660847
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO: implement test
    pass


# Generated at 2022-06-17 19:48:20.429535
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--json', '{"hello": "world"}', 'http://httpbin.org/post'])
    assert args.json == {"hello": "world"}
    assert args.url == 'http://httpbin.org/post'


# Generated at 2022-06-17 19:48:27.091450
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:48:35.032032
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help == True
    args = parser.parse_args(['--version'])
    assert args.version == True
    args = parser.parse_args(['--traceback'])
    assert args.traceback == True
    args = parser.parse_args(['--debug'])
    assert args.debug == True
    args = parser.parse_args(['--verbose'])
    assert args.verbose == True
    args = parser.parse_args(['--output', 'file'])
    assert args.output_file == 'file'
    args = parser.parse_args(['--output-file', 'file'])
    assert args.output_file == 'file'
    args = parser.parse_args

# Generated at 2022-06-17 19:48:44.962530
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == None
    assert args.data == None
    assert args.files == None
    assert args.params == None
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.follow == False
    assert args.max_redirects == None
    assert args.timeout == None
    assert args.check_status == False
    assert args.headers_off == False
    assert args.body_off == False
    assert args.style == None
    assert args.style_off == False
    assert args.download == False

# Generated at 2022-06-17 19:48:54.305223
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test for method parse_args of class HTTPieArgumentParser
    # This method tests the parse_args method of the HTTPieArgumentParser class
    # It tests the method with a variety of inputs and checks the output against the expected output
    # Inputs:
    #   args: a list of strings to be parsed
    # Outputs:
    #   args: the parsed arguments
    # Exceptions:
    #   None

    # Test 1: Test with no arguments
    args = []
    parser = HTTPieArgumentParser()
    args = parser.parse_args(args)
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.files == {}
    assert args.params == []
    assert args.auth == None
    assert args.auth_