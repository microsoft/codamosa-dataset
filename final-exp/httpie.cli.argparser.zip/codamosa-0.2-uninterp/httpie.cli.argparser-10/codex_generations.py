

# Generated at 2022-06-17 19:39:45.468174
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.files == None
    assert args.params == None
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.follow == False
    assert args.max_redirects == None
    assert args.timeout == None
    assert args.check_status == False
    assert args.headers_off == False
    assert args.body_off == False
    assert args.style == None
    assert args.style_off == False
    assert args.download == False

# Generated at 2022-06-17 19:39:48.190488
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test for method parse_args of class HTTPieArgumentParser
    # This method is tested indirectly by test_main()
    pass


# Generated at 2022-06-17 19:40:00.551118
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http://httpbin.org/get'])
    assert args.url == 'http://httpbin.org/get'
    assert args.method == 'GET'
    assert args.headers == {}
    assert args.data == {}
    assert args.params == {}
    assert args.files == {}
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.output_options == 'Hhb'
    assert args.output_options_history == 'Hhb'
    assert args.download == False
    assert args.download_resume == False
    assert args.download_all == False


# Generated at 2022-06-17 19:40:09.957918
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test for method parse_args of class HTTPieArgumentParser
    # This method tests the parse_args method of the HTTPieArgumentParser class
    # It creates an instance of the class and calls the parse_args method
    # It then checks if the returned value is an instance of the Namespace class
    # It also checks if the returned value has the correct attributes
    parser = HTTPieArgumentParser()
    args = parser.parse_args()
    assert isinstance(args, argparse.Namespace)
    assert hasattr(args, 'url')
    assert hasattr(args, 'method')
    assert hasattr(args, 'headers')
    assert hasattr(args, 'data')
    assert hasattr(args, 'files')
    assert hasattr(args, 'params')
    assert hasattr(args, 'auth')
    assert hasattr

# Generated at 2022-06-17 19:40:19.151445
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = ['--json', '{"foo": "bar"}', 'http://httpbin.org/post']
    parser = HTTPieArgumentParser()
    args = parser.parse_args(args)
    assert args.json == {'foo': 'bar'}
    assert args.url == 'http://httpbin.org/post'
    assert args.headers == {}
    assert args.data == {}
    assert args.files == {}
    assert args.params == {}
    assert args.method == 'POST'
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.download == False
    assert args.download_resume == False

# Generated at 2022-06-17 19:40:26.933249
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--json', '{"a": "b"}', 'https://httpbin.org/get'])
    assert args.json == {"a": "b"}
    assert args.url == 'https://httpbin.org/get'
    assert args.headers == []
    assert args.data == []
    assert args.files == {}
    assert args.params == []
    assert args.method == 'GET'
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.timeout == None
    assert args.max_redirects == 30
    assert args.verify == True
    assert args.cert == None
    assert args.download == False
    assert args.download_resume == False

# Generated at 2022-06-17 19:40:35.887755
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http', 'httpbin.org/get'])
    assert args.url == 'httpbin.org/get'
    assert args.method == 'GET'
    assert args.headers == []
    assert args.data == []
    assert args.files == []
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.ignore_netrc == False
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.output_options == 'HhB'
    assert args.output_options_history == 'HhB'
    assert args.download == False
    assert args.download_resume == False


# Generated at 2022-06-17 19:40:45.732567
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http', 'httpbin.org'])
    assert args.url == 'httpbin.org'
    assert args.method == 'GET'
    assert args.headers == []
    assert args.data == []
    assert args.params == []
    assert args.files == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.download == False
    assert args.download_resume == False
    assert args.output_options == 'H'
    assert args.output_options_history == 'H'
    assert args.prettify == 'all'

# Generated at 2022-06-17 19:40:58.624955
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:41:08.851437
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--json', '{"a": "b"}', 'https://httpbin.org/post'])
    assert args.json == {"a": "b"}
    assert args.url == 'https://httpbin.org/post'
    assert args.headers == []
    assert args.data == []
    assert args.files == []
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.ignore_stdin == False
    assert args.method == 'POST'
    assert args.form == False
    assert args.pretty == 'all'
    assert args.style == 'solarized'
    assert args.print == 'H'
    assert args.download

# Generated at 2022-06-17 19:42:05.514814
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help
    args = parser.parse_args(['--version'])
    assert args.version
    args = parser.parse_args(['--traceback'])
    assert args.traceback
    args = parser.parse_args(['--debug'])
    assert args.debug
    args = parser.parse_args(['--json'])
    assert args.json
    args = parser.parse_args(['--pretty'])
    assert args.pretty
    args = parser.parse_args(['--style'])
    assert args.style
    args = parser.parse_args(['--download'])
    assert args.download
    args = parser.parse_args(['--download-resume'])
   

# Generated at 2022-06-17 19:42:10.642787
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http://httpbin.org/get'])
    assert args.url == 'http://httpbin.org/get'
    assert args.method == 'GET'
    assert args.headers == {}
    assert args.data == {}
    assert args.params == {}
    assert args.files == {}
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.output_options == 'Hhb'
    assert args.output_options_history == 'Hhb'
    assert args.prettify == 'all'
    assert args.download == False

# Generated at 2022-06-17 19:42:21.345426
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:42:30.801418
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == None
    assert args.data == None
    assert args.params == None
    assert args.files == None
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.max_redirects == 30
    assert args.follow == False
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.download == False
    assert args.download_resume == False

# Generated at 2022-06-17 19:42:42.755783
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:42:52.927577
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--version'])
    assert args.version
    assert not args.debug
    assert not args.traceback
    assert not args.check_ssl
    assert not args.ignore_stdin
    assert not args.ignore_netrc
    assert not args.download
    assert not args.download_resume
    assert not args.output_file_specified
    assert not args.output_file
    assert not args.output_options
    assert not args.output_options_history
    assert not args.prettify
    assert not args.style
    assert not args.style_sheet
    assert not args.verbose
    assert not args.headers
    assert not args.data
    assert not args.files
    assert not args.params
    assert not args.auth

# Generated at 2022-06-17 19:43:03.414764
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test HTTPieArgumentParser.parse_args()
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http', 'httpbin.org', '--json'])
    assert args.url == 'httpbin.org'
    assert args.json == True
    assert args.headers == None
    assert args.data == None
    assert args.files == None
    assert args.params == None
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.cert == None
    assert args.timeout == None
    assert args.max_redirects == None
    assert args.follow == False
    assert args.method == None
    assert args.output_file == None
    assert args.output_

# Generated at 2022-06-17 19:43:13.129275
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:43:22.997199
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args(args=[])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.files == {}
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.allow_redirects == True
    assert args.max_redirects == 10
    assert args.follow_redirects == True
    assert args.check_status == True
    assert args.headers_off == False
    assert args.body_off == False

# Generated at 2022-06-17 19:43:30.946649
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--json', '{"foo": "bar"}', 'http://httpbin.org/post'])
    assert args.json == '{"foo": "bar"}'
    assert args.url == 'http://httpbin.org/post'
    assert args.method == 'POST'
    assert args.headers == [('Content-Type', 'application/json')]
    assert args.data == '{"foo": "bar"}'
    assert args.files == {}
    assert args.params == {}
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.ignore_stdin == False
    assert args.ignore_netrc == False
    assert args.output_file == None

# Generated at 2022-06-17 19:45:17.118424
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help
    args = parser.parse_args(['--version'])
    assert args.version
    args = parser.parse_args(['--traceback'])
    assert args.traceback
    args = parser.parse_args(['--debug'])
    assert args.debug
    args = parser.parse_args(['--json'])
    assert args.json
    args = parser.parse_args(['--form'])
    assert args.form
    args = parser.parse_args(['--pretty', 'all'])
    assert args.prettify == 'all'
    args = parser.parse_args(['--style', 'solarized'])
    assert args.style == 'solarized'

# Generated at 2022-06-17 19:45:21.198032
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--json', '{"foo": "bar"}', 'http://httpbin.org/post'])
    assert args.json == {"foo": "bar"}
    assert args.url == 'http://httpbin.org/post'


# Generated at 2022-06-17 19:45:28.417997
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help
    args = parser.parse_args(['--version'])
    assert args.version
    args = parser.parse_args(['--traceback'])
    assert args.traceback
    args = parser.parse_args(['--debug'])
    assert args.debug
    args = parser.parse_args(['--verbose'])
    assert args.verbose
    args = parser.parse_args(['--quiet'])
    assert args.quiet
    args = parser.parse_args(['--output', 'file'])
    assert args.output_file == 'file'
    args = parser.parse_args(['--output-file', 'file'])

# Generated at 2022-06-17 19:45:36.587572
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.parse_args(['--help'])
    parser.parse_args(['--version'])
    parser.parse_args(['--traceback'])
    parser.parse_args(['--debug'])
    parser.parse_args(['--ignore-stdin'])
    parser.parse_args(['--download'])
    parser.parse_args(['--download-resume'])
    parser.parse_args(['--output', 'file'])
    parser.parse_args(['--output-dir', 'dir'])
    parser.parse_args(['--output-file', 'file'])
    parser.parse_args(['--output-file-append'])
    parser.parse_args(['--output-file-prefix', 'prefix'])
    parser

# Generated at 2022-06-17 19:45:47.398645
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.files == []
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.follow == False
    assert args.timeout == None
    assert args.max_redirects == None
    assert args.check_status == False
    assert args.headers_off == False
    assert args.body_off == False
    assert args.style == None
    assert args.style_off == False
    assert args.print_headers

# Generated at 2022-06-17 19:45:50.312478
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test for method parse_args of class HTTPieArgumentParser
    # This method is not tested because it is a wrapper for argparse.ArgumentParser.parse_args
    pass


# Generated at 2022-06-17 19:45:59.913228
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.params == []
    assert args.files == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.prettify == None
    assert args.download == False
    assert args.download_resume == False
    assert args.verbose == False
    assert args.traceback == False
    assert args.check_status == False


# Generated at 2022-06-17 19:46:09.120345
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == []
    assert args.files == []
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.max_redirects == 30
    assert args.follow == False
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.download == False
    assert args.download_resume == False

# Generated at 2022-06-17 19:46:19.624521
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test 1
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help == True
    # Test 2
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--version'])
    assert args.version == True
    # Test 3
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--traceback'])
    assert args.traceback == True
    # Test 4
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--debug'])
    assert args.debug == True
    # Test 5
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--verbose'])
    assert args.verbose == True
    # Test 6


# Generated at 2022-06-17 19:46:27.636962
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()