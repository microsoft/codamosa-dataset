

# Generated at 2022-06-17 19:39:48.700650
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.files == {}
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.max_redirects == 30
    assert args.follow_redirects == True
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.download == False
    assert args.download_resume == False


# Generated at 2022-06-17 19:40:01.092190
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == []
    assert args.params == []
    assert args.files == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.allow_redirects == True
    assert args.max_redirects == 10
    assert args.follow_redirects == True
    assert args.check_status == True
    assert args.headers_off == False
    assert args.body_off == False
    assert args.verbose == False


# Generated at 2022-06-17 19:40:05.854679
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = ['--method', 'GET', '--auth', 'user:pass', 'http://httpbin.org/get']
    parser = HTTPieArgumentParser()
    args = parser.parse_args(args)
    assert args.method == 'GET'
    assert args.auth == 'user:pass'
    assert args.url == 'http://httpbin.org/get'

# Generated at 2022-06-17 19:40:15.942782
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:40:24.010646
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http://httpbin.org/get'])
    assert args.url == 'http://httpbin.org/get'
    assert args.method == 'GET'
    assert args.headers == {}
    assert args.data == {}
    assert args.files == {}
    assert args.params == {}
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.timeout == None
    assert args.verify == True
    assert args.cert == None
    assert args.proxy == None
    assert args.allow_redirects == True
    assert args.max_redirects == 10
    assert args.follow == False
    assert args.style == None
    assert args.style_sheet

# Generated at 2022-06-17 19:40:34.188575
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:40:45.301359
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.files == None
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.max_redirects == 30
    assert args.follow_redirects == True
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.pretty == None
    assert args.download == False
    assert args

# Generated at 2022-06-17 19:40:58.573789
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:41:08.163022
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:41:19.268245
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--json', '{"a": "b"}', 'http://httpbin.org/post'])
    assert args.json == {"a": "b"}
    assert args.url == "http://httpbin.org/post"
    assert args.headers is None
    assert args.auth is None
    assert args.auth_type is None
    assert args.auth_plugin is None
    assert args.ignore_stdin is False
    assert args.method is None
    assert args.data is None
    assert args.form is False
    assert args.files is None
    assert args.params is None
    assert args.output_file is None
    assert args.output_file_specified is False
    assert args.download is False

# Generated at 2022-06-17 19:42:52.662607
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http', 'http://httpbin.org/get'])
    assert args.url == 'http://httpbin.org/get'
    assert args.method == 'GET'
    assert args.headers == []
    assert args.data == {}
    assert args.files == {}
    assert args.params == {}
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.output_file == None
    assert args.output_options == 'H'
    assert args.output_options_history == 'H'
    assert args.output_file_specified == False
    assert args.download == False
    assert args.download_resume == False

# Generated at 2022-06-17 19:43:03.216629
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == None
    assert args.data == None
    assert args.params == None
    assert args.files == None
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.proxy == None
    assert args.timeout == None
    assert args.max_redirects == None
    assert args.follow == False
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.download == False
    assert args.download_resume == False

# Generated at 2022-06-17 19:43:12.981757
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-17 19:43:22.863817
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:43:30.836829
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.files == {}
    assert args.params == []
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.download == False
    assert args.download_resume == False
    assert args.download_all_urls == False
    assert args.download_all_urls_file == None
    assert args.download_all_urls_file_type == None
    assert args.download_all_urls_file_type_force == False
    assert args.download_all_urls_file_type

# Generated at 2022-06-17 19:43:40.270779
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:43:49.486108
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help
    args = parser.parse_args(['--version'])
    assert args.version
    args = parser.parse_args(['--debug'])
    assert args.debug
    args = parser.parse_args(['--traceback'])
    assert args.traceback
    args = parser.parse_args(['--check-status'])
    assert args.check_status
    args = parser.parse_args(['--follow'])
    assert args.follow
    args = parser.parse_args(['--max-redirects', '10'])
    assert args.max_redirects == 10
    args = parser.parse_args(['--timeout', '10'])
    assert args.timeout

# Generated at 2022-06-17 19:43:58.875116
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http://httpbin.org/get'])
    assert args.url == 'http://httpbin.org/get'
    assert args.method == 'GET'
    assert args.headers == []
    assert args.data == []
    assert args.params == []
    assert args.files == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.verify_all == False
    assert args.cert == None
    assert args.cert_key == None
    assert args.cert_key_passphrase == None
    assert args.output_file == None
    assert args.output_options == 'Hhb'
    assert args.output

# Generated at 2022-06-17 19:44:06.827278
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http', 'httpbin.org/get'])
    assert args.url == 'http://httpbin.org/get'
    assert args.method == 'GET'
    assert args.headers == []
    assert args.data == []
    assert args.params == []
    assert args.files == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.output_options == 'H'
    assert args.output_options_history == 'H'
    assert args.prettify == 'all'
    assert args.download == False
    assert args.download_resume == False
   

# Generated at 2022-06-17 19:44:15.621733
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args([])

# Generated at 2022-06-17 19:47:22.292614
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == []
    assert args.params == []
    assert args.files == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.cert == None
    assert args.timeout == None
    assert args.max_redirects == None
    assert args.follow == False
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.download == False
    assert args.download_resume == False

# Generated at 2022-06-17 19:47:33.641807
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == []
    assert args.files == []
    assert args.params == []
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.output_options_session == None
    assert args.output_options_download == None
    assert args.output_options_download_resume == None
    assert args.output_options_download_session == None
    assert args.output_options_download_resume_session == None
    assert args.output_options_download_resume_all == None
    assert args.output_options_download_

# Generated at 2022-06-17 19:47:42.140388
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    args = HTTPieArgumentParser().parse_args([])
    assert args.url == None
    assert args.method == None
    assert args.headers == []
    assert args.data == None
    assert args.params == []
    assert args.files == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.download == False
    assert args.download_resume == False
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.prettify == None
    assert args.style == None
    assert args.style_sheet == None
    assert args.verbose == False
   

# Generated at 2022-06-17 19:47:50.290633
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http', 'httpbin.org', 'Accept:application/json'])
    assert args.url == 'httpbin.org'
    assert args.headers == {'Accept': 'application/json'}
    assert args.method == 'GET'
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.ignore_netrc == False
    assert args.data == None
    assert args.files == None
    assert args.form == False
    assert args.params == None
    assert args.json == None
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.download == False
    assert args.download_resume == False

# Generated at 2022-06-17 19:48:00.841027
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help
    args = parser.parse_args(['--version'])
    assert args.version
    args = parser.parse_args(['--traceback'])
    assert args.traceback
    args = parser.parse_args(['--debug'])
    assert args.debug
    args = parser.parse_args(['--download'])
    assert args.download
    args = parser.parse_args(['--download-resume'])
    assert args.download_resume
    args = parser.parse_args(['--download-resume', '--download'])
    assert args.download_resume

# Generated at 2022-06-17 19:48:07.946349
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http://httpbin.org/get'])
    assert args.url == 'http://httpbin.org/get'
    assert args.method == 'GET'
    assert args.headers == []
    assert args.data == []
    assert args.files == []
    assert args.params == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.output_options == 'Hhb'
    assert args.output_options_history == 'Hhb'
    assert args.prettify == True
    assert args.download == False
    assert args.download_resume == False


# Generated at 2022-06-17 19:48:09.920941
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test for method parse_args of class HTTPieArgumentParser
    # This method is not tested because it is too complex
    pass


# Generated at 2022-06-17 19:48:19.796717
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-17 19:48:22.850548
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test for method parse_args of class HTTPieArgumentParser
    # This method is not tested because it is not used in the code
    pass


# Generated at 2022-06-17 19:48:32.117279
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--help'])
    assert args.help
    args = parser.parse_args(['--version'])
    assert args.version
    args = parser.parse_args(['--traceback'])
    assert args.traceback
    args = parser.parse_args(['--debug'])
    assert args.debug
    args = parser.parse_args(['--ignore-stdin'])
    assert args.ignore_stdin
    args = parser.parse_args(['--timeout', '10'])
    assert args.timeout == 10
    args = parser.parse_args(['--max-redirects', '10'])
    assert args.max_redirects == 10
    args = parser.parse_args(['--check-status'])