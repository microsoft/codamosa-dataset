

# Generated at 2022-06-21 13:19:24.191225
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    orig_stdout = sys.stdout
    sys.stdout = io.BytesIO()

    parser = HTTPieArgumentParser()
    parser.parse_args(['GET'])
    assert parser.args.method == HTTP_GET
    assert parser.args.url is None

    sys.stdout = orig_stdout

# Generated at 2022-06-21 13:19:36.382753
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser                    = HTTPieArgumentParser()
    parser.add_argument('-u', '--upload', action='store_true')
    parser.add_argument('-v', '--verbose', action='store_true')
    parser.add_argument('-d', '--data', type=str)
    parser.add_argument('-f', '--format', type=str)
    args = parser.parse_args('')
    assert args.upload == False
    assert args.verbose == False
    assert args.data == None
    assert args.format == None

    args = parser.parse_args(['--upload', '--verbose', '--data', 'mydata', '--format', 'myformat'])
    assert args.upload == True
    assert args.verbose == True

# Generated at 2022-06-21 13:19:39.561695
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    args = parser.parse_args('')
    assert not args.follow
    assert not args.download
    assert args.output_file is None


# Generated at 2022-06-21 13:19:41.074311
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert(issubclass(HTTPieHelpFormatter,RawDescriptionHelpFormatter))



# Generated at 2022-06-21 13:19:44.034338
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    with pytest.raises(SystemExit):
        # FIXME: this only tests for bad usage (missing args, etc.)
        HTTPieArgumentParser().parse_args(args=['--ignore-stdin', '--traceback'])

# Generated at 2022-06-21 13:19:56.461743
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    import os
    import sys
    sys.argv = ['http', 'post', 'http://httpbin.org/post', 'x==3']
    args = HTTPieArgumentParser().parse_args()
    print(args)
    print(vars(args))
    assert args.url == 'http://httpbin.org/post'
    assert args.method == 'POST'
    assert args.headers == [
        KeyValue(key='x', sep='==', value='3', orig='x==3')
    ]
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.output_options is None
    assert args.output_options_history is None
    assert args.download == False
    assert args.download_resume == False
    assert args.follow == True

# Generated at 2022-06-21 13:20:05.348335
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    print("\n\n test_HTTPieArgumentParser\n#########################################################")
    parser = HTTPieArgumentParser()
    # parser.add_descriptions()
    parser.add_auth()
    parser.add_headers()
    parser.add_body()
    parser.add_output()
    parser.add_misc()
    parser.add_group_help()
    parser.parse_args()
    print("#########################################################\n test_HTTPieArgumentParser")

# Generated at 2022-06-21 13:20:07.169012
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    assert formatter.__init__() is None


# Generated at 2022-06-21 13:20:20.005985
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    class FHTTPDigestAuth(DigestAuth):
        auth_type = 'fDigest'
        auth_require = False

        @classmethod
        def get_auth(cls, username=None, password=None):
            return None, None

        @classmethod
        def raw_auth_code(cls, raw_auth):
            return False, None

        @classmethod
        def help(cls):
            return 'A fake Digest auth class'

        @classmethod
        def netrc_parse(cls, netrc_machine_section):
            return False, None


    class FHTTPProxyAuth(ProxyDigestAuth):
        auth_type = 'fProxyDigest'
        auth_require = False

        @classmethod
        def get_auth(cls, username=None, password=None):
            return

# Generated at 2022-06-21 13:20:29.665940
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.add_argument('--foo')
    parser.add_argument('--bar')
    # Test that regular arguments are parsed
    assert parser.parse_args([
        '--foo', 'FOOVAL',
        '--bar', 'BARVAL',
    ]) == Namespace(bar='BARVAL', foo='FOOVAL', parsed_args=None)
    # Test that `parsed_args` is set
    assert parser.parse_args([
        '--foo', 'FOOVAL',
        '--bar', 'BARVAL',
        'bazval',
    ]) == Namespace(bar='BARVAL', foo='FOOVAL', parsed_args=['bazval'])

# Generated at 2022-06-21 13:21:33.274054
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-21 13:21:37.496372
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-21 13:21:43.847575
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    help_msg = '  This is a message\n  with several lines'
    help_msg_de_dented = 'This is a message\nwith several lines\n\n'
    assert formatter._split_lines(help_msg, max_help_position=2) == help_msg_de_dented.splitlines()

###

# Generated at 2022-06-21 13:21:52.840733
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter(max_help_position=9)
    parser = argparse.ArgumentParser(formatter_class=formatter)
    parser.add_argument('--help', help='''
    The help to display
    can be here.''')
    parser.print_help()
    parser.add_argument('--help2', help='''
    The help to display
    can be here.''')
    parser.print_help()



# Generated at 2022-06-21 13:22:02.588201
# Unit test for constructor of class HTTPieArgumentParser

# Generated at 2022-06-21 13:22:14.014488
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # note: the method parse_args() is overrided,
    # hence the test does not trigger executing of the function parse_args()
    # other than what's specified for the overrided method parse_args().
    # We check the modified attribute values.

    from httpie.constants import PRETTY_STDOUT_TTY_ONLY, OUTPUT_OPTIONS_DEFAULT
    from httpie.core import env
    from httpie.input import AuthCredentials, KeyValueArgType
    from httpie.output import OUT
    from httpie.plugins import plugin_manager

    env.stderr = io.StringIO()
    env.is_windows = False
    env.stdout_isatty = True
    env.stdout = io.StringIO()
    env.stdout_encoding = 'utf8'


# Generated at 2022-06-21 13:22:25.827598
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser(prog='http', env=Environment() )
    args = ['--json', '--style', 'foo', '--style-error', 'bar', '-b', '',
            '-h', 'X-Foo:bar', '-h', 'X-Baz:', '-h', 'X-Baz', '--auth', 'baz',
            '--auth-type', 'basic', '--ignore-netrc', '--output', 'file']
    parsed_args = parser.parse_args(args)


    assert parsed_args.output_file == 'file'
    assert parsed_args.style == 'foo'
    assert parsed_args.style_error == 'bar'
    assert parsed_args.json

# Generated at 2022-06-21 13:22:35.122373
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """Test the method parse_args of class HTTPieArgumentParser."""

    # Setup
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.constants import URL_PARAMETER_COMPONENTS
    from httpie.cli.context import Environment
    from httpie.cli.constants import DEFAULT_UA
    from httpie.cli.parser import HTTPieArgumentParser


# Generated at 2022-06-21 13:22:36.632812
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert HTTPieHelpFormatter()._split_lines(
        '  foo', 100) == ['foo', '']



# Generated at 2022-06-21 13:22:47.029107
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # Case 1:
    assert HTTPieArgumentParser is ArgumentParser

    # Case 2:
    args1 = ['-i', '-p', 'ugly', '--traceback', 'example.com']
    parser1 = HTTPieArgumentParser()
    parsed_args1 = parser1.parse_args(args1)
    assert parsed_args1.style == 'ugly'
    assert parsed_args1.traceback is True
    assert parsed_args1.url == 'example.com'
    assert parsed_args1.verify is True

    # Case 3:
    args2 = ['--help']
    parser2 = HTTPieArgumentParser()
    with pytest.raises(SystemExit):
        parser2.parse_args(args2)

    # Case 4:

# Generated at 2022-06-21 13:24:06.299069
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from io import StringIO
    from colorama import init as colorama_init, Fore, Style
    from httpie import __version__ as httpie_version
    from httpie import ExitStatus
    from httpie.cli import environment
    from httpie.cli import parser
    from httpie.cli.argtypes import KeyValueArgType, DataDictArgType

    args = parser.HTTPieArgumentParser().parse_args([])

# Generated at 2022-06-21 13:24:17.161308
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    # There are HelpFormatter methods that need to be overridden in
    # order to properly use them in the HTTPieHelpFormatter class.
    # This overridden methods are self._split_lines() and self._format_text().
    # The first method takes a text as a parameter and splits it into a list of
    # strings and the second one takes a text and width of a terminal, formats
    # the text and returns a string.

    # Input for self._split_lines()
    paragraph = """\
        HTTPie is a command line HTTP client that will make you smile.
        Its goal is to make CLI interaction with web services as human-friendly
        as possible. It provides a simple http command that allows for sending
        arbitrary HTTP requests using a simple and natural syntax, and displays
        colorized output.
        """
    formatter = HTTPieHelpFormatter()


# Generated at 2022-06-21 13:24:23.830016
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    '''
        Purpose - Unit test for constructor of class HTTPieArgumentParser
        Params IN - None
        Return - None
    '''
    parser = HTTPieArgumentParser()
    print(parser)
    print(parser.formatter_class)
    print(parser.env.stdout)
    print(parser.env.stderr)
    print(parser.args)
    print(parser.stdin_isatty)
    print(parser.stdin)
    print(parser.stdin_bytes)
    print(parser.stdin_bytes_as_str)
    print(parser.stdin_text)
    print(parser.stdin_is_encoded_text)

# Main of the Test Script

# Generated at 2022-06-21 13:24:33.922016
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = parser.parse_args()
    assert args.output_file == None
    assert args.download == False
    assert args.method == None
    assert args.all == False
    assert args.check_status == False
    assert args.ignore_stdin == False
    assert args.headers == []
    assert args.request_items == []
    assert args.data == None
    assert args.form == False
    assert args.files == {}
    assert args.params == {}
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.verbose == False
    assert args.silent == False
    assert args.traceback == False
    assert args.unicode_get == False
    assert args.follow == False
    assert args.max_redirects == None

# Generated at 2022-06-21 13:24:40.057411
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    test_formatter = HTTPieHelpFormatter()
    help_text = '''
    This is formatter help.
    This is formatter help.
    '''
    help_text = test_formatter._split_lines(help_text, 20)
    assert help_text == ['This is formatter help.', 'This is formatter help.', '']


# Generated at 2022-06-21 13:24:40.794822
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    assert True


# Generated at 2022-06-21 13:24:44.875885
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=HTTPieHelpFormatter)
    parser.add_argument("-f", help="""
        foo bar
        foo bar
        """, default="11")
    args = parser.parse_args("".split(" "))
    print(args)



# Generated at 2022-06-21 13:24:54.581593
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """Function to unit test the constructor of class
    HTTPieArgumentParser
    """

    parser = HTTPieArgumentParser()

    # Checking for tuple
    assert(isinstance(parser, tuple))

    # Checking for private function _parse_items
    assert(hasattr(parser, '_parse_items'))

    # Checking for private function _process_output_options
    assert(hasattr(parser, '_process_output_options'))

    # Checking for private function _process_pretty_options
    assert(hasattr(parser, '_process_pretty_options'))

    # Checking for private function _process_download_options
    assert(hasattr(parser, '_process_download_options'))

    # Checking for private function _process_format_options
    assert(hasattr(parser, '_process_format_options'))



# Generated at 2022-06-21 13:25:00.369765
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = parser.parse_args(args=[])
    assert args.headers == []
    assert args.data == []
    assert args.files == []
    assert args.params == []
    assert args.output_file == None
    assert args.output_options == OUTPUT_OPTIONS_DEFAULT
    assert args.output_options_history == OUTPUT_OPTIONS_DEFAULT
    assert args.prettify == PRETTY_MAP['all']
    assert args.method == HTTP_GET
    assert args.verbose == False
    assert args.all == False
    assert args.form == False
    assert args.traceback == False
    assert args.check_status == False
    assert args.follow == False
    assert args.follow_redirects == False
    assert args.max_redirects == 5
    assert args

# Generated at 2022-06-21 13:25:05.355737
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    args = parser.parse_args(['--foo'])
    assert args.foo

    parser = ArgumentParser()
    parser.add_argument('-f', '--foo', action='store_true')
    args = parser.parse_args(['-f'])
    assert args.foo

    parser = ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    assert parser.get_default_values().foo is False
    args = parse_args(['--foo'], parser=parser)
    assert args.foo

    parser = ArgumentParser()
    parser.add_argument('-f', '--foo', action='store_true')
    assert parser.get_default_values().foo is False
    args

# Generated at 2022-06-21 13:26:44.897338
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    helpText = "testing, 1, 2, 3, 4"
    obj_helpFormat = HTTPieHelpFormatter(max_help_position=6)
    obj_helpFormat._split_lines(helpText, width=20)


# Generated at 2022-06-21 13:26:50.022146
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    text = "abc def\nghi\n\njkl mno"
    lines = HTTPieHelpFormatter()._split_lines(text, 80)
    assert lines == ['abc def  ', 'ghi        ', '', '', 'jkl mno']
    lines = HTTPieHelpFormatter()._split_lines(text, 4)
    assert lines == ['abc', 'def', 'ghi', '', 'jkl', 'mno']



# Generated at 2022-06-21 13:26:58.266808
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

    args = parser.parse_args(
        ['--verbose', 'https://httpbin.org/get'],
    )
    assert args.verbose == True
    assert args.method == 'GET'
    assert args.url == 'https://httpbin.org/get'

    args = parser.parse_args(
        ['https://httpbin.org/get'],
    )
    assert args.method == 'GET'
    assert args.url == 'https://httpbin.org/get'

    args = parser.parse_args(
        ['https://httpbin.org/get', 'key=val'],
    )
    assert args.url == 'https://httpbin.org/get'
    assert args.method == 'GET'

# Generated at 2022-06-21 13:26:59.577966
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert parser.description == DOCUMENTATION



# Generated at 2022-06-21 13:27:00.982894
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    assert formatter._split_lines(__doc__, 80) == dedent(__doc__).strip().split('\n\n')



# Generated at 2022-06-21 13:27:02.827780
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.get_default('_env')
    parser.parse_args(['www.baidu.com'])
# Unit tests for function parse_items_from_args

# Generated at 2022-06-21 13:27:07.517047
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args()

    assert args.default_scheme == 'https'
    assert args.headers == []
    assert args.request_items == []
    assert args.verbose == False
    assert args.debug == False
    assert args.traceback == False
    assert args.download == False
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.output_options == 'Hhb'
    assert args.output_options_history == 'Hhb'
    assert args.verify == True
    assert args.verify_tunnel == True
    assert args.ignore_netrc == False
    assert args.ignore_stdin == False
    assert args.stream == False
    assert args.timeout == None
    assert args

# Generated at 2022-06-21 13:27:16.876632
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    from httpie.core import env, ExitStatus
    from httpie.cli.parser import HTTPieArgumentParser
    from httpie.context import Environment
    from httpie.downloads import Downloader


# Generated at 2022-06-21 13:27:23.601859
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    # Because there is no clear way to call the method under test, we
    # monkey patch it to get visibility into its argument and return
    # value
    def _parse_args_method(self, args=None, namespace=None):
        self._parse_args_method_args = {
            "args": args,
            "namespace": namespace,
        }
        return self._parse_args_method_return

    class TestHTTPieArgumentParser(HTTPieArgumentParser):
        _parse_args_method_args = None
        _parse_args_method_return = None


    TestHTTPieArgumentParser._parse_args_method = _parse_args_method

    # Since the method under test is private, instantiate the class
    # under test in order to call the method under test
    parser = TestHTTPieArgumentParser()



# Generated at 2022-06-21 13:27:35.208014
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie.core import main
    input, output = get_input_output()

    # Testing the functionality of the httpie cli interface.
    input.write("http GET localhost")
    input.seek(0)
    output.seek(0)
    main(args=['--ignore-stdin'], stdin=input, stdout=output)
    output.seek(0)
    assert "HTTP/1.0 200 OK" in output.read()
    output.seek(0)
    output.truncate(0)

    input.write("http --form user=admin -a admin:password POST localhost")
    input.seek(0)
    output.seek(0)
    main(args=['--ignore-stdin'], stdin=input, stdout=output)
    output.seek(0)
   