

# Generated at 2022-06-21 13:19:21.686079
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    pass

# Command-line option storage.

# Generated at 2022-06-21 13:19:30.928503
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """
    test_HTTPieArgumentParser_parse_args
    """

# Generated at 2022-06-21 13:19:33.200782
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    args = parser.parse_args()
    print(args)



# Generated at 2022-06-21 13:19:43.809220
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args()
    assert args.url is None
    assert args.auth is None
    assert args.headers == []
    assert args.request_items == []
    assert args.proxies == {}
    assert args.output_file_specified is None
    assert args.output_file is None
    assert args.output_file_specified is None
    assert args.output_file is None
    assert args.download is None
    assert args.follow is None
    assert args.check_status is None
    assert args.method is None
    assert args.download_resume is None
    assert args.stream is None
    assert args.timeout is None
    assert args.max_redirects is None
    assert args.session is None
    assert args.verify is None
   

# Generated at 2022-06-21 13:19:50.615669
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

  parser = HTTPieArgumentParser()
  args = parser.parse_args(['GET', 'http://localhost/'])

  assert args is not None
  assert args.url == 'http://localhost/'
  assert args.method == 'GET'
  assert args.headers == {}
  assert args.params == OrderedDict()
  assert args.files == OrderedDict()
  assert args.data == None
  assert args.prettify == 'all'
  assert args.output_options == 'Hhb'
  assert args.output_file == None
  assert args.output_file_specified == False
  assert args.colors == '256'
  assert args.style == None

# Generated at 2022-06-21 13:19:53.214492
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    parser.parse_args()
    # Nothing to do here, only to do the coverage
    # pass

# Generated at 2022-06-21 13:20:06.597949
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    # Mimic the default options for "http --help" command
    parser = get_argparser(prog='http', add_help_option=True)
    httpie_help_formatter = HTTPieHelpFormatter(parser._actions[0],
                                                              parser._optionals)
    # Create a set of option_strings and argument strings and test if each one
    # is an item in the help formatter
    option_strings = ["-h", "--headers", "-b", "--body", "--verbose", "-f",
                      "--form", "--json", "--print-bodies",
                      "--download", "--download-all", "--output"]
    argument_strings = ["[QUERY [QUERY2 [...]]]", "[METHOD] URL [ITEM [ITEM2 [...]]]"]

# Generated at 2022-06-21 13:20:14.186595
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie.cli.context import Environment
    from httpie.cli.constants import DEFAULT_UA

    for args in (
        (),
        ('--help',),
        ('--version',),
    ):
        arg_parser = HTTPieArgumentParser(prog='http', env=Environment())
        assert arg_parser.parse_args(args) is not None

    def test_HTTPieArgumentParser_parse_args_basic():
        arg_parser = HTTPieArgumentParser(prog='http', env=Environment())
        args = arg_parser.parse_args(
            args=[
                'httpbin.org', 'Accept:application/json', 'x==abc', 'y==def'
            ]
        )

# Generated at 2022-06-21 13:20:23.616004
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    sys.argv = ['http', '--json', 'POST', '--body', '{"key": "val"}', 'http://localhost:5000/echo']
    args = HTTPieArgumentParser().args
    assert not args.print_body
    assert args.json
    assert args.body == '{"key": "val"}'
    assert args.headers['content-type'] == 'application/json'
    assert args.method == 'POST'
    assert args.url == 'http://localhost:5000/echo'

test_HTTPieArgumentParser_parse_args()
 
 

# Generated at 2022-06-21 13:20:26.511668
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    hhf = HTTPieHelpFormatter()
    assert len(hhf.format_help().split('\n')) != len(argparse.HelpFormatter().format_help().split('\n'))


# Generated at 2022-06-21 13:21:08.310623
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    output = "\nItem1\nItem2\n\n"
    parser = argparse.ArgumentParser(
        description="Description",
        formatter_class=HTTPieHelpFormatter
    )
    parser.add_argument(
        "--option", "--opt",
        action="store_true",
        help=output
    )
    doc = parser.format_help()
    assert "  --opt  \n" in doc
    assert "Item1" in doc
    assert "Item2" in doc


# Generated at 2022-06-21 13:21:16.363449
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', help=dedent("""
        The foo option.

        It does foo things.

        Nifty.
        """))
    _, width = argparse.HelpFormatter._get_max_help_position(parser)
    expected_help = dedent("""
        \b
        The foo option.

        It does foo things.

        Nifty.


        """)

    assert len(expected_help) == width + 1



# Generated at 2022-06-21 13:21:24.579759
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from docopt import docopt
    
    def call_parse_args_to_get_args_object(args):
        import sys
        ap = HTTPieArgumentParser()
        args = ap.parse_args(args=args, namespace=HTTPieArgumentParser.Namespace())
        return args
    # Test 1
    args = ['-v', '--pretty', 'all', 'https://httpbin.org/get']
    args_object = call_parse_args_to_get_args_object(args)
    print(args_object)
    print(args_object.url)
    assert args_object.verbose == True
    assert args_object.pretty == 'all'
    assert args_object.url == 'https://httpbin.org/get'

# Generated at 2022-06-21 13:21:26.924194
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert isinstance(parser, argparse.ArgumentParser)
    assert isinstance(parser, HTTPieArgumentParser)


if __name__ == '__main__':
    # run unit test
    test_HTTPieArgumentParser()

# Generated at 2022-06-21 13:21:31.040313
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import argparse
    parser = HTTPieArgumentParser()
    args = parser.parse_args()
    assert isinstance(args, argparse.Namespace)

# Generated at 2022-06-21 13:21:40.757136
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    # GIVEN
    # Create the command-line arguments
    parser = argparse.ArgumentParser(description='', epilog='', add_help=False)
    parser.add_argument('request')
    parser.add_argument('--json', dest='--json', help='\n\n    header-key: header-value')
    parser.add_argument('--form', dest='--form', help='\n\n    header-key: header-value')
    parser.add_argument('--verbose', dest='--verbose', help='\n\n    header-key: header-value')

    # WHEN
    # Create the output of the command-line arguments
    # The help output will be indented
    output = parser.format_help()

    # THEN
    # Check that the output is indented

# Generated at 2022-06-21 13:21:54.884982
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

    args = parser.parse_args(['--ignore-stdin', '--timeout=1', 'URL'])
    assert args.url == 'URL'
    assert args.ignore_stdin == True
    assert args.timeout == 1
    
    args = parser.parse_args(['-X', 'POST', 'URL', '--auth-type=basic'])
    assert args.url == 'URL'
    assert args.auth_type == 'basic'
    assert args.method == 'POST'
    assert args.auth is None
    
    args = parser.parse_args(['-X', 'POST', 'URL', '--auth', 'user:pass'])
    assert args.url == 'URL'
    assert args.auth_type == 'basic'

# Generated at 2022-06-21 13:21:57.346161
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # parser = HTTPieArgumentParser()
    # parser.print_help()
    pass

test_HTTPieArgumentParser()

# Generated at 2022-06-21 13:22:00.378465
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args([])

    assert args.__dict__

# Generated at 2022-06-21 13:22:12.346995
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    #test1
    parser = HTTPieArgumentParser()
    parser.add_argument('url')
    parser.add_argument('-v', '--verbose', action=VerboseAction)
    parser.add_argument('--form', '--json', action='store_true')
    parser.add_argument('--debug', action=DebugAction)
    parser.add_argument('--offline', action='store_true')
    parser.add_argument('-o', '--output', type=argparse.FileType('wb'))
    parser.add_argument('--session', metavar='FILE')
    parser.add_argument('--session-read-only', action='store_true')
    parser.add_argument('--session-delete-data', action='store_true')

# Generated at 2022-06-21 13:23:20.446055
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # Part1: test _normalize_url()
    _parser = HTTPieArgumentParser()

    # test1: convert URL to its final form.
    _url1 = 'www.google.com'
    _result1 = 'http://www.google.com'
    assert _parser._normalize_url(_url1) == _result1

    # test2: add a default port to the URL.
    _url2 = 'https://www.google.com'
    _result2 = 'https://www.google.com:443'
    assert _parser._normalize_url(_url2) == _result2

    # Part2: test _print_message()
    # test1: if file is stdout, write message to _env.stdout
    # test2: if file is stderr, write message to _env.stder

# Generated at 2022-06-21 13:23:23.455887
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter(max_help_position=0)
    assert len(formatter._max_help_position) == 0
    assert len(formatter.max_help_position) == 2


# Generated at 2022-06-21 13:23:31.352638
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=HTTPieHelpFormatter)
    parser.add_argument('-b',
                        help=u"""
                -b, --body
                --body-required
                [TEXT | @FILE | <INPUT]
            """)
    assert parser.format_help() == """\
    usage: [-h] [-b [TEXT | @FILE | <INPUT>]]

    optional arguments:
      -h, --help  show this help message and exit
      -b          -b, --body
                  --body-required
                  [TEXT | @FILE | <INPUT>]"""



# Generated at 2022-06-21 13:23:36.822535
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():

    parser = HTTPieArgumentParser()
    parser.args.verify = True
    assert parser.args.verify == True

    parser = HTTPieArgumentParser()
    parser.args.verify = False
    assert parser.args.verify == False

    parser = HTTPieArgumentParser()
    parser.args.check_status = True
    assert parser.args.check_status == True

    parser = HTTPieArgumentParser()
    parser.args.check_status = False
    assert parser.args.check_status == False


# Generated at 2022-06-21 13:23:47.414401
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

    args = parser.parse_args('')

    assert args.auth == []
    assert args.headers == []
    assert args.method == 'GET'
    assert args.params == {}
    assert args.output_file == None
    assert args.download == False
    assert args.session == []
    assert args.body == []
    assert args.headers == []
    assert args.params == {}
    assert args.proxies == {}


    args = parser.parse_args('--auth')

    assert args.auth == ['--auth']
    assert args.headers == []
    assert args.method == 'GET'
    assert args.params == {}
    assert args.output_file == None
    assert args.download == False
    assert args.session == []

# Generated at 2022-06-21 13:23:59.112668
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():

    class TestHTTPieArgumentParser(HTTPieArgumentParser):
        def __init__(self):
            """
            This is the constructor method for the test class
            """
            self._env = Env()
            self._env.stdout = sys.stdout
            self._env.stdin = sys.stdin
            self._env.stderr = sys.stderr
            self._env.devnull = open(os.devnull, 'wb')
            self._env.stdout_encoding = sys.stdout.encoding or 'utf8'
            self._env.stdout_isatty = sys.stdout.isatty()
            self._env.stdin_isatty = sys.stdin.isatty()

# Generated at 2022-06-21 13:24:00.742422
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    httpie_argument_parser = HTTPieArgumentParser()
    expected_description = DESCRIPTION
    actual_description = httpie_argument_parser.description
    assert actual_description == expected_description


# Generated at 2022-06-21 13:24:02.206546
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    p = HTTPieArgumentParser()
    print(p)


# Generated at 2022-06-21 13:24:07.922986
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    print("\n")
    print("Unit test for constructor of class HTTPieHelpFormatter")
    print("--------------------------------------------------------------")

    formatter = HTTPieHelpFormatter()
    print(type(formatter))
    print(type(formatter).__name__)

    print("--------------------------------------------------------------\n")


# Generated at 2022-06-21 13:24:18.240499
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-21 13:26:48.516935
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    import argparse

    parser = argparse.ArgumentParser(description='description',
                                     formatter_class=HTTPieHelpFormatter)
    parser.add_argument('-a', dest='a', help='a')
    print(parser.format_help())


# Generated at 2022-06-21 13:26:56.966609
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie.core import main
    from httpie.config import Environment
    env = Environment()
    args = HTTPieArgumentParser(env=env).parse_args([])
    assert args.url == 'https://www.google.com'
    assert args.auth == None
    assert args.headers == None
    assert args.method == 'GET'
    assert args.body == None
    assert args.output_file == None
    
    parser = HTTPieArgumentParser(env=env)
    args = parser.parse_args(['https://www.google.com', '--auth=username:password', '--headers', 'content-type:application/json', '--method', 'POST', '--body', '{"id":1,"name":"httpie"}', '--output', 'httpie.json'])

# Generated at 2022-06-21 13:27:02.939481
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """Unit test for HTTPieArgumentParser class.
    """
    # create a parser
    ap = HTTPieArgumentParser()
    # set arguments
    argv = ['POST', 'http://httpie.org/post', 'name=John', 'foo=bar']
    # parse arguments
    args = ap.parse_args(argv)
    # check if parsed arguments are valid
    assert args.url == 'http://httpie.org/post'
    assert args.method == 'POST'
    assert args.request_items == [KeyValueArgType(*SEPARATOR_GROUP_DATA_ITEMS).__call__('name=John'), KeyValueArgType(*SEPARATOR_GROUP_DATA_ITEMS).__call__('foo=bar')]
    assert args.headers == []
    # set arguments

# Generated at 2022-06-21 13:27:09.407616
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        prog='http',
        formatter_class=HTTPieHelpFormatter,
        description='description',
        epilog='epilog')
    parser.add_argument('--foo', help='\tline1\n\n\tline2')
    parser.print_help()


# Generated at 2022-06-21 13:27:18.060867
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    def test_error(fixture_path, error_pattern, env=None):
        #file_name = os.path.basename(fixture_path)
        with TestEnvironment(env=env) as env:
            parser = HTTPieArgumentParser()
            try:
                parser.parse_args(test_file_path(fixture_path, data=True))
            except SystemExit as e:
                if not e.code == 2:
                    raise AssertionError('SystemExit(%r) not raised' % 2)
                else:
                    error_message = parser.fetch_error(e)
                    if error_pattern not in error_message:
                        raise AssertionError('%r not in %r' % (
                            error_pattern,
                            error_message,
                        ))


# Generated at 2022-06-21 13:27:28.309493
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert parser.exit_status
    assert parser.output_file
    assert parser.stdin_isatty
    assert parser.stdout_isatty
    assert parser.form
    assert parser.headers
    assert parser.follow
    assert parser.check_status
    assert parser.verify
    assert parser.stream
    assert parser.all
    assert parser.download_resume
    assert parser.download
    assert parser.download_as
    assert parser.continue_download
    assert parser.quiet
    assert parser.output
    assert parser.prettify
    assert parser.verbose
    assert parser.style
    assert parser.style_html
    assert parser.style_colors
    assert parser.style_table
    assert parser.style_progress
    assert parser.style_gradient
   

# Generated at 2022-06-21 13:27:29.614798
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    assert HTTPieArgumentParser("")

# Generated at 2022-06-21 13:27:40.567920
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # argparse.ArgumentParser.parse_args is not a property, so we cannot
    # mock it directly.
    class A:
        def _print_message(self, *a, **b):
            print('fake_print_message', a, b)

    parser = HTTPieArgumentParser(
        prog='HTTPie',
        usage=argparse.SUPPRESS,
        epilog=argparse.SUPPRESS,
        add_help=False,
        httpie=A(),
        env=Env()
    )
    parser.add_argument('--print', dest='output_options', type=str,
                        help='Control which HTTPie output options are\n'
                             'displayed in the output.')
    args = parser.parse_args(['--print', 'a'])

# Generated at 2022-06-21 13:27:50.662525
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    with pytest.raises(ValueError):
        HTTPieArgumentParser(
            usage='usage',
            epilog='epilog',
            env=Environment(),
            config=Config(DEFAULT_CONFIG_DIR,
                          merge_defaults=False),
            plugin_manager=plugin_manager,
            stdin_isatty=True,
            stdout_isatty=True,
            stdin=sys.stdin,
            stdout=sys.stdout,
            stderr=sys.stderr,
            stdout_encoding=sys.stdout.encoding,
            stderr_encoding=sys.stderr.encoding)



# Generated at 2022-06-21 13:27:59.303105
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()