

# Generated at 2022-06-21 13:19:24.542776
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    '''Tests constructing an HTTPieArgumentParser'''

    # Test 1: No arguments
    args = []
    env = Environment()
    parser = HTTPieArgumentParser(args=args, env=env)
    assert parser


# Unit tests for _add_version_option

# Generated at 2022-06-21 13:19:32.579992
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.context import Environment
    from httpie.output.streams import get_binary_stream
    env = Environment()
    env.config = config.Config(iter([
        'default_options=--pretty=format',
    ]))
    parser = HTTPieArgumentParser(prog='http', env=env)
    parser.error = lambda *args: None
    args = parser.parse_args([
        'http', '--default-options=--pretty=form',
        'http://httpie.org/'
    ])
    expected = argparse.Namespace()
    expected.headers = []
    expected.data = []
    expected.files = []
    expected.params = []
    expected.auth = None
    expected.auth_type = None
   

# Generated at 2022-06-21 13:19:43.334606
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():

    # create an object of class HTTPieArgumentParser
    target = HTTPieArgumentParser()

    # test if the object is of type HTTPieArgumentParser
    def test_if_object_is_of_type_argument_parser():
        assert isinstance(target, argparse.ArgumentParser)

    # test if the object has the expected attributes
    def test_if_object_has_expected_attributes():
        assert hasattr(target, '_parse_args') is True
        assert hasattr(target, 'error') is True
        assert hasattr(target, 'exit') is True
        assert hasattr(target, 'print_help') is True
        assert hasattr(target, 'print_usage') is True

    # call the unit tests
    test_if_object_is_of_type_argument_parser()
    test_

# Generated at 2022-06-21 13:19:51.129279
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        formatter_class=HTTPieHelpFormatter)
    parser.add_argument('-h')
    parser.add_argument('-v')
    parser.add_argument('-b', '')

    assert parser.format_help() == dedent('''
        usage:
              [-h] [-v] [-b]

        positional arguments:
          -h

        optional arguments:
          -v

          -b
              ''').strip()


# Generated at 2022-06-21 13:19:54.139775
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    argument_parser = HTTPieArgumentParser()
    return

if __name__ == '__main__':
    test_HTTPieArgumentParser()

# Generated at 2022-06-21 13:20:07.121541
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-21 13:20:10.761178
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """Create an instance of HTTPieArgumentParser"""

    import httpie.cli.parser

    temp_parser=httpie.cli.parser.HTTPieArgumentParser()
    assert temp_parser



# Generated at 2022-06-21 13:20:23.616661
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-21 13:20:32.625309
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.add_argument('--foo')
    parser.add_argument('--bar')
    parser.add_argument('baz')
    parser.add_argument('quux')
    parser.env.stdout = io.BytesIO()

    args = parser.parse_args(args=[])
    assert args == argparse.Namespace(
        bar=None,
        baz=None,
        quux=None,
        foo=None
    )

    args = parser.parse_args(args=['foo', '--bar=bar', 'baz'])
    assert args == argparse.Namespace(
        bar='bar',
        baz='baz',
        quux=None,
        foo='foo'
    )


# Generated at 2022-06-21 13:20:33.391632
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert parser


# Generated at 2022-06-21 13:21:37.699024
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', help='foo\nbar\nbaz')
    parser.add_argument('--bar', help='  foo\n  bar')
    parser.add_argument('baz', help='  foo\n  bar')
    parser.parse_args(['--help'])
    return parser.format_help()



# Generated at 2022-06-21 13:21:42.136698
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http', 'get', 'httpbin.org/get', 'User-Agent:HTTPie/0.9.9'])
    assert args.url == 'http://httpbin.org/get'
    assert args.headers['User-Agent'] == 'HTTPie/0.9.9'
    
    

# Generated at 2022-06-21 13:21:48.770134
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    assert formatter.max_help_position == 6
    assert formatter._split_lines('', 0) == ['']
    assert formatter._split_lines('abc\ndef\nghi\n\n', 0) == ['abc', 'def', 'ghi', '', '']

# Here act as the main entry of http

# Generated at 2022-06-21 13:21:57.643048
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # 避免调用实现以及不必要的方法
    parser = HTTPieArgumentParser()
    assert(isinstance(parser, argparse.ArgumentParser))
    assert_obj_attr(parser)
    # parser.add_argument argv=None, conflict_handler='error', prefix_chars='-', fromfile_prefix_chars='@', 
    # argument_default=None, add_help=True
    return parser


# Generated at 2022-06-21 13:22:10.457515
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    class FakeEnv():
        class FakeStdStream():
            def __init__(self):
                self.encoding = 'utf-8'
                self.isatty = True
        stdin = FakeStdStream()
        stdout = FakeStdStream()
        stderr = FakeStdStream()
        stdin_isatty = True
        stdout_isatty = True
        stderr_isatty = True
        stdout_encoding = 'utf-8'
        color = True
        is_windows = False
        unicode_is_utf8 = False
    env = FakeEnv()
    # TODO: test for other cases
    httpie_args = ['--', 'http://example.com']
    args = HTTPieArgumentParser(env).parse_args(httpie_args)


# Generated at 2022-06-21 13:22:22.074993
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Testing parse_args method of HTTPieArgumentParser
    import argparse
    import tempfile
    import unittest
    from httpie.compat import is_windows
    from httpie.downloads import (
        parse_content_range, parse_download_args, parse_download_range
    )
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.status import ExitStatus
    from httpie.upload import (
        filename_from_content_disposition, filename_from_url,
        get_content_type
    )
    from utils import HTTPieTestEnvironment, MockEnvironment, MockEnvironmentTestCase
    from utils import TestEnvironment, http

# Generated at 2022-06-21 13:22:31.099186
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = ArgumentParser(add_help=False)
    parser.add_argument('--a', action='store_true', default=False)

    with mock.patch('httpie.cli.HTTPieArgumentParser._create_parser') as create_parser:
        create_parser.return_value = parser

        hp = HTTPieArgumentParser()
        hp.add_argument = mock.Mock()
        hp.parse_args(['--a', '--b'])

        # -h was not passed to `parser`, we shouldn't get `-a` in `args`.
        assert create_parser.call_args[1]['args'] == ['--b']


# Generated at 2022-06-21 13:22:35.881197
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    """
    Unit test for constructor of class HTTPieHelpFormatter
    """
    help_formatter = HTTPieHelpFormatter()
    assert help_formatter.__dict__.get('max_help_position') == 6
    assert help_formatter.__dict__.get('width') == 90
    assert help_formatter.__dict__.get('current_indent') == ''
    assert help_formatter.__dict__.get('level') == 1


# Generated at 2022-06-21 13:22:40.652805
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    ap = HTTPieArgumentParser()
    args = ap.parse_args(['http', '--json', 'redis://127.0.0.1:6379'])
    assert(args.url == 'redis://127.0.0.1:6379')
    assert(args.json == True)

# Generated at 2022-06-21 13:22:44.357819
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    http = HTTPie()
    http.args = AttributeDict()
    for key in ['traceback', 'pretty', 'colors', 'style']:
        http.args[key] = False
    http.args.output_options = ""

    parser = HTTPieArgumentParser(
        prog='http',
        description=__doc__.splitlines()[0],
        env=http.env,
        args=http.args,
    )

# Generated at 2022-06-21 13:24:00.023827
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    help_text = """\
        The request data.

        One of:
        - a JSON/JSONP string beginning with ``{`` or ``[``
        - @filename
        - key1=val1 [key2=val2] [keyN=valN]
        """
    parser = argparse.ArgumentParser(formatter_class=HTTPieHelpFormatter)
    parser.add_argument('data', metavar='data', nargs='*', help=help_text)
    args = parser.parse_args([])
    assert args.data == [], args.data
    help_actual = parser.format_help()

# Generated at 2022-06-21 13:24:03.776803
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=HTTPieHelpFormatter)
    parser.add_argument('--foo', metavar='bar',
                        help='''
                            foo to some value.

                            Another paragraph.
                        ''')
    assert parser.format_help() == '''\
usage: [-h] [--foo bar]

optional arguments:
  -h, --help  show this help message and exit
  --foo bar   foo to some value.

              Another paragraph.

'''



# Generated at 2022-06-21 13:24:06.864098
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    h = HTTPieHelpFormatter(max_help_position=6)
    assert h.max_help_position == 6


# Generated at 2022-06-21 13:24:17.688883
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """For testing the class HTTPieArgumentParser and its methods.
    """
    args = HTTPieArgumentParser()
    
    # testing get_default method in the class
    assert args.get_default('--max-redirects') == None
    assert args.get_default('--download') == None
    assert args.get_default('--form') == None
    assert args.get_default('--auth') == None
    assert args.get_default('--ignore-stdin') == None
    assert args.get_default('--style') == None
    assert args.get_default('--download-resume') == None
    assert args.get_default('--debug') == None
    assert args.get_default('--timeout') == None
    assert args.get_default('--default-scheme') == None

# Generated at 2022-06-21 13:24:19.558195
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert parser.__class__ == HTTPieArgumentParser



# Generated at 2022-06-21 13:24:26.292358
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    serializable_args = __main__.HTTPieArgumentParser.parse_args(['-F', '--help'])
    args = __main__.Arguments()
    args.__dict__ = serializable_args
    try:
        assert args.form == True
    except:
        print("Method parse_args of class HTTPieArgumentParser did not return correct result, please test again")

test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-21 13:24:35.724368
# Unit test for constructor of class HTTPieArgumentParser

# Generated at 2022-06-21 13:24:37.523999
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    HTTPieArgumentParser().parse_args(["--json", "--ignore-stdin", "http://httpbin.org/get"])

# Generated at 2022-06-21 13:24:44.025399
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = mock.Mock()
    args.dry_run = None
    args.config = None
    args.colors = None
    args.style = None
    args.default_options = None
    args.traceback = None
    args.download = None
    args.download_resume = None
    args.output_file_specified = None
    args.download_output_prefix = None
    args.output_dir = None
    args.download_flat = None
    args.download_output_file = None
    args.download_output_dir = None
    args.download_output_path = None
    args.multipart_data = None
    args.timeout = None
    args.timeout_sec = None
    args.verify = None
    args.verify_status = False
    args.verify_ssl

# Generated at 2022-06-21 13:24:53.316522
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie = HTTPieArgumentParser()
    httpie.parse_args(['--verbose','--traceback','--method','GET','--auth','user:pass','--headers','H1','--headers','H2','--output','/tmp/output','--form','F1','--form','F2','dummy'])
    print("httpie.args.verbose = ",httpie.args.verbose)
    print("httpie.args.traceback = ",httpie.args.traceback)
    print("httpie.args.method = ",httpie.args.method)
    print("httpie.args.auth = ",httpie.args.auth)
    print("httpie.args.headers = ",httpie.args.headers)
    print("httpie.args.output = ",httpie.args.output)

# Generated at 2022-06-21 13:27:37.692048
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-21 13:27:41.020840
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert 'hello' == dedent('hello').strip()
    assert 'hello\n\n' == dedent('hello').strip() + '\n\n'
    assert ['hello', ''] == dedent('hello').strip() + '\n\n'.splitlines()



# Generated at 2022-06-21 13:27:44.847127
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    test_args = ['https://httpbin.org/get']
    args = HTTPieArgumentParser().parse_args(test_args, env)

    assert args.url == 'https://httpbin.org/get'


# Generated at 2022-06-21 13:27:55.623247
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    try:
        from unittest.mock import Mock
    except ImportError:
        from mock import Mock
    # Test init
    try:
        formatter = HTTPieHelpFormatter()
    except Exception as e:
        assert 0, 'Error in constructor of class HTTPieHelpFormatter: {}'.format(e)
    # Test _split_lines
    formatter2 = HTTPieHelpFormatter
    formatter2._split_lines = Mock(return_value='ABCD')
    assert formatter2._split_lines('''
    abcd

    efgh
    ''', 20) == 'ABCD'
    formatter2._split_lines.assert_called_once_with('''
    abcd

    efgh
    ''', 20)
    # Test new_aliases

# Generated at 2022-06-21 13:27:58.531322
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    str = HTTPieHelpFormatter(max_help_position=2)._split_lines("""
                                    hello
                                    world

                                    hello
                                    world""", 100)
    assert str == ['hello', 'world', '', 'hello', 'world', '']



# Generated at 2022-06-21 13:28:00.234036
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert HTTPieHelpFormatter(max_help_position=6).max_help_position == 6


# Generated at 2022-06-21 13:28:02.883418
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    test_parser = HTTPieArgumentParser()
    sys.argv = ['httpie', '--json', 'POST', 'http://httpbin.org/post', 'foo=bar']
    test_parser.parse_args()
    assert test_parser.args.json is True

# Generated at 2022-06-21 13:28:08.554695
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    '''
    This test case tests the method parse_args of class HTTPieArgumentParser
    '''
    # Setup
    argv = ['http', '--form']
    httpie_argparser = HTTPieArgumentParser()

    # Exercise
    args = httpie_argparser.parse_args(argv)

    # Verify

# Generated at 2022-06-21 13:28:14.363487
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    http_argument_parser=HTTPieArgumentParser(prog='http',
                                              env=Environment(),
                                              quiet=False,
                                              full_help=True)
    #a=http_argument_parser._parent_subparsers
    #print(a)
    #a.choices['auth'].choices['plugin'].choices
    #print(a.choices['auth'].choices['plugin'].choices)
    #print(a.choices['auth'].choices['plugin'].choices['jwt'])
    #print(a.choices['auth'].choices['plugin'].choices['jwt'].help)
    #print(a.choices['auth'].choices['plugin'].choices['jwt'].option_string)
    http_argument_

# Generated at 2022-06-21 13:28:19.424735
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    tests = []

    # TODO: Add more tests!
    tests.append((
        ['--output-file ~/tmp/example.out', 'http://www.example.com/'],
        {
            'output_file_specified': True,
            'output_file': io.StringIO('This is the outfile'),
            'url': 'http://www.example.com/'
        }
    ))

    tests.append((
        ['--download', 'http://www.example.com/'],
        {
            'output_file': None,
            'url': 'http://www.example.com/',
            'download': True
        }
    ))
