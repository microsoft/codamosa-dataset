

# Generated at 2022-06-21 13:19:29.035353
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-21 13:19:41.123312
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    http = HTTPie()
    http.args.timeout = '10'
    http.args.output_file = 'outfile'
    http.args.output_file_specified = True
    http.args.check_status = True
    http.args.download = True
    http.args.download_resume = True
    http.args.download_start = '10'
    http.args.download_end = '10'
    http.args.output_options = 'ppp'
    http.args.output_options_history = 'ppp'
    http.args.method = 'GET'
    http.args.url = 'url'
    http.args.request_items = ['items']
    http.args.auth = 'auth'
    http.args.auth_type = 'auth_type'

# Generated at 2022-06-21 13:19:49.006152
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    parser._process_format_options()
    # test _process_format_options
    assert parser.args.format_options == PARSED_DEFAULT_FORMAT_OPTIONS
    try:
        parser._process_format_options()
    except:
        pass
    # test _process_download_options
    parser._process_download_options()
    # test _process_pretty_options
    parser._process_pretty_options()
    # test _process_output_options
    parser._process_output_options()
    assert parser.args.output_options == OUTPUT_OPTIONS_DEFAULT
    assert parser.args.output_options_history == OUTPUT_OPTIONS_DEFAULT
    # test _parse_items
    parser._parse_items()

# Generated at 2022-06-21 13:19:54.295686
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Return a mock HTTPieArgumentParser instance
    # And checks if the expected methods are called
    argparse_mock = mock.MagicMock()
    argparse_mock.add_argument = mock.MagicMock()
    argparse_mock.parse_known_args = mock.MagicMock()

    httpie_args_parser = HTTPieArgumentParser()
    httpie_args_parser.args = mock.MagicMock()
    httpie_args_parser.handle_aliases = mock.MagicMock()
    httpie_args_parser.handle_common = mock.MagicMock()
    httpie_args_parser.handle_config_file = mock.MagicMock()
    httpie_args_parser.handle_download = mock.MagicMock()
    httpie_args_parser.handle_output_options

# Generated at 2022-06-21 13:19:55.402391
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO
    pass

# Generated at 2022-06-21 13:20:08.218586
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # Get the HTTPieArgumentParser class
    HTTPieArgumentParser = HTTPieArgumentParserClass()

    # Test properties of the class
    assert isinstance(HTTPieArgumentParser.HTTPIE_APPEARS_ON_FIRST_LINE, bool)
    assert isinstance(HTTPieArgumentParser.format_option_definitions, dict)
    assert isinstance(HTTPieArgumentParser.max_content_length, int)
    assert isinstance(HTTPieArgumentParser.max_headers_count, int)
    assert isinstance(HTTPieArgumentParser.timeout, int)

    assert isinstance(HTTPieArgumentParser.add_argument, object)
    assert isinstance(HTTPieArgumentParser.add_subparsers, object)

# Generated at 2022-06-21 13:20:12.435476
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    help_formatter = HTTPieHelpFormatter()
    assert help_formatter._split_lines('  foo\n\n  bar\n\n  baz\n', 80) == ['foo', '', 'bar', '', 'baz']

# HTTPieHelpFormatter test

# Generated at 2022-06-21 13:20:13.380565
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    pass


# Generated at 2022-06-21 13:20:19.780781
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    '''Unit test for constructor of class HTTPieHelpFormatter.
    '''
    my_help_formatter = HTTPieHelpFormatter()
    assert isinstance(my_help_formatter, HTTPieHelpFormatter)
    assert my_help_formatter.max_help_position == 6
    assert my_help_formatter.width == 80 # default width


# Generated at 2022-06-21 13:20:27.614140
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    docoptparser = argparse.ArgumentParser(prog='http')
    docoptparser.add_argument('-v', help=dedent('''\
        Print the HTTP request and response data.
        '''))
    docoptparser.add_argument('-b', help=dedent('''\
        The HTTP request body data.
        '''))

    help_parser = argparse.ArgumentParser(prog='http', formatter_class=HTTPieHelpFormatter)
    for action in docoptparser._actions:
        help_parser._add_action(action)


# Generated at 2022-06-21 13:21:11.636412
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Just in case a Windows user is using a `python.exe` that is not
    # in `PATH`, we need to add the directory containing it to `PATH`
    # to be able to run the test script.
    # See <http://docs.python.org/2/using/cmdline.html#environment-variables>
    if IS_WINDOWS and 'PATH' not in os.environ:
        os.environ['PATH'] = os.path.dirname(os.path.abspath(sys.executable))
    # We save and restore original environment, so that the test
    # doesn't interfere with the user's running environment.

# Generated at 2022-06-21 13:21:15.102926
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    out = formatter._split_lines(text='\n\tHello\n\tWorld\n\n', width=76)
    assert out == ['Hello', 'World', '', '']



# Generated at 2022-06-21 13:21:24.173420
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.add_argument('--quiet', action='store_true')
    parser.parse_args()

#     def parse_args(self, args=None, namespace=None):
#         """
#         Parse the arguments, perform minor/major validation,
#         apply default options, etc.

#         """

#         if args is None:
#             # Don't modify the caller's arg list.
#             args = sys.argv[1:]

#         self._args = args

#         # The base parser will only ever look at the first `--` occurrence
#         # so we remove it from the list and then add it back in later.
#         double_dash_index = self._args.index('--') if '--' in self._args else None
#         if double_

# Generated at 2022-06-21 13:21:33.933131
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    from argparse import ArgumentParser
    parser = ArgumentParser(
        description='HTTPie - a CLI, cURL-like tool for humans.',
        formatter_class=HTTPieHelpFormatter,
        add_help=False)
    parser.add_argument('item', help="""
        Item help. It can span multiple lines.
        """)
    parser.add_argument('-F', '--form', help="""
        Form help. It can span multiple lines.
        """)
    parser.add_argument('--follow', help="""
        Follow help. It can span multiple lines.
        """)
    parser.print_help()
    assert parser.description == dedent("""
        HTTPie - a CLI, cURL-like tool for humans.
        """).strip()

# Generated at 2022-06-21 13:21:42.594209
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    io = io_mock()
    env = Environment(
        # stdin=io.stdin,
        # stdout=io.stdout,
        # stderr=io.stderr,
        # stdin_isatty=False,
        # stdout_isatty=False,
        # stderr_isatty=False,
        # stdout_encoding=None,
        config_dir=CONFIG_DIR_PATH,
        config_file=CONFIG_FILE_PATH,
        env=None,
        is_windows=False
    )

    parser = HTTPieArgumentParser(env)
    args = parser.parse_args(['/dev/null', '-h'])
    assert args.url == '/dev/null'
    assert args.headers == ['-h']
    assert args

# Generated at 2022-06-21 13:21:56.640784
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """Test cases for constructor of class HTTPieArgumentParser."""

    # Case 1: only default values are passed.
    httpie_parser_obj_1 = HTTPieArgumentParser()
    assert isinstance(httpie_parser_obj_1.parser, argparse.ArgumentParser)
    assert httpie_parser_obj_1.parser.usage == httpie_parser_obj_1.EPILOG
    assert httpie_parser_obj_1.parser.prog == httpie_parser_obj_1.env.app_name.upper()
    assert httpie_parser_obj_1.parser.add_help == False
    assert isinstance(httpie_parser_obj_1.env, Environment)

    # Case 2: only parser and env are passed.

# Generated at 2022-06-21 13:21:58.427130
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    httpie_arg_parser = HTTPieArgumentParser()
    print(httpie_arg_parser.__doc__)

# Generated at 2022-06-21 13:22:00.705775
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    parser.add_argument("--test")



# Generated at 2022-06-21 13:22:06.541447
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    from io import StringIO
    from argparse import ArgumentParser

    parser = ArgumentParser(formatter_class=HTTPieHelpFormatter)
    parser.add_argument('--foo', help='''\

        First paragraph.

        Second paragraph.
        ''')
    help = parser.format_help().strip()
    print(help)



# Generated at 2022-06-21 13:22:13.211086
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    usage = """
    Parse arguments and return tuple of
    (RequestItems,
     namedtuple('Environment', ['stream', 'stdout_isatty', 'colors']),
     namedtuple('OutputOptions', ['pretty', 'ugly'])).

    """
    parser = argparse.ArgumentParser(description=usage,
                                     formatter_class=HTTPieHelpFormatter)
    args = parser.parse_args()


# Unit test function

# Generated at 2022-06-21 13:23:18.050714
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=HTTPieHelpFormatter)
    parser.print_help()


# Generated at 2022-06-21 13:23:23.939139
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Create a instance of HTTPieArgumentParser
    parser = HTTPieArgumentParser(
        formatter_class=lambda prog: HTTPieHelpFormatter(prog, max_help_position=40))

    # Call parse_args of HTTPieArgumentParser
    args = parser.parse_args(args=[])

    # Test that vars of args is equal to the expected_vars

# Generated at 2022-06-21 13:23:33.954788
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    from httpie import base
    from httpie.base import http
    from httpie.constants import DEFAULT_UA
    from httpie.constants import PRETTY_MAP
    from httpie.constants import __version__
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.context import Environment
    # Create Environment. FIXME:
    http.config = base.Config()
    http.config.default_options = http.config.default_options
    http.config.load()
    http.session = requests.Session()
    http.session.trust_env = False
    http.headers = http.Headers(http.config.default_options['--headers'])
    http.__version__ = __version__
    http.__file__ = __file__
    http.auth_plugin_manager = plugin_

# Generated at 2022-06-21 13:23:45.119271
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    class TestHTTPieArgumentParser(HTTPieArgumentParser):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.env = TestEnv()
    
    parser = TestHTTPieArgumentParser()
    args = parser.parse_args(["--traceback", "https://postman-echo.com/get", "--form", "a=b", "c=d"])
    
    
    
    # Write tests for HTTPieArgumentParser class
    # Find these properties from the args object
    assert(args.traceback == True)
    assert(args.url == "https://postman-echo.com/get")
    
    
    assert(args.data) is not None
    assert(args.headers) is not None

# Generated at 2022-06-21 13:23:46.174016
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    HTTPieArgumentParser()

# Generated at 2022-06-21 13:23:57.492429
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser(
        args=[],
        env=Env()
    )
    parser.add_argument('--version', action='version', version='1.0')
    parser.add_argument('-x', '--proxy')
    parser.add_argument('-a', '--auth')
    parser.add_argument('--auth-type')
    parser.add_argument('--ignore-stdin', action='store_true')
    parser.add_argument('--body-json')
    parser.add_argument('--body-json-lines')
    parser.add_argument('--body-yaml')
    parser.add_argument('--body-multipart')
    parser.add_argument('-t', '--timeout')
    parser.add_argument('--check-status')
    parser.add_

# Generated at 2022-06-21 13:24:09.234438
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser(prog='test', description='test')
    args = parser.parse_args(
        ['--debug=True', '--output-file=test', '--form', '--json', '--check-status', '--check-headers', '--style=formatting', '--style=colors', '--style=default-scheme-headers', '--style=colors', '--style=colors']
    )
    assert args.debug
    assert args.output_file.name == 'test'
    assert args.form
    assert args.json
    assert args.check_status
    assert args.check_headers
    assert args.style == 'formatting,colors,default-scheme-headers'

# Generated at 2022-06-21 13:24:13.673108
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        description='test',
        formatter_class=HTTPieHelpFormatter,
    )
    parser.add_argument('--foo', help="""
        one
        two
    """)
    parser.parse_args(['--help'])



# Generated at 2022-06-21 13:24:22.224695
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(args=[])
    assert args.url == ''
    assert args.headers == []
    assert args.request_items == []
    assert args.method == 'GET'
    assert args.auth is None
    assert args.auth_type is None
    assert args.ignore_netrc is False
    assert args.download is False
    assert args.download_resume is False
    assert args.output_file is None
    assert args.output_options is None
    assert args.output_options_history is None
    assert args.body_type is None
    assert args.follow is False
    assert args.follow_redirects is False
    assert args.ignore_stdin is False
    assert args.verify is True
    assert args.stream is False

# Generated at 2022-06-21 13:24:32.800775
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # check values of args
    with open('HTTPieArgumentParser_test.txt','r') as f:
        lines = f.readlines()
    count = 0
    for line in lines:
        count += 1
        if count % 3 == 1:
            tmp = line.split(' ')
            args = tmp[0].replace('\'', '')
            args = args.split(',')
            args.insert(0, "http") # NOTE: 'http' is the default cmd
        if count % 3 == 2:
            tmp2 = line.split(' ')
            kwargs = tmp2[0].replace('\'', '')
            kwargs = kwargs.split(',')
        if count % 3 == 0:
            tmp3 = line.split(' ')

# Generated at 2022-06-21 13:27:13.405476
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    class TestArgumentParser(argparse.ArgumentParser):
        def __init__(self, **kwargs):
            super().__init__(
                formatter_class=HTTPieHelpFormatter,
                **kwargs
            )

    parser = TestArgumentParser(
        prog='http',
        usage='%(prog)s some-url arg1 arg2',
        description='description',
        epilog='epilog',
        add_help=False,
    )
    parser.add_argument('foo', help='  line1\n  line2\n\n  line4\n')
    parser.print_help()


# Generated at 2022-06-21 13:27:22.175371
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    args = HTTPieArgumentParser().parse_args([
        'GET',
        'http://httpbin.org/get',
        'X-API-Token: 123'
    ])

# Generated at 2022-06-21 13:27:26.203679
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Initialize argument parser
    parser = HTTPieArgumentParser()
    # Check parse_args method returns None
    assert parser.parse_args() is None

test_HTTPieArgumentParser_parse_args()


# Generated at 2022-06-21 13:27:30.973386
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """
    Test HTTPieArgumentParser.parse_args.
    """
    
    args = ['http', '--help']
    parser = HTTPieArgumentParser(httpie_args=args, env=Environment())
    result = parser.parse_args()
    assert result.method is None

# Generated at 2022-06-21 13:27:32.785200
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    HTTPieArgumentParser()

# Generated at 2022-06-21 13:27:42.347274
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():

    assert HTTPieArgumentParser.__doc__ == ArgumentParser.__doc__
    assert HTTPieArgumentParser.error.__func__ == ArgumentParser.error.__func__
    assert HTTPieArgumentParser.exit.__func__ == ArgumentParser.exit.__func__

    ap = HTTPieArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
        fromfile_prefix_chars='@',
        add_help=False,
    )
    ap.add_argument('-h', '--help', dest='help', action='store_true',
                    help='Show this help message and exit.')
    ap.add_argument('--version', dest='version',
                    action='store_true', help='Show the version and exit.')
    args = ap.parse_args([])

# Generated at 2022-06-21 13:27:47.823218
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    class TestParser(argparse.ArgumentParser):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, formatter_class=HTTPieHelpFormatter,
                             **kwargs)
    parser = TestParser(description='Some desc.')
    args = parser.parse_args([])


# Generated at 2022-06-21 13:27:57.557204
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    arg_parser = HTTPieArgumentParser()
    assert arg_parser.add_argument('--foo', action='store_true')
    assert arg_parser.add_argument('-a')
    assert not arg_parser.add_argument('-b')
    with pytest.raises(SystemExit):
        arg_parser.parse_args(['-b'])
    assert arg_parser.parse_args(['-b', '-a', '1'])
    with pytest.raises(SystemExit):
        arg_parser.parse_args(['-a', 'arg1', 'arg2'])
    assert arg_parser.parse_args(['arg1', '-a', 'arg2'])
    assert not arg_parser.parse_args(['--foo', 'arg1', '-a'])

# Generated at 2022-06-21 13:28:03.708619
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = HTTPieArgumentParser(env={}).parse_args([])
    assert args.method is None
    assert args.auth is None
    assert args.headers is None
    assert args.data is None
    assert not args.output_stderr
    assert not args.session
    assert args.max_redirects is None
    assert args.verify is True
    assert args.prettify is None
    assert args.download is False
    assert args.timeout is None
    assert args.check_status is False
    assert args.follow is True
    assert args.all is False
    assert args.print_body is True
    assert args.output_file is None
    assert args.output_options is None
    assert args.output_options_history is None

    assert not args.ignore_stdin
    assert args.tra

# Generated at 2022-06-21 13:28:14.425837
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    sample_help = '''
        foo:
            foo is a special argument
        bar:
            bar is another special argument
    '''
    assert HTTPieHelpFormatter.__init__.__doc__ == "A nicer help formatter."
    assert HTTPieHelpFormatter._split_lines.__doc__ == "Split a text into a list of lines."
    assert HTTPieHelpFormatter._split_lines(None, sample_help, 80) == ['foo:', '    foo is a special argument', 'bar:', '    bar is another special argument']
    assert HTTPieHelpFormatter._split_lines(None, sample_help, 20) == ['foo:', '    foo is a', 'special argument', 'bar:', '    bar is another', 'special argument']
