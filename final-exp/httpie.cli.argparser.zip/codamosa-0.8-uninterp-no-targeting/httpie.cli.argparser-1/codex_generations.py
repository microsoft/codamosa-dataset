

# Generated at 2022-06-21 13:19:30.721259
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(prog='http',
                                     description='HTTPie %s' % __version__,
                                     epilog='See ' + docs_url,
                                     formatter_class=HTTPieHelpFormatter,
                                     add_help=False)
    # The default width is 80 chars (click.termui.get_terminal_size()[0])
    # and the max help position (max_help_position) is 6.
    # The indent for the args help is 4 spaces and the indent for
    # the epilog is 6 spaces, so the maximum allowed chars is:
    # 80 - 4 - 6 - 2 (because there are two extra spaces between the args
    # help and the epilog) = 68.

# Generated at 2022-06-21 13:19:36.220940
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    httpie = HTTPieArgumentParser()
    try:
        from httpie.compat import is_windows
        if not is_windows:
            httpie.version = "1.0.1"
            parser = httpie.parse_args([])
            assert httpie.version in str(parser)
    except ImportError:
        pass

# Generated at 2022-06-21 13:19:45.994815
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from requests import Session
    from requests.cookies import RequestsCookieJar
    from httpie import __version__
    from httpie.input import KeyValueArgType
    from httpie.plugins import plugin_manager
    
    httpie = HTTPieArgumentParser()
    env = httpie.env
    args = httpie.args
    parser = httpie.parser
    session = httpie.session
    plugin_manager = httpie.plugin_manager
    http_options = httpie.http_options
    

# Generated at 2022-06-21 13:19:58.587849
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # FIXME: `sys.executable` fails in tests
    argv = ['http', 'httpbin.org']
    parser = HTTPieArgumentParser()
    parser.add_argument('-v', action='store_true')
    args = parser.parse_args(argv)

# Generated at 2022-06-21 13:20:10.417918
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TEST SETUP
    # --install-completion and --save-config
    # are handled by __init__ and are not tested here.
    parser = HTTPieArgumentParser()
    try:
        argparse.ArgumentParser(add_help=False, prog='http')
    except TypeError:
        # Python < 3.3 doesn't allow `prog` in __init__.
        parser.prog = 'http'

    args = parser.parse_args([])
    assert args.output_options == OUTPUT_OPTIONS_DEFAULT
    assert args.output_options_history == OUTPUT_OPTIONS_DEFAULT
    assert args.prettify == PRETTY_MAP['all']
    assert args.colors == 256
    assert args.unicode
    assert args.follow

# Generated at 2022-06-21 13:20:11.969565
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    # test constructor
    HTTPieHelpFormatter()



# Generated at 2022-06-21 13:20:15.170737
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    name = 'HTTPieHelpFormatter'
    instance = HTTPieHelpFormatter()
    assert name == instance.__class__.__name__


# Generated at 2022-06-21 13:20:22.670829
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    import argparse
    formatter = HTTPieHelpFormatter()
    parser = argparse.ArgumentParser(formatter_class=formatter)
    parser.add_argument(
        "addresses",
        metavar="ADDR",
        type=str,
        nargs="+",
        help="""
            an IP address.
            may be repeated
        """
    )
    parser.print_help()


# Generated at 2022-06-21 13:20:26.096629
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    #
    help_formatter = HTTPieHelpFormatter(max_help_position=50)
    assert help_formatter.max_help_position == 50, "The initial value of max_help_position is not equal."


# Generated at 2022-06-21 13:20:27.551073
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser(env=Environment())
    parser.register_argument('-t', '--timeout')
    parser.register_argument('-p', '--parallel')
    return parser;


# Generated at 2022-06-21 13:21:30.943682
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert 'HTTPieHelpFormatter' in globals()
    assert isinstance(HTTPieHelpFormatter, type)



# Generated at 2022-06-21 13:21:34.315312
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser(prog='args_parser')
    assert isinstance(parser.args, Arguments)
    assert isinstance(parser.args, Namespace)


# Generated at 2022-06-21 13:21:37.213010
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    ap = HTTPieArgumentParser()
    assert isinstance(ap, HTTPieArgumentParser)
    ap_result = ap.parse_args()
    assert isinstance(ap_result, Namespace)

# Generated at 2022-06-21 13:21:44.609937
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    """
    Test class HTTPieHelpFormatter
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    parser.add_argument('--bar')
    parser.add_argument('baz')
    help_message = """\
        A longer, indented for comparison

        help for --foo.

        help for --bar that is also
        longer and indented.
        """
    parser.add_argument('--foo', help=help_message)
    _, args_help = parser.format_help().split("positional arguments:")
    assert args_help == """\
  baz

  --foo  A longer, indented for comparison

        help for --foo.

  --bar  help for --bar that is also
         longer and indented.

"""


# Generated at 2022-06-21 13:21:53.686307
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        description='httpie',
        formatter_class=HTTPieHelpFormatter)
    parser.add_argument(
        '-v',
        action='store_true',
        help='variable\n'
             '\n'
             'additional text',
    )
    lines = parser.format_help().splitlines()
    assert lines[lines.index('-v                variable') + 1] == \
        '                  additional text'


# Generated at 2022-06-21 13:21:54.589455
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser(formatter_class=HttpieHelpFormatter)

# Generated at 2022-06-21 13:21:59.644872
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    args = parser.parse_args()
    for config in (args.config_dir, args.config_file):
        assert os.path.isfile(config) and os.access(config, os.R_OK)

if __name__ == '__main__':
    test_HTTPieArgumentParser()

# Generated at 2022-06-21 13:22:11.508560
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    my_help_string = "Usage: http [http://hostname[:port]/]URI.\n" \
    "  The default host is http://localhost, and the default port is 80.\n" \
    "  Use - for the URI to read a string from standard input.\n" \
    "  If the URI contains a colon or backslash or starts with a slash, it is treated\n" \
    "  as the path to a file.\n" \
    "  Otherwise it is treated as a URL.\n" \
    "\n" \
    "Example:\n" \
    "  http http://example.com/\n" \
    "  http -h 'Content-Type:application/json' -f POST http://example.com/ < data.json\n" \
    # "  http -

# Generated at 2022-06-21 13:22:17.113029
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    print("Test begin!")
    config = Config(
        colors = 256,
        defaults = {},
        env = {},
        config_dir = '',
        config_file = '',
        config_file_path = '',
        config_dirs = [],
        config_files = []
    )
    parser = HTTPieArgumentParser(config = config)

# Generated at 2022-06-21 13:22:28.339632
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.parse_args([])
    assert parser.args.exit_status == ExitStatus.OK
    assert parser.args.output_options_history == 'BHJq'
    assert parser.args.output_options == 'BHJ'
    assert parser.args.download_resume is False
    assert parser.args.download is False
    assert parser.args.prettify == set()
    assert parser.args.follow is False
    assert parser.args.session is None
    assert parser.args.auth is None
    assert parser.args.auth_type is None
    assert parser.args.output_file_specified is False
    assert parser.args.output_file is None
    assert parser.args.output_file_specified is False
    assert parser.args.output_file is None


# Generated at 2022-06-21 13:23:47.865004
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    from httpie.core import Environment
    from httpie.cli.base import parser
    env = Environment()
    p = parser(env=env)
    assert isinstance(p, HTTPieArgumentParser)

# Generated at 2022-06-21 13:23:59.829795
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # create a new parser
    parser = HTTPieArgumentParser(prog='http',
                                  epilog='See https://httpie.org/doc for details.',
                                  formatter_class=argparse.RawDescriptionHelpFormatter,
                                  description=__doc__.splitlines()[0],
                                  add_help=False
                                 )

    # add the sub-parser for the verify command to the parser
    subparsers = parser.add_subparsers(dest='command')
    parser_verify = subparsers.add_parser('verify', help='Verify the SSL certificate.')


# Generated at 2022-06-21 13:24:12.247182
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.parse_args(["httpbin.org/ip"])
    parser.parse_args(["httpbin.org/post"])
    parser.parse_args(["httpbin.org/get"])
    parser.parse_args(["httpbin.org/put"])
    parser.parse_args(["httpbin.org/patch"])
    parser.parse_args(["httpbin.org/delete"])
    parser.parse_args(["httpbin.org/status/418"])
    parser.parse_args(["httpbin.org/cookies/set?k1=v1"])
    parser.parse_args(["httpbin.org/cookies"])

# Generated at 2022-06-21 13:24:14.683985
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert HTTPieHelpFormatter.__name__ == 'HTTPieHelpFormatter'


FORMATTER = HTTPieHelpFormatter



# Generated at 2022-06-21 13:24:18.526380
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    # SUT
    parser = HTTPieArgumentParser()
    # ARRANGE
    parser._actions = []
    parser._optionals = None
    parser._positionals = None

    # ACT
    result = parser.parse_args()

    # ASSERT
    assert result == argparse.Namespace()


# Generated at 2022-06-21 13:24:24.322794
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test case 1
    test_input = {
        "args" : "http://example.com/path",
        "env" : FakeEnvironment()
    }

# Generated at 2022-06-21 13:24:25.464883
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    parser

# Generated at 2022-06-21 13:24:27.442428
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO: Implement
    raise SkipTest # TODO: put implementation here.



# Generated at 2022-06-21 13:24:28.503504
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # TODO: test
    pass


# Generated at 2022-06-21 13:24:32.166335
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Given
    parser = HTTPieArgumentParser()
    args = None
    try:
        # When
        args = parser.parse_args([])
    except SystemExit:
        pass

    # Then
    assert args is not None

 

# Generated at 2022-06-21 13:26:14.035977
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert(HTTPieHelpFormatter() == RawDescriptionHelpFormatter())



# Generated at 2022-06-21 13:26:21.479085
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    input_copy = sys.argv.copy()
    del sys.argv[1:]
    sys.argv.append("http")
    sys.argv.append("--download")
    sys.argv.append("http://httpbin.org/get")
    sys.argv.append("--output=path123")
    #sys.argv.append("-v") # prints version
    args = parser.parse_args()
    print(f"args = {args}")
    sys.argv = input_copy

test_HTTPieArgumentParser_parse_args()


# Generated at 2022-06-21 13:26:30.452590
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """Test the class HTTPieArgumentParser using unittest model."""
    import argparse
    import sys
    import os
    import contextlib
    import io

    class MyArgumentParser(HTTPieArgumentParser):
        """
        Define the description of class HTTPieArgumentParser.
        """
        def __init__(self, *args, **kwargs):
            """Define the method __init__ of class HTTPieArgumentParser."""
            super(MyArgumentParser, self).__init__(*args, **kwargs)
            self.add_argument('-m', '--method', dest='method', default=None)

    @contextlib.contextmanager
    def captured_output():
        """Define the context manager captured_output."""
        new_out, new_err = io.StringIO(), io.StringIO

# Generated at 2022-06-21 13:26:38.634571
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie.args import IGNORE_STDIN
    hp = _HTTPieArgumentParser()
    args = hp.parse_args('-h')
    assert args.headers == []

    # test --help
    args = hp.parse_args('--help')
    assert args.help
    args = hp.parse_args('-v')
    assert args.version

    # test --json
    args = hp.parse_args('--json')
    assert args.json
    args = hp.parse_args('--json "[{\\"key\\": \\"value\\"}]"')
    assert args.json == [{"key": "value"}]

    # test --pretty
    args = hp.parse_args('--pretty')
    assert args.prettify == 'colors'

# Generated at 2022-06-21 13:26:41.568512
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """
    test the constructor of class HTTPieArgumentParser
    :return: None
    """
    if __name__ == "__main__":
        # invoke test_HTTPieArgumentParser
        test_HTTPieArgumentParser()
    ap = HTTPieArgumentParser()
    assert ap.parser is not None



# Generated at 2022-06-21 13:26:45.743662
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    with open('formatter_test.txt', 'w') as fp:
        formatter.add_usage(fp, 'abc', 'def')
        formatter.add_arguments(fp, 'abc')
    sys.exit(1)


# Generated at 2022-06-21 13:26:56.023137
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    with test_env(stdin=subprocess.PIPE) as env:
        args = HTTPieArgumentParser(env=env).parse_args([
            '--verbose', 'localhos'
        ], env=env)
        assert args.url == 'localhos'
        assert args.method == 'GET'
        assert args.data == []
        assert args.files == {}
        assert args.headers == []
        assert args.params == []
        assert args.output_file is None
        assert args.output_options == 'Hhb'
        assert args.traceback is False
        assert args.check_status is False
        assert args.download is False
        assert args.download_resume is False
        assert args.max_redirects == 5
        assert args.timeout == DEFAULT_TIMEOUT

# Generated at 2022-06-21 13:27:02.589495
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    """Unit test for constructor of class HTTPieHelpFormatter"""
    hhf = HTTPieHelpFormatter()
    assert hhf.max_help_position == 6


# Generated at 2022-06-21 13:27:07.585218
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    
    # test_01
    p = HTTPieArgumentParser()

# Generated at 2022-06-21 13:27:16.809698
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.constants import RequestType
    from httpie.cli.environment import Environment
    from httpie.cli.parser import Parser
    from httpie.cli.requestitems import RequestItems
    env = Environment()
    parser = Parser(env)
    parser.parse_args([])
    parser.request_items = RequestItems()
    parser.request_items.add(
        RequestType.URL, 'https://developer.github.com/v3/repos/#list-organization-repositories'
    )