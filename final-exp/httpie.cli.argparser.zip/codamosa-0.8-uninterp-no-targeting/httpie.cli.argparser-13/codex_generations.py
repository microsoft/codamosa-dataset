

# Generated at 2022-06-21 13:19:32.688967
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    
    parser = HTTPieArgumentParser()
    args = ['http', 'http://example.org', 'GET', '-o', 'output.txt', '-f', '-a', 'user:pwd', '-H', 'Accept-Language: en']
    args = parser.parse_args(args)
    
    assert args.auth == 'user:pwd'
    assert args.url == 'http://example.org'
    assert args.method == 'GET'
    assert args.output_file == 'output.txt'
# API class
# Will create API class with it's constructor
# API will be pointed to API_URL
# API will be pointed to API_PORT


# Generated at 2022-06-21 13:19:38.006283
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.add_argument(dest='one', type=int)
    parser.add_argument(dest='two', type=int)
    parser.add_argument('-t', '--temp', dest='three')
    
    assert parser.parse_args(['1', '2', '-t', '3']) == argparse.Namespace(one=1, two=2, three='3')
    assert parser.parse_args(['1', '2', '-t3']) == argparse.Namespace(one=1, two=2, three='3')
    assert parser.parse_args(['1', '2', '-t', '3', '-t', '4']) == argparse.Namespace(one=1, two=2, three='3')
    assert parser.parse

# Generated at 2022-06-21 13:19:39.513248
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    _test_HTTPieArgumentParser_parse_args.__wrapped__()


# Generated at 2022-06-21 13:19:42.522118
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    fmt = HTTPieHelpFormatter()
    assert fmt._split_lines('\nLine1\nLine2\n', 100) == ['Line1', 'Line2', '', '']



# Generated at 2022-06-21 13:19:46.355107
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    text = """
    This is a description

    And this is a description for an argument.
    """
    lines = HTTPieHelpFormatter()._split_lines(text, 80)
    assert lines == [
        'This is a description',
        '',
        'And this is a description for an argument.',
        ''
    ]


# Generated at 2022-06-21 13:19:59.319982
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # basic usage
    p = HTTPieArgumentParser()
    assert p.args.debug is False
    assert p.args.traceback is False
    assert p.args.check_ssl is True
    assert p.args.download is False
    assert p.args.download_resume is False
    assert p.args.form is False
    assert p.args.all is False
    assert p.args.prettify is None

    # custom log level
    p = HTTPieArgumentParser(log_level=logging.DEBUG)
    assert p.args.debug is True
    assert p.args.traceback is False
    assert p.args.check_ssl is True
    assert p.args.download is False
    assert p.args.download_resume is False
    assert p.args.form is False
    assert p.args

# Generated at 2022-06-21 13:20:10.742775
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """
    Test HTTPieArgumentParser.parse_args()
    """
    parser = ArgParserForTest('')
    args = parser.parse_args(['http://www.baidu.com', '--output=-'])
    assert len(args.output_options_history) == len(args.output_options)

    args = parser.parse_args(['http://www.baidu.com', '--output-options=h'])
    assert len(args.output_options_history) == len(args.output_options)

    args = parser.parse_args(['http://www.baidu.com', '--output-options-history=h'])
    assert len(args.output_options_history) != len(args.output_options)

    # Test args.prettify

# Generated at 2022-06-21 13:20:12.382862
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO: Implement this test ...
    assert True


# Generated at 2022-06-21 13:20:24.978537
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
   # test case1
   http='GET'
   url='http://httpie.org'
   args=[]
   args.append('http')
   args.append('GET')
   args.append(url)
   argv=args
   argv=[]
   argv.append(http)
   argv.append(url)
   args=tuple(argv)
   parser=HTTPieArgumentParser(prog='http',add_help=False)
   parser.add_argument('method',metavar='METHOD',nargs='?')
   parser.add_argument('url',metavar='URL',nargs='?')
   parser.add_argument('--form',action='store_true',help='Use Form/Firerfox mode.'
   )

# Generated at 2022-06-21 13:20:28.895431
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        formatter_class=HTTPieHelpFormatter)
    parser.add_argument('--foo',
                        help='''
                            foo long
                            long help
                        ''',
                        default='foo')
    args = parser.parse_args(['--help'])


# Generated at 2022-06-21 13:21:10.520784
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        description='This is a description',
        formatter_class=HTTPieHelpFormatter)
    parser.add_argument('--foo', help='foo\nbar')
    parser.add_argument('bar', help='bar\nbaz')
    help = parser.format_help()
    assert 'foo\n  bar' in help
    assert 'bar\n  baz' in help
    # Make sure there is a newline after the first argument
    # since it doesn't end with \n.
    assert help.index('\n  bar') > help.index('bar\n  baz')


# Generated at 2022-06-21 13:21:16.147679
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser = HTTPieArgumentParser()
    # args_string = '--auth "user:pass" --check-status --debug --download --form -H "h1:v1" -h "h2:v2" "http://httpbin.org/post" name=John age=30'
    args_string = '--auth "user:pass" "http://httpbin.org/post" name=John age=30'
    args = httpie_argument_parser.parse_args(
        args_string.split())
    def print_attributes(obj):
        for attr in dir(obj):
            print("obj.%s = %s" % (attr, getattr(obj, attr)))

    print_attributes(args)

test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-21 13:21:22.305475
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=HTTPieHelpFormatter)
    parser.add_argument('--foo')
    assert parser.format_help().splitlines() == [
        'usage: test.py [-h] [--foo FOO]',
        '',
        'optional arguments:',
        '  -h, --help  show this help message and exit',
        '  --foo FOO   ',
        '',
        '               ',
        '',
        '',
    ]


# Generated at 2022-06-21 13:21:28.077947
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args_parser = HTTPieArgumentParser()
    args_parser.parse_args([
        'http',
        '--verbose',
        '--output=file.json',
        '--format',
        'pretty',
        '--h',
        'hello',
        '--data',
        'a=1&b=2',
        'g.com/test'
    ])

    assert args_parser.args.verbose == True
    assert args_parser.args.output == 'file.json'
    assert args_parser.args.format == 'pretty'
    assert args_parser.args.headers == [('H', 'hello')]
    assert args_parser.args.data == ['a=1&b=2']
    assert args_parser.args.url == 'g.com/test'

# Unit test

# Generated at 2022-06-21 13:21:39.455289
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    test_HTTPieArgumentParser = HTTPieArgumentParser(env=1, add_help=False)
    test_HTTPieArgumentParser.initialize_args()

# Generated at 2022-06-21 13:21:44.623421
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--debug',
                              'test_B6',
                              'http://www.baidu.com'])
    print(args)

#functions of class HTTPieArgumentParser

# Generated at 2022-06-21 13:21:47.860853
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    help_formatter = HTTPieHelpFormatter()
    assert isinstance(help_formatter, RawDescriptionHelpFormatter)


# Generated at 2022-06-21 13:21:58.775086
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():

    class TestEnv:

        def __init__(self):
            self.stdout_isatty = True
            self.stderr_isatty = True
            self.is_windows = False
            self.stdout = sys.stdout
            self.stderr = sys.stderr

    test = HTTPieArgumentParser(TestEnv())
    args = test.parse_args(['--output', 'file'])
    assert args.output_file is not None
    args = test.parse_args(['--output', 'file', '--quiet'])
    assert args.quiet is True
    assert args.output_file is not None



# Generated at 2022-06-21 13:22:00.739532
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    response = HTTPieArgumentParser.parse_args(['http', '-h'])

# Generated at 2022-06-21 13:22:12.776346
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # http --form --verbose
    args = HTTPieArgumentParser().parse_args(args_str='')
    assert not args.form
    assert not args.verbose
    args = HTTPieArgumentParser().parse_args(args_str='--form --verbose')
    assert args.form
    assert args.verbose
    # http -f -v
    args = HTTPieArgumentParser().parse_args(args_str='')
    assert not args.form
    assert not args.verbose
    args = HTTPieArgumentParser().parse_args(args_str='-f -v')
    assert args.form
    assert args.verbose
    # http --download
    args = HTTPieArgumentParser().parse_args(args_str='')
    assert not args.download
    args = HTTPieArg

# Generated at 2022-06-21 13:23:22.721155
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    help_str = "This is a test help_str"
    parser = argparse.ArgumentParser(formatter_class=HTTPieHelpFormatter)
    parser.add_argument('--test', 
                        help=help_str)
    print(parser.format_help())
    # assert parser.format_help() == help_str

# end of class HTTPieHelpFormatter


# Generated at 2022-06-21 13:23:25.777587
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    try:
        HTTPieHelpFormatter(max_help_position=6)
    except:
        print("Unit test for constructor of class HTTPieHelpFormatter failed.")


# Generated at 2022-06-21 13:23:35.147222
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # Test the constructor of class HTTPieArgumentParser
    parser = HTTPieArgumentParser()
    assert isinstance(parser, HTTPieArgumentParser)
    assert hasattr(parser, 'args')
    assert hasattr(parser, 'env')
    assert hasattr(parser, 'error')
    assert hasattr(parser, 'format_usage')
    assert hasattr(parser, 'format_help')
    assert hasattr(parser, 'format_version')
    assert hasattr(parser, 'parse_args')
    assert hasattr(parser, 'get_default_values')
    assert hasattr(parser, 'parse_known_args')
    assert hasattr(parser, 'print_usage')
    assert hasattr(parser, 'print_help')
    assert hasattr(parser, 'print_version')

# Generated at 2022-06-21 13:23:39.406357
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    assert formatter.width == 79
    assert formatter.max_help_position == 6
    assert formatter.help_position == 26 
    assert formatter.indent_increment == 2


# Generated at 2022-06-21 13:23:49.060247
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    sys.argv = 'http GET localhost:8000/api/courses/'.split()
    args = HTTPieArgumentParser().parse_args()
    assert args.url == 'http://localhost:8000/api/courses/'
    assert args.method == 'GET'

    sys.argv = 'http --help'.split()
    args = HTTPieArgumentParser().parse_args()
    assert args.help

    sys.argv = 'http POST localhost:8000/api/register/'.split()
    args = HTTPieArgumentParser().parse_args()
    assert args.url == 'http://localhost:8000/api/register/'
    assert args.method == 'POST'
    
    sys.argv = 'http GET localhost:8000/api/courses/ --auth username:password'.split()

# Generated at 2022-06-21 13:24:01.264164
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser(prog='http', env=None, args_files=[])
    parser.exit = lambda *a, **kw: None
    parser.error = lambda *a, **kw: None

    args = parser.parse_args('-f', '--form', '--json', "--foo", "bar", 'baz')

    assert args.json == 'bar'
    assert args.data == [('foo', 'baz')]
    assert args.headers == {}

    args = parser.parse_args(
        '--json', '{"k1": "v1"}', '--json', '{"k2": "v2"}', '--foo', 'bar')

    assert args.json == {
        'k1': 'v1',
        'k2': 'v2'
    }
    assert args

# Generated at 2022-06-21 13:24:02.301526
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    help_formatter = HTTPieHelpFormatter()
    assert help_formatter.max_help_position == 2


# Generated at 2022-06-21 13:24:02.931262
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()



# Generated at 2022-06-21 13:24:14.989534
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    from requests.compat import http_client
    http_client.HTTPConnection = MockHTTPConnection

    actual = HTTPieArgumentParser()
    expected = {'add_help': True, 'fromfile_prefix_chars': '@'}
    assert actual.__dict__ == expected, \
      (actual.__dict__, expected)

    actual = HTTPieArgumentParser().parse_args([])
    expected = {'prog': 'http', 'url': None, 'request_items': [],
                'output_file': None, 'auth_type': None}
    assert actual.__dict__ == expected, \
      (actual.__dict__, expected)


# Generated at 2022-06-21 13:24:23.126036
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from .output import BINARY_SUPPRESSED_NOTICE

    args = parser.parse_args([])
    assert args.debug == False
    assert args.download == False
    assert args.download_resume == False
    assert args.form == False
    assert args.headers == [
        'Accept: */*',
        'Accept-Encoding: gzip, deflate',
        'Connection: keep-alive',
        'Content-Length: 0',
        'Host: example.com',
        'User-Agent: HTTPie/0.9.9'
    ]
    assert args.ignore_netrc == False
    assert args.ignore_stdin == False
    assert args.max_headers == 0
    assert args.max_redirects == 5
    assert args.method == 'GET'
    assert args.output_

# Generated at 2022-06-21 13:26:58.801169
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():

    from httpie.status_codes import codes
    from httpie.cli import env
    from httpie.cli.args import parser

    # Test construction of class HTTPieArgumentParser
    def test_HTTPieArgumentParser_constructor():

        parser_obj = HTTPieArgumentParser(
            env=env,
            add_config_dir=True,
            add_help=True,
            add_output_options=True,
            add_output_options_history=True,
            add_pretty_options=True,
            add_verbose=True
        )

        assert (
            'HTTPie - cURL for humans'
            == parser_obj.description
        ), 'parser_obj.description is unexpected value'


# Generated at 2022-06-21 13:27:04.074822
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Success
    print('Test Success')
    print('Test 1')
    parser = HTTPieArgumentParser()

# Generated at 2022-06-21 13:27:14.780138
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser(request_items_type=RequestItems, env=Environment())
    assert parser.args is None
    assert parser.environ is None
    assert parser.args_file_finder is None
    assert parser.has_stdin_data is None
    assert parser.should_exit is None
    assert parser.args_file_settings is None
    assert parser.args.verbose == False
    assert parser.args.no_traceback is None
    assert parser.args.traceback is False
    assert parser.args.format is None
    assert parser.args.output_options is None
    assert parser.args.output_options_history is None
    assert parser.args.pretty is False
    assert parser.args.style is None
    assert parser.args.style_sheet is None
    assert parser.args.download is None

# Generated at 2022-06-21 13:27:23.828652
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    args = HTTPieArgumentParser().parse_args([])
    assert args.__class__.__name__ == 'Namespace', args.__class__.__name__
    ok_(hasattr(args, 'headers'), args)
    ok_(hasattr(args, '__dict__'), args)
    ok_(hasattr(args, '__dict__'), args)
    ok_(hasattr(args, '__dict__'), args)
    ok_(hasattr(args, '__dict__'), args)
    ok_(hasattr(args, '__dict__'), args)
    ok_(hasattr(args, '__dict__'), args)
    ok_(hasattr(args, '__dict__'), args)
    ok_(hasattr(args, '__dict__'), args)
    ok_(hasattr(args, '__dict__'), args)


# Generated at 2022-06-21 13:27:31.923331
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    help_formatter = HTTPieHelpFormatter()
    arg_text = 'bar'
    action = argparse.Action(option_strings='-h, --help', dest='help', default=argparse.SUPPRESS)
    try:
        help_formatter.add_argument(action)
    except TypeError:
        print("OUTPUT:", Output(True))
    result = help_formatter._split_lines(arg_text='bar', width=80)
    assert result == ['bar\n\n'], result


# Generated at 2022-06-21 13:27:34.077839
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    sys.argv = ["http", "--help"]
    args = parser().parse_args()


# Generated at 2022-06-21 13:27:43.344596
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # Test with multiple arguments
    args = ['--auth', 'username:password', 'https://http.bin']
    env = Environment(stdin=io.StringIO('Hello'), stdout=io.StringIO())
    parser = HTTPieArgumentParser(add_help=False)
    namespace = parser.parse_args(args, env)
    assert namespace.auth == 'username:password'
    assert namespace.url == 'https://http.bin'

    # Test with single argument
    args = ['https://http.bin']
    env = Environment(stdin=io.StringIO('Hello'), stdout=io.StringIO())
    parser = HTTPieArgumentParser(add_help=False)
    namespace = parser.parse_args(args, env)
    assert namespace.url == 'https://http.bin'

# Generated at 2022-06-21 13:27:54.847701
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    old_env = dict(os.environ)
    parser = HTTPieArgumentParser()
    parser.parse_args(args=['-h'])
    args = parser.parse_args(args=['https://httpbin.org', '--form','a=1', 'b=2', '-p', 'b', 'c=3'])
    # print('args.url:', args.url)
    # print('args.headers:', args.headers)
    # print('args.data:', args.data)
    # print('args.params:', args.params)
    assert args.url == 'https://httpbin.org'
    assert args.headers == [(':method', 'GET')]
    assert args.data == {'a': '1', 'b': '2'}

# Generated at 2022-06-21 13:28:03.820709
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    from httpie.cli.constants import OUTPUT_OPTIONS
    from httpie.cli.parser import get_parser

    parser = get_parser()
    
    for opt in OUTPUT_OPTIONS:
        arg = parser._option_string_actions[opt].metavar.upper()
        help_output = parser._option_string_actions[opt].help
        expected = dedent(help_output).strip() + '\n\n'
        assert arg.split('\n\n')[0] == expected.split('\n\n')[0], \
            "The help output for %s is not correctly dedented" % opt



# Generated at 2022-06-21 13:28:09.337016
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """
    1. Test for parsing arguments contained in an argparse.Namespace,
       which can be accessed via the "args" property, e.g., args.url.
    2. Test for the correct initialization of the corresponding attributes.
    3. Test for the correct initialization of the corresponding env.
    4. Test for the correct initialization of the corresponding config.
    5. Test for the correct initialization of the corresponding args.
    """
    # Get test input
    test_input_http_args = ['-v', 'httpbin.org/get']

    # Create an argparse parser
    args_parser = HTTPieArgumentParser()

    # Parse the test input
    args = args_parser.parse_args(test_input_http_args)

    # Assert the output
    assert args.url == 'httpbin.org/get'
   