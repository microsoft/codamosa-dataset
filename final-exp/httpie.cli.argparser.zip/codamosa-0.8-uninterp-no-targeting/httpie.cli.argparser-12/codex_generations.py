

# Generated at 2022-06-21 13:19:23.205839
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    help_formatter_inst = HTTPieHelpFormatter()
    help_formatter_inst._split_lines('1\n2', 2)



# Generated at 2022-06-21 13:19:24.145711
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    raise NotImplementedError


# Generated at 2022-06-21 13:19:25.869707
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    arg_parser = HTTPieArgumentParser();
    arg_parser.print_help()


# Generated at 2022-06-21 13:19:38.041200
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Create HTTPieArgumentParser instance and call parse_args method
    parser = HTTPieArgumentParser()
    args = parser.parse_args()
    # Assert that attributes of returned Argument Namespace are correct
    assert args.__class__.__name__ == 'Namespace'
    assert args.headers == []
    assert args.data == []
    assert args.files == {}
    assert args.params == []
    assert args.output_file == ''
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.form == False
    assert args.pretty == None
    assert args.style == None
    assert args.stream is True
    assert args.verify == True
    assert args.ssl == {}
    assert args.download == False
    assert args.download_resume == False


# Generated at 2022-06-21 13:19:42.901434
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    print('Test: HTTPieArgumentParser_parse_args')

    # Define the arguments for the HTTPieArgumentParser

# Generated at 2022-06-21 13:19:44.520857
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formater = HTTPieHelpFormatter()
    assert hasattr(formater, '_split_lines')


# Generated at 2022-06-21 13:19:54.092110
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        formatter_class=HTTPieHelpFormatter)

    parser.add_argument(
        '-a', '--auth',
        default=[],
        type=AuthCredentials(),
        metavar=' = '.join((
            'USER[:PASS]',
            '[TOKEN]'
        )),
        dest='auth',
        help=dedent("""\
        Specify a username and password for HTTP authentication.
        For more details see: https://httpie.org/docs#authentication

        """).strip())



# Generated at 2022-06-21 13:20:07.077853
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie.cli.parser import HTTPieArgumentParser
    from httpie.context import Environment
    from httpie.plugins import plugin_manager
    from httpie.compat import is_windows
    from httpie.input import SEP_CREDENTIALS
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.downloads import Downloader
    parser = HTTPieArgumentParser()
    args = parser.parse_args(
        args=['--user=admin:secret', 'http://localhost'], env=Environment(), stdin=None)

    credentials = parse_auth(args.auth)
    assert credentials.key == 'admin'
    assert credentials.value == 'secret'
    assert credentials.sep == SEP_CREDENTIALS

# Generated at 2022-06-21 13:20:08.407595
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    HTTPieArgumentParser()

# Generated at 2022-06-21 13:20:11.553914
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert isinstance(parser, argparse.ArgumentParser)

if __name__ == '__main__':
    test_HTTPieArgumentParser()

# Generated at 2022-06-21 13:20:51.241455
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args('')
    assert args.prettify == True



# Generated at 2022-06-21 13:20:52.847203
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser(prog='http', env=Environment())
    assert parser.args.prettify == PRETTY_MAP[PRETTY_STDOUT_TTY_ONLY]

# Generated at 2022-06-21 13:20:54.740064
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    for i in parser._actions:
        print(i.dest,end=": ")
        print(i.choices)

if __name__ == '__main__':
    test_HTTPieArgumentParser()

# Generated at 2022-06-21 13:21:02.615708
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    sp = HTTPieArgumentParser()
    print(sp.args)
    print(sp.args.help)
    print(sp.args.headers)
    print(sp.env)
    print(sp.env.stdout)
    print(sp.env.stderr)
    print(sp.env.config)
    print(sp.env.config_dir)
    print(sp.env.config_path)
    print(sp.env.config_paths)
    print(sp.env.config_dir_path)
    print(sp.env.config_file_paths)
    print(sp.env.color)
    print(sp.env.colors)
    print(sp.env.default_options)
    print(sp.env.default_options.help)

# Generated at 2022-06-21 13:21:07.116015
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # Test the normal construction
    parser = HTTPieArgumentParser(description='test usage')
    # Test the exception of description
    try:
        HTTPieArgumentParser(description=1)
        raise AssertionError('should raise ValueError')
    except ValueError:
        pass


# Generated at 2022-06-21 13:21:18.707486
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():

    # Identify the location of function test_HTTPieHelpFormatter()
    dirname = os.path.dirname(__file__)

    # Find the location of file HTTPieHelpFormatter.txt
    fn = os.path.join(dirname, 'HTTPieHelpFormatter.txt')

    # Open file HTTPieHelpFormatter.txt
    f = open(fn, 'r')

    # Read the content of file HTTPieHelpFormatter.txt
    text = f.read()

    # Close file HTTPieHelpFormatter.txt
    f.close()

    # Set the width to 30
    width = 30

    # Get a new object of class HTTPieHelpFormatter
    h = HTTPieHelpFormatter(width = width)

    # Call function _split_lines() of class HTTPieHelpFormatter
    # to split the content of

# Generated at 2022-06-21 13:21:20.053520
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert parser is not None



# Generated at 2022-06-21 13:21:27.257989
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    # *args - the positional arguments to format
    # **kwargs - the named arguments to format
    A = "This is a short line", "This is a very long line that should be wrapped because it is bigger than 50 characters"
    B = {"a":"This is a short line","b":"This is a very long line that should be wrapped because it is bigger than 50 characters"}
    try:
        formatter = HTTPieHelpFormatter(*A)
        # Test that description of the argument is correctly formatted
        assert formatter.max_help_position == 6
    except Exception as e:
        # Test that the correct exception is raised
        assert isinstance(e, Exception)

# Generated at 2022-06-21 13:21:32.108339
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser()
    parser.add_argument('-a', help='a\n\n b')
    parser.add_argument('-b', help='a\n\n b')
    parser.print_help()


# Generated at 2022-06-21 13:21:36.181658
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['https://httpbin.org/get', '--json'])
    assert args.url == 'https://httpbin.org/get'
    assert args.json is True

# Generated at 2022-06-21 13:22:55.851630
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser()
    parser.add_argument('-a', help='some help text')
    parser.add_argument('--another', help='another help text')
    parser.format_help()
    print(parser.format_help())
    print()
    parser = argparse.ArgumentParser()
    parser.add_argument('-a', help='some help text')
    parser.add_argument('--another', help='another help text')
    parser._optionals.title = 'arguments'
    # print()
    # print(parser.format_help())
    # print("=====================")
    # print(parser.format_usage())
    # print("=====================")
    # print(parser.format_help())
    # print("=====================")
    parser.format_help()
   

# Generated at 2022-06-21 13:22:56.845674
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    pass



# Generated at 2022-06-21 13:23:04.700210
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    # Unit tests for constructor of class HTTPieHelpFormatter
    assert_equals(HTTPieHelpFormatter(max_help_position=3)._width, 80)
    assert_equals(HTTPieHelpFormatter(max_help_position=3, width=120)._width, 120)
    # -1 = use _width as is (80)
    assert_equals(HTTPieHelpFormatter(max_help_position=-1)._width, 80)
    assert_equals(HTTPieHelpFormatter(max_help_position=-1, width=120)._width, 120)



# Generated at 2022-06-21 13:23:14.500184
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO: Passing argv to parse_args() is not the correct
    # way to test this function.
    parser = HTTPieArgumentParser()
    args = parser.parse_args()

    assert args.go_to_json is None, 'Default of go_to_json should be None'
    assert args.follow_all_redirects is None, 'Default of follow_all_redirects should be None'
    assert args.offline is None, 'Default of offline should be None'
    assert args.output_file is None, 'Default of output_file should be None'
    assert args.output_file_specified is None, 'Default of output_file_specified should be None'
    assert args.print_method is False, 'Default of print_method should be False'

# Generated at 2022-06-21 13:23:24.621985
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import os
    import requests
    import xmltodict


# Generated at 2022-06-21 13:23:28.291551
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = ['--traceback', 'http://localhost:8000/get']
    parser = HTTPieArgumentParser()
    args = parser.parse_args(args)
    assert args.traceback == True
    assert args.url == 'http://localhost:8000/get'

# Generated at 2022-06-21 13:23:33.873938
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    assert formatter._split_lines('\n\n    help\n\n', 80) == ['help']
    assert formatter._split_lines('\n   help help\n\n', 80) == ['help help']

_builtin_prettifiers = {
    'all', 'color', 'format', 'format_options',
    'json', 'pretty', 'stream', 'ugly'
}



# Generated at 2022-06-21 13:23:36.195097
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    """
    class HTTPieHelpFormatter(RawDescriptionHelpFormatter):
    """
    pass


# Generated at 2022-06-21 13:23:46.853648
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # HTTPieArgumentParser
    env = Environment(colors=256)
    args = HTTPieArgumentParser().parse_args(args=[], env=env)
    assert(args.url == '')
    assert(args.output_file == None)
    assert(args.auth_plugin == None)
    assert(args.auth == None)
    assert(args.auth_type == None)
    assert(args.data == None)
    assert(args.files == None)
    assert(args.form == False)
    assert(args.headers == None)
    assert(args.params == None)
    assert(args.ignore_stdin == False)
    assert(args.prettify == PRETTY_MAP['all'])
    assert(args.style == None)
    assert(args.style_path == None)

# Generated at 2022-06-21 13:23:58.314688
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    def new_formatter(text):
        formatter = HTTPieHelpFormatter(max_help_position=6, width=80)
        formatter.add_text(text)
        return formatter._current_indent, formatter._whitespace_matcher.sub(' ', formatter._retrieve_help()).strip()

    def add_text(text):
        assert new_formatter(text) == (0, text.strip())

    def add_text_with_indent(text):
        assert new_formatter('\n'.join([' ' * 12 + l for l in text.splitlines()])) == (12, text.strip())

    def add_text_with_empty_line(text):
        assert new_formatter(text) == (0, text.strip())


# Generated at 2022-06-21 13:26:46.144379
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    help_formatter = RawDescriptionHelpFormatter(max_help_position=7)
    help_formatter.max_help_position = 6
    assert help_formatter


# Generated at 2022-06-21 13:26:50.534217
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        prog='http',
        formatter_class=HTTPieHelpFormatter,
    )
    parser.add_argument('--foo', help='foo\nbar\nbaz')



# Generated at 2022-06-21 13:26:58.700445
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # parse_args
    # Tests for method parse_args of class HTTPieArgumentParser

    args = HTTPieArgumentParser().parse_args([])
    assert args.method is None
    assert args.url is None
    assert args.headers == CIMultiDict()
    assert args.auth is None
    assert args.auth_type is None
    assert args.auth_plugin is None
    assert args.data is None
    assert args.params == CIMultiDict()
    assert args.files == CIMultiDict()
    assert args.json == []
    assert args.json_stdin is False
    assert args.form == False
    assert args.body == False
    assert args.verbose == False
    assert args.headers_file == []
    assert args.output_file is None

# Generated at 2022-06-21 13:27:04.373464
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # Test passing no arguments
    try:
        test_parser = HTTPieArgumentParser()
        assert 1 == 0, "Shouldn't reach this point!"
    except SystemExit:
        assert 1 == 1
    except:
        assert 1 == 0, "Unexpected exception raised!"

    # Test passing only 'env' argument
    test_parser = HTTPieArgumentParser(env=None)
    assert isinstance(test_parser, HTTPieArgumentParser)

    # Test passing both arguments (with env=None)
    test_parser = HTTPieArgumentParser(usage=None, env=None)
    assert isinstance(test_parser, HTTPieArgumentParser)

    # Test passing both arguments (with env=Environ())
    test_parser = HTTPieArgumentParser(usage=None, env=Environ())

# Generated at 2022-06-21 13:27:10.560087
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    ap = HTTPieArgumentParser()
    assert isinstance(ap, HTTPieArgumentParser)
    assert isinstance(ap, argparse.ArgumentParser)
    return ap

if __name__ == "__main__":
    ap = test_HTTPieArgumentParser()
    assert isinstance(ap, HTTPieArgumentParser)
    assert isinstance(ap, argparse.ArgumentParser)

# Generated at 2022-06-21 13:27:12.367626
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.parse_args(["--help"])
    

# Generated at 2022-06-21 13:27:21.344118
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # Get the instance of `HTTPieArgumentParser`
    argumentParser = HTTPieArgumentParser()
    # Test: `_add_auth_group`
    # Use article: <https://segmentfault.com/a/1190000007383426>
    # to get the Node object.
    assert hasattr(argumentParser.parser, '_actions')
    is_auth_group_added = False
    for node in argumentParser.parser._actions:
        if isinstance(node, _ArgumentGroup):
            assert node.title == AUTH_GROUP.title
            is_auth_group_added = True
    assert is_auth_group_added

    # Test: `_apply_general_options`
    # Test: `_apply_no_options`
    # Test: `_apply_options`
    # Test: `_

# Generated at 2022-06-21 13:27:33.298018
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--pretty=all', 'POST', 'https://httpbin.org/post', 'foo=bar'])
    assert args.pretty == 'all'
    assert args.method == 'post'
    assert args.url == 'https://httpbin.org/post'
    assert args.request_items == [KeyValue(key='foo', value='bar', orig='foo=bar')]

if __name__ == '__main__':
    test_HTTPieArgumentParser_parse_args()
 
# ============================
# Output options
# ============================

OUTPUT_OPTIONS_ALL  = ''.join(OUTPUT_OPTIONS)

OUTPUT_OPTIONS_DEFAULT_STDOUT_REDIRECTED = OUTPUT_

# Generated at 2022-06-21 13:27:42.830754
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # 1. test with no configuration
    args = HTTPieArgumentParser().parse_args([])
    assert args.offline==False
    assert args.verify==True

    # 2. test with configuration with offline
    args = HTTPieArgumentParser(config=Config({'offline':True})).parse_args([])
    assert args.offline==True
    args = HTTPieArgumentParser(config=Config({"verify":False})).parse_args([])
    assert args.verify==False
    
    # 3. test with configuration and command line args
    args = HTTPieArgumentParser(config=Config({'offline':False,"verify":True})).parse_args(['--offline'])
    assert args.offline==True

# Generated at 2022-06-21 13:27:47.775738
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # p = HTTPieArgumentParser(None, {})
    # p.add_argument('--foo', type=int)
    # args = p.parse_args(['-f1'])
    # assert args.foo == 1
    pass
