

# Generated at 2022-06-21 13:19:37.733310
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    from httpie.core import main
    def run(items, **kwargs):
        env = Environment(**kwargs)
        ap = HTTPieArgumentParser(
            env=env,
            items=items,
            stdin_isatty=False,
            stdout_isatty=False,
        )
        return main(ap, env)

    run(['httpie', 'GET', 'http://httpbin.org/get'])
    run(['httpie', 'http://httpbin.org/get'])
    run(['httpie', 'GET', 'http://httpbin.org/get', 'Accept:'])

# Generated at 2022-06-21 13:19:48.842809
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from command_args import get_default_arguments
    from env import Env
    from httpie import __version__
    from utils import Version
    from adict import ADict
    env = Env(headers={}, stdin=None, stdin_isatty=False,
        stdout=StringIO(), stdout_isatty=False)
    args = HTTPieArgumentParser(env=env).parse_args(
        args=[])
    assert args == ADict(), 'args should be {}'
    default_arguments = get_default_arguments()
    args = HTTPieArgumentParser(env=env).parse_args(
        args=default_arguments.args)
    assert args.url == default_arguments.url, 'args.url should be {}'.format(default_arguments.url)
    assert args

# Generated at 2022-06-21 13:19:54.188312
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args_1 = ['http://localhost']
    args_2 = ['http://localhost', '--json']
    hx = HTTPieArgumentParser()
    hx.parse_args(args_1)
    hx.parse_args(args_2)
# nocov end


# Generated at 2022-06-21 13:20:02.136146
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """
    Unit test for HTTPieArgumentParser class method parse_args.
    """
    # Setup the parser object
    parser = HTTPieArgumentParser()
    # Test method parse_args with appropriate arguments
    args = parser.parse_args(['-v', 'http://httpbin.org/headers'])
    result = args.verbose
    expected_result = True
    # Test if the result is as expected
    assert result == expected_result

# Generated at 2022-06-21 13:20:07.455369
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """
    Test if the constructor of the class HTTPieArgumentParser executes
    properly and if it doesn't, raise the appropriate error.
    """
    assert_raises(HTTPieArgumentParser('test') == '<HTTPieArgumentParser: object at 0x7f45b685ac18>')


# Generated at 2022-06-21 13:20:13.967916
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    f = HTTPieHelpFormatter(max_help_position = 50)

    help = """
    This is a paragraph
    of help text.

    Argument help can be
    indented.

    It will be dedented
    and separated by a
    blank line.

    """
    help_lines = [
        '  This is a paragraph',
        '  of help text.',
        '',
        '  Argument help can be',
        '  indented.',
        '',
        '  It will be dedented',
        '  and separated by a',
        '  blank line.',
        '',
        ''
    ]
    assert help_lines == f._split_lines(help, 25)



# Generated at 2022-06-21 13:20:26.143057
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie.context import Environment
    from httpie.config import DEFAULT_CONFIG_DIR, DEFAULT_CONFIG_PATH
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie._compat import urlparse
    config_dir = os.path.dirname(os.path.dirname(DEFAULT_CONFIG_PATH))
    env = Environment(
        stdin=sys.stdin,
        stdout=sys.stdout,
        stderr=sys.stderr,
        config_dir=config_dir,
        config_path=DEFAULT_CONFIG_PATH,
        colors=256,
        prefer_ipv6=False,
        default_options=[]
    )

    # Initialize HTTPieArgumentParser
    parser = HTTPieArgumentParser(env=env)

    args

# Generated at 2022-06-21 13:20:29.619169
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    class TestArgs:
        arg_name = "test"

    formatter = HTTPieHelpFormatter(max_help_position=100)
    help_msg = formatter._format_action_invocation(TestArgs())
    assert help_msg == "test"



# Generated at 2022-06-21 13:20:36.294307
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """Unit test for constructor of class HTTPieArgumentParser."""

    parser = HTTPieArgumentParser(env=Environment(), prog="http",
                                  print_help=lambda: None)
    import textwrap

    # When user puts a space between a series of items, test if this
    # is correctly parsed
    args = shlex.split("""-H a -H b -Hc=d --print=hB key=value "key with space = value with space" 'key=value with spaces' f=@D:\\Users\\Jian\\Documents\\GitHub\\httpie\\tests\\data\\testfile""")
    parsed_args = parser.parse_args(args=args)
    assert parsed_args.headers == [
        ('a', None),
        ('b', None),
        ('c', 'd')
    ]

# Generated at 2022-06-21 13:20:38.721936
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    args = HTTPieArgumentParser({}, ['http', 'https://www.google.com'])
    # print(args.args)
    print(args.headers)
    print(args.data)
    print(args.files)
    print(args.params)
    print(args.multipart_data)

# test_HTTPieArgumentParser()

# Generated at 2022-06-21 13:21:41.789644
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    description = """Test help formatter."""
    parser = argparse.ArgumentParser(
        description=description,
        formatter_class=HTTPieHelpFormatter,
        add_help=False
    )
    parser.add_argument("-T", "--test", help="""
    Test
    Help
    Formatter
    """)
    parser_help = parser.format_help().split("\n")
    assert parser_help[1].strip() == "Test"
    assert parser_help[2].strip() == "Help"
    assert parser_help[3].strip() == "Formatter"



# Generated at 2022-06-21 13:21:44.573927
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """ Unit test for method parse_args of class HTTPieArgumentParser """
    # TODO: implement this
    pass



# Generated at 2022-06-21 13:21:54.711911
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    print(HTTPieHelpFormatter.__doc__)
    test_args = ('arg1', 'arg2', 'arg3')
    test_kwargs = {'help_text': 'help for arg',
                   'required_args_count': 1,
                   'nargs': '*'}
    parser = argparse.ArgumentParser(argument_default=argparse.SUPPRESS)
    parser.add_argument(*test_args, **test_kwargs)
    assert parser.format_help() == 'help for arg\n'


# Generated at 2022-06-21 13:22:03.435386
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    parser = HTTPieArgumentParser()
    parser.add_argument('first')
    parser.add_argument('second')
    parser.add_argument('-a', '--alphabet', action='append')
    parser.add_argument('-b')
    parser.add_argument('-c', action='store_true')
    parser.add_argument('-d', '--delta')
    parser.add_argument('-e', '--epsilon', action='store_false')
    parser.add_argument('-f', type=float)
    parser.add_argument('-g', action='count')
    parser.add_argument('-h', type=int)


# Generated at 2022-06-21 13:22:07.002951
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert isinstance(parser, HTTPieArgumentParser) == True

if __name__ == '__main__':
    #test_HTTPieArgumentParser()
    pass

# Generated at 2022-06-21 13:22:11.296342
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    with mock.patch('sys.argv', ['httpie', '--debug']):
        parser = HTTPieArgumentParser()
        args = parser.parse_args()
    assert args.output_options_history == OUTPUT_OPTIONS_DEFAULT_HISTORY

# Generated at 2022-06-21 13:22:22.365257
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    test_string = '''

        test

        test



        test

        test


    '''
    assert len(HTTPieHelpFormatter._split_lines(test_string, 80)) == 7, "Constructor must return 7 lines"


# class HTTPieHelpFormatter:
#     def add_arguments(self, actions):
#         # insert default value in arguments
#         if actions:
#             for action in actions:
#                 if action.default is not argparse.SUPPRESS:
#                     if not action.help:
#                         action.help = ''
#                     action.help += ('(default: %(default)s) ' % dict(default=action.default))
#
#         # format help insert
#         return super().add_arguments(actions)



# Generated at 2022-06-21 13:22:24.819130
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    print(parser)

if __name__ == "__main__":
    test_HTTPieArgumentParser()

# Generated at 2022-06-21 13:22:28.340903
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Uncomment/modify to customize the test
    parser = HTTPieArgumentParser()
    args = None
    assert parser.parse_args(args) == args, "parse_args() didn't return what I expected" # verify returned value


# Generated at 2022-06-21 13:22:30.738080
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    h = HTTPieArgumentParser()
    try:
        h.parse_args(['http', 'get'])
    except:
        pass



# Generated at 2022-06-21 13:23:49.155995
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    # Create a test instance of HTTPieArgumentParser
    parser = HTTPieArgumentParser(
        prog='http',
        env=Environment(),
        args_capsule=args_capsule,
    )

    # Call the method being tested
    args = parser.parse_args(['http://example.com'])

    # Verify that the method runs and returns
    assert args is not None

    # Verify that the args contain the expected values
    assert args.url == 'http://example.com'


# Use the following code to run unittests in a development environment.
# This will help ensure new code and refactored code does not introduce
# unintended behavior changes. Make sure to run the tests with every change.
#
# from httpie import httpie
# from httpie.core import httpie_files
# httpie_files.DATA_PATH =

# Generated at 2022-06-21 13:23:57.601717
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # 'create'
    parser = HTTPieArgumentParser()
    args = parser.parse_args(["--help"])
    assert args.debug == False
    assert args.download == False
    assert args.form == False
    assert args.ignore_stdin == False
    assert args.output_file == None
    assert args.timeout == DEFAULT_TIMEOUT
    assert args.traceback == False
    
if __name__ == "__main__":
    test_HTTPieArgumentParser_parse_args()
 

# Generated at 2022-06-21 13:24:08.918471
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(description='foo')
    parser.add_argument('--bar', help='bar help')
    parser.add_argument('--baz', help=dedent("""\
        baz help line 1
        baz help line 2
        """))
    help_str = parser.format_help()
    assert help_str == dedent("""\
        usage: test [-h] [--bar BAR] [--baz BAZ]

        foo

        optional arguments:
          -h, --help  show this help message and exit
          --bar BAR   bar help
          --baz BAZ   baz help line 1
                     baz help line 2
    """)



# Generated at 2022-06-21 13:24:12.247854
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    hhf = HTTPieHelpFormatter()
    assert hhf.__init__ == HTTPieHelpFormatter.__init__
    assert hhf._split_lines == HTTPieHelpFormatter._split_lines



# Generated at 2022-06-21 13:24:21.469060
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    help_formatter = HTTPieHelpFormatter(max_help_position=6)
    assert help_formatter.max_help_position == 6

GLOBAL_DEFAULT_OPTIONS = {
    'max_redirects': 30,
    'timeout': None,
    'headers': (),
    'output_options': OUTPUT_OPTIONS_DEFAULT,
    'download': False,
}

GLOBAL_DEFAULT_OPTIONS_OFFLINE = dict(GLOBAL_DEFAULT_OPTIONS,
                                      output_options=OUTPUT_OPTIONS_DEFAULT_OFFLINE)


# Generated at 2022-06-21 13:24:30.093039
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    # create parser for testing
    parser = argparse.ArgumentParser()
    parser.add_argument("--new")
    # use my customized formatter
    parser.formatter_class = HTTPieHelpFormatter
    parser.print_help()
    print('\n\n') # print extra new line

    # create parser for testing
    parser = argparse.ArgumentParser()
    parser.add_argument("--new")
    # use my customized formatter
    parser.formatter_class = argparse.RawTextHelpFormatter
    parser.print_help()


# Generated at 2022-06-21 13:24:32.167389
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    """A nicer help formatter.

    This is a unit test.

    """
    print("This is a unit test.")
    return 0


# Generated at 2022-06-21 13:24:37.594875
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    """
    >>> help_formatter = HTTPieHelpFormatter()
    >>> help_formatter._split_lines('\\n\\n DELETE /api/jobs/{job_id}\\n\\nDeletes a job.', 80)
    ['DELETE /api/jobs/{job_id}', '', 'Deletes a job.']
    >>> help_formatter.indent_increment
    1
    >>> help_formatter.max_help_position
    5
    """
    pass



# Generated at 2022-06-21 13:24:38.993775
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    with pytest.raises(SystemExit):
        HTTPieArgumentParser().parse_args(['-v', 'httpie'])

# Generated at 2022-06-21 13:24:41.810660
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    h = HTTPieArgumentParser()
    assert h.prog == 'http'
    assert h.name == 'http'
    assert h.description == 'cURL-like tool for humans'
    assert h.epilog == EPILOG
    assert h.allow_interspersed_args == False

# Generated at 2022-06-21 13:26:22.792125
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['GET', 'http://localhost'])
    assert args.url == 'http://localhost'
    assert args.method == 'GET'

if __name__ == '__main__':
    test_HTTPieArgumentParser_parse_args()
 
__all__ = (
    HTTPieArgumentParser,
)

# Generated at 2022-06-21 13:26:30.865502
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from json import loads
    from requests.cookies import RequestsCookieJar

    cookies = (
        'foo=bar;qux=baz; sessionToken=abc123; HttpOnly;'
        ' baz=foobar; sessionToken=xyz098'
    )
    assert loads(HTTPieArgumentParser().parse_args(
        ['--cookie', cookies, 'httpbin.org/cookies']
    ).cookies.get_dict()) == {
        'baz': 'foobar',
        'foo': 'bar',
        'qux': 'baz',
        'sessionToken': 'xyz098'
    }

    cookies = 'sessionToken=abc123; HttpOnly; XSRF-TOKEN=abc123;'

# Generated at 2022-06-21 13:26:38.958352
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():

    # testing the HTTPieArgumentParser class
    httpie_arg_parser = HTTPieArgumentParser()
    httpie_arg_parser.add_argument('--form',
                                   dest='form',
                                   action='store_true',
                                   default=False,
                                   help='Treat all data parameters as key=value form data.'
                                        ' If the data parameter is @filename, the contents of the file are sent as if it was the value of a key named after the base filename.')
    httpie_arg_parser.add_argument('--headers', action='append', default=[], dest='headers',
                                   help='Extra headers to be included in the request. '
                                        'Should be passed in the form of Header1: Value1, '
                                        'Header2: Value2, ...')
    httpie_arg_parser.add_

# Generated at 2022-06-21 13:26:50.681331
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from json import dumps
    from time import time
    from httpie.plugins import builtin
    for plugin in builtin.plugins:
        plugin_manager.register(plugin)

    parser = HTTPieArgumentParser()
    args = parser.parse_args([
        'https://httpie.org/get',
        'Accept:application/json',
        "X-API-Token:123"
    ])
    assert args.method == 'GET'
    assert args.headers == {'Accept': 'application/json', 'X-API-Token': '123'}
    assert args.url == 'https://httpie.org/get'
    assert args.auth_plugin is None


# Generated at 2022-06-21 13:26:58.831911
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # Instantiate an object of class HTTPieArgumentParser
    arg_parser = HTTPieArgumentParser()

    # Call method add_argument of class HTTPieArgumentParser
    name_space = arg_parser.add_argument('--auth', '--auth-type', action='store_true')
    # Check if method add_argument of class HTTPieArgumentParser returns the expected value
    print('Test 1:')
    print(name_space)

    # Call method parse_args of class HTTPieArgumentParser
    name_space = arg_parser.parse_args(['--auth', '--auth-type'])
    # Check if method parse_args of class HTTPieArgumentParser returns the expected value
    print('Test 2:')
    print(name_space)

    # Call method add_argument of class HTTPieArgumentParser
    name

# Generated at 2022-06-21 13:27:04.102059
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """Unit test for constructor of class HTTPieArgumentParser"""
    parser = HTTPieArgumentParser()
    # print("type(parser.args) =",type(parser.args))
    assert isinstance(parser.args, argparse.Namespace)
    # print("type(parser.env) =",type(parser.env))
    assert isinstance(parser.env, Environment)
    # print("type(parser.formatter_class) =",type(parser.formatter_class))
    assert isinstance(parser.formatter_class, argparse.HelpFormatter)
    # print("type(parser.cli_state) =",type(parser.cli_state))
    assert isinstance(parser.cli_state, HTTPieCliState)
    assert isinstance(parser.plugin_manager, PluginManager)


# Generated at 2022-06-21 13:27:08.767399
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    help_formatter = HTTPieHelpFormatter()
    text = 'send a GET request to the specified URL\n\n'
    n_lines = len(help_formatter._split_lines(text, 36))
    assert n_lines == 2



# Generated at 2022-06-21 13:27:17.478791
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """
    Test constructor of class HTTPieArgumentParser:
    - Check the number of actions added is correct
    - Check the number of arguments added is correct
    - Check if argument default values are correct
    """
    parser = HTTPieArgumentParser()
    parser.parse_args([])
    test_info = {}
    test_info["number_of_actions_added"] = 63
    test_info["number_of_arguments_added"] = 60

# Generated at 2022-06-21 13:27:20.148323
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    # Arrange
    func = lambda x,y:None
    help_formatter = HTTPieHelpFormatter(func)

    # Act
    assert None == help_formatter._split_lines("\nhhh\n", 0)



# Generated at 2022-06-21 13:27:31.300197
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie.core import parser
    from httpie.context import Environment
    parser = parser.HTTPieArgumentParser(Environment())
    
    args = parser.parse_args(['--ignore-stdin', '--form', 'user=bob', '--form', 'password=password', '--auth-type=basic', '--auth=username:password', 'http://localhost:5000/endpoint'])
    assert(args.data == [])
    assert(args.headers == [])
    assert(args.method == 'GET')
    assert(args.ignore_stdin == True)
    assert(args.auth_type.lower() == 'basic')
    assert(args.auth.lower() == 'username:password')
    assert(args.url == 'http://localhost:5000/endpoint')