

# Generated at 2022-06-21 13:19:24.832067
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(description='test', prog='test', formatter_class=HTTPieHelpFormatter)
    parser.add_argument('--test', help='''
        test
        test2''')
    parser.add_argument('--test2', help='''
        test
        test2''')
    print(parser.format_help())


# Generated at 2022-06-21 13:19:32.474971
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    httpie_parser = HTTPieArgumentParser()
    httpie_parser.add_argument("url", type=str)
    parsed_args = httpie_parser.parse_args("https://www.google.com".split(" "))
    assert isinstance(parsed_args, Namespace)
    assert parsed_args.url == "https://www.google.com"

if __name__ == '__main__':
    test_HTTPieArgumentParser()

# Generated at 2022-06-21 13:19:43.246172
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    args = argparse.Namespace()
    args.output_options = None
    args.output_options_history = None
    args.prettify = None
    args.prettify = None
    args.format = None
    args.download = False
    args.download_resume = False
    args.stream = False
    args.verbose = False

    args.output_file = None

    parser = HTTPieArgumentParser()
    parser.args = args

    parser._process_output_options()
    parser._process_pretty_options()
    parser._process_download_options()
    parser._process_format_options()

    assert parser.args.output_options == OUTPUT_OPTIONS_DEFAULT
    assert parser.args.output_options_history == OUTPUT_OPTIONS_DEFAULT

# Generated at 2022-06-21 13:19:55.402285
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args([])
    assert args.form == False
    assert args.offline == False
    assert args.output_file == None
    assert args.output_options == 'HhbB'
    assert args.prettify == 'all'
    args = parser.parse_args(['--form', '--offline', '--output-options', 'HhbB', '--prettify', 'all'])
    assert args.form == True
    assert args.offline == True
    assert args.output_options == 'HhbB'
    assert args.prettify == 'all'

# Generated at 2022-06-21 13:19:57.887840
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    obj = HTTPieHelpFormatter(max_help_position=3)
    assert obj.max_help_position == 3




# Generated at 2022-06-21 13:20:01.257723
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    args = parser.parse_args()
    print(args)

#test_HTTPieArgumentParser()

# Generated at 2022-06-21 13:20:11.666572
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args=['httpie','https://httpie.org']
    httpie_argumentparser=HTTPieArgumentParser()
    httpie_argumentparser.parse_args(args)
    assert httpie_argumentparser.args.method == None
    assert httpie_argumentparser.args.url == 'https://httpie.org'
    assert httpie_argumentparser.args.api == False
    assert httpie_argumentparser.args.pretty == False
    assert httpie_argumentparser.args.all == False
    assert httpie_argumentparser.args.form == False
    assert httpie_argumentparser.args.headers == None
    assert httpie_argumentparser.args.body == None
    assert httpie_argumentparser.args.verbose == False
    assert httpie_argumentparser.args.stream == False

# Generated at 2022-06-21 13:20:24.343301
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # test HTTPieArgumentParser constructor
    parser = htp.HTTPieArgumentParser()

    # test _get_formatter method
    formatter = parser._get_formatter()
    # test __del__ method
    del(formatter)

    # test add_argument
    parser.add_argument('--test')

    # test add_argument_group
    group = parser.add_argument_group('test_group')
    group.add_argument('--test-group')

    # test add_mutually_exclusive_group
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--test-mutually-exclusive-group')

    # test add_subparsers
    parser.add_subparsers()
    parser.add_subparsers(dest='subparser')

   

# Generated at 2022-06-21 13:20:26.188181
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args()
    print(args)


# Generated at 2022-06-21 13:20:30.505654
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    args = parser.parse_args()
    assert args.timeout == 60
    assert args.traceback == False  # pylint: disable=no-member
    assert args.user_agent is None
    assert args.adapters is not None
    assert args.interface is None
    assert args.json is False
    assert args.pretty is None
    assert args.style is None
    assert args.style_sheet is None
    assert args.download is False
    assert args.download_resume is False
    assert args.continue_downloads is False
    assert args.session is None
    assert args.output_file is None
    assert args.output_file_specified is False
    assert args.auth is None
    assert args.auth_plugin is None
    assert args.auth_type is None
   

# Generated at 2022-06-21 13:21:37.322900
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args_list = ['--verbose','https://www.myapifilms.com/imdb?title=Toy+story&format=JSON&aka=0&business=0&seasons=0&seasonYear=0&technical=0&filter=N&exactFilter=0&limit=1&lang=en-us&actors=N&biography=0&trailer=0&uniqueName=0&filmography=0&bornDied=0&starSign=0&actorActress=0&actorTrivia=0&movieTrivia=0&awards=0&moviePhotos=N&movieVideos=N&similarMovies=0&adultSearch=0&callback=JSONP_CALLBACK']
    args = HTTPieArgumentParser().parse_args(args_list)
    assert args.verbose is True

# Generated at 2022-06-21 13:21:41.981398
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    #Test for init
    assert HTTPieHelpFormatter.__init__(5,5,5) == None
    #Test for _split_lines
    assert HTTPieHelpFormatter._split_lines('\tthis is a test\n\tfor the class') == ['this is a test', 'for the class']




# Generated at 2022-06-21 13:21:56.087489
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    from argparse import Namespace
    from httpie import __version__
    from httpie.input import KeyValue
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.formatter import FORMATS

    def create_argparse_namespace(url, *args, **kwargs):
        """
        Custom function to create a instance of Namespace
        :param url:
        :param args:
        :param kwargs:
        :return:
        """
        namespace = Namespace()
        namespace.url = url
        namespace.request_items = []

        # Create the items
        for arg in args:
            namespace.request_items.append(arg)
        # Update the namespace with keyword arguments

# Generated at 2022-06-21 13:22:05.399390
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    p = HTTPieArgumentParser()
    args = p.parse_args(['--output-file', '-', '--download'])
    assert(args.output_file_specified)

test_HTTPieArgumentParser_parse_args()

# Examples of use:
# http https://example.org --download
# http https://example.org --download --output a.txt
# http https://example.org --download --output -
# http https://example.org --download
# http https://example.org
# http https://example.org --download --output -d

# Generated at 2022-06-21 13:22:09.407803
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    f = HTTPieHelpFormatter(max_help_position=1)
    lines = f._split_lines('''
    foo

    bar
    ''', 1)
    assert lines == ['foo', '', 'bar', '']



# Generated at 2022-06-21 13:22:10.511975
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    f = HTTPieHelpFormatter()


# Generated at 2022-06-21 13:22:13.877775
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    # The help info of the argument '--help' should be indented (without '-')
    # and contain 2 blank lines.
    assert '   -h, --help' in HTTPieHelpFormatter().format_help().splitlines()



# Generated at 2022-06-21 13:22:25.627861
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        prog = 'http',
        formatter_class = HTTPieHelpFormatter
    )
    parser.add_argument('--item',
                        help = """
                            This is a command line tool.
                            It helps you make HTTP requests.

                            * It is a cURL-like alternative with intuitive UI, JSON support, syntax highlighting, wget-like downloads, extensions, etc.
                            * httpie is a CLI, cURL-like tool for humans.

                            h2o-http is a fork of httpie which is no longer maintained.

                            """,
                        default = 'value',
                        required = False
    )
    args = parser.parse_args([])
    result = args.item
    expected = 'value'
    assert result == expected


# Generated at 2022-06-21 13:22:26.743148
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()


# Generated at 2022-06-21 13:22:35.783247
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args()
    assert args.url == 'https://httpbin.org/get'
    assert args.method == 'GET'
    assert args.headers == (('Accept', 'application/json'),)
    assert args.auth is None
    assert args.auth_type is None
    assert args.ignore_stdin is False
    assert args.help is False
    assert args.download is False
    assert args.download_resume is False
    assert args.output_file is None
    assert args.output_file_specified is False
    assert args.output_options is None
    assert args.output_options_history is None
    assert args.prettify == PRETTY_MAP[PRETTY_STDOUT_TTY_ONLY]
    assert args.body is None


# Generated at 2022-06-21 13:23:42.328465
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser(env=Environment(), add_help=False)
    args = parser.parse_args([])
    assert args.env == Environment(), args.env


# Generated at 2022-06-21 13:23:50.723571
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():

    args = HTTPieArgumentParser().parse_args('--traceback'.split())
    assert args.traceback

    args = HTTPieArgumentParser().parse_args('--print=H'.split())
    assert args.output_options == "H"

    args = HTTPieArgumentParser().parse_args('--download --continue'.split())
    assert args.download
    assert args.download_resume

    args = HTTPieArgumentParser().parse_args(['--timeout=10.0'.split()])
    assert args.timeout == 10.0

    args = HTTPieArgumentParser().parse_args('/dev/null'.split())
    assert args.url == '/dev/null'

    # FIXME: This is a hack to prevent an AttributeError

# Generated at 2022-06-21 13:24:03.055069
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    with patch('requests.sessions.Session.send', return_value=MockRequest(b'foo')):
        http = CLI()
        args = http.parser.parse_args(
            [
                '--auth-type=header',
                '--auth',
                'user:pass',
                '--headers',
                ':value',
                'http://httpbin.org/headers',
            ],
        )

    assert args.auth_type == AuthCredentials.TYPE_HEADER
    assert args.auth == AuthCredentials(value='user:pass')
    assert args.headers == [KeyValue('', 'value')]
    assert args.check_status
    assert args.follow_redirects
    assert args.max_redirects == 5
    assert args.timeout == DEFAULT_TIMEOUT
    assert args

# Generated at 2022-06-21 13:24:12.097633
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    class TestEnvironment(Environment):
        stdout_isatty = False
        stdin_isatty = False
        is_windows = False
        config_dir = None
        config = None

    parser = HTTPieArgumentParser(
        env=TestEnvironment(),
        prog=None,
        add_help=False,
        default_method=None,
        default_scheme=None
    )
    args = parser.parse_args(['example.com'])
    assert args.url == 'example.com'

# Generated at 2022-06-21 13:24:20.988929
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    obj = HTTPieArgumentParser()
    obj.add_argument('--version', action='version', version='HTTPie 0.0.9')
    obj.add_argument('-a', '--auth',
                     type=parse_auth,
                     help='username:password')
    obj.add_argument('-A', '--auth-type',
                     type=AuthCredentials,
                     help='Basic|Digest|AWS4-HMAC-SHA256')
    obj.add_argument('--cert', help='Path to TLS certificate file.')
    obj.add_argument('--data-binary',
                     help='Send data as binary (default for POST).')
    obj.add_argument('--download', '--download-all',
                     action='store_true',
                     dest='download',
                     help='Download all response data.')


# Generated at 2022-06-21 13:24:32.259443
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        formatter_class=HTTPieHelpFormatter)
    parser.add_argument('--foo', help="""\
        This is a very long long long long long long long
        long long long long long long long long long long
        long long long long long long long long long long
        long long long long long long long long long long
        long long argument that needs very long long long
        long long long long long long long long long long
        long long long long long long long long long long
        long long long long long long long long long long
        long long long long long long long help.""")
    # This would raise if the _split_lines method
    # of the formatter is not being used.
    parser_help = parser.format_help()
    assert long_help



# Generated at 2022-06-21 13:24:35.606315
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    hp = HTTPieArgumentParser()
    assert hp.status == 0
    assert hp.postbuf == None
    assert hp.postdata == None
    assert hp.response == None
    assert hp.is_logged == None

# Create the argument parser object

# Generated at 2022-06-21 13:24:41.722197
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    logger = logging.getLogger()
    # 单个测试
    def test(args, kargs):
        cmd = ' '.join(args)
        logger.info(cmd)
        args = HTTPieArgumentParser.parse_args(args)
        assert args.__dict__ == kargs
        return args
    # 具体测试
    args = ['-v', 'localhost', 'foo=bar', '--form', 'baz=qux', '-L']

# Generated at 2022-06-21 13:24:46.201113
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser(
        prog='http',
        description='HTTPie %s, a cURL-like, TUI-based HTTP client.' % __version__,
        epilog='See http://httpie.org for more info and usage examples.',
        add_help=False,
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    args = parser.parse_args('http httpie.org'.split())
    assert args.url == 'http://httpie.org'
    assert parser.args == args, 'HTTPieArgumentParser.args is not set'



# Generated at 2022-06-21 13:24:50.819800
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():

    description = "HTTPie - a CLI, cURL-like tool for humans."
    epilog = "See http://httpie.org for detailed usage information."
    parser = HTTPieArgumentParser(prog='http',
                                  description=description,
                                  epilog=epilog)
    assert parser.descripti