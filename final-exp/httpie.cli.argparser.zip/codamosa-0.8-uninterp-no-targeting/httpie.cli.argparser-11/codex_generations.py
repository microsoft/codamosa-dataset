

# Generated at 2022-06-21 13:19:27.346086
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    myparser = HTTPieArgumentParser()
    assert myparser._actions == []
    assert myparser._option_string_actions == {}


# Generated at 2022-06-21 13:19:31.787155
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert parser.parser_args['description'] == USAGE
    assert parser.parser_args['formatter_class'] == argparse.RawDescriptionHelpFormatter


# Generated at 2022-06-21 13:19:34.340556
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # noinspection PyProtectedMember
    parser = HTTPieArgumentParser()
    args = parser.parse_args([])

# Generated at 2022-06-21 13:19:38.553947
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    fake_parser = HTTPieArgumentParser()

    # Test one: create fake parser with fake args
    fake_args = []
    actual_output = fake_parser.parse_args(fake_args)
    expected_output = None

    assert actual_output == expected_output



# Generated at 2022-06-21 13:19:49.416188
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-21 13:19:56.610302
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.add_argument('--foo')
    parser.add_argument('bar')

    args = parser.parse_args('--foo 42'.split())
    assert args == argparse.Namespace(bar='bar', foo='42')

    # Converters should be applied.
    args = parser.parse_args('--foo 42 bar'.split())
    assert args == argparse.Namespace(bar='bar', foo='42')



# Generated at 2022-06-21 13:20:09.277995
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    test_url = "http://httpbin.org/"
    test = HTTPieArgumentParser("http")
    assert test._description == 'HTTPie %s, a CLI, cURL-like tool for humans.' % __version__
    assert test.argparser.prog == 'http'
    assert test.argparser.usage == 'http [<url> | -f FILE] [options] [<http-data>]'
    assert test._request_method_default == 'GET'
    assert test._request_data_default == ''
    assert test.has_stdin_data == False
    assert test.env.is_windows == sys.platform.startswith('win')
    test.args = test.argparser.parse_args([test_url])
    assert test.args.url == test_url
    test.args = test.argparser

# Generated at 2022-06-21 13:20:10.852660
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    httpie_args = HTTPieArgumentParser()
    assert httpie_args

# Generated at 2022-06-21 13:20:21.863819
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--foo',
        help="""
        Line 1
        Line 2
        """
    )
    actual = parser.format_help()
    expected = """\
usage: python -m unittest [-h] [--foo FOO]

optional arguments:
  -h, --help  show this help message and exit
  --foo FOO   Line 1
              Line 2
""".replace('python', sys.executable)
    assert expected == actual, actual
"""
Basic command line argument parser.

It provides a method for parsing HTTPie arguments
from the `sys.argv`.

"""



# Generated at 2022-06-21 13:20:30.863935
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    http = HTTPieArgumentParser()
    assert http.parse_args(['http', 'get', 'http://example.com'])
    assert http.parse_args(['http', 'get', 'http://example.com', 'key=value'])
    assert http.parse_args(['http', 'get', 'http://example.com', 'key==value'])
    assert http.parse_args(['http', 'get', 'http://example.com', 'key:=value'])
    assert http.parse_args(['http', 'get', 'http://example.com', 'key:==value'])
    assert http.parse_args(['http', 'get', 'http://example.com', 'key:json=value'])


# Generated at 2022-06-21 13:21:09.462764
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    s = '''
    A nicer help formatter.

    Help for arguments can be indented and contain new lines.
    It will be de-dented and arguments in the help
    will be separated by a blank line for better readability.


    '''
    assert(HTTPieHelpFormatter()._split_lines(s,10) == s.splitlines())



# Generated at 2022-06-21 13:21:20.528013
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-21 13:21:25.818645
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO: find a way to specify stdin to emulate user input
    args = HTTPieArgumentParser().parse_args(["--help"])
    print(args)

# Generated at 2022-06-21 13:21:32.065741
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert('\n\n'.join(HTTPieHelpFormatter()._split_lines(dedent("""\
        This is help text.

            > indentation is fine
            > and so is newline
        """))) == dedent("""\
        This is help text.

            > indentation is fine
            > and so is newline


        """))


# Generated at 2022-06-21 13:21:37.904862
# Unit test for constructor of class HTTPieHelpFormatter

# Generated at 2022-06-21 13:21:45.105276
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = list_to_args_tuples([
        'redis://localhost',
        '-v',
        '-a', 'user:pass',
        'key=val',
        '-d', 'hello',
        '-h', 'foo:bar',
        'X-Baz:123',
        '--timeout', '123',
        '--form',
        '-x',
        '--auth-type', 'basic',
        '--proxy', 'localhost:8080',
        '--download',
        '--offline',
    ])
    env = Environment()
    parser = HTTPieArgumentParser(prog='http', env=env)
    httpie_args = parser.parse_args(args)
    assert httpie_args.url == 'redis://localhost'
    assert httpie_args.method

# Generated at 2022-06-21 13:21:58.103926
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    h = HTTPieHelpFormatter(prog="http")
    parser = argparse.ArgumentParser(
        prog="http",
        formatter_class=HTTPieHelpFormatter,
    )
    parser.add_argument(
        "--foo",
        help="""
            Foo.

            Bar?
        """
    )
    parser.add_argument("--bar", help="Baz")
    args_help_str = parser.format_help().split("\n")
    foo_help_str = args_help_str[1]
    baz_help_str = args_help_str[4]
    assert foo_help_str == "  --foo  Foo."
    assert baz_help_str == "  --bar  Baz"


# Generated at 2022-06-21 13:22:10.617040
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--body', '{ "key" : "value" }', 'httpbin.org/post'])
    # By default, args.json is not set, so this should be None
    assert args.data != None
    # By default, args.json is not set, so this should be None
    assert args.json == None

    # If you set --json to false it should be false
    args = parser.parse_args(['--body', '{ "key" : "value" }', '--json', 'false', 'httpbin.org/post'])
    assert args.json == False
    # By default, args.json is not set, so this should be None
    assert args.data != None

    # If you set --json to true it should be true


# Generated at 2022-06-21 13:22:14.394287
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    help = """
    This is a
      multi-line help text
       """
    formatter = HTTPieHelpFormatter()
    assert ["This is a", "multi-line help text", ''] == formatter._split_lines(help, 80)



# Generated at 2022-06-21 13:22:17.825436
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    parser.print_message('TEST MESSAGE')
    assert parser._print_message == parser.print_help


# Generated at 2022-06-21 13:23:30.842179
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    result = HTTPieArgumentParser().parse_args(
        args=['https://postman-echo.com/post', 'bob=Alice', '--json'])
    assert result.json
    assert result.url == 'https://postman-echo.com/post'
    assert str(result.data) == "b'{\"bob\": \"Alice\"}'"
mock = Mock()
#mock.configure_mock(HTTPieArgumentParser=test_HTTPieArgumentParser_parse_args)
HTTPieArgumentParser, mock.HTTPieArgumentParser

test_HTTPieArgumentParser_parse_args()

 

# Generated at 2022-06-21 13:23:33.726046
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    # Arrange
    formatter = HTTPieHelpFormatter()

    # Act
    lines = formatter._split_lines('\n  Args help text\n')
    # Assert
    assert lines == ['Args help text', '']



# Generated at 2022-06-21 13:23:35.957255
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    http = HTTPie()
    assert http.parser.args.method == 'GET'

# Generated at 2022-06-21 13:23:46.639194
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    from argparse import ArgumentParser
    from argparse import ArgumentDefaultsHelpFormatter
    parser = ArgumentParser(description='test', formatter_class=ArgumentDefaultsHelpFormatter)

# Generated at 2022-06-21 13:23:50.345338
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    
    try:
        parser.parse_args(['--auth', 'a:b'])
    except NameError:
        pass
    else:
        assert False

test_HTTPieArgumentParser_parse_args()
 

# Generated at 2022-06-21 13:23:52.303561
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    # TODO: need to add more unit tests


# Generated at 2022-06-21 13:24:04.952673
# Unit test for constructor of class HTTPieHelpFormatter

# Generated at 2022-06-21 13:24:11.994402
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    assert formatter._split_lines('  args help', width=None) == ['args help', '', '']
    assert formatter._split_lines('  args \n help', width=None) == ['args', 'help', '', '']
    assert formatter._split_lines('  args \n  help', width=None) == ['args', '', 'help', '', '']


# Generated at 2022-06-21 13:24:14.474207
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    assert len(formatter._split_lines("""\
    foo

    bar
    baz""", 80)) == 2



# Generated at 2022-06-21 13:24:15.671929
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    help_formatter = HTTPieHelpFormatter()



# Generated at 2022-06-21 13:25:40.846731
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    env = Environment()
    parser = HTTPieArgumentParser(env=env)
    args = parser.parse_args(['http'])
    assert isinstance(args, Namespace)



# Generated at 2022-06-21 13:25:42.161847
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    assert HTTPieArgumentParser.parse_args(HttpieArgumentParser_fixture_1)

# Generated at 2022-06-21 13:25:47.503502
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser('')
    args = parser.parse_args(['http://httpbin.org/post', 'foo=bar', 'baz=bar'])
    assert args.method == 'POST'
    assert args.url == 'http://httpbin.org/post'

# Generated at 2022-06-21 13:25:49.588282
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    print(parser)


# Generated at 2022-06-21 13:25:52.039468
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    hp = HTTPieArgumentParser()
    print(hp.args)

    assert hp.args.data == None

if __name__ == '__main__':
    test_HTTPieArgumentParser()

# Generated at 2022-06-21 13:25:56.540362
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():

    parser = argparse.ArgumentParser(
        prog='http',
        formatter_class=HTTPieHelpFormatter,
        description='Description that is very long and should be wrapped nicely',
        epilog='Epilog is here to show if the wrapping is broken or not.',
    )
    parser.add_argument(
        'first',
        help='''First is the first argument,
        and should align nicely within the description.
        '''
    )
    print(parser.format_help())



# Generated at 2022-06-21 13:26:03.034074
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-21 13:26:05.324649
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    f = HTTPieHelpFormatter()
    text = f._split_lines('foo', 10)
    assert text == ['foo', '']



# Generated at 2022-06-21 13:26:14.185855
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-21 13:26:15.958950
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    arg_parser = HTTPieArgumentParser()
    assert type(arg_parser) == HTTPieArgumentParser

