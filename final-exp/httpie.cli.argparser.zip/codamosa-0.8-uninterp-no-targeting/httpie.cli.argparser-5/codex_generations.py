

# Generated at 2022-06-21 13:19:25.090739
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert parser


# Generated at 2022-06-21 13:19:28.478917
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(description='description', formatter_class=HTTPieHelpFormatter)
    parser.add_argument('-x', help='\n\nfoo\n\n')
    parser.parse_args(['-h'])


# Generated at 2022-06-21 13:19:37.576632
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    desc = dedent("""
    description:
      description_line1
      description_line2

    arg_help:
      arg_help_line1
      arg_help_line2
    """).strip()
    formatter = HTTPieHelpFormatter(max_help_position=30)
    assert formatter._split_lines(desc, 80) == [
        'description:',
        'description_line1',
        'description_line2',
        '',
        'arg_help:',
        'arg_help_line1 arg_help_line2'
    ]



# Generated at 2022-06-21 13:19:40.043629
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    HTTPieArgumentParser(InitializeParams())

# Unit tests for methods of class HTTPieArgumentParser
# FIXME: Pending implementation

# Generated at 2022-06-21 13:19:48.298764
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    parser.add_argument('--abc', '--def')
    parser.add_argument('--ggg')
    args = parser.parse_args('--abc'.split())
    assert args.abc == True

# Generated at 2022-06-21 13:19:53.688801
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args_string = "echo localhost:5000/api/v1/users/ --auth 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjo5LCJlbWFpbCI6InRlc3RpZDExMkBob3RtYWlsLmNvbSIsImV4cCI6MTU1NTY2NTAyMSwiaWF0IjoxNTU1NTc4NjIxfQ.6fo1U6nYFo4pks6-XRK8W_SLLHnqnZZf2Q1xTZzJ7QQ'"
    
    args_string = args_string.split(' ')
    parser = HTTPieArgument

# Generated at 2022-06-21 13:19:58.500141
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        formatter_class=HTTPieHelpFormatter
    )
    parser.add_argument('-x', help="""\
    Notice how this help is indented and has a newline.
    It will be dedented and separated by a blank line.
    """)



# Generated at 2022-06-21 13:20:05.678397
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        description=__doc__,
        epilog="See '%(prog)s <command> --help' for more information on a "
               'specific command.',
        formatter_class=HTTPieHelpFormatter,
        prog=os.path.basename(sys.argv[0]),
    )


# Generated at 2022-06-21 13:20:13.655783
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    usage_message='http --help'
    http_args='/v2/api-docs'
    args=['--help']
    args+=http_args.split(' ')
    parser = HTTPieArgumentParser(args=args, prog='http', usage=usage_message)
    parsed_args = parser.parse_args()
    assert parsed_args.url == 'https://localhost:9200/v2/api-docs'
    assert parsed_args.auth_type is None
    assert parsed_args.auth == None
    assert parsed_args.verify_ssl == True
    assert parsed_args.cert == None
    assert parsed_args.client_cert == None
    assert parsed_args.config_dir == None
    assert parsed_args.config == None
    assert parsed_args.download == False

# Generated at 2022-06-21 13:20:25.867768
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(["-v", "https://httpbin.org/get"])
    assert args.url == "https://httpbin.org/get"
    assert args.verbose == True


# Generated at 2022-06-21 13:21:40.496914
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    import io
    from httpie.plugins import plugin_manager
    mock_devnull = io.StringIO()
    def mock_stderr():
        return io.StringIO()
    parser = HTTPieArgumentParser(
        stdin=io.StringIO(),
        stdout=io.StringIO(),
        stderr=mock_stderr,
        devnull=mock_devnull,
        env=Environment(
            stdin=io.StringIO(),
            stdout=io.StringIO(),
            stderr=mock_stderr,
            devnull=mock_devnull,
            colors=256,
            extensions=plugin_manager.get_enabled_plugins()
        )
    )


# Generated at 2022-06-21 13:21:41.715475
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    HTTPieArgumentParser()

# Generated at 2022-06-21 13:21:55.808208
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = ['--traceback', 
            '--timeout', '5', 
            'localhost:8080',
            '--verbose',
            '--print', 'B',
            '--print-body', '--print-headers',
            '--output','F:/output.txt',
            '--form',
            '--method','GET',
            'a=1&b=2',
            'User-Agent:curl/7.43.0']
    parser = HTTPieArgumentParser()
    args = parser.parse_args(args)
    assert args.traceback==True
    assert args.timeout==5
    assert args.url=='localhost:8080'
    assert args.verbose==True
    assert args.print=='B'
    assert args.print_body==True
    assert args.print_headers

# Generated at 2022-06-21 13:21:59.694245
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    args = ['http', 'POST', 'httpbin.org/post', 'greeting==Hello', 'username==John']
    vars(HTTPieArgumentParser().parse_args(args))


# Generated at 2022-06-21 13:22:11.611171
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    ## parse_args
    # Test
    args = ['GET']
    args_dict = {
            '--auth': None,
            '--body': None,
            '--download': None,
            '--form': None,
            '--headers': None,
            '--output': None,
            '--verbose': None,
            '--ignore-stdin': None,
            '--pretty': None,
            '--print': None,
            '--print-b': None,
            '--print-h': None,
            '--print-hh': None,
            '--print-u': None,
            'METHOD': 'GET',
            'URL': None,
            'ITEM': []
        }
    result = HTTPieArgumentParser().parse_args(args)

# Generated at 2022-06-21 13:22:12.657310
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter(max_help_position = 8)
    assert formatter.max_help_position == 8


# Generated at 2022-06-21 13:22:24.324752
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-21 13:22:29.827430
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args_list = ['http']
    argparser = HTTPieArgumentParser()
    args_list.extend(['https://httpbin.org/anything'])
    args = argparser.parse_args(args_list)
    assert args.url == 'https://httpbin.org/anything'
    assert args.method == 'GET'
    assert len(argparser._errors) == 0

# Generated at 2022-06-21 13:22:41.571295
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-21 13:22:44.060022
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Unit test for method parse_args of class HTTPieArgumentParser
    assert False # TODO: implement your test here


# Generated at 2022-06-21 13:24:03.530152
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    import io

    # The constructor of class HTTPieArgumentParser needs
    # an instance of class Environment and an instance of class Namespace.
    # First, we call the constructor of class Environment to
    # create an instance of class Environment.
    environment = Environment()
    # Second, we call the constructor of class Namespace to
    # create an instance of class Namespace.
    namespace = Namespace()
    # Lastly, we call the constructor of class HTTPieArgumentParser to
    # create an instance of class HTTPieArgumentParser.
    HTTPieArgumentParser(environment, namespace)


# Generated at 2022-06-21 13:24:15.442582
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter(prog="my_prog")

# Generated at 2022-06-21 13:24:23.289241
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # get an Argparse namespace object
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['GET', 'http://httpbin.org/headers'])
    # specify what is expected to be returned

# Generated at 2022-06-21 13:24:33.526687
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # Initialise the ArgumentParser class with the default command line arguments
    httpie_argument_parser = HTTPieArgumentParser()

    # Check whether the ArgumentParser constructor has retrieved the default command line argument
    assert httpie_argument_parser.args.download == False
    assert httpie_argument_parser.args.traceback == False
    assert httpie_argument_parser.args.verbose == False
    assert httpie_argument_parser.args.offline == False
    assert httpie_argument_parser.args.color == False
    assert httpie_argument_parser.args.form == False
    assert httpie_argument_parser.args.pretty == "none"
    assert httpie_argument_parser.args.spec == "json"
    assert httpie_argument_parser.args.format_options == []

# Generated at 2022-06-21 13:24:34.425241
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert HTTPieHelpFormatter()


# Generated at 2022-06-21 13:24:36.526972
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert HTTPieHelpFormatter.__init__.__name__ == '__init__'
    assert HTTPieHelpFormatter.__init__.__doc__ == None


# Generated at 2022-06-21 13:24:40.964456
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        prog='http',
        formatter_class=HTTPieHelpFormatter
    )
    parser.add_argument(
        '--request', metavar='METHOD',
        help='Make an HTTP request method, one of GET/POST/PUT/DELETE/PATCH',
        default=HTTP_GET)
    print(parser.format_help())


# Generated at 2022-06-21 13:24:46.760997
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Initialize an instance of HTTPieArgumentParser
    httpie_argsparser = HTTPieArgumentParser()
    # Add --uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu

# Generated at 2022-06-21 13:24:55.920531
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Setup the parser
    parser = HTTPieArgumentParser()
    # Call the parser with a test suite of arguments

# Generated at 2022-06-21 13:25:00.210211
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # Check if the object is initialized or not
    HTTPieArgumentParserObject = HTTPieArgumentParser()
    assert HTTPieArgumentParserObject._is_initialized == False
    # Create an object of class HTTPieArgumentParser
    HTTPieArgumentParserObject = HTTPieArgumentParser(is_initialized=True)
    assert HTTPieArgumentParserObject._is_initialized == True

test_HTTPieArgumentParser()

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 13:27:45.480077
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.parse_args()

# Generated at 2022-06-21 13:27:49.905521
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """
    Unit test for constructor of class HTTPieArgumentParser
    """
    arg_parser = HTTPieArgumentParser()
    assert isinstance(arg_parser, HTTPieArgumentParser) and isinstance(arg_parser, RawDescriptionHelpFormatter)


# Generated at 2022-06-21 13:27:57.671244
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(description="This is a description of the script")
    group1 = parser.add_argument_group("Group 1")
    group1.add_argument("--foo", action='store', help="This is a long help text for foo and it goes on and on and on and on and on and on and on")
    group2 = parser.add_argument_group("Group 2")
    group2.add_argument("--bar", action='store', help="This is a help text for bar")
    args = parser.format_help().split("\n")
    assert args[72] == "  --foo  This is a long help text for foo and it goes on"


# Generated at 2022-06-21 13:28:02.333061
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser(prog='http', env=Environment())
    parser.add_argument('--arg', action='store_true')
    args = parser.parse_args(['http://127.0.0.1:5000', '--arg', 'foo'])
    assert args.arg == True
    assert args.url == None
    assert args.method == 'http://127.0.0.1:5000'
    assert args.request_items == [KeyValueArgType(*SEPARATOR_GROUP_ALL_ITEMS).__call__('--arg=foo')]

# Generated at 2022-06-21 13:28:08.127158
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    args = [
        '--json',
        'https://localhost',
        'foo=bar',
        'baz=bar', 'bar=baz'
    ]

    # The KWARGS are used in HTTPieArgumentParser.__init__
    # KWARGS = {}

    # Create HTTPieArgumentParser and call parse_args to handle args
    parser = HTTPieArgumentParser()
    parsed_args = parser.parse_args(args)

    # Check if parser and parsed_args's variables are in right value
    assert not parser.env.config.default_options
    assert not parser.env.config.default_options_use_system_config
    assert not parser.env.config.default_options_use_colors
    assert not parser.env.config.default_options_record_history


# Generated at 2022-06-21 13:28:08.977340
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.parse_args()

# Generated at 2022-06-21 13:28:17.538457
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    # Re-define method
    def _split_lines(self, text, width):
        text = dedent(text).strip() + '\n\n'
        return text.splitlines()
    
    # Add new method to class
    setattr(HTTPieHelpFormatter, "my_method", _split_lines)
    formatter = HTTPieHelpFormatter(max_help_position=6, *(1,), **{"a": 0})
    assert formatter.max_help_position == 6
    assert formatter.my_method("", "") == ["", ""]


# Generated at 2022-06-21 13:28:28.332687
# Unit test for constructor of class HTTPieArgumentParser

# Generated at 2022-06-21 13:28:34.996485
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # test code here
    print('test_HTTPieArgumentParser')
    # fake argv
    argv = ['httpie', '--help']
    args = HTTPieArgumentParser().parse_args(argv[1:])
    # proceed test
    assert args.url is None
    assert args.headers is None
    assert args.verify is True
# End test


if __name__ == '__main__':
    # test if only this file is called for test
    test_HTTPieArgumentParser()
    print('test_HTTPieArgumentParser done')
# eof

# Generated at 2022-06-21 13:28:37.038656
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args([])
    assert args.download == False
    assert args.download_resume == False