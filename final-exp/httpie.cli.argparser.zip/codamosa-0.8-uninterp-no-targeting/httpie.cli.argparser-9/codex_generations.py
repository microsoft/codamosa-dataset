

# Generated at 2022-06-21 13:19:41.074397
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test for method parse_args of class HTTPieArgumentParser
    args_no_url = []
    args_no_url.extend(['--no-style', '--no-traceback', '--print=b', '--download', 'HEAD'])
    args_no_url.extend(['httpbin.org/get'])
    args_no_url.extend(['Accept:application/json', 'User-Agent:HTTPie/0.9.9'])
    args_no_url.extend(['a==b', 'c:=d', 'e:~f'])
    args_no_url.extend(['g@/path/to/file'])
    args_no_url.extend([r'h@C:\Users\somebody\file.txt'])
#     args_no

# Generated at 2022-06-21 13:19:48.975675
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http', '/get', 'name=HTTPie'])
    
    assert args.headers == [
        'User-Agent: HTTPie/0.9.9',
        'Accept-Encoding: gzip, deflate',
        'Accept: */*'
    ]
    assert args.url == 'http://httpbin.org/get'
    assert args.method == 'GET'
    assert args.data == [('name', 'HTTPie')]
    assert args.output_file_specified is False
    assert args.auth is None 
    assert args.auth_plugin is None
    assert args.download is False
    assert args.download_resume is False
    assert args.prettify is True
    assert args.json is False

# Generated at 2022-06-21 13:19:49.646226
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()


# Generated at 2022-06-21 13:19:54.792046
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test parse_args
    try:
        from httpie.input import KeyValueArgType
        from httpie.input import SEPARATOR_GROUP_DATA_ITEMS
        from httpie.input import SEPARATOR_GROUP_ALL_ITEMS
        from httpie.context import Environment
    except ImportError:
        return
    argparse.ArgumentTypeError = argparse.ArgumentError
    environment = Environment()
    parser = HTTPieArgumentParser(add_help=True, env=environment)
    args = ['http', 'GET', 'localhost']
    expected = HTTPieArgumentParser(add_help=True, env=environment).parse_args(args)
    result = parser.parse_args(args)
    assert result == expected
    args = ['http', 'GET', 'localhost', 'foo=bar', 'baz']
   

# Generated at 2022-06-21 13:20:07.724381
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    cli = HTTPieArgumentParser()
    # 1. test for _parse_config
    cli._parse_config('test_config.json')
    assert(cli.args.config == 'test_config.json')
    assert(cli.args.style == 'solarized')
    assert(cli.args.format == 'json')
    # 2. test for _post_process
    path = 'file://path/to/file.ext'
    cli.args.url = path
    cli.args.request_items = [RequestItemArgType(KeyValueArgType('a', 'b'))]
    cli.has_stdin_data = False
    cli._post_process()
    assert(cli.args.url == path)
    # 3. test for _process_auth
    cli.args.auth

# Generated at 2022-06-21 13:20:09.857331
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    # noinspection PyProtectedMember
    parser._parse_known_args()

# Generated at 2022-06-21 13:20:11.863246
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    print('test_HTTPieArgumentParser', parser.args)


# Generated at 2022-06-21 13:20:22.894050
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    as_args = ['https://raw.githubusercontent.com/jakubroztocil/httpie/master/httpie/__version__.py']
    # Create a mock of parser
    parser = MockHTTPieArgumentParser()
    # Run method parse_args
    parser.parse_args(args=as_args)
    returned = parser.parse_args(args=as_args)
    # Check that class has method parse_args
    assert hasattr(parser, 'parse_args'), 'Parser does not have method parse_args'
    # Check that method parse_args returns correct object
    #assert returned == as_args
    assert type(returned) == Namespace


# Generated at 2022-06-21 13:20:23.564541
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    pass


# Generated at 2022-06-21 13:20:26.918578
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    return HTTPieArgumentParser().parse_args(['--json', 'https://biter.mdxblogs.com/api/v1/testAPI'])

test_HTTPieArgumentParser_parse_args()


# Generated at 2022-06-21 13:21:14.480691
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    http = HTTPieArgumentParser()
    # Test for the content of instance variables and properties.
    assert(http.__dict__['args'] == None)
    assert(http.__dict__['env'] == None)
    assert(http.__dict__['has_stdin_data'] == None)
    assert(http.__dict__['parser'] == None)
    assert(http.__dict__['_actions'] != None)

    # Test for the content of instance functions.
    assert(http.__dict__['__init__'] != None)
    assert(http.__dict__['__add_parser_environment'] != None)
    assert(http.__dict__['__add_parser_download'] != None)
    assert(http.__dict__['__add_parser_format'] != None)

# Generated at 2022-06-21 13:21:16.225487
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # TODO: Write unit test
    pass

# Generated at 2022-06-21 13:21:22.155122
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()

# Generated at 2022-06-21 13:21:25.029253
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['https://httpbin.org/get', '-p'])
    assert args.url == 'https://httpbin.org/get'
    assert args.print_body == True
# Changing the default value of an option (the --verbose option)
# Note that an option can hold multiple values!

# Generated at 2022-06-21 13:21:34.106108
# Unit test for constructor of class HTTPieHelpFormatter

# Generated at 2022-06-21 13:21:42.721958
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-21 13:21:45.033582
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert (HTTPieHelpFormatter().__class__.__name__ == 'HTTPieHelpFormatter') == True


# Generated at 2022-06-21 13:21:49.128074
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    assert formatter._split_lines(text="""
        aaa
        bbb""",
        width=0) == ['aaa', 'bbb', '']


# Generated at 2022-06-21 13:22:00.988921
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import os
    from unittest.mock import MagicMock

    # Save and delete the environment variable 'HTTPIE_CONFIG_DIR'
    with_config_dir = 'HTTPIE_CONFIG_DIR' in os.environ
    config_dir_orig = os.environ.pop('HTTPIE_CONFIG_DIR', None)
    
    # Save and delete the environment variable 'HTTPIE_CONFIG_DIR'
    config_dir = tempfile.mkdtemp()
    os.environ['HTTPIE_CONFIG_DIR'] = config_dir

# Generated at 2022-06-21 13:22:03.771542
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # TODO: write test
    print("TODO: write test")
    return


# Generated at 2022-06-21 13:23:18.974324
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie.utils import overriding_environ
    import sys
    from httpie.cli import env
    from httpie.cli import __version__

    def check_parse_args(args=None, envvars=None, **kwargs):
        if args is None:
            args = []
        if envvars is None:
            envvars = {}

        env.env = env.Environment(__version__,
                                  'UTF-8',
                                  envvars=overriding_environ(envvars))

        parser = HTTPieArgumentParser()
        namespace = parser.parse_args(args)

        for k, v in kwargs.items():
            nv = getattr(namespace, k.replace('_', '-'), None)

# Generated at 2022-06-21 13:23:29.594624
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
  parser = HTTPieArgumentParser()
  args = parser.parse_args(['https://github.com/hfaran'])
  assert args.url == 'https://github.com/hfaran'
  assert isinstance(args.auth, ExplicitNullAuth)
  assert args.download == False
  assert args.form == False
  assert args.headers == {}
  assert args.data == {}
  assert args.files == {}
  assert args.params == {}
  assert args.multipart_data == []
  assert args.output_file_specified == False
  assert args.quiet == False
  assert args.method == 'GET'
  assert args.request_items == []
  assert args.request_as_json == None
  assert args.auth_type == None
  assert args.auth_plugin == None
  assert args

# Generated at 2022-06-21 13:23:39.708688
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    assert formatter._split_lines("""
    Help for arguments can be indented and
    contain new lines. It will be de-dented and
    arguments in the help will be separated by
    a blank line for better readability.

    """, 80) == ['Help for arguments can be indented',
                  'and',
                  'contain new lines. It will be',
                  'de-dented and',
                  'arguments in the help will be',
                  'separated by',
                  'a blank line for better',
                  'readability.',
                  '',
                  '']


# Generated at 2022-06-21 13:23:41.795145
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert isinstance(parser, HTTPieArgumentParser)



# Generated at 2022-06-21 13:23:44.358030
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    result = HTTPieHelpFormatter('max_help_position')
    expected_result = RawDescriptionHelpFormatter('max_help_position')
    assert result == expected_result



# Generated at 2022-06-21 13:23:54.694792
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import sys
    import unittest
    from httpie.cli.constants import HTTP_POST
    from httpie.cli.parser import HTTPieArgumentParser
    from httpie.context import Environment
    from httpie.plugins.builtin import AuthPlugin, FormatterPlugin, ConverterPlugin
    from httpie.plugins.builtin import JSONPlugin, HTTPBasicAuth, HTTPDigestAuth
    class TestAll(unittest.TestCase):
        def setUp(self):
            self.env = Environment(
                stdin=sys.stdin,
                stdout=sys.stdout,
                stderr=sys.stderr,
                color=False,
            )
            self.parser = HTTPieArgumentParser()

# Generated at 2022-06-21 13:24:07.089212
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """https://github.com/jakubroztocil/httpie/blob/master/tests/test_helpers.py"""

    # [httpie] class HTTPieArgumentParser
    httpie_argument_parser = HTTPieArgumentParser()
    assert httpie_argument_parser is not None

    # [httpie] class HTTPieArgumentParser
    parser = HTTPieArgumentParser()
    parser.environment = Environment()

# Generated at 2022-06-21 13:24:12.478393
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    http = HTTPieArgumentParser()
    http.add_argument = Spy('add_argument')
    http.add_argument_group = Spy('add_argument_group')
    http.add_help_group = Spy('add_help_group')
    http._add_path_options_group = Spy('_add_path_options_group')
    http._add_method_group = Spy('_add_method_group')
    http._add_other_options_group = Spy('_add_other_options_group')
    http._add_query_options_group = Spy('_add_query_options_group')
    http._add_headers_group = Spy('_add_headers_group')
    http._add_body_options_group = Spy('_add_body_options_group')
    http._add_output_options_

# Generated at 2022-06-21 13:24:14.660758
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    pass


# ##############################################################################
# ########## Class that is used to handle session argument processing ###########
# ##############################################################################

# Generated at 2022-06-21 13:24:22.703017
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    assert "Test\n\n" == formatter._split_lines("\nTest\n", 80)[""]

version = pkg_resources.get_distribution('httpie').version


# Generated at 2022-06-21 13:27:07.761712
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    output = parser.parse_args(['httpie.org'])
    assert output.check_ssl_cert
    assert output.debug
    assert output.download
    assert not output.follow
    assert not output.headers
    assert output.method == 'GET'
    assert not output.output_file
    output = parser.parse_args(['httpie.org', '--post'])
    assert output.method == 'POST'
    output = parser.parse_args(['httpie.org', '--method=GET'])
    assert output.method == 'GET'
    output = parser.parse_args(['httpie.org', '--ignore-stdin'])
    assert not hasattr(output, 'data')

# Generated at 2022-06-21 13:27:14.132409
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        prog='http',
        formatter_class=HTTPieHelpFormatter,
        add_help=False)
    parser.add_argument('--test',
                        help='''\
        help 1
          help 2
            help 3''')
    assert parser.format_help() == '''\
usage: http [options] [http://]hostname[:port]/path

optional arguments:
  -h, --help            show this help message and exit
  --test                help 1
                        help 2
                        help 3
'''



# Generated at 2022-06-21 13:27:17.630353
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    '''
    Unit test for method parse_args of class HTTPieArgumentParser
    '''
    http = HTTPieArgumentParser('http')

    # code 
    try:
        http.parse_args()
    except SystemExit:
        pass



# Generated at 2022-06-21 13:27:19.810070
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser = HTTPieArgumentParser()
    args = httpie_argument_parser.parse_args(args=[])
    assert isinstance(args, argparse.Namespace)

# Generated at 2022-06-21 13:27:22.977193
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args([])
    assert args.debug == False

# Unit tests for method _setup_standard_streams of class HTTPieArgumentParser

# Generated at 2022-06-21 13:27:34.748710
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
 
    class _TestHTTPieArgumentParser(HTTPieArgumentParser):

        def __init__(self, *args, **kwargs):
            super(_TestHTTPieArgumentParser, self).__init__(
                *args, prog='http', **kwargs)

    parser = _TestHTTPieArgumentParser()
    parser._apply_default_options = lambda: None
    parser._process_raw_args = lambda args: args
    parser._get_config_dir_paths = lambda: []

    args = parser.parse_args(['http://example.org'])
    assert args.url == 'http://example.org'
    assert args.method == 'GET'

    args = parser.parse_args(['http://example.org/get'])
    assert args.url == 'http://example.org/get'
   

# Generated at 2022-06-21 13:27:43.868552
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """
    Test HTTPieArgumentParser constructor
    """
    parser = HTTPieArgumentParser()
    # has no arguments
    args = parser.parse_args([])
    assert args.get('url', None) == None
    # has a URL
    args = parser.parse_args(['httpie.org'])
    assert args.get('url', None) == 'httpie.org'
    # has a URL and some parameters
    args = parser.parse_args(['httpie.org', 'limit=1'])
    assert args.get('url', None) == 'httpie.org'
    assert args.get('request_items', None) == [KeyValueArgType(*SEPARATOR_GROUP_ALL_ITEMS).__call__('limit=1')]
    # has a URL and some parameters, with a `--data

# Generated at 2022-06-21 13:27:46.586538
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():           
    from httpie.cli.parser import parser

    help_str = parser.format_help()
    assert help_str != None 


# Generated at 2022-06-21 13:27:48.816090
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    assert formatter._split_lines.__name__ == '_split_lines'


# Generated at 2022-06-21 13:27:58.325572
# Unit test for constructor of class HTTPieArgumentParser