

# Generated at 2022-06-21 13:19:30.356441
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-21 13:19:33.881550
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    assert formatter._split_lines(text="""
        foo

    """, width=10) == ["foo", "", ""]


# Generated at 2022-06-21 13:19:37.733102
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """Test for constructor of class HTTPieArgumentParser
    :return: None
    """
    print('In HTTPieArgumentParser: test_HTTPieArgumentParser()')
    parser = HTTPieArgumentParser()
    assert parser

# Generated at 2022-06-21 13:19:46.946068
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-21 13:19:59.665315
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # http --help -v
    # python3 -m unittest tests.test_argparser.HTTPieArgumentParser.test_HTTPieArgumentParser
    class MockIsatty:
        def __init__(self, value1, value2):
            self.stdin_isatty = value1
            self.stdout_isatty = value2

    parser = HTTPieArgumentParser(
        stdin=open(os.devnull, 'rb'),
        stdout=open(os.devnull, 'wb'),
        stderr=open(os.devnull, 'wb'),
        env=MockIsatty(True, True),
        depend_on_arguments=True
    )
    parser.error = lambda msg: msg

# Generated at 2022-06-21 13:20:05.123662
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """
    Simple test of HTTPieArgumentParser

    :return: None
    """
    httpie_argument_parser = HTTPieArgumentParser()
    assert httpie_argument_parser.__class__.__name__ == "HTTPieArgumentParser"



# Generated at 2022-06-21 13:20:06.888646
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """ Unit test for method parse_args of class HTTPieArgumentParser """
    pass

    # FIXME: Complete unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-21 13:20:08.621200
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser(env=Env())
    print(parser.parse_args(()))

# Generated at 2022-06-21 13:20:10.919877
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    httpie_arg_parser = HTTPieArgumentParser()
    print(httpie_arg_parser.args)

# Generated at 2022-06-21 13:20:23.766185
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    import os
    import re
    import sys
    import json
    import subprocess

    # Test the default parameter of the constructor.
    temp_dir = os.getenv('TMPDIR')
    temp_dir = temp_dir.replace('\\', '/')
    temp_dir = temp_dir + 'httpie/'

    # Test a non-existent directory.
    try:
        parser = HTTPieArgumentParser('/')
    except SystemExit:
        # Expected exit.
        pass

    try:
        # Test that the default configuration files will be loaded.
        parser = HTTPieArgumentParser(temp_dir)
    except SystemExit:
        # Expected exit.
        pass

    # Test that the default configuration files will be loaded even if the
    # path has a complicated structure.

# Generated at 2022-06-21 13:21:06.321344
# Unit test for constructor of class HTTPieArgumentParser

# Generated at 2022-06-21 13:21:12.358881
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    from httpie.cli.parser import parser
    from io import StringIO
    import sys
    sys.stdout = StringIO()
    print("this is httpieHelpFormatter constructor unit test.")
    parser.print_help()
    sys.stdout.close() # close it to prevent ResourceWarning
    sys.stdout = sys.__stdout__ # switch back to the system stdout



# Generated at 2022-06-21 13:21:14.293061
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    a = HTTPieHelpFormatter()
    assert type(a) is HTTPieHelpFormatter


# Generated at 2022-06-21 13:21:17.800660
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    a = '''
    this is a test
    for a new line of help file
    '''
    b = HTTPieHelpFormatter.__init__(a)
    print (b)


# Generated at 2022-06-21 13:21:21.514959
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    op = argparse.ArgumentParser(formatter_class=HTTPieHelpFormatter)
    op.add_argument("--foo", help="""
        usage of foo.
        """)
    if op.parse_args([]):
        assert True
    else:
        assert False


# Generated at 2022-06-21 13:21:27.200723
# Unit test for constructor of class HTTPieArgumentParser

# Generated at 2022-06-21 13:21:36.301599
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(description='Test',
                                     formatter_class=HTTPieHelpFormatter)
    parser.add_argument('--argument', help='''
        this is a help for the argument which
        is indented and contains a new line.
    ''')
    args_help = parser.format_help()
    assert 'usage: ' in args_help
    assert 'this is a help for the argument which' in args_help
    assert 'is indented and contains a new line.' in args_help
    print(args_help)



# Generated at 2022-06-21 13:21:44.121321
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    import sys
    import io
    import os
    class EnvStub(object):
        def __init__(self, stdin, stdout, stderr):
            self.stdin = stdin
            self.stdout = stdout
            self.stderr = stderr
            self.is_windows = os.name == 'nt'
            if hasattr(stdout, 'encoding'):
                self.stdout_encoding = stdout.encoding
            else:
                self.stdout_encoding = 'UTF-8'
            self.stdout_isatty = stdout.isatty()
            self.stderr_isatty = stderr.isatty()
            self.devnull = open(os.devnull, 'wb')

    import argparse

# Generated at 2022-06-21 13:21:48.352716
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    args = parser.parse_args('www.google.com'.split())

    assert args.url == 'https://www.google.com'


# Generated at 2022-06-21 13:21:59.423433
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    test_dic = {'max_help_position': 6, 'args': ['a'], 'kwargs': {'a': 'b', 'c': 'd'}}
    test_help_text = """
    a
    b
    c
    d
    """
    test_httpie_formatter = HTTPieHelpFormatter(**test_dic['kwargs'])
    test_httpie_formatter.add_argument('','',help=test_help_text)
    test_parse_args = test_httpie_formatter.parse_args(test_dic['args'])
    return test_httpie_formatter, test_help_text, test_parse_args


# Generated at 2022-06-21 13:22:52.860856
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = HTTPieArgumentParser().parse_args(['http://httpbin.org/get'])
    assert args.url == 'http://httpbin.org/get'
    assert args.method == 'GET'
    assert args.headers == []
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.data == None
    assert args.json == False
    assert args.form == False
    assert args.output_file == None
    assert args.params == None
    assert args.files == None
    assert args.output_file_specified == False
    assert args.output_options == 'hb'
    assert args.output_options_history == 'hb'
    assert args.prettify == False
    assert args.colors == 256

# Generated at 2022-06-21 13:22:59.533965
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import sys
    import os.path
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from httpie import httpie

# Generated at 2022-06-21 13:23:10.115255
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    # Make sure the method gets called
    parser = HTTPieArgumentParser()
    parser.parse_args = MagicMock()

    input_args = ['--json', 'KEY1=VAL1', 'KEY2=VAL2', 'https://example.com']
    parser.parse_args(input_args)

    # Make sure the method recieves the input arguments
    parser.parse_args.assert_called_once_with(input_args)
    test_args = parser.parse_args.call_args[0][0]
    assert test_args == input_args

    # Make sure the method produces the correct output arguments

# Generated at 2022-06-21 13:23:18.753463
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-21 13:23:23.652222
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    assert_equals(formatter('Usage:', '[options]\nhello\n  world'), 'Usage:\nhello\n  world')
    assert_equals(formatter('Usage: hello\n  world\n  world'), 'Usage: hello\nworld\nworld')


# Generated at 2022-06-21 13:23:25.828823
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    test = HTTPieHelpFormatter()
    assert test.max_help_position == 6


# Generated at 2022-06-21 13:23:35.102291
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    try:
        import StringIO
        out = StringIO.StringIO()
    except ImportError:
        import io
        out = io.StringIO()
    help = HTTPieHelpFormatter(max_help_position=6)
    parser = argparse.ArgumentParser(argument_default=argparse.SUPPRESS,
                                     formatter_class=help,
                                     description="test")
    parser.add_argument("args", help="  args help.")
    parser.add_argument("-a", "--module", dest="module",
                        help="""test""")
    parser.add_argument("--debug", dest="debug",
                        help=("debug, "
                              "test."))
    parser.print_help(file=out)

# Generated at 2022-06-21 13:23:46.174028
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    default_words = ['  -h, --help  ', '  --traceback  ', '  -v, --verbose  ']
    default_help = 'Some help here.\n\nAbout the argument:\nMore help'

    # the helpformatter of python 3 
    python_help_formatter = argparse.HelpFormatter()
    # the helpformatter of httpie
    httpie_help_formatter = HTTPieHelpFormatter()

    for words, help_ in zip([default_words, default_words, default_words], [default_help, default_help, default_help]):
        assert httpie_help_formatter._split_lines(help_, 20) == python_help_formatter._split_lines(help_, 20)


# Generated at 2022-06-21 13:23:50.920636
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    from textwrap import dedent
    help_text = dedent('''\
    http localhost
    http --help

    http --json

    http --form
    ''').strip()
    parser = argparse.ArgumentParser(description=help_text,
                                     formatter_class=HTTPieHelpFormatter)
    args = parser.parse_args([])



# Generated at 2022-06-21 13:23:58.742578
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = HTTPieArgumentParser().parse_args
    # args() in case of no argument
    assert args([]).path == "https://httpie.org"
    # args() in case of single argument
    assert args(['https://httpie.org']).path == "https://httpie.org"
    # args() in case of multiple arguments
    assert args(['https://httpie.org', 'GET']).path == "https://httpie.org"

# Generated at 2022-06-21 13:25:38.253341
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # no exception
    HTTPieArgumentParser()


# Generated at 2022-06-21 13:25:38.691663
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    pass



# Generated at 2022-06-21 13:25:41.630593
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    helpFormatter = HTTPieHelpFormatter()
    assert helpFormatter.indent_increment == 2
    assert helpFormatter.current_indent == 0
    assert helpFormatter.max_help_position == 6
    assert helpFormatter.width == 90



# Generated at 2022-06-21 13:25:53.319759
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    class HTTPieArgumentParser(BaseArgumentParser):
        ignore_unknown_options = True

        def __init__(self, env, **kwargs):
            # type: (Environment, **Any) -> None
            kwargs.setdefault('description', self.description)
            kwargs.setdefault('formatter_class', self.formatter_class)
            kwargs.setdefault('add_help', False)
            super(HTTPieArgumentParser, self).__init__(**kwargs)
            self.env = env
            self.add_arguments()
    # --ignore-netrc [IGNORE_NETRC]
    parser = HTTPieArgumentParser(Environment())
    assert parser.parse_args(
        ['--ignore-netrc']).ignore_netrc == True

# Generated at 2022-06-21 13:26:00.236164
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():

    p = plugin_manager._get_plugins()
    l = []

    for n in p:
        l.append(n.name)

    print(l)
    #['ssh', 'json', 'jira', 'graphql', 'traceroute', 'Github-Auth', 'jwt', 'icecast', 'aws', 'clientcert', 'jmespath', 'aws-sigv4', 'httpie', 'hpack']

    #def __init__(self):
    #    super().__init__(
    #        formatter_class=HTTPieHelpFormatter,
    #        description=DESCRIPTION,
    #        epilog=EPILOG,
    #        usage=USAGE
    #    )
    #    self.add_arguments()

    #def add_arguments(self):
    #    super

# Generated at 2022-06-21 13:26:05.429391
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    # A smaller indent for args help.
    kwargs = {'max_help_position':6}
    Text = "A smaller indent for args help."
    assert HTTPieHelpFormatter(**kwargs)._split_lines(Text, width = None) == ['A smaller indent for args help.', '', '']


# Generated at 2022-06-21 13:26:13.315175
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    parser.add_argument('--no-default-options')
    parser.add_argument('--default-options')
    parser.add_argument('--arg-options')
    parser.add_argument('--arg-no-options')
    args = parser.parse_args(args=['--default-options'])
    print("default_options:", args.default_options)
    # default_options: True

    args = parser.parse_args(args=['--no-default-options'])
    print("default_options:", args.default_options)
    # default_options: False


test_HTTPieArgumentParser()

# Generated at 2022-06-21 13:26:19.360831
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    argv = []
    argv.append('--form')
    argv.append('q=1')
    ap = HTTPieArgumentParser()

    args = ap.parse_args(argv)

    assert args.form == True
    assert args.__dict__['request_items'][0].key == 'q'
    assert args.__dict__['request_items'][0].value == '1'
    assert args.__dict__['request_items'][0].sep == '='


# Generated at 2022-06-21 13:26:28.225464
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie import input
    from httpie.context import Environment
    from httpie.core import main
    from httpie.plugins import plugin_manager
    from httpie.output.streams import log_debug, log_info
    from httpie.compat import stdout
    from httpie.compat import StringIO
    from httpie.plugins import AuthPlugin
    from httpie.plugins import AuthCredentials
    from httpie.plugins import AuthPlugin
    from httpie.plugins import AuthCredentials
    from httpie.plugins import get_netrc_auth
    from httpie.plugins import plugin_manager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.input import SEPARATOR_CREDENTIALS
    from httpie.input import SEPARATOR_GROUP_ALL_ITEMS

# Generated at 2022-06-21 13:26:29.611349
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    print(parser.has_positional_arguments)

