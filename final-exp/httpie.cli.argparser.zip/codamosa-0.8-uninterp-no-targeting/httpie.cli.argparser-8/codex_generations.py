

# Generated at 2022-06-21 13:19:28.014913
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    help = """
    A nicer help formatter.

    Help for arguments can be indented and contain new lines.
    It will be de-dented and arguments in the help
    will be separated by a blank line for better readability.
    """
    assert str(HTTPieHelpFormatter()) == help



# Generated at 2022-06-21 13:19:32.249460
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    import argparse
    try:
        parser = HTTPieArgumentParser(prog=PROG,
                        )
    except argparse.ArgumentError as e:
        print(e)



# Generated at 2022-06-21 13:19:33.432540
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    return parser

# Generated at 2022-06-21 13:19:43.979865
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser(prog='httpie')
    parser.exit = print
    parser.error = print
    parser.add_argument('-T')

    capture = io.StringIO()
    sys.stderr = capture
    try:
        parser.parse_args(['-T'])
    except SystemExit:
        pass
    finally:
        sys.stderr = sys.__stderr__

# Generated at 2022-06-21 13:19:54.336389
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    class MockArgumentParser(HTTPieArgumentParser):
        pass

    text_formatter = help_epilog_formatter_class(
        max_help_position=30,
        width=120)
    argument_parser = MockArgumentParser(
        prog='http',
        description='A cURL-like tool for humans.',
        formatter_class=text_formatter,
        add_help=False  # Help already being added in the epilog.
    )
    assert argument_parser.prog == 'http'
    assert argument_parser.description == 'A cURL-like tool for humans.'


test_HTTPieArgumentParser()

# Generated at 2022-06-21 13:19:57.660300
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    text="""hi
    hello
    my name is peng"""
    formatter=HTTPieHelpFormatter()
    print(formatter._split_lines(text,20))
# Unit test end


# Generated at 2022-06-21 13:19:59.833751
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    pass

if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-21 13:20:04.345618
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    # Create an instance of class HTTPieHelpFormatter
    test_instance_two = HTTPieHelpFormatter()

    assert isinstance(test_instance_two, RawDescriptionHelpFormatter) == True


# Generated at 2022-06-21 13:20:09.957221
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    try:
        parser = argparse.ArgumentParser(
            prog='http',
            description='description for http',
            epilog='http is awesome',
            formatter_class=HTTPieHelpFormatter)
    except Exception as e:
        assert 'HTTPieHelpFormatter' in str(e)
        assert 'description for http' in str(e)
        assert 'http is awesome' in str(e)


# Generated at 2022-06-21 13:20:22.669498
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-21 13:20:57.790517
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    assert formatter._split_lines("""A


test


""", 80) == [
        "A test",
        "",
        ""
    ]



# Generated at 2022-06-21 13:21:04.878189
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    argv = []
    env = _Environment(argv)
    parser = HTTPieArgumentParser(
        prog='http',
        env=env,
        # Don't mess with the real config.
        config_dir=os.devnull,
    )
    args = parser.parse_args(args=argv)
    assert args.headers['content-type'] == 'application/json'
    assert args.headers['user-agent'] == env.default_user_agent()
    assert args.auth == (None, None)
    assert args.output_options == OUTPUT_OPTIONS_DEFAULT
    assert args.output_options_history == OUTPUT_OPTIONS_DEFAULT
    assert args.prettify == PRETTY_JSON
    assert args.download is False
    assert args.download_resume is False
   

# Generated at 2022-06-21 13:21:16.912451
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    with patch('httpie.cli.base.__version__', 'testing'):
        parser = HTTPieArgumentParser()
        args = parser.parse_args()

        assert args.A == HTTPieArgumentParser.HTTP_11
        assert args.b == None
        assert args.b64encode == None
        assert args.body == None
        assert args.body_columns == []
        assert args.body_file == None
        assert args.body_file_raw == None
        assert args.body_format == None
        assert args.body_preview_window == None
        assert args.body_style == None
        assert args.c == '.httpie'
        assert args.cert == []
        assert args.cert_key == None
        assert args.client_certs == None
        assert args.ciphers == None


# Generated at 2022-06-21 13:21:21.695948
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert parser.error == HTTPieArgumentParser.error
    assert parser.exit == HTTPieArgumentParser.exit
    assert parser.print_usage == HTTPieArgumentParser.print_usage
    assert parser.print_help == HTTPieArgumentParser.print_help
    assert parser.format_usage == HTTPieArgumentParser.format_usage
    assert parser.format_help == HTTPieArgumentParser.format_help
    assert parser.parse_known_args == HTTPieArgumentParser.parse_known_args
    assert parser.parse_args == HTTPieArgumentParser.parse_args


# Generated at 2022-06-21 13:21:22.857147
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    httpie = HTTPieArgumentParser()
    assert httpie.env == Environment()



# Generated at 2022-06-21 13:21:23.945539
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--traceback'])

# Generated at 2022-06-21 13:21:27.805000
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    args = HTTPieArgumentParser(color=False).parse_args([
        'http', '--ignore-stdin',
        'http://httpbin.org/get'
    ])
    assert not args.ignore_stdin

    args = HTTPieArgumentParser(color=False).parse_args([
        'http', '--ignore-stdin',
        'http://httpbin.org/get'
    ])
    assert not args.ignore_stdin


# Tests for parser for class HTTPieArgumentParser

# Generated at 2022-06-21 13:21:34.500448
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    args = HTTPieArgumentParser(
        prog='http',
        # We don't do `from httpie import __version__`
        # because that would import a lot of code and modules that may break.
        version='httpie' ' (unknown version)'
    ).parse_args(args=[])
    assert isinstance(args, argparse.Namespace)


# Generated at 2022-06-21 13:21:43.001926
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    assert HTTPieArgumentParser(reason='test_HTTPieArgumentParser_parse_args').parse_args(
        'httpbin.org')
    assert HTTPieArgumentParser(reason='test_HTTPieArgumentParser_parse_args').parse_args(
        ['httpbin.org'])
    assert HTTPieArgumentParser(reason='test_HTTPieArgumentParser_parse_args').parse_args([])
    assert HTTPieArgumentParser(reason='test_HTTPieArgumentParser_parse_args').parse_args('')
    assert HTTPieArgumentParser(reason='test_HTTPieArgumentParser_parse_args').parse_args(
        ['-a', 'admin', 'httpbin.org'])

# Generated at 2022-06-21 13:21:48.366299
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    test_file = 'test_file'

    def create_parser(traceback=False, ignore_stdin=False, ignore_stdin_isatty=True,
                      output_file=None, output_file_isatty=True, stdin_isatty=True,
                      stdin_has_content=True, output_file_specified=False, download=False,
                      pretty=False, quiet=False, verbose=False):
        parser = HTTPieArgumentParser()
        parser.env = AttrDict({
            'is_windows': False,
            'stdin': io.StringIO(),
            'stdin_isatty': stdin_isatty,
            'stdin_encoding': 'utf8'
        })


# Generated at 2022-06-21 13:22:50.865370
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert False


# Generated at 2022-06-21 13:22:55.875581
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    f = HTTPieHelpFormatter()
    for text in [
        'hello!\n\nworld',
        ' hello!\n\nworld ',
        ' hello!\n\n world ',
        'hello!\n\n world\n',
        'hello!\n\nworld ',
        'hello!\n\n world\n',
        'hello!\n\n world\n ',
        'hello!\n\n world \n ',
    ]:
        assert f._split_lines(text, 80) == [
            'hello!',
            '',
            'world',
            '',
        ]



# Generated at 2022-06-21 13:22:58.528923
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    a = HTTPieHelpFormatter()
    print(a._split_lines.__doc__)



# Generated at 2022-06-21 13:23:05.685738
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        formatter_class=HTTPieHelpFormatter,
        description="""
        HTTPie - a CLI, cURL-like tool for humans.

        """,
        epilog="""
        If you find any bugs or have suggestions, please create an issue at
        https://github.com/jakubroztocil/httpie/issues


        Don't forget to exit with Ctrl-D, the shell is probably hiding the ^D.

        """,
        add_help=False,
    )



# Generated at 2022-06-21 13:23:15.234159
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    # headers
    assert parser.parse_args(
        ['--headers', 'X-Foo: Bar', 'example.org']
    ).headers == CaseInsensitiveDict({
        'X-Foo': 'Bar'
    })
    assert parser.parse_args(
        ['example.org', 'X-Foo: Bar']
    ).headers == CaseInsensitiveDict({
        'X-Foo': 'Bar'
    })
    assert parser.parse_args(
        ['example.org', '--headers', 'X-Foo: Bar']
    ).headers == CaseInsensitiveDict({
        'X-Foo': 'Bar'
    })

# Generated at 2022-06-21 13:23:16.592224
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    assert formatter._max_help_position == 6


# Generated at 2022-06-21 13:23:26.076592
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    ret = dedent('''
        Usage: http POST example.org hello=World

        Get POST

        Arguments:
          hello  Hello world.

        ''').strip()
    parser = argparse.ArgumentParser(
        description="Get POST",
        # A smaller indent for args help.
        formatter_class=HTTPieHelpFormatter,
        # Don't mess with my formatter
        add_help=False
    )
    # parser.add_argument("--help", action="help", help=argparse.SUPPRESS)
    parser.add_argument("hello", help="Hello world.")
    parser.print_help()
    # print(ret == parser.format_help())


# Generated at 2022-06-21 13:23:31.756568
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie.context import Environment
    from httpie import client
    
    args = client.parser.parse_args(['POST', 'http://httpbin.org/post', 'name=John'])
    print (args)
    try:
        args = client.parser.parse_args([])
        print (args)
    except SystemExit as e:
        print (e)
    return args.url, args.method, args.headers, args.data


# Generated at 2022-06-21 13:23:34.679406
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=HTTPieHelpFormatter)
    args = parser.parse_args('-h'.split())
    assert 'usage' in args


# Generated at 2022-06-21 13:23:45.780503
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """Unit test for method parse_args of class HTTPieArgumentParser."""
    #pylint: disable=protected-access

    # args = ['GET', 'https://httpbin.org/get']
    os.environ['HTTPIE_CONFIG_DIR'] = './'
    os.environ['HOME'] = './'

    # args = ['GET', 'https://httpbin.org/get']

    args = ['GET', 'https://httpbin.org/get', 'Accept:application/json']

    httpie_args = ['http', '--version', '--help',
                   '--ignore-stdin', '--output=abc.txt',
                   '--download', '--timeout=10']

    httpie_args.extend(args)

    parser = HTTPieArgumentParser()

    # parsed_args = parser

# Generated at 2022-06-21 13:26:20.475337
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    # test for method _get_parser_args
    # assert parser._get_parser_args()
    # test for method _get_parser_kwargs
    # assert parser._get_parser_kwargs()
    # test for method _apply_global_options
    # assert parser._apply_global_options()
    # test for method _process_url
    # assert parser._process_url()
    # test for method _print_message
    # assert parser._print_message()
    # test for method _setup_standard_streams
    # assert parser._setup_standard_streams()
    # test for method _process_auth
    # assert parser._process_auth()
    # test for method _apply_no_options
    # assert parser._apply_no_options()
    # test for method

# Generated at 2022-06-21 13:26:29.101193
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    session = requests.Session()
    env = Environment(session)
    args = ['http', 'test-domain.org', 'key-one==value-one', 'key-two:=value-two']

    # Arrange
    parser = HTTPieArgumentParser()
    parser.env = env

    # Act
    args = parser.parse_args(args)

    # Assert
    assert isinstance(parser, HTTPieArgumentParser)
    assert isinstance(parser.args, argparse.Namespace)
    assert args.url == 'test-domain.org'
    assert isinstance(args.headers, dict)
    assert args.headers['key-one'] == 'value-one'
    assert isinstance(args.data, dict)
    assert args.data['key-two'] == 'value-two'

# Generated at 2022-06-21 13:26:37.474799
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    args = parser.parse_args()
    print(args.verbose)
    print(args.auth_plugin)
    print(args.auth)
    print(args.url)
    print(args.method)
    print(args.headers)
    print(args.form)
    print(args.body)
    print(args.files)
    print(args.output_file)
    print(args.output_options)
    print(args.config_dir)
    print(args.default_options)
    print(args.prettify)
    print(args.session)
    print(args.download)
    print(args.timeout)
    print(args.max_redirects)
    print(args.download_resume)

# Generated at 2022-06-21 13:26:43.692627
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-21 13:26:52.113896
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # Test the constructor of class HTTPieArgumentParser
    parser = HTTPieArgumentParser()
    #assert parser.args is not None
    # ? assert parser.env is None
    #assert parser.exit is None
    #assert parser.error is None
    #assert parser.config is None
    #assert parser.name is None

    # Test if function env setting is valid
    #parser.env = Object()
    #assert parser.env is not None
    #parser.env = None
    #assert parser.env is None
    #parser.env = Object()
    #assert parser.env is not None
    #parser.env = None
    #assert parser.env is None
    #parser.env = Object()
    #assert parser.env is not None
    #parser.env = None
    #assert parser.env is None
    #

# Generated at 2022-06-21 13:26:57.468532
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    assert formatter._split_lines('wtf', 2) == ['wtf', '\n', '\n']
    assert formatter._split_lines('wtf', 2) != ['wtf', '\n']
    assert formatter._split_lines('wtf', 2) != ['wtf', '\n']
    assert formatter._split_lines('wtf', 2) != ['wtf', '\n', '\n', '\n']


# Generated at 2022-06-21 13:27:01.426878
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """
    Test for method HTTPieArgumentParser.parse_args()
    """
    parser = HTTPieArgumentParser()

    r = parser.parse_args()
    assert r.headers == {}
    assert r.data == {}
    assert r.files == {}
    assert r.params == {}
    assert r.multipart_data == []

if __name__ == '__main__':
    # Unit test
    test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-21 13:27:06.482862
# Unit test for constructor of class HTTPieArgumentParser

# Generated at 2022-06-21 13:27:15.916094
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """
    Unit test for constructor of class HTTPieArgumentParser
    """
    http = HTTPieArgumentParser()
    http.add_argument("-v", "--verbose", help="increase output verbosity",
                      action="store_true")
    http.add_argument("--output", help="write to file")
    http.add_argument("-f", "--format", dest="output_options",
                      help="change the output formatting (options: hHjJ)")
    http.add_argument("-p", "--print", dest="output_options",
                      type=lambda s: s.strip(), action=OptionAppendAction,
                      help="print options (options: bBcdeghHjJkLMmNqrRsSuvwWy)")

# Generated at 2022-06-21 13:27:17.138490
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    pass
# Unit tests for method parse of class HTTPieArgumentParser