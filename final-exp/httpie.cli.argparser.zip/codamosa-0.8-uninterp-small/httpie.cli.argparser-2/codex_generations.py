

# Generated at 2022-06-25 17:55:11.785054
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
    # Correct arguments
    args = h_t_t_pie_argument_parser_1.parse_args(['http', 'httpbin.org', 'GET'])
    assert args.url == 'httpbin.org'
    assert args.method == 'GET'
    # Incorrect argument
    try:
        h_t_t_pie_argument_parser_1.parse_args(['http', 2])
    except SystemExit:
        pass
    # Correct arguments
    args = h_t_t_pie_argument_parser_1.parse_args(['http', 'httpbin.org', '-v'])
    assert args.verbose == True
    # Correct arguments
    args = h_t_t_pie_argument_parser_

# Generated at 2022-06-25 17:55:16.053480
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Testing for 'default'
    # Testing for 'parse_known_args'
    # Testing for 'version'
    # Testing for 'formatter_class'
    # Testing for 'description'
    # Testing for 'help'
    # Testing for 'conflict_handler'
    # Testing for 'prefix_chars'
    test_case_0()

# Generated at 2022-06-25 17:55:17.090195
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    test_case_0()


# Generated at 2022-06-25 17:55:24.834203
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-25 17:55:28.894936
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """Test for method parse_args of class HTTPieArgumentParser"""
    # Test
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.parse_args()


# Generated at 2022-06-25 17:55:32.915347
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    test_case_0()

if __name__ == "__main__":
    for func in getmembers(sys.modules[__name__]):
        if func[0].startswith("test_"):
            print("Running", func[0])
            func[1]()
            print("")
    print("success")

# Generated at 2022-06-25 17:55:35.607073
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.parse_args()



# Generated at 2022-06-25 17:55:41.788733
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args_0 = ['Test', 'Case']
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    result_0 = h_t_t_pie_argument_parser_0.parse_args(args_0)
    result_0.method = 'http'
    assert result_0.url == 'http://Test/Case'


# Generated at 2022-06-25 17:55:50.483121
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    print('<-----test_HTTPieArgumentParser_parse_args-----!')
    try:
        h_t_t_pie_argument_parser_0.parse_args()
        print('test_HTTPieArgumentParser_parse_args ok!')
    except Exception as ex:
        print('test_HTTPieArgumentParser_parse_args failed!')
        print('exception is: ' + str(ex))
        print(traceback.format_exc())


# Generated at 2022-06-25 17:55:51.447831
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    method = HTTPieArgumentParser.parse_args
    # Test 0
    #test_case_0


# Generated at 2022-06-25 17:56:52.862907
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-25 17:57:05.188191
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.error = magic_mock()
    h_t_t_pie_argument_parser_0._parse_items = magic_mock()
    h_t_t_pie_argument_parser_0._process_pretty_options = magic_mock()
    h_t_t_pie_argument_parser_0._process_output_options = magic_mock()
    h_t_t_pie_argument_parser_0._process_download_options = magic_mock()
    h_t_t_pie_argument_parser_0._process_format_options = magic_mock()
    h_t_t_pie_argument_parser_0._setup_standard_streams

# Generated at 2022-06-25 17:57:13.358989
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    test_case_0()
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_2 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_3 = HTTPieArgumentParser()
    args = ["-v"]
    args_0 = ["-v", "-v"]
    args_1 = ["-v", "-v", "-v"]
    args_2 = ["-H", "-v"]
    args_3 = ["-H"]
    args_4 = ["-b", "-v"]
    args_5 = ["-b"]
    args_6 = ["-A", "-v"]

# Generated at 2022-06-25 17:57:27.095631
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Instance of class HTTPieArgumentParser.
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    # Test an argument which contains a dash.
    h_t_t_pie_argument_parser_0.add_argument('--preserve-host')
    # Test an argument which contains an underscore.
    h_t_t_pie_argument_parser_0.add_argument('--max-redirects')
    # Test an argument which contains punctuation.
    h_t_t_pie_argument_parser_0.add_argument('--max-redirects', type=int)
    # Test an argument which is not specified in sys.argv.

# Generated at 2022-06-25 17:57:34.633467
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # CASE:
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.parse_args([])

    # CASE:
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.parse_args(['--no-headers'])

    # CASE:
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.parse_args(['--no-headers', '--no-headers'])

    # CASE:
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument

# Generated at 2022-06-25 17:57:39.202486
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser = HTTPieArgumentParser()
    h_t_t_pie_argument_parser.parse_args()

# Generated at end of file
# PYTEST_DONT_REWRITE
# Unit tests for class HTTPieArgumentParser

# Generated at 2022-06-25 17:57:46.319159
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Call HTTPieArgumentParser.parse_args
    # TODO: Add arguments to method
    try:
        test_case_0()
        test_case_1()
    except SystemExit as e:
        # TODO: Add test cases that will fail the argument parser.
        raise RuntimeError("Test failing with error code :" + str(e.code))

test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-25 17:57:56.621975
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # h_t_t_pie_argument_parser_1, args_1 = None, None
    if 'httpie.cli.argparser.HTTPieArgumentParser.parse_args' in globals():
        args_1 = globals()['httpie.cli.argparser.HTTPieArgumentParser.parse_args']
    else:
        args_1 = None

    testValue_0 = ('http_method',)
    if 'httpie.cli.argparser.HTTPieArgumentParser.parse_args' in globals():
        args_1 = globals()['httpie.cli.argparser.HTTPieArgumentParser.parse_args']
    else:
        args_1 = None

    testValue_1 = ('http_method',)
    if args_1 is not None:
        h_t_t_pie_

# Generated at 2022-06-25 17:58:00.164503
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    # FIXME: Test disabled.
    # assert h_t_t_pie_argument_parser_0.parse_args() == 0


# Generated at 2022-06-25 17:58:06.067666
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = ['https://httpbin.org/post', 'name=John', 'foo=bar', 'colon=user:pass', 'one:two=three:four']
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    parse_args_0 = h_t_t_pie_argument_parser_0.parse_args(args)


# Generated at 2022-06-25 17:59:56.352648
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
	# Setup args
	# args is None
	# args is object
	# args is empty list
	# args is list of length 1
	# args is list of length > 1
	# args is number
	# args is string
	args = ['hello', 'world']
	
	h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
	# calls method parse_known_args
	
	# calls method _apply_general_options
	
	# calls method _apply_no_options
	
	# calls method _guess_method
	
	# calls method _parse_items
	
	# calls method _process_auth
	
	# calls method _process_download_options
	
	# calls method _process_format_options
	
	# calls method _process_output_options
	

# Generated at 2022-06-25 18:00:03.636151
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    # Arguments to test method
    sys.argv = ['http', 'https://httpbin.org/get']

    # Make an instance of the class
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()

    # Test method
    h_t_t_pie_argument_parser_0.parse_args()

    # Verify results
    assert h_t_t_pie_argument_parser_0.args.url == 'https://httpbin.org/get'


# Generated at 2022-06-25 18:00:11.337378
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    list_0 = ['http','--auth','user','--json','http://httpbin.org/get','User-Agent:','new','--headers','name','nick','--timeout','2','--check-status','--download','--print','status','--verbose']
    try:
        pprint.pprint(h_t_t_pie_argument_parser_0.parse_args( list_0 ) )
    except SystemExit:
        pass


# Generated at 2022-06-25 18:00:21.253918
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
    argv_1 = ["GET", "--help"]
    args_1 = h_t_t_pie_argument_parser_1.parse_args(argv_1)
    assert type(args_1) == Namespace
    assert args_1.method == "GET"
    assert args_1.help == True
    assert args_1.debug == False
    assert args_1.ignore_stdin == False
    assert args_1.download == False
    assert args_1.download_resume == False
    assert args_1.headers == []
    assert args_1.request_items == []
    assert args_1.auth == None
    assert args_1.auth_type == 'basic'

# Generated at 2022-06-25 18:00:25.452726
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """Unit test for HTTPieArgumentParser.parse_args"""
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.parse_args([''])


# Generated at 2022-06-25 18:00:32.992802
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    assert isinstance(h_t_t_pie_argument_parser_0, HTTPieArgumentParser)
    assert not h_t_t_pie_argument_parser_0.parse_args([])
    assert isinstance(h_t_t_pie_argument_parser_0.parse_args(['--help']), argparse.Namespace)


# Generated at 2022-06-25 18:00:34.998594
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = h_t_t_pie_argument_parser_0.parse_args('--version')
    assert args.version is True


# Generated at 2022-06-25 18:00:35.952439
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    test_case_0()


# Generated at 2022-06-25 18:00:40.332801
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.error = mock.MagicMock()
    h_t_t_pie_argument_parser_0.error.side_effect = AttributeError
    h_t_t_pie_argument_parser_0.error.__name__ = 'error'
    try:
        h_t_t_pie_argument_parser_0.parse_args(['-h'])
    except AttributeError:
        pass
    h_t_t_pie_argument_parser_0.error.assert_called_with(None, None, None)


# Generated at 2022-06-25 18:00:48.788586
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    try:
        h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
        assert h_t_t_pie_argument_parser_1.parse_args('--help') == True

    except AssertionError:
        logger.log_error("Test failed", __file__, sys._getframe().f_lineno)
        print(traceback.print_exc())


# Generated at 2022-06-25 18:03:13.860125
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_args_0 = h_t_t_pie_argument_parser_0.parse_args()
    assert isinstance(h_t_t_pie_args_0, argparse.Namespace)



# Generated at 2022-06-25 18:03:17.658677
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Create an instance of HTTPieArgumentParser
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()

    # Call method parse_args of h_t_t_pie_argument_parser_0
    h_t_t_pie_argument_parser_0.parse_args()



# Generated at 2022-06-25 18:03:24.935124
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # a HTTPieArgumentParser
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    # str
    argv_0 = sys.argv
    # assert h_t_t_pie_argument_parser_0.parse_args(argv=argv_0)
    # None
    print(h_t_t_pie_argument_parser_0.parse_args(argv=argv_0))


# Generated at 2022-06-25 18:03:28.732355
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    env = Environment()
    args = h_t_t_pie_argument_parser_0.parse_args(['--debug'], env=env)
    assert args.debug == True


# Generated at 2022-06-25 18:03:31.572624
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.parse_args()



# Generated at 2022-06-25 18:03:32.595147
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    test_case_0()


# Generated at 2022-06-25 18:03:37.843548
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    subcommand = "test"

    #case0: subcommand is null
    res = parser.parse_args(arguments=None, subcommand=None)
    assert res.h_t_t_pie_version == None

    #case1: subcommand is not null
    res = parser.parse_args(arguments=None, subcommand="test")
    assert res.h_t_t_pie_version == "test"
    # Write your code here


# Generated at 2022-06-25 18:03:40.268445
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Configure REST API and JSON nodes to send HTTP requests and obtain response
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.parse_args()

# Generated at 2022-06-25 18:03:43.232392
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Command line arguments
    args = []

    # Expected return value
    expected_return_value = None

    assert expected_return_value == h_t_t_pie_argument_parser_0.parse_args(args)




# Generated at 2022-06-25 18:03:47.641959
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    try:
        h_t_t_pie_argument_parser_0.parse_args()
    except SystemExit as e:
        assert e.code == 2
