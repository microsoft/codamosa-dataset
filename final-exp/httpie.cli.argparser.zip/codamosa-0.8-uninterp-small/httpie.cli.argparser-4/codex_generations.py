

# Generated at 2022-06-25 17:55:13.934497
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from .downloads import Downloader
    from .output.streams import VerifiedHTTPSConn

    from . import __version__ as version
    from .input import ParseError

    # Create fake command line arguments

# Generated at 2022-06-25 17:55:17.045805
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # type: () -> None
    assert_raises(ValueError, HTTPieArgumentParser().parse_args, [])
    assert(HTTPieArgumentParser().parse_args(['https://httpie.org']) is not None)



# Generated at 2022-06-25 17:55:19.825982
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.add_argument('-t','--timeout',type=None,default=None)
    parser.parse_args(['-t','a'])


# Generated at 2022-06-25 17:55:20.974810
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    pass


# Generated at 2022-06-25 17:55:31.652826
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO: This test was not written completely
    cli_args = ['--json', '--form', 'y=2', '--form', 'x=1', 'httpbin.org/get',
                'X-Header:value', 'host:httpbin.org', ':80', ':', '@/dev/null',
                'http://httpbin.org/post', 'a==', 'b:=', 'key==val', 'empty==',
                'undef==None', 'Host:', 'color==auto', 'timeout=', '=abc',
                '==abc', '::', '@:@', '0']
    try:
        args = HTTPieArgumentParser().parse_args(cli_args)
    except Exception as e:
        # TODO: Find a way to check that an exception was raised
        pass

# Generated at 2022-06-25 17:55:40.566972
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    raw_request_item_args = [
        'GET', 'http://httpbin.org/anything',
        'key-vim=val-vim', 'key-httpie=val-httpie'
    ]
    arg_parser_0 = HTTPieArgumentParser()
    args, alone_args = arg_parser_0.parse_known_args(raw_request_item_args)

    if args.request_items:
        print("Request items are: ")
        for item in args.request_items:
            print("item is: ", item)


# Generated at 2022-06-25 17:55:43.865661
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    test_case_0()

if __name__ == '__main__':
    test_HTTPieArgumentParser_parse_args()
    print('test is done')

# Generated at 2022-06-25 17:55:46.935010
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_0 = HTTPieArgumentParser()
    # FIXME: Replaced by test_case_0.
    httpie_argument_parser_0.parse_args()

# Generated at 2022-06-25 17:55:50.726227
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.parse_args()
    pass

if __name__ == '__main__':
    test_HTTPieArgumentParser_parse_args()
    pass

# Generated at 2022-06-25 17:55:56.484768
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_help_formatter_0 = HTTPieHelpFormatter()
    httpie_argument_parser_0.set_defaults(
        debug=False,
        download=False,
        download_resume=False,
        follow=False,
        form=False,
        ignore_netrc=False,
        ignore_stdin=False,
        json=False,
        output_file_specified=False,
        plain=False,
        traceback=False,
        verify=True,
    )
    httpie_argument_parser_0.add_argument(
        '-v', '--verbose', action='store_true',
        help='Enables verbose output.')
    httpie_argument_parser_0.add

# Generated at 2022-06-25 17:56:40.410718
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_0 = HTTPieArgumentParser()
    httpie_argument_parser_1 = HTTPieArgumentParser()
    httpie_argument_parser_2 = HTTPieArgumentParser()
    httpie_argument_parser_3 = HTTPieArgumentParser()
    httpie_argument_parser_4 = HTTPieArgumentParser()
    httpie_argument_parser_5 = HTTPieArgumentParser()
    httpie_argument_parser_6 = HTTPieArgumentParser()
    httpie_argument_parser_7 = HTTPieArgumentParser()
    httpie_argument_parser_8 = HTTPieArgumentParser()
    httpie_argument_parser_9 = HTTPieArgumentParser()
    httpie_argument_parser_10 = HTTPieArgumentParser()
    httpie_argument_parser_11 = HTTPie

# Generated at 2022-06-25 17:56:42.216804
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(args=["http://httpbin.org/get"])
    assert args.url == "http://httpbin.org/get"


# Generated at 2022-06-25 17:56:48.301063
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    # This test case has been removed from this function because it was
    # not supported by the current script generator.
    return


# Generated at 2022-06-25 17:56:58.903998
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_0 = HTTPieArgumentParser()
    # Test for when argv is not empty
    assert isinstance(httpie_argument_parser_0.parse_args([sys.argv[0]]), argparse.Namespace)
    # Test for when argv is empty
    assert isinstance(httpie_argument_parser_0.parse_args(argv=[]), argparse.Namespace)

if __name__ == "__main__":
    test_case_0()
    test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-25 17:57:08.844988
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    test_HTTPieArgumentParser_parse_args_test_case_0__argv = [
        '',
        '-v',
        'http://localhost:80',
        '--json'
        ]
    test_HTTPieArgumentParser_parse_args_test_case_0__expected = None
    h_t_t_pie_argument_parser_0.parse_args(
        test_HTTPieArgumentParser_parse_args_test_case_0__argv
    )
    assert h_t_t_pie_argument_parser_0 == test_HTTPieArgumentParser_parse_args_test_case_0__expected

if __name__ == "__main__":
    test_case_0()
   

# Generated at 2022-06-25 17:57:20.349228
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    httpie_argument_parser_0 = HTTPieArgumentParser(True)


# Generated at 2022-06-25 17:57:33.003529
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.config import DEFAULT_CONFIG_DIR, DEFAULT_CONFIG_PATH
    from httpie.input import KeyValue, KeyValueArgType
    from httpie.plugins import plugin_manager
    from httpie.downloads import Downloader
    from httpie.session import Session
    from httpie.compat import is_windows, is_py26, is_py27
    from httpie.compat import str, bytes
    import io, sys, tempfile, os
    import pytest
    from pathlib import Path
    import pkg_resources
    print()
    print('Unit test for: HTTPieArgumentParser.parse_args()')
    print()

    #print(dir(HTTPBasicAuth))
    #print(dir(KeyValue))
    #print(

# Generated at 2022-06-25 17:57:44.218537
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # h_a_p_0 = HTTPieArgumentParser(prog='http -h')
    parser = HTTPieArgumentParser(prog='http -h')
    args = parser.parse_args()

# Generated at 2022-06-25 17:57:55.473271
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_T_T_pie_arg_parser_0 = HTTPieArgumentParser()

    # Test cases
    # Example: http --form POST example.org hello=World
    #__main__.test_case_0
    h_T_T_pie_arg_parser_0.parse_args(
        '--form POST example.org hello=World'.split())

    # Example: http https://httpbin.org/headers
    #__main__.HTTPieArgumentParser.parse_args_test_case_1
    h_T_T_pie_arg_parser_0.parse_args(
        'https://httpbin.org/headers'.split())

    # Example: http --json POST https://httpbin.org/anything key1=val1 key2=val2
    #__main__.HTTPieArgumentParser.parse

# Generated at 2022-06-25 17:58:02.830777
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    arg_parser = HTTPieArgumentParser()
    arg_parser.add_argument('--method',
        dest = 'method',
        help = 'HTTP method to use for the request',
        required = False)
    arg_parser.add_argument('--url',
        dest = 'url',
        help = 'URL to send the request to',
        required = True)
    arg_parser.add_argument('--body',
        dest = 'body',
        help = 'item to include in the body',
        required = False)
    arg_parser.add_argument('--output',
        dest = 'output_file',
        help = 'output file',
        required = False)

# Generated at 2022-06-25 17:59:11.402666
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    httpie_argument_parser_0 = HTTPieArgumentParser()

    try:
        httpie_argument_parser_0.parse_args()
    except SystemExit:
        pass
    try:
        httpie_argument_parser_0.parse_args(['-k', '-v'])
    except SystemExit:
        pass
    try:
        httpie_argument_parser_0.parse_args(['-J', '-h'])
    except SystemExit:
        pass
    try:
        httpie_argument_parser_0.parse_args(['-u', '-a'])
    except SystemExit:
        pass
    try:
        httpie_argument_parser_0.parse_args(['--form', '--download'])
    except SystemExit:
        pass

# Generated at 2022-06-25 17:59:21.175938
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    test_env_var_0 = os.environ
    test_env_var_1 = {'EDITOR': 'dummy-editor'}
    httpie_argparse_0 = HTTPieArgumentParser(
            httpie_env=Environment(debug=True, env=test_env_var_0, stdin=sys.stdin, stdin_isatty=True, stdout=sys.stdout, stdout_isatty=True, stderr=sys.stderr, stderr_isatty=True),
            add_help=False,
            formatter_class=HTTPieHelpFormatter,
            prog='http'
            )

# Generated at 2022-06-25 17:59:29.544007
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_pie_argument_parser_0._setup_standard_streams()
    h_t_pie_argument_parser_0._setup_args_parsing()
    h_t_pie_argument_parser_0._parse_items()
    h_t_pie_argument_parser_0._apply_no_options(['--no-print', '--no-download'])
    h_t_pie_argument_parser_0._guess_method()
    h_t_pie_argument_parser_0._process_auth()
    h_t_pie_argument_parser_0._process_output_options()
    h_t_pie_argument_parser_0._process_pretty_options()
    h_t_pie_argument

# Generated at 2022-06-25 17:59:40.960873
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    arg_parser_0 = HTTPieArgumentParser(
        prog='http',
        description="cURL-like tool for humans.",
        epilog=("See https://httpie.org/doc#help for more detailed help, "
                "examples, and info."),
        formatter_class=HTTPieHelpFormatter,
        prefix_chars='-+',
        add_help=False
    )
    arg_parser_0.add_argument('-X', '--method', dest='method', default=None, help='Specify request method to use.')
    arg_parser_0.add_argument('-v', '--verbose', dest='verbose', action='store_true', help='Print the whole request.')

# Generated at 2022-06-25 17:59:41.856942
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    pass


# Generated at 2022-06-25 17:59:51.910236
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_0 = HTTPieArgumentParser(prog='httpie', add_config_dir=True, env=Environment(), version=__version__)
    httpie_argument_parser_0.add_argument('--download-max-size', type=as_int_or_raise, metavar='BYTES', dest='download_max_size', help='Set a maximum content size to download (use \'0\' to disable).')
    httpie_argument_parser_0.add_argument('--form-string', '--form', '--data', '-d', action='append', dest='request_items', type=KeyValueArgType(*SEPARATOR_GROUP_DATA_ITEMS), help='Set form values (H)')

# Generated at 2022-06-25 17:59:52.777462
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO
    pass


# Generated at 2022-06-25 17:59:54.870409
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_0 = HTTPieArgumentParser()
    try:
        httpie_argument_parser_0.parse_args(None)
    except SystemExit:
        pass
    else:
        raise AssertionError("AssertionError")


# Generated at 2022-06-25 18:00:05.867084
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser(
        prog='')
    h_t_t_pie_argument_parser_2 = HTTPieArgumentParser(
        prog='',
        usage=None)
    h_t_t_pie_argument_parser_3 = HTTPieArgumentParser(
        prog='',
        usage='',
        description=None)
    h_t_t_pie_argument_parser_4 = HTTPieArgumentParser(
        prog='',
        usage='',
        description='',
        epilog=None)

# Generated at 2022-06-25 18:00:16.714940
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_0 = HTTPieArgumentParser()
    httpie_argument_parser_0._create_parser()
    httpie_argument_parser_0._add_arguments()
    # args = [
    #     '--download',
    #     'https://api.github.com/repos/jkbrzt/httpie/tarball/0.9.9',
    #     '--output',
    #     '/tmp/httpie-github-api-github-com-repos-jkbrzt-httpie-tarball-0-9-9'
    # ]
    args = [
        'https://leetcode-cn.com/api/problems/all/',
        '--verbose'
    ]
    httpie_argument_parser_0.parse_args(args)

# Generated at 2022-06-25 18:02:30.521765
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Create a new HTTPieArgumentParser object
    parser = HTTPieArgumentParser()
    parser.parse_args(['https://www.example.com/'])


# Generated at 2022-06-25 18:02:38.731785
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    # Call HTTPieArgumentParser.parse_args to parse the arguments
    # httpie_argument_parser_0 = HTTPieArgumentParser()
    # httpie_argument_parser_0.parse_args(["--traceback", "https://postman-echo.com/post", "test=test"])
    # httpie_argument_parser_0.parse_args(["https://postman-echo.com/post", "test=test"])
    httpie_arg_parser_2 = HTTPieArgumentParser()
    httpie_arg_parser_2.parse_args(["--auth", "testuser:1234", "https://postman-echo.com/post", "test=test"])

# Generated at 2022-06-25 18:02:46.997003
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    argv = shlex.split("http --follow --headers \"a: b\" --form")
    parser_0 = HTTPieArgumentParser(
        prog='http',
        description='CLI HTTP client. Supports HTTP/1.1 and HTTP/2.\n\n'
            'SEE ALSO:\n\n    http://httpie.org/doc',
        usage='http [OPTIONS] [URL]...\n\n'
            'With no URL argument, it reads from standard input.',
        add_help=True,
        formatter_class=HTTPieHelpFormatter
    )
    parser_0.exit = lambda code=0: ''
    parser_0.print_help = lambda file=None: ''
    parser_0.print_usage = lambda file=None: ''
    parser_0.error = lambda message: ''

# Generated at 2022-06-25 18:02:51.718597
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()

    test_args = ['https://httpbin.org/get']
    test_namespace = h_t_t_pie_argument_parser_0.parse_args(test_args)
    print(test_namespace.url)


# Generated at 2022-06-25 18:02:59.959152
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test case 0
    HTTPieArgumentParser_class_0 = HTTPieArgumentParser()
    HTTPieArgumentParser_class_0.parse_args(['--json', '{}'])
    HTTPieArgumentParser_class_0.parse_args()

if __name__ == '__main__':
    test_case_0()
    test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-25 18:03:03.917716
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser = HTTPieArgumentParser()
    try:
        h_t_t_pie_argument_parser.parse_args(["", "--version"])
    except:
        print('Exception')
    return


# Generated at 2022-06-25 18:03:04.475900
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    pass



# Generated at 2022-06-25 18:03:14.150889
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.add_argument('--help', action='store_true')
    parser.add_argument('-v', '--verbose', action='store_true')
    parser.add_argument('-m', '--method', type=str)
    parser.add_argument('-a', '--auth', type=str)
    parser.add_argument('-M',
                        '--manual-auth',
                        '--auth-type',
                        default='basic',
                        type=str)
    parser.add_argument('-p', '--print', default='hB')
    parser.add_argument('-b',
                        '--body',
                        action='store_true',
                        help='Include response body in the output')

# Generated at 2022-06-25 18:03:21.266532
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # LHS operand
    parser = HTTPieArgumentParser(prog='http', env=Environment())
    argument_parser_parse_args_parser = parser
    # RHS operand
    args = ['https://httpie.org/get']
    argument_parser_parse_args_args = args

    args = argument_parser_parse_args_parser.parse_args(argument_parser_parse_args_args)
    print(args)

if __name__ == '__main__':
    test_case_0()
    test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-25 18:03:32.330734
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_0 = HTTPieArgumentParser()
    # Test HTTPieArgumentParser.parse_args() with arguments (None)
    try:
        httpie_argument_parser_0.parse_args()
    except SystemExit as exception_0:
        print(exception_0)
    try:
        httpie_argument_parser_0.parse_args(['--ignore-stdin', '--auth-type=basic', '--body', '--prettify'])
    except SystemExit as exception_0:
        print(exception_0)
    try:
        httpie_argument_parser_0.parse_args(['--auth-type=basic', '--body', '--prettify'])
    except SystemExit as exception_0:
        print(exception_0)

# Unit test