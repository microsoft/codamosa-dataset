

# Generated at 2022-06-25 17:55:11.837146
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import sys
    import os
    # Constructor test
    obj = HTTPieArgumentParser()

    # Setting up args
    print("Setting up args")
    parser = HTTPieArgumentParser()
    httpie_dir = os.path.dirname(__file__)+'/..'

# Generated at 2022-06-25 17:55:12.940216
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    test_case_0()
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()


# Generated at 2022-06-25 17:55:15.639075
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = [
      'www.google.com',
      '--auth-type',
      'digest',
      '-vb',
      'POST',
      '--ignore-netrc'
    ]
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_1.parse_args(args)


# Generated at 2022-06-25 17:55:21.132556
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Case 1
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    arguments = [b'localhost']
    h_t_t_pie_argument_parser_0.parse_args(arguments)
    # Test case 0 is ok
    test_case_0()

if __name__ == '__main__':
    test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-25 17:55:31.776829
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.parse_args()
    h_t_t_pie_argument_parser_0.parse_args(['--version'])
    h_t_t_pie_argument_parser_0.parse_args(['--verbose'])
    h_t_t_pie_argument_parser_0.parse_args(['--form', '--headers'])
    h_t_t_pie_argument_parser_0.parse_args(['--download', '--output'])
    h_t_t_pie_argument_parser_0.parse_args(['--ignore-stdin', '--exit-status'])
    h_t_t_pie_argument_parser_0

# Generated at 2022-06-25 17:55:36.024768
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    # TODO: Invoke parse_args
    # h_t_t_pie_argument_parser_0.parse_args()



# Generated at 2022-06-25 17:55:42.688764
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Define arguments
    args_0 = []
    # Check exception
    try:
        HTTPieArgumentParser().parse_args(args_0)
    except HTTPieArgumentParserError as e:
        pass
    args_1 = ['test']
    # Check exception
    try:
        HTTPieArgumentParser().parse_args(args_1)
    except HTTPieArgumentParserError as e:
        pass

# Generated at 2022-06-25 17:55:49.790970
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    args = ['test']
    try:
        h_t_t_pie_argument_parser_0.parse_args(args=args)
        print('\n...Success, parse_args in class HTTPieArgumentParser')
    except Exception as e:
        print('\nFailed, parse_args in class HTTPieArgumentParser')
        print(e)


# Generated at 2022-06-25 17:55:53.780273
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
    argv = []
    # No exception expected:
    h_t_t_pie_argument_parser_1.parse_args(argv)


# Generated at 2022-06-25 17:56:02.623556
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    sys.argv = ["httpie", "http://httpie.org", "Accept:application/json", "User-Agent:a client"]
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.add_argument("-l", "--list", action="store_true",dest="list", help="List plugins.")
    h_t_t_pie_argument_parser_0.add_argument("-d", "--download", action="store_true", dest="download", help="Download the request body.",)

# Generated at 2022-06-25 17:57:00.455304
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.parse_args()


# Generated at 2022-06-25 17:57:02.972766
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0_parse_args = h_t_t_pie_argument_parser_0.parse_args(['hello.com'])
    assert h_t_t_pie_argument_parser_0_parse_args


# Generated at 2022-06-25 17:57:11.942395
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
    # noinspection PyTypeChecker
    actual = h_t_t_pie_argument_parser_1.parse_args(["--format","json","--pretty","all","get","https://httpbin.org/get","Accept:application/json"])
    expected = namespace(download=False, download_resume=False, output_file=None, output_file_specified=False, output_options=None, output_options_history=None, output_stream=None, params=[], raw_http=False, request_items=[KeyValueArg('Accept', 'application/json', 'application/json', None, False, None)], stdin_isatty=False, traceback=False)
    assert actual == expected


# Generated at 2022-06-25 17:57:14.414444
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()


# Generated at 2022-06-25 17:57:27.043329
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    args = h_t_t_pie_argument_parser_0.parse_args(['httpie', 'https://api.github.com/repos/jakubroztocil/httpie'])
    assert args.output_file_specified == False
    assert args.output_options == 'C'
    assert args.output_options_history == 'C'
    assert args.pretty == 'all'
    assert args.download == False
    assert args.download_resume == False
    assert args.format == 'pretty'
    assert args.format_options == {}
    assert args.follow == False



# Generated at 2022-06-25 17:57:33.954493
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    raw_args_0 = ()
    try:
        h_t_t_pie_argument_parser_0.parse_args(raw_args_0)
    except SystemExit as e:
        assert (e.code == 0)
        return
    raise Exception(
        'ExpectedSystemExit not raised by HTTPieArgumentParser.parse_args')


# Generated at 2022-06-25 17:57:42.093282
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    print("Test: test_HTTPieArgumentParser_parse_args")
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    try:
        r = h_t_t_pie_argument_parser_parse_args_0 = h_t_t_pie_argument_parser_0.parse_args()
        print("args.print = " + r.print)
    except SystemExit:
        pass
    except:
        print("Unexpected error:", sys.exc_info()[0])
        raise


# Generated at 2022-06-25 17:57:48.492403
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = HTTPieArgumentParser.parse_args(
        ['get', 'http://httpbin.org/get'], stdin=None)
    assert args.method == 'GET'
    assert args.url == 'http://httpbin.org/get'
    assert not args.data
    assert not args.headers
    assert not args.files
    assert not args.params


# Generated at 2022-06-25 17:57:49.377715
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    pass

# Generated at 2022-06-25 17:57:58.840812
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-25 17:59:09.401423
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_1 = HTTPieArgumentParser()

    try:
        httpie_argument_parser_1.parse_args(''.split())
    except SystemExit:
        pass

    try:
        httpie_argument_parser_1.parse_args('--method GET --body GET GET GET GET GET GET GET GET GET GET GET GET GET GET GET GET'.split())
    except SystemExit:
        pass

    try:
        httpie_argument_parser_1.parse_args('--method GET --body GET GET GET GET GET GET GET GET GET GET GET GET GET GET GET GET --verify'.split())
    except SystemExit:
        pass


# Generated at 2022-06-25 17:59:14.349829
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_0 = HTTPieArgumentParser()
    # Test method with no arg
    try:
        httpie_argument_parser_0.parse_args()
    except Exception as exception_value:
        print('Exception value:', exception_value)


# Generated at 2022-06-25 17:59:24.364100
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import sys, os
    from httpie.constants import HTTPIE_CONFIG_DIR
    from httpie import constants as C
    import os.path
    argv = ["http[s]://localhost:8080/"]
    if _pythonMajorVersion < 3:
        import __builtin__
        builtins = __builtin__
    else:
        import builtins
    builtins.__dict__['_'] = lambda str: str
    tmp_config_home = os.path.join(os.getcwd(), "test")
    os.environ['HOME'] = tmp_config_home
    os.mkdir(tmp_config_home)
    os.mkdir(os.path.join(tmp_config_home, HTTPIE_CONFIG_DIR))
    httpie_argument_parser_0 = HTTPieArgumentParser()

# Generated at 2022-06-25 17:59:30.044206
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser_0 = HTTPieArgumentParser()
    parser_0.add_argument('--foo, -f', action='store_true', help='foo help')
    parser_0.parse_args(['-f', '-vvv'])


# Generated at 2022-06-25 17:59:31.399144
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args()


# Generated at 2022-06-25 17:59:39.292453
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    test_args = ['http', 'httpbin.org/get']
    h_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_pie_argument_parser_args = h_t_pie_argument_parser_0.parse_args(test_args)
    assert (h_t_pie_argument_parser_args.url == test_args[1])
    
test_HTTPieArgumentParser_parse_args()


# Generated at 2022-06-25 17:59:50.393810
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie.input import KeyValueArgType
    from httpie.input import SEPARATOR_GROUP_ALL_ITEMS
    from httpie.constants import HTTP_GET, HTTP_POST
    # HTTPieArgumentParser(args=None, prog=None, formatter_class=None, **kwargs)
    httpieArgumentParser_0 = HTTPieArgumentParser()
    httpieArgumentParser_0.add_argument('--request-items',
        action='append',
        default=[],
        dest='request_items',
        type=KeyValueArgType(
            *SEPARATOR_GROUP_ALL_ITEMS),
        help='Request item')
    httpieArgumentParser_0.add_argument('--method',
        dest='method',
        help='Specify request method')

# Generated at 2022-06-25 17:59:52.784511
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test cases here
    a_rg_parse_0 = HTTPieArgumentParser()
    a_rg_parse_0._parse_args()
    a_rg_parse_0.parse_args()

# Generated at 2022-06-25 17:59:54.516618
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = []
    with pytest.raises(SystemExit):
        parser = HTTPieArgumentParser(args)
        parser.parse_args()
        # (self, args, env)


# Generated at 2022-06-25 18:00:05.505393
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    process_output_options_0 = HTTPieArgumentParser(
        args=['http', 'https://httpbin.org/get'],
        env=Environment()
    )

    # Body is required for this request
    parse_items_0 = HTTPieArgumentParser(
        args=['http', 'https://httpbin.org/put'],
        env=Environment()
    )

    # Case 1: no arguments
    try:
        parse_items_0.parse_args([])
    except SystemExit as e:
        assert e.code == 2
    else:
        raise Exception("Expected SystemExit")
    parse_items_0 = HTTPieArgumentParser(
        args=['http', 'https://httpbin.org/get'],
        env=Environment()
    )

    # Case 2: one argument

# Generated at 2022-06-25 18:02:20.811113
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.add_argument("-t", help="-t option", type=bool, default=False)
    h_t_t_pie_argument_parser_0.parse_args(["-t"])


# Generated at 2022-06-25 18:02:32.993544
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    session = requests.Session()
    stdin_isatty = sys.stdin.isatty()
    stdout_isatty = sys.stdout.isatty()

# Generated at 2022-06-25 18:02:35.865302
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_arg_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_arg_parser_0.parse_args()


# Generated at 2022-06-25 18:02:38.829160
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # The parser namespace of HTTPieArgumentParser.
    args_0 = HTTPieArgumentParser().parse_args()
    assert(args_0 == None)


# Generated at 2022-06-25 18:02:47.076216
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_0 = HTTPieArgumentParser(prog="httpie")
    httpie_argument_parser_1 = HTTPieArgumentParser(prog="httpie", add_help=False)
    httpie_argument_parser_2 = HTTPieArgumentParser(prog="httpie", add_help=False)
    httpie_argument_parser_3 = HTTPieArgumentParser(prog="httpie", add_help=False)
    httpie_argument_parser_4 = HTTPieArgumentParser(prog="httpie", add_help=False)
    httpie_argument_parser_5 = HTTPieArgumentParser(prog="httpie", add_help=False)
    httpie_argument_parser_6 = HTTPieArgumentParser(prog="httpie", add_help=False)
    http

# Generated at 2022-06-25 18:02:51.475161
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    tester_HTTPieArgumentParser_parse_args_0 = HTTPieArgumentParser()
    # assert tester_HTTPieArgumentParser_parse_args_0.parse_args() ==
    assert_equal(tester_HTTPieArgumentParser_parse_args_0.parse_args(), None)


# Generated at 2022-06-25 18:03:04.367691
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser(prog='test', add_help=False)
    h_t_t_pie_debug_formatter_0 = HTTPieDebugFormatter(prog='test', add_help=False)
    h_t_t_pie_argument_parser_0.add_argument('--help', '-h', action='help')
    h_t_t_pie_argument_parser_0.add_argument('--verbose', '-v', action='store_true')
    h_t_t_pie_argument_parser_0.add_argument('--version', '-V', action='version')
    h_t_t_pie_argument_parser_0.add_argument('url')
    h_t_t_pie_argument_parser_1

# Generated at 2022-06-25 18:03:10.655995
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    try:
        h_t_t_pie_argument_parser_0.parse_args()
    except SystemExit as e:
        if e.code != 0:
            print("parse_args with Cmd: {} failed", ' '.join(sys.argv))

while True:
    test_case_0()
    test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-25 18:03:11.253066
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    pass


# Generated at 2022-06-25 18:03:20.706425
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser_parse_args_0 = HTTPieArgumentParser()
    parse_arg_return_value_0 = parser_parse_args_0.parse_args()
    assert (parse_arg_return_value_0.auth_plugin.__class__.__name__ == 'NoAuth')
    assert (parse_arg_return_value_0.auth_type == 'noauth')
    assert (parse_arg_return_value_0.download == False)
    assert (parse_arg_return_value_0.download_resume == False)
    assert (parse_arg_return_value_0.form == True)
    assert (parse_arg_return_value_0.follow == False)
    assert (parse_arg_return_value_0.headers == OrderedDict())