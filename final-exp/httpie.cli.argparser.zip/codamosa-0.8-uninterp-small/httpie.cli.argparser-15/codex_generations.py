

# Generated at 2022-06-25 17:55:06.837222
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args_0 = HTTPieArgumentParser()
    args_1 = args_0.parse_args(["https://httpie.org/get"])
    args_2 = args_0.parse_args(["https://httpie.org/get", "-h"])
    print(args_1)
    print(args_2)


# Generated at 2022-06-25 17:55:08.587897
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    unit_test_argv = "http 'http://127.0.0.1' -v"
    argv = unit_test_argv.split() 
    parser = HTTPieArgumentParser()
    parser.parse_args(argv)
    

# Generated at 2022-06-25 17:55:12.778170
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    test_args_0 = ['--ignore-stdin']
    assert h_t_t_pie_argument_parser_0.parse_args(test_args_0)


# Generated at 2022-06-25 17:55:19.384133
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    ap = HTTPieArgumentParser()
    argv = ['-f', 'json', 'httpie.org']
    ap.parse_args(argv=argv)

    argv = ['POST', 'httpie.org']
    ap.parse_args(argv=argv)

    argv = ['--data', 'c', 'httpie.org']
    ap.parse_args(argv=argv)

    argv = ['--data', 'c', 'httpie.org']
    ap.parse_args(argv=argv)


# Generated at 2022-06-25 17:55:30.434213
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()

    # Test if the method parse_args of class HTTPieArgumentParser is working properly
    assert h_t_t_pie_argument_parser_0.parse_args(["curl", "--", "http://localhost:8080/api/v1/close"]).url == "curl"
    assert h_t_t_pie_argument_parser_0.parse_args(["curl", "--", "http://localhost:8080/api/v1/close"]).method == "GET"
    assert h_t_t_pie_argument_parser_0.parse_args(["curl", "--", "http://localhost:8080/api/v1/close"]).headers == {}
    assert h_t_t_pie_argument

# Generated at 2022-06-25 17:55:37.155330
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_parse_args_0 = HTTPieArgumentParser()
    str_0 = ' '
    str_1 = '#'
    str_2 = '6'
    str_3 = ':'
    str_4 = ','
    str_5 = '@'
    str_6 = '?'
    str_7 = '__GLOBAL__'
    str_8 = '__netrc__'
    str_9 = '__netrc_file__'
    str_10 = '__netrc_machine__'
    str_11 = '__netrc_password__'
    str_12 = '__netrc_username__'
    str_13 = '__piped__'
    str_14 = '__json__'
    str_15 = '__item__'

# Generated at 2022-06-25 17:55:49.320052
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-25 17:55:55.183809
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    sys.argv = [
        'http', 'https://httpie.org/', 'Accept:', 'application/json', 'User-Agent:', 'HTTPie/0.9.2'
    ]
    h_t_t_pie_argument_parser_0.parse_args()


# Generated at 2022-06-25 17:56:03.110875
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Instantiate with a docstring
    arg_parser = HTTPieArgumentParser(description='description', epilog='epilog')
    arg_parser.add_argument('--arg_name_1', action='store_const', const=True, dest='arg_name_1', help='Test argument 1')
    arg_parser.add_argument('--arg_name_2', type=int, dest='arg_name_2', help='Test argument 2')
    test_args = ['--arg_name_2', '2']
    args, unknown_args = arg_parser.parse_known_args(test_args)
    # Test
    assert known_args.arg_name_1 == None
    assert known_args.arg_name_2 == 2


# Generated at 2022-06-25 17:56:15.629553
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    argument_parser_0 = HTTPieArgumentParser(
        prog='http')
    HTTPieArgumentParser_parse_args_var_0 = argument_parser_0.parse_args([])
    print(HTTPieArgumentParser_parse_args_var_0.url)

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


# Generated at 2022-06-25 17:56:59.009941
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_0 = HTTPieArgumentParser()
    with pytest.raises(AttributeError):
        httpie_argument_parser_0.parse_args(argv_0=['http', '--version'])
        httpie_argument_parser_0.parse_args(argv_0=['http', '--help'])
        httpie_argument_parser_0.parse_args(argv_0=['http'])


# Generated at 2022-06-25 17:57:00.194366
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    test_case_0()


# Generated at 2022-06-25 17:57:03.904855
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser(
        usage=set_usage()
    )
    h_t_t_pie_argument_parser_0._add_arguments()


# Generated at 2022-06-25 17:57:11.002130
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # From:
    # https://github.com/jakubroztocil/httpie/blob/0.9.8/tests/test_arguments.py#L222-L363
    def _run(a):
        return HTTPieArgumentParser().parse_args(a)

    args = _run(['-v', 'GET', 'http://example.org/'])
    assert args.method == 'GET'
    assert args.url == 'http://example.org/'
    assert args.verbose == True

    args = _run(['GET', 'http://example.org/'])
    assert args.method == 'GET'
    assert args.url == 'http://example.org/'
    assert args.verbose == False

    args = _run(['GET'])

# Generated at 2022-06-25 17:57:24.050168
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    a = HTTPieArgumentParser()
    # Assert statements
    assert a.args.url == 'http://httpie.org' # asserts that a.args.url is equal to 'http://httpie.org'
    assert a.has_stdin_data == False # asserts that a.has_stdin_data is equal to False
    assert a.args.output_file is None # asserts that a.args.output_file is equal to None
    assert a.args.output_file_specified == False # asserts that a.args.output_file_specified is equal to False
    assert a.args.download == False # asserts that a.args.download is equal to False
    assert a.args.verbose == False # asserts that a.args.verbose is equal to False
    assert a.args.output_options == 'HhB' # asserts

# Generated at 2022-06-25 17:57:27.356233
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    arg_values = 'request_item+'
    arg_names = ['url']
    namespace = argparse.Namespace()
    raise Exception("Not implemented")


# Generated at 2022-06-25 17:57:37.213439
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_args_0 = Namespace()
    h_t_t_pie_args_0.ignore_stdin = True
    h_t_t_pie_args_0.output_file = sys.stdout
    h_t_t_pie_args_0.output_file_specified = True
    h_t_t_pie_args_0.download = False
    h_t_t_pie_args_0.prettify = 'all'
    h_t_t_pie_args_0.prettifier = PRETTY_MAP['all']

# Generated at 2022-06-25 17:57:42.162066
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_1.data_items_are_form = MagicMock(return_value=None)
    h_t_t_pie_argument_parser_1.print_message = MagicMock(return_value=None)
    h_t_t_pie_argument_parser_1.parse_known_args = MagicMock(return_value=(None,None))
    h_t_t_pie_argument_parser_1.set_defaults = MagicMock(return_value=None)
    h_t_t_pie_argument_parser_1.error = MagicMock(return_value=None)

# Generated at 2022-06-25 17:57:53.890057
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
    h_t_t_pie_root_arg_parser_0 = h_t_t_pie_argument_parser_1
    sys_argv_0 = [
        'http',
        '--traceback',
        '--auth-type',
        'basic',
        '--timeout',
        '0.0001',
        '--download',
        '--output',
        '-',
        'http://httpbin.org/get'
    ]
    # Arguments will be overwritten when read from configuration file,
    # so we need to preserve a copy after parsing, but before reading
    # configuration file.

# Generated at 2022-06-25 17:58:01.878759
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_0 = HTTPieArgumentParser(docs=None,
                                                    env=HTTPieEnvironment(),
                                                    add_help=True,
                                                    output_format='',
                                                    auto_env_prefix='HTTPIE_',
                                                    env_settings=None,
                                                    auto_env_var_prefix='HTTPIE_')
    httpie_argument_parser_0.add_argument('--ignore-stdin', help='',
                                          action='store_true')
    httpie_argument_parser_0.add_argument('--json', help='',
                                          action='store_true')
    httpie_argument_parser_0.add_argument('--form', help='',
                                          action='store_true')
    httpie_argument_parser_0.add_argument

# Generated at 2022-06-25 17:59:14.994786
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_parse_args_0 = h_t_t_pie_argument_parser_0.parse_args()

# Usage: HTTPie [--version] [--json] [--form] [--pretty {all,colors,format,none}]
# [--style STYLE] [--print WHAT] [--headers] [--body] [--verbose] [--all]
# [--history-print WHAT] [--stream] [--output FILE] [--download]
# [--continue] [--session SESSION] [--auth USER[:PASS]] [--auth-type BASIC|DIGEST]
# [--proxy PROTOCOL://HOST:PORT] [--follow] [--max

# Generated at 2022-06-25 17:59:20.598362
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_tpie_argument_parser_0 = HTTPieArgumentParser()
    h_t_tpie_argument_parser_0.error = lambda *s: raise_from(HTTPieError(), None)
    h_t_tpie_argument_parser_0.parse_args(['-v'])

if __name__ == "__main__":
    test_case_0()
    test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-25 17:59:22.861726
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    p = HTTPieArgumentParser()
    p.parse_args(['--version'])


# Generated at 2022-06-25 17:59:26.111828
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    test_args = ['https://github.com']
    h_t_t_pie_argument_parser_0.parse_args(args=test_args)


# Generated at 2022-06-25 17:59:39.891120
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test case for CLITests.test_cli_errors_traceback
    parser_0 = HTTPieArgumentParser()
    args_0 = parser_0.parse_args(('--traceback', 'http', ))
    s_t_d_o_u_t_0_0 = args_0.stdout
    s_t_d_e_r_r_0_0 = args_0.stderr
    o_u_t_p_u_t_file_specified_0_0 = args_0.output_file_specified
    auth_plugin_0_0 = args_0.auth_plugin
    s_t_d_o_u_t_0_1 = s_t_d_o_u_t_0_0
    s_t_d_e_r_r_0_1

# Generated at 2022-06-25 17:59:44.698702
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_0 = HTTPieArgumentParser()
    httpie_argument_parser_0.parse_args(['https://httpbin.org'])

if __name__ == "__main__":
    test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-25 17:59:54.293177
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    input_0 = [
        '--form',
        'key=value',
        '{0}'.format(MOCK_SERVER_BASE_URL),
    ]

# Generated at 2022-06-25 18:00:00.389760
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    print("Testing method parse_args of class HTTPieArgumentParser\n")

    httpie_parser = HTTPieArgumentParser()

    h_t_t_pie_help_formatter_0 = HTTPieHelpFormatter()
    httpie_parser._prog = ''
    args = httpie_parser.parse_args(['--prog-name', 'test', '--traceback', 'http://localhost/'])


# Generated at 2022-06-25 18:00:04.515942
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    help_formatter = HTTPieHelpFormatter()
    parser.formatter_class = help_formatter
    args = parser.parse_args(['--ignore-stdin'])
    print("Result: " + str(args))


# Generated at 2022-06-25 18:00:15.691251
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    # Instantiation of HTTPieArgumentParser class
    httpie_argument_parser_0 = HTTPieArgumentParser()

    # If HTTPieArgumentParser class attributes are changed, then the next line needs to be updated
    assert httpie_argument_parser_0._positionals._group_actions == []
    assert httpie_argument_parser_0._subparsers == None
    assert httpie_argument_parser_0._actions == []
    assert httpie_argument_parser_0._option_string_actions == {}
    assert httpie_argument_parser_0._defaults == {}
    assert httpie_argument_parser_0._has_negative_number_optionals == False
    assert httpie_argument_parser_0._registries == {'action': {}, 'type': {}, 'dest': {}}
    assert httpie_argument_

# Generated at 2022-06-25 18:02:46.581095
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # initialize argument parser
    args = ['https://httpbin.org/post', 'name=Nishant']
    parser = HTTPieArgumentParser()
    args_0 = parser.parse_args(args)


# Generated at 2022-06-25 18:02:49.939431
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    # h_t_t_pie_argument_parser_0.parse_args()


# Generated at 2022-06-25 18:02:53.464102
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.parse_args(['GET', 'http://example.com'])
    parser.parse_args(['GET', 'http://example.com', 'key=value'])
    parser.parse_args(['GET', 'http://example.com', 'key=value', 'other=value'])


# Generated at 2022-06-25 18:03:04.754335
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-25 18:03:09.592810
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Input parameters for method.
    args = ''
    env = None
    # Expected return value.
    return_value = None

    # Call method.
    return_value = HTTPieArgumentParser.parse_args(args, env)

    # Check if return value is as expected.
    assert return_value == return_value


# Generated at 2022-06-25 18:03:14.411140
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_0 = HTTPieArgumentParser()
    sys.argv = ['httpie', 'http://0.0.0.0:8080/print-args', '-a', '--auth-type', 'basic', '--auth', 'user:pass', '--traceback', 'DELETE', 'GET', 'POST']
    httpie_argument_parser_0.parse_args()

# Generated at 2022-06-25 18:03:17.665403
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    arg_str = '192.168.1.6'
    args = parser.parse_args(arg_str.split())
    assert args.url == arg_str


# Generated at 2022-06-25 18:03:24.109244
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_0 = HTTPieArgumentParser(requests.Session(), 
        stdout=sys.stdout, stderr=sys.stderr)
    httpie_argument_parser_0.parse_args(['http', 'httpbin.org', 'get'])
    httpie_argument_parser_0.parse_args(['http', '--version'])


# Generated at 2022-06-25 18:03:27.276200
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_0 = HTTPieArgumentParser()
    sys_argv = []
    args = httpie_argument_parser_0.parse_args(sys_argv)
    print(args)


# Generated at 2022-06-25 18:03:35.378639
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser(
        env=test_env_0,
        config_dir=test_config_dir_0,
        output_file=test_output_file_0
    )
    h_t_t_pie_argument_parser_0._parse_args(argv=test_argv_0)
    h_t_t_pie_argument_parser_0._parse_args(argv=test_argv_1)
    h_t_t_pie_argument_parser_0._parse_args(argv=test_argv_2)
