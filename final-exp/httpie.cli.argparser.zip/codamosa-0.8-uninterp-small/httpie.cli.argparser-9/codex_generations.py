

# Generated at 2022-06-25 17:55:12.178965
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    test_args = ['example.com']
    try:
        h_t_t_pie_argument_parser_0.parse_args(test_args)
        h_t_t_pie_argument_parser_0.error = error
    except SystemExit as exited:
        assert exited.code == 0


# Generated at 2022-06-25 17:55:21.673790
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    args = h_t_t_pie_argument_parser_0.parse_args(raw_args=[])
    assert args.help == False
    assert args.version == False
    assert args.check_updates == False
    assert args.ignore_stdin == False
    assert args.offline == False
    assert args.method == None
    assert args.data == None
    assert args.headers == None
    assert args.auth == None
    assert args.auth_type == None
    assert args.verify == True
    assert args.verify == True
    assert args.cert == None
    assert args.cert == None
    assert args.ssl == False
    assert args.timeout == None
    assert args.timeout == None
    assert args

# Generated at 2022-06-25 17:55:24.933162
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_1.parse_args()


# Generated at 2022-06-25 17:55:32.473769
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.add_argument("--foo", action = "store", default = [], dest = "foo")
    argv_0 = ['--foo=baz', '--foo=bar', '--foo=qux']
    args_0 = h_t_t_pie_argument_parser_0.parse_args(argv_0)
    assert args_0.foo == ['baz', 'bar', 'qux']

# Test cases for class KeyValueArgType

# Generated at 2022-06-25 17:55:38.758662
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    # (namespace, return_value) = h_t_t_pie_argument_parser_0.parse_args()
    # return_value_0 = h_t_t_pie_argument_parser_0.parse_args()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:55:51.138682
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from io import StringIO, BytesIO
    from argparse import Namespace

    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.add_argument('-a', '--auth', action='store', default=None)
    h_t_t_pie_argument_parser_0.add_argument('--auth-type', action='store', default=None)
    h_t_t_pie_argument_parser_0.add_argument('--body', action='store', default=None)
    h_t_t_pie_argument_parser_0.add_argument('--body-type', action='store', default=None)

# Generated at 2022-06-25 17:56:00.984462
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    # Testing argument 1 of method parse_args
    # Testing argument argv

    argv_0 = ["--body=1"]
    argv_1 = ["--body=1"]

    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    with pytest.raises(SystemExit):
        h_t_t_pie_argument_parser_0.parse_args(argv_0)
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
    with pytest.raises(SystemExit):
        h_t_t_pie_argument_parser_1.parse_args(argv_1)

    # Testing argument 2 of method parse_args
    # Testing argument namespace

    argv_0 = ["--body=1"]
    namespace_0 = None



# Generated at 2022-06-25 17:56:03.636770
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_1.parse_args()


# Generated at 2022-06-25 17:56:06.705379
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    url = "https://httpbin.org/get"
    self.assertTrue(HTTPieArgumentParser("http", url) == 0)
    

# Generated at 2022-06-25 17:56:15.733739
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from ..core import main as http
    # test for error handling
    #check if raise exception
    try:
        h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
        h_t_t_pie_argument_parser_1.parse_args([''])
        # h_t_t_pie_argument_parser_1.parse_args(["-d"])
        assert sys.exc_info()[1] is None
    except Exception as ex:
        print(ex)
        assert sys.exc_info()[1], ex

# Generated at 2022-06-25 17:57:25.157596
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Create an object of the class under test
    h_t_tpie_argument_parser = HTTPieArgumentParser()

    # Unit test of method parse_args of class HTTPieArgumentParser
    # TODO: Anything missing when testing parse_args?
    h_t_tpie_argument_parser.parse_args()


# Generated at 2022-06-25 17:57:32.640555
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    # Test with argument args of type str
    # Test with argument env of type Environment
    env_0_0 = Environment()
    # Test with argument args_override of type str
    args_override_0_0 = ''
    h_t_t_pie_argument_parser_0.parse_args(env_0_0, args_override_0_0)



# Generated at 2022-06-25 17:57:41.649408
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
    sys.argv = ['http', '--method=POST', '--ignore-stdin', '-v', '-f', 'https://httpie.org/']
    h_t_t_pie_argument_parser_1.parse_args()
    print(h_t_t_pie_argument_parser_1.args)
    #assert h_t_t_pie_argument_parser_1.args.method == 'POST'

if __name__ == '__main__':
    test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-25 17:57:44.338880
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser = HTTPieArgumentParser()
    h_t_t_pie_argument_parser.parse_args()

# Generated at 2022-06-25 17:57:55.547354
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    print ("tests for method parse_args of class HTTPieArgumentParser")
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_2 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_3 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_4 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_5 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_6 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_7 = HTTPieArgumentParser()
    h_t_

# Generated at 2022-06-25 17:58:02.878806
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    str_0 = '--auth'
    str_1 = '--auth-type'
    str_2 = '--body'
    str_3 = '--download'
    str_4 = '--form'
    str_5 = '--headers'
    str_6 = '--ignore-stdin'
    str_7 = '--json'
    str_8 = '--output'
    str_9 = '--pretty'
    str_10 = '--print'
    str_11 = '--query'
    str_12 = '--style'
    str_13 = '--verbose'
    str_14 = '--verify'
    str_15 = '--version'
    str_16 = 'GET'
   

# Generated at 2022-06-25 17:58:15.712324
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.add_argument('-e', '--edit', default=False, action=store_true(), dest='edit', help='Edit request.')
    h_t_t_pie_argument_parser_0.add_argument('-t', '--traceback', default=False, action=store_true(), dest='traceback', help='Print exception traceback should one occur.')
    h_t_t_pie_argument_parser_0.add_argument('--download', default=False, action=store_true(), dest='download', help='Download file.')

# Generated at 2022-06-25 17:58:23.671779
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    self = h_t_t_pie_argument_parser_0
    args = list([])
    args[:] = []
    parse_args = h_t_t_pie_argument_parser_0.parse_args(args)
    self = h_t_t_pie_argument_parser_0
    args = list(['GET'])
    args[:] = ['GET']
    parse_args = h_t_t_pie_argument_parser_0.parse_args(args)


if __name__ == '__main__':
    test_case_0()
    test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-25 17:58:28.892880
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    # TODO: Pass some proper arguments
    args = h_t_t_pie_argument_parser_0.parse_args()


# Generated at 2022-06-25 17:58:38.300986
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    str_arg_0 = "localhost"
    str_arg_1 = "-X"
    str_arg_2 = "POST"
    string_array_arg_0 = "--form"
    string_array_arg_1 = "field_name_0=field_value_0"
    string_array_arg_2 = "field_name_1=field_value_1"
    string_array_arg_3 = "field_name_2=field_value_2"
    string_array_arg_4 = "field_name_3=field_value_3"
    string_array_arg_5 = "field_name_4=field_value_4"

# Generated at 2022-06-25 18:00:47.841220
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # The Python interpreter or a Python program started with the -E option bypasses
    # user-configuration files and only reads sys.prefix/site-python
    Py_IgnoreEnvironmentFlag = 1
    if (getattr(sys, 'flags', None) and Py_IgnoreEnvironmentFlag
            or hasattr(sys, 'real_prefix')):
        return

    test_args = ('http', 'httpbin.org/get')

    # This will raise SystemExit if parse_args() fails.
    parser = HTTPieArgumentParser()
    parser.parse_args(test_args)


# Generated at 2022-06-25 18:00:57.431146
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.add_argument('--arg1', action='store', type='int')
    h_t_t_pie_argument_parser_0.add_argument('--arg2', action='store', type='str')
    h_t_t_pie_argument_parser_0.add_argument('-arg3', action='store', type='int')
    h_t_t_pie_argument_parser_0.add_argument('-abc', '--arg4', action='store', type='int')
    h_t_t_pie_argument_parser_0.add_argument('--arg5', action='store', type='int')
    h_t_t_pie_argument_parser_

# Generated at 2022-06-25 18:01:02.589745
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Input parameters
    args = []

    # Unit test output parameters
    # The output should be processed by calling
    # the other test class methods,
    # in order to check that they are correct.
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_1.parse_args(args)


# Generated at 2022-06-25 18:01:04.647266
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    #self.assertEqual(expected, HTTPieArgumentParser.parse_args(args, namespace))
    assert False # TODO: implement your test here


# Generated at 2022-06-25 18:01:11.363284
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_environment_0 = Environment(None, None, None)
    # Test unless a TypeError exception is raised:
    try:
        h_t_t_pie_argument_parser_0.parse_args(h_t_t_pie_environment_0)
    except TypeError:
        #g_raise_error('TypeError')
        pass

# Generated at 2022-06-25 18:01:23.356984
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Instantiate mock class for global object `plugin_manager`
    plugin_manager_1 = MockPluginManager()

    # Instantiate mock class for global object `httpie_config`
    httpie_config_1 = MockHTTPieConfig()

    # Instantiate mock class for global object `env`
    env_1 = MockEnv()

    # Instantiate mock class for global object `files`
    files_1 = MockFiles()

    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser(
        config=httpie_config_1,
        env=env_1,
        files=files_1
    )

    # Instantiate mock class for global object `merge_dicts`
    merge_dicts_1 = MockMergeDicts()
    # The following call to unmock() is needed if the mock

# Generated at 2022-06-25 18:01:27.327861
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Setup
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()

    # Invoke method
    argument_parser_return_value = h_t_t_pie_argument_parser_0.parse_args()
    assert isinstance(argument_parser_return_value, argparse.Namespace)



# Generated at 2022-06-25 18:01:28.776511
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
	# TODO: write the unit test for HTTPieArgumentParser.parse_args()
    assert true


# Generated at 2022-06-25 18:01:32.891069
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    test_argv = ['https://httpbin.org/get']
    h_t_t_pie_argument_parser_0.parse_args(test_argv)


# Generated at 2022-06-25 18:01:37.490224
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    args = []
    arg_0 = ''
    args.append(arg_0)
    h_t_t_pie_argument_parser_0.parse_args(args)


# Generated at 2022-06-25 18:04:16.896677
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_1 = HTTPieArgumentParser()

# Generated at 2022-06-25 18:04:24.096462
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

    config_dir = '.httpie'
    config_path = os.path.realpath(os.path.join(config_dir, 'config.json'))
    # set config
    config = {
        "default_options": [
            "--form"
        ],
        "short_options": {},
        "implicit_content_type": "json"
    }

    if not os.path.exists(config_dir):
        os.makedirs(config_dir)

    with open(config_path, 'w') as f:
        json.dump(config, f)
    # set config


# Generated at 2022-06-25 18:04:26.372637
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Prepare a command line string to pass to parser
    cmd_line = 'http --help'
    # Get arguments from CommandLineParser
    parser = HTTPieArgumentParser()
    args = parser.parse_args(cmd_line.split())


# Generated at 2022-06-25 18:04:29.251016
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """
    :return:
    """
    # noinspection PyTypeChecker
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    # noinspection PyTypeChecker
    h_t_t_pie_argument_parser_0._parse_args()

# Generated at 2022-06-25 18:04:37.559503
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from test_case import *
    # Test case 0
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.add_argument('-h', '--help', action='help', help='Show this help message and exit.')
    h_t_t_pie_argument_parser_0.add_argument('-v', '--verbose', action='store_true', dest='verbose', default=False, help='Request/response info in debug mode. (Hint: try also --trace/--traceback.)')
    h_t_t_pie_argument_parser_0.add_argument('-V', '--version', action='version', version=__version__, help="Show the app's version number and exit.")
    h_t_t_