

# Generated at 2022-06-25 17:55:08.148576
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.parse_args()

if __name__ == '__main__':
    test_case_0()
    test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-25 17:55:10.756409
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.parse_args(['--traceback', 'http://example.com'])


# Generated at 2022-06-25 17:55:20.265498
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # No error
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    try:
        h_t_t_pie_argument_parser_0.parse_args()
    except Exception as e:
        print(e)
        assert False
    # No error
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
    try:
        h_t_t_pie_argument_parser_1.parse_args(['-H', 'Host:example.com'])
    except Exception as e:
        print(e)
        assert False
    # No error
    h_t_t_pie_argument_parser_2 = HTTPieArgumentParser()

# Generated at 2022-06-25 17:55:31.094484
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-25 17:55:43.360438
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # First test
    httpie_argument_parser_object_0 = HTTPieArgumentParser()
    arg_input_0 = ['--help']
    arg_input_1 = []
    try:
        httpie_argument_parser_object_0.parse_args(arg_input_0, arg_input_1)
    except Exception:
        pass
    # Second test
    httpie_argument_parser_object_1 = HTTPieArgumentParser()
    arg_input_2 = [':?']
    arg_input_3 = ['-v']
    try:
        httpie_argument_parser_object_1.parse_args(arg_input_2, arg_input_3)
    except Exception:
        pass
    # Third test
    httpie_argument_parser_object_2 = HTTPieArgumentParser()


# Generated at 2022-06-25 17:55:46.330472
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.parse_args()


# Generated at 2022-06-25 17:55:53.174816
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    # Setup test
    test_HTTPieArgumentParser_parse_args_0 = HTTPieArgumentParser()

    # Invoke method
    result_test_HTTPieArgumentParser_parse_args_0 = test_HTTPieArgumentParser_parse_args_0.parse_args()

    # Verify test
    assert isinstance(result_test_HTTPieArgumentParser_parse_args_0, argparse.Namespace)


# Generated at 2022-06-25 17:56:02.260309
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    # test for 0 arguments
    try:
        new_argv = [sys.argv[0]]
        h_t_t_pie_argument_parser_0.parse_args(new_argv)
    except SystemExit:
        raise AssertionError('too few arguments')
    except:
        pass
    # test for 1 argument
    try:
        new_argv = [sys.argv[0], 'httpie']
        h_t_t_pie_argument_parser_0.parse_args(new_argv)
    except SystemExit:
        raise AssertionError('too few arguments')
    except:
        pass
    # test for 2 argument

# Generated at 2022-06-25 17:56:07.293439
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    # Construct arguments
    args = ['--json', "http://www.google.com"]

    # Obtain object
    httpie_argument_parser = HTTPieArgumentParser()

    # Invoke method
    httpie_argument_parser.parse_args(args)

    return


# Generated at 2022-06-25 17:56:18.527561
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Instance of class HTTPieArgumentParser
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()

    # Test call to method parse_args of class HTTPieArgumentParser with args=([],), and kwargs={'check_file_exists': False}, actual result is None
    assert h_t_t_pie_argument_parser_0.parse_args([]) == None
    # Test call to method parse_args of class HTTPieArgumentParser with args=(['www.baidu.com', '--json', '--json=true'],), and kwargs={'check_file_exists': False}, actual result is None

# Generated at 2022-06-25 17:57:21.097124
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    parsed_args = h_t_t_pie_argument_parser_0.parse_args()
    # For now, just verify we can get here without crashing.
    print("Successfully parsed args")


# Generated at 2022-06-25 17:57:33.533271
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser(args=None)
    h_t_t_pie_argument_parser_1.parse_args()
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser(args=None)
    args = ["-H","Content-Type:application/json","https://httpbin.org/post","name=mehran"]
    h_t_t_pie_argument_parser_1.parse_args(args)
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser(args=None)
    args = ['https://httpbin.org/post']
    h_t_t_pie_argument_parser_

# Generated at 2022-06-25 17:57:37.096700
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    # Test exception raised when called with argument "None"
    with raises(TypeError):
        h_t_t_pie_argument_parser_0.parse_args("None")


# Generated at 2022-06-25 17:57:42.209049
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """
    Check whether parse_args return an object with expected attributes

    """
    h_ap = HTTPieArgumentParser()
    h_ap.parse_args("http://localhost:8080".split())

    assert h_ap.args.url == "http://localhost:8080"



# Generated at 2022-06-25 17:57:49.563943
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser(cli_args=['https://httpbin.org/get'])
    args = parser.parse_args(['https://httpbin.org/get'])
    # If you called parse_args() with a non-zero exit_on_error, don’t use the return value
#    assert parser.exit_code == 0

if __name__=='__main__':
    test_case_0()

# Generated at 2022-06-25 17:57:53.420598
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    argv_0 = ['--colors', 'always']
    h_t_t_pie_argument_parser_0.parse_args(argv=argv_0)


# Generated at 2022-06-25 17:57:55.849871
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    print("Test: HTTPieArgumentParser.parse_args")

    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()


# Generated at 2022-06-25 17:57:58.538680
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.parse_args()


# Generated at 2022-06-25 17:57:59.674532
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    HTTPieArgumentParser()

# Generated at 2022-06-25 17:58:06.777689
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # httpie-0.9.3/httpie/cli.py
    # def parse_args(self, args=None, namespace=None):
    test_case_0()
    
    # httpie-0.9.3/httpie/cli.py
    # def parse_args(self, args=None, namespace=None):
    h_t_t_pie_argument_parser = HTTPieArgumentParser()
    h_t_t_pie_argument_parser.parse_args()

    return


# Generated at 2022-06-25 18:00:06.989368
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-25 18:00:10.443811
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    context_0 = ArgumentParserContext()
    httpie_args_0 = h_t_t_pie_argument_parser_0._parse_args(context_0)


# Generated at 2022-06-25 18:00:13.639177
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.parse_args()

# Generated at 2022-06-25 18:00:16.877140
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
    print("Testing parse_args() method.")
    h_t_t_pie_argument_parser_1.parse_args()

# Test

# Generated at 2022-06-25 18:00:20.149323
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    args = []
    args = h_t_t_pie_argument_parser_0.parse_args(args)
    assert args is not None


# Generated at 2022-06-25 18:00:26.288685
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from io import StringIO
    from unittest.mock import MagicMock, create_autospec
    request_item_args0 = create_autospec(RequestItemArgs)
    request_item_args0.sep = SEPARATOR_GROUP_ALL_ITEMS
    SEPARATOR_GROUP_ALL_ITEMS0 = SEPARATOR_DEFAULT
    request_item_args0.orig = SEPARATOR_GROUP_ALL_ITEMS0
    class_value0 = create_autospec(KeyValueArgType, instance=True)
    class_value0.default_sep = SEPARATOR_GROUP_ALL_ITEMS
    request_item_args0.key_value_arg_type = class_value0
    request_item_args0.data = SEPARATOR_GROUP_ALL_ITEMS
    SEPARATOR

# Generated at 2022-06-25 18:00:34.533372
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser_0 = HTTPieArgumentParser()
    args_0 = parser_0.parse_args(['--form', 'http://127.0.0.1:5000/get'])
    assert args_0.verbose
    assert args_0.headers
    assert args_0.traceback
    assert args_0.output_options
    assert args_0.output_options_history
    assert args_0.offline
    assert args_0.download
    assert args_0.download_resume
    assert args_0.timeout


# Generated at 2022-06-25 18:00:41.691565
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_2 = HTTPieArgumentParser()
    h_t_t_pie_environment_1 = HTTPieEnvironment()
    h_t_t_pie_argument_parser_2.env = h_t_t_pie_environment_1
    h_t_t_pie_argument_parser_2.args = arguments.Args()
    h_t_t_pie_argument_parser_2.args.output_file = None
    h_t_t_pie_argument_parser_2.args.output_options = None
    h_t_t_pie_argument_parser_2.args.output_options_history = None
    h_t_t_pie_argument_parser_2.args.output_file_specified = False
    h_t_t_pie_argument_parser

# Generated at 2022-06-25 18:00:42.920021
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    test_case_0()


# Generated at 2022-06-25 18:00:49.761134
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    # Test for function 'parse_args'
#     args = h_t_t_pie_argument_parser_0.parse_args()
    return

if __name__ == "__main__":
    test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-25 18:03:13.848760
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_0 = HTTPieArgumentParser()
    assert_equal(None, httpie_argument_parser_0._parse_args([]))


# Generated at 2022-06-25 18:03:24.520480
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Case 0
    command_0 = ''
    namespace_0 = h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    args_0 = command_0.split()
    namespace_0 = h_t_t_pie_argument_parser_0.parse_args(args_0)
    assert namespace_0.config_dir == '~/.config/httpie'

# Generated at 2022-06-25 18:03:34.522777
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Setup
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
    first_argv_0 = ['--download']
    second_argv_0 = ['--download', '--download-resume']
    third_argv_0 = []
    fourth_argv_0 = ['--download', '--download-resume']
    fifth_argv_0 = ['--download']

    # Invocation
    (first_ns_0, first_args_0) = h_t_t_pie_argument_parser_1.parse_args(first_argv_0)
    (second_ns_0, second_args_0) = h_t_t_pie_argument_parser_1.parse_args(second_argv_0)

# Generated at 2022-06-25 18:03:41.252356
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie.config import DEFAULT_CONFIG_DIR

    # Setup

# Generated at 2022-06-25 18:03:52.136286
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    # Test repeated error messages
    try:
        h_t_t_pie_argument_parser_0.parse_args(['-G'])
        assert False
    except ValueError:
        pass
    try:
        h_t_t_pie_argument_parser_0.parse_args(['-G'])
        assert False
    except ValueError:
        pass
    try:
        h_t_t_pie_argument_parser_0.parse_args(['-G'])
        assert False
    except ValueError:
        pass
    try:
        h_t_t_pie_argument_parser_0.parse_args(['-G'])
        assert False
    except ValueError:
        pass
    #

# Generated at 2022-06-25 18:03:54.824444
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = ["-h"]
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_1.parse_args(args)


# Generated at 2022-06-25 18:04:03.396588
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    # Command-line options.
    argv = 'http --auth foo:bar --body "" --form key:val --ignore-stdin --json false --max-headers 123 --max-redirs 123 --max-url-len 123 --method POST --no-index-paths --no-session --output-file "" --no-verify --output-dir "" --output "" --print hH --prettify all --querystring key:val --timeout 5 --traceback --follow --verify "" --download --download-resume --form-string key:val --headers key:val --output-options "" --body-format json --config-file "" --download-as "" --max-content-length 12345 --upgrade --session "" http://httpbin.org/get'
    #

# Generated at 2022-06-25 18:04:12.232959
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    global ascii_art_0

# Generated at 2022-06-25 18:04:15.020629
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()

    # TODO: Write unit test for method parse_args of class HTTPieArgumentParser


# Generated at 2022-06-25 18:04:19.077968
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    w_t_m_h_t_t_pie_argument_parser = HTTPieArgumentParser()
    w_t_m_h_t_t_pie_argument_parser_args = w_t_m_h_t_t_pie_argument_parser.parse_args()
