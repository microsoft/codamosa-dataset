

# Generated at 2022-06-25 17:55:11.383502
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = ['--auth-type=basic', '--pretty=all', 'http://httpbin.org/get']

    h_t_t_pie_argument_parser_assert_0 = HTTPieArgumentParser()
    try:
        h_t_t_pie_argument_parser_assert_1 = h_t_t_pie_argument_parser_assert_0.parse_args(args)
    except ValueError as error:
        print(error)


# Generated at 2022-06-25 17:55:14.333122
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    assert h_t_t_pie_argument_parser_0.parse_args() == (None, None)


# Generated at 2022-06-25 17:55:17.381500
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # FIXME: no args and no exception for now
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.parse_args('')



# Generated at 2022-06-25 17:55:19.831592
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_1.parse_args()

# Generated at 2022-06-25 17:55:30.743740
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Instantiate the parser.
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0._parser = test_argparse._ArgumentParser_0
    h_t_t_pie_argument_parser_0._parser._actions = []
    h_t_t_pie_argument_parser_0._parser._actions.append(test_argparse._Action_0())
    h_t_t_pie_argument_parser_0._parser._actions.append(test_argparse._Action_1())
    h_t_t_pie_argument_parser_0._parser._actions.append(test_argparse._Action_2())

# Generated at 2022-06-25 17:55:34.306742
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # INIT
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()

    # INST
    parsing_result = h_t_t_pie_argument_parser_0.parse_args([])

    # CHECK
    assert isinstance(parsing_result.version, bool) == True



# Generated at 2022-06-25 17:55:46.018801
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test case with argument "args=None"
    try:
        test_case_0()
    except Exception as e:
        print(e)
        print("FAILED test_case_0 of test_HTTPieArgumentParser_parse_args")
        assert False
    # Test case with argument "args=[]"
    try:
        HTTPieArgumentParser().parse_args([])
    except Exception as e:
        print(e)
        print("FAILED test_case_1 of test_HTTPieArgumentParser_parse_args")
        assert False
    # Test case with argument "args=['prog']"
    try:
        HTTPieArgumentParser().parse_args(['prog'])
    except Exception as e:
        print(e)

# Generated at 2022-06-25 17:55:53.366362
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    # Test for method parse_args of class HTTPieArgumentParser
    try:
        test_case_0()
        assert True
    except TypeError as err:
        assert False, str(err)
    except ValueError as err:
        assert False, str(err)
    except Exception as err:
        assert False, str(err)
    else:
        assert True


# Generated at 2022-06-25 17:55:54.471867
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    pass


# Generated at 2022-06-25 17:56:02.968015
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    print("*"*10, 'test_HTTPieArgumentParser_parse_args', '*'*10)
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    sys.argv = ['http', '--debug', 'http://httpbin.org/get']
    args = h_t_t_pie_argument_parser_0.parse_args()
    assert args.debug
    assert args.url == 'http://httpbin.org/get'
    assert args.method == 'GET'
    assert args.headers == {}
    assert args.data == {}
    assert args.files == {}
    assert args.params == {}
    assert not args.explain
    assert not args.stream
    assert not args.download
    assert not args.download_resume
    assert args.verbose

# Generated at 2022-06-25 17:56:39.881401
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_parse_args_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_parse_args_0.add_argument('--verbose', '-v', action='store_true', help="Be verbose.")
    h_t_t_pie_argument_parser_parse_args_0.add_argument('--force-colors', '-fc', action='store_true', help="Forcibly use colors in terminal output.")
    h_t_t_pie_argument_parser_parse_args_0.add_argument('--no-scheme-specific-defaults', action='store_true', help="Don't use scheme-specific default options.")

# Generated at 2022-06-25 17:56:46.013995
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_0 = HTTPieArgumentParser(env=None,
                                                    stdin=None,
                                                    stdout=None,
                                                    stderr=None)
    sys.argv = ['argv[0]', 'argv[1]']
    assert_raises_regex(
        SystemExit,
        r'2',
        httpie_argument_parser_0.parse_args
    )

test_case_0()
test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-25 17:56:51.810491
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import sys
    arguments = sys.argv
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser(prog='http')
    h_t_t_pie_argument_parser_0.add_argument(argument_0, argument_1='argument_1')
    h_t_t_pie_argument_parser_0.parse_args(arguments)


# Generated at 2022-06-25 17:56:58.567709
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    HTTPieArgumentParser.parse_args(
        args=['--version'],
        parser_class=HTTPieArgumentParser,
        stdout=StringIO(),
        env=Environment(),
        with_plugins=False,
        resp_status_handler=None,
        stdin=StringIO()
    )


# Generated at 2022-06-25 17:57:00.145970
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    test_HTTPieArgumentParser_parse_args_0()


# Generated at 2022-06-25 17:57:03.328867
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    try:
        raise RuntimeError('Test Failed')
    except:
        tb = traceback.format_exc()
        parser.error(tb)

# Generated at 2022-06-25 17:57:08.415118
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_parse_args_0 = HTTPieArgumentParser()
    rest = ['a', 'b']
    httpie_argument_parser_parse_args_args_0 = httpie_argument_parser_parse_args_0.parse_args(rest)

if __name__ == '__main__':
    #test_case_0()
    test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-25 17:57:19.884350
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    test_parser = HTTPieArgumentParser(description="HTTPie", allow_interspersed_args=False, prog="http", usage=None, add_help=True, formatter_class=HTTPieHelpFormatter)
    parser_args_0 = [[]]
    test_parser.add_argument("-v", "--verbose", dest="verbose", action="store_true", help="Operate verbosely.", default=[False])
    test_parser.add_argument("-j", "--json", dest="json", action="store_true", help="Produce JSON output.", default=[False])

# Generated at 2022-06-25 17:57:27.042902
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    sys.argv = ["http", "get", "http://httpbin.org/get"]
    arguments = h_t_t_pie_argument_parser_0.parse_args()
    assert arguments.url == "http://httpbin.org/get"
    assert arguments.method == "GET"


# Generated at 2022-06-25 17:57:32.556983
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser = HTTPieArgumentParser()
    test_case_0()
    test_HTTPieHelpFormatter_format_option_strings()
    test_case_2()
    test_case_1()
    return h_t_t_pie_argument_parser.parse_args()


# Generated at 2022-06-25 17:58:40.930425
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import os
    import sys

    parser_0 = HTTPieArgumentParser()
    parser_0.parse_args([])
    parser_0.parse_args(['--verbose', 'http://127.0.0.1:5000/test_1', 'key1=val1', 'key2=val2'])
    parser_0.parse_args(['--form', 'http://127.0.0.1:5000/test_2', 'key3=val3', 'key4=val4'])
    parser_0.parse_args(['--debug', 'http://127.0.0.1:5000/test_1', 'key1=val1', 'key2=val2'])

# Generated at 2022-06-25 17:58:45.801814
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser(env=os.environ, stdin_isatty=True, stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr)
    h_t_t_pie_argument_parser_0.parse_args()


# Generated at 2022-06-25 17:58:54.588955
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args_0 = ['--json', '-j', '--print=B', '--print=H', '--body=form', '--headers', '--ignore-stdin', '--style=Solarized', '-o', '--output', '-i', '--include', '--timeout', '--verify', '--auth', '-a', '--auth-type', '--proxy']
    args_1 = ['-v', '--verbose']
    args_2 = ['--download', '--download', '--download']
    args_3 = ['--verbose', '--headers', '--download', '--download', '--form', '--json', '--print=H', '--print=B']

# Generated at 2022-06-25 17:58:57.398943
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args_0 = ['http', '--help']
    env_0 = Environment()
    result = HTTPieArgumentParser(env_0).parse_args(args_0)
    assert result == 0


# Generated at 2022-06-25 17:58:59.259785
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    #self.assertEqual(self.tested.HTTPieArgumentParser.parse_args(), 0)
    pass

# Generated at 2022-06-25 17:59:04.114039
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.add_argument('--stuff')
    h_t_t_pie_argument_parser_0.parse_args(['--stuff', 'value'])


# Generated at 2022-06-25 17:59:07.792948
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    # ERROR: TypeError: parse_args() missing 2 required positional arguments: 'args' and 'env'
    #assert False


# Generated at 2022-06-25 17:59:19.597010
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_parser_0.add_argument('--method')
    h_t_t_pie_parser_0.add_argument('--auth')
    h_t_t_pie_parser_0.add_argument('--download')
    h_t_t_pie_parser_0.add_argument('--output_file')
    h_t_t_pie_parser_0.add_argument('--ignore_stdin')
    h_t_t_pie_parser_0.add_argument('--help')
    h_t_t_pie_parser_0.add_argument('--traceback')

# Generated at 2022-06-25 17:59:28.489955
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    my_HTTPieArgumentParser_0 = HTTPieArgumentParser()
    my_HTTPieArgumentParser_0.parse_args()
    my_HTTPieArgumentParser_0.parse_args(argv=['--version'])
    my_HTTPieArgumentParser_0.parse_args(argv=['--prettify', 'all'])
    my_HTTPieArgumentParser_0.parse_args(argv=['--verbose'])
    my_HTTPieArgumentParser_0.parse_args(argv=['--traceback'])
    my_HTTPieArgumentParser_0.parse_args(argv=['--follow'])
    my_HTTPieArgumentParser_0.parse_args(argv=['--max-redirs', '3'])
    my_HTTPieArgumentParser

# Generated at 2022-06-25 17:59:36.030088
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_0 = HTTPieArgumentParser()

    # Test if no arguments or options were provided
    httpie_argument_parser_0.parse_args(args=[])
    httpie_argument_parser_0.parse_args(args=[], namespace=argparse.Namespace())

    # Test if an argument and an option were provided
    httpie_argument_parser_0.parse_args(args=['-h'], namespace=argparse.Namespace())


# Generated at 2022-06-25 18:01:53.174578
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = ['/tmp/httpie_test.py', 'http://httpbin.org/get?a=1&b=2']
    # Argument 1: command line argument list, argument 2: executable name
    args_dict = HTTPieArgumentParser().parse_args(args)
    assert args == args_dict.args
    assert args_dict.args_bytes == b'/tmp/httpie_test.py http://httpbin.org/get?a=1&b=2'
    assert args_dict.args_bytes == b'/tmp/httpie_test.py http://httpbin.org/get?a=1&b=2'
    assert args == ['http://httpbin.org/get?a=1&b=2']
    assert args_dict.env.colors == 256

# Generated at 2022-06-25 18:02:05.154028
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Try to parse arguments with HTTPieArgumentParser
    h_t_t_pie_args_parser_1 = HTTPieArgumentParser()
    try:
        h_t_t_pie_args_1 = h_t_t_pie_args_parser_1.parse_args()
    except KeyboardInterrupt:
        print("Keyboard interrupted")
        return
    h_t_t_pie_args_parser_1.validate_args(h_t_t_pie_args_1)
    h_t_t_pie_args_1.__dict__
    h_t_t_pie_args_parser_1.args = h_t_t_pie_args_1
    h_t_t_pie_args_parser_1.__dict__
    h_t_t_pie_args_parser

# Generated at 2022-06-25 18:02:09.521077
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    try:
        h_t_t_pie_argument_parser_0.parse_args(["-?"])
    except SystemExit as e:
        if (e.code == 0):
            pass  # Expected
    except Exception as inst:
        print(type(inst))  # the exception instance
        print(inst.args)  # arguments stored in .args
        print(inst)
        assert False


# Generated at 2022-06-25 18:02:16.442146
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    a_r_g_parser_0 = HTTPieArgumentParser()
    a_r_g_parser_0.add_argument('--header',dest = 'headers',action = 'append',default = [],type = parse_header,metavar = 'HEADER',help = 'Header to include in the request (may be repeated).')
    a_r_g_parser_0.add_argument('--body',dest = 'data',type = str,metavar = 'BODY',help = 'Request body data (POST/PUT).')
    a_r_g_parser_0.add_argument('--form','-f',dest = 'form',action = 'store_true',help = 'Send data as form fields instead of JSON or external files (for POST, PATCH, and PUT).')

# Generated at 2022-06-25 18:02:20.032161
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    # assert parse_result.args.url == 'https://httpbin.org/get'
    # assert parse_result.args.output == '<stdout>'
    # assert parse_result.args.pretty == 'all'
    # assert parse_result.args.download == False
    # assert parse_result.args.ignore_stdin == False


# Generated at 2022-06-25 18:02:32.117833
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_0 = HTTPieArgumentParser()
    sys.argv = []
    httpie_argument_parser_0.parse_args()
    sys.argv = ['-h']
    httpie_argument_parser_0.parse_args()
    sys.argv = ['-v']
    httpie_argument_parser_0.parse_args()
    sys.argv = ['--headers']
    httpie_argument_parser_0.parse_args()
    sys.argv = ['--headers', '--body']
    httpie_argument_parser_0.parse_args()
    sys.argv = ['--json', '--body']
    httpie_argument_parser_0.parse_args()
    sys.argv = ['--verbose', '--body']
    httpie_argument

# Generated at 2022-06-25 18:02:39.482628
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_0 = HTTPieArgumentParser()
    httpie_help_formatter_0 = HTTPieHelpFormatter()
    httpie_argument_parser_0.formatter_class = httpie_help_formatter_0
    h_t_t_pie_arg_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_arg_parser_0.formatter_class = HTTPieHelpFormatter()
    args = h_t_t_pie_arg_parser_0.parse_args(
        ['--output', '', '--all', '--umask', '066', '--validate-certs', '--ignore-stdin']
    )

# Generated at 2022-06-25 18:02:47.383911
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test data
    request_items = ''
    verbose = True
    output_file = None
    headers = None
    form = True
    tweak = None
    stream = None
    output_options = ''
    output_options_history = None
    config_path = ''
    env = None
    appname = 'http'
    version = '0.9.9'
    colors = None
    style = None
    debug = False
    traceback = False
    output_format = None
    options = None
    download = None
    continue_entry = None
    prefer_curl = None
    verify = False
    proxy = None
    cert = None
    json = False
    pretty = None
    print_body = None
    implicit_content_type = None
    output_file_specified = False
    auth = None

# Generated at 2022-06-25 18:02:53.818141
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_0 = HTTPieArgumentParser()
    # TEST CASE 0
    try:
        test_case_0()
    except Exception:
        print("Exception in test case 0")
    else:
        print("Test case 0 passed")
    # TEST CASE 1
    # TODO: Create test case 1
    # TEST CASE 2
    # TODO: Create test case 2
    # TEST CASE 3
    # TODO: Create test case 3
    # TEST CASE 4
    # TODO: Create test case 4

test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-25 18:03:01.682881
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    parser = HTTPieArgumentParser()
    parser.add_argument("url")
    parser.add_argument("auth")
    parser.add_argument("--download")
    parser.add_argument("--form")
    parser.add_argument("-c", "--cookie")
    args = parser.parse_args("www.baidu.com --download --form")
    print(args)

if __name__ == '__main__':
    test_HTTPieArgumentParser_parse_args()