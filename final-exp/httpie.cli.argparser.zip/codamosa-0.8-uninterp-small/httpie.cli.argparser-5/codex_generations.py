

# Generated at 2022-06-25 17:55:12.277081
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_2 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_3 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_4 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_5 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_6 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_7 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_8 = HTTPieArgumentParser()
   

# Generated at 2022-06-25 17:55:14.217758
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.parse_args(argv=['http', '--help'], env=None)


# Generated at 2022-06-25 17:55:16.215675
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    test_case_0()

if __name__ == '__main__':
    test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-25 17:55:18.861474
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.parse_args()


# Generated at 2022-06-25 17:55:21.488337
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_arg_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_arg_parser_0.parse_args([])


# Generated at 2022-06-25 17:55:27.755630
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    root = os.path.abspath(os.path.join(os.path.dirname(__file__)))
    test_env_path = os.path.join('tests', 'test_env')
    env = Environment(colors=256, config_dir=test_env_path)
    parser = HTTPieArgumentParser(env)
    test_case_0()
    test_case_0()


# Generated at 2022-06-25 17:55:35.670438
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    sys_exit = mock.Mock()
    h_t_t_pie_argument_parser_0.exit = sys_exit
    h_t_t_pie_argument_parser_0.error = sys_exit

    with pytest.raises(SystemExit):
        h_t_t_pie_argument_parser_0.parse_args(['--help'])

    with pytest.raises(SystemExit):
        h_t_t_pie_argument_parser_0.parse_args(['-h'])

    # This error is raised while HTTPieArgumentParser._setup_standard_streams
    # is executed
    with pytest.raises(SystemExit):
        h_t_t_pie_argument_parser_

# Generated at 2022-06-25 17:55:47.680672
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-25 17:55:51.138444
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    argv = []
    httpie_argparser_0 = HTTPieArgumentParser()
    httpie_argparser_0.parse_args(argv)


# Generated at 2022-06-25 17:55:54.367030
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import sys
    sys.argv = ['http', 'https://httpbin.org/get']
    args = HTTPieArgumentParser().parse_args()
    assert args.url=="https://httpbin.org/get"

# Generated at 2022-06-25 17:56:41.719378
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_0 = HTTPieArgumentParser(prog = "httpie_0")
    httpie_argument_parser_1 = HTTPieArgumentParser(prog = "httpie_1")
    httpie_argument_parser_2 = HTTPieArgumentParser()
    # help='Specify HTTP method.'
    httpie_argument_parser_2.add_argument('-m', '--method',
                                          help = 'Specify HTTP method.')
    # Different instances of class HTTPieArgumentParser with different parameters
    httpie_argument_parser_0_object_instances = [httpie_argument_parser_0, httpie_argument_parser_1, httpie_argument_parser_2]

# Generated at 2022-06-25 17:56:48.811678
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    test_data = [
    """
     HTTPie
     ======
     :version:
     """
    ,
    """
     HTTPie
     ======
     :version:
     :author:
     """
    ,
    """
     HTTPie
     ======
     :author:
     """
    ]

    exception_thrown = False
    for test_data_item in test_data:
        try:
            parser = HTTPieArgumentParser()
            args = parser.parse_args(test_data_item.split(' '))
        except Exception as e:
            exception_thrown = True
            print(e)
        else:
            if exception_thrown:
                raise Exception("Parsing completed successfully when an exception was expected to be raised")

# Generated at 2022-06-25 17:57:02.478404
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser_0 = HTTPieArgumentParser()
    h_t_t_pie_help_formatter_0 = HTTPieHelpFormatter()
    h_t_t_pie_help_formatter_0.max_help_position = 45
    parser_0.formatter = h_t_t_pie_help_formatter_0
    parser_0.parse_args(['--help'])
    parser_0.parse_args(['-h'])
    parser_0.parse_args(['--version'])
    parser_0.parse_args(['-v'])
    parser_0.parse_args(['--debug'])
    parser_0.parse_args(['--traceback'])
    parser_0.parse_args(['--output', 'a', '--download'])
    parser_0

# Generated at 2022-06-25 17:57:08.450524
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie import __version__

    main = HTTPieArgumentParser(add_help=False)
    main._add_default_options()
    # Unit test for calling method parse_args of class HTTPieArgumentParser
    def test_case_0():
        arg_line = ['-v']
        arg_args = main.parse_args(arg_line)
        print(arg_args)

    def test_case_1():
        arg_line = ['--json', '{}']
        arg_args = main.parse_args(arg_line)
        print(arg_args)

    def test_case_2():
        arg_line = []
        arg_args = main.parse_args(arg_line)
        print(arg_args)


# Generated at 2022-06-25 17:57:12.695582
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    http_ie_argument_parser_0 = HTTPieArgumentParser()
    test_http_ie_argument_parser_parse_args_0 = '--print=HdJ --headers'
    http_ie_argument_parser_0.parse_args(test_http_ie_argument_parser_parse_args_0)


# Generated at 2022-06-25 17:57:18.166321
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Create an instance of class HTTPieArgumentParser
    httpie_argument_parser_0 = HTTPieArgumentParser()
    # Call method parse_args of httpie_argument_parser_0
    httpie_argument_parser_0_args = httpie_argument_parser_0.parse_args()


# Generated at 2022-06-25 17:57:28.582273
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()

    try:
        h_t_t_pie_argument_parser_0.parse_args(sys.argv)
    except SystemExit as e:
        assert(e.code == 0)
        print("Unit test for HTTPieArgumentParser_parse_args completed successfully")
    except Exception as e:
        print("Unable to complete unit test for HTTPieArgumentParser_parse_args due to following exception: " + str(e))
    finally:
        h_t_t_pie_argument_parser_0.exit(0)



# Generated at 2022-06-25 17:57:37.825366
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    argv_0 = ("httpie", "POST", "http://httpbin.org/post", "Content-Type:application/json", "{'hello': 'world'}")
    args_0 = h_t_t_pie_argument_parser_0.parse_args(argv_0[1:])

    assert type(args_0) == argparse.Namespace
    assert args_0.headers == [('Content-Type', 'application/json')]
    assert args_0.data == "{'hello': 'world'}"
    assert args_0.url == 'http://httpbin.org/post'
    assert args_0.method == 'POST'


# Generated at 2022-06-25 17:57:50.031435
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Instantiating the HTTPieArgumentParser object
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser(
        env=cli.environment,
        formatter_class=HTTPieHelpFormatter
    )

    # Instantiating the HTTPieHelpFormatter object
    h_t_t_pie_help_formatter_0 = HTTPieHelpFormatter()

    # Instantiating the HTTPieHelpFormatter object
    h_t_t_pie_help_formatter_1 = HTTPieHelpFormatter()

    # Call to parse_args of HTTPieArgumentParser object
    try:
        h_t_t_pie_argument_parser_0.parse_args()
    except SystemExit as e:
        if e.code == 0:
            pass
        else:
            raise e

#

# Generated at 2022-06-25 17:57:52.789371
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser_0 = HTTPieArgumentParser
    args = ['http', 'www.example.com']
    parser_0.parse_args(args)


# Generated at 2022-06-25 17:58:31.414921
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Arrange

    parser_0 = HTTPieArgumentParser()
    # Act
    parser_0.parse_args()
    # Assert



# Generated at 2022-06-25 17:58:39.967965
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    test_argv_0 = ["http", "example.org"]
    test_parser_0 = HTTPieArgumentParser()
    # test_env_0 = Environment()
    test_env_0 = Environment(colors=256)
    test_env_0.is_windows = False
    test_env_0.stdin = sys.stdin
    test_env_0.stdin_isatty = sys.stdin.isatty()
    test_env_0.stdout_isatty = sys.stdout.isatty()
    test_env_0.stdout = sys.stdout
    test_env_0.stderr_isatty = sys.stderr.isatty()
    test_env_0.stderr = sys.stderr
    test_env_0.__

# Generated at 2022-06-25 17:58:42.819499
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.parse_args()

test_case_0()
test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-25 17:58:51.234222
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    parser = h_t_t_pie_argument_parser_0
    args = parser.parse_args([])
    args = parser.parse_args(['--version'])
    args = parser.parse_args(['--version'])
    args = parser.parse_args([])
    args = parser.parse_args(['--version'])
    args = parser.parse_args([])
    args = parser.parse_args(['--version'])
    args = parser.parse_args([])
    args = parser.parse_args(['--version'])
    args = parser.parse_args(['--version'])
    args = parser.parse_args(['--version'])

# Generated at 2022-06-25 17:58:58.012112
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    print("\nTest of parse_args method of HTTPieArgumentParser\n")

    httpie_argument_parser_0 = HTTPieArgumentParser()

    try:
        httpie_argument_parser_1 = HTTPieArgumentParser(sys.argv).parse_args()
        print("\nName of arguments is: " + str(httpie_argument_parser_1))
    except:
        print("\nUnable to parse arguments\n")

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 17:59:08.915495
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_0 = HTTPieArgumentParser(description=None, epilog=None, parents=[], usage=None, add_help=True,
                                                    formatter_class=None, prefix_chars=None, fromfile_prefix_chars=None,
                                                    argument_default=None, conflict_handler=None, add_version=None,
                                                    allow_abbrev=True)

    httpie_argument_parser_0.parse_args()

    httpie_argument_parser_0.parse_args(['--compress', '--download', '--download-resume', '--download-resume', '--download-resume', '--download-resume', '-o', 'FILE'])


if __name__ == '__main__':
    test_HTTPieArgumentParser_parse

# Generated at 2022-06-25 17:59:13.296445
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    argv = ['http', '--help']
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.parse_args(argv)


# Generated at 2022-06-25 17:59:15.594584
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_0 = HTTPieArgumentParser()
    assert True # TODO: may fail


# Generated at 2022-06-25 17:59:25.499629
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    # Test Case 0
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    print(h_t_t_pie_argument_parser_0)
    # h_t_t_pie_argument_parser_0.parse_args(["--debug"])
    h_t_t_pie_argument_parser_0.error("test")
    h_t_t_pie_argument_parser_0.error("test")
    h_t_t_pie_argument_parser_0.error("test")
    h_t_t_pie_argument_parser_0.add_argument("--debug", nargs=0)
    h_t_t_pie_argument_parser_0.parse_args(["--debug"])

# Generated at 2022-06-25 17:59:35.616927
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_0 = HTTPieArgumentParser()
    help_0 = "test help"
    httpie_argument_parser_0._test_help_output = help_0
    assert httpie_argument_parser_0.help_str == help_0, f'Expected help_0, but got: {httpie_argument_parser_0.help_str}'
    # No exception
    httpie_argument_parser_0.parse_args([])


# Generated at 2022-06-25 18:00:21.461152
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from . import httpie
    from httpie.core import main
    from httpie.compat import str
    from httpie.plugins import plugin_manager
    from httpie.plugins import builtin
    from httpie import __version__
    from httpie.input import ParseError
    from click import ClickException

    # test_case_000
    h_t_t_pie_arg_parser_0 = HTTPieArgumentParser()
    try:
        h_t_t_pie_arg_parser_0.parse_args()
    except SystemExit as e:
        assert e.args[0] == 2

    # test_case_001
    h_t_t_pie_arg_parser_1 = HTTPieArgumentParser()

# Generated at 2022-06-25 18:00:34.013963
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-25 18:00:37.090873
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    env = MockEnvironment(stdout_isatty=True,
                          stdin_isatty=True,
                          is_windows=False)
    httpie = HTTPie(env=env)
    HTTPieArgumentParser.parse_args(httpie, [])


# Generated at 2022-06-25 18:00:39.760624
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    try:
        h_t_t_pie_argument_parser_0.parse_args(argv=['--help'])
    except SystemExit:
        pass


# Generated at 2022-06-25 18:00:44.207559
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    assert h_t_t_pie_argument_parser_0.exception is None
    assert h_t_t_pie_argument_parser_0.error is None
    h_t_t_pie_argument_parser_0.add_argument('str')
    h_t_t_pie_argument_parser_0.parse_args()
    assert h_t_t_pie_argument_parser_0.exception is None
    assert h_t_t_pie_argument_parser_0.error is None


# Generated at 2022-06-25 18:00:50.447636
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.parse_args()

if __name__ == '__main__':
    test_case_0()
    test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-25 18:00:55.078211
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import tempfile
    #http = HTTPieArgumentParser()
    with tempfile.NamedTemporaryFile() as f:
        http = HTTPieArgumentParser(env=Environment(stdin=f, stdin_isatty=True))
        args = http.parse_args(['--json', 'http://httpbin.org'])
        args.method
        args.output_options
        args.output_options_history
        args.prettify
        #args.help
        args.url
        args.auth_type
        args.headers
        args.data
        args.form
        args.files
        args.params
        args.ignore_stdin
        args.output_file
        args.download
        args.download_resume
        args.style
        args.style_type
        args.style_theme

# Generated at 2022-06-25 18:01:02.252614
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_0 = HTTPieArgumentParser(
        # Formatter for printing help messages
        formatter_class = HTTPieHelpFormatter,
        # If True, print all error messages directly to sterr.
        ignore_unknown_options = False,
        # Add_help option
        add_help = False,
        # Argument name
        prog = "http"
    )
    sys.argv = ["http --method POST 'https://httpbin.org/get' name=httpie"]
    httpie_argument_parser_0.parse_args()


# Generated at 2022-06-25 18:01:04.673708
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # FIXME: add unit tests
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_1.parse_args()


# Generated at 2022-06-25 18:01:15.627439
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Args:
    #     args: A list of strings that will be parsed.
    # Returns:
    #     An `argparse.Namespace` object.
    # Raises:
    #     argparse.ArgumentError: if arguments are incorrect.

    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser(env=Environment())
    h_t_t_pie_argument_parser_parse_args_0 = None

# Generated at 2022-06-25 18:02:38.545019
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    try:
        config = Config()
        items = [('a', 'b'), ('c', 'd')]

        httpie_argument_parser_0 = HTTPieArgumentParser(Config(), items)
        res = httpie_argument_parser_0.parse_args()

        httpie_argument_parser_2 = HTTPieArgumentParser(Config(), items)
        res = httpie_argument_parser_2.parse_args(['a=b'])

        httpie_argument_parser_4 = HTTPieArgumentParser(Config(), items)
        res = httpie_argument_parser_4.parse_args(['c=d', 'a=b'])

    except Exception as e:
        print(e)


# Generated at 2022-06-25 18:02:42.206245
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args_0 = [
        'http',
        'http://httpbin.org/get'
    ]
    parser_0 = HTTPieArgumentParser()
    parser_0.parse_args(args=args_0)


# Generated at 2022-06-25 18:02:52.561116
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from requests.packages.urllib3.exceptions import InsecureRequestWarning
    from requests.packages.urllib3.exceptions import SubjectAltNameWarning
    print("Testing HTTPieArgumentParser.parse_args()")

    httpie_argument_parser_0 = HTTPieArgumentParser()
    httpie_argument_parser_0.parse_args(["-v"])

    # Test if all the flags that should be there, are
    assert 0 <= httpie_argument_parser_0.args.max_redirects <= 100
    assert httpie_argument_parser_0.args.timeout
    assert httpie_argument_parser_0.args.output_file_specified == False
    assert httpie_argument_parser_0.args.download == False
    assert httpie_argument_parser_0.args.check_status == False

# Generated at 2022-06-25 18:03:04.690633
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    run_tests = False
    if run_tests:
        # test 1
        parser = HTTPieArgumentParser(description=description)

        parser.add_argument('-H', '--header',
                            dest='headers',
                            metavar='HEADER',
                            action='append',
                            type=HeaderArgType(),
                            default=[],
                            help='Header to include in the request '
                                 '(H).')
        parser.add_argument('-f', '--form',
                            dest='form',
                            action='store_true',
                            default=False,
                            help='Data items are bundled into a form.')

# Generated at 2022-06-25 18:03:07.573302
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser_parse_args_0 = HTTPieArgumentParser(env=Environment())
    parser_parse_args_0.parse_args(args=[])


# Generated at 2022-06-25 18:03:11.456838
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Arrange
    httpie_argument_parser_0 = HTTPieArgumentParser()

    # Act
    httpie_argument_parser_0.parse_args()
    # Assert
    # TODO: Unit test for parse_args method of class HTTPieArgumentParser
    pass


# Generated at 2022-06-25 18:03:20.939225
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_2 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_3 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_4 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_5 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_6 = HTTPieArgumentParser()
    try:
        h_t_t_pie_argument_parser_0.parse_args('')
    except NoSuchOption:
        pass

# Generated at 2022-06-25 18:03:25.292513
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    test_args = ['httpie', ]
    h_t_t_pie_argument_parser_0.parse_args(test_args)

# Generated at 2022-06-25 18:03:31.233200
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_args_parser_0 = HTTPieArgumentParser()
    test_parse_args_0 = httpie_args_parser_0.parse_args()
    test_parse_args_1= httpie_args_parser_0.parse_args(['--method=t'])
    test_parse_args_2 = httpie_args_parser_0.parse_args(['--ignore-stdin'])


# Generated at 2022-06-25 18:03:33.456594
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.parse_args(['get', 'http://localhost'])

