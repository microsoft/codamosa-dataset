

# Generated at 2022-06-25 17:55:16.010845
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # print(help(HTTPieArgumentParser.parse_args))
    # h_t_t_pieargumentparser_parse_args_args = None
    # h_t_t_pieargumentparser_parse_args_args = ['--traceback']
    h_t_t_pieargumentparser_parse_args_args = ['-h']
    # h_t_t_pieargumentparser_parse_args_args = ['--help']
    # h_t_t_pieargumentparser_parse_args_args = ['https://en.wikipedia.org']
    # h_t_t_pieargumentparser_parse_args_args = ['https://en.wikipedia.org/', 'test2=5']
    # h_t_t_pieargumentparser_parse_args_

# Generated at 2022-06-25 17:55:24.344296
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test cases
    parser = HTTPieArgumentParser(prog='http', env=Environment(), add_help=False)
    args = parser.parse_args(['GET', 'http://localhost'])
    assert(args.method == 'GET')
    assert(args.url == 'http://localhost')

    args = parser.parse_args(['GET', 'http://localhost', 'one', 'two'])
    assert(args.method == 'GET')
    assert(args.url == 'http://localhost')
    assert(any(arg.key == 'one' and arg.value == 'two' 
        for arg in args.request_items))

    args = parser.parse_args(['http://localhost', 'one', 'two'])
    assert(args.method == 'GET')

# Generated at 2022-06-25 17:55:30.168889
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    # Test original parser with better error message
    test_arg1 = '-u'
    test_arg2 = 'user:pass'
    test_arg3 = 'http://example.com'
    with pytest.raises(SystemExit):
        HTTPieArgumentParser().parse_args([test_arg1, test_arg2, test_arg3])

    # Test original parser with better error message
    test_arg1 = '-u'
    test_arg2 = 'user:pass'
    test_arg3 = 'http://example.com'
    with pytest.raises(SystemExit):
        HTTPieArgumentParser().parse_args([test_arg1, test_arg2, test_arg3])

# Generated at 2022-06-25 17:55:32.513342
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser = HTTPieArgumentParser()
    httpie_argument_parser.parse_args()
    # TODO: test for this method more


# Generated at 2022-06-25 17:55:40.678587
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    # Test the test_case_0() if the module is run
    if __name__ == '__main__':
        test_case_0()

    # Initialize an instance of HTTPieArgumentParser
    httpie_argument_parser_0 = HTTPieArgumentParser()
    # Call parse_args() on httpie_argument_parser_0
    args = httpie_argument_parser_0.parse_args()
    # Check if args is not None
    assert args is not None
    # Do some assertions on args to check that it is as expected

# Generated at 2022-06-25 17:55:52.763096
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from sys import argv
    from os import getcwd, chdir
    the_path = getcwd()
    try:
        chdir('/home/travis/build/jakubroztocil/httpie')
    except ObjectNotFoundError:
        pass
    argv_tmp_var = argv
    argv = ['/usr/local/bin/http', '--download', '--traceback', 'https://httpbin.org/ip']
    httpie_argument_parser_0 = HTTPieArgumentParser()
    the_returned_value = httpie_argument_parser_0.parse_args()
    assert type(the_returned_value) is argparse.Namespace
    assert the_returned_value.auth is None
    assert the_returned_value.auth_type is None

# Generated at 2022-06-25 17:55:54.830773
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser_0 = HTTPieArgumentParser()
    output_0 = parser_0.parse_args()


# Generated at 2022-06-25 17:55:58.187754
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """ Test parse_args method of class HTTPieArgumentParser """
    TestHTTPieArgumentParser_parse_args = HTTPieArgumentParser()
    TestHTTPieArgumentParser_parse_args.parse_args()


# Generated at 2022-06-25 17:56:04.850764
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_0 = HTTPieArgumentParser(
        description='a cURL-like, modern command line HTTP client',
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    httpie_argument_parser_0.add_argument(
        '-v',
        '--verbose',
        action='store_true',
        dest='verbose',
        help='Print the whole request as well as its response.'
    )
    import sys
    try:
        args = httpie_argument_parser_0.parse_args(sys.argv[1:])
    except HTTPError as e:
        print(e, file=sys.stderr)
        sys.exit(1)

if __name__ == '__main__':
    test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-25 17:56:17.058443
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_arg_parser_0 = HTTPieArgumentParser()
    try:
        h_t_t_pie_arg_parser_0.parse_args(h_t_t_pie_arg_parser_0.args)
    except SystemExit:
        pass


if __name__ == "__main__":
    test_case_0()
    test_HTTPieArgumentParser_parse_args()
# # python3.6
# # -*- coding: utf-8 -*-
# import argparse
# from copy import deepcopy
# from getpass import getpass, getuser
# import mimetypes
# import os
# import re
# import shlex
# import sys
# import warnings
#
# import requests
#
# from . import __version__, exit
# from .comp

# Generated at 2022-06-25 17:57:27.822082
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test 1: No error
    httpie_arg_parser_0 = HTTPieArgumentParser()
    
    stream_0 = io.StringIO()
    sys.stderr = stream_0
    try:
        httpie_arg_parser_0.parse_args(['-h'])
    except:
        sys.stderr = sys.__stderr__
        raise 
    sys.stderr = sys.__stderr__
    
    # Test 2: Error, test_case_0
    httpie_arg_parser_1 = HTTPieArgumentParser()
    try:
        httpie_arg_parser_1.parse_args(['-h'])
    except Exception as err:
        pass
    # Test 3: Error, missing argument
    httpie_arg_parser_2 = HTTPie

# Generated at 2022-06-25 17:57:37.615472
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie import ExitStatus
    from httpie.input import ParseError
    from httpie.cli import input_stream
    from httpie.cli import environment
    from httpie.cli import HTTPieArgumentParser
    import sys

    httpie_argument_parser_0 = HTTPieArgumentParser(
        default_scheme='https',
        default_options=[],
        env=environment.Environment(),
        stdin=input_stream.get_in(follow_redirects=True),
        stdout=sys.stdout,
        stderr=sys.stderr
    )
    try:
        httpie_argument_parser_0.parse_args([
            '--output', '--output'
        ])
    except SystemExit as e:
        assert e.code == ExitStatus.USAGE


# Generated at 2022-06-25 17:57:49.871058
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    self = HTTPieArgumentParser()
    os.environ['HTTPIE_ENV_COLORBLIND'] = '1'
    os.environ['HTTPIE_ENV_STYLE'] = 'solarized'
    os.environ['HTTPIE_ENV_HTTP_CLIENT'] = 'urllib3'
    os.environ['HTTPIE_ENV_TIMEOUT'] = '2.5'
    os.environ['HTTPIE_ENV_MAX_AGE'] = '0'
    os.environ['HTTPIE_ENV_STRIP_ANSI'] = '1'
    os.environ['HTTPIE_ENV_VERIFY'] = '1'
    os.environ['HTTPIE_ENV_INITIAL_PWD'] = '/home/yunfeiguo/'
    os

# Generated at 2022-06-25 17:57:59.205662
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_0 = HTTPieArgumentParser()

    h_t_t_pie_help_formatter_0 = HTTPieHelpFormatter()
    httpie_argument_parser_0.formatter_class = h_t_t_pie_help_formatter_0

    # arg_strings is a list of string arguments to be parsed.
    # the default values for all args are in httpie_argument_parser_0.parse_known_args

    arg_strings = []
    parsed_args = httpie_argument_parser_0.parse_known_args(arg_strings)

# Generated at 2022-06-25 17:58:01.946434
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    # h_t_t_pie_argument_parser_0.parse_args()
    pass

# Generated at 2022-06-25 17:58:07.560927
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    # Arrange
    args = []
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()

    # Act
    try:
        h_t_t_pie_argument_parser_0.parse_args(args, 'http')
    except SystemExit:
        pass
    except:
        raise

    # Assert
    return


# Generated at 2022-06-25 17:58:12.927136
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    test_case_0()

if __name__ == '__main__':
    test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-25 17:58:21.696640
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import argparse
    arg_parse_0 = argparse.ArgumentParser()
    arg_parse_1 = argparse.ArgumentParser()
    _method_output_0 = arg_parse_0.parse_args()
    _method_output_1 = arg_parse_1.parse_args()
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
    _method_output_2 = h_t_t_pie_argument_parser_0.parse_args()
    _method_output_3 = h_t_t_pie_argument_parser_1.parse_args()


# Generated at 2022-06-25 17:58:25.268780
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # FIXME: add a test
    assert False


# Generated at 2022-06-25 17:58:33.388069
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    o_h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    o_h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
    o_h_t_t_pie_argument_parser_2 = HTTPieArgumentParser()
    o_h_t_t_pie_argument_parser_0.parse_args()
    o_h_t_t_pie_argument_parser_1.parse_args(["ls"])
    o_h_t_t_pie_argument_parser_2.parse_args(["cd"])


# Generated at 2022-06-25 17:59:43.985693
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from io import StringIO
    from tempfile import TemporaryFile
    from httpie.input import ParseException
    from requests.exceptions import InvalidSchema
    import os
    import signal
    import sys
    import time
    import unittest
    # h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    # h_t_t_pie_argument_parser_0.parse_args(args=['--traceback'])
    print('test_HTTPieArgumentParser_parse_args')
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.parse_args(args=['GET','https://httpbin.org/get'])

# Generated at 2022-06-25 17:59:49.414998
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Create an instance of HTTPieArgumentParser class
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    # Get the list of arguments
    args = sys.argv[1:]
    # Call the method
    a = h_t_t_pie_argument_parser_0.parse_args(args)
    # Verify the result
    assert(isinstance(a, args_type))


# Generated at 2022-06-25 17:59:59.012574
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    print("Test: test_HTTPieArgumentParser_parse_args")
    # Test the case where not arguments are specified
    parser = HTTPieArgumentParser()
    args = parser.parse_args([])
    # Check to see if the expected attributes were created 
    assert 'output_format' in args.__dict__
    assert 'verbose' in args.__dict__
    assert 'headers' in args.__dict__
    assert 'verify' in args.__dict__
    assert 'traceback' in args.__dict__
    assert 'offline' in args.__dict__
    assert 'download' in args.__dict__
    assert 'method' in args.__dict__
    assert 'json' in args.__dict__
    assert 'pretty' in args.__dict__
    assert 'auth' in args.__dict

# Generated at 2022-06-25 18:00:04.089841
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    test_case_0()
    h_t_t_pie_argument_parser_0.parse_args(['arg1', 'arg2'])

if __name__ == '__main__':
    test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-25 18:00:08.068086
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    httpie_parse_args_0 = h_t_t_pie_argument_parser_0.parse_args()

# Generated at 2022-06-25 18:00:17.945317
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = {
        '--auth': None,
        '--body': None,
        '--download': None,
        '--form': None,
        '--headers': None,
        '--ignore-stdin': None,
        '--output': None,
        '--request': 'DELETE',
        '--scheme': None,
        '--session': None,
        '--stream': None,
        '--timeout': None,
        '--verbose': None,
        '--verify': True,
        '--verify': None,
        '--verify': False,
        '<url>': 'https://github.com/httpie/httpie'
    }
    # Define the response of mock get_netrc_auth

# Generated at 2022-06-25 18:00:21.253857
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    print("Unit test for method parse_args of class HTTPieArgumentParser")
    # TODO: Write unit tests
    args = None
    httpie = HTTPieArgumentParser.create_parser(env=Environment())
    httpie.parse_args(args)

# Generated at 2022-06-25 18:00:33.788709
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = []
    out_a_r_g_parser_0 = HTTPieArgumentParser()
    try:
        out_a_r_g_parser_0.parse_args(args)
        assert False
    except SystemExit:
        pass
    args = ['--help']
    try:
        out_a_r_g_parser_0.parse_args(args)
        assert False
    except SystemExit:
        pass
    args = ['--version']
    try:
        out_a_r_g_parser_0.parse_args(args)
        assert False
    except SystemExit:
        pass
    args = ['--debug']
    out_a_r_g_parser_0.parse_args(args)
    args = ['--traceback']
    out_a_r_g_parser

# Generated at 2022-06-25 18:00:37.171328
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    global httpie_argument_parser_0
    global args
    global args_0

    httpie_argument_parser_0 = HTTPieArgumentParser()
    args = httpie_argument_parser_0.parse_args()
    args_0 = httpie_argument_parser_0.parse_args()

# Generated at 2022-06-25 18:00:39.346794
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argparser_0 = HTTPieArgumentParser()
    httpie_argparser_0.parse_args(["GET", "http://localhost:8000", "-f", "data=value"])


# Generated at 2022-06-25 18:02:51.874174
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    print('')
    parser_0 = HTTPieArgumentParser()
    # parser_0.parse_args()


if __name__ == '__main__':
    test_case_0()
    test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-25 18:03:04.710146
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    # Assertion error: Unable to split 'http://127.0.0.1:7000/'
    try:
        h_t_t_pie_argument_parser_0.parse_args('')
    except SystemExit as e:
        pass
    # Assertion error: One request per invocation
    try:
        h_t_t_pie_argument_parser_0.parse_args('http://127.0.0.1:7000/')
    except SystemExit as e:
        pass
    # Assertion error: One request per invocation

# Generated at 2022-06-25 18:03:14.376128
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_0 = HTTPieArgumentParser()
    argv_0 = []
    argv_0.append('http')
    argv_0.append('--json')
    args_0 = httpie_argument_parser_0.parse_args(argv_0)
    test_utils.assert_equals_str(args_0.form, None, 'args_0.form')
    test_utils.assert_equals_str(args_0.output_options_history, None, 'args_0.output_options_history')
    test_utils.assert_equals_str(args_0.output_options_detail, 'all', 'args_0.output_options_detail')

# Generated at 2022-06-25 18:03:16.566196
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_0 = HTTPieArgumentParser()
    httpie_argument_parser_0.parse_args()


# Generated at 2022-06-25 18:03:27.192212
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_arg_parser = HTTPieArgumentParser()
    with pytest.raises(SystemExit) as excinfo:
        h_t_t_pie_arg_parser.parse_args(['-v'])
    assert excinfo.value.code == 0
    h_t_t_pie_arg_parser.parse_args(['--help'])
    h_t_t_pie_arg_parser.parse_args(['help'])
    h_t_t_pie_arg_parser.parse_args(['help', 'http'])
    h_t_t_pie_arg_parser.parse_args(['http', '--help'])
    h_t_t_pie_arg_parser.parse_args(['help', 'httpie'])
    h_t_t_

# Generated at 2022-06-25 18:03:36.773609
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    print("test_HTTPieArgumentParser_parse_args")
    # Test HTTPieArgumentParser.parse_args
    parser = HTTPieArgumentParser()
    argv = ["http", "httpbin.org/get", "a=1","b=2"]
    args = parser.parse_args(argv)

    print(args)
    print("args.method", args.method)
    print("args.url", args.url)
    print("args.headers", args.headers)
    print("args.data", args.data)
    print("args.json", args.json)
    print("args.form", args.form)
    print("args.files", args.files)
    print("args.auth_plugin", args.auth_plugin)
    print("args.auth", args.auth)

# Generated at 2022-06-25 18:03:45.075077
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    input_args = ['http', '-v', '-bp', '/usr/local/bin/http', 'http://localhost:8080/api/catalog/v4/search/skus', '--query', '"a=c"',
                  '--query', '"b=B"', '--query', '"c=d"', '--query', '"b=B"', '--query', '"b=B"', '--query', '"b=B"', '--query',
                  '"b=B"', '--query', '"b=B"']
    httpie_argument_parser_0 = HTTPieArgumentParser()
    args = httpie_argument_parser_0.parse_args(input_args)
    print(args)


# Generated at 2022-06-25 18:03:54.891477
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    # Test if the first name is correct
    if h_t_t_pie_argument_parser_0.name != 'http':
        raise AssertionError()
        # Test if the first prog is correct
    if h_t_t_pie_argument_parser_0.prog != 'http':
        raise AssertionError()
    # Test if the first argument is correct

# Generated at 2022-06-25 18:03:56.853713
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.parse_args()


# Generated at 2022-06-25 18:04:06.186997
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test for following methods:
    #   _apply_no_options
    #   _body_from_file
    #   _guess_method
    #   _parse_items
    #   _process_auth
    #   _process_download_options
    #   _process_format_options
    #   _process_output_options
    #   _process_pretty_options
    #   _rewrite_urlencoded_type_arg
    #   _scheme_rewrite
    #   _setup_standard_streams
    #   _validate_output_file
    #   add_argument
    #   add_subparsers
    #   error
    output_options_history = 'H'
    args_0=[]
    args_0.append('HTTPie')