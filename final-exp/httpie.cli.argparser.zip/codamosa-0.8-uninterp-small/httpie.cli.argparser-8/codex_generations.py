

# Generated at 2022-06-25 17:55:16.915851
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Constructor HTTPieArgumentParser() testing zero arguments
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()

    # Method parse_args() testing zero arguments
    str_arg_list = [
        'example.org',
        '--form',
        'a=b',
        'c=d'
    ]
    args = h_t_t_pie_argument_parser_0.parse_args(str_arg_list)

    assert args.headers == {'Content-Type': 'application/x-www-form-urlencoded'}

# Generated at 2022-06-25 17:55:23.440577
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    test_HTTPieArgumentParser_parse_args_arguments_0 = ['http', '--json', 'httpbin.org', 'Content-Type: text/html']
    
    try:
        h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    except:
        print("Unable to create HTTPieArgumentParser object")
        assert False

    try:
        args = h_t_t_pie_argument_parser_0.parse_args(test_HTTPieArgumentParser_parse_args_arguments_0)
    except:
        print("Unable to parse arguments")
        assert False
    

# Generated at 2022-06-25 17:55:28.319371
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_0 = HTTPieArgumentParser()
    try:
        httpie_argument_parser_0.parse_args()
    except SystemExit as system_exit_0:
        assert system_exit_0.code == 2
    else:
        raise Exception("Expected Exception")



# Generated at 2022-06-25 17:55:36.015140
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    args = Namespace()
    args.auth = None
    args.auth_type = None
    args.body = None
    args.body_from = None
    args.download = False
    args.download_resume = False
    args.exit_status = False
    args.follow = False
    args.form = False
    args.format = None
    args.headers = []
    args.ignore_netrc = False
    args.ignore_stdin = False
    args.implicit_content_type = 'auto'
    args.json = None
    args.max_redirects = 30
    args.method = None
    args.output = None
    args.output_file = None

# Generated at 2022-06-25 17:55:36.750086
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    pass


# Generated at 2022-06-25 17:55:40.513825
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser() # Instantiate object
    h_t_t_pie_argument_parser_1.parse_args()


# Generated at 2022-06-25 17:55:43.809163
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.parse_args()


# Generated at 2022-06-25 17:55:45.013967
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    test_case_0()


# Generated at 2022-06-25 17:55:56.512165
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    # Set up test object
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
    argv = ['--ignore-stdin', '--verbose', '--print', 'B', '--style', 'par.",@.+~`\'`\\\"\\\"', '--style', 'par.",@.+~`\'`\\\"\\\"', 'https://api.github.com/gists/a7b1c1834686749081c3']
    args = h_t_t_pie_argument_parser_1.parse_args(argv)

    # Check if the value returned is correct
    assert args.debug == False
    assert args.download == False
    assert args.follow == False
    assert args.max_redirects == 10
    assert args.max_requests == 1

# Generated at 2022-06-25 17:56:00.755698
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # test with arguments.
    args0 = {}
    args0['argv'] = None
    args0['namespace'] = None
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.parse_args(**args0)



# Generated at 2022-06-25 17:56:41.048284
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    # Test case for calling method with arguments
    # HTTPieArgumentParser_instance = HTTPieArgumentParser()
    # HTTPieArgumentParser_instance.parse_args(arguments)
    raise NotImplementedError


# Generated at 2022-06-25 17:56:48.488633
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """
    Method: parse_args
    """
    # Test configurable parameters for parse_args
    # argv: Command line arguments, i.e. sys.argv[1:]
    # env: Environment variables, i.e. os.environ
    argv = ['--output-file=tests/testfiles/output.txt', '--download', '-L', 'http://httpbin.org/get', '--auth-type=basic', '-a', 'testuser', 'testpassword']
    env = {}

    # Uncomment to test interactive mode
    # Test a set attributes
    # h_t_t_pie_parameters = HTTPieParameters()
    # h_t_t_pie_arg_parser = HTTPieArgumentParser(h_t_t_pie_parameters)
    # args = h_t_t

# Generated at 2022-06-25 17:56:52.491662
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.parse_args()


# Generated at 2022-06-25 17:56:58.914015
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser(env=Environment(colors=256))
    try:
        _ = h_t_t_pie_argument_parser_0.parse_args([])
    except SystemExit:
        pass


# Generated at 2022-06-25 17:57:03.788638
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()

    # Test if argparse.ArgumentParser.parse_args is being called
    if hasattr(h_t_t_pie_argument_parser_0, 'parse_args'):
        # Call argparse.ArgumentParser.parse_args
        h_t_t_pie_argument_parser_0.parse_args()

    # Make sure HTTPieHelpFormatter.format_option_strings is being called
    for action in h_t_t_pie_argument_parser_0._actions:
        if not hasattr(action, 'help') or action.help == argparse.SUPPRESS:
            continue

# Generated at 2022-06-25 17:57:08.370794
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.add_argument('--version', action='version', version='2.0.0')

# Generated at 2022-06-25 17:57:15.001657
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    method_arguments_0 = ['http', '--ignore-stdin']
    httpie_argument_parser_0 = HTTPieArgumentParser()
    # TypeError: parse_args() missing 1 required positional argument: 'argv'
    # httpie_argument_parser_0.parse_args(method_arguments_0)

if __name__ == '__main__':
    test_HTTPieArgumentParser_parse_args()


# We want to use the same version of semver as the `header_rewriter`
# but we can't because of circular imports.
#
# Let's that this is an acceptable approximation.
# FIXME: <https://github.com/psf/requests/issues/3608>


# Generated at 2022-06-25 17:57:28.363952
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-25 17:57:31.532902
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_0 = HTTPieArgumentParser()
    httpie_argument_parser_0.parse_args()


# Generated at 2022-06-25 17:57:36.868768
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = list(sys.argv)
    args = args[1:]
    parser = HTTPieArgumentParser()
    parser.parse_args(args)



# Create a HTTPieArgumentParser instance to test it.
#parser = HTTPieArgumentParser()
#parser.parse_args(sys.argv[1:])

if __name__ == '__main__':
    test_HTTPieArgumentParser_parse_args()
    #test_case_1()

# Generated at 2022-06-25 17:58:51.417927
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Setup args
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    # Setup kwargs
    args_kwargs = []
    args_kwargs.append(
        mock.call(                      # args
            '-h',
        ))
    args_kwargs.append(
        mock.call(                      # args
            '--help',
        ))
    args_kwargs.append(
        mock.call(                      # args
            '--version',
        ))

    # Invoke method
    with mock.patch('sys.argv', new=['http']):
        try:
            h_t_t_pie_argument_parser_0.parse_args(**kwargs)
        except SystemExit:
            pass


# Generated at 2022-06-25 17:58:52.772471
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.parse_args()

# Generated at 2022-06-25 17:58:56.183090
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_0 = HTTPieArgumentParser()
    try:
        httpie_argument_parser_0.parse_args()
    except SystemExit as e:
        assert e.code == 0


# Generated at 2022-06-25 17:59:01.623994
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # setup
    httpie_argument_parser0 = HTTPieArgumentParser()
    args0 = ['http']
    expected_result = (None, None)
    # exercise
    actual_result = httpie_argument_parser0.parse_args(args0)
    # verify
    assert actual_result == expected_result
    # cleanup
    del httpie_argument_parser0


# Generated at 2022-06-25 17:59:11.517023
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_parse_args_obj = HTTPieArgumentParser()
    # arguments: ['--help']
    # expected result:
    #   Namespace(form=False, headers=None, ignore_stdin=False, json=None, output_file=None, output_file_specified=False, output_options=None, output_options_history=None, params=None, pretty=None, print_bodies=None, print_headers=None, print_history=None, print_status=None, quiet=False, traceback=False, url=None, verbose=False)

# Generated at 2022-06-25 17:59:21.302131
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Signature: name, args=None, namespace=None
    httpie_argument_parser_0 = HTTPieArgumentParser()
    httpie_argument_parser_0.add_argument('-I', '--head', action='store_true', help='Fetch HEAD only', dest='head')
    httpie_argument_parser_0.add_argument('-H', '--header', action='append', help='Custom header to set in the request (H). You can specify as many extra headers as you want by using this option multiple times. It can be used to set multiple headers of the same name (note that when used with -A, headers set by -H are overwritten by headers set by -A). Example: -H "Host: foo.bar" -H "Accept: application/json"', metavar='', type=keyvalue_argtype, dest='headers')


# Generated at 2022-06-25 17:59:29.603194
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    init_str_0 = 'http --ignore-stdin --help --traceback'
    parser_0 = HTTPieArgumentParser()
    args_0 = parser_0.parse_args(init_str_0)
    parser_1 = HTTPieArgumentParser()
    init_str_1 = 'http --ignore-stdin --help --traceback'
    args_1 = parser_1.parse_args(init_str_1)
    parser_2 = HTTPieArgumentParser()
    args_2 = parser_2.parse_args(None)
    parser_3 = HTTPieArgumentParser()
    args_3 = parser_3.parse_args(None)
    parser_4 = HTTPieArgumentParser()
    init_str_2 = 'http --ignore-stdin --help --traceback'
    args_4

# Generated at 2022-06-25 17:59:41.042242
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    httpie_args_0 = ["--print=H"]
    arg_result_0 = h_t_t_pie_argument_parser_0.parse_args(httpie_args_0)
    assert arg_result_0.print == "H"
    httpie_args_1 = ["--print"]
    arg_result_1 = h_t_t_pie_argument_parser_0.parse_args(httpie_args_1)
    assert arg_result_1.print == "HBhJ"
    httpie_args_2 = ["--download"]
    arg_result_2 = h_t_t_pie_argument_parser_0.parse_args(httpie_args_2)
    assert arg_result_2

# Generated at 2022-06-25 17:59:43.573664
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser_0 = HTTPieArgumentParser()
    parser_0.parse_args(['-h'])

# Generated at 2022-06-25 17:59:45.370286
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    pass


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 18:02:06.163155
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser(env=None, add_help=False, ignore_unknown_options=False)
    return parser.parse_args(
        args=['url']
    )


# Generated at 2022-06-25 18:02:13.934756
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    print('')
    parser = HTTPieArgumentParser()
    print('Input args: ["--help"]')
    args = parser.parse_args(["--help"])
    print('Output argparse.Namespace:', args)
    print('')
    print('Input args: ["--version"]')
    args = parser.parse_args(["--version"])
    print('Output argparse.Namespace:', args)
    print('')
    print('Input args: ["https://httpbin.org/get"]')
    args = parser.parse_args(["https://httpbin.org/get"])
    print('Output argparse.Namespace:', args)
    print('')
    print('Input args: ["--verify=no", "https://httpbin.org/get"]')

# Generated at 2022-06-25 18:02:20.920256
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test 1:
    httpie_argparser_0 = HTTPieArgumentParser(
        env=Environment(colors=256, is_windows=True, stdin=os.fdopen(0, 'r'), stdout=sys.stdout),
        extras_require=None)
    try:
        httpie_argparser_0.parse_args(['https://www.google.com'])
    except Exception:
        pass

if __name__ == '__main__':
    test_case_0()
    test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-25 18:02:33.091993
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_parser_0 = HTTPieArgumentParser(prog='http',
                                              formatter_class=argparse.RawDescriptionHelpFormatter,
                                              add_help=False,
                                              allow_abbrev=False)
    h_t_t_pie_parser_0.add_argument('-h', '--help',
                                    help='Prints this help message and exits.',
                                    action='store_true')
    h_t_t_pie_parser_0.add_argument('--man',
                                    help='Prints the full help message and exits.',
                                    action='store_true')

# Generated at 2022-06-25 18:02:40.009045
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    def HTTPieArgumentParser_parse_args(self, args=None, namespace=None):
        if args is None:
            # args default to the system args
            args = sys.argv[1:]
        # map each action's option strings to the action itself
        option_string_actions = {
            option_string: action
            for action in self._actions
            for option_string in action.option_strings}

        # find all options that actually expect an argument
        # keep the options with nargs='?' at the front, the
        # rest at the back
        argument_options = []
        non_argument_options = []
        option_string_to_action = {}

# Generated at 2022-06-25 18:02:47.234749
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.add_argument(
        '-f', '--foo',
        type=int,
        choices=[1, 2, 3],
        required=True,
        help='foo',
    )
    parser.add_argument(
        'bar',
        type=int,
        choices=[1, 2, 3],
        required=True,
        help='bar',
    )
    args = parser.parse_args(['2', '1'])
    assert isinstance(args, Namespace)
    assert args.foo == 2
    assert args.bar == 1

if __name__ == "__main__":
    test_case_0()
    test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-25 18:02:55.252437
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser = HTTPieArgumentParser()
    h_t_t_pie_argument_parser.add_argument()
    h_t_t_pie_argument_parser.add_argument()
    h_t_t_pie_argument_parser.add_argument()
    h_t_t_pie_argument_parser.add_argument()
    args = h_t_t_pie_argument_parser.parse_args()

    # check whether the method parse_args of class HTTPieArgumentParser returns the expected value
    assert args.auth_type == ''

if __name__ == '__main__':
    test_case_0()
    test_HTTPieArgumentParser_parse_args()
    output = 'Finished: test_HTTPieArgumentParser'
    print(output)

# Generated at 2022-06-25 18:03:05.389611
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-25 18:03:06.869225
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.parse_args()


# Generated at 2022-06-25 18:03:16.386820
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_0 = HTTPieArgumentParser()

    mocker.patch('httpie.config.DEFAULT_CONFIG_DIR', mocker.Mock(return_value=None))
    mocker.patch('click.Context', mocker.Mock(return_value=None))

    mocker.patch('httpie.core.get_config_dir', mocker.Mock(return_value=None))
    mocker.patch('click.open_file', mocker.Mock(return_value=None))

    mocker.patch('os.path.exists', mocker.Mock(return_value=None))
    mocker.patch('httpie.config.DEFAULT_CONFIG_PATH', mocker.Mock(return_value=None))