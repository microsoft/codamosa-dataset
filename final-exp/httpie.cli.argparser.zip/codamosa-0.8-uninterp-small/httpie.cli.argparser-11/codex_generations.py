

# Generated at 2022-06-25 17:55:09.451803
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.parse_args()


# Generated at 2022-06-25 17:55:12.233038
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = sys.argv[1:]
    # argparse.ArgumentParser.parse_args()
    sys.argv = args
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.parse_args()

if __name__ == "__main__":
    multi_main([test_HTTPieArgumentParser_parse_args])
    #test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-25 17:55:20.418419
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """
    This test case will test the method parse_args of the class HTTPieArgumentParser
    """
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
    _args = []
    _args = h_t_t_pie_argument_parser_1.parse_args(_args)


# Generated at 2022-06-25 17:55:24.261083
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    argv = list()
    h_t_t_pie_argument_parser_0.parse_args(argv)


# Generated at 2022-06-25 17:55:30.086373
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_0 = HTTPieArgumentParser()
    # Test that None fails
    try:
        httpie_argument_parser_0.parse_args(None)
        assert False
    except TypeError:
        assert True
    # Test that a list apart from None fails
    try:
        httpie_argument_parser_0.parse_args(['a'])
        assert False
    except TypeError:
        assert True
    # Test that if an item isn't a string, it will fail
    try:
        httpie_argument_parser_0.parse_args(['a', 'b', 1])
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-25 17:55:41.119697
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    try:
        h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
        h_t_t_pie_argument_parser_0.parse_args()
    except AttributeError as inst:
        print("Exception thrown in test_HTTPieArgumentParser_parse_args")
        print(type(inst))
        print(inst.args)
        print(inst)
        print("Exception thrown in test_HTTPieArgumentParser_parse_args")
        raise
    except IOError as inst:
        print("Exception thrown in test_HTTPieArgumentParser_parse_args")
        print(type(inst))
        print(inst.args)
        print(inst)
        print("Exception thrown in test_HTTPieArgumentParser_parse_args")
        raise



# Generated at 2022-06-25 17:55:51.025673
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = 'foo --bar 1 --baz=2 qux --quux=3'.split()
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    if (h_t_t_pie_argument_parser_0.parse_args(args).quux != 3):
        raise RuntimeError
    if (h_t_t_pie_argument_parser_0.parse_args(args).baz != 2):
        raise RuntimeError
    if (h_t_t_pie_argument_parser_0.parse_args(args).bar != 1):
        raise RuntimeError


# Generated at 2022-06-25 17:55:55.553485
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0_args = []
    h_t_t_pie_argument_parser_0.parse_args(args=h_t_t_pie_argument_parser_0_args)

# Generated at 2022-06-25 17:55:59.866144
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import argparse
    httpie_args = ['http', 'httpbin.org/get']

    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()

    argparse.Namespace._fields

    h_t_t_pie_argument_parser_0.parse_args(args=httpie_args)


# Generated at 2022-06-25 17:56:03.594076
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
    # Test type, is a method.
    assert isinstance(h_t_t_pie_argument_parser_1.parse_args, collections.abc.Callable)


# Generated at 2022-06-25 17:57:11.760093
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    test_args = ['--debug']

    assert h_t_t_pie_argument_parser_0.parse_args(test_args) != None, \
    "method parse_args of class HTTPieArgumentParser failed: \'None\' returned"

    
if __name__ == '__main__':

    test_case_0()
    
    print('Test passed')

# Generated at 2022-06-25 17:57:15.845883
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    command_line = ""
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.parse_args(command_line)


# Generated at 2022-06-25 17:57:17.621169
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Case: default
    test_case_0()


# Generated at 2022-06-25 17:57:22.922493
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.add_argument()
    args = h_t_t_pie_argument_parser_0.parse_args()

# Generated at 2022-06-25 17:57:33.527785
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Arguments parsed into ns
    args = h_t_t_pie_argument_parser_0.parse_args(['--json', 'www.amazon.com/best-sellers'])
    assert(args.json == True)
    # Arguments parsed into ns
    args = h_t_t_pie_argument_parser_0.parse_args(['--print=h,b', '--form', '-h', 'Accept: text/plain', 'httpsbin.org/post'])
    assert(args.print == 'h,b')
    assert(args.form == True)
    assert(args.headers == ['Accept: text/plain'])
    assert(args.url == 'httpsbin.org/post')

# Generated at 2022-06-25 17:57:35.679681
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser(prog='http', env=Environment())
    parser._apply_no_options([])


# Generated at 2022-06-25 17:57:48.122058
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0=HTTPieArgumentParser()

    # Test non-static method
    # Tests instantiation of class HTTPieArgumentParser

    # Test for invalid input
    h_t_t_pie_argument_parser_0.parse_args(**{
        "__name__": __name__
    })

    # Test for invalid input
    h_t_t_pie_argument_parser_0.parse_args(**{
        "__name__": __name__
    })

    # Test for invalid input
    h_t_t_pie_argument_parser_0.parse_args(**{
        "__name__": __name__
    }) # Test for invalid input

# Generated at 2022-06-25 17:57:57.975205
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # If a POST/PUT request has been specified but no content
    # was specified via GET, HEADERS, or INPUT_FILE_PATH,
    # then make it a GET request.
    # if args.method == 'POST' and not args.data and not args.files and not is_content_stdin(args):
    #     args.method = 'GET'

    # Test that the parse_args method handles the reference input
    # Test case 0
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    parsed_args_0 = h_t_t_pie_argument_parser_0.parse_args(["https://httpie.org"])
    assert(parsed_args_0.method == "GET")

# Generated at 2022-06-25 17:58:03.599515
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # No output, check for other test cases
    if not _test_case_HTTPieArgumentParser_pre_parse_args():
        return
    
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.parse_args()


# Generated at 2022-06-25 17:58:10.981105
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_2 = h_t_t_pie_argument_parser_0.parse_args(['http', 'get'])
    assert h_t_t_pie_argument_parser_2.url == 'get'


# Generated at 2022-06-25 18:00:22.888399
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    # get_default_output_options()
    # set_from_args_kwargs()
    # replace_request_items()
    # replace_config_dir()
    # replace_config_path()
    # replace_auth()
    # replace_auth_plugin()
    # replace_auth_type()
    # replace_headers()
    # replace_pretty()
    # replace_style()
    # replace_output_options()
    # replace_output_options_history()
    # replace_verbose()
    # replace_debug()
    # replace_traceback()
    # replace_download_resume()
    # replace_download()
    # replace_output_file()
    # replace_output_file_specified()
   

# Generated at 2022-06-25 18:00:35.505921
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()

    with captured_stderr() as stderr:
        with captured_stdout() as stdout:
            h_t_t_pie_argument_parser_1.parse_args([])
            stdout.seek(0)
            assert stdout.read() == ''
            stderr.seek(0)
            assert stderr.read() == ''


# Generated at 2022-06-25 18:00:42.097899
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    # Strings
    args = 'h_t_t_pie.py --verbose --pretty all https://api.github.com/repos/jakubroztocil/httpie/commits'
    results = h_t_t_pie_argument_parser_0.parse_args(args.split())
    # List of strings
    args = ['h_t_t_pie.py', '--verbose', '--pretty all', 'https://api.github.com/repos/jakubroztocil/httpie/commits']
    results = h_t_t_pie_argument_parser_0.parse_args(args)


# Unit test main()

# Generated at 2022-06-25 18:00:54.382150
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # option_strings,dest,nargs='?',const=None,default=None
    a1 = argparse.Action('-v', 'verbose', '?', '', '')
    a2 = argparse.Action('-h', 'help', '?', '', '')
    a3 = argparse.Action('-m', 'method', '?', '', '')
    a4 = argparse.Action('-x', 'proxy', '?', '', '')
    a5 = argparse.Action('--debug', 'debug', '?', '', '')
    a6 = argparse.Action('-b', 'body', '?', '', '')
    a7 = argparse.Action('-f', 'form', '?', '', '')

# Generated at 2022-06-25 18:00:57.052329
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO: pass arguments to the function
    # h_t_t_pie_argument_parser.parse_args(**kwargs)
    pass


# Generated at 2022-06-25 18:01:05.699319
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    try:
        # --- Pass
        h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
        h_t_t_pie_argument_parser_0.parse_args(['https://httpbin.org/get', 'a:b', 'c'])

        # --- Fail (TypeError)
        try:
            h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
            h_t_t_pie_argument_parser_1.parse_args('https://httpbin.org/get', 'a:b', 'c')
            raise Exception("Test failed: parse_args failed to raise TypeError for unparsable args")
        except TypeError:
            pass

    except Exception as e:
        print(str(e))
        raise e


httpie_argument_parser

# Generated at 2022-06-25 18:01:13.963606
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # test_case_0
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    
    with pytest.raises(SystemExit):
        h_t_t_pie_argument_parser_0.parse_args()
    
    with pytest.raises(SystemExit):
        h_t_t_pie_argument_parser_0.parse_args(['-h'])
    
    with pytest.raises(SystemExit):
        h_t_t_pie_argument_parser_0.parse_args(['http://localhost/'])
    

# Generated at 2022-06-25 18:01:25.741221
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    args = []

# Generated at 2022-06-25 18:01:31.025137
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()

    # Call method
    self = h_t_t_pie_argument_parser_0
    args = h_t_t_pie_argument_parser_0.parse_args([])

    assert( isinstance(args, argparse.Namespace) )
    assert( args.__dict__ == {} )


# Generated at 2022-06-25 18:01:43.300242
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # 1. Arguments:
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    try:
        HTTPieArgumentParser.parse_args(h_t_t_pie_argument_parser_0, [])
    except SystemExit as e:
        module_type_store.set_type_of(stypy.reporting.localization.Localization(__file__, 14, 4), 'stypy_return_type', type(e))
        module_type_store.store_return_type_of_current_context(stypy_return_type_23527)
        
        # Destroy the current context
        module_type_store = module_type_store.close_function_context()
        
        # Return type of the function 'test_HTTPieArgumentParser_parse_args'

# Generated at 2022-06-25 18:04:27.435037
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_0 = HTTPieArgumentParser()
    argv = []
    argv.append('http');
    argv.append('--help')
    httpie_argument_parser_0.parse_args(argv)
    httpie_argument_parser_0.print_help()



# Generated at 2022-06-25 18:04:31.784365
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    help_formatter_0 = HTTPieHelpFormatter()
    arg_parser_0 = HTTPieArgumentParser(prog='http', usage=None, description=None, epilog=None, parents=[], formatter_class=help_formatter_0, prefix_chars='--', fromfile_prefix_chars=None, argument_default=None, conflict_handler='error', add_help=False, allow_abbrev=True)
    # Case 0: default
    arg_parser_0.parse_args()
    # Case 1: `None`
    test_case_1(arg_parser_0)


# Generated at 2022-06-25 18:04:36.523733
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    assert h_t_t_pie_argument_parser_0.parse_args() == None

if __name__ == "__main__":
    test_case_0()
    test_HTTPieArgumentParser_parse_args()