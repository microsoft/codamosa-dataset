

# Generated at 2022-06-25 17:55:12.277022
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = ['--download', 'http://localhost:8000/10k', '--method', 'POST', '--output', '10kb.txt']
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.parse_args(args)


if __name__ == '__main__':
    test_case_0()
    test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-25 17:55:18.749024
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    arg_list = [
                    ['http', 'http://httpbin.org/get'],
                    ['http', 'http://httpbin.org/headers', 'Accept:text/html']
                ]

    for testArg in arg_list:
        h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
        h_t_t_pie_argument_parser_1.parse_args(testArg)


if __name__ == "__main__":

    test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-25 17:55:20.417994
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    test_case_0()

test_HTTPieArgumentParser_parse_args()


# Generated at 2022-06-25 17:55:27.069765
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = ['http', 'https://httpbin.org/ip']
    parser = HTTPieArgumentParser()
    parser.add_argument('--out')
    parser.add_argument('urls',nargs='*')
    parsed_args = parser.parse_args(args)
    assert(parsed_args == argparse.Namespace(out=None,urls=['https://httpbin.org/ip']))



# Generated at 2022-06-25 17:55:31.483298
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.parse_args(['www.google.com'])
    # Expected call: 'self.parse_args.assert_called_once_with(self.args)'



# Generated at 2022-06-25 17:55:39.421796
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    # Replace with your own unit test for method HTTPieArgumentParser.parse_args
    # called with parameters [argv=].
    # Uncomment the next line and replace exception type and message with real ones.
    # raise NotImplementedError('Testing of this unit test has not been implemented yet.')

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 17:55:41.231881
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # FIXME: no test cases yet
    pass


# Generated at 2022-06-25 17:55:42.972157
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test case 0
    test_case_0()



# Generated at 2022-06-25 17:55:44.181807
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    test_case_0()


# Generated at 2022-06-25 17:55:44.915331
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    assert True


# Generated at 2022-06-25 17:56:20.397992
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    # When there is not a possibility of a failure then the output is None.
    # h_t_t_pie_argument_parser_0.parse_args([])


# Generated at 2022-06-25 17:56:21.965705
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser_0 = HTTPieArgumentParser()
    # Now add arguments
    # parser_0.add_argument()
    parser_0.parse_args()

# Generated at 2022-06-25 17:56:26.178703
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Create a HTTPieArgumentParser instance
    parser_0 = HTTPieArgumentParser()
    # Get command-line arguments
    args_intput = sys.argv[1:]
    # Parse command-line arguments
    args = parser_0.parse_args(args=args_intput)
    print("args: ", args)
    print("args.url: ", args.url)
    print("args.headers: ", args.headers)

if __name__ == '__main__':
    test_HTTPieArgumentParser_parse_args()
    # test_case_0()

# Generated at 2022-06-25 17:56:35.005284
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    # Setup for HTTPieArgumentParser.parse_args
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.parse_args_0 = 'test_value_0'
    h_t_t_pie_argument_parser_0.parse_args_1 = 'test_value_1'

    # Invoke method
    h_t_t_pie_argument_parser_0.parse_args()

    # Tests
    assert(True)


# Generated at 2022-06-25 17:56:45.784328
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    global parser
    parser = HTTPieArgumentParser()

# Generated at 2022-06-25 17:56:50.550395
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    argv = [
        '--timeout=10',
        '--http2',
        '--form',
        '--download',
        '--pretty',
        'all'
    ]
    httpie_argparser_0 = HTTPieArgumentParser()
    httpie_argparser_0.parse_args(argv)

if __name__ == "__main__":
    test_case_0()
    test_HTTPieArgumentParser_parse_args

# Generated at 2022-06-25 17:57:03.954919
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    parser = HTTPieArgumentParser(
        prog='HTTPie',
        formatter_class=HTTPieHelpFormatter,
        add_config_dir=False
    )

    try:
        argv = ['--exit-ok', '--download', '--method', 'GET', '--url', 'http://127.0.0.1:9000/']
        args = parser.parse_args(argv)

    except SystemExit as e:
        return str(e)

    if args.exit_ok == False:
        return "--exit-ok is False"

    if args.download == False:
        return "--download is False"

    if args.method != "GET":
        return "--method is not GET"

    if args.url != "http://127.0.0.1:9000/":
        return

# Generated at 2022-06-25 17:57:05.931783
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # setUp test
    http_i_e_argument_parser_0 = HTTPieArgumentParser()
    # test
    assert http_i_e_argument_parser_0.parse_args()


# Generated at 2022-06-25 17:57:07.637837
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    test_httpie_argument_parser = HTTPieArgumentParser()
    test_httpie_argument_parser.parse_args()


# Generated at 2022-06-25 17:57:11.636586
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test cases that fail
    try:
        httpie_argument_parser_0 = HTTPieArgumentParser()
        httpie_argument_parser_0.parse_args("--download --continue")
        assert False
    except SystemExit:
        pass

if __name__ == '__main__':
    test_case_0()

    test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-25 17:58:23.907254
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(args=['--auth-type=basic', 'http://localhost:8080', '/path/to/file'])
    print(args)
    # args = parser.parse_args(args=['http://localhost:8080', '--form', 'file=@/path/to/file'])
    # print(args)
    # args = parser.parse_args(args=['http://localhost:8080', '--form', 'file=@/path/to/file', '--download'])
    # print(args)
    #args = parser.parse_args(args=['http://localhost:8080', '--form', 'file=@/path/to/file', '--download', '--output=out.txt'])
    #print(args)

# Generated at 2022-06-25 17:58:31.028096
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from test_data.httpie_argument_parser_test_data import httpie_argument_parser_test_data
    # TODO: figure out how to pass the test_data constants
    # httpie_argument_parser_test_data = HTTPieArgumentParserTestData()
    # test_data = httpie_argument_parser_test_data.get_test_data()
    test_data = httpie_argument_parser_test_data

    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    num_tests = len(test_data)
    for idx in range(num_tests):
        test_header_1 = test_data[idx].test_header_1
        test_header_2 = test_data[idx].test_header_2

# Generated at 2022-06-25 17:58:34.227318
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_arg_parser_0 = HTTPieArgumentParser()
    argv_0 = ["--version"]
    httpie_arg_parser_0.parse_args(argv_0)


# Generated at 2022-06-25 17:58:39.470870
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    c_l_i_parser_0 = HTTPieArgumentParser()
    argv_0 = ["/usr/local/bin/http", "--ignore-stdin", "--verbose", "GET", "example.org/get"]
    # check the output of the method parse_args is correct
    assert c_l_i_parser_0.parse_args(argv_0) == ('example.org/get',)

# Generated at 2022-06-25 17:58:44.897796
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    if __IPYTHON__:
        pytest.skip()

    try:
        parse_args(['--help'])
    except SystemExit as e:
        if e.code != 0:
            raise

    try:
        parse_args(['--version'])
    except SystemExit as e:
        if e.code != 0:
            raise


# Generated at 2022-06-25 17:58:54.237598
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Tell Python not to write bytecode files
    sys.dont_write_bytecode = True

    httpie_argument_parser_0 = HTTPieArgumentParser(prog='http',
                                                    env=EnvironmentForTests(),
                                                    add_config_dir_arg=True)

    assert httpie_argument_parser_0.parse_args(['demo.org', '--help'])
    assert not httpie_argument_parser_0.parse_args([])
    assert not httpie_argument_parser_0.parse_args(None)
    assert not httpie_argument_parser_0.parse_args(['--verbose'])

    # Assume we're at the root of the project
    httpie_argument_parser_0.env.config_dir = 'tests/config'
    assert httpie_argument

# Generated at 2022-06-25 17:59:04.848484
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    try:
        import StringIO
    except ImportError:
        from io import StringIO
    h_t_t_pie_argument_parser_0.env.stderr = StringIO.StringIO()
    h_t_t_pie_argument_parser_0.env.stdout = StringIO.StringIO()
    h_t_t_pie_argument_parser_0.env.stdin = StringIO.StringIO()
    h_t_t_pie_argument_parser_0.env.stdin_isatty = False
    h_t_t_pie_argument_parser_0.env.stdout_isatty = False
    h_t_t_pie_argument_parser_0.parse_args([])

# Generated at 2022-06-25 17:59:10.831827
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    HTTPieArgumentParser_parse_args_0 = HTTPieArgumentParser()
    HTTPieArgumentParser_parse_args_0.add_argument("-o", "--output-file", type = argparse.FileType("wb"))
    args = HTTPieArgumentParser_parse_args_0.parse_args("-o '/path/to/file'")
    print(args.output_file)

if __name__ =='__main__':
    test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-25 17:59:17.963139
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test for the case where:
        args = ['--json']
        namespace = Namespace()
        namespace = parse_args(args, namespace)
        assert namespace == Namespace(json=True)
    # Test for the case where:
        args = ['--headers']
        namespace = Namespace()
        namespace = parse_args(args, namespace)
        assert namespace == Namespace(headers=True)
    # Test for the case where:
        args = []
        namespace = Namespace()
        namespace = parse_args(args, namespace)
        assert namespace == Namespace()

# Generated at 2022-06-25 17:59:20.656711
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0._parse_items()

# Generated at 2022-06-25 18:01:36.028393
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    for _ in range(100):
        args = HTTPieArgumentParser().parse_args(
        ['www.example.com', 'GET'])


# Generated at 2022-06-25 18:01:47.254625
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

    # No such option: --help-no-exist
    with pytest.raises(SystemExit):
        parser.parse_args(['http', '--help-no-exist'])

    # No such option: --no-exist
    with pytest.raises(SystemExit):
        parser.parse_args(['http', '--no-exist'])

    # Shortcut option: -h
    parser.parse_args(['http', '-h'])

    # Shortcut option: -v
    parser.parse_args(['http', '-v'])

    # Shortcut option: -V
    parser.parse_args(['http', '-V'])

    # Option set: --json
    parser.parse_args(['http', '--json'])

    # Option set

# Generated at 2022-06-25 18:01:53.913315
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # tests execution context
    # (parsing of arguments: `http --method PUT -a user:password URL "k=v"`)
    httpie_argparse_0 = HTTPieArgumentParser()
    httpie_argparse_0.add_argument('--method', default='GET')
    httpie_argparse_0.add_argument('--auth', default='user:password')
    httpie_argparse_0.add_argument('-a', dest='auth')
    args = httpie_argparse_0.parse_args(
        ['--method', 'PUT', '-a', 'user:password', 'URL', '"k=v"'])
    # AssertionError: 'url' != URL
    # assert args.url == 'URL'
    # AssertionError: 'method' != PUT
   

# Generated at 2022-06-25 18:01:57.431338
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.parse_known_args()


# Generated at 2022-06-25 18:02:02.552955
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_parse_args_0 = HTTPieArgumentParser()
    httpie_argument_parser_parse_args_1 = HTTPieArgumentParser()
    httpie_argument_parser_parse_args_2 = HTTPieArgumentParser()
    # Provide actual return value of function `parse_args()`
    httpie_argument_parser_parse_args_0.env = None
    httpie_argument_parser_parse_args_2.env = None

    # Add test case for the arguments:
    # ```
    # @type self: HTTPieArgumentParser
    # ```
    # Also, specify a correct return value
    #  of function `parse_args()`
    #  in order to not produce a false positive test result
    httpie_argument_parser_parse_args_1.env = None

# Generated at 2022-06-25 18:02:04.215685
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_0 = HTTPieArgumentParser()
    assert True


# Generated at 2022-06-25 18:02:13.316391
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    # 
    print("--------")
    print(h_t_t_pie_argument_parser_0.parse_args())
    print("--------")
    print(h_t_t_pie_argument_parser_0.parse_args(["www.baidu.com"]))
    print("--------")
    print(h_t_t_pie_argument_parser_0.parse_args(["http", "www.baidu.com"]))
    print("--------")
    print(h_t_t_pie_argument_parser_0.parse_args(["http", "www.baidu.com"]))
    print("--------")

# Generated at 2022-06-25 18:02:18.650966
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    # Test with an empty list
    assert h_t_t_pie_argument_parser_0.parse_args([]) is None
    # Test with a list containing an invalid option
    try:
        assert h_t_t_pie_argument_parser_0.parse_args(["--invalid-option"])
    except Exception as e:
        assert isinstance(e, SystemExit)
    # Test with a list containing a valid option
    assert h_t_t_pie_argument_parser_0.parse_args(["-v"]) is not None


# Generated at 2022-06-25 18:02:29.693753
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_help_formatter_0 = HTTPieHelpFormatter()
    h_t_t_pie_help_formatter_1 = HTTPieHelpFormatter()
    h_t_t_pie_help_formatter_2 = HTTPieHelpFormatter()
    h_t_t_pie_help_formatter_3 = HTTPieHelpFormatter()
    h_t_t_pie_help_formatter_4 = HTTPieHelpFormatter()
    h_t_t_pie_help_formatter_5 = HTTPieHelpFormatter()
    h_t_t_pie_help_formatter_6 = HTTPieHelpFormatter()
    h_t_t_pie_help_formatter_7 = HTTPieHelpFormatter()
    h_t_t_pie_help_formatter_8

# Generated at 2022-06-25 18:02:33.752101
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO: This test needs to be fixed after fixing the method
    # TODO: This test needs to be fixed after fixing the method
    # TODO: This test needs to be fixed after fixing the method
    pass
