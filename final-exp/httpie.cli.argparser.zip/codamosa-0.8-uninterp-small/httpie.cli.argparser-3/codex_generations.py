

# Generated at 2022-06-25 17:55:13.226855
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser = HTTPieArgumentParser()
    env = Environment()
    args = h_t_t_pie_argument_parser.parse_args(
        args=[],
        env=env
    )
    assert args.follow == True
    assert args.method == None
    assert args.headers == None
    assert args.data == None
    assert args.params == None
    assert args.files == None
    assert args.prettify == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.auth_plugin == None
    assert args.traceback == False
    assert args.alias == None
    assert args.output_file == None
    assert args.output_file_specified == False

# Generated at 2022-06-25 17:55:17.714348
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    sys.argv = "httpie -h".split()
    httpie_argument_parser = HTTPieArgumentParser()
    args = httpie_argument_parser.parse_args()
    assert args.help
    sys.argv = "httpie".split()
    httpie_argument_parser = HTTPieArgumentParser()
    args = httpie_argument_parser.parse_args()
    assert args.url == 'localhost'
    sys.argv = "httpie 123".split()
    httpie_argument_parser = HTTPieArgumentParser()
    args = httpie_argument_parser.parse_args()
    assert args.url == '123'
    sys.argv = "httpie --print=hB --output=123".split()
    httpie_argument_parser = HTTPieArgumentParser()
    args = http

# Generated at 2022-06-25 17:55:21.409497
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    global h_t_t_pie_argument_parser_1
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
    print("Testing method parse_args of class HTTPieArgumentParser")
    return h_t_t_pie_argument_parser_1.parse_args()


# Generated at 2022-06-25 17:55:29.219227
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.parse_args()
    try:
        h_t_t_pie_argument_parser_0.parse_args()
    except Exception as e:
        if isinstance(e, HTTPieError):
            print('Exception of class HTTPieError')
            print(e)
        else:
            print('Exception of other class')
            print(e.__class__.__name__)


# Generated at 2022-06-25 17:55:30.565986
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    HTTPieArgumentParser.parse_args()


# Generated at 2022-06-25 17:55:36.273861
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test type error
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
    try:
        h_t_t_pie_argument_parser_1.parse_args(0)
    except TypeError:
        pass
    else:
        raise AssertionError('TypeError not raised')

    # Test TypeError
    h_t_t_pie_argument_parser_2 = HTTPieArgumentParser()
    try:
        h_t_t_pie_argument_parser_2.parse_args([])
    except TypeError:
        pass
    else:
        raise AssertionError('TypeError not raised')

# Generated at 2022-06-25 17:55:37.494353
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    test_case_0()


# Generated at 2022-06-25 17:55:38.873201
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    pass # TODO


# Generated at 2022-06-25 17:55:50.716842
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    test_case()
    test_case_0()

DEFAULT_FORMAT_OPTIONS = {
    'body': {'ignore': None},
    'headers': {'exclude': None},
    'style': {'colors': True},
    'style.colors': {'request': None},
    'style.colors.request': {'method': 'blue'},
}

PARSED_DEFAULT_FORMAT_OPTIONS = {
    'body': {'ignore': None},
    'headers': {'exclude': None},
    'style': {'colors': True},
    'style.colors': {'request': None},
    'style.colors.request': {'method': 'blue'},
}



# Generated at 2022-06-25 17:55:53.089377
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--download', 'gfdsg', '--version'])
    parser.add_argument('--download', action='store_true')
    parser.add_argument('--version', action='store_true')
    #assert args.greeting == 'hello world'

# Generated at 2022-06-25 17:56:25.835030
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = ArgumentParser()

    arg1 = "-help"
    arg2 = "-"

    args = parser.parse_args([arg1, arg2])

    pass


# Generated at 2022-06-25 17:56:27.594105
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    test_case_0()


# Generated at 2022-06-25 17:56:40.777310
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from json import dumps, loads
    from os import devnull
    from tempfile import NamedTemporaryFile

    from pygments.lexers import HttpLexer
    from pygments import highlight
    from pygments.formatters import TerminalFormatter
    from pygments.formatters.terminal256 import Terminal256Formatter
    from pygments.formatters.terminal import TerminalFormatter

    # Setup
    args = []
    kwargs = {}
    parser = HTTPieArgumentParser()
    # Exercise
    result = parser.parse_args(args, kwargs)
    # Verify
    assert type(result) == argparse.Namespace
    assert not result.headers
    assert result.output_options == 'hB'
    assert not result.prettify
    assert not result.style
    assert not result.style_path

# Generated at 2022-06-25 17:56:44.472399
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    try:
        h_t_t_pie_argument_parser_0.parse_args(['https://httpbin.org/get', 'Accept:application/json'])
    except:
        pass


# Generated at 2022-06-25 17:56:49.383943
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    if __name__ == "__main__":
        args = __parser__.parse_args(['_unit_test_case_0'])


main = handle_default_options(test_HTTPieArgumentParser_parse_args)

if __name__ == "__main__":
    main()

# Generated at 2022-06-25 17:56:55.524867
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = h_t_t_pie_argument_parser_0.parse_args()
    assert args
    sys.exit(0)

if __name__ == "__main__":
    test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-25 17:57:06.519408
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    sys_arg_v = "python http.py"
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    try:
        h_t_t_pie_argument_parser_0.parse_args(sys_arg_v)
    except SystemExit:
        pass
    else:
        # If no exception is raised, then run test_case_0
        test_case_0()

# To run this test, uncomment the line below
#test_HTTPieArgumentParser_parse_args()

# To run this test, uncomment the lines below
#OUTPUT_OPTIONS = {'h', 'c', 'b', 't', 'H', 'u', 's', 'o', 'a'}
#test_case_0()

# vim: set sts=4 sw

# Generated at 2022-06-25 17:57:08.686111
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    argv = ['C:\\Users\\dev\\PycharmProjects\\httpie\\httpie\\parser.py']
    parser = HTTPieArgumentParser()
    parser.parse_args(argv)
    return parser.args


# Generated at 2022-06-25 17:57:10.800230
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    test_case_0()

if __name__ == '__main__':
    test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-25 17:57:14.414256
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    # Validate return type
    assert isinstance(h_t_t_pie_argument_parser_0.parse_args(), argparse.Namespace)


# Generated at 2022-06-25 17:58:20.956352
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

	# Create an instance of the class
	h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()

	# Invoke method parse_args
	try:
		ans = h_t_t_pie_argument_parser_1.parse_args()
	except Exception as e:
		print('[!] Test Failed: parse_args')

	# Check if the result is as expected
	if ans == None:
		print('[+] Test Passed: parse_args')
	else:
		print('[!] Test Failed: parse_args')


# Generated at 2022-06-25 17:58:32.013990
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    argv = ['./http-0.9.9', '--auth-type', 'abc', '--auth', 'abc:abc', 'http://wiki.jikexueyuan.com/project/httpie/quickstart.html']
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    (args, _) = h_t_t_pie_argument_parser_0.parse_args(argv)
    assert args.auth_type == 'abc'
    assert args.auth == 'abc:abc'
    assert args.url == 'http://wiki.jikexueyuan.com/project/httpie/quickstart.html'


# Generated at 2022-06-25 17:58:40.461094
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    assert 'http' == h_t_t_pie_argument_parser_0.prog
    # TODO: fill in the rest of this test case.
    # http: error: no such option: -d
    # http: error: the following arguments are required: url
    # http: error: the following arguments are required: url

    # This is a bit tricky. For example running
    # http GET url 'Content-Type: application/json' header2: header2-value
    # will result in the following:
    # - URL is in 'method' instead of 'url'
    # - 'Content-Type: application/json' is in 'url' instead of 'headers'
    # - 'header2: header2-value' is in 'headers'

# Generated at 2022-06-25 17:58:44.461093
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    option1 = "foo"
    args1 = ['bar']
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_1.parse_args(args1, option1)


# Generated at 2022-06-25 17:58:46.285648
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--version'])
    assert args.version

# Generated at 2022-06-25 17:58:54.916570
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test that args.method is set to the default value of HTTP_GET
    # when invoked as http URL
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.args = h_t_t_pie_argument_parser_0.parse_args()
    assert h_t_t_pie_argument_parser_0.args.method == HTTP_GET

    # Test that args.method is set to HTTP_GET when
    # invoked as http URL
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_1.args = h_t_t_pie_argument_parser_1.parse_args(['https://httpbin.org/get'])


# Generated at 2022-06-25 17:59:05.730973
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    url = 'http://httpbin.org/get'
    args = []
    return_value = h_t_t_pie_argument_parser_0.parse_args(args)
    assert return_value.url == url
    assert return_value.method == 'GET'
    assert return_value.headers == {}
    assert return_value.request_items == []

    args = [url, 'X-test-header:test-value']
    return_value = h_t_t_pie_argument_parser_0.parse_args(args)
    assert return_value.url == url
    assert return_value.method == 'GET'
    assert return_value.headers['X-test-header'] == 'test-value'
    assert return_value.request_items == []


# Generated at 2022-06-25 17:59:11.135604
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    print("\nInput for method parse_args of class HTTPieArgumentParser")
    print("http --form POST example.org hello=world")
    print("\nOutput for method parse_args of class HTTPieArgumentParser")
    print(h_t_t_pie_argument_parser_0.parse_args("http --form POST example.org hello=world"))


# Generated at 2022-06-25 17:59:15.548906
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_1 = HTTPieArgumentParser()
    # Missing requirement: sys.argv
    # testing if ValueError was raised
    try:
        httpie_argument_parser_1.parse_args()
    except ValueError as e:
        print("Assertion passed: \"sys.argv\" is needed")


# Generated at 2022-06-25 17:59:17.122871
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.parse_args()
    # ...


# Generated at 2022-06-25 18:01:21.802691
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    str__args = ["-v", "localhost:9000", "hello=world"]
    str__kwargs = None
    str__kwargs = {}
    h_t_t_pie_argument_parser_0.parse_args(str__args, str__kwargs)


# Generated at 2022-06-25 18:01:27.659217
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie import __main__
    import pprint
    pp = pprint.PrettyPrinter()

    args = __main__.parse_args([
        '--headers',
        'a:b',
        '--form',
        'c=d',
        'https://httpbin.org/post',
    ])
    pp.pprint(args)

if __name__ == '__main__':
    test_case_0()
    test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-25 18:01:30.995395
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
    a_r_g_m_e_n_t_p_a_r_s_e_r_2 = a_r_g_m_e_n_t_p_a_r_s_e_r_1.parse_args(["--help"])


# Generated at 2022-06-25 18:01:36.976210
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    print("Testing parse_args")
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.parse_args(["--auth", 'kC'])

if __name__ == "__main__":
    test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-25 18:01:47.939799
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_2 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_3 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_4 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_5 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_6 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_7 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_8 = HTTPieArgumentParser()
   

# Generated at 2022-06-25 18:01:50.354996
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
    args = h_t_t_pie_argument_parser_1.parse_args()


# Generated at 2022-06-25 18:02:02.419904
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Invoke method
    args = h_t_t_pie_argument_parser_0.parse_args(["-v","--traceback", "GET", "http://httpbin.org/get"])
    # Verify Expected vs. Actual
    assert "GET" == args.method, "args.method == GET"
    assert "http://httpbin.org/get" == args.url, "args.url == http://httpbin.org/get"

    # Invoke method
    args = h_t_t_pie_argument_parser_0.parse_args(["GET", "http://httpbin.org/get"])
    # Verify Expected vs. Actual
    assert "GET" == args.method, "args.method == GET"

# Generated at 2022-06-25 18:02:05.692065
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    args = h_t_t_pie_argument_parser_0.parse_args()


# Generated at 2022-06-25 18:02:07.043795
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    pass


# Generated at 2022-06-25 18:02:14.455124
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    argv = ["http", "--traceback", "--check-status", "--check-certificate", "https://httpbin.org/", "Host: httpbin.org"]
    parser = HTTPieArgumentParser()
    parse_result = parser.parse_args(argv)
    assert isinstance(parse_result, Namespace)
    assert parse_result.url == "https://httpbin.org/"
    assert parse_result.headers == ['Host: httpbin.org']
    assert parse_result.auth is None
    assert parse_result.auth_type is None
    assert parse_result.auth_plugin is None
    assert parse_result.traceback, "traceback should be enabled"
    assert parse_result.check_status, "status code checking should be enabled"