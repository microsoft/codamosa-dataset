

# Generated at 2022-06-25 17:55:03.526150
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    print('Testing Unit Test HTTPieArgumentParser parse_args...')
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    args = [ '--help' ]
    h_t_t_pie_argument_parser_0.parse_args(args=args)
    print('Unit test for parse_args successful...')


# Generated at 2022-06-25 17:55:14.462641
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    print("Testing parse_args")
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    arg_parse_0 = argparse.ArgumentParser()
    sys_argv_0 = sys.argv
    try:
        sys.argv = [sys.argv[0], '-p', 'all', 'https://httpbin.org/get']
        args_0 = h_t_t_pie_argument_parser_0.parse_args(arg_parse_0)
        if args_0.output_options != '':
            raise RuntimeError('assert 1 <0> failed')
    finally:
        sys.argv = sys_argv_0


# Generated at 2022-06-25 17:55:20.923745
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    print("\nUnit test for method parse_args of class HTTPieArgumentParser")
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.parse_args([])
    h_t_t_pie_argument_parser_0.parse_args(['--help'])

# Code for running the unit test for method parse_args of class HTTPieArgumentParser
test_HTTPieArgumentParser_parse_args()


# Generated at 2022-06-25 17:55:31.610527
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    global issue_869_seen, issue_1244_seen, issue_1244_warning_seen, issue_1322_seen, issue_1389_seen, issue_1449_seen, issue_1462_seen, issue_1566_seen, issue_1569_seen, issue_1570_seen, issue_1636_seen, issue_1639_seen, issue_1640_seen, issue_1641_seen, issue_1642_seen, issue_1643_seen, issue_1644_seen, issue_1645_seen, issue_1653_seen, issue_1654_seen, issue_1655_seen, issue_1656_seen, issue_1657_seen, issue_1658_seen, issue_1659_seen, issue_1660_seen, issue_1661_seen, issue_1662_seen

# Generated at 2022-06-25 17:55:33.276571
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    args = '-v'
    result = h_t_t_pie_argument_parser_0.parse_args(shlex.split(args))
    print("result = " + str(result))

# Generated at 2022-06-25 17:55:44.742108
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with a null argument
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    assert h_t_t_pie_argument_parser_0.parse_args(( () )) == False

    # Test with a single string argument
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
    args_1 = h_t_t_pie_argument_parser_1.parse_args( ("-v"))
    assert args_1.verbose == True
    assert args_1.method == "GET"
    assert args_1.url == None
    assert args_1.ignore_stdin == False
    assert args_1.headers == {}
    assert args_1.data == None
    assert args_1.files == []
    assert args_1.params == {}

# Generated at 2022-06-25 17:55:47.731040
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_1.parse_args()


# Generated at 2022-06-25 17:55:49.967081
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO: figure out a way to test this method.
    test_case_parse_args_0()


# Generated at 2022-06-25 17:56:00.031861
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.parse_args()
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_1.parse_args()
    h_t_t_pie_argument_parser_1.parse_args(['-h'])
    h_t_t_pie_argument_parser_1.parse_args(['--help'])
    h_t_t_pie_argument_parser_2 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_2.parse_args(['--version'])


# Generated at 2022-06-25 17:56:02.682479
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.parse_args()


# Generated at 2022-06-25 17:56:42.721722
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """
    Unit test for method parse_args of class HTTPieArgumentParser
    """
    httpie_parser = HTTPieArgumentParser()
    test_args = ['-A', 'test_agent', '-b', 'key=val']
    test_args_result = httpie_parser.parse_args(test_args)
    test_args_expected = ['key=val']
    assert test_args_result.headers == test_args_expected


# Generated at 2022-06-25 17:56:48.171628
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_TTPieArgumentParser_0 = HTTPieArgumentParser()
    h_TTPieArgumentParser_0.parse_args()


# Generated at 2022-06-25 17:56:53.806634
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_0 = HTTPieArgumentParser()
    httpie_argument_parser_0.parse_args()
    httpie_argument_parser_0.parse_args(['http', '--help'])

test_case_0()

# Generated at 2022-06-25 17:57:05.502456
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    # Case 0
    httpie_argument_parser_0 = HTTPieArgumentParser()
    args_0 = httpie_argument_parser_0.parse_args(['--output', 'out_0.png', '-b', '-i', '--timeout', '3'])

    # Case 1
    httpie_argument_parser_1 = HTTPieArgumentParser()
    args_1 = httpie_argument_parser_1.parse_args(['--output', 'out_1.png', '--form', '-i', '--timeout', '3'])

    # Case 2
    httpie_argument_parser_2 = HTTPieArgumentParser()

# Generated at 2022-06-25 17:57:13.601667
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    t_h_i_n_k_i_e_s_client_http_0 = HTTPie(
        _default_options=DEFAULT_OPTIONS,
        _plugins=('h_t_t_p_i_e_plugins_manager.HTTPiePluginManager', None),
        _test_case=test_case_0)

# Generated at 2022-06-25 17:57:25.371431
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    # HTTPieArgumentParser.parse_args(data=None, request_items=None)
    # -> namespace
    try:
        h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
        h_t_t_pie_argument_parser_0.parse_args(data=None, request_items=None)
        # assert(h_t_t_pie_argument_parser_0.get_default('request_items') == None)
    except Exception as e:
        print(str(e))
        print('expected exception: {}'.format(e))
        traceback.print_exc()
        return False
    else:
        return True


# Generated at 2022-06-25 17:57:35.518266
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser(prog='http', add_help=False)
    try:
        h_t_t_pie_argument_parser_0.parse_args(['https://example.com/'])
        assert False
    except SystemExit:
        pass
    try:
        h_t_t_pie_argument_parser_0.parse_args(['http://example.com/'])
        assert False
    except SystemExit:
        pass
    try:
        h_t_t_pie_argument_parser_0.parse_args(['http://example.com/'])
        assert False
    except SystemExit:
        pass


# Generated at 2022-06-25 17:57:47.909867
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-25 17:57:57.809053
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser_0 = HTTPieArgumentParser()
    parser_0.parse_args()
    parser_1 = HTTPieArgumentParser()
    parser_1.parse_args(['-h'])
    parser_2 = HTTPieArgumentParser()
    parser_2.parse_args(['--help'])
    parser_3 = HTTPieArgumentParser()
    parser_3.parse_args(['--manual'])
    parser_4 = HTTPieArgumentParser()
    parser_4.parse_args(['--version'])
    parser_5 = HTTPieArgumentParser()
    parser_5.parse_args(['--ignore-stdin'])
    parser_6 = HTTPieArgumentParser()
    parser_6.parse_args(['--verbose'])
    parser_7 = HTTPieArgumentParser

# Generated at 2022-06-25 17:58:10.551145
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser_0 = HTTPieArgumentParser()
    parser_0._print_message(message='wqwq', file='wqwq')
    parser_0._setup_standard_streams()
    parser_0._process_auth()
    parser_0._apply_no_options(no_options=['--no-OPTION'])
    parser_0._body_from_file(fd='wqwq')
    parser_0._guess_method()
    parser_0._parse_items()
    parser_0._process_output_options()
    parser_0._process_pretty_options()
    parser_0._process_download_options()
    parser_0._process_format_options()

if __name__ == "__main__":
    test_case_0()
    test_HTTPieArgumentParser

# Generated at 2022-06-25 17:59:14.163164
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    import sys
    args = parser.parse_args(sys.argv[1:])

if __name__ == "__main__":
    test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-25 17:59:18.222333
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_0 = HTTPieArgumentParser()
    try:
        httpie_argument_parser_0._parse_args()
    except TypeError as type_error_0:
        print("TypeError raised during method invocation: " +str(type_error_0))
    return



# Generated at 2022-06-25 17:59:22.814896
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    try:
        h_t_t_pie_argument_parser_0.parse_args()
    except SystemExit as e:
        assert e.code == 2
    else:
        raise AssertionError

# Generated at 2022-06-25 17:59:27.211669
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Testing HTTPieArgumentParser.parse_args method
    httpie_argument_parser_test_1 = HTTPieArgumentParser(dict(), 'http', 'http-description')

# Generated at 2022-06-25 17:59:33.223841
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Assert no error occured when calling the function.
    try:
        parser = HTTPieArgumentParser()
        parser.parse_args()
    except Exception as e:
        assert False, f"Error occured when calling the function: {e}"

# Assert that the parse_args function returns a non-empty "args" object

# Generated at 2022-06-25 17:59:42.816046
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    HTTPieArgumentParser_parse_args_0 = HTTPieArgumentParser()
    HTTPieArgumentParser_parse_args_0.parse_args()
    HTTPieArgumentParser_parse_args_1 = HTTPieArgumentParser()
    HTTPieArgumentParser_parse_args_1.parse_args(['url'])
    HTTPieArgumentParser_parse_args_2 = HTTPieArgumentParser()
    HTTPieArgumentParser_parse_args_2.parse_args(['url', 'method'])
    HTTPieArgumentParser_parse_args_3 = HTTPieArgumentParser()
    HTTPieArgumentParser_parse_args_3.parse_args(['url', 'method', 'path'])

# Generated at 2022-06-25 17:59:52.244216
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-25 17:59:54.207225
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    check_for_possible_httpie_cmd()


# Generated at 2022-06-25 18:00:04.872618
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    '''
    Method parse_args of class HTTPieArgumentParser
    '''
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0._parse_args()
    h_t_t_pie_argument_parser_0._parse_args()
    h_t_t_pie_argument_parser_0.add_argument("--form", "--form")
    h_t_t_pie_argument_parser_0.add_argument("--style", "--style")
    h_t_t_pie_argument_parser_0.add_argument("--print", "--print")
    h_t_t_pie_argument_parser_0.add_argument("--auth", "--auth")
    h_t_t_pie

# Generated at 2022-06-25 18:00:09.368050
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser_0 = HTTPieArgumentParser()
    parser_argv_0 = ["http", "-o stdout:ext:json", "google.com"]
    parser_result_0 = parser_0.parse_args(parser_argv_0)


# Generated at 2022-06-25 18:02:37.158712
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser_0 = HTTPieArgumentParser()
    parser_1 = HTTPieArgumentParser(add_help=False)

    # Test whether parsing args works as expected
    parser_2 = HTTPieArgumentParser(add_help=False)
    args_0 = parser_2.parse_args()
    assert args_0.help == False
    assert args_0.version == False
    assert args_0.debug == False
    assert args_0.traceback == False
    assert args_0.download == False
    assert args_0.download_resume == False
    assert args_0.offline == False
    assert args_0.ignore_stdin == False
    assert args_0.ignore_netrc == False
    assert args_0.no_session_cookies == False
    assert args_0.session_read_only

# Generated at 2022-06-25 18:02:46.384505
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args0 = ['/usr/local/bin/http', '--ignore-stdin', 'httpbin.org/post', 'foo=bar']
    a_r_g_s0 = ArgumentParser().parse_args(args0)
    print(a_r_g_s0)
    h_a_p0 = HTTPieArgumentParser()
    h_a_p0.add_argument('--ignore-stdin', action='store_true')
    h_a_p0.add_argument('--follow', action='store_true')
    h_a_p0.add_argument('--max-redirects', type=int)
    h_a_p0.add_argument('--timeout', type=float)

# Generated at 2022-06-25 18:02:52.091132
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.add_argument('-a', '--auth', type=parse_auth,
                        help='Use HTTP Basic/Digest Authentication')
    parsed_args = parser.parse_args(['--auth', 'myuser:mypass'])
    action, = parser._actions
    # Parsing the arguments sets the object returned by the action
    # with the value specified
    assert parsed_args.auth is action.const



# Generated at 2022-06-25 18:02:56.135437
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args()


# Generated at 2022-06-25 18:03:04.885180
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    a_HTTPieArgumentParser_0 = HTTPieArgumentParser()
    # Test trigger exception and pass
    try:
        a_HTTPieArgumentParser_0.parse_args()
    except SystemExit:
        pass
    try:
        a_HTTPieArgumentParser_0.parse_args(["http://www.baidu.com"])
    except SystemExit:
        pass
    try:
        a_HTTPieArgumentParser_0.parse_args(["http://www.baidu.com", "a=1", "b=2", "id=1", "name=xiaoming"])
    except SystemExit:
        pass


# Generated at 2022-06-25 18:03:10.803524
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    HTTPieArgumentParser_parse_args_0 = HTTPieArgumentParser(usage=None, prog=None, epilog=None, description=None, formatter_class=None, conflict_handler=None, prefix_chars=None, fromfile_prefix_chars=None, argument_default=None, add_help=True)
    HTTPieArgumentParser_parse_args_0.parse_args([])


# Generated at 2022-06-25 18:03:12.481002
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    ap = HTTPieArgumentParser()
    args = ap.parse_args(())


# Generated at 2022-06-25 18:03:15.702184
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args("httpie://example.com/test")
    print("test_HTTPieArgumentParser_parse_args: " + args.method + " " + args.url)


# Generated at 2022-06-25 18:03:19.206091
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test #0: Initialization
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.parse_args(['http', 'http://httpbin.org/get'])


# Generated at 2022-06-25 18:03:20.751770
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.parse_args()
