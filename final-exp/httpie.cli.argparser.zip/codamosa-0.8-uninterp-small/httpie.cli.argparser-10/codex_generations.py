

# Generated at 2022-06-25 17:55:07.994463
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = "http://127.0.0.1/get".split(' ')
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    result = h_t_t_pie_argument_parser_0.parse_args(args)


# Generated at 2022-06-25 17:55:12.641939
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    try:
        h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
        args = h_t_t_pie_argument_parser_0.parse_args([])
        print(args)
    except SystemExit as e:
        assert e.code == 0


# Generated at 2022-06-25 17:55:15.114057
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    # AssertionError: # TODO: implement test
    raise Exception("Test unimplemented")

# Generated at 2022-06-25 17:55:18.775288
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.parse_args()


# Generated at 2022-06-25 17:55:23.508273
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # print(sys.argv)
    if len(sys.argv) < 2:
        return

    if sys.argv[1] == "test_case_0":
        h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
        try:
            test_case_0()
        except Exception as e:
            print(e)


if __name__ == "__main__":
    test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-25 17:55:28.471037
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    if not os.path.isfile(OUTPUT_FILE):
        return
    try:
        with open(OUTPUT_FILE, 'r') as f:
            for line in f.readlines():
                if line.startswith('test_case_'):
                    eval(line)
    except Exception as e:
        print(str(e))
        os.system('rm -f '+OUTPUT_FILE)
        assert False

test_HTTPieArgumentParser_parse_args()
# print(HTTPieArgumentParser.__subclasses__())

# Generated at 2022-06-25 17:55:31.437772
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    print("Testing method parse_args")
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    try:
        h_t_t_pie_argument_parser_0.parse_args()
    except Exception as e:
        print(str(e))
        assert(str(e) == 'The following arguments are required: [URL]')


# Generated at 2022-06-25 17:55:35.378153
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    method = h_t_t_pie_argument_parser_0.parse_args
    args = []
    expected_exception = None
    expected_result = None

# This method calls a method in a class

# Generated at 2022-06-25 17:55:38.210778
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_1.parse_args()


# Generated at 2022-06-25 17:55:48.268490
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()

    list_0 = [ ]
    list_1 = [ '-h' ]
    list_2 = [ '--headers' ]

    str_0 = h_t_t_pie_argument_parser_0.parse_args(list_0)
    str_1 = h_t_t_pie_argument_parser_0.parse_args(list_1)
    str_2 = h_t_t_pie_argument_parser_0.parse_args(list_2)

    assert str_0 == None
    assert str_1 == None
    assert str_2 == None

# Generated at 2022-06-25 17:56:51.759541
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    #
    # Testing the following exceptions:
    #
    args_0 = [
    ]
    exc_0 = AssertionError
    try:
        h_t_t_pie_argument_parser_0.parse_args(args=args_0)
    except exc_0:
        pass
    else:
        assert False
    #
    # Testing the following exceptions:
    #
    args_0 = [
        'h'
    ]
    exc_0 = AssertionError
    try:
        h_t_t_pie_argument_parser_0.parse_args(args=args_0)
    except exc_0:
        pass
    else:
        assert False
    #
    # Testing the following

# Generated at 2022-06-25 17:57:04.788133
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    command_line = ['http', '', '', '', '', '', '', '', '', '']
    # 0 = error code, 1 = validated_args, 2 = error_msg
    try:
        httpie_arg_parse = h_t_t_pie_argument_parser_0.parse_args(command_line)
        print("0 = error code, 1 = validated_args, 2 = error_msg")
        print(httpie_arg_parse)
    except SystemExit as e:
        print(e.code)
        print(e.message)
        print(e.args)
        print(e.__dict__)

if __name__ == "__main__":
    test_HTTPieArgumentParser_parse

# Generated at 2022-06-25 17:57:13.106027
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    #Test 0: test normal way of parsing
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    args = h_t_t_pie_argument_parser_0.parse_args(['--version'])
    print(args)
    assert args.version == True

    args = h_t_t_pie_argument_parser_0.parse_args(['--debug'])
    assert args.debug == True

    args = h_t_t_pie_argument_parser_0.parse_args(['--default-scheme=git'])
    assert args.default_scheme == 'git'

    args = h_t_t_pie_argument_parser_0.parse_args(['--download'])
    assert args.download == True

    args = h_t_t_pie

# Generated at 2022-06-25 17:57:17.284836
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()
    assert h_t_t_pie_argument_parser_1.parse_args() is not None


# Generated at 2022-06-25 17:57:20.348440
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_1 = HTTPieArgumentParser()

    # No exception raised, test passed.
    assert True

# Generated at 2022-06-25 17:57:25.919094
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # noinspection PyUnresolvedReferences
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser() # Type is HTTPieArgumentParser
    # noinspection PyTypeChecker
    args = h_t_t_pie_argument_parser_0.parse_args()



# Generated at 2022-06-25 17:57:36.528990
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.env.stdin = BytesIO()
    h_t_t_pie_argument_parser_0.env.stdin_isatty = True
    h_t_t_pie_argument_parser_0.env.stdout = BytesIO()
    h_t_t_pie_argument_parser_0.args = argparse.Namespace()
    h_t_t_pie_argument_parser_0.args.traceback = False
    h_t_t_pie_argument_parser_0.args.debug = False
    h_t_t_pie_argument_parser_0.extra_args = []

# Generated at 2022-06-25 17:57:48.280829
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """
    Test parse_args method of class HTTPieArgumentParser
    """
    # FIXME
    args = ['--traceback', '--json', '--pretty', 'all', '-v', 'http://www.baidu.com']
    #arg_parser = HTTPieArgumentParser()
    #arg_parser.parse_args(args)

    #print(arg_parser.args)
    #args = arg_parser.parse_args()
    #arg_parser = HTTPieArgumentParser(args)
    #arg_parser.args = arg_parser.parse_args(args)
    #arg_parser.args = arg_parser.parse_known_args(args)[0]
    #print(arg_parser.args)


# Generated at 2022-06-25 17:57:53.198276
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    (args, env) = h_t_t_pie_argument_parser_0.parse_args(
        ['--output=test_data_output'])
    if (args.output == 'test_data_output'):
        pass


# Generated at 2022-06-25 17:57:59.223737
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    HTTPieArgumentParser()
    res = HTTPieArgumentParser.parse_args('"GET', 'https://httpbin.org/get')
    print(res)
    #parse_args
    #p = HTTPieArgumentParser()
    #p.parse_args('"GET', 'https://httpbin.org/get')

test_HTTPieArgumentParser_parse_args()

if __name__ == '__main__':
    import pytest
    pytest.main("C:\\Users\\gagan\\PycharmProjects\\Testing\\test.py")

# Generated at 2022-06-25 17:59:47.993148
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO: unit test this
    pass


# Generated at 2022-06-25 17:59:51.268088
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser = HTTPieArgumentParser()
    args = []
    h_t_t_pie_argument_parser.parse_args(args)
    h_t_t_pie_argument_parser.parse_auth()


# Generated at 2022-06-25 17:59:55.324898
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
    h_t_t_pie_argument_parser_0.parse_args()

if __name__ == '__main__':
    test_case_0()
    test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-25 18:00:00.799489
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    try:
        # Setup test case
        httpie_argument_parser_0 = HTTPieArgumentParser()
        # Exercise SUT
        test_case_0()

    except Exception as err:
        print("Caught exception: " + str(err))
        # Teardown test case
        teardown_test_case_0()
        assert False


# Generated at 2022-06-25 18:00:02.078476
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    test_case_0()


# Generated at 2022-06-25 18:00:06.582669
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Create a HTTPieArgumentParser object
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()

    # Call parse_args method for HTTPieArgumentParser object
    h_t_t_pie_argument_parser_0.parse_args()


# Generated at 2022-06-25 18:00:08.936664
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    test_case_0()

if __name__ == '__main__':
    test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-25 18:00:19.008716
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    def test_case_0():
        h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()
        args_0 = ['--ignore-stdin', '-b', '--traceback', '-e']
        namespace_0 = h_t_t_pie_argument_parser_0.parse_args(args_0)
        assert namespace_0.debug == False
        assert namespace_0.download == False
        assert namespace_0.download_resume == False
        assert namespace_0.env_auth == False
        assert namespace_0.verbose == False
        assert namespace_0.pretty == None
        assert namespace_0.output_options == None
        assert namespace_0.output_options_history == None
        assert namespace_0.output_file == None
        assert namespace_0.output_file_

# Generated at 2022-06-25 18:00:20.850065
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    test_case_0()

if __name__ == '__main__':
    test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-25 18:00:26.622867
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser_0 = HTTPieArgumentParser()
    # Test cases
    # 1
    if (httpie_argument_parser_0.parse_args(['http', 'http://example.com']) != 0):
        raise Exception # TODO: implement your test here
    # 2
    if (httpie_argument_parser_0.parse_args(['http', '--help']) != 0):
        raise Exception # TODO: implement your test here
    # 3
    if (httpie_argument_parser_0.parse_args(['http', '--version']) != 0):
        raise Exception # TODO: implement your test here
    # 4
    if (httpie_argument_parser_0.parse_args(['http', '--traceback']) != 0):
        raise Exception # TODO: implement your

# Generated at 2022-06-25 18:02:53.639293
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    HTTPieArgumentParser_obj = HTTPieArgumentParser()
    self_argument_parser_obj = argparse.ArgumentParser()
    test_args = self_argument_parser_obj.parse_args(args=['https://www.google.com','--headers','X-ABC-Header','User:me'])
    assert (HTTPieArgumentParser_obj.parse_args(argparse.Namespace(argv=test_args.argv), self_argument_parser_obj),argparse.Namespace(argv=test_args.argv)) == (argparse.Namespace(argv=[
    'https://www.google.com',
    '--headers',
    'X-ABC-Header',
    'User:me']),argparse.Namespace(argv=test_args.argv))

# Generated at 2022-06-25 18:02:59.371426
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-25 18:03:03.942430
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    # assert parser.parse_args(['http://google.com', 'user-agent:Httpie']) is not None

if __name__ == '__main__':
    # test_HTTPieArgumentParser_parse_args()
    test_case_0()

# Generated at 2022-06-25 18:03:13.399867
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.parse_args(['--traceback'])
    parser.parse_args(['https://httpbin.org', 'User-Agent:httpie'])
    parser.parse_args(['https://httpbin.org/post', 'User-Agent:httpie',
                       '--form'])
    parser.parse_args(['https://httpbin.org/post', 'User-Agent:httpie',
                       '--form', 'name=John'])
    parser.parse_args(['https://httpbin.org/post', 'User-Agent:httpie',
                       '--form', 'name=John', '--output=foo.txt'])

# Generated at 2022-06-25 18:03:16.330836
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    argv = ['--help']
    try:
        HTTPieArgumentParser().parse_args(argv)
    except SystemExit:
        pass
    else:
        assert False

# Generated at 2022-06-25 18:03:18.713722
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    test_argv = ['request', 'https://www.google.com']
    parser = HTTPieArgumentParser()
    parser.parse_args(test_argv)


# Generated at 2022-06-25 18:03:29.905727
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Initialize a HTTPieArgumentParser object
    argument_parser = HTTPieArgumentParser()

    print('Test `optparse` argument parser with arguments:')
    print('##########################################')
    print('http httpbin.org/get name==foo')
    print('http httpbin.org/get -p "name==foo"')
    print('http --form httpbin.org/post name=foo')
    print('http --form httpbin.org/post -d "name==foo"')
    print('http --form httpbin.org/post -f "name==foo"')
    print('http --form httpbin.org/post name==foo')
    print('http --form httpbin.org/post "name==foo"')
    print('http --form httpbin.org/post name="foo bar"')

# Generated at 2022-06-25 18:03:31.660785
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h_t_t_pie_argument_parser_0 = HTTPieArgumentParser()

# Generated at 2022-06-25 18:03:39.498242
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    test_parse_args_0()
    test_parse_args_1()
    test_parse_args_2()
    test_parse_args_3()
    test_parse_args_4()
    test_parse_args_5()
    test_parse_args_6()
    test_parse_args_7()
    test_parse_args_8()
    test_parse_args_9()
    test_parse_args_10()
    test_parse_args_11()
    test_parse_args_12()
    test_parse_args_13()
    test_parse_args_14()
    test_parse_args_15()
    test_parse_args_16()
    test_parse_args_17()
    test_parse_args_18()
    test_parse_args_19()

# Generated at 2022-06-25 18:03:41.942852
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    test_HTTPieArgumentParser_parse_args_0()
    # test_HTTPieArgumentParser_parse_args_1()
    # test_HTTPieArgumentParser_parse_args_2()
