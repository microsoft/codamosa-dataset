

# Generated at 2022-06-11 22:47:24.582599
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = argparse.Namespace()
    parser = HTTPieArgumentParser()
    parser.parse_args(args)


# Generated at 2022-06-11 22:47:36.435620
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test for Method parse_args of Class HTTPieArgumentParser

    # Arrange
    # Create the parser and parse the given args
    arguments = ['https://httpbin.org/get', '-kd', 'jack=nicholson', '-j', 'Joker']
    parser = HTTPieArgumentParser(args=arguments)
    arg_holder = parser.parse_args()

    # Act
    # Get the expected result
    expected = argparse.Namespace()
    expected.headers = {}
    expected.output_file = None
    expected.request_items = []
    expected.auth = None
    expected.auth_plugin = None
    expected.auth_type = None
    expected.auth_host = None
    expected.http_auth = None
    expected.proxy_auth = None

# Generated at 2022-06-11 22:47:43.908611
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    env = Environment(stdin=StdinBytesIO())
    parser = HTTPieArgumentParser(env=env)
    args = parser.parse_args(args=['-h'])
    assert args.headers == [
        'colon-separated: values',
    ]
    args = parser.parse_args(args=['-h', 'colon-separated: yes'])
    assert args.headers == [
        'colon-separated: values',
        'colon-separated: yes'
    ]
    with pytest.raises(SystemExit):
        args = parser.parse_args(args=['--ignore-stdin', '@data.json'])
    env = Environment(stdin=StdinBytesIO(b'{}'))
    parser = HTTPieArgumentParser(env=env)
   

# Generated at 2022-06-11 22:47:54.939428
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test presence of mandatory keys
    params = dict(process_kwargs=dict(args=['foo', 'bar']))

# Generated at 2022-06-11 22:48:06.796261
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    #test_HTTPieArgumentParser_parse_args
    parser  = HTTPieArgumentParser()
    result = parser.parse_args()
    assert type(result).__name__ == 'Namespace',\
            'Parse args result should be a Namespace, but was ' + type(result).__name__
    assert result.json == False, 'Default json should be False. It was ' + str(result.json)
    assert result.download == False, 'Default download should be False. It was ' + str(result.download)
    assert result.offline == False, 'Default offline should be False. It was ' + str(result.offline)
    assert result.ignore_stdin == False, 'Default ignore_stdin should be False. It was ' + str(result.ignore_stdin)

# Generated at 2022-06-11 22:48:10.649097
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO: implement test.
    # raise NotImplementedError("test_HTTPieArgumentParser_parse_args()")
    pass


# Generated at 2022-06-11 22:48:18.856256
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """Test parse_args() of HTTPieArgumentParser."""

    # Arrange
    httpie_argument_parser = HTTPieArgumentParser()

    # Act
    results = httpie_argument_parser.parse_args(['-h'])

    # Assert
    assert isinstance(results, argparse.Namespace)
    assert results.headers == []
    assert results.files == {}
    assert results.method is None
    assert results.params == []
    assert results.data == []
    assert results.error_response_headers is None
    assert results.insecure is False
    assert results.prettify is None
    assert results.suppress_connect_tunneling_warning is None
    assert results.timeout == DEFAULT_TIMEOUT
    assert results.auth_plugin is None

# Generated at 2022-06-11 22:48:24.764253
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['GET', 'http://httpbin.org/anything'])
    print('args:', args)
    
    args = parser.parse_args(['GET', 'http://httpbin.org/anything'])
    print('args:', args)
    

# Generated at 2022-06-11 22:48:34.543306
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    class Mock(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)
    args = Mock(headers=[], output_options=None, download=False, download_resume=False)
    args.auth = None
    args.auth_type = None
    args.json = Mock()
    args.json.dumps = json.dumps
    args.method = None
    args.multipart_data = None
    args.request_items = [KeyValueArgType(
            *SEPARATOR_GROUP_ALL_ITEMS).__call__('name=Samuel')]
    args.scope = None
    args.url = "http://www.google.com"
    args.auth_plugin = None
    args.data = Mock()
    args.data_and_files

# Generated at 2022-06-11 22:48:39.033882
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.add_argument('-i', '--include', action='store_true')
    parser.add_argument('-v', '--verbose', action='store_true')
    args = parser.parse_args(['-iv'])
    assert args.include
    assert args.verbose
    

# Generated at 2022-06-11 22:49:34.280621
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    with responses.RequestsMock() as rsps:
        rsps.add(
            desc="GET /get?foo=bar",
            method="GET",
            url=VCRHTTPBIN_URL + "/get?foo=bar",
            json={
                "args": {"foo": "bar"},
                "headers": {
                    "Accept": "application/json",
                    "Accept-Encoding": "gzip, deflate",
                    "Host": "httpbin.org",
                    "User-Agent": "HTTPie/1.0.0",
                },
                "origin": "87.89.69.189, 87.89.69.189",
                "url": "https://httpbin.org/get?foo=bar",
            },
        )

# Generated at 2022-06-11 22:49:43.889558
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    try:
        # args = parser.parse_args([])
        args = parser.parse_args(['-j', 'GET'])
        print(args)
    except Error as e:
        print(e.args[0])
        sys.exit(1)
    
    
test_HTTPieArgumentParser_parse_args()


# Generated at 2022-06-11 22:49:53.526978
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = HTTPieArgumentParser(add_help=False).parse_args([
        'GET', 'httpbin.org', 'Accept:'
    ])
    assert args.method == 'GET'
    assert args.url == 'httpbin.org'
    assert args.headers == [KeyValueArg('Accept', '')]

    # Allow intermixed positional and keyword arguments.
    args = HTTPieArgumentParser(add_help=False).parse_args([
        '--form', 'foo=bar',
        'httpbin.org', 'baz', 'buzz:fizz'
    ])
    assert args.method == 'POST'
    assert args.url == 'httpbin.org'
    assert args.headers == [KeyValueArg('baz', ''), KeyValueArg('buzz', 'fizz')]

# Generated at 2022-06-11 22:50:05.302860
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test the method parse_args of class HTTPieArgumentParser with valid input
    # Test 1
    # In this case, the content of the file we put in stdin is passed as the body of an HTTP request.
    # Test 1.1
    # Test the case with not '--verify' option
    test_file = os.path.join(
        os.path.dirname(__file__), 'test_httpie_api_unittest.txt')
    # Set the argument list into the list which contains ['--ignore-stdin', 'GET', 'http://httpbin.org/get']
    arguments = ['--ignore-stdin', 'GET', 'http://httpbin.org/get']
    sys.argv = arguments
    # Test stdin = ''.encode('utf-8')
    stdin = ''.encode

# Generated at 2022-06-11 22:50:15.676335
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test1: home path does not exist
    with patch('httpie.cli.argparser.os.path.expanduser',
               return_value='/home/ywang1090') as mock_expanduser:
        with patch('httpie.cli.argparser.os.path.exists',
                   return_value=False) as mock_exists:
            mock_sys = MagicMock()
            mock_sys.argv = ["http", "www.google.com"]
            with patch('httpie.cli.argparser.sys', mock_sys):
                with patch('httpie.cli.argparser.HTTPieArgumentParser'):
                    with pytest.raises(SystemExit) as ex_info:
                        HTTPieArgumentParser.parse_args()
                    assert ex_info.value.args[0] == 0


# Generated at 2022-06-11 22:50:26.121525
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO: Replace with a test that does not rely on the internet.
    kwargs = {
        'prog': 'http',
        'usage': '%(prog)s [OPTIONS] URL [REQUEST_ITEM [REQUEST_ITEM ...]]',
        'version': __version__,
        'env': Environment(),
        'args': [],
        'formatter_class': CustomHelpFormatter,
        'add_help': False,
        
        'conflict_handler': 'resolve',
        
        'prefix_chars': '-',
        'argument_default': None,
    }
    http_args = HTTPieArgumentParser(**kwargs)

# Generated at 2022-06-11 22:50:33.800113
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.add_argument("--foo")
    parser.add_argument("--bar", action="store_true")
    parser.add_argument("--baz", action="store_false")
    parser.add_argument("quux", nargs="?")
    parser.add_argument("corge")
    parser.add_argument("--grault", nargs=2)
    args = parser.parse_args(["--foo=1", "--bar", "--baz", "quux", "corge", "--grault", "g", "y", "--", "--not-an-opt"])
    assert args.foo == "1"
    assert args.bar is True
    assert args.baz is False
    assert args.quux is None

# Generated at 2022-06-11 22:50:40.846834
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie.core import main
    from httpie.core import http
    from httpie.core import json
    from httpie.core import __version__ as httpie_version

    # Using stdin
    file_to_write = "https://www.example.com/worker"
    input_http = "POST"
    input_http_headers = "Content-Type: application/json"
    input_http_data = '{"id":"2016001","first_name":"CC","last_name":"A"}'
    file_content = input_http + "\n" + input_http_headers + "\n" + input_http_data
    input_http_file = open(file_to_write, "w")
    input_http_file.write(file_content)
    input_http_file.close()
    input_http

# Generated at 2022-06-11 22:50:53.066929
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from json import loads

    with mock.patch('httpie.cli.argtypes.KeyValueArgType') as KVAT:
        kwargs = dict(
            prog='http',
            args=['GET', 'http://httpbin.org/get'],
        )
        parser = HTTPieArgumentParser(env=Environment(), **kwargs)
        args = parser.parse_args()
        assert args.method == 'GET'
        assert args.url == 'http://httpbin.org/get'
        assert KVAT.call_count == 0

    with mock.patch('httpie.cli.argtypes.KeyValueArgType') as KVAT:
        kwargs = dict(
            prog='http',
            args=['http://httpbin.org/get', 'foo==bar', 'baz=='],
        )

# Generated at 2022-06-11 22:50:59.563096
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    arg1 = "--auth tokens:FZ3o5/Yh5J5+dnbRvjX9JCuAPpDgVQLwZM+qZToqhFc="
    arg2 = "-X GET -v"
    arg3 = "-h 'Host: cmxlocationsandbox.cisco.com' -h 'Accept: application/json'"
    arg4 = "https://cmxlocationsandbox.cisco.com/api/config/v1/maps/info/DevNetCampus/DevNetBuilding/DevNetZone"
    arglist = [arg1, arg2, arg3, arg4]
    result = HTTPieArgumentParser(prog="Mock").parse_args(arglist)

# Generated at 2022-06-11 22:52:33.748936
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    arg_parser = HTTPieArgumentParser()
    args = arg_parser.parse_args(['httpie', '--version'])
    # Header order is not important
    assert_equal(sorted(args.__dict__.keys()), sorted(['version']))
    assert_equal(args.version, True)

    args = arg_parser.parse_args(['httpie', '--verbose'])
    assert_equal(sorted(args.__dict__.keys()), sorted(['verbose']))
    assert_equal(args.verbose, True)

    args = arg_parser.parse_args(['httpie', '--debug'])
    assert_equal(sorted(args.__dict__.keys()), sorted(['debug']))
    assert_equal(args.debug, True)

    args = arg_

# Generated at 2022-06-11 22:52:45.574756
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    app_parser = HTTPieArgumentParser()
    # unhandled_args = ['http', 'https://', 'http://']
    # args = app_parser.parse_args(unhandled_args)
    # print(args)
    # unhandled_args = ['http', 'GET', 'http://', '--form', 'para1=1', '--form', 'para2=2']
    # args = app_parser.parse_args(unhandled_args)
    # print(args)
    unhandled_args = ['http', 'GET', 'http://', '--form', 'para1=1', '--form', 'para2=2', '@/home/sjf0115/httpie/httpie/plugins/form.py']
    args = app_parser.parse_args(unhandled_args)

# Generated at 2022-06-11 22:52:52.845943
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    http = HTTPie()
    http_args = http.parse_args([
        'GET',
        'https://example.com',
        'Foo:Bar',
        'Baz:',
        'empty'
    ])
    assert http_args.url == 'https://example.com'
    assert http_args.headers['Foo'] == 'Bar'
    assert http_args.headers['Baz'] == ''
    assert http_args.data['empty'] == ''

# Generated at 2022-06-11 22:53:02.467415
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Unit test for method parse_args of class HTTPieArgumentParser
    from httpie.core import __version__
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.client import DEFAULT_VERIFY
    arguments = ['-v', '-vv', '--verbose',
        '--pretty', 'all', '--style', 'solarized',
        '--print', 'B',
        '--debug',
        'https://httpbin.org/get',
        'a==b', 'c==d', 'e==f'
    ]
    args = HTTPieArgumentParser().parse_args(arguments)
    assert args.debug is True
    assert args.headers == [
        'a: b',
        'c: d',
        'e: f'
    ]
    assert args

# Generated at 2022-06-11 22:53:07.409036
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = HTTPieArgumentParser().parse_args(args = [])
    assert args.body == True, "failed test"

if __name__ == "__main__":
    test_HTTPieArgumentParser_parse_args()



# Generated at 2022-06-11 22:53:18.036302
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    base_parser = BaseParser(prog='http',
        formatter_class=ArgumentDefaultsHelpFormatter,
        add_help=False,
        usage=SUPPRESS)
    arg_parser = HTTPieArgumentParser()
    def get_args(arg_str):
        return arg_parser.parse_args(arg_str.split())
    def assertWithError(arg_str,expected_error):
        try:
            get_args(arg_str)
            assert False
        except AssertionError as e:
            print_error(arg_str)
            print_error(str(e))
            assert False
        except BaseException as e:
            print_error('Caught exception: '+str(e))
            assert str(e)==expected_error
        else:
            assert False

# Generated at 2022-06-11 22:53:25.942084
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    environment = Environment()
    parser = HTTPieArgumentParser(environment=environment)
    # Just a simple test to make sure there is no error.
    # Actual testing is done through unit tests for the methods of this class.
    parser.parse_args(['https://pypi.org'])
# Class to parse the user-provided items, which are arguments of form
# `key:value`, `key@file`, `@file`, or `key=value`, etc.

# Generated at 2022-06-11 22:53:33.540834
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = [
        '--body', '-',
        'http://www.google.com/search?q=HTTPie+is+awesome',
        'Authorization:Bearer:12345',
        'Cache-Control:no-cache'
    ]
    hp = HTTPieArgumentParser()
    hp.env = Environment()
    cp = hp.parser
    output = hp.parse_args(args)
    assert 'http://www.google.com/search?q=HTTPie+is+awesome' in output.url
    assert 'Authorization' in output.headers
    assert 'Cache-Control' in output.headers
 
test_HTTPieArgumentParser_parse_args()


# Generated at 2022-06-11 22:53:43.766411
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args()
    assert args.base_url is None
    assert args.download is False
    assert args.download_resume is False
    assert args.form is False
    assert args.format_options == {'snake_case_headers': True, 'colors': True, 'verify': True, 'stream': True, 'pretty': 'all', 'progress': 'on', 'style': 'solarized'}
    assert args.headers == []
    assert args.ignore_netrc is False
    assert args.ignore_stdin is False
    assert args.max_headers == DEFAULT_MAX_HEADERS
    assert args.max_redirects == DEFAULT_MAX_REDIRECTS
    assert args.method is None
    assert args.output_file is None


# Generated at 2022-06-11 22:53:44.718107
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    return 0