

# Generated at 2022-06-11 22:47:29.325739
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    http = HTTPieArgumentParser()

    # Test case 1
    test_args = ['http', '--verbose', '--print=Hh', '-L', 'https://httpbin.org/get']
    parsed_args = http.parse_args(test_args)
    print(parsed_args)

# Generated at 2022-06-11 22:47:30.297233
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO: implement
    pass

# Generated at 2022-06-11 22:47:33.482731
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    assert isinstance(parser.parse_args([]), argparse.Namespace)

# Generated at 2022-06-11 22:47:42.503976
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # request: GET /ip
    parser = HTTPieArgumentParser(foo=22, bar='bar')
    args = parser.parse_args(['/ip'])
    assert args.url == 'https://httpbin.org/ip'
    assert args.method == 'GET'
    assert args.headers == {}
    assert args.foo == 22
    assert args.bar == 'bar'
    assert args.is_windows_pty_supported is None
    assert args.stream == False
    assert args.check_status == False
    assert args.check_ssl == False
    
    
    
    
    # request: GET /ip
    parser = HTTPieArgumentParser(foo=22, bar='bar')

# Generated at 2022-06-11 22:47:52.831514
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    
    # No arguments
    # print(HTTPieArgumentParser([]).parse_args())
    
    # Argument parse
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--verbose', 'httpbin.org/get', '--headers'])
    parser.terminate()
    
    # Argument parse
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['httpbin.org/post', '--data', 'name=Foo', '-f'])
    parser.terminate()
    
    
    # Argument parse
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--traceback', '--traceback'])
    parser.terminate()


# Main function

# Generated at 2022-06-11 22:47:58.776291
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser(add_help=False)
    parser.add_argument('--foo')
    parser.add_argument('--bar')
    args = parser.parse_args(['--foo', 'one'])
    assert args.foo == 'one'
    assert args.bar is None

# Generated at 2022-06-11 22:48:00.273018
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO: Add tests for this method
    raise NotImplementedError

# Generated at 2022-06-11 22:48:04.154971
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Arrange
    args = []
    test_parser = HTTPieArgumentParser()

    # Action
    with pytest.raises(SystemExit):
        test_parser.parse_args(args)




# Generated at 2022-06-11 22:48:15.460951
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test: init HTTPieArgumentParser
    parser = HTTPieArgumentParser(
        prog='http',
        epilog=manual_epilog,
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    # Test: parse_args: empty command case
    args = parser.parse_args([])
    assert args.exit_status == ExitStatus.OK
    assert args.output_options == parser.defaults['output_options']
    assert args.output_options_history == parser.defaults['output_options_history']
    
    # Test: parse_args: one argument
    args = parser.parse_args(['example.org'])
    assert args.exit_status == ExitStatus.OK
    assert args.output_options == parser.defaults['output_options']
    assert args

# Generated at 2022-06-11 22:48:27.691656
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-11 22:49:11.161931
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args()
    

# Generated at 2022-06-11 22:49:13.443750
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = HTTPieArgumentParser().parse_args('')
    assert args == {}
test_HTTPieArgumentParser_parse_args()


# Generated at 2022-06-11 22:49:18.409098
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Case 1 : Parse arguments
    stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='UTF-8')
    stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='UTF-8')
    env = Environment(stdin=sys.stdin,
                      stdin_isatty=sys.stdin.isatty(),
                      stdout=stdout,
                      stdout_isatty=stdout.isatty(),
                      stderr=stderr,
                      stderr_isatty=stderr.isatty(),
                      devnull=sys.stdout.buffer)
    parser = HTTPieArgumentParser(options_first=True, env=env)

# Generated at 2022-06-11 22:49:23.306656
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
  """Unit test for method parse_args of class HTTPieArgumentParser"""
  # Test pre-conditions
  parser = HTTPieArgumentParser()
  parser.args = None
  # Test post-condition
  parser.parse_args([])
  assert parser.args != None, "Parser did not parse args"


# Generated at 2022-06-11 22:49:33.534458
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from tempfile import gettempdir
    from os.path import join

    a = HTTPieArgumentParser()
    args = a.parse_args(['-f', 'doge'])

    assert args.request_items == [
        KeyValueArgType(*SEPARATOR_GROUP_DATA_ITEMS)('doge')
    ]

    args = a.parse_args(['-f', 'doge', 'wow'])

    assert args.request_items == [
        KeyValueArgType(*SEPARATOR_GROUP_DATA_ITEMS)('doge'),
        KeyValueArgType(*SEPARATOR_GROUP_DATA_ITEMS)('wow')
    ]

    args = a.parse_args(['-f', 'doge', 'wow', 'such'])


# Generated at 2022-06-11 22:49:43.438380
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.add_argument(
        '--force-headers',
        action='store_true',
        dest='force_headers')
    parser.add_argument(
        '--outputoptions',
        action='store',
        dest='output_options')
    parser.add_argument(
        '--format',
        action='store',
        default='json',
        dest='prettify')
    outputoptions = 'hdrs.server,hdrs.request.method'
    args = parser.parse_args(['--force-headers', '--outputoptions', outputoptions, '--format=default'], env=None)
    assert type(args) == argparse.Namespace
    assert args.force_headers == True

# Generated at 2022-06-11 22:49:53.476067
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO Add tests for argument parser.
    pass
# Class documentation string in the format of reStructuredText.
# See: https://docs.python.org/3/library/inspect.html#inspect.cleandoc

# Generated at 2022-06-11 22:49:58.113953
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import unittest
    class testcases(unittest.TestCase):
        def test_1(self):
            # s = '''s
            # '''
            args = HTTPieArgumentParser().parse_args([])

    unittest.main(verbosity=2)

# Process command line arguments and return to be used by others

# Generated at 2022-06-11 22:50:07.103054
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_args = ['http', 'https://httpbin.org/get', 'test_key=test_value']
    httpie_args = HTTPieArgumentParser().parse_args(httpie_args, env)
    assert httpie_args.url == 'https://httpbin.org/get'
    assert httpie_args.request_items == [KeyValue(key='test_key', value='test_value')]
    
test_HTTPieArgumentParser_parse_args()
 


# Generated at 2022-06-11 22:50:16.316318
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    class MockEnvironment:
        config = None
        args = None
        stdout = None
        stderr = None
        devnull = None
        stdout_isatty = None
        stderr_isatty = None
        stdout_encoding = None
        is_windows = None
    mock_env = MockEnvironment()
    test_class = HTTPieArgumentParser(
        prog='mock_prog',
        env=mock_env, 
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    args = test_class.parse_args(['http://127.0.0.1:5000/users','--json','{"username":"test1", "email":"test1@gmail.com", "password":"test11223"}','--form'])
    args2 = test_class.parse_

# Generated at 2022-06-11 22:51:43.237764
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
	parser = HTTPieArgumentParser()
	args = parser.parse_args(['--details','--verbose','GET','http://httpbin.org/'])
	assert args
	assert args.get('verbose')
	assert args.get('all')
	assert args.get('method')
	assert args.get('url')

# Generated at 2022-06-11 22:51:53.061893
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-11 22:51:59.082601
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = HTTPieArgumentParser.parse_args(['https://www.cloudflare.com'])
    assert args.url == 'https://www.cloudflare.com'
test_HTTPieArgumentParser_parse_args()

# 5. plugin_manager

# Generated at 2022-06-11 22:52:06.469516
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import sys

    from httpie.core import load_config
    from httpie.core import DEFAULT_CONFIG_DIR
    from httpie.core import FileNotFound

    load_config(DEFAULT_CONFIG_DIR)
    parser = HTTPieArgumentParser()
    print("parser.arg_parser.format_usage():\n{0}\n".format(parser.arg_parser.format_usage()))
    parser.add_arg_group("request", "Request")

    args = ["https://www.python.org", "User-Agent:", "test"]

    # 1. parse_args
    args_namespace = parser.parse_args(args)
    # 2. set_first_url
    parser.set_first_url()
    # 3. _normalize_headers
    parser._normalize_headers()
   

# Generated at 2022-06-11 22:52:18.506838
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie.config import DEFAULT_OPTIONS
    DEFAULT_OPTIONS['output_options'] = ''
    DEFAULT_OPTIONS['prettify'] = True
    DEFAULT_OPTIONS['default_options'] = []
    DEFAULT_OPTIONS['default_options'].append('--prettify')
    DEFAULT_OPTIONS['default_options'].append('--body')
    DEFAULT_OPTIONS['default_options'].append('')

    DEFAULT_OPTIONS['config'] = ''
    DEFAULT_OPTIONS['traceback'] = False
    DEFAULT_OPTIONS['verbose'] = False
    DEFAULT_OPTIONS['debug'] = False
    DEFAULT_OPTIONS['download'] = False
    DEFAULT_OPTIONS['offline'] = False
   

# Generated at 2022-06-11 22:52:24.373720
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie.cli import parser

    parser = HTTPieArgumentParser()
    params = [
        '-v',
        'https://api.github.com/get'
    ]
    args = parser.parse_args(params)

    # This will print all the variable values.
    # It's not very beautiful.
    for k, v in args.__dict__.items():
        print(k, v)



# Generated at 2022-06-11 22:52:31.306723
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_parser = HTTPieArgumentParser()
    for cmd in commands:
        args = httpie_parser.parse_args(cmd.split())
        #print(args)
        print(cmd)
        print(args.url,vars(args))

httpie_parser = HTTPieArgumentParser()
args = httpie_parser.parse_args()
parse_json = lambda s: json.loads(json.dumps(s))
#print('Parse args:',vars(args))

# Generated at 2022-06-11 22:52:43.256772
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    k = HTTPieArgumentParser
    with pytest.raises(SystemExit):
        k.parse_args(["-h"])

    with pytest.raises(SystemExit):
        k.parse_args(["--help"])

    args = k.parse_args(["--json"])
    assert args.json

    args = k.parse_args(["--json=false"])
    assert not args.json

    with mock.patch.object(k, "_open_file",
                           mock.Mock(return_value=b"a")):
        args = k.parse_args(["--json=@a"])
        assert args.json == {"@a": "a"}
        k._open_file.assert_called_once_with("a")


# Generated at 2022-06-11 22:52:49.443599
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    http = HTTPieArgumentParser()
    # parse_args with empty argument
    assert isinstance(http.parse_args([]), Namespace)
    # parse_args with argument
    assert isinstance(http.parse_args(["GET"]), Namespace)

# Generated at 2022-06-11 22:52:59.862131
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie.httpie import HTTPie
    httpie = HTTPie()
    parser = httpie.args_parser
    url = 'https://webvpn.neu.edu.cn/http/77726476706e69737468656265737421ca67b/login.aspx'
    ret = parser.parse_args(
        ["http", url, "lt='LT-189898-7qYlZOgX9pM1B6sJH3qwa3TBBTQwEH-webvpn1.neu.edu.cn'", "execution='e2s2'",
         "submit='登录'", "--form"])
    print(ret)
    assert ret is not None
    assert ret.url == url

# Generated at 2022-06-11 22:56:05.982904
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser(env=Environ())
    output = parser.parse_args(['https://www.google.com/'])
    return output

# Create the parser
parser = HTTPieArgumentParser(env=Environ())

# Create the checkpoint
checkpoint = Checkpoint()

# Check the output of the unit test

# Generated at 2022-06-11 22:56:14.613873
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    bs = 'http'
    urls = [
        'https://localhost:5000/api/v1.0/tasks',
        'http://localhost:5000/api/v1.0/tasks',
        'http://localhost:5000/api/v1.0/tasks',
        'http://localhost:5000/api/v1.0/tasks'
    ]
    default_headers = [
        'Content-Type:application/json',
        'Accept:application/json'
    ]
    query_string = 'order_by=task_id&sort=desc'
    output_file = 'c://temp/test_HTTPieArgumentParser_parse_args.txt'
    max_redirects = 10
    max_body_size = 10000
    string_method = ['POST', 'GET']
    string

# Generated at 2022-06-11 22:56:19.434140
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    argv = ['--print', 'b']
    parser = HTTPieArgumentParser()
    args = parser.parse_args(args=argv)
    assert args.output_options == 'b'

#Unit test for method _print_message of class HTTPieArgumentParser

# Generated at 2022-06-11 22:56:26.402736
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # 1. Create the needed inputs
    args = ['http','api.gle.com','x-api-key:12345']
    # 2. Create the object
    parser = HTTPieArgumentParser()
    # 3. Call the method
    parser.parse_args(args)
    # 4. Check the output, we don't care about this as this is just a namespace
    return parser
parser = test_HTTPieArgumentParser_parse_args()
print(parser.args)


# Generated at 2022-06-11 22:56:32.080202
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    with StringIO() as stdin:
        stdin.write(u'{"foo":"bar"}')
        stdin.seek(0)
        stdin_isatty = stdin.isatty()
        stdin = getattr(sys.stdin, 'buffer', sys.stdin)
        stdout = getattr(sys.stdout, 'buffer', sys.stdout)
        stderr = getattr(sys.stderr, 'buffer', sys.stderr)
        devnull = open(os.devnull, 'w')