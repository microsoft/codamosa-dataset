

# Generated at 2022-06-11 22:47:30.803915
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """
    Test HTTPieArgumentParser.parse_args method

    """

    parser = HTTPieArgumentParser()
    args = parser.parse_args([])
    assert isinstance(args, argparse.Namespace)
    assert args.output == 'all'
    assert args.prettify == PRETTY_MAP['all']
    assert args.download == False
    assert args.download_resume == False
    assert args.format == False
    assert args.format_options == PARSED_DEFAULT_FORMAT_OPTIONS
    assert args.output_options == OUTPUT_OPTIONS_DEFAULT_STDOUT_REDIRECTED
    
    args = parser.parse_args(['--debug', 'http://httpbin.org/get'])
    assert args.output == 'all'
    assert args.prettify

# Generated at 2022-06-11 22:47:41.372042
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    print("test_HTTPieArgumentParser_parse_args()")

    args = HTTPieArgumentParser().parse_args(['www.example.org'])
    print("args:")
    print(args)

    # assert args.url == 'www.example.org'
    # assert args.method == 'GET'
    # assert args.headers == []
    # assert args.params == []
    # assert args.data == []
    # assert args.files == []
    # assert args.auth.key == ''
    # assert args.auth.value == ''
    # assert args.auth.sep == ''
    # assert args.auth.orig == ''
    # assert args.timeout == DEFAULT_TIMEOUT
    # assert args.output_file is None
    # assert args.output_options is None
    # assert args.

# Generated at 2022-06-11 22:47:46.745279
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Setup test
    program = 'http'
    args = [
        'https://httpbin.org/post',
        'x-api-token:123',
        'user-id:456',
        'content-type:application/json',
        'Authorization:Basic bXl1c2VyOnBhc3N3b3Jk',
        '{"a":1}'
    ]
    pap = HTTPieArgumentParser(program)
    pap.set_env(HttpieEnvironment(program))
    default_config = pap.env.get_config()

    # Run the test
    parsed_args = pap.parse_args(args)


# Generated at 2022-06-11 22:47:52.198808
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.add_argument("url",help="URL")
    parser.add_argument("--headers",help="Custom headers to be sent")
    args = parser.parse_args("http://httpbin.org/get --headers")
    print(str(args.headers))
    print(str(args.url))



# Generated at 2022-06-11 22:48:04.621732
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args()
    assert args.headers == None
    assert args.data == None
    assert args.files == None
    assert args.params == None
    assert args.multipart_data == None
    assert args.verbose == False
    assert args.debug == False
    assert args.output_file == None
    assert args.download == False
    assert args.download_resume == False
    assert args.offline == False
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.pretty == False
    assert args.prettify == None
    assert args.tor == False
    assert args.all == False
    assert args.style == None
    assert args.style_sheet == None
    assert args.traceback

# Generated at 2022-06-11 22:48:10.784237
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    H = HTTPieArgumentParser(prog='http')
    args = H.parse_args()
    assert args.output_options == 'HbB'
#show_source(HTTPieArgumentParser)
#test_HTTPieArgumentParser_parse_args()
HTTPieArgumentParser.parse_args = test_HTTPieArgumentParser_parse_args


# Generated at 2022-06-11 22:48:18.935763
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-11 22:48:30.504565
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Create an instance of HTTPieArgumentParser
    parser = HTTPieArgumentParser()

    # Call method parse_args
    parser.parse_args(['localhost'])

    assert parser.args.url == 'localhost'
    assert parser.args.method is None
    assert parser.args.output_options is None
    assert parser.args.debug is None
    assert parser.args.download is None
    assert parser.args.download_resume is None
    assert parser.args.form is None
    assert parser.args.headers == []
    assert parser.args.ignore_netrc is None
    assert parser.args.output == None
    assert parser.args.output_file is None
    assert parser.args.output_file_specified is None
    assert parser.args.output_options_history is None
    assert parser.args.pre

# Generated at 2022-06-11 22:48:39.781233
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    argv=[]
    args=HTTPieArgumentParser().parse_args(argv)
    assert args.exit_status

    argv=['--ignore-stdin']
    args=HTTPieArgumentParser().parse_args(argv)
    assert args.ignore_stdin

    argv=['--check-status']
    args=HTTPieArgumentParser().parse_args(argv)
    assert args.check_status

    argv=['--traceback']
    args=HTTPieArgumentParser().parse_args(argv)
    assert args.traceback

    argv=['--http1.1']
    args=HTTPieArgumentParser().parse_args(argv)
    assert args.http1_1

    argv=['--pretty','all']
    args=HTTPieArgumentParser().parse_

# Generated at 2022-06-11 22:48:45.715796
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['foo', 'bar'])
    assert args.args == ['foo', 'bar']
    assert args.output_file_specified is False
    assert args.output_file is None
    assert args.output_options == 'HBIc'
    assert args.output_options_history == 'HBIc'
    assert args.dump_options is None
    assert args.dump_all is False
    assert args.form is False
    assert args.print_body is False
    assert args.method == 'GET'
    assert args.headers == []
    assert args.auth == None
    assert args.auth_plugin == None
    assert args.data == None
    assert args.params == []
    assert args.files == []
    assert args.multipart_data

# Generated at 2022-06-11 22:50:08.139716
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    with app.test_client() as c:
        rv = c.get('/api/parser')
        assert rv.status_code == 200


# Generated at 2022-06-11 22:50:11.977721
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(args=['localhost','-H','accept:Application/JSON'])
    assert args.url == 'localhost'
    assert args.headers['accept'] == 'Application/JSON'

# Generated at 2022-06-11 22:50:23.630959
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    # Case 1:
    # Test when the method parse_args of the class HTTPieArgumentParser
    # is called after the method add_argument with parameter name "--form"
    # and parameter action "store_true" was called
    def test_HTTPieArgumentParser_parse_args_case1():

        # Create an object of class HTTPieArgumentParser
        httpie_argument_parser = HTTPieArgumentParser()

        # Create a string with the value of argument
        # "--form"
        string_with_option = "--form"

        # Call the method add_argument from class
        # HTTPieArgumentParser with parameter name "--form" and
        # parameter action "store_true"
        httpie_argument_parser.add_argument(name=string_with_option, action="store_true")

        # Create an

# Generated at 2022-06-11 22:50:32.170817
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['https://httpbin.org'])
    assert args.url == 'https://httpbin.org'
    assert args.method == 'GET'
    assert args.headers == []
    assert args.data == []
    assert args.files == []
    assert args.json == []
    assert args.params == []
    assert args.origin == []
    assert args.follow == True
    assert args.max_redirects == 10
    assert args.method == 'GET'
    assert args.auth == None
    assert args.auth_type == None
    assert args.proxy == None
    assert args.download == False
    assert args.download_resume == False
    assert args.output_file == None
    assert args.output_file_specified == False


# Generated at 2022-06-11 22:50:40.216081
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['-v', 'httpbin.org/get'])
    assert args.url == 'httpbin.org/get'
    assert args.method == 'GET'
    assert args.data == []
    assert args.headers == []
    assert args.params == []
    assert args.files == []
    assert args.auth == []
    assert args.verify == True
    assert args.proxy == []
    assert args.timeout == (None, None)
    assert args.output_file == []
    assert args.download == False
    assert args.download_resume == False
    assert args.download_as == []
    assert args.output_options == 'Hb'
    assert args.output_options_history == 'Hb'
    assert args.pre

# Generated at 2022-06-11 22:50:45.699819
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """
    Test HTTPieArgumentParser.parse_args.
    """

    # Case 1:
    # test if the instance is created with no attributes
    parser = HTTPieArgumentParser()
    
    # Unit test for method parse_url of class HTTPieArgumentParser

# Generated at 2022-06-11 22:50:55.850457
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    p = HTTPieArgumentParser()
    args = p.parse_args('GET http://example.com')
    assert args.method == 'GET'
    assert args.url == 'http://example.com'
    
    args = p.parse_args('--json http://example.com')
    assert args.method == 'GET'
    assert args.url == 'http://example.com'
    assert args.data == []
    assert args.headers == []
    assert args.params == []
    assert args.files == []
    assert args.multipart_data == []
   
    args = p.parse_args('--json http://example.com foo=bar')
    assert args.method == 'GET'
    assert args.url == 'http://example.com'

# Generated at 2022-06-11 22:51:06.561299
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO: replace with mock
    class MockEnv:
        def __init__(self, **kwargs):
            if 'stdin' in kwargs:
                self.stdin = kwargs.get('stdin')
            else:
                self.stdin = None
            if 'env' in kwargs:
                self.env = kwargs.get('env')
            else:
                self.env = None
            if '__call__' in kwargs:
                self.__call__ = kwargs.get('__call__')
            else:
                self.__call__ = None
            self.config = None


    class MockArgs:
        def __init__(self, **kwargs):
            if 'auth_plugin' in kwargs:
                self.auth_plugin = kwargs

# Generated at 2022-06-11 22:51:16.481183
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(shlex.split('''
    -f http://example.com
    '''))
    assert args.url == 'http://example.com'
    assert args.follow
    assert args.verbose == 0
test_HTTPieArgumentParser_parse_args()
## http-core
##
## HTTP request, response, and their parts.

# See: http://tools.ietf.org/html/rfc7231
#      http://tools.ietf.org/html/rfc7233
#      http://tools.ietf.org/html/rfc7232
#      http://tools.ietf.org/html/rfc7230
#      http://tools.ietf.org/html/rfc3986#section-3.1


# Generated at 2022-06-11 22:51:26.509554
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    http_arguments_string, http_arguments_list = get_http_arguments()
    ap = HTTPieArgumentParser()
    parsed_args = ap.parse_args(http_arguments_string)
    assert_that(parsed_args.url, equal_to('https://postman-echo.com/post'))
    assert_that(parsed_args.method, equal_to('post'))
    assert_that(parsed_args.headers, has_entry('Content-Type', 'application/json'))
    assert_that(parsed_args.data, has_entry('key', 'value'))
    assert_that(parsed_args.json, equal_to(''))
    assert_that(parsed_args.form, equal_to(''))

# Unit test

# Generated at 2022-06-11 22:52:55.779263
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-11 22:53:03.117893
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.parse_args(['http://www.v2ex.com'])
    parser.parse_args(['http://www.v2ex.com', '--auth', 'user', '--form'])
    parser.parse_args(['http://www.v2ex.com', '--auth', 'user', '--form'])
    parser.parse_args(['http://www.v2ex.com', '--auth', 'user', '--form'])
    parser.parse_args(['-v', 'http://www.v2ex.com', '--auth', 'user', '--form'])

# Generated at 2022-06-11 22:53:15.013266
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_parser = HTTPieArgumentParser(prog='http')
    args = httpie_parser.parse_args(['hubspot.com'])
    assert args.debug == False
    assert args.download == False
    assert args.timeout == 60.0
    assert args.url == 'hubspot.com'
    assert args.output_file == None
    assert args.auth == None
    assert args.auth_plugin == None
    assert args.method == 'GET'
    assert args.headers == []
    assert args.params == []
    assert args.input_file == None
    assert args.output_file_specified == False
    assert args.output_options == 'hb'
    assert args.output_options_history == 'hb'
    assert args.prettify == None
    assert args.verify == True

# Generated at 2022-06-11 22:53:18.919240
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    cmd_line = "http try.httpie.org --color"
    arg_parser = HTTPieArgumentParser(add_help=False)
    args = arg_parser.parse_args(cmd_line.split())
    print(args)

test_HTTPieArgumentParser_parse_args()


# Generated at 2022-06-11 22:53:30.115773
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    os.system('pip install httpie')
    import httpie
    from httpie.config import DEFAULT_CONFIG_PATH
    if os.path.isfile(DEFAULT_CONFIG_PATH):
        os.remove(DEFAULT_CONFIG_PATH)
    os.system('http --help')
    os.system('http --debug')
    # lets create a config file
    os.system('http --print=hB --pretty=all --body --style=solarized')
    os.system('http --config-delete')
    os.system('http --config-delete --force')
    os.system('http --config-delete --force --config=/tmp/a')
    os.system('http --config-delete --force --config=/tmp/a --force')

# Generated at 2022-06-11 22:53:34.465214
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.add_argument('--arg1')
    parser.add_argument('--arg2')
    parser.add_argument('--arg3')
    args = parser.parse_args(['--arg1=val1', '--arg2=val2'])
    assert args.arg1 == 'val1'
    assert args.arg2 == 'val2'
    assert args.arg3 is None



# Generated at 2022-06-11 22:53:36.030455
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    # TODO: add more tests
    assert parser.parse_args([])

# Generated at 2022-06-11 22:53:44.636994
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """
    Unit test for method parse_args of class HTTPieArgumentParser
    """
    
    parser = HTTPieArgumentParser()
    args = parser.parse_args('http://www.google.com/')
    assert args.url == 'http://www.google.com/'

    args = parser.parse_args(['http://www.google.com/', 'key', 'value'])
    assert args.url == 'http://www.google.com/'
    assert args.request_items[0].key == 'key'
    assert args.request_items[0].value == 'value'
    
    

# Generated at 2022-06-11 22:53:50.475136
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    TEST_PARSER = HTTPieArgumentParser()
    TEST_PARSER.add_argument('arg1')
    ARGS = TEST_PARSER.parse_args(['arg1val'])
    assert ARGS.arg1 == 'arg1val'
    assert ARGS.args == ['arg1val']



# Generated at 2022-06-11 22:53:52.292558
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """Test for method parse_args of class HTTPieArgumentParser"""
    pass

# Unit tests for class Environment