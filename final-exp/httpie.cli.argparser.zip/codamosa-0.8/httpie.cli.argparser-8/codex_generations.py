

# Generated at 2022-06-11 22:47:29.328409
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args([])
    assert args.url == 'https://httpbin.org/'
    assert args.headers == [':authority: httpbin.org',
                            ':method: GET',
                            ':path: /',
                            ':scheme: https',
                            'accept: */*',
                            'accept-encoding: gzip, deflate',
                            'connection: keep-alive',
                            'user-agent: HTTPie/0.9.8']
    assert args.method == 'GET'
    assert args.json is False
    assert args.output_file is None
    assert args.download is False
    assert args.download_resume is False
    assert args.max_redirects is 30
    assert args.output_

# Generated at 2022-06-11 22:47:37.409963
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.parse_args(['http://example.com'])
    parser.parse_args(['http://example.com', 'var=value'])
    parser.parse_args(['-m', 'GET', 'http://example.com'])
    parser.parse_args(['-v', 'http://example.com'])
    parser.parse_args(['-h', 'http://example.com'])

test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-11 22:47:44.258068
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http://example.com'])
    pprint(args)
    print(args.headers)
    print(args.json)
    print(args.output_file)

test_HTTPieArgumentParser_parse_args()


# Generated at 2022-06-11 22:47:55.375330
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-11 22:48:00.069499
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['https://httpbin.org', '-v'])
    assert args.url == 'https://httpbin.org'
    assert args.verbose == True


# Generated at 2022-06-11 22:48:01.153487
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    #TODO:
    pass

# Generated at 2022-06-11 22:48:11.386429
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # given
    parser = HTTPieArgumentParser(env=FakeEnv())

    # when
    actual = parser.parse_args(['--json', '{"abc":123}', 'abc'])

    # then
    expected_headers = [
        KeyValue(key='Content-Type',
            value='application/json',
            sep =': ',
            orig='Content-Type: application/json'),
    ]
    expected_data = b'{"abc":123}'
    assert actual.headers == expected_headers
    assert actual.data == expected_data
    assert actual.url == 'abc'


test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-11 22:48:19.212733
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

    if sys.version_info.major < 3:
        # noinspection PyUnresolvedReferences
        arg_str = unicode('')
    else:
        # noinspection PyUnresolvedReferences
        arg_str = str('')

    args = parser.parse_args(arg_str.split())
    
    assert args.method == 'GET'
    assert args.url == 'https://httpbin.org/'
    assert not args.headers
    assert not args.data
    assert not args.files
    assert args.params == []
    assert args.request_items == []
    assert not args.output_file_specified
    assert args.output_file == None
    assert args.output_options == 'H'
    assert args.output_options_history == 'H'

# Generated at 2022-06-11 22:48:27.203915
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie.cli import httpie

    with patch.object(httpie.HTTPieArgumentParser, '_get_args', return_value=None):
        with patch.object(httpie.HTTPieArgumentParser, '_get_parser') as _get_parser:
            args = httpie.HTTPieArgumentParser().parse_args()
            _get_parser.assert_called_once_with()
            assert args is _get_parser.return_value.parse_args.return_value


# Generated at 2022-06-11 22:48:28.672577
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.parse_args()

# Generated at 2022-06-11 22:49:08.091993
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """

    """
    return None


# Generated at 2022-06-11 22:49:16.286264
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    parser = HTTPieArgumentParser(env=TestEnvironment())
    args = parser.parse_args([])

    # Validate the instance of the object args
    assert isinstance(args, Namespace)
    

# Generated at 2022-06-11 22:49:26.840049
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie.input import KeyValue, KeyValueArgType


# Generated at 2022-06-11 22:49:35.551187
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args([])
    assert args.debug
    assert args.colors
    assert not args.print_headers
    assert args.follow
    assert not args.download
    assert args.output_file is None
    assert args.output_options == 'HhB'
    assert args.output_options_history == 'HhB'
    assert not args.ignore_netrc
    assert not args.ignore_stdin
    assert not args.verbose
    assert not args.offline
    assert args.prettify == 'all'
    assert args.headers == []
    assert args.data is None
    assert args.files is None
    assert args.params is None
    assert args.auth is None
    assert args.auth_plugin is None
    assert args.auth

# Generated at 2022-06-11 22:49:44.268693
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # get_stdin_data has side effect. We don't want this side effect for this test.
    def get_stdin_data(self):
        yield b'hello'
    class Test(object):
        def __init__(self):
            self.stdout = io.StringIO()
            self.stdout_isatty = False
            self.stderr = io.StringIO()
            self.stderr_isatty = False
            self.stdin = io.BytesIO()
            self.stdin_isatty = False
            self.devnull = io.BytesIO()
            self.stdin_encoding = 'utf8'
            self.is_windows = False
    test_env = Test()
    test_parser = HTTPieArgumentParser(env=test_env)

# Generated at 2022-06-11 22:49:53.647581
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-11 22:50:01.495102
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """Unit test for method parse_args of class HTTPieArgumentParser"""
    # TODO: Finish this unit test
    # os = Mock()
    # os.isatty = True
    # os.EX_USAGE = 64
    # httpie = HTTPie(os=os)
    # httpie.argparser = HTTPieArgumentParser(httpie)
    # arg_list = ['echo', '--json', '{"a": "b"}']
    # args = httpie.argparser.parse_args(arg_list)
    pass

# Unit tests for class HTTPie

# Generated at 2022-06-11 22:50:10.709515
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Arrange
    args = ['--ipv4', 'url', '--form', 'key1=val1']
    env_stub = {'IS_WINDOWS': False, 'is_windows': False}
    
    # Act
    parser = HTTPieArgumentParser()
    parser.environment = MockEnvironment(**env_stub)
    parser.parse_args(args)
    
    # Assert
    assert parser.args.ipv4
    assert parser.args.request_items[0].key == 'key1'



# Generated at 2022-06-11 22:50:18.265049
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args()
    assert args.debug == False
    assert args.traceback == False
    assert args.help == False
    assert args.version == False
    assert args.check_status == False
    assert args.check_ssl_cert == True
    assert args.download_all == False
    assert args.compress == False
    assert args.verify == True
    assert args.timeout == 300
    assert args.headers == []
    assert args.max_headers == None
    assert args.max_redirects == None
    assert args.style == 'colors'
    assert args.styles == {}
    assert args.style_sheet == None
    assert args.format == None
    assert args.output_options == 'hB'
    assert args.output_options_

# Generated at 2022-06-11 22:50:28.888311
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = ["localhost", "-H", "a=1", "-H", "b=2"]
    parser = HTTPieArgumentParser()
    parsed = parser.parse_args(args=args)
    assert parsed.url == "http://localhost"
    assert parsed.headers == {b"a": b"1", b"b": b"2"}
    assert parsed.headers.keys() == {b"a", b"b"}
    assert parsed.headers.values() == {b"1", b"2"}
    assert parsed.auth.key == None
    assert parsed.auth.value == None
    assert parsed.auth.separator == None
    assert parsed.auth.orig == None

    args = ["localhost", "a=1", "-f", "a=2", "-H", "b=3"]
    parser = HTTPieArgumentParser()

# Generated at 2022-06-11 22:52:03.604914
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.add_argument("--output_options", type=str, )
    parser.add_argument("--prettify", type=str, )
    parser.add_argument("--all", action="store_true", )
    parser.add_argument("--output_options_history", type=str, )
    parser.add_argument("--headers", action="store_true", )
    parser.add_argument("--download_resume", type=str, )
    parser.add_argument("--download", action="store_true", )
    parser.add_argument("--download_resume", type=str, )
    parser.add_argument("--download", action="store_true", )
    parser.add_argument("--download", action="store_true", )
    parser.add_

# Generated at 2022-06-11 22:52:05.312146
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import pytest
    with pytest.raises(SystemExit):
        parser = HTTPieArgumentParser()
        parser.parse_args(['--help'])

# Generated at 2022-06-11 22:52:16.557048
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    class Mock(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)
    
    
    class MockHTTPieArgumentParser(HTTPieArgumentParser):
        def __init__(self, **kwargs):
            pass

        def prop_x(self):
            return 'x'

        def prop_y(self):
            return 'y'

        def prop_z(self):
            return 'z'

        def raise_exception(self, exception):
            raise exception

        def _apply_no_options(self, *args, **kwargs):
            self.prop_x()

        def _process_auth(self, *args, **kwargs):
            self.prop_y()


# Generated at 2022-06-11 22:52:26.041272
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import plugin_manager
    from httpie import ExitStatus
    from httpie.client import AuthCredentials
    from httpie.core import httpserver

    stdin_isatty = sys.stdin.isatty()
    stdout_isatty = sys.stdout.isatty()

    # default values
    stdin = sys.stdin

    args = ['http', 'httpbin.org/get']
    if stdout_isatty:
        args += ['--pretty=all']
    args += ['HTTP/1.1']
    env = Environment(stdin=stdin, stdout=sys.stdout, stderr=sys.stderr)
    httpie_parser = HTTPieArgumentParser

# Generated at 2022-06-11 22:52:29.700677
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argument_parser = HTTPieArgumentParser()

# Generated at 2022-06-11 22:52:41.679099
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    for file in LIST_OF_LOGS:
        print(file)
        http_request = get_request_from_file(file)
        # The HTTP request argument to be parsed.
        args = http_request.split(' ')
        # Perform the parsing.
        argparse_args = HTTPieArgumentParser().parse_args(args)
        # Print the parsed arguments.
        print('Parsed arguments:')
        print(argparse_args)
        # Print the arguments.
        print('Arguments:')
        print(args)
        # Print the HTTP request.
        print('HTTP Request:')
        print(http_request)
        # Print the request body.
        print('Request Body:')
        print(get_request_body_from_file(file))
        print('\n')

# #################################################################

# Generated at 2022-06-11 22:52:45.181207
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http://www.google.com'])
    assert args.url == 'http://www.google.com'
    
# unit test for method _process_url

# Generated at 2022-06-11 22:52:50.940248
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser=HTTPieArgumentParser()
    args=parser.parse_args(['http://localhost:8080'])
    assert args.url=='http://localhost:8080'
    assert args.data==None
# Test case for class HTTPieArgumentParser

# Generated at 2022-06-11 22:52:53.868438
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Not implemented yet
    print("Method HTTPieArgumentParser_parse_args is not implemented yet")
    assert False

# Generated at 2022-06-11 22:53:01.339541
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.parse_args(['httpie'])
    parser.parse_args(['http', 'localhost:5000/foo'])
    parser.parse_args(['http', 'localhost:5000/foo', 'bar=baz'])
    parser.parse_args(['http', 'localhost:5000/foo', 'bar=baz', '--json'])
    parser.parse_args(['http', 'localhost:5000/foo', 'bar=baz', '--headers'])

test_HTTPieArgumentParser_parse_args()
 

# Generated at 2022-06-11 22:55:57.771815
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    class Person(object):
        def __init__(self):
            self.name = None
            self.age = None

    def format_person(person):
        proof = "type({0}) is {1}".format(person.__class__, type(Person))
        assert type(person) is Person, proof
        return person.name

    class TestParser(HTTPieArgumentParser):
        def __init__(self, *args, **kwargs):
            HTTPieArgumentParser.__init__(self, *args, **kwargs)
            self.add_argument("--name", default="John")
            self.add_argument("--age", type=int, default=18)

        def process_arguments(self, args):
            self.args.person = Person()
            self.args.person.name = args.name

# Generated at 2022-06-11 22:56:06.343334
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    test_cases = [
        ('http', 'http', []),
        ('http httpie.org', 'http', ['httpie.org']),
        ('http :80 --headers', 'http', [':80'], {'headers':True}),
        ('http :80 --headers test', 'http', [':80', '--headers', 'test'], {}),
        ('http --headers', 'http', [], {'headers':True}),
        ('http --headers test', 'http', ['--headers', 'test'], {})
    ]

    for args_string, method, url, params in test_cases:
        args = HTTPieArgumentParser().parse_args(args_string.split())
        assert args.method == method
        assert args.url == url

# Generated at 2022-06-11 22:56:10.889407
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Record
    parser = HTTPieArgumentParser()
    args = ['--version']
    # Play
    parsed_args = parser.parse_args(args)
    # Assert
    assert parsed_args.version == True
# End def


# Generated at 2022-06-11 22:56:16.365867
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """Test HTTPieArgumentParser.parse_args method
    
    """

    # test with no argument
    args_str = []
    ap = HTTPieArgumentParser()
    # try to get the command line arguments
    try:
        args = ap.parse_args(args_str)
    except SystemExit as e:
        if e.code != 0:
            raise
        raise ValueError('expected error')
    # check the attributes
    assert args.exit_status == 0

    # test with --offline
    args_str = ['--offline']
    ap = HTTPieArgumentParser()
    # try to get the command line arguments
    try:
        args = ap.parse_args(args_str)
    except SystemExit as e:
        if e.code != 0:
            raise

# Generated at 2022-06-11 22:56:27.030764
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import json
    import sys
    import unittest
    from unittest import mock

    class MockEnv:
        stdout_encoding = sys.stdout.encoding
        stdout = mock.MagicMock()
        stderr = mock.MagicMock()
        stdout_isatty = True
        stderr_isatty = True
        is_windows = False
        devnull = mock.MagicMock()

    class MockPluginManager:

        @classmethod
        def get_auth_plugin(cls, auth_type):
            return MockAuthPlugin

        @classmethod
        def get_auth_plugins(cls):
            return []

        @classmethod
        def get_format_plugin(cls, format_type):
            return MockFormatPlugin


# Generated at 2022-06-11 22:56:36.178160
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    # This class is an argparse.ArgumentParser subclass, we will use it
    # to parse arguments passed to the ``main.py`` script.
    argparser = HTTPieArgumentParser()

    # If we call `parse_args` and pass no arguments, the function should return
    # an argparse.Namespace object with all attributes set to None.
    args = argparser.parse_args([])
    assert args.__class__ is argparse.Namespace
    for attr in argparser.env.default_options:
        assert hasattr(args, attr.only_cli_option or attr.name)
        assert getattr(args, attr.only_cli_option or attr.name) is None

    # The function should return an argparse.Namespace object populated with
    # all parsed arguments from the command line.
    args