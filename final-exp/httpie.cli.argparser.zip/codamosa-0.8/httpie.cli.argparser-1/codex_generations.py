

# Generated at 2022-06-11 22:47:28.868940
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from HttpRunnerManager.libs.argument import HTTPieArgumentParser
    from HttpRunnerManager.libs.config import create_config

    args = HTTPieArgumentParser().parse_args(
        ['https://demo.httprunner.org/get'],
        env=create_config()
    )
    assert args.url == 'https://demo.httprunner.org/get', args.url


# Generated at 2022-06-11 22:47:39.905677
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-11 22:47:51.074814
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-11 22:47:52.148379
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    pass


# Generated at 2022-06-11 22:48:04.572268
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-11 22:48:15.711428
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Setup
    test_parser = HTTPieArgumentParser()
    
    # Test #1
    args = ['--form','key=value', 'httpbin.org/put']
    args = test_parser.parse_args(args)
    
    assert not args.download
    assert not args.form
    assert not args.headers
    assert not args.output_file_specified
    assert not args.params
    assert not args.pretty
    assert not args.session
    assert not args.traceback
    assert args.all
    assert args.auth is None
    assert args.auth_type == 'basic'
    assert args.config_dir
    assert args.default_options == ['']
    assert args.download_resume
    assert args.json
    assert args.max_redirects == 10
    assert args.method

# Generated at 2022-06-11 22:48:24.017717
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    print('\n')
    # parse_args() is called implicitly later
    parser = HTTPieArgumentParser()
    parser.add_argument('--debug')
    # parse_args is also called in 
    #   HTTPieArgumentParser._process_session_options()
    #   HTTPieArgumentParser._parse_json_arg()
    #   HTTPieArgumentParser._parse_items()
    #   HTTPieArgumentParser._parse_items()
    parser.parse_args()
    pass

# Generated at 2022-06-11 22:48:33.958147
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    def test_parser(args, env):
        parser = HTTPieArgumentParser()
        parser.parse_args(args=args)
        return parser.args, parser.env

    from pygments import formatters as pygments_formatters
    from pygments import lexers as pygments_lexers
    from pygments.styles import get_style_by_name

    httpie_lexer = pygments_lexers.HttpLexer()
    ansi_escape_code_lexer = pygments_lexers.get_lexer_by_name('ansi')

    # I wish pygments returned a sorted list,
    # ...but it doesn't, so we must sort it.
    available_styles = sorted(get_style_by_name(style_name)
        for style_name in pygments_formatters.get_all_styles())

# Generated at 2022-06-11 22:48:34.594081
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    pass

# Generated at 2022-06-11 22:48:42.847486
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.parser import HTTPieArgumentParser
    from httpie.cli.constants import (OUTPUT_OPTIONS,
                                      OUTPUT_OPTIONS_DEFAULT,
                                      OUTPUT_OPTIONS_DEFAULT_REDIRECTED,
                                      OUTPUT_OPTIONS_DEFAULT_OFFLINE)
    from httpie.plugins import plugin_manager
    plugin_manager.discover()
    parser = HTTPieArgumentParser()
    items_arg_type = parser.get_items_arg_type()


# Generated at 2022-06-11 22:49:41.991473
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-11 22:49:48.386599
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Create instance of HTTPieArgumentParser
    args = HTTPieArgumentParser(prog='http', add_help=False)
    args.formatter_class = lambda prog: argparse.RawTextHelpFormatter(prog,width=float("inf"))
    args.add_argument('--auth', metavar='USER[:PASS]')
    args.add_argument('--auth-type', metavar='TYPE')
    args.add_argument('--body', metavar='FILE')
    args.add_argument('--config-dir', metavar='DIR')
    args.add_argument('--download', action='store_true')
    args.add_argument('--download-resume')
    args.add_argument('--form', action='store_true')

# Generated at 2022-06-11 22:49:55.541091
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-11 22:50:08.719205
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-11 22:50:11.753892
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO: Add unit tests for HTTPieArgumentParser.parse_args()
    raise ValueError('Unimplemented')

# noinspection PyShadowingBuiltins,PyUnusedLocal

# Generated at 2022-06-11 22:50:15.092387
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    with patch('sys.argv', ['http', '--timeout=123', '--timeout=234']):
        subject = HTTPieArgumentParser()
        with pytest.raises(SystemExit):
            subject.parse_args()
    assert subject.args.timeout == 234

# Generated at 2022-06-11 22:50:26.084061
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Create a HTTPieArgumentParser object
    httpieArgumentParser = HTTPieArgumentParser(env=Environment())

    # Testing the output of method HTTPieArgumentParser.parse_args for 1st code block for this method
    httpieArgumentParser.args = Mock()
    httpieArgumentParser.args.traceback = True
    httpieArgumentParser.args.version = False
    httpieArgumentParser.args.check_status = False
    httpieArgumentParser.args.follow = False
    httpieArgumentParser.args.all = False
    httpieArgumentParser.args.print_headers = 'normal'
    httpieArgumentParser.args.body_preview = None
    httpieArgumentParser.args.timeout = None
    httpieArgumentParser.args.max_redirects = None
    http

# Generated at 2022-06-11 22:50:26.978460
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    assert True


# Generated at 2022-06-11 22:50:34.332518
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

#==
    # TODO:
    #   - check for empty values in args.headers
    #   - check for empty values in args.data
#==

    # Variables
    #----------

    # sys.argv[0] = ''

    # static class members
    HTTPieArgumentParser.args = None
    HTTPieArgumentParser.command = None


# Generated at 2022-06-11 22:50:37.128168
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    test_cases = (
        ([], {}),
    )
    t = HTTPieArgumentParser()
    for test_case, expected in test_cases:
        yield (check_output_options, t, test_case, expected)

# Generated at 2022-06-11 22:52:19.078084
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from testing.httpie.core import http
    from .test_core import USER_AGENT
    from .test_core import DEFAULT_UA
    from .test_core import VERSION

    def parse(args, **kwargs):
        return http.parse_args(args.split(), **kwargs)

    ############################################################
    # Client arguments

    # --version
    args = parse(['--version'])
    assert args.version == VERSION
    assert args.debug == False

    # --debug
    args = parse(['--debug'])
    assert args.version == None

    # --ignore-stdin
    args = parse([])
    assert args.ignore_stdin == False
    args = parse(['--ignore-stdin'])
    assert args.ignore_stdin == True

    # --pretty


# Generated at 2022-06-11 22:52:24.069105
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import argparse
    argparse._sys.argv = ['http', '--print=H', 'httpbin.org']
    parser = HTTPieArgumentParser()
    parser.parse_args()
    assert parser.args.output_options == 'H'

test_HTTPieArgumentParser_parse_args()
 

# Generated at 2022-06-11 22:52:33.721280
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth

    env = Environment(colors=256)
    parser = HTTPieArgumentParser(env=env)
    env.stdout_isatty = True
    env.stderr_isatty = False
    args = parser.parse_args(argv=[
        '--auth-type=basic', '--auth=user:pass', 'httpbin.org/get'])
    assert args.auth_type == 'basic'
    assert isinstance(args.auth_plugin, HTTPBasicAuth)
    assert args.auth.orig == 'user:pass'
    assert args.auth.key == 'user'
    assert args.auth.value == 'pass'
    assert args.auth.sep == ':'

# Generated at 2022-06-11 22:52:45.543728
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """
    Unit test for method HTTPieArgumentParser.parse_args()
    """
    output_format = "json"
    output_options = ["all", "redirects", "history"]
    args = arguments.HTTPieArgumentParser.parse_args(["https://httpbin.org/get", "-X", "GET", "-o", output_format])
    assert args.output_options == "all"
    assert args.output_options_history == "all"
    assert args.output_format == output_format
    args = arguments.HTTPieArgumentParser.parse_args(["https://httpbin.org/get", "-X", "GET", "-o", output_format, "--print", ",".join(output_options)])
    assert args.output_options == "".join(output_options)

# Generated at 2022-06-11 22:52:50.452675
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    # Setup
    parser = HTTPieArgumentParser()

    # Exercise
    parser.parse_args([])

    # Verify
    assert hasattr(parser.args, '__getitem__')



# Generated at 2022-06-11 22:53:00.903046
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = HTTPieArgumentParser().parse_args([
        '--max-time', '10',
        '--json', '{"foo": "bar"}',
        'GET',
        'http://httpbin.org/ip',
        'Accept:' 'application/json',
        'X-Api-Key:' '123',
        'User-Agent:' 'custom',
        'Cookie:' 'foo=bar; baz=qux',
        'Foo:bar'
    ])
    assert args.max_time == 10
    assert args.json == {'foo': 'bar'}
    assert args.method == 'GET'
    assert args.url == 'http://httpbin.org/ip'

# Generated at 2022-06-11 22:53:08.190577
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Assertions:
    # Return the arguments to the command line with their parsed values
    # Test arguments (1 arg):
    arg_namespace = Namespace()
    arg_namespace.seed = 'seed'

    # Test function:
    arg_result = HTTPieArgumentParser.parse_args(arg_namespace)

    # Return the arguments to the command line with their parsed values
    assert arg_result == arg_namespace



# Generated at 2022-06-11 22:53:18.655723
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from click.testing import CliRunner
    from httpie.cli import main

    runner = CliRunner()
    result = runner.invoke(main)
    assert result.exit_code == 0

    # test --version
    result = runner.invoke(main, ['--version'])
    assert result.exit_code == 0

    # test --debug
    result = runner.invoke(main, ['--debug'])
    assert result.exit_code == 0

    # test --traceback
    result = runner.invoke(main, ['--traceback'])
    assert result.exit_code == 0

    # test --help
    result = runner.invoke(main, ['--help'])
    assert result.exit_code == 0

    # test --verbose
    result = runner.invoke(main, ['--verbose'])
    assert result

# Generated at 2022-06-11 22:53:29.192846
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = parser.parse_args(args=['post', 'http://httpbin.org/post', 'title=Python HTTP for Humans'])
    assert args.method == 'POST'
    assert args.url == "http://httpbin.org/post"
    assert args.data[0].key == "title"
    assert args.data[0].value == "Python HTTP for Humans"
test_HTTPieArgumentParser_parse_args()
parser = HTTPieArgumentParser(add_help=False)
args=['post', 'http://httpbin.org/post', 'title=Python HTTP for Humans']
args = parser.parse_args(args=['post', 'http://httpbin.org/post', 'title=Python HTTP for Humans'])


# Generated at 2022-06-11 22:53:36.217252
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args()
    assert isinstance(args, argparse.Namespace)
    assert repr(args).startswith("Namespace(")
    assert args.__dict__.keys() == {'url', 'headers'}
    # assert args.url == None
    # assert args.headers == []
    # assert args.method == None
    # assert args.request_item_args == []
    # assert args.files == OrderedDict()
    # assert args.data == None
    # assert args.params == OrderedDict()
    # assert args.multipart_data == False
    # assert args.method == None
    # assert args.auth == None
    # assert args.auth_type == None
    # assert args.auth_plugin == None
    #