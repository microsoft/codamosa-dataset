

# Generated at 2022-06-11 22:47:29.849786
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

    # No args
    print(parser.parse_args([]))
    # One arg
    print(parser.parse_args(["http://www.google.com"]))
    # Two args
    print(parser.parse_args(["http://www.google.com", "test=test1"]))
    # One arg -- verbose
    print(parser.parse_args(["-v", "http://www.google.com"]))
    # One arg -- verbose -- body
    print(parser.parse_args(["-v", "-b", "http://www.google.com"]))
    # One arg -- verbose -- body -- headers
    print(parser.parse_args(["-v", "-b", "-h", "http://www.google.com"]))
    # One arg --

# Generated at 2022-06-11 22:47:37.890000
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # test for method parse_args
    # of class HTTPieArgumentParser
    # given the following inputs
    parser = HTTPieArgumentParser()
    args = ['https://httpbin.org/get']
    # when I call parse_args
    result = parser.parse_args(args)
    # then I see that I get the following result
    assert isinstance(result, argparse.Namespace)
    assert 'url' in result
    assert result.url == 'https://httpbin.org/get'

# Generated at 2022-06-11 22:47:50.463633
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-11 22:47:55.560508
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # HTTPieArgumentParser.parse_args

    # Initial test
    # FIXME: what is the purpose of this test?
    parser = HTTPieArgumentParser()
    assert parser.parse_args([]) == Namespace()

    # Test that args with no defaults are processed properly
    parser = HTTPieArgumentParser()
    parser.add_argument('-p', '--print', default=None)
    parser.add_argument('-v', '--verbose', default=None, action='store_true')
    parser.add_argument('--verbose', default=None, action='store_true')
    parser.add_argument('--headers', default=None)
    parser.add_argument('--include', default=None, action='store_true')

# Generated at 2022-06-11 22:48:00.626526
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test for method parse_args
    # of class HTTPieArgumentParser
    # This method is a protected method.
    # It cannot be tested directly.
    # We need to test the public method parse_args_validate instead.
    pass


# Generated at 2022-06-11 22:48:12.389249
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args('foo bar baz'.split())
    assert args.auth == None
    assert args.data == {}
    assert args.explicit_http_version == False
    assert args.headers == []
    assert args.method == 'GET'
    assert args.params == {}
    assert args.url == 'https://foo:bar@localhost:8080/baz'
    assert args.output_file_specified == False
    assert args.output_file == None
    assert args.download == False
    assert args.follow == False
    assert args.download_resume == False
    assert args.check_status == True
    assert args.ignore_stdin == False
    assert args.stream == False
    assert args.timeout == None
    assert args.verify == True


# Generated at 2022-06-11 22:48:16.091966
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--ignore-stdin', '--json', 'get', 'httpbin.org'])
    assert args.json == True
    args = parser.parse_args(['--ignore-stdin', '--json=nocolor', 'get', 'httpbin.org'])
    assert args.prettify == 'none'
    
    
assert test_HTTPieArgumentParser_parse_args()


# Generated at 2022-06-11 22:48:17.506621
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    assert False # TODO: implement your test here


# Generated at 2022-06-11 22:48:29.791437
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie.input import SEP_CREDENTIALS, SEP_GROUP_ITEMS
    from httpie.input import SEP_HEADERS, SEP_HEADERS_EMPTY
    from httpie.input import SEP_QUERY_PARAMS, SEP_QUERY_PARAMS_EMPTY
    from httpie.cli import ENV_TRUE_OPTIONS
    from httpie.cli import AUTH_PLUGIN_MAP
    from httpie.plugins import plugin_manager
    from httpie.plugins.builtin import AuthPlugin, HTTPSClientAuthPlugin, HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBearerAuth, HTTPProxyAuth


# Generated at 2022-06-11 22:48:35.578609
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    pass # FIXME
    # Create an HTTPieArgumentParser instance
    args = ["https://httpie.org", "Accept:application/json"]
    instance = HTTPieArgumentParser(args)
    # Try to run method here
    try:
        result = instance.parse_args()
    except Exception as error:
        print(error)
# Delete all references to the instance when done
del instance


#===============================================================================
# HTTPieArgumentParser2
#===============================================================================
# noinspection PyClassHasNoInit

# Generated at 2022-06-11 22:49:23.665771
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    opts = parser.parse_args(args=[])
    assert opts is not None

# Generated at 2022-06-11 22:49:33.887453
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test case 1.
    if True:
        # Case 1.1
        with mock.patch('sys.stdin') as MOCK_sys_stdin:
            MOCK_sys_stdin.fileno.return_value = -1
            MOCK_sys_stdin.isatty.return_value = True
            with mock.patch('httpie.cli.argtypes.KeyValueArgType') as MOCK_KeyValueArgType:
                MOCK_KeyValueArgType.return_value = None
                with mock.patch('argparse.ArgumentParser._parse_known_args') as MOCK_parser__parse_known_args:
                    MOCK_parser__parse_known_args.return_value = (['1'], ['2'])

# Generated at 2022-06-11 22:49:43.696902
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # --json and --form
    with raises(ValueError):
        parse_args(args=['http', '--json', 'GET', '--form', 'httpbin.org/get'])

    # --form and --verbose
    with raises(ValueError):
        parse_args(args=['http', '--form', '--verbose', 'httpbin.org/get'])

    # --json and --verbose
    with raises(ValueError):
        parse_args(args=['http', '--json', '--verbose', 'httpbin.org/get'])

    # --output-dir and --output-file
    with raises(ValueError):
        parse_args(args=['http', '--output-dir=xy', '--output-file=xy'])

    # --output-dir and --download

# Generated at 2022-06-11 22:49:53.496076
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import os
    import sys
    import json
    import os.path

    if sys.version_info < (2, 7, 9):
        return

    # data_dir = os.path.join(os.path.dirname(__file__), 'data')

    # data = []
    # for fn in os.listdir(data_dir):
    #     with open(os.path.join(data_dir, fn)) as f:
    #         data.append((fn, json.load(f)))
    from httpie import __version__
    from httpie.core import __version__ as core_version
    from httpie.compat import is_windows, is_py26


# Generated at 2022-06-11 22:50:03.281329
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = ['root@200.27.205.17', '-h', '--json', '--verify=no', '--traceback', '-m', 'GET', '/sales/orders', 'search-by-tag=tag']
    parser = HTTPieArgumentParser()
    args = parser.parse_args(args)
    assert args.url == 'root@200.27.205.17'
    assert args.headers == ['-h']
    assert args.request_items == ['--json', '--verify=no', '--traceback']
    assert args.method == 'GET'
    assert args.parameters == ['/sales/orders', 'search-by-tag=tag']

# Generated at 2022-06-11 22:50:14.365950
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser_class = partial(HTTPieArgumentParser,
                           env=Env(config_dir=None),
                           parser_formatter_class=ParserFormatter)
    parser = parser_class()
    parser.parse_args(['--download'])
    parser.parse_args(['--download','https://www.google.com','--output','xxx'])
    parser.parse_args(['--download', 'https://www.google.com'])
    parser.parse_args(['https://www.google.com'])
    parser.parse_args(['--download', '--output', 'xxx', 'https://www.google.com'])
    parser.parse_args(['--download', '--output', 'xxx'])
    parser.parse_args(['--download'])
    parser.parse_args([])

# Generated at 2022-06-11 22:50:25.817287
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    # Unit test for method parse_args of class HTTPieArgumentParser

    HTTPieArgumentParser = HTTPieArgumentParser_()
    args = HTTPieArgumentParser.parse_args(['--json', '/get'])
    assert_equals(args.json, '/get')
    args = HTTPieArgumentParser.parse_args(['/get'])
    assert_equals(args.json, None)
    args = HTTPieArgumentParser.parse_args(['--json', '/get', '--form', 'item1=1&item2=2'])
    assert_equals(args.json, '/get')
    assert_equals(args.form, 'item1=1&item2=2')

# Generated at 2022-06-11 22:50:29.761331
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser() # create an instance
    parsed_args = parser.parse_args() # parse input args
    # 
    assert parsed_args.output_options == 'hb'
    assert parsed_args.output_options_history == 'hHbB'

# Generated at 2022-06-11 22:50:33.246532
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.add_argument('--arg')
    # noinspection PyTypeChecker
    args = parser.parse_args(['--arg', 'val'])
    assert args.arg == 'val'

# Generated at 2022-06-11 22:50:40.716414
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    #### Setup the HTTPieArgumentParser object
    argv = [
        '--form', 
        'item1=value1', 
        '--form', 
        'item2=value2', 
        '--form', 
        'item3=value3'
    ]
    parser = HTTPieArgumentParser(
        args=[],
        env=Environment(colors=256),
        stdin=None,
        stdin_isatty=False,
    )
    #### Validate the HTTPieArgumentParser.parse_args method
    args = parser.parse_args(argv=argv)
    assert args.form == env.stdin == env.stdin_isatty == None
    assert args.headers == {}
    assert args.output_file == '-'
    assert args.output_file

# Generated at 2022-06-11 22:52:15.975936
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # self, args, env, stdin=None, stdout=None, stderr=None, error=None
    argsparser = HTTPieArgumentParser(['--version'], env=Environment())
    args = argsparser.parse_args()
    assert args.version is True

# Generated at 2022-06-11 22:52:25.714453
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    _args = HTTPieArgumentParser(
            formatter_class=argparse.RawDescriptionHelpFormatter,
            prog='http',
            usage='''\
http [<url>] [<method>] [<args>]

A curl-like, modern command line HTTP client.

See http://httpie.org/ or run `http --help`.
''',
            description='''\
For the first positional argument, http will interpret the
value as a URL if it includes only URL-decodable characters,
does not contain spaces, and does not start with a dash (-)
or a double dash (--).
''',
            epilog='httpie %s, cURL %s' % (__version__, curl_version),
            add_help=False,
            allow_abbrev=False)
    args = _args.parse_

# Generated at 2022-06-11 22:52:29.082992
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httppie = HTTPieArgumentParser('')
    args, extra = httppie._parse_args()
    return args.verbose
print(test_HTTPieArgumentParser_parse_args())


# Generated at 2022-06-11 22:52:30.223325
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    assert "Not implemented"

# Generated at 2022-06-11 22:52:42.944377
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-11 22:52:49.078940
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import sys
    # Note: For a stdout redirect, stdin will be closed.
    # Use `cat` to prevent that.
    # python test/unit/test_args.py 2>/dev/null <(echo 'Hello World!')
    # python test/unit/test_args.py < test/unit/test_args_stdin.txt
    # stdout_fd = redirect_fd(sys.stdout, 'test/unit/test_args_stdout_ref.txt')
    # stderr_fd = redirect_fd(sys.stderr, 'test/unit/test_args_stderr_ref.txt')
    # sys.stdout.write('Hello World!\n')
    # stdout_fd.close()
    # stderr_fd.close()
    parser = HTTPieArgumentParser

# Generated at 2022-06-11 22:53:00.077503
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
	import sys
	import traceback
	sys.tracebacklimit=1
	args=['https://httpie.org/','--verbose','--ignore-stdin','--download','--output','abc','--form','--follow','--headers','asciinema-player https://asciinema.org/a/58438.js']
	parser=HTTPieArgumentParser
	try:
		ret=parser.parse_args(args, env=None, stdin_isatty=False, stdout_isatty=False, stderr_isatty=False, devnull=None)
	except Exception as e:
		print('Exception: ' + str(e))
		traceback.print_exc()
		return 1

test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-11 22:53:11.916651
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Input data
    input_args = ["GET", "http://httpbin.org/status/200"]
    # Expected output data
    expected_args = Namespace(all=False, auth=None, auth_type='basic', data=None, description=True, follow=False, form=False, headers=None, ignore_stdin=False, json=False, output_file=None, params=None, pretty='all', print_body='all', print_headers='always', progress_bar=True, query_params=None, raise_errors=True, request_items=None, session=None, session_read_only=False, session_write=True, timeout='30', traceback=False, verbose=1, version=False)
    # Run the code to be tested
    args = HTTPieArgumentParser().parse_args(input_args)

# Generated at 2022-06-11 22:53:22.111497
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-11 22:53:31.480632
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = 'httpbin.org/get --headers "key1:value1" "key2:value2" --timeout=3'
    parser = HTTPieArgumentParser()
    parser.parse_args(args)
    assert parser.args.url == 'httpbin.org/get'
    assert parser.args.headers == [('KEY1:VALUE1', 'key1'), ('KEY2:VALUE2', 'key2')]
    assert parser.args.timeout == 3
    args = 'httpbin.org/get --output=test.json --headers "key1:value1" "key2:value2" --timeout=3'
    parser = HTTPieArgumentParser()
    parser.parse_args(args)
    assert parser.args.url == 'httpbin.org/get'