

# Generated at 2022-06-11 22:47:33.723839
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test that there are options that are executable 
    # after parsing the command-line input.
    
    # Command-line input
    url = "https://httpbin.org/get"
    
    
    # Parse the command-line input
    args = HTTPieArgumentParser().parse_args(args=[url])
    
    # Test that there are options that are executable 
    # after parsing the command-line input.
    assert args.output_options is not None
    assert args.print_body is not None
    assert args.prettify is not None
    assert args.history_options is not None
    assert args.style is not None
    assert args.style_sheet is not None
    assert args.debug is not None
    assert args.traceback is not None
    assert args.download is not None

# Generated at 2022-06-11 22:47:42.624280
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    parser.add_argument('-v', '--verbose', action='count')
    parser.add_argument('-o', '--output', type=argparse.FileType('wb'))
    args = parser.parse_args()
    
    env = Environment()
    env.config = Config()
    parser = HTTPieArgumentParser(
        env=env,
        args=args,
        formatter_class=SmartHelpFormatter
    )
    
    parser.add_argument('--bar')
    parser.add_argument('--baz', dest='baz_dest')
    parser.convert_arg_line_to_args = lambda arg_line: arg_line.split()

# Generated at 2022-06-11 22:47:53.345980
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.parser.parse_args(['GET', 'http://httpbin.org/get'])
    parser.parser.parse_args(['http://httpbin.org/get'])
    parser.parser.parse_args(['GET', 'http://httpbin.org/get', 'Yay!'])
    parser.parser.parse_args(['GET', 'http://httpbin.org/get', 'foo:bar'])
    parser.parser.parse_args(['--traceback', 'GET', 'http://httpbin.org/get', 'Yay!'])
    parser.parser.parse_args(['--traceback', 'GET', 'http://httpbin.org/get', 'Yay!'])

# Generated at 2022-06-11 22:48:05.539942
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = HTTPieArgumentParser().parse_args()
    print(args)
# Test case
test_HTTPieArgumentParser_parse_args()

# output

# Generated at 2022-06-11 22:48:16.420457
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-11 22:48:19.500625
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    with pytest.raises(SystemExit):
        HTTPieArgumentParser().parse_args(['--help'])

# Generated at 2022-06-11 22:48:21.444042
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    assert HTTPieArgumentParser(None, None).parse_args()


# Generated at 2022-06-11 22:48:32.016975
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    sys.stdout = io.StringIO()
    sys.stderr = io.StringIO()
    # We need to create an instance of the HTTPieArgumentParser class.
    h = HTTPieArgumentParser()
    # We need to process the parse_known_args to test the parse_args method.
    h.parse_known_args()
    assert h == h.parse_args()
    # We are just testing the parse_args method, so we need to run the 
    # command as though the object is running from the command line.
    sys.argv[1:] = ['-v', '-H', 'Accept: text/html', 'https://httpbin.org/get']
    assert h == h.parse_args()
# We will now test the Error Handling for if no arguments are passed.

# Generated at 2022-06-11 22:48:40.997488
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """Test the HTTPieArgumentParser.parse_args method with a simple list of args
    for GET request
    """
    
    args1 = ["http", "localhost:9090/python/get_simple_list/list_app/list_app.py", "--json", "--verbose"]
    args2 = ["http", "localhost:9090/python/get_simple_list/list_app/list_app.py", "X-API-Key:123", "--json", "--verbose"]
    args3 = ["http", "localhost:9090/python/get_simple_list/list_app/list_app.py", "id=1", "--json", "--verbose"]

# Generated at 2022-06-11 22:48:43.261424
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import __main__  # noqa
    args = HTTPieArgumentParser().parse_args(from_args=None)
    print(args)

if __name__ == '__main__':
    test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-11 22:49:46.530807
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import io

# Generated at 2022-06-11 22:49:49.286532
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO: Need to replace with a test case
    parser = HTTPieArgumentParser()
    args = parser.parse_args()



# Generated at 2022-06-11 22:49:55.937843
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie.client import Environment
    from httpie.config import Config
    from httpie import input
    # TODO: No mocking framework for now.
    input.isatty = lambda _: False
    env = Environment()
    env.use_colors = False
    env.stdin = io.StringIO("curl 'http://httpbin.org/get'")
    env.config = Config()

    parser = HTTPieArgumentParser()
    args = parser.parse_args(env=env)
    # print(args)
    assert args.url == "http://httpbin.org/get"
    assert args.headers == []
    assert args.method == "GET"
    assert args.auth is None
    assert args.auth_type is None
    assert not args.ignore_netrc
    assert args.ignore_std

# Generated at 2022-06-11 22:50:02.986284
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.parse_args(['-X', 'GET', 'http://example.com', '--traceback'])
    parsed_args = parser.parse_args(['-X', 'GET', 'http://example.com', '--traceback'])
    assert isinstance(parsed_args, Namespace)
    assert parsed_args.method == 'GET'


# Generated at 2022-06-11 22:50:14.244375
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser(prog='http', epilog='See https://github.com/jakubroztocil/httpie for more details.')
    parser.add_argument('-v', '--verbose', action='store_true', help='Print the whole request as well as its response.')
    parser.add_argument('-b', '--body', dest='request_items', action=KeyValueArg, help='The request item.', env_var='HTTPIE_BODY_ITEMS')
    parser.add_argument('-r', '--referer', dest='headers', action=HeaderArg, help='Set Referer header.', env_var='HTTPIE_REFERER_HEADER')

# Generated at 2022-06-11 22:50:21.905280
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test
    c = HTTPieArgumentParser()
    arg = c.parse_args(args=['--assert=code:200', 'GET', 'https://httpbin.org/get'])
    # Assert
    assert arg.assert_.value == "code:200"
    assert arg.method == "GET"
    assert arg.url == "https://httpbin.org/get"


# Generated at 2022-06-11 22:50:29.964274
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    '''
    Test whether the method parse_args of class HTTPieArgumentParser 
    works as expected
    '''
    arguments = '--body test.json http://127.0.0.1:5000/books'
    fileobj = io.open('test.json', 'wb')
    test_json = '{"name" : "book", "author" : "test"}'
    fileobj.write(test_json.encode('utf-8'))
    fileobj.close()
    args = HTTPieArgumentParser().parse_args(arguments.split())
    assert args.url == 'http://127.0.0.1:5000/books'
    assert args.data == test_json
    os.remove('test.json')

# Generated at 2022-06-11 22:50:39.030383
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser(add_help=False)
    # 1) Try to set the method to "GET" and the url to "http://www.google.com"
    result = parser.parse_args(args=["GET","http://www.google.com"])
    assert result.method == "GET" and result.url == "http://www.google.com"
    # 2) Try to set the User-Agent to "Mozilla/5.0" and the url to "http://www.google.com", 
    #    with a GET request as the method
    result = parser.parse_args(args=["--headers","User-Agent: Mozilla/5.0", "http://www.google.com"])

# Generated at 2022-06-11 22:50:50.986614
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Make a new instance of HTTPieArgumentParser to be used in the unit test
    parser = HTTPieArgumentParser()
    
    # Make sure that HTTPieArgumentParser is an instance of argparse.ArgumentParser
    assert isinstance(parser, argparse.ArgumentParser)
    
    # Store argparse.ArgumentParser.parse_args in a variable 
    # so that it can be called in the unit test
    parse_args = parser.parse_args
    
    # Call argparse.ArgumentParser.parse_args with the following arguments
    args = parse_args([])
    
    # Make sure that parse_args returns an instance of argparse.Namespace
    assert isinstance(args, argparse.Namespace)

    # Check the type of args.auth
    assert type(args.auth) == type(None)


# Generated at 2022-06-11 22:50:54.529656
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_arg_parser=HTTPieArgumentParser()
    url='http://api.com/apidoc'
    args=httpie_arg_parser.parse_args(args=[url],env={})
    assert args.url==url

# Generated at 2022-06-11 22:52:04.070443
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser(httpie_version = "1.0.0", full_version = "1.0.0")
    with tmp_file_path("-d={'a':'1'} -u a:b") as fd:
        args = parser.parse_args(['--verbose', fd])
    assert args.url == "http://a:b"
    assert args.data == '{"a": "1"}'
    assert args.headers == []
    assert args.method == "GET"
    
    with tmp_file_path("GET http://example.org") as fd:
        args = parser.parse_args(['--verbose', fd])
    assert args.url == "http://example.org"
    assert args.method == "GET"
    assert args.headers == []


# Generated at 2022-06-11 22:52:14.542584
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO: Complete this unit test function
    env = AttrDict()
    env.stdin = sys.stdin
    env.stdin_isatty = False
    env.stdout = sys.stdout
    env.stdout_isatty = False
    env.stderr = sys.stderr
    env.stderr_isatty = False
    args = []
    args.append('http')
    args.append('--form')
    args.append('POST')
    args.append('--json')
    args.append('/json-print')
    args.append('--auth-type=basic')
    args.append('--auth=user:12345')
    if PY26:
        args.append('--ignore-stdin')

# Generated at 2022-06-11 22:52:24.981763
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie import __version__
    from httpie.core import DEFAULT_CONFIG_DIR
    from httpie.config import UNSET
    from httpie.config import get_default_config_dir
    import os
    import sys
    import tempfile
    import warnings

    def mock_get_config_dir(fallback=None):
        return os.path.join(tempfile.gettempdir(), 'httpie_%s' % os.getpid())

    import httpie
    from httpie import __main__
    from httpie.cli.parser import HTTPieArgumentParser, HTTPieArgumentError
    from httpie.__main__ import parser
    from httpie.cli.parser import NO_ARGV_OPTIONS
    import httpie.cli.config
    from httpie.cli.config import _default_options

   

# Generated at 2022-06-11 22:52:26.722342
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # data
    # instantiate
    # method
    # assert

    pass


# Generated at 2022-06-11 22:52:34.728623
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """
    Test HTTPieArgumentParser.parse_args

    """

    h = HTTPieArgumentParser()
    # Test adding arguments
    h.add_argument('--arg1', '-A1')
    h.add_argument('--arg2', '-A2')
    # Test conflict resolution
    h.add_argument('--arg1', '-a1')

    cases = (
        ('arg1', ('-A1', True)),
        ('arg1', ('-a1', False)),
        ('arg2', ('--arg2', None)),
    )

    for arg, case in cases:
        # Test parsing
        args = h.parse_args(list(case[0]))
        assert getattr(args, arg) == case[1]

    # Test handling incorrect arguments

# Generated at 2022-06-11 22:52:45.757655
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-11 22:52:46.393842
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    pass

# Generated at 2022-06-11 22:52:56.582596
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """
    自动化测试 HTTPieArgumentParser 的 parse_args 方法
    """

    # 使用全局变量的 HTTPieArgumentParser 的 parse_args 方法
    r = parse_args(['GET', 'http://httpbin.org/headers'])
    assert r.method == 'GET'
    assert r.url == 'http://httpbin.org/headers'
    assert r.verbose == False

    # 使用实例的 HTTPieArgumentParser 的 parse_args 方法
    parser = HTTPieArgumentParser()
    parser.env = Environment()
    r = parser.parse_args(args=['GET', 'http://httpbin.org/headers'])


# Generated at 2022-06-11 22:53:04.529001
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from io import StringIO
    from httpie.config import Config
    from httpie.context import Environment
    env = Environment()
    # Get default config
    config = Config(env)
    parser = HTTPieArgumentParser(
            prog='http',
            env=env,
            config=config,
            include_default_options=False)
    parser.add_argument('--form', action='store_true')
    parser.add_argument('--print', choices=OUTPUT_OPTIONS)
    parser.add_argument('--output-options', '--opts', default=[],
            action=StoreUniqueCombination,
            parser=lambda s: s.split(','))

# Generated at 2022-06-11 22:53:06.200213
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    pass


# Generated at 2022-06-11 22:54:56.338309
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """
    The argument parser is the top-level entry point to the command line 
    parameters
    """
    pass


# Generated at 2022-06-11 22:55:05.508246
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # noinspection PyProtectedMember
    sys.argv = ['http', 'https://httpbin.org/get']
    cli_args = HTTPieArgumentParser().parse_args(sys.argv[1:])
    # noinspection PyProtectedMember

# Generated at 2022-06-11 22:55:07.335149
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO: Perform unit test
    pass



# Generated at 2022-06-11 22:55:09.724451
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    runner = CliRunner()
    result = runner.invoke(cli.main)
    assert result.exit_code == 0



# Generated at 2022-06-11 22:55:16.705373
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Load test data from file 'test_HTTPieArgumentParser_parse_args.json'
    test_values_file = os.path.join(
        os.path.dirname(__file__),
        'test_HTTPieArgumentParser_parse_args.json'
    )
    test_values = json.loads(open(test_values_file).read())

    def execute_parse_args(argv):
        parser = HTTPieArgumentParser(
            env=Environment()
        )
        args = parser.parse_args(argv.split())

# Generated at 2022-06-11 22:55:22.379691
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    class CliStub(object):
        """
        A stub class to mock the method exit of argparse.ArgumentParser.

        """
        def __init__(self):
            #: the status code
            self.exit_status = 0

        def exit(self, status, *args):
            self.exit_status = status

    class EnvStub():
        """
        A stub class to mock the Env class
        (args is passed by reference to History class)

        """
        def __init__(self, args):
            self.args = args
            self.config = dict()
            self.stdout = sys.stdout

    httpie = HTTPieArgumentParser(cli=CliStub(), env=EnvStub(args=[]))
    # test the default value of --timeout in the method parse_args


# Generated at 2022-06-11 22:55:31.458697
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = ["--help"]
    HTTPieArgumentParser.parse_args(args)
    args = ["https://httpbin.org/get"]
    HTTPieArgumentParser.parse_args(args)
    args = ["https://httpbin.org/get", "X-API-Token:12345"]
    HTTPieArgumentParser.parse_args(args)
    args = ["https://httpbin.org/get", "--auth=admin:admin"]
    HTTPieArgumentParser.parse_args(args)
    args = ["https://httpbin.org/get", "--auth-type=basic"]
    HTTPieArgumentParser.parse_args(args)
    args = ["https://httpbin.org/get", "--download"]
    HTTPieArgumentParser.parse_args(args)

# Generated at 2022-06-11 22:55:32.521705
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    pass
# noinspection PyMethodMayBeStatic

# Generated at 2022-06-11 22:55:40.643059
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    ap = HTTPieArgumentParser()
    stdin_data = BytesIO(b"foo")
    ap.env.stdin = stdin_data
    ap.env.stdin_isatty = False
    args = ap.parse_args([
        'GET',
        'https://httpie.org',
        'Accept:text/html',
        'If-None-Match:"686897696a7c876b7e"'
        ])
    print(args.headers)
    print(args.data)

# Generated at 2022-06-11 22:55:46.355664
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Retrieve a test example as if we were running httpie as a script
    http_test = subprocess.run(['http', '--help'], shell=False, stdout=subprocess.PIPE)
    output = http_test.stdout
    parsed_arguments = HTTPieArgumentParser.parse_args(output)