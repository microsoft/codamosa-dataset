

# Generated at 2022-06-11 22:47:29.540882
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Parameter 1, argv: a list of strings of various lengths
    argv = ['http', '--timeout', '100', '--ignore-stdin', '--auth', 'user:pass', '--json', '--pretty', 'all', '--print', 'b', 'httpbin.org/get']
    
    # Parameter 2, env: environment object
    env = Environment(colors=256, default_options=[], is_windows=False, stdin=None, stdin_isatty=True, stdout=None, stdout_isatty=True, stderr=None, stderr_isatty=True)
    
    # creating objects for all classes used in the method 
    parser = HTTPieArgumentParser()
    parser.args = Namespace()
    parser.args.timeout = None

# Generated at 2022-06-11 22:47:40.535144
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Create a parser without arguments that should not be tested specifically
    parser = HTTPieArgumentParser()
    
    # Create a test case

# Generated at 2022-06-11 22:47:51.694997
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = ['--traceback',
            '--follow',
            '--max-redirects=3',
            '--verify=no',
            '--auth-type=basic',
            '--auth=john:123',
            '--timeout=3',
            '--check-status',
            '-v',
            'GET',
            'localhost:8080',
            'X-API-Token:12345',
            'name==John',
            'status:=active',
            'groups:=[1,2,3]',
            '@test.txt',
            'httpbin.org/post']

    httpie_argparser = HTTPieArgumentParser(prog="http")
    httpie_argparser.add_argument('--traceback')
    httpie_argparser.add_argument('--follow')


# Generated at 2022-06-11 22:48:03.988704
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """Unit test for method parse_args of class HTTPieArgumentParser"""
    parser = HTTPieArgumentParser()
    #test parse_args with a valid url and without ignore stdin
    url = 'https://httpbin.org/'
    args = parser.parse_args([url])
    assert args.url == 'https://httpbin.org/'
    assert args.ignore_stdin == False
    #test parse_args with a valid url and with ignore stdin, 
    #no data in stdin should be read
    args = parser.parse_args([url, '--ignore-stdin'])
    assert args.url == 'https://httpbin.org/'
    assert args.ignore_stdin == True
    #test that exception is thrown when no url is given
    with pytest.raises(SystemExit):
        args

# Generated at 2022-06-11 22:48:15.344495
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Create a mock of the class HTTPieArgumentParser
    # This instance is going to be used as a context in the with clause,
    # and so, it must implement the __enter__ and __exit__ methods.
    mock_parser = Mock(spec=HTTPieArgumentParser)
    mock_parser.__enter__ = Mock()
    mock_parser.__exit__ = Mock()
    
    # Create a mock that simulates the arguments of argparser.parse_args.
    # This mock will receive the call of the method parse_args when it is executed.
    mock_parse_args = Mock()
    mock_parse_args.return_value = Mock()
    
    # Configure to mock object to simulate the behaviour of argparser.parse_args.
    mock_parser.parse_args = mock_parse_args
    
    # Create a

# Generated at 2022-06-11 22:48:19.499773
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.add_argument('-v', '--verbose', default=0)
    args = parser.parse_args(['-v', '2'])
    assert args.verbose == 2

# Generated at 2022-06-11 22:48:27.401073
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h = HTTPieArgumentParser()
    h.parse_args(['--json', '{ "a": 1, "b": 2 }'])
    print(h.args.json)
    # TODO: finish the test
test_HTTPieArgumentParser_parse_args()

# This class is based on the class in Python 3.8
# The original source code is avaliable at:
# https://github.com/python/cpython/blob/master/Lib/argparse.py


# Generated at 2022-06-11 22:48:33.284294
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Create an instance of HTTPieArgumentParser
    http_argument = HTTPieArgumentParser()
    # Create an instance of `argparse.Namespace`
    test_args = Namespace()
    # Create a stub to hold the arguments as a list of strings
    args = []

    # Example of result for parsing the arguments and
    # Return a Namespace with the arguments passed
    # assert http_argument.parse_args(args, test_args) == Namespace(arguments=[])
    pass

# Generated at 2022-06-11 22:48:36.285034
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # test case 1: no options
    test_args = []
    args = HTTPieArgumentParser(env=Environment()).parse_args(args=test_args)
    assert hasattr(args, 'help') # args has function help()


# Generated at 2022-06-11 22:48:44.052141
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # User provided arguments
    args = "httpie https://rameshb.com"
    args = args.split()

    # calling the HTTPieArgumentParser.parse_args method
    httpie_parser = HTTPieArgumentParser()
    parsed_args = httpie_parser.parse_args(args)

    # asserting that url passed by user is converted to a valid url
    assert parsed_args.url == 'https://rameshb.com/'

    # validating the output of the parsed arguments
    assert isinstance(parsed_args, argparse.Namespace)
    assert parsed_args.url == 'https://rameshb.com/'
    assert parsed_args.config_dir == '~/.httpie'
    assert parsed_args.config_file == ['~/.httpienrc']

# Generated at 2022-06-11 22:49:43.184929
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    argv = [
        'http', '--json', '--follow', 'GET',
        'https://httpbin.org/get',
        'foo==bar', 'bar==baz'
    ]
    args = HTTPieArgumentParser().parse_args(argv)
    assert args.request_items == [KeyValue(key='foo', value='bar', sep='=='), KeyValue(key='bar', value='baz', sep='==')]
    assert args.headers == {'Content-Type': 'application/json'}
    assert args.method == 'GET'
    assert args.follow



# Generated at 2022-06-11 22:49:46.251667
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    '''
    Unit test for method parse_args of class HTTPieArgumentParser
    '''
    h = HTTPieArgumentParser()
    
    
    

# Generated at 2022-06-11 22:49:54.915732
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parse = parser.HTTPieArgumentParser().parse_args
    # No args

# Generated at 2022-06-11 22:50:06.528012
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    assert HTTPieArgumentParser.parse_args(
        ['www.google.com','Authorization','Token','TOKEN','name','mayank']
    ).request_items==[
        KeyValueArgType(
            key='Authorization',
            value='Token',
            sep=' ',
            orig='Authorization Token',
        ),
        KeyValueArgType(
            key='TOKEN',
            value='name',
            sep='=',
            orig='TOKEN=name',
        ),
        KeyValueArgType(
            key='',
            value='mayank',
            sep='',
            orig='mayank',
        ),
    ]
test_HTTPieArgumentParser_parse_args()

 

# Generated at 2022-06-11 22:50:16.041259
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    try:
        os.remove('output.txt')
    except:
        pass

    ap = HTTPieArgumentParser()

# Generated at 2022-06-11 22:50:21.481417
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http', 'https://http.cat/', 'User-Agent:Mozilla/5.0'])
    assert args.headers == {'User-Agent':'Mozilla/5.0'}

# Generated at 2022-06-11 22:50:30.129487
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = HTTPieArgumentParser(prog="http", add_help=False,
                                output_stream=_StringIO())
    args.parse_args([
        '--auth', 'user:passwd',
        '--max-headers', '100',
        '--ignore-stdin',
        '--form',
        '--headers',
        '--style', 'solarized',
        '--print', 'url,h',
        '--print-body=all',
        '--compress',
        'https://httpbin.org/get',
        'key=val'
    ])
    assert args.args.auth == 'user:passwd'
    assert args.args.max_headers == 100
    assert args.args.ignore_stdin
    assert args.args.form
    assert args.args.headers


# Generated at 2022-06-11 22:50:39.170665
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    desc = "HTTPie - a CLI, cURL-like tool for humans."
    epilog = "Paths, queries, and headers can be prefixed with: :, $, or ?"
    version = httpie.__version__
    filename = "httpie.rst"

    parser = HTTPieArgumentParser(desc=desc, epilog=epilog, version=version)

    args = parser.parse_args(["--version","httpie.org"])
    parser.print_version()

    args = parser.parse_args(["--help","httpie.org"])

    with open(filename, 'r') as f:
        args = parser.parse_args(["--help", "--man", "--man-file", filename, "httpie.org"])
        parser.print_man_page(f)


# Generated at 2022-06-11 22:50:42.331259
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    argv = []
    args = HTTPieArgumentParser().parse_args(argv)
    assert False # TODO: implement your test here


# Generated at 2022-06-11 22:50:53.792328
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import argparse.namespace
    
    # create a mock object that implements a `error` method
    class MockArgs(object):
        def error(self, *args, **kwargs):
            pass
    
    # create an instance of the class to be tested
    httpie_argument_parser = HTTPieArgumentParser()
    httpie_argument_parser.error = MockArgs().error
    
    # create the source data
    args = [u'http']

    # the call to be tested
    try:
        result = httpie_argument_parser.parse_args(args=args)
    except Exception as err:
        print("{0}".format(err))
        assert False
    
    # the expected result

# Generated at 2022-06-11 22:52:33.152643
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    if sys.version_info >= (3, 0):
        raise Exception('Please test on Python 2.x')

    from colorama import Fore, Style

# Generated at 2022-06-11 22:52:45.334500
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    env = Environment()
    kwargs = {
        'prog': 'http',
        'formatter_class': ArgumentDefaultsHelpFormatter,
        'add_help': False,
        'env': env,
        'usage': '',
        'complete_invalid_option': False,
    }
    parser = HTTPieArgumentParser(**kwargs)
    args = parser.parse_args(args=[])
    assert args.json == False
    assert args.pretty == False
    assert args.style == 'default'
    assert args.style_sheet == None
    assert args.download == False
    assert args.timeout == None
    assert args.check_status == True
    assert args.follow == False
    assert args.all == False
    assert args.headers == True
    assert args.body == True
    assert args

# Generated at 2022-06-11 22:52:56.004475
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie = HTTPieArgumentParser()

    args = httpie.parse_args(['https://httpbin.org/get'])

    # convert the argparse.Namespace object to JSON to compare

# Generated at 2022-06-11 22:53:04.187260
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    res = HTTPieArgumentParser()
    args = [
        '--style=colors',
        '--style=colors',
        'httpbin.org/ip',
        'Accept:application/json',
        'User-Agent:Mozilla/5.0 (X11; Linux x86_64)',
        'Cookie:foo=bar;bar=baz',
        'Connection:close',
        '--form',
        'a=b',
        'c=d'
    ]
    args = res.parse_args(args)
    assert args.url == 'httpbin.org/ip'

# Generated at 2022-06-11 22:53:16.227185
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    HELP_TYPE = 'help'
    VERSION_TYPE = 'version'
    DEBUG_TYPE = 'debug'
    COLOR_TYPE = 'color'
    COLOR_OPTIONS = ['never', 'always', 'auto', 'auto_no_invert']
    COLOR_DEFAULT = 'auto'
    PRETTY_OPTIONS = ['all', 'none', 'colors', 'format',
                      'format_human', 'colors_human']

# Generated at 2022-06-11 22:53:21.894041
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = HTTPieArgumentParser().parse_args(
        ['https://google.com', '--json', '--print', 'b']
    )
    assert args.url == 'https://google.com'
    assert args.output_options == 'b'
    assert args.prettify == True
    # noinspection PyProtectedMember
    assert args.print_body == True

test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-11 22:53:31.292186
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args([])
    assert args.method == None
    assert args.download == False
    assert args.output_file == None
    assert args.headers == []
    assert args.auth == None
    assert args.params == []
    assert args.files == {}
    assert args.data == None
    assert args.output_file_specified == False
    assert args.offline == False
    assert args.verbose == False

    args = parser.parse_args(['-m', 'POST', '--download', '--output', 'file', '-H', 'a:v', '-A', 'u:p', '-P', 'k:v', '@f', '-j', '{}', '-v'])
    assert args.method == 'POST'


# Generated at 2022-06-11 22:53:32.459692
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO:
    pass
# class HTTPieArgumentParser


# Generated at 2022-06-11 22:53:33.704208
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.parse_args([])

# Generated at 2022-06-11 22:53:44.085417
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import io
    from httpie.context import Environment
    from httpie.plugins import plugin_manager
    environment = Environment()
    args = HTTPieArgumentParser(
        env=environment,
        usage=USAGE,
        description=DESCRIPTION,
        epilog='''\
Documentation: https://httpie.org
Complete documentation: https://httpie.org/docs
''',
        formatter_class=CustomHelpFormatter,
        add_help=False
    ).parse_args([])
    assert args.help is False
    assert args.headers is None
    assert args.auth is None
    assert args.auth_type is None
    assert args.timeout is None
    assert args.max_redirects is 30
    assert args.method is None
    assert args.json is False
    assert args.pretty is False


# Generated at 2022-06-11 22:55:39.472874
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import sys
    import io

    # construct the argument parse and parse the arguments
    parser = HTTPieArgumentParser()
    parser.version = '2.0.0'

# Generated at 2022-06-11 22:55:41.909464
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    HTTPieArgumentParser_instance = HTTPieArgumentParser()
    with pytest.raises(SystemExit):
        HTTPieArgumentParser_instance.parse_args()

# Generated at 2022-06-11 22:55:53.103151
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args()
    assert args.auth == None
    assert args.auth_plugin == None
    assert args.headers == {'Content-Type': 'application/json'}
    assert args.data == None
    assert args.files == {}
    assert args.form == False
    assert args.params == {}
    assert args.json == True
    assert args.output_file == None
    assert args.download == False
    assert args.max_redirects == 30
    assert args.method == None
    assert args.url == None
    assert args.max_content == None
    assert args.output_options == 'hB'
    assert args.output_options_history == 'hB'
    assert args.prettify == PRETTY_MAP['all']
   

# Generated at 2022-06-11 22:55:55.692581
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """
    Test parse_args method of class HTTPieArgumentParser
    """
    pass
# Unit tests for class HTTPieArgs

# Generated at 2022-06-11 22:56:00.211509
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = HTTPieArgumentParser(
        prog = 'http',
        version='2.6.0'
    ).parse_args(['--version'])
    assert args.version


    args = HTTPieArgumentParser(
        prog = 'http',
        version='2.6.0'
    ).parse_args(['--version'])
    assert args.version



# Generated at 2022-06-11 22:56:05.322556
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_parser = HTTPieArgumentParser()
    args = httpie_parser.parse_args(['https://httpbin.org/get'])
    assert hasattr(args, 'url')
    assert args.url == 'https://httpbin.org/get'
    assert args.output_file == None
    assert args.output_options == None
test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-11 22:56:14.377969
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    env = Environment()    
    parser = HTTPieArgumentParser(
        env=env,
        prog='http',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description=__doc__,
        epilog=None,
        allow_abbrev=False,
    )

    # test absolute url, no args
    args = parser.parse_args(
        [
            'http://httpbin.org/'
        ]
    )

# Generated at 2022-06-11 22:56:22.017443
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http://localhost'])
    assert args.url == 'http://localhost'
    args = parser.parse_args(['http://localhost', '--json'])
    assert args.json is True
    args = parser.parse_args(['http://localhost', '--json', '{"key": "value"}'])
    assert args.json is True
    assert args.data == '{"key": "value"}'

# Generated at 2022-06-11 22:56:24.199897
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    HTTPieArgumentParser.parse_args()
    pass
    ##print (str(HTTPieArgumentParser.parse_args()))

# Generated at 2022-06-11 22:56:27.352744
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    HTTPieArgumentParser_instance = HTTPieArgumentParser()
    args = HTTPieArgumentParser_instance.parse_args(['test_test'])
    assert args.test == 'test_test'
