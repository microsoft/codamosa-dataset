

# Generated at 2022-06-11 22:47:31.390374
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import imp, os, sys
    root_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
    library = imp.load_source(
        'httpie', os.path.join(root_dir, 'http', '__init__.py')
    )
    sys.modules['httpie.__main__'] = sys.modules['httpie']
    httpie = library.__main__

    # Note: The following tests have been adapted from the unit test of
    # `httpie.cli.parser.parse_args`

    def parse(*args, **kwargs):
        args = list(args)
        parser = httpie.get_parser()

# Generated at 2022-06-11 22:47:41.657756
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-11 22:47:52.148204
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """Unit test for method parse_args of class HTTPieArgumentParser"""
    parser = HTTPieArgumentParser()
    # parser.parse_args(args)
    parser = HTTPieArgumentParser()
    parser.parse_args([])
    # parser.parse_args(args)
    parser = HTTPieArgumentParser()
    parser.parse_args(['--auth', 'custom', '-u', 'SOMEUSER', '-H', 'Content-Type: application/json', 'https://httpbin.org/anything'])
    # parser.parse_args(args)
    parser = HTTPieArgumentParser()

# Generated at 2022-06-11 22:48:04.513737
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()    
    args = parser.parse_args(['-vh'])
    assert(args.verbose == True)
    assert(args.headers == True)
    assert(args.traceback == False)
    assert(args.all == True)

    args = parser.parse_args(['-v', '--traceback', '-H'])
    assert(args.verbose == True)
    assert(args.headers == False)
    assert(args.traceback == True)
    assert(args.all == False)

    args = parser.parse_args(['-v', '--traceback', '-H', '-b', 'json'])
    assert(args.verbose == True)
    assert(args.headers == False)
    assert(args.traceback == True)
   

# Generated at 2022-06-11 22:48:14.728277
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import sys
    args = ['-iv','-X','POST', 'httpbin.org', 'foo==bar']
    env = Environment()

    parser = HTTPieArgumentParser(env)
    parsed_args = parser.parse_args(args=args)

    sys.modules['__main__'].__file__ = 'http'
    assert parsed_args.method == 'POST'
    assert parsed_args.traceback is True
    assert parsed_args.verbose is True
    assert parsed_args.url == 'httpbin.org'
    assert parsed_args.data == [KeyValue(key='foo', value='bar')]

test_HTTPieArgumentParser_parse_args()


# Generated at 2022-06-11 22:48:26.842434
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from io import StringIO
    from httpie.config import Environment, DEFAULT_CONFIG_DIR
    from httpie.context import Environment as Env
    from httpie.plugins import plugin_manager
    from httpie.compat import str

# Generated at 2022-06-11 22:48:31.940754
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_arg_parser = HTTPieArgumentParser()
    assert httpie_arg_parser.parse_args([])

    args = httpie_arg_parser.parse_args(['httpie'])
    assert args.url == 'httpie'

    args = httpie_arg_parser.parse_args(['httpie', 'localhost:8000'])
    assert args.url == 'localhost:8000'



# Generated at 2022-06-11 22:48:40.966809
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-11 22:48:46.410874
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    HTTPieArgumentParser.parse_args(['--help'])
    HTTPieArgumentParser.parse_args(['--debug'])
    HTTPieArgumentParser.parse_args(['--version'])

# Generated at 2022-06-11 22:48:50.808109
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    d = {'http_class': http_classes.HTTPiePythonRequests}
    c = cli.HTTPieArgumentParser(**d)
    c.parse_args([])
    url = "http://www.google.com"
    c.parse_args([url])
    c.parse_args(["--method", "GET", url])
    c.parse_args(["-f", url])
    c.parse_args(["--form", url])
    c.parse_args(["--verbose", url])
    c.parse_args(["--auth-type=basic", url])
    # Test the setting of request data and headers
    c.parse_args(["--data", "foo=bar", url])
    c.parse_args(["--data", "'foo=bar'", url])

# Generated at 2022-06-11 22:49:45.327675
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = ['--check-status', '--print=BHB', 'http://httpbin.org/get']
    parser = HTTPieArgumentParser()
    parsed_args = parser.parse_args(args)
    assert parsed_args.check_status
    assert parsed_args.output_options == 'BHB'
    assert parsed_args.url == 'http://httpbin.org/get'

# Generated at 2022-06-11 22:49:54.453617
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from .config import Config
    from .output import BINARY_SUPPRESSED_NOTICE, Colorized

    from httpie.context import Environment
    from httpie.plugins import plugin_manager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import BuiltinAuthPluginManager
    from httpie.utils import parse_auth

    class MockEnvironment(Environment):
        def __init__(self, **kwargs):
            self.stdin_isatty = True
            self.stdout_isatty = True
            self.stderr_isatty = True
            self.__dict__.update(kwargs)


    def make_mock_args(**kwargs):
        # Assume values are correct and only provide the ones being mocked.
        args = MockEnvironment(**kwargs)


# Generated at 2022-06-11 22:49:58.616556
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Arrange
    parser = HTTPieArgumentParser()
    # Acts
    args = parser.parse_args(['https://www.google.com'])

    # Assert
    assert args.url == 'https://www.google.com'


# Generated at 2022-06-11 22:50:11.269846
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import tempfile
    from httpie import __main__ as httpie_main
    from httpie import ExitStatus, __version__ as version
    import httpie.cli as cli
    import httpie.compat as compat
    import httpie.downloads as downloads
    import httpie.plugins as plugins
    from httpie.config import DEFAULT_CONFIG_DIR, DEFAULT_CONFIG_PATH, DEFAULT_CONFIG
    import httpie.output as output
    import httpie.input as input
    import httpie.settings as settings

    def get_temp_file(content):
        """
        Return the name of a temporary file containing the given content.
        """
        file_handle, file_name = tempfile.mkstemp()
        file_handle = os.fdopen(file_handle, 'wb')

# Generated at 2022-06-11 22:50:18.585884
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """
    Transition method to unit test for testing.
    """

# Generated at 2022-06-11 22:50:29.151775
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from unittest.mock import patch
    from httpie.core.constants import HTTP_GET, HTTP_POST
    from httpie.core.constants import OUT_RESP_HEADERS, OUT_RESP_BODY
    from httpie.core.constants import OUT_REQ_HEADERS, OUT_REQ_BODY

    #
    # --ignore-stdin is set.
    #
    with patch('httpie.cli.argparser.parse_options',
               return_value={'ignore_stdin': True}):
        # --data is specified.
        args = HTTPieArgumentParser().parse_args(['http', '--ignore-stdin', '--data=foo=bar', 'example.org'])
        assert args.method == HTTP_GET
        assert args.data == 'foo=bar'
       

# Generated at 2022-06-11 22:50:33.032365
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    with patch.object(HTTPieArgumentParser, 'exit', side_effect=Exception('exit')):
        with pytest.raises(Exception, match='exit'):
            HTTPieArgumentParser().parse_args('a=b'.split())
    
    

# Generated at 2022-06-11 22:50:37.009444
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    argv = ['httpie', 'http://httpbin.org']
    parser = HTTPieArgumentParser()
    args = parser.parse_args(argv)
    assert args.url == 'http://httpbin.org'
    
test_HTTPieArgumentParser_parse_args()
 

# Generated at 2022-06-11 22:50:49.089722
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    argv = "http --pretty=all -vvvv https://www.wikipedia.org"
    args = HTTPieArgumentParser().parse_args(argv.split())
    assert( args.prettify == PRETTY_MAP["all"])
    assert( args.headers == [])
    assert( args.auth == None)
    assert( args.auth_type == None)
    assert( args.auth_plugin == None)
    assert( args.body == None)
    assert( args.body_from_file == None)
    assert( args.compress == False)
    assert( args.data == [])
    assert( args.download == False)
    assert( args.download_resume == False)
    assert( args.files == [])
    assert( args.form == False)

# Generated at 2022-06-11 22:50:49.778463
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    pass



# Generated at 2022-06-11 22:52:33.886200
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-11 22:52:45.576429
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Mock all class attributes of HTTPieArgumentParser
    class MockHTTPieArgumentParser:
        def add_argument(self,*args,**kwargs):
            pass

        def exit(self,*args,**kwargs):
            pass

        def error(self,*args,**kwargs):
            pass

        def parse_known_args(self,*args,**kwargs):
            pass

    HTTPieArgumentParser.add_argument = MockHTTPieArgumentParser().add_argument
    HTTPieArgumentParser.exit = MockHTTPieArgumentParser().exit
    HTTPieArgumentParser.error = MockHTTPieArgumentParser().error
    HTTPieArgumentParser.parse_known_args = MockHTTPieArgumentParser().parse_known_args

    # Mock class attributes of argparse.ArgumentParser
    argparse.Arg

# Generated at 2022-06-11 22:52:56.057988
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import io
    http = HTTPieArgumentParser()
    http.env = Env()
    http.args = SimpleNamespace()

    # If no args, defaults to --help
    # args = []
    # http.parse_args(args)
    # assert http.args.help == True

    # If no args, defaults to --help
    args = ['--help']
    http.parse_args(args)
    assert http.args.help == True

    # If no args, defaults to --help
    args = ['--download']
    http.parse_args(args)
    assert http.args.download == True
    assert http.args.output_file == None
    assert http.args.output_file_specified == False

    # If no args, defaults to --help

# Generated at 2022-06-11 22:53:01.758470
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    _test_HTTPieArgumentParser_parse_args()
# !/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
from httpie.cli.base import parser_mapping
from httpie.cli.entrypoint import http
from httpie.cli.utils import get_args
from httpie.cli.formatter.colors import get_lexer
from httpie.cli.formatter.formatters import get_formatter

# Generated at 2022-06-11 22:53:13.615974
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # noinspection PyPackageRequirements
    from mock import patch

    def _run(args_str=''):
        return HTTPieArgumentParser().parse_args(args_str.split())

    assert _run('--debug').debug
    assert _run('--debug foo bar').debug
    with patch('httpie.cli.argtypes.KeyValueArgType.__call__') as c:
        _run('key=val')
        c.assert_called_with(['key=val'])

    # Empty value
    assert _run('key').headers == ['key:']
    assert _run('key=').headers == ['key:']
    assert _run('key=').headers == ['key:']

    # = in the value
    assert _run('key=v=al').headers == ['key:v=al']
    # No space

# Generated at 2022-06-11 22:53:19.786424
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie.base.context import Context

    args = ['--debug', '--form', '--headers', 'https://example.com',
            'key=value', 'key==value']

    # Serialize the httpie's Context instance to JSON
    # It's the result of parsing the command line args
    c = Context(args)
    c_json = c.to_json()

    pp = pprint.PrettyPrinter(indent=4)
    pp.pprint(c_json)



# Generated at 2022-06-11 22:53:30.943682
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # The HTTPieArgumentParser has been tested by the integration tests.
    # These unit tests simply ensure that the class is properly instantiated and parsed
    # and that there is no exception.
    parser = HTTPieArgumentParser()
    parser.parse_args(["--help"])
    parser.parse_args(["http://localhost:5001/echo"])
    parser.parse_args(["https://httpbin.org/get"])
    parser.parse_args(["https://httpbin.org/post", "foo=bar", "ham=eggs"])
    parser.parse_args(["https://httpbin.org/post", "foo=@example.json"])
    parser.parse_args(["https://httpbin.org/post", "foo=@example.json", "ham=eggs"])
    parser.parse

# Generated at 2022-06-11 22:53:37.852390
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    print("\n\n")
    print("-"*80)
    print("Unit test for method parse_args of class HTTPieArgumentParser")

    # Test Case 1
    arguments = ["-m", "GET", "-b",  "key=value", "https://httpbin.org/get"]
    print("HTTPieArgumentParser.parse_args(arguments={})".format(arguments))
    parser = HTTPieArgumentParser(
        prog="httpi.py",
        env=Environment(),
        stdin=sys.stdin,
        stdout=sys.stdout,
        stderr=sys.stderr
    )
    args = parser.parse_args(arguments)
    print("args:")
    print(args)
    print("vars(args):")
    print(vars(args))

# Generated at 2022-06-11 22:53:42.265194
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_env = provision_env()
    parser = HTTPieArgumentParser(env=httpie_env)
    args = parser.parse_args(['--fake', 'httpie.org'])
    assert args.url == 'httpie.org'
    assert args.fake



# Generated at 2022-06-11 22:53:53.388750
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args("--json http://httpbin.org/get".split())
    assert args.json and args.url == "http://httpbin.org/get" and parser.has_stdin_data == False and args.traceback == False and args.download_resume == False and args.output_file == None and args.all == False and args.offline == False and args.prettify == "all" and args.style == "solarized" and args.session == None and args.cert == None and args.ignore_netrc == False and args.verbose == False and args.output_options == "" and args.download == False and args.headers == [] and args.params == OrderedMultidict() and args.data == "" and args.files == OrderedMultidict() and args