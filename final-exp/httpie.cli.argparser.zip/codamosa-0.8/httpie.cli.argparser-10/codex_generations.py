

# Generated at 2022-06-11 22:47:30.532733
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(args=["https://github.com/jakubroztocil/httpie"])
    assert args.headers == {}
    assert args.auth == None
    assert args.ignore_stdin == False
    assert args.ignore_netrc == False
    assert args.body == {}
    assert args.data == b''
    assert args.error_style == 'color'
    assert args.follow == False
    assert args.form == False
    assert args.max_headers == None
    assert args.max_redirects == None
    assert args.max_body == DEFAULT_MAX_BODY
    assert args.method == 'GET'
    assert args.params == {}
    assert args.print == 'bBhHkKtTqQ'


# Generated at 2022-06-11 22:47:41.173268
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    # assert string
    args = parser.parse_args(['hello'])
    assert args.url == 'hello'
    # assert list of string
    args = parser.parse_args(['hello', 'world'])
    assert args.url == 'hello'
    assert args.request_items == [KeyValueArgType("world")]
    # assert list of string with --
    args = parser.parse_args(['hello', 'world','--verbose'])
    assert args.url == 'hello'
    assert args.request_items == [KeyValueArgType("world")]
    assert args.verbose == True
    # assert list of string with -
    args = parser.parse_args(['hello', 'world', '-v'])
    assert args.url == 'hello'
   

# Generated at 2022-06-11 22:47:44.399485
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    # parser.error()
    # parser.exit()
    parser.add_argument('--headers', '-h', action='append')
    

# Generated at 2022-06-11 22:47:55.541600
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.exit = lambda x: None
    parser.parse_args = lambda: None
    parser.error = lambda x: None
    parser.print_message = lambda x: None
    parser.env = None
    parser.env = Environment()
    parser._print_message = lambda message, file=None: None
    parser.args = None
    parser.args = parser.parse_args(args=[], namespace=argparse.Namespace())
    parser.args = parser.parse_args(args=['url'],
                                    namespace=argparse.Namespace())
    parser.args = parser.parse_args(args=['url', 'item'],
                                    namespace=argparse.Namespace())

# Generated at 2022-06-11 22:48:07.935865
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-11 22:48:17.561899
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test: parsing with no arguments
    args = HTTPieArgumentParser.parse_args([])
    assert args.url == 'https://httpbin.org'
    assert args.method == 'GET'
    assert args.headers == []
    assert args.params == []
    assert args.original_url == ''
    assert args.output_file == None
    assert args.output_options is None
    assert args.output_options_history is None
    assert args.prettify == PRETTY_STDOUT_TTY_ONLY
    assert args.download == False
    assert args.download_resume == False
    assert args.ignore_stdin == True
    assert args.timeout == 120.0
    assert args.verify == True
    assert args.cert == None
    assert args.cert_key == None
    assert args.max

# Generated at 2022-06-11 22:48:29.792124
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # one argument
    argv = [
        'http',
        'https://httpie.org/',
    ]
    args = HTTPieArgumentParser().parse_args(argv)
    assert args.url == 'https://httpie.org/'

    # arguments with colon
    argv = [
        'http',
        'https://httpie.org/',
        'hi:1',
        'hello:2',
    ]
    args = HTTPieArgumentParser().parse_args(argv)
    assert args.url == 'https://httpie.org/'
    assert len(args.request_item_args) == 2
    assert args.request_items[0].sep == ': '
    assert args.request_items[0].key == 'hi'

# Generated at 2022-06-11 22:48:33.092431
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = ['localhost', 'get', 'foo=bar']
    parser = HTTPieArgumentParser()
    parsed_args = parser.parse_args(args)
    for arg in args:
        assert arg in str(parsed_args)

 


# Generated at 2022-06-11 22:48:41.916992
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import mock

    args = ['--method', 'GET', '--headers', 'hdr:val', '--auth', 'user:pass', '--form', 'data=val', '--output=file', 'http://localhost:8080/path?query=val']
    with mock.patch('httpie.cli.argparser.argparse.ArgumentParser.parse_args') as mock_argparse_parse_args:
        httpie_api = HTTPieArgumentParser()
        httpie_api.parse_args(args)
        httpie_api.parse_args(args)
        httpie_api.parse_args(args)
        httpie_api.parse_args(args)
        httpie_api.parse_args(args)
        httpie_api.parse_args(args)
        httpie_api.parse_args

# Generated at 2022-06-11 22:48:44.051808
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    
    # Arrange
    parser = HTTPieArgumentParser()

    # Act
    with pytest.raises(SystemExit):
        parser.parse_args(['get', 'http://127.0.0.1:80'])

# Generated at 2022-06-11 22:49:38.530658
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_parser = HTTPieArgumentParser()
    args = httpie_parser.parse_args(
        # We do not need to include all the default arguments
        [
            'get',  # Method
            'https://www.google.com',  # URL
            '--auth-type=basic',  # Authentication type
            '--auth=root:toor',  # Authentication credentials
            '--form',  # Method argument
            '--headers',  # Header argument
            '--body-from-file=images/rabbit.jpeg',  # Body file or URL
            '--headers-history',  # History information
            '--output-options=b',  # Output options, b = body
            '--pretty=all',  # Pretty format
            '--verbose'  # Verbose
        ]
    )

    # Method

# Generated at 2022-06-11 22:49:42.094920
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    sys.argv = [
        'http','--help'
    ]
    args = HTTPieArgumentParser().parse_args()
    assert args.help == True
    # TODO: There should be a way to test all those methods that are called by the constructor.

# Generated at 2022-06-11 22:49:48.430178
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-11 22:49:53.190884
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    parser = HTTPieArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('bar')
    parser.add_argument('baz', nargs='?')
    args = parser.parse_args(args=['--foo', 'bar', 'baz'])
    assert args.foo
    assert args.bar == 'bar'
    assert args.baz == 'baz'


# Generated at 2022-06-11 22:50:04.863719
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args()

    assert args.headers == {}
    assert args.data == {}
    assert args.params == {}
    assert args.files == {}
    assert args.auth == None
    assert args.output_file == None
    assert args.form == None
    assert args.follow == False
    assert args.timeout == None
    assert args.check_status == False
    assert args.verify == True
    assert args.proxy == None
    assert args.download == False
    assert args.download_resume == False
    assert args.download_no_content_length == False
    assert args.download_cut_off == None
    assert args.verbose == False
    assert args.traceback == False
    assert args.output_options == 'hHb'
   

# Generated at 2022-06-11 22:50:11.977375
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = ["https://httpbin.org/ip",
            "--headers",
            """User-Agent:curl/7.47.0""",
            "Accept:*/*"
            ]
    parser = HTTPieArgumentParser()
    parser.parse_args(args=args)

    print(parser.args.headers)
    assert parser.args.headers == {'User-Agent': 'curl/7.47.0',
                                   'Accept': '*/*'}



# Generated at 2022-06-11 22:50:15.881546
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = httpie.core.parser.HTTPieArgumentParser().parse_args([])
    assert args.traceback == False
    args = httpie.core.parser.HTTPieArgumentParser().parse_args(['--traceback'])
    assert args.traceback == True
test_HTTPieArgumentParser_parse_args()
 

# Generated at 2022-06-11 22:50:23.343373
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    env = Environment()
    parser = HTTPieArgumentParser(env)
    kwargs = {
        'prog':'http',
        'usage':"%(prog)s [OPTIONS] [URL [REQUEST_ITEM [REQUEST_ITEM ...]]]",
        'formatter_class': RawTextHelpFormatter
    }
    parser.parse_args(['http','-h'],kwargs)
    # parse a HTTPieArgumentParser object with given arguments


# Generated at 2022-06-11 22:50:24.921112
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    assert parser.parse_args([]) != None

# Generated at 2022-06-11 22:50:29.225944
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Initialize the class to test
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--json','{\"name\": \"test_name\"}','http://localhost:8000/api/test'])
    # Test the property of the class
    assert(args.json == {'name': 'test_name'})

# Generated at 2022-06-11 22:52:02.403266
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-11 22:52:11.679516
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    env = Environment()
    parser = HTTPieArgumentParser(env, 'http')
    args = parser.parse_args(args=['http://example.com'])
    assert args.url == 'http://example.com'
    assert args.headers == {} and args.form == False
    assert args.auth == None and args.auth_plugin == None
    assert args.output_file_specified == False
    assert args.request_items == []
    assert args.method == 'GET'
    assert args.all == False and args.download == False and args.offline == False and args.verbose == False and args.traceback == False and args.quiet == False and args.output_file == None and args.check_status == False
    assert args.follow == False and args.max_redirects == 5 and args.style == 'all'

# Generated at 2022-06-11 22:52:23.541589
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.parse_args("http://httpbin.org/".split(" "))
    parser.parse_args("http://httpbin.org/ -v".split(" "))
    parser.parse_args("http://httpbin.org/ -h user-agent:HTTPie/0.9.2".split(" "))
    parser.parse_args("http://httpbin.org/ -h user-agent:HTTPie/0.9.2 -h accept-encoding:gzip,deflate".split(" "))
    parser.parse_args("http://httpbin.org/ -h user-agent:HTTPie/0.9.2 -h accept-encoding:gzip,deflate -v".split(" "))

# Generated at 2022-06-11 22:52:30.905561
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    argv = ['-v', '-h', 'Header1:Value1', '--auth=root:pass', 'http://localhost/resource1']
    args = HTTPieArgumentParser().parse_args(argv)
    assert args.verify == True
    assert args.headers['Header1'] == 'Value1'
    assert args.auth.orig == 'root:pass'
    assert args.url == 'http://localhost/resource1'

 

# Generated at 2022-06-11 22:52:35.147598
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import doctest
    parser = HTTPieArgumentParser()
    doctest.run_docstring_examples(parser.parse_args,[],globals(), True, parser)
test_HTTPieArgumentParser_parse_args()

# method fill_vars

# Generated at 2022-06-11 22:52:45.905302
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    env = Environment()
    with patch.object(HTTPieArgumentParser, 'error') as error_mock:
        check_parse_args(HTTPieArgumentParser, 'http', env)
        assert not error_mock.called

    with patch.object(HTTPieArgumentParser, 'error') as error_mock:
        check_parse_args(HTTPieArgumentParser, 'http https://example.org', env)
        assert not error_mock.called

    with patch.object(HTTPieArgumentParser, 'error') as error_mock:
        check_parse_args(HTTPieArgumentParser, 'http http://example.org', env)
        assert error_mock.called


# Generated at 2022-06-11 22:52:52.082403
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.add_argument('foo') #, nargs='?')
    parser.add_argument('bar') #, nargs='?')
    args = parser.parse_args(['ok', 'cool'])
    assert args.foo == 'ok'
    assert args.bar == 'cool'

# Generated at 2022-06-11 22:53:02.181009
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args([])

# Generated at 2022-06-11 22:53:03.439809
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO
    pass


# Generated at 2022-06-11 22:53:15.448924
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    with patch.object(HTTPieArgumentParser, '__init__', return_value=None):
        inst = HTTPieArgumentParser()
        # FIXME: py3: isinstance(Exception, object) returns False
        with patch.object(HTTPieArgumentParser, 'error', side_effect=SystemExit) as mock_error:
            with patch.object(HTTPieArgumentParser, 'exit', side_effect=SystemExit):
                inst.traceback = True
                with pytest.raises(SystemExit):
                    inst._parse_args(['2', 'URL'])
                assert mock_error.call_args[0][0].startswith('usage:')

        with patch.object(HTTPieArgumentParser, 'exit', side_effect=SystemExit):
            inst.traceback = False

# Generated at 2022-06-11 22:55:02.769618
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = ['--json']
    args = parser.parse_args(args)
    assert args.json


# Generated at 2022-06-11 22:55:13.241167
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = HTTPieArgumentParser().parse_args(['http://localhost:8081'])
    assert args.url == 'http://localhost:8081'
    assert args.method is None
    assert args.headers == []
    assert args.params == []
    assert args.data == []
    assert args.files == []
    assert args.auth is None
    assert args.output_file is None
    assert args.output_file_specified is None
    assert args.download == False
    assert args.color == False
    assert args.no_color == False
    assert args.traceback == False
    assert args.check_status == False
    assert args.follow == False
    assert args.follow_redirects == False
    assert args.all is False
    assert args.form == False
    assert args.json == False

# Generated at 2022-06-11 22:55:18.867164
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    input_args = [
        "http://httpbin.org/get",
        "Authorization:Basic",
        "Ym9iOnNlY3JldAo="
    ]

# Generated at 2022-06-11 22:55:27.562575
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    ap = HTTPieArgumentParser()

    # Test empty args
    args = ap.parse_args(args=[])
    assert args.data is None
    assert args.debug_flag is False
    assert args.form is False
    assert args.headers is None
    assert args.ignore_stdin is False
    assert args.method is None
    assert args.output_file is None
    assert args.output_file_specified is False
    assert args.output_options is None
    assert args.output_options_history is None
    assert args.prettify is None
    assert args.print is None
    assert args.querystring == {}
    assert args.request_items is None
    assert args.timeout is None
    assert args.url is None
    assert args.verbose is False
    assert args.verbose_flag is False


# Generated at 2022-06-11 22:55:36.910254
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    def _setup():
        #Spoof sys.argv
        sys.argv = [
            'http',
            '--json',
            'GET',
            'example.com'
        ]
        #Spoof stdout
        out = StringIO()
        sys.stdout = out
        #Spoof stderr
        err = StringIO()
        sys.stderr = err

    with patch.object(HTTPieArgumentParser, 'parse_args') as mock_parse_args:
        httpie = HTTPie()
        httpie.args = Namespace()
        httpie.args.config_dir = tempfile.gettempdir()

        _setup()
        httpie.__init__()

        httpie.parse_args()
        assert mock_parse_args.called


# Generated at 2022-06-11 22:55:45.115694
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-11 22:55:55.140924
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = parser.parse_args("httpbin.org/get".split())
    assert args.url == "httpbin.org/get"
    assert args.auth is None
    assert args.headers == {}
    assert args.output_file is None
    assert args.output_options is None
    assert args.output_options_history is None
    assert args.pretty is None
    assert args.prettify is None
    assert args.method == "GET"
    assert args.data == {}
    assert args.form == False
    assert args.params == {}
    assert args.files == {}
    assert args.json == {}
    assert args.json_filter is None
    assert args.style == None
    assert args.verbose == False
    assert args.all is False
    assert args.download is False
    assert args.download_

# Generated at 2022-06-11 22:56:00.980283
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """Unit test for method parse_args of class HTTPieArgumentParser"""

    parser = HTTPieArgumentParser()
    result = parser.parse_args(['--version'])
    # Type of result should be argparse.Namespace
    assert isinstance(result, argparse.Namespace)
    # Should not return any errors
    assert result == argparse.Namespace(version=True)
# Object of type HTTPieArgumentParser
httpie_argument_parser = HTTPieArgumentParser()

# Generated at 2022-06-11 22:56:08.105830
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    http = HTTPieArgumentParser()
    http_args = http.parse_args(['-v', '--form', 'POST', 'https://httpbin.org/post'])
    
    
    assert http_args.__getattribute__('form') == True
    assert http_args.__getattribute__('verbose') == True
    assert http_args.__getattribute__('method') == 'POST'
    assert http_args.__getattribute__('url') == 'https://httpbin.org/post'
    assert isinstance(http_args.__getattribute__('headers'), OrderedCaseInsensitiveDict)
    assert isinstance(http_args.__getattribute__('files'), OrderedMultidict)
    assert isinstance(http_args.__getattribute__('data'), OrderedMultidict)
    assert isinstance

# Generated at 2022-06-11 22:56:14.142537
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.add_argument('--debug')
    args = parser.parse_args()

    assert hasattr(args, 'debug')
    assert args.debug == None
    # args = parser.parse_args(['--debug'])
    # assert args.debug == True
    # args = parser.parse_args(['--debug=True'])
    # assert args.debug == True
    # args = parser.parse_args(['--debug=False'])
    # assert args.debug == False





