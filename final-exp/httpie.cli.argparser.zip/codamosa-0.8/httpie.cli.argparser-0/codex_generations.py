

# Generated at 2022-06-11 22:47:33.191784
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # If a HTTPieArgumentParser instance is provided,
    # then args is parsed in this method.
    httpie_argument_parser = HTTPieArgumentParser()
    args = httpie_argument_parser.parse_args()

    assert args.url == 'http://httpbin.org'
    assert args.auth_plugin == None
    assert args.ignore_stdin == False
    assert args.method == 'GET'
    assert args.headers == {}
    assert args.params == {}
    assert args.data == {}
    assert args.files == {}
    assert args.timeout == None
    assert args.max_redirects == DEFAULT_MAX_REDIRECTS
    assert args.verify == None
    assert args.cert == None
    assert args.proxy == None
    assert args.follow == False
    assert args.output

# Generated at 2022-06-11 22:47:42.390441
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args()
    assert args.debug is False
    assert args.download is False
    assert args.ignore_stdin is False
    assert args.output_file is None
    assert args.output_file_specified is False
    assert args.offline is False
    assert args.quiet is False
    assert args.traceback is False
    assert args.verbose is False
    assert args.download_resume is False
    assert args.stream is False
    assert args.check_status is True
    assert args.timeout == DEFAULT_TIMEOUT
    assert args.max_redirects == DEFAULT_MAX_REDIRECTS
    assert args.max_headers == DEFAULT_MAX_HEADERS
    assert args.max_body == DEFAULT_MAX_BODY

# Generated at 2022-06-11 22:47:45.999922
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    with patch('httpie.cli.argtypes.KeyValueArgType'):
        with patch('httpie.cli.argtypes.URLArgType'):
            cli = HTTPieArgumentParser()
            assert cli is not None

# Generated at 2022-06-11 22:47:58.261149
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
        # Testing default values
        sys.argv = ['http', '--http2']
        parser = HTTPieArgumentParser()
        args = parser.parse_args()
        assert args.http2
        assert not args.curl_debug
        assert args.traceback is True
        assert args.output_file is None
        assert args.output_options == 'HBIcJS'
        assert args.output_options_history == 'HBIcJS'
        assert args.prettify == 'all'
        assert args.traceback
        
        # Testing switch with default values
        sys.argv = ['http', '-h/--headers', '--verbose', '--no-colors', '--pretty', 'none']
        parser = HTTPieArgumentParser()
        args = parser.parse_args()
        assert args.headers

# Generated at 2022-06-11 22:48:09.946315
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args()

    # mandatory arguments
    assert args.url == None

    # optional arguments
    assert args.abbrev == 2
    assert args.auth == None
    assert args.auth_type == None
    assert args.body == None
    assert args.body_from_file == None
    assert args.check_status == True
    assert args.config_dir == None
    assert args.follow == False
    assert args.form == False
    assert args.ignore_netrc == False
    assert args.ignore_stdin == False
    assert args.json == False
    assert args.max_headers == None
    assert args.max_redirects == 10
    assert args.method == None
    assert args.multipart_data == None
    assert args.output

# Generated at 2022-06-11 22:48:15.710468
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    class MyHTTPieArgumentParser(HTTPieArgumentParser):
        def _parse_arguments(self, args=None, namespace=None):
            raise NotImplementedError

    parser = MyHTTPieArgumentParser()
    args = parser.parse_args(['--json', '--form', 'foo=bar'])
    assert args.json == args.form == args.style == args.style_force == True


# Generated at 2022-06-11 22:48:17.795406
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args('--auth foobar'.split())
    assert args.auth == 'foobar'

# Generated at 2022-06-11 22:48:29.923202
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie.cli.parser import HTTPieArgumentParser
    parser = HTTPieArgumentParser()
    # parser.add_argument('--foo')
    parser.add_argument(
        '--headers',
        action='append',
        default=[],
        type=KeyValueArgType(SEPARATOR_CREDENTIALS,
                             SEPARATOR_GROUP_ITEMS_WITH_QUOTES),
        dest='headers',
        metavar='HEADER',
        help='Header to include in the request (repeatable)')
    parsed_args = parser.parse_args(['--headers'] + ['foo:bar'])
    print(parsed_args)
    assert parsed_args.headers == [KeyValue('foo', 'Bar')]
# test_HTTPieArgumentParser_parse_args()
# Unit test

# Generated at 2022-06-11 22:48:39.315593
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test 1: no arguments specified
    sys.argv = ['http']
    args = HTTPieArgumentParser().parse_args()
    assert args.url is None

    # Test 2: one argument specified
    sys.argv = ['http', 'https://httpie.org']
    args = HTTPieArgumentParser().parse_args()
    assert args.url == 'https://httpie.org'

    # Test 3: two arguments specified
    sys.argv = ['http', 'https://httpie.org', 'http://httpie.org']
    args = HTTPieArgumentParser().parse_args()
    assert args.method == 'https://httpie.org'
    assert args.url == 'http://httpie.org'
    assert args.request_items == [('http://httpie.org', None, None)]

   

# Generated at 2022-06-11 22:48:41.978844
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = ['GET', 'https://httpbin.org/headers']
    parser = HTTPieArgumentParser()
    args = parser.parse_args(args)
    assert args.method == 'GET'
    assert args.url == 'https://httpbin.org/headers'


# Generated at 2022-06-11 22:50:09.990764
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
  parser = HTTPieArgumentParser()
  args = parser.parse_args(['-v', 'httpie.org'])
  assert args.verbose is True

test_HTTPieArgumentParser_parse_args()


# Generated at 2022-06-11 22:50:17.867010
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # pylint: disable=redefined-outer-name
    from httpie.cli import get_parser
    from httpie.compat import is_windows
    from subprocess import PIPE, Popen
    _, env = get_parser()
    env.stdin = PIPE
    env.stdout = PIPE
    env.stderr = PIPE if is_windows else None
    if not is_windows:
        # Output to PIPE not allowed on Windows.
        env.stdout_isatty = env.stderr_isatty = False

# Generated at 2022-06-11 22:50:25.390458
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['get', 'example.com'])
    assert args.url == 'http://example.com/'
    args = parser.parse_args(['get', 'https://example.com'])
    assert args.url == 'https://example.com/'
    args = parser.parse_args(['get', 'http://example.com'])
    assert args.url == 'http://example.com/'
    
    
    

 

# Generated at 2022-06-11 22:50:28.764567
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # setup
    argv = list()
    parser = HTTPieArgumentParser(ArgumentParser())

    # action
    args = parser.parse_args(argv)

    # verify
    assert args
# }}}

# {{{ Command class

# Generated at 2022-06-11 22:50:34.932823
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    class HTTPieArgumentParserStub(HTTPieArgumentParser):
        def print_usage(self, file=None):
            pass
    args = ['-X', 'POST', 'example.com', 'field1=val1', 'field2=val2']
    parser = HTTPieArgumentParserStub(
        prog='http',
        usage=USAGE,
    )
    assert parser.parse_args(args).method == 'POST'

# Generated at 2022-06-11 22:50:38.778839
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Arrange
    input_args = ['https://httpbin.org/get']
    argparser = HTTPieArgumentParser()
    # Act
    parsed = argparser.parse_args(input_args)
    # Assert
    assert parsed.url == 'https://httpbin.org/get'

# Generated at 2022-06-11 22:50:50.756519
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # set up
    httpie_argument_parser = HTTPieArgumentParser()
    
    # test
    # http
    httpie_argument_parser.parse_args(['http'])
    
    # http ie
    httpie_argument_parser.parse_args(['http', ''])
    
    # http ie get
    httpie_argument_parser.parse_args(['http', 'get', ''])
    
    # http ie get www.google.com
    httpie_argument_parser.parse_args(['http', 'get', 'www.google.com'])
    
    # http www.google.com
    httpie_argument_parser.parse_args(['http', 'www.google.com'])
    
    # http get www.google.com
    httpie_argument_parser.parse_args

# Generated at 2022-06-11 22:50:54.849589
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # given
    argv = ['--json', 'http://www.google.com']
    parser = HTTPieArgumentParser()
    # when
    args = parser.parse_args(argv)
    # then
    assert args.json
    assert args.url == 'http://www.google.com'

# Generated at 2022-06-11 22:50:56.517528
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--version'])
    assert args.version


# Generated at 2022-06-11 22:51:06.620116
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-11 22:52:55.680641
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-11 22:52:59.460304
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Setup
    parser = HTTPieArgumentParser(prog='HTTPie')
    # Exercise
    args = parser.parse_args(['https://httpbin.org/', 'hello'])
    # Verify
    assert args.url == 'https://httpbin.org/hello'



# Generated at 2022-06-11 22:53:05.889387
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    config = Config()
    config.default_options = {}
    config.config_dir = None
    config.config_file_paths = []
    config.env = Environment()

# Generated at 2022-06-11 22:53:16.711735
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-11 22:53:28.203453
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    repl_test_args = []
    repl_test_args.append('-h')
    repl_test_args.append('-m GET')
    repl_test_args.append('-a USER')
    repl_test_args.append('-f')
    repl_test_args.append('-t')
    repl_test_args.append('-v')
    repl_test_args.append('-j')
    repl_test_args.append('-b')
    repl_test_args.append('-p')
    repl_test_args.append('--traceback')
    repl_test_args.append('--ignore-stdin')
    repl_test_args.append('--verify=False')
    repl_test_args.append('--proxy=PROXY')
    repl_test_args.append

# Generated at 2022-06-11 22:53:29.838941
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
  parser = HTTPieArgumentParser()
  parser.parse_args([])


# Generated at 2022-06-11 22:53:36.613527
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from requests.models import RequestEncodingMixin
    import os
    import tempfile

    parser = HTTPieArgumentParser(args=[])
    args = parser.parse_args()
    assert args.session
    assert args.session.headers == {}
    assert args.headers == {}
    assert args.request_items == []
    assert args.prettify is None
    assert args.method is None
    assert args.url is None
    assert args.data is None
    assert args.params == {}
    assert args.files == {}
    assert args.auth is None
    assert args.auth_type is None
    assert args.auth_plugin is None
    assert args.verify is True
    assert args.output_stream == sys.stdout
    assert args.output_stream_encoding is None

# Generated at 2022-06-11 22:53:47.762346
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args([])
    assert isinstance(args, argparse.Namespace)
    assert args.headers is None
    assert args.data == []
    assert args.files == []
    assert args.params == []
    assert args.output_options == 'HhB'
    assert args.output_options_history == 'HhB'
    assert args.output_file is None
    assert args.output_file_specified is False
    assert args.continue_download is False
    assert args.download_resume is False
    assert args.download is False
    assert args.prettify is False
    assert args.method is None
    assert args.verbose is False
    assert args.all is False
    assert args.body is False

# Generated at 2022-06-11 22:53:58.032157
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Parser object for method parse_args for class HTTPieArgumentParser
    parser = HTTPieArgumentParser()
    parsed_args = parser.parse_args(
        ['--json', '--method=Post', '--json', '--json', '-h', 'Accept: text/json', 
        '--form', '--debug'])
    # Since the first argument is mandatory, the parsing is successful
    # Asserting that the parsed value of command line argument is as expected
    assert_that('--json' in parsed_args.json)
    assert_that('--method' in parsed_args.method)
    assert_that('--h' in parsed_args.headers)
    assert_that('--form' in parsed_args.form)
    assert_that('--debug' in parsed_args.debug)
# Example for invoking the

# Generated at 2022-06-11 22:54:00.886360
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    _arg_parser = HTTPieArgumentParser()
    _arg_parser.parse_args(['https://www.google.com'])
    # todo: assert more
test_HTTPieArgumentParser_parse_args()
