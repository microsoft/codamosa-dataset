

# Generated at 2022-06-11 22:47:34.406974
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    test_cases = []
    # Formatted output
    test_cases.append(('-f', False, 'formatted'))
    test_cases.append(('-f ', False, 'formatted'))
    test_cases.append(('-f, ', False, 'formatted'))
    test_cases.append(('-f=', False, 'formatted'))
    test_cases.append(('-f=false', True, 'formatted'))
    test_cases.append(('-f=', False, 'formatted'))
    test_cases.append(('--form', False, 'formatted'))
    test_cases.append(('--pretty', True, 'all'))
    test_cases.append(('-ppretty', False, 'all'))

# Generated at 2022-06-11 22:47:42.735630
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args=['--output', 'output', '--download', '--download-resume', '--ignore-netrc', '-O', 'True', '-d', 'a=b', '--form', 'GET', 'www.xxx.com', '--json', '{"c":d}']

    # return a namespace object
    try:
        #inheritance 
        parser = HTTPieArgumentParser()
        # parse the args and return namespace
        args=parser.parse_args(args)
        assert args

    # if error occur, print the error
    except argparse.ArgumentError as e:
        print('\n%s' %e.message)
    except Exception as e:
        print('\n%s' %e.message)

 

# Generated at 2022-06-11 22:47:45.648879
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    input_value = HTTPieArgumentParser()
    type(input_value).parse_args = MethodType(parse_args, input_value)
    return input_value


# Generated at 2022-06-11 22:47:57.801630
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    argparse_old_stdout = argparse._sys.stdout
    argparse._sys.stdout = io.StringIO()

    # test HTTPieArgumentParser.parse_args method
    # in the case when no error occurs
    argv1 = ['http', 'GET', 'http://httpie.org']
    args = HTTPieArgumentParser().parse_args(argv1)

    first_assert = (args.url == 'http://httpie.org')
    second_assert = (args.method == 'GET')
    assert first_assert and second_assert

    # test HTTPieArgumentParser.parse_args method
    # in the case when an error occurs
    argv2 = ['http']

# Generated at 2022-06-11 22:48:09.370810
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args([])
    assert args.verbose == 0
    assert args.output_options is None
    assert args.output_options_history is None
    assert args.quiet is False
    assert args.download is False
    assert args.download_resume is False
    assert args.download_all is False
    assert args.download_columns is None
    assert args.download_dir is None
    assert args.download_outfile_template is None
    assert args.download_default_filename is None
    assert args.download_queries is None
    assert args.download_with_queries is False
    assert args.download_without_queries is False
    assert args.download_no_overwrite is False
    assert args.follow is False
    assert args.max_

# Generated at 2022-06-11 22:48:18.239451
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    arg_parser = HTTPieArgumentParser()
    arg_dict = vars(arg_parser.parse_args(['-h']))
    assert arg_dict['headers'] == None
    assert arg_dict['print'] == "bBHJ:D"
    assert arg_dict['response'] == True
    assert arg_dict['params'] == None
    assert arg_dict['stream'] == False
    assert arg_dict['output_file'] == None
    assert arg_dict['check_status'] == True
    assert arg_dict['timeout'] == 300
    assert arg_dict['verify'] == True
    assert arg_dict['all'] == True
    assert arg_dict['download'] == False
    assert arg_dict['download_resume'] == False
    assert arg_dict['verbose'] == False

# Generated at 2022-06-11 22:48:22.278480
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['get', 'url'])
    assert args.url == 'url'
    assert args.method == 'GET'

# Generated at 2022-06-11 22:48:27.635987
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser('', env)
    args = parser.parse_args([
        '--output-file=temp.txt', 'http://httpbin.org/get'])
    assert args.output_file.name == 'temp.txt'
    assert args.url == 'http://httpbin.org/get'
        

# Generated at 2022-06-11 22:48:36.594762
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie import input
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins import plugin_manager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie import cli
    from httpie.cli import parser
    from requests.structures import CaseInsensitiveDict
    import tempfile
    import os
    plugin_manager.load_installed_plugins()
    parser.env = Environment()


    env = Environment()
    args = parser.parse_args(args=[], env=env)
    assert args.headers == []
    assert args.data == DEFAULT_DATA
    assert args.params == []
    assert not args.output_file
    assert not args.output_file_specified
    assert not args.verify

# Generated at 2022-06-11 22:48:42.998271
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = ['https://httpbin.org/get', 'Accept:application/json']
    httpie_parser = HTTPieArgumentParser()
    args_object = httpie_parser.parse_args(args)
    assert not httpie_parser.error_occurred
    assert args_object.url == 'https://httpbin.org/get'
    assert args_object.headers == {'Accept': 'application/json'}
    assert args_object.request_items == [KeyValue(key='Accept', value='application/json', sep=':')]

test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-11 22:50:11.565811
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    return inspect.cleandoc('''
        Tests for the class HTTPieArgumentParser
        
        setUp
            Create a new instance of the AbstractArgumentParser class
        parse_args
            A)
                If the item --help is in the sys.argv
                    Should return the help.
            B)
                If the item --version is in the sys.argv
                    Should return the version.
            C)
                If the item --traceback is in the sys.argv
                    Should return the help.
            D)
                If the item --traceback is not in the sys.argv
                    Should return the help.
        ''')

# Generated at 2022-06-11 22:50:18.696012
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """Unit test for method parse_args of class HTTPieArgumentParser"""      
    h = HTTPieArgumentParser()
    args = h.parse_args([])
    assert args.args == []
    assert args.host == 'localhost'
    assert args.http2 == False
    assert args.http2_prior_knowledge == False
    assert args.ignore_netrc == False
    assert args.ignore_stdin == False
    assert args.max_headers == 1024
    assert args.max_redirects == 10
    assert args.output == sys.stdout
    assert args.output_format == 'color'
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.output_options == 'hb'
    assert args.output_options_history == 'hb'
   

# Generated at 2022-06-11 22:50:19.453395
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    pass

# Generated at 2022-06-11 22:50:26.978186
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Parameters
    argv = ['https://httpbin.org/get', 'Accept:application/json', 'User-Agent:httpie']
    args = HTTPieArgumentParser().parse_args(argv)
    arr = [{
        argv[0]: ''
    }, {
        argv[1]: ''
    }, {
        argv[2]: ''
    }]
    # Testing
    assert args.url == arr[0]
    assert args.headers == arr[1]
    assert args.values_dict == arr[2]
 

# Generated at 2022-06-11 22:50:29.200159
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    pass


# Generated at 2022-06-11 22:50:38.552229
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.add_argument('--auth', default=None, action='store',
                        help='Colon-separated username:password pair.')
    parser.add_argument('--auth-type', default=None, action='store',
                        help='Specifies the auth mechanism.')
    parser.add_argument('--data', default=None, action='store',
                        help='Strings to be sent via POST.')
    parser.add_argument('--data-binary', default=None, action='store',
                        help='Binary data to be sent via POST.')
    parser.add_argument('--debug', default=False, action='store_true',
                        help='Turn on debugging output.')

# Generated at 2022-06-11 22:50:50.567441
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser(prog='foo')
    parser.add_argument('--args', nargs='*')
    parser.add_argument('--kwargs', nargs='*')

    args = parser.parse_args(
        ['a', '-k', '1', 'b', '--kwargs', 'kw1=val1', '--kwargs', 'kw2=val2'],
    )
    assert args.args == ['a', '-k', '1', 'b']
    assert args.kwargs == ['kw1=val1', 'kw2=val2']


# Generated at 2022-06-11 22:50:56.169750
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    options = ['https://httpbin.org/get', 'Accept:application/json', 'User-Agent:HTTPie/0.9.9']
    request_args = HTTPieArgumentParser().parse_args(options)
    assert request_args.url == 'https://httpbin.org/get'
    assert request_args.headers['Accept'] == 'application/json'
    assert request_args.headers['User-Agent'] == 'HTTPie/0.9.9'

# Generated at 2022-06-11 22:51:06.590887
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    # Test the case when we provide url and method to the command line
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http', 'https://httpie.org', 'GET'])
    assert_equal(args.url, 'https://httpie.org')
    assert_equal(args.method, 'GET')

    # Test if the HTTPieArgumentParser might have been called from a script
    # For this case we don't need to send anything
    parser = HTTPieArgumentParser()
    args = parser.parse_args([])
    assert_equal(args.url, None)
    assert_equal(args.method, None)

# Start testing
test_HTTPieArgumentParser_parse_args()
 

#
# Plugin classes
#

#
# BasePlugin class
#

# Generated at 2022-06-11 22:51:16.515628
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.add_argument('-a', '--auth', dest='auth')
    parser.add_argument('-b', dest='body')
    parser.add_argument('-c', '--config')
    parser.add_argument('-f', '--form', dest='form', action='store_true')
    parser.add_argument('-H', dest='headers')
    parser.add_argument('-h', '--help', dest='help', action='store_true')
    parser.add_argument('-i', '--include', dest='include', action='store_true')
    parser.add_argument('-j', '--json', dest='json', action='store_true')

# Generated at 2022-06-11 22:52:42.639707
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Get the expected result
    expected = {
        'args': None,
        'headers': None,
        'request_items': None,
        'url': None
    }
    # Get the actual result
    actual = HTTPieArgumentParser().parse_args(args=[])

    # Assert that the actual and expected results are equal
    assert actual == expected

# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ #
# Unit testing for file httpie/config.py
# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ #


# Generated at 2022-06-11 22:52:43.651729
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    assert True

# Generated at 2022-06-11 22:52:55.371383
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    def mock_env_get_bool(k, default=False):
        return {
            'color': True,
            'stdout_isatty': True,
            'stdout_isformatted': True,
            'is_windows': False,
        }.get(k, default)

    env = mock.MagicMock()
    env.config.get_default.return_value = None
    env.config.get_bool.return_value = None
    env.config.get_mapping.return_value = {}
    env.config.get_safe_env.return_value = {}
    env.config.get_config_dir.return_value = None
    env.config.get_config_paths.return_value = []
    env.config.get.return_value = None
    env.color = True


# Generated at 2022-06-11 22:53:03.818738
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-11 22:53:15.741797
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # dict to store test results
    result = dict()
    # dict to store test errors
    errors = dict()
    # dict to store test successes
    successes = dict()
    # create parser
    parser = HTTPieArgumentParser()
    # create dict to pass to parse_args
    test_args_dict = dict(
        # args that should be ignore
        data='test data',
        headers='test',
        verify=True,
        # args that should not be ignored
        url='http://test.com',
        verbose=True,
        output_options='verbose'
    )
    # dict to hold expected values

# Generated at 2022-06-11 22:53:25.956252
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    env_stdin_encoding_mock = mock.Mock()
    env_stdout_encoding_mock = mock.Mock()
    env_stdout_isatty_mock = mock.Mock()
    env_stderr_isatty_mock = False
    env_stdin_isatty_mock = True
    env_devnull_mock = mock.Mock()
    env_is_windows_mock = mock.Mock()
    env_get_size_mock = mock.Mock()
    env_stdout_mock = mock.Mock()
    env_stderr_mock = mock.Mock()
    request_items_mock = mock.Mock()
    request_items_mock().__iter__ = mock.Mock()
    request_

# Generated at 2022-06-11 22:53:31.735872
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """
    Testing for method parse_args of the class HTTPieArgumentParser.
    """
    parser = HTTPieArgumentParser()
    test_args = ['127.0.0.1:5600','param1=6','param2=2']
    try:
        args = parser.parse_args(test_args)
    except Exception as e:
        print(e)
    else:
        print(args)


# test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-11 22:53:33.292367
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    assert parser.parse_args([])



# Generated at 2022-06-11 22:53:43.465886
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """
    Test case 1
    """

# Generated at 2022-06-11 22:53:54.281995
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie.client import parse_auth, get_config
    from httpie.downloads import Downloader
    from httpie.plugins.builtin import (
        HTTPBasicAuth,
        HTTPBearerAuth,
        HTTPDigestAuth,
    )
    from httpie.plugins.manager import PLUGIN_MANAGER
    from httpie.context import Environment

    test_env = Environment()
    test_config = get_config(env=test_env)
    test_downloader = Downloader(test_config)
    test_args = [
        'http',
        '--json',
        '--form',
        '--auth-type=basic',
        '--auth',
        'user:password',
        'httpbin.org',
        'foo=bar'
    ]
    test_args = HTTPie