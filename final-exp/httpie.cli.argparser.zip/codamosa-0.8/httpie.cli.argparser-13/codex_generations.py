

# Generated at 2022-06-11 22:47:30.430960
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    cli_args = [
        '--verbose',
        '--form',
        'api-key=123',
        'address=\'1111 8th ave, new york, ny\'',
        'url=https://maps.googleapis.com/maps/api/geocode/json',
        '--traceback',
        '--debug',
        '--download',
    ]
    args = HTTPieArgumentParser(
        default_options=[],
        env=Environment(),
        stdin_isatty=True
    ).parse_args(cli_args)

    assert args.verbose is True
    assert args.form is True
    assert args.headers == [('api-key', '123'), ('address', '1111 8th ave, new york, ny')]

# Generated at 2022-06-11 22:47:41.136534
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['https://www.httpbin.org/get', 'x=1', 'y=two'])
    assert args.url == 'https://www.httpbin.org/get'
    assert args.request_items == [KeyValue(key='x', value='1', sep='=', orig='x=1'),KeyValue(key='y', value='two', sep='=', orig='y=two')]
    assert args.method == 'GET'
    args = parser.parse_args(['https://www.httpbin.org/status/200'])
    assert args.url == 'https://www.httpbin.org/status/200'
    assert args.method == 'GET'
    assert not hasattr(args, 'request_items')
    args = parser

# Generated at 2022-06-11 22:47:46.833026
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import argparse
    parser = argparse.ArgumentParser(description='A foo that bars')
    parser.add_argument('--foo')
    parser.add_argument('bar')
    args = parser.parse_args(['BAR', '--foo', 'FOO'])
    assert args.foo == 'FOO'
    assert args.bar == 'BAR'
    
    

# Generated at 2022-06-11 22:47:51.416273
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from .utils import MockEnvironment, mock_get_netrc_auth, mock_decode_auth

    class MockAuthPlugin(AuthPlugin):
        auth_type = 'mock'

    parser = HTTPieArgumentParser()
    args = parser.parse_args([])
    assert args.method == 'GET'
    assert args.headers == Headers([])
    assert args.data is None
    assert args.params == KeyValueArgType([])
    assert args.files == KeyValueArgType([])
    assert args.json is None
    assert args.verbose is False
    assert args.headers_file is None

    # Ignore stdin.
    args = parser.parse_args(['http://example.org', '--ignore-stdin'])
    assert args.url == 'http://example.org'

    # By default ignore std

# Generated at 2022-06-11 22:48:00.575468
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """Unit test for method parse_args of class HTTPieArgumentParser."""
    parser = HTTPieArgumentParser()
    parser.add_argument('-g', '--group', dest='groups', action='append_const',
                        const='group')
    parser.add_argument('-i', '--index', dest='index', action='append_const',
                        const='index')
    result = parser.parse_args(['-g', '-i'])
    assert result == argparse.Namespace(groups=['group'], index=['index'])

# Generated at 2022-06-11 22:48:09.259474
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args([])
    assert args.output_options == OUTPUT_OPTIONS_DEFAULT
    assert args.output_options_history == OUTPUT_OPTIONS_DEFAULT
    
    args = parser.parse_args(['--traceback'])
    assert args.traceback

    args = parser.parse_args(['--timeout=10'])
    assert args.timeout == 10

    args = parser.parse_args(['--timeout=10'])
    assert args.timeout == 10

# Generated at 2022-06-11 22:48:18.238109
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args_list = [
        ["http://httpbin.org", "User-Agent:HTTPie", "Accept-Encoding:gzip,deflate,identity",
         "--auth", "username:password"],
        ["http://httpbin.org/post", "Accept-Encoding:gzip,deflate,identity", "--auth", 
         "username:password", "--json", "{\"test\": \"foo\", \"test2\": \"bar\"}"]
    ]
    argparse_data_list = []
    for args in args_list:
        args_parser = HTTPieArgumentParser(args=args, environ=environ)
        args_parser.parse_args()
        argparse_data = args_parser.args
        delattr(argparse_data, "auth_plugin")

# Generated at 2022-06-11 22:48:30.009987
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """
    Unit test for method parse_args of class HTTPieArgumentParser of module httpie.cli.argtypes


    """

    # Initialization
    _httpie_argument_parser = HTTPieArgumentParser()
    _args = [_httpie_argument_parser.prog]
    self = _httpie_argument_parser

    # Test body
    self._setup_parser()
    args = self.parse_args(_args)
    self._process_args(args)
    self._detect_method()
    self._guess_method()
    self._parse_items()
    self._process_output_options()
    self._process_pretty_options()
    self._process_download_options()
    self._apply_no_options(args.no_options)
    self._process_format_options()
   

# Generated at 2022-06-11 22:48:39.408469
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    '''
    Test HTTPieArgumentParser.parse_args()
    '''

# Generated at 2022-06-11 22:48:45.475539
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-11 22:49:46.139581
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # noinspection PyShadowingNames
    def script_path(path):
        return '/home/foo/.local/bin/http'
    # noinspection PyShadowingNames

# Generated at 2022-06-11 22:49:54.867031
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
  '''
  Test the method of HTTPieArgumentParser()
  '''
  # Test case 1
  argv = ['http', '--version', 'http://httpie.org']
  parser = HTTPieArgumentParser(env=Environment(), argv=argv) 
  args = parser.parse_args()
  assert args.version == True
  assert args.url == 'http://httpie.org'
  
  # Test case 2
  argv = ['http', 'http://httpie.org']
  parser = HTTPieArgumentParser(env=Environment(), argv=argv) 
  args = parser.parse_args()
  assert args.version == False
  assert args.url == 'http://httpie.org'
  
  # Test case 3

# Generated at 2022-06-11 22:49:56.138175
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """Unit test for HTTPieArgumentParser.parse_args"""
    pass

# Generated at 2022-06-11 22:50:05.770217
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test case 1:
    parser = HTTPieArgumentParser()
    assert parser.parse_args() == 'AggregateError()'
    # Test case 2:
    parser = 'AggregateError'
    try:
        raise parser
    except Exception as obj:
        assert str(obj) == 'AggregateError'
        del obj
    # Test case 3:
    parser = 'AggregateError()'
    try:
        raise AggregateError()
    except AggregateError as obj:
        assert str(obj) == 'AggregateError()'
        del obj
# Test suite


# Generated at 2022-06-11 22:50:12.373503
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = HTTPieArgumentParser().parse_args(
        ['--json', '--headers', '--follow', 'http://httpbin.org/get']
    )

    assert 'http://httpbin.org/get' == args.url
    assert args.headers is True
    assert args.follow is True

    # --json should have been used, so `--form` or `--data` should be None.
    assert args.form is None
    assert args.data is None
    assert args.files is None
    assert args.params is None
# Let's call our unit test
test_HTTPieArgumentParser_parse_args()
 
# Let's test the parent class
test_ArgumentParser_parse_args()
 
# Let's test the grand parent class
test_ArgumentParser.test_parse_args()

# Let

# Generated at 2022-06-11 22:50:19.053084
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args_ = HTTPieArgumentParser(prog='http', add_help=False)
    args_.add_argument('--abc')
    args_.add_argument('--def', action='store_true')
    args_.add_argument('--ghi', action='store_true')
    args_.add_argument('--jkl', type=str)
    args_.add_argument('pos_arg')
    args = args_.parse_args(['--abc', '123', '--def', '--ghi', '--jkl', 'mno', 'pqr'])
    assert args.abc == '123'

# Generated at 2022-06-11 22:50:24.243363
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie.context import Environment
    
    # input
    args = "--json"
    # output
    output_args = ["--json"]
    args = HTTPieArgumentParser(env=Environment()).parse_args(args.split(" "))
    assert args.json == True
    

# Generated at 2022-06-11 22:50:28.242424
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # replace command line with "test"
    sys.argv = ['http', 'test']
    arg_parser = HTTPieArgumentParser()
    return arg_parser.parse_args()

args = test_HTTPieArgumentParser_parse_args()
print(args)


# Generated at 2022-06-11 22:50:38.061160
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    def test_HTTPieArgumentParser_parse_args_base(args, expected):
        env = TerminalEnvironment()

        env.stdin = BytesIO()
        env.stdin.buffer = env.stdin
        env.stdin_isatty = False
        env.stdout = BytesIO()
        env.stdout_isatty = False
        env.stderr = BytesIO()
        env.stderr_isatty = False

        parser = HTTPieArgumentParser(env=env, args=[])
        parser.args = parser.parse_args(args=args)

        def get_value(args, name):
            _value = getattr(args, name, None)
            if isinstance(_value, collections.abc.Iterator):
                _value = list(_value)
            return _value

       

# Generated at 2022-06-11 22:50:50.133575
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """
    The method parse_args for class HTTPieArgumentParser raises the error:
    TypeError: '_AttributeHolder' object is not callable
    """
    input_list = [
        'http',
        'https://httpie.org',
        'Accept:text/html',
        'User-Agent:HTTPie/0.9.2',
        'cache-control:no-cache',
        'content-type:application/json;charset=utf-8',
        'Host:scrapy.org',
    ]
    parser = HTTPieArgumentParser(
        env=Env(),
        usage="%(prog)s [OPTIONS] [URL] [ITEM]...",
        prog='http',
        allow_interspersed_args=True
    )
    assert parser.parse_args

# Generated at 2022-06-11 22:51:52.781030
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():  # noqa: D102

    HTTPieArgumentParser_instance = HTTPieArgumentParser()
    HTTPieArgumentParser_instance.env = DummyEnv()

    # The following two lines don't seem to do anything.
    stdout_file = StringIO()
    sys.stdout = stdout_file

    # This method call should not raise an exception if successful
    HTTPieArgumentParser_instance.parse_args(
        ['https://httpbin.org/headers'])


if __name__ == '__main__':
    test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-11 22:52:03.976029
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.add_argument('-q', '--query', type=KeyValueArgType(),
                        help='Set query string parameters. Use a key or '
                             'a key=value pair. If a value is a '
                             'valid JSON object, then it will be '
                             'automatically stringified.',
                        action=MergeDictSafeAppendAction,
                        dest='params',
                        metavar='KEY=VALUE')

# Generated at 2022-06-11 22:52:14.426417
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-11 22:52:21.980116
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    with pytest.raises(SystemExit, message="test_HTTPieArgumentParser_parse_args"):
        parser = HTTPieArgumentParser(description='description')
        parser.add_argument('-a')
        parser.add_argument('-b')
        parser.add_argument('-c')
        parser.parse_args(['-a', '1', '-b', '2', '-c', '3'])

# Generated at 2022-06-11 22:52:33.150406
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
  parser = HTTPieArgumentParser(prog='http')
  with pytest.raises(SystemExit):
    parser.parse_args(['--debug'])
   
  args = parser.parse_args(['--debug', '--auth-type=digest', 'https://httpie.org', 'Accept:application/json'])
  assert args.verbose == 2 and args.debug == True and args.method == None and args.url == 'https://httpie.org' and args.request_items == [{'key': 'Accept','value': 'application/json','sep': ':','orig': 'Accept:application/json'}] and args.download == False and args.download_resume == False and args.output_file == None and args.output_file_specified == None and args.output_options == 'hB' and args

# Generated at 2022-06-11 22:52:39.876494
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_arg_parser = HTTPieArgumentParser()
    arg_list = []
    args = httpie_arg_parser.parse_args(arg_list)
    print(args)

# Running the unit test
if __name__ == "__main__":
    test_HTTPieArgumentParser_parse_args()
 

# Generated at 2022-06-11 22:52:47.859485
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    
    # Test 1:
    print('\nTest 1\n------')
    args = '--timeout=10 http://httpbin.org/get --headers Content-Type:text/html'
    args = args.split()
    args = HTTPieArgumentParser().parse_args(args)
    print('\ttest1:', args)
    assert args.timeout == 10
    assert args.headers[0] == 'Content-Type=text/html'
    
    # Test 2:
    print('\nTest 2\n------')
    args = '--timeout=10 --headers Content-Type:text/html http://httpbin.org/get'
    args = args.split()
    args = HTTPieArgumentParser().parse_args(args)
    print('\ttest2:', args)

# Generated at 2022-06-11 22:52:53.279113
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    #1. Arrange
    #1.1. Input argument
    parser = HTTPieArgumentParser()

    #1.2. Expected output
    expected_result = True
    #2. Act
    #2.1. Execute the method
    actual_result = parser.parse_args([])
    #3. Assert
    assert actual_result==expected_result

test_HTTPieArgumentParser_parse_args()
 

# Generated at 2022-06-11 22:52:56.095248
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    print(parser.parse_args(["--help"]))
import json
import re
import os.path
import os

# debug

# Generated at 2022-06-11 22:53:04.265929
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser(prog='test', env=Environment())
    ac1 = parser.parse_args([])
    assert ac1.help is None
    assert ac1.headers is None
    assert ac1.body is None
    assert ac1.params is None
    
    ac2 = parser.parse_args(['--help'])
    assert ac2.help is False
    
    ac3 = parser.parse_args(['--headers', 'h1: v1', 'h2: v2'])
    assert ac3.headers == CaseInsensitiveDict({'h1': 'v1', 'h2': 'v2'})
    
    with open('test_file.txt', 'wb') as f:
        f.write(b'Hello World!')

# Generated at 2022-06-11 22:54:44.773182
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    # Set the attributes of the parser
    parser = HTTPieArgumentParser(env={'stdout_isatty': True})
    parser.args = None
    parser.has_stdin_data = None

    # Set the attributes of the parser.args
    parser.args = type('args', (), {'auth_plugin': None})

    # Parser not defined when we run unit test

    # Parser.args not defined when we run unit test

    # Unrecognized arguments
    args = parser.parse_args(['http', '--foo'])
    assert args.method == 'GET'
    assert args.url == 'http://api.httpie.org'
    assert args.headers == {}
    assert args.data == {}
    assert args.params == {}

    # Unrecognized arguments

# Generated at 2022-06-11 22:54:50.081340
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args([])
    assert args.url == 'https://httpbin.org/'
    assert args.headers == {'Host': 'httpbin.org'}

    args = parser.parse_args(['GET', 'https://httpbin.org/'])
    assert args.method == 'GET'

    args = parser.parse_args(['GET', 'https://httpbin.org/', 'Content-Type:text/plain'])
    assert len(args.headers) == 2


# Generated at 2022-06-11 22:55:01.442817
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # unit tests on parse_args method
    parser = HTTPieArgumentParser(
        prog="http",
        default_method='GET',
        env=Environment(),
        ignore_unknown_options=False
    )
    # Test 1: check whether exception is raised when the option is unknown
    try:
        parser.parse_args(
            ['--unknown-option', 'http://httpbin.org/get']
        )
    except Exception as e:
        test1 = isinstance(e, HTTPieArgumentParser['error'])
    else:
        test1 = False
    assert (test1) # test 1 passes
    # Test 2: check whether exception is raised when the option is mutually exclusive

# Generated at 2022-06-11 22:55:07.303549
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from requests.compat import urljoin
    from requests.models import PRETTY_MAP
    from httpie.context import Environment
    from httpie.plugins import plugin_manager
    from httpie.compat import is_py26
    # create a dummy args

# Generated at 2022-06-11 22:55:15.461690
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    test_command = "GET"
    url = "http://localhost/test"
    argv = [test_command, url]
    args = parser.parse_args(argv)
#     assert args.method == test_command
#     assert args.url == url
#     assert args.output_options == '{}'
#     assert len(args.request_items) == 0
#     assert not hasattr(args, "debug")
#     assert not hasattr(args, "download")
#     assert not hasattr(args, "download_resume")
#     assert not hasattr(args, "follow")
#     assert not hasattr(args, "offline")
#     assert not hasattr(args, "quiet")
#     assert not hasattr(args, "traceback")


# Generated at 2022-06-11 22:55:20.652516
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    ap = HTTPieArgumentParser()
    # HTTPieArgumentParser.parse_args([])
    # get_prog_name()
    import sys
    print(sys.argv[0])
    # HTTPieArgumentParser.parse_args(['http',])
    args = ap.parse_args(['http', ])
    print(args)

    args = ap.parse_args(['http', '192.168.0.1:5000/mid'])
    print(args.headers)
    print(args.json)
    print(args.pretty)
    print(args.timeout)
    print(args.verify)
    print(args.headers)

    print(args)
    args = ap.parse_args('http httpbin.org/get'.split())
    print(args)

# Generated at 2022-06-11 22:55:27.309746
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--body', 'data', 'httpbin.org/post', 'q:=value'])
    assert args.data == 'q:=value'
    assert args.body == 'data'
    args = parser.parse_args(['httpbin.org/post', 'q:=value'])
    assert args.data == 'q:=value'
    assert args.body is None

# Generated at 2022-06-11 22:55:31.956087
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    # Arrange
    expected_result = "test_method://test_url.com"
    test_argument = "test_method://test_url.com"
    test_items = []
    args = None

    # Act
    test_instance = HTTPieArgumentParser(items=test_items)
    args = test_instance.parse_args(argv=[test_argument])

    actual_result = args.url

    # Assert
    assert actual_result == expected_result

# Generated at 2022-06-11 22:55:35.558273
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO: Implement unit test for method parse_args of class HTTPieArgumentParser
    raise NotImplementedError()



# Generated at 2022-06-11 22:55:43.748654
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # String Input
    # Return value of function
    rtn = HTTPieArgumentParser('test').parse_args([])
    # Expected return value