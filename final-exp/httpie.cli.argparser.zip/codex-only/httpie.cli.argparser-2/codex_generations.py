

# Generated at 2022-06-23 18:37:34.011023
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    args = HTTPieArgumentParser().parse_args('GET https://httpbin.org/get'.split())
    assert args.method == 'GET'
    assert args.url == 'https://httpbin.org/get'
    assert args.headers is None
    assert args.data is None
    assert args.files is None
    assert args.params is None
    assert args.auth_type == 'basic'
    assert args.auth is None
    assert args.output_file is None
    assert args.output_file_specified is False
    assert args.stdin is None
    assert args.stdin_isatty is None
    assert args.timeout == DEFAULT_TIMEOUT
    assert args.check_status is True
    assert args.verify is True
    assert args.verify_ssl_certs is True
    assert args.download

# Generated at 2022-06-23 18:37:43.867107
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # Test constructor
    env = Environment()
    parser = HTTPieArgumentParser(env=env, add_help=False)
    # Test _apply_no_options
    parser._apply_no_options(['--no-pretty'])
    parser.args.all
    parser.args.pretty
    parser.args.ugly = True
    parser._apply_no_options(['--no-ugly'])
    parser.args.all
    parser.args.ugly
    parser.args.output_options_history = '', '', '', '', '', ''
    parser._apply_no_options(['--no-output-options-history'])
    parser.args.all
    parser.args.output_options = '', '', '', '', '', ''

# Generated at 2022-06-23 18:37:50.926213
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    help_str = """
    Usage: python3 cli/parse_args.py <command> [<args>]

    Commands:

      help       Show this help message and exit.
      post       Post data to the server.
      get        Get data from the server.
      put        Put data to the server.

    """
    formatter = HTTPieHelpFormatter()
    formatter._split_lines(help_str,80)


# module level helper functions


# Generated at 2022-06-23 18:37:56.006503
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # 1. https://httpie.org/doc#testing
    # 2. https://httpie.org/doc#installation
    # 3. https://pypi.python.org/pypi/httpie/0.9.6
    # Each of 1,2,3 is a URL, so at least 3 URLs, which can be interpreted as URIs (URL is a subset of URI).
    args = ['http', 'https://httpie.org/doc#testing', 'https://httpie.org/doc#installation', 'https://pypi.python.org/pypi/httpie/0.9.6']
    ap = HTTPieArgumentParser(add_help=False)
    print(ap.parse_args(args))


# Generated at 2022-06-23 18:38:03.438303
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    class Test():
        def my_function(self, arg1, arg2='def_arg2'):
            '''
            Text for arg1.

            Text for arg2
            '''

            print("test")

        func = my_function.__doc__

    help_parser = argparse.ArgumentParser(formatter_class=HTTPieHelpFormatter)
    help_parser.add_argument('-a', help=Test.func)
    helpstr = help_parser.format_help()

    assert helpstr == 'usage: test.py [-h] [-a arg1 arg2]\n\noptional arguments:\n  -h, --help  show this help message and exit\n  -a          Text for arg1.\n\n            Text for arg2\n\n'



# Generated at 2022-06-23 18:38:07.354620
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    arg_parser = HTTPieArgumentParser()
    arg_parser.parse_args([])

if __name__ == '__main__':
    arg_parser = HTTPieArgumentParser()
    arg_parser.parse_args([])

# Generated at 2022-06-23 18:38:16.108552
# Unit test for constructor of class HTTPieHelpFormatter

# Generated at 2022-06-23 18:38:19.547300
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Given
    args = ["https://www.httpbin.org/headers"]

    # When
    parser = HTTPieArgumentParser()
    ns = parser.parse_args(args)

    # Then
    assert ns.url == "https://www.httpbin.org/headers"
    assert len(ns.headers) == 0
    assert ns.data is None 
    assert ns.files is None
    assert ns.params is None
    assert not ns.download 
    assert not ns.download_resume
    assert not ns.download_async
    assert not ns.download_no_content
    
    
    
    

# Generated at 2022-06-23 18:38:25.750434
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    description = """\
    This is a test!
    It contains a few
    lines of text."""
    # Using a smaller indent for the args help.
    formatter = HTTPieHelpFormatter(3)
    lines = formatter._split_lines(description, 80)
    assert ['    This is a test!', '    It contains a few', '    lines of text.', '', ''] == lines



# Generated at 2022-06-23 18:38:26.866911
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
	pass


# Generated at 2022-06-23 18:38:31.463492
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['GET', 'http://httpbin.org/', 'Host:httpbin.org'])
    assert args.method == 'GET'
    assert args.url == 'https://httpbin.org/'
    assert args.headers == {'Host': 'httpbin.org'}



# Generated at 2022-06-23 18:38:34.459540
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert parser.args.options == []

    print('\nTesting constructor of class HTTPieArgumentParser')


# Generated at 2022-06-23 18:38:37.041576
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args()
    # TODO: Check the answer against the model

# Generated at 2022-06-23 18:38:41.806400
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser(verbose=True)
    # print(parser.args)
    print(parser.format_help())
    print(parser._actions)

if __name__ == '__main__':
    test_HTTPieArgumentParser()

# Generated at 2022-06-23 18:38:43.865915
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert parser.version == httpie.__version__


# Generated at 2022-06-23 18:38:51.481106
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    argv = ['--headers']
    parser = HTTPieArgumentParser(add_help=False)
    parser.add_argument('--headers', action='store_true')
    try:
        args = parser.parse_args(argv)
    except HTTPieError as e:
        assert str(e) == 'hello'
    else:
        assert args.headers is True
        assert argv == []
test_HTTPieArgumentParser_parse_args()


# Generated at 2022-06-23 18:39:01.797809
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-23 18:39:14.618217
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = 'http httpbin.org'
    expected_type = argparse.Namespace

# Generated at 2022-06-23 18:39:16.358420
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert HTTPieHelpFormatter(max_help_position=6)


# Generated at 2022-06-23 18:39:19.073519
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """
    TODO
    """

    parser = HTTPieArgumentParser()
    parser.parse_args()



# Generated at 2022-06-23 18:39:21.547719
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    args = {
        'max_help_position': 1,
        'width': 1
    }
    formatter = HTTPieHelpFormatter(**args)
    text = """
    x
    y
    z
    """
    assert formatter._split_lines(text, **args) == ['x', 'y', 'z', '']



# Generated at 2022-06-23 18:39:27.007757
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    # parser.parse_args(['s2i', '--version'])
    # parser.parse_args(['s2i', '--help'])
    parser.parse_args(['get', 'https://www.github.com'])
    # parser.parse_args(['--debug', '--help'])



# Generated at 2022-06-23 18:39:35.714109
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    old_env = {}
    env = Environment(**vars(ENV_DEFAULTS))
    args = Arguments(env)
    old_env.update(env)

    parser = HTTPieArgumentParser(args)
    parser.env = env
    parser.args = args

    args_copy = copy.copy(args)

    parser.__init__(args,
        always_json=False,
        form=False,
        ignore_stdin=False,
        json=False,
        stdin_isatty=False,
        upload_files=False,
        output_file=False,
        stdout_isatty=False
    )

    assert args.always_json is args_copy.always_json
    assert args.form is args_copy.form
    assert args.ignore_stdin is args_

# Generated at 2022-06-23 18:39:44.460921
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # initialize empty HTTPieArgumentParser object
    http = HTTPieArgumentParser()  
    # Check ArgumentParser object is initialized with basic attributes,
    # without any requirement
    assert not http.args.auth_plugin
    assert not http.args.auth_type
    assert not http.args.auth
    assert not http.args.output_file
    assert not http.args.output_file_specified
    assert not http.args.download

if __name__ == '__main__':
    test_HTTPieArgumentParser()
    print("Test Passed")

# Generated at 2022-06-23 18:39:57.087271
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    # Given
    def get_help(kwargs):
        class FakeParser(object):
            def __init__(self, kwargs):
                self.kwargs = kwargs

            def add_argument(self, *args, **kwargs):
                pass

        parser = FakeParser(kwargs)
        http_help_formatter = HTTPieHelpFormatter(parser, max_help_position=10)
        help_text = kwargs['help']
        
        # When
        http_help_formatter.add_argument(*args, **kwargs)

        # Then
        return (http_help_formatter, help_text)

    # Given

# Generated at 2022-06-23 18:40:01.639060
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        formatter_class=HTTPieHelpFormatter,
        description=__doc__,
    )
    parser.add_argument(
        '--foo',
        help="""\
        foo to your heart's content
        """
    )
    parser.parse_args('--help'.split())



# Generated at 2022-06-23 18:40:06.060406
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser('hello')
    assert parser.prog == 'hello'
    assert parser.description != ''
    assert parser.epilog != ''
    assert parser.add_argument != ''
    assert parser.error_message != ''

"""
Method:
    add_argument(...)
        purpose:
            add an argument to the parser
        params:
            *
            **
        returns:
            None
Unit test:
    # TODO
"""

# Generated at 2022-06-23 18:40:08.742018
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    test_str = "Indent and add new lines in help for arguments."
    print(test_str)
    print()
    print()



# Generated at 2022-06-23 18:40:19.021089
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    h = HTTPieHelpFormatter()
    assert h.__dict__.get('max_help_position') == 6
    assert h.__dict__.get('width') == 90
    assert h.__dict__.get('current_indent') == 0
    assert h.__dict__.get('level') == 0
    assert h.__dict__.get('_root_section') is None
    assert h.__dict__.get('_last_item') is None
    assert h.__dict__.get('_indent_per_level') == 2
    assert h.__dict__.get('_long_break_initial_indent') is None
    assert h.__dict__.get('_short_break_initial_indent') is None

# Generated at 2022-06-23 18:40:26.304769
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    """
    测试HTTPieHelpFormatter类的构造函数
    :return: None
    """
    parser = argparse.ArgumentParser(
        description='foo',
        formatter_class=HTTPieHelpFormatter,
    )
    parser.add_argument('-a', help='\n  A\n  B\n\n C')
    parser.add_argument('-b', help='\n  A\n  B\n\n C')
    parser.parse_args(args=[])



# Generated at 2022-06-23 18:40:33.206855
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # case 1:
    parser = HTTPieArgumentParser()
    assert parser.args.all == False
    assert parser.args.output_file_specified == False
    assert parser.args.verbose == False
    assert parser.args.offline == False

    # case 2:
    parser = HTTPieArgumentParser()
    parser.args.verbose = True
    assert parser.args.verbose == True
    assert parser.args.all == True
    assert parser.args.output_file_specified == False

    # case 3:
    parser = HTTPieArgumentParser()
    parser.args.output_file = 'test.txt'
    parser.args.download = True
    parser.args.quiet = True
    parser._setup_standard_streams()
    assert parser.args.output_file_specified == True

# Generated at 2022-06-23 18:40:40.120611
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    text = """
    Line one.

    Line two.

        Some help for arg1.
        And another one.

    Line three.
    """
    formatter = HTTPieHelpFormatter()
    assert formatter._split_lines(text, 80) == [
        'Line one.',
        '',
        'Line two.',
        '',
        '    Some help for arg1.',
        '    And another one.',
        '',
        'Line three.',
        '',
        ''
    ]



# Generated at 2022-06-23 18:40:42.053567
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert parser.args.auth is None

# Generated at 2022-06-23 18:40:50.730864
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    options = parser.parse_args(args=['GET', 'https://example.com'])
    assert options.method == 'GET'
    assert options.url == 'https://example.com'
    assert options.headers == []
    assert options.data == {}
    assert options.json == {}
    assert options.params == {}
    assert options.auth == None
    assert options.auth_type == None
    assert options.auth_plugin == None
    assert options.download == False
    assert options.output_file_specified == False
    assert options.pretty == 'all'
    assert options.prettify == PRETTY_MAP['all']
    assert options.style == None
    assert options.style_sheet == None
    assert options.print_body_only == False
    assert options.body

# Generated at 2022-06-23 18:41:03.080406
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    # This is just a doc test.
    class FooAction(argparse.Action):
        def __init__(self, option_strings, dest, nargs=None, **kwargs):
            if nargs is not None:
                raise ValueError("nargs not allowed")
            super().__init__(option_strings, dest, **kwargs)
        def __call__(self, parser, namespace, values, option_string=None):
            print('%r %r %r' % (namespace, values, option_string))
            setattr(namespace, self.dest, values)

    parser = argparse.ArgumentParser(
        formatter_class=HTTPieHelpFormatter)

# Generated at 2022-06-23 18:41:12.261160
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    # Function _split_lines(self, text, width)
    max_help_position = 6
    text = '''
    This is the help for argument "--arg1". It is indented and contains
    new lines. It will be de-dented and will contain blank lines for better
    readability.
    '''
    helptext = '\n    This is the help for argument "--arg1". It is indented and contains\n    new lines. It will be de-dented and will contain blank lines for better\n    readability.\n\n'
    assert HTTPieHelpFormatter(max_help_position)._split_lines(text, max_help_position) == helptext.splitlines()



# Generated at 2022-06-23 18:41:22.727386
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    from argparse import ArgumentParser
    parser = ArgumentParser(formatter_class=HTTPieHelpFormatter)
    parser.add_argument('--help-me', help="""
    This

        is

                multiline



    help.

    """)
    parser.print_help()
    from io import StringIO
    import sys
    save_stdout = sys.stdout
    try:
        out = StringIO()
        sys.stdout = out
        parser.print_help()
        output = out.getvalue().strip()
    finally:
        sys.stdout = save_stdout

# Generated at 2022-06-23 18:41:24.702020
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    
    print(parser)

# Generated at 2022-06-23 18:41:26.812407
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert parser.__class__ == argparse.ArgumentParser



# Generated at 2022-06-23 18:41:39.294872
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args()
    assert args.url is None
    assert args.request_items == []
    assert args.method is None
    assert args.auth is None
    assert args.ignore_stdin is False
    assert args.headers == {}
    assert args.headers_type is None
    assert args.data is None
    assert args.params == {}
    assert args.files == {}
    assert args.form is False
    assert args.style is None
    assert args.download is False
    assert args.download_resume is False
    assert args.output_file is None
    assert args.output_file_specified is False
    assert args.output_options is None
    assert args.output_options_history is None
    assert args.verbose is False

# Generated at 2022-06-23 18:41:41.513256
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-23 18:41:51.164763
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        description='description',
        formatter_class=HTTPieHelpFormatter
    )
    parser.add_argument('--foo', help='foo\nbar')
    parser.add_argument('bar', help='bar\nfoo')
    expected = """\
    description
    usage:

    positional arguments:
    bar                   bar
                          foo

    optional arguments:
    --foo foo             foo
                          bar

    """
    assert parser.format_help() == expected

HTTPieHelpFormatter.test = classmethod(test_HTTPieHelpFormatter)


# Generated at 2022-06-23 18:42:01.964114
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    if '--help' in sys.argv:
        # Make help message show properly
        sys.stdout.write('\n')

# Generated at 2022-06-23 18:42:14.750230
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()

    assert parser.args == parser.parse_args([])
    assert parser.args.headers == []
    assert parser.args.request_items == []
    assert parser.args.data is None
    assert parser.args.files == {}
    assert parser.args.params == {}
    assert parser.args.multipart_data == []


# Generated at 2022-06-23 18:42:16.049855
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    args = HTTPieArgumentParser.parse_args()
    print(args)



# Generated at 2022-06-23 18:42:16.669798
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    pass



# Generated at 2022-06-23 18:42:25.801321
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    description = "description\n\n"

    # Choose the content of argument ``description``,
    # which will be tested for different content in paragraphs.
    for i in range(0, 5):
        arg_help = ""
        for j in range(0, i):
            arg_help += "\n"
        arg_help += "arg help"
        for j in range(0, i):
            arg_help += "\n"
        arg_help += "\n"

        formatter = HTTPieHelpFormatter(description=description + arg_help)
        print(formatter._format_usage(None, None))



# Generated at 2022-06-23 18:42:37.085530
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # ## ArgParse
    # `ArgParse` class is the original Python class to parse command line
    # arguments.  It has a bit of boilerplate code and its usage is a bit more
    # complicated than `ArgumentParser` which we will look at next.
    from argparse import ArgumentParser
    # patch Python 2.6's missing `ArgumentParser.error` to bail on errors
    if not hasattr(ArgumentParser, 'error'):
        setattr(ArgumentParser, 'error',
                lambda *a, **k: self.exit(2, *a, **k))
        # ## ArgumentParser
        # `ArgumentParser` class is the new Python class to parse command line
        # arguments.  It is a subclass of `ArgParse` with simpler interface and
        # better user experience. To use `ArgumentParser`, we need

# Generated at 2022-06-23 18:42:47.034270
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    http_parser = HTTPieArgumentParser()

    assert(http_parser.args.headers is None)
    assert(http_parser.args.method is None)
    assert(http_parser.args.params is None)
    assert(http_parser.args.prettify is False)
    assert(http_parser.args.print == 'H')
    assert(http_parser.args.print_headers is None)
    assert(http_parser.args.timeout is None)
    assert(http_parser.args.traceback is None)
    assert(http_parser.args.auth_type is None)
    assert(http_parser.args.max_headers is None)
    assert(http_parser.args.max_redirects is None)
    assert(http_parser.args.follow_redirects is None)
   

# Generated at 2022-06-23 18:42:49.003244
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert isinstance(HTTPieHelpFormatter(), RawDescriptionHelpFormatter)
    assert isinstance(HTTPieHelpFormatter(), HTTPieHelpFormatter)
    assert isinstance(HTTPieHelpFormatter.__init__, types.MethodType)



# Generated at 2022-06-23 18:42:50.545500
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    httpArg = HTTPieArgumentParser()
    print (httpArg)


# Generated at 2022-06-23 18:42:52.584904
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    env = Environment()
    args = []
    parser = HTTPieArgumentParser(
        env=env,
        args=args,
    )
    parser.parse_args()

# Generated at 2022-06-23 18:42:54.311239
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.parse_args()

# Generated at 2022-06-23 18:42:58.493054
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    help_test = "aaa\n\nbbb\n\nccc\n"
    formatter = HTTPieHelpFormatter(max_help_position=2, width=80)
    assert formatter._split_lines(help_test, 80) == ["aaa", "bbb", "ccc", "", ""]



# Generated at 2022-06-23 18:43:10.961706
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    # Test args.verify
    parser.args.verify = False
    parser._process_verify_options()
    assert parser.args.verify == False

    parser.args.verify = True
    parser._process_verify_options()
    assert parser.args.verify == True

    parser.args.verify = None
    parser._process_verify_options()
    assert parser.args.verify == True

    parser.args.verify = "./certs/cert.pem"
    parser._process_verify_options()
    assert parser.args.verify == "./certs/cert.pem"

    # Test args.timeout
    parser.args.timeout = 10
    parser._process_timeout_options()

# Generated at 2022-06-23 18:43:12.856463
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    tester = HTTPieArgumentParser()

# Generated at 2022-06-23 18:43:23.874922
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(args=['-h'])
    assert isinstance(args, argparse.Namespace)    
    assert args.headers == DEFAULT_UA
    assert args.auth == None
    assert args.auth_plugin == None
    assert args.download == False
    assert args.follow == False
    assert args.follow_redirects == True
    assert args.max_redirects == HTTPieArgumentParser.DEFAULT_MAX_REDIRECTS
    assert args.method == None
    assert args.verbose == False
    assert args.all_headers == False
    assert args.form == False
    assert args.json == False
    assert args.pretty == None
    assert args.print_body == True
    assert args.print_headers == True
    assert args

# Generated at 2022-06-23 18:43:34.830971
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert HTTPieHelpFormatter().__init__(4)==None



# Generated at 2022-06-23 18:43:39.722269
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    tmp = argparse.ArgumentParser()
    tmp.add_argument('--foo', help='Lorem ipsum dolor sit amet, consectetur \n adipisicing elit, sed do eiusmod tempor\n incididunt ut labore et dolore magna aliqua.')
    print(tmp.format_help())


# Generated at 2022-06-23 18:43:51.743557
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """
    Test HTTPieArgumentParser.parse_args

    """
    args = ["--json", "--auth-type=basic", "http://localhost:5000", "--json", "a=1", "b=2", "--auth", "--verbose"]
    parser = HTTPieArgumentParser()
    parser.parse_args(args=args)
    assert parser.args.json
    assert parser.args.auth_type == 'basic'
    assert parser.args.url == "http://localhost:5000"
    assert parser.args.json
    assert parser.args.auth_type == 'basic'
    assert parser.args.request_item_args[0].key == 'a'
    assert parser.args.request_item_args[0].value == '1'

# Generated at 2022-06-23 18:43:54.052971
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    parser.add_argument('--foo')
    assert parser.format_epilog('bar') == 'bar\n'



# Generated at 2022-06-23 18:44:01.178411
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO: Implement appropriate unit test
    return

# Unit tests for class HTTPieArgumentParser
# TODO: Implement appropriate unit tests

# Unit tests for module httpie
# TODO: Implement appropriate unit tests

# Unit tests for module httpie.client
# TODO: Implement appropriate unit tests

# Unit tests for class AsyncHTTPieStream
# TODO: Implement appropriate unit tests

# Unit tests for class AsyncHTTPieRaw
# TODO: Implement appropriate unit tests

# Unit tests for class AsyncHTTPiePretty
# TODO: Implement appropriate unit tests

# Unit tests for class AsyncHTTPieColored
# TODO: Implement appropriate unit tests

# Unit tests for class AsyncHTTPieVerbose
# TODO: Implement appropriate unit tests

# Unit tests for class AsyncHTTPieStream
# TODO: Implement appropriate unit

# Generated at 2022-06-23 18:44:12.326484
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # Test1: No arguments
    args = []
    try:
        # Test1: No arguments
        parser = HTTPieArgumentParser(args, env=Environment())
        assert False  # Should not reach here
    except argparse.ArgumentError as e:
        assert re.match('^too few arguments$', str(e))

    # Test2: Default arguments
    args = ['-p', 'c:\\test.txt', 'https://jsonplaceholder.typicode.com/albums']
    parser = HTTPieArgumentParser(args, env=Environment())
    assert parser.args.output_file == open('c:\\test.txt', 'wb')
    assert parser.args.url == 'https://jsonplaceholder.typicode.com/albums'

    # Test3: Invalid arguments

# Generated at 2022-06-23 18:44:19.273518
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    sys.argv = ['http','--help']
    parser = argparse.ArgumentParser(
        description='HTTPie %s' % __version__,
        formatter_class=HTTPieHelpFormatter,
    )
    parser.add_argument('-v','--version', action='version',
                            version='HTTPie %s' % __version__)
    parser.add_argument('method',
                            nargs='?',
                            default=HTTP_GET,
                            help='The HTTP method to be used for the request.')
    parser.add_argument('--auth', metavar='USER[:PASS]',
                                help='Basic HTTP authentication.')
    args = parser.parse_args(sys.argv[1:])


# Generated at 2022-06-23 18:44:22.754181
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert HTTPieHelpFormatter()._split_lines("\n     aa\n  bb\ncc\n\n", 6) == ['aa', 'bb', 'cc', '', '']


#
# Helpers
#


# Generated at 2022-06-23 18:44:26.079662
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    cli_args_strs = ['http://example.com', '-v', '<', '-']
    cli_args = HTTPieArgumentParser().parse_args(cli_args_strs)
    print('http%s : %s' % (cli_args.no_verify, cli_args.url))

#test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-23 18:44:31.578139
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=HTTPieHelpFormatter)
    parser.add_argument('-x', help='some text\nwith\nnew lines.')
    args = parser.parse_args(['--help'])



# Generated at 2022-06-23 18:44:34.731625
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    # fix arguments
    parser.args = parser.parse_args(['--ignore-stdin',
                                     'http://www.google.com'])
    # check if parsing is done correctly
    assert parser.args.ignore_stdin is True


# Generated at 2022-06-23 18:44:40.411507
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # No value
    argv = ['test', 'value']
    options = HTTPieArgumentParser().parse_args(argv)
    assert options.url == 'test'
    assert options.method == 'value'
    # Add value
    argv = ['test', 'value', '-p']
    options = HTTPieArgumentParser().parse_args(argv)
    assert options.url == 'test'
    assert options.method == 'value'
    assert options.headers == []
    assert options.auth == []
    assert options.params == []
    assert options.json == []
    assert options.body == []
    assert options.download == []
    assert options.ignore_stdin == []
    assert options.timeout == []
    assert options.max_headers == []
    assert options.max_redirects == []


# Generated at 2022-06-23 18:44:46.289487
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie.core import main
    with open('./http_history.txt', 'r') as his:
        for line in his.readlines():
            try:
                _ = main(args=line.strip().split()[1:])
            except Exception as e:
                print(e)

# Generated at 2022-06-23 18:44:47.716636
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.parse_args([])

# Generated at 2022-06-23 18:44:49.839615
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert HTTPieHelpFormatter().__class__ == RawDescriptionHelpFormatter



# Generated at 2022-06-23 18:45:02.098990
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.parse_args(['--json','--stream','--form','--pretty=all','--headers','Content-Type:text/html','--auth=username:password','https://httpbin.org/post/'])

    # Check whether the arguments have been set correctly
    assert(parser.args.json==True)
    assert(parser.args.stream==True)
    assert(parser.args.form==True)
    assert(parser.args.prettify=='all')
    assert(parser.args.headers==[('Content-Type','text/html')])
    assert(parser.args.auth=='username:password')
    assert(parser.args.url=='https://httpbin.org/post/')
    # Test parser.error()

# Generated at 2022-06-23 18:45:08.005295
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = ['http', 'https://httpie.org/doc']
    result = HTTPieArgumentParser.parse_args(args)

    assert result.url == 'https://httpie.org/doc'
    assert result.headers['User-Agent'] == 'HTTPie/' + __version__
    assert result.headers['Accept-Encoding'] == 'gzip, deflate'


# Generated at 2022-06-23 18:45:21.446836
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser()
    parser.add_argument('-a', '--aaa', help = "A long help string\nA second line\nA third line")
    parser.add_argument('-b', '--bbb')

    help_text = parser.format_help().splitlines()
    # print(help_text)
    print()
    # print(help_text[3])
    # print(help_text[4])
    # print(help_text[5])
    # print(help_text[8])
    # print(help_text[9])
    # print(help_text[10])
    assert help_text[3] == '  -a AAA, --aaa AAA  A long help string'
    assert help_text[4] == '                     A second line'
    assert help_

# Generated at 2022-06-23 18:45:30.912024
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    with pytest.raises(SystemExit) as e:
        HTTPieArgumentParser().parse_args([])
    assert str(e.value) == '2'
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


# Generated at 2022-06-23 18:45:36.216313
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    arguments = ['-v']
    args = HTTPieArgumentParser(arguments)
    args.add_argument('-v')

    assert args.args.verbose == True
    print('test_HTTPieArgumentParser')


# Generated at 2022-06-23 18:45:39.690290
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    init_mock_args()
    parser = HTTPieArgumentParser()
    args = parser.parse_args()
    print (args)
    print (args.url)



# Generated at 2022-06-23 18:45:42.789863
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = []
    assert parser.parse_args(args) == parser.args
    
test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-23 18:45:48.388066
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=HTTPieHelpFormatter)
    parser.add_argument('--foo', help='\nfoo\nbar\n\nbaz\n\n')
    assert parser.format_help() == dedent("""\
    usage: [-h] [--foo FOO]
    
    optional arguments:
      -h, --help  show this help message and exit
      --foo FOO   foo
                  bar
    
                  baz
    """)


# Generated at 2022-06-23 18:45:57.571065
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """Testing constructor of class HTTPieArgumentParser"""
    Parser = HTTPieArgumentParser()
    assert Parser._colors_enabled
    assert not Parser._disable_colors
    assert not Parser._request_abbrev
    assert not Parser.env.is_windows
    assert Parser.env.stdout_isatty
    assert not Parser.env.stdout_isatty
    assert Parser.env.stderr_isatty
    assert not Parser.env.stderr_isatty



# Generated at 2022-06-23 18:46:05.280748
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
  test_call = "http 'http://httpbin.org/cookies/set?k1=v1' 'k2=v2' Cookies"
  parser = HTTPieArgumentParser()
  parser.parser = Mock()
  #parser.parse_args(test_call.split())
  #assert parser.parser.parse_args.called
  parser.parse_args(test_call.split())
  assert parser.parser.parse_args.called


# Generated at 2022-06-23 18:46:15.443707
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie.context import Environment
    from httpie.plugins import plugin_manager
    from httpie import cli
    from argparse import Namespace
    cli.ArgumentParser = HTTPieArgumentParser

    parser = HTTPieArgumentParser(
        env=Environment(),
        plugins=plugin_manager,
    )
    parser.add_argument('URL', nargs='?')

    args = parser.parse_args(['http://127.0.0.1:5000/get'])
    assert "parsed_args" in dir(args)
    parsed_args = args.parsed_args
    assert isinstance(parsed_args, Namespace)
    assert "url" in dir(parsed_args)
    assert "request_items" in dir(parsed_args)

# Generated at 2022-06-23 18:46:18.137282
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
  parser = HTTPieArgumentParser()
  assert parser.env.is_windows
  assert parser.parser_args=={'add_help': True, 'conflict_handler': 'resolve'}


# Generated at 2022-06-23 18:46:24.579016
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    import sys
    import io

    class Object(object):

        pass

    stdout_stream_mock = io.StringIO()
    stdout_stream_mock.isatty = lambda: True

    stdin_stream_mock = io.StringIO()
    stdin_stream_mock.read = lambda: "request body"

    stderr_stream_mock = io.StringIO()
    stderr_stream_mock.isatty = lambda: True

    sys.stdout = stdout_stream_mock
    sys.stdin = stdin_stream_mock
    sys.stderr = stderr_stream_mock

    env = Object()
    env.stdout = stdout_stream_mock
    env.stdout_isatty = True
    env.stderr

# Generated at 2022-06-23 18:46:36.745613
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    input_args = ['-v',
		'--pretty=all',
		'--style=solarized-dark',
		'https://www.baidu.com/',
		'User-Agent:',
		'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36',
		'Accept-Language:',
		'zh-CN,zh;q=0.9',
	]


# Generated at 2022-06-23 18:46:46.199972
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    help_format = HTTPieHelpFormatter(max_help_position=6)
    # args = [-h, --help]
    args = ['parser_args', '--help', 'parser_args']
    # Add a fake parser to see if it will print help as expected
    parser = argparse.ArgumentParser()
    parser.add_argument('--help', action='help')
    sys.argv = args
    # Use args[0] to check the help information of http command in terminal
    print(help_format.format_help(args[0], parser))
    # Use args[1] to check the help information of http command in terminal
    print(help_format.format_help(args[1], parser))


DEFAULT_UA = 'HTTPie/%s' % __version__
CONFIG_DIR = os.path.join

# Generated at 2022-06-23 18:46:56.826795
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert parser.env.is_windows == is_windows
    assert parser.env.stdout_isatty == sys.stdout.isatty()
    assert parser.env.devnull.write(b'foo') == 3
    assert parser.env.stderr.write(b'foo') == 3
    assert parser.env.stdout
    assert parser.env.stderr
    assert parser.env.stdin
    assert parser.env.stdout_encoding
    assert parser.env.stderr_encoding
    assert parser.env.stdin_encoding
    parser.args.url = 'foo'
    parser.args.output_file = 'foo'
    parser.args.output_file_specified = True
    parser._setup_standard_streams()

# Generated at 2022-06-23 18:46:58.565344
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatted_string = HTTPieHelpFormatter().format_help()
    assert formatted_string



# Generated at 2022-06-23 18:47:08.816436
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():

    class MockArgs:
        def __init__(self):
            self.check_plain = True
            self.check_json = False
            self.print_bodies_only_for_error_response = False
            self.check_status = False
            self.headers = {}
            self.ignore_stdin = False
            self.form = False
            self.output_options = OUTPUT_OPTIONS_DEFAULT
            self.timeout = 10
            self.skip_auto_headers = False
            self.verbose = False
            self.json = True
            self.print_header_only = False
            self.output = None
            self.download = False

    parser = argparse.ArgumentParser(
        formatter_class=HTTPieHelpFormatter)

# Generated at 2022-06-23 18:47:16.652633
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    parser.add_argument(
        '--foo',
        dest='foo',
        default='bar',
        help='baz'
    )
    parser.add_argument(
        'arg',
        nargs='+'
    )
    args = parser.parse_args(['--foo', '123', 'q'])
    assert args.foo == '123'
    assert args.arg == ['q']



# Generated at 2022-06-23 18:47:23.866307
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter(max_help_position=6, width=None)
    assert formatter.width is None
    assert formatter.max_help_position == 6
    assert _find_all_args_in_help(formatter)
    assert _find_all_args_in_help(formatter)

