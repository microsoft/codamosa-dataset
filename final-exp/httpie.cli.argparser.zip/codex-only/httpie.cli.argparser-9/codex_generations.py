

# Generated at 2022-06-23 18:37:34.292015
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    test_help_str = '''
        This is a help text.
          indented part
        not indented
        '''
    test_help_str_dedented = '''This is a help text.
      indented part
    not indented

    '''
    res = ''
    for x in HTTPieHelpFormatter(max_help_position=4)._split_lines(test_help_str, width=80):
        res = res +  x + '\n'
    assert res == test_help_str_dedented, "deindent text failed!"


# fix the issue of: ``http --ignore-stdin --auth-type=digest httpbin.org/get``
# test_HTTPieHelpFormatter()


# Generated at 2022-06-23 18:37:38.972450
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    argstr = '--offline'
    argstr = [c for c in argstr]
    parser = HTTPieArgumentParser()
    args = parser.parse_args(argstr)
    assert args.offline == True
    assert args.download == False
    assert args.download_resume == False

# Generated at 2022-06-23 18:37:44.852669
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # Case 0: Positive
    query = {'q':'query string'}
    args = str(query).replace("\'", "\"")
    command = 'http GET httpbin.org/get ' + args

    args = shlex.split(command)
    parser = HTTPieArgumentParser()
    parsed_args = parser.parse_args(args)
    assert parsed_args.url == 'httpbin.org/get', 'Wrong url'
    assert parsed_args.method == 'GET', 'Wrong method'
    assert parsed_args.request_items[0].key == 'q', 'Wrong request item'

    # Case 1: Negative
    expected_msg = 'unrecognized arguments: --method'
    args = ['--method', 'GET', 'httpbin.org/get','q==query string']
    parser = HTTP

# Generated at 2022-06-23 18:37:47.268209
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.parse_args(['http','--version'])


# Generated at 2022-06-23 18:37:53.843598
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie.constants import __version__
    from httpie.cli import parse_args

    args = parse_args(args=['http','--verbose','--headers','--body','--traceback','--download','GET','www.runoob.com'])

    # Ensure --version is processed correctly
    assert args.version == __version__

    # Ensure --verbose is processed correctly
    assert args.verbose == True

    # Ensure --headers is processed correctly
    assert args.headers == True

    # Ensure --body is processed correctly
    assert args.body == True

    # Ensure --traceback is processed correctly
    assert args.traceback == True

    # Ensure --download is processed correctly
    assert args.download == True

    # Ensure --auth is processed correctly
    assert args.auth == None

    # Ensure --output is processed correctly
   

# Generated at 2022-06-23 18:37:58.836668
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.add_argument('--url', required=True)
    args = parser.parse_args([
        '--url',
        'https://example.org',
        '--form',
    ])
    assert args.url == 'https://example.org'
    assert args.form



# Generated at 2022-06-23 18:38:04.190258
# Unit test for constructor of class HTTPieHelpFormatter

# Generated at 2022-06-23 18:38:13.831422
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.formatter import HTTPieHelpFormatter
    # Formatter: A nicer help formatter.
    formatter = HTTPieHelpFormatter()
    # set help parameters
    parser = argparse.ArgumentParser(formatter_class=HTTPieHelpFormatter,
                                     add_help=False)
    parser.add_argument('--foo', metavar='key=val', type=KeyValueArgType()
                          ).help = '''
        foo the first
        bar the second
    '''
    parser.add_argument('bar', nargs='?').help = '''
        bar the first
        bar the second
    '''

# Generated at 2022-06-23 18:38:23.316887
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    
    printExecutedTest("test_HTTPieArgumentParser_parse_args")
    args = ["https://httpbin.org/headers", "Content-Type:application/json"]
    args = HTTPieArgumentParser().parse_args(args)
    assert args.url == "https://httpbin.org/headers"
    assert args.request_items[0] == args.request_items[0].to_str()
    assert args.request_items[0].sep == ":"
    assert args.request_items[0].key == "Content-Type"
    assert args.request_items[0].value == "application/json"
    args = ["https://httpbin.org/headers", "Content-Type:", "application/json"]
    args = HTTPieArgumentParser().parse_args(args)
    assert args.url

# Generated at 2022-06-23 18:38:25.001567
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    print(parser)
    parser.parse_args()

# Generated at 2022-06-23 18:38:29.292748
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    # noinspection PyUnresolvedReferences
    assert parser.parser.formatter_class.max_help_position == 40
    assert parser.parser.formatter_class.width == 80



# Generated at 2022-06-23 18:38:35.334271
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():

    env_mock = Env(
        config={},
        stdin=StringIO(),
        stdin_isatty=False,
        stdout=StringIO(),
        stdout_isatty=False,
        stderr=StringIO(),
        stderr_isatty=False
    )

    httpie_argument_parser_mock = HTTPieArgumentParser(env=env_mock)

    assert httpie_argument_parser_mock.args == httpie_argument_parser_mock.parse_args([])

# Generated at 2022-06-23 18:38:36.799669
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert isinstance(HTTPieHelpFormatter() , HTTPieHelpFormatter)



# Generated at 2022-06-23 18:38:48.632127
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
	output_options = 'Hhb'
	output_options_history = 'H'
	headers = []
	params = []
	data = ''
	files = []
	data_file_name = ''
	data_file_type = ''
	data_file_content = ''
	multipart_data = []
	auth = ''
	auth_plugin = None
	auth_type = ''
	insecure = False
	output_file = None
	output_file_specified = False
	output_file_open_mode = 'wb'
	download = False
	download_resume = False
	method = 'GET'
	form = False
	json = False
	print_body = True
	no_body = False
	pretty = None
	stream = False
	style = 'solarized'
	style_vari

# Generated at 2022-06-23 18:39:00.161226
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import pytest
    from httpie import input
    from httpie.constants import DEFAULT_FORMAT
    from httpie.input import SEP_CREDENTIALS
    env = TestEnvironment()
    config_dir = None
    config = Config(env=env, config_dir=config_dir,
                    output_options=OUTPUT_OPTIONS_DEFAULT)
    # when
    parser = HTTPieArgumentParser(
        env=env, config=config, config_dir=config_dir,
        output_options=OUTPUT_OPTIONS_DEFAULT)

# Generated at 2022-06-23 18:39:13.709196
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # ***************************************************
    # out_file = open('test/results/HTTPieArgumentParser_parse_args.txt', 'w+')
    # for line in out_file: print(line)
    # ***************************************************
    args = HTTPieArgumentParser().parse_args()
    assert not args.help
    assert args.http_version == HTTP_DEFAULT_VERSION
    assert args.max_redirects == 0
    assert args.timeout == DEFAULT_TIMEOUT
    assert args.method == HTTP_GET
    assert not args.auth
    assert not args.auth_type
    assert not args.ignore_netrc
    assert args.output_options == 'H'
    assert args.output_options_history == 'H'
    assert args.prettify == PRETTY_MAP['all']

# Generated at 2022-06-23 18:39:22.396340
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(description="""
        The main point
        of this description""",
        formatter_class=HTTPieHelpFormatter)
    parser.add_argument('--foo', help="""
        Line 1 of the argument's help
        Line 2
        """)
    parser.add_argument('bar', help="""
        Line 1 of the argument's help
        Line 2
        """)
    help_msg = parser.format_help()
    assert help_msg.count('\n') == help_msg.count('\n\n')



# Generated at 2022-06-23 18:39:26.832649
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--traceback','https://httpbin.org/'])
    assert args.traceback
    assert isinstance(args, DotDict)
    assert args['traceback']
    assert not args.verbose
    



# Generated at 2022-06-23 18:39:31.652091
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # Set up the environment.
    env = Environment(**VARS)
    env.stdout = io.BytesIO()
    env.stdout_isatty = True
    env.stderr = io.BytesIO()
    env.stderr_isatty = True
    env.stdin = io.BytesIO()
    env.stdin_isatty = True
    parser = HTTPieArgumentParser(env)


# Generated at 2022-06-23 18:39:44.365628
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    stderr = StringIO()
    parser = HTTPieArgumentParser(stderr=stderr)
    args = parser.parse_args(args=[])
    assert args.method == 'GET'
    assert args.url == 'http://httpie.org/'
    assert args.headers == []
    assert args.data == []
    assert args.params == []
    assert args.output_file == None
    assert args.output_options == 'H'
    assert args.output_options_history == 'H'
    assert args.print_body_only == False
    assert args.style == 'colorful'
    assert args.style_expanded == False
    assert args.verbose == False
    assert args.debug == False
    assert args.traceback == False
    assert args.json == False
    assert args.pretty

# Generated at 2022-06-23 18:39:56.654969
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    assert isinstance(HTTPieArgumentParser(True,True),HTTPieArgumentParser)
    assert isinstance(HTTPieArgumentParser(None,None,True,False),HTTPieArgumentParser)
    assert isinstance(HTTPieArgumentParser(None,None,True,None),HTTPieArgumentParser)
    assert isinstance(HTTPieArgumentParser(None,None,True),HTTPieArgumentParser)
    assert isinstance(HTTPieArgumentParser(None,None,None),HTTPieArgumentParser)
    assert isinstance(HTTPieArgumentParser(None,None,),HTTPieArgumentParser)
    assert isinstance(HTTPieArgumentParser(None),HTTPieArgumentParser)
    assert isinstance(HTTPieArgumentParser(),HTTPieArgumentParser)


# Generated at 2022-06-23 18:40:02.405618
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    f = HTTPieHelpFormatter()
    line = f._split_lines("   Hi there\n\n    dude\n       dude\n", 40)
    assert line[0] == "Hi there\n\n"
    assert line[1] == "dude\n"
    assert line[2] == "dude\n"
    assert line[3] == ""
    assert len(line) == 4


# Generated at 2022-06-23 18:40:08.940918
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    from httpie.cli.argtypes import AuthCredentials, KeyValueArgType, PARSED_DEFAULT_FORMAT_OPTIONS, parse_auth, parse_format_options
    from httpie.cli.constants import HTTP_GET, HTTP_POST, OUTPUT_OPTIONS, OUTPUT_OPTIONS_DEFAULT, OUTPUT_OPTIONS_DEFAULT_OFFLINE, OUTPUT_OPTIONS_DEFAULT_STDOUT_REDIRECTED, OUT_RESP_BODY, PRETTY_MAP, PRETTY_STDOUT_TTY_ONLY, RequestType, SEPARATOR_CREDENTIALS, SEPARATOR_GROUP_ALL_ITEMS, SEPARATOR_GROUP_DATA_ITEMS, URL_SCHEME_RE
    from httpie.cli.exceptions import ParseError

# Generated at 2022-06-23 18:40:19.096862
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    parser.add_argument('action', choices=['bark', 'meow'])
    parser.add_argument('--foo')
    parser.add_argument('--bar', required=True)
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(['bark', '--foo=X', '--bar=Y'])
    assert args.foo == 'X'
    assert args.bar == 'Y'
    assert args.baz is False
    assert args.action == 'bark'

    with pytest.raises(SystemExit) as exc_info:
        parser.parse_args(['bark', '--foo=X', '--baz'])

# Generated at 2022-06-23 18:40:25.025442
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    args = HTTPieArgumentParser(
        name='http',
        prog='http',
        usage='%(prog)s [OPTIONS] URL [REQUEST_ITEM [REQUEST_ITEM ...]]',
        version=__version__,
        formatter_class=RawTextHelpFormatter,
        allow_interspersed_args=False,
        env=env
    ).parse_args()
    print(vars(args))


# Generated at 2022-06-23 18:40:37.178573
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser('description',
                                     formatter_class=HTTPieHelpFormatter)
    parser.add_argument('--foo', help='foo\nbar\n')
    assert parser.format_help()
    if sys.version_info[:2] == (3, 2):
        # Workaround for Python 3.2
        return
    assert parser.format_help() == """\
usage: description

positional arguments:

  optional arguments:
    --foo foo
        bar\
"""

#def test_parse_format_options():
#    assert parse_format_options('') == {}
#    assert parse_format_options('a=b') == {'a': 'b'}
#    assert parse_format_options('a=b,c="d"') == {'a': 'b

# Generated at 2022-06-23 18:40:37.745427
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    pass



# Generated at 2022-06-23 18:40:45.500261
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        description='testing argparse formatter',
        epilog='testing argparse formatter',
        formatter_class=HTTPieHelpFormatter)
    parser.add_argument('-a',
                        help="""
                        testing argparse formatter
                        testing argparse formatter""")
    parser.add_argument('-b',
                        help="""testing argparse formatter""")
    parser.print_help()



# Generated at 2022-06-23 18:40:52.849340
# Unit test for constructor of class HTTPieArgumentParser

# Generated at 2022-06-23 18:40:57.264751
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    http = HTTPieArgumentParser(prog='http', env=Environment())
    print(http.print_help())
    http_get = HTTPieArgumentParser(prog='http get', env=Environment())
    print(http_get.print_help())


# Generated at 2022-06-23 18:41:08.036424
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = parse_args(args=[],
                      env=Environment(colors=256,
                                      stdin_isatty=False,
                                      stdout_isatty=True))
    assert args.max_headers == 6000

    args = parse_args(args=['--max-headers', '0'],
                      env=Environment(colors=256,
                                      stdin_isatty=False,
                                      stdout_isatty=True))
    assert args.max_headers == None
 
    args = parse_args(args=['--max-headers', '9000'],
                      env=Environment(colors=256,
                                      stdin_isatty=False,
                                      stdout_isatty=True))
    assert args.max_headers == 9000
    

# Generated at 2022-06-23 18:41:11.947328
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Setup empty ArgumentParser
    parser = HTTPieArgumentParser()
    # Run method
    try:
        args = parser.parse_args(['--help'])
        raise Exception('Expected for ArgumentParserError to be raised')
    except SystemExit:
        pass



# Generated at 2022-06-23 18:41:13.439127
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert isinstance(parser, argparse.ArgumentParser)

# Generated at 2022-06-23 18:41:14.302504
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    pass


# Generated at 2022-06-23 18:41:25.468788
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # unit: HTTPieArgumentParser.parse_args() -> Namespace
    args = HTTPieArgumentParser().parse_args(['GET', 'http://example.com'])
    assert args.method == 'GET'
    assert args.url == 'http://example.com'
    
    args = HTTPieArgumentParser().parse_args(['http://example.com', 'X-Foo:bar'])
    assert args.method == 'GET'
    assert args.url == 'http://example.com'
    assert args.headers['X-Foo'] == 'bar'

    args = HTTPieArgumentParser().parse_args(['http://example.com', 'baz', '--form'])
    assert args.method == 'POST'
    assert args.url == 'http://example.com'

# Generated at 2022-06-23 18:41:35.228547
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """
    :type mock_parser: unittest.mock.Mock
    """
    import unittest.mock as mock
    mock_parser = mock.Mock(spec=HTTPieArgumentParser)
    mock_parser.parse_known_args.return_value = (mock.Mock(spec=argparse.Namespace), [])
    mock_parser.env = mock.Mock(spec=Environment)
    mock_parser.env.config = mock.MagicMock(spec=Config)
    mock_parser.env.config.config_dir = "./"
    mock_parser.env.is_windows.return_value = False
    mock_parser.env.is_macos.return_value = False
    mock_parser.env.is_linux.return_value = True

# Generated at 2022-06-23 18:41:38.289047
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    try:
        s = HTTPieHelpFormatter()
        assert s is not None
    except:
        assert False



# Generated at 2022-06-23 18:41:48.025598
# Unit test for constructor of class HTTPieArgumentParser

# Generated at 2022-06-23 18:41:56.848879
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-23 18:42:03.537616
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    text = '    A nicer help formatter.\n\n\n'
    text += '    Help for arguments can be indented and contain new lines.\n'
    text += '    It will be de-dented and arguments in the help\n'
    text += '    will be separated by a blank line for better readability.'
    arg_help = HTTPieHelpFormatter()._split_lines(text, 60)
    assert arg_help == text.splitlines()


# Generated at 2022-06-23 18:42:15.952111
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    temp_sys_argv = sys.argv.copy()
    sys.argv = ['http',  'https://httpbin.org/get']

# Generated at 2022-06-23 18:42:27.217388
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """Unit test for class HTTPieArgumentParser"""
    args = [
        '--traceback',
        '--ignore-stdin',
        '--headers',
        '--verbose',
        '--output-file',
        '/tmp/abc.txt',
        '--download',
        '--pretty',
        'none',
        '--format',
        'colors',
        '--printer',
        'legacy',
        '--output-options',
        'l',
        '--output-options-history',
        'H',
        'http://www.google.com/',
        '--method',
        'GET',
    ]
    http = HttpieArgumentParser()
    http.parse_args(args)



# Generated at 2022-06-23 18:42:39.449274
# Unit test for constructor of class HTTPieHelpFormatter

# Generated at 2022-06-23 18:42:48.011902
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    from argparse import ArgumentParser
    parser = ArgumentParser(
        prog='program',
        formatter_class=HTTPieHelpFormatter,
    )

# Generated at 2022-06-23 18:42:49.538334
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert isinstance(HTTPieHelpFormatter(), HTTPieHelpFormatter)



# Generated at 2022-06-23 18:42:57.498398
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    h = HTTPieHelpFormatter()
    h.start_section("test")
    h.add_argument("-t", "--test", help="test help")
    h.end_section()
    h.format()

    h = HTTPieHelpFormatter()
    h.start_section("test")
    h.add_argument("-t", "--test", help="test help")
    h.end_section()
    h.start_section("test")
    h.add_argument("-t", "--test", help="test help")
    h.end_section()
    h.format()



# Generated at 2022-06-23 18:43:10.465226
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """
    HTTPieArgumentParser parse_args should return args
    """
    expected_output = namedtuple('Args', 'url method headers params output_file')
    expected_output.url = 'http://httpie.org/'
    expected_output.method = 'POST'
    expected_output.headers = 'Content-Type: application/json'
    expected_output.params = 'a=1&b=2'
    expected_output.output_file = '~/download.txt'

    parser = HTTPieArgumentParser()
    output = parser.parse_args(['http://httpie.org/', 'POST', 'Content-Type: application/json', 'a=1&b=2', '--output=~/download.txt'])
    assert expected_output == output


# Generated at 2022-06-23 18:43:22.607444
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    debug = False
    testfiles_path = os.path.join(
        os.path.abspath(os.path.dirname(__file__)), 'testfiles')
    env = Environment(stdin=io.BytesIO(),
                      stdin_isatty=False,
                      stdout=io.BytesIO(),
                      stdout_isatty=False,
                      stderr=io.BytesIO())
    testdata = []
    for filename in sorted(os.listdir(testfiles_path)):
        if filename.startswith('parsed_args'):
            with open(os.path.join(testfiles_path, filename), 'rb') as f:
                testdata.append(pickle.load(f))

# Generated at 2022-06-23 18:43:33.619253
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    path_to_file = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '../../femebe/src/test/regress/data/input/pg_dump.output'
    )
    args = [path_to_file]
    options = {
        'curl_options': [],
        'default_options': [],
        'debug': False,
        'ignore_netrc': False,
        'traceback': False,
        'output': sys.stdout,
    }
    parser = HTTPieArgumentParser(args=args, env=options)
    args = parser.parse_args()

# Generated at 2022-06-23 18:43:38.502269
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser(
        usage=SUPPRESS,  # We're going to override it.
        prog='http',
        env=Environment()
    )
    assert parser.usage == 'http [OPTIONS] [URL] [ITEM [ITEM] ...]'
    assert parser.prog == 'http'
    assert parser.env == Environment()


# Generated at 2022-06-23 18:43:43.206062
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = HTTPieArgumentParser().parse_args([])
    assert args.json is False
    assert args.form is False
    assert args.headers is False
    assert args.style == 'colors'
    assert args.output_file is None
    assert args.output_options == 'H'

# Generated at 2022-06-23 18:43:54.732158
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    import argparse
    parser = argparse.ArgumentParser(description="""
        HTTPie - a CLI, cURL-like tool for humans.

        https://httpie.org

    """, prog='http', formatter_class=HTTPieHelpFormatter, add_help=False, epilog="""
        ------------------------------------------------------------
        The project is on Twitter: https://twitter.com/clihttp
        ------------------------------------------------------------
    """)
    parser.add_argument('--version', action='version',
                        version='httpie {0}'.format(__version__))
    parser.add_argument('--debug', action='store_true',
                        help="Print traceback on errors.")
    parser.add_argument('--traceback', action='store_true',
                        help=argparse.SUPPRESS)

# Generated at 2022-06-23 18:44:07.593638
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import argparse
    ap = argparse.ArgumentParser()
    HTTPieArgumentParser.format_parser(ap)
    args = ap.parse_args(['--format=foo:bar:baz;qux=quux'])
    assert not args.format_options
    args = ap.parse_args(['--format=foo:bar:baz;qux=quux', '--format-options='])
    assert not args.format_options
    #args = ap.parse_args(['--format=foo:bar:baz;qux=quux', '--format-options=abc'])
    assert args.format_options == {'foo': 'bar', 'baz': True}

# Generated at 2022-06-23 18:44:19.605285
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--debug', '--traceback', '--timeout', '5',
                              '--session', 'https://example.com', '--session-read-only', '--session-clear', '--auth', 'user:pass', '--auth-type', 'basic',
                              '--json', '--form', '--verbose', '--print=hB', '--headers', '--body', '--style=solarized', '--download', '--download-resume'])
    assert args.session == 'https://example.com'
    assert args.session_read_only and args.session_clear and args.debug and args.traceback
    assert args.timeout == 5
    assert args.auth == 'user:pass'
    assert args.auth_type

# Generated at 2022-06-23 18:44:28.269740
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    tester = HTTPieArgumentParser("This is description", env=TestEnvironment()())
    env_ref = tester.env
    assert tester.env == TestEnvironment()()
    with open("test_file.txt", "w+") as test_file:
        tester._body_from_file(test_file)
        assert tester.args.data is test_file
    tester._guess_method()
    tester.args.method = "GET"
    assert tester.args.method == "GET"
    tester.args.url = "localhost"
    tester._guess_method()
    tester.args.method = "GET"
    assert tester.args.method == "GET"
    tester.args.method = None
    tester.has_stdin_data = True
    tester

# Generated at 2022-06-23 18:44:40.013903
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # case 1
    arg1 = ['-j']
    parser1 = HTTPieArgumentParser()
    args1 = parser1.parse_args(arg1)
    assert args1.json == True
    assert args1.pretty == False
    assert args1.print_headers == False
    assert args1.verbose != True
    assert args1.download == False
    assert args1.download_resume == False
    assert args1.output_options != 'H'
    assert args1.output_options_history != 'H'
    assert args1.prettify == False

    # case 2
    arg2 = ['--pretty=all']
    parser2 = HTTPieArgumentParser()
    args2 = parser2.parse_args(arg2)
    assert args2.json == False
    assert args2.pretty == True


# Generated at 2022-06-23 18:44:42.093900
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        formatter_class=HTTPieHelpFormatter)
    parser.add_argument('--foo', help="""\
        Foo to some
        place
        """)
    parser.add_argument('bar', help="""\
        Bar to
        some other
        place
        """)
    parser.parse_args(['--help'])


# Generated at 2022-06-23 18:44:48.495238
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # This method is a dummy test, future tests should be added here
    argv = ['http', '--headers', 'http://httpbin.org/headers']
    args = HTTPieArgumentParser(prog='HTTPie').parse_args(argv[1:])

    assert args.headers
    assert args.url == 'http://httpbin.org/headers'
    assert args.method == 'GET'

# Generated at 2022-06-23 18:44:49.601758
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO
    pass
 

# Generated at 2022-06-23 18:45:01.871505
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # test case 1
    from urllib.parse import urlparse
    from httpie import __version__

    #test case 1
    #test empty command line
    parser = HTTPieArgumentParser()
    args = parser.parse_args(''.split())
    assert args.help == False
    assert args.version == False
    assert args.colors == None
    assert args.debug == False
    assert args.traceback == False
    assert args.download == False
    assert args.download_resume == False
    assert args.download_all_urls_match == None
    assert args.download_all_urls_match_re == False
    assert args.download_output_dir == None
    assert args.download_output_dir_layout != None
    assert args.download_output_prefix != None
    assert args.download_

# Generated at 2022-06-23 18:45:05.349416
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.parse_args(['GET', 'http://www.google.com'])
    parser.parse_args(['--auth-type=basic', 'http://www.google.com'])

# Generated at 2022-06-23 18:45:19.013950
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # HTTPieArgumentParser's constructor
    ap = HTTPieArgumentParser()
    # using asserts to check that the contructor correctly instantiated the class attributes
    # args = ap.args
    # env = ap.env
    #
    # # custom fill-in values for each attribute
    # args.arg1 = "customistate"
    # args.arg2 = 500
    # args.arg3 = True
    # env.attr1 = "customistate"
    # env.attr2 = 500
    # env.attr3 = False
    #
    # # use getattr to get the instance attributes of the class.
    # # comparing it to the custom values that was filled in to check if they are the same
    # # this is done to check if the constructor correctly instantiated the attributes
    # assert getattr(ap.args, '

# Generated at 2022-06-23 18:45:20.722897
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    rt = HTTPieArgumentParser()
    rt.parse_args([])

# Generated at 2022-06-23 18:45:28.256491
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args([])
    assert args.auth
    assert args.auth_type
    assert args.auth_plugin
    assert args.headers
    assert args.method
    assert args.data
    assert args.files
    assert args.params
    assert args.output_file
    assert args.output_file_specified
    assert args.headers_preserve_case

test_HTTPieArgumentParser_parse_args()

 

# Generated at 2022-06-23 18:45:39.896794
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = [
        '--auth',r'xxx',
        r'http://httpbin.org/post',
        r'-d',r'a=1',r'b=2'
    ]

    parser = HTTPieArgumentParser(env=Environment())

    NoTracebackOnArgumentTypeErrorParser.parse_args(parser, args)

    print(parser.args.auth)
    print(parser.args.auth_type)
    print(parser.args.auth_plugin)
    print(parser.args.method)
    print(parser.args.url)
    print(parser.args.headers)
    print(parser.args.data)


if __name__ == '__main__':
    test_HTTPieArgumentParser_parse_args()


# %%

# Generated at 2022-06-23 18:45:53.040938
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-23 18:45:54.073036
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    '''
    >>> htpf = HTTPieHelpFormatter()
    '''



# Generated at 2022-06-23 18:45:56.005807
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    assert formatter.max_help_position == 6


# Generated at 2022-06-23 18:46:08.803825
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """[summary]
    Raises:
        ValueError: [description]

    Returns:
        [type]: [description]
    """
    # Unit test to check method parse_args of class HTTPieArgumentParser
    # http --verbose https://httpbin.org/get
    args = HTTPieArgumentParser().parse_args(["--verbose", "https://httpbin.org/get"])
    assert args.url == "https://httpbin.org/get"
    assert args.verbose == True
    assert args.http_status_only == False
    assert args.method == None
    assert args.request_items == []
    assert args.ignore_stdin == False
    assert args.headers == []
    assert args.data == None
    assert args.json == None
    assert args.form == False
    assert args

# Generated at 2022-06-23 18:46:10.855092
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser(prog='http', usage='', env=Environment(), )
    assert parser.prog == 'http'

# Generated at 2022-06-23 18:46:20.145176
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Unit test for method parse_args of class HTTPieArgumentParser

    parser = HTTPieArgumentParser(add_verbose=False, add_debug=False)
    args = parser.parse_args([])
    assert args.ignore_stdin == False

    parser = HTTPieArgumentParser(add_verbose=False, add_debug=False)
    args = parser.parse_args(['post', 'http://httpie.org/',  'name=J.R.R.Tolkien'])
    assert args.url == 'http://httpie.org/'
    assert args.request_items[0].key == 'name'
    assert args.request_items[0].value == 'J.R.R.Tolkien'

    parser = HTTPieArgumentParser(add_verbose=False, add_debug=False)


# Generated at 2022-06-23 18:46:33.438884
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    class TestParser(argparse.ArgumentParser):
        def __init__(self):
            super().__init__(formatter_class=HTTPieHelpFormatter)

    class TestParserChild(TestParser):
        def __init__(self):
            super().__init__(allow_abbrev=False)

    parser = TestParser()
    parser.add_argument('--foo', help='''
        Foo does a lot of cool stuff. Like this and that.

        And even this.
    '''.strip())

# Generated at 2022-06-23 18:46:41.876988
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    desc = 'HTTPie %s, a cURL-like, JSON-aware utility for humans.' % __version__
    parser = HTTPieArgumentParser(
        formatter_class=argparse.RawTextHelpFormatter,
        add_help=False,
        prog='http',
        # Don't exit on error
        error_status=False,
        description=desc,
    )

    args = parser.parse_args(['https://foo.com'])
    assert args.url == 'https://foo.com'
    args = parser.parse_args()
    assert args.url is None


# Generated at 2022-06-23 18:46:46.185307
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    test = HTTPieArgumentParser()
    assert isinstance(test, argparse.ArgumentParser)
    assert isinstance(test, ArgparseExtensions)
    assert not test.env.stdin_isatty


# Generated at 2022-06-23 18:46:47.623332
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert parser is not None

# Generated at 2022-06-23 18:46:57.675079
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    parser.add_argument('url', nargs='?')
    rest = ['get', 'https://www.httpbin.org/get']
    parser.parse_args(rest)
    assert(parser.args.url == 'https://www.httpbin.org/get')
    rest = ['get', '-J', 'https://www.httpbin.org/get']
    parser.parse_args(rest)
    assert(parser.args.url == 'https://www.httpbin.org/get')
    #
    # old tests
    #
    # _url = 'http://www.example.com'
    # args = parser.parse_args([_url])
    # assert(args.url == _url)
    # parser.add_argument('-a', '--auth', dest

# Generated at 2022-06-23 18:47:08.338500
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    def test(string, expect):
        formatter = HTTPieHelpFormatter()
        help_text = formatter._split_lines(string, 80)
        assert expect == help_text[0]

    test("""\
        Usage: http [OPTIONS] METHOD URL [ITEM [ITEM ...]]

        HTTPie - a CLI, cURL-like tool for humans.

        Item syntax: KEY[=VAL] [KEY[=VAL] ...]
        """,
        'Usage: http [OPTIONS] METHOD URL [ITEM [ITEM ...]]'
    )


# Generated at 2022-06-23 18:47:20.063711
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    import argparse
    from httpie.status import ExitStatus

    from httpie.cli.argtypes import KeyValueArgType
    from httpie import ExitStatus

    class Args:
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)


# Generated at 2022-06-23 18:47:24.984980
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    help = dedent("""\
    test1 [string]
        help for test1

    test2 [string]
        help for test2
        -- contd.

    test3 [string]
        help for test3
        -- contd.
    """)
    formatter = HTTPieHelpFormatter()
    args = ["--help"]
    parser = argparse.ArgumentParser(
        prog='http',
        description='HTTPie: a CLI, cURL-like tool for humans.',
        formatter_class=HTTPieHelpFormatter,
        add_help=False,
    )
    parser.add_argument('--foo', help=help),
    _, remaining_args = parser.parse_known_args(args)

    assert remaining_args == args
