

# Generated at 2022-06-23 18:37:36.942648
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from HTTPie.argtypes import KeyValueArgType, KeyValue

    class DummyArgsNamespace(object):
        def __init__(self):
            self.headers = []
            self.data = None
            self.request_items = []
            self.method = None
            self.url = None
            self.prettify = None
            self.output_options = None
            self.output_options_history = None
            self.download = False
            self.download_resume = False
            self.format_options = None
            self.traceback = False
            self.output_file = None
            self.auth = None
            self.ignore_stdin = False
            self.ignore_stdin_redirects = False
            self.force_sequential = False
            self.download = False

# Generated at 2022-06-23 18:37:43.826447
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        prog='http',
        formatter_class=HTTPieHelpFormatter,
    )
    parser.add_argument('foo', help='  A simple argument.\n\n  Second line.')
    parser.add_argument('bar', help='\n  Another argument.\n\n\n  Third line.')
    help_text = parser.format_help()
    assert '  A simple argument.' in help_text
    assert 'Second line.' in help_text
    assert 'Another argument.' in help_text
    assert 'Third line.' in help_text



# Generated at 2022-06-23 18:37:48.518787
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        description='title',
        formatter_class=HTTPieHelpFormatter)
    parser.add_argument('bar', help="""\
                        Bar, or baz.

                        Choose wisely.""")
    parser.print_help()


# Generated at 2022-06-23 18:37:52.259592
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    class Test(object):
        def __init__(self, **kwargs):
            return kwargs
    test = Test(**HTTPieHelpFormatter())
    assert test['max_help_position'] == 6
    assert test['help_position'] == 27
    assert test['width'] == 90

# Generated at 2022-06-23 18:38:00.731231
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    print('--- test HTTPieArgumentParser ---')
    parser = HTTPieArgumentParser(prog='http',
                                  env=Environment(),
                                  add_config_dir_hook=lambda *args: None,
                                  add_help_hook=lambda *args: None,
                                  add_output_options_hook=lambda *args: None,
                                  add_resumable_download_arg=lambda *args: None)

    # Check out the attribute of class HTTPieArgumentParser
    print('parser.args.output_file_specified = ',
          parser.args.output_file_specified)
    print('parser.args.version = ',
          parser.args.version)
    print('parser.args.error_http = ',
          parser.args.error_http)

# Generated at 2022-06-23 18:38:03.736640
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """
    docstring for test_parse_args
    """
    pass

# Unit tests for class CLIConfig

# Generated at 2022-06-23 18:38:14.189169
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """
    >>> from httpie import arguments
    >>> HTTPieArgumentParser().parse_args(['http://example.com/'])
    Namespace(auth=None, auth_type=None, data='', download=False,
        download_resume=False, download_role=None, files=[], form=False,
        headers=[], ignore_netrc=False, ignore_stdin=False, json=False,
        method='GET', multipart_data=[], output_file=None, output_file_specified=False,
        output_options='H', output_options_history='H', params=[],
        pretty=None, prettify='all', print_bodies=False, print_headers=True,
        traceback=False, url='http://example.com/',
        verbose=False)
    """

# Unit test

# Generated at 2022-06-23 18:38:17.496903
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
  import os
  parser = HTTPieArgumentParser()
  if os.name == 'nt':
    assert parser.is_windows == True
  else:
    assert parser.is_windows == False

# Generated at 2022-06-23 18:38:18.894241
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    parser.add_argument

# Generated at 2022-06-23 18:38:26.255224
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['https://localhost:9000/v0.1/auth/user', '-u', 'admin@admin.com'])
    assert args.url == 'https://localhost:9000/v0.1/auth/user'
    assert args.auth.key == 'admin@admin.com'
    
    args = parser.parse_args(['https://localhost:9000/v0.1/auth/user', '-u', 'admin@admin.com:test'])
    assert args.url == 'https://localhost:9000/v0.1/auth/user'
    assert args.auth.key == 'admin@admin.com'
    assert args.auth.value == 'test'
    

# Generated at 2022-06-23 18:38:36.703476
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args([])
    # args.client_certs = None
    # args.data = []
    # args.files = []
    # args.headers = []
    # args.max_connections = 4
    # args.max_redirects = 10
    # args.method = 'GET'
    # args.output_file = None
    # args.output_format = 'colors'
    # args.output_options = 'hB'
    # args.output_options_history = 'HB'
    # args.prettify = 'all'
    # args.proxies = None
    # args.request_items = []
    # args.session_read = False
    # args.session_write = False
    # args.stream = False


# Generated at 2022-06-23 18:38:39.143687
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert HTTPieHelpFormatter().__init__(max_help_position=6)== None




# Generated at 2022-06-23 18:38:50.575688
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """
    Unit test for method parse_args of class HTTPieArgumentParser
    """
    assert HTTPieArgumentParser(env=Environment()).parse_args(['-h']) is None
    # test output to stdout
    assert HTTPieArgumentParser(env=Environment()).parse_args(['http://', '-v']).verbose
    assert HTTPieArgumentParser(env=Environment()).parse_args(['http://', '-h']).headers
    assert HTTPieArgumentParser(env=Environment()).parse_args(['http://', '-b']).body
    assert HTTPieArgumentParser(env=Environment()).parse_args(['http://', '-f']).follow
    assert HTTPieArgumentParser(env=Environment()).parse_args(['http://', '-a']).auth
    assert HTTP

# Generated at 2022-06-23 18:38:58.674910
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    assert formatter._split_lines('line1\nline2', 80) == ['line1', 'line2', '', '']
    assert formatter._split_lines('line1\n\nline2', 80) == ['line1', '', 'line2', '', '']
    assert formatter._split_lines('\nline1\nline2\n', 80) == ['', 'line1', 'line2', '', '']



# Generated at 2022-06-23 18:39:04.337125
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = [
        '-v',
        '--pretty=all',
        '--print=H',
        '--format=json',
        '/some-URL',
    ]

    actual_result = parser.parse_args(args)

    expected_result = Namespace(
        format='json',
        output_options='H',
        pretty='all',
        url='/some-URL',
        verbose=True)

    assert expected_result == actual_result



# Generated at 2022-06-23 18:39:07.060463
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    arSParser =HTTPieArgumentParser()
    assert arSParser.add_argument
    assert arSParser.add_formatter_option

# Generated at 2022-06-23 18:39:17.383407
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert isinstance(parser, ArgumentParser)
    assert parser.args == None
    assert isinstance(parser.env, Environment)
    assert isinstance(parser.stdout, io.IOBase)
    assert isinstance(parser.stdout_isatty, bool)
    assert isinstance(parser.stderr, io.IOBase)
    assert isinstance(parser.stderr_isatty, bool)
    assert isinstance(parser.devnull, io.IOBase)
    assert isinstance(parser.help, bool)
    assert isinstance(parser.stdin, io.IOBase)
    assert isinstance(parser.stdin_isatty, bool)
    assert isinstance(parser.stdin_encoding, str)
    assert parser.method == None
    assert parser.url

# Generated at 2022-06-23 18:39:24.425179
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(["httpbin.org/get"])
    assert args.url == "httpbin.org/get"

# If this is the main module, then we invoke the HTTPieArgumentParser.parse_args method
if __name__ == "__main__":
    parser = HTTPieArgumentParser()
    args = parser.parse_args()
    print("args:", args)


# Generated at 2022-06-23 18:39:26.437532
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    assert parser.parse_args([]) == parser.args

# Generated at 2022-06-23 18:39:28.068617
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    parser.add_argument('foo')



# Generated at 2022-06-23 18:39:29.236882
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    pass

# Generated at 2022-06-23 18:39:32.711577
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
  base_parser = argparse.ArgumentParser()
  sp = HTTPieArgumentParser()
  sp.add_argument('--foo')
  args = sp.parse_args(['--foo', 'bar'], namespace=base_parser.parse_args([]))
  assert args.foo == 'bar'

# Generated at 2022-06-23 18:39:45.238755
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    ap = HTTPieArgumentParser()
    parser = ap.parse_args(args=['https://httpbin.org/get'])
    assert parser.url == 'https://httpbin.org/get'
    assert parser.method == 'GET'
    assert parser.verbose == False
    assert parser.headers == None
    assert parser.data == None
    assert parser.json == None
    assert parser.files == None
    assert parser.params == None
    assert parser.auth == None
    assert parser.auth_type == None
    assert parser.insecure == False
    assert parser.timeout == None
    assert parser.max_redirects == None
    assert parser.check_status == True
    assert parser.headers == None
    assert parser.headers_file == None
    assert parser.output_file == None
    assert parser.download

# Generated at 2022-06-23 18:39:48.947418
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert(HTTPieHelpFormatter()._split_lines("""
        some text
        follows
        """, 80) == ['some text', 'follows', ''])


# Generated at 2022-06-23 18:39:51.225339
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()


# Generated at 2022-06-23 18:39:56.609602
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    print('-- test_HTTPieHelpFormatter --')

    formatter = HTTPieHelpFormatter()
    assert(formatter.max_help_position == 6)
    assert(formatter._split_lines('Response Content-Type\npretty: <type>', 80) == ['Response Content-Type\npretty: <type>', ''])



# Generated at 2022-06-23 18:40:05.291380
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    from httpie.utils import get_response_parser
    parser = HTTPieArgumentParser(description='description', version='version', env=Env())
    assert parser.description == 'description'
    assert parser.version == 'version'
    assert parser._environment == Env()
    assert parser.prog == 'http'
    assert parser.add_argument.__name__ == 'add_argument'
    assert parser.error.__name__ == 'error'
    assert parser.parse_known_args.__name__ == 'parse_known_args'
    assert parser.parse_args.__name__ == 'parse_args'
    assert parser.format_help.__name__ == 'format_help'
    assert parser.format_usage.__name__ == 'format_usage'

# Generated at 2022-06-23 18:40:08.425673
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    help_formatter = HTTPieHelpFormatter()
    assert help_formatter
    assert isinstance(help_formatter, RawDescriptionHelpFormatter)



# Generated at 2022-06-23 18:40:18.662512
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    from .constants import DEFAULT_CONFIG_DIR, DEFAULT_CONFIG_PATH, DEFAULT_CONFIG_FILE
    from os import devnull, path
    from .__init__ import get_version
    from .context import Environment
    from .config import Config
    from .plugins import plugin_manager

    env = Environment()
    config = Config(config_dir=DEFAULT_CONFIG_DIR, config_file=DEFAULT_CONFIG_FILE)
    sys.argv = ['http','httpbin.org','--print','all','--output-file','../test_results/test','--print','h']
    # Provided all the dependencies we can creat an instance of
    # HTTPieArgumentParser
    parser = HTTPieArgumentParser(add_help=True, env=env, config=config, verify=True, cert=None)


# Generated at 2022-06-23 18:40:24.542968
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    # Test for constructor of class HTTPieHelpFormatter
    assert HTTPieHelpFormatter().__init__

    # Test for _split_lines() method of class HTTPieHelpFormatter
    text = "This is a test"
    width = 1
    tester = HTTPieHelpFormatter()
    assert tester._split_lines(text, width).__eq__(['This is a test','\\n'])



# Generated at 2022-06-23 18:40:27.977966
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert parser.prog == 'http'
    assert parser.description
    assert parser.epilog
    assert parser.formatter_class == argparse.RawDescriptionHelpFormatter
    assert parser.fromfile_prefix_chars == '@'



# Generated at 2022-06-23 18:40:32.533007
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    global open, os, sys
    sys.argv = ['/usr/local/bin/http', '--debug']
    cls = HTTPieArgumentParser
    try:
        open.return_value.read.return_value = ''
        cls()
    except Exception as exc:
        os.getcwdu.side_effect = None
        os.path.exists.side_effect = None
        sys.stdin.encoding = 'ascii'
        raise exc


# Generated at 2022-06-23 18:40:44.065583
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """Test of the constructor of class HTTPieArgumentParser
    """
    class DummyEnv:
        config = DummyConfig()
        stdout = sys.stdout
        stderr = sys.stderr
        stdin = sys.stdin
        stdin_isatty = sys.stdin.isatty()
        stdout_isatty = sys.stdout.isatty()
        stderr_isatty = sys.stderr.isatty()
        is_windows = False
        colors = 256
        stdout_encoding = sys.stdout.encoding
        devnull = open(os.devnull, 'w')
        config_dir = os.path.expanduser('~')

    class Args:
        dump_config = False
        verbose = True

# Generated at 2022-06-23 18:40:52.291742
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    httpie_args = ["http", "https://api.github.com/repos/jakubroztocil/httpie", "-v", "--auth-type=basic", "--ignore-netrc", "--body", "Hello World", "--headers", "Content-Type: application/json", "X-Auth-Token: 5f4dcc3b5aa765d61d8327deb882cf99"]
    parser = HTTPieArgumentParser()
    result = parser.parse_args(httpie_args)
    assert result.url == "https://api.github.com/repos/jakubroztocil/httpie"
    assert result.method == "GET"
    assert result.auth_type == 'basic'
    assert result.ignore_netrc == True
    assert result.data == "Hello World"
   

# Generated at 2022-06-23 18:40:55.688327
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    with patch('sys.argv', ['http', 'test.com']):
        parser = HTTPieArgumentParser()
        assert parser.args.url == "test.com"


# Generated at 2022-06-23 18:41:00.241550
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    # FIXME: The default value of args.quiet is True, where it
    # should be False.
    assert parser.args.quiet == True

    # FIXME: The default value of args.traceback is False, where it
    # should be True.
    assert parser.args.traceback == False

# Generated at 2022-06-23 18:41:05.120165
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    pa = HTTPieArgumentParser()
    x = pa.parse_args(args=['--method', 'GET', 'httpbin.org', 'X-Foo:Bar'])
    assert x.method == 'GET'
    assert x.url == 'httpbin.org'
    assert x.headers[0]['X-Foo'] == 'Bar'
 

# Generated at 2022-06-23 18:41:14.600754
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    Empty = Empty = argparse.ArgumentParser(
        formatter_class=HTTPieHelpFormatter
    )
    Empty.add_argument(
        '-v', '--verbose',
        help='''
        Be verbose.

        This is useful for debugging
        and seeing all the information
        sent and received.
        ''')
    expected = dedent('''
        usage: Empty [-h] [-v]
        optional arguments:
          -h, --help   show this help message and exit
          -v, --verbose
                      Be verbose.
                      This is useful for debugging
                      and seeing all the information
                      sent and received.
    ''').strip()
    assert str(Empty.format_help()).strip().splitlines() == expected.splitlines()


# Generated at 2022-06-23 18:41:21.059305
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    stdin_isatty = True
    print(stdin_isatty)
    stdout_isatty = True
    print(stdout_isatty)
    stderr_isatty = True
    print(stderr_isatty)
    env = Environment(stdin_isatty, stdout_isatty, stderr_isatty)

    arguments = ["http", "--json", "--form", "http://httpbin.org/post", "a=1", "b=2", "c=3", "--print=b,c,d"]
    parser = HTTPieArgumentParser(env=env)
    print(parser.parse_args(args=arguments))

# Generated at 2022-06-23 18:41:33.263958
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    """Unit test for constructor of class HTTPieHelpFormatter
    """
    def extract_args(argument_list):
        return [argument.option_strings for argument in argument_list]

    parser = argparse.ArgumentParser()
    parser.add_argument('--abc', help='abc\nxyz')
    parser.add_argument('--def', help='def')
    parser.add_argument('--ghi', help='ghi')
    argument_list = parser._get_positional_actions() + parser._get_optional_actions()

# Generated at 2022-06-23 18:41:38.122893
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        prog='http',
        formatter_class=HTTPieHelpFormatter,
        description="""httpie

        Go ahead, install it. It's not like we're _that_ cute.

        """)
    parser.parse_args()



# Generated at 2022-06-23 18:41:40.182922
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    """Test the constructor of class HTTPieHelpFormatter
    """
    parser = argparse.ArgumentParser(
        description='test',
        formatter_class=HTTPieHelpFormatter)
    parser.add_argument('--foo', help='''\
        foo to one
        line''')
    parser.add_argument('bar', help='''bar to other
    line''')
    parser.parse_known_args(['--help'])


# Generated at 2022-06-23 18:41:43.660595
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    help = '''\
    This is a help string and will be indented.
    It can also span multiple lines.
    '''

    assert '\n' not in HTTPieHelpFormatter()._split_fields(help)[0]



# Generated at 2022-06-23 18:41:44.689945
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    HTTPieArgumentParser()

# Generated at 2022-06-23 18:41:52.211300
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # Set up a parser for testing
    parser = HTTPieArgumentParser()
    # Assert the value of parser object
    assert parser.prog == 'http'
    assert parser.description == 'a curl-like, modern command line HTTP client'
    assert parser.argument_default == argparse.SUPPRESS
    assert parser.add_help == True
    assert parser.formatter_class == argparse.RawDescriptionHelpFormatter



# Generated at 2022-06-23 18:41:52.693282
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert True


# Generated at 2022-06-23 18:41:57.507971
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    class TestCommand:
        args = ()

    parser = argparse.ArgumentParser(
        description='test',
        formatter_class=HTTPieHelpFormatter)
    for args, kwargs in TestCommand.args:
        parser.add_argument(*args, **kwargs)
    parser.print_help()



# Generated at 2022-06-23 18:41:59.513131
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser(env=Environment())
    assert parser.env is not None



# Generated at 2022-06-23 18:42:08.214491
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():

    # Create a HTTPieArgumentParser object
    h = HTTPieArgumentParser()

    # Test HTTPieArgumentParser.discover_config_files
    # Test with no config options passed in
    assert h.discover_config_files() == \
        [os.path.expanduser(user_config_path),
         os.path.expanduser(system_config_path),
         os.path.expanduser('~/.config/httpie/config'),
         '/etc/httpie/config']

    # Test with config options passed in

# Generated at 2022-06-23 18:42:13.194175
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = [
        'https:google.com',
        'hello',
        'test',
    ]
    parser = HTTPieArgumentParser()
    parsed_args = parser.parse_args(args)
    assert parsed_args.url == 'https:google.com'



# Generated at 2022-06-23 18:42:23.582694
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    from tempfile import mkstemp
    from pathlib import Path
    tmp_file = mkstemp()
    parser_ = HTTPieArgumentParser()
    args = parser_.parse_args([])
    assert args.url is None
    assert args.headers is None
    assert args.params is None
    assert args.data is None
    assert args.files is None
    assert args.method is None
    assert args.auth is None
    assert args.auth_plugin is None
    assert args.body is None
    assert args.compress is False
    assert args.json is None
    assert args.output_file is None
    assert args.output_file_specified is False
    assert args.output_options is None
    assert args.output_options_history is None
    assert args.verbose is False
    assert args.download is False

# Generated at 2022-06-23 18:42:33.213339
# Unit test for constructor of class HTTPieHelpFormatter

# Generated at 2022-06-23 18:42:34.359922
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # TODO
    pass


# Generated at 2022-06-23 18:42:36.330656
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    f = HTTPieHelpFormatter()
    assert f


# Generated at 2022-06-23 18:42:39.041083
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    print("parser = ", parser)



# Generated at 2022-06-23 18:42:47.802071
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    print('httpie.cli.argparser.HTTPieArgumentParser.parse_args')
    args = []
    fp = io.StringIO()
    env = Environment()
    parser = HTTPieArgumentParser(args=args, stdin=fp, env=env)
    options = parser.parse_args()
    assert options.auth is None
    assert options.auth_type is None
    assert options.download is False
    assert options.output_file is None
    assert options.output_file_specified is False
    assert options.prettify is None
    assert options.pretty is None
    assert options.style is None
    assert options.verbose is False
    assert options.traceback is False
    assert options.output_options is None
    assert options.output_options_history is None
    assert options.verify is True


# Generated at 2022-06-23 18:42:50.360216
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO
    pass

# Class wrapper for `parse_validate_focus_options`
# Also used in `main.py`

# Generated at 2022-06-23 18:42:59.741277
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    from httpie.core import main
    argv_list = ['http', 'https://httpbin.org/get']
    if __name__ == '__main__':
        main(argv_list)
    #
    #
    #
    def _test_httpie_argument_parser(argv_list, **kwargs):
        '''
        @see: the method `main` in `httpie.core`
        @return: an instance of class `HTTPieArgumentParser`
        '''
        parser = HTTPieArgumentParser(
            env=Environment(),
            description=kwargs.get('description', USAGE.split('\n\n')[0]),
            epilog=kwargs.get('epilog', __doc__.split('\n\n')[1])
        )
        parser.add_

# Generated at 2022-06-23 18:43:11.504114
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    Response = type('Response', (object,), {})
    resp = Response()
    resp.status_code = 200
    resp._content_consumed = True
    resp.encoding = 'utf-8'
    resp.request = 'get http://httpbin.org'

# Generated at 2022-06-23 18:43:19.014513
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    args = {'max_help_position': 6, 'indent_increment': 2, 'width': 80, 'short_first': 1}
    assert HTTPieHelpFormatter(*args)
    args = {'max_help_position': 6, 'indent_increment': 2, 'width': 80, 'short_first': "f"}
    assert not HTTPieHelpFormatter(*args)

# Argument parser
# ===============


# Generated at 2022-06-23 18:43:22.997313
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # pylint: disable=unused-variable
    url = 'https://httpbin.org'
    args = HTTPieArgumentParser().parse_args(['https://httpbin.org'])
    assert args.url == url
    # pylint: enable=unused-variable

# Generated at 2022-06-23 18:43:28.355059
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Arrange
    parser = HTTPieArgumentParser()
    args = ['--version']

    # Act
    with patch.object(parser, "exit") as mock_exit:
        parser.parse_args(args)

    # Assert
    mock_exit.assert_called_once_with(0)



# Generated at 2022-06-23 18:43:37.894148
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    help_text = """
        This is the start of the help text.

        This is the more description.

        The end.
    """
    class Args:
        pretty = None
        download = None
        output = None
    args = Args()
    with HDTMock(sys.stdout) as mock:
        HTTPieHelpFormatter(
            prog='http', max_help_position=6,
        ).add_usage(
            HTTPieHelpFormatter.format_usage(args).splitlines()[0],
            [('AUTH', 'Credentials in the form USER:PASS.'),
             ('PRETTY', help_text.strip())]
        )

# Generated at 2022-06-23 18:43:44.055956
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()

    # This class is just an extension of argparse.ArgumentParser so the following tests
    # would also be applicable

    # Test the constructor succeeds
    assert parser is not None

    # Test the parser is an instance of ArgumentParser
    assert isinstance(parser, argparse.ArgumentParser)

    # Test the parser is an instance of HTTPieArgumentParser
    assert isinstance(parser, HTTPieArgumentParser)



# Generated at 2022-06-23 18:43:46.685701
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert isinstance(parser, HTTPieArgumentParser)


# Generated at 2022-06-23 18:43:56.337818
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():

    class TestParser(argparse.ArgumentParser):
        def format_help(self):
            formatter = self._get_formatter()
            formatter.add_usage(self.usage, self._actions,
                                self._mutually_exclusive_groups)
            formatter.add_text(self.description)
            for action_group in self._action_groups:
                formatter.start_section(action_group.title)
                formatter.add_text(action_group.description)
                formatter.add_arguments(action_group._group_actions)
                formatter.end_section()
            formatter.add_text('\n')
            return formatter.format_help()

    p = argparse.ArgumentParser(formatter_class=HTTPieHelpFormatter)

# Generated at 2022-06-23 18:44:00.615030
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    parser.add_argument('--test-argument', action='store_true')
    args = parser.parse_args(['--test-argument'])
    assert args.test_argument == True

# Generated at 2022-06-23 18:44:08.892740
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    arg_help = dedent("""\
        HTTP method to use for the request, e.g. GET.
        (default: GET)
        """)
    parser = argparse.ArgumentParser(formatter_class=HTTPieHelpFormatter)
    parser.add_argument('-m', dest='method', default=HTTP_GET,
                        help=arg_help)
    help_string = parser.format_help()
    assert help_string[:help_string.index('\n')].endswith('GET\n')



# Generated at 2022-06-23 18:44:20.319608
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    my_parser = HTTPieArgumentParser()
    my_parser.add_argument("-a", "--aaa", required=False, default=1, type=int)
    my_parser.add_argument("-b", "--bbb", required=False, type=int)
    my_parser.add_argument("-c", "--ccc", required=False, type=int)

    args_str = '--aaa=2 -b=3 -c=4'  # aaa=1, bbb=3, ccc=4
    parsed = my_parser.parse_args(args_str.split())
    assert parsed.aaa == 2
    assert parsed.bbb == 3
    assert parsed.ccc == 4

# Generated at 2022-06-23 18:44:22.281081
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    obj = HTTPieArgumentParser(env=None)
    assert obj.env is None



# Generated at 2022-06-23 18:44:24.497601
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Create an instance of HTTPieArgumentParser class
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http', 'https://httpbin.org/get'])
    #assert args.json == False

# Generated at 2022-06-23 18:44:34.167470
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    t = HTTPieHelpFormatter(max_help_position=5)
    assert t._split_lines('\n    test1\n    test2\n',5) == ['test1','test2','']
    assert t._split_lines('\n  test1\n    test2\n',5) == ['test1','    test2','']
    assert t._split_lines('test1\n  test2',5) == ['test1','  test2','']

#test_HTTPieHelpFormatter()


# Generated at 2022-06-23 18:44:38.022894
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    from httpie.input import KeyValueArgType
    test_parser = HTTPieArgumentParser()

    # test_parser._parse_args
    print("test_parser._parse_args()")
    print(test_parser._parse_args())

# Generated at 2022-06-23 18:44:44.999786
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = HTTPieArgumentParser().parse_args()
    assert args.help == False 
    assert args.json == False 
    assert args.form == False 
    assert args.auth == None 
    assert args.auth_type == 'basic' 
    assert args.auth_plugin == None
    assert args.download == False 
    assert args.download_output_file == None 
    assert args.download_resume == False 
    assert args.download_session == None 
    assert args.ignore_netrc == False 
    assert args.ignore_stdin == False 
    assert args.output_file == None 
    assert args.output_file_specified == None 
    assert args.pretty == 'all' 
    assert args.prettify == 'all' 
    assert args.style == None 


# Generated at 2022-06-23 18:44:52.154157
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        formatter_class=HTTPieHelpFormatter,
        description=dedent("""
            description should be dedented.

            as well as the epilog.
            """
        ),
        epilog=dedent("""
            description should be dedented.

            as well as the epilog.
            """
        )
    )
    parser.add_argument('--foo')
    parser.add_argument('bar')
    help = parser.format_help()
    print(help)




# Generated at 2022-06-23 18:44:56.281621
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert parser
    http_string = 'http'
    args = parser.parse_args(http_string)
    assert args.args[0] == http_string

# Generated at 2022-06-23 18:45:06.129987
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    # Set up an instance of subclass HTTPieArgumentParser
    from httpie.cli.argtypes import KeyValueArgType
    from httpie import httpie

    parser = httpie.get_argument_parser()

    # Suppress argparse error output
    httpie.env.stderr = io.StringIO()

    # Check usual case
    url = 'https://httpie.org'
    args = parser.parse_args([url])
    assert isinstance(args, Namespace)

    args.headers = KeyValueArgType()(None)
    assert isinstance(args.headers, Headers)
    assert args.headers == Headers()
    args.headers = KeyValueArgType()([])
    assert isinstance(args.headers, Headers)
    assert args.headers == Headers()
    args.headers = KeyValueArgType()

# Generated at 2022-06-23 18:45:19.899983
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    print(os.getcwd())
    print(__file__)
    print(os.path.abspath(__file__))
    print(os.path.dirname(os.path.abspath(__file__)))
    print(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    print(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    exe_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    print(exe_dir+"\\bin\\http")
    print(exe_dir+"\\bin\\http")

# Generated at 2022-06-23 18:45:22.654721
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.parse_args([])

test_HTTPieArgumentParser_parse_args()
 

# Generated at 2022-06-23 18:45:26.511243
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    class FakeArgumentParser:
        pass
    ap = FakeArgumentParser()
    ap.add_argument_group = FakeArgumentParser()
    formatter = HTTPieHelpFormatter()
    formatter._split_lines(
        """\
test:
    a
    b
""",
        width=80
    ) == ["test:","    a","    b"]



# Generated at 2022-06-23 18:45:28.901635
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    args = HTTPieArgumentParser().parse_args(args=[])
    # The default value of args.method should be 'GET'
    assert args.method == 'GET'



# Generated at 2022-06-23 18:45:41.734462
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    if __name__ == '__main__':
        # Initialize the environment
        httpie = HTTPie()
        # Initialize the output, stdout and stderr
        httpie.env.stdout = io.BytesIO()
        httpie.env.stderr = io.BytesIO()
        httpie.env.stdout_isatty = False
        httpie.env.stderr_isatty = False
        httpie.args.ignore_stdin = False
        httpie.args.check_status = True
        httpie.args.download = False
        httpie.args.download_resume = False
        httpie.args.output_options = None
        httpie.args.output_options_history = None
        httpie.args.auth = None
        httpie.args.auth_type = None


# Generated at 2022-06-23 18:45:46.212672
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    input_args = ['-b', 'a=1', 'b=2', 'GET', 'http://www.baidu.com']
    httpie = HTTPieCoreArgumentParser()
    args = httpie.parse_args(input_args)
    print(args)

if __name__ == '__main__':
    test_HTTPieArgumentParser()

# Generated at 2022-06-23 18:45:58.792864
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', help='foo')
    parser.add_argument('--bar', help='bar')
    help_string = parser.format_help()
    help_string_expected = 'usage: [-h] [--foo FOO] [--bar BAR]\n\noptional arguments:\n  -h, --help  show this help message and exit\n  --foo FOO\n  --bar BAR\n'

    assert help_string == help_string_expected
    httpie_help_formatter = HTTPieHelpFormatter()
    help_string = httpie_help_formatter.format_help(parser)

# Generated at 2022-06-23 18:46:06.980636
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    test1 = HTTPieArgumentParser(None)
    # test1.print_message(test1.usage)
    assert True

# Test for method _print_message() of class HTTPieArgumentParser
# def test_print_message():
#     test1 = HTTPieArgumentParser(None)
#     test1._print_message("test")
#     assert True

# Test for method _setup_standard_streams() of class HTTPieArgumentParser

# Generated at 2022-06-23 18:46:16.626099
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    arg_parser = HTTPieArgumentParser()
    arg_parser.add_argument('--debug', action='store_true')
    arg_parser.add_argument('--log-level', type=str, default='NOTSET',
                           choices=['NOTSET', 'DEBUG', 'INFO', 'WARNING',
                                    'ERROR', 'CRITICAL'])
    arg_parser.add_argument('--output', type=str, default=None)
    arg_parser.add_argument('--print', type=str)
    arg_parser.add_argument('--print-options', action='append')

    args = arg_parser.parse_args([])
    assert args.debug == False
    assert args.log_level == 'NOTSET'
    assert args.output == None
    assert args.print == None
    assert args.print_options

# Generated at 2022-06-23 18:46:23.708815
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert isinstance(parser, HTTPieArgumentParser)
    assert isinstance(parser.env, Environment)
    assert isinstance(parser.arg_config_group, ArgumentParser)
    assert isinstance(parser.arg_options_group, ArgumentParser)
    assert isinstance(parser.arg_request_group, ArgumentParser)
    assert isinstance(parser.arg_output_group, ArgumentParser)
    assert isinstance(parser.arg_misc_group, ArgumentParser)
    assert isinstance(parser.arg_auth_group, ArgumentParser)
    assert isinstance(parser.arg_plugins_group, ArgumentParser)
    assert isinstance(parser.arg_ver_group, ArgumentParser)
    assert isinstance(parser.args, Namespace)
    assert isinstance(parser.env, Environment)


################################

# Generated at 2022-06-23 18:46:24.922076
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    HTTPieArgumentParser()


# Generated at 2022-06-23 18:46:27.890833
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    httpie_argument_parser = HTTPieArgumentParser()
    if httpie_argument_parser == HTTPieArgumentParser():
        assert False

# Generated at 2022-06-23 18:46:33.390379
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    a = HTTPieArgumentParser()
    b = a.parse_args(['a', '1', 'b', '2', 'c', '3'])
    assert b.a == '1'
    assert b.b == '2'
    assert b.c == '3'



# Generated at 2022-06-23 18:46:40.739913
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    # test for parser.prog
    assert parser.prog == 'http'
    # test for parser.description
    assert parser.description == '<description>'
    # test for parser.epilog
    assert parser.epilog == '<epilog>'
    # test for parser.argument_groups
    assert parser.argument_groups == {
        'request': '<request>',
        'http': '<http>'
    }


# Generated at 2022-06-23 18:46:53.510869
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    arguments = MockArguments()
    arguments._actions = [
        MockAction(
            option_strings = [],
            dest = 'method',
        ),
        MockAction(
            option_strings = ['--headers'],
            dest = 'headers',
        ),
        MockAction(
            option_strings = ['--data'],
            dest = 'data',
        ),
        MockAction(
            option_strings = ['--files'],
            dest = 'files',
        ),
    ]
    arguments.has_stdin_data = False

    parser = HTTPieArgumentParser(
        add_headers = False,
        allow_unknown_options = False,
        env = MockEnvironment(),
        arguments = arguments,
    )


# Generated at 2022-06-23 18:46:58.427203
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    args = HTTPieArgumentParser().parse_args()
    out = 'args.data = {}\nargs.files = {}\nargs.form = False\nargs.headers = {}\nargs.method = GET\nargs.params = {}\nargs.url = None'
    assert out == str(vars(args))  # vars() convert object as dict

# Generated at 2022-06-23 18:47:08.816110
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    for line in open('arguments_command.txt', 'r', encoding='utf-8'):
        line = line.strip()
        if line.startswith('#') or len(line) == 0:
            continue
        args = shlex.split(line)
        #print(args)
        parser = HTTPieArgumentParser()
        if '--traceback' in args:
            parser.args = parser.parse_args(args)
            html_file = open('./traceback.html', 'w', encoding='utf-8')
            cgitb.Hook(file=html_file).handle()
            html_file.close()
            webbrowser.open('./traceback.html')
        else:
            parser.args = parser.parse_args(args)

# Generated at 2022-06-23 18:47:20.435110
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser('http')
    assert parser.prog == 'http'
    assert len(parser.subparsers._group_actions) == 1
    assert parser.subparsers._group_actions[0].title == 'subcommands'
    assert len(parser.subparsers._group_actions[0].choices) == 2
    assert 'url' in parser.subparsers._group_actions[0].choices
    assert 'install-completion' in parser.subparsers._group_actions[0].choices
    assert '-h' in parser.subparsers._group_actions[0].choices.get('url').option_strings
    assert '--help' in parser.subparsers._group_actions[0].choices.get('url').option_strings
    assert parser

# Generated at 2022-06-23 18:47:30.223930
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    HTT_parser = HTTPieArgumentParser()

    # Case when only one argument is passed
    args = HTT_parser.parse_args(['http'])
    assert args.help == False

    # Case when only two arguments are passed
    args = HTT_parser.parse_args(['http', 'https://google.com'])
    assert args.help == False
    assert args.url == 'https://google.com'
    assert args.json == False

    # Case when only three arguments are passed
    args = HTT_parser.parse_args(['http', 'https://google.com', '--json'])
    assert args.help == False
    assert args.url == 'https://google.com'
    assert args.json == True
    assert args.data == None
    
    # Case when four arguments are passed
