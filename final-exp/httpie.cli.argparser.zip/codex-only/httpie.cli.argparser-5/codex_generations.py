

# Generated at 2022-06-23 18:37:36.378917
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    help_text = """
    this is line one
    this is line two


    """
    parsed_help = [
        'this is line one',
        'this is line two',
        '',
        ''
    ]
    for i in range(0, len(parsed_help)):
        if HTTPieHelpFormatter._split_lines(help_text, 1)[i] != parsed_help[i]:
            print("HelpFormatter test failed @", i)
            return False
    return True

# argparse's default is to print the full help message when an error occurs,
# which is not what we want when the error is e.g. unknown argument or a
# parsing error. In those cases, we want just the message.

# Generated at 2022-06-23 18:37:40.368880
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = HTTPieArgumentParser().parse_args()
    print (args)

if __name__ == '__main__':
    try:
        test_HTTPieArgumentParser_parse_args()
    except Exception as e:
        print (e)
        traceback.print_exc()

# Generated at 2022-06-23 18:37:43.744456
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser(prog='http', env=Environment())
    parser.print_version = lambda: None
    parser.exit = lambda: None
    parser.error = lambda msg: None
    parser.parse_args(['http://github.com', '--json'])

# Generated at 2022-06-23 18:37:54.873141
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert 'test one\n\ntest two\n\n' == HTTPieHelpFormatter()._split_lines("""test one
    test two
    """, 80)
    assert 'test one\n\ntest two\n\n' == HTTPieHelpFormatter()._split_lines("""test one
                    test two
    """, 80)
    assert 'test one\n\ntest two\n\n' == HTTPieHelpFormatter()._split_lines("""test one
        test two
    """, 80)


# Generated at 2022-06-23 18:38:06.388083
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-23 18:38:15.318938
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-23 18:38:20.052136
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    prs = HTTPieArgumentParser()
    args = prs.parse_args(cls=HTTPieArgumentParser)
    assert args.headers == [], repr(args.headers)
    assert args.download == False, repr(args.download)
    assert args.output_file == None, repr(args.output_file)

# Generated at 2022-06-23 18:38:31.816371
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    test_args = HTTPieArgumentParser().parse_args()
    assert test_args.auth is None
    assert test_args.auth_type is None
    assert test_args.body is None
    assert test_args.body_from_file is None
    assert test_args.check_status is False
    assert test_args.compress is False
    assert test_args.data is None
    assert test_args.download is False
    assert test_args.download_resume is False
    assert test_args.explain_options is False
    assert test_args.follow is False
    assert test_args.form is False
    assert test_args.headers == []
    assert test_args.history_items is None
    assert test_args.ignore_netrc is False
    assert test_args.ignore_stdin is False


# Generated at 2022-06-23 18:38:36.958707
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    
    parser = HTTPieArgumentParser(prog='http', env=Environment())
    args = parser.parse_args(args=['https://www.google.com/'])
    headers = HeaderDict([(':method', 'GET')])
    assert args.headers == headers

    parser = HTTPieArgumentParser(prog='http', env=Environment())
    args = parser.parse_args(args=['https://www.google.com/', ':method', 'GET'])
    headers = HeaderDict([(':method', 'GET')])
    assert args.headers == headers
    args = parser.parse_args(args=['https://www.google.com/', ':method:', 'GET'])
    headers = HeaderDict([(':method', 'GET')])
    assert args.headers == headers

# Generated at 2022-06-23 18:38:38.644783
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    http = HTTPieArgumentParser()

# Generated at 2022-06-23 18:38:41.644525
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():    
    parser = HTTPieArgumentParser()
    # Check argparse.ArgumentParser.parse_args
    args = parser.parse_args(['--version'])

# Generated at 2022-06-23 18:38:45.818744
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    class A:
        def __init__(self,*args, **kwargs):
            pass
    x = HTTPieHelpFormatter(max_help_position = 5, *args, **kwargs)
    assert x is None


# Generated at 2022-06-23 18:38:54.860374
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    from httpie.cli.argtypes import KeyValueArgType


# Generated at 2022-06-23 18:38:55.762662
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.parse_args([])

# Generated at 2022-06-23 18:39:03.520002
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    text = '''
        Example of help

        This help can contain new lines and leading whitespace
        will be stripped.
        '''

    # width parameter is not used by the method
    # pylint: disable=W0613
    def method(text, width):
        lines = []
        text = dedent(text).strip() + '\n\n'
        lines = text.splitlines()
        return lines

    help_formatter = HTTPieHelpFormatter()
    lines = help_formatter._split_lines(text, 10)
    assert lines == method(text, 10)



# Generated at 2022-06-23 18:39:06.948941
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert isinstance(parser, HTTPieArgumentParser),\
        'Type of parser is not HTTPieArgumentParser'


# Generated at 2022-06-23 18:39:17.323623
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--method', 'GET', '--headers', 'key:value', '--data', 'key=value', 'https://httpbin.org/get'])
    assert args.method == 'GET', 'method'
    assert args.headers == [KeyValueArg(key='key', sep=':', value='value')], 'header args'
    assert args.request_items == [KeyValueArg(key='key', sep='=', value='value')], 'data args'
    assert args.url == 'https://httpbin.org/get', 'url'
    assert args.auth is None, 'auth'
    assert args.auth_type is None, 'auth_type'
    assert args.ignore_netrc is False, 'ignore_netrc'

# Generated at 2022-06-23 18:39:28.493242
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    
    
    
    
    #hack to use rss and rps as "--"
    #after running all test cases, the sys.argv has been changed, so restore it here
    sys.argv=sys.argv[:1]
    sys.argv.append("--")
    try:
        response = requests.get("http://httpbin.org/headers")
        assert response.status_code == 200
    except:
        print("Unable to connect to httpbin.org, skip online test")
        return
    
    parser = HTTPieArgumentParser()
    
    
    
    
    
    
    
    parser.parse_args(("-v",))
    parser.parse_args(("--verbose",))
    parser.parse_args(("--version",))
    parser.parse_args

# Generated at 2022-06-23 18:39:32.745264
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """Unit test for class HTTPieArgumentParser.

    In order to run this test, please execute command "pytest -v" in this
    directory.

    The output should be:

    test_argument_parser.py::test_HTTPieArgumentParser PASSED

    """
    parser = HTTPieArgumentParser()
    assert type(parser) == HTTPieArgumentParser

# Generated at 2022-06-23 18:39:45.281829
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    arg = argparse.Namespace()
    arg.url = None
    arg.method = None
    arg.output_file = None
    arg.body = None
    arg.request_items = None
    arg.headers = None
    arg.data = None
    arg.files = None
    arg.params = None
    arg.multipart_data = None
    arg.output_options = None
    arg.output_options_history = None
    arg.prettify = None
    arg.prettify_all = None
    arg.download = None
    arg.download_resume = None
    arg.ignore_stdin = None
    arg.follow = None
    arg.max_redirects = None
    arg.timeout = None
    arg.check_status = None
    arg.verify = None
    arg

# Generated at 2022-06-23 18:39:58.527329
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """
    HTTPie Arguments Parser
    
    Args:
        args_list (list of strings): a list of arguments

    Returns:
        Namespace object populated with args_list
    """
    parser = HTTPieArgumentParser()
    # Test of parsing of Positional arguments
    # Parse the arguments to a list
    args_list = ['https://httpbin.org/get', 'a=b']
    args = parser.parse_args(args_list)

    # Test of parsing of Optional arguments
    # Test of parsing of no-options arguments
    args_list = ['https://httpbin.org/get', 'a=b', '--no-traceback']
    args = parser.parse_args(args_list)
    assert args.traceback == False

    # Test of parsing of auth arguments
    # Test of parsing

# Generated at 2022-06-23 18:40:04.284988
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser()
    parser.formatter_class = HTTPieHelpFormatter
    parser.add_argument('--songs', help='List of songs.\n\nYou can '
                        'provide more than one song.')
    parser.add_argument('--name', help='The name of the playlist.')
    args_help = parser.format_help()
    assert 'List of songs.\n\nYou can provide more than one song.' in args_help
    assert 'The name of the playlist.' in args_help



# Generated at 2022-06-23 18:40:06.332537
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    HTTPieArgumentParser()

# Test for the method _guess_method of class HTTPieArgumentParser

# Generated at 2022-06-23 18:40:11.437735
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    argparser = HTTPieArgumentParser()
    args = argparser.parse_args(['https://httpbin.org/get'])
    assert args.headers == mimetypes.MimeTypes().guess_all_extensions('application/json')



# Generated at 2022-06-23 18:40:16.252416
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = HTTPieArgumentParser(prog="curl").parse_args([])
    assert(args.headers == {"host": "example.com"})
    assert(args.auth == None)
    assert(args.auth_type == None)
# Test for get_parser_args

# Generated at 2022-06-23 18:40:26.187988
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert parser.is_valid()
    parser.error("test")
    parser.error("test", "test")
    parser.error("test", "test", "test")
    parser.exit()
    parser.exit(0)
    parser.exit(1)
    assert parser.version is not None
    assert parser.version_string is not None
    parser.exit_with_message('test')
    parser.parse_args([])
    parser.parse_args(['--help'])
    parser.parse_args(['--version'])
    parser.get_prog_name()
    parser.print_help()
    parser.print_version()
    parser.convert_arg_line_to_args('test')
    parser.print_usage()
    parser.print_message

# Generated at 2022-06-23 18:40:30.653488
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    help_formatter = HTTPieHelpFormatter()
    parser = argparse.ArgumentParser(formatter_class=help_formatter)
    parser.add_argument('--foo', help='''
        bar bar bar bar bar bar bar bar bar bar bar bar bar bar bar bar
        bar bar bar bar bar bar bar bar bar bar bar bar bar bar bar bar
        ''', metavar='BAR')
    parser.print_help()


# Generated at 2022-06-23 18:40:35.645975
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """
    Creating the parser and then invoking it with the '-h' help flag
    """
    # Define a command to run
    args = ['-h', '-q', 'https://www.httpbin.org/']
    # Generate the parser
    parser = HTTPieArgumentParser()
    # Run the parser
    parser.parse_args(args=args)
    # All good


# Generated at 2022-06-23 18:40:47.414712
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Setup
    parser = HTTPieArgumentParser()

    # Exercise 1
    args = parser.parse_args([
        '--method', 'POST',
        'http://example.com',
        'name=John',
        'foo=bar',
        'nested%5Bkey%5D=value'
    ])
    assert args.method == 'POST'
    assert args.headers == [('content-type', 'application/json')]

    # Exercise 2
    args = parser.parse_args([
        '--method', 'GET',
        'http://example.com',
        'name=John',
        'foo=bar',
        'nested%5Bkey%5D=value'
    ])
    assert args.method == 'GET'
    assert args.headers == []

    # Teardown
    parser

# Generated at 2022-06-23 18:40:53.514826
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser(env=EnvironmentForTest())
    parser.add_argument("-a", action="store_true")
    parser.add_argument("-b", "--bar", action="store_true")
    arguments = parser.parse_args(
        [
            "-a", "1", "-b", "foo=bar", "123",
            "-a", "2", "-b", "bar=foo", "456",
            "--ignore-stdin",
            "--b", "bar=foo", "456",
            "--a", "3", "--b", "foo=bar", "789",
            "--b", "bar=foo", "789",
            "-b", "bar=foo", "789",
        ]
    )
    assert arguments.json is None
    assert arguments.pretty_options is False

# Generated at 2022-06-23 18:41:02.757610
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert len('\n\n')==2
    assert len(dedent('').strip())==0
    # dedent(''), strip(), so we can have a trailing new line
    # there is a bug in Python 3.5 assertion statement
    #assert len(dedent('').strip()+'\n\n')==2
    assert len(dedent('hello').strip())==5
    assert len('hello')==5
    # dedent(''), strip(), so we can have a trailing new line
    # there is a bug in Python 3.5 assertion statement
    #assert len(dedent('hello').strip()+'\n\n')==7
    assert len(dedent('hello\nworld\n').strip())==11
    assert len(dedent('hello\nworld\n').strip()+'\n\n')

# Generated at 2022-06-23 18:41:07.837389
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = ['GET', 'https://httpie.org/doc']
    parser = HTTPieArgumentParser()
    parsed_args = parser.parse_args(args)
    assert parsed_args.url == 'https://httpie.org/doc'
    assert parsed_args.method == 'GET'


# Generated at 2022-06-23 18:41:12.203265
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    assert HTTPieArgumentParser().__class__ == HTTPieArgumentParser
    assert isinstance(HTTPieArgumentParser().__class__, object)

    try:
        HTTPieArgumentParser()
    except TypeError:
        print("TypeError Error.")

test_HTTPieArgumentParser()


# Generated at 2022-06-23 18:41:21.628710
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    text = """    Arguments are parsed from the left to the right.

        Argument names starting with `+` or `-` mean they are without or
        with value respectively.

        Boolean arguments are activated if they are specified,
        even without a value.

    """

    splitted = HTTPieHelpFormatter()._split_lines(text, 80)

    expected_result = [
        'Arguments are parsed from the left to the right.', '',
        'Argument names starting with `+` or `-` mean they are without or',
        'with value respectively.', '',
        'Boolean arguments are activated if they are specified,',
        'even without a value.', '', ''
    ]

    assert splitted == expected_result



# Generated at 2022-06-23 18:41:34.103851
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    # Test with no argument
    args = parser.parse_args([])
    assert args.url=='https://httpbin.org/'
    # Test with '-h' argument
    args = parser.parse_args(['-h'])
    assert args.url == 'https://httpbin.org/'
    # Test with '--headers' argument
    args = parser.parse_args(['--headers'])
    assert args.headers==True
    # Test with '--json' argument
    args = parser.parse_args(['--json'])
    assert args.json==True
    # Test with '--form' argument
    args = parser.parse_args(['--form'])
    assert args.form==True
    # Test with '--timeout' argument

# Generated at 2022-06-23 18:41:40.634455
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    arg_parser = HTTPieArgumentParser()
    arg_parser.env.stdout = sys.stdout
    arg_parser.env.stderr = sys.stderr
    arg_parser.parse_args(['https://localhost:8000/get'])
    assert arg_parser.args.url == 'https://localhost:8000/get'
    assert arg_parser.args.method == 'GET'


# Generated at 2022-06-23 18:41:41.365653
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert(True)


# Generated at 2022-06-23 18:41:41.893061
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    pass


# Generated at 2022-06-23 18:41:54.306658
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """Test HTTPieArgumentParser.parse_args"""

# Generated at 2022-06-23 18:41:55.606823
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    item = HTTPieHelpFormatter()
    return


# Generated at 2022-06-23 18:42:01.249591
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    class TestEnvironment(Environment):
        def __init__(self):
            self.is_windows = False
            self.is_posix = True
            self.stdout_isatty = True
            self.stderr_isatty = True
            self.stdout_encoding = 'UTF-8'
            self.stdin_encoding = 'UTF-8'
            self.stdin = sys.stdin
            self.stdout = sys.stdout
            self.stderr = sys.stderr
            self.stdin_isatty = sys.stdin.isatty()
            self.stdout_isatty = sys.stdout.isatty()
            self.stderr_isatty = sys.stderr.isatty()
            self.stdin_raw = sys.std

# Generated at 2022-06-23 18:42:09.434965
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['https://google.com'])
    assert args.auth_type == 'basic'
    assert args.ignore_stdin
    assert args.stream
    assert args.timeout == 60
    assert args.validate_certs
    assert args.verify == True
    assert args.max_redirects == 5
    assert args.headers == {'Content-Type': 'application/json', 'User-Agent': 'HTTPie/0.9.9'}
    assert args.auth is None
    assert args.body is None
    assert args.check_status
    assert args.download is False
    assert args.download_resume is False
    assert args.form is False
    assert args.ignore_netrc
    assert args.max_headers == 100
   

# Generated at 2022-06-23 18:42:14.249427
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    print('Test HTTPieArgumentParser:')
    parser = HTTPieArgumentParser()
    print('parser created!')
    args = parser.parse_args()
    print('args: ' + str(args))
    #print(args.url)

if __name__ == '__main__':
    test_HTTPieArgumentParser()

# Generated at 2022-06-23 18:42:15.055511
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    pass


# Generated at 2022-06-23 18:42:16.419958
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    h = HTTPieHelpFormatter()
    assert h.max_help_position == 6


# Generated at 2022-06-23 18:42:19.271881
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    '''
    Unit test for constructor of class HTTPieArgumentParser
    
    HTTPieArgumentParser
    '''
    pass

# Generated at 2022-06-23 18:42:30.244771
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import sys
    import fudge
    from httpie.core import main
    from httpie.plugins import BuiltinPluginManager
    from httpie import ExitStatus
    from httpie.compat import is_py26

    @fudge.patch('httpie.core.get_response')
    def run(get_response):
        stdin = fudge.Fake().provides('read').expects('read').returns('stdin')
        stdin.expects('close')

        stdout = fudge.Fake().has_attr(name='stdout').expects('write')
        if not is_py26:
            stdout.expects('flush')
        stderr = fudge.Fake().has_attr(name='stderr').provides('write')


# Generated at 2022-06-23 18:42:30.848469
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    pass

# Generated at 2022-06-23 18:42:41.985630
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    argparse_object = argparse.ArgumentParser()
    argparse_object._positionals.title = 'keyword arguments'
    argparse_object._optionals.title = 'optional arguments'
    argparse_object.add_argument('--foo', help='foo help')
    argparse_object.add_argument('bar', help='bar help')
    formatter = HTTPieHelpFormatter()
    assert formatter._split_lines('first\n\nsecond', 80) == [
        'first', '', 'second'
    ]
    assert formatter._metavar_formatter(argparse_object, ('bar',)) == ('bar',)



# Generated at 2022-06-23 18:42:45.846436
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    f = HTTPieHelpFormatter()
    text = """
            Print only the headers of the response.
        """
    assert f._split_lines(text, 0) == ['Print only the headers of the response.', '']



# Generated at 2022-06-23 18:42:48.635966
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # TODO: add tests
    pass


#Unit test for method parse_argv

# Generated at 2022-06-23 18:42:58.667860
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Define some constants
    raw_request_items = [
        KeyValueArgType('--json')('a=1'),
        KeyValueArgType('--auth')('b=2'),
        KeyValueArgType('--auth')('b=3'),
        KeyValueArgType('--auth')('c=4'),
        KeyValueArgType('--auth')('e=5'),
    ]
    raw_headers = ['g:6', 'h=7', 'i:=8']
    pretty = 'all'
    output_options  = OUTPUT_OPTIONS_DEFAULT_STDOUT_REDIRECTED
    output_options_history = OUTPUT_OPTIONS_DEFAULT_OFFLINE
    output_file = tempfile.NamedTemporaryFile('w', delete=False).name
    output_file_

# Generated at 2022-06-23 18:43:05.143932
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    from argparse import ArgumentParser
    parser = ArgumentParser(formatter_class=HTTPieHelpFormatter)
    parser.add_argument('--foo', help="""\
        foo happens.

        It's very complicated.
        """)
    help_pos = parser.format_help().find('--foo')
    assert help_pos == 17



# Generated at 2022-06-23 18:43:06.654838
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    pass
setattr(HTTPieArgumentParser, "parse_args", test_HTTPieArgumentParser_parse_args)


# Generated at 2022-06-23 18:43:09.635393
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # Test HTTPieArgumentParser.__init__()
    parser = HTTPieArgumentParser()
    assert isinstance(parser, HTTPieArgumentParser)


# Generated at 2022-06-23 18:43:21.780753
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    print("HTTPieHelpFormatter..")
    help_formatter = HTTPieHelpFormatter()
    print(help_formatter)


parser = argparse.ArgumentParser(
    description='cURL for humans.',
    formatter_class=HTTPieHelpFormatter,
    add_help=False
)
parser.add_argument('--version', action='version',
                    version=__import__('httpie').__version__)
parser.add_argument('-h', '--help', action='help',
                    help='Show this help message and exit.')
parser.add_argument('--traceback', action='store_true',
                    help='Print exception traceback should one occur.')
parser.add_argument('--debug', action='store_true', help=argparse.SUPPRESS)



# Generated at 2022-06-23 18:43:29.042216
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # Mock the statichttpie module
    def mocked_get_config_path():
        return '/home/user_name/.httpie'

    def mocked_get_config_dir():
        return '/home/user_name/.config/httpie'

    def mocked_get_netrc_path():
        return '/home/user_name/.netrc'

    def mocked_get_local_netrc_path():
        return '/home/user_name/.netrc.local'

    def mocked_get_netrc_auth(http_url):
        return ('test_user', 'test_pass')

    def mocked_get_local_netrc_auth(http_url):
        return ('test_user', 'test_pass')

    httpie = MagicMock()
    httpie.get_config_path.side_effect = mocked_

# Generated at 2022-06-23 18:43:38.390689
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        formatter_class=HTTPieHelpFormatter,
        # Don't sort arguments.
        # The order in which arguments and option groups appear in the help
        # output is the order in which they are defined in the parser.
        argument_default=argparse.SUPPRESS,
    )
    # Test arguments with indented help text.
    parser.add_argument('--foo', help="""\
        Foo bar
        bar foo
    """)
    # Test options group with indented help text.
    group = parser.add_argument_group('Group')
    group.add_argument('--bar')

    args = parser.parse_args([])
    h = parser.format_help()

# Generated at 2022-06-23 18:43:42.674744
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    # Arrange
    class TestClass(HTTPieHelpFormatter):
        def __init__(self):
            return super().__init__(max_help_position=9)

    # Act
    obj = TestClass()

    # Assert
    pass


# Generated at 2022-06-23 18:43:50.004376
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    test_string = """
    Here is a long text that is describing the argument,
    it can span on multiple lines and contain indentation
    which will be automatically removed.
    """
    result_list = formatter._split_lines(test_string, 80)
    print(result_list)
    print(result_list[0].strip())
    

# Generated at 2022-06-23 18:43:55.757814
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import httpie.config as config
    parser = HTTPieArgumentParser()
    config.load_config(parser)
    args=parser.parse_args(['httpbin.org/get', '--form', 'a=1', 'b=2'])
    assert args.url=='httpbin.org/get'
    assert args.method=='GET'
    assert args.form
    assert args.params == {'a': '1', 'b': '2'}



# Generated at 2022-06-23 18:44:08.348057
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    #self.env.stderr = io.BytesIO()
    parser = HTTPieArgumentParser(env=Env(),force_colors=False)
    #assert False
    args = parser.parse_args([
        '--form',
        'http://httpbin.org/post',
        'name=john',
        'foo@bar.file',
        'password=12345'
    ])
    assert args.form
    assert args.headers['Content-Type'] == 'application/x-www-form-urlencoded; charset=utf-8'
    assert args.data['name'] == 'john'
    assert args.files['foo'] == 'bar.file'


# Generated at 2022-06-23 18:44:12.170478
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    assert formatter._split_lines("""\
    one two
    three
    """, 5) == ["one two", "three", "", ""]


# Generated at 2022-06-23 18:44:23.308558
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie.core import main as parse_args
    from httpie.client import Environment
    # noinspection PyUnresolvedReferences,PyPackageRequirements
    import httpie.plugins.builtin
    try:
        # noinspection PyUnresolvedReferences,PyPackageRequirements
        import httpie.plugins.form
    except ImportError:
        pass
    try:
        # noinspection PyUnresolvedReferences,PyPackageRequirements
        import httpie.plugins.download
    except ImportError:
        pass
    try:
        # noinspection PyUnresolvedReferences,PyPackageRequirements
        import httpie.plugins.json
    except ImportError:
        pass
    try:
        # noinspection PyUnresolvedReferences,PyPackageRequirements
        import httpie.plugins.prompt
    except ImportError:
        pass
    import os

# Generated at 2022-06-23 18:44:25.278566
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """
    HTTPieArgumentParser() is constructor for HTTPieArgumentParser class and
    it takes no arguments.
    """
    _HTTPieArgumentParser = HTTPieArgumentParser()
    assert _HTTPieArgumentParser

# Generated at 2022-06-23 18:44:38.485474
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-23 18:44:44.309628
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # Create a new HTTPieArgumentParser
    parser = HTTPieArgumentParser(env=Environment())

    args, _ = parser.parse_known_args()

    # Test if the attribute args of parser are the same as defaults
    assert args == parser.DEFAULTS



# Generated at 2022-06-23 18:44:48.974285
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    """
    A unit test for the constructor of class HTTPieHelpFormatter.
    :return:
    """
    help_formatter = HTTPieHelpFormatter()
    assert help_formatter.max_help_position == 6
    assert help_formatter._width == 90   # the default width for formatter.



# Generated at 2022-06-23 18:45:00.430712
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    docopt = dedent("""
            Usage: docopt_test.py [options]

            -f, --first  FIRST
            -s, --second SECOND
            -t, --third  THIRD

            Options:
                -h --help
            """)
    # Test format_help_1
    result = HTTPieHelpFormatter(prog="docopt_test.py")
    # It will add a blank line for each argument.
    result = result.format_help().strip().split('\n')
    assert len(result) == 5
    # Test format_usage
    result = HTTPieHelpFormatter().format_usage(docopt).strip()
    assert result == 'Usage: docopt_test.py [options]'
    
    

# Generated at 2022-06-23 18:45:13.244249
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(description='test for class HTTPieHelpFormatter', formatter_class=HTTPieHelpFormatter)
    parser.add_argument(
        '--test-indent1', metavar='test-indent1', help="""\
        This description should be indented.
        Line 2
        """
    )
    parser.add_argument(
        '--test-indent2', metavar='test-indent2', help="""\
This description should be indented.
Line 2
"""
    )
    parser.add_argument(
        '--test-indent3', metavar='test-indent3', help="""\
This description should be indented.
    Line 2
"""
    )

# Generated at 2022-06-23 18:45:15.493779
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    ap = HTTPieArgumentParser('a short description')
    assert ap.description == 'a short description'


# Generated at 2022-06-23 18:45:17.355524
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    pass


# Tests for the entire module

# Generated at 2022-06-23 18:45:28.820121
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args_list = [
        ['http', '-v', 'https://google.com/'], ['http', '-v', 'https://google.com/'], ['http', '-v', 'https://google.com/'], ['http', '-v', 'https://google.com/'], ['http', '-v', 'https://google.com/'], ['http', '-v', 'https://google.com/'], ['http', '-v', 'https://google.com/'], ['http', '-v', 'https://google.com/'], ['http', '-v', 'https://google.com/'],
    ]

    for args in args_list:
        try:
            HTTPieArgumentParser().parse_args(args)
        except (SystemExit, KeyboardInterrupt):
            pass



# Generated at 2022-06-23 18:45:35.047554
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    parser.add_argument('--integer', type=int)
    parser.add_argument('--float', type=float)

# Generated at 2022-06-23 18:45:40.509463
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    test_cases = [
        (['x'], 'x', [], [], None, None, None, None, None, None),
        (['y'], 'y', [], [], None, None, None, None, None, None),
        (['x', '-v'], 'x', [], [], None, None, None, None, None, None)
    ]

    for test_case in test_cases:
        args = test_case[0]
        with patch.object(HTTPieArgumentParser, 'error') as mock_error:
            mock_error.side_effect = HTTPieError
            mock_parser = HTTPieArgumentParser()
            with pytest.raises(HTTPieError):
                mock_parser.parse_args(args)
    return True


# Generated at 2022-06-23 18:45:43.083565
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert len(HTTPieHelpFormatter()._split_lines("""
        foo bar


        bar foo

        """)) == 4


# Generated at 2022-06-23 18:45:47.098563
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        description='description',
        formatter_class=HTTPieHelpFormatter)
    parser.add_argument('--foo', help=' foo help')
    print(parser.format_help())



# Generated at 2022-06-23 18:45:59.351500
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['get', 'httpbin.org', 'sudo=true'])
    assert args.url == 'httpbin.org'
    assert args.method == 'GET'
    assert args.headers == []
    assert args.output_file == None
    assert args.download == False
    assert args.exit_status == 0
    assert args.check_status == False
    assert args.ignore_stdin == False
    assert args.timeout == None
    assert args.max_redirects == 30
    assert args.follow_redirects == True
    assert args.output_options is None
    assert args.output_options_history is None
    assert args.pretty == None
    assert args.style == None
    assert args.format == None
    assert args.format_

# Generated at 2022-06-23 18:46:10.987741
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    parser = HTTPieArgumentParser(env=Env())

    parser_2 = HTTPieArgumentParser(env=Env())

    parser.add_argument('--version', action='version', version='%(prog)s 2.0')
    parser.add_argument('--test_arg', default=[], action='append')

    parser_2.add_argument('--test_arg_2', default=[], action='append')

    # compare
    assert parser.parse_args() == parser_2.parse_args()

    args = parser.parse_args(['--test_arg', 'test_value'])

    # compare
    assert args == parser.parse_args(['--test_arg', 'test_value'])

    # compare

# Generated at 2022-06-23 18:46:21.149761
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    # Unit test for constructor of class HTTPieHelpFormatter
    # Arrange
    input_str = "  Environment:\n    HTTPIE_CONFIG_DIR  Directory to load the user config" \
                "from.\n  $XDG_CONFIG_HOME/httpie if unset.\n    HTTPIE_CONFIG_FILE  File " \
                "to load the user config from.\n  $HTTPIE_CONFIG_DIR/config.json if unset." \
                "\n    HTTPIE_DEBUG  Enable debug output.\n    HTTPIE_FORMAT  Specify a custom" \
                "\n  output format." \
                "\n    HTTPIE_VERIFY_SSL  Verify SSL certs.\n    HTTPIE_SSL_NO_VERIFY  Don't " \
                "verify SSL certs."
    expected

# Generated at 2022-06-23 18:46:34.436435
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    assert formatter._split_lines('aabb', 10) == ['aabb']
    assert formatter._split_lines('  aabb', 10) == ['aabb']
    assert formatter._split_lines('''
        aabb
        bb
        cc
        ddd
        ''', 10) == ['aabb', 'bb', 'cc', 'ddd']
    assert formatter._split_lines('aabb\nbb\ncc\nddd', 10) == ['aabb', 'bb', 'cc', 'ddd']


# def test_httpie_helpformatter():
#     formatter = HTTPieHelpFormatter()
#     assert formatter._split_lines(
#         'foo\nbar\n\nBaz\n\n\n\nqux\

# Generated at 2022-06-23 18:46:41.387999
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # Get the argv sample from httpie/doc/httpie-args-sample.txt
    from httpie.core import main_helpers
    from httpie.core.main import create_parser

    parser = create_parser()
    args = main_helpers.get_sample_argv()
    #args = sys.argv[:]
    opts = parser.parse_args(args)
    #print(args)
    print(opts)

# Generated at 2022-06-23 18:46:46.138971
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    log0 = 'No tests written yet'
    print(log0)
    # self.assertEqual(expected, HTTPieArgumentParser.parse_args(*args, **kwargs))
    assert log0 == 'No tests written yet'


# Generated at 2022-06-23 18:46:56.753006
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert parser.prog == 'http'
    assert parser.usage == '%(prog)s [OPTIONS] [URL] [ITEM [ITEM]]...'
    assert parser.description == (
        'HTTPie is a cURL-like tool for humans. '
        'https://github.com/jakubroztocil/httpie'
    )

# Generated at 2022-06-23 18:47:01.717402
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    AP = HTTPieArgumentParser()
    return AP

# Testing code for class HTTPieArgumentParser
if __name__ == '__main__':
    print("Testing constructors of classes HTTPieArgumentParser")
    test_HTTPieArgumentParser()
    print("Testing done")

# Generated at 2022-06-23 18:47:08.091369
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    '''
    >>> help_text = '\\n'.join([
    ...     'First line',
    ...     '  Second line',
    ...     '',
    ...     '  Third line',
    ... ])
    >>> lines = HTTPieHelpFormatter()._split_lines(help_text, 80)
    >>> print('\n'.join(lines))
    First line

    Second line

    Third line
    <BLANKLINE>
    '''


# Generated at 2022-06-23 18:47:14.148815
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    f = HTTPieHelpFormatter()
    # Test dedent and word wrap 
    text = """\
        Blah blah blah
        blah blah
        """
    text1 = """Blah blah blah"""
    text2 = """blah blah"""
    assert f._split_lines(text, 10) == [text1, text2, '']



# Generated at 2022-06-23 18:47:23.116455
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # `HTTPieArgumentParser.parse_args([])` calls `env.config.load()`.
    # `Config.load()` calls `Config.get_config_path()` which may call
    # `os.getcwd()`. Mock it and make it return the directory where
    # this file is.
    with mock.patch('os.getcwd') as os_getcwd_mock:
        # Calling `dirname` twice is intentional.
        os_getcwd_mock.return_value = os.path.dirname(
            os.path.dirname(__file__))
        env = Environment()
        # TODO: would be better to use `io.StringIO`
        parser = HTTPieArgumentParser(env=env, prog='http')


# Generated at 2022-06-23 18:47:31.070342
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie.client import HTTPie
    from httpie.core import parse_items
    from httpie.context import Environment
    from httpie.args import KeyValueArgType, RequestItems
    from httpie.downloads import get_filename_from_content_disposition

    env = Environment()
    parser = ArgParser(prog='http', env=env, compat=False)
    args = parser.parse_args(
        shlex.split("GET 'https://httpbin.org/get' key:value")
    )
    print(args)

    args = parser.parse_args(
        shlex.split("GET  'https://httpbin.org/get' key:value --verbose")
    )
    print(args)
