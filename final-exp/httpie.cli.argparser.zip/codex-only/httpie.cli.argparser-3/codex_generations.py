

# Generated at 2022-06-23 18:37:25.785272
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert parser
    assert isinstance(parser, HTTPieArgumentParser)
    assert issubclass(HTTPieArgumentParser, argparse.ArgumentParser)

# Generated at 2022-06-23 18:37:28.175069
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert hasattr(HTTPieHelpFormatter, '_split_lines')

# Testing whether _split_lines is defined

# Generated at 2022-06-23 18:37:30.684776
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    max_help_position_global=6
    assert HTTPieHelpFormatter.__init__(max_help_position_global)


# Generated at 2022-06-23 18:37:35.537862
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    pass
    # temp_args = sys.argv[1:]
    # temp_parser = HTTPieArgumentParser(add_help=False)
    # temp_parsed = temp_parser.parse_args(temp_args)
    # assert temp_parsed == argparse.Namespace
    # pass


# Generated at 2022-06-23 18:37:36.556694
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    pass

# Generated at 2022-06-23 18:37:45.392354
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    Reset_Auth_Credentials()
    Reset_Authentication()
    args = [
        '-F',
        'ALL',
        '-a',
        'test:test',
        '-i',
        'https://postman-echo.com/basic-auth'
    ]
    parser = HTTPieArgumentParser()
    parser.parse_args(args=args)
    assert args == parser.args.raw_args
    for k in parser.args.__dict__:
        if k in ['raw_args', 'begin_time', 'config_file']:
            continue
        v = parser.args.__dict__[k]
        if isinstance(v, str):
            v = v.encode('utf-8')
        print('{} = {}'.format(k, v))
        # assert False


# Generated at 2022-06-23 18:37:55.938629
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
  parser = argparse.ArgumentParser(formatter_class=HTTPieHelpFormatter)

# Generated at 2022-06-23 18:38:01.589614
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    def test(arg_string, expected):
        args = HTTPieArgumentParser().parse_args(
            shlex.split(arg_string)
        )
        assert args == expected

    test('', {})
    test('/get', {'url': '/get'})
    test('/get one=1', {'url': '/get', 'headers': [('one', '1')]})
    test('/get one==1', {'url': '/get', 'headers': [('one', '=1')]})
    test('/get one==1+2=!@#$%^&*()', {'url': '/get', 'headers': [('one', '=1+2=!@#$%^&*()')]})

# Generated at 2022-06-23 18:38:12.339968
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    assert formatter._split_lines('hello', 10) == ['hello']
    assert formatter._split_lines('hello\n', 10) == ['hello']
    assert formatter._split_lines('hello\n\n', 10) == ['hello']
    assert formatter._split_lines('hello\n\n\n', 10) == ['hello']
    assert formatter._split_lines('hello\nworld', 10) == ['hello', 'world']
    assert formatter._split_lines('hello\n\nworld', 10) == ['hello', 'world']
    assert formatter._split_lines('hello\n\nworld\n', 10) == ['hello', 'world']

# Generated at 2022-06-23 18:38:16.156801
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
  # Initialize the ArgumentParser
  parser = HTTPieArgumentParser()

  # Create a list of command line arguments
  args = ['www.google.com']

  target_func = parser.parse_args
  result = target_func(args)
  assert result
  # TODO: Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-23 18:38:25.663483
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
    prog='http',
    usage='%(prog)s '
         '[OPTIONS] '
         '[METHOD] URL '
         '[ITEM [ITEM]]',
    description='An HTTP client, written in Python, for humans.\n',
    epilog=('See also: httpie-awesome(1) '
            '- a curated list of awesome HTTPie resources.'),
    formatter_class=HTTPieHelpFormatter,
    )
    parser.add_argument(
        '--version',
        action='version',
        version='HTTPie %s' % __version__,
        help='Display the version and exit.',
    )

# Generated at 2022-06-23 18:38:27.073792
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # instantiation of class
    HTTPieArgumentParser(enable_cookies=False)

# Generated at 2022-06-23 18:38:29.627739
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        description='foo', formatter_class=HTTPieHelpFormatter)
    parser.add_argument('bar', help='bar')



# Generated at 2022-06-23 18:38:31.790785
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=HTTPieHelpFormatter)
    parser.add_argument(
        '--foo',
        help="""
                Boring argument.

                Does nothing.
            """)
    args = parser.parse_args([])



# Generated at 2022-06-23 18:38:34.173985
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert parser.description is not None
    assert parser.epilog is not None
    assert parser.error is not None
    assert parser._print_message is not None



# Generated at 2022-06-23 18:38:46.480699
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Arrange
    parser = HTTPieArgumentParser()
    argv = ['--debug', '--auth', 'user:pass']

# Generated at 2022-06-23 18:38:50.955970
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    help_formatter = HTTPieHelpFormatter(max_help_position=1)
    assert help_formatter
    assert help_formatter.max_help_position == 1


# Generated at 2022-06-23 18:38:57.221800
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert HTTPieHelpFormatter.__name__ == 'HTTPieHelpFormatter'
    assert HTTPieHelpFormatter.__doc__ == 'A nicer help formatter.\n\n    Help for arguments can be indented and contain new lines.\n    It will be de-dented and arguments in the help\n    will be separated by a blank line for better readability.\n\n    \n    '



# Generated at 2022-06-23 18:39:08.865269
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    
    try:
        parser = HTTPieArgumentParser()
        parser.parse_args()

    except SystemExit:
        assert True
    else:
        assert False

    try:
        parser = HTTPieArgumentParser()
        parser.parse_args(['https://github.com/jakubroztocil/httpie'])

    except SystemExit:
        assert True
    else:
        assert False

    args = parser.parse_args(['--help'])
    assert args.url is None
    assert args.debug

    args = parser.parse_args(['https://github.com/jakubroztocil/httpie'])
    assert args.url == 'https://github.com/jakubroztocil/httpie'
    assert not args.debug

    args = parser.parse_args

# Generated at 2022-06-23 18:39:15.704688
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    a = HTTPieArgumentParser()
    url = 'http://example.com/api/'
    args = a.parse_args([url, '-i'])
    assert isinstance(args, argparse.Namespace)
    assert args.headers['Connection'] == 'close'
    assert isinstance(args.headers, CaseInsensitiveDict)
    assert args.url == url
    assert args.json is False

test_HTTPieArgumentParser_parse_args()


# Generated at 2022-06-23 18:39:21.316297
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    text = '''\
        One line summary.

        Extended description.

        Extended description continued.
    '''
    expected = '''\
        One line summary.


        Extended description.


        Extended description continued.


    '''
    assert expected == HTTPieHelpFormatter()._split_lines(text, 80)



# Generated at 2022-06-23 18:39:31.075108
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    args = HTTPieArgumentParser().parse_args(args=['http://localhost'])
    assert args.url == 'http://localhost'
    assert args.json is False
    assert args.form is False
    assert args.output_file is None
    assert args.output_options is None
    assert args.output_options_history is None
    assert args.follow is False
    assert args.download is False
    assert args.download_resume is False
    assert args.check_status is False
    assert args.ignore_stdin is False
    assert args.pretty is None
    assert args.prettify == PRETTY_STDOUT_TTY_ONLY
    assert args.style == None
    assert args.style_sheet == None
    assert args.headers == None
    assert args.verbose == False

# Generated at 2022-06-23 18:39:44.169930
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """
    Test method parse_args of class HTTPieArgumentParser
    """
    # Test input
    args = ['http', 'https://httpbin.org/get']
    namespace = Namespace()
    parser = HTTPieArgumentParser()
    # Test method
    parser.parse_args(args, namespace)
    # Test output
    r = parser.args
    assert r.url.value == 'https://httpbin.org/get'
    assert r.url.arg_type == ARG_TYPE_POSITIONAL
    assert r.url.orig == 'https://httpbin.org/get'
    assert r.abbrev == False
    assert r.all == False
    assert r.auth == None
    assert r.auth_type == None
    assert r.auth_plugin == None
    assert r.body == None


# Generated at 2022-06-23 18:39:45.537167
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    httpie_argparse.HTTPieArgumentParser(usage="test_usage")

# Generated at 2022-06-23 18:39:47.477291
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    import doctest
    doctest.testmod(HTTPieArgumentParser)



# Generated at 2022-06-23 18:39:53.145710
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Preparing for testing
    argv = ''
    env = Environment()
    parser = HTTPieArgumentParser(env=env)
    
    # Testing
    parser.parse_args(shlex.split(argv))
    # end
    

# Generated at 2022-06-23 18:39:59.642299
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Create the parser.
    parser = HTTPieArgumentParser()
    # Define allowed arguments.
    arguments = ['--body', '"test_body"', 'http://test.com']
    # Parse the arguments.
    args = parser.parse_args(arguments)
    # Print the values of the parsed arguments.
    print(args.url)
 
test_HTTPieArgumentParser_parse_args()


# Generated at 2022-06-23 18:40:11.868556
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    print('************************************************************')
    print('Unit test for method parse_args(), class HTTPieArgumentParser')
    print('************************************************************')
    
    args = ['--help']
    parser = HTTPieArgumentParser()
    parser.parse_args(args)
    
    args = ['--version']
    parser = HTTPieArgumentParser()
    parser.parse_args(args)
    
    args = ['http://httpbin.org/get']
    parser = HTTPieArgumentParser()
    parser.parse_args(args)
    
    args = ['GET', 'http://httpbin.org/get']
    parser = HTTPieArgumentParser()
    parser.parse_args(args)
    
    args = ['http://httpbin.org/headers', 'Accept:' 'application/json']
    parser = HTTPie

# Generated at 2022-06-23 18:40:15.674615
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    with pytest.raises(AttributeError):
        # Test calling _split_lines() before use
        HTTPieHelpFormatter._split_lines(HTTPieHelpFormatter(), text="abc", width=80)


# Generated at 2022-06-23 18:40:21.216663
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Arrange

    h = HTTPieArgumentParser()
    args = ['--json', 'http://localhost:5000/']

    # Act

    try:
        h.parse_args(args)
        parsed_args = True
    except:
        parsed_args = False

    # Assert
    assert(parsed_args)


# Generated at 2022-06-23 18:40:29.726519
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        prog = 'http',
        description = 'HTTPie - a CLI, cURL-like tool for humans.',
        epilog = 'See http://httpie.org for more details.',
        add_help = False,
        formatter_class = HTTPieHelpFormatter
    )

    parser.add_argument(
        '--version',
        action = 'version',
        version = 'HTTPie {}'.format('0.9.9'),
        help = '''Show the version number and exit.'''
    )

    parser.add_argument(
        '-h', '--help',
        action = 'help',
        help = '''Show this help and exit.'''
    )


# Generated at 2022-06-23 18:40:31.446873
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    pass

if __name__ == '__main__':
    test_HTTPieArgumentParser()

# Generated at 2022-06-23 18:40:33.747784
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # construct an object of class HTTPieArgumentParser
    parser = HTTPieArgumentParser()
    # the object has the attribute args of the class argparse.Namespace
    assert isinstance(parser.args, argparse.Namespace)
    # the object has the attribute env of the class Environment
    assert isinstance(parser.env, Environment)
    # the object has the attribute exit_status

# Generated at 2022-06-23 18:40:38.491707
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    ap = HTTPieArgumentParser()
    args = ap.parse_args([])
    assert args.json is None
    args = ap.parse_args(['--json', 'abc'])
    assert args.json == 'abc'
test_HTTPieArgumentParser_parse_args()


# Generated at 2022-06-23 18:40:50.053187
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    assert issubclass(HTTPieArgumentParser, ConfigArgumentParser) == True
    assert issubclass(HTTPieArgumentParser, ArgumentParser) == True
    assert(
        hasattr(
            HTTPieArgumentParser,
            "_separate_url_from_request_items"),
        True)
    assert(
        hasattr(
            HTTPieArgumentParser,
            "_print_message"),
        True)
    assert(
        hasattr(
            HTTPieArgumentParser,
            "_setup_standard_streams"),
        True)
    assert(
        hasattr(
            HTTPieArgumentParser,
            "_process_auth"),
        True)
    assert(
        hasattr(
            HTTPieArgumentParser,
            "_apply_no_options"),
        True)

# Generated at 2022-06-23 18:40:55.614327
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    import sys
    import argparse
    ap = HTTPieArgumentParser()
    ap.parse_args(['httpbin.org/get', '--ignore-stdin'])
    assert not hasattr(ap, 'env')
    assert not hasattr(ap, 'args')
    assert not hasattr(ap, 'POST')
    assert not hasattr(ap, '_actions')
    assert not hasattr(ap, 'usage')
    assert not hasattr(ap, 'epilog')
    assert not hasattr(ap, 'prog')
    assert not hasattr(ap, 'add_argument')
    assert not hasattr(ap, 'add_mutually_exclusive_group')
    assert not hasattr(ap, 'set_defaults')
    assert not hasattr(ap, 'get_default')

# Generated at 2022-06-23 18:41:06.640495
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie.core import DEFAULT_USER_AGENT
    from httpie.context import Environment
    from requests.cookies import RequestsCookieJar
    import io
    args = HTTPieArgumentParser().parse_args([u'localhost'])
    assert args.url.geturl() == u'http://localhost/'
    assert args.headers == {}
    assert args.method == u'GET'
    assert not args.auth
    assert not args.follow
    assert not args.ignore_netrc
    assert not args.check_status
    assert not args.download
    assert not args.download_resume
    assert not args.form
    assert args.headers is not None
    assert args.method is not None
    assert args.params is not None
    assert args.data is None
    assert args.json is None

# Generated at 2022-06-23 18:41:15.733050
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    from contextlib import redirect_stdout
    from io import StringIO
    from httpie import env
    from httpie.client import JSON_ACCEPT
    from requests.structures import CaseInsensitiveDict
    from httpie.compat import is_windows

    args = HTTPieArgumentParser().parse_args([])
    env.config = Config()
    env.stdout = StringIO()
    env.stderr = StringIO()
    env.stderr.isatty = env.stdout.isatty = False
    env.stdout_isatty = sys.stdout.isatty()
    env.stderr_isatty = sys.stderr.isatty()
    env.color = Color()

# Generated at 2022-06-23 18:41:18.500820
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    HTTPieArgumentParser._parse_args('--download', '--output=filename.txt')[1]
# copy/paste from http://stackoverflow.com/questions/15008758/parsing-boolean-values-with-argparse

# Generated at 2022-06-23 18:41:30.320072
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import json

    argv = ['--headers']
    assert parse_args(argv).headers == True

    argv = ['--traceback']
    assert parse_args(argv).traceback == True

    argv = ['--ignore-stdin']
    assert parse_args(argv).ignore_stdin == False

    argv = ['--verify=certs.pem']
    assert parse_args(argv).verify == 'certs.pem'

    argv = ['-p','--format=json']
    assert parse_args(argv).format == OUTPUT_OPTIONS_DEFAULT

    argv = ['-p','--prettify']
    assert parse_args(argv).prettify == PRETTY_STDOUT_TTY_ONLY


# Generated at 2022-06-23 18:41:36.737557
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('-v', '--verbose', action='count', help="""
        More output.

        Can be used more than once for even more verbose output.
    """)
    parser.parse_args("-h".split())


# Generated at 2022-06-23 18:41:37.579260
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert 1 == 1



# Generated at 2022-06-23 18:41:42.785439
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    testvalue=dedent('''
        arg1\tArgument Help1
        arg2\tArgument Help2''')
    print(testvalue)
    print(testvalue.strip())
    print (testvalue.strip()+'\n\n')
    print (testvalue.strip()+'\n\n').splitlines()
    return




# Generated at 2022-06-23 18:41:49.565491
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    """Ref: unittest_argparse.py"""
    class MyFormatter(HTTPieHelpFormatter):
        def _split_lines(self, text, width):
            return text.splitlines()

    # Do we have the desired attributes?
    assert '_max_help_position' in dir(MyFormatter)

    # Can we instantiate?
    mf = MyFormatter()
    # We have a usable repr?
    assert repr(mf)
    # Is __str__(mf) == str(mf)?
    assert str(mf) == str(mf)



# Generated at 2022-06-23 18:41:52.475533
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser.parse_args
    print(parser)

test_HTTPieArgumentParser_parse_args()


# Generated at 2022-06-23 18:42:01.755409
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Create a mock of HTTPieArgumentParser
    my_HTTPieArgumentParser = HTTPieArgumentParser(prog='HTTPie', add_help=False, formatter_class=RawTextHelpFormatter)
    my_HTTPieArgumentParser.add_argument('--version', action='version', default=SUPPRESS)
    my_HTTPieArgumentParser.add_argument('-v', '--verbose', action='store_true')
    my_HTTPieArgumentParser.add_argument('--json', default=False, action='store_true')

    # Test the parse_args method
    args = my_HTTPieArgumentParser.parse_args(['-v', '--json'])
    assert args.verbose == True
    assert args.json == True

# Generated at 2022-06-23 18:42:09.345520
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-23 18:42:14.155766
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    import sys
    from httpie.core import env
    parser = HTTPieArgumentParser(env=env.Environment())
    parser.add_argument('-a', '--auth')
    args = parser.parse_args(['-a', 'alice:secret', 'example.org'])
    assert args.auth == 'alice:secret'



# Generated at 2022-06-23 18:42:16.776375
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # Given
    # When
    parser = HTTPieArgumentParser()
    # Then
    # The flag --help should be present
    assert '--help' in parser.format_help()

"""
Demonstrate the use of generator variable scope
"""

# Generated at 2022-06-23 18:42:19.636644
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    args = HTTPieArgumentParser(env=Environment()).parse_args([])
    assert args.check_status == True
    assert args.colors == True

# Generated at 2022-06-23 18:42:26.871929
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    from io import StringIO
    import argparse
    from httpie.cli.argparser import ArgParser
    from httpie.cli.help import HTTPieHelpFormatter

    argParser = ArgParser(HTTPieHelpFormatter, False, 0)
    argParser.prog = "http"
    argParser.usage = "http www.google.com"
    argParser.add_argument("url")
    output = StringIO()
    argParser.print_help(output)

# Generated at 2022-06-23 18:42:27.960524
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    pass


# Generated at 2022-06-23 18:42:32.401954
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # test_config_dir_not_writable
    # test_config_dir_not_writable
    # test_config_dir_not_writable
    # test_config_dir_not_writable
    # test_config_dir_not_writable
    # test_config_dir_not_writable
    pass


# Generated at 2022-06-23 18:42:36.034252
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    print("Start test_HTTPieArgumentParser")
    args = HTTPieArgumentParser()
    print("End test_HTTPieArgumentParser")


# Generated at 2022-06-23 18:42:39.632666
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    print('Testing class HTTPieArgumentParser: ')
    docopt_parser = HTTPieArgumentParser(env=Environment())
    print('HTTPieArgumentParser creation successful!')

# Generated at 2022-06-23 18:42:50.500547
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    import logging
    import socket
    import unittest
    global httpie_process
    httpie_process = HTTPieProcess()

    class TestHTTPieArgumentParser(unittest.TestCase):
        def setUp(self):
            global httpie_process
            global socket
            self.httpie_process = httpie_process
            self.args = self.httpie_process.args
            self.env = self.httpie_process.env
            self.httpie_parser = self.httpie_process.httpie_parser

            self.httpie_parser.parse_args(['http', 'get', 'http://localhost:5000/'])
            self.args = self.httpie_parser.args
            self.env = self.httpie_parser.env

            # To test two servers running
            self.s = socket

# Generated at 2022-06-23 18:42:54.311283
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # construct argument parser
    parser = HTTPieArgumentParser()
    # construct arguments
    args = parser.parse_args('GET http://abc.com'.split())
    # show parsed arguments
    print(args)


# Generated at 2022-06-23 18:43:01.058929
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        formatter_class=HTTPieHelpFormatter
    )
    parser.add_argument('--foo', help="""\
A longer description
with newlines.
""")
    parser.add_argument('bar', help="""\
Short desc
   with newlines
""")
    parser.add_argument('baz', help="""\
Short
description
for option.
""")
    parser.print_help()


# Generated at 2022-06-23 18:43:06.381395
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # os.environ.clear()
    # assert HTTPieArgumentParser().parse_args("httpbin.org").url == "httpbin.org", "Simple call to httpbin.org"
    pass
# end unit test for method parse_args of class HTTPieArgumentParser



# Generated at 2022-06-23 18:43:17.645613
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    # Case 1: normal case
    httpiehelp = HTTPieHelpFormatter()
    # print(httpiehelp._split_lines('this is a test\nstring', 20))
    assert httpiehelp._split_lines('this is a test\nstring', 20) == ['this is a test', 'string', '', '']
    # Case 2: blank text
    httpiehelp = HTTPieHelpFormatter()
    assert httpiehelp._split_lines('', 20) == ['', '']
    # Case 3: end with a new line character
    httpiehelp = HTTPieHelpFormatter()
    # print(httpiehelp._split_lines('this is a test\nstring\n', 20))

# Generated at 2022-06-23 18:43:19.513602
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    assert formatter is not None


# Generated at 2022-06-23 18:43:28.628474
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # Test 1: No traceback to be displayed
    try:
        HTTPieArgumentParser(None, raise_error_traceback=False)

    except:
        assert False, "HTTPieArgumentParser() threw an exception:" + "\n" + traceback.format_exc()

    # Test 2: Traceback to be displayed
    try:
        HTTPieArgumentParser(None, raise_error_traceback=True)

    except:
        assert True, "HTTPieArgumentParser() threw an exception:" + "\n" + traceback.format_exc()



# Generated at 2022-06-23 18:43:34.531602
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    import sys, io
    sys.stdin = sys.__stdin__ = io.StringIO()
    sys.modules['requests'] = requests
    # sys.modules['httpie.plugins'] = httpie.plugins
    from httpie import httpie

    parser = httpie.HTTPieArgumentParser()
    # parser.print_usage()
    args = parser.parse_args()
    print(args)



# Generated at 2022-06-23 18:43:39.209403
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=HTTPieHelpFormatter)
    parser.add_argument("-a", "--aaa",
                        help="test help\nfor\nabc\nabc\nabc")
    try:
        parser.parse_args("--help".split())
    except SystemExit:
        pass



# Generated at 2022-06-23 18:43:48.474753
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    from httpie.cli.argtypes import KeyValueArgType
    from textwrap import dedent

    parser = argparse.ArgumentParser(
        description='desc',
        formatter_class=HTTPieHelpFormatter,
    )
    parser.add_argument(
        '--auth-type', dest='auth_type',
        choices=('basic', 'digest'),
        help=dedent("""\
            The authentication mechanism to be used.
            Get more information from the following link:
            https://docs.python.org/3/library/http.client.html#http.client.HTTPDigestAuth
        """),
    )
    opts = parser.parse_args(args=[])
    assert opts.auth_type is None



# Generated at 2022-06-23 18:43:52.033569
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    kwargs = {}
    args = (6, )
    formatter_tester = HTTPieHelpFormatter(*args, **kwargs)
    assert formatter_tester.max_help_position == 6





# Generated at 2022-06-23 18:43:55.861552
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    # 1. check the default formatter
    default_formatter = HTTPieHelpFormatter()
    assert default_formatter.max_help_position == 6
    # 2. check the custom formatter
    custom_formatter = HTTPieHelpFormatter(max_help_position=10)
    assert custom_formatter.max_help_position == 10



# Generated at 2022-06-23 18:43:57.542969
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    h = HTTPieHelpFormatter()


# Generated at 2022-06-23 18:44:09.343491
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    #
    class MockArgumentParser:
        # Just for testing
        def __init__(self):
            self.description = ''
            self.epilog = ''
            self.optionals = []

    #
    parser = MockArgumentParser()
    formatter = HTTPieHelpFormatter(parser)
    #
    assert formatter._max_help_position == 6
    #
    assert formatter._width == 80
    #
    assert formatter._whitespace_matcher is re.compile('\s+')
    #
    assert (
        formatter._long_break_matcher
        is re.compile(r'(\n\n|[^\n]\n(?=[^\n])|\*\*[^\*]+\*\*)')
    )
    #
    assert form

# Generated at 2022-06-23 18:44:17.232812
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    # Example:
    # --verbose
    #   [h|--headers]
    #   [b|--body]
    #   [q|--querystring]
    #   [f|--follow]
    #   [a|--all] (implies -b, -h, -q, -f)
    help_text = """
    [h|--headers]
    [b|--body]
    [q|--querystring]
    [f|--follow]
    [a|--all] (implies -b, -h, -q, -f)"""

# Generated at 2022-06-23 18:44:24.883995
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Unit test for method parse_args of class HTTPieArgumentParser
    from mock import patch
    from .utils import MockEnvironment

    args = [
        '--form', '--json', '--auth-type', 'implicit',
        'https://httpbin.org/anything',
        'x==1', 'y==2',
        '--follow', '--max-redirects', '10',
        '--ignore-stdin',
        '--output', 'output.json',
        '--download', '--download-resume',
        '--print', 'hb', '--pretty', 'all',
        '--debug'
    ]


# Generated at 2022-06-23 18:44:38.122979
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['GET', 'http://localhost:8080'])
    assert args.url == 'http://localhost:8080'
    assert args.method == 'GET'
    assert args.output_file is None
    assert args.download is False
    assert args.download_resume is False
    assert args.timeout is None
    assert args.max_redirects is None
    assert args.session == ''
    assert args.session_read_only is False
    assert args.follow is False
    assert args.check_status is False
    assert args.check_ssl is False
    assert args.ignore_stdin is False
    assert args.output_options is None
    assert args.output_options_history is None
    assert args.verbose is False
    assert args

# Generated at 2022-06-23 18:44:50.458277
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    args = ['-A', 'curl', '--json', '--download', '--output', 'out', 'http://example.org/']
    env = Environment(stdout=six.StringIO(), stdout_isatty=True)
    parser = HTTPieArgumentParser(args=args, env=env)

    # Check the applied environment gets correct stdout and stdout_isatty
    assert(parser.env.stdout.getvalue() == ''), 'The stdout should be empty'
    assert(parser.env.stdout_isatty), 'The stdout_isatty should be true'

    # Check the construction of HTTPieArgumentParser
    parser.parse_args(args=args)
    assert(parser.args.user_agent == 'curl'), 'The user agent should be curl'

# Generated at 2022-06-23 18:44:57.146361
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter(10)
    # string to be dedented and stripped before splitting into multiple lines
    text = """\
        One.
        Two.
        
        Three.
        """
    lines = formatter._split_lines(text, 15)
    assert(lines == ['One.', 'Two.', '', 'Three.', ''])



# Generated at 2022-06-23 18:45:01.112115
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """
    Unit test for HTTPieArgumentParser.parse_args method
    """
    pass
### End of unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-23 18:45:07.618830
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=HTTPieHelpFormatter)
    parser.add_argument('--foo', help="""\
    Description of a very long argument that
    should be splitted...""")
    parser.add_argument('bar', help="""\
    Description of a very long argument that
    should be splitted...""")
    parser.add_argument('-b', '--baz', help="""\
    Description of a very long argument that
    should be splitted...""")
    parser.print_help()
    print()
    parser.print_usage()
    print()



# Generated at 2022-06-23 18:45:09.823372
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO: Add tests here to verify that your code works
    raise NotImplementedError()

# Generated at 2022-06-23 18:45:12.961643
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    http_argparse = HTTPieArgumentParser()
    http_argparse._print_message(message='Hello World!')

# Generated at 2022-06-23 18:45:20.265372
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # Parse from string
    args = HTTPieArgumentParser().parse_args('http GET https://www.baidu.com/ --verify=True')
    assert(args.method == 'GET')
    assert(args.url == 'https://www.baidu.com/')
    assert(args.verify == True)

    # Parse from sys.argv
    sys.argv = ['http', 'GET', 'https://www.baidu.com/', '--verify=True']
    args = HTTPieArgumentParser().parse_args()
    assert(args.method == 'GET')
    assert(args.url == 'https://www.baidu.com/')
    assert(args.verify == True)


# Generated at 2022-06-23 18:45:30.339390
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Create the parser to test
    parser=HTTPieArgumentParser()

    # Require all args to be present, *except* the ones mentioned below

# Generated at 2022-06-23 18:45:41.538235
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    class MockArgumentParser(argparse.ArgumentParser):
        def __init__(self, *args, **kwargs):
            self.prog = "MyProgram"
            #self.add_argument = Mock()
            argparse.ArgumentParser.__init__(self, *args, **kwargs)
            
    parser = MockArgumentParser(
        usage="usage",
        description="description",
        epilog="epilog",
        formatter_class=HTTPieHelpFormatter)
    parser.print_help()

# arguments can be indented and contain new lines.
# It will be de-dented and arguments in the help
# will be separated by a blank line for better readability.

# Generated at 2022-06-23 18:45:47.864077
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    p = argparse.ArgumentParser(
        description='foo',
        formatter_class=HTTPieHelpFormatter
    )
    p.add_argument('--bar', help='''
        bar
        bar
        bar''')
    help = p.format_help()
    assert help == dedent('''
    usage: <unknown> [-h] [--bar BAR]

    foo

    optional arguments:
      -h, --help  show this help message and exit
      --bar BAR   bar
                  bar
                  bar
    ''').strip()


# Generated at 2022-06-23 18:45:59.929887
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # Test for HTTPieArgumentParser constructor
    parser = HTTPieArgumentParser()
    assert parser.error == argparse.ArgumentParser.error
    assert parser._print_message == argparse._sys.stderr.write

# Generated at 2022-06-23 18:46:02.556856
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert len(HTTPieHelpFormatter._split_lines.__doc__) > 0


# Generated at 2022-06-23 18:46:13.344811
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """Unit test for method parse_args of class HTTPieArgumentParser"""
    arguments = [
        '--body',
        'test.json',
        '--download',
        'http://httpbin.org/status/418',
        '--form',
        '--headers',
        'Accept:application/json',
        'Content-Type:application/json',
        '--method',
        'GET',
        '--output',
        'test.txt',
        '--pretty',
        'none',
        '--print',
        'b',
        '--verbose',
        '--verify',
        'no'
    ]
    # ensure code runs
    parser = HTTPieArgumentParser()
    parsed = parser.parse_args(arguments)
    # check returned object

# Generated at 2022-06-23 18:46:17.391097
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    def _check_help_formatter(self, expected, string):
        self.assertEqual(HTTPieHelpFormatter._split_lines(self, string, 1000), expected)
    _check_help_formatter(None, "\ndedented\nstr\n", ["dedented", "str", "", ""])



# Generated at 2022-06-23 18:46:21.721341
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    long_help="""\
    foo
      bar
    """
    formatter = HTTPieHelpFormatter(allow_long_help=True)
    assert len(formatter._split_lines(long_help, 80)) == 2
    assert formatter._split_lines(long_help, 80)[0] == 'foo'
    assert formatter._split_lines(long_help, 80)[1] == '  bar'


# Generated at 2022-06-23 18:46:32.830994
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """
    Unit test for method parse_args of class HTTPieArgumentParser
    """
    # Test 1: Test with arguments
    args = ['localhost', '--print=b']
    input_arguments = HTTPieArgumentParser().parse_args(args)
    assert(input_arguments.url == 'localhost')
    assert(input_arguments.output_options == 'b')

    # Test 2: Test with empty arguments
    args = []
    with pytest.raises(argparse.ArgumentError):
        input_arguments = HTTPieArgumentParser().parse_args(args)

# Generated at 2022-06-23 18:46:37.344544
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    help_formatter = HTTPieHelpFormatter()
    assert help_formatter._split_lines("""
    Get file from remote server.

    Response will be saved in file.

    """, 80) == ["Get file from remote server.", "", "Response will be saved in file.", "", ""]



# Parser for request body

# Generated at 2022-06-23 18:46:41.702028
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    '''
    >>> formatter = HTTPieHelpFormatter(max_help_position=3)
    >>> formatter._split_lines('  foo\\n  bar\\n\\n  baz', 80)
    ['foo', 'bar', '', 'baz']
    '''



# Generated at 2022-06-23 18:46:45.248385
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    """Test case for constructor of class HTTPieHelpFormatter."""
    HttpHelpFormatter = HTTPieHelpFormatter()
    assert HTTPieHelpFormatter is HttpHelpFormatter


# Generated at 2022-06-23 18:46:50.563632
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    try:
        import subprocess
        import sys
        import requests
        import httpie
        subprocess.check_call([sys.executable, "-m", "httpie.cli", "--help"])
    except Exception as e:
        print('ERROR', e)
        return False
    return True


# Generated at 2022-06-23 18:46:58.828894
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    arg_parser = HTTPieArgumentParser(
        name=__name__,
        prog='http',
        version=__version__,
        description=__doc__,
        epilog='''\
`http URL` is a shortcut for `http GET URL`
        '''
    )
    # Unit test for public method set_defaults

# Generated at 2022-06-23 18:47:08.958171
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Initialize class instance
    HTTPieArgumentParser_inst = HTTPieArgumentParser()

    # Command on which to perform unit test
    cmd = ['http', 'post', 'http://httpbin.org/post', 'name=Darth Vader']

    try:
        # Parse command
        parsed_cmd = HTTPieArgumentParser_inst.parse_args(cmd)

        # Success signals
        print("parse_args() has functioned as expected")
        print("\nParsed command:\n{0}".format(parsed_cmd))

    except:
        # Error message
        print("parse_args() has NOT functioned as expected")
        # Print error
        traceback.print_exc()


# Generated at 2022-06-23 18:47:12.186672
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    httpie_help_formatter = HTTPieHelpFormatter()
    assert httpie_help_formatter.max_help_position == 6


# Generated at 2022-06-23 18:47:21.910946
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    print('test HTTPieArgumentParser_parse_args')
    args = ['http', '--json']
    parser = HTTPieArgumentParser()
    parser.parse_args(args)
    args = ['http', '--json', 'get']
    parser = HTTPieArgumentParser()
    parser.parse_args(args)
    args = ['http', '--json', 'get', '--style=solarized']
    parser = HTTPieArgumentParser()
    parser.parse_args(args)
    args = ['http', '--json', 'get', '--style=solarized', 'http://poi.com']
    parser = HTTPieArgumentParser()
    parser.parse_args(args)

test_HTTPieArgumentParser_parse_args()