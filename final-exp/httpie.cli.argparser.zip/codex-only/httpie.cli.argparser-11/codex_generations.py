

# Generated at 2022-06-23 18:37:33.823912
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    print("\n---\n HTTPieArgumentParser_parse_args(self, args=None, namespace=None)")
    parser = HTTPieArgumentParser()
    parser.parse_args(['--download','--output','test.txt','https://postman-echo.com/get','foo=bar'])
    print(parser.args)
    parser.parse_args(['--download','--output','test.txt','--method','POST','https://postman-echo.com/get','foo=bar'])
    print(parser.args)



# Generated at 2022-06-23 18:37:43.699211
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-23 18:37:45.201647
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert isinstance(parser, HTTPieArgumentParser)



# Generated at 2022-06-23 18:37:48.681609
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from tempfile import NamedTemporaryFile
    from httpie.core import main
    
    tempFile = NamedTemporaryFile()
    tempFile.close()
    output = main(args=['--verbose',
            '--output=%s'%tempFile.name,
            'https://httpbin.org/ip'])
    assert output == 0

# Generated at 2022-06-23 18:37:58.209218
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        prog='http',
        formatter_class=HTTPieHelpFormatter,
        description='The foo option:\n  line1\n  line2',
        epilog='The bar argument:\n  line1\n  line2',
        add_help=False)
    parser.add_argument('--foo', help='foo')
    parser.add_argument('bar', help='bar')
    help_text = parser.format_help()

# Generated at 2022-06-23 18:38:05.977125
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    args = [
        '--style', 'solarized', 
        '--style-scheme', 'solarized',
        '--verbose',
        '--print', '',
        'http://www.w3school.com.cn/',
        '--output'
    ]
    parser = HTTPieArgumentParser()
    parser.parse_args(args)

    if __name__ == '__main__':
        parser.print_help()

if __name__ == '__main__':
    test_HTTPieArgumentParser()

# Generated at 2022-06-23 18:38:11.645420
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    help = "\"servers\",\n\"servers\":\n\"servers\""
    formatter = HTTPieHelpFormatter(max_help_position=20)
    lines = formatter._split_lines(help, 20)
    assert lines == ['"servers",', '"servers":', '"servers"']



# Generated at 2022-06-23 18:38:13.934250
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert HTTPieHelpFormatter('test').max_help_position == 'test'


# Generated at 2022-06-23 18:38:23.052125
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    epilog = """
        Colored output can be configured with --style and --style-sheet option.

        For further, detailed syntax help, see the docs on
        <http://httpie.org>.
        """
    desc = """\
        An HTTP client, a user-friendly cURL replacement.
        """
    #
    # Usage:y
    #   http [--json] [--form] [--pretty <all|colors|format>] [--print <all|body|headers|status>]
    #        [--style <style>] [--style-sheet <file>] [--verbose] [--headers] [--body]
    #        [--ignore-stdin] [--auth-type <basic|digest>] [--auth <user:password>] [--proxy <proxy>]
    #        [--follow] [--max-redirect

# Generated at 2022-06-23 18:38:27.501042
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    text = 'Example:\n    foo\n    bar'
    assert formatter._split_lines(text, 80) == ['Example:', 'foo', 'bar', '']
# Unit test end



# Generated at 2022-06-23 18:38:37.914230
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    p = argparse.ArgumentParser(
        formatter_class=HTTPieHelpFormatter)
    p.add_argument(
        '-f', dest='format', choices=['json', 'colon'],
        help='\n\
            The output format.\n\
            \n\
            The default is pretty JSON, except if stdout is redirected\n\
            when the default becomes colon-separated values.\n\
            \n\
            Choices:\n\
            \n\
            http://httpie.org/doc#output-options\n\
        ')
    test_str = textwrap.dedent(test_HTTPieHelpFormatter.__doc__)
    argparse.ArgumentParser().parse_args(test_str.split())



# Generated at 2022-06-23 18:38:39.924107
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert HTTPieHelpFormatter.__init__ != RawDescriptionHelpFormatter.__init__


# Generated at 2022-06-23 18:38:51.889985
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Unit test for method parse_args of class HTTPieArgumentParser
    # Test 1
    args = ['--ignore-stdin', 'http://www.example.com', 'User-Agent:HTTPie/0.8.0', 'Accept:*/*', 'Accept-Encoding:gzip,deflate', 'Host:httpbin.org']
    parser = HTTPieArgumentParser()
    args = parser.parse_args(args)
    assert args.ignore_stdin == True
    assert args.url == 'http://www.example.com'
    assert args.headers == [('User-Agent', 'HTTPie/0.8.0'), ('Accept', '*/*'), ('Accept-Encoding', 'gzip, deflate'), ('Host', 'httpbin.org')]
    # Test 2

# Generated at 2022-06-23 18:38:56.711728
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        prog='http', formatter_class=HTTPieHelpFormatter)
    parser.add_argument(
        '--foo', help="""\
        Some help for the --foo argument.

        The help can span multiple lines.
        """
    )


# Generated at 2022-06-23 18:39:05.048031
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-23 18:39:13.397064
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    pytest.debug_func()
    parser = HTTPieArgumentParser()
    parser.debug_func()
    #parser.setup()
    #parser.add_argument('-v', '--verbose', action='store_true')
    #parser.add_argument('-o', '--output', help='Output file')
    #parser.add_argument('-O', '--output-options', help='Output options')
    parser.parse_args(['http://example.com/'])

 


# Generated at 2022-06-23 18:39:20.162703
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """This is a unit test for the class HTTPieArgumentParser
    """

# Generated at 2022-06-23 18:39:30.197816
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert isinstance(parser, HTTPieArgumentParser)

    # Unit test for _alter_request_item_args of class HTTPieArgumentParser
    def test__alter_request_item_args():
        args = parser._alter_request_item_args([])
        assert isinstance(args, list)
        assert args == []

        args = parser._alter_request_item_args([':method', 'GET'])
        assert isinstance(args, list)
        assert args == ['method', 'GET']

        args = parser._alter_request_item_args(['GET'])
        assert isinstance(args, list)
        assert args == ['url', 'GET']

        args = parser._alter_request_item_args(['http://httpbin.org/get'])
        assert isinstance

# Generated at 2022-06-23 18:39:43.152230
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    args = HTTPieArgumentParser().parse_args()

    assert args.config_dir == os.path.expanduser('~') + os.sep + '.config' + os.sep + 'httpie'
    assert args.config_path == None
    assert args.config_file == None
    assert args.all == False
    assert args.body == None
    assert args.check_status == True
    assert args.colors == None
    assert args.crawl == False
    assert args.debug == False
    assert args.download == False
    assert args.download_resume == False
    assert args.explain == False
    assert args.json == False
    assert args.offline == False
    assert args.output_file == None
    assert args.output_file_specified == False

# Generated at 2022-06-23 18:39:43.952220
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    assert formatter



# Generated at 2022-06-23 18:39:46.812308
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    arg1 = '--verify=False'
    arg2 = 'https://httpbin.org/get'
    args = parser.parse_args([arg1, arg2])
    assert args.verify.value is False
    assert args.url == 'https://httpbin.org/get'

test_HTTPieArgumentParser_parse_args()

# Response class


# Generated at 2022-06-23 18:39:59.688082
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    class TestHTTPieHelpFormatter(HTTPieHelpFormatter):
        pass
    parser = argparse.ArgumentParser(
        description="", formatter_class=TestHTTPieHelpFormatter)
    parser.add_argument(
        "--test",
        type=int,
        help="""
        This is a test.

        And it is multiline.
        """
    )
    parser.print_help()


DEFAULT_METHOD = HTTP_GET
DEFAULT_DATA_CONTENT_TYPE = 'application/x-www-form-urlencoded; charset=utf-8'
DEFAULT_VERBOSE_LEVEL = 0
DEFAULT_PAGER = os.environ.get('PAGER', 'less')
DEFAULT_VERIFY = True
# Default Accept header value.

# Generated at 2022-06-23 18:40:01.450822
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert isinstance(HTTPieHelpFormatter(), HTTPieHelpFormatter)


# Generated at 2022-06-23 18:40:06.831661
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    text = '''foo bar

        foo bar
        foo bar
            foo bar

    foo bar
        '''
    assert list(HTTPieHelpFormatter()._split_lines(text, 80)) == [
        'foo bar',
        '',
        'foo bar',
        'foo bar',
        '    foo bar',
        '',
        'foo bar',
        '',
    ]



# Generated at 2022-06-23 18:40:17.475236
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args()
    assert not args.request_items
    assert args.method is None
    assert args.headers is None
    assert args.data is None
    assert args.params is None
    assert args.files is None
    assert 'url' not in args
    assert not args.output_file_specified
    assert not args.output_file_specified
    assert args.output_options == 'hb'
    assert args.output_options_history == 'hb'
    assert not args.verbose
    assert not args.print_body_only
    assert not args.debug
    assert args.prettify == PRETTY_STDOUT_TTY_ONLY
    assert not args.download
    assert args.download_resume
    assert not args.offline
   

# Generated at 2022-06-23 18:40:26.636325
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import io, sys, tempfile
    from copy import deepcopy as dc
    from os.path import exists as pexists, join as pjoin, dirname
    from httpie import __main__ as cli
    from httpie.core import __version__ as httpie_version
    import httpie.core
    from httpie.compat import is_py26
    from httpie.output.streams import DL_SENTINEL
    from httpie.input import SEP_CREDENTIALS
    from httpie.input import parse_items, KeyValueArgType
    from httpie.plugins import plugin_manager
    from httpie.plugins.builtin import AuthPlugin, HttpiePlugin

# Generated at 2022-06-23 18:40:29.137340
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    parser.add_argument('-s', '--sillysilly', default='',
                        help='silly silly')
    args = parser.parse_args(['--sillysilly', 'silly'])
    assert args.sillysilly == 'silly'

test_HTTPieArgumentParser()

# Generated at 2022-06-23 18:40:36.519055
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    help_text = """\
        Usage: http [OPTIONS] URL [ITEM [ITEM]]
        Options:
            --arg        value   Some argument.
        """
    parser = argparse.ArgumentParser(
        description='description',
        formatter_class=HTTPieHelpFormatter,
    )
    parser.add_argument('--arg')
    assert parser.format_help() == dedent(help_text) + '\n'



# Generated at 2022-06-23 18:40:38.193900
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    parser.parse_args()

# Generated at 2022-06-23 18:40:42.406763
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    with pytest.raises(ValueError, match=r'^Expected an absolute URL, got .*'):
        HTTPieArgumentParser(prog='http', env='testing.env')

# Generated at 2022-06-23 18:40:48.023209
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=HTTPieHelpFormatter)
    parser.add_argument(
        '--foo',
        help='''\
         foo to your baz.

         Choose wisely
        '''
    )
    help_text = parser.format_help()
    assert 'foo to your baz' in help_text
    assert 'Choose wisely' in help_text



# Generated at 2022-06-23 18:40:53.123424
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        formatter_class=HTTPieHelpFormatter)
    parser.add_argument('foo')
    args = parser.parse_args(['--help'])
    print(args)
    return 0



# Generated at 2022-06-23 18:41:02.631897
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    HTTPieArgumentParser_parse_args = HTTPieArgumentParser.parse_args

# Generated at 2022-06-23 18:41:12.684151
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    help_string = '''
    This is the help message
    of this program. It can span
    multiple lines.'''
    args_help = '''
    -h --help     Show this help
    -v --version  Show version
    '''
    parser = argparse.ArgumentParser(formatter_class=HTTPieHelpFormatter)
    parser.add_argument('-h', '--help', action='help', help=help_string)
    parser.add_argument('-v', '--version', action='version', version='2.0.0')
    help_message = parser.format_help()
    first_blank_line = help_message.find('\n\n')
    assert help_message[:first_blank_line] == help_string.strip()
    second_blank_line = help_message.find

# Generated at 2022-06-23 18:41:16.044959
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    text_to_parse = '''
    this is a

    test
    '''
    assert formatter._split_lines(text_to_parse, 80) == [
        'this is a',
        '',
        'test',
        ''
    ]



# Generated at 2022-06-23 18:41:23.121526
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    from httpie.core import __version__ as httpie_version
    from httpie.status import ExitStatus

    class MockEnvironment:
        stdin = sys.stdin
        stdin_isatty = True
        stdout = sys.stdout
        stdout_isatty = True
        stderr = sys.stderr
        stderr_isatty = True

        @property
        def is_windows(self):
            return False

    class MockExitStatus:
        def __init__(self, args):
            self.args = args

    class MockArgumentParser(HTTPieArgumentParser):
        def __init__(self, *args, **kwargs):
            self.args = {}
            super().__init__(*args, **kwargs)


# Generated at 2022-06-23 18:41:35.320640
# Unit test for constructor of class HTTPieHelpFormatter

# Generated at 2022-06-23 18:41:46.242245
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.env = Environment()
    parser.args = parser.parse_args([])
    assert parser.args.auth_type == None
    assert parser.args.auth_plugin == None
    assert parser.args.check_status == True
    assert parser.args.compress == False
    assert parser.args.download == False
    assert parser.args.download_resume == False
    assert parser.args.download_session == False
    assert parser.args.download_timeout == 1800
    assert parser.args.download_max_size == None
    assert parser.args.download_max_redirects == 5
    assert parser.args.output_file == None
    assert parser.args.output_file_specified == False
    assert parser.args.pretty == None

# Generated at 2022-06-23 18:41:56.994751
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    """
    Example from httpbin-cli
    """
    d = {'y': 'foo', 'z': 'bar'}
    class MyClass():
        def __init__(self, arg1, arg2, arg3='default', arg4=['a', 'b']):
            self.arg1 = arg1
            self.arg2 = arg2
            self.arg3 = arg3
            self.arg4 = arg4
        def __str__(self):
            return 'arg1: {}\narg2: {}\narg3: {}\narg4: {}'.format(
                self.arg1,
                self.arg2,
                self.arg3,
                self.arg4,
            )
    parser = argparse.ArgumentParser(description='description')

# Generated at 2022-06-23 18:42:02.723789
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    # parameter value
    args = "http://httpbin.org/get".split()

#     args = parser.parse_args(args)

#     parser.finalize_parse(args)
from httpie.core import main

from httpie.plugins import plugin_manager
from httpie.output.streams import ColorizedStream



# Generated at 2022-06-23 18:42:09.969090
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    class MockParser(object):
        def __init__(self):
            self.description = 'description'
            self.usage = 'usage'
            self.prog = 'http'
            self.epilog = 'epilog'
            self.parents = []
            self.formatter_class = argparse.RawDescriptionHelpFormatter
        def error(self, message):
            raise Exception(message)
        def add_argument(self, *args, **kwargs):
            pass

    mock_parser = MockParser()
    httpie_argument_parser = HTTPieArgumentParser(mock_parser, '/path/to/http')

    assert httpie_argument_parser.parser == mock_parser
    assert httpie_argument_parser.httpie_path == '/path/to/http'

# Generated at 2022-06-23 18:42:11.962468
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    
    parser = HTTPieArgumentParser()
    
    parser.parse_args(['--help'])

# Generated at 2022-06-23 18:42:21.120560
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
  default = {}
  default['script'] = None
  default['quiet'] = False
  default['method'] = None
  default['headers'] = None
  default['data'] = None
  default['params'] = None
  default['files'] = None
  default['ignore_stdin'] = False
  default['traceback'] = False
  default['output_file'] = None
  default['output_options'] = None
  default['output_options_history'] = None
  default['download'] = False
  default['download_resume'] = False
  default['timeout'] = None
  default['max_redirects'] = None
  default['verify'] = None
  default['cert'] = None
  default['auth'] = None
  default['auth_type'] = None
  default['auth_plugin'] = None
  default

# Generated at 2022-06-23 18:42:25.807262
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    argv = ['--pretty=all', 'https://httpie.org/']
    kwargs = {'env':Environment(), 'prog':'http', 'args_override':argv}
    # method parse_args() returns a Namespace object
    args = HTTPieArgumentParser(**kwargs).parse_args()
    assert args.__class__ == argparse.Namespace
    assert args.pretty == ['all']
    assert args.url == 'https://httpie.org/'

# Generated at 2022-06-23 18:42:29.412515
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():

    """
    Test function for constructor of class HTTPieArgumentParser.
    See if the HTTPieArgumentParser object is constructed
    """

    # create object for HTTPieArgumentParser
    parser = HTTPieArgumentParser()
    assert isinstance(parser, HTTPieArgumentParser) == True


# Generated at 2022-06-23 18:42:31.743145
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # TODO:
    args = HTTPieArgumentParser.parse_args([])
    assert args.output == 'all', 'default value of output is not "all"'


# Generated at 2022-06-23 18:42:38.534069
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Given a $parser and some $args
    parser = HTTPieArgumentParser()
    args = [
    ]

    # Then Result should be

# Generated at 2022-06-23 18:42:40.922429
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    args = HTTPieArgumentParser().parse_args(['--version'])
    assert args.version is True
    args = HTTPieArgumentParser().parse_args(['get'])
    assert args.method == 'get'

# Generated at 2022-06-23 18:42:52.329501
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    for args_string in ["$ http -h", "$ http -hv", "$ http get -h",
                        "$ http get -hv", "$ http post -h", "$ http post -hv",
                        "$ http --help", "$ http --help-all", "$ http -hv",
                        "$ http get --help", "$ http get --help-all",
                        "$ http post --help", "$ http post --help-all",
                        "$ http --version", "$ http --json", "$ http --stat-code",
                        "$ http --elide", "$ http --traceback", "$ http --print=h",
                        "$ http --print=H"]:
        with capture_stderr(HTTPieArgumentParser().parse_args, args_string) as stderr:
            if args_string == "$ http --version":
                assert True

# Generated at 2022-06-23 18:42:57.411994
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # HTTPieArgumentParser.__init__
    assert HTTPieArgumentParser(None)
    assert HTTPieArgumentParser([])
    assert HTTPieArgumentParser(['testing'])
    assert HTTPieArgumentParser(['testing', 'testing2'])
    assert not HTTPieArgumentParser(['testing', 'testing2', 'testing3'])



# Generated at 2022-06-23 18:43:10.465420
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        prog='http',
        formatter_class=HTTPieHelpFormatter
    )
    parser.add_argument('--foo', help="""
        Lorem ipsum dolor sit amet, consectetur adipisicing elit,
        sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
        Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris
        """)

# Generated at 2022-06-23 18:43:13.531370
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    """Test the constructor of class HTTPieHelpFormatter."""
    # The constructor class HTTPieHelpFormatter
    assert HTTPieHelpFormatter()



# Generated at 2022-06-23 18:43:24.240545
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    description = "TEST\nTEST\nTEST"
    epilog = "TEST\nTEST\nTEST"
    try:
        parser = argparse.ArgumentParser(description=description, epilog=epilog, formatter_class=HTTPieHelpFormatter)
        parser.add_argument("-d", "--date", action="store_true", help="display the date in an easy-to-read format")
        parser.parse_args()
    except SystemExit:
        pass


# Generated at 2022-06-23 18:43:29.116640
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    if __name__ == '__main__':
        parser = argparse.ArgumentParser(
            description='test',
            formatter_class=HTTPieHelpFormatter)
        parser.add_argument('--foo', help='foo\nbar\nbaz')
        parser.print_help()


# Generated at 2022-06-23 18:43:38.428282
# Unit test for constructor of class HTTPieHelpFormatter

# Generated at 2022-06-23 18:43:42.767465
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    parser.init_parser_props()
    parser.parse_args(['https://m.baidu.com'])
    parser.print_help()

if __name__ == '__main__':
    test_HTTPieArgumentParser()

# Generated at 2022-06-23 18:43:46.042838
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert parser.args.verbose == False

# Generated at 2022-06-23 18:43:46.992682
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-23 18:43:56.513575
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    httpie = HTTPie()

    class TestHTTPieArgumentParser(ArgumentParser, HTTPieArgumentParser):
        pass

    httpie_argument_parser = TestHTTPieArgumentParser(
        httpie,
        usage=get_usage(),
        description=get_description(),
        add_help=False,
        allow_interspersed_args=False,
        formatter_class=RawDescriptionHelpFormatter,
        prog=PROG,
    )


# Generated at 2022-06-23 18:44:06.494309
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    class Dummy:
        formatter = HTTPieHelpFormatter()
        parser = argparse.ArgumentParser(description=__doc__,
                                         formatter_class=formatter)
        parser.add_argument('--foo', help='''
        lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
        eiusmod tempor incididunt ut labore et dolore magna aliqua.
        ''')
        parser.add_argument('bar', help=argparse.SUPPRESS)
        print(parser.format_help())

# print help message
test_HTTPieHelpFormatter()


# Generated at 2022-06-23 18:44:18.995484
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-23 18:44:21.766188
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    #class parser(object): pass
    #p=parser()
    httpie_argument_parser=HTTPieArgumentParser()
    print(httpie_argument_parser)


# Generated at 2022-06-23 18:44:29.382808
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    args_dict = {"headers": "{'Test: 123'}",
                 "method": "get",
                 "url": "http://127.0.0.1/",
                 "max_headers": "{'Test': '123'}",
                 "run_data": "{'Test': '123'}"}
    args = argparse.Namespace(**args_dict)

# Generated at 2022-06-23 18:44:40.444519
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    help = HTTPieHelpFormatter(max_help_position=61)
    help.add_argument('--test1',
                      help='Example help for --test1 argument\n'
                           'with two lines')
    help.add_argument('--test2',
                      help='Example help for --test2 argument\n'
                           'with two lines')
    help_str = help.format_help()
    # Check especially that the two arguments are separated by a blank line

# Generated at 2022-06-23 18:44:46.391318
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['https://httpstat.us/200'])
    assert args.url == 'https://httpstat.us/200'
    assert args.headers == {}
    assert args.data == {}
    assert args.files == {}
    assert args.params == {}

    args = parser.parse_args(['https://httpstat.us/200', 'Accept-Encoding:gzip'])
    assert args.url == 'https://httpstat.us/200'
    assert args.headers == {'Accept-Encoding': 'gzip'}
    assert args.data == {}
    assert args.files == {}
    assert args.params == {}


# Generated at 2022-06-23 18:44:55.163026
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    args = HTTPieArgumentParser(env=Env()).parse_args(
        ['--json'])
    assert(args.output_options == 'H')

    args = HTTPieArgumentParser(env=Env()).parse_args(
        ['--style', 'monokai'])
    assert(args.output_options == 'H')

    args = HTTPieArgumentParser(env=Env()).parse_args(
        ['--style', 'none'])
    assert(args.output_options == 'H')

# Generated at 2022-06-23 18:45:05.642070
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Arrange
    parser_args = parser._get_args()
    usage_args = ['https://httpbin.org/get']


# Generated at 2022-06-23 18:45:19.304410
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # test HTTPieArgumentParser.parse_args() with a simplest case
    arg_parser = HTTPieArgumentParser()
    arg_parser.set_env(Environment(stdin=sys.stdin,
                                   stdin_isatty=False,
                                   stdout=sys.stdout,
                                   stdout_isatty=True,
                                   stderr=sys.stderr,
                                   stderr_isatty=True))

# Generated at 2022-06-23 18:45:20.495753
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    hpf = HTTPieHelpFormatter()



# Generated at 2022-06-23 18:45:22.851282
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    #HTTPieArgumentParser()
    pass

# Generated at 2022-06-23 18:45:26.742219
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    test_str = formatter._split_lines('''\
    this line is one
    this line is two
    this line is three
    ''', 70)
    assert test_str == ['this line is one',
                        'this line is two',
                        'this line is three',
                        '',
                        '']



# Generated at 2022-06-23 18:45:37.776010
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    parser.header_overrides.add_group('User-Agent', ['curl/7.54.0'])
    assert parser.header_overrides.get('User-Agent') == ['curl/7.54.0']
    parser.header_overrides.add_group('Accept', ['**/*'])
    assert parser.header_overrides.get('Accept') == ['**/*']
    parser.header_overrides.add_group('Accept', ['*/*'])
    assert parser.header_overrides.get('Accept') == ['**/*', '*/*']
    parser.header_overrides.add_group('Accept-Encoding', ['gzip'])
    assert parser.header_overrides.get('Accept-Encoding') == ['gzip']

# Generated at 2022-06-23 18:45:47.006505
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    """Test if it can format help with args from constructor"""
    from argparse import ArgumentParser

    parser = ArgumentParser(
        description='HTTPie command line HTTP client.',
        usage="%(prog)s [options] [http://hostname[:port]/]path",
        formatter_class=HTTPieHelpFormatter
    )

    parser.add_argument(
        '--version',
        action='version',
        version='%%(prog)s %s' % __version__,
        help='Print the version and exit.'
    )

    parser.add_argument(
        '--debug',
        action='store_true',
        help='Show debug information.'
    )


# Generated at 2022-06-23 18:45:59.278895
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h = HTTPieArgumentParser()
    args = h._parse_args(['http', 'https://example.com'])
    assert args.url == 'https://example.com'
    assert not args.download
    assert not args.download_resume
    assert not args.form
    assert not args.ignore_netrc
    assert args.output_file is None
    assert not args.output_options_history
    assert args.headers == {}
    assert not args.method
    assert not args.multipart_data
    assert not args.params
    assert args.pretty == 'all'
    assert not args.querystring
    assert not args.request_items
    assert not args.session
    assert not args.silent
    assert not args.stream
    assert not args.traceback
    assert not args.verbose
   

# Generated at 2022-06-23 18:46:07.312650
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """ Unit tests for constructor of class HTTPieArgumentParser. """

    # This is initialised so that it can be passed to the constructor of class
    # HTTPieArgumentParser.
    environ = Environment()

    # SMTPArgumentParser is initialised with the argparse.ArgumentParser
    # constructor to test the constructor functionality.
    arg_parser = HTTPieArgumentParser(add_help=False, env=environ)
    args = arg_parser.parse_args([])

# Generated at 2022-06-23 18:46:10.121564
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    expected_args_help_indent = 14
    args_help_indent = HTTPieHelpFormatter()._current_indent

    assert args_help_indent == expected_args_help_indent



# Generated at 2022-06-23 18:46:19.490316
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    import argparse
    class TestCommand(object):
        def __init__(self, get_parser):
            self.get_parser = get_parser
    parser = argparse.ArgumentParser(
        prog='http',
        argument_default=argparse.SUPPRESS,
        formatter_class=HTTPieHelpFormatter,
        description='HTTPie does this and that.'
    )
    parser.add_argument('--foo',
                        help='The address to bind to locally.')
    parser.add_argument('bar',
                        help='The port to bind to locally.',
                        type=int)
    argv = ['--help']
    cmd = TestCommand(get_parser=lambda: parser)
    args = parser.parse_args(argv[1:])
    exit_ = 0

# Generated at 2022-06-23 18:46:33.100359
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    from tempfile import NamedTemporaryFile
    sut = HTTPieArgumentParser()
    temp_file = NamedTemporaryFile(delete=False)
    temp_file.write(b'I am test file contents')
    temp_file.close()
    # URL with username and password should work
    sut.args = sut.parse_args(['http', 'user@host.com', '#hello=world'])
    sut.finalize_parse()
    assert sut.args.url == 'user@host.com'
    assert sut.args.request_items[0].key == '#hello'
    assert sut.args.request_items[0].value == 'world'
    # URL with hostname should work

# Generated at 2022-06-23 18:46:37.930205
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    '''
    Unit test for constructor of class HTTPieArgumentParser
    '''
    parser = HTTPieArgumentParser()
    parser.exit = lambda status=0, message=None: None
    parser.error = lambda message: None
    parser.print_usage = lambda epilog: print(epilog)
    print(parser)



# Generated at 2022-06-23 18:46:42.807044
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    
    parser = HTTPieArgumentParser("Test parser")
    test_command_line_args = ["https://www.google.com/search?q=test"]
    args = parser.parse_args(test_command_line_args)
    assert args.url == test_command_line_args[0]
    
    return 

# Generated at 2022-06-23 18:46:45.806753
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    args = ['localhost']
    parser = HTTPieArgumentParser(args, env = Env())
    print(parser.args)

test_HTTPieArgumentParser()


# Generated at 2022-06-23 18:46:51.955590
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert parser is not None
    args = parser.parse_args(["--json"])
    assert args.json == True
    args = parser.parse_args([])
    assert args.json == False
    args = parser.parse_args(["--json", "False"])
    assert args.json == False
    args = parser.parse_args(["--json", "y"])
    assert args.json == True
    args = parser.parse_args(["--json", "n"])
    assert args.json == False

if __name__ == '__main__':
    test_HTTPieArgumentParser()

# Generated at 2022-06-23 18:46:59.483112
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    from argparse import ArgumentParser
    parser = ArgumentParser(description='Does some stuff')
    parser.add_argument('-f', help=' foo', metavar='[foo]')
    parser.add_argument('--bar', help='  bar')
    parser.add_argument('lorem', help='  lorem ipsum dolor sit amet')
    print(parser.format_help())


# A dict of filter functions that validate the CLI argument values.

# Generated at 2022-06-23 18:47:08.159763
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    from httpie.core import main
    from httpie.context import Environment
    env = Environment()
    arg_parser = HTTPieArgumentParser(
        env=env,
        formatter_class=HelpfulArgumentDefaultsHelpFormatter,
    )
    assert arg_parser.prog == 'http'
    assert arg_parser.description == 'A curl-like, ' \
                                     'modern command line HTTP client.'
    assert arg_parser.epilog == 'See httpie.org for detailed documentation.'
    assert arg_parser.formatter_class is HelpfulArgumentDefaultsHelpFormatter
    assert arg_parser.env == env

# Generated at 2022-06-23 18:47:11.909328
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    print(parser.parse_args(['httpie', 'https://httpbin.org/get']))


# Generated at 2022-06-23 18:47:22.006875
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = ['--json', '--headers', '--body', '--verbose', '--form', '--print', 'B', 'https://httpbin.org/post']

    env = Environment(colors=256, stdin_isatty=True, stdout_isatty=True)

    a = Arguments(args, env)

    parser = HTTPieArgumentParser(env=env)
    parser.add_argument('--json', action='store_true')
    parser.add_argument('--headers', action='store_true')
    parser.add_argument('--body', action='store_true')
    parser.add_argument('--verbose', '-v', action='store_true')
    parser.add_argument('--form', action='store_true')

# Generated at 2022-06-23 18:47:26.164841
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    test_line = "--help,-h            Print this help information."
    formatter = HTTPieHelpFormatter()
    assert(formatter._split_lines(test_line, 100)[0] == test_line)
    return

