

# Generated at 2022-06-23 18:37:26.036083
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
   parser = HTTPieArgumentParser()
   print(parser)

if __name__ == '__main__':
    test_HTTPieArgumentParser()

# Generated at 2022-06-23 18:37:35.781693
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    mock_parser = Mock(HTTPieArgumentParser)
    mock_parser.env = MagicMock()
    mock_parser.env.stdin_isatty.return_value = False
    mock_parser.env.stdout_isatty.return_value = True
    mock_parser.env.stdout_encoding = 'utf-8'
    mock_parser.args = MagicMock()
    mock_parser.args.output_options_history = None

    mock_parser.error = MagicMock()
    mock_parser.parse_known_args = MagicMock()
    mock_parser.parse_known_args.return_value = (None, [])
    mock_parser._process_format_options = MagicMock()
    mock_parser._process_download_options = MagicMock()
    mock_parser._process

# Generated at 2022-06-23 18:37:42.613044
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.add_argument('--foo')
    args = parser.parse_args([])
    assert args.foo is None
    args = parser.parse_args(['--foo=bar'])
    assert args.foo == 'bar'
    args = parser.parse_args(['--foo', 'bar'])
    assert args.foo == 'bar'
    
    parser = HTTPieArgumentParser()
    parser.add_argument('--foo', action='append')
    args = parser.parse_args(['--foo', 'bar', '--foo', 'baz'])
    assert args.foo == ['bar', 'baz']
    
    parser = HTTPieArgumentParser()
    parser.add_argument('--foo', nargs='+')

# Generated at 2022-06-23 18:37:47.174873
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-23 18:37:57.328942
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    env = TestEnvironment(colors=256)
    parser = HTTPieArgumentParser(env=env)
    parser.add_argument(u'--offline' )
    parser.add_argument(u'--output-file' , help=u'Write the response body to a file.')
    parser.add_argument(u'--method', 
                        dest=u'method' , 
                        type=u'_method' , 
                        help=u'Request method (e.g. `GET`, `POST`).')
    parser.add_argument(u'--auth-type', type=str,
                        help=('How to handle authentication.'))
    parser.add_argument(u'--auth', type=str,
                        help=('Set authentication credentials.'))

# Generated at 2022-06-23 18:38:01.526407
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    p = argparse.ArgumentParser(
        description='description',
        formatter_class=HTTPieHelpFormatter,
    )
    p.add_argument('--foo', help="""
    multi
    line
    help
    """)
    assert p.format_help()



# Generated at 2022-06-23 18:38:07.650572
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # Create a new parser instance
    parser = HTTPieArgumentParser(env=TestEnvironment())
    assert parser is not None, 'HTTPieArgumentParser is not instantiated'
    assert parser.env is not None, 'HTTPieArgumentParser is not instantiated'
    assert parser.args is None, 'HTTPieArgumentParser args is not None after instantiated'


# Generated at 2022-06-23 18:38:12.261857
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """
    Unit test for method parse_args of class HTTPieArgumentParser
    """
    httprint = _setup_httprint_environment(args=[])
    os.chdir(httprint.args.directory)

    argparser = HTTPieArgumentParser()

    result = argparser.parse_args([])
    assert not result.headers
    assert not result.data

# Generated at 2022-06-23 18:38:20.535057
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
  parser = HTTPieArgumentParser()
  args = parser.parse_args()

  assert hasattr(args,'api') == False
  assert hasattr(args,'auth') == True
  assert hasattr(args,'auth_plugin') == True
  assert hasattr(args,'auth_type') == True
  assert hasattr(args,'body') == True
  assert hasattr(args,'body_columns') == True
  assert hasattr(args,'body_preview') == True
  assert hasattr(args,'cert') == True
  assert hasattr(args,'config_dir') == True
  assert hasattr(args,'config_file') == True
  assert hasattr(args,'data') == True
  assert hasattr(args,'debug') == True
  assert hasattr(args,'download') == True

# Generated at 2022-06-23 18:38:32.205679
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    result = parser.parse_args(['-v', 'GET', 'http://example.html'])

# Generated at 2022-06-23 18:38:39.131881
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """
    Unit test for constructor of class HTTPieArgumentParser
    """
    s = 'https://www.httpbin.org/'

# Generated at 2022-06-23 18:38:50.530246
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    pass
    # hhf = HTTPieHelpFormatter()
    # # 1
    # text = """\
#     Hello world.

#     Goodbye world.
# """
    # print(hhf._split_lines(text, 80))
    # # 2
    # text = """\
# Hello world.

# Goodbye world.
# """
    # print(hhf._split_lines(text, 80))
    # # 3
    # text = """\
#     Hello world.

# Goodbye world.
# """
    # print(hhf._split_lines(text, 80))



# Generated at 2022-06-23 18:39:01.471912
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    class Args:
        def __init__(self):
            self.base_url = None
            self.default_options = None
            self.debug = False
            self.download = False
            self.download_resume = False
            self.download_output = None
            self.output_options_history = None
            self.output_options = None
            self.json_pp = False
            self.nested_json_indent = None
            self.headers = None
            self.ignore_netrc = None
            self.ignore_stdin = None
            self.method = None
            self.output_file = None
            self.output_file_specified = None
            self.output_options = None
            self.output_options_history = None
            self.pretty = None
            self.style = None

# Generated at 2022-06-23 18:39:14.320756
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-23 18:39:17.951729
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter(max_help_position=2)
    assert formatter._split_lines('a\n\nb', 20) == ['a', '', 'b', '', '']


# Generated at 2022-06-23 18:39:25.247636
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    print('parser.prog=',parser.prog)
    print('parser.description', parser.description)
    for attr in HTTPieArgumentParser.__dict__:
        print(attr, '=', getattr(parser, attr))
    parser.parse_args(['--output', '-', 'GET', 'http://httpbin.org/get'])

if __name__ == '__main__':
    test_HTTPieArgumentParser()

# Generated at 2022-06-23 18:39:27.858069
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    parser._parse_args()

if __name__ == '__main__':
    test_HTTPieArgumentParser()

# Generated at 2022-06-23 18:39:36.802045
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    test_format = HTTPieHelpFormatter(
        prog='PROG',
        description='foo',
        epilog='bar',
        usage=None,
        formatter_class=None,
        prefix_chars='=',
        fromfile_prefix_chars='@',
        argument_default=None,
        conflict_handler='error',
        add_help=None)
    # print(test_format.format_option(arg1='val'))
    # print(test_format.format_option_strings(args=['-a', '-b', '-c']))
    print(test_format.format_usage())
    print(test_format.format_help())

test_HTTPieHelpFormatter()




# Generated at 2022-06-23 18:39:42.110883
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser(
        prog='HTTPie',
        default_scheme='http',
        default_method='GET',
        epilog=''
    )

    args = parser.parse_args('/index.html'.split())
    assert args.url == 'http://index.html'

    args = parser.parse_args('http://example.org/'.split())
    assert args.url == 'http://example.org/'

    args = parser.parse_args('example.org'.split())
    assert args.url == 'http://example.org'

    args = parser.parse_args('/index.html https://example.com'.split())
    assert args.url == 'http://index.html'

    args = parser.parse_args('--print=H'.split())
    assert args.output_options

# Generated at 2022-06-23 18:39:46.979481
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    http = HTTPieArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    http.add_argument('-X', '--request',
                      choices=[HTTP_POST, HTTP_GET, HTTP_PUT, HTTP_PATCH],
                      dest='method',
                      metavar='COMMAND',
                      help="Specify request command to use",
                      default=None)

# Generated at 2022-06-23 18:39:49.471935
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    """
    Unit test for constructor of class HTTPieHelpFormatter
    """

    formatter = HTTPieHelpFormatter()   # constructor
    assert formatter.max_help_position == 6
    assert formatter.width == 120
    assert formatter.max_help_position == 6
    

# Generated at 2022-06-23 18:39:51.750034
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    print(HTTPieHelpFormatter.__name__)


# Generated at 2022-06-23 18:40:02.369328
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test parse_args() with a single positional argument.
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['localhost:5000'])
    assert args.url == 'http://localhost:5000'
    assert args.json == False

    # Test parse_args() with a single positional argument and a flag.
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['localhost:5000', '--json'])
    assert args.url == 'http://localhost:5000'
    assert args.json == True

    # Test parse_args() with a single positional argument and a flag and a value.
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['localhost:5000', '--json', 'true'])
    assert args.url == 'http://localhost:5000'
   

# Generated at 2022-06-23 18:40:06.884863
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    orig_argv = sys.argv
    sys.argv = ['http', 'https://httpbin.org/get']
    args = HTTPieArgumentParser().parse_args()
    sys.argv = orig_argv
    assert(args.url == 'https://httpbin.org/get')

# Generated at 2022-06-23 18:40:10.076293
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    class Foo:
        doc = """
        >>> argparse.ArgumentParser(
        ...     formatter_class=HTTPieHelpFormatter).print_help()  # doctest: +SKIP
        usage: PROG [-h] [--version]
        ...
        """

    import doctest
    doctest.testmod(Foo)



# Generated at 2022-06-23 18:40:14.034914
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    # the assert was taken from httpie code itself
    assert formatter._split_lines(
        '''

        My very own


        help.

        '''
        , 80) == ['My very own', '', '', 'help.', '']




# Generated at 2022-06-23 18:40:24.928952
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert parser.env.is_windows == False
    assert parser.env.stdout_isatty == True
    assert parser.env.stdout_encoding == 'utf8'
    assert parser.env.stderr_isatty == True
    assert parser.env.stderr_encoding == 'utf8'
    assert parser.env.stdin_isatty == True
    assert parser.env.stdin_encoding == 'utf8'
    assert parser.env.stdout == sys.stdout.buffer
    assert parser.env.stderr == sys.stderr.buffer
    assert parser.env.devnull == subprocess.DEVNULL
    assert parser.env.stdin == sys.stdin.buffer

parser = HTTPieArgumentParser()



# Generated at 2022-06-23 18:40:31.196688
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # unit tests for HTTPieArgumentParser
    parser = HTTPieArgumentParser()

# Generated at 2022-06-23 18:40:32.590008
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    assert isinstance(formatter, RawDescriptionHelpFormatter)


# Generated at 2022-06-23 18:40:44.111037
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    with patch('sys.stdin'):
        sys.stdin.buffer = unittest.mock.MagicMock()
        sys.stdin.isatty = lambda: False
        with patch('sys.stderr'):
            sys.stderr.buffer = unittest.mock.MagicMock()
            sys.stderr.isatty = lambda: False
            with patch('sys.stdout'):
                sys.stdout.buffer = unittest.mock.MagicMock()
                sys.stdout.isatty = lambda: False
                with patch('os.devnull'):
                    os.devnull = unittest.mock.MagicMock()

# Generated at 2022-06-23 18:40:49.352276
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    help_message = """
        Directory listing in JSON:
        http -f GET example.org/api/
        """
    lines = HTTPieHelpFormatter(max_help_position=8)._split_lines(help_message, 80)
    assert lines == ['Directory listing in JSON:', '', 'http -f GET example.org/api/', '']



# Generated at 2022-06-23 18:41:02.224451
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():    
    parser = HTTPieArgumentParser()    

# Generated at 2022-06-23 18:41:12.516541
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    with pytest.raises(SystemExit):
        HTTPieArgumentParser(add_help=False).parse_args(args=['-h'])
        
    with pytest.raises(SystemExit):
        HTTPieArgumentParser(add_help=False).parse_args(args=['--help'])
        
    with pytest.raises(SystemExit):
        HTTPieArgumentParser(add_help=False).parse_args(args=[])
        
    with pytest.raises(SystemExit):
        HTTPieArgumentParser(add_help=False).parse_args(args=['-h'])
        
    with pytest.raises(SystemExit):
        HTTPieArgumentParser(add_help=False).parse_args(args=['--h'])
        

# Generated at 2022-06-23 18:41:15.109620
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter(max_help_position=3)
    assert formatter._split_lines('hello world\n', 20) == ['hello world\n']



# Generated at 2022-06-23 18:41:18.005370
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    pass

_TRUEISH = {'1', 'true', 'on', 'yes', 'y'}
_FALSEISH = {'0', 'false', 'off', 'no', 'n'}



# Generated at 2022-06-23 18:41:29.884459
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        description='foo',
        formatter_class=HTTPieHelpFormatter)
    parser.add_argument('bar', help='''
        lorem ipsum dolor sit amet
        >

        consectetur adipiscing elit
        ''', choices=['a', 'b']
    )
    parser.add_argument('baz', help='foobar')
    parser.add_argument('--qux', help='quxx')
    _, text = parser.format_help().split('\n', 1)

# Generated at 2022-06-23 18:41:41.964925
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """Unit test for HTTPieArgumentParser class constructor
    """
    # Test error out when the class is instantiated with no argument
    try:
        p = HTTPieArgumentParser()
    except TypeError as e:
        assert (e.args[0] == '__init__() missing 1 required positional argument: \'args\''), \
            "HTTPieArgumentParser constructor should raise TypeError when invoked with no argument"
    else:
        assert (False), "HTTPieArgumentParser constructor should raise TypeError when invoked with no argument"

    # HTTPieArgumentParser constructor should raise TypeError when invoked with invalid argument type

# Generated at 2022-06-23 18:41:50.704933
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    args = ['--traceback','--check-status','--verify','CACERT','--verify','--json','GET','http://127.0.0.1:8000/api/posts/<id>/','id:1','Authorization:Token','Bearer','1234','--ignore-stdin','\x1b[39;49;00m\x1b[39;49;00m\x1b[39;49;00m']
    parser = HTTPieArgumentParser()
    args = parser.parse_args(args)
    print(args)
    assert args.auth == 'Token Bearer 1234'
    assert args.auth_type == 'token'
    assert args.auth == 'Token Bearer 1234'
    assert args.data == None
    assert args.download == False
    assert args.files == None


# Generated at 2022-06-23 18:42:01.662982
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie.config import Config, ConfigDict

    class Struct:
        def __init__(self, **entries):
            self.__dict__.update(entries)

    class MockEnv:
        """
        :type stdout: io.TextIO
        :type stdout_isatty: bool
        :type stderr: io.TextIO
        :type stderr_isatty: bool
        :type stdin: io.TextIO
        :type stdin_isatty: bool
        :type is_windows: bool
        :type colors: int
        :type stdout_encoding: str
        """
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    parser = HTTPieArgumentParser()


# Generated at 2022-06-23 18:42:07.796070
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(description='hi',
                                     formatter_class=HTTPieHelpFormatter)
    parser.add_argument('foo', help='\n bar \n \n \nbaz \n \n \n boo')
    parser.parse_args(['foo'])
    assert parser.format_help() == dedent("""\
        usage: -c [-h] foo

        hi

        positional arguments:
          foo           \n bar \n \n \nbaz \n \n \n boo

        optional arguments:
          -h, --help    show this help message and exit
    """)



# Generated at 2022-06-23 18:42:18.610402
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser(
                prog='http',
                formatter_class=HTTPieHelpFormatter,
            )
    parser.add_argument('-d', dest='data', metavar='DATA',
                        help='data string to be sent.')
    parser.add_argument('--headers', dest='headers', metavar='HEADERS',
                        help='HTTP Headers.')
    parser.add_argument('-b', dest='params', metavar='PARAMS',
                        help='data to be sent via url.')
    parser.add_argument('url', help='URL to be requested.')

# Generated at 2022-06-23 18:42:21.532700
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    HTTPieArgumentParser.env = None
    HTTPieArgumentParser.args = None
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--version'])
    assert args.version == True
    assert args.traceback == False

# Generated at 2022-06-23 18:42:25.653846
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    p = argparse.ArgumentParser(prog="http", formatter_class=HTTPieHelpFormatter)
    p.add_argument('foo', help="""Usage: http [OPTIONS]
                                  HTTPie 0.9.3
                              """)
    args = p.parse_args([])
    # the newline at the end of the default HTTPie help is removed
    assert not p.format_help().endswith('\n')



# Generated at 2022-06-23 18:42:36.911394
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    assert HTTPieArgumentParser
    assert not HTTPieArgumentParser == HTTPieArgumentParser
    test = HTTPieArgumentParser
    assert not test == test
    assert not test == {}
    assert not test == []
    assert not test == ''
    assert not test == '     '
    assert not test == '\n\t\r'
    assert not test == '\t\n\t'
    assert not test == 0
    assert not test == None
    assert test != HTTPieArgumentParser
    assert test != test
    assert test != {}
    assert test != []
    assert test != ''
    assert test != '     '
    assert test != '\n\t\r'
    assert test != '\t\n\t'
    assert test != 0
    assert test != None


# Generated at 2022-06-23 18:42:46.941673
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    import os

    import sys

    import pytest

    STDIN_ENCODING = sys.stdin.encoding or 'utf8'

    class EnvironmentStub(object):
        """
        A stub for `httpie.core.Environment`.

        """
        __test__ = False
        stdin = sys.stdin
        stdin_isatty = sys.stdin.isatty()
        stdin_encoding = STDIN_ENCODING
        stdout = sys.stdout
        stdout_isatty = sys.stdout.isatty()
        stdout_encoding = sys.stdout.encoding
        stderr = sys.stderr
        stderr_isatty = sys.stderr.isatty()
        stderr_encoding = sys.stderr.encoding

# Generated at 2022-06-23 18:42:51.524463
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """
    Unit test for class HTTPieArgumentParser
    """
    parser = HTTPieArgumentParser()
    parser.print_help()

# Execute unit test
if __name__ == '__main__':
    test_HTTPieArgumentParser()

# Generated at 2022-06-23 18:42:53.476212
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    print(HTTPieHelpFormatter.__init__.__doc__)
    sys.exit(0)



# Generated at 2022-06-23 18:42:57.624970
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    'Utility method to test the constructor of HTTPieArgumentParser'
    print('Testing HTTPieArgumentParser constructor')
    args = HTTPieArgumentParser()
    assert args.output_file_specified == False
    assert args.verbose
    assert args.download
    assert args.prettify



# Generated at 2022-06-23 18:43:10.506631
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser(prog='http')
    args = parser.parse_args([])
    assert args.auth == None
    assert args.headers == []
    assert args.data == []
    assert args.request_items == []
    assert args.params == []
    assert args.json == None
    assert args.form == False
    assert args.ascii == False
    assert args.download == False
    assert args.download_resume == False
    assert args.output_file_specified == False
    assert args.output_file == None
    assert args.output_options == None
    assert args.output_options_history == None
    assert args.output_options is None
    assert args.output_options_history is None
    assert args.output_file_specified == False

# Generated at 2022-06-23 18:43:18.236227
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        description='', epilog='http https://www.postman.com',
        formatter_class=HTTPieHelpFormatter
    )
    parser.add_argument('--foo', help='foo: Lorem ipsum dolor sit amet.\n\n    '
                                      'And a second line.')
    args = parser.parse_args(['--help'])


# Generated at 2022-06-23 18:43:20.230278
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    assert isinstance(HTTPieArgumentParser().parse_args([]), argparse.Namespace)


# Generated at 2022-06-23 18:43:30.248359
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    help = {"help": "This is the help for a command",
            "a": "Argument A",
            "b": "Argument B\nLine 2",
            "c": "Argument C"}
    f = HTTPieHelpFormatter(help)
    assert len(f.format_help(None, None).splitlines()) == 5
    assert f.format_help(None, None).splitlines()[2] == "Argument A"
    assert f.format_help(None, None).splitlines()[3] == "Argument B"
    assert f.format_help(None, None).splitlines()[4] == "Line 2"



# Generated at 2022-06-23 18:43:38.088826
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Setup
    argv = ['GET','http://127.0.0.1:5000/','--print','C','--headers','--body']
    args = HTTPieArgumentParser(
        env=Environment(),
        add_help=False,
        # Don't mess with sys.argv
        args_only=True,
).parse_args(argv)
    # Exercise
    # Assert
    assert args.method == 'GET'
    assert args.url == 'http://127.0.0.1:5000/'
    assert args.output_options == 'C'
    assert args.output_options_history == None
    assert args.headers == True


# Generated at 2022-06-23 18:43:40.514545
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter(max_help_position=6)


# Generated at 2022-06-23 18:43:50.478348
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    # 1. Test normal case
    class Test1(object):
        def __init__(self):
            parser = argparse.ArgumentParser(
                prog='test1', formatter_class=HTTPieHelpFormatter,
                description='\n This is a good test!\n')
            parser.add_argument('-i', '--input', default='test.txt', type=str, help="\n this is a test! ")
            parser.print_help()

    # 2. Test abnormal cases
    # 2.1 Newline at the end of the description
    class Test2(object):
        def __init__(self):
            parser = argparse.ArgumentParser(
                prog='test2', formatter_class=HTTPieHelpFormatter,
                description='\n This is a good test!\n \n')
           

# Generated at 2022-06-23 18:43:55.883930
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie.cli.argtypes import KeyValueArgType, KeyValueArgTypeRaw

    parser_class = HTTPieArgumentParser
    parser = parser_class()
    args = parser.parse_args(['https://httpie.org/get', 'username==jkbrzt', 'id==1'])
    assert args.auth.orig == 'jkbrzt'
    assert args.auth.key == 'jkbrzt'

# Generated at 2022-06-23 18:43:59.248612
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert parser.args.output_options is None

if __name__ == '__main__':
    test_HTTPieArgumentParser()

# Generated at 2022-06-23 18:44:11.136751
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Case 1:
    # If a function has a list of arguments, the value of each argument will be replaced
    # by a variable if an equal sign and the variable name appear in the mocker's argument.
    # The variable should be defined in the test file.
    args = ['--ignore-stdin', '--output=/dev/null', '--timeout=10']

# Generated at 2022-06-23 18:44:18.704260
# Unit test for constructor of class HTTPieHelpFormatter

# Generated at 2022-06-23 18:44:22.280770
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    http = HTTPieArgumentParser()
    http.env = TestEnvironment()
    args = http.parse_args()
    assert args.output_options == 'HhB'
    assert args.verify is True


# Generated at 2022-06-23 18:44:28.148779
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    try:
        # Check if httpie had been installed using setuptools
        import pkg_resources
        installed_distributions = dict([(p.key, p) for p in pkg_resources.working_set])
        if 'httpie' not in installed_distributions:
            # FIXME: Download and install httpie
            pass
    except:
        # Setuptools had not been installed
        pass

    parser = HTTPieArgumentParser()
    args = parser.parse_args()
    print(args)
    assert(args.headers)


# Generated at 2022-06-23 18:44:31.286427
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # Test method __init__
    try:
        HTTPieArgumentParser()
        assert True
    except:
        assert False


# Generated at 2022-06-23 18:44:37.033958
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    help_formatter = HTTPieHelpFormatter()
    help_text = 'opt1\nopt2\n\nopt3\n'
    expected_result = ['opt1', 'opt2', '', 'opt3', '']
    result = help_formatter._split_lines(help_text, 3)
    assert(result == expected_result)



# Generated at 2022-06-23 18:44:45.794671
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    long_help = argparse.ArgumentParser(
        description='Long help',
        formatter_class=HTTPieHelpFormatter
    )
    short_help = argparse.ArgumentParser(
        description='Short help',
        formatter_class=argparse.HelpFormatter
    )
    assert len(long_help.format_help().split('\n')) == 5, 'Expect 5 lines of output'
    assert len(short_help.format_help().split('\n')) == 2, 'Expect 2 lines of output'


# Generated at 2022-06-23 18:44:46.973212
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert HTTPieHelpFormatter()



# Generated at 2022-06-23 18:44:49.602015
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert isinstance(parser, HTTPieArgumentParser)



# Generated at 2022-06-23 18:45:01.917959
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    assert parser.parse_args(['--ignore-stdin', 'http://www.example.com'])
    assert parser.parse_args(['--auth-type=basic', 'http://www.example.com'])
    assert parser.parse_args(['http://www.example.com', 'debounce=100'])
    assert parser.parse_args(['--body=@hello.txt', '--form', 'http://www.example.com'])
    assert parser.parse_args(['--headers=X-foo:bar', 'http://www.example.com'])
    assert parser.parse_args(['--ignore-stdin', '--headers=X-foo:bar', 'http://www.example.com'])

# Generated at 2022-06-23 18:45:14.392355
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert parser.env.config_dir == os.path.join(os.path.expanduser('~'), '.httpie')
    assert os.path.exists(parser.env.config_dir) == True
    assert parser.env.config_path == os.path.join(parser.env.config_dir, 'config.json')
    assert os.path.exists(parser.env.config_path) == True
    assert parser.env.config_path_set == True
    with open(parser.env.config_path) as config_file:
        config_json = json.load(config_file)

# Generated at 2022-06-23 18:45:26.770448
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    from httpie.cli import http
    CLI = http
    CLI.env = Environment()
    CLI.env.stdout_isatty = True
    args = CLI.get_args(['--print', 'h'])
    assert args.output_options == 'h'
    assert args.output_options_history == 'h'
    args = CLI.get_args(['--prettify=all'])
    assert args.prettify == ENV_PRETTY_COLORS_ON
    args = CLI.get_args(['--prettify=none'])
    assert args.prettify == ENV_PRETTY_COLORS_OFF
    args = CLI.get_args(['--prettify=auto'])
    assert args.prettify == PRETTY_STDOUT_TTY_ONLY
    args

# Generated at 2022-06-23 18:45:35.104709
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    # Initialize a formatter
    formatter = HTTPieHelpFormatter()
    # Get the description of version
    description = formatter.format_description(
        "HTTPie - a CLI, cURL-like tool for humans.\n\n"
        "https://httpie.org\n")
    # Check whether the description is 'HTTPie - a CLI, cURL-like tool for humans.\n\nhttps://httpie.org\n'
    assert description == 'HTTPie - a CLI, cURL-like tool for humans.\n\nhttps://httpie.org\n'



# Generated at 2022-06-23 18:45:40.533022
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    class FakeEnv():
        env = {
            'COLOR': 'on',
            'TERM': 'xterm',
        }
        stdin_isatty = False
        stdin = None
        stdout_isatty = True
        stdout = None
    class FakeStdin():
        def __init__(self):
            self.fileno = lambda: 1
            self.isatty = lambda: True
            self.buffer = BytesIO()
            self.read = lambda: self.buffer.read()
    env = FakeEnv()
    parser = HTTPieArgumentParser(env=env)
    stdin = FakeStdin()
    stdin.buffer.write(b'a=1')
    sys.stdin = stdin
    env.stdin = stdin

# Generated at 2022-06-23 18:45:45.798607
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        description='foo',
        formatter_class=HTTPieHelpFormatter
    )
    parser.add_argument('--help', action='store_true')
    parser.add_argument('bar', help='bar\nbaz\n\nqux')
    parser.print_help()


# Generated at 2022-06-23 18:45:58.522656
# Unit test for constructor of class HTTPieHelpFormatter

# Generated at 2022-06-23 18:46:10.594392
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    usage = 'http <url> <args>'
    arg_args = []
    arg_args.append(argparse.ArgumentParser(usage=usage, add_help=False).add_argument(
        '-arg1', '--argument1', dest='dest1', metavar='HELP1',
        help='help for argument1\n'
             ' This is argument1\n'
             '    This is argument1\n'
    ))

    arg_args.append(argparse.ArgumentParser(usage=usage, add_help=False).add_argument(
        '-arg2', '--argument2', dest='dest2', metavar='HELP2',
        help='help for argument2\n'
             ' This is argument2\n'
             '    This is argument2\n'
    ))

# Generated at 2022-06-23 18:46:12.190744
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    print(formatter)



# Generated at 2022-06-23 18:46:21.430074
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-23 18:46:29.229291
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    args = HTTPieArgumentParser()
    assert isinstance(args, argparse.ArgumentParser)
    assert args.version == __version__
    assert args.add_help
    assert args.prog == 'http'
    assert args.formatter_class == argparse.RawTextHelpFormatter
    assert args.env == Environment()
    assert args.config_dir is None
    assert args.config_path is None

# Generated at 2022-06-23 18:46:39.461030
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    # Test instances initialization
    formatter = HTTPieHelpFormatter()
    assert formatter.max_help_position == 6

    formatter = HTTPieHelpFormatter(max_help_position=120)
    assert formatter.max_help_position == 120

    formatter = HTTPieHelpFormatter(max_help_position=1)
    assert formatter.max_help_position == 1

    formatter = HTTPieHelpFormatter(max_help_position='5')
    assert formatter.max_help_position == 5

    formatter = HTTPieHelpFormatter(max_help_position=None)
    assert formatter.max_help_position == None


# Generated at 2022-06-23 18:46:47.962482
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie.cli.argtypes import KeyValue
    from httpie import httpie as httpie_cli

    httpie_cli.parse_args()
    httpie_cli.parse_args(['--json'])
    httpie_cli.parse_args(['--pretty=all'])
    httpie_cli.parse_args(['--verify', 'no'])
    httpie_cli.parse_args(['--body', 'foobar'])
    httpie_cli.parse_args(['--stream'])
    httpie_cli.parse_args(['--download'])
    httpie_cli.parse_args(['--download', '--ignore-stdin'])
    httpie_cli.parse_args(['--download', '--output', '-'])

# Generated at 2022-06-23 18:46:48.998959
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert parser.__class__.__name__ == 'HTTPieArgumentParser'

# Generated at 2022-06-23 18:46:58.157548
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = HTTPieArgumentParser().parse_args([]) # return Namespace
    # To verify the type of return value of the method parse_args
    assert isinstance(args, argparse.Namespace), \
        'The type of return value of the method parse_args is not Namespace'
    # To verify some return values of the method parse_args
    # To verify the return value of attribute args of argparse.Namespace
    assert hasattr(args, 'args'), \
        'The Namespace instance created by the method parse_args does not contain attribute args'
    # To verify the return value of attribute auth of argparse.Namespace
    assert hasattr(args, 'auth'), \
        'The Namespace instance created by the method parse_args does not contain attribute auth'
    # To verify the return value of attribute body of argparse.Namespace
   

# Generated at 2022-06-23 18:47:08.661609
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    import tempfile
    import os
    import pprint
    import json
    try:
        temp_file=tempfile.mkstemp()
        # Write output file
        with open(temp_file[1],'w') as fd:
            fd.write('line1\nline2\n')
        argv = ['http', '--output', temp_file[1], 'httpbin.org/get']
        args = parse_args(argv)
        # Read output file
        with open(temp_file[1],'r') as fd:
            lines = fd.readlines()
        for line in lines:
            print(line,end='')
    finally:
        os.remove(temp_file[1])

# Python 2 and 3 compatible `input`

# Generated at 2022-06-23 18:47:11.061229
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    a = HTTPieArgumentParser()
    assert a


# Generated at 2022-06-23 18:47:15.525540
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    from argparse import ArgumentParser
    from io import StringIO
    parser = ArgumentParser(formatter_class=HTTPieHelpFormatter,
                            epilog='    epilog 1.\n    epilog 2.')
    parser.add_argument('--foo', help='foo help')
    parser.add_argument('bar', help='    bar help\n    bar help continued\n')
    parser.print_help(file=StringIO())


# Generated at 2022-06-23 18:47:23.389234
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args('')
    assert not args.output_options_history
    assert not args.headers
    assert args.prettify == PRETTY_STDOUT_TTY_ONLY
    assert not args.verbose
    args = parser.parse_args(['-f'])
    assert args.prettify == PRETTY_STDOUT_TTY_ONLY
    args = parser.parse_args(['--prettify', 'all'])
    assert args.prettify == PRETTY_STDOUT_TTY_ONLY
    args = parser.parse_args(['--prettify'])
    assert args.prettify == PRETTY_STDOUT_TTY_ONLY