

# Generated at 2022-06-23 18:37:35.647267
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    class Example(object):
        def __init__(self, foo=None, bar=None):
            pass

        def run(self):
            parser = argparse.ArgumentParser(
                prog='example',
                formatter_class=HTTPieHelpFormatter,
            )
            parser.add_argument('--foo', default=42, type=int,
                                help='FOO!\n\nSelect a number.')
            parser.add_argument('bar', default='life', type=str,
                                help='BAR!\n\nSelect a word')
            parser.parse_args()

    p = Example()
    p.run()


# Generated at 2022-06-23 18:37:45.006699
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    '''Run $ nosetests tests/test_api.py'''
    #test_HTTPieArgumentParser.__doc__
    #test_HTTPieArgumentParser.__doc__
    print(test_HTTPieArgumentParser.__doc__)
    print('\n')
    ######################
    #httpie.__version__
    #'1.0.0'
    print(httpie.__version__)
    print('\n')
    ######################
    assert httpie.__version__ == '1.0.0'
    ap = HTTPieArgumentParser()
    print('\n\n')
    #####################
    type(ap)
    #<class 'httpie.cli.argtypes.HTTPieArgumentParser'>
    print(type(ap))
    print('\n')

# Generated at 2022-06-23 18:37:55.895152
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    class MockHTTPieArgumentParser:
        pass
    obj = MockHTTPieArgumentParser()
    obj.env = MockEnvironment()
    obj.env.stdout_isatty = False
    obj.env.stderr_isatty = False
    obj.env.stdin_isatty = False
    obj.env.stdout = sys.stdout
    obj.env.stderr = sys.stderr
    obj.env.stdin = sys.stdin
    obj.env.stdin_isatty = sys.stdin
    obj._actions = [
        MockAction(option_strings=['--form'], dest='form', type=str)
    ]

# Generated at 2022-06-23 18:38:00.978312
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    parser = argparse.ArgumentParser()
    parser.add_argument('-a', '--arg', help='arg\nhelper\n')
    parser.add_argument('-b', '--arg2', help=argparse.SUPPRESS)
    # parser.print_help(sys.stdout)


# Generated at 2022-06-23 18:38:07.843253
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(args=['--help'])

    # Check that only the first element is non-None
    assert args.base_url is None
    assert args.body_style == 'FORM'
    assert args.download == False
    assert args.download_resume == False
    assert args.output_file_specified == False
    assert args.prettify == True


# Generated at 2022-06-23 18:38:12.685758
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    f = HTTPieHelpFormatter()
    assert f.__doc__ == 'A nicer help formatter.'
    f = HTTPieHelpFormatter(10)
    assert f.max_help_position == 10
    f = HTTPieHelpFormatter(max_help_position = 11, width = 12)
    assert f.max_help_position == 11
    assert f.width == 12
    return f


# Generated at 2022-06-23 18:38:14.241506
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    args = HTTPieArgumentParser().parse_args(['a'])


# Generated at 2022-06-23 18:38:23.509379
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    def f():
        pass
    parser = argparse.ArgumentParser(prog='PROG',
                                     add_help=True,
                                     formatter_class=HTTPieHelpFormatter)
    parser.add_argument('--foo', help='line1\n\n  line2')
    parser.add_argument('bar', help=f.__doc__)
    out = io.StringIO()
    parser.print_help(out)
    assert out.getvalue() == dedent("""
        usage: PROG [-h] [--foo FOO] bar

        positional arguments:
          bar

        optional arguments:
          -h, --help  show this help message and exit
          --foo FOO
            line1

            line2
    """).strip() + '\n'


# Generated at 2022-06-23 18:38:27.102500
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    os.environ['HTTPIE_CONFIG_DIR'] = './'
    conf = HTTPieArgumentParser().config['settings']
    assert conf['user_agent'].startswith('HTTPie/')



# Generated at 2022-06-23 18:38:38.047974
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # httpie.args.JSONParseError
    # httpie.args.OutputOptionsValueError
    # httpie.args.ParseError
    # httpie.args.PrettyOptionsValueError
    from httpie.args import JSONParseError, OutputOptionsValueError, ParseError, PrettyOptionsValueError
    from httpie.context import Environment
    from httpie.plugins import plugin_manager
    #
    plugin_manager.load_installed_plugins()
    #
    URL_STR = 'example.com'
    #
    #
    #
    #
    parser = HTTPieArgumentParser()
    parser.init_argument_parser(Environment())
    parser.parse_args([URL_STR])
    #
    parser = HTTPieArgumentParser()
    parser.init_argument_parser(Environment())
    parser.parse_args

# Generated at 2022-06-23 18:38:39.215451
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    pass



# Generated at 2022-06-23 18:38:50.632035
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    parser = HTTPieArgumentParser()
    # No errors expected on empty argv
    argv = ''
    args = parser.parse_args(argv)

# Generated at 2022-06-23 18:38:56.555251
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(
        ['http', '--input', 'tests/data/request_binary_data.txt'])
    # Assert the args is read from the input file successfully
    assert args.method == 'POST'
    assert args.url == 'http://example.org/path'
    assert args.headers['content-type'] == 'text/x-bin'

    args = parser.parse_args(
        ['http', '--input', 'tests/data/request_binary_data.txt', '--form'])
    assert args.method == 'POST'
    assert args.url == 'http://example.org/path'
    assert args.headers['content-type'] == 'application/x-www-form-urlencoded'

# Generated at 2022-06-23 18:38:57.943105
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert HTTPieHelpFormatter().__init__ == HTTPieHelpFormatter.__init__



# Generated at 2022-06-23 18:39:10.413612
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    env = Environment(colors=256, stdin_isatty=True, stdout_isatty=True)
    parser = HTTPieArgumentParser(env=env)
    parser.add_argument('-h', '--help', action=parser.help, default=False)
    parser.add_argument('--version', action=parser.version, default=False)
    parser.add_argument('--print', default=parser._START_PRINT_OPTIONS)
    parser.add_argument('-v', action='version', version='1.0.0')
    parser.add_argument('--test1', type=int, default=1, help='Test1')
    parser.add_argument('--test2', type=float, default=parser._START_FORMAT_OPTIONS)

# Generated at 2022-06-23 18:39:13.531532
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    assert formatter
    formatter1 = HTTPieHelpFormatter(max_help_position = 6)
    assert formatter1



# Generated at 2022-06-23 18:39:20.267479
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    #from httpie.httpie import parse_args as target
    from httpie.parser import HTTPieArgumentParser

    parser = HTTPieArgumentParser()
    target = parser.parse_args
    assert target, 'a function is required'


# Generated at 2022-06-23 18:39:24.525442
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    arg_parser = HTTPieArgumentParser()
    args = arg_parser.parse_args(["--download","--pretty","json"])
    assert args.download == True
    assert args.pretty == "json"
 
# Test with different combinations of options

# Generated at 2022-06-23 18:39:27.220440
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_parser = HTTPieArgumentParser()
    result = httpie_parser.parse_args()
    # Should run without errors
    assert result.exit_status is None

# Generated at 2022-06-23 18:39:30.618237
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    parser.print_help()

if __name__ == '__main__':
    test_HTTPieArgumentParser()

# Generated at 2022-06-23 18:39:43.457163
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    help1 = """
    GET     http://httpbin.org/get\
            http://httpbin.org/get\
    """
    help2 = """
    GET http://httpbin.org/get
    http://httpbin.org/get
    """
    help3 = """
    Get http://httpbin.org/get
    http://httpbin.org/get
    """
    formatter1 = HTTPieHelpFormatter()
    formatter2 = HTTPieHelpFormatter(max_help_position=3)
    formatter3 = HTTPieHelpFormatter(max_help_position=666)

    assert formatter1._split_lines(help1, 20) == help2.splitlines()
    assert formatter2._split_lines(help1, 20) == help3.splitlines()
    assert formatter3._split_

# Generated at 2022-06-23 18:39:45.610767
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """
    Check whether the return value of constructor is instance of
    HTTPieArgumentParser

    """
    http_argument_parser = HTTPieArgumentParser()
    assert isinstance(http_argument_parser, HTTPieArgumentParser)
    return True



# Generated at 2022-06-23 18:39:58.663705
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """
        Test `HTTPieArgumentParser.parse_args`.
    """

    m = HTTPieArgumentParser(
        prog="http",
        usage=SUPPRESS,
        env=Environment(prefixes=[]),
        stdout=io.BytesIO(),
        stderr=io.BytesIO(),
        stdin=io.BytesIO(),
        #config=None,
        default_options=HTTPieArgumentParser.default_options,
        default_options_unix=HTTPieArgumentParser.default_options_unix,
        add_help=False,
        allow_env_vars=False,
        # args=None,
        # namespace=None,
    )
    args = m.parse_args()
    assert args.verify is True
    assert args.headers is []

# Generated at 2022-06-23 18:40:01.864179
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    http = HTTPieArgumentParser()
    result = http.parse_args(['-f', 'www.google.com'])
    print(result)

test_HTTPieArgumentParser_parse_args()


# Generated at 2022-06-23 18:40:06.629101
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    parser.add_argument('--location')
    parser.add_argument('pos', nargs='*')

    # noinspection PyTypeChecker
    args = parser.parse_args('--location=foo'.split())
    assert args.location == 'foo'
    assert args.pos == []



# Generated at 2022-06-23 18:40:10.477042
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    httpie_args = HTTPieArgumentParser()
    assert isinstance(httpie_args, HTTPieArgumentParser)



# Generated at 2022-06-23 18:40:22.603952
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    class MockHTTPieArgumentParser(HTTPieArgumentParser):
        def __init__(self, *args, **kwargs):
            super(MockHTTPieArgumentParser, self).__init__(*args, **kwargs)
            self.env = Env()
            self.env.config = Config()
            self.env.stdout = sys.stdout
            self.env.stderr = sys.stderr
            self.env.stdout_isatty = sys.stdout.isatty()
            self.env.stderr_isatty = sys.stderr.isatty()
            self.env.stdout_encoding = sys.stdout.encoding or 'utf8'
            self.env.is_windows = False

    parser = MockHTTPieArgumentParser()
    args = parser

# Generated at 2022-06-23 18:40:23.908812
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    ap = HTTPieArgumentParser()
    print(ap)

# Generated at 2022-06-23 18:40:31.656418
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    # class HTTPServer, does not have __init__() function
    try:
        class HTTPServer:
            args = ""
        assert (HTTPieHelpFormatter(args).__init__ == HTTPServer.__init__)
    except AssertionError:
        print("ERROR: test_HTTPieHelpFormatter ")
    else:
        print("SUCCESS: test_HTTPieHelpFormatter")


netrc_auth_warning = '''
Warning: Authentication is requested but --auth/--auth-type is not set.
In this case, the credentials WILL NOT be read from ~/.netrc
'''.strip()

insecure_auth_warning = '''
Warning: Authentication via HTTP is strongly discouraged.
Use HTTPS instead.
'''.strip()


# Generated at 2022-06-23 18:40:33.427083
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    test_raw_help = '''
    Test help
    '''
    assert help == dedent(test_raw_help).strip() + '\n\n'



# Generated at 2022-06-23 18:40:36.134007
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    httpie_argument_parser = HTTPieArgumentParser()
    print(httpie_argument_parser._actions)


# Generated at 2022-06-23 18:40:48.178658
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """
    Unit test for constructor of class HTTPieArgumentParser

    """

    from httpie.core import DEFAULT_CONFIG_PATH
    parser = HTTPieArgumentParser(default_config_path=DEFAULT_CONFIG_PATH)
    assert parser._default_config_path == DEFAULT_CONFIG_PATH

    args = parser.parse_known_args(['https://github.com','user','pass','--auth','basic','--verbose'])

    assert args[0].auth_plugin is not None
    assert args[0].auth_plugin.__class__.__name__ == 'BasicAuth'
    assert args[0].verbose
    assert args[0].url == 'https://github.com'
    assert args[0].headers[0][0] == 'user'
    assert args[0].headers[0][1]

# Generated at 2022-06-23 18:40:55.101837
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        prog='http',
        formatter_class=HTTPieHelpFormatter)
    parser.add_argument('--test', help="""\
This is a test.

It has two paragraphs.

Blah blah blah.
""")
    args = parser.parse_args(['--help'])
    assert args.test is None



# Generated at 2022-06-23 18:40:59.144743
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--json', 'http://test.com/test'])
    assert args.json
    assert args.args == ['http://test.com/test']

# Generated at 2022-06-23 18:41:09.333622
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    temp_stdout = io.StringIO()
    temp_stderr = io.StringIO()
    args = HTTPieArgumentParser(
        env=Environment(
            stdout=temp_stdout,
            stderr=temp_stderr,
            stdin=io.StringIO(''),
            stdin_isatty=True,
            merge_environment=False,
        )
    ).parse_args(['https://postman-echo.com/post', '-h'])
    test_stdout = get_help_text('http')
    temp_stdout.seek(0)
    test_stdout = test_stdout.replace('http', 'http ' + args.url)
    assert temp_stdout.read() == test_stdout



# Generated at 2022-06-23 18:41:11.736357
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # """Unit tests for `HTTPieArgumentParser.parse_args()`"""
    HTTPieArgumentParser.parse_args(['--help'])


# Generated at 2022-06-23 18:41:17.728967
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    args = parser.parse_args('https://httpbin.org/get'.split())
    assert isinstance(args, argparse.Namespace)
    assert args.url == 'https://httpbin.org/get'
    assert args.method == 'GET'
    assert args.env is not None
    assert args.config is not None
    assert args.args is not None


# Generated at 2022-06-23 18:41:29.662825
# Unit test for constructor of class HTTPieArgumentParser

# Generated at 2022-06-23 18:41:35.218335
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    obj = HTTPieArgumentParser()
    args = ['-h']
    msg = '\n' + obj._get_help().strip('\n') + '\n'
    with pytest.raises(SystemExit) as exc:
        obj.parse_args(args)
    assert exc.value.code == msg



# Generated at 2022-06-23 18:41:46.113118
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    from io import StringIO
    from httpie.cli.parser import parser
    stream = StringIO()
    help_formatter = HTTPieHelpFormatter()
    help_formatter.add_usage(parser.usage, parser._actions,
                             parser._mutually_exclusive_groups)
    help_formatter.add_arguments(parser._optionals._group_actions)
    parser.print_help(stream, formatter=help_formatter)
    print(stream.getvalue())


MAX_CONTENT_SIZE = 100 * 1024 * 1024  # 100MiB

# Mapping from request type names to RequestType items.
REQUEST_TYPES = {
    HTTP_GET: RequestType.GET,
    HTTP_POST: RequestType.POST,
}

# Mapping from output-option names to OutputOption items.
D

# Generated at 2022-06-23 18:41:56.917720
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    old_stdout = sys.stdout
    sys.stdout = open("test_HTTPieHelpFormatter.txt", 'w')
    parser = argparse.ArgumentParser(formatter_class=HTTPieHelpFormatter)

    parser.add_argument("--foo",
                        help="""
                        This is a very long, indented help
                        that is going to be wrapped and
                        de-dented.
                        """)

    parser.add_argument("bar",
                        help="""
                        This help also is going to be
                        wrapped, but not dedented.
                        """)

    parser.print_help()
    sys.stdout = old_stdout
    with open("test_HTTPieHelpFormatter.txt", 'r') as f:
        a = f.read()


# Generated at 2022-06-23 18:41:59.022174
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # FIXME: this is only a stub until we re-implement the unit tests
    pass


# Generated at 2022-06-23 18:42:01.847636
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    parser = HTTPieArgumentParser(prog='HTTPie')
    args = parser.parse_args(args = ['--version'])

    # print(args.version)

    print(args)

# Generated at 2022-06-23 18:42:04.822095
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = HTTPieArgumentParser().parse_args(['--verbose', 'httpbin.org'])
    assert args.verbose
    assert not args.debug
    assert args.url == 'httpbin.org'



# Generated at 2022-06-23 18:42:05.853057
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    assert True
    
    


# Generated at 2022-06-23 18:42:13.968900
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    logging.disable(logging.CRITICAL)

    httpie_parser = HTTPieArgumentParser()
    httpie_parser.httpie_args.append(['-h', '-h'])
    httpie_parser.httpie_pos_args.append('www.baidu.com')
    args = httpie_parser.parse_args()

    print(args)

if __name__ == '__main__':
    test_HTTPieArgumentParser()

# Generated at 2022-06-23 18:42:15.542926
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert HTTPieHelpFormatter(max_help_position=6).max_help_position == 6



# Generated at 2022-06-23 18:42:26.182625
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    global parser_h1
    parser_h1 = HTTPieArgumentParser(env = Env(), verify = True)
    parser_h1.add_argument('-p', '--print', '--output-options', 
                        dest = 'output_options', 
                        default = None, 
                        metavar = 'OPTIONS', 
                        type = lambda s: output_option_type(s, parser_h1.error))
    return parser_h1.parse_args(args = ('--print','status,time'))

result = test_HTTPieArgumentParser_parse_args()
print(result)

print(result.output_options)

print(type(result.output_options))


# Generated at 2022-06-23 18:42:30.917016
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    help_text = '''\
        This program is cool.

        :
        A text with newlines
        and indents
    '''
    formatter = HTTPieHelpFormatter()
    assert formatter._split_lines(help_text, 80) == [
        'This program is cool.', '',
        'A text with newlines', 'and indents', '', '']


# Generated at 2022-06-23 18:42:43.962988
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args([])
    assert args.colors == False
    assert args.prettify == False
    assert args.output_options is None
    assert args.output_options_history is None
    assert args.output_options == 'none'
    assert args.output_options_history == 'none'
    assert args.download == False
    assert args.download_resume == False
    assert args.download_insecure == False
    assert args.max_download_size is None
    assert args.raw_stream == False
    assert args.format_options == PARSED_DEFAULT_FORMAT_OPTIONS
    assert args.method is None
    assert args.url == ''
    assert args.headers == []
    assert args.request_items == []
    assert args

# Generated at 2022-06-23 18:42:55.029012
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie = HTTPieArgumentParser() # TODO: figure out why this does not work for unittest
    parser = httpie._get_parser()
    args = parser.parse_args('--ignore-stdin GET example.com'.split())
    assert args.ignore_stdin is True
    assert args.method == 'GET'
    assert args.url == 'example.com'
    args = parser.parse_args('--ignore-stdin POST example.com echo'.split())
    assert args.ignore_stdin is True
    assert args.method == 'POST'
    assert args.url == 'example.com'
    assert args.data == 'echo'
    args = parser.parse_args('--ignore-stdin PUT example.com echo'.split())
    assert args.ignore_stdin is True

# Generated at 2022-06-23 18:43:02.319593
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = ['-h']
    cli_parser = HTTPieArgumentParser()
    cli_parser.parse_args(args)
    assert cli_parser


    #args = ['-v', '-s', 'http://example.com']
    #args = ['-v', '--traceback', '--auth-type=Bearer', 'http://127.0.0.1:8000/api/home/']
    #args = ['-v', '--traceback', '--json', '--auth-type=Bearer', '--auth=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpZCI6MSwiZXhwIjoxNTQ2NzQ1MjI3fQ.wCbnfQtZ

# Generated at 2022-06-23 18:43:10.248225
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    urls = ['http://httpbin.org', 'http://httpbin.org/get', 'http://httpbin.org/post']
    for url in urls:
        parser = HTTPieArgumentParser(url)
        args = parser.parse_args()

        if args.headers is not None:
            for header in args.headers:
                assert isinstance(header, Header)
        if args.params is not None:
            for param in args.params:
                assert isinstance(param, KeyValueArg)

# Generated at 2022-06-23 18:43:12.126904
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert(isinstance(HTTPieHelpFormatter(), RawDescriptionHelpFormatter))


# Generated at 2022-06-23 18:43:19.124649
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test args
    test_args = ['https://httpbin.org', 'user=admin', '-v']
    parser = HTTPieArgumentParser(env=None)
    expanded_args = parser.parse_args(args=test_args)
    assert 'admin' == expanded_args.auth.value
    assert 'https://httpbin.org' == expanded_args.url


# Generated at 2022-06-23 18:43:31.160256
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Arrange
    initiator = HTTPieArgumentParser()
    arguments = ['./http',
                 'http://httpbin.org',
                 '--json',
                 '{"key": "value"}',
                 ]
    # Act
    result = initiator.parse_args(arguments)
    # Assert
    assert(isinstance(result, argparse.Namespace))
    assert(isinstance(result.headers, CaseInsensitiveDict))
    assert(isinstance(result.data, CaseInsensitiveDict))
    assert(isinstance(result.files, CaseInsensitiveDict))
    assert(isinstance(result.params, CaseInsensitiveDict))
    assert(isinstance(result.multipart_data, CaseInsensitiveDict))
    assert(isinstance(result.method, str))

# Generated at 2022-06-23 18:43:39.612883
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from io import StringIO

    parser = HTTPieArgumentParser()
    #
    old_stdout = sys.stdout
    sys.stdout = StringIO()
    if sys.stderr is not None:
        old_stderr = sys.stderr
        sys.stderr = StringIO()
    old_stdin = sys.stdin
    sys.stdin = StringIO()
    try:
        # Only return args, not env
        args = parser.parse_args()
    finally:
        sys.stdout.seek(0)
        sys.stdout.truncate()
        sys.stdout = old_stdout
        if sys.stderr is not None:
            sys.stderr.seek(0)
            sys.stderr.truncate()
            sys.stder

# Generated at 2022-06-23 18:43:44.903916
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    hhf = HTTPieHelpFormatter(max_help_position=6)
    assert "Help for arguments can be indented and contain new lines." \
        in hhf._split_lines(
            dedent("""
            Help for arguments can be indented and contain new lines.
            It will be de-dented and arguments in the help
            will be separated by a blank line for better readability.
            """), 80)



# Generated at 2022-06-23 18:43:53.435742
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser(env=Environment(colors=256, stdin_isatty=False,
                                                   stdout_isatty=False, stderr_isatty=False))
    assert parser.prog == "http"
    assert parser.formatter_class is RawDescriptionHelpFormatter
    assert parser.usage is None
    assert parser.epilog is None
    assert parser.description is None
    assert parser.add_help is True
    assert parser.add_version is True
    assert parser.allow_interspersed_args is True
    assert parser.args is None
    assert hasattr(parser, "env")

# Generated at 2022-06-23 18:44:00.006508
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    argparse.ArgumentParser.parse_args = parse_args
    HTTPieArgumentParser.parse_args = parse_args
    httpie_parser = HTTPieArgumentParser()
    httpie_parser.parse_args(['https://api.github.com', '--print=hb'])
    httpie_parser.parse_args(['ignore', 'https://api.github.com', '--print=hb'])
    config_dir = tempfile.mkdtemp()
    with open(os.path.join(config_dir, 'config.json'), 'w') as f:
        json.dump({'verify': False}, f)
    httpie_parser = HTTPieArgumentParser(config_dir=config_dir)

# Generated at 2022-06-23 18:44:04.168795
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    help = """
    1
    2
    """

    help = formatter._split_lines(help, 80)
    assert '1' in help
    assert '2' in help



# Generated at 2022-06-23 18:44:09.074894
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Create arguments
    args=['https://jsonplaceholder.typicode.com/users', '--form']
    parser=HTTPieArgumentParser()
    # parse arguments
    args_parsed=parser.parse_args(args)
    print(args_parsed)


# Generated at 2022-06-23 18:44:21.328972
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    type_string = 'HTTPieArgumentParser'
    arg = '-j'
    arg_value = None

# Generated at 2022-06-23 18:44:23.002342
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    argparser = HTTPieArgumentParser()
    print(argparser.__dict__)


# Generated at 2022-06-23 18:44:29.987776
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import sys
    import os
    #from httpie.cli import HTTPieArgumentParser
    #from httpie.input import ParseError

    env = Environment(stdin_isatty=False)

    def parse(*args):
        parser = HTTPieArgumentParser(env)
        assert parser.env is env
        return parser.parse_args(args, env)

    def parse_error(message, *args):
        try:
            parse(*args)
            assert False, 'exit not called'
        except ParseError as e:
            assert (str(e)) == message

    parse_error(
        'url is required',
    )
    # --json
    args = parse('--json')
    assert args.request_items == [KeyValue(key=None, value='', sep=None)]
    # --json with

# Generated at 2022-06-23 18:44:40.846062
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    try:
        from io import StringIO
    except ImportError:
        from cStringIO import StringIO
        from io import open


# Generated at 2022-06-23 18:44:41.472712
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert isinstance(HTTPieHelpFormatter,RawDescriptionHelpFormatter)


# Generated at 2022-06-23 18:44:49.649562
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        formatter_class=HTTPieHelpFormatter)
    parser.add_argument('bar', help='''
    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
    Donec mattis pretium massa. Aliquam erat volutpat. Nulla facilisi.

    Donec vulputate interdum sollicitudin. Nunc lacinia auctor quam sed
    pellentesque.
    '''.strip())
    parser.parse_args(['bar'])


# Generated at 2022-06-23 18:44:51.611391
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    pass
    # parser = HTTPieArgumentParser()

if __name__ == '__main__':
    test_HTTPieArgumentParser()

# Generated at 2022-06-23 18:45:03.454122
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args()
    assert args.debug is False
    assert args.download is False
    assert args.download_resume is False
    assert args.form is False
    assert args.ignore_netrc is False
    assert args.output_file is None
    assert args.output_file_specified is False
    assert args.output_options is None
    assert args.output_options_history is None
    assert args.prettify is 'none'
    assert args.quiet is False
    assert args.traceback is False
    assert args.verbose is False
    assert args.verify is True
    assert args.auth is None
    assert args.auth_plugin is None
    assert args.auth_type is None
    assert args.body is None
    assert args.config_

# Generated at 2022-06-23 18:45:07.431351
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_parser  = HTTPieArgumentParser()
    args = httpie_parser.parse_args(['--help'])
    assert args.help == True, "HTTPieArgumentParser_parse_args() failed"


# Generated at 2022-06-23 18:45:16.201974
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    args = parser.parse_args([
        'httpie.org',
        'Accept:text/html',
        '-H', 'Host:httpie.org',
        '-v'
    ])
    assert(args.headers == ['Accept:text/html', 'Host:httpie.org'])
    assert(args.method == 'GET')
    assert(args.verbose == 2)
    assert(args.url == 'httpie.org')



# Generated at 2022-06-23 18:45:27.290509
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Initializing the argparser
    argparser = HTTPieArgumentParser()
    # Testing the parse_args method with a valid url, valid request data and valid output file
    args = argparser.parse_args(['url', '-d', 'key=value', '-o', 'file'])
    # Validating the parsed_args
    assert args.url == 'url'
    # Validating the request_items
    assert args.request_items[0].sep == '='
    assert args.request_items[0].key == 'key'
    assert args.request_items[0].value == 'value'
    # Validating the output_file
    assert args.output_file.name == 'file'


# Generated at 2022-06-23 18:45:28.180106
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # TODO: add a test here
    pass



# Generated at 2022-06-23 18:45:40.114888
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert type(parser.args) is Namespace
    assert parser.args.session_cookie is None
    assert parser.args.user_agent is None
    assert parser.args.print is None
    assert parser.args.method is None
    assert parser.args.output is None
    assert parser.args.output_file is None
    assert parser.args.download is False
    assert parser.args.download_resume is False
    assert parser.args.headers == []
    assert parser.args.form is False
    assert parser.args.check_status is True
    assert parser.args.ignore_stdin is False
    assert parser.args.timeout_connect is None
    assert parser.args.timeout_socket is None
    assert parser.args.max_redirects is 5
    assert parser.args

# Generated at 2022-06-23 18:45:48.911389
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():

    # Initiate a HTTPieArgumentParser object
    parser = HTTPieArgumentParser()

    # Check whether parser is an instance of HTTPieArgumentParser
    assert isinstance(parser, HTTPieArgumentParser)

    # Check whether parser is an instance of ArgumentParser
    assert isinstance(parser, argparse.ArgumentParser)

    # Check whether the parser is an instance of RawDescriptionHelpFormatter
    assert isinstance(parser.formatter_class, argparse.RawDescriptionHelpFormatter)

    # check the env attribute of parser
    assert isinstance(parser.env, Environment)

    # check the args attribute of parser
    assert isinstance(parser.args, argparse.Namespace)

    # Check the description, epilog and help attributes of parser
    assert isinstance(parser.description, str)


# Generated at 2022-06-23 18:45:50.967995
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    class test_HTTPieHelpFormatter(HTTPieHelpFormatter):
        pass
    tester = test_HTTPieHelpFormatter()
    assert tester.__init__(max_help_position=4)


# Generated at 2022-06-23 18:45:53.135558
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """
    Unit test the method parse_args of class HTTPieArgumentParser
    """
    args = []
    arg_parser = HTTPieArgumentParser()
    arg_parser.environment = Environment()
    arg_parser.parse_args(args=args)



# Generated at 2022-06-23 18:45:57.346003
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    ap = HTTPieArgumentParser()
    # Parse args, else unit test will return error:
    # 'SystemExit' object is not iterable
    try:
        ap.parse_args([])
    except SystemExit:
        pass

# Generated at 2022-06-23 18:46:09.486185
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-23 18:46:13.773969
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    httpie_argument_parser = HTTPieArgumentParser()
    args = httpie_argument_parser.parse_args()
    print(args)
    assert args.url == 'http://'

if __name__ == '__main__':
    test_HTTPieArgumentParser()

# Generated at 2022-06-23 18:46:18.517585
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_args = [
        'http',
        '--pretty',
        'all',
        'GET',
        'https://localhost:8080/advanced/api/v1/products',
        'id==1',
        'name=robert',
        '--auth-type',
        'JWT'
    ]
    assert HTTPieArgumentParser().parse_args(httpie_args)

# Generated at 2022-06-23 18:46:19.452593
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()



# Generated at 2022-06-23 18:46:33.100301
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():

    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    args = parser.parse_args(['--foo=bar'])
    print(args)
    # Namespace(foo='bar')


    from httpie import command
    from httpie.constants import DEFAULT_UA, DEFAULT_FORMAT
    from httpie.context import Environment
    env = Environment(colors=0)
    parser = command.HTTPieArgumentParser(prog='http', env=env)


    args = parser.parse_args(['--foo=bar'])
    # {'foo': 'bar'}

    print(args.__dict__)
    # { 'foo': 'bar'}


# Generated at 2022-06-23 18:46:40.786616
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        formatter_class=HTTPieHelpFormatter,
        description="""
        Some text.

        Some description.
        """
    )

    parser.add_argument(
        '--foo',
        help="""
        Arg description.

        Some more text.
        """,
    )
    parser.add_argument(
        'bar',
        help="""
        Arg description.

        Some more text.
        """,
    )
    print(parser.format_help())


# Generated at 2022-06-23 18:46:46.184840
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    from argparse import ArgumentParser
    parser = ArgumentParser(formatter_class=HTTPieHelpFormatter)
    parser.add_argument('--foo', help='''
            Foo bar.

                baz
            ''')
    parser.parse_args(['--help'])



# Generated at 2022-06-23 18:46:49.174992
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    def dummy_parser():
        pass
    ht = HTTPieArgumentParser(add_help=False, description=dummy_parser)
    assert ht

# Generated at 2022-06-23 18:46:52.610301
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    p = HTTPieArgumentParser()
    p.parse_args('GET httpbin.org/get'.split())

if __name__ == '__main__':
    test_HTTPieArgumentParser()

# Generated at 2022-06-23 18:46:56.018555
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert "def __init__(self, max_help_position=6, *args, **kwargs):" in inspect.getsource(HTTPieHelpFormatter)
    assert "super().__init__(*args, **kwargs)" in inspect.getsource(HTTPieHelpFormatter)



# Generated at 2022-06-23 18:46:58.519243
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args('GET http://httpbin.org/get')
    pprint(vars(args))

# Generated at 2022-06-23 18:47:08.820343
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.parse_args(['http://api.bootsnipp.com/snippets/featured'])
    assert parser.args.url == 'http://api.bootsnipp.com/snippets/featured'
    assert parser.args.method == 'GET'
    assert parser.args.auth is None
    assert parser.args.auth_type is None
    assert parser.args.auth_plugin is None
    assert parser.args.data is None
    assert parser.args.form is False
    assert parser.args.files == {}
    assert parser.args.headers == {}
    assert parser.args.params == {}
    assert parser.args.multipart_data is None
    assert parser.args.body == ''
    assert parser.args.body_on_error is False

# Generated at 2022-06-23 18:47:12.517886
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    sys.argv = ["http","--help"]
    p = HTTPieHelpFormatter()
    assert(isinstance(p,RawDescriptionHelpFormatter))


# Generated at 2022-06-23 18:47:22.344032
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    #takes all the command line arguments from user and store in cmd
    cmd='http --headers --json --auth-type=basic --body --form "https://http4k.org/cookies" cookie="nomnom"'
    #initializing parser to parse the command line arguments
    parser=HTTPieArgumentParser(cmd.split())
    args1=parser.parse_args()
    args1.url=quote(args1.url)
    assert args1.headers==True
    assert args1.json==True
    assert args1.auth_type=='basic'
    assert args1.body==True
    assert args1.form==True
    assert args1.method=='GET'
    assert args1.url=='https%3A%2F%2Fhttp4k.org%2Fcookies'
    assert args1.request

# Generated at 2022-06-23 18:47:26.652106
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert HTTPieHelpFormatter(max_help_position=20).max_help_position == 20

# Template for generating a parser for various groups of arguments.
parser_template = argparse.ArgumentParser(formatter_class=HTTPieHelpFormatter)