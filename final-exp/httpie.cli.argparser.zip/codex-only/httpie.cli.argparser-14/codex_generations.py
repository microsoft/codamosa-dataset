

# Generated at 2022-06-23 18:37:22.069208
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    http = HTTPieArgumentParser()
    return 1

# Generated at 2022-06-23 18:37:35.218345
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.parse_args(['--traceback', '--json', '{}', 'http://localhost/post'])
    parser.parse_args(['http://localhost/post'])
    parser.parse_args(['--download', '--output', 'f.txt', 'http://localhost/post'])
    parser.parse_args(['--download', '--output', 'f.txt', '--verbose', '--print=hb', 'http://localhost/post'])
    parser.parse_args(['-j', '{}', 'http://localhost/post'])
    parser.parse_args(['-j', '{}'])
    parser.parse_args(['-p', 'body=some-body', 'http://localhost/post'])
    parser.parse_args

# Generated at 2022-06-23 18:37:39.241064
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    result = formatter._split_lines(text="""

        http get example.org

        foo bar

        http --form POST example.org hello=World
    """, width=10)

    assert result == [
        "http get example.org",
        "",
        "foo bar",
        "",
        "http --form POST example.org hello=World",
    ]



# Generated at 2022-06-23 18:37:47.369422
# Unit test for constructor of class HTTPieArgumentParser

# Generated at 2022-06-23 18:37:49.522901
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    # FIXME: add more tests here.
    assert parser

# Generated at 2022-06-23 18:37:58.840872
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    env = Environment()
    args = HTTPieArgumentParser(env).parse_args([])
    assert args.headers == {}
    assert args.params == {}
    assert args.data == Data()
    assert args.files == Files()
    assert args.output_file == None
    assert args.output_file_specified == False
    assert args.output_options == 'HBhbJjqs'
    assert args.output_options_history == 'HBhbJjqs'
    assert args.download == False
    assert args.download_resume == False
    assert args.download_all_urls == False
    assert args.download_existing == True
    assert args.download_output_directory == '.'

# Generated at 2022-06-23 18:38:00.730809
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser('foo', formatter_class=HTTPieHelpFormatter)
    assert isinstance(parser.formatter, HTTPieHelpFormatter)



# Generated at 2022-06-23 18:38:11.588587
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test case 1: Testing with no arguments
    # Inputs : Empty
    # Expected Outputs : Empty
    try:
        HTTPieArgumentParser()
    except Exception as e:
        print(e)
    # Test case 2: Testing with valid arguments
    # Inputs : '--help'
    # Expected Outputs : ArgumentParser(
    # 	prog='http',
    # 	usage="%(prog)s [OPTIONS] [URL] [REQUEST_ITEM]...\n       %(prog)s [OPTIONS] -- [URL] [REQUEST_ITEM]...",
    # 	description='CLI HTTP client for humans and computers',
    # 	formatter_class=<class 'argparse.HelpFormatter'>,
    # 	conflict_handler='error',


# Generated at 2022-06-23 18:38:22.067277
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie.httpie import HTTPieArgumentParser
    from httpie.httpie import HTTPie
    from httpie.httpie import get_netrc_auth
    from httpie.plugins.builtin import AuthPlugin, Plugin, plugin_manager
    from httpie.input import ParseException
    from httpie import __doc__ as httpie_desc
    from httpie import doc

    parser = HTTPieArgumentParser(description=httpie_desc)
    args = parser.parse_args(['snksoft.com'])
    print(args)
    assert isinstance(args.auth, AuthCredentials) == True
    assert args.auth.orig == ""
    assert args.auth.key == ""
    assert args.auth.value == ""
    assert args.compress == False

# Generated at 2022-06-23 18:38:32.806181
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    tmp = HTTPieHelpFormatter(max_help_position=6)
    # pylint:disable=protected-access

# Generated at 2022-06-23 18:38:43.244510
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    class Dummy:
        pass

    hfp = HTTPieHelpFormatter(max_help_position=1)
    # noinspection PyUnresolvedReferences
    hfp._width = 60
    # noinspection PyProtectedMember
    assert hfp._whitespace_matcher.sub(' ', hfp._split_lines(Dummy.__doc__, 0)[0]) == 'A nicer help formatter.\n'
    # noinspection PyProtectedMember
    assert hfp._whitespace_matcher.sub(' ', hfp._split_lines(Dummy.__doc__, 0)[1]) == 'Help for arguments can be indented and contain new lines.\n'



# Generated at 2022-06-23 18:38:45.610215
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser=argparse.ArgumentParser(description='test_description',formatter_class=HTTPieHelpFormatter)


# Generated at 2022-06-23 18:38:51.752114
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    import sys

    class CustomStdout(io.BytesIO):
        buffer = io.BytesIO
        encoding = 'utf-8'
        isatty = lambda self: True

    ap = HTTPieArgumentParser()
    ap.stdout = stdout = CustomStdout()
    ap.stderr = stderr = CustomStdout()

    ap.parse_args(['--verbose', '--ignore-stdin', '--print=Hb', '--output=stdout', 'GET'])
    assert ap.args.verbose == True
    assert ap.args.ignore_stdin == True
    assert ap.args.print == 'Hb'
    assert ap.args.output == 'stdout'
    assert ap.args.method == 'GET'


# Generated at 2022-06-23 18:38:59.584478
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    # setup the test
    input = """
    abc
    abc
    abc
    """
    # start test
    try:
        a = HTTPieHelpFormatter()
    except Exception:
        print("constructor error!")
    # test output
    try:
        a._split_lines(input, 6)
    except Exception:
        print("test _split_lines error!")
    # test output
    try:
        a._split_lines(input, 10)
    except Exception:
        print("test _split_lines error!")


# Generated at 2022-06-23 18:39:13.306852
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    arguments=list()
    # Arguments
    arguments.append("http")
    arguments.append("--pretty")
    arguments.append("all")
    arguments.append("--verbose")
    arguments.append("--headers")
    arguments.append("--body")
    arguments.append("--stream")
    arguments.append("--download")
    arguments.append("--download-resume")
    arguments.append("--download-as")
    arguments.append("--download-and-save")
    arguments.append("--download-output")
    arguments.append("--download-stdout")
    arguments.append("--offline")
    arguments.append("--http2")
    arguments.append("--output")
    arguments.append("--format")
    arguments.append("--style")
    arguments.append("--style-sheet")


# Generated at 2022-06-23 18:39:23.668210
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    args = HTTPieArgumentParser(prog='test').parse_args(args=[])
    assert args.output_file == sys.stdout

    args = HTTPieArgumentParser(prog='test').parse_args(args=['GET', 'http://example.com'])
    assert args.method == 'GET'
    assert args.url == 'http://example.com'
    assert args.output_file == sys.stdout

    args = HTTPieArgumentParser(prog='test').parse_args(args=['--output=/dev/null', 'GET', 'http://example.com'])
    assert args.output_file.name == '/dev/null'


# Generated at 2022-06-23 18:39:26.081246
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    with pytest.raises(SystemExit):
        parser.parse_args(args=[])


# Generated at 2022-06-23 18:39:30.958201
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    """Test the constructor of the class HTTPieHelpFormatter"""
    formatter = HTTPieHelpFormatter()
    assert formatter.max_help_position == 6
    formatter = HTTPieHelpFormatter(24)
    assert formatter.max_help_position == 24


# Generated at 2022-06-23 18:39:44.170906
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    assert parser.parse_args(['-h']).help
    assert parser.parse_args([])
    assert parser.parse_args(
        ['-v', '--style=solarized', 'https://httpbin.org/get']
    ).style == 'solarized'
    assert parser.parse_args(['--headers', 'foo:bar']).headers == {'foo': 'bar'}
    assert parser.parse_args(['--headers', 'foo:bar']).headers == {'foo': 'bar'}
    assert parser.parse_args(['--headers', 'foo:bar', 'https://httpbin.org/get']).headers == {'foo': 'bar'}

# Generated at 2022-06-23 18:39:56.655456
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():

    print('Test starting')

    # Test constructor without arguments
    try:
        HTTPieArgumentParser()
        print('Test 1 failed')
    except SystemExit:
        print('Test 1 passed')

    # Test constructor with wrong type of arguments
    try:
        HTTPieArgumentParser(0)
        print('Test 2 failed')
    except SystemExit:
        print('Test 2 passed')

    # Test constructor with a single string argument
    try:
        HTTPieArgumentParser('String')
        print('Test 3 failed')
    except SystemExit:
        print('Test 3 passed')

    # Test constructor with a list containing non strings
    try:
        HTTPieArgumentParser([0, 1])
        print('Test 4 failed')
    except SystemExit:
        print('Test 4 passed')

    # Test constructor with a list containing a single

# Generated at 2022-06-23 18:40:05.323317
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser(prog=PROG, env=Environment(), add_help=False)
    parser.add_argument('-j', '--json', dest='prettify',
                        default=True, help='Pretty JSON output')
    parser.add_argument('-o', '--output', dest='output_file', type=argparse.FileType('wb'))
    parser.add_argument('--overwrite', dest='output_file_specified', action='store_true')
    parser.add_argument('-v', '--verbose', dest='verbose', action='store_true')
    parser.add_argument('url', nargs='?', help='URL', type=KeyValueArgType(),
                        default='https://httpie.org/',
                        action=MergeJSONBodyAction)

# Generated at 2022-06-23 18:40:16.376320
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args()

# Generated at 2022-06-23 18:40:16.994694
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    pass



# Generated at 2022-06-23 18:40:21.348932
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """
     constructor of class HTTPieArgumentParser

    """
    if not HTTPIE_DEBUG:
        print('No unittest for `HTTPieArgumentParser()` if not HTTPIE_DEBUG')
        return
    parser = HTTPieArgumentParser()
    assert parser

# Generated at 2022-06-23 18:40:22.867340
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    arg_parser = HTTPieArgumentParser()
    arg_parser.parse_args()

# Generated at 2022-06-23 18:40:26.386311
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(description='description',
                                     formatter_class=HTTPieHelpFormatter)
    parser.add_argument('--foo', help='foo\nbar\nbaz\n')
    parser.add_argument('--bar')
    parser.print_help()



# Generated at 2022-06-23 18:40:29.463618
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    from argparse import ArgumentError
    assert ArgumentError, HTTPieHelpFormatter(max_help_position=6, indent_increment=2,
                                              width=80, short_first=1)



# Generated at 2022-06-23 18:40:32.557529
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    argparse_help_formatter_methods = dir(argparse.HelpFormatter)
    assert set(argparse_help_formatter_methods) == set(dir(HTTPieHelpFormatter))

# compatibility with Python 3.4.2 and 3.4.3

# Generated at 2022-06-23 18:40:41.909824
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    """
    Test the use of HTTPieHelpFormatter
    """
    from httpie.cli.parser import get_parser
    parser = get_parser()
    usage = parser.format_usage()
    for pos, line in enumerate(usage.split('\n')):
        # line numbers are 1-based
        if line == 'http [HTTP_VERB] http-url [ITEM [ITEM]]':
            assert pos == 3, "Test failed: the line number for http is not 3"
            break
    help_text = parser.format_help()
    assert help_text.find('username password') != -1, "Test failed: the username password is not found in help text"
    assert help_text.find('--download') != -1, "Test failed: the --download argument is not found in help text"
    assert help_

# Generated at 2022-06-23 18:40:45.074266
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
  print("Test case")
  x = HTTPieHelpFormatter(prog='hi')
  x._split_lines('hi', 0)


# Generated at 2022-06-23 18:40:51.819828
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # test method
    http_request_parser = HTTPieArgumentParser()
    http_request_parser.parse_args(
        ['GET', 'http://www.test.com/api/test', 'param1=test'])
    print('method: %s' % http_request_parser.args.method)
    print('url: %s' % http_request_parser.args.url)
    print('data: %s' % http_request_parser.args.data)
    print('headers: %s' % http_request_parser.args.headers)
    print('request_item: %s' % http_request_parser.args.request_items)
    print('format_options: %s' % http_request_parser.args.format_options)

# Generated at 2022-06-23 18:41:03.340535
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    args = ['--help']
    parser = HTTPieArgumentParser()
    parsed = parser.parse_args(args)
    assert parsed.command == ['--help'], 'command should be --help'
    assert parsed.debug == False, 'debug should be False'
    assert parsed.ignore_stdin == False, 'ignore_stdin should be False'
    assert parsed.traceback == False, 'traceback should be False'
    assert parsed.output_file == None, 'output_file should be None'
    assert parsed.output_options == None, 'output_options should be None'
    assert parsed.output_options_history == None, 'output_options_history should be None'
    assert parsed.download == False, 'download should be False'
    assert parsed.download_resume == False, 'download_resume should be False'


# Generated at 2022-06-23 18:41:13.070673
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    print("---> Test for constructor of class HTTPieHelpFormatter")
    print(HTTPieHelpFormatter.__doc__)
    parser = argparse.ArgumentParser(formatter_class=HTTPieHelpFormatter)
    parser.add_argument('--long-argv', help='Help of long_argv')
    parser.add_argument('-s', '--short-argv', help='Help of short_argv')
    args = parser.parse_args([])
    # This will print:
    # usage: [-h] [--long-argv LONG_ARGV] [-s SHORT_ARGV]
#     positional arguments:
#       -h, --help            show this help message and exit
#       --long-argv LONG_ARGV
#                             Help of long_argv
#       -s SHORT_AR

# Generated at 2022-06-23 18:41:20.617254
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    ap = HTTPieArgumentParser()
    # Bypass super().parse_args()
    ap.parse_known_args = lambda *args, **kwargs: (None, args[0])
    ap.parse_args = ap._parse_args
    argv = ['--print=status', '--check-status', '--ignore-stdin', '--method=OPTIONS', 'httpie', '--form']
    args = argv
    args, unknown = ap.parse_args(args)
    assert args.output_options == 's'
    assert args.check_status
    assert args.ignore_stdin
    assert args.method == 'OPTIONS'
    assert args.url == 'httpie'
    assert args.form
    assert unknown == []


# Generated at 2022-06-23 18:41:22.888857
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """Unit test for constructor of class HTTPieArgumentParser"""
    args = HTTPieArgumentParser()
    print(args)

# Generated at 2022-06-23 18:41:32.845449
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie = HTTPieArgumentParser()
    args = httpie.parse_args()
    assert args.output_file == None
    assert args.output_options_history == 'HBI'
    assert args.verbose == False
    assert args.format == 'json'
    assert args.download_resume == False
    assert args.offline == False
    assert args.download == False
    assert args.download_resume == False
    assert args.check_status == True
    assert args.timeout == None
    assert args.auth == None
    assert args.headers == None
    assert args.output_options == 'hb'
    assert args.json == False
    assert args.pretty == True
    assert args.style == None
    assert args.stream == False
    assert args.output == None

# Generated at 2022-06-23 18:41:33.393592
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    pass

# Generated at 2022-06-23 18:41:34.105322
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    return



# Generated at 2022-06-23 18:41:45.170711
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    def args_to_dict(args):
        return dict(
            [(k, v) for k, v in vars(args).items()
             if not k.startswith('_')
             ]
        )

    parser = HTTPieArgumentParser()
    args = parser.parse_args([])

# Generated at 2022-06-23 18:41:46.616288
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    HTTPieArgumentParser()


# Generated at 2022-06-23 18:41:49.722787
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['httpbin.org'])
    assert args.url == 'httpbin.org'


# Generated at 2022-06-23 18:41:56.876947
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # HTTPieArgumentParser.parse_args(args, namespace=None)
    pass


# class HTTPie_1_0_3(object):
#     """
#     An HTTPie session.

#     Provides methods for preparing and executing
#     `httpie.core.request.Request` objects.

#     """
#     def __init__(self, env, config_dir, config_path, args=None, stdin=None):
#         self.env = env
#         self.config_dir = config_dir
#         self.config_path = config_path
#         self.session = None
#         self.auth = None
#         self.args = None
#         self.config = None
#         self.stdin = stdin

#         if args is None:
#             args = []

#

# Generated at 2022-06-23 18:42:02.212141
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    text = "This is a block of text that is indented \
    and contains newlines,\n\nand pointers"
    lines = ["This is a block of text that is indented and contains",
             "",
             "and pointers",
             ""]
    assert HTTPieHelpFormatter()._split_lines(text, 80) == lines



# Generated at 2022-06-23 18:42:14.841692
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():

    # args help
    help_text = dedent("""
        args:

        -p, --private

        Do not print cookie headers. (default: False)
    """)

    # expect to return 'Do not print cookie headers. (default: False)',
    # 'Do not print cookie headers.' and 'Do not print cookie headers'
    # given the help text of the argument with both argument name and
    # argument default value
    assert next(iter(HTTPieHelpFormatter()
                   ._split_lines(help_text, 80))) == 'args:'
    assert next(iter(HTTPieHelpFormatter()
                   ._split_lines(help_text, 80))) == ''
    assert next(iter(HTTPieHelpFormatter()
                   ._split_lines(help_text, 80))) == '-p, --private'

# Generated at 2022-06-23 18:42:21.905977
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser_args = {
        'prog': 'http',
        'formatter_class': RawDescriptionHelpFormatter
    }
    parser = HTTPieArgumentParser(**parser_args)
    assert parser.prog == 'http'

    # check .__dict__
    assert type(parser.__dict__) == dict
    assert parser.__dict__['default_config_files'] == DEFAULT_CONFIG_FILES
    assert parser.__dict__['env'] == Environment(parser)


# Generated at 2022-06-23 18:42:32.038721
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    # --download
    args = parser.parse_args([
        '--download', 'https://api.github.com/repos/jakubroztocil/httpie'
    ])
    assert args.download == True
    assert args.output_file is None
    # --output
    args = parser.parse_args([
        'https://api.github.com/repos/jakubroztocil/httpie/readme',
        '--output', 'README.md'
    ])
    assert args.download == False
    assert args.output_file.name == 'README.md'
    assert args.output_file.readable() == True
    # --download --output

# Generated at 2022-06-23 18:42:34.138074
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HttpieArgumentParser()
    print(parser)


# Generated at 2022-06-23 18:42:44.564022
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter(width=80)
    parser = argparse.ArgumentParser(description="abc\nabc", formatter_class=formatter)
    parser.add_argument('-x', help="abc\nabc")
    parser.add_argument('y', help="abc\nabc")
    parser.print_help()

# Parser group.
parser = argparse.ArgumentParser(
    prog='http',
    description='An HTTP client, similar to cURL.',
    epilog=('See also: https://httpie.org/doc'),
    formatter_class=HTTPieHelpFormatter,
    add_help=False
)

# ------------------------------------------------------------------------------
# Input


# Generated at 2022-06-23 18:42:46.181287
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    pass
if __name__ == "__main__":
    test_HTTPieArgumentParser()

# Generated at 2022-06-23 18:42:49.390948
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    ap = HTTPieArgumentParser()
    # Nothing to do, so far
    # print(ap.args)
    return True



# Generated at 2022-06-23 18:42:53.124374
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    assert HTTPieArgumentParser.parse_args(['--version']) == '0.9.9'
    assert HTTPieArgumentParser.parse_args(['--help']) == '0.9.9'


# Generated at 2022-06-23 18:43:01.320371
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Create a HTTPieArgumentParser instance
    parser = HTTPieArgumentParser()
    # Create a args Namespace
    args = argparse.Namespace()
    # Receive the exit status
    status = parser.parse_args([], args)
    # Check if the exit status is expected
    assert not status
    # Check if the Namespace is populated correctly
    assert args.auth_plugin is None
    assert args.auth is None
    assert args.auth_type is None
    assert args.download is False
    assert args.download_resume is False
    assert args.output_file is None
    assert args.output_file_specified is False
    assert args.quiet is False
    assert args.request_items is None
    assert args.timeout == HTTPIE_DEFAULT_TIMEOUT
    assert args.prettify is False
   

# Generated at 2022-06-23 18:43:08.786990
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
  args = []
  namespace = argparse.Namespace()
  _test_HTTPieArgumentParser = HTTPieArgumentParser(add_help=False, args=args, namespace=namespace)
  _test_HTTPieArgumentParser_parse_args = _test_HTTPieArgumentParser.parse_args()
  assert (_test_HTTPieArgumentParser_parse_args == namespace)


# Generated at 2022-06-23 18:43:21.516969
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """Unit test for method parse_args of class HTTPieArgumentParser
    """

    expectation = ['GET', 'http://example.com', None, None, {}, {}, {}, None, None, PRETTY_MAP[PRETTY_STDOUT_TTY_ONLY], '', {}, {}, None, None, None]

    parser = HTTPieArgumentParser()

    for i in range(0, len(parser.parse_args(['get', 'http://example.com'])), 1):
        if parser.parse_args(['get', 'http://example.com'])[i] != expectation[i]:
            print('test_HTTPieArgumentParser_parse_args: Failed')
            break

# Generated at 2022-06-23 18:43:28.792529
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        formatter_class=HTTPieHelpFormatter)
    parser.add_argument('-x', help="""
        Multiline help
        """)
    print(parser.format_help())
    assert parser.format_help() == """usage: <BLANKLINE>
       [ -x ]

<BLANKLINE>
optional arguments:
  -x   Multiline help

<BLANKLINE>
"""



# Generated at 2022-06-23 18:43:38.205169
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    h = HTTPieHelpFormatter()

# Generated at 2022-06-23 18:43:48.780798
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-23 18:43:49.694812
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    pass

# Generated at 2022-06-23 18:43:55.375076
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    def f1(parser):
        parser.add_argument('--foo', help='\n'.join([
            'foo',
            'bar',
        ]))

    parser = argparse.ArgumentParser()
    f1(parser)
    help_str = parser.format_help()
    assert (
        help_str.startswith("usage: ")
    )
    assert '--foo  foo' in help_str
    assert 'bar' in help_str



# Generated at 2022-06-23 18:43:57.592843
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test with no arguments
    # Should return a BasicConfig object
    args = HTTPieArgumentParser().parse_args([])
    assert isinstance(args, BasicConfig)


# Generated at 2022-06-23 18:44:08.243797
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', help = dedent("""
    One line summary.
    Longer explanation.
    Optional more info.
    """))
    parser.add_argument('bar', help = 'Another argument.')
    help_text = parser.format_help()
    assert help_text.count('foo') == 2
    assert help_text.count('bar') == 2 # 2, as bar is positional and required.
    assert help_text.count('\n\n') == 2 # 2, because the help text is separated.
    assert help_text.count('\n  ') == 8 # 2 for args, 2 for the summary, 4 for text.

# Generated at 2022-06-23 18:44:19.956818
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    args = HTTPieArgumentParser().parse_args()
    assert args.headers == {}
    assert args.data == {}
    assert args.verbose == False
    assert args.method == 'GET'
    assert args.auth == None
    assert args.auth_type == None
    assert args.ignore_stdin == False
    assert args.verify == True
    assert args.output == None
    assert args.download == False
    assert args.download_resume == False
    assert args.follow == False
    assert args.timeout == 30
    assert args.max_redirects == 10
    assert args.output_options == 'hb'
    assert args.output_options_history == 'hB'
    assert args.prettify == False


# Generated at 2022-06-23 18:44:28.456280
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Arrange
    original_argv = sys.argv
    original_stdout = sys.stdout
    original_stderr = sys.stderr
    argv = [
        'http',
        '--download',
        '--output',
        'output_file',
        '--form',
        'foo=bar',
        'localhost',
        '--headers',
        'Content-Type: application/json',
        "Content-Length: '42'",
        'Accept: text/plain'
    ]
    # f = mock.Mock()
    # f.getvalue.return_value = '{1}'
    # sys.stdout = mock.Mock()
    # sys.stdout.buffer = f
    # sys.stderr = sys.stdout
    parser = HTTPieArgument

# Generated at 2022-06-23 18:44:34.382292
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    example_indented = """\
Example:
    http httpbin.org
"""
    example_dedented = """\
Example:
    http httpbin.org
"""
    assert formatter._split_lines(example_indented, 80) == example_dedented.splitlines()


# Generated at 2022-06-23 18:44:43.191463
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():

    try:
        import io as StringIO
    except ImportError:
        from io import StringIO

    from httpie.base.config_dicts import CaseInsensitiveDict
    from httpie.core import main
    from httpie.compat import is_windows

    # noinspection PyTypeChecker
    class MockStdout(object):
        """
        If a string or bytes is written to this file-like object,
        it will be available as `self.content`.

        """
        def __init__(self):
            self.content = None

        def write(self, s):
            if isinstance(s, str):
                s = s.encode('utf8')
            self.content = s

        def isatty(self):
            return False

        def flush(self):
            pass

    # noinspection

# Generated at 2022-06-23 18:44:46.973161
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter(max_help_position=2)
    assert formatter._split_lines('a\nb\nc', 3) == ['a', 'b', 'c']



# Generated at 2022-06-23 18:44:52.678529
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    class TestFormatter(HTTPieHelpFormatter):
        def add_usage(self, usage, actions, groups, prefix=None):
            return

    def test_add_usage():
        formatter = TestFormatter()
        formatter.add_usage('', [], [], '')

    test_add_usage()



# Generated at 2022-06-23 18:45:04.117810
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_argparser = HTTPieArgumentParser()
    parser = httpie_argparser.parser
    namespace = parser.parse_args(['http', '--verbose'])
    assert isinstance(namespace, Namespace)
    assert namespace.method == GET
    assert namespace.prettify == PRETTY_MAP['all']
    assert namespace.all
    httpie_argparser = HTTPieArgumentParser()
    parser = httpie_argparser.parser
    namespace = parser.parse_args(['http', '--pretty=none'])
    assert namespace.prettify == PRETTY_MAP['none']
    httpie_argparser = HTTPieArgumentParser()
    parser = httpie_argparser.parser
    namespace = parser.parse_args(['http', '--verify=yes'])

# Generated at 2022-06-23 18:45:11.496065
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(formatter_class=HTTPieHelpFormatter)
    parser.add_argument('foo', help="""
lorem ipsum dolor sit amet
consectetur adipscing elit
""")
    expected = """
  foo
        lorem ipsum dolor sit amet
        consectetur adipscing elit

"""
    assert parser.format_help() == expected



# Generated at 2022-06-23 18:45:15.870914
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(args=['--json', 'www.test.com'])

    assert not args.form
    assert args.json
# Integrate unit test into main function

# Generated at 2022-06-23 18:45:25.192403
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        formatter_class=HTTPieHelpFormatter,
        description='description')

    parser.add_argument('--foo', help='''\
        foo

        bar


        baz
        ''')

    expected = '\n'.join([
        'description',
        '',
        'optional arguments:',
        '  --foo  foo',
        '',
        '  bar',
        '',
        '  baz',
        '',
        '',
    ])
    assert parser.format_help() == expected



# Generated at 2022-06-23 18:45:32.510843
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    test_http_ie = HTTPieArgumentParser()

# Generated at 2022-06-23 18:45:36.460886
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = RawDescriptionHelpFormatter()
    assert formatter.indent_increment == 2
    formatter = HTTPieHelpFormatter()
    assert formatter.indent_increment == 1



# Generated at 2022-06-23 18:45:39.728946
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    request = HTTPieArgumentParser()
    try:
        print(request)
    except Exception as e:
        print(e)
    print(request.__str__())



# Generated at 2022-06-23 18:45:41.427208
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    print(parser)

# Generated at 2022-06-23 18:45:49.716783
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    import sys
    import unittest
    from .tests.data import BIN_DIRECTORY
    # create an instance of the class
    _env = Environment()
    parser = HTTPieArgumentParser(env=_env)
    # capture the standard output
    capturedOutput = io.StringIO()
    sys.stdout = capturedOutput
    # call the function with invalid arguments
    with unittest.TestCase():
        parser.error('test')
    sys.stdout = sys.__stdout__
    # print the captured output
    #print(capturedOutput.getvalue())
    # the output is correct if it contains the message
    assert capturedOutput.getvalue().find('test') != -1
    # create an instance of the class
    _env = Environment()
    parser = HTTPieArgumentParser(env=_env)


# Generated at 2022-06-23 18:45:55.655681
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import pytest
    from httpie import cli

    # Test HTTPieArgumentParser
    args = tuple()
    kwargs = {'args_override': ['https://httpbin.org/get',
                                'User-Agent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36"',
                                '--traceback']}
    http = cli.HTTPieArgumentParser
    args = http.parse_args(*args, **kwargs)
    assert args.url == 'https://httpbin.org/get'

# Generated at 2022-06-23 18:46:01.510466
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        prog='http',
        formatter_class=HTTPieHelpFormatter,
        description=dedent("""
            description line one

            description line two

            description line three
        """),
        epilog='epilog',
        add_help=False  # Don't add the automatic -h, --help.
    )
    parser.add_argument('--foo', help='foo help')
    parser.add_argument('bar', help='bar help')
    print(parser.format_help())


# Generated at 2022-06-23 18:46:05.499979
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    httpieHelpFormatter = HTTPieHelpFormatter(max_help_position=6)
    assert httpieHelpFormatter._split_lines("this is a test", width=100) == ['this is a test', '', '']



# Generated at 2022-06-23 18:46:07.878876
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    helpformatter = HTTPieHelpFormatter()
    helpformatter._split_lines(text='', width=None)


# Generated at 2022-06-23 18:46:09.622027
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    flag = '--yes'
    assert HTTPieArgumentParser()._is_flag(flag)


# Generated at 2022-06-23 18:46:14.608653
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    p= HTTPieArgumentParser()
    assert p.env is not None
    assert p.args is not None
    print("class HTTPieArgumentParser constructor tested\n")

if __name__ == '__main__':
    test_HTTPieArgumentParser()

# Generated at 2022-06-23 18:46:15.825445
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    print(HTTPieArgumentParser())


# Generated at 2022-06-23 18:46:23.221529
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    import sys
    import tempfile

    from httpie import args
    from httpie.plugins import plugin_manager

    parser = HTTPieArgumentParser(prog=args.HTTPie.name)

    # noinspection PyUnresolvedReferences
    assert parser.prog == args.HTTPie.name
    assert parser.parent == args.HTTPie
    assert parser.env == args.Environment()
    assert parser.plugin_manager == plugin_manager

    stdout_save = sys.stdout
    sys.stdout = tempfile.TemporaryFile()

    stderr_save = sys.stderr
    sys.stderr = tempfile.TemporaryFile()

    parser.print_message('test')

    sys.stdout.seek(0)
    sys.stderr.seek(0)
    sys.stdout = std

# Generated at 2022-06-23 18:46:27.890523
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    test_content = '''
    test_content
    '''
    formatter = HTTPieHelpFormatter()

    result = formatter._split_lines(test_content, 80)
    assert result == ['test_content', '']



# Generated at 2022-06-23 18:46:33.196402
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    env = Environment(colors=256)
    parser = HTTPieArgumentParser(env)
    method = 'GET'
    url = 'http://httpbin.org/'
    args = []
    args_dict = parser.parse_args(args)
    assert args_dict.method == method
    assert args_dict.url == url
    args = ['GET']
    args_dict = parser.parse_args(args)
    assert args_dict.method == method
    assert args_dict.url == url
    args = ['http://httpbin.org/']
    args_dict = parser.parse_args(args)
    assert args_dict.method == method
    assert args_dict.url == url
    args = ['--endpoint', 'https://httpbin.org/', 'GET']
    args_dict = parser.parse

# Generated at 2022-06-23 18:46:42.354928
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--verbose', '--debug', '--traceback',
                             'GET', '--form', '--json', '{ "name": "value" }',
                             'http://httpbin.org/post?test=test'])
    assert args.verbose == True
    assert args.debug == True
    assert args.traceback == True
    assert args.method == 'GET'
    assert args.form == True
    assert args.json == '{ "name": "value" }'
    assert args.url == 'http://httpbin.org/post?test=test'

# Generated at 2022-06-23 18:46:54.015886
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO: finish

    parser = HTTPieArgumentParser()
    args = parser.parse_args([])

# Generated at 2022-06-23 18:47:05.286806
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test 1: All option defined, no request item
    args = ['--form', '--print=H']
    hp = HTTPieArgumentParser()
    with pytest.raises(exceptions.Error):
        hp.parse_args(args=args)

    # Test 2: Invalid option
    args = ['--foo', '-b', 'bar']
    hp = HTTPieArgumentParser()
    with pytest.raises(exceptions.Error):
        hp.parse_args(args=args)

    # Test 3: Error in body_from_file
    args = ['--form', '--output', '-', '-b', 'abc']
    hp = HTTPieArgumentParser()
    hp.has_stdin_data = True
    with pytest.raises(exceptions.Error):
        hp.parse_args

# Generated at 2022-06-23 18:47:08.909039
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    ap = HTTPieArgumentParser()
    args = ap.parse_args()
    print(HTTPieArgumentParser.__bases__)
    print(ap.args)

# Generated at 2022-06-23 18:47:17.569675
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    # Create a parser to test parsing
    parser = argparse.ArgumentParser(
        description='test description',
        formatter_class=HTTPieHelpFormatter,
    )
    parser.add_argument(
        'bar',
        help="""\
        This is multiline
        help.
        """)

    assert parser.format_help() == dedent("""\
        usage:  test description
        
        positional arguments:
          bar         This is multiline
                      help.
        
        """)



# Generated at 2022-06-23 18:47:22.209196
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    class TempForTestFormatter(HTTPieHelpFormatter):
        pass
    instance = TempForTestFormatter('max_help_position=10')
    assert instance.max_help_position == 10

