

# Generated at 2022-06-23 18:37:32.768533
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    argv = ['-v']
    parser = HTTPieArgumentParser()
    parser.parse_args(argv)
    parser.get_default('verbose')
    parser.error('-v is an invalid option!')
    parser.parse_known_args(argv)
    parser.exit
    parser.print_usage()
    parser.print_help()
    parser.get_usage()
    parser.get_default('debug')
    parser.update_settings('-v')
    parser.format_option_strings('debug')
    parser.format_option_strings('options')
    parser.get_default('default')


# Generated at 2022-06-23 18:37:40.325031
# Unit test for constructor of class HTTPieHelpFormatter

# Generated at 2022-06-23 18:37:48.196520
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    class HTTPieArgumentParserTest(HTTPieArgumentParser):
        def parse_args(self, args=()):
            return self.parse_known_args(args)

    parser = HTTPieArgumentParserTest(
        None,
        prog='http',
        description=None,
        formatter_class=argparse.RawTextHelpFormatter,
        argument_default=argparse.SUPPRESS,
    )
    with pytest.raises(SystemExit):
        parser.error('test')
    parser.add_argument('url', action='append', nargs='?', type=str,
                        help=argparse.SUPPRESS)
    with pytest.raises(SystemExit):
        parser.parse_args()

# Generated at 2022-06-23 18:37:51.246227
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    test_parser = HTTPieArgumentParser()
    assert isinstance(test_parser.env, Environment)
    assert test_parser.args is None
    assert isinstance(test_parser.args, Namespace)

# Generated at 2022-06-23 18:38:00.144352
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    # Create a mock action for help
    argument = argparse.ArgumentParser(add_help=False)
    action = argument.add_argument('-j', '--junit-xml',
                                   action='help',
                                   help='Write JUnit XML output to file.')

    # Create formatter
    fmt = HTTPieHelpFormatter()
    # Set action.help to value we want to test
    action.help = ' Write JUnit XML output to file.\nIt will be de-dented and arguments in the help\nwill be separated by a blank line for better readability.'

    # Get results
    result = fmt._split_lines(action.help, 80)

    # Set expected results

# Generated at 2022-06-23 18:38:11.047406
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie.core import main
    from httpie.input import ParseError
    from httpie.status import ExitStatus

    def get_exit_status(args):
        session = Session()
        parser = HTTPieArgumentParser(session=session)
        try:
            parser.parse_args(args)
        except Exception as e:
            # if not isinstance(e, ParseError):
                # raise
            pass
        return session.exit_status

    # Invalid method
    assert get_exit_status(['get']) == ExitStatus.OK
    assert get_exit_status(['eget']) == ExitStatus.PARHIPER_ERROR
    assert get_exit_status(['GET']) == ExitStatus.OK
    assert get_exit_status(['get', 'test']) == ExitStatus.PARHIPER

# Generated at 2022-06-23 18:38:20.047983
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--method', 'POST', '--data', 'a=b', 'httpbin.org/post', 'c=d'])
    assert args.method == 'POST'
    assert args.data == [b'a=b']
    assert args.url == 'httpbin.org/post'
    assert args.request_items == [KeyValue(key='c', value='d', sep=SEPARATOR_DATA)]
    assert args.headers == [KeyValue(key='Content-Type', value='application/json', sep=SEPARATOR_HEADERS)]

# Generated at 2022-06-23 18:38:31.816038
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """Test HTTPieArgumentParser constructor"""
    
    # When there is an invalid argument showing up
    # Then an error message will be raised
    with pytest.raises(Error) as excinfo:
        p = HTTPieArgumentParser()
        p.parse_args(['-V', '2'])

    # When there is an invalid argument showing up
    # Then an error message will be raised
    with pytest.raises(Error) as excinfo:
        p = HTTPieArgumentParser()
        p.parse_args(['-h'])

    # When there is an invalid argument showing up
    # Then an error message will be raised
    with pytest.raises(Error) as excinfo:
        p = HTTPieArgumentParser()
        p.parse_args(['--term-style'])

    # When there

# Generated at 2022-06-23 18:38:36.958634
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    parser.add_argument('--boolean', action='store_true')
    parser.add_argument('--name')
    parser.add_argument('--count', type=int)

    args = parser.parse_args([])
    assert args.boolean is None
    assert args.name is None
    assert args.count is None

    args = parser.parse_args(['--boolean'])
    assert args.boolean is True
    assert args.name is None
    assert args.count is None

    args = parser.parse_args(['--boolean', '--name', 'Dave'])
    assert args.boolean is True
    assert args.name == 'Dave'
    assert args.count is None


# Generated at 2022-06-23 18:38:39.926144
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser(env=Environment())
    assert isinstance(parser, HTTPieArgumentParser)



# Generated at 2022-06-23 18:38:46.333141
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    h = HTTPieArgumentParser()
    h._parse_args(['--form', '--verbose', 'post', 'https://httpbin.org/post', 'foo=bar', 'baz=bar'])
    assert h.args.method == 'POST'
    assert h.args.url == 'https://httpbin.org/post'
    assert h.args.request_items[0].value == 'bar'
 
test_HTTPieArgumentParser_parse_args()

 

# Generated at 2022-06-23 18:38:49.800347
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    assert isinstance(formatter, RawDescriptionHelpFormatter)


# Generated at 2022-06-23 18:38:54.430988
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    o = HTTPieArgumentParser()
    o.parse_args()
    o.parse_args(['http://abc.com'])
    o.parse_args(['http://abc.com', 'key=value'])


# Generated at 2022-06-23 18:38:56.431213
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    assert formatter.format_help() == ""


# Generated at 2022-06-23 18:38:57.830094
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert parser


# Generated at 2022-06-23 18:39:00.149990
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['--auth', 'user:password', 'https://example.org'])
    assert args.auth == 'user:password'

# Generated at 2022-06-23 18:39:03.729383
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert HTTPieHelpFormatter().__init__()._split_lines('Hello World!', 13) == ['Hello World!']


# Generated at 2022-06-23 18:39:08.918977
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    """Return the help message for the --verbose option"""
    description = HTTPieHelpFormatter().format_help().split('\n')
    for line in description:
        if line.strip().startswith('--verbose'):
            return line
    assert False, 'test_HTTPieHelpFormatter() failed'



# Generated at 2022-06-23 18:39:19.321976
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    epilog = 'See https://httpie.org/doc#custom-auth for details.'
    args = HTTPieArgumentParser(prog='HTTPie', epilog=epilog).parse_args(['httpie/tests/data/file_binary_input'])
    assert not hasattr(args, "auth_type")
    assert args.auth is None
    assert args.url == 'httpie/tests/data/file_binary_input'
    assert not args.output_file_specified
    assert args.stdin_isatty
    assert not args.output_isatty
    assert args.output_file is None
    assert args.verbose
    assert not args.offline
    assert not args.download
    assert args.download_resume
    assert not args.multipart
    assert args.output_options

# Generated at 2022-06-23 18:39:24.353776
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-23 18:39:30.578880
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    httpiehelpformatter = HTTPieHelpFormatter()
    text = 'foo\n\nbar'
    # return a list of lines
    result = httpiehelpformatter._split_lines(text, 6)
    assert result == ['foo', '', 'bar']


# Generated at 2022-06-23 18:39:43.407190
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    class TestFormatter(HTTPieHelpFormatter):
        def __init__(self, prog, indent_increment=1,
                max_help_position=0, width=24):
             HTTPieHelpFormatter.__init__(self, indent_increment=indent_increment,
                max_help_position=max_help_position, width=width)
        def _split_lines(self, text, width):
            return text.split('\n')
    
    parser = argparse.ArgumentParser()
    help_text = '''
    Test argument
    '''
    parser.add_argument('-a', help=help_text)
    print('\n')
    TestFormatter(parser.prog).add_argument(parser.parse_args([''])._get_kwargs()[0])



# Generated at 2022-06-23 18:39:45.585220
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    test_parser = HTTPieArgumentParser()
    test_parser.add_argument('testarg')
    test_parser.parse_args(['testval'])
    assert test_parser.args.testarg == 'testval'
# Unit tests for class KeyValue

# Generated at 2022-06-23 18:39:47.573005
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert parser

# Generated at 2022-06-23 18:39:52.750757
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    p = argparse.ArgumentParser(formatter_class=HTTPieHelpFormatter)
    p.add_argument('-a', help="""
        Multiline
        help.""")
    p.print_help()



# Generated at 2022-06-23 18:39:57.708058
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(description='Argparse Python module',
                                     formatter_class=HTTPieHelpFormatter)
    parser.add_argument('--foo', help='  Line1\nLine2\nLine3.')
    parser.add_argument('bar', help='Line4.')
    parser.print_help()



# Generated at 2022-06-23 18:40:02.178417
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """
    Test for constructor of class HTTPieArgumentParser
    """
    print ("test_HTTPieArgumentParser()")
    try:
        parser = HTTPieArgumentParser(description=ipp_description)
    except Exception:
        print ("Parser initialization failed")
    else:
        print ("Parser creation successful")


# Generated at 2022-06-23 18:40:04.060525
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    assert formatter.indent_increment == 1



# Generated at 2022-06-23 18:40:08.157484
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert parser.args.traceback


if __name__ == '__main__':
    parser = HTTPieArgumentParser()
    parser.parse_args()
    print(parser.args)

# Generated at 2022-06-23 18:40:10.237700
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    HTTPieArgumentParser()

# Generated at 2022-06-23 18:40:12.304041
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert parser


# Generated at 2022-06-23 18:40:23.805133
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """
    Test for method parse_args of class HTTPieArgumentParser.
    """
    args = [
        "http",
        "--auth",
        "username:password",
        "--auth-type=basic",
        "-v",
        "GET",
        "https://httpbin.org/basic-auth/username/password"
    ]

    parser = HTTPieArgumentParser()
    args = parser.parse_args(args)
    assert args.auth == 'username:password'
    assert args.auth_type == 'basic'
    assert args.verbose
    assert args.method == 'GET'
    assert args.url == 'https://httpbin.org/basic-auth/username/password'


# Generated at 2022-06-23 18:40:31.625696
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    # parser.print_help()
    # parser.print_usage()
    args = parser.parse_args(
        shlex.split('--json --form --follow --verbose --headers "custom_header: custom_header" --body "custom_body: custom_body" --auth-type basic --auth "xxx:xxx" --timeout 0.123 --pretty all --download --download-resume --output-file /tmp/output_file http://localhost:8080/contact/1234')
    )

    log.debug(args)
    assert args.json
    assert args.form
    assert args.follow
    assert args.verbose
    assert args.headers == {'custom_header': 'custom_header'}
    assert args.data == {'custom_body': 'custom_body'}


# Generated at 2022-06-23 18:40:36.020724
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """
    Test the constructor of HTTPieArgumentParser
    """
    args = HTTPieArgumentParser().parse_args(
        ['localhost:8888', '--json', '--form', 'name=david'])
    assert args.method is None
    assert args.url == 'localhost:8888'
    assert args.request_item_args == ['name=david']
    assert args.auth is None
    assert args.auth_type is None
    assert args.ignore_stdin is False
    assert args.headers == {}
    assert args.params == {}
    assert args.data is None
    assert args.files == {}
    assert args.multipart_data is False
    assert args.form is True
    assert args.output_file is None
    assert args.output_options is None
    assert args.output_

# Generated at 2022-06-23 18:40:36.845624
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO: do test for this method
    pass

# Generated at 2022-06-23 18:40:41.164292
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # create a instance of class
    parser = HTTPieArgumentParser()
    # get parser argument
    args = parser.parse_args()
    # print the value of link
    print(args.url)


# Generated at 2022-06-23 18:40:44.979797
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """Test constructor of class HTTPieArgumentParser.

    """
    # Construct an instance of HTTPieArgumentParser
    parser = HTTPieArgumentParser()
    # Check the class attribute args
    assert parser.args is None


# Generated at 2022-06-23 18:40:52.651421
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    fd = io.StringIO('request body/data')
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http', 'example.com'])
    assert args.method == 'GET'
    assert args.url == 'example.com'
    assert args.headers == {}
    assert args.request_items == []
    assert args.data is None
    assert args.files == {}
    assert args.params == []
    assert args.multipart_data == False

    args = parser.parse_args(['http', 'example.com', 'body=test'])
    assert args.method == 'GET'
    assert args.url == 'example.com'
    assert args.headers == {}

# Generated at 2022-06-23 18:40:54.675777
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """
    Unit test for method parse_args of class HTTPieArgumentParser
    """
    return


# Generated at 2022-06-23 18:41:00.268489
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(args=[])
    assert args.method == "GET"
    assert args.url == "https://api.github.com/repos/psf/requests/issues"
    assert args.auth_plugin == None
    assert args.auth == None
    assert args.ignore_netrc == False

# Generated at 2022-06-23 18:41:05.191524
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    '''
    Unit test for constructor of class HTTPieHelpFormatter
    '''
    if __name__ == "__main__":
        fmt = HTTPieHelpFormatter()
        assert fmt._split_lines('Line1\nLine2', width=80) == ['Line1', 'Line2', '']
    else:
        raise AssertionError("test_HTTPieHelpFormatter: Failed")


# Generated at 2022-06-23 18:41:07.776211
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()

# Generated at 2022-06-23 18:41:18.052619
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # setup
    cap = HTTPieArgumentParser()
    args = ['https://localhost/']

# Generated at 2022-06-23 18:41:19.642422
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser()


# Generated at 2022-06-23 18:41:24.102095
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    text = '''\
        first line
        second line
    '''
    assert formatter._split_lines(text, width=None) == [
        'first line',
        'second line',
        ''
    ]



# Generated at 2022-06-23 18:41:24.940278
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    pass



# Generated at 2022-06-23 18:41:30.320028
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    test_parser = HTTPieArgumentParser()
    test_parser.add_argument('--foo', action='store_true')
    test_parser.add_argument('arg1')

    result = test_parser.parse_args(['--foo', 'bar'])
    assert result.foo is True
    assert result.arg1 == 'bar'

# Generated at 2022-06-23 18:41:31.777942
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO
    pass



# Generated at 2022-06-23 18:41:38.030959
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie = HTTPieArgumentParser()
    # Parser.__init__() sets default values before calling parse_args
    # So, the default values are calculated here.
    # TODO: I don't know how to do it.
    args = httpie.parse_args(["http", "--help"])
    # TODO: I don't know how to test the other variables.
    assert(args.url == "http")
    assert(args.headers == {})
    assert(args.data == {})
    assert(args.params == {})
    assert(args.files == {})
    assert(args.json == None)
    assert(args.auth == None)
    assert(args.auth_type == None)
    assert(args.auth_plugin == None)
    assert(args.timeout == None)

# Generated at 2022-06-23 18:41:39.962686
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert isinstance(
        HTTPieHelpFormatter(description_width=100),
        RawDescriptionHelpFormatter)


# Generated at 2022-06-23 18:41:49.299354
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
  args = HTTPieArgumentParser().parse_args(
    argv=['-v','-f','--print=h','-p=B', '-P=C', '--print=B','-O', 'http://httpbin.org/post','a=a', 'b=b', 'a=a']
  )
  assert args.auth == None, f'expect args.auth == None, get {args.auth}'
  assert args.auth_type == None, f'expect args.auth_type == None, get {args.auth_type}'
  assert args.auth_plugin == None, f'expect args.auth_plugin == None, get {args.auth_plugin}'
  assert args.body == None, f'expect args.body == None, get {args.body}'
  assert args.body

# Generated at 2022-06-23 18:41:53.728989
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    argv = ['http', 'httpie.org', 'Accept:application/json']
    args = HTTPieArgumentParser().parse_args(argv)
    assert args.url == 'httpie.org'
    assert args.headers == {'Accept':'application/json'}


# Generated at 2022-06-23 18:41:56.474203
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    assert formatter._split_lines('usage: prog  other', 20)



# Generated at 2022-06-23 18:42:00.100704
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # Make sure that the constructor works for both main and scripts.
    for name in ['main', 'script']:
        env = Environment(name)
        parser = HTTPieArgumentParser(add_help=False, env=env)
        assert parser.env is env



# Generated at 2022-06-23 18:42:02.901410
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """Test HTTPieArgumentParser.parse_args() method."""
    # sample input for test
    args = Namespace(download = True)
    parser = HTTPieArgumentParser(args)
    parser.parse_args()

# Generated at 2022-06-23 18:42:06.059017
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = HTTPieArgumentParser().parse_args()
    print(args)
test_HTTPieArgumentParser_parse_args()


# Generated at 2022-06-23 18:42:12.341916
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert parser.positional_action_group.title == 'Request'
    assert parser.positional_action_group.description == 'HTTP request URL'
    assert parser.positional_action_group.conflict_handler == 'resolve'

    #assert parser.required_action_group == parser.argument_action_group
    #assert isinstance(parser.argument_action_group, ArgumentDefaultActionGroup)

    #assert len(parser.argument_action_group.actions) == 1
    #assert_url(parser)

    #assert parser.optional_action_group.title == 'Optional arguments'
    #assert parser.optional_action_group.description == (
    #    'Send an HTTP request and get a pyload')
    #assert parser.optional_action_group.conflict_handler == 'res

# Generated at 2022-06-23 18:42:21.330227
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        description="A nicer help formatter.",
        prog='httpie',
        add_help=False,
        formatter_class=HTTPieHelpFormatter,
    )
    
    foo_help = '''
    foo
        help:help:help:help:help:help:help:help:help
        help:help:help:help:help:help:help:help:help
        help:help:help:help:help:help:help:help:help
        help:help:help:help:help:help:help:help:help
        help:help:help:help:help:help:help:help:help
    '''
    parser.add_argument('-f', '--foo', help=foo_help)

    help_str = parser.format_help()

# Generated at 2022-06-23 18:42:23.482381
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    help_formatter=HTTPieHelpFormatter('--foo')
    print(help_formatter._split_lines(__doc__, 80))

# ---- Command Line Interface ----


# Generated at 2022-06-23 18:42:25.458015
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    assert formatter._split_lines("""\
        foo
        bar
    """, 80) == ["foo", "bar", "", ""]

# end


# Generated at 2022-06-23 18:42:28.588800
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    actual = formatter._split_lines('this is\na test', 3)
    assert (actual == ['this is', 'a test', '\n', ''])



# Generated at 2022-06-23 18:42:30.289502
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    h = HTTPieHelpFormatter()
    assert h.__init__(max_help_position=6)



# Generated at 2022-06-23 18:42:34.360144
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    test = formatter._split_lines("""
        a
        b
        """, 30)
    assert test == ['a','b','','','\n']



# Generated at 2022-06-23 18:42:45.649210
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    class MockParser:
        def __init__(self):
            self.indents = [3,3,2,2,4]
            self.width = 20
        def format_help(self):
            return "usage: long_usage \n  -a, --arg1\n  -b, --arg2\n    regular_indent argument \n  -c\n    special_indent argument \n  -d\n"
    parser = MockParser()
    formatter = HTTPieHelpFormatter(max_help_position=3)
    actual = formatter._split_lines(parser.format_help(), parser.width)[-1]
    expected = ' '.join([' ' * parser.indents[i] + '\n' for i in range(1, len(parser.indents))])
    assert actual == expected


# Generated at 2022-06-23 18:42:48.821560
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
  parser = HTTPieArgumentParser()
  parser.error()
  parser.exit()
  parser.print_version()


# Generated at 2022-06-23 18:42:58.797163
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-23 18:43:10.584254
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """Unit test for constructor of class 'HTTPieArgumentParser'.

    """
    # Test with no parameter
    assert not HTTPieArgumentParser()

    # Test with empty 'args' array
    assert not HTTPieArgumentParser(args=[])

    # Test with 'args' array containing one element
    assert HTTPieArgumentParser(args=['--debug'])

    # Test with 'args' array containing more elements
    assert HTTPieArgumentParser(args=['--debug', '--verbose'])

    # Test with parameter 'args' is not string type
    assert HTTPieArgumentParser(args='')

    # Test with parameter 'prog' is string type
    assert HTTPieArgumentParser(prog='--debug')


# Generated at 2022-06-23 18:43:15.816528
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # testing component Constructor by providing default args
    # It should return an object of class HTTPieArgumentParser
    args = HTTPieArgumentParser().parse_args()
    assert isinstance(args, HTTPieArgumentParser)


# This is an integration test

# Generated at 2022-06-23 18:43:25.378145
# Unit test for constructor of class HTTPieArgumentParser

# Generated at 2022-06-23 18:43:30.520312
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert 'This is help argument' == \
        HTTPieHelpFormatter()._split_lines(
            '  This is help argument', 80)[0][1:]
    assert ['This is help argument', '', ''] == \
        HTTPieHelpFormatter()._split_lines(
            '  This is help argument', 80)


# Generated at 2022-06-23 18:43:41.348960
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    """Test the function of constructor of class HTTPieHelpFormatter."""
    formatter = HTTPieHelpFormatter()
    assert formatter.width == 80
    assert formatter.max_help_position == 6
    parser = argparse.ArgumentParser(formatter_class=HTTPieHelpFormatter)
    parser.add_argument('--foo', help=dedent("""
      This is a help info
      with multi-line."""))
    parser.add_argument('some_arg')
    formatter.add_usage(parser.format_usage())
    for action_group in parser._action_groups:
        formatter.start_section(action_group.title)
        formatter.add_text(action_group.description)
        formatter.add_arguments(action_group._group_actions)
        formatter.end_

# Generated at 2022-06-23 18:43:50.570893
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    import argparse
    parser = HTTPieArgumentParser()
    assert parser.add_argument.__self__ is parser
    assert parser.add_argument_group.__self__ is parser
    assert parser.add_mutually_exclusive_group.__self__ is parser
    assert str(parser.description).startswith('CLI')
    assert isinstance(parser.prog, str)
    assert parser.usage is None
    assert parser._positionals
    assert parser._optionals


if __name__ == "__main__":
    test_HTTPieArgumentParser()

# Generated at 2022-06-23 18:43:59.223557
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = _TEST_ARGS
    _HTTPieArgumentParser = HTTPieArgumentParser(args)
    parser = _HTTPieArgumentParser.parse_args()


# Generated at 2022-06-23 18:44:11.177387
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():

    parser = ArgumentParser(description='haha', fromfile_prefix_chars='@')

    args = 'httpie --ignore-stdin -jbv --debug --output=hahah --download'
    args = args.split()
    assert parser.parse_args(args) == Namespace(json=True, debug=True, download=True, output='hahah', pretty='all', verbose=True)

    args = []
    assert parser.parse_args(args) == Namespace(json=False, debug=False, download=False, output=None, pretty='none', verbose=False)

    args = 'httpie --pretty=colors'.split()
    assert parser.parse_args(args) == Namespace(json=False, debug=False, download=False, output=None, pretty='colors', verbose=False)




# Generated at 2022-06-23 18:44:16.964269
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    res = HTTPieArgumentParser().parse_args(
        args=[
            '--traceback',
            'https://httpie.org/docs'
        ]
    )

    assert res.traceback == True
    assert res.url == 'https://httpie.org/docs'

# Generated at 2022-06-23 18:44:22.328774
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(["--json", "--verbose", "http://www.google.com"])
    assert args.json == True
    assert args.verbose == True
    assert args.url == "http://www.google.com"

test_HTTPieArgumentParser_parse_args()
 

# Generated at 2022-06-23 18:44:29.661421
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # 1. parse_args without argument
    p = HTTPieArgumentParser()
    assert len(p.parse_args([]).request_items) == 0
    # 2. parse_args with too many arguments
    p = HTTPieArgumentParser()
    assert len(p.parse_args(['url1', 'url2']).request_items) == 0
    # 3. parse_args with only one argument as url
    p = HTTPieArgumentParser()
    assert len(p.parse_args(['url']).request_items) == 0
    # 4. parse_args with one argument as item
    p = HTTPieArgumentParser()
    assert len(p.parse_args(['key=value']).request_items) == 1
    # 5. parse_args with one argument as item
    p = HTTPieArgumentParser

# Generated at 2022-06-23 18:44:40.701085
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    class MockRawArgumentParser(object):
        def __init__(self, *args, **kwargs):
            self.parents = []
            self.description = ''
            self.epilog = ''
            self.usage = ''
            self.environment_defaults = {}

        def add_argument(self, *args, **kwargs):
            pass

        def add_subparsers(self, *args, **kwargs):
            pass

        def add_parser(self, *args, **kwargs):
            pass

        def error(self, *args, **kwargs):
            pass


# Generated at 2022-06-23 18:44:43.217520
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    c = HTTPieArgumentParser()
    assert c.__class__.__name__ == 'HTTPieArgumentParser'

# Generated at 2022-06-23 18:44:46.034141
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    fmt = HTTPieHelpFormatter()
    assert fmt._split_lines('Hello\nWorld!')[-1] == ''



# Generated at 2022-06-23 18:44:51.758199
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser()

    parser.add_argument('--foo', help='foo\nbar\n\nbaz')
    parser.add_argument('some_arg', help='\n'.join([
        'line1',
        'line2',
        'line3']))
    print(parser.format_help())



# Generated at 2022-06-23 18:45:03.580839
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import unittest
    import sys
    import os
    from contextlib import contextmanager
    from tempfile import NamedTemporaryFile
    
    from httpie import httpie
    
    @contextmanager
    def setup_test_window_size(window_size):
        original_window_size = httpie.httpie.WIN_SIZE
        httpie.httpie.WIN_SIZE = window_size
        yield None
        httpie.httpie.WIN_SIZE = original_window_size
    
    @contextmanager
    def restore_original_stdout():
        original_stdout = sys.stdout
        sys.stdout = open(os.devnull, 'bw')
        yield None
        sys.stdout.close()
        sys.stdout = original_stdout
    
    

# Generated at 2022-06-23 18:45:16.560621
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """
    Unit tests for the constructor of class HTTPieArgumentParser
    """

# Generated at 2022-06-23 18:45:18.129220
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert 1 == 1


# Generated at 2022-06-23 18:45:29.310482
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    import argparse
    # note that this way of testing class is suggested by section:
    #   7. Test Classes and Test Cases
    #  in
    #   https://docs.python.org/3/library/unittest.html#organizing-test-code
    #  I think this is the most convenient way
    assert issubclass(HTTPieArgumentParser, argparse.ArgumentParser)
    assert HTTPieArgumentParser.__doc__ == __doc__
    assert HTTPieArgumentParser.__init__.__doc__ == ArgumentParser.__init__.__doc__
    # there are two properties associated with __init__:
    # 1) HTTPieArgumentParser.__init__.__defaults__
    # 2) HTTPieArgumentParser.__init__.__kwdefaults__
    # so it is tricky to test

# Generated at 2022-06-23 18:45:34.131318
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert parser.description == (
        "A CLI, cURL-like tool for humans."
    )



# Generated at 2022-06-23 18:45:45.043497
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    http_ie_arg_parser = HTTPieArgumentParser()
    http_ie_arg_parser.add_argument("-c", "--cookies",
                                    help="load cookies from FILE before session",
                                    type=str)
    http_ie_arg_parser.add_argument("-d", "--data",
                                    help="HTTP POST data (H)",
                                    type=str)
    http_ie_arg_parser.add_argument("-D", "--dump-header",
                                    help="print headers to DUMP_HEADER and include them in the request",
                                    type=argparse.FileType('wb'))
    http_ie_arg_parser.add_argument("--download",
                                    help="Download URL to OUTPUT_FILE.",
                                    action="store_true")
    http_ie_arg_

# Generated at 2022-06-23 18:45:51.755534
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    test_text= dedent("""
    this is a test
      with a line indented
    """)
    expected_text = dedent("""
    this is a test
    with a line indented

    """)
    assert HTTPieHelpFormatter._split_lines(None, test_text, None) == expected_text.splitlines()



# Generated at 2022-06-23 18:45:53.961935
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert HTTPieHelpFormatter

# Test for _split_lines(self, text, width)

# Generated at 2022-06-23 18:45:57.659980
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    args = '''
    --form POST parameters as form
    --json POST parameters as JSON
    --body POST parameters as JSON'''
    print('\n'.join(HTTPieHelpFormatter()._split_lines(args, 60)))



# Generated at 2022-06-23 18:46:09.802199
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    def _parse(arguments):
        parser = HTTPieArgumentParser()
        return parser.parse_args(arguments.split())

    # form
    args = _parse("httpbin.org/headers --form POST --json name=george")
    assert args.json == {'name': 'george'}
    assert args.verbose
    assert args.all
    assert args.prettify
    assert args.headers == {'Content-Type': 'application/x-www-form-urlencoded'}
    assert args.method == 'POST'

    # data
    args = _parse("httpbin.org/post --data name=george")
    assert args.json == {'name': 'george'}
    assert args.verbose
    assert args.all
    assert args.prettify

# Generated at 2022-06-23 18:46:20.239599
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
  try:
    from httpie import cli as _cli
  except ImportError:
    _cli = None
  class MockHTTPSession(object):
    def __init__(self):
      self.headers = {"accept": 'text/plain'}
      self.config = {}
      self.verify = True
      self.stream = True

  class MockArgs(object):
    def __init__(self):
      self.data = None
  class MockConfig(object):
    def __init__(self):
      self.data = None
  environment = Environment(MockConfig(), MockHTTPSession(), MockArgs())
  http = HTTPieHelpFormatter(environment,MockArgs()) # class HTTPieHelpFormatter()
  args = MockArgs()
  args.data = None
  args.timeout = None
  args.session_

# Generated at 2022-06-23 18:46:29.121696
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # Create parser
    parser = HTTPieArgumentParser()
    # Parse arguments
    args = parser.parse_args('httpie --verbose --debug --help'.split())
    assert args.verbose == True
    assert args.debug == True
    assert args.help == True
    # Parse more arguments
    args = parser.parse_args('httpie --download --traceback --help'.split())
    assert args.download == True
    assert args.traceback == True
    assert args.help == True


# Generated at 2022-06-23 18:46:31.405754
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert HTTPieHelpFormatter()._split_lines('\n123\n', 0) == ['123', '', '']



# Generated at 2022-06-23 18:46:39.101878
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    # check default values of the constructor of class HTTPieHelpFormatter
    hf = HTTPieHelpFormatter(max_help_position=6, indent_increment=2, width=80)
    assert hf.max_help_position == 6
    assert hf.width == 80

    # check a special value of the constructor of class HTTPieHelpFormatter
    hf = HTTPieHelpFormatter(width=40)
    assert hf.width == 40


# Generated at 2022-06-23 18:46:47.786928
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # Since argparse will exit if there's an error, we can't unittest any error
    # case with argparse by using the following command
    # python3 -m unittest discover -v test/
    # We need to find a way to capture the exception thrown out
    httpie_args = [
        'http',
        '-j',
        '-a',
        'httpie',
        'https://httpbin.org/get',
        'Accept-Language:en'
    ]
    # success case
    args = HTTPieArgumentParser().parse_args(httpie_args)
    assert args.json is True
    assert args.auth == 'httpie'
    assert args.url == 'https://httpbin.org/get'
    assert args.headers[0] == ('Accept-Language', 'en')
    #

# Generated at 2022-06-23 18:46:55.855520
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # python -m unittest tests.test_arguments.test_HTTPieArgumentParser
    argparse.ArgumentParser._print_message = _print_message

    # Replacing the actual method is not reliable
    def mock_exit(self, _=None, message=None, status=None):
        # Default values are included because of old Python versions
        # that do not pass them to exit().
        raise SystemExit(status or 0, message or '')
    argparse.ArgumentParser._exit = mock_exit

    env = Environment(stdin=io.BytesIO(), stdin_isatty=True)

    # Test output_file=None, which is default when stdout_isatty=True
    parser = HTTPieArgumentParser(env=Environ(stdout=io.BytesIO(), stdout_isatty=True))

# Generated at 2022-06-23 18:47:06.810407
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Note: This is a unit test, not an integration test. It tests
    # the parser without actually making an HTTP request.
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http://httpbin.org/get'])
    assert 'http://httpbin.org/get' == args.url
    assert 'GET' == args.method
    assert args.headers == []
    assert args.data is None
    assert args.files is None
    assert args.params == []
    assert args.auth is None
    assert args.follow is False
    assert args.timeout == DEFAULT_TIMEOUT
    assert args.max_redirects == 5
    assert args.check_status == False
    assert args.json_pp == False
    assert args.xml_pp == False
    assert args.headers_pp == True

# Generated at 2022-06-23 18:47:19.122205
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    args = HTTPieArgumentParser().parse_args(['-h'])
    print(args)

# Generated at 2022-06-23 18:47:29.935108
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie.httpie import main
    from httpie.core import main
    from httpie.plugins import plugin_manager
    from httpie.input import get_input_stream

    from httpie import ExitStatus
    from httpie.compat import is_windows
    from httpie.core import VERSION
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.plugins import plugin_manager
    from httpie.config import Config, read_configs
    from httpie.input import get_input_stream
    from httpie.context import Environment
    from httpie.context import Environment
    from httpie.core import main
    from httpie.core import main
    from httpie.core import main
    from httpie.core import main
    from httpie.core import main
    from httpie.core import main
   