

# Generated at 2022-06-23 18:37:25.837686
# Unit test for constructor of class HTTPieHelpFormatter

# Generated at 2022-06-23 18:37:29.636075
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    parser.add_argument('-a')
    parser.add_argument('-j')
    parser.add_argument('-c')
    args = parser.parse_args()

# Generated at 2022-06-23 18:37:30.813008
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    parser.print_help()

# Generated at 2022-06-23 18:37:32.672011
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():

    hpf = HTTPieHelpFormatter(4, max_help_position=4)



# Generated at 2022-06-23 18:37:42.253471
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        formatter_class=HTTPieHelpFormatter
    )
    parser.add_argument('--foo', help="""
        This is a normal argument.

        This is a second paragraph.
        """)
    parser.add_argument('bar', help="""
        This is a normal argument.

        This is a second paragraph.
        """)
    help_text = parser.format_help()
    lines = help_text.splitlines()
    assert '--foo  This is a normal argument.' == lines[3]
    assert '            This is a second paragraph.' == lines[4]
    assert '        bar  This is a normal argument.' == lines[6]
    assert '            This is a second paragraph.' == lines[7]



# Generated at 2022-06-23 18:37:44.899992
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    import pprint
    parser = HTTPieArgumentParser()
    pprint.pprint(parser.args.__dict__)

if __name__ == "__main__":
    test_HTTPieArgumentParser()

# Generated at 2022-06-23 18:37:52.133735
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        prog="http",
        formatter_class=HTTPieHelpFormatter,
        description="HTTPie %s, a CLI, cURL-like tool for humans." % __version__,
        epilog="See https://httpie.org/ for detailed usage information."
    )
    parser.add_argument('--bw', help='Set bandwidth limit in bytes/second.')
    args = parser.parse_args(["--help"])


# Generated at 2022-06-23 18:37:55.673756
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    class Args:
        pass
    args = Args()
    args.ignore_stdin = False
    args.pretty = 'all'
    args.style = 'solarized'
    args.print = 'h'
    args.stream = False
    assert(args)



# Generated at 2022-06-23 18:38:00.842888
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    env = Environment(stdout_isatty=True, stdin_isatty=False)
    argv = ['GET', 'http://localhost', '-v']
    args = HTTPieArgumentParser(env=env).parse_args(argv)
    assert args.url == 'http://localhost'
    assert args.method == 'GET'
    assert args.verbose

# Generated at 2022-06-23 18:38:11.663573
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """HTTPieArgumentParser
    """
    test_name='HTTP'
    test_version='1.0'
    test_description='description'
    test_parser_class=HTTPieArgumentParser
    test_formatter_class=HTTPieHelpFormatter
    test_env=Environment()
    test_prog='http'
    test_add_help=True
    test_httpie_prog='http'

# Generated at 2022-06-23 18:38:15.616997
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """Assert that `HTTPieArgumentParser.parse_args` correctly handles
    `--style` option.
    """
    args = parser.parse_args(['--style=foo'])
    assert args.style == 'foo'


# Generated at 2022-06-23 18:38:17.353786
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
  parser = HTTPieArgumentParser()
  print(parser)



# Generated at 2022-06-23 18:38:23.379491
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    local_args = ['http', 'https://httpbin.org/post']
    local_args += ['--form', '--prettify=all', '--output=test.txt', 'one=1', 'two==2']
    par = HTTPieArgumentParser(local_args)
    print(par.request_items)
    print(par.headers)
    print(par.output_file)
    print(par.params)
    print(par.prettify)
    print(par.url)


# Generated at 2022-06-23 18:38:26.046491
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    httpie_argument_parser = HTTPieArgumentParser()
    assert httpie_argument_parser is not None
    print(httpie_argument_parser.__dict__)

# Generated at 2022-06-23 18:38:36.461369
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    global httpie_argparser
    httpie_argparser = HTTPieArgumentParser()

    # test 1:
    url = 'https://google.com/'
    headers = ['content-type:application/json']
    data = {'name': 'value'}
    files = [('file.txt','file.txt')]
    args = httpie_argparser.parse_args(['-v','-h']+headers+['-f','-j',url]+data+['-F']+files)
    assert_equal(args.url, url)
    assert_equal(args.headers, headers)
    assert_equal(args.data, data)
    assert_equal(args.files, files)
    assert_equal(args.verbose, True)
    assert_equal(args.headers, True)
    assert_equal

# Generated at 2022-06-23 18:38:47.527808
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        formatter_class=HTTPieHelpFormatter,
        description='A command line HTTP client.'
    )
    parser.add_argument(
        '-b', '--body',
        type=str,
        help=('\n'
              'Raw data to post.')
    )
    parser.add_argument(
        '-f', '--form',
        type=str,
        help=('\n'
              'Form data to post.')
    )
    parser.add_argument(
        '--json',
        type=str,
        help=('\n'
              'JSON data to post.')
    )
    parser.print_help()


# Generated at 2022-06-23 18:38:55.488676
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    print(HTTPieHelpFormatter.__doc__)
    print(HTTPieHelpFormatter.__name__)
    print(HTTPieHelpFormatter.__module__)
    print(HTTPieHelpFormatter.__init__.__doc__)
    print(HTTPieHelpFormatter._split_lines.__doc__)
test_HTTPieHelpFormatter()

# TODO: consistent with --ignore-stdin

# TODO: Limit the number of redirects followed by default.
# TODO: HTTPieError
# TODO: Improve argparse error messages
# TODO: Saner default for --form
# TODO: Support file:/// URLs
# TODO: Support HTTP_PROXY_REQUIRED env variable
# TODO: Support --traceback option.



# Generated at 2022-06-23 18:38:57.401479
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    try:
        HTTPieArgumentParser()
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-23 18:39:03.202727
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    class TestFormatter(object):
        def __init__(self, max_help_position=6, *args, **kwargs):
            # A smaller indent for args help.
            kwargs['max_help_position'] = max_help_position
            super().__init__(*args, **kwargs)

    formatter = TestFormatter()
    assert formatter.max_help_position == 6


# Generated at 2022-06-23 18:39:11.006423
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    # TODO: (1) add signature of HTTPieArgumentParser to test.
    #       (2) add new test functions for HTTPieArgumentParser.
    assert parser.env.stdout_isatty == True
    assert parser.env.stderr_isatty == True
    assert parser.env.stdout_encoding == 'utf8'
    assert parser.args.output_file == None


# Generated at 2022-06-23 18:39:23.286045
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test of the ArgumentParser object
    argparser = HTTPieArgumentParser()
    assert argparser.formatter_class is argparse.RawTextHelpFormatter
    assert argparser.error == argparse.ArgumentParser.error
    assert argparser.usage == argparse.ArgumentParser.usage
    assert argparser.print_help == argparse.ArgumentParser.print_help

    # Test of the HTTPieArgumentParser object
    httpie_argparser = HTTPieArgumentParser()

    # Test of method _get_prog with prog=None
    assert httpie_argparser._get_prog() == 'HTTPie'

    # Test of method _get_prog with prog='some_prog'
    httpie_argparser.prog = 'some_prog'
    assert httpie_argparser._get_prog

# Generated at 2022-06-23 18:39:32.191415
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # Test HTTPieArgumentParser with no arguments
    sys.argv = ["http"]
    args = ArgumentParser().parse_args()
    assert args.url is None
    assert args.debug == False
    assert args.method == 'GET'
    assert args.data == None
    assert args.headers == []
    assert args.params == []
    assert args.files == {}

    # Test HTTPieArgumentParser with one arg: url
    sys.argv = ["http", "http://192.168.254.1"]
    args = ArgumentParser().parse_args()
    assert args.url == 'http://192.168.254.1'
    assert args.debug == False
    assert args.method == 'GET'
    assert args.data == None
    assert args.headers == []
    assert args.params == []

# Generated at 2022-06-23 18:39:34.293481
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    global parser
    parser = HTTPieArgumentParser()

test_HTTPieArgumentParser()


# Generated at 2022-06-23 18:39:46.289682
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # Test input data for construction of class HTTPieArgumentParser
    # function: __init__
    args_list = ['https://httpie.org/search', '--request', '-d', '{}', 'key=value']

# Generated at 2022-06-23 18:39:59.504325
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    capture = io.StringIO()
    parser = HTTPieArgumentParser(prog='http',
                                  env=Environment(stdout=capture))
    parser.add_argument('--headers')
    parser.add_argument('--body')
    parser.add_argument('--method')
    parser.add_argument('--output')
    parser.add_argument('--download')
    parser.add_argument('--download-resume')
    parser.add_argument('--offline')
    parser.add_argument('--stream')
    parser.add_argument('--verify')
    parser.add_argument('--auth')
    parser.add_argument('--auth-type')
    parser.add_argument('--proxy')
    parser.add_argument('--all')
    parser.add_argument('--debug')
   

# Generated at 2022-06-23 18:40:07.084358
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['http'])
    assert args.method is None
    assert args.url is None

    args = parser.parse_args(['http', 'url'])
    assert args.method is None
    assert args.url == 'url'

    args = parser.parse_args(['http', 'method', 'url'])
    assert args.method == 'method'
    assert args.url == 'url'

    args = parser.parse_args(['http', 'url', 'key', 'value'])
    assert args.method == 'url'
    assert args.url == 'key'
    assert args.request_items == [KeyValueArgType()('value')]


# Generated at 2022-06-23 18:40:10.644300
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert parser is not None


if __name__ == '__main__':
    test_HTTPieArgumentParser()

# Generated at 2022-06-23 18:40:16.345728
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    # Imports:
    import argparse
    # Setup:
    text = "help of format=pretty"
    # Exercise
    formatter = HTTPieHelpFormatter()
    result = formatter._split_lines(text, 72)
    expected = ['help of format=pretty', '', '']
    # Verify
    assert result == expected


# Generated at 2022-06-23 18:40:23.252909
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
   parser = argparse.ArgumentParser(
       prog='http',
       description='HTTPie %s' % httpie.__version__,
       epilog='See also: http --help, http --help-all',
       formatter_class=HTTPieHelpFormatter,
       add_help=False
   )
   parser.add_argument('--version', action='version',
                       version='HTTPie %s' % httpie.__version__)

# http -h

# Generated at 2022-06-23 18:40:31.145734
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    def check(text):
        actual = HTTPieHelpFormatter(
            max_help_position=6
        )._split_lines(text, 40)
        expected = dedent(text).strip() + '\n\n'
        assert expected.splitlines() == actual

    # Arguments help shouldn't be indented.
    check('''\
        foo
          bar
        baz
    ''')

    # Arguments help shouldn't be indented.
    check('''\
        foo
          bar
        baz
    ''')

    # But the description can be indented and contain new lines.
    check('''
        Foo.

          - bar: 42
          - baz: quux

        Lorem ipsum.
    ''')

    # Optional arguments should work.

# Generated at 2022-06-23 18:40:32.620206
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert parser.prog == 'http'
    assert parser.usage is None

# Generated at 2022-06-23 18:40:33.670900
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    print(dict(vars(parser.args)))

# Generated at 2022-06-23 18:40:36.059422
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    HTTPieHelpFormatter()

# Create a parser function that has a @staticmethod decorator

# Generated at 2022-06-23 18:40:40.553367
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test initialization of HTTPieArgumentParser
    args = HTTPieArgumentParser().parse_args()
    assert args.url == DEFAULT_URL
    assert args.method == HTTP_GET
    assert args.data == {}


# Generated at 2022-06-23 18:40:43.924488
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
        formatter = HTTPieHelpFormatter()
        assert formatter._split_lines("""\
            hello
              world
                """, 80) == ['hello', '  world', '\n']



# Generated at 2022-06-23 18:40:48.880305
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert parser.description == "CLI HTTP client"
    assert parser.exit_status is None
    assert parser.error_msg == ''
    assert parser.has_stdin_data is False
    # assert parser.args
    assert parser.formatter_class == RawHelpFormatter



# Generated at 2022-06-23 18:40:54.340076
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    """
    This unit test is used to test the constructor of class HTTPieHelpFormatter
    :return:
    """
    formatter = HTTPieHelpFormatter(max_help_position=6)
    assert formatter._max_help_position == 6



# Generated at 2022-06-23 18:40:58.355548
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():

    # Tested on Mac

    # Prepare info needed to run the HTTPieArgumentParser
    parser = HTTPieArgumentParser()
    assert isinstance(parser, HTTPieArgumentParser)
    parser.run()



# Generated at 2022-06-23 18:41:07.302672
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args()
    assert repr(args) == "Namespace(auth=None, auth_type='basic', auth_plugin=None, config_dir='~/.httpie', download=False, download_resume=False, form=False, headers=[], ignore_netrc=False, ignore_stdin=False, method=None, multipart_data=False, output_file=None, output_file_specified=False, output_options='HBI', output_options_history='HBI', params=[], prettify='none', request_items=None, traceback=False, url=None, verbose=False)"

if __name__ == '__main__':
    test_HTTPieArgumentParser_parse_args()

# Generated at 2022-06-23 18:41:10.567043
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    """Create an instance of class HTTPieHelpFormatter
    """
    args = HTTPieHelpFormatter()
    return args
# End of unit test for constructor of class HTTPieHelpFormatter



# Generated at 2022-06-23 18:41:15.619007
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(description='description',
                                     formatter_class=HTTPieHelpFormatter)
    parser.add_argument('-b', type=int, help='bar\nfoo\n\n')
    parser.add_argument('-a', type=int, help='Wooow\n    ')
    parser.print_help()



# Generated at 2022-06-23 18:41:22.837921
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Local import to avoid setup.py complaining about missing packages
    from httpie.compat import is_windows, is_py26, is_py27, is_py34

    parser = HTTPieArgumentParser(prog='http')
    args = parser.parse_args([])

# Generated at 2022-06-23 18:41:27.090078
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    parser.parse_args(['http', '--version'])
    assert parser.args.http2
    assert parser.args.offline
    assert parser.args.download
    assert parser.args.session

# Generated at 2022-06-23 18:41:30.485785
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    help_str = '''Hello
      World'''
    assert HTTPieHelpFormatter()._split_lines(help_str, 80) == ['Hello', 'World', '', '']
#



# Generated at 2022-06-23 18:41:31.450548
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    pass



# Generated at 2022-06-23 18:41:33.656929
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO: Implement test
    pass
# Backwards compatibility; taken from 1.0.3

# Generated at 2022-06-23 18:41:40.686990
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    ap = HTTPieArgumentParser()
    ap.add_argument('--foo', action='store_true')
    ap.add_argument('--bar', action='store_false')
    ap.add_argument('--baz', action='store_false')
    args = ap.parse_args(['--foo', '--bar'])
    assert args.foo
    assert not args.bar
    assert args.baz



# Generated at 2022-06-23 18:41:52.624700
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """
    Unit test for method parse_args of class HTTPieArgumentParser
    """
    test = pd.DataFrame(columns=['args', 'expected'])

# Generated at 2022-06-23 18:42:02.554674
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    try:
        from unittest import mock
    except ImportError:
        import mock

    reset_formatter = mock.Mock()
    reset_formatter.return_value = None

    arg = argparse.ArgumentParser()
    arg.add_argument("-v", "--verbosity", help = """This is help for verbosity
    that should be indented and contains several lines""")
    arg.add_argument("-c", "--count", help="Help for count")
    arg.add_argument("-f", "--foo", help="Help for foo")

    with reset_formatter.reset_mock():
        parser = argparse.ArgumentParser(formatter_class=HTTPieHelpFormatter)
        parser.add_help = False

# Generated at 2022-06-23 18:42:05.853611
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    lines = HTTPieHelpFormatter.split_lines('Test\nTest')
    expected =  ['Test', 'Test', '']
    assert lines == expected


# Generated at 2022-06-23 18:42:17.440405
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    httpie_args = HTTPieArgumentParser().parse_args(['http', 'GET', 'https://example.com', '-v'])
    assert isinstance(httpie_args, argparse.Namespace)
    # Attributes
    assert httpie_args.all
    assert httpie_args.auth is None
    assert httpie_args.auth_type is None
    assert httpie_args.body
    assert httpie_args.body_include
    assert httpie_args.check_status
    assert httpie_args.compress
    # assert httpie_args.config_dir == os.path.join(os.path.expanduser('~'), '.httpie')
    assert httpie_args.download
    assert httpie_args.download_resume
    assert httpie_args.form
    assert httpie_args

# Generated at 2022-06-23 18:42:28.255860
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    from argparse import ArgumentParser
    parser = ArgumentParser(
        description='title',
        formatter_class=HTTPieHelpFormatter)
    parser.add_argument('--foo', help='  line1\n  line2')
    parser.add_argument('bar', help='\n  line1\n\n  line2\n')
    assert parser.format_help() == dedent("""
        usage: test [-h] [--foo FOO] bar

        title

        positional arguments:
          bar        

                  line1

                  line2
          
        optional arguments:
          -h, --help  show this help message and exit
          --foo FOO   line1
                      line2

    """).lstrip()



# Generated at 2022-06-23 18:42:31.362461
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['GET', 'https://google.com'])
    assert args.method == 'GET'
    assert args.url == 'https://google.com'
    assert args.verify == True



# Generated at 2022-06-23 18:42:44.313601
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("plain")
    parser.add_argument("-d", "--data")
    parser.add_argument("-F", "--form")
    parser.add_argument("-f", "--files", nargs=2)
    parser.add_argument("--json", nargs=argparse.REMAINDER)

    args = parser.parse_args(['plain-arg', '-d', 'data-arg', '-F', 'form-arg',
                              '-f', 'files-arg1', 'files-arg2', '--json', 'json-arg1', 'json-arg2'])

    return args

args = test_HTTPieArgumentParser_parse_args()

print(args.plain)

# Generated at 2022-06-23 18:42:55.456455
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    from types import SimpleNamespace

    parser = HTTPieArgumentParser()
    args = SimpleNamespace()
    args.url = 'http://127.0.0.1:5000/api/median?list=1,2,3'
    args.verbose = False
    args.all = True
    args.quiet = False
    args.offline = False
    args.output_file_specified = False
    args.download = False
    args.download_resume = False
    args.traceback = True
    args.output_options = None
    args.output_options_history = None
    args.method = HTTP_GET
    args.headers = []
    args.data = []
    args.request_items = []
    args.params = []
    args.dump_props = 'all'
    args.pre

# Generated at 2022-06-23 18:43:00.586933
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        description="\nDESC\n\n",
        usage="\nUsage\n",
        formatter_class=HTTPieHelpFormatter
    )
    parser.add_argument("--foo", help="\nhelp")
    print(parser.format_help())


# Generated at 2022-06-23 18:43:06.267890
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    parser.parse_args(['-h'])
    parser.parse_args(['--h'])
    parser.parse_args(['-V'])
    parser.parse_args(['--version'])
    parser.parse_args(['--version-info'])
    parser.parse_args(['--version-info'])
    parser.parse_args(['--version-info'])
    parser.parse_args(['--colors'])
    parser.parse_args(['--style'])
    parser.parse_args(['--debug'])
    parser.parse_args(['--traceback'])
    parser.parse_args(['--print'])
    parser.parse_args(['--output-options'])

# Generated at 2022-06-23 18:43:08.782996
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    args = parser.parse_args()
    assert args.url == args.base_url, 'HTTPieArgumentParser() failed to initialize the url argument'

test_HTTPieArgumentParser()

# Generated at 2022-06-23 18:43:21.471075
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    rootparser = HTTPieArgumentParser()
    print(rootparser)


# Generated at 2022-06-23 18:43:32.966781
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from httpie.input import KeyValue
    from httpie.utils import unicode, bytes
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth, HTTPDigestAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    parser = HTTPieArgumentParser()

    # Pass an empty list, but the method will take sys.argv[1:]
    args = parser.parse_args([])

    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.body == None
    assert args.compress == False
    assert args.download == False
    assert args.follow == False
    assert args.follow_

# Generated at 2022-06-23 18:43:34.319041
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert HTTPieHelpFormatter.__doc__ is not None



# Generated at 2022-06-23 18:43:35.461462
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()


# Generated at 2022-06-23 18:43:36.884157
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert HTTPieHelpFormatter.__name__ == 'HTTPieHelpFormatter'



# Generated at 2022-06-23 18:43:47.033513
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test case 1:
    with pytest.raises(SystemExit):
        HTTPieArgumentParser('http').parse_args()
    # Test case 2:
    with pytest.raises(SystemExit):
        HTTPieArgumentParser(['-u', 'john:passwd', 'http://httpbin.org/headers', '-v']).parse_args()
    # Test case 3:
    with pytest.raises(SystemExit):
        HTTPieArgumentParser(['http://httpbin.org/headers', 'User-Agent:httpie-unittest']).parse_args()
    # Test case 4:
    arg_parser = HTTPieArgumentParser(['-v','https://httpbin.org/headers', 'User-Agent:httpie-unittest']).parse_args()
    assert arg_parser.url

# Generated at 2022-06-23 18:43:49.227689
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter(max_help_position=3)
    assert isinstance(formatter, RawDescriptionHelpFormatter)



# Generated at 2022-06-23 18:43:57.572457
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(args=[])
    assert args.output_file is None
    assert args.output_file_specified is False
    assert args.auth_type is None
    assert args.auth is None
    assert args.auth_plugin is None
    assert args.ignore_stdin is False
    assert args.traceback is False
    assert args.download is False
    assert args.download_resume is False
    assert args.pretty is None
    assert args.prettify is None
    assert args.style == DEFAULT_STYLE
    assert args.style_sheet is None
    assert args.verbose is False
    assert args.all is False
    assert args.headers is None
    assert args.data is None
    assert args.params is None
    assert args.files

# Generated at 2022-06-23 18:44:09.477933
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # Prepare the test
    with HTTPResponseMock([('HTTP/1.1', 200)]) as r:
        rd = {'status': 200, 'status_line': '200 OK', 'request': {'url': 'http://test.test'}}
        r.json = lambda *arg, **kwargs: rd
        env = Environment()
        env.stdout = open(os.devnull, 'w')
        env.stderr = open(os.devnull, 'w')
        env.stdout_isatty = False
        env.stderr_isatty = False
        # We need to disable the input as the test may not have access to a console
        # so the program will crash on input
        env.stdin_isatty = False

# Generated at 2022-06-23 18:44:12.212112
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    httpie_help_formatter = HTTPieHelpFormatter(max_help_position=6)
    assert httpie_help_formatter._split_lines('http', 6) == ['http\n\n']



# Generated at 2022-06-23 18:44:23.309958
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    from collections import namedtuple
    from unittest import TestCase
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.plugins import AuthPlugin

    class MyTestPlugin(AuthPlugin):
        auth_type = 'test_plugin'
        description = "Test plugin"

        def get_auth(self, username, password):
            return username
    # See https://github.com/jakubroztocil/httpie/pull/1412
    class TestHTTPieHelpFormatter(TestCase):
        def setUp(self):
            self.parser = argparse.ArgumentParser(
                prog='http',
                formatter_class=HTTPieHelpFormatter)


# Generated at 2022-06-23 18:44:25.247688
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    parser.parse_args(args=['none'])



# Generated at 2022-06-23 18:44:29.151247
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    http = HTTPieArgumentParser()

if __name__ == '__main__':
    test_HTTPieArgumentParser()

# Generated at 2022-06-23 18:44:29.814063
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    pass


# Generated at 2022-06-23 18:44:32.798485
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    env = Environment()
    parser = HTTPieArgumentParser(env=env)
    assert parser.env == env



# Generated at 2022-06-23 18:44:42.325712
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    this = HTTPieArgumentParser()
    # test for method parse_args of class HTTPieArgumentParser
    # test for method parse_args of class HTTPieArgumentParser

    assert True == True

# Generated at 2022-06-23 18:44:49.691046
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    with mock.patch('httpie.cli.argparser.sys.exit') as sys_exit_mock:
        with mock.patch('httpie.cli.argparser.print') as print_mock:
            with mock.patch('httpie.cli.argparser.os') as os_mock:
                os_mock.isatty.return_value = True
                parser = HTTPieArgumentParser()
                args = parser.parse_args(args=[], namespace=argparse.Namespace())



# Generated at 2022-06-23 18:45:01.964769
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    args = HTTPieArgumentParser().parse_args()
    assert args.url == 'https://repo1.maven.org/maven2/org/apache/maven/plugins/maven-compiler-plugin/3.8.0/maven-compiler-plugin-3.8.0.pom'
    assert args.auth == None
    assert args.auth_plugin == None
    assert args.auth_type == None
    assert args.body == None
    assert args.body_from_file == None
    assert args.check_status == True
    assert args.compress == False
    assert args.data == None
    assert args.data_binary == False
    assert args.download == False
    assert args.download_resume == False
    assert args.download_resume_size == None
    assert args.timeout

# Generated at 2022-06-23 18:45:14.392165
# Unit test for constructor of class HTTPieHelpFormatter

# Generated at 2022-06-23 18:45:26.724497
# Unit test for constructor of class HTTPieHelpFormatter

# Generated at 2022-06-23 18:45:33.601040
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        formatter_class=HTTPieHelpFormatter,
        description='This is the description.\nIt is on multiple lines',
    )


# Generated at 2022-06-23 18:45:38.862656
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    parser.error = Mock()

    # arguments = ['-v']
    # parser.parse_args(arguments)
    # assert parser.error.call_args[0][0] == "argument -v: ignored explicit argument '-v'"

    arguments = ['-b']
    parser.parse_args(arguments)
    assert parser.error.call_args[0][0] == "argument -b: ignored explicit argument '-b'"

    parser.error = Mock()
    arguments = ['--form']
    parser.parse_args(arguments)
    assert parser.error.call_args[0][0] == "argument --form: ignored explicit argument '--form'"

    parser.error = Mock()
    arguments = ['--print=B']
    parser.parse_args(arguments)


# Generated at 2022-06-23 18:45:41.510078
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    http_parser = HTTPieArgumentParser()
    args = http_parser.parse_args()
    assert type(args) is argparse.Namespace

# Generated at 2022-06-23 18:45:49.777386
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # test_joint_partial_invalid_form
    # args = ['http', '--form', 'foo@', 'bar=baz']
    # expected_output = ('foo', ('baz', 'bar'))
    args = ['http', '--form', 'foo@', 'bar=baz']
    expected_output = ('foo', ('baz', 'bar'))
    parser = HTTPieArgumentParser()
    parser.add_argument('--form', action='store_true')
    parsed_args = parser.parse_args(args)
    assert not parsed_args.form
    assert parsed_args.request_items[0].key == expected_output[0]
    assert parsed_args.request_items[0].value == expected_output[1]

    # test_partial_invalid_form_with_double_

# Generated at 2022-06-23 18:45:52.544637
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    class arg():
        def __init__(self, help):
            self.help = help

    f = HTTPieHelpFormatter()
    assert f._split_lines(arg.__init__.__doc__, 50) == ['A smaller indent for args help.', '']



# Generated at 2022-06-23 18:46:01.624207
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO: better test coverage
    from httpie.core import main
    from httpie.core import program
    from httpie.core import get_exit_status
    from httpie.core import validate_config_dir
    from httpie.core import ensure_config_dir
    from httpie.core import get_config_dir
    from httpie.core import EXIT_OK
    import os
    
    stream = io.StringIO()
    sys.stderr = stream
    
    # (1) Test when there is no config_dir
    httpie_dir = os.path.dirname(httpie.__file__)
    httpie_dir_parent = os.path.dirname(httpie_dir)
    sys.argv = ['http', 'https://httpie.org']
    # Ensure that httpie.org

# Generated at 2022-06-23 18:46:09.669713
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    from io import StringIO
    import sys
    sys.stdout = StringIO()
    parser = argparse.ArgumentParser()
    parser.add_argument("echo", help="echo the string you use here")
    parser.add_argument("-s", "--square", help="display a square of a given number",
                        type=int)
    parser.add_argument("-v", "--verbosity", help="increase output verbosity",
                        action="count", default=0)
    #parser.print_help()
    #sys.stdout.getvalue()


# Generated at 2022-06-23 18:46:20.239215
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    import os
    from io import StringIO

    class Args(object):
        """ Mock object for argparse.Namespace """
        def __init__(self):
            self.headers = []
            self.data = []
            self.files = []
            self.params = []
            self.method = "GET"
            self.url = "http://127.0.0.1:17980/api/v1/nodes"

    # Construct HTTPieArgumentParser object
    env = Environment()
    parser = HTTPieArgumentParser(env=env)

    # Construct args object
    args = Args()

    # Test when headers is not None
    args.headers = [('X-Requested-By', 'ambari')]
    args = parser.parse_args(args)

# Generated at 2022-06-23 18:46:33.529830
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():

    formatter = HTTPieHelpFormatter(max_help_position=80)
    assert formatter._split_lines('\n', 80) == ['\n\n']
    assert formatter._split_lines('fff\n', 80) == ['fff\n\n']
    assert formatter._split_lines('\n\n', 80) == ['\n\n\n\n']
    assert formatter._split_lines('\n\n\n', 80) == ['\n\n\n\n\n']
    assert formatter._split_lines('\n\n\n\n', 80) == ['\n\n\n\n\n\n']
    assert formatter._split_lines('\n  fff\n', 80) == ['fff\n\n']

# Generated at 2022-06-23 18:46:39.644145
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
   help_formatter = HTTPieHelpFormatter()
   help_string = '''\
    arg_help
    arg_help_cont

    arg_help_indented'''
   expected_string = '''\
arg_help
arg_help_cont

arg_help_indented
'''
   assert expected_string == help_formatter._split_lines(help_string, 20)



# Generated at 2022-06-23 18:46:42.182323
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    args = HTTPieArgumentParser(env=Environment()).parse_args([])
    assert args.__class__.__name__ == "Namespace"


# Generated at 2022-06-23 18:46:53.926444
# Unit test for constructor of class HTTPieArgumentParser

# Generated at 2022-06-23 18:47:05.286278
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    epilog = '\nHTTPie %s, requests %s, Python %s.' % (
        __version__,
        requests.__version__,
        '{0.major}.{0.minor}.{0.micro}'.format(sys.version_info),
    )
    parser = HTTPieArgumentParser(
        epilog=epilog,
        prog='http',
        formatter_class=argparse.RawTextHelpFormatter,
        description='A command line HTTP client that will make you smile.'
    )
    assert parser.prog == 'http'
    assert parser.description == 'A command line HTTP client that will make you smile.'
    assert parser.epilog.startswith('\nHTTPie ')
    assert parser.formatter_class == argparse.RawTextHelpFormatter


# Unit

# Generated at 2022-06-23 18:47:18.221172
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    from httpie.core import main
    from httpie.output.streams import get_argparser_kwargs
    args = main(args=['get', 'example.org'], **get_argparser_kwargs())
    args = HTTPieArgumentParser().parse_args(args)
    assert args.headers == {}
    assert args.data == {}
    assert args.params == {}
    assert args.files == {}
    assert args.method is None
    assert args.url == 'https://example.org'
    assert args.ignore_stdin is False
    assert args.output_options == OUTPUT_OPTIONS_DEFAULT
    assert args.output_options_history == OUTPUT_OPTIONS_DEFAULT
    assert args.output_file is None
    assert args.output_file_specified is False
    assert args.download

# Generated at 2022-06-23 18:47:29.618322
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """Illustrates, how to write unit tests for methods."""
    # Create an instance of an argument parser
    parser_instance = HTTPieArgumentParser(add_help=False)
    # Create an instance of parser arguments
    args_instance = parser_instance.parse_args()
    # Check if testing arguments instance is a instance of parser arguments
    assert isinstance(args_instance, argparse.Namespace)
from io import BytesIO
from urllib.parse import urlsplit
from collections import namedtuple
from os import devnull
from ssl import CertificateError, match_hostname
# Open an instance of BytesIO, to use it as a file-like object
_devnull = BytesIO()