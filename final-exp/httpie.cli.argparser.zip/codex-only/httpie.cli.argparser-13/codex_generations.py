

# Generated at 2022-06-23 18:37:37.036963
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    http = HTTPie()
    http.args = attrdict.AttrDict()
    http.args.url = "http://example.com"
    http.args.request_items = ["user:admin", "password:passwd", "role:admin"]
    http.args.method = ""
    http.args.auth = ""
    http.args.auth_plugin = ""
    http.args.auth_type = ""
    http.args.headers = ["Content-Type:application/json", "Accept:json"]
    http.args.data = []
    http.args.files = ["./test_command.json"]
    http.args.params = []
    http.args.json = False
    http.args.form = False
    http.args.output_file = "./output_file.json"

# Generated at 2022-06-23 18:37:40.846086
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    print("==== Unit test for constructor of class HTTPieHelpFormatter ====")
    try:
        hf = HTTPieHelpFormatter()
        hf.add_argument("--help", help="help")
    except Exception as e:
        print("Exception occured: %s" % (e))


# Generated at 2022-06-23 18:37:51.294043
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        description='Foo bar baz.',
        formatter_class=HTTPieHelpFormatter
    )
    parser.add_argument('--foo', help='''\
        Foo to some
        place.
        ''')
    parser.add_argument('bar', help='''\
        Bar to some
        other place.

        And a paragraph.
        ''')
    parser.add_argument('baz', help='Baz to somewhere else.')

# Generated at 2022-06-23 18:38:00.181343
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # set env.is_windows, env.stdout_isatty, env.stderr_isatty, env.stdout, env.stderr
    env = Environment()
    env.is_windows = True
    env.stdout_isatty = True
    # env.stderr_isatty = True
    env.stdout = sys.stdout
    env.stderr = sys.stderr

    # Create the parser
    parser = HTTPieArgumentParser(env=env)
    
    # Test case 1
    sys.argv = [sys.argv[0], '--method', 'GET', '--headers', 'Accept: */*', '--headers', 'User-Agent: HTTPie/1.0.3']
    args = parser.parse_args()

# Generated at 2022-06-23 18:38:11.091451
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # pylint: disable=C0103,C0111
    maxDiff = None
    stdin = io.BytesIO(b"""--form
Content-Type: application/json

{"foo":"bar"}
--form
Content-Type: application/json

{"bar":"baz"}""")
    stdin_isatty = True

    env = Env(
        stdin=stdin,
        stdin_isatty=stdin_isatty
    )
    args = HTTPieArgumentParser(env=env).parse_args(['localhost'])

    #Test __init__
    assert args.__init__.__defaults__ == (None, '_')
    assert args.__init__.__kwdefaults__ == {'env': None, 'informatter': None}
    assert args.__init__

# Generated at 2022-06-23 18:38:12.772936
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert parser is not None

if __name__ == "__main__":
    # Unit test for constructor of class HTTPieArgumentParser
    test_HTTPieArgumentParser()
    print("HTTPieArgumentParser test passed!")

# Generated at 2022-06-23 18:38:21.178312
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert str(HTTPieHelpFormatter())

# class Parser(argparse.ArgumentParser):
#     """Argument parser with a custom error formatter."""
#
#     def __init__(self, *args, **kwargs):
#         kwargs['formatter_class'] = HTTPieHelpFormatter
#         super().__init__(*args, **kwargs)
#
#     def error(self, message):
#         """Overrides argparse's error method to allow multiline error
#         messages.
#
#         """
#         message = dedent(message).rstrip() + '\n'
#         print(message, file=sys.stderr)
#         self.print_usage(sys.stderr)
#         sys.exit(2)



# Generated at 2022-06-23 18:38:22.756145
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
	print('pass')


# Generated at 2022-06-23 18:38:26.347797
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser(env = None)
    assert parser.args is None
    assert parser.env == Environment()


# Generated at 2022-06-23 18:38:32.081976
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    assert formatter._split_lines('abc', 6) == ['abc\n\n']
    assert formatter._split_lines('  \n  a\n  b\n  c  ', 6) == ['a\n', 'b\n', 'c\n\n']


# Generated at 2022-06-23 18:38:36.987208
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    # Give the parser some args to parse
    args = parser.parse_args(['https://www.foo.com', 'Foo:Bar'])
    assert args.url == 'https://www.foo.com'
 
    # With stdin
    args = parser.parse_args(['https://www.foo.com', 'Foo:Bar'], stdin=StringIO('{"Foo":"Bar", "Baz":"Tom"}'))
    assert args.headers['Foo'] == 'Bar, If-None-Match'


# Generated at 2022-06-23 18:38:39.101274
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    assert True

test_HTTPieArgumentParser()


# Generated at 2022-06-23 18:38:43.808712
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser(prog='http')
    assert parser.prog == 'http'
    assert isinstance(parser.formatter, argparse.RawDescriptionHelpFormatter)
    assert isinstance(parser.env, Environment)
    assert isinstance(parser.config, Config)



# Generated at 2022-06-23 18:38:47.853273
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    env = TestEnvironment()
    env.stdout_isatty = True
    args = HTTPieArgumentParser().parse_args(
        args=['http', 'url'],
        env=env,
    )
    print(args)

# Generated at 2022-06-23 18:38:49.871511
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    assert formatter._max_help_position == 6


# Generated at 2022-06-23 18:39:00.885658
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    class TestHTTPieHelpFormatter(HTTPieHelpFormatter):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
    fmt = TestHTTPieHelpFormatter(prog='testp')
    parser = argparse.ArgumentParser(
        prog='testp',
        formatter_class=HTTPieHelpFormatter,
    )
    parser.add_argument('--foo', help="""foo
    bar""")
    parser.add_argument('bar')
    parser.add_argument('-b', action='append')
    parser.add_argument('-o', action='store_true')
    args = parser.parse_args()
    with pytest.raises(SystemExit):
        parser.print_help()

# Generated at 2022-06-23 18:39:14.059074
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():

    # Args
    args = ['https://www.google.com/','--headers','Connection: close','--json','{"provider": "airtel","userID": "9999999999","txnAmount": "101","channelCode": "INT","currencyCode": "INR","itemCode": "101","itemType": "ecm","countryCode": "IN","paymentModes": "INT","returnUrl": "paytm.com","notifyUrl": "paytm.com"}']

    # Expected values
    stdin_isatty = False
    stdout_isatty = False
    stderr_isatty = True
    windows = False
    stdout_encoding = 'utf8'
    devnull = open(os.devnull, 'wb')

    # Testing
    parser = HTTPieArgumentParser(args)
    assert parser

# Generated at 2022-06-23 18:39:24.043241
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(description='')
    parser.add_argument('-a', help='Argument -a')
    parser.add_argument('-b', help='\nArgument -b\nwith many lines\n')

    help_message = parser.format_help()

    assert 'Argument -a' in help_message
    assert 'Argument -a' in help_message
    assert 'Argument -b' in help_message
    assert '\nArgument -b\nwith many lines\n' not in help_message
    assert 'Argument -b\nwith many lines' in help_message



# noinspection PyAbstractClass

# Generated at 2022-06-23 18:39:32.705084
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-23 18:39:42.991894
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter(*[i for i in range(50)])
    assert formatter._max_help_position==6
    assert formatter._width==80
    assert formatter._indent_increment==2
    assert formatter._long_break_after==30
    assert formatter._short_break_after==60
    assert formatter._current_indent==0
    assert formatter._level==0
    assert formatter._action_max_length==18
    assert formatter._root_section is None
    assert formatter._prog is None
    assert formatter._max_help_position is not None



# Generated at 2022-06-23 18:39:48.154497
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    parser.add_argument('-o', metavar='FILE', dest='output_file',
                        help='Write output to FILE instead of stdout.')
    parser.add_argument('--no-session', action='store_false', dest='session',
                        default=True, help='Disable session.')
    parser.add_argument('--session-read-only', action='store_true',
                        dest='session_read_only',
                        help='Speak read-only session.')
    parser.add_argument('--auth-type', metavar='TYPE', type=str.upper,
                        help='Specify a custom authetication type.')

# Generated at 2022-06-23 18:40:00.518806
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    """
    >>> f = HTTPieHelpFormatter(width=20)
    >>> f._split_lines(' hello  \n   world ', width=20)
    ['hello', 'world']
    >>> f._split_lines(' hello', width=20)
    ['hello']
    >>> f._split_lines(' hello  ', width=20)
    ['hello']
    >>> f._split_lines('\n  hello  \n   world \n', width=20)
    ['hello', 'world']
    >>> f._split_lines('hello\\n\\nworld', width=20)
    ['hello', '', 'world']
    """


DEFAULT_UA = 'HTTPie/%s' % __version__

# Check if we are running on ree, otherwise fallback to __version__
# http://stackoverflow.com/

# Generated at 2022-06-23 18:40:03.016753
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    isinstance (HTTPieHelpFormatter, RawDescriptionHelpFormatter)
    isinstance (HTTPieHelpFormatter(max_help_position = 8), RawDescriptionHelpFormatter)


# Generated at 2022-06-23 18:40:04.490754
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    assert formatter
# End


# Generated at 2022-06-23 18:40:06.125523
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert isinstance(HTTPieHelpFormatter(), ArgumentDefaultsHelpFormatter)



# Generated at 2022-06-23 18:40:17.022608
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    httpie_arg_parser = HTTPieArgumentParser()
    httpie_arg_parser.funcname()
    #print(httpie_arg_parser.__dict__)
    #print(httpie_arg_parser.__class__.__dict__)
    print(httpie_arg_parser.__doc__)
    #print(httpie_arg_parser.__name__)
    print(httpie_arg_parser)
    #print(httpie_arg_parser.add_argument)
    print(httpie_arg_parser.add_argument())
    #print(httpie_arg_parser.add_argument_group)
    print(httpie_arg_parser.add_argument_group())
    print(httpie_arg_parser.print_help())
    #print(httpie_arg_parser.__str

# Generated at 2022-06-23 18:40:18.581734
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # TODO Unit test not implemented
    assert False

# Generated at 2022-06-23 18:40:24.197204
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # In Python 3+, the "compile_help" argument is deprecated.
    HTTPieArgumentParser(compile_help=True)

    # Test keyword argument "add_help"
    parser = HTTPieArgumentParser(add_help=False)
    assert not parser.add_help


# Unit test function for method
# HTTPieArgumentParser._process_output_options

# Generated at 2022-06-23 18:40:26.025279
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert HTTPieHelpFormatter()._split_lines('\nfoo\nbar\n', 10) == ['foo', 'bar', '', '']


# Generated at 2022-06-23 18:40:37.531873
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    class dummy:
        pass
    out = StringIO()
    cli_parser = argparse.ArgumentParser(add_help=False)
    cli_parser.prog = 'http'
    cli_parser.usage = 'http [OPTIONS] [REQUEST_TARGET]'
    cli_parser.print_help = lambda _: None
    cli_parser.exit = lambda _: None
    cli_parser.add_argument = lambda *args, **kwargs: None
    cli_parser.parse_args = lambda *args, **kwargs: dummy()
    cli_parser.print_usage = lambda _: None
    cli_parser.format_usage = lambda: 'usage'
    cli_parser.format_help = lambda: 'help'
    args = dummy()

# Generated at 2022-06-23 18:40:38.263805
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    pass

# Generated at 2022-06-23 18:40:41.588640
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    result = HTTPieHelpFormatter._split_lines.__doc__
    assert result == 'A smaller indent for args help.\n'


# Generated at 2022-06-23 18:40:44.390807
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    parser = HTTPieArgumentParser()
    args = parser.parse_args(['GET', 'http://httpbin.org/get', '--headers', 'name: value'])

# Generated at 2022-06-23 18:40:48.922268
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    help_text = HTTPieHelpFormatter._split_lines('''\
    -H KEY:VALUE
    [HTTP header. You may specify as many as needed]
    ''', 80)
    assert '\n[HTTP header. You may specify as many as needed]\n\n' == help_text



# Generated at 2022-06-23 18:40:53.608357
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    parser.print_usage()
    parser.print_help()


if __name__ == "__main__":
    test_HTTPieArgumentParser()

# Generated at 2022-06-23 18:41:04.395173
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = HTTPieArgumentParser.parse_args(["http://localhost:80"],[])
    assert args.url == "http://localhost:80"
    args = HTTPieArgumentParser.parse_args(["http://localhost:80", "key=value"],[])
    assert args.headers["key"] == "value"
    args.headers == {}
    args = HTTPieArgumentParser.parse_args(["http://localhost:80","key=value1", "key=value2"],[])
    assert args.headers["key"] == "value1,value2"
    args.headers == {}
    args = HTTPieArgumentParser.parse_args(["http://localhost:80","foo='{bar:1}'", "foo='{bar:2}'"],[])

# Generated at 2022-06-23 18:41:09.648470
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # given
    command = 'http GET https://httpbin.org/get'
    argv = shlex.split(command)
    hp = HTTPieArgumentParser()
    # when
    args = hp.parse_args(argv)
    # then
    assert args.method == 'GET'
    assert args.url == 'https://httpbin.org/get'

# Generated at 2022-06-23 18:41:14.005960
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    '''
    Unit test for method parse_args of class HTTPieArgumentParser
    method did not return any value
    '''
    TCO = TestCaseOfArgumentParser()
    try:
        # test exception is raised
        TCO.test_HTTPieArgumentParser_parse_args()
    except:
        pass
    else:
        assert False

# Generated at 2022-06-23 18:41:25.043398
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # This test requires a hostname, to be able to create a URL
    assert socket.gethostname()

    # Example of userargs:
    #   ['--json', '{"name": "value"}', 'https://httpbin.org/post']
    userargs = ['--json', '{"name": "value"}', 'https://httpbin.org/post']

    # The object args is of HTTPieArgumentParser class.
    args = HTTPieArgumentParser(prog='http', env=Environment()).parse_args(userargs)

    # Test that parsing worked as expected
    assert not args.verbose
    assert not args.all
    assert not args.download
    assert not args.pretty
    assert len(args.headers) == 0
    assert len(args.params) == 0
    assert len(args.data) == 0

# Generated at 2022-06-23 18:41:36.636715
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    env = Environment()
    parser = HTTPieArgumentParser(env)
    with pytest.raises(SystemExit):
        parser.parse_args([])

   # basic parser successfully
    args = parser.parse_args(['--help'])
    assert args.output_file == sys.stdout

    # basic parser successfully
    args = parser.parse_args(['--version'])
    assert args.output_file == sys.stdout

    # custom parser successfully
    args = parser.parse_args(['--traceback'])
    assert args.output_file == sys.stdout

    # custom parser successfully
    args = parser.parse_args(['--debug'])
    assert args.output_file == sys.stdout


# Generated at 2022-06-23 18:41:43.452705
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    """Parse the given arguments and return a :class:`~argparse.Namespace`."""
    # The given args
    args = mock.MagicMock()
    args.no_config = False
    args.config_dir = None
    args.config_file_paths = None
    args.config_env_vars = None
    args.config_file_finders = None
    args.config_dirs_env_var = None
    args.colors = None
    args.style = None
    args.theme = None
    args.default_options = None
    args.auto_colors = None
    args.optimizations = None
    args.dotdicts = None
    args.pretty = None
    args.style_errors = None
    args.output_options = None
    args.output_options_history

# Generated at 2022-06-23 18:41:46.241993
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    print(parser.parse_args(['https://httpbin.org/get']))
    print(parser.parse_args(['--help']) )



# Generated at 2022-06-23 18:41:52.367953
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = ['--ignore-stdin', 'example.com', 'foo==bar']
    parsed = HTTPieArgumentParser().parse_args(args)
    assert parsed.ignore_stdin is True
    assert parsed.url == 'example.com'
    assert parsed.request_items == [KeyValueArgType('==', '=')('foo==bar')]


# Generated at 2022-06-23 18:42:02.246407
# Unit test for constructor of class HTTPieHelpFormatter

# Generated at 2022-06-23 18:42:14.841008
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # The method has no test coverage, yet.
    def test__process_format_options():
        mock_HTTPieArgumentParser = Mock(spec=HTTPieArgumentParser)
        mock_HTTPieArgumentParser.args = Mock()
        mock_HTTPieArgumentParser.args.format_options = None
        HTTPieArgumentParser(mock_HTTPieArgumentParser)._process_format_options()
        assert mock_HTTPieArgumentParser.args.format_options == PARSED_DEFAULT_FORMAT_OPTIONS
        mock_HTTPieArgumentParser = Mock(spec=HTTPieArgumentParser)
        mock_HTTPieArgumentParser.args = Mock()
        mock_HTTPieArgumentParser.args.format_options = []
        HTTPieArgumentParser(mock_HTTPieArgumentParser)._process_format

# Generated at 2022-06-23 18:42:25.801105
# Unit test for method parse_args of class HTTPieArgumentParser

# Generated at 2022-06-23 18:42:28.300818
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert HTTPieHelpFormatter().__init__()._split_lines('a\nb', 6).__str__() == "['a\\nb\\n\\n']"


# Generated at 2022-06-23 18:42:40.770846
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    env = Environment()

# Generated at 2022-06-23 18:42:48.604397
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    text = dedent("""\
    test for argparse.ArgumentParser(
                    description='HTTPie - a CLI, cURL-like tool for humans.',
                    epilog=EPILOG,
                    formatter_class=HTTPieHelpFormatter,
                    )
    """)
    assert text == dedent("""\
    test for argparse.ArgumentParser(
    description='HTTPie - a CLI, cURL-like tool for humans.',
    epilog=EPILOG,
    formatter_class=HTTPieHelpFormatter,
    )

    """)

PARSER_DESCRIPTION = """HTTPie - a CLI, cURL-like tool for humans.

https://httpie.org
"""



# Generated at 2022-06-23 18:42:55.172996
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    parser = argparse.ArgumentParser(
        description='description',
        formatter_class=HTTPieHelpFormatter,
    )
    parser.add_argument('--foo', help='\tfoo')
    assert parser.format_help().strip('\n') == """
usage: [-h] [--foo FOO]

description

optional arguments:
  -h, --help  show this help message and exit
  --foo FOO   foo"""


# Generated at 2022-06-23 18:43:02.399545
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    import sys
    sys.argv = ["httpie.py", "GET", "http://www.google.com", "Accept", "application/json"]
    parser = HTTPieArgumentParser(prog="httpie.py", add_help=True)
    httpie_args = parser.parse_args()
    #print("In test_HTTPieArgumentParser()")
    #print("HTTP args: ", httpie_args)
    #print("HTTP verb: ", httpie_args.method)
    #print("HTTP URL: ", httpie_args.url)
    #print("HTTP verb: ", httpie_args.method)
    #print("HTTP data: ", httpie_args.data)
    #print("HTTP headers: ", httpie_args.headers)
    #print("HTTP params: ", httpie_args.params)


# Generated at 2022-06-23 18:43:06.360488
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    help_text = (
        '\n'
        '  --ignore-stdin      Ignore stdin.\n'
        '                      Used with --bash, --zsh, etc.\n'
        '\n'
        '  -D, --download      Download URL.\n'
        '\n'
    )
    formatted_text = ''.join(formatter._split_lines(help_text, 80))
    assert formatted_text == help_text

#   The shorter class name to be used in the help.

# Generated at 2022-06-23 18:43:07.574682
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    print_help()


if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-23 18:43:15.102642
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    # test _split_lines()
    assert formatter._split_lines("""\
        arg1 help

        arg2 help
        """, None) == ['arg1 help', '', 'arg2 help', '']
    # test _split_lines()
    assert formatter._split_lines("""\
            arg1 help

            arg2 help
        """, None) == ['arg1 help', '', 'arg2 help', '']



# Generated at 2022-06-23 18:43:16.304988
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert help(HTTPieHelpFormatter)


# Generated at 2022-06-23 18:43:23.624732
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # check https://github.com/jakubroztocil/httpie/pull/361
    # check https://github.com/jakubroztocil/httpie/pull/357
    parser = HTTPieArgumentParser()
    parser.parse_args(args=[
        '--ignore-stdin',
        '--form',
        'foo=bar',
        '--verify=no',
        'https://httpbin.org/post'
    ], env=Environment())
    # don't raise exception
    assert True



# Generated at 2022-06-23 18:43:34.705167
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    #  1. arguments=[]
    arguments = []
    parser = HTTPieArgumentParser(prog='http')
    args = parser.parse_args(arguments)
    assert parser.get_prog_name() == 'http'
    assert parser.get_default_values() == args
    assert args.__dict__ == vars(argparse.Namespace(colors=256,
                                                    headers=None,
                                                    output_file_specified=False))

    #   1.1 arguments=['--help']
    arguments = ['--help']
    parser = HTTPieArgumentParser(prog='http')
    args = parser.parse_args(arguments)
    assert parser.get_prog_name() == 'http'
    assert parser.get_default_values() == args
    assert args.__dict__

# Generated at 2022-06-23 18:43:44.717361
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    class CLI:
        def __init__(self, prog, desc=None):
            self.prog = prog
            self.desc = desc
            self.help_args = ['help']

        def add_argument(self, *args, **kwargs):
            if 'help' in kwargs:
                self.help_args.append(kwargs['help'])

    cli = CLI('http')
    cli.add_argument('--foo', help='foo\nbar\n  baz')
    cli.add_argument('--hoge', help='hoge')
    cli.add_argument('--fuga', help='fuga')
    assert cli.help_args == ['help', 'foo\nbar\n  baz', 'hoge', 'fuga']

    cli2 = CLI('http')

# Generated at 2022-06-23 18:43:54.917102
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    from .__main__ import HTTPieArgumentParser
    from ..downloads import FileTransferProgress

    parser = HTTPieArgumentParser()
    #args = parser.parse_args(['http://www.baidu.com'])
    #args = parser.parse_args(['-b', 'http://www.baidu.com'])
    #args = parser.parse_args(['-b', 'http://www.baidu.com', '-A', 'IE'])
    #args = parser.parse_args(['-b', 'http://www.baidu.com/s?wd=hello'])
    #args = parser.parse_args(['-b', 'http://www.baidu.com/s', 'wd=hello'])
    #args = parser.parse_args(['-b', '

# Generated at 2022-06-23 18:44:02.508887
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    '''Unit test for constructor of class HTTPieHelpFormatter'''
    def website_code(text):
        from IPython.core.display import HTML, display
        display(HTML(
            '<a href="{0}" target="_blank">{0}</a>'.format(text)
        ))

    website_code("https://github.com/jakubroztocil/httpie/blob/master/httpie/cli/argparser.py")


# Generated at 2022-06-23 18:44:13.181050
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    test_text = '''
    The following two lines will be dedented, separated with a blank line,
    and start with the same position again.
    '''

    class DocstringArgumentDefaultsHelpFormatter(HTTPieHelpFormatter):
        """Just for testing."""
    formatter = DocstringArgumentDefaultsHelpFormatter()

    # pylint: disable=protected-access
    lines = formatter._split_lines(text=test_text, width=80)

    assert lines == [
        'The following two lines will be dedented, separated with a'
        ' blank line,',
        'and start with the same position again.',
        '',
        ''
    ]


# pylint: disable=too-many-branches, too-many-locals, too-many-statements

# Generated at 2022-06-23 18:44:24.064416
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = SHELL_LIKE_CLI_DEFAULT_VALUES.copy()
    args['method'] = 'get'
    args['url'] = 'http://httpbin.org/get'
    args['headers'] = None
    args['ignore_stdin'] = False
    args['timeout'] = None
    args['auth'] = None
    args['auth_type'] = None
    args['proxy'] = None
    args['allow_redirects'] = True
    args['max_redirects'] = None
    args['follow_redirects'] = True
    args['timeout'] = None
    args['check_status'] = True
    args['verify'] = True
    args['cert'] = None
    args['trust_env'] = True
    args['auth_plugin'] = None
    args['output_file']

# Generated at 2022-06-23 18:44:32.127322
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    help_text = '''\
    Usage: http COMMAND [OPTIONS] [URL]

    http: error: argument URL: invalid url value: '''
    assert formatter._split_lines(help_text, 100) == ['Usage: http COMMAND [OPTIONS] [URL]', '', 'http: error: argument URL: invalid url value: ']



# Generated at 2022-06-23 18:44:42.013446
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    with patch.object(HTTPieArgumentParser, 'exit') as mock_exit, \
            patch.object(HTTPieArgumentParser, 'error') as mock_error, \
            patch.object(HTTPieArgumentParser, '_parse_items') as mock_parse_items, \
            patch.object(HTTPieArgumentParser, '_process_output_options') as mock_process_output_options, \
            patch.object(HTTPieArgumentParser, '_process_pretty_options') as mock_process_pretty_options:
        mock_parse_items.return_value = None
        mock_process_output_options.return_value = None
        mock_process_pretty_options.return_value = None
        instance = HTTPieArgumentParser()
        instance.parse_args(['command', '--option'])
        mock

# Generated at 2022-06-23 18:44:52.301275
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    formatter = HTTPieHelpFormatter()
    assert ['\n\n'] == formatter._split_lines('', 6)
    assert ['\n\n'] == formatter._split_lines(' ', 6)
    assert ['\n\n'] == formatter._split_lines('\n\n', 6)
    assert ['\n\n'] == formatter._split_lines('\n', 6)
    assert ['ab\n\n'] == formatter._split_lines('ab', 6)
    assert ['ab\n\n'] == formatter._split_lines('ab\n', 6)
    assert [['a', 'b\n\n']] == formatter._split_lines('a\nb', 6)

# Generated at 2022-06-23 18:44:58.552981
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    """
    Constructor for class `HTTPieArgumentParser`.
    """
    parser = HTTPieArgumentParser(add_help=False)
    parser.exit = functools.partial(do_exit, parser)
    parser.error = functools.partial(do_error, parser)
    return parser


# Generated at 2022-06-23 18:45:10.647175
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # prepare
    sys.argv = [sys.argv[0], 'https://www.baidu.com', '--debug']
    # check
    parser = HTTPieArgumentParser()
    assert isinstance(parser.args, argparse.Namespace)
    assert parser.env is not None
    assert parser.env.is_windows is False
    assert parser.env.stdin_isatty is True
    assert isinstance(parser.env.stdin, io.TextIOWrapper)
    assert parser.env.stdout_isatty is True
    assert isinstance(parser.env.stdout, io.TextIOWrapper)
    assert parser.env.stderr_isatty is True
    assert isinstance(parser.env.stderr, io.TextIOWrapper)

# Generated at 2022-06-23 18:45:13.855784
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    httpie_argparser = HTTPieArgumentParser(session=Session())
    assert isinstance(httpie_argparser, HTTPieArgumentParser)

# Generated at 2022-06-23 18:45:14.618631
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    assert True



# Generated at 2022-06-23 18:45:21.502162
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    env = Environment()
    env.stdout = io.StringIO()
    env.stdout_isatty = True
    parser = HTTPieArgumentParser(env=env)
    args = parser.parse_args(args=[])
    assert args.method == 'GET'
    assert not hasattr(args, 'url')
    assert not hasattr(args, 'headers')
    assert not hasattr(args, 'data')

# Generated at 2022-06-23 18:45:29.981385
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # Initializations
    parser = HTTPieArgumentParser()
    parser.env = create_environ()
    parser.add_argument = lambda *args, **kwargs: None
    parser.error = lambda message: None
    parser.exit = lambda status=0, message=None: None
    parser._get_value = lambda name, section, environment_variable, default: None

    # Testing
    # Test create_parser_with_defaults
    # Testing key_values_type
    # Testing AddOption
    # Testing error
    # Testing exit

    # Testing _get_value
    # Testing _set_config_dir
    # Testing _configure_request
    # Testing _validate_input_file
    # Testing _fix_windows_cwd_path
    # Testing _canonicalize_url
    # Testing _print_message


# Generated at 2022-06-23 18:45:36.877360
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser(
        prog='http',
        usage=argparse.SUPPRESS,
        env=Env(),
        add_help=False)
    assert parser.__class__.__name__ == 'HTTPieArgumentParser'
    assert parser.prog == 'http'
    assert parser.__dict__ == {}


# Generated at 2022-06-23 18:45:40.557213
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = HTTPieArgumentParser.parse_args(
        [
            'https://httpbin.org/get',
            'X-API-Token: 123',
            'group:read,write'
        ]
    )



# Generated at 2022-06-23 18:45:47.397154
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    # Create the HTTPieArgumentParser object
    parser = HTTPieArgumentParser()

    # Test the httpie_version attribute of parser
    assert parser.httpie_version == __version__

    # Test the httpie_version_string attribute of parser
    assert parser.httpie_version_string == __ver__

    # Test the httpie_version_info attribute of parser
    assert parser.httpie_version_info == __version_info__



# Generated at 2022-06-23 18:45:59.527838
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    """
    Test if the de-indent function works well
    """
    assert HTTPieHelpFormatter()._split_lines("\n        test", 9) == ["test"]


# TODO: should we remove `--verify`?
# TODO: add --continue / --follow


# Generated at 2022-06-23 18:46:06.608903
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Fail: no url given
    with pytest.raises(SystemExit):
        HTTPieArgumentParser().parse_args(["example.org"])
    # Fail: multiple auth_password given
    with pytest.raises(SystemExit):
        HTTPieArgumentParser().parse_args(["http://example.org", "--auth", "username:password", "--auth", "username2:password2"])

# Generated at 2022-06-23 18:46:17.299218
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Test 1: Instantiation of Argument Parser object HTTPieArgumentParser
    # from module argparser.py
    argparser = HTTPieArgumentParser()
    # Test 2: Type check: argparser is of class HTTPieArgumentParser
    assert isinstance(argparser, HTTPieArgumentParser)
    # Test 3: Type check: argparse is of class ArgumentParser and not of class HTTPieArgumentParser
    assert not isinstance(argparse, HTTPieArgumentParser)
    # Test 4: Encode error test, if the input to method parse_args of class HTTPieArgumentParser is a string
    with pytest.raises(AttributeError):
        HTTPieArgumentParser().parse_args("www.google.com")
 

# Generated at 2022-06-23 18:46:19.258865
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    args = ['--ignored','--body','--help']
    parser = HTTPieArgumentParser(*args)
    return parser


# Generated at 2022-06-23 18:46:23.458067
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    import pytest
    from argparse import Namespace
    from httpie.constants import URL
    p = HTTPieArgumentParser()
    argv = ['--ignore-stdin', '--json', '--form', 'name=John', '--headers', 'Accept:application/json', URL]
    args = p.parse_args(argv=argv)
    assert args.json == True
    assert args.form == True
    assert args.headers == {'Accept':'application/json'}


# Generated at 2022-06-23 18:46:24.880236
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    c = HTTPieArgumentParser()
    # TODO: implement test code
    #assert c.parse_args(["<input>", ...]) == "<output>"
    pass

# Generated at 2022-06-23 18:46:37.024871
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():

    # First, we initialize the argument parser
    parse = HTTPieArgumentParser()

    # Then we test that it has the expected arguments
    assert '--config-dir' in parse._actions
    assert '--debug' in parse._actions
    assert '--default-config-dir' in parse._actions
    assert '--default-options' in parse._actions
    assert '--download' in parse._actions
    assert '--download-resume' in parse._actions
    assert '--download-resume' in parse._actions
    assert '--format' in parse._actions
    assert '--format-options' in parse._actions
    assert '--headers' in parse._actions
    assert '--help' in parse._actions
    assert '--ignore-stdin' in parse._actions
    assert '--implicit-content-type' in parse._actions


# Generated at 2022-06-23 18:46:46.435906
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    args = list(get_aliases_as_args('GET https://httpbin.org/ip'))
    parser = HTTPieArgumentParser(env=Environment())
    parsed_args = parser.parse_args(args)
    assert parsed_args.GET == True
    assert parsed_args.method == 'GET'
    assert parsed_args.url == 'https://httpbin.org/ip'

    args = list(get_aliases_as_args('GET https://httpbin.org/get'))
    parser = HTTPieArgumentParser(env=Environment())
    parsed_args = parser.parse_args(args)
    assert parsed_args.GET == True
    assert parsed_args.method == 'GET'
    assert parsed_args.url == 'https://httpbin.org/get'


# Generated at 2022-06-23 18:46:49.009204
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    assert isinstance(parser.args, argparse.Namespace)


# Generated at 2022-06-23 18:46:58.185995
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # Case 1: [--pretty=all, --form]
    arg_list1 = ['--pretty=all', '--form']
    # Case 2: [--pretty=all, --form]
    arg_list2 = ['--pretty=all', '--form']
    # Case 3: [--pretty=all, --form]
    arg_list3 = ['--pretty=all', '--form']
    # Case 4: [--pretty=all, --form]
    arg_list4 = ['--pretty=all', '--form']
    # Case 5: [--pretty=all, --form]
    arg_list5 = ['--pretty=all', '--form']
    # Case 6: [--pretty=all, --form]
    arg_list6 = ['--pretty=all', '--form']
    # Case 7: [--

# Generated at 2022-06-23 18:47:05.837203
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    cli = argparse.ArgumentParser(
        formatter_class=HTTPieHelpFormatter
    )
    cli.add_argument('--foo', help="""\
    Lorem ipsum dolor sit amet, consectetuer adipiscing elit.

    Integer eu lacus accumsan arcu fermentum euismod.

    """)
    cli.print_help()
    """Help formatter to use with ``argparse.ArgumentParser``. """



# Generated at 2022-06-23 18:47:10.839806
# Unit test for constructor of class HTTPieHelpFormatter
def test_HTTPieHelpFormatter():
    _formatter = HTTPieHelpFormatter(max_help_position=10)
    assert _formatter._max_help_position == 10, \
            'Unable to implement the constructor of class HTTPieHelpFormatter'


# Generated at 2022-06-23 18:47:21.361136
# Unit test for constructor of class HTTPieArgumentParser
def test_HTTPieArgumentParser():
    parser = HTTPieArgumentParser()
    args = parser.parse_args()
    assert args.auth == None
    assert args.auth_type == None
    assert args.auth_plugin == None
    assert args.auto.json_indent == 2
    assert args.auto.mimetype == {}
    assert args.auto.optimize == False
    assert args.auto.preserve_format == False
    assert args.auto.sort_headers == False
    assert args.body == False
    assert args.check_status == False
    assert args.compress == False
    assert args.config_dir == '~/.config/httpie'
    assert args.download == False
    assert args.download_resume == True
    assert args.form == False
    assert args.headers == []
    assert args.ignore_netrc == False

# Generated at 2022-06-23 18:47:27.726440
# Unit test for method parse_args of class HTTPieArgumentParser
def test_HTTPieArgumentParser_parse_args():
    # setup
    parser = HTTPieArgumentParser()
    # act
    parser.parse_args(['-v', '--no-style', '--style=solarized'])
    # assert
    assert parser.args.verify == False
    assert parser.args.style == 'solarized'
    assert parser.args.offline == True
# end unit test for HTTPieArgumentParser.parse_args
