

# Generated at 2022-06-12 19:10:01.518156
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .YoutubeDL import YoutubeDL
    pp = MetadataFromTitlePP(YoutubeDL(), '%(title)s - %(artist)s')
    test_info = {
        'title': 'My Title - Author Name Goes Here',
        'duration': 'Not touched by the PP',
    }

    [], test_info = pp.run(test_info)

    assert test_info['title'] == 'My Title - Author Name Goes Here'
    assert test_info['artist'] == 'Author Name Goes Here'
    assert test_info['duration'] == 'Not touched by the PP'



# Generated at 2022-06-12 19:10:11.687602
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from ytdl_pp_common import FakeYDL

    target = MetadataFromTitlePP(YoutubeDL(FakeYDL()), '%(artist)s - %(title)s')

    assert target.run({'title': 'the title'}) == ([], {'title': 'the title'})

    assert target.run({'title': 'A - B'}) == (
        [], {'title': 'A - B', 'artist': 'A', 'title': 'B'})

    assert target.run({'title': 'A - B - C'}) == (
        [], {'title': 'A - B - C', 'artist': 'A', 'title': 'B - C'})

    assert target.run({'title': 'A - B - C - D'})

# Generated at 2022-06-12 19:10:15.756207
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # setup
    from .common import FileDownloader
    downloader = FileDownloader({})
    titleformat = '%(title)s - %(artist)s'
    parser = MetadataFromTitlePP(downloader, titleformat)
    info = {'title': 'song title - song artist'}
    wanted_info_items = {'title': 'song title', 'artist': 'song artist'}
    # assert
    unused_errs, info = parser.run(info)
    for item, value in wanted_info_items.items():
        assert info[item] == value



# Generated at 2022-06-12 19:10:23.499635
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    downloader = None
    titleformat = '%(title)s - %(artist)s'
    titleregex = r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    pp = MetadataFromTitlePP(downloader, titleformat)
    assert (pp._titleformat == titleformat and
            pp._titleregex == titleregex and
            sys.version_info >= (3, 0))
    title = 'title - artist'
    info = {'title': title}
    [], info = pp.run(info)
    assert info['title'] == 'title'
    assert info['artist'] == 'artist'
    title = 'title - artist - album'
    info = {'title': title}
    [], info = pp.run(info)

# Generated at 2022-06-12 19:10:35.806690
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    Case1: Normal use case for method run of class MetadataFromTitlePP.
    Expected: When title is not empty and matches the title format,
              then metadata info should be set correctly.
    """
    def _to_screen(msg):
        print(msg)

    info = {'title': 'This is a title'}
    mpp = MetadataFromTitlePP(
        {'to_screen': _to_screen}, titleformat='%(title)s')
    mpp.run(info)
    assert info == {'title': 'This is a title'}

    info = {'title': 'This is a title - with artist'}
    mpp = MetadataFromTitlePP(
        {'to_screen': _to_screen}, titleformat='%(title)s - %(artist)s')
    m

# Generated at 2022-06-12 19:10:44.342837
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    p = MetadataFromTitlePP(None, '')
    assert p.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert p.format_to_regex('%(title)s %(artist)s') == r'(?P<title>.+)\ (?P<artist>.+)'
    assert p.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert p.format_to_regex('%(title)s - %(artist)s - %(year)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<year>.+)'

# Generated at 2022-06-12 19:10:54.917821
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.downloader import YoutubeDL
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.compat import compat_tempfile
    from youtube_dl.utils import sanitize_open

    with compat_tempfile.NamedTemporaryFile() as info_file:
        ydl = YoutubeDL({
            'logger': YoutubeDL.noop_logger(),
            'postprocessors': [{
                'key': 'MetadataFromTitle',
                'format': '%(title)s - %(artist)s',
            }, {
                'key': 'ExecAfterDownload',
                'exec_cmd': 'echo %(artist)s > %(info_file)s',
                'info_file': info_file.name,
            }],
        })

# Generated at 2022-06-12 19:11:01.532179
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    t = MetadataFromTitlePP(None, '%(title)s')
    assert t.format_to_regex('%(title)s') == '(?P<title>.+)'
    t = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert t.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-12 19:11:05.069064
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    assert MetadataFromTitlePP(None, '%(nothing)s')._titleformat == ('%(nothing)s')
    assert MetadataFromTitlePP(None, '%(nothing)s')._titleregex == ('(?P<nothing>.+)')


# Generated at 2022-06-12 19:11:11.697789
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from yt_dl_metadata.downloader import YTDLMetadataDownloader
    dl = YTDLMetadataDownloader({'writethumbnail': False,
                                 'writeinfojson': False})
    pp = MetadataFromTitlePP(dl, '%(artist)s - %(title)s')
    info = {'title': 'Artist name - Title'}
    res_infos = pp.run(info)[1]
    assert res_infos['title'] == 'Title'
    assert res_infos['artist'] == 'Artist name'


# Generated at 2022-06-12 19:11:21.109845
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    Test that a given format is interpreted and inserted as metadata
    """
    class FakeInfo:
        pass

    downloader = None
    titleformat = '%(uploader)s uploaded %(upload_date)s'
    pp = MetadataFromTitlePP(downloader, titleformat)

    info = FakeInfo()
    info.title = 'test uploaded 2018-12-31'
    [], info = pp.run(info)
    assert info.uploader == 'test'
    assert info.upload_date == '2018-12-31'


# Generated at 2022-06-12 19:11:32.658950
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    downloader = YoutubeDL(params={'listformats': True, 'nooverwrites': True, 'quiet': True})

    # Test the case where no groups are captured
    downloader.params['outtmpl'] = '%(title)s'
    pp = MetadataFromTitlePP(downloader,  '%(title)s')
    assert pp.run({'title': 'Test'}) == ([], {'title': 'Test'})

    # All attributes are captured
    downloader.params['outtmpl'] = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(downloader,  '%(title)s - %(artist)s')

# Generated at 2022-06-12 19:11:41.813488
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    info = {}

    info['title'] = 'Metallica - Nothing Else Matters'
    info = pp.run(info)[1]
    assert info['title'] == 'Nothing Else Matters'
    assert info['artist'] == 'Metallica'

    info['title'] = 'Metallica - Nothing Matter'
    info = pp.run(info)[1]
    assert info == {}

    info['title'] = 'Metallica - '
    info = pp.run(info)[1]
    assert info['title'] == ''
    assert info['artist'] == 'Metallica'

# Generated at 2022-06-12 19:11:44.139498
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass


if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-12 19:11:54.048425
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    reload(sys)
    sys.setdefaultencoding('utf-8')

    class TestMetadataFromTitlePP_run(unittest.TestCase):
        def setUp(self):
            self.pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')

        def test_empty_string(self):
            info = {'title': ''}
            expected_info = {'title': ''}
            self.pp.run(info)
            self.assertDictEqual(info, expected_info)

        def test_simple_string1(self):
            info = {'title': 'Foobar'}
            expected_info = {'title': 'Foobar'}
            self.pp.run(info)
            self.assertD

# Generated at 2022-06-12 19:12:04.133220
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import functools
    import os
    import tempfile
    import sys
    from collections import namedtuple
    from unittest import TestCase
    from ytdl.YoutubeDownloader import YoutubeDownloader

    def w_screen(msg):
        print(msg)

    def w_error(msg):
        print('ERROR: ' + msg)

    class DummyInfoDict(dict):
        @property
        def display_id(self):
            return self['title']

    class DummyExtractor(object):
        def __init__(self, info_dict):
            self._info_dict = info_dict

        @property
        def IE_DESC(self):
            return 'Dummy'

        def _real_extract(self, url):
            return self._info_dict


# Generated at 2022-06-12 19:12:13.843008
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    def _fake_downloader(to_screen_str):
        class _Downloader(object):
            to_screen = to_screen_str
        return _Downloader()
        
    def _test_run(titleformat, title, expected_title, expected_artist,
                  expected_to_screen_strs):
        def _test_run_inner(to_screen_str):
            downloader = _fake_downloader(to_screen_str)
            pp = MetadataFromTitlePP(downloader, titleformat)
            info = {'title': title}
            pp.run(info)
            assert info['title'] == expected_title
            assert info['artist'] == expected_artist
            assert to_screen_str.value == '\n'.join(expected_to_screen_strs)

# Generated at 2022-06-12 19:12:18.613536
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    downloader = None
    titleformat = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(downloader, titleformat)
    title = 'Some Title - Some Artist'

    info = {'title' : title}
    info_expected = {'title' : 'Some Title', 'artist' : 'Some Artist'}

    pp.run(info)
    assert info == info_expected

# Generated at 2022-06-12 19:12:25.768349
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    class DummyYDL(object):
        def __init__(self):
            self.params = {}
            self.to_screen = lambda message: None
            self.to_stderr = lambda message: None

    class DummyInfo(dict):
        def __init__(self):
            super(DummyInfo, self).__init__({'title': 'Test - Foo Artist'})
            self.url = 'params=are+ignored'

    ydl = DummyYDL()
    ydl.params['prefer_in_title'] = 'title,artist'

    info = DummyInfo()
    postprocessor = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    postprocessor.run(info)
    assert info['title'] == 'Test'
    assert info['artist']

# Generated at 2022-06-12 19:12:36.506737
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from collections import namedtuple
    TestDownloader = namedtuple('TestDownloader', 'to_screen')
    test_downloader = TestDownloader(
        to_screen=lambda *msg: print('[fromtitle] ' + msg[0]))


# Generated at 2022-06-12 19:12:48.934002
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Run test on method MetadataFromTitlePP.run
    # TODO: use mock downloader
    downloader = None
    titleformat = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(downloader, titleformat)
    # input = title, output = info
    test_inputs = {
        'video': {
            'title': 'Video Title - Artist Name'
        },
    }
    expected_outputs = {
        'video': {
            'title': 'Video Title',
            'artist': 'Artist Name',
        },
    }
    for test, input in test_inputs.items():
        print('test case %s' % test)
        info = input
        output = pp.run(info)[1]
        expected = expected_outputs[test]
       

# Generated at 2022-06-12 19:12:59.805655
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl
    import youtube_dl.extractor.youtube

    # Initialize constant test values
    fake_downloader = youtube_dl.YoutubeDL({
            'format': 'bestaudio[height<=?96]',
            'writethumbnail': True,
            'writeinfojson': True,
            'simulate': True,
            'verbose': True,
            'quiet': False,
            'skip_download': True,
            'ignoreerrors': False,
            'outtmpl': '%(id)s',
        })
    fake_url = 'http://www.youtube.com/watch?v=BaW_jenozKc'

# Generated at 2022-06-12 19:13:07.041686
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Arrange
    import youtube_dl
    import unittest
    import sys
    class TestDownloader(youtube_dl.YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(TestDownloader, self).__init__(*args, **kwargs)
            self.to_screen = sys.stdout.write
    class TestPP(MetadataFromTitlePP):
        def __init__(self, format):
            super(TestPP, self).__init__(TestDownloader(), format)
        def format_to_regex(self, fmt):
            return '^(?P<title>.+)$'
    class Test(unittest.TestCase):
        def test_run(self):
            test_pp = TestPP('%(title)s')

# Generated at 2022-06-12 19:13:14.735210
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .. import YoutubeDL

    ydl = YoutubeDL()

    title = 'This is a video'
    info = {'id': 'SomeId', 'title': title, 'tracks': '', 'upload_date': '',
            'creator': '', 'album': '', 'track_number': '', 'release_year': '',
            'release_date': '', 'track': '', 'artist': '', 'album_artist': ''}

    # Test 1
    titleformat = '%(title)s'
    pp = MetadataFromTitlePP(ydl, titleformat)
    expected_info = info.copy()
    expected_info['title'] = 'This is a video'
    _, actual_info = pp.run(info)
    assert actual_info == expected_info

    # Test 2

# Generated at 2022-06-12 19:13:21.256834
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import pytube
    yt = pytube.YouTube('https://www.youtube.com/watch?v=z_AbfPXTKms')
    mp3_url = yt.get_mp3_url()
    mp3_file_name = mp3_url.split('/')[-1]
    mp3_file_extension = mp3_url.split('.')[-1]
    return mp3_file_name



# Generated at 2022-06-12 19:13:30.641986
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    downloader = {'to_screen': print}

# Generated at 2022-06-12 19:13:41.137883
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    # Suppose you are downloading a video from the YouTube channel "TEDx Talks"
    # with the title "A.I. Experiments: Visualizing High-Dimensional Space",
    # then you can navigate to the channel page, get the channel ID
    # and set the title format as follows:
    titleformat = '%(title)s'
    pp = MetadataFromTitlePP(None, titleformat)

    # Test 1:
    # With the title "A.I. Experiments: Visualizing High-Dimensional Space",
    # the method run should fill the key 'title' with the value
    # "A.I. Experiments: Visualizing High-Dimensional Space".
    info = {'title': 'A.I. Experiments: Visualizing High-Dimensional Space'}
    output = pp.run(info)

# Generated at 2022-06-12 19:13:52.196873
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FakeYDL
    from .extractor import gen_extractors
    from collections import OrderedDict

    ydl = FakeYDL()
    ydl.add_info_extractor(gen_extractors()[0])
    title = 'skafjdskl(@&*g8934g9j3g4jg4jkjsdfgjskg90sdfj - sjdflsdjhf89g9j0sg09sg9sgj - sfskdfskdjfjskldf - jskdlfjskfjskf'
    ydl.add_default_info({'title': title})

    pp = MetadataFromTitlePP(ydl, '%(title)s')
    pp.run(ydl.ydl_opts)

# Generated at 2022-06-12 19:14:00.326545
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class MockInfoDict(dict):
        pass
    idict = MockInfoDict()
    idict['title'] = 'Foo bar - Baz'
    # Run the unit test
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    pp.run(idict) == idict
    # Check the result
    assert idict['artist'] == 'Foo bar'
    assert idict['title'] == 'Baz'

# Generated at 2022-06-12 19:14:12.496559
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    Unit test for method run of class MetadataFromTitlePP.
    Testing valid and invalid format strings to ensure that correctly
    formatted titles are correctly parsed and that titles that don't follow
    the format string do not match.
    """

    from ..YoutubeDL import YoutubeDL
    from .common import FileDownloader

    def _test_run(titleformat, testtitle, expected):
        """
        Helper function for unit test.
        *titleformat*: the format string for a title
        *testtitle*: the title to parse (valid or invalid)
        *expected*: dictionary of expected values
        """
        ydl = YoutubeDL({'quiet': True, 'simulate': True})
        fd = FileDownloader({'quiet': True, 'simulate': True}, ydl)
        pp = MetadataFromTitlePP(fd, titleformat)


# Generated at 2022-06-12 19:14:22.721673
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class FakeInfo:
        def __init__(self):
            self.title = 'title'
            self.artist = None

    info = FakeInfo()
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    _, info = pp.run(info)
    assert info.title == 'title' and info.artist == 'title'

    info = FakeInfo()
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(title)s')
    _, info = pp.run(info)
    assert info.title == 'title' and info.artist == 'title - title'

# Generated at 2022-06-12 19:14:30.957618
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.embedthumbnail import ThumbnailIE
    from youtube_dl.postprocessor import FFmpegMetadataPP

    ydl = YoutubeDL({'quiet': True})
    ie = InfoExtractor('test_ie')
    ie.set_downloader(ydl)
    ie.to_screen = lambda x: None
    ie.report_warning = lambda x: None

    # test that %(extractor)s gets replaced by the name of the
    # extractor and %(title)s by the title
    outtmpl = '%(extractor)s - %(title)s.mp4'
    pp = FFmpegMetadataPP(ydl, outtmpl)
    ie.add_post

# Generated at 2022-06-12 19:14:39.053088
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class FakeDownloader:
        def to_screen(self, msg):
            print(msg)

    ffmpeg_pp = MetadataFromTitlePP(FakeDownloader(), "%(title)s - %(author)s")

    # Basic test
    info = {}
    info['title'] = 'test - author'
    ffmpeg_pp.run(info)
    assert(info['title'] == 'test')
    assert(info['author'] == 'author')

    # Test if nothing happens on wrong title format
    info = {}
    info['title'] = 'title'
    ffmpeg_pp.run(info)
    assert(info['title'] == 'title')
    assert('author' not in info)

    # Test if attributes are parsed correctly with more than one "."
    info = {}

# Generated at 2022-06-12 19:14:45.171075
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    postprocessor = MetadataFromTitlePP(None,
                                        '%(title)s - %(artist)s')

    info = {}
    info['title'] = 'song title - artist name'

    postprocessor._downloader.to_screen = lambda s: None
    results, info = postprocessor.run(info)

    assert info == {'title': 'song title', 'artist': 'artist name'}



# Generated at 2022-06-12 19:14:56.206128
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # For unit testing, we need to mock youtube_dl.
    # Let's create a dummy class first.
    class DummyYoutubeDL:
        @staticmethod
        def to_screen(message):
            print(message)

    # Create a dummy dictionary to be used as input of the postprocessor
    dummydict = {'title': 'Armin van Buuren feat. Trevor Guthrie - This Is What It Feels Like'}

    # Create a MetadataFromTitlePP object
    metadatafromtitlepp = MetadataFromTitlePP(DummyYoutubeDL(), '%(artist)s - %(title)s')

    # Run the postprocessor
    metadatafromtitlepp.run(dummydict)

    # Verify the output
    assert dummydict['artist'] == 'Armin van Buuren feat. Trevor Guthrie'

# Generated at 2022-06-12 19:15:05.160365
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest
    import sys

    class TestMetadataFromTitlePP(unittest.TestCase):
        def test_format_to_regex(self):
            import warnings
            with warnings.catch_warnings():
                warnings.simplefilter('ignore')
                isRegex = MetadataFromTitlePP._MetadataFromTitlePP__format_to_regex
                self.assertEqual(isRegex('%(title)s - %(artist)s'),
                                 '(?P<title>.+) - (?P<artist>.+)')

        def test_parse_title(self):
            from collections import namedtuple
            from tests.danmaku.helper import FakeYDL
            from youtube_dl import FileDownloader

            Info = namedtuple('Info', ('title',))

# Generated at 2022-06-12 19:15:09.404887
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.compat import compat_str
    import youtube_dl
    fttp = MetadataFromTitlePP(youtube_dl, "%(title)s - %(artist)s")
    fttp.run({'title': compat_str('test title - test artist'),
              'artist': compat_str('orig artist'),
              'others': compat_str('others')})

# Generated at 2022-06-12 19:15:19.297682
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl.YoutubeDL import YoutubeDL
    from ytdl.extractor.common import SearchInfoExtractor
    from ytdl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class TestDownloader(YoutubeDL):
        def __init__(self, **kwargs):
            super(TestDownloader, self).__init__(**kwargs)
            self.to_screen('%s' % TestDownloader.__name__)

    class TestInfoExtractor(SearchInfoExtractor):
        def __init__(self, **kwargs):
            super(TestInfoExtractor, self).__init__(**kwargs)
            self.to_screen('%s' % TestInfoExtractor.__name__)


# Generated at 2022-06-12 19:15:30.896051
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class TestDownloader:
        def to_screen(self, *args, **kwargs):
            pass

    metadata1 = {
        'title': 'Foo - Bar - Test [123p]',
        'url': '',
        'webpage_url': '',
        'uploader': '',
        'ext': '',
        'format': '',
        'player_url': '',
    }

    metadata2 = {
        'title': 'Foo - Bar - Test',
        'url': '',
        'webpage_url': '',
        'uploader': '',
        'ext': '',
        'format': '',
        'player_url': '',
    }


# Generated at 2022-06-12 19:15:41.222279
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    Unit test for method run of class MetadataFromTitlePP
    """
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange

    downloader = YoutubeDL({
        'format': 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'
    })


# Generated at 2022-06-12 19:15:54.902261
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class FakeYDL:
        to_screen_value = None
        def to_screen(self, value):
            self.to_screen_value = value

    from ytdl.extractor.common import InfoExtractor
    class FakeIE(InfoExtractor):
        def __init__(self, ydl, ie_url, ie_name, ie_list_title, ie_list_id):
            super(FakeIE, self).__init__(ydl, ie_url, ie_name=ie_name, ie_list_title=ie_list_title, ie_list_id=ie_list_id)
            self.info = {
                'title': 'My test title - My test artist'
            }
            self.title_format = '%(title)s - %(artist)s'


# Generated at 2022-06-12 19:16:02.896299
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    downloader = object()
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    info = {}
    res, newInfo = pp.run(info)
    assert res == []
    assert newInfo == {}

    info['title'] = 'The amazing title of this video - By cool artist'
    res, newInfo = pp.run(info)
    assert res == []
    assert newInfo == {'title': 'The amazing title of this video',
                       'artist': 'By cool artist'}

    info['title'] = 'Fail to parse this title - By cool artist'
    res, newInfo = pp.run(info)
    assert res == []
    assert newInfo == {}

# Generated at 2022-06-12 19:16:12.811369
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    d = {'title': 'Test - different Title'}
    mpp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    # parsed title: Test
    # parsed artist: different Title
    d = mpp.run(d)

    mpp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    # parsed title: Test - different Title
    # Could not interpret title of video as '%(title)s - %(artist)s'
    d = mpp.run(d)

    mpp = MetadataFromTitlePP(None, 'Nothing here - %(nothing)s')
    # Could not interpret title of video as 'Nothing here - %(nothing)s'
    d = mpp.run(d)


# Generated at 2022-06-12 19:16:13.799154
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # TODO: Write unit tests for method run of class MetadataFromTitlePP
    pass


# Generated at 2022-06-12 19:16:26.514643
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import tempfile
    import subprocess

    # initialize a downloader-like object
    class FakeDownloader(object):
        def __init__(self):
            self._titles = []

        def to_screen(self, title):
            self._titles.append(title)

    fake_downloader = FakeDownloader()

    # initialize a PostProcessor instance for testing
    postprocessor = MetadataFromTitlePP(
        fake_downloader, '%(artist)s - %(title)s')

    # test that "no match" is handled correctly
    video_info = {'title': 'foo bar'}
    result = postprocessor.run(video_info)
    assert len(result) == 2 and all(isinstance(elt, list) for elt in result)

# Generated at 2022-06-12 19:16:26.972439
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass

# Generated at 2022-06-12 19:16:38.998321
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    import youtube_dl
    import os
    # tests uses medata from https://music.yandex.ru/album/2968397
    # https://music.yandex.ru/download/album/2968397/n0R8mBk-oFb.m4a?track=1
    # https://music.yandex.ru/download/album/2968397/n0R8mBk-oFb.m4a?track=2
    # https://music.yandex.ru/download/album/2968397/n0R8mBk-oFb.m4a?track=3
    # https://music.yandex.ru/download/album/2968397/n0R8mBk-oFb.m4a?track

# Generated at 2022-06-12 19:16:51.047414
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor import FFmpegMetadataPP

    # create mock youtube_dl object
    ydl = YoutubeDL({})
    ydl.params = {}
    ydl.params['writethumbnail'] = True
    ydl.params['writeautomaticsub'] = True
    ydl.params['sublangs'] = ['en']
    ydl.params['allsubtitles'] = True
    ydl.params['writesubtitles'] = True
    ydl.params['max_sleep_interval'] = 1
    ydl.params['sleep_interval'] = 1
    ydl.params['subtitleslangs'] = ['en']
    ydl.params['subtitlesformat'] = 'ass'

    # create mock FFmpegMetadataPP object

# Generated at 2022-06-12 19:16:57.743702
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    from youtube_dl.YoutubeDL import YoutubeDL

    d = YoutubeDL({})
    d.add_default_info_extractors()

    pp = MetadataFromTitlePP(d, '%(title)s')
    info = {'title': 'A title'}
    assert d.process_info(info) == ({}, {'title': 'A title'})

    pp = MetadataFromTitlePP(d, '%(title)s - %(artist)s')
    info = {'title': 'A title - An artist'}
    assert d.process_info(info) == ({}, {'title': 'A title', 'artist': 'An artist'})

    pp = MetadataFromTitlePP(d, '%(artist)s - %(title)s')

# Generated at 2022-06-12 19:17:06.388829
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.utils import DateRange
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_str


# Generated at 2022-06-12 19:17:19.526179
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl
    options = youtube_dl.YoutubeDL().add_default_info_extractors()['default']
    options.update(youtube_dl.YoutubeDL().params)
    options.update({
        'postprocessors': [{
            'key': 'MetadataFromTitle',
            'format': '%(title)s - %(artist)s',
        }],
    })
    downloader = youtube_dl.YoutubeDL(options)
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    # Test a simple match, no groups
    info = {'title': 'The Title - The Artist'}
    pp.run(info)
    assert info == {'title': 'The Title - The Artist',
                    'artist': 'The Artist'}


# Generated at 2022-06-12 19:17:24.827742
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .YoutubeDL import YoutubeDL
    downloader = FileDownloader(YoutubeDL())
    postprocessor = MetadataFromTitlePP(downloader, '%(artist)s_%(title)s')
    info = {'title': 'Foo_Bar'}
    postprocessor.run(info)
    assert info == {'title': 'Foo_Bar', 'artist': 'Foo'}
    info = {'title': 'Foo_Bar_Baz'}
    postprocessor.run(info)
    assert info == {'title': 'Foo_Bar_Baz', 'artist': 'Foo'}
    info = {'title': 'Foo'}
    postprocessor.run(info)
    assert info == {'title': 'Foo', 'artist': None}


# Generated at 2022-06-12 19:17:31.572912
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FakeYDL
    from .downloader import DummyDownloader
    import youtube_dl.extractor.common

    for fmt in ['%(title)s %(id)s',
                '%(group)s - %(title)s - %(id)s',
                '%(title)s %(episode)02d %(id)s',
                '%(artist)s - %(title)s - %(id)s',
                '%(group)s - %(artist)s - %(title)s - %(id)s']:
        if re.search(r'%\(\w+\)s', fmt):
            ydl = FakeYDL()
            title = 'My_video_title 2016_02_11 ' + fmt % ydl

# Generated at 2022-06-12 19:17:37.102103
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.metadatafromtitle import \
        MetadataFromTitlePP

    def _reporthook(d):
        if d['status'] == 'finished':
            d['filename'] = 'test_fromtitle_run.mp4'
            d['title'] = 'Artist - Title (Album)'
            d['fulltitle'] = 'Artist - Title (Album) by Full Artist'

    ydl = YoutubeDL({
        'noprogress': True,
        'quiet': True,
    })
    ydl.add_progress_hook(_reporthook)
    postprocessor = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')

    info = {}
    postprocessor.run(info)
    assert info['title']

# Generated at 2022-06-12 19:17:47.883792
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class TestDownloader(object):
        def __init__(self):
            self.to_screen_buffer = ''

        def to_screen(self, message):
            self.to_screen_buffer += message + '\n'

    td = TestDownloader()
    mftPP = MetadataFromTitlePP(td, '%(title)s')
    info = {
        'title': 'some title'
    }

    (formats, info) = mftPP.run(info)

    assert info['title'] == 'some title'
    assert td.to_screen_buffer == '[fromtitle] parsed title: some title\n', \
        'Incorrect output for to_screen method on TestDownloader'
    assert len(formats) == 0


# Generated at 2022-06-12 19:17:59.163172
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    info = {
        'title': 'title_value',
        'artist': 'artist_value',
        'album': 'album_value',
        'tracknumber': 'tracknumber_value',
        'date': 'date_value',
    }


# Generated at 2022-06-12 19:18:06.269796
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import os
    import sys
    import tempfile
    import unittest
    import ydl_opts

    import youtube_dl

    def make_title_py_files(title):
        _, fname = tempfile.mkstemp()
        with open(fname, 'wb') as f:
            f.write(title.encode('utf-8'))
        return fname

    class TempYDL(youtube_dl.YoutubeDL):
        def to_screen(self, msg):
            pass

    def run_pp_test(
            attributes, title, titleformat, expected_info,
            expected_warnings=None):
        expected_warnings = expected_warnings or []

# Generated at 2022-06-12 19:18:16.631428
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest
    class TestMetadataFromTitlePP_run(unittest.TestCase):
        def setUp(self):
            #import sys
            #sys.modules['youtube_dl.YoutubeDL'] = MockYoutubeDL
            self.mpp = MetadataFromTitlePP(None, '%(title)s')

        def test_run_regex_1(self):
            info = {'title':'Foo - Bar'}
            meta, info = self.mpp.run(info)
            self.assertEqual(meta, [])
            self.assertEqual(info['title'], 'Foo')

        def test_run_regex_2(self):
            info = {'title':'Foo - Bar'}

# Generated at 2022-06-12 19:18:25.497037
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import pytest

    from ytdl.extractor import common

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(self, *args, **kwargs)

    class FakeDownloader(object):
        def to_screen(self, msg):
            pass

    # Test case: titleformat == title
    info = FakeInfoDict()
    info['title'] = 'Test - Title'
    processor = MetadataFromTitlePP(FakeDownloader(), 'Test - Title')
    assert processor.run(info) == ([], info)

    # Test case: titleformat == titleformat with no grouping
    info = FakeInfoDict()
    info['title'] = 'Test - Title'

# Generated at 2022-06-12 19:18:34.773946
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .downloader import gen_pp_configs
    from collections import defaultdict
    from .downloader import Downloader
    from .compat import compat_str

    pp_configs = gen_pp_configs(
        # The following are strings, not tuples, because YouTubeDL does not
        # allow multiple postprocessors for the same name.
        ('metadatafromtitle', '%(title)s - %(id)s'),
        ('metadatafromtitle', '%(uploader)s - %(upload_date)s - %(title)s'),
    )


# Generated at 2022-06-12 19:18:49.358717
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from . import YoutubeDL
    from .extractor.youtube import YoutubeIE
    ydl = YoutubeDL(YoutubeDL.params)
    mp = MetadataFromTitlePP(ydl,  '%(uploader)s/%(uploader_id)s/%(channel_id)s %(title)s')
    info = {'title': 'name of the playlist/XyZ123/channelid name of the video'}
    info = YoutubeIE._extract_metadata(ydl, '', info)
    assert info['uploader_id'] == 'XyZ123'
    assert info['uploader'] == 'name of the playlist'
    assert info['channel_id'] == 'channelid'
    assert info['title'] == 'name of the video'

# Generated at 2022-06-12 19:18:58.428478
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl
    import utils
    f = youtube_dl.YoutubeDL({'yesplaylist': True}).process_ie_result

    expected_info = {
        'title': 'Foo - Bar',
        'artist': 'Foo',
        'album': 'Bar',
        'track': '1',
        'genre': 'Rock',
        'comment': 'Foo is the best',
    }
    titleformat = '%(artist)s - %(album)s'
    titleformat_regex = '%(artist)s - %(album)s'

    info = {'title': 'Foo - Bar'}
    pp = MetadataFromTitlePP(
        youtube_dl.YoutubeDL(), titleformat, titleformat_regex)
    out, info = pp.run(info)

# Generated at 2022-06-12 19:19:08.168665
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.Downloader import Downloader

    # Test a regular expression
    ftt = MetadataFromTitlePP(Downloader(params={}), '^(?P<artist>[\S ]+) - (?P<title>[^-]+)$')
    info = ftt.run({'title': 'Metallica - Nothing else matters'})[1]
    assert info['artist'] == 'Metallica'
    assert info['title'] == 'Nothing else matters'

    # Test a string matching
    ftt = MetadataFromTitlePP(Downloader(params={}), '%(artist)s - %(title)s')
    info = ftt.run({'title': 'Paso a paso: dos manzanas'})[1]
    assert info['artist'] == None

# Generated at 2022-06-12 19:19:13.739902
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class DummyYDL():
        def to_screen(self, txt):
            print(txt)
    dummy_info = {'title' : 'aa-bb'}
    mp = MetadataFromTitlePP(DummyYDL(), '%(a)s-%(b)s')
    mp.run(dummy_info)
    assert dummy_info['a'] == 'aa'
    assert dummy_info['b'] == 'bb'

# Generated at 2022-06-12 19:19:22.448222
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest
    import sys
    import io
    import ydl

    # Check that the outputs of parser matches the pattern.
    # Check that the outputs of parser contains the metadatas.

    class MockYDL(ydl.YoutubeDL):
        def __init__(self, **kwargs):
            super(MockYDL, self).__init__(**kwargs)

        def to_screen(self, msg):
            pass

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.mydl = MockYDL()
            self.mydl.params['titleformat'] = "%(title)s - %(artist)s"
            self.mydl.params['quiet'] = True
            self.mydl.params['simulate'] = True

# Generated at 2022-06-12 19:19:29.166042
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import os

    # env
    os.environ['PYTHONPATH'] = ':'.join(sys.path)
    os.environ['LOG_LEVEL'] = 'debug'

    # object
    class FakeInfo:
        def __init__(self, title):
            self.title = title
    info = FakeInfo('The movie title')
    class FakeDownloader:
        def __init__(self, *args):
            pass
        def to_screen(self, msg):
            pass
        def report_warning(self, msg):
            pass
    downloader = FakeDownloader('', '0.0.1', '', '', '', '', '')
    fromtitle_pp = MetadataFromTitlePP(downloader,
                                       '%(title)s - %(year)s')



# Generated at 2022-06-12 19:19:38.038147
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Create the environment
    metadata_from_titlePP = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    info = {
        'title': 'Zedd - Clarity (ft. Foxes) [Official Music Video]',
        'track': 'Clarity'
    }
    # Test the method method run of class MetadataFromTitlePP
    metadata_from_titlePP.run(info)
    assert info['title'] == 'Zedd - Clarity (ft. Foxes) [Official Music Video]', 'title'
    assert info['track'] == 'Clarity', 'track'
    assert info['artist'] == 'Zedd', 'artist'



# Generated at 2022-06-12 19:19:46.261051
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ..YoutubeDL import YoutubeDL
    from ..utils import DateRange
    youtube_dl = YoutubeDL({})
    youtube_dl.add_post_processor(MetadataFromTitlePP(youtube_dl,
                                                      '%(artist)s - %(title)s'))
    ret_info = youtube_dl.extract_info('https://www.youtube.com/watch?v=XBjAUfrpH-k',
         download=False)
    assert ret_info['title'] == 'Una Mattina'
    assert ret_info['artist'] == 'Ludovico Einaudi'
    youtube_dl = YoutubeDL({})
    youtube_dl.add_post_processor(MetadataFromTitlePP(youtube_dl,
                                                      '%(artist)s - %(title)s'))
    ret_

# Generated at 2022-06-12 19:19:57.395670
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ..YoutubeDL import YoutubeDL
    import sys
    if sys.version_info.major < 3:
        from urllib import quote
    else:
        from urllib.parse import quote

    titleformat = '%(title)s - %(artist)s'
    titleformat_regex = ('(?P<title>.+)\ \\-\ (?P<artist>.+)'
                         if re.search(r'%\(\w+\)s', titleformat)
                         else titleformat)