

# Generated at 2022-06-12 19:09:58.657198
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    titleformat = '%(site)s %(title)s %(artist)s'
    regex = '(?P<site>.+) (?P<title>.+) (?P<artist>.+)'
    assert MetadataFromTitlePP.format_to_regex(None, titleformat) == regex

# Generated at 2022-06-12 19:10:02.520045
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp.run({'title': 'Foo - Bar'})[1] == {'title': 'Foo', 'artist': 'Bar'}


# Generated at 2022-06-12 19:10:12.268895
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from .common import FakeYDL
    from .extractor.common import InfoExtractor


# Generated at 2022-06-12 19:10:18.661464
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftpp = MetadataFromTitlePP(None, '%(f1)s - %(f2)s')
    assert mftpp.format_to_regex('%(f1)s - %(f2)s') == '(?P<f1>.+)\ \-\ (?P<f2>.+)'
    assert mftpp.format_to_regex('%(f1)s - abcdef%(f2)s') == '(?P<f1>.+)\ \-\ abcdef(?P<f2>.+)'

# Generated at 2022-06-12 19:10:24.681110
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    instance = MetadataFromTitlePP(None, None)
    assert (instance.format_to_regex('123%(abc)sd%(def)s456')
            == r'123(?P<abc>.+)d(?P<def>.+)456')

if __name__ == '__main__':
    test_MetadataFromTitlePP_format_to_regex()

# Generated at 2022-06-12 19:10:36.089362
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl.extractor.common as yt_common
    inc = yt_common.InfoExtractor
    pp = MetadataFromTitlePP
    down = yt_common.FileDownloader
    down.to_screen = lambda x : None
    info = {'title': 'bla', '_filename': 'video.mp4'}

    # Valid title
    info['title'] = 'House - Hey boy hey girl'
    assert pp(down, r'%(artist)s - %(title)s').run(info) == ([], {'_filename': 'video.mp4', 'artist': 'House', 'title': 'Hey boy hey girl'})

    # Valid title with unassigned group
    info['title'] = 'House - Hey boy hey girl'

# Generated at 2022-06-12 19:10:44.548557
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl
    def _print(*args):
        pass
    ydl = youtube_dl.YoutubeDL()
    ydl.to_screen = _print
    ydl.parameters['writesubtitles'] = False
    ydl.parameters['writeautomaticsub'] = False
    ydl.parameters['skip_download'] = True
    # test default (fmt %(ext)s)
    assert MetadataFromTitlePP(ydl, None).run({
        'title': 'What a wonderfull world - Louis Armstrong',
        'ext': 'mp4',
    }) == ([], {
        'title': 'What a wonderfull world - Louis Armstrong',
        'ext': 'mp4',
    })
    # test that titleformat is required

# Generated at 2022-06-12 19:10:54.952658
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange

    class OpDummy:
        def to_screen(self, *args, **kwargs):
            pass

    class YDLDummy(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(YDLDummy, self).__init__(*args, **kwargs)
            self.params = {}

    # date and date_range are not tested here

    try:
        import mutagen
        assert mutagen
    except ImportError:
        def test_mutagen_support():
            pass
        return test_mutagen_support

    # one test with mutagen


# Generated at 2022-06-12 19:10:58.955629
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-12 19:11:07.761810
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest
    import sys
    import pytube.extractor.utils

    class MockDownloader():
        def to_screen(self, msg):
            sys.stdout.write(str(msg) + "\n")

    class TestMetadataFromTitlePP(unittest.TestCase):
        def test_run(self):
            info = {'title': 'MyTitle'}
            pp = MetadataFromTitlePP(MockDownloader(), '%(title)s')
            pp.run(info)

        def test_run_negative(self):
            info = {'title': 'MyTitle'}
            pp = MetadataFromTitlePP(MockDownloader(), '%(blub)s')
            pp.run(info)


# Generated at 2022-06-12 19:11:20.854348
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    class DummyDownloader():
        def to_screen(self, _):
            pass

    # Test with a format with group separator
    format1 = '%(uploader)s|%(title)s|%(id)s'
    regex1 = '^(?P<uploader>.+)\|(?P<title>.+)\|(?P<id>.+)$'
    info1 = {'title': 'mannol|myvideo|bzfDgV304pY'}
    titlepp1 = MetadataFromTitlePP(DummyDownloader(), format1)
    assert titlepp1._titleregex == regex1
    res = titlepp1.run(info1)

# Generated at 2022-06-12 19:11:32.452556
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({'outtmpl': '%(title)s'})
    ydl.add_default_info_extractors()

    # Testcase 1: no 'titleformat' given
    pp = MetadataFromTitlePP(ydl, None)
    info = {}
    assert pp.run(info) == ([], {})

    # Testcase 2: 'titleformat' given, but no metadata extracted
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    info = {}
    assert pp.run(info) == (
        ['[fromtitle] Could not interpret title of video as "%s"' % pp._titleformat],
        {}
    )

    # Testcase 3: incomplete metadata extracted
    pp = Metadata

# Generated at 2022-06-12 19:11:42.774460
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl.YoutubeDL import YoutubeDL
    from ytdl.PostProcessor import PostProcessor

    def _find_match(args, fp_url, title, ext, resolution, format_id, player_url, **skip):
        assert args['url'] == fp_url and args['title'] == title and args['ext'] == ext and args['resolution'] == resolution and args['format_id'] == format_id
        return {'title': title, 'ext': ext, 'resolution': resolution, 'format_id': format_id}

    def _doit(url, title, *expected):
        ydl = YoutubeDL({'format': 'bestaudio/best'})
        ydl._find_match = _find_match
        m = re.search(r'http://www.youtube.com/(.+)$', url)

# Generated at 2022-06-12 19:11:53.682827
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    sys.path.insert(0, "..")  # So that you can run this without installing youtube_dl
    from youtube_dl.YoutubeDL import YoutubeDL

    class Extractor:
        pass

    class FakeInfoExtractor(Extractor):
        def __init__(self, extractor_type):
            self._type = extractor_type

        @property
        def IE_NAME(self):
            return self._type

    class FakeInfo:
        @property
        def extractor(self):
            return FakeInfoExtractor('fakeie')

        @property
        def webpage_url(self):
            return 'https://fakeie.com'

        def __getitem__(self, key):
            return None

        def __setitem__(self, key, value):
            pass

    fake_ydl = Youtube

# Generated at 2022-06-12 19:12:04.030086
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    Test for method run for class MetadataFromTitlePP
    """
    print("Running test_MetadataFromTitlePP_run")
    from . import YoutubeDL
    from .YoutubeDL import YoutubeDL
    from .extractor import common as YoutubeDLCommon
    import sys

    class LoggingYoutubeDL(YoutubeDL):
        def process_ie_result(self, ie_result):
            self.processed_info_dicts += [ie_result]

        def to_screen(self, *args, **kwargs):
            pass

    ydl = LoggingYoutubeDL(params=dict(titleformat='%(artist)s - %(title)s'))
    ydl.processed_info_dicts = []

# Generated at 2022-06-12 19:12:13.706459
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # check behavior with invalid arguments
    expected = ('Could not interpret title of video as '
                '"%(title)s - %(artist)s - %(album)s - %(album_artist)s"')
    actual = MetadataFromTitlePP(
        None, '%(title)s - %(artist)s - %(album)s - %(album_artist)s').run(
        {'title': 'foo'})[1]['title']
    assert (expected, 'foo') == (actual, 'foo')

    # check behavior with valid arguments
    expected = {'title': 'Track 1', 'artist': 'Foo', 'album': 'Bar'}

# Generated at 2022-06-12 19:12:22.322106
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.YoutubeDL import YoutubeDL
    titleformat = '%(title)s - %(artist)s - %(album)s - (%(year)s) - %(genre)s - %(track)s'
    # test 1: valid title with all attributes
    data = {'title': 'a - b - c - (d) - e - f'}
    pp = MetadataFromTitlePP(FileDownloader(YoutubeDL(), ''), titleformat)
    info = pp.run(data)[1]
    assert info['title'] == 'a - b - c - (d) - e - f'
    assert info['artist'] == 'a'
    assert info['album'] == 'b'
    assert info['year'] == 'd'

# Generated at 2022-06-12 19:12:32.915929
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    mp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    info = {'title': 'Video Title - Performer'}
    result = mp.run(info)
    assert len(result) == 2
    assert len(result[0]) == 0
    assert result[1] == {'title': 'Video Title', 'artist': 'Performer'}

    mp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    info = {'title': 'Video Title'}
    result = mp.run(info)
    assert len(result) == 2
    assert len(result[0]) == 0
    assert result[1] == info

    mp = MetadataFromTitlePP(None, '%(title)s')

# Generated at 2022-06-12 19:12:41.927128
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest
    import sys

    class FakeYDL:
        def to_screen(self, msg):
            sys.stdout.write(msg + '\n')

        def to_stderr(self, msg):
            sys.stderr.write(msg + '\n')

    class FakeInfoDict:
        def __init__(self):
            self.__dict__ = {}

    # Test with a titleformat like '%(artist)s - %(title)s'
    # and a title like 'Artist - Title'

    info_dict = FakeInfoDict()
    info_dict.title = 'Artist - Title'

# Generated at 2022-06-12 19:12:49.657952
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    metadata_info = {'title' : 'hello world - youtube'}
    metadata_format = '%(title)s - %(site)s'

    class FakeDownloader(object):
        def to_screen(self,msg):
            print(msg)

    metadata_pp = MetadataFromTitlePP(FakeDownloader(), metadata_format)
    metadata_pp.run(metadata_info)
    assert metadata_info['site'] == 'youtube'


# Generated at 2022-06-12 19:13:02.394021
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import collections

    test_data_1 = collections.OrderedDict([('title', 'A Title - B Artist'),
                                           ('artist', None),
                                           ('album', None),
                                           ('track', None)])
    test_data_2 = collections.OrderedDict([('title', 'A Title - B Artist - C Album - D Track - 0'),
                                           ('artist', None),
                                           ('album', None),
                                           ('track', None)])
    test_data_3 = collections.OrderedDict([('title', 'Random title'),
                                           ('artist', None),
                                           ('album', None),
                                           ('track', None)])

    from .common import FileDownloader
    from .extractor import GenYoutubeIE

    # test 1

# Generated at 2022-06-12 19:13:08.309855
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    ydlpp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    info = {'title': 'Foo - Bar'}
    ydlpp.run(info)
    assert info['title'] == 'Foo - Bar'
    assert info['artist'] == 'Bar'

    # same with an empty string
    ydlpp = MetadataFromTitlePP(None, '%(title)s')
    info = {'title': 'Foo'}
    ydlpp.run(info)
    assert info['title'] == 'Foo'

    # missing format string
    ydlpp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    info = {'title': ''}
    ydlpp.run(info)

# Generated at 2022-06-12 19:13:09.426028
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass


# Generated at 2022-06-12 19:13:19.849770
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .ytdl import YoutubeDL
    ydl = YoutubeDL({})
    # Test that regex works without %(...)s placeholders
    pp1 = MetadataFromTitlePP(ydl, '%(w)s')
    _, info = pp1.run({'title': 'something else', 'w': 'test'})
    assert(info['w'] == 'test')
    _, info = pp1.run({'title': 'something else'})
    assert(info['w'] == 'test')
    # Test that regex works with %(...)s placeholders
    pp2 = MetadataFromTitlePP(ydl, '%(w)s in %(title)s')
    _, info = pp2.run({'title': 'something else', 'w': 'test'})
    assert(info['w'] == 'test')

# Generated at 2022-06-12 19:13:29.580324
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class DummyDownloader(object):
        def __init__(self):
            self.infos = {}

        def to_screen(self, msg):
            pass

    dldr = DummyDownloader()
    pp = MetadataFromTitlePP(dldr, '%(artist)s - %(title)s - %(album)s - %(track)s - %(ext)s')
    info = {'title': 'Artist 1 - Title 1 - Album 1 - 01'}
    pp.run(info)

    assert(info['artist'] == 'Artist 1')
    assert(info['title'] == 'Title 1')
    assert(info['album'] == 'Album 1')
    assert(info['track'] == '01')
    assert(info['ext'] == None)


# Generated at 2022-06-12 19:13:40.781559
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import json
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')

    def assertInfo(args, expected_info):
        info = {'title': args}
        _, info = pp.run(info)
        return json.dumps(info) == json.dumps(expected_info)

    assert assertInfo('My Artist - My Title', {
        'title': 'My Title',
        'artist': 'My Artist'
    })
    assert assertInfo('My Artist - My Title - Foo', {
        'title': 'My Title - Foo',
        'artist': 'My Artist'
    })
    assert assertInfo('My Artist - My Title - Foo Bar', {
        'title': 'My Title - Foo Bar',
        'artist': 'My Artist'
    })
    assert assertInfo

# Generated at 2022-06-12 19:13:52.158601
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', '..'))
    from ydl.postprocessor import get_postprocessor_classes
    from ydl.downloader import get_downloader_classes

    params = {'postprocessors': 'metadata_from_title'}
    info = {'webpage_url': 'http://example.com/',
            'title': '1234, artist'}
    downloader_classes = get_downloader_classes(params=params)
    downloader = downloader_classes[0](params=params)
    downloader.to_stdout = lambda s: sys.stdout.write(repr(s) + '\n')

# Generated at 2022-06-12 19:14:03.867594
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Arrange
    # pylint: disable=invalid-name
    # Act and Assert
    assert MetadataFromTitlePP(None, '%(title)s').run({'title': 'Abc'}) == ([], {'title': 'Abc'})
    assert MetadataFromTitlePP(None, '%(title)s').run({'title': 'A - b'}) == ([], {'title': 'A'})
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s').run({'title': 'A - b'}) == ([], {'title': 'A', 'artist': 'b'})

    assert MetadataFromTitlePP(None, '%(title)s').run({'title': 'A - b'}) == ([], {'title': 'A'})

# Generated at 2022-06-12 19:14:15.008664
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import ydl_api
    downloader = ydl_api.YoutubeDL(ydl_api.params.Params({}))
    pp = MetadataFromTitlePP(downloader, '%(artist)s - %(title)s')

    # test regular title parsing
    info = {'title': 'The Artist - Title'}
    pp.run(info)
    assert info == {'title': 'The Artist - Title', 'artist': 'The Artist'}

    # test special characters
    info = {'title': 'The Artist - Title [hello world] (world hello) {world hello}'}
    pp.run(info)
    assert info == {'title': 'The Artist - Title [hello world] (world hello) {world hello}', 'artist': 'The Artist'}

    # test missing title part

# Generated at 2022-06-12 19:14:25.719605
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader

    ytdl_options = {
        'noplaylist': True,
        'quiet': True,
        'simulate': True,
    }

    ydl = FileDownloader(ytdl_options)
    ydl.params.update({
        'title': 'Video title',
        'artist': 'Author\'s name in the title',
    })

    pp = MetadataFromTitlePP(ydl, '%(artist)s - %(title)s')
    pp_result = pp.run({
        'title': 'Video title - Author\'s name in the title',
    })

    assert len(pp_result) == 2
    assert len(pp_result[0]) == 0
    assert pp_result[1]['title'] == 'Video title'

# Generated at 2022-06-12 19:14:38.484148
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    info = sys.modules[__name__].__dict__
    info['title'] = 'Dive - Ed Sheeran'
    metadata, info = pp.run(info)
    verify_metadata(metadata, info, {'title': 'Dive', 'artist': 'Ed Sheeran'})

    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(album)s')
    info = sys.modules[__name__].__dict__
    info['title'] = 'Dive - Ed Sheeran - ÷ (Deluxe)'
    metadata, info = pp.run(info)

# Generated at 2022-06-12 19:14:49.710827
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from StringIO import StringIO
    # Fake "to_screen" method to be able to catch the output of method run
    buffer = StringIO()
    def to_screen_fake(txt, **kwargs):
        buffer.write(txt)

    def format_to_regex_fake(fmt):
        return fmt

    # Creation of a fake Downloader object
    class DownloaderFake(object):
        def to_screen(self, *args, **kwargs):
            to_screen_fake(*args, **kwargs)
    downloader_fake = DownloaderFake()

    # Creatiion of a fake Info dict
    info_fake = {
        'title': 'Test - Title'
    }

    # Run of method run
    pp = MetadataFromTitlePP(downloader_fake, '%(title)s')
    pp

# Generated at 2022-06-12 19:15:00.660681
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from ..compat import compat_urllib_request
    from ..utils import encode_data_uri
    from ..extractor import gen_extractors
    from ..extractor.common import InfoExtractor
    from ..postprocessor.execafterdownload import ExecAfterDownloadPP

    # Create downloader and initialise fake extractor
    downloader = FileDownloader({})
    downloader.add_info_extractor(FakeIE(downloader))
    downloader.add_post_processor(MetadataFromTitlePP(downloader, '%(artist)s - %(title)s'))

    uri = encode_data_uri(b'content', 'video/x-unknown')
    # Call the method run of MetadataFromTitlePP

# Generated at 2022-06-12 19:15:09.128841
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest
    import tempfile
    import os
    import shutil

    downloader = unittest.mock.MagicMock()
    downloader.to_screen = lambda x, y: None

    def assertEqualInfo(info, expected):
        if info != expected:
            import pprint
            raise AssertionError(
                'info expected:\n%s\ngot:\n%s'
                % (pprint.pformat(expected), pprint.pformat(info)))

    with tempfile.TemporaryDirectory() as tempdir:
        # Test standard format
        title = 'my title - my artist - my album'
        info = {'title': title, 'ext': 'm4a'}

# Generated at 2022-06-12 19:15:18.778004
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import ytdl.YoutubeDL
    downloader = ytdl.YoutubeDL({})
    # Set youtube title
    title = 'Clip 1 - 6. Nov. - 29. Nov. 2014'
    info = {'title': title}
    titleformat = '%(clip)s - %(start)s - %(end)s %(year)s'
    pp = MetadataFromTitlePP(downloader, titleformat)

    # Execute method run
    res, info = pp.run(info)
    # Test result
    assert res == []
    assert info['clip'] == 'Clip 1'
    assert info['start'] == '6. Nov.'
    assert info['end'] == '29. Nov.'
    assert info['year'] == '2014'


# Generated at 2022-06-12 19:15:29.349532
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FakeYDL
    fakeydl = FakeYDL()
    pp = MetadataFromTitlePP(fakeydl, '%(artist)s - %(track)s')
    info = {
        'title': 'Kylie Minogue - Can\'t Get You Outta My Head',
    }
    [], info = pp.run(info)
    assert info['track'] == 'Can\'t Get You Outta My Head'
    assert info['artist'] == 'Kylie Minogue'
    fakeydl.to_screen.assert_called_with('[fromtitle] parsed track: Can\'t Get You Outta My Head')
    fakeydl.to_screen.assert_called_with('[fromtitle] parsed artist: Kylie Minogue')

# Generated at 2022-06-12 19:15:39.494859
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import io

    print_called = False
    def print_message(*args, **kwargs):
        global print_called
        print_called = True
        print(*args, **kwargs)

    def reset_print_called():
        global print_called
        print_called = False

    def check_print_called(expected):
        global print_called
        return (print_called == expected)

    from youtube_dl import YoutubeDL
    from youtube_dl.postprocessor import PostProcessor
    class MockPostProcessor(PostProcessor):
        def __init__(self, *args, **kwargs):
            pass
        def run(self, info):
            return [], info

    def mock_YoutubeDL_init(self, *args, **kwargs):
        self.to_screen = print_message



# Generated at 2022-06-12 19:15:46.239885
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    downloader = YoutubeDL()

    titleformat = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(downloader, titleformat)
    match = re.match(pp._titleregex, 'Test Title - Test Artist')
    assert match is not None
    assert match.groupdict() == {'title': 'Test Title', 'artist': 'Test Artist'}

    titleformat = '%(title)s - %(unknown)s'
    pp = MetadataFromTitlePP(downloader, titleformat)
    match = re.match(pp._titleregex, 'Test Title - Test Artist')
    assert match is not None
    assert match.groupdict() == {'title': 'Test Title', 'unknown': 'Test Artist'}



# Generated at 2022-06-12 19:15:54.971760
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import re
    import os.path
    import shutil
    import sys
    import tempfile

    class FakeInfo():
        def __init__(self, name):
            self.title = name

    class FakeYDL():
        def __init__(self):
            self.to_screen = sys.stderr.write

    def run(titleformat, testname):
        (fd, name) = tempfile.mkstemp(prefix='fake_downloaded_video_')
        os.close(fd)
        try:
            with open(name, 'wb') as f:
                f.write(str.encode(testname))
            pp = MetadataFromTitlePP(FakeYDL(), titleformat)
            _, info = pp.run(FakeInfo(testname))
            return info
        finally:
            os.un

# Generated at 2022-06-12 19:16:03.764153
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import io
    import sys

    import pytest

    from youtube_dl.YoutubeDL import YoutubeDL

    fmt = '%(title)s - %(artist)s - %(genre)s - %(foo)s'
    regex = '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<genre>.+)\ \-\ (?P<foo>.+)'
    title = 'The title - The artist - The genre - The foo'
    metadata = {
        'title': title,
        'artist': None,
        'genre': None,
        'foo': None,
    }

    def fixed_time():
        return 1550571520

    downloader = YoutubeDL(params={'quiet': True})

# Generated at 2022-06-12 19:16:15.734377
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    sys.modules['pytube'] = sys.modules['__main__']
    from pytube import PostProcessor
    from pytube.compat import compat_str
    from pytube.compat import compat_urllib_request

    # Mock the download method of PostProcessor class
    def mocked_download(self, filename, info_dict):
        return

    PostProcessor.download = mocked_download
    mp4 = 'https://example.com/video.mp4'
    # Create a FileDownloadInfo object
    info_dict = dict(id='id', title='title', url=mp4,
                     thumbnail='image url', ext='mp4',
                     playlist='example playlist', playlist_index='1',
                     http_headers=None)
    info = compat_urllib_request.FileDownloadInfo(info_dict)

# Generated at 2022-06-12 19:16:27.104400
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    # Mocked objects
    downloader = object()
    info = {'title': 'Something+Else'}

    # Test run() method
    pp = MetadataFromTitlePP(downloader, '%(title)s')
    assert pp.run(info) == ([], info)
    assert info['title'] == 'Something+Else'

    # Test run() method with invalid expression
    pp = MetadataFromTitlePP(downloader, '%(title)s-%(id)s')
    assert pp.run(info) == ([], info)
    assert info['title'] == 'Something+Else'

    # Test run() method with valid expression
    info['title'] = 'Something+Else-12345'
    pp = MetadataFromTitlePP(downloader, '%(title)s-%(id)s')

# Generated at 2022-06-12 19:16:39.146670
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert MetadataFromTitlePP.run({'title': 'hello world'}, 'hello world')
    assert MetadataFromTitlePP.run({'title': 'hello world'}, ' hello world ')
    assert MetadataFromTitlePP.run({'title': 'hello world'}, '%(title)s')
    assert MetadataFromTitlePP.run({'title': 'hello world'}, ' hello world ')
    # assert MetadataFromTitlePP.run({'title': 'hello world'}, '%(tt)s')
    assert MetadataFromTitlePP.run({'title': 'hello world'}, '%(title)s - bye')
    assert MetadataFromTitlePP.run({'title': 'hello world'}, '(%(title)s - bye)')

# Generated at 2022-06-12 19:16:51.172471
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl.downloader import FakeYDL
    from ytdl.PostProcessor import PostProcessor
    from ytdl.extractor.common import InfoExtractor
    from ytdl.element import *

    class FakeInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return Info(
                {
                    'id': 'test_id',
                    'title': 'test_title - test_artist',
                    'description': 'test_description',
                    'thumbnail': 'test_thumbnail',
                    'ext': 'test_ext',
                    'format': 'test_format',
                    'url': 'test_url',
                    'player_url': 'test_player_url',
                })

    ydl = FakeYDL({'youtube_include_dash_manifest': True})


# Generated at 2022-06-12 19:16:57.809301
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest

    # pylint: disable=protected-access
    class TestMetadataFromTitlePP(unittest.TestCase):
        def test_regex(self):
            titleformat = '%(title)s - %(artist)s'
            titleregex = (MetadataFromTitlePP(None, titleformat)) \
                ._titleregex
            self.assertEqual(
                titleregex,
                '(?P<title>.+)\ \-\ (?P<artist>.+)')
        def test_parse(self):
            titleformat = '%(title)s - %(artist)s'
            title = 'Saturday Morning: Cartoons\' Greatest Hits - Various Artists'
            metadata = {'title': title}
            MetadataFromTitlePP(None, titleformat).run(metadata)
            self.assertE

# Generated at 2022-06-12 19:17:06.437375
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from collections import namedtuple
    from unittest import TestCase

    test_info = namedtuple('TestInfo', ['title'])('abc')
    mftpp = MetadataFromTitlePP(YoutubeDL(), '%(title)s')
    assert mftpp.run(test_info) == ([], {'title': 'abc'})

    version_re = re.compile(r'[0-9.]+')
    test_info = namedtuple('TestInfo', ['title'])('%(title)s version %(version)s')
    mftpp = MetadataFromTitlePP(YoutubeDL(), '%(title)s version %(version)s')

# Generated at 2022-06-12 19:17:17.675484
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    import logging
    class Logger:
        def debug(self, msg):
            logging.debug(msg)
        def warning(self, msg):
            logging.warning(msg)
        def error(self, msg):
            logging.error(msg)
    title = 'pianist - john legend - concert'
    titleformat = '%(title)s - %(artist)s'
    ydl_opts = {}
    ydl = YoutubeDL(ydl_opts)
    ydl.params = {'call_home': False}
    ydl.extract_info = lambda *args, **kargs: {'title': title}
    ydl.download = lambda *args, **kargs: None

# Generated at 2022-06-12 19:17:26.313742
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Initialize class
    downloader = None
    titleformat = '%(title)s - %(artist)s'
    metadata_from_title = MetadataFromTitlePP(downloader, titleformat)

    # Run run method with a string as input
    info = {'title': 'Video title - Artist name'}
    info_from_run, updated_info = metadata_from_title.run(info)

    # Assert the output hoping the run method will have parsed the input
    # successfully
    assert updated_info['title'] == ''
    assert updated_info['artist'] == 'Artist name'

    # Run run method with a string as input that cannot be parsed
    info = {'title': 'Cannot parse'}
    info_from_run, updated_info = metadata_from_title.run(info)

    # Assert

# Generated at 2022-06-12 19:17:32.285963
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ydl.utils import FakeYDL
    from ydl.compat import compat_ascii
    title = 'Jack Johnson - Banana Pancakes'
    titleformat = '%(artist)s - %(title)s'
    # Set the info dict containing the video title
    video_info = {'title': title, 'upload_date': ''}
    metadataFromTitlePP = MetadataFromTitlePP(FakeYDL(),
                                              titleformat)
    metadataFromTitlePP.run(video_info)
    # Check that the metadata have been extracted correctly
    assert video_info['title'] == 'Banana Pancakes'
    assert compat_ascii(video_info['artist']) == 'Jack Johnson'

# Generated at 2022-06-12 19:17:41.514008
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.utils import DateRange

    title = 'Video - Asshole of the week: Trump'
    titleformat = '%(title)s - %(artist)s'
    expectedinfo = {
        'title': 'Video',
        'artist': 'Asshole of the week: Trump',
    }

    class MockYDL:
        def to_screen(s, m):
            pass

    class TestPP(MetadataFromTitlePP):
        def __init__(self, ydl, titleformat):
            super(TestPP, self).__init__(ydl, titleformat)

    pp = TestPP(MockYDL(), titleformat)
    ret, info = pp.run({
        'id': 'foobar',
        'title': title,
        'upload_date': DateRange('20171103'),
    })

# Generated at 2022-06-12 19:18:02.441848
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .youtube_dl.YoutubeDL import YoutubeDL
    from .youtube_dl.YoutubeDL import YoutubeDL
    from .compat import compat_str

    def get_info():
        return {'title': 'Selfie - The Chainsmokers'}

    def get_outtmpl():
        return '%(title)s.mp3'

    def to_screen(msg):
        pass

    ydl = YoutubeDL({})
    ydl.params['outtmpl'] = get_outtmpl
    ydl.my_getinfo = get_info
    ydl.to_screen = to_screen

    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    ret, info = pp.run(get_info())

    # assert that the title and artist keys were parsed correctly

# Generated at 2022-06-12 19:18:12.153324
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys, os

    meta_fmt = '%(artist)s -- %(title)s'
    meta_regex = '(?P<artist>.+)' + re.escape(' -- ') + '(?P<title>.+)'
    meta_titles = [
        'Adam K -- Wake Up (Ft. Matthew Steeper) [Monstercat Release]',
        'Adam K -- Wake Up (Ft. Matthew Steeper)',
        'Adam K - Wake Up (Ft. Matthew Steeper) [Monstercat Release]',
        'Adam K - Wake Up (Ft. Matthew Steeper)',
        '[Monstercat Release] Adam K -- Wake Up (Ft. Matthew Steeper)',
        '[Monstercat Release] Adam K -- Wake Up (Ft. Matthew Steeper)',
    ]

# Generated at 2022-06-12 19:18:22.615122
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    mp3_result = {
        'title': '[한글자막]소수점 이하를 곱하는 방법 익히기 by 한국현대문화유산원 머지않아요정현'
    }
    mp3_test = MetadataFromTitlePP(None, '%(title)s')
    testresult = mp3_test.run(mp3_result)


# Generated at 2022-06-12 19:18:28.084813
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import Downloader, FileDownloader
    from .extractor.common import InfoExtractor
    from .utils import sanitize_filename
    from .compat import compat_urllib_parse_unquote


# Generated at 2022-06-12 19:18:36.087441
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.downloader import YoutubeDL
    downloader = YoutubeDL()
    bad_url = 'http://www.youtube.com/watch?v=123456789'
    info = {
        'title': 'No match',
        'webpage_url': bad_url,
        'extractor': 'youtube',
        'extractor_key': 'Youtube',
        'duration': 123
    }

    # Should not modify info since it doesn't match
    MetadataFromTitlePP(downloader, '%(title)s').run(info)
    assert info == {
        'title': 'No match',
        'webpage_url': bad_url,
        'extractor': 'youtube',
        'extractor_key': 'Youtube',
        'duration': 123
    }

    # Should modify title and extract ID

# Generated at 2022-06-12 19:18:45.502895
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    downloader = YoutubeDL()
    pp = MetadataFromTitlePP(downloader,
                             '%(uploader)s - %(upload_date)s - %(title)s')

    info = {}
    info['title'] = 'Crash Course Psychology #16 - Memory'
    title = info['title']

    pp.run(info)
    assert 'uploader' in info
    assert 'upload_date' in info
    assert info['uploader'] == 'CrashCourse'
    assert info['upload_date'] == '20121210'
    assert info['title'] == title

    pp = MetadataFromTitlePP(downloader,
                             '%(uploader)s - %(upload_date)s - %(title)s')

    info = {}

# Generated at 2022-06-12 19:18:55.945055
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl
    import unittest

    class FakeInfoDict(dict):
        pass

    class FakeYDL(object):
        pass

    ydl = FakeYDL()
    ydl.to_screen = lambda s: None
    info = FakeInfoDict({'title': 'test - test'})

    p = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    p.run(info)
    assert info['title'] == 'test'
    assert info['artist'] == 'test'

    info = FakeInfoDict({'title': 'test - test'})
    p = MetadataFromTitlePP(ydl, '%(title)s')
    p.run(info)
    assert info['title'] == 'test - test'

# Generated at 2022-06-12 19:19:06.976924
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import json
    import unittest
    import collections
    import re

    class FakeDL(object):
        def __init__(self):
            self.calls = []
            self.infos = []
        def to_screen(self, s):
            self.calls.append(('to_screen', s))
        def to_stdout(self, s):
            self.calls.append(('to_stdout', s))

    class FakeInfo(dict):
        def __init__(self, d):
            for key in d:
                self[key] = d[key]
        def __setitem__(self, key, value):
            self.infos.append(('set', key, value))
            dict.__setitem__(self, key, value)

# Generated at 2022-06-12 19:19:16.365100
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from collections import namedtuple
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import DateRangeFaker

    from youtube_dl.extractor.youtube import YoutubeIE

    downloader = YoutubeDL(params={'outtmpl': '%(id)s.%(ext)s'})
    parse = DateRangeFaker(DateRange('20100101'), DateRange('20100102')).parse
    downloader.add_info_extractor(YoutubeIE(downloader))
    downloader.add_default_info_extractors()


# Generated at 2022-06-12 19:19:20.741220
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl.downloader import YoutubeDL
    p = MetadataFromTitlePP(YoutubeDL(), '%(title)s - %(artist)s')
    info = {
        'title': 'My video title - My video artist',
    }
    p.run(info)
    assert info['title'] == 'My video title'
    assert info['artist'] == 'My video artist'

# Generated at 2022-06-12 19:19:49.524209
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class TestDownloader:
        def to_screen(self, msg):
            pass

    test_pp = MetadataFromTitlePP(TestDownloader(),'%(title)s - %(artist)s')

    test_info = {'title': 'Test Title - Test Artist'}
    test_pp.run(test_info)
    assert test_info['title'] == 'Test Title' and test_info['artist'] == 'Test Artist'

    test_info = {'title': 'Test Title'}
    test_pp.run(test_info)
    assert test_info['title'] == 'Test Title' and not 'artist' in test_info

    test_info = {'title': 'Test Title - Test Artist - Test Album'}