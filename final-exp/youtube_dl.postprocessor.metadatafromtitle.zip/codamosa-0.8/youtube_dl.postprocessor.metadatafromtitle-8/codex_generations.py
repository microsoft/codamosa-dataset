

# Generated at 2022-06-12 19:10:04.087386
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys; sys.path.append('..')  # For importing downloader

    metadata = {'title': 'Original Title - Artist'}
    formats = {
        '%(title)s - %(artist)s': ['title', 'artist'],
        '%(artist)s - %(title)s': ['artist', 'title'],
        '%(title)s': ['title'],
    }

    for titleformat, expected in formats.items():
        metadata_copy = metadata.copy()
        from .youtube_dl import YoutubeDL
        processor = MetadataFromTitlePP(YoutubeDL(), titleformat)
        result, info = processor.run(metadata_copy)
        assert processor._titleregex == processor.format_to_regex(titleformat)
        assert info == expected_result(expected, metadata)



# Generated at 2022-06-12 19:10:11.668092
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    #import ydl

    # TODO: Write test
    #print(sys.getdefaultencoding())
    # sample_filename = '2015-01-02_12-00-00.mp4'
    # sample_title = 'LIVE: Watch the '
    # sample_metadata = {'title': sample_title, 'autonumber': '12'}

    #mftpp = MetadataFromTitlePP(ydl, '%(title)s%(autonumber)s')
    #mftpp.run(sample_metadata)


# Generated at 2022-06-12 19:10:16.816133
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.youtube import YoutubeIE
    from .test_utils import FakeYDL

    ydl = FakeYDL({'extractors': [YoutubeIE.ie_key()]})
    ydl.add_default_info_extractors()
    postprocessor = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s - %(track)s')

    # info with title 'Cool Title - Fun Artist - 1'

# Generated at 2022-06-12 19:10:21.842063
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    PP = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    info = {'title': 'Artist-Song'}
    [], info = PP.run(info)
    assert info['artist'] == 'Artist'
    assert info['title'] == 'Song'

    # Test with a shorter title
    info = {'title': 'Artist'}
    [], info = PP.run(info)
    assert info['artist'] == 'Artist'
    assert 'title' not in info

    # Test with title longer than expected
    info = {'title': 'Artist - Song 1 - Song 2'}
    [], info = PP.run(info)
    assert info['artist'] == 'Artist'
    assert info['title'] == 'Song 1'

    # Test with a subtitle in the title
    PP

# Generated at 2022-06-12 19:10:32.085372
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    Unit tests for the method run.
    """
    import sys
    import unittest
    from .common import FakeInfoExtractor

    # replace original sys.stdout
    sys.stdout = sys.__stdout__

    class DummyDownloader(object):
        def to_screen(self, msg):
            pass

    class DummyExtractor(FakeInfoExtractor):
        titleformat = '%(title)s - %(artist)s'

    # create instance of dummy downloader and extractor
    dummy_ydl = DummyDownloader()
    dummy_extractor = DummyExtractor(dummy_ydl)
    pp = MetadataFromTitlePP(dummy_ydl, dummy_extractor.titleformat)

    # create dummy video information

# Generated at 2022-06-12 19:10:42.141246
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test case description:
    #   Input:
    #     Object MetadataFromTitlePP with formatting string "%(title)s - %(artist)s"
    #     Object with dictionary in parameter info:
    #       key: 'title'
    #       value: 'Song Title - Artist Name'
    #   Output:
    #     List of object with dictionary in parameter info:
    #       key: 'title'
    #       value: 'Song Title'
    #     List of object with dictionary in parameter info:
    #       key: 'artist'
    #       value: 'Artist Name'
    mf = MetadataFromTitlePP(None, "%(title)s - %(artist)s")
    info = {'title': 'Song Title - Artist Name'}
    res = mf.run(info)

# Generated at 2022-06-12 19:10:49.532821
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """Test method run() of class MetadataFromTitlePP"""
    downloader = None
    titleformat = "%(artist)s - %(title)s from %(album)s"
    metadata = {
            'title'   : 'A title for the video'
        }
    pp = MetadataFromTitlePP(downloader, titleformat)
    # Test: no match
    initial_metadata = metadata
    metadata = {
            'title'   : 'A title for the video'
        }
    postprocessors, metadata = pp.run(metadata)
    if (metadata['artist'], metadata['title'], metadata['album']) != (None, None, None):
        print("test_MetadataFromTitlePP_run(): FAILED: match when none expected: %s" % metadata)
    if metadata != initial_metadata:
        print

# Generated at 2022-06-12 19:10:54.492471
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    mp = MetadataFromTitlePP(None, '%(title)s')
    mp._titleregex = '%\(title\)s'
    title = 'video title'
    info = {'title': title}
    mp.run(info=info)
    assert info['title'] == title
    assert 'artist' not in info


# Generated at 2022-06-12 19:11:00.934887
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class MockYD(object):
        def __init__(self):
            self.to_screen = print

    info = {'title': 'Splin - Topol'}
    titleformat = '%(artist)s - %(title)s'
    instance = MetadataFromTitlePP(MockYD(), titleformat)
    result = instance.run(info)
    assert result == ([], {'title': 'Splin - Topol', 'artist': 'Splin'})


# Generated at 2022-06-12 19:11:08.592278
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest
    obj = MetadataFromTitlePP(None, None)
    obj.format_to_regex = lambda x: x
    # Check that a title like '"One% - Two% - Three"' is parsed correctly
    # if the title format is '"%(artist)s - %(title)s - %(album)s"'
    obj._titleformat = r'"%(artist)s - %(title)s - %(album)s"'
    response = obj.run({'title': '"One% - Two% - Three"'})
    obj._titleformat = r'"%(artist)s - %(title)s - %(album)s"'

# Generated at 2022-06-12 19:11:20.471447
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
     p = MetadataFromTitlePP('dummy_downloader', '%(title)s')
     info = {'title': 'title'}
     r1 = p.run(info)
     info = {'title': 'title - artist'}
     r2 = p.run(info)
     assert r1 == ([], {'title': 'title'})
     assert r2 == ([], {'title': 'title - artist', 'artist': 'artist'})
     p = MetadataFromTitlePP('dummy_downloader',
                             '%(title)s - %(artist)s - %(album)s')
     info = {'title': 'title - artist - album'}
     r3 = p.run(info)

# Generated at 2022-06-12 19:11:32.280429
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp.format_to_regex(pp._titleformat) == '(?P<artist>.+)\ \-\ (?P<title>.+)'
    assert pp._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'
    assert pp.run({'title':'Adele - Hello'}) == ([], {'title':'Adele - Hello', 'artist':'Adele'})
    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp.run({'title':'Adele - Hello'}) == ([], {'title':'Adele - Hello'})

# Generated at 2022-06-12 19:11:41.196137
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import time
    import pycurl
    import pprint
    import tempfile
    from io import BytesIO
    from collections import namedtuple
    from youtube_dl.YoutubeDL import YoutubeDL

    pp = MetadataFromTitlePP(None, '%(title)s by %(artist)s')
    song_info = {'title': 'Helena by My Chemical Romance'}
    _, song_info = pp.run(song_info)
    expected = {
        'title': 'Helena',
        'artist': 'My Chemical Romance',
    }
    assert song_info == expected



# Generated at 2022-06-12 19:11:51.441041
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ..downloader import YoutubeDL
    import json
    import os

    dl = YoutubeDL()
    dl.to_screen = lambda x: x # remove output for this unit test
    pp = MetadataFromTitlePP(dl, "%(artist)s - %(track)s")
    info = {
        'format_id': 'high',
        'ext': 'mp4',
        'title': 'The XX - VCR',
        'format': '720p',
        'filesize': 12345,
        'acodec': 'aac',
        'vcodec': 'h264',
    }

    result, info = pp.run(info)
    assert info['artist'] == 'The XX'
    assert info['track'] == 'VCR'


# Generated at 2022-06-12 19:11:59.166167
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl.extractor.youtube
    from youtube_dl.YoutubeDL import YoutubeDL
    from collections import OrderedDict
    from unittest import TestCase


# Generated at 2022-06-12 19:12:08.749966
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    run() method test of class MetadataFromTitlePP.
    """
    class dummy_downloader(object):
        def to_screen(self, msg):
            print(msg)

    # Create an instance of class MetadataFromTitlePP
    x = MetadataFromTitlePP(dummy_downloader(), '%(title)s - %(artist)s')
    info = dict()

    # info as required by _match_title method
    info['title'] = 'First Song - Artist 1'
    info['uploader'] = 'FirstArtist'
    info['uploader_id'] = '1234'
    info['uploader_url'] = 'http://www.youtube.com/firstartist'
    info['extractor'] = 'youtube'

# Generated at 2022-06-12 19:12:18.372720
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import tempfile
    
    if sys.version_info >= (3, 0):
        from io import StringIO
    else:
        from StringIO import StringIO
    from youtube_dl.YoutubeDL import YoutubeDL
        
    # Test positive cases

# Generated at 2022-06-12 19:12:22.910155
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .downloader import Downloader
    metadataformat = '%(episode_number)s - %(title)s'
    title = '1 - Title'
    metadata = {'episode_number': None, 'title': title}
    fromtitle = MetadataFromTitlePP(Downloader(None), metadataformat)
    metadata = fromtitle.run(metadata)[1]
    assert metadata['episode_number'] == '1'

# Generated at 2022-06-12 19:12:23.726733
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # TODO
    assert False




# Generated at 2022-06-12 19:12:28.492382
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    info = {'title': 'testartist - testtitle'}
    expected_output = [{}, {'artist': 'testartist', 'title': 'testtitle'}]
    result = pp.run(info)
    assert result == expected_output



# Generated at 2022-06-12 19:12:40.856248
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from collections import namedtuple
    from pytube.compat import compat_urllib_http
    from pytube.downloader import Downloader
    from pytube.extractor import YoutubeIE
    from pytube.postprocessor.common import FFmpegPostProcessor
    from pytube.config import DEFAULT_OUTTMPL

    # Define Downloader, and YoutubeIE
    dl = Downloader()
    MockResponse = namedtuple('MockResponse', ['read'])

    # Extract info
    info_dict = dict(
        url='http://www.youtube.com/watch?v=BaW_jenozKc',
        ie_key='Youtube'
    )
    ie = YoutubeIE(dl, info_dict)
    info_dict = ie.extract(info_dict['url'])

    # Mock the HTTP response


# Generated at 2022-06-12 19:12:52.772024
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Scenario:
    # Titleformat: "%(artist)s - %(title)s"
    # Title: "Justin Bieber - Baby ft. Ludacris"
    # Result: no change, because of 'ft.' in the title
    titleformat = '%(artist)s - %(title)s'
    title = 'Justin Bieber - Baby ft. Ludacris'
    pp = MetadataFromTitlePP(None, titleformat)
    result = pp.run({'title': title})
    assert result[1]['artist'] == None
    assert result[1]['title'] == title

    # Scenario:
    # Titleformat: "%(artist)s - %(title)s"
    # Title: "Justin Bieber - Baby feat. Ludacris"
    # Result: change

# Generated at 2022-06-12 19:13:02.707004
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    mft = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    info = {'title': 'Nightcore - We Own The Sky'}
    mft.run(info)
    assert info['artist'] == 'Nightcore'

    # For the following tests, a whole single video is created
    import os
    import os.path
    from .extractor import gen_extractors
    from .common import FileDownloader

    class FakeLogger():
        def debug(self, msg):
            pass

        def warning(self, msg):
            pass

        def error(self, msg):
            pass


# Generated at 2022-06-12 19:13:13.540642
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    expected = {'attribute1': 'value1', 'attribute2': 'value2', 'attribute3': 'value3'}
    title = 'value1 - value2 - value3'
    titleformat = '%(attribute1)s - %(attribute2)s - %(attribute3)s'
    # Test with a normal titleformat
    pp = MetadataFromTitlePP(None, titleformat)
    assert pp._titleregex == (pp.format_to_regex(titleformat))
    info = {'title': title}
    assert pp.run(info) == ([], expected)
    # Test with a titleformat that contains characters that need to be escaped
    titleformat = '%(attribute1)s - %(attribute2)s - %%(attribute3)s'
    pp = MetadataFromTitlePP(None, titleformat)


# Generated at 2022-06-12 19:13:19.057629
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    mft = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    info = {'title': 'Sending My Love - Zhane'}
    result = mft.run(info)
    assert info == {'artist': 'Zhane', 'title': 'Sending My Love'}
    assert result == ([], info)

# Generated at 2022-06-12 19:13:28.907737
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    Test MetadataFromTitlePP.run
    """
    from youtube_dl.downloader import Downloader
    from youtube_dl.utils import YoutubeDL
    ydl = YoutubeDL({})
    d = Downloader(ydl)
    m = MetadataFromTitlePP(d, '%(artist)s-%(title)s-%(year)s')
    m.run({'title': 'tit-le-2015'}) == [], {'artist': 'tit', 'title': 'le', 'year': '2015'}
    m.run({'title': 'tit-le-20XX'}) == [], {'artist': 'tit', 'title': 'le', 'year': '20XX'}
    m.run({'title': 'tit-le-2015-with-more'}) == [],

# Generated at 2022-06-12 19:13:40.666646
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """Tests title parsing functionality"""
    import os
    import sys
    import unittest

    sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))

    class TestDownloaderPP(PostProcessor):
        def __init__(self, to_screen=lambda s: None):
            self.to_screen = to_screen

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.to_screen = lambda s: None
            self.downloader = TestDownloaderPP(to_screen=self.to_screen)
            self.mftpp = MetadataFromTitlePP(self.downloader, "%(artist)s - %(title)s")


# Generated at 2022-06-12 19:13:52.158171
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import os
    import sys
    import shutil
    import tempfile
    import unittest

    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor

    class FakeInfoDict(object):
        def __init__(self, videoinfo):
            self.videoinfo = videoinfo

    # Monkey patch PostProcessor
    PostProcessor.__bases__ = (object,)
    # The DummyPP does nothing
    class DummyPP(PostProcessor):
        def run(self, info):
            return [], info

    class FromTitlePPTest(unittest.TestCase):
        def setUp(self):
            self.downloader = YoutubeDL({'outtmpl': '%(title)s'})
            self.tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-12 19:14:03.868141
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .YoutubeDL import YoutubeDL
    from .extractor.common import InfoExtractor
    from .utils import DateRange

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name, ie_id):
            InfoExtractor.__init__(self, ie_name, ie_id)

        def _real_extract(self, url):
            return {}

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, params):
            self.params = params
            self.to_screen = params.get('to_screen', None)
            self.params['extractors'] = [
                (FakeInfoExtractor('testie1', 'extractor1'), FakeInfoExtractor('testie2', 'extractor2'))]
            self.params['extractor_key']

# Generated at 2022-06-12 19:14:09.915002
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    res = {'title': '123 - 243 - aaa'}
    fromtitle = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    newinfo = fromtitle.run(res)
    print(newinfo)
    assert len(newinfo) == 0
    assert newinfo[1]['artist'] == '243 - aaa'



# Generated at 2022-06-12 19:14:25.076342
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import pytube
    from types import MethodType
    from collections import namedtuple

    title_format = '%(artist)s - %(title)s'
    title_regex = '(?P<artist>.+) - (?P<title>.+)'
    # Fake downloader
    downloader = namedtuple('FakeDownloader', ('to_screen',))._make([lambda x: None])
    # Fake postprocessor
    postprocessor = MetadataFromTitlePP(downloader, title_format)
    postprocessor._titleregex = title_regex
    # Fake video info
    video_info = {'title': 'test - test'}

    assert('title' not in video_info)
    assert('artist' not in video_info)

    # Test postprocessor

# Generated at 2022-06-12 19:14:30.170207
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from test import mock_dl

    # test simple case where titleformat is a constant string
    pp = MetadataFromTitlePP(mock_dl(), 'foo')
    assert pp.run({'title': 'foo'}) == ([], {})
    assert pp.run({'title': 'foobar'}) == ([], {'title': 'foobar'})

    # test regex case where titleformat is a regex
    pp = MetadataFromTitlePP(mock_dl(), 'foo(?P<bar>.+)')
    assert pp.run({'title': 'foo'}) == ([], {'bar': None})
    assert pp.run({'title': 'foobar'}) == ([], {'bar': 'bar'})

    # test real world case where titleformat is a python format string
    # with 'name' placeholders
    pp = Met

# Generated at 2022-06-12 19:14:39.391491
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FD
    from .extractor import GenYoutubeIE

    # Case: simple string with one group
    pp = MetadataFromTitlePP(FD(), '%(title)s')
    info = {'title': 't', 'webpage_url': 'w'}
    r, info = pp.run(info)
    assert info['title'] == 't'
    assert r == []

    # Case: simple string (no group)
    pp = MetadataFromTitlePP(FD(), 't')
    info = {'title': 't', 'webpage_url': 'w'}
    r, info = pp.run(info)
    assert info['title'] == 't'
    assert r == []

    # Case: two simple strings

# Generated at 2022-06-12 19:14:50.855985
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest
    import sys
    from io import BytesIO
    from .common import FileDownloader, FakeYDL
    from .compat import compat_urllib_error

    class FakeFileDownloader(FileDownloader):
        def __init__(self, ydl, params):
            self.ydl = ydl
            self.params = params

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            ydl = FakeYDL({'logger': sys.stdout})
            params = {}
            self.fakedl = FakeFileDownloader(ydl, params)
            self.pp = MetadataFromTitlePP(self.fakedl, '%(title)s - %(artist)s')


# Generated at 2022-06-12 19:15:01.662836
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from . import FileDownloader

    def get_file_title(url):
        if url == 'http://example.com/some_video':
            return "some_video - http://example.com/some_video"
        else:
            return None

    # dummy downloader
    downloader = FileDownloader({})
    downloader.get_info_extractor = lambda x: None
    downloader.get_file_title = get_file_title

    # dummy postprocessor
    p = MetadataFromTitlePP(downloader, r'%(video_id)s')

    # title format matches
    t = 'some_video - http://example.com/some_video'
    url = 'http://example.com/some_video'
    info = {'title': t}

# Generated at 2022-06-12 19:15:09.317988
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({'verbose': True})
    titleformat = '%(title)s - %(uploader)s - %(id)s'
    pp = MetadataFromTitlePP(ydl, titleformat)
    # Test for a sample title
    info = {'title': 'Sample Title - uploader - 12345'}
    assert pp.run(info) == ([], {'title': 'Sample Title',
                                 'uploader': 'uploader',
                                 'id': '12345'})
    # Test for invalid title
    info = {'title': 'Invalid Title'}
    assert pp.run(info) == ([], {'title': 'Invalid Title'})

# Generated at 2022-06-12 19:15:19.230903
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ydl.compat import compat_http_server
    from ydl.downloader.common import FileDownloader
    from ydl.downloader.http import HttpFD
    import tempfile
    import os.path
    import threading

    class TestHTTPServer(compat_http_server.HTTPServer):
        def run(server):
            server.serve_forever()

    class TestPP(MetadataFromTitlePP):
        def __init__(self, titleformat):
            super(TestPP, self).__init__(None, titleformat)

        def write_string(self, s):
            self.result = s

    handle, fname = tempfile.mkstemp(prefix='youtubedl.', suffix='.mp4')
    os.close(handle)
    os.remove(fname)



# Generated at 2022-06-12 19:15:30.856729
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import youtube_dl
    from .extractor import YoutubeIE
    from .downloader import Downloader

    def _get_video_info(url, title, fmt):
        ydl = youtube_dl.YoutubeDL({'verbose': False})
        downloader = Downloader(ydl, {}, {})
        info = {'url': url, 'extractor': YoutubeIE.ie_key(), 'title': title}
        pp = MetadataFromTitlePP(downloader, fmt)
        pp.run(info)
        return info

    # simple example with one group

# Generated at 2022-06-12 19:15:41.194457
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    Unit test for method run of class MetadataFromTitlePP
    """
    import re
    import sys
    sys.path.append(r'test')

    from ydl import YDL
    mdftpp = MetadataFromTitlePP(YDL(), '%(title)s - %(artist)s')
    info = {'title': 'Video Title - Video Artist'}
    info = mdftpp.run(info)
    assert info[0] == [] and info[1] == {'title': 'Video Title', 'artist': 'Video Artist'}

    mdftpp = MetadataFromTitlePP(YDL(), '%(artist)s - %(title)s')
    info = {'title': 'Video Title - Video Artist'}
    info = mdftpp.run(info)
    assert info[0] == []

# Generated at 2022-06-12 19:15:52.012154
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pp = MetadataFromTitlePP(None, '%(title)s')
    # title, no match
    info = {'title': 'foobar'}
    downloaded, info_out = pp.run(info)
    assert info == info_out
    # title, match group 1
    title = 'foo bar'
    pp = MetadataFromTitlePP(None, 'foo %(title)s')
    info = {}
    downloaded, info_out = pp.run(info)
    assert info_out['title'] == 'bar'
    # title, match group 2
    pp = MetadataFromTitlePP(None, 'foo %(title)s bar %(title)s')
    info = {}
    downloaded, info_out = pp.run(info)
    assert info_out['title'] == 'bar'
    # title,

# Generated at 2022-06-12 19:16:11.216602
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import ytdl_pp as pp
    import sys
    import os
    import tempfile

    assert sys.version_info[0] == 2, 'test_MetadataFromTitlePP_run only valid for Python 2'

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a ytdl_pp.BaseYoutubedl object
    ydl = pp.BaseYoutubedl(ydl_opts={'format': 'best',
                                     'outtmpl': temp_dir + '/%(title)s-%(id)s.%(ext)s',
                                     'writeinfojson': True,
                                     'writethumbnail': True,
                                     'writesubtitles': True})

    # Create a ytdl_pp.MetadataFromTitlePP object
    title

# Generated at 2022-06-12 19:16:16.974937
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    import json
    import os

    input_file = os.path.join(os.path.dirname(__file__), 'postprocessor.py')
    output_file = '/tmp/metadata_from_titlepp_test.json'

    ydl = YoutubeDL({
        'postprocessors': [{
            'key': 'MetadataFromTitle',
            'titleformat': '%(title)s - %(id)s',
        }],
        'outtmpl': output_file,
    })
    ydl.params['logger'].setLevel(50)
    ydl.download([input_file])

    with open(output_file, 'r') as f:
        info_dict = json.load(f)


# Generated at 2022-06-12 19:16:27.981739
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    downloader = object()
    info = {'title': 'Test - Foo'}
    titleformat = '%(title)s - %(artist)s'

    p = MetadataFromTitlePP(downloader, titleformat)
    assert p.run(info) == ([], {'title': 'Test - Foo',
                                'artist': 'Foo'})

    p2 = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s - %(bar)s')
    assert p2.run(info) == ([], {'title': 'Test - Foo',
                                 'artist': 'Foo',
                                 'bar': ''})

    info = {'title': 'Artur Rubinstein plays Chopin nocturne in G minor'}

# Generated at 2022-06-12 19:16:39.864917
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import mock_downloader
    from .compat import compat_urllib_parse_unquote_plus

    class TestPP(MetadataFromTitlePP):
        def __init__(self, titleformat):
            super(TestPP, self).__init__(None, titleformat)

    attrs = ['%(title)s', '%(artist)s - %(title)s']
    titles = ['title', 'artist - title']
    for attr, title in zip(attrs, titles):
        res, info = TestPP(attr).run({'title': title})
        assert info['title'] == title
        assert res == []

    # unquoted '%' characters should be supported
    pp = TestPP('%(title)s')

# Generated at 2022-06-12 19:16:51.913873
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    Unit test for method run of class MetadataFromTitlePP
    """
    import os
    import sys
    import unittest
    import doctest
    import inspect

    # Test for wrong types of parameters (AssertionError)
    # Copy-paste from method run of class MetadataFromTitlePP
    class TestMetadataFromTitlePP(object):
        def __init__(self, downloader, titleformat):
            self._downloader = downloader
            self._titleformat = titleformat
            self._titleregex = (self.format_to_regex(titleformat)
                                if re.search(r'%\(\w+\)s', titleformat)
                                else titleformat)


# Generated at 2022-06-12 19:16:58.130063
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from collections import namedtuple
    from unittest.mock import MagicMock

    TitleInfo = namedtuple('VideoInfo', ['title'])
    ph = {'title': None}
    downloader = MagicMock()
    downloader.to_screen = MagicMock()

    mp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    assert mp.format_to_regex(mp._titleformat) == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert mp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-12 19:17:06.605041
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl
    import os
    import tempfile

    # youtube-dl.org/watch?v=XXXXXX returns XXXXXX
    test_url = 'youtube-dl.org/watch?v=ABCDEFGHIJK'
    downloader = youtube_dl.YoutubeDL({'outtmpl': '%(id)s%(ext)s'})
    downloader.add_info_extractor(
        youtube_dl.extractor.YoutubeIE(downloader))
    test_info = {'id': 'ABCDEFGHIJK',
                 'title': 'yt-dl test video 1, \"/\\\':ä↭'
                }

    info_dicts, new_info = MetadataFromTitlePP(downloader, '%(id)s')(test_info)

# Generated at 2022-06-12 19:17:17.850480
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    Checks that run method is working properly
    """
    from youtube_dl.YoutubeDL import YoutubeDL

    regex_format = '%(artist)s - %(track)s'
    regex = (MetadataFromTitlePP.format_to_regex(regex_format)
             if re.search(r'%\(\w+\)s', regex_format)
             else regex_format)

    ydl = YoutubeDL({'writedescription': True,
                     'writeannotations': True,
                     'writeinfojson': True,
                     'writethumbnail': True,
                     'write_all_thumbnails': True,
                     'format': 'bestaudio/best',
                     'postprocessors': [{'key': 'MetadataFromTitle',
                                         'format': regex_format}]})
    ydl.add_default

# Generated at 2022-06-12 19:17:26.506174
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Mock up a downloader to test the method 'run'
    class MockYDL:
        def to_screen(self, msg):
            print(msg)

    ydl = MockYDL()
    ydl.to_screen('[fromtitle] Could not interpret title of video as "a|b"')
    pp = MetadataFromTitlePP(ydl, 'a|b')
    info = {'title': 'c|d'}
    pp.run(info)
    assert 1 == len(info)
    assert info['title'] == 'c|d'

    ydl.to_screen('[fromtitle] parsed b: c')
    pp = MetadataFromTitlePP(ydl, 'a|b')
    info = {'title': 'c|d'}
    pp.run(info)
    assert 2 == len

# Generated at 2022-06-12 19:17:33.312795
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ydl.extractor import YoutubeIE
    from ydl.utils import prepare_filename

    mock_ydl = type('mock_ydl', (object,), {
        'params': {'outtmpl': '%(title)s-%(id)s.%(ext)s'},
        'to_screen': lambda m: print('[TO_SCREEN] %s' % m)
    })()
    ie = YoutubeIE(mock_ydl)
    ie.report_download_page = lambda m: None # disable reporting

    def fetch_page(url, headers=None, data=None):
        return '{"id": "eL_PfvzPI14"}'

    ie.fetch_page = fetch_page

# Generated at 2022-06-12 19:17:57.777706
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    dummy_downloader = object()
    pp = MetadataFromTitlePP(dummy_downloader, '%(title)s - %(artist)s')
    video_info = {'title': 'Interpretation - Missingno'}
    assert pp.run(video_info) == ([], {'title': 'Interpretation', 'artist': 'Missingno'})



# Generated at 2022-06-12 19:18:05.647877
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class Downloader:
        def __init__(self):
            self._to_screen_log = []

        def to_screen(self, msg):
            self._to_screen_log.append(msg)

    downloader = Downloader()

    info = {'title': 'Captain Phillips - Official Trailer (HD) - YouTube'}
    pp = MetadataFromTitlePP(downloader, '%(artist)s - %(title)s')
    info = pp.run(info)[1]
    assert info == {'title': 'Captain Phillips',
                    'artist': 'Official Trailer (HD)',
                    '_filename': None,
                    '_id': None}

# Generated at 2022-06-12 19:18:15.829616
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    class TestDownloaderPP:
        def __init__(self):
            self.to_screen_value = ''
        def to_screen(self, value):
            self.to_screen_value += value + '\n'
    class TestInfoPP:
        def __init__(self, title_value):
            self.title = title_value
            self.artist = None
            self.year = None
            self.genre = None
    dl = TestDownloaderPP()
    pp = MetadataFromTitlePP(dl, '%(title)s - %(artist)s - %(year)s - %(genre)s')
    title_value = 'Dazed and Confused - Led Zeppelin - 1973 - Rock'
    res_info = TestInfoPP(title_value)

# Generated at 2022-06-12 19:18:24.862675
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    def downloader_getter(name):
        return lambda self, message: print(message)
    Downloader.to_screen = downloader_getter('to_screen')
    # A sample video title
    video_title = 'A video (2011) - A description'
    # Self explanatory
    title_format = '%(title)s (%(year)s)'
    info = {'title': video_title}
    postprocessor = MetadataFromTitlePP(downloader_getter, title_format)
    processed, metadata = postprocessor.run(info)
    assert processed == []
    assert metadata['title'] == 'A video'
    assert metadata['year'] == '2011'

if __name__ == "__main__":
    import sys
    import inspect
    import pytest

    # Get a list of all functions, classes and

# Generated at 2022-06-12 19:18:34.637891
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    def fake_formatter(info):
        info['title'] = 'Super - Bad Guy (2012)'
        return info

    def fake_downloader():
        downloader = object()
        downloader.to_screen = lambda x: x
        return downloader

    f = MetadataFromTitlePP(fake_downloader(), '%(artist)s - %(track)s (%(year)s)')
    res, info = f.run(fake_formatter({}))
    assert info['artist'] == 'Super'
    assert info['track'] == 'Bad Guy'
    assert info['year'] == '2012'

    f = MetadataFromTitlePP(fake_downloader(), '%(track)s - %(artist)s')
    res, info = f.run(fake_formatter({}))

# Generated at 2022-06-12 19:18:44.378315
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    downloader_test = YoutubeDL({
        'merge_output_format': 'mkv',
        'format': 'bestvideo+bestaudio',
        'postprocessors': [{'key': 'MetadataFromTitlePP', 'titleformat': "%(artist)s - %(track)s"}]
    })
    downloader_test.add_default_info_extractors()

    # Test regex with the above regex
    title = 'Britney Spears - Criminal'
    date = DateRange('20120908')
    filename = 'Britney_Spears_Criminal_Criminal'
    # info should be a dictionary

# Generated at 2022-06-12 19:18:49.314387
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    info = {'title' : 'foo - bar'}
    unittest.TestCase().assertEqual(
        pp.run(info), ([], {'artist': 'bar', 'title': 'foo'}))



# Generated at 2022-06-12 19:18:58.396118
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    info = {'title': 'The Title - The Artist'}
    pp.run(info)
    assert info == {
        'title': 'The Title',
        'artist': 'The Artist'
    }

    pp = MetadataFromTitlePP(None, '%(title)s')
    info = {'title': 'The Title - The Artist'}
    pp.run(info)
    assert info == {
        'title': 'The Title - The Artist'
    }

    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    info = {'title': 'The Title - The Artist - Album: The Album'}
    pp.run(info)

# Generated at 2022-06-12 19:19:08.140149
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import io
    from ..compat import compat_str
    from ..utils import DateRange
    from .common import FileDownloader
    pp = MetadataFromTitlePP(
        FileDownloader(
            params={'logger':lambda *args, **kwargs: None,
                    'progress_hooks':[]}),
        '%(title)s - %(artist)s')
    info = {}
    info['title'] = 'My video title'
    pp.run(info)
    assert info == {'artist': 'NA', 'title': 'My video title'}

    info = {}
    info['title'] = 'My video title - My video artist'
    pp.run(info)
    assert info == {'artist': 'My video artist', 'title': 'My video title'}


# Generated at 2022-06-12 19:19:17.549148
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import copy
    from .__main__ import YoutubeDL
    info = {'title': 'Emmaljunga IV 2011-04-21 - Emmaljunga City Cross - EasyWalker Mosey'}
    ydl = YoutubeDL()
    ydl.add_post_processor(
        MetadataFromTitlePP(ydl, '%(title)s - %(brand)s - %(product)s'))
    pp_info, info_out = ydl.post_processors[0].run(info)
    assert pp_info == []
    assert info_out == {
        'title': info['title'],
        'brand': 'Emmaljunga',
        'product': 'EasyWalker Mosey',
    }
    info_orig = copy.deepcopy(info)
    ydl = YoutubeDL()