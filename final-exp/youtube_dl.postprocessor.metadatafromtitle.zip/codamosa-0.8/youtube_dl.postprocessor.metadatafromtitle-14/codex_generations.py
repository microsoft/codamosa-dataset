

# Generated at 2022-06-12 19:10:05.845944
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Set up
    from ydl.YoutubeDL import YoutubeDL
    downloader = YoutubeDL()
    downloader.to_screen = lambda x: None  # Make the output of to_screen go to nowhere

    pp = MetadataFromTitlePP(downloader, '%(artist)s - %(track)s [%(year)s]')
    info = {'title': 'Big Data - The Business of Emotion [2014]'}

    # Verify
    expected_info = {'title': 'Big Data - The Business of Emotion [2014]',
                     'artist': 'Big Data',
                     'track': 'The Business of Emotion',
                     'year': '2014'}
    actual_info = info
    pp.run(actual_info)
    assert expected_info == actual_info


# Generated at 2022-06-12 19:10:11.625133
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    titleformat = '%(artist)s - %(title)s.%(ext)s'
    pp = MetadataFromTitlePP(None, titleformat)
    title = 'Artist - Title.ext'
    info = { 'title': title }
    errs = pp.run(info)
    assert len(errs) == 0
    assert info['title'] == 'Artist - Title.ext'
    assert info['artist'] == 'Artist'
    assert info['ext'] == 'ext'



# Generated at 2022-06-12 19:10:15.676527
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    metadata_pp = MetadataFromTitlePP(None, "%(title)s - %(artist)s")
    regex = metadata_pp.format_to_regex("%(title)s - %(artist)s")
    assert regex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-12 19:10:23.468631
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    obj = MetadataFromTitlePP(None, None)
    assert obj.format_to_regex(
        '%(title)s - %(artist)s') == \
        r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert obj.format_to_regex(
        '%(asdf)s - %(qwerty)s - %(zxcv)s') == \
        r'(?P<asdf>.+)\ \-\ (?P<qwerty>.+)\ \-\ (?P<zxcv>.+)'

# Generated at 2022-06-12 19:10:31.933932
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    info = {
            'id': 'AyIj8Z_34zs',
            'title': 'A - artist feat. B (C)',
            'duration': None,
            'uploader': 'D',
            'upload_date': '20160101'
            }
    titleformat = '%(artist)s - %(title)s [%(id)s by %(uploader)s](%(upload_date)s)'
    pp = MetadataFromTitlePP(None, titleformat)
    pp.run(info)
    assert info['title'] == 'A - artist feat. B (C) [AyIj8Z_34zs by D](20160101)'
    assert info['artist'] == 'artist feat. B'
    assert info['id'] == 'AyIj8Z_34zs'
   

# Generated at 2022-06-12 19:10:41.990871
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # MetadataFromTitlePP.run was not able to extract the metadata from the title
    from_title_pp = MetadataFromTitlePP('dummy', '%(title)s - %(artist)s')
    infodict = {'title': 'TestTitle - TestArtist'}
    assert from_title_pp.run(infodict) == ([], {
        'title': 'TestTitle',
        'artist': 'TestArtist',
    })
    infodict = {'title': 'TestTitle - TestArtist', 'artist': 'SomeOtherArtist'}
    assert from_title_pp.run(infodict) == ([], {
        'title': 'TestTitle',
        'artist': 'TestArtist',
    })
    # There is no match in the title
    infodict = {'title': 'WrongFormat'}

# Generated at 2022-06-12 19:10:49.312384
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class FakeDownloader:
        def to_screen(self, message):
            pass
    class FakeInfoDict():
        def __init__(self, title):
            self.title = title

# Generated at 2022-06-12 19:10:56.617756
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    from ytdl.YoutubeDL import YoutubeDL
    from ytdl.PostProcessor import PostProcessor

    class TestMetadataFromTitlePP(MetadataFromTitlePP):
        def __init__(self, *args, **kwargs):
            PostProcessor.__init__(self, *args, **kwargs)

    class TestYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            YoutubeDL.__init__(self, *args, **kwargs)

        def to_screen(self, *args, **kwargs):
            pass

    class TestInfoExtractor(object):
        def __init__(self, titles, durations):
            self._titles = titles
            self._durations = durations
            self._count = 0


# Generated at 2022-06-12 19:11:01.786497
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .compat import compat_str
    # 1. Test for titleformat like %(title)s - %(artist)s
    titleformat = '%(title)s - %(artist)s'
    postprocessor = MetadataFromTitlePP(FileDownloader({}), titleformat)
    title = 'this is a test title - test artist'
    info = {'title': title}
    exp_info = {'title': 'this is a test title', 'artist': 'test artist'}
    res = postprocessor.run(info)
    assert len(res) == 2
    assert len(res[1]) == len(exp_info)
    assert info == exp_info
    # 2. Test for titleformat like '%(title)s - %(artist)s - %(year)s


# Generated at 2022-06-12 19:11:08.874739
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # only test the cases that are not covered by the fixtures
    from ytdl_extractors.ytdl.extractor import MetadataFromTitlePP
    mft = MetadataFromTitlePP('', '')

    assert mft.format_to_regex('%%a') == '%a'
    assert mft.format_to_regex('%%') == '%'
    assert mft.format_to_regex('%%(a)s') == '%(a)s'
    assert mft.format_to_regex('%A') == '%A'

    assert mft.format_to_regex('%(a)s') == '(?P<a>.+)'

# Generated at 2022-06-12 19:11:20.590661
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # test with simple format
    tftp = MetadataFromTitlePP(None, '%(title)s')
    info1 = {'title': 'title1'}
    info2 = {'title': 'title2 - title3'}

    info1, _ = tftp.run(info1)
    assert(info1['title'] == 'title1')

    info2, _ = tftp.run(info2)
    assert(info2['title'] == 'title2 - title3')

    # test with complex format
    tftp = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(album)s')
    info1 = {'title': 'title1 - artist1 - album1'}

# Generated at 2022-06-12 19:11:30.892946
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Definition of test data
    input_title = 'C for Dummies'
    input_title_format = '%(title)s'
    expected_output_metadata = {'title': 'C for Dummies'}

    # Creation of a downloader
    downloader = object()

    # Creation of the object to be tested
    metadata_from_title_pp = MetadataFromTitlePP(downloader, input_title_format)

    # Test
    output_metadata = {'title': input_title}
    metadata_from_title_pp.run(output_metadata)

    # Make sure that input and output are equal
    assert output_metadata == expected_output_metadata

# Generated at 2022-06-12 19:11:35.388581
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    d = {'title': 'abc', 'ext': 'mp4'}
    t = MetadataFromTitlePP(None, '%(title)s.%(ext)s')
    assert t.run(d) == ([], {'title': 'abc', 'ext': 'mp4', 'title_id': 'abc'})

# Generated at 2022-06-12 19:11:44.271122
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys

    # Just to have a dummy downloader

# Generated at 2022-06-12 19:11:53.445140
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    downloader = object()
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    assert pp.format_to_regex('%(title)s - %(artist)s') == (
        r'(?P<title>.+)\ \-\ (?P<artist>.+)')
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    result, info = pp.run({'title': 'test title - test artist'})
    assert result == []
    assert 'title' in info
    assert info['title'] == 'test title'
    assert 'artist' in info
    assert info['artist'] == 'test artist'



# Generated at 2022-06-12 19:12:00.301423
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl

# Generated at 2022-06-12 19:12:09.824497
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ydl.postprocessor.run import RunPostProcessor
    from ydl.downloader.YdlUrlRequest import YdlUrlRequest
    from ydl.YdlLogger import getLogger

    downloader = YdlUrlRequest(YdlUrlRequest.create_std_opts(), getLogger())
    downloader.add_post_processor(RunPostProcessor(downloader,
                                                   {'exe': 'echo'}))
    metadata_pp = MetadataFromTitlePP(downloader,
                                      '%(title)s [%(resolution)s]')

    # test format_to_regex
    assert metadata_pp.format_to_regex('%(title)s') == r'(?P<title>.+)'

    # test run

# Generated at 2022-06-12 19:12:18.313789
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl
    # Test %(title)s
    test_titleformat = '%(title)s'
    test_title_in = 'Armin van Buuren - A State Of Trance 741 (27.08.2015)'
    test_title_out = 'Armin van Buuren - A State Of Trance 741 (27.08.2015)'
    test_md_in = {'id': '123', 'title': test_title_in}
    test_md_out = {'id': '123', 'title': test_title_out}
    pp = MetadataFromTitlePP(youtube_dl.YoutubeDL(), test_titleformat)
    assert pp.run(test_md_in)[1] == test_md_out
    # Test %(id)s
    test_titleformat = '%(id)s'

# Generated at 2022-06-12 19:12:25.586034
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    mf = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert mf.run({'title': 'My title - My artist'}) == ([], {'title': 'My title', 'artist': 'My artist'})
    mf = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert mf.run({'title': 'My title - My artist - My video'}) == ([], {'title': 'My title', 'artist': 'My artist'})
    mf = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert mf.run({'title': 'My title - My artist - My video - Stupid'}) == ([], {'title': 'My title', 'artist': 'My artist'})

# Generated at 2022-06-12 19:12:34.935769
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.downloader.http import HttpFD

    fd = HttpFD(None, 'title=TGIF: This Week in Open Source with VMware’s "Photon"', {})
    ydl = FakeYDL()
    pp = MetadataFromTitlePP(ydl, ydl.params['titleformat'])
    pp.run(fd.info)
    assert fd.info == {
        'title': 'TGIF: This Week in Open Source with VMware’s "Photon"',
        'artist': 'This Week in Open Source',
        'album': 'TGIF',
        'album_artist': 'VMware'
    }


# Generated at 2022-06-12 19:12:43.352459
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # create dummy YoutubeDL object
    ydl = YoutubeDL({})

    # test with normal titleformat
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    fmt_test = 'Test song - Test singer'
    info_test = {
        'title': fmt_test,
        'extractor': 'Unknown'
    }
    res, info = pp.run(info_test)
    assert res == []
    assert info['title'] == fmt_test
    assert info['artist'] == 'Test singer'

    # test that it works if titleformat is actually just a part of the title

# Generated at 2022-06-12 19:12:54.749491
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    Test MetadataFromTitlePP.run with example strings.
    """
    import sys
    import unittest
    class MyDownloader(object):
        def to_screen(self, msg):
            print(msg)

    class TestMetadataFromTitlePP(unittest.TestCase):
        def test_format_to_regex(self):
            self.assertEqual(
                MetadataFromTitlePP(MyDownloader(), '').format_to_regex(''),
                '')
            self.assertEqual(
                MetadataFromTitlePP(MyDownloader(), 'fmt').format_to_regex('fmt'),
                'fmt')
            self.assertEqual(
                MetadataFromTitlePP(MyDownloader(), 'format').format_to_regex('.*'),
                '.*')

# Generated at 2022-06-12 19:13:01.320980
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Arrange
    import youtube_dl.YoutubeDL
    d = youtube_dl.YoutubeDL({})
    d.to_screen = lambda x: x
    p = MetadataFromTitlePP(d, '%(id)s')
    # Act
    info = {}
    info['title'] = 'this is the video title'
    result, info_result = p.run(info)
    # Assert
    assert info_result['id'] == 'this'
    assert result == []



# Generated at 2022-06-12 19:13:12.550843
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    downloader = YoutubeDL()

    def test(format, title, expected_metadata={}):
        pp = MetadataFromTitlePP(downloader, format)
        metadata = {'title': title}
        _, metadata = pp.run(metadata)
        for name, value in expected_metadata.items():
            assert value == metadata[name]

    test(
        '%(title)s',
        'test_title',
        {'title': 'test_title'})

    test(
        '%(title)s - %(artist)s',
        'test_title - test_artist',
        {'title': 'test_title', 'artist': 'test_artist'})


# Generated at 2022-06-12 19:13:22.996691
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    print("MetadataFromTitlePP.run")
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    if pp.run({'title': 'Video title - artist'})[1] != {'title': 'Video title', 'artist': 'artist'}:
        raise Exception("Expected {'title': 'Video title', 'artist': 'artist'}")

    try:
        pp.run({'title': 'Video title - artist'})
    except:
        raise Exception("Expected no error")

    pp = MetadataFromTitlePP(None, '%(title)s')
    if pp.run({'title': 'Video title'})[1] != {'title': 'Video title'}:
        raise Exception("Expected {'title': 'Video title'}")

# Generated at 2022-06-12 19:13:29.204831
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl.downloader import YoutubeDL
    ydl = YoutubeDL()

    ydl.add_default_info_extractors()
    ydl.add_info_extractor(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s'))

    results = ydl.extract_info(
        'http://example.com/video.html',
        download=False)

    assert results['title'] == 'a - a'
    assert results['artist'] == 'b - b'

# Generated at 2022-06-12 19:13:40.713180
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DEFAULT_OUTTMPL

    def run_fromtitle_test(titleformat, title, expected_info=None):
        downloader = FileDownloader({})

        # the following method will be mocked and the real method will not be called
        downloader.to_screen = lambda msg: True

        ydl = MetadataFromTitlePP(downloader, titleformat)
        info = {'id': 'test123', 'title': title}
        expected_info = expected_info if expected_info is not None else {}
        expected_info.update({'id': 'test123', 'title': title})
        ydl.run(info)
        assert expected_info == info

    # without regex

# Generated at 2022-06-12 19:13:52.158162
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-12 19:14:03.536732
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
   import os
   import youtube_dl
   import json
   test_data_path = os.path.join(os.path.dirname(__file__), 'test_data', 'title_metadatapp')
   with open(u'%s/title_metadatapp.json' % test_data_path, u'rb') as f:
        data = json.load(f)

   for title_key, title_config in data.items():
       for idx, sample in enumerate(title_config['samples']):
           downloader = youtube_dl.YoutubeDL(os.devnull)
           pp = MetadataFromTitlePP(downloader, title_key)
           info = {'title': sample['title']}
           pp.run(info)
           assert info == sample['info']

# Generated at 2022-06-12 19:14:14.701868
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import json

    import youtube_dl
    import youtube_dl.extractor
    import youtube_dl.postprocessor

    test_data = json.load(open('test_data/metadata_from_title.json'))

# Generated at 2022-06-12 19:14:27.833911
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # verify that MetadataFromTitlePP extracts attributes correctly
    class FakeInfo:
        def __init__(self, **kwargs):
            self.__dict__ = kwargs
    class FakeDl:
        def __init__(self):
            self.to_screen_list = []
        def to_screen(self, msg):
            self.to_screen_list.append(msg)

    info = FakeInfo(title='Video Title - Artist')
    dl = FakeDl()
    pp = MetadataFromTitlePP(dl, '%(title)s - %(artist)s')
    assert pp.run(info) == ([], {'title': 'Video Title', 'artist': 'Artist'})

# Generated at 2022-06-12 19:14:33.749154
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    post_processor = MetadataFromTitlePP(YoutubeDL(), '%(artist)s - %(title)s')
    info = {'title': 'The Artist - The Title'}
    should = {'title': 'The Artist - The Title', 'artist': 'The Artist'}
    post_processor.run(info)
    assert info == should

# Generated at 2022-06-12 19:14:40.851104
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from unittest import mock

    class MockYDL(object):
        def to_screen(self, msg):
            print(msg)

        def to_stderr(self, msg):
            print(msg)

    mock_ydl = MockYDL()

    pp = MetadataFromTitlePP(mock_ydl, '%(title)s')
    info = {'title': 'Title'}
    pp.run(info)
    assert info['title'] == 'Title'

    pp = MetadataFromTitlePP(mock_ydl, '%(artist)s - %(title)s')
    info = {'title': 'Artist - Title'}
    pp.run(info)
    assert info['title'] == 'Title'
    assert info['artist'] == 'Artist'

    pp = MetadataFromTitlePP

# Generated at 2022-06-12 19:14:51.239734
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Importing here because it would make importing file metadata_from_title.py
    # fail
    from .common import FileDownloader
    test_downloader = FileDownloader({}, False, '', '', None, None)
    metadataFromTitlePP = MetadataFromTitlePP(test_downloader, '%(artist)s')
    # Test success
    result = metadataFromTitlePP.run({'title': 'Test artist'})
    assert(result == ([], {'title': 'Test artist', 'artist': 'Test artist'}))
    # Test failure
    result = metadataFromTitlePP.run({'title': 'Test title'})
    assert(result == ([], {'title': 'Test title'}))


# Generated at 2022-06-12 19:15:02.020450
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .YoutubeDL import YoutubeDL
    from .extractor.youtube import YoutubeIE
    from .compat import compat_urllib_request
    from json import loads
    from urllib.error import HTTPError
    from io import BytesIO

    def get_ytdl():
        class MockYoutubedl(YoutubeDL):
            def __init__(self, ydl):
                self.to_screen_called = []
                self.ydl = ydl
                self.params = {}
                self.cache = {}

            def to_screen(self, *args):
                self.to_screen_called.append(args)

        return MockYoutubedl(YoutubeDL(params={'verbose': True}))

    # test title with no information in it
    downloader = get_ytdl()


# Generated at 2022-06-12 19:15:09.404651
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.utils import DateRange
    from youtube_dl.YoutubeDL import YoutubeDL
    downloader = YoutubeDL({})
    downloader.add_default_info_extractors()
    titleformat = '%(title)s - %(artist)s - %(date)s'
    pp = MetadataFromTitlePP(downloader, titleformat)
    info = {
        'title': 'title - artist - 2012',
        'date': DateRange(None, '2012'),
    }
    info_out = info.copy()
    del info_out['date']
    info_out['artist'] = 'artist'
    assert pp.format_to_regex(titleformat) == (
        'title\\ \\-\\ artist\\ \\-\\ (?P<date>.+)')
    assert pp.run([], info)

# Generated at 2022-06-12 19:15:19.297823
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    ftt = MetadataFromTitlePP('', '')
    
    # convert %(..)s to regex group
    assert ftt.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert ftt.format_to_regex('%(artist)s (- %(title)s)%(codec)s') == r'(?P<artist>.+)\ \(-\ (?P<title>.+)\)(?P<codec>.+)'
    
    # split a string according to the pattern
    expected_regex = re.compile(r'(?P<artist>.+)\ \(-\ (?P<title>.+)\)(?P<codec>.+)')
    
    info = {}
    info['title'] = 'My favorite artist (my song)'
    _

# Generated at 2022-06-12 19:15:30.905548
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .extractor import YoutubeIE
    info = {
        'title': 'Les Paul Trio - Blues Stay Away From Me - 4/17/1949',
        'extractor': 'YoutubeIE',
        'url': 'https://www.youtube.com/watch?v=gxf_8FkfV7k',
        'extractor_key': YoutubeIE.ie_key(),
        'webpage_url': 'http://www.youtube.com/watch?v=gxf_8FkfV7k',
    }
    mp = MetadataFromTitlePP(None, '%(artist)s - %(title)s - %(date)s')

# Generated at 2022-06-12 19:15:39.947123
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .Downloader import Downloader
    from .FileDownloader import FileDownloader
    from .common import FileDownloader as CommonFileDownloader

    input_info = {
        'title': 'Actual Title'
    }
    expected_output_info = input_info.copy()
    expected_output_info['attribute'] = 'Parsed Title'

    downloader = Downloader(params={})
    file_downloader = FileDownloader(downloader, 'http://test.com', {})
    pp = MetadataFromTitlePP(file_downloader, '%(attribute)s')

    assert pp.run(input_info) == ([], expected_output_info)


# Generated at 2022-06-12 19:15:46.315335
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    tformat = '%(title)s-%(artist)s'
    utitle = 'The title - The artist'


    class FakeInfoDict():
        pass

    info = FakeInfoDict()
    info.title = utitle
    info.artist = None
    info2 = info

    metadatapp = MetadataFromTitlePP(None, tformat)
    metadatapp.run(info)
    assert info.artist == 'The artist'

    tformat2 = '%(artist)s-%(title)s'
    utitle = 'The artist - The title'

    info2.title = utitle
    metadatapp = MetadataFromTitlePP(None, tformat2)
    metadatapp.run(info2)
    assert info2.artist == 'The artist'

# Generated at 2022-06-12 19:16:02.884142
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import ydl_info

    info = ydl_info.YDLInfo({
        'title': 'Video - Artist - Album',
        'ext': 'flv',
    })

    # Missing video information
    missing_video_info = MetadataFromTitlePP(None, '%(title)s').run(info)[1]
    assert 'canvas_id' not in missing_video_info
    assert 'artist' not in missing_video_info

    # Missing artist information
    missing_artist_info = MetadataFromTitlePP(None, '%(title)s - %(artist)s').run(info)[1]
    assert missing_artist_info['artist'] == 'Artist'
    assert 'canvas_id' not in missing_artist_info

    # Missing canvas_id information
    missing_canvas_id_info = Met

# Generated at 2022-06-12 19:16:12.811194
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from io import StringIO
    import sys
    import unittest
    from youtube_dl.YoutubeDL import YoutubeDL
    dl = YoutubeDL({})
    sys.stdout = StringIO()  # keep output from being displayed

    # Test with a regex with a group match
    titleformat = '%(artist)s - %(title)s'
    titleregex = '(?P<artist>.+)\ \-\ (?P<title>.+)'
    titletoinfo = 'Metallica - Master Of Puppets'
    info = { 'title': titletoinfo }
    pp = MetadataFromTitlePP(dl, titleformat)
    # pp.run should return a tuple of two dictionaries
    result = pp.run(info)
    assert result[1]['title'] == titletoinfo

# Generated at 2022-06-12 19:16:25.299925
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp.format_to_regex('%(artist)s - %(title)s') \
        == r'(?P<artist>.+)\ \-\ (?P<title>.+)'


# Generated at 2022-06-12 19:16:32.511973
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    downloader = None
    titleformat = '%(artist)s - %(title)s'
    test_pp = MetadataFromTitlePP(downloader, titleformat)
    info = dict(title = 'Alesso - Heroes (we could be) ft. Tove Lo')
    video_info, info = test_pp.run(info)
    assert info['title'] == 'Heroes (we could be) ft. Tove Lo'
    assert info['artist'] == 'Alesso'

    titleformat = '%(artist)s - %(album)s - %(title)s'
    test_pp = MetadataFromTitlePP(downloader, titleformat)
    info = dict(title = 'Alesso - Forever - Heroes (we could be) ft. Tove Lo')
    video_info, info = test_pp.run

# Generated at 2022-06-12 19:16:41.550904
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.utils import DateRange
    from youtube_dl.YoutubeDL import YoutubeDL

    DummyYDL = type('DummyYDL', (YoutubeDL, object), {
        'params': {'writethumbnail': True},
        '_screen_file': None,
    })

    # Unparsable format
    dl = DummyYDL()
    dl._screen_file = open(b'/dev/null', 'w')
    info = {'title': 'foo'}
    pp = MetadataFromTitlePP(dl, 'foo%(title)sbar')
    pp.run(info)
    assert info == {'title': 'foo'}

    # Unmatching format
    dl = DummyYDL()

# Generated at 2022-06-12 19:16:52.961398
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # test with regex
    test_value = '%(title)s - %(artist)s'
    regex = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    expected_info = {'title': 'test_title', 'artist': 'test_artist', 'id': 'test_id'}
    info = {'title': 'test_title - test_artist', 'id': 'test_id'}
    test_object = MetadataFromTitlePP(None, test_value)
    result = test_object.format_to_regex(test_value)
    assert result == regex
    result, result_dict = test_object.run(info)
    assert result == []
    assert result_dict == expected_info
    # test without regex
    test_value = '%(title)s'

# Generated at 2022-06-12 19:17:00.612657
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ..extractor.common import InfoExtractor
    import youtube_dl
    info = {
        'title': 'The Foo - The Bar'
    }
    ex = InfoExtractor(None)
    ex.monostate = True
    ex.add_info_extractor(MetadataFromTitlePP(ex, '%(title)s').run(info))

    out = ex.process_ie_result(info, [])
    assert(out[1]['title'] == 'The Foo')
    assert(out[1]['artist'] == 'The Bar')

# Generated at 2022-06-12 19:17:07.834725
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    Test method run of class MetadataFromTitlePP.
    """
    import sys, os, unittest
    from .downloader import Downloader
    from .postprocessor import PostProcessor
    from .compat import compat_urllib_parse_unquote_plus

    # Mocking Downloader class
    class MockDownloader(Downloader):
        def __init__(self):
            pass
        def to_screen(self, *args, **kargs):
            pass
    class MockPostProcessor(PostProcessor):
        def __init__(self, downloader):
            pass
        def run(self, information):
            pass
    # Mocking the global variable __pyfile__
    __pyfile__ = os.path.abspath(__file__)
    metadata_from_title_pp = MetadataFromTitle

# Generated at 2022-06-12 19:17:18.554432
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor import YoutubeIE
    class FakeInfo:
        def __init__(self, info_dict):
            self.__dict__.update(info_dict)
    downloader = FileDownloader({'format': 'best'})

# Generated at 2022-06-12 19:17:27.275991
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test creating dict from title with default format
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    info = {}
    info['title'] = 'Some Artist - Some Title'
    pp.run(info)
    assert info['artist'] == 'Some Artist'
    assert info['title'] == 'Some Title'

    # Test creating dict from title with custom format
    pp = MetadataFromTitlePP(None, '%(track)s %(title)s')
    info = {}
    info['title'] = '01 Some Title'
    pp.run(info)
    assert info['track'] == '01'
    assert info['title'] == 'Some Title'

    # Test that dict is not created from title with unknown format

# Generated at 2022-06-12 19:17:56.513681
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class downloader_mock:
        def to_screen(self, message):
            return
    downloader_mock = downloader_mock()

    # Use as usual
    info = {'title': 'Some title'}
    processor = MetadataFromTitlePP(downloader_mock, 'Some title')
    processor.run(info)

    # Use with regexp
    info = {'title': 'Some artist - Some title'}
    processor = MetadataFromTitlePP(downloader_mock, '%(artist)s - %(title)s')
    processor.run(info)

    # Use with regexp that doesn't match
    info = {'title': 'Some title'}
    processor = MetadataFromTitlePP(downloader_mock, '%(artist)s - %(title)s')
    processor

# Generated at 2022-06-12 19:18:04.935880
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import YoutubeDL
    from .extractor import gen_extractors

    def _do_run(format, title, expected_result):
        msg = '[fromtitle] could not parse title "%s" with pattern "%s"' % (title, format)

        ydl = YoutubeDL({})

        ydl.add_default_info_extractors()
        ydl.add_info_extractor(
            gen_extractors(ydl, ['youtube:generic'])[0])

        pp = MetadataFromTitlePP(ydl, format)

        result = []
        pp.run({'title': title}, result)
        assert result == expected_result, msg

    # Test different formats
    _do_run(
        '%(title)s',
        'Foo',
        ['title: Foo']
    )



# Generated at 2022-06-12 19:18:11.914173
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Arrange
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.http import HttpFD
    downloader = YoutubeDL({})
    downloader.to_screen = lambda x: None
    info = {
        'title': 'Foo Bar - Baz',
    }
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    # Act
    res, info = pp.run(info)
    # Assert
    assert res == []
    assert info['title'] == 'Foo Bar'
    assert info['artist'] == 'Baz'


# Generated at 2022-06-12 19:18:18.522256
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    downloader = FileDownloader({})
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    info = {'title': 'Hotel California - Eagles', 'url': 'xxx'}
    pp.run(info)
    assert info == {
        'title': 'Hotel California',
        'artist': 'Eagles',
        'url': 'xxx',
    }



# Generated at 2022-06-12 19:18:26.655878
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest
    import sys

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.pp = MetadataFromTitlePP(None, '%(artist)s-%(title)s')

        def test_cases(self):
            title = 'Cher-Believe'
            result = [], {'title': title, 'artist': 'Cher', 'title': 'Believe'}
            self.assertEquals(self.pp.run({'title': title}), result)

    # Run the tests
    suite = unittest.TestLoader().loadTestsFromTestCase(TestMetadataFromTitlePP)
    unittest.TextTestRunner(verbosity=2, stream=sys.stdout).run(suite)



# Generated at 2022-06-12 19:18:35.386631
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # test valid title formats
    def test_run_title(titleformat):
        info = {'title': 'title - author'}
        pp = MetadataFromTitlePP(None, titleformat)
        pp.run(info)
        assert info['title'] == 'title'
        assert info['author'] == 'author'


# Generated at 2022-06-12 19:18:45.028403
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            import youtube_dl.YoutubeDL
            from youtube_dl.utils import DateRange
            from youtube_dl.utils import DateRange
            from youtube_dl.utils import DateRange
            from youtube_dl.utils import DateRange

# Generated at 2022-06-12 19:18:55.371381
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.downloader import FileDownloader
    from youtube_dl.YoutubeDL import YoutubeDL
    from os import path


# Generated at 2022-06-12 19:19:05.992487
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import tempfile
    import os
    import json
    import argparse
    from ytdl.YoutubeDL import YoutubeDL
    from ytdl.PostProcessor import PostProcessor

    old_argv = sys.argv
    sys.argv = ['ytdl',
                '-v',
                '--metadata-from-title', '%(artist)s - %(album)s - %(track)s',
                'https://www.youtube.com/watch?v=e4BNvq3yXIY']
    def _config_youtube_dl(params):
        return lambda: params
    with tempfile.NamedTemporaryFile('w', delete=False) as f:
        sys.argv[-1] = f.name

# Generated at 2022-06-12 19:19:15.628868
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    Tests MetadataFromTitlePP.run()
    """
    # test case #1
    title_format = '%(title)s - %(artist)s'
    title = "I Wanna Be Like You - Louis Prima"
    assert (MetadataFromTitlePP(None, title_format).format_to_regex(title_format) ==
            '(?P<title>.+)\ \-\ (?P<artist>.+)')
    assert (MetadataFromTitlePP(None, title_format).run(
        {'title': title})[1] == {'title': "I Wanna Be Like You", 'artist': 'Louis Prima'})

    # test case #2
    title_format = '%(title)s - %(artist)s'
    title = "I Wanna Be Like You"