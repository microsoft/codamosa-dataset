

# Generated at 2022-06-12 19:10:06.026180
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import pytest
    from youtube_dl.compat import compat_str
    from youtube_dl.downloader.postprocessor.common import PostProcessor
    from youtube_dl.downloader.compat import compat_urllib_error

    class TestDownloader(object):
        def __init__(self):
            self.to_screen_messages = []

        def to_screen(self, message):
            self.to_screen_messages.append(message)

        def report_error(self, message, tb=None, description=None):
            self.to_screen_messages.append(message)
            if tb is not None:
                self.to_screen_messages.append(tb)
            if description is not None:
                self.to_screen_messages.append(description)


# Generated at 2022-06-12 19:10:14.750618
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import PostProcessor
    mft = PostProcessor(None)
    assert mft.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert mft.format_to_regex('%(title)s - %(artist)s - %(year)d') == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<year>\d+)'

# Generated at 2022-06-12 19:10:20.134181
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Arrange
    downloader = object()
    titleformat = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(downloader, titleformat)
    info = {'title': 'Test title - Test artist'}
    expected = [], {'title': 'Test title - Test artist', 'artist': 'Test artist'}

    # Act
    actual = pp.run(info)

    # Assert
    assert actual == expected


# Generated at 2022-06-12 19:10:26.069086
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl.YoutubeDL import YoutubeDL
    ydl_opts = {'logger': YoutubeDL()._opts.logger}
    pp = MetadataFromTitlePP(None, '%(artist)s - %(track)s - %(title)s')
    assert pp.run({'title': 'Pink Floyd - Comfortably Numb - Live In Pompeii 2016'}) == ([], {
           'artist': 'Pink Floyd', 'track': 'Comfortably Numb',
           'title': 'Pink Floyd - Comfortably Numb - Live In Pompeii 2016'})
    pp = MetadataFromTitlePP(None, '%(title)s: %(artist)s')
    # Test with and without regular expression

# Generated at 2022-06-12 19:10:37.547791
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class downloader:
        def __init__(self):
            self.to_screen = lambda x: None
    class info:
        title = None

    title = 'artist "title" (feat. artist2) [genre]'
    titleformat = '%(artist)s "title" (feat. %(artist2)s) [%(genre)s]'
    metadata = MetadataFromTitlePP(downloader, titleformat).run(info())[1]
    assert metadata['artist'] == 'artist' and metadata['title'] == 'title' and metadata['artist2'] == 'artist2' and metadata['genre'] == 'genre'

    title = 'artist - title'
    titleformat = '%(artist)s - %(title)s'
    metadata = MetadataFromTitlePP(downloader, titleformat).run(info())[1]


# Generated at 2022-06-12 19:10:45.147276
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert r'(?P<title>.+)\ \-\ (?P<artist>.+)' \
             == MetadataFromTitlePP(None, '%(title)s - %(artist)s') \
                   ._titleregex
    assert r'(?P<artist>.+)' \
             == MetadataFromTitlePP(None, '%(artist)s') \
                   ._titleregex
    assert r'(?P<artist>.+)\ \-\ (?P<title>.+)' \
             == MetadataFromTitlePP(None, '%(artist)s - %(title)s') \
                   ._titleregex

# Generated at 2022-06-12 19:10:54.988217
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .test import get_test_downloader
    from .test import match_regex_or_die
    test_downloader = get_test_downloader()
    test_video_info = {'title': 'Unit test video'}
    test_metadata_from_title_pp = MetadataFromTitlePP(test_downloader, '%(title)s')
    (metadata, new_video_info) = test_metadata_from_title_pp.run(test_video_info)
    # After run method of MetadataFromTitlePP,
    # metadata should be empty list and the title of input video info should be copied to new video info
    assert(metadata == [])
    assert(new_video_info['title'] == 'Unit test video')
    # Test with a regex to parse video title
    test_metadata_from_title_

# Generated at 2022-06-12 19:11:03.663927
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Create a fake downloader instance
    class FakeYDL():
        def to_screen(self, msg):
            print(msg)
    fake_ydl = FakeYDL()
    pp = MetadataFromTitlePP(fake_ydl, "%(title)s - %(artist)s")
    res, info = pp.run({'id': 'fake_id', 'title': 'Fake Title - Fake Artist'})
    assert info['id'] == 'fake_id'
    assert 'title' in info
    assert info['title'] == 'Fake Title'
    assert 'artist' in info
    assert info['artist'] == 'Fake Artist'



# Generated at 2022-06-12 19:11:12.538591
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-12 19:11:17.100929
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_titlepp = MetadataFromTitlePP(None, "%(title)s - %(artist)s")
    metadata = {}
    metadata_from_titlepp.run(metadata)
    assert metadata["title"] == "", "title is not empty"
    assert metadata["artist"] == "", "artist is not empty"

# Generated at 2022-06-12 19:11:21.933632
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_instance = MetadataFromTitlePP(None, '%(artist)s-%(title)s')
    test_info = {}
    # assert run returns a tuple (video data, video metadata)
    assert(type(test_instance.run(test_info)) is tuple)



# Generated at 2022-06-12 19:11:27.420571
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor

    downloader = YoutubeDL({
        'outtmpl': '[%(title)s]',
        'writedescription': True,
        'writeinfojson': True
    })
    downloader.add_info_extractor(InfoExtractor(downloader=downloader))

    # download with no %(...)s in the titleformat:
    for titleformat in ['%(title)s', '%(title)s - %(uploader)s']:
        pp = MetadataFromTitlePP(downloader, titleformat)

        # video with title "hello world"

# Generated at 2022-06-12 19:11:33.381561
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    class Info(object):

        def __init__(self, title):
            self.title = title
            self.artist = None
            self.track = None
            self.album = None

    info = Info('Radiohead - Paranoid Android')
    titleformat = '%(artist)s - %(track)s'
    fromtitlepp = MetadataFromTitlePP(None, titleformat)
    fromtitlepp.run(info)
    assert info.artist == 'Radiohead'
    assert info.track == 'Paranoid Android'
    assert info.album is None

    info = Info('John Williams - Jurassic Park Theme')
    titleformat = '%(track)s by %(artist)s on %(album)s'
    fromtitlepp = MetadataFromTitlePP(None, titleformat)
    fromtitlepp.run(info)

# Generated at 2022-06-12 19:11:42.905057
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class TestDownloader:
        def __init__(self):
            self._screen_buffer = ''

        def to_screen(self, msg):
            self._screen_buffer += msg + '\n'

    titleformat = '%(title)s - %(artist)s'
    title = 'test pickle - title -- split here'
    test = MetadataFromTitlePP(TestDownloader(), titleformat)
    info = {'title': title}
    (formats, info) = test.run(info)

    assert info == {
        'title': 'test pickle',
        'artist': 'title -- split here'
    }
    assert test._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-12 19:11:53.685088
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert MetadataFromTitlePP(None, '%(artist)s - %(title)s').run({'title': 'artist - title'})[1] == {'artist': 'artist', 'title': 'title'}
    assert MetadataFromTitlePP(None, '%(artist)s - %(title)s').run({'title': 'artist - title - other'})[1] == {'artist': 'artist', 'title': 'title'}
    assert MetadataFromTitlePP(None, '%(artist)s - %(title)s').run({'title': 'artist - title other'})[1] ==  {'title': 'artist - title other'}
    assert MetadataFromTitlePP(None, 'title foo').run({'title': 'title foo'})[1] == {'title': 'title foo'}
   

# Generated at 2022-06-12 19:12:04.021420
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    MetadataFromTitlePP.run - test case
    """
    class FakeDownloader(object):
        def to_screen(self, msg):
            print(msg)
    class FakeInfo(dict):
        pass

    info = FakeInfo()
    info['title'] = "The.Lord.of.the.Rings.The.Fellowship.of.the.Ring.2001.EXTENDED.720p.BluRay.x264.YIFY"

    pp = MetadataFromTitlePP(FakeDownloader(),
                             "%(title)s.%(ext)s")
    _, info = pp.run(info)
    assert info['title'] == "The.Lord.of.the.Rings.The.Fellowship.of.the.Ring"

# Generated at 2022-06-12 19:12:13.664684
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import os
    import tempfile
    import unittest
    import ydl_utils

    class YDL:
        def to_screen(self, msg):
            print(msg)

    class FakeInfoDict(dict):
        def __init__(self, title='', *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self['title'] = title

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.downloader = YDL()
            self.temp_filename = tempfile.mktemp()

        def tearDown(self):
            os.remove(self.temp_filename)


# Generated at 2022-06-12 19:12:22.004289
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl
    pp = MetadataFromTitlePP(youtube_dl.YoutubeDL(youtube_dl.FileDownloader()), '%(title)s - %(artist)s')
    assert pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert not pp.format_to_regex('%(title)s - %(artist')
    info = {'title': 'Hello - World'}
    res, _ = pp.run(info)
    assert res == []
    assert 'Artist' in info
    assert info['Artist'] == 'World'
    assert 'Title' in info
    assert info['Title'] == 'Hello'

# Generated at 2022-06-12 19:12:26.463757
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    Test to check that MetadataFromTitlePP method run works as expected.
    """
    downloader = object
    titleformat = '%(artist)s - %(title)s'
    metadatafromtitlepp = MetadataFromTitlePP(downloader, titleformat)
    info = {'title': 'Artist - Title'}
    metadatafromtitlepp.run(info)
    assert('title' in info)
    assert(info['title'] == 'Title')
    assert('artist' in info)
    assert(info['artist'] == 'Artist')


# Generated at 2022-06-12 19:12:36.607524
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    Test that the metadata are correctly extracted from the title
    """
    from youtube_dl.downloader import YoutubeDL
    downloader = YoutubeDL()
    postprocessor = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s - %(date)s')

    info = {'title': 'TestTitle - TestArtist - TestDate'}

    # The run method of postprocessor does two things :
    # 1. Update the video metadata
    # 2. Return a list of files
    # The second behavior is not tested here.
    postprocessor.run(info)

    assert info == {
        'title': 'TestTitle',
        'artist': 'TestArtist',
        'date': 'TestDate'
    }, 'Test failed'

# Generated at 2022-06-12 19:12:50.293737
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest.mock as mock
    downloader = mock.Mock()
    pp = MetadataFromTitlePP(downloader, '%(title)s -%(artist)s')
    expected = [('title', 'Video Title'), ('artist', 'Artist Name')]
    info = {'title': 'Video Title -Artist Name'}

    retval = pp.run(info)

    for key, value in expected:
        assert info[key] == value
    assert len(retval) == 2
    assert retval[0] == []
    assert retval[1] == info

    downloader.to_screen.assert_has_calls([
        mock.call('[fromtitle] parsed title: Video Title'),
        mock.call('[fromtitle] parsed artist: Artist Name')
    ])

# Generated at 2022-06-12 19:13:00.817867
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl.downloader

    import os

    current_directory = os.path.dirname(os.path.abspath(__file__))
    config_filename = os.path.join(current_directory, 'terminal_fragment.json')


# Generated at 2022-06-12 19:13:11.903884
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    class TestMetadataFromTitlePP_run(unittest.TestCase):
        def test_run(self):
            # Create a TestMetadataFromTitlePP_run object
            mftpp_run = MetadataFromTitlePP(sys.modules[__name__],
                                            "%(title)s by %(artist)s")
            # test on a video which name should be interpretable
            info = {'title': 'Test of interpretability and reliability by Thomas'}
            (a, b) = mftpp_run.run(info)
            self.assertEqual(b['artist'], 'Thomas')
            self.assertEqual(b['title'], 'Test of interpretability and reliability')
    unittest.main()


# Generated at 2022-06-12 19:13:17.305244
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    dl = type('test_dl', (object,), {'to_screen': lambda x: 0})()
    pp = MetadataFromTitlePP(dl, '%(title)s')
    assert pp.run({'title': 'some title'}) == ([], {'title': 'some title'})
    assert pp.run({'title': 'wrong format'}) == ([], {'title': 'wrong format'})



# Generated at 2022-06-12 19:13:27.491533
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import pytest
    class FakeDownloader():
        def to_screen(self, message):
            print(message)
    mp = MetadataFromTitlePP(FakeDownloader(), '%(title)s [%(extractor_key)s]')
    info = {
        'title': 'some title [youtube]',
        'extractor_key': 'Youtube',
        'test': 'some value'
        }
    results = mp.run(info)
    assert not results[0]  # no error
    assert results[1]['title'] == 'some title'
    assert results[1]['extractor_key'] == 'youtube'
    assert results[1]['test'] == 'some value'
    with pytest.raises(KeyError):
        info['test2']

# Generated at 2022-06-12 19:13:33.626227
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # test string: title
    def get_title():
        return 'Germans React To EDM - Episode 1 - Calvin Harris'

    # expected dict
    expected_results = {
        'title': 'Germans React To EDM - Episode 1 - Calvin Harris',
        'artist': 'Calvin Harris',
        'episode' : '1',
    }

    # test format
    titleformat = '%(title)s - Episode %(episode)s - %(artist)s'

    postprocessor = MetadataFromTitlePP(None, titleformat)

    info = { 'title' : get_title() }
    postprocessor.run(info)
    assert info == expected_results

# Generated at 2022-06-12 19:13:41.915223
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from unittest import TestCase

    class MockYDL(object):
        def to_screen(self, s):
            pass

    class MockInfo(dict):
        pass

    class Test(TestCase):
        def test_run(self):
            info = MockInfo({'title': 'foo - bar'})
            pp = MetadataFromTitlePP(MockYDL(), '%(title)s - %(artist)s')
            res = pp.run(info)
            self.assertEqual(res, ([], {'title': 'foo', 'artist': 'bar'}))

    if not unittest.main(argv=['progname'], exit=False):
        sys.exit(0)

# Generated at 2022-06-12 19:13:50.795867
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Initialize class and test variables
    mp = MetadataFromTitlePP(None, "%(title)s - %(artist)s")
    title_string = "Test Title - Test Artist"
    info = {'title': title_string}

    # Execute test
    pp_results, info_results = mp.run(info)

    # Assert test results
    assert('title' in info_results.keys() and
           'artist' in info_results.keys() and
           len(pp_results) == 0 and
           info_results['title'] == "Test Title" and
           info_results['artist'] == "Test Artist")

# Generated at 2022-06-12 19:13:57.050235
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest
    import sys
    import os

    class MockDict(dict):
        """Mock object.
        """
        def get(self, key, d=None):
            return self[key]

    class MockYoutubeDL(object):
        """Mock object.
        """
        def __init__(self):
            pass

        def to_screen(self, text):
            pass

    class TestPP(unittest.TestCase):
        def setUp(self):
            sys.modules['youtube_dl'] = sys.modules['__main__']
            self.pp = MetadataFromTitlePP(MockYoutubeDL(), '%(uploader)s')

        def tearDown(self):
            del sys.modules['youtube_dl']

        def test_run(self):
            info = MockDict

# Generated at 2022-06-12 19:14:05.892863
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    info = { }  # Dictionary that shall be filled by PostProcessor

    # Title is empty
    postprocessor = MetadataFromTitlePP("", "")
    result_info = postprocessor.run(info)
    assert len(result_info) == 0  # Empty list of errors
    assert result_info == info  # No update of PostProcessor's info dictionary

    # Title is not empty but does not match title format
    info = { 'title' : "Everything is Awesome" }
    postprocessor = MetadataFromTitlePP("", "%(artist)s - %(title)s")
    result_info = postprocessor.run(info)
    assert len(result_info) == 0  # Empty list of errors
    assert result_info == info  # No update of PostProcessor's info dictionary

    # Title is not empty and matches title format
   

# Generated at 2022-06-12 19:14:17.938909
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .downloader import FileDownloader
    from .compat import compat_str
    downloader = FileDownloader({})
    title_text = 'Test Title'
    info = {'title': title_text, 'webpage_url': 'http://example.com',
            'duration': 10}
    pp = MetadataFromTitlePP(downloader, '%(title)s')
    pp_return, info_return = pp.run(info)
    if info_return['title'] != title_text:
        raise ValueError('Method run of class MetadataFromTitlePP failed')
    regex_pattern = '(?P<title>.+)'
    if pp._titleregex != regex_pattern:
        raise ValueError('Method run of class MetadataFromTitlePP failed')
    title_text = 'Test Title - Example Artist'

# Generated at 2022-06-12 19:14:27.390290
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl

    class MyInfoDict(dict):
        IE_NAME = 'ie_name'

        def __init__(self, *args, **kwargs):
            super(MyInfoDict, self).__init__(*args, **kwargs)
            self['title'] = 'title'

    class MyYoutubeDL():
        def __init__(self):
            self.to_screen_messages = []

        def to_screen(self, msg):
            self.to_screen_messages.append(msg)

    myYDL = MyYoutubeDL()
    myInfoDict = MyInfoDict()
    titleFormat1 = '%(title)s - %(artist)s'
    mftpp1 = MetadataFromTitlePP(myYDL, titleFormat1)
    mftpp1.run

# Generated at 2022-06-12 19:14:38.035485
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .downloader import YoutubeDL
    from .compat import compat_str
    from .utils import DateRange

    def _test(titleformat, title, correct_metadata):
        """
        Test with a title and a titleformat, if the resulting
        metadata is the expected one
        """
        # Creating the info dictionary:
        info = {
            'display_id': 's3fmCJEmgLs',
            'extractor_key': 'Youtube',
            'extractor': 'youtube',
            'webpage_url': 'http://www.youtube.com/watch?v=s3fmCJEmgLs',
            'webpage_url_basename': 'watch',
            'id': 's3fmCJEmgLs',
            'title': title
        }

        # Instantiating the PP


# Generated at 2022-06-12 19:14:49.470347
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # In Py2 re.match return None for no match, str in Py3
    assert MetadataFromTitlePP(object, '%(artist)s - %(title)s').run({
            'title': 'Test title'})[1] is None
    assert MetadataFromTitlePP(object, '%(artist)s - %(title)s').run({
            'title': 'Test artist - Test title'})[1] == {
            'artist': 'Test artist',
            'title': 'Test title'
    }
    # Multiple attributes on one line

# Generated at 2022-06-12 19:15:00.545883
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class Downloader:
        def __init__(self):
            self.to_screen_output = []

        def to_screen(self, msg):
            self.to_screen_output.append(msg)

    @classmethod
    def format_to_regex(cls, fmt):
        return cls._titleregex

    video_info = {'title': 'A title - The Artist'}
    downloader = Downloader()
    metadata_pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    metadata_pp.format_to_regex = format_to_regex
    metadata_pp.run(video_info)
    assert video_info == {'title': 'A title', 'artist': 'The Artist'}

# Generated at 2022-06-12 19:15:05.622351
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # pylint: disable=import-error
    from ytdl_core.YtdlHooks import DownloadHook
    # pylint: enable=import-error
    downloader = DownloadHook()
    mftpp = MetadataFromTitlePP(downloader, '%(title)s')
    assert mftpp.run({'title': 'Some title'})[1] == {'title': 'Some title'}


# Generated at 2022-06-12 19:15:13.566948
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL

    class TestYoutubeDL(YoutubeDL):
        """TestYoutubeDL class that does not require internet connection"""

        def __init__(self, ydl):
            super(TestYoutubeDL, self).__init__(ydl._params)
            self.result = []

        def to_screen(self, s):
            self.result.append(s)

    class TestInfoDict(dict):
        """TestInfoDict class that does not require internet connection"""

        pass

    ydl = YoutubeDL({'noplaylist': True})
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s'))
    info = {}
    info['title'] = 'something - something else'

# Generated at 2022-06-12 19:15:21.331599
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ..YoutubeDL import YoutubeDL
    from ..YoutubeDL import FileDownloader
    from ..compat import compat_urlparse
    from xml.etree import ElementTree

    # create a downloader used by the postprocessor to parse the title
    ydl = YoutubeDL()

    # create a fake downloader that does not perform any downloads.
    # it is needed to construct a valid PostProcessor.
    def _fake_get_filename(self, info_dict):
        return info_dict['filepath']

    def _fake_report_warning(self, msg):
        pass

    dl = FileDownloader(ydl, {'outtmpl': '%(id)s'})
    dl.get_filename = _fake_get_filename.__get__(dl)
    dl.report_warning = _fake_report_

# Generated at 2022-06-12 19:15:32.354832
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    titleformat = '%(title)s - %(artist)s'
    regex = r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    # Test if 'titleformat' is parsed to 'regex'
    class MockYDL(object):
        pass
    ydl = MockYDL()
    ydl.to_screen = lambda x: None
    # 'info' is a dict to be filled by run method
    info = {}
    info['title'] = 'title - artist'

    # 'pp' is a MetadataFromTitlePP instance
    pp = MetadataFromTitlePP(ydl, titleformat)

    # Call run
    pp.run(info)
    # Check results
    assert pp._titleregex == regex
    assert info['title'] == 'title'

# Generated at 2022-06-12 19:15:42.536610
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    downloader = _FakeYoutubeDL()


    # empty format
    pp = MetadataFromTitlePP(downloader, '')
    info = {'title': 'title of video'}
    res, info = pp.run(info)
    assert res == []
    assert info == {'title': 'title of video'}

    # format made only of fixed string parts
    pp = MetadataFromTitlePP(downloader, 'title - artist')
    info = {'title': 'title of video - artist'}
    res, info = pp.run(info)
    assert res == []
    assert info == {'title': 'title of video - artist'}

    # format with missing %(title)s
    pp = MetadataFromTitlePP(downloader, 'No title here')

# Generated at 2022-06-12 19:15:59.452353
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import json
    import sys
    import unittest

    class MockDownloader(object):
        def __init__(self):
            self.to_screen_return_value = []

        def to_screen(self, value):
            self.to_screen_return_value.append(value)

    class MockInfo(object):
        def __init__(self, title):
            self.title = title

    class TestMetadataFromTitlePP(unittest.TestCase):
        def test_run(self):
            mock_downloader = MockDownloader()
            mock_info = MockInfo(title='Darth Vader - The Imperial March [1080p]')
            metadata_from_title_pp = MetadataFromTitlePP(mock_downloader, '%(title)s - %(artist)s')
            actual_return_value

# Generated at 2022-06-12 19:16:06.802060
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest
    import sys
    import shutil
    import os
    import tempfile
    import subprocess

    from .common import FileDownloader

    # construct downloader with metadata_from_title enabled
    class DummyYoutubeDL:
        def __init__(self):
            self.params = {'metadata_from_title': '%(artist)s - %(track)s - %(title)s'}
        def to_screen(self, msg):
            print(msg)
            sys.stdout.flush()

    # define sample video data
    class DummyVideo:
        def __init__(self, video_id, video_title):
            self.id = video_id
            self.title = video_title

    # run a sample download

# Generated at 2022-06-12 19:16:14.626358
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from yt_dl.youtube_dl import YoutubeDL
    # Parse title of video with id SgQFgMq3wvo
    # "Dogs vs. Cats"
    title = 'Dogs vs. Cats'
    titleformat = '%(title)s'
    test_info = {'id': 'SgQFgMq3wvo', 'title': title}
    test_downloader = YoutubeDL({'outtmpl': u'%(id)s'})
    test_downloader.to_screen = lambda s: s
    test_downloader.to_stderr = lambda s: s
    test_PP = MetadataFromTitlePP(test_downloader, titleformat)
    assert test_PP.run(test_info)[1]['title'] == title
    # Parse title of video with id

# Generated at 2022-06-12 19:16:26.686639
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest
    import sys
    if sys.version_info[0] >= 3:
        from io import StringIO
    else:
        from StringIO import StringIO

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            info = {'title': 'MetadataFromTitlePP:title:123:artist:456:album:789'}
            self.pp = MetadataFromTitlePP(self, '%(title)s:%(title)s:%(artist)s:%(artist)s:%(album)s:%(album)s:%(publisher)s')
            self.pp.run(info)

        def to_screen(self, msg):
            pass


# Generated at 2022-06-12 19:16:38.765318
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    # Instantiate _all_ FileDownloaders, PostProcessors and YoutubeDL
    FileDownloader(YoutubeDL({'format':'best', 'nooverwrites':True, 'outtmpl':'%(title)s.%(ext)s'}))
    PostProcessor(YoutubeDL({'format':'best', 'nooverwrites':True, 'outtmpl':'%(title)s.%(ext)s'}))
    YoutubeDL({'format':'best', 'nooverwrites':True, 'outtmpl':'%(title)s.%(ext)s'})

    # Expected metadata and downloaded info


# Generated at 2022-06-12 19:16:45.588671
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl.YoutubeDL import YoutubeDL
    ydl_inst = YoutubeDL({})
    pp_inst = MetadataFromTitlePP(ydl_inst, '%(artist)s - %(title)s')
    # checks any result, as long as no error occurs
    assert pp_inst.run({'title': 'The Weeknd - Can\'t Feel My Face'}) == ([], {})

# Generated at 2022-06-12 19:16:54.901858
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    sys.modules["youtube_dl"] = sys.modules["__main__"]

    class MockYoutubeDL(object):
        def to_screen(self, txt):
            pass
    downloader = MockYoutubeDL()

    class TestMetadataFromTitlePP(unittest.TestCase):
        def test_run_no_match(self):
            fromtitlepp = MetadataFromTitlePP(downloader, '%(artist)s - %(song)s')
            title1 = "Title of the video"
            self.assertEqual(fromtitlepp.run({'title': title1}), ([], {'title': title1}))


# Generated at 2022-06-12 19:17:04.923307
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    import unittest.mock
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_str

    class MockInfoDict(dict):
        pass

    class MockDownloader(object):
        def __init__(self):
            self.screen_output = []

        def to_screen(self, msg):
            self.screen_output.append(msg)

    def run_MetadataFromTitlePP(downloader, titleformat, title):
        pp = MetadataFromTitlePP(downloader, titleformat)
        info = MockInfoDict()
        info['title'] = title
        return pp.run(info)

    def get_screen_output(downloader):
        return u'\n'.join(downloader.screen_output)

   

# Generated at 2022-06-12 19:17:16.069101
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # make sure that single items are parsed correctly
    pp = MetadataFromTitlePP(None, '%(title)s')
    info = {}
    info['title'] = 'test'
    _, info = pp.run(info)
    assert info['title'] == 'test'

    # make sure that single items with quotes are parsed correctly
    pp = MetadataFromTitlePP(None, '%(title)s')
    info = {}
    info['title'] = '"test"'
    _, info = pp.run(info)
    assert info['title'] == '"test"'

    # make sure that multiple items are parsed correctly
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    info = {}
    info['title'] = 'test - test'
    _, info = pp

# Generated at 2022-06-12 19:17:25.111676
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ..utils import DateRange

    ydl = object()

    def to_screen(msg):
        print(msg.encode('utf-8'))
    ydl.to_screen = to_screen

    # test if regex is built correctly
    regex_pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    assert regex_pp._titleregex == '(?P<title>.+) - (?P<artist>.+)'
    # test if values are stored correctly
    info = {}
    _, info = regex_pp.run(info)
    assert info == {
        'title': 'my title',
        'artist': 'my artist'
    }

    # test if literal '%' is escaped

# Generated at 2022-06-12 19:17:54.217797
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest

    ydl = lambda: 0

    ydl.to_screen = lambda msg: 0

    class YDL:
        def __init__(self):
            self.params = {
                'skip_download': True
            }

    ydl.params = {'skip_download': True}
    ydl.ydl_opts = YDL()


# Generated at 2022-06-12 19:18:04.005035
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor import gen_extractors

    downloader = FileDownloader()
    downloader.params.update({
        'noplaylist': True,
        'usenetrc': False,
        'username': None,
        'password': None,
        'videopassword': None,
        'forceurl': True,
        'forcetitle': True,
        'forcethumbnail': True,
        'forcedescription': True,
        'forcefilename': True,
        'forcedate': True,
        'forceformat': True,
        'forcejson': True,
        'no_warnings': True,
        'simulate': True,
        'skip_download': True,
        'call_home': False,
    })
    downloader.add_info_

# Generated at 2022-06-12 19:18:12.758026
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .extractor import gen_extractors
    assert len(gen_extractors()) > 0
    assert len(gen_extractors(u'https://www.youtube.com/watch?v=BaW_jenozKc')) > 0
    extractor = gen_extractors(u'https://www.youtube.com/watch?v=BaW_jenozKc')[0]
    assert extractor is not None
    extractor.download(extractor.suitable([u'https://www.youtube.com/watch?v=BaW_jenozKc'])[0])
    info = extractor._request_webpage(u'https://www.youtube.com/watch?v=BaW_jenozKc', None, u'Downloading video webpage')
    assert 'title' in info

# Generated at 2022-06-12 19:18:23.269993
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ..YoutubeDL import YoutubeDL

    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    class Test_MetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.__downloader = YoutubeDL(dict())

        def test_run_when_format_is_not_a_regex(self):
            video_info = dict(title='My Foo Video')
            pp = MetadataFromTitlePP(self.__downloader, 'My Foo Video')
            info = pp.run(video_info)[1]

            self.assertEqual(video_info, info)

        def test_run_when_format_is_not_satisfied(self):
            video_info = dict(title='My Foo Video')

# Generated at 2022-06-12 19:18:34.527969
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class FakeInfoDict:
        def __init__(self):
            self.dict = {}

        def __getitem__(self, key):
            return self.dict[key]

        def __setitem__(self, key, value):
            self.dict[key] = value

    class FakeDict:
        def __init__(self):
            self.dict = {}

        def __getitem__(self, key):
            return self.dict[key]

        def __setitem__(self, key, value):
            self.dict[key] = value

    class FakeYDL:
        def __init__(self):
            self.dict = {}

        def to_screen(self, value):
            print(value)

    fake_info_dict = FakeInfoDict()

# Generated at 2022-06-12 19:18:42.787997
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .downloader import FileDownloader
    from .common import FileDownloader as TestFileDownloader
    from .common import YoutubeDL, FakeYDL
    ydl = FakeYDL()
    # FileDownloader(ydl)
    fd = TestFileDownloader({'title': 'test - title'})
    pp = MetadataFromTitlePP(fd, '%(title)s')
    _, info = pp.run(fd.ydl.extract_info('fake_id', force_generic_extractor=True))
    assert info['title'] == 'test'


if __name__ == '__main__':
    import nose
    nose.core.runmodule()

# Generated at 2022-06-12 19:18:49.246223
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .downloader import Downloader
    from .common import FileDownloader

    # test object
    downloader = Downloader(params={})
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')

    # test run
    info = {'title': 'Clip title'}
    infos, info = pp.run(info)
    assert info == {}

    info = {'title': 'Clip - title - artist'}
    infos, info = pp.run(info)
    assert info == {}

    info = {'title': 'Clip title - artist'}
    infos, info = pp.run(info)
    assert info == {'title': 'Clip title', 'artist': 'artist'}


# Generated at 2022-06-12 19:18:58.326721
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class FakeDownloader:
        def to_screen(self, x):
            pass

    class FakeInfo:
        def __init__(self):
            self.title = None

    def test(title, titleformat, expected):
        info = FakeInfo()
        info.title = title
        pp = MetadataFromTitlePP(FakeDownloader(), titleformat)
        pp.run(info)
        for key, value in expected.items():
            assert info[key] == value

    test('', '', {})
    test('a', '', {})
    test('', 'a', {})
    test('a', 'a', {})
    test('ab', 'a', {})
    test('a', 'ab', {})
    test('a', 'a(?P<x>x)?', {'x': None})


# Generated at 2022-06-12 19:19:08.138495
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # input data
    info = {
        'title': 'Test Title - Artist Black, The',
        'categories': ['tutorial', 'tutorial-unreal-engine'],
        'webpage_url': 'http://www.youtube.com/watch?v=KjhStdV_4Z4',
    }
    # expected values for output

# Generated at 2022-06-12 19:19:15.075961
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    import os

    class FakeYDL(YoutubeDL):
        def process_info(self, info_dict):
            assert 'upload_date' in info_dict
            assert info_dict['upload_date'] == '20150309'

    ydl = FakeYDL({})
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(upload_date)s'))
    ydl.process_ie_result(None, {'title': '20150309'})
