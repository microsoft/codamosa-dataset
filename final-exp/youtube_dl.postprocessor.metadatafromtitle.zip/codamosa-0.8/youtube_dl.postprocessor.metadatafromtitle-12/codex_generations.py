

# Generated at 2022-06-12 19:10:04.272563
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert pp.format_to_regex('') == ''
    assert pp.format_to_regex('%(title)s-%(artist)s') == '(?P<title>.+)-(?P<artist>.+)'
    assert pp.format_to_regex('Length: %(length)s') == 'Length:\ (?P<length>.+)'

# Generated at 2022-06-12 19:10:10.981027
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    assert (MetadataFromTitlePP(None, '%(title)s - %(artist)s')
            ._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)')
    assert (MetadataFromTitlePP(None, '%(title)s - %(artist)s- %(artist)s')
            ._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)\-\ (?P<artist>.+)')


# Generated at 2022-06-12 19:10:20.366869
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor import gen_extractors


# Generated at 2022-06-12 19:10:24.590154
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .extractor import YoutubeIE

    downloader = FakeDownloader()
    extractor = YoutubeIE(downloader)

    res = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    info = {'title': 'testtitle - testartist'}
    res.run(info)
    assert 'title' in info
    assert info['title'] == 'testtitle'
    assert 'artist' in info
    assert info['artist'] == 'testartist'


# Generated at 2022-06-12 19:10:35.950737
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, '').format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert MetadataFromTitlePP(None, '').format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, '').format_to_regex('%(title)s.%(artist)s') == r'(?P<title>.+)\.(?P<artist>.+)'
    assert MetadataFromTitlePP(None, '').format_to_regex('%(title)s[%(artist)s]') == r'(?P<title>.+)\[(?P<artist>.+)\]'
    assert Met

# Generated at 2022-06-12 19:10:41.689455
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    downloader = {
        'to_screen': lambda x: sys.stdout.write('%s\n' % x)
    }

    data = {
        'title': 'My title'
    }

    pp = MetadataFromTitlePP(
        downloader,
        '%(title)s - %(artist)s'
    )

    pp.run(data)
    title, artist = data['title'], data['artist']
    assert title == artist


# Generated at 2022-06-12 19:10:49.114639
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange

    ytdl = YoutubeDL({'extract_flat': 'flat', 'simulate': True, 'quiet': True})

    out, info = MetadataFromTitlePP(ytdl, '%(title)s - %(artist)s').run(
        {'title': 'Cocoon - U Got 2 Know'})
    assert info == {'title': 'Cocoon - U Got 2 Know',
                    'artist': 'Cocoon'}, info

    # Test date regex


# Generated at 2022-06-12 19:10:56.481294
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import pytest
    from ytdl.youtube_dl.downloader import YoutubeDL

    def wrap_title(title):
        return {'title': title}

    # Test invalid input
    data = MetadataFromTitlePP(YoutubeDL({}), 'a b c')
    assert data.run({}) == ([], {})

    # Test simple string input
    data = MetadataFromTitlePP(YoutubeDL({}), 'a b c')
    assert data.run(wrap_title('a b c')) == ([], {})

    # Test regex input
    data = MetadataFromTitlePP(YoutubeDL({}), 'a.*c')
    assert data.run(wrap_title('abc')) == ([], {})

    # Test regex input with groups

# Generated at 2022-06-12 19:11:01.676313
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ydl.compat import compat_str

    # Main object
    ydl = object()

    # Test empty title
    info = {'title': ''}
    titleformat = '%(title)s - %(author)s'
    pp = MetadataFromTitlePP(ydl, titleformat)
    info = pp.run(info)[1]
    for name in ('title', 'author'):
        assert name not in info, 'Found %s in info' % name

    # Test title format: %(title)s - %(author)s
    info = {'title': '_o0o_ - _a0a_'}
    pp = MetadataFromTitlePP(ydl, titleformat)
    info = pp.run(info)[1]

# Generated at 2022-06-12 19:11:08.588739
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # Test a normal case
    metafromtitle = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert metafromtitle.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    # Test an unusual case
    metafromtitle = MetadataFromTitlePP(None, '%(title)s - %(artist)s%(fileprefix)s')
    assert metafromtitle.format_to_regex('%(title)s - %(artist)s%(fileprefix)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)(?P<fileprefix>.+)'

# Generated at 2022-06-12 19:11:21.472467
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import copy

    sys.modules['pytube'] = MockPyTubeModule()
    sys.modules['pytube.extractor'] = MockPyTubeExtractorModule()
    sys.modules['pytube.compat'] = MockPyTubeCompatModule()

    from pytube.postprocessor import MetadataFromTitlePP

    metadataFromTitlePP = MetadataFromTitlePP(None, "%(title)s - %(artist)s")

    info = {
        'title': 'foo'
    }
    expected_info = copy.copy(info)
    expected_info.update({
        'title': 'foo',
        'artist': 'NA'
    })
    assert metadataFromTitlePP.run(info) == ([], expected_info)

    info = {
        'title': 'foo - bar'
    }
    expected_info

# Generated at 2022-06-12 19:11:30.540859
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    titleformat = '%(title)s - %(artist)s'
    titleformat_regex = '(.+) - (.+)'
    video_title = "my video - my artist"

    pp = MetadataFromTitlePP(None, titleformat)
    pp._titleformat = titleformat
    pp._titleregex = titleformat_regex
    info = {}
    info['title'] = video_title
    info = pp.run(info)[-1]

    assert info['title'] == 'my video'
    assert info['artist'] == 'my artist'


# Generated at 2022-06-12 19:11:41.271343
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest

# Generated at 2022-06-12 19:11:51.476593
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class MockDownloader:
        def to_screen(self, message):
            pass
    from ..compat import compat_str
    titleformat = '%(title)s - %(artist)s - %(album)s'
    titleformat_regex = '(?P<title>.+) - (?P<artist>.+) - (?P<album>.+)'
    title = 'Some title - Some artist - Some album'
    test_metadata = {'title': title}
    test_metadata_expected = {'title': 'Some title',
                              'artist': 'Some artist',
                              'album': 'Some album',
                              }
    metadata_from_titlepp = MetadataFromTitlePP(
        downloader=MockDownloader(), titleformat=titleformat)
    assert metadata_from_titlepp._titleformat == titleformat


# Generated at 2022-06-12 19:11:59.164001
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    t = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    # some test cases

# Generated at 2022-06-12 19:12:08.726504
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    titleformat = '%(title)s - %(artist)s'
    title = 'Test Title - Test Artist'
    info = {'title': title}

    class TestDownloader(object):
        def __init__(self):
            self.to_screen_called_with = None

        def to_screen(self, msg):
            self.to_screen_called_with = msg

    downloader = TestDownloader()
    metadata_from_title_pp = MetadataFromTitlePP(downloader, titleformat)
    result = metadata_from_title_pp.run(info)

    assert result == ([], {'title': title, 'artist': 'Test Artist', 'titleformat': titleformat}), \
        'Result is not ([], {...}), but {0}'.format(result)
    assert downloader.to_screen

# Generated at 2022-06-12 19:12:18.372476
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test basic usage
    mp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    info = {'title': 'Numb - Linkin Park'}
    additional, new_info = mp.run(info)
    assert (new_info['title'] == 'Numb') and (new_info['artist'] == 'Linkin Park')
    # Test %(foo)s in title format without %(...)s in title itself
    mp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    info = {'title': 'Numb - Linkin Park - Foo Bar'}
    additional, new_info = mp.run(info)
    assert len(new_info) == 1
    # Test %(...)s in title format without a %(foo)s


# Generated at 2022-06-12 19:12:25.612929
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader

    # Note: the following code is not part of the test, but can be used to
    # run and debug the test quickly from the command-line.

    # config = {'--output': '%(title)s.%(ext)s', '--get-title': True}
    # ydl = FileDownloader({'quiet': True, 'no_warnings': True, 'forcefilename': True})
    # ydl.params.update(config)
    # ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s'))
    #
    # ydl.add_info_extractor(YouTubeIE())
    # ydl.add_info_extractor(YouTubePlaylistIE())
    # ydl.add_info_extractor

# Generated at 2022-06-12 19:12:36.323746
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL

    info = {'title': 'pretty test title'}
    fmt = '%(title)s - %(artist)s'
    regex = '(?P<title>.+)\ \-\ (?P<artist>.+)'

    downloader = YoutubeDL({})
    pp = MetadataFromTitlePP(downloader, fmt)
    assert pp._titleformat == fmt
    assert pp._titleregex == regex

    info['title'] = 'pretty test title - pretty test artist'
    pp.run(info)
    assert info['title'] == 'pretty test title'
    assert info['artist'] == 'pretty test artist'

    info['title'] = 'pretty test title - '
    pp.run(info)
    assert info['title'] == 'pretty test title'

# Generated at 2022-06-12 19:12:40.589980
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-12 19:12:53.936104
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    downloader = None
    titleformat = '%(title)s - %(artist)s'
    instance = MetadataFromTitlePP(downloader, titleformat)

    # test 1
    title = 'VIDEO - TITLE - ARTIST'
    info = {}
    info['title'] = title
    expected_info = {}
    expected_info['title'] = 'TITLE'
    expected_info['artist'] = 'ARTIST'
    result_info = instance.run(info)
    assert info == expected_info

    # test 2
    titleformat = '%(title)s - %(artist)s - %(album)s'
    instance = MetadataFromTitlePP(downloader, titleformat)
    title = 'VIDEO - TITLE - ARTIST - ALBUM'
    info = {}
    info['title'] = title


# Generated at 2022-06-12 19:13:03.552674
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .compat import compat_etree_Element
    from .common import FileDownloader
    from .extractor import get_info_extractor
    from .downloader import prepare_filename

    class FakeIE(object):
        """Fake InfoExtractor"""
        def __init__(self, ie_id):
            self._id = ie_id
        def get_id(self):
            return self._id

    downloader = FileDownloader()

    # test title format with regex
    #
    # This tests parsing of %(title)s and %(artist)s
    # which are parsed as regex groups.
    regex_format = r'%(title)s by %(artist)s'
    regex_regex = r'(?P<title>.+) by (?P<artist>.+)'
    postprocessor = MetadataFromTitle

# Generated at 2022-06-12 19:13:14.136233
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import os
    import tempfile
    import ydl_opts
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-12 19:13:24.906828
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    import os
    # This test is the only one that works without the full extractor and
    # postprocessor framework.

# Generated at 2022-06-12 19:13:33.044759
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest
    class TestMetadataFromTitlePP_run(unittest.TestCase):
        def test_case_1(self):
            class FakeDownloader(object):
                def __init__(self, retval):
                    self.retval = retval
                def to_screen(self, msg):
                    self.retval['to_screen'].append(msg)
            class FakeInfo(object):
                pass

            retval = {
                'to_screen': [],
            }
            downloader = FakeDownloader(retval)
            pp = MetadataFromTitlePP(downloader, '%(title)s by %(artist)s')

            infos = [{
                'title': 'Flower Dance - DJ Okawari',
            }]

# Generated at 2022-06-12 19:13:40.029953
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Input for test
    info = {'title': 'My Title.mp4'}
    # Expected output from test
    exp_info = info.copy()
    exp_info['title'] = 'My Title'

    # Execute test
    pp = MetadataFromTitlePP(None, '%(title)s.mp4')
    (_, result) = pp.run(info)

    # Check results
    assert result == exp_info, (
        'Expected: %s\n But was: %s\n' % (exp_info, result))


# Generated at 2022-06-12 19:13:51.423071
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test case 1:
    title = '%(title)s'
    regex = '^(?P<title>.+)$'
    attributes = {'title': 'test'}
    actual_value = MetadataFromTitlePP(None, title).run((attributes))
    expected_value = ([], {'title': 'test'})
    assert actual_value == expected_value, '\nError in test case 1\n' \
                                            'Input: %s\n' \
                                            'Expected output: %s\n' \
                                            'Actual output:   %s' \
                                           % (title, expected_value, actual_value)

    # Test case 2:
    title = '%(title)s - %(artist)s'

# Generated at 2022-06-12 19:13:58.179285
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    dl = object()
    mpp = MetadataFromTitlePP(dl, '%(artist)s - %(title)s')
    info = {'title': 'Queen - Bohemian Rhapsody'}
    mpp.run(info)
    assert info['artist'] == 'Queen'
    assert info['title'] == 'Bohemian Rhapsody'


# Generated at 2022-06-12 19:14:07.123620
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # NOTE: this module is not always available,
    #       so MetadataFromTitlePP_test.py can't import it
    from ytdl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    from operator import methodcaller
    mftpp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    assert(mftpp.run({'title': 'Sibelius – Symphony No. 5'}) == ([], {'title': 'Sibelius', 'artist': 'Symphony No. 5'}))
    assert(mftpp.run({'title': 'Title :: Artist'}) == ([], {'title': 'Title', 'artist': 'Artist'}))

# Generated at 2022-06-12 19:14:11.039119
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.FileDownloader import FileDownloader
    ydl = YoutubeDL({})
    fd = FileDownloader(ydl, {'simulate': True})
    pp = MetadataFromTitlePP(fd, '%(artist)s - %(title)s')

    # Test parsing with regex
    info = {}
    pp.run(info)
    assert info == {}

    # Test parsing with regex
    info = {'title': 'ABC - DEF'}
    pp.run(info)
    assert info == {'title': 'ABC - DEF', 'artist': 'ABC'}

    # Test parsing with regex
    info = {'title': 'ABC - DEF - GHI'}
    pp.run(info)

# Generated at 2022-06-12 19:14:22.809708
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ..compat import compat_etree_ElementTree
    from ..compat import compat_urllib_request
    from ..YoutubeDL import YoutubeDL

    downloader = YoutubeDL(params={'dump_single_json': True})
    downloader.params['outtmpl'] = '%(title)s.%(ext)s'
    downloader.add_info_extractor('YoutubeIE')

    # no title attribute, no option --metadata-from-title
    output = downloader.extract_info(
        compat_urllib_request.Request('http://www.youtube.com/watch?v=iwGFalTRHDA'),
        download=False)
    assert 'title' not in output
    assert output['id'] == 'iwGFalTRHDA'
    assert output['ext'] == 'webm'


# Generated at 2022-06-12 19:14:31.097911
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import pytest
    from ydl_addons.postprocessor.common import Downloader

    titleformat = '%(title)s - %(artist)s'
    titleregex = r'(?P<title>.+)\ \-\ (?P<artist>[^<]+)'
    video_info = {'title': 'Video title - Video artist'}
    postprocessor = MetadataFromTitlePP(Downloader(), titleformat)

    # regex is generated correctly
    assert postprocessor._titleregex == titleregex

    # title is parsed correctly
    metadata_from_title, new_video_info = postprocessor.run(video_info)
    assert not metadata_from_title
    assert new_video_info['title'] == 'Video title'
    assert new_video_info['artist'] == 'Video artist'

    # title is not

# Generated at 2022-06-12 19:14:39.143528
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from . import YoutubeDL

    # init YouTubeDL with a fake config
    youtube_dl = YoutubeDL({
        'outtmpl': '%(title)s.%(ext)s',
        '_titleformat_flat': '%(title)s - %(uploader)s - %(id)s',
        'writedescription': True,
        'writeinfojson': True,
        'writethumbnail': True,
        'writeannotations': True,
        'writeautomaticsub': True,
        'allsubtitles': True,
    })

    # init MetadataFromTitlePP with fake YouTubeDL
    metadata_from_title = MetadataFromTitlePP(
        youtube_dl, '%(title)s - %(uploader)s - %(id)s')

    # run MetadataFromTitlePP with fake input

# Generated at 2022-06-12 19:14:50.566023
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # pylint: disable=too-many-locals
    from youtube_dl.downloader import Downloader
    from youtube_dl.options import OptionParser
    from youtube_dl.utils import post_processor_args, match_filter_func
    from youtube_dl.extractor import get_info_extractor

    from .common import InfoExtractorMock, FakeYDL
    from .test_utils import make_result_video
    from .debug_utils import set_logger

    # setup logger to debug level
    set_logger()


# Generated at 2022-06-12 19:15:00.618641
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    titleformat = '%(uploader)s - %(title)s'
    title = 'TestUploader - TestTitle'
    downloader = None
    info = {'elapsed': '00h02m22s', 'title': title,
            'uploader': 'TestUploader', 'upload_date': '20141005'}

    pp = MetadataFromTitlePP(downloader, titleformat)
    pp_info = pp.run(info)
    assert pp_info[0] == []
    assert pp_info[1] == {'elapsed': '00h02m22s', 'title': 'TestTitle',
                          'uploader': 'TestUploader - TestTitle',
                          'upload_date': '20141005'}

# Generated at 2022-06-12 19:15:09.095785
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .YoutubeDL import YoutubeDL
    import unittest

    class TestMetadataFromTitlePP(unittest.TestCase):
        def test_run(self):
            metadataFromTitlePP = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
            # test with missing video title
            info = {}
            [], info = metadataFromTitlePP.run(info)
            self.assertEqual(info, {})
            # test with title matching provided format
            info = {'title': 'Crazy - Gnarls Barkley'}
            [], info = metadataFromTitlePP.run(info)
            self.assertEqual(info, {'title': 'Crazy', 'artist': 'Gnarls Barkley'})


# Generated at 2022-06-12 19:15:19.027818
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # test_class is a class for testing by mocking youtube_dl
    class test_class:
        def to_screen(self, msg):
            print(msg)
        def report_warning(self, msg, **kwargs):
            print(msg)
    # Initialize a test_class on which to run the test
    test_instance = test_class()
    # Define the test input
    info = {'title': 'Song title - Artists name'}
    # Define the strings that should be printed
    expected = [
        '[fromtitle] parsed title: Song title',
        '[fromtitle] parsed artist: Artists name'
    ]
    # Run the test
    pp = MetadataFromTitlePP(test_instance, '%(title)s - %(artist)s')
    pp.run(info)
    # Compare the printed

# Generated at 2022-06-12 19:15:30.561739
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-12 19:15:40.747497
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-12 19:15:49.371803
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Input data
    info = {'title': 'MyVideo | 2017-06-10 16-33-00'}
    # Output data
    out = {'upload_date': '2017-06-10 16-33-00', 'title': 'MyVideo'}

    # test run
    pp = MetadataFromTitlePP(None, '%(title)s | %(upload_date)s')
    info1 = {}
    info1.update(info)
    [], info1 = pp.run(info1)
    assert info1 == out


# Generated at 2022-06-12 19:16:02.567732
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    try:
        from ytdl.downloader import YoutubeDL
        test_downloader = YoutubeDL()
    except ImportError:
        from unittest import SkipTest
        raise SkipTest('test_PostProcessor_run skipped: could not import ytdl.postprocessor')

    test_downloader.params['outtmpl'] = '%(title)s'
    test_downloader.params['writethumbnail'] = True
    # test_downloader.params['writedescription'] = True
    # test_downloader.params['writeannotations'] = True

    # test_downloader.add_info_extractor(
    #     YoutubeIE(test_downloader, '%(id)s'))

    url = 'https://www.youtube.com/watch?v=BaW_jenozKc'
    test_downloader

# Generated at 2022-06-12 19:16:12.520745
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    Unit test for the method run of the class MetadataFromTitlePP to verify,
    that the method correctly extracts metadata
    """

    downloader = object()
    downloader.to_screen = object() # method is called, but we do not use the information
    titleformat = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(downloader, titleformat)

    title = 'FOO - BAR'
    info = {'title': title}
    new_info = dict(info)
    new_info['title'], new_info['artist'] = 'FOO', 'BAR'
    assert (pp.run([], info) == ([], new_info))

    title = 'FOO - BAR - [bla]'
    info = {'title': title}
    new_info = dict

# Generated at 2022-06-12 19:16:18.841163
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    info = {'title': 'Bruno Mars - Just the way you are'}
    assert pp.run(info) == ([], {'title': 'Bruno Mars - Just the way you are', 'artist': 'Bruno Mars'})


# Generated at 2022-06-12 19:16:29.417525
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    downloader = object()
    pp = MetadataFromTitlePP(downloader, '%(artist)s')
    expected = [
        ('[fromtitle] parsed artist: %s' % expected_artist, expected_artist)
        for expected_artist in [
            'SR-71',
            'The Beatles',
            'The Rolling Stones',
            'The Beatles',
            'The Beatles',
            'The Beatles',
            None
        ]
    ]

# Generated at 2022-06-12 19:16:40.644794
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    import sys
    import pytube
    from pytube.exceptions import PytubeError
    from io import BytesIO
    from unittest import TestCase

    class MockDownloader(object):
        def to_screen(self, message):
            pass

    class MockEntity(object):
        def __init__(self, content):
            self.content = content

        def read(self):
            return self.content

        def readlines(self):
            return [self.content]

        def close(self):
            pass

    class TestMetadataFromTitlePP(TestCase):
        def setUp(self):
            pytube.set_security_policy(pytube.SecurityPolicy.loose())
            self.downloader = MockDownloader()
            self.video_url = 'http://test.test/test.mp4'
           

# Generated at 2022-06-12 19:16:52.637305
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl
    # Case 1
    downloader = youtube_dl.YoutubeDL()
    titleformat = '%(title)s - %(artist)s'
    titleregex = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    metadata_from_title_pp = MetadataFromTitlePP(downloader, titleformat)
    info = {'title': 'youtube-dl test video - test artist' }
    info_expected = {'title': 'youtube-dl test video', 'artist': 'test artist'}
    (retcode, retinfo) = metadata_from_title_pp.run(info)
    assert retinfo == info_expected
    assert retcode == ([], info_expected)
    del metadata_from_title_pp
    # Case 2

# Generated at 2022-06-12 19:17:03.604018
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    def testit(title, titleformat, expected_metadata):
        info = {'title': title}
        obj = MetadataFromTitlePP(None, titleformat)
        obj.run(info)
        assert info == expected_metadata

    testit('', '', {'title': ''})
    testit('Dummy', '', {'title': 'Dummy'})
    testit('Dummy', '%(title)s', {'title': 'Dummy'})
    testit('Dummy - ABC', '%(title)s', {'title': 'Dummy - ABC'})
    testit('Dummy', '%(title)s - ABC', {'title': 'Dummy - ABC'})

# Generated at 2022-06-12 19:17:07.595764
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .__main__ import get_config
    from .extractor import gen_extractors
    from .extractor.youtube import YoutubeIE
    from .utils import DateRange

    def get_date_range(timestamp):
        return DateRange(timestamp, timestamp)

    downloader = FakeYoutubeDL({
        'simulate': True,
        'outtmpl': '%(title)s.f4a',
        'nooverwrites': True,
        'writedescription': True,
        'writeinfojson': True,
        'writeannotations': True,
    })

    downloader.add_info_extractor(YoutubeIE(downloader))

    # Use youtube-dl's own test suite
    gen_extractors(downloader)

    # Register our unit test

# Generated at 2022-06-12 19:17:18.519764
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest


# Generated at 2022-06-12 19:17:27.275876
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    import sys

    # Title format: "%(title)s %(foo)s - %(artist)s"
    test_title_format = "%(title)s %(foo)s - %(artist)s"
    # Title format to regex: "(?P<title>.+) (?P<foo>.+) - (?P<artist>.+)"
    test_title_regex = "(?P<title>.+) (?P<foo>.+) - (?P<artist>.+)"

    def test_format_to_regex(self):
        assert self._titleregex == test_title_regex

    MetadataFromTitlePP.format_to_regex = test_format_to_regex

    test_video_title = "test_title foo - test_artist"
   

# Generated at 2022-06-12 19:17:46.328357
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import os
    sys.path.append(os.path.join(
        os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
        'youtube_dl'))
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import ExtractorError

    def test_value(prop, expected):
        if expected is None:
            if prop.get('actual') is not None:
                raise AssertionError('%s: expected:None, actual:%s'
                    % (prop['name'], prop.get('actual')))

# Generated at 2022-06-12 19:17:57.542776
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import types
    import unittest

    class MyDict(dict):
        def __setitem__(self, key, value):
            self.__dict__[key] = value

    class MyLogger(object):
        def debug(self, msg):
            print('MyLogger:debug: %s' % msg)
            sys.stdout.flush()

    class MyDownloader(object):
        def __init__(self):
            self.to_screen_calls = []

        def to_screen(self, msg):
            print('MyDownloader:to_screen: %s' % msg)
            sys.stdout.flush()
            self.to_screen_calls.append(msg)


# Generated at 2022-06-12 19:18:05.484012
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ydl.utils import DateRange
    from ydl.compat import compat_etree_fromstring
    from ydl.postprocessor import FFmpegExtractAudioPP

    class FakeYDL:
        def to_screen(self, msg):
            print(msg)
    ydl = FakeYDL()

    def fake_extract_audio(fname, outtmpl, ie, ffmpeg_params):
        if '%(artist)s' in outtmpl:
            return FakeYDL.download(ydl, {
                'id': 'TestVideo',
                'title': 'test - video',
                'upload_date': '20130806'
            })

# Generated at 2022-06-12 19:18:13.313258
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl.YoutubeDL import YoutubeDL
    from ytdl.extractor.common import InfoExtractor
    from ytdl.utils import DateRange

# Generated at 2022-06-12 19:18:18.933901
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    mft = MetadataFromTitlePP(None, '%(key1)s-%(key2)s-%(key3)s-%(key4)s-')

    # Should return empty lists and preserve dictionary of key-value pairs
    assert (mft.run({'key1': 'value1',
                     'key2': 'value2',
                     'key3': 'value3',
                     'key4': 'value4'})
            == ([], {'key1': 'value1',
                     'key2': 'value2',
                     'key3': 'value3',
                     'key4': 'value4'}))

    # Should return empty lists and preserve dictionary of key-value pairs
    # with additional element not specified in title format.

# Generated at 2022-06-12 19:18:26.878746
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-12 19:18:34.564362
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl
    # pylint: disable=protected-access
    dl = youtube_dl.YoutubeDL({})
    info = {}
    # check if titleformat is incompatible with title
    pp = MetadataFromTitlePP(dl, titleformat='%(title)s%(artist)s')
    pp.run(info)
    # check a correct title
    pp = MetadataFromTitlePP(dl, titleformat='%(title)s - %(artist)s')
    info['title'] = 'Song title - Artist'
    info, out_info = pp.run(info)
    assert info['title'] == 'Song title' and info['artist'] == 'Artist'

# Generated at 2022-06-12 19:18:39.710763
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pp = MetadataFromTitlePP('', '%(title)s - %(artist)s')
    info = {'title': 'test title - artist'}
    assert pp._titleregex == 'test title - artist'
    pp.run(info)
    assert info == {'title': 'test title - artist', 'artist': 'artist'}


# Generated at 2022-06-12 19:18:47.485093
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Passes
    assert MetadataFromTitlePP(None,'%(title)s').run({'title': 'title'}) == ([], {})
    assert MetadataFromTitlePP(None,'%(title)s').run({'title': 'title-title'}) == ([], {})
    assert MetadataFromTitlePP(None,'%(title)s').run({'title': 'title- title'}) == ([], {'title': 'title'})
    assert MetadataFromTitlePP(None,'%(title)s').run({'title': 'title -title'}) == ([], {'title': 'title'})
    assert MetadataFromTitlePP(None,'%(title)s').run({'title': 'title - title'}) == ([], {'title': 'title'})

# Generated at 2022-06-12 19:18:57.032274
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """Test of MetadataFromTitlePP.run"""
    import unittest
    from .common import DummyYDL # pylint: disable=import-error
    from .extractor.common import InfoExtractor # pylint: disable=import-error
    from .compat import compat_str

    class TestPP(object):
        """
        Dummy downloader for testing.
        """
        def __init__(self):
            self.to_screen = lambda *_: None
            self.to_stdout = lambda *_: None
            self.to_stderr = lambda *_: None

    class TestIE(InfoExtractor):
        """
        Dummy InfoExtractor for testing.
        """
        _VALID_URL = r'(?i)https?://.*'

# Generated at 2022-06-12 19:19:24.151323
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import ydl_opts
    from ydl.extractor import get_info_extractor

    class DummyYDL(object):
        def __init__(self):
            self.to_screen = lambda msg: None

    postprocessor = MetadataFromTitlePP(DummyYDL(), '%(title)s')
    ie = get_info_extractor('SoundcloudIE')
    info = ie._real_extract('https://soundcloud.com/gaetan-d-haene/julian-lopez-el-juli-pase-de-pecho-at-plaza-de-toros-las-ventas-madrid-spain-29-05-2016')

# Generated at 2022-06-12 19:19:30.116216
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    def test(titleformat, test_title, exp_title, exp_artist):
        expected = {'title': exp_title, 'artist': exp_artist}
        fff = MetadataFromTitlePP(None, titleformat)
        info = {'title': test_title}
        _, actual = fff.run(info)
        if actual != expected:
            print('MetadataFromTitlePP.run failed for', titleformat,
                  'for title', test_title,
                  ':\nexpected', expected,
                  '\ngot', actual)
    test('%(title)s - %(artist)s',
         'Here is the title - Here is the artist',
         'Here is the title', 'Here is the artist')

# Generated at 2022-06-12 19:19:39.681695
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .downloader import YoutubeDL
    ydl = YoutubeDL({})

    example_title = '''
    2018 NFL Preseason: Hall of Fame Game Highlights - Raiders vs. Eagles
    '''

    expected_info = {
        'title': example_title,
        'season_number': 2018,
        'episode_number': 225,
        'ext': 'mp4',
        'format': '137+140/137/134+140/134/133+140/133/160+140/160/17/18/22',
        'format_id': '137+140/137/134+140/134/133+140/133/160+140/160/17/18/22',
        'resolution': 'any',
        'format_note': 'DASH video',
    }

    # Testing one of the regexps
    title_

# Generated at 2022-06-12 19:19:41.002734
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass


# Generated at 2022-06-12 19:19:48.059707
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL


# Generated at 2022-06-12 19:19:58.163000
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """Unit test of class MetadataFromTitlePP
    Uses a example with artist, title and tracknumber, which is separated by
    a dash. The class MetadataFromTitlePP should extract these informations
    using the regular expression.
    """
    import regex as re
    import sys
    import unittest
    import youtube_dl

    class MockDownloader():
        to_screen = sys.stdout.write

    class MockInfo():
        def __init__(self):
            self.title = 'Foo Bar - Some Title - 02'

    info = MockInfo()
    downloader = MockDownloader()
    # Using a simple format as titleformat, which matches to the title of the
    # video.
    titleformat = '%(artist)s - %(title)s - %(tracknumber)s'
    pp = MetadataFromTitle