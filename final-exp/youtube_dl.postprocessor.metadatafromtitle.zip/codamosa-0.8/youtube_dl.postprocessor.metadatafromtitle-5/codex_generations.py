

# Generated at 2022-06-12 19:10:04.504425
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor.youtube import YoutubeIE

    FakeYDL = type('FakeYDL', (FileDownloader,), {'params': {}})

    testpp = MetadataFromTitlePP(FakeYDL(),
                                 '%(title)s - %(uploader)s')
    testinfo = {'title': 'mytitle - myuploader',
                'uploader': 'myuploader'}

    testpp.run(testinfo)
    assert testinfo['title'] == 'mytitle'
    assert testinfo['uploader'] == 'myuploader'

    testpp = MetadataFromTitlePP(FakeYDL(),
                                 '%(title)s - %(uploader)s')

# Generated at 2022-06-12 19:10:13.617813
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .compat import compat_urllib_parse
    titleformat = '%(title)s - %(artist)s'
    title = 'MyTitle - MyArtist'
    downloader = MockDownloader()
    processor = MetadataFromTitlePP(downloader, titleformat)
    # Test if processor interprets a given title according to format
    info = {}
    info['title'] = title
    info['titleformat'] = titleformat
    expected_output_regex = '\[fromtitle\] parsed title: MyTitle'
    output_stream = compat_urllib_parse.unquote_to_bytes(
        processor.run(info)[1]['title'])
    assert re.search(expected_output_regex, output_stream)

# Generated at 2022-06-12 19:10:22.037560
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader

    # test for default title pattern
    info = {'title':'abc - xyz', 'artist':'NA', 'description':'NA', 'filesize':12345}
    downloader = FileDownloader(params={})
    a = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    a.run(info)
    assert info['title'] == 'abc'
    assert info['artist'] == 'xyz'
    assert info['description'] == 'NA'

    # test for default title pattern
    info = {'title':'abc - xyz', 'artist':'NA', 'description':'NA', 'filesize':12345}
    downloader = FileDownloader(params={})

# Generated at 2022-06-12 19:10:32.172307
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl.YoutubeDL
    import youtube_dl.postprocessor.common
    from collections import defaultdict

    ydl = youtube_dl.YoutubeDL({'simulate': True})

    postprocessor = MetadataFromTitlePP(ydl, '%(artist)s  - %(title)s')

    info = defaultdict(lambda: '', {
        'id': 1,
        'title': 'Elvis Presley - Suspicious Minds (Audio)',
    })
    assert postprocessor.run(info) == ([], {
        'artist': 'Elvis Presley',
        'id': 1,
        'title': 'Elvis Presley - Suspicious Minds (Audio)',
    })

    postprocessor = MetadataFromTitlePP(ydl, '%(title)s + %(title2)s')

   

# Generated at 2022-06-12 19:10:42.213094
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import pytest

    def _mocked_downloader_to_screen(text):
        print(text)

    class MockedYoutubeDL:
        def __init__(self):
            self.to_screen = _mocked_downloader_to_screen

    class MockInfoDict():
        def __init__(self, title):
            self.title = title
            self.artist = None
            self.title_from_file = None

    class TestCase:
        def __init__(self, input_title, input_format, output_artist, output_title_from_file):
            self.input_title = input_title
            self.input_format = input_format
            self.expected_output_artist = output_artist
            self.expected_output_title_from_file = output_title_from_file

   

# Generated at 2022-06-12 19:10:49.588350
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    t = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert t._titleformat == '%(title)s - %(artist)s'
    assert t._titleregex == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'

    t = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(album)s')
    assert t._titleformat == '%(title)s - %(artist)s - %(album)s'
    assert t._titleregex == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)\\ \\-\\ (?P<album>.+)'

    t = MetadataFromTitlePP(None, '%(title)s')

# Generated at 2022-06-12 19:10:57.038772
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ..YoutubeDL import YoutubeDL
    info = {
        'title' : 'John Smith - Song Title',
        'ext'   : 'mp4',
        'format': 'mp4',
        'filepath': 'test.mp4',
        'format_id': 'mp4',
    }
    pp = MetadataFromTitlePP(YoutubeDL(), '%(artist)s - %(title)s')
    pp.run(info)
    assert info['artist'] == 'John Smith'
    assert info['title']  == 'Song Title'

# Generated at 2022-06-12 19:11:02.305092
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # init objects
    downloader = object()
    titleformat = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(downloader, titleformat)

    # test
    title = 'California - Phantom Planet'
    info = {'title': title}
    info_expected = {'title': 'California', 'artist': 'Phantom Planet'}
    [], info_returned = pp.run(info)
    assert info == info_expected

    # test
    title = 'Blah Blah Bla - Whatever'
    info = {'title': title}
    info_expected = {'title': title}
    [], info_returned = pp.run(info)
    assert info == info_expected

    # test
    title = 'Blah % Blah - Whatever'
    title_expected

# Generated at 2022-06-12 19:11:08.465085
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test MetadataFromTitlePP._format_to_regex
    assert MetadataFromTitlePP(None, None).format_to_regex('%(title)s') == '(?P<title>.+)'
    assert MetadataFromTitlePP(None, None).format_to_regex(' - %(title)s') == '\ \-\ (?P<title>.+)'

    # Test MetadataFromTitlePP.run
    run_results = MetadataFromTitlePP(
        None,
        '',
    ).run({'title': 'test'})
    assert run_results[0] == []
    assert run_results[1]['title'] == 'test'

# Generated at 2022-06-12 19:11:17.192300
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import os.path
    import doctest
    sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
    import youtube_dl
    import youtube_dl.downloader
    dl = youtube_dl.downloader.FileDownloader({})
    pp = MetadataFromTitlePP(dl, '%(artist)s - %(title)s')
    doctest.run_docstring_examples(pp.run, globals())

if __name__ == '__main__':
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-12 19:11:32.280525
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import \
        encode_data, encode_dict, encode_url
    from tempfile import NamedTemporaryFile

    def call_run(title, titleformat, expected_result):
        # Create youtube_dl.YoutubeDL instance
        ydl = YoutubeDL({})
        ydl.params = {}
        ydl.downloaded_info_dicts = []
        ydl.cache.downloader_cache = {}

        # Create MetadataFromTitlePP instance
        pp = MetadataFromTitlePP(ydl, titleformat)

        # Create and add sample info to downloaded_info_dicts
        info = {'title': title}
        ydl.downloaded_info_dicts.append(info)

        # Call run
        pp.run(info)



# Generated at 2022-06-12 19:11:42.635952
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys

    downloader = None
    class Downloader:
        to_screen_call_args = None
        def to_screen(self, msg):
            self.to_screen_call_args = (msg)

    downloader = Downloader()

    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    info = { 'title': 'A B C - D E F' }
    infos, newinfo = pp.run(info)
    assert newinfo is not None
    assert newinfo['title'] == 'A B C'
    assert newinfo['artist'] == 'D E F'
    assert downloader.to_screen_call_args == '[fromtitle] parsed title: A B C'

# Generated at 2022-06-12 19:11:53.555739
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import mock
    import os
    import sys

    downloader = mock.Mock()
    # This is to avoid that "fromtitle" tries to access
    # sys.argv[0] which is not set.
    sys.argv = ['test_MetadataFromTitlePP_run']

    # Test 1: %(title)s
    fromtitle = MetadataFromTitlePP(downloader,
                                    '%(title)s')
    info = {
        'title': 'A title with special char "ä"',
    }
    fromtitle.run(info)
    assert info['title'] == 'A title with special char "ä"'
    assert info.get('artist') is None

    # Test 2: %(title)s - %(artist)s

# Generated at 2022-06-12 19:12:00.380823
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest
    class TestMetadataFromTitlePP_run(unittest.TestCase):
        def test_format_to_regex(self):
            metadataFromTitlePP = MetadataFromTitlePP(None, None)
            self.assertEqual(
                metadataFromTitlePP.format_to_regex('%(title)s - %(artist)s'),
                '(?P<title>.+)\ \-\ (?P<artist>.+)')
        def test_parse_title_1(self):
            metadataFromTitlePP = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
            info = {'title': 'This is a title - by an artist'}
            expected_info = {'title': 'This is a title', 'artist': 'by an artist'}

# Generated at 2022-06-12 19:12:09.813379
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from . import YoutubeDL
    dl = YoutubeDL({})
    dl.params['postprocessor_args'] = [
        [
            '--metadata-from-title',
            '%(artist)s - %(title)s'
        ]
    ]
    dl.add_post_processor(MetadataFromTitlePP(dl, '%(artist)s - %(title)s'))

    # Test that regexp is parsed and tested
    assert dl._post_processors[0].format_to_regex(
        '%(title)s - %(artist)s') == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'

    # Test correct regexp
    info = {'title': 'Test - Test'}
    dl._post_processors[0].run(info)

# Generated at 2022-06-12 19:12:19.170573
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl.downloader
    from youtube_dl.compat import compat_str

    ydl = youtube_dl.downloader.YoutubeDL()

    # Metadata from title
    info = {'id': 'BoM6q3QQ2QE',
            'title': 'Deadmau5 - "Ghosts N Stuff" feat. Rob Swire',
            'ext': 'mp4',
            'url': 'http://www.youtube.com/watch?v=BoM6q3QQ2QE',
            'uploader': 'Ultra Music',
            'uploader_id': 'UMG',
            'upload_date': '20091125',
            'license': 'Standard YouTube License',
            'creator': 'Deadmau5',
            'track': 'Ghosts N Stuff'}

# Generated at 2022-06-12 19:12:24.311708
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from sys import version_info
    if version_info[0] < 3:
        import codecs
    else:
        def codecs(name, arg, arg2):
            return arg2
    import io
    import unittest
    import ydl

    class FakeDownloader:

        def __init__(self):
            self.to_screen = lambda x: None

    class FakeYDL:
        def __init__(self):
            self.params = {'outtmpl': '%(title)s - %(artist)s'}
            self.downloader = FakeDownloader()

        def to_screen(self, msg):
            pass


# Generated at 2022-06-12 19:12:35.110509
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import ytdl_manager
    from ytdl_manager import FileDownloader
    from ytdl_manager import YoutubeDL
    import tempfile
    import pytest

    @staticmethod
    def _fetch_format(fmt):
        return {'url': '--',
                'format': fmt,
                'format_id': fmt['format_id'],
                'alt_title': None,
                }

    @staticmethod
    def get_get_info(formats):
        @staticmethod
        def get_info(url):
            return {'title': 'title',
                    'formats': [MetadataFromTitlePP._fetch_format(fmt)
                                for fmt in formats]
                    }

        return get_info


# Generated at 2022-06-12 19:12:42.265121
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import copy
    import ytdl_down
    from ytdl_down.extractor import get_info_extractor
    class FakeDl (object):
        def __init__(self, test_value):
            self.test_value = test_value
        def to_screen(self, *args):
            self.test_value = args[0]
    title = 'Youtube Downloader -- Download & Convert Videos from Youtube %(ext)s'
    info = get_info_extractor('youtube').extract('http://youtube.com/watch?v=BaW_jenozKc')
    info['ext'] = 'mp4'
    test_value = ''
    ftp = MetadataFromTitlePP(FakeDl(test_value), title)
    ftp.run(info)

# Generated at 2022-06-12 19:12:53.840161
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader, std_headers
    from .extractor import gen_extractors
    import json

    url = 'https://www.youtube.com/watch?v=BaW_jenozKc'
    outtmpl = '%(title)s.%(ext)s'
    title = 'test_title'
    titleformat = '%(title)s: %(id)s - %(ext)s'
    expected_title = title + ': BaW_jenozKc - mp4'


# Generated at 2022-06-12 19:13:06.974368
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from collections import namedtuple

    test_input = namedtuple('test_input', 'title format')

# Generated at 2022-06-12 19:13:14.837803
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import Downloader
    from .YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    ydl.add_post_processor(MetadataFromTitlePP(Downloader(), '%(title)s'))

    examples = dict(
        title='title',
        artist='artist - title',
        artist_title='artist - title',
        artist_title_album='artist - title  -  album',
        artist_title_album_trackno='artist - title  -  album  -  trackno',
    )
    for format, title in examples.items():
        test(ydl, title, {'title': title}, format=format)


# Generated at 2022-06-12 19:13:25.751210
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from . import YoutubeDL

    ydl = YoutubeDL(FileDownloader())

    # Test basic regex
    title = 'The Wubbcast Episode 01 - The Wubb Girlz'
    titleformat = '%(title)s'
    titleregex = ydl.pp_convert.format_to_regex(titleformat)
    match = re.match(titleregex, title)
    assert match.group(1) == title

    # Test multiple matches
    title = 'The Wubbcast Episode 01 - The Wubb Girlz'
    titleformat = 'The Wubbcast Episode %(episode_number)s - %(artist)s'
    titleregex = ydl.pp_convert.format_to_regex(titleformat)
    match = re.match(titleregex, title)

# Generated at 2022-06-12 19:13:35.735544
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import pytest
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.YoutubeDLDownloader import YoutubeDLDownloader
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import YoutubeDLError

    # mock downloader
    class MockDownloader(YoutubeDLDownloader):
        def to_screen(self, msg):
            pass
    mock_ydl = YoutubeDL({}, MockDownloader())

    # mock extractor
    class MockIE(InfoExtractor):
        def __init__(self, downloader, ie_key):
            pass
        @staticmethod
        def suitable(url):
            return True

# Generated at 2022-06-12 19:13:43.575581
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ..YoutubeDL import YoutubeDL

    ydl = YoutubeDL({'quiet': True})
    test_input = 'artist - song (album)'
    test_output = ['fromtitle']
    for test_fmt in [test_input, '%(artist)s - %(song)s (%(album)s)',
                     '%(song)s (%(album)s) - %(artist)s ',
                     '%(album)s - %(song)s - %(artist)s']:
        pp = MetadataFromTitlePP(ydl, test_fmt)
        info = {'title': test_input}
        pp.run(info)
        assert info['song'] == 'song'
        assert info['artist'] == 'artist'
        assert info['album'] == 'album'
        assert info['extractor']

# Generated at 2022-06-12 19:13:53.346663
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl.YoutubeDL import YoutubeDL

# Generated at 2022-06-12 19:14:04.746375
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    ydl.params['nooverwrites'] = True
    mp = MetadataFromTitlePP(ydl, '%(artist)s - %(title)s')
    assert mp.run({'id': '3d62a42b774c', 'title': 'NikitA - 9 Lives'}) == ([], {'id': '3d62a42b774c', 'title': 'NikitA - 9 Lives', 'artist': 'NikitA', 'title': '9 Lives'})

# Generated at 2022-06-12 19:14:15.649972
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import copy
    downloader = type('Downloader', (object,), {})
    task1 = {
        'title': 'Title - Artist',
        'webpage_url': 'https://www.youtube.com/watch?v=DUlI6w4m6bk'}
    params1 = {
        'titleformat': '%(title)s - %(artist)s'}
    titleformat1 = '%(title)s - %(artist)s'
    class1 = MetadataFromTitlePP(downloader, titleformat1)
    task2 = copy.deepcopy(task1)
    params2 = copy.deepcopy(params1)
    task3 = copy.deepcopy(task1)
    params3 = copy.deepcopy(params1)
    task3['title'] = task3['title'].replace

# Generated at 2022-06-12 19:14:26.224966
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-12 19:14:35.067703
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl
    class InfoDict:
        def __init__(self, *args, **kwargs):
            self.__dict__ = kwargs
    class FakeDownloader:
        def to_screen(self, *args):
            pass

    # Test method with titleformat in the form of regex pattern
    p = MetadataFromTitlePP(downloader=FakeDownloader(), titleformat=r'(?P<title>.+)\ \-\ (?P<artist>.+)')
    i = InfoDict(title="Hello - Foo")
    m = p.run(i)
    assert(i.title == "Hello")
    assert(i.artist == "Foo")

    # Test method with titleformat in the form of '%(coding)s %(title)s'

# Generated at 2022-06-12 19:14:53.083807
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import types
    import pytest

    class YoutubeDL(object):
        @staticmethod
        def to_screen(msg): pass

    PARSED_DICT = {'upload_date': '20120101', 'title': 'test title'}
    UNPARSED_DICT = {'title': 'upstream title'}

    def add_info_dict(info):
        def _add_info_dict(self, info):
            self.info = info
        return types.MethodType(_add_info_dict, YoutubeDL())

    # empty info error
    with pytest.raises(Exception):
        pp = MetadataFromTitlePP(add_info_dict({}), '%(title)s')
        pp.run({})

    # no match error
    with pytest.raises(Exception):
        pp = Met

# Generated at 2022-06-12 19:15:03.777015
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    MetadataFromTitlePP.format_to_regex('%(title)s') == '(?P<title>.+)'
    MetadataFromTitlePP.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    class MockYDL:
        def __init__(self):
            self.to_screen = print
    ydl = MockYDL()
    pp = MetadataFromTitlePP(
        ydl, '%(title)s - %(artist)s'
    )
    info = {}
    pp.run(info)
    pp = MetadataFromTitlePP(
        ydl, '%(title)s - %(artist)s - %(silly man)s'
    )

# Generated at 2022-06-12 19:15:06.120325
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from . import YoutubeDL

    class Info:
        pass

    ydl = YoutubeDL()
    info = Info()
    mftpp = MetadataFromTitlePP(ydl, "%(title)s")
    mftpp.run(info)

# Generated at 2022-06-12 19:15:16.364613
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    import sys
    downloader = FileDownloader({})
    downloader.to_screen = lambda msg: sys.stderr.write(msg + '\n')
    # Test titleformat with regex
    pp = MetadataFromTitlePP(downloader, r'%(title)s - %(artist)s')
    info = {'title': 'Title - Artist'}
    assert pp.run(info) == ([], {'title': r'Title - Artist', 'artist': r'Artist'})
    # Test titleformat without regex
    pp = MetadataFromTitlePP(downloader, r'Title - Artist')
    info = {'title': 'Title - Artist'}
    assert pp.run(info) == ([], {'title': r'Title - Artist'})
    # Test titleformat with incomplete

# Generated at 2022-06-12 19:15:22.563175
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import tempfile
    import os
    import shutil
    import unittest

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self._tmp_dir = tempfile.mkdtemp(prefix='youtube-dl-test_')

        def tearDown(self):
            shutil.rmtree(self._tmp_dir, ignore_errors=True)

        def test_basic(self):
            info = {'title': 'Custom Title - Custom Artist'}
            pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
            pp.run(info)
            self.assertEqual(info['title'], 'Custom Title')
            self.assertEqual(info['artist'], 'Custom Artist')


# Generated at 2022-06-12 19:15:33.187016
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .downloader import FakeDownloader

    class FakeYDL:
        def add_info_extractor(self, ie):
            pass

    ydl = FakeYDL()
    ydl_opts = {'simulate': True}

    # test for simple string
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    test_entry = {'title': 'Little Talks - Of Monsters And Men'}
    _, test_entry = pp.run(test_entry)
    assert test_entry['title'] == 'Little Talks'
    assert test_entry['artist'] == 'Of Monsters And Men'

    # test for regex string
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')

# Generated at 2022-06-12 19:15:37.398434
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl.YoutubeDL

    f = MetadataFromTitlePP(youtube_dl.YoutubeDL({}), "%(title)s - %(artist)s")
    f.run({'title': 'The title - The artist'})

# Generated at 2022-06-12 19:15:45.239399
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys

    # monkey patching to mock some imports
    class MockDownloader:
        def to_screen(self, msg):
            print(msg)
    class MockTrue:
        def groupdict(self):
            return {'title': 'title_value', 'artist': 'artist_value'}
    class MockFalse:
        def groupdict(self):
            return {'title': 'title_value'}

    sys.modules['youtube_dl.downloader'] = youtube_dl.downloader
    d = youtube_dl.downloader.Downloader(MockDownloader())
    pp = MetadataFromTitlePP(d, '%(title)s - %(artist)s')

# Generated at 2022-06-12 19:15:54.695063
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    mp = MetadataFromTitlePP(YoutubeDL({}), '%(artist)s - %(title)s')

    info = {'title': 'Adele - Hello'}
    result = mp.run(info)
    assert result[1]['artist'] == 'Adele'
    assert result[1]['title'] == 'Hello'

    info = {'title': 'The Exploited - Beat the Bastards'}
    result = mp.run(info)
    assert result[1]['artist'] == 'The Exploited'
    assert result[1]['title'] == 'Beat the Bastards'

    info = {'title': 'Adele - Hello - Blahblah'}
    result = mp.run(info)

# Generated at 2022-06-12 19:16:03.562443
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl.extractor.common import InfoExtractor

    class MockDownloader(object):
        def to_screen(self, msg):
            print(msg)

    class MockExtractor(InfoExtractor):
        def __init__(self, downloader = None):
            self.downloader = MockDownloader()
            self._type = None

        IE_DESC = (
            'This desc is used in _real_ extractor'
        )


# Generated at 2022-06-12 19:16:24.218669
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    Test for method MetadataFromTitlePP
    """
    import sys
    ydl = DummyYdl()
    fromtitle = MetadataFromTitlePP(ydl, '%(title)s.%(ext)s')
    # test None
    info = {}
    expected_info = {}
    expected_msgs = ""
    msgs, info = fromtitle.run(info)
    assert_equal(expected_info, info)
    assert_equal(expected_msgs.splitlines(), msgs)
    # test simple regex
    info = {'title': 'foo'}
    expected_info = {'title': 'foo'}
    expected_msgs = "INFO: [fromtitle] parsed title: foo"
    msgs, info = fromtitle.run(info)

# Generated at 2022-06-12 19:16:31.902567
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl
    import json

    # Prepare a downloader and an info dict
    ydl = youtube_dl.YoutubeDL()
    info = {"title": "title - artist"}

    # Test #1: classify name of video according to format %(title)s - %(artist)s
    pp = MetadataFromTitlePP(ydl, "%(title)s - %(artist)s")
    assert pp.run(info) == (None, {"title": "title", "artist": "artist"})

    # Test #2: classify name of video according to format %(title)s
    pp = MetadataFromTitlePP(ydl, "%(title)s")
    assert pp.run(info) == (None, {"title": "title - artist", "artist": None})

    # Test #3: classify name of video and show error

# Generated at 2022-06-12 19:16:41.411065
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import ydl_opts
    opts = ydl_opts.CopyOpts()

    temp_title = 'title'
    info = {'title': temp_title}

    # Test with format_to_regex
    m = MetadataFromTitlePP('dummy', '%(title)s')
    temp_regex = m.format_to_regex('%(title)s')
    m._titleregex = temp_regex
    info_result, info_expected = m.run(info), {'title': temp_title}
    assert info_result == info_expected

    # Test with titleformat
    m = MetadataFromTitlePP('dummy', '%(title)s')
    info_result, info_expected = m.run(info), {'title': temp_title}
    assert info_result

# Generated at 2022-06-12 19:16:52.927948
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    mdftpp = MetadataFromTitlePP(YoutubeDL(), '%(artist)s - %(title)s')
    assert mdftpp.run(
        {'title': 'foo - bar'}) == ([], {'artist': 'foo', 'title': 'bar'})
    assert mdftpp.run(
        {'title': '- foo - bar - baz -'}) == ([], {
            'artist': '- foo - bar - baz', 'title': '-'})
    assert mdftpp.run(
        {'title': '- foo - bar - baz -', 'artist': 'asdf'}) == ([], {
            'artist': 'asdf', 'title': '- foo - bar - baz -'})

# Generated at 2022-06-12 19:17:03.644451
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .compat import compat_http_client
    import tempfile

    metadataPP = MetadataFromTitlePP(FileDownloader({}),
                                     '%(title)s - %(artist)s')

    # Test title with single video
    info = {}
    info['title'] = 'Title - Artist'
    expected_info = {}
    expected_info['title'] = 'Title'
    expected_info['artist'] = 'Artist'

    [], info = metadataPP.run(info)
    assert info == expected_info

    # Test title with multiple media
    info = {}
    info['title'] = 'Title - Artist'
    expected_info = {}
    expected_info['title'] = 'Title'
    expected_info['artist'] = 'Artist'

    [], info = metadataPP

# Generated at 2022-06-12 19:17:06.034092
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    info = dict(
        title='Barenaked Ladies - One Week [Official Music Video]'
    )
    p = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    out, info = p.run(info)
    assert len(out) == 0
    assert info['artist'] == 'Barenaked Ladies'
    assert info['title'] == 'One Week [Official Music Video]'



# Generated at 2022-06-12 19:17:17.437524
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

# Generated at 2022-06-12 19:17:23.519206
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    Unit test for method run of class MetadataFromTitlePP
    """
    from .YoutubeDL import YoutubeDL

    def test_equals(test_info, expected_info):
        """
        This function check if info dictionary returned by run method of
        MetadataFromTitlePP is the same as the expected_info.
        """
        for key in test_info:
            assert key in expected_info, "info must contains key \"%s\"" % key
            assert test_info[key] == expected_info[key], \
                "info's value \"%s\" must be equal to \"%s\"" % \
                (test_info[key], expected_info[key])
        for key in expected_info:
            assert key in test_info, "info must contains key \"%s\"" % key


# Generated at 2022-06-12 19:17:28.836248
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class Downloader:
        def to_screen(self, msg):
            print(msg)
    class Info:
        def __init__(self, title):
            self.title = title
    d = Downloader()
    i = Info(title="test test")
    m = MetadataFromTitlePP(d, '%(test)s %(test)s')
    m.run(i)
    assert len(i.__dict__) == 1
    i = Info(title="test - test")
    m = MetadataFromTitlePP(d, '%(test)s - %(test)s')
    m.run(i)
    assert len(i.__dict__) == 1
    i = Info(title="test - test")

# Generated at 2022-06-12 19:17:35.477459
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import pytube
    from .common import FileDownloader
    from .compat import compat_str, compat_urllib_parse

    class MockYoutubeDL(object):
        # Pretend it's a valid URL
        def __init__(self, *args, **kwargs):
            self.params = kwargs['params']
            self.result = {
                'webpage_url': 'https://www.youtube.com/watch?v=' + self.params['v'],
                'title': 'Random Video Title',
                '_type': 'url',
            }
            self.to_screen_calls = []
            self.report_warning_calls = []
            self.report_error_calls = []
        def to_screen(self, message):
            self.to_screen_calls.append(message)

# Generated at 2022-06-12 19:18:03.217755
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.downloader import type_work
    class TestDownloader:
        def __init__(self):
            self.to_screen = print

        def to_screen(self, message):
            print(message)

    class TestInfo:
        def __init__(self, title):
            self.title = title

    # Test Scenario 1:
    #  - title format is "%(artist)s - %(title)s":
    #  - title is 'ARASHI - Monster'
    #  - expected result:
    #    - return info = {
    #       'artist': 'ARASHI', 'title': 'Monster'
    #    }
    fpp1 = MetadataFromTitlePP(TestDownloader(), "%(artist)s - %(title)s")

# Generated at 2022-06-12 19:18:12.408684
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import Downloader
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_request

    class FakeExtractor(InfoExtractor):
        IE_NAME = 'fakie'
        _TEST = {
            'url': 'http://fakie.com/video/01.html',
            'info_dict': {
                'title': 'fakie - Test video 01',
                'artist': 'fakie_artist',
                'album': 'fakie_album',
                'track_number': 1,
            }
        }


# Generated at 2022-06-12 19:18:22.907089
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FakeDownloader
    from .compat import compat_str
    dl = FakeDownloader()
    pp = MetadataFromTitlePP(dl, r'%(title)s (by %(artist)s)')

    # Simple matching
    d = {
        'title': 'Hello (by World)'
    }
    pp.run(d)
    assert d == {
        'title': 'Hello',
        'artist': 'World'
    }

    # No matching
    d = {
        'title': 'Hello World'
    }
    pp.run(d)
    assert d == {
        'title': 'Hello World'
    }
    assert dl._msgs == []

    # Multiple matches

# Generated at 2022-06-12 19:18:28.011921
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata = {
        'title': 'Titre - Auteur',
        'upload_date': '20190628',
        'creator': None,
    }
    format_ = '%(title)s - %(creator)s'
    converter = MetadataFromTitlePP(None, format_)
    assert converter._titleformat == format_
    assert converter._titleregex == '(?P<title>.+)\ \-\ (?P<creator>.+)'

    res, metadata = converter.run(metadata)
    assert metadata['title'] == 'Titre'
    assert metadata['creator'] == 'Auteur'



# Generated at 2022-06-12 19:18:36.062779
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    #sys.argv = [sys.argv[0], 'ytsearch10:title_is_artist']
    import youtube_dl

    class DummyYDL(object):
        def to_screen(self, msg):
            pass

    ydl_opts = {
        'writethumbnail': False,
        'writeinfojson': False,
        'skip_download': True,
        'format': 'bestaudio/best',
        'postprocessors': [{
            'key': 'MetadataFromTitle',
            'format': '%(artist)s - %(title)s'
        }],
        'logger': DummyYDL(),
        'progress_hooks': [],
    }

# Generated at 2022-06-12 19:18:45.504130
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL

    # First test: Check if the post-processor can interpret the default format
    # of output template "%(title)s-%(id)s.%(ext)s" and assign the correct
    # metadata to the info dict.
    #
    # Example:
    #     'title': 'Foo-id0id.mp4'
    # is transformed to:
    #     'title': 'Foo'
    #     'id': 'id0id'
    info = {'title': 'Foo-id0id.mp4'}
    titleformat = '%(title)s-%(id)s.%(ext)s'

    postprocessor = MetadataFromTitlePP(YoutubeDL(), titleformat)
    postprocessor.run(info)


# Generated at 2022-06-12 19:18:55.945149
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import ydl_test_support
    ydl = ydl_test_support.FakeYDL({})


# Generated at 2022-06-12 19:19:02.401470
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class FakeYDL:
        def __init__(self):
            self.to_screen_count = 0

        def to_screen(self, str):
            self.to_screen_count += 1
            pass

    info = {'title': 'Category:Videos of cats in water'}
    format = '%(category)s:%(videos)s of %(animals)s in %(environment)s'
    ydl = FakeYDL()
    pp = MetadataFromTitlePP(ydl, format)

    pp.run(info)

    assert info == {
        'title': 'Category:Videos of cats in water',
        'category': 'Category',
        'videos': 'Videos',
        'animals': 'cats',
        'environment': 'water'
    }
    assert ydl.to_screen

# Generated at 2022-06-12 19:19:10.115604
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class TestDownloader():
        def to_screen(self, text): pass

    class TestInfo():
        pass

    titleformat = '%(title)s - %(artist)s'
    title = 'a title - an artist'
    info = TestInfo()
    info.title = title
    pp = MetadataFromTitlePP(TestDownloader(), titleformat)
    # assert that the info dict is unchanged by pp.run
    oldinfo = dict(info.__dict__)
    pp.run(info)
    assert info.__dict__ == oldinfo
    # assert that the run method populates the info object according to the titleformat
    pp.run(info)
    assert info.__dict__['artist'] == 'an artist'
    assert info.__dict__['title'] == 'a title'

# Generated at 2022-06-12 19:19:19.245150
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor.common import InfoExtractor

    downloader = FileDownloader({})
    downloader.add_info_extractor(InfoExtractor())
