

# Generated at 2022-06-12 19:10:10.019454
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from .common import FakeYDL

    ydl = FakeYDL()
    pp = MetadataFromTitlePP(ydl,
        '%(title)s - %(artist)s - %(year)s')

    # test: no match
    title = 'my title'
    info = {'title': title}
    expected = 'Could not interpret title of video as "%s"' % pp._titleformat
    ret = pp.run(info)
    assert(ret == ([], info))
    assert(('info', expected) in ydl.msgs)
    ydl.msgs = []

    # test: regex match
    title = 'my title - my artist - my year'
    info = {'title': title}
    ret

# Generated at 2022-06-12 19:10:16.804481
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl.downloader

    pp = MetadataFromTitlePP(youtube_dl.downloader.FileDownloader(),
                             '(?P<artist>.+)\ \-\ (?P<title>.+)')
    info = {'title': 'MÃ¶tley CrÃ¼e - Dr. Feelgood'}
    pp.run(info)
    assert info['title'] == 'Dr. Feelgood'
    assert info['artist'] == 'MÃ¶tley CrÃ¼e'


# Generated at 2022-06-12 19:10:21.822589
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl import YoutubeDL
    class TestDownloader(YoutubeDL):
        def __init__(self, *args, **kargs):
            super(TestDownloader, self).__init__(*args, **kargs)
            self.to_screen_buffer = []

        def to_screen(self, msg):
            if msg is not None:
                self.to_screen_buffer.append(msg)

    my_downloader = TestDownloader()
    my_postprocessor = MetadataFromTitlePP(
        my_downloader, '%(artist)s - %(title)s')
    info = {'title': 'foo - bar'}
    my_postprocessor.run(info)

    assert info['title'] == 'foo - bar'
    assert info['artist'] == 'foo'


# Generated at 2022-06-12 19:10:29.729668
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    obj = MetadataFromTitlePP(None, None)
    assert obj.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert obj.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert obj.format_to_regex('%(title)s - %(artist)s - %(uploader)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<uploader>.+)'

# Generated at 2022-06-12 19:10:40.200576
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .extractor import gen_extractors
    gen_extractors()
    from .common import FileDownloader
    downloader = FileDownloader(None, force_generic_extractor=True)
    pp = MetadataFromTitlePP(downloader, '')
    assert pp.format_to_regex('') == ''
    assert pp.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-12 19:10:48.060653
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import io

    class DummyYoutubeDL():
        def __init__(self):
            self.to_screen_buffer = io.StringIO()
            self._err_buffer = io.StringIO()
            self.params = {}
            self.result = []
            self.processed_info_dicts = []
            self.title_format = '%(title)s'
            self.title_regex = self.format_to_regex(self.title_format)
            self.has_been_run = False

        def to_screen(self, message, skip_eol=False):
            print(message, file=self.to_screen_buffer, end='\n' if not skip_eol else '')


# Generated at 2022-06-12 19:10:55.791416
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ..YoutubeDL import YoutubeDL
    from .common import FakeYDL
    from .extractor.common import InfoExtractor

    class TestIE(InfoExtractor):
        def _real_extract(self, url):
            ie = self
            return {
                'id': 'TestID',
                'title': 'test_title',
                'formats': 'test_formats',
                '_type': 'url',
                'ie_key': ie.ie_key,
            }

    ie = TestIE()
    ie.ie_key = 'TestIE'
    ie.extractor = None
    fydl = FakeYDL()
    fydl._ies.append(ie)


# Generated at 2022-06-12 19:11:05.852509
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import ytdl_manager
    import ytdl_manager.postprocessor.common
    import ytdl_manager.extractor.common
    downloader = ytdl_manager.postprocessor.common.Downloader()
    metadataFromTitlePP = MetadataFromTitlePP(downloader,
            "Artist - Album Track - Title")
    ytdl_manager.extractor.common.InfoExtractor = object

# Generated at 2022-06-12 19:11:16.032653
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    from ytdl.YoutubeDL import YoutubeDL

    class DummyYoutubeDL(YoutubeDL):
        def __init__(self, params, out=sys.stdout):
            # we only override one of YoutubeDL's methods
            super(DummyYoutubeDL, self).__init__(params)
            self.to_screen = lambda msg: out.write(msg + '\n')

    # test result of method run
    class TestParams:
        metadatafromtitle = '%(artist)s - %(title)s [%(genre)s]'
    expected = {'title': 'Expected Title', 'artist': 'Expected Artist',
                'genre': 'Expected genre'}
    info = {'title': 'Expected Artist - Expected Title [Expected genre]'}
    downloader = Dummy

# Generated at 2022-06-12 19:11:24.022037
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import os

    import youtube_dl
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    def download(ydl, url, test_filename):
        ydl.add_default_info_extractors()
        ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s'))
        result_filename = os.path.join(ydl.ydl_opts['outtmpl'], test_filename)
        ydl.to_stderr = lambda s: None
        info = ydl.extract_info(url, download=False)
        ydl.process_ie_result(info, download=True)
        metadata = ydl.extract_info(result_filename, download=False)
        return metadata

    # expected

# Generated at 2022-06-12 19:11:32.457254
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftpp = MetadataFromTitlePP(None, None)
    assert (mftpp.format_to_regex('%(title)s - %(artist)s (%(year)s)')
            == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \((?P<year>.+)\)')
    assert (mftpp.format_to_regex('%(title)s - %(artist)s')
            == r'(?P<title>.+)\ \-\ (?P<artist>.+)')
    assert (mftpp.format_to_regex('%(title)s')
            == r'(?P<title>.+)')

# Generated at 2022-06-12 19:11:42.775114
# Unit test for constructor of class MetadataFromTitlePP

# Generated at 2022-06-12 19:11:49.354549
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import subprocess
    import sys
    if sys.platform in ['win32', 'win64']:
        command = ["py.test", "--cov", "--cov-report", "term-missing", "--cov", "youtube_dl"]
    else:
        command = ["py.test", "--cov", "--cov-report", "term-missing", "--cov", "youtube_dl"]
    subprocess.call(command)

# Generated at 2022-06-12 19:11:57.847857
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from ..YoutubeDL import YoutubeDL
    assert re.match(
        YoutubeDL(dict()).process_info(dict(title='test title'))[1]['titleregex'],
        'test title')
    assert re.match(
        YoutubeDL(dict(title='%(title)s')).process_info(dict(title='test title'))[1]['titleregex'],
        'test title')
    assert re.match(
        YoutubeDL(dict(title='%(title)s')).process_info(dict(title='simple test title'))[1]['titleregex'],
        'simple test title')

# Generated at 2022-06-12 19:12:07.154630
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    import unittest
    suite = unittest.TestSuite()

# Generated at 2022-06-12 19:12:14.442159
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessorError
    for format, regex in [
            ('%(title)s', '(?P<title>.+)'),
            ('%(title)s-%(artist)s', '(?P<title>.+)\-(?P<artist>.+)')]:
        pp = MetadataFromTitlePP(YoutubeDL(), format)
        assert pp._titleregex == regex, \
            'expected "%s", got "%s"' % (regex, pp._titleregex)


# Generated at 2022-06-12 19:12:22.863386
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import subprocess
    from youtube_dl.YoutubeDL import YoutubeDL

    mp3_path = 'data/test.mp3'
    mp3_size = int(subprocess.Popen(
        'ffprobe -i "%s" -show_entries format=size -v quiet -of csv="p=0"' % mp3_path,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        shell=True).communicate()[0])

# Generated at 2022-06-12 19:12:33.484268
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class InfoDictMock:
        pass
    # Mock class to simulate youtube_dl.YoutubeDL
    class YoutubeDLMock:
        def __init__(self):
            self.to_screen_text = ''
        def to_screen(self, text):
            self.to_screen_text = text
        def to_screen_n(self, text):
            self.to_screen_text = text
    class DictTestDict:
        pass
    ydl = YoutubeDLMock()
    mft = MetadataFromTitlePP(ydl, '%(title)s')
    info = InfoDictMock()
    info.title = 'video title'
    info.artist = 'John Doe'
    mft.run(info)
    assert info.title == 'video title'

# Generated at 2022-06-12 19:12:43.217425
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-12 19:12:54.653986
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.downloader import YoutubeDL
    from youtube_dl.postprocessor import MetadataFromTitlePP

    def test_postprocessor(info):
        if not all(k in info for k in ('title','artist','album')):
            return [], False
        else:
            return [], True

    ydl = YoutubeDL(params={'verbose': False, 'simulate': True})
    ydl._postprocessors = [MetadataFromTitlePP(ydl, '%(title)s - %(artist)s'), test_postprocessor]

    info = {'title': 'this is the title - this is the artist'}
    assert ydl.process_ie_result(info, download=True) == True

    info = {'title': 'this is the title - this is the artist - this is the album'}

# Generated at 2022-06-12 19:13:04.196749
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import pytube

    downloader = pytube.YoutubeDL({})
    downloader.to_screen = lambda x: x

    pp_title_regex = (r'^(?P<series>.+)\ (?P<season>\d+)\ '
                      r'(?P<episode>\d+)\ (?P<subtitle>.+)\ \-\ '
                      r'(?P<episode_title>.+)\ (?P<year>\d+)$')
    pp_title_num_regex = r'^First Episode \((?P<year>\d+)\)$'
    pp_artist_regex = r'^(?P<artist>.+) - (?P<song_title>.+)$'

# Generated at 2022-06-12 19:13:14.194368
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import youtube_dl
    class MockYD(object):
        def to_screen(self, msg):
            print(msg, file=sys.stdout)
    downloader = MockYD()

    current_test_num = 0
    def test(title, titleformat, **expected_info):
        global current_test_num
        current_test_num += 1
        print('[test case %d]' % current_test_num)
        info = {'title': title}
        pp = MetadataFromTitlePP(downloader, titleformat)
        _, info = pp.run(info)
        assert info == expected_info
        return

    # Test cases:
    # <expected output, input>

# Generated at 2022-06-12 19:13:24.954729
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    fake_downloader = {
        'to_screen': lambda *args: print(args)
    }
    pp = MetadataFromTitlePP(downloader=fake_downloader, titleformat='%(artist)s - %(title)s')
    info = {
        'title': 'Action Bronson - Larry Csonka (feat. Mayhem Lauren)',
    }
    errs, info2 = pp.run(info)

    assert info == {
        'title': 'Action Bronson - Larry Csonka (feat. Mayhem Lauren)',
    }

    assert info2 == {
        'title': 'Action Bronson - Larry Csonka (feat. Mayhem Lauren)',
        'artist': 'Action Bronson',
        'title': 'Larry Csonka (feat. Mayhem Lauren)',
    }


# Generated at 2022-06-12 19:13:34.194337
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import tempfile
    import shutil
    import os
    import ydl_opts
    from ydl.utils import encodeFilename

    test_dir_name = tempfile.mkdtemp('_test_download', 'youtube_dl_')
    test_video = {'id': 'test_video', 'title': 'Extract Test - YouTube',
                  'url': 'www.youtube.com/watch?v=test_video',
                  'requested_formats': [{'format_id': 'test_format',
                                         'format': 'test_format',
                                        'filesize': '100000',
                                        'ext': 'mp4',
                                        'url': 'www.youtube.com/watch?v=test_video'}],
                  '_filename': 'test_video.mp4'}
    opts = y

# Generated at 2022-06-12 19:13:42.755511
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl
    from types import ModuleType
    # fake downloader
    class FakeYDL:
        def __init__(self):
            self.to_screen_list = []
        def to_screen(self, msg):
            self.to_screen_list.append(msg)

    FakeModule = ModuleType('youtube_dl')
    FakeModule.utils = youtube_dl.utils
    fake_ydl = FakeYDL()
    fake_ydl.params = {}

    metadata_from_title = MetadataFromTitlePP(fake_ydl, 'Test - title')
    format_filename = metadata_from_title.format_filename

    # no title at all
    video_info = {
        'title' : 'abc',
        'artist' : 'def'
    }
    # run
    metadata_from_

# Generated at 2022-06-12 19:13:52.750587
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl_server.core import Downloader
    from ytdl_server.extractor import YoutubeIE
    from ytdl_server.extractor.common import InfoExtractor

    ie = InfoExtractor(Downloader())
    ie.set_downloader(Downloader())
    ie.add_info_extractor(YoutubeIE())

    info = ie.extract('https://www.youtube.com/watch?v=pzI1F8O_Oss')
    pp = MetadataFromTitlePP(Downloader(), '%(title)s - %(uploader)s')

# Generated at 2022-06-12 19:14:04.481657
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import os.path

    argv = ['--ignore-config', '-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best',
            '--output', '%(title)s-%(id)s.%(ext)s', '--merge-output-format',
            'mkv', '--metadata-from-title', '%(title)s - %(artist)s']

    path_to_testdata_dir = os.path.join(os.path.dirname(os.path.abspath(
        __file__)), "testdata")
    path_to_testdata_file = os.path.join(path_to_testdata_dir, "testdata.yml")
    title = 'title_to_be_replaced'

# Generated at 2022-06-12 19:14:15.444101
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    ydl = YoutubeDL()
    ydl.downloader.postprocessors.append(MetadataFromTitlePP(ydl, '%(artist)s - %(title)s %(blah)s'))
    ydl.downloader.params.update({
        'simulate': True
    })

    result = ydl.extract_info('http://www.youtube.com/watch?v=BaW_jenozKc', download=False)

    assert result['artist'] == 'Hans Zimmer'
    assert result['title'] == 'Time'

    ydl.downloader.postprocessors = []
    ydl.downloader.postprocessors.append(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s'))


# Generated at 2022-06-12 19:14:26.223583
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Given method run of class MetadataFromTitlePP is
    # defined by the regular expression '%\((?P<title>.+)\)\s-'

    # If a string 'abc - def' is passed to the method
    result = MetadataFromTitlePP(None, '%(title)s -').run({
        'title': 'abc - def',
    })

    # then the method returns no errors
    assert result == ([], {
        'title': 'abc',
    })

    # and if a string 'abc - def - ghi' is passed to the method
    result = MetadataFromTitlePP(None, '%(title)s -').run({
        'title': 'abc - def - ghi',
    })

    # then the method returns no errors

# Generated at 2022-06-12 19:14:36.989775
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    def assert_metafromtitle(titleformat, title, expected, assert_error_message=None):
        """
        Asserts that the given titleformat correctly extracts title information
        from the given title.
        """
        downloader = FakeFD()
        downloader.to_screen = lambda x: x
        downloader.to_screen = lambda x: x
        info = {}
        titleformat = ('%(id)s' if titleformat is None else titleformat)
        info['title'] = title
        result = MetadataFromTitlePP(downloader, titleformat).run(info)
        if assert_error_message is None:
            assert expected == info
        else:
            assert expected == info, assert_error_message

    yield assert_metafromtitle, None, 'X', {'id': 'X'}

# Generated at 2022-06-12 19:14:45.059721
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class DummyDownloader():
        def to_screen(self, msg):
            return

    pp = MetadataFromTitlePP(DummyDownloader(), '%(genre)s - %(artist)s - %(song)s')
    info = {'title': 'jazz - John Smith - What a wonderful world'}
    pp.run(info)
    assert info['genre'] == 'jazz'
    assert info['artist'] == 'John Smith'
    assert info['song'] == 'What a wonderful world'

    pp = MetadataFromTitlePP(DummyDownloader(), '%(genre)s - %(artist)s - %(song)s')
    info = {'title': 'jazz'}
    pp.run(info)
    assert not info['genre']
    assert not info['artist']

# Generated at 2022-06-12 19:14:56.078535
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    try:
        import json
    except ImportError:
        import simplejson as json

    # Init the PP
    pp = MetadataFromTitlePP(None, '%(title)s-%(artist)s-%(album)s')

    # Set a video title
    video_title = 'Title-Artist-Album'
    video_info = {'title': video_title}

    # Run MetadataFromTitlePP
    error_list, pp_output = pp.run(video_info)

    # Check if the PP failed
    assert len(error_list) == 0, (
        ('test_MetadataFromTitlePP_run returned %s expected 0'
         + os.linesep + 'Output: %s')
        % (error_list, json.sanitize(pp_output)))

    # Check if the PP extracted the

# Generated at 2022-06-12 19:15:00.843305
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl.extractor.youtube import YoutubeIE
    youtube_dl = YoutubeDL({'skip_download': True})
    info = {'title': 'Song - Artist'}
    assert MetadataFromTitlePP(youtube_dl, '%(title)s - %(artist)s').run(info)[1] == {
        'title': 'Song',
        'artist': 'Artist',
        'title': 'Song - Artist'}
    assert MetadataFromTitlePP(youtube_dl, '%(title)s').run(info)[1] == {
        'title': 'Song - Artist',
        'title': 'Song - Artist'}

# Generated at 2022-06-12 19:15:09.256995
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import Downloader
    downloader = Downloader()
    pp = MetadataFromTitlePP(downloader, '%(title)s-%(artist)s-%(album)s')
    info = {'title': 'title-artist-album'}

    (result, info) = pp.run(info)
    assert result == []
    assert info['title'] == 'title'
    assert info['artist'] == 'artist'
    assert info['album'] == 'album'

    info = {'title': 'title-artist-'}
    (result, info) = pp.run(info)
    assert result == []
    assert info['title'] == 'title'
    assert info['artist'] == 'artist'
    assert 'album' not in info


# Generated at 2022-06-12 19:15:19.163026
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Mocked up downloader
    def to_screen(message):
        print(message)
    from ..utils import FakeYDL
    downloader = FakeYDL()
    downloader.to_screen = to_screen
    # Test metadata extraction
    titleformats = [
        '%(title)s - %(artist)s',
        '%(title)s - %(artists)s'
    ]
    titles = [
        'Horizon - Sick Individuals, DBSTF',
        'Horizon - Sick Individuals feat. DBSTF'
    ]
    for titleformat in titleformats:
        p = MetadataFromTitlePP(downloader, titleformat)

# Generated at 2022-06-12 19:15:30.773415
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # test to match a string like '%(title)s - %(artist)s'
    titleformat = '%(title)s - %(artist)s'
    titleregex = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    title = 'Numb - Linkin Park'
    title_match = re.match(titleregex, title)
    title_match_dict = title_match.groupdict() if title_match is not None else None
    assert title_match_dict == {'title': 'Numb', 'artist': 'Linkin Park'}, 'ERROR: not matched'

    pp = MetadataFromTitlePP(None, titleformat)
    info = {'title': title}
    (formats, info_ret) = pp.run(info)

# Generated at 2022-06-12 19:15:31.927176
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # TODO: write test for method run
    assert(0)



# Generated at 2022-06-12 19:15:37.398785
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Testcase of description of the function
    titleformat = "%(title)s - %(artist)s"
    expected = {'title': "Some title", "artist": "Some artist"}
    title = "Some title - Some artist"
    pp = MetadataFromTitlePP(None, titleformat)
    result = dict()
    pp.run({'title': title})
    assert result == expected

# Generated at 2022-06-12 19:15:45.239472
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    titleformat = '%(title)s (%(year)s)'
    title = 'Video Title (2017)'
    info = {'title': title}
    pp = MetadataFromTitlePP(None, titleformat)
    assert isinstance(pp, PostProcessor)
    assert pp.format_to_regex(titleformat) == '(?P<title>.+)\ \((?P<year>\\d{4})\)'
    assert pp._titleregex == '(?P<title>.+)\ \((?P<year>\d{4})\)'
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-12 19:15:54.702053
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    # Mock a downloader object
    class MockDownloader():
        def to_screen(self, s):
            print(s)

    downloader = MockDownloader()
    fmt = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(downloader, fmt)

    # Mock an information object
    class MockInfo():
        def __init__(self, title):
            self.title = title
            self.format = 'm4a'
            self.ext = 'm4a'

        def __getitem__(self, key):
            return self.__dict__[key]

        def __setitem__(self, key, value):
            self.__dict__[key] = value

    info = MockInfo('title - artist')

    pp.run(info)


# Generated at 2022-06-12 19:16:06.576857
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest
    import sys
    import os
    if os.path.isdir(os.path.expanduser('~') + '/unittest'):
        os.chdir(os.path.expanduser('~') + '/unittest')
    else:
        os.chdir(os.path.dirname(__file__))
    sys.path.append(os.getcwd())
    from youtube_dl.YoutubeDL import YoutubeDL

    class FakeDownloader():
        def to_screen(self, msg):
            print(msg)

    class FakeInfoDict():
        def __init__(self, title, **kwargs):
            self['title'] = title
            for k, v in kwargs.items():
                self[k] = v


# Generated at 2022-06-12 19:16:14.493924
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest

    class MockInfoDict(dict):

        def __init__(self):
            super(MockInfoDict, self).__init__()

        def __str__(self):
            string = ''
            for key, value in self.items():
                string += '\n' + str(key) + ': ' + str(value)
            return string

    class MockDownloader():
        def to_screen(self, message):
            print(message)

    downloader = MockDownloader()
    info = dict(title='')

    title_formats = [
        '',
        '%(title)s',
        '%(title)s - %(artist)s'
    ]


# Generated at 2022-06-12 19:16:26.595123
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    downloader = 'dummy'
    titleformat = '%(title)s - [%(id)s] - %(%(unmatched_key)s)s'

    def to_screen(self, message):
        print(message)

    downloader.to_screen = to_screen

    pp = MetadataFromTitlePP(downloader, titleformat)

    info = {
        'title': 'abc [def] - [ghi] - 123 - [jkl] - [mno]',
    }

    # Run, expect no exception raised
    pp.run(info)

    # Test the results

# Generated at 2022-06-12 19:16:38.603889
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    class DownloaderMock(object):
        def to_screen(self, msg):
            pass
    dlmock = DownloaderMock()
    pp = MetadataFromTitlePP(dlmock, '%(title)s - %(artist)s')
    assert pp.run({'title': 'abc - def', 'format': 'mp3'}) == ([], {'title': 'abc', 'artist': 'def', 'format': 'mp3'})
    assert pp.run({'title': 'abc', 'format': 'mp3'}) == ([], {'title': 'abc', 'format': 'mp3'})
    pp = MetadataFromTitlePP(dlmock, '%(title)s - %(artist)s')

# Generated at 2022-06-12 19:16:50.924877
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.downloader.common import FileDownloader
    downloader = FileDownloader(params={'noprogress': True})
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    info = {'title': 'Title - Artist'}
    res, info = pp.run(info)
    assert len(res) == 0
    assert info['title'] == 'Title'
    assert info['artist'] == 'Artist'

    downloader = FileDownloader(params={'noprogress': True})
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    info = {'title': 'Not Matching'}
    res, info = pp.run(info)
    assert len(res) == 0

# Generated at 2022-06-12 19:17:03.307078
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-12 19:17:08.941350
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class MockDownloader:
        def to_screen(self, msg):
            pass
    assert MetadataFromTitlePP(MockDownloader, '%(title)s - %(artist)s').run({'title': 'Song title - Artist name'}) == ([], {'artist': 'Artist name', 'title': 'Song title'})
    assert MetadataFromTitlePP(MockDownloader, '%(title)s - %(artist)s').run({'title': 'Song title - Artist name - Ft. guest'}) == ([], {'artist': 'Artist name', 'title': 'Song title'})

# Generated at 2022-06-12 19:17:18.618779
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .ytdl_mock import DownloaderMock
    from .extractor_mock import InfoExtractorMock

    def do_test(titleformat, expected_res, expected_title):
        title = 'foo'
        ydl = DownloaderMock()
        ie = InfoExtractorMock(ydl)
        ie.title = title
        pp = MetadataFromTitlePP(ydl, titleformat)
        res, info = pp.run({'title': title})
        assert res == []
        assert info['title'] == expected_title
        for attribute in expected_res:
            assert attribute in info
            assert info[attribute] == expected_res[attribute]

    do_test('%(title)s', {'title': 'foo'}, 'foo')

# Generated at 2022-06-12 19:17:27.344640
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    Method to test run method of MetadataFromTitlePP class
    """
    class FakeInfoDict(dict):
        """
        Class to fake usage of youtube_dl.utils.dict_Objective
        """
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.filename = None

    class FakeYoutubeDL():
        """
        Class to fake usage of youtube_dl.YoutubeDL
        """
        to_screen_list = []
        def to_screen(self, message):
            """
            Method to mock to_screen method of youtube_dl.YoutubeDL
            """
            self.to_screen_list.append(message)


# Generated at 2022-06-12 19:17:34.212275
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import ydl_opts as opts
    from .common import FileDownloader
    from .extractor import gen_extractors

    # Check if method run of class MetadataFromTitlePP
    # successfully parse information from an input string
    # and return a dictionary with the parsed information
    # as keys and their value.
    # The test is done by comparing the output of run of
    # MetadataFromTitlePP to an expected result.

    # Create extractor
    ydl = FileDownloader({'outtmpl': '%(id)s',
                          'postprocessors': [MetadataFromTitlePP(
                              ydl, '%(artist)s - %(song)s')],
                          'quiet': True})
    ydl.add_info_extractor(gen_extractors()[0])

   

# Generated at 2022-06-12 19:17:53.103434
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    class MockDl:
        def to_screen(self, msg): print(msg)
    class MockPP:
        def run(self, info): return [], info
    dl = MockDl()
    from ytdl_conf import fromtitle
    pp_1 = MetadataFromTitlePP(dl, fromtitle)
    pp_2 = MockPP()
    info = { 'title': 'MARINA AND THE DIAMONDS - PRIMADONNA (OFFICIAL MUSIC VIDEO)' }
    pp_1.run(info)
    pp_2.run(info)

if __name__ == '__main__':
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-12 19:18:01.368515
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    postprocessor = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    info = dict()
    info['title'] = 'This is a title - Some Artist'
    test, res = postprocessor.run(info)
    assert res['title'] == 'This is a title'
    assert res['artist'] == 'Some Artist'
    info = dict()
    info['title'] = 'Title only, no artist'
    test, res = postprocessor.run(info)
    assert res['title'] == 'Title only, no artist'
    assert 'artist' not in res

# Generated at 2022-06-12 19:18:12.053742
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .compat import compat_urllib_request


# Generated at 2022-06-12 19:18:22.488155
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import pytest
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.generic import GenericIE

    ydl = YoutubeDL({})
    ydl.add_info_extractor(GenericIE())
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s'))


# Generated at 2022-06-12 19:18:33.789714
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl.extractor.common import YoutubeIE
    from ytdl.config import DataDownloader
    #
    # test with a regex
    #
    regex = '.*(?P<videotype>blabla)_.*'
    pp = MetadataFromTitlePP(None, regex)
    result = pp.run({'title': '*&@(#blabla_+))'})
    assert result == ([], {'title': '*&@(#blabla_+))', 'videotype': 'blabla'})

    result = pp.run({'title': '*&@(#blablabla_+))'})  # no match
    assert result == ([], {'title': '*&@(#blablabla_+))'})
    #
    # test with a '

# Generated at 2022-06-12 19:18:43.303413
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from collections import namedtuple

    from .extractor import YoutubeIE
    from .downloader import FileDownloader

    def _downloader_build_default_opts(self):
        return namedtuple('Options', ['metadatafromtitle'])(
            metadatafromtitle='%(artist)s - %(title)s')

    info = {}
    info['title'] = 'Lana Del Rey - Cola (Official Music Video)'
    info['extractor'] = 'youtube'
    info['id'] = 'cNHZfe7aZec'
    info['ext'] = 'webm'

    FileDownloader.build_default_opts = _downloader_build_default_opts

    youtube_ie = YoutubeIE()
    pp = MetadataFromTitlePP(youtube_ie, '%(artist)s - %(title)s')


# Generated at 2022-06-12 19:18:52.988952
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ..utils import DateRange

    downloader = None
    infos = [{
        'id': 'OQSNhk5ICTI',
        'title': 'Taylor Swift - Back To December',
        'categories': ['Music'],
        'upload_date': DateRange('20110120', '20110121'),
        'uploader_id': 'TaylorSwiftVEVO',
        'uploader': 'TaylorSwiftVEVO',
        'uploader_url': r're:https?://(?:www\.)?youtube.com/user/TaylorSwiftVEVO',
        'uploader_location': None,
    }]

    def my_report_warning(self, msg):
        print('Warning: %s' % msg)


# Generated at 2022-06-12 19:19:00.730878
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # pylint: disable=unused-argument,redefined-outer-name,missing-docstring
    import unittest
    from collections import namedtuple

    class FakeInfo:
        def __init__(self, title):
            self.title = title

    class FakeDownloader:
        def __init__(self):
            self.msgs = []

        def to_screen(self, msg):
            self.msgs.append(msg)

    class FakePostProcessor:
        def __init__(self, expected_title):
            self.expected_title = expected_title
            self.info = None

        def run(self, info):
            self.info = info
            assert info['title'] == self.expected_title
            return [], info


# Generated at 2022-06-12 19:19:09.228476
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    def _test_title(title, metadata={}, titleformat=None, expect_error=False):

        class FakeInfoDict(object):
            def __init__(self, title, metadata):
                self.title = title
                for m in metadata:
                    self.__setattr__(m, metadata[m])

        class FakeYDL(object):
            def to_screen(self, message):
                assert not expect_error
                pass

        titleformat = (titleformat
                       if titleformat
                       else '%(title)s - %(artist)s')

        metadata_from_title = MetadataFromTitlePP(FakeYDL(), titleformat)

        assert metadata_from_title._titleformat == titleformat

        info = FakeInfoDict(title, {})
        _, info = metadata_from_title.run(info)



# Generated at 2022-06-12 19:19:13.613785
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata = {'title': 'my title - Foo Fighters'}
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    _, metadata_output = pp.run(metadata)
    assert metadata_output['title'] == 'my title'
    assert metadata_output['artist'] == 'Foo Fighters'

# Generated at 2022-06-12 19:19:41.939532
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    info = {'title': '1234 - 5678'}
    expected_info = {'title': '1234', 'artist': '5678'}
    metadata_from_title_pp.run(info)
    assert info == expected_info


# Generated at 2022-06-12 19:19:47.961449
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # common func
    set_title = lambda title: lambda info: (info['title'] if title is None else title)
    # test1: match method
    test1_regex_format = r'^.+\ \-\ .+$'
    test1_title = '01 - artist name'
    test1_author, test1_album = 'artist name', None
    test1_titleformat = '%(author)s - %(album)s'
    test1_pp = MetadataFromTitlePP(None, test1_titleformat)
    info = {'title': test1_title}
    assert(test1_pp.run([], info)[1] == {'title': test1_title})

# Generated at 2022-06-12 19:19:58.162428
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # create a class instance
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    # test if the accessor class works correctly
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    # execute the run method
    info = {'title': 'A test title - by a test artist'}
    _, info = pp.run(info)
    # check if the run method worked correctly
    assert info['title'] == 'A test title'
    assert info['artist'] == 'by a test artist'

    # execute the run method again with a different title
    info['title'] = 'A different title - by the test artist'
    _,