

# Generated at 2022-06-12 19:10:02.852573
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class DummyDownloader():
        def to_screen(self, message):
            print(message)

    pp = MetadataFromTitlePP(DummyDownloader(), '%(title)s - %(artist)s')
    info = {}
    info['title'] = 'Some long title - Plus another one - By someone'
    items, info = pp.run(info)
    assert info['title'] == 'Some long title'
    assert info['artist'] == 'Plus another one'
    # TODO: Check next regex
    #info = {}
    #pp = MetadataFromTitlePP(DummyDownloader(), '')
    #pp.run(info)

# Generated at 2022-06-12 19:10:10.260905
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # import method run of class MetadataFromTitlePP
    from youtube_dl.postprocessor import MetadataFromTitlePP

    # create class variable info
    info = {
        'title': 'Normal Title'
    }

    # create class variable titleformat
    titleformat = '%(title)s'

    # create instance PP
    pp = MetadataFromTitlePP(None, titleformat)

    # call method run of class MetadataFromTitlePP
    pp.run(info)

    # evaluate result
    assert info['title'] == 'Normal Title'

# Generated at 2022-06-12 19:10:20.028608
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    ydl.params['simulate'] = True
    ydl.params['forcejson'] = True
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s.%(ext)s'))
    info = None
    for i in ydl.extract_info('http://youtube.com/watch?v=BaW_jenozKc', download=False):
        info = i
    assert info['title'] == 'test'
    assert info['ext'] == 'webm'
    ydl = YoutubeDL()
    ydl.params['simulate'] = True
    ydl.params['forcejson'] = True

# Generated at 2022-06-12 19:10:26.006436
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest
    import tempfile
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor import get_info_extractor

    class Capture(object):
        def __init__(self):
            self.output = []

        def to_screen(self, msg):
            self.output.append(msg)

    class TestPostProcessor(unittest.TestCase):
        def setUp(self):
            self.ydl = YoutubeDL()
            self.ydl_opts = {}
            self.ydl.params['outtmpl'] = '%(id)s'
            self.ydl.to_screen = self.capture.to_screen

        def test_run(self):
            ie = get_info_extractor('youtube')

# Generated at 2022-06-12 19:10:37.547561
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import tempfile
    import unittest
    from ytdl.YoutubeDL import YoutubeDL

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, *args, **dargs):
            self.to_screen_called = False
            self.to_screen_message = ''
            super(MockYoutubeDL, self).__init__(*args, **dargs)
        def to_screen(self, *args, **dargs):
            self.to_screen_called = True
            self.to_screen_message = args[0]

    class MockInfoDict(dict):
        def add_info_extractor(self, ie):
            pass

    class MockIE(object):
        def __init__(self, ie_name):
            self.ie_name = ie_name

# Generated at 2022-06-12 19:10:47.587274
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import sys
    if sys.version_info >= (3, 0):
        sys.modules['__main__'].xbmc = Mock()
    else:
        sys.modules['__main__'].xbmc = Mock()
        sys.modules['__main__'].xbmcaddon = Mock()
    sys.modules['__main__'].xbmcplugin = Mock()
    sys.modules['__main__'].xbmcvfs = Mock()
    sys.modules['__main__'].urllib = Mock()
    sys.modules['__main__'].urllib2 = Mock()
    sys.modules['__main__'].re = Mock()
    sys.modules['__main__'].urllib.quote = Mock(return_value='quote')

# Generated at 2022-06-12 19:10:52.004860
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    titleformat = '%(title)s - %(artist)s'
    title = 'Avenged Sevenfold - So Far Away (Official Music Video)'
    expected = {'artist': 'Avenged Sevenfold', 'title': 'So Far Away (Official Music Video)'}
    info = {}
    pp = MetadataFromTitlePP('', titleformat)
    _, info = pp.run(info)
    assert info == expected

# Generated at 2022-06-12 19:10:52.773829
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass


# Generated at 2022-06-12 19:10:58.858596
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Given
    info = {'title': 'The Beatles - I Want to Hold Your Hand - Live in Madison Square Garden, New York - 1964'}
    expected_info = {
        'title': 'The Beatles - I Want to Hold Your Hand - Live in Madison Square Garden, New York - 1964',
        'artist': 'The Beatles',
        'song': 'I Want to Hold Your Hand',
        'event': 'Live in Madison Square Garden, New York',
        'date': '1964'
    }

    # When
    metadata_from_title = MetadataFromTitlePP(None, '%(artist)s - %(song)s - %(event)s - %(date)s')
    [], info = metadata_from_title.run(info)

    # Then
    assert info == expected_info

# Generated at 2022-06-12 19:11:04.176310
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl.YoutubeDL
    ydl = youtube_dl.YoutubeDL({
        'download_archive': False,
        'logger': youtube_dl.FileDownloader.std_headers['User-Agent'],
    })
    ydl.add_default_info_extractors()
    metadata_from_title = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    info = {'title': 'title'}
    metadata_from_title.run(info)
    assert info == {'title': 'title'}
    info = {'title': 'title - artist'}
    metadata_from_title.run(info)
    assert info == {'title': 'title - artist', 'artist': 'artist'}
    metadata_from_title = MetadataFromTitlePP

# Generated at 2022-06-12 19:11:17.010031
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys    # FIXME: mock sys.stdout and compare to desired output
    from collections import namedtuple

    FakeYDL = namedtuple('FakeYDL', ['to_screen'])

    def fake_to_screen(*args, **kwargs):
        sys.stdout.write(args[0]+'\n')

    info = {
        "title": "Le Tour de France 2015 - Live coverage - Stage 15 WT",
        "creator": None,
        "date": None,
        "description": None,
        "categories": None,
        "uploader": None
    }

    ydl = FakeYDL(to_screen=fake_to_screen)

    pp = MetadataFromTitlePP(ydl, '%(title)s')
    pp.run(info)

# Generated at 2022-06-12 19:11:24.465276
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ydl import YoutubeDL
    class PostProcessorMock(object):
        def to_screen(self, msg):
            print('[fromtitle] ' + msg)

    # Test german single title
    title_test1 = 'Außerirdische kommen! - Ein Reporter packt aus! (Trailer)'
    title_format = '%(title)s'
    regex_format = '(?P<title>.+)'
    regex_title_test1 = MetadataFromTitlePP(
        PostProcessorMock(), title_format)._titleregex
    assert(regex_title_test1 == regex_format)
    match_title_test1 = re.match(regex_title_test1, title_test1)

# Generated at 2022-06-12 19:11:31.936144
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Arrange
    titleformat = '%(artist)s - %(title)s'
    metadata_from_titlePP = MetadataFromTitlePP(None, titleformat)
    metadata_from_titlePP._titleregex = '^(?P<artist>.+) - (?P<title>.+)$'
    info = {'title': 'artist1 - title1'}

    # Act
    info = metadata_from_titlePP.run(info)

    # Assert
    assert info['artist'] == 'artist1'
    assert info['title'] == 'title1'

# Generated at 2022-06-12 19:11:36.374167
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    test method run of class MetadataFromTitlePP
    """
    def test_run(input_string, expected_result):
        pp = MetadataFromTitlePP(None, input_string)
        pp.run({'title': 'Some Title'})

    # Unit test method run of class MetadataFromTitlePP
    test_run('%(title)s', {'title': 'Some Title'})
    test_run('%(title)s - %(artist)s', {'title': 'Some Title'})
    test_run('%(title)s', {'title': 'Some Title'})
    test_run('%(title)s - %(artist)s', {'title': 'Some Title'})

# Generated at 2022-06-12 19:11:44.664638
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # TODO: branch coverage
    # TODO: add more test cases
    import sys
    import unittest
    from unittest.mock import Mock
    # re.match returns None if nothing is found
    assert MetadataFromTitlePP(Mock(), "%(title)s").run({'title': 'test'})[1]['title'] is None
    # re.match returns Match object if something is found
    assert MetadataFromTitlePP(Mock(), "%(title)s").run({'title': 'test'})[1]['title'] == 'test'
    # re.match uses escaped string as regex
    assert MetadataFromTitlePP(Mock(), "%(title)s\%").run({'title': 'test'})[1]['title'] is None
    # re.match uses compiled regex
    pattern = re.comp

# Generated at 2022-06-12 19:11:54.432632
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from collections import namedtuple
    # Set up a mock downloader and
    # override methods in a way that
    # makes sure that the method to_screen
    # is called and that the message it is
    # called with is recorded in the variable s
    class MockYDL:
        def __init__(self):
            self.s = ''
        def to_screen(self, msg):
            self.s += msg

    MockInfo = namedtuple('MockInfo', 'title')
    info = {'info': MockInfo(title='a title - with an artist'),
            'fulltitle': 'A title - with an artist',
            'filename': 'filename'}
    ydl = MockYDL()
    # Initialize MetadataFromTitlePP with a pattern
    # that matches the title

# Generated at 2022-06-12 19:12:04.314073
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import os
    import subprocess
    from .common import PostProcessor
    class DummyDownloader(object):
        def __init__(self):
            self.to_screen = sys.stdout.write

    # Create temporary file containing test content
    fd, temp_file = tempfile.mkstemp(suffix='.mp3', prefix='youtubedl-test-title-')
    os.close(fd)
    fd = open(temp_file, 'w')
    fd.write('The FooBarBaz show - FooBarBaz interview - FooBarBaz interview with FooBarBaz - The FooBarBaz show - FooBarBaz interview\n')
    fd.close()


# Generated at 2022-06-12 19:12:14.041904
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import YouTubeDL
    class Proxy(object):
        def __init__(self):
            self.stderr = sys.stderr
            self.fromtitle = None
            self.parsed = None
        def to_screen(self, msg):
            self.fromtitle = msg
        def report_warning(self, msg):
            self.fromtitle = msg
    p = Proxy()
    ydl = YouTubeDL.YoutubeDL(params={'simulate': True, 'quiet': True})
    ydl.add_post_processor(MetadataFromTitlePP(p, '%(title)s - %(artist)s'))
    # Test valid data
    res, info = ydl.post_process({'title': 'DemoSong - DemoArtist'}, {})

# Generated at 2022-06-12 19:12:22.564336
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    dl = YoutubeDL()
    
    # Test for some title format that includes fixed strings
    pp = MetadataFromTitlePP(dl, 'Test%(title)sSong')
    info = {'title': 'TestTitleTestSong'}
    res, info = pp.run(info)
    assert info['title'] == 'Title'

    # Test for some title format with one group
    pp = MetadataFromTitlePP(dl, 'Test%(title)sSong2')
    info = {'title': 'TestTitle2'}
    res, info = pp.run(info)
    assert info['title'] == 'Title'

    # Test for some title format with multiple groups

# Generated at 2022-06-12 19:12:33.250072
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """Unit test for method run of class MetadataFromTitlePP."""

    from .downloader import FileDownloader

    tmp = 'tmp'
    downloader = FileDownloader(params={})
    pp = MetadataFromTitlePP(downloader=downloader, titleformat='%(title)s')
    assert pp.run({'title': 'foo'})==([], {'title': 'foo'})

    pp = MetadataFromTitlePP(downloader=downloader, titleformat='%(title)s - %(artist)s')
    assert pp.run({'title': 'foo'})==([], {'title': 'foo'})
    assert pp.run({'title': '- foo'})==([], {'title': '- foo'})

# Generated at 2022-06-12 19:12:46.156659
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import subprocess

    if sys.version_info < (3, 2):
        raise Exception('Python 3.2 or later required for test')

    subprocess.check_call(
        ['git', 'clone', 'https://github.com/rg3/youtube-dl.git', 'youtube-dl'])
    sys.path.insert(0, 'youtube-dl')

    from ytdl_hook import DownloadHook

    h = DownloadHook(DownloadHook({'fromtitle': '', 'metadatafromtitle': ''},
                                  'youtube-dl', '', ''))
    pp = MetadataFromTitlePP(h.downloader, '%(title)s - %(artist)s')
    info = {'title': 'Some Title - Somebody Else'}
    pp.run(info)


# Generated at 2022-06-12 19:12:47.110569
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    #TODO
    pass

# Generated at 2022-06-12 19:12:58.281383
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_video_title = 'The Big Bang Theory - S07E11 - The Santa Simulation'
    test_regex = r'[Tt]he\ [Bb]ig\ [Bb]ang\ [Tt]heory\ -\ [Ss]\d{2}[Ee]\d{2}\ -\ .*'

# Generated at 2022-06-12 19:13:06.367224
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp.run({'title': 'Foo - Bar'}) == ([], {'artist': 'Foo', 'title': 'Bar'})
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp.run({'title': 'Foo'}) == ([], {'title': 'Foo'})
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp.run({'title': 'F  - Bar'}) == ([], {'title': 'F  - Bar'})
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')

# Generated at 2022-06-12 19:13:09.978541
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert(MetadataFromTitlePP(None, '%(title)s - %(artist)s').run({'title': 'Foo - Bar'})[1] == {'title': 'Foo', 'artist': 'Bar'})

# Generated at 2022-06-12 19:13:14.504010
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    titleformat = '%(artist)s (YT) - %(title)s'
    title = 'The Artist (YT) - The Title'
    downloader = None
    info = {'title': title}
    pp = MetadataFromTitlePP(downloader, titleformat)
    pp.run(info)
    assert info['artist'] == 'The Artist'
    assert info['title'] == 'The Title'

# Generated at 2022-06-12 19:13:21.017202
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class FakeInfo:
        pass

    info = FakeInfo()
    info.title = "The video title"
    info.artist = "The artist of the video"

    pp = MetadataFromTitlePP(None, "%(title)s - %(artist)s")
    assert pp.run(info) == ([], info)
    assert info.title == "The video title"
    assert info.artist == "The artist of the video"

# Generated at 2022-06-12 19:13:30.429508
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from argparse import Namespace
    from pytube import YouTube
    from pytube import FileDownloader
    from pytube.downloader import Video
    video = YouTube('https://www.youtube.com/watch?v=N7G8TKUDN0s').get('mp4', '360p')

# Generated at 2022-06-12 19:13:41.032073
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    import tempfile
    import os

    if sys.version_info < (2, 7):
        import unittest2 as unittest

    # Mock downloader class
    class MockYoutubeDL(object):
        def __init__(self):
            self.to_screen_executions = []
            self.file_descriptors = []

        def to_screen(self, *args, **kwargs):
            self.to_screen_executions.append((args, kwargs))

    # Mock output file class
    class MockOutputFile(object):
        def __init__(self):
            self.fh = tempfile.NamedTemporaryFile(delete=False)

        def write(self, data):
            self.fh.write(data)


# Generated at 2022-06-12 19:13:52.196483
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    print('Testing MetadataFromTitlePP - run')
    import ydl_opts
    downloader = object()
    titleformat = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(downloader, titleformat)
    print('  Test 1')
    info = {'title': 'The Artist - The Title'}
    print(info)
    result, info = pp.run(info)
    print(info)
    assert info['title'] == 'The Title'
    assert info['artist'] == 'The Artist'

    print('  Test 2')
    info = {'title': 'The Artist - The Title.mp3'}
    print(info)
    result, info = pp.run(info)
    print(info)
    assert info['title'] == 'The Title.mp3'

# Generated at 2022-06-12 19:14:06.223995
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    def t(tformat, title, expected_out):
        tformat = '%(title)s - %(artist)s'
        pp = MetadataFromTitlePP(None, tformat)
        info = {'title': title}
        pp.run(info)
        assert info == expected_out

    # same title, different case
    t(None, 'Foo', {'title': 'Foo'})
    t(None, 'FoO', {'title': 'FoO'})
    t(None, 'foO', {'title': 'foO'})

    # different titles
    t(None, 'Foo', {'title': 'Foo'})
    t(None, 'Foo Bar', {'title': 'Foo Bar'})

# Generated at 2022-06-12 19:14:15.923908
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor import FFmpegExtractAudioPP
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor import MetadataFromTitlePP
    import io

    info = {'title': 'Foo - Bar'}

    match_code = '''
import re
match = re.match(r'(?P<title>.+) - (?P<artist>.+)', info['title'])
assert match is not None
for attribute, value in match.groupdict().items():
    info[attribute] = value
'''


# Generated at 2022-06-12 19:14:22.946356
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class DummyDownloader(object):
        def to_screen(self, msg):
            pass

    pp = MetadataFromTitlePP(DummyDownloader(), '%(title)s - %(artist)s')
    info = {'title': 'hello world - foo bar'}
    result = pp.run(info)
    assert result[0] == []
    assert result[1]['title'] == 'hello world'
    assert result[1]['artist'] == 'foo bar'

# Generated at 2022-06-12 19:14:28.453770
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from mock import MagicMock
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader import YoutubeDL
    downloaderMock = YoutubeDL()
    downloaderMock.to_screen = MagicMock()
    downloaderMock.params = {'no_warnings': True}
    info = {'title': 'some title - some other title'}
    expected = [{'title': 'some title', 'other_title': 'some other title'}]
    assert_equals(
        MetadataFromTitlePP(downloaderMock, '%(title)s - %(other_title)s').run(info),
        expected)
    expected = [{'title': 'some title', 'artist': 'some other title'}]

# Generated at 2022-06-12 19:14:37.422350
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import pytube
    downloader = pytube.downloader.Downloader()
    pp = MetadataFromTitlePP(downloader, '%(artist)s - %(title)s')

    # Title matches
    info = {}
    info['title'] = 'Foo Fighters - The Pretender'
    metadata, info = pp.run(info)
    assert metadata == []
    assert info['artist'] == 'Foo Fighters'
    assert info['title'] == 'The Pretender'

    # Title does not match
    info = {}
    info['title'] = 'Title'
    metadata, info = pp.run(info)
    assert metadata == []
    assert 'artist' not in info
    assert 'title' not in info

# Generated at 2022-06-12 19:14:48.830742
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL as _YoutubeDL
    from youtube_dl import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ydl):
            super(FakeInfoExtractor, self).__init__(ydl)
            self._ydl = ydl

        def _real_initialize(self):
            pass

        def _real_extract(self, *args, **kwargs):
            return {'id': 'abcde', 'title': '%(artist)s - %(title)s'}

    ydl = _YoutubeDL({'quiet': True, 'simulate': True})
    ydl.add_info_extractor

# Generated at 2022-06-12 19:14:58.414432
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys

    # Create mocked info and downloader
    class MyInfo(dict):
        def add(self, key, value):
            self[key] = value
    info = MyInfo()
    info['title'] = 'Avicii - X You (Original Version) [Official Video]'
    info['ext'] = 'mp4'

    class MyDownloader(object):
        def to_screen(self, s):
            sys.stdout.write(s)
            sys.stdout.write('\n')
    downloader = MyDownloader()

    # Create pp and run it
    pp = MetadataFromTitlePP(downloader, '%(artist)s - %(title)s')
    pp.run(info)

# Generated at 2022-06-12 19:15:03.040361
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_fromtitle = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    info = {'title': 'The title - The artist'}
    metadata_fromtitle.run(info)
    assert info['title'] == 'The title'
    assert info['artist'] == 'The artist'

# Generated at 2022-06-12 19:15:10.564034
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from test import get_test_file_data

    # Test with a titleformat setting that isn't in a valid format
    mp = MetadataFromTitlePP(None, '%(title)s - %(bad)s')
    mp.format_to_regex('%(title)s - %(bad)s')
    assert mp._titleregex == '\%\(title\)s\ \-\ \%\(bad\)s'

    # Test with a titleformat that is in a valid format and a video
    # title that doesn't match the format
    mp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    mp.format_to_regex('%(title)s - %(artist)s')

# Generated at 2022-06-12 19:15:19.669255
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .test import FakeYDL
    from .compat import compat_etree_fromstring

    def build_info(title):
        info = {'title': title, 'webpage_url': '', 'format': '', 'id': ''}
        info['_type'] = 'video'
        info['webpage'] = compat_etree_fromstring('''
            <html>
              <head>
              </head>
              <body>
                <div id="eow-title">%s</div>
              </body>
            </html>
        ''' % title)
        return info

    # A sample set of titles that should be mapped to the values below.
    # None means the title regex did not match.
    # Each element represents a different test-case.

# Generated at 2022-06-12 19:15:41.222118
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    '''
    Testcase for a PostProcessor. Check whether the default settings of
    MetadataFromTitlePP.run() works as expected.
    '''

    import sys
    import unittest
    import warnings
    import tempfile
    try:
        tempfile.TemporaryFile(mode='w+b').close()
    except TypeError:
        # Python 2.5 doesnt handle the mode argument properly
        pass

    from .jsinterp import JsInterpreter
    from .extractor import gen_extractors
    from .downloader import get_suitable_downloader
    from .common import FileDownloader

    print('Test MetadataFromTitlePP.run()...')
    warnings.filterwarnings('ignore', category=DeprecationWarning)

    def test_set_downloader(self, downloader):
        self.download

# Generated at 2022-06-12 19:15:50.651755
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pp = MetadataFromTitlePP(None, '%(title)s')
    info = {
        'title': 'My video title',
    }

    # Test that run adds title
    pp.run(info)
    assert 'title' in info
    assert info['title'] == 'My video title'

    # Test that run adds artist and title from a more complete name
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    info = {
        'title': 'Artist - Title',
    }
    pp.run(info)
    assert info['title'] == 'Title'
    assert info['artist'] == 'Artist'


# Generated at 2022-06-12 19:15:58.869185
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from . import YoutubeDL
    from .extractor.common import InfoExtractor
    from .utils import DateRange

    assert MetadataFromTitlePP.format_to_regex(
        '%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP.format_to_regex(
        '$(title)s - %(artist)s') == r'\$\(title\)s\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP.format_to_regex(
        '%%(title)s - %(artist)s') == r'\%\(title\)s\ \-\ (?P<artist>.+)'


# Generated at 2022-06-12 19:16:06.449339
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # try parsing with incomplete title
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    info = {'title': 'Test'}
    pp.run(info)
    assert 'artist' not in info

    # parse artist and title
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    info = {'title': 'Test - Test'}
    pp.run(info)
    assert 'artist' in info
    assert info['artist'] == 'Test'

    # ignore title and parse artist and album
    pp = MetadataFromTitlePP(None, '%(artist)s - %(album)s')
    info = {'title': 'Test - Test - Test'}
    pp.run(info)
    assert 'artist'

# Generated at 2022-06-12 19:16:14.449936
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest

    test_cases = [
        {
            'format' : '%(title)s - %(artist)s',
            'title' : 'Dreadlock Holiday - 10cc',
            'expected': {
                'title': 'Dreadlock Holiday',
                'artist': '10cc'
            }
        },
        {
            'format' : '%(title)s - %(artist)s',
            'title' : 'Dreadlock Holiday 10cc',
            'expected': {
                'title': 'Dreadlock Holiday 10cc',
                'artist': None
            }
        }
    ]

    class MyFakeYDL:
        def to_screen(self, msg):
            pass


# Generated at 2022-06-12 19:16:26.595691
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .compat import compat_str
    # Title: Music Video - %(artist)s - %(title)s - %(track)s - %(album)s
    # Title: Music Video - %(artist)s - %(title)s - %(album)s - %(track)s
    pp = MetadataFromTitlePP(FileDownloader(),
                             'Music Video - %(artist)s - %(title)s - %(track)s - %(album)s')
    info = {}
    [], info = pp.run(info)
    assert info == {
        'title': compat_str('Music Video - John Doe - "Track Title" - 11 - "Album Title"')
    }

# Generated at 2022-06-12 19:16:38.644019
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Note: this unit test does not require the Downloader object
    # and should not use it.
    object = MetadataFromTitlePP(None, "%(title)s")
    # test if all fields are correctly extracted
    title = "title - attribute1 - attribute2 - attribute3"
    info = {'title': title}
    metadata = []
    result = object.run(info)
    assert (info['title'] == title)
    assert (info['attribute1'] == 'attribute1')
    assert (info['attribute2'] == 'attribute2')
    assert (info['attribute3'] == 'attribute3')
    assert (metadata == result[0])

    # test if all fields are correctly extracted, if the title contains '%'
    title = "title - attribute1 - attribute2 - attribute3%more"

# Generated at 2022-06-12 19:16:50.925335
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import os
    os.mkdir('./downloads')
    f = open('downloads/output.mp3', 'w')
    f.close()
    from .downloader.YoutubeDL import YoutubeDL
    from .YoutubeDLDownloader import YoutubeDLDownloader
    downloader = YoutubeDLDownloader(YoutubeDL(), "http://www.youtube.com/watch?v=1eQvGa4H2wA")

# Generated at 2022-06-12 19:16:56.426277
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl
    tst_ytdl = youtube_dl.YoutubeDL({'nooverwrites': True})
    tst_pp = MetadataFromTitlePP(tst_ytdl, '%(artist)s - %(title)s')
    tst_info = {'title': 'Artist - Song Title'}
    tst_pp.run(tst_info)
    assert 'artist' in tst_info and tst_info['artist'] == 'Artist'
    assert 'title' in tst_info and tst_info['title'] == 'Song Title'


# Generated at 2022-06-12 19:17:05.784407
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .downloader import YoutubeDL
    from mock import patch

    downloader = YoutubeDL()
    downloader.to_screen = lambda x: x
    downloader.to_stdout = lambda x: x

    def patch_write_string(fd, str):
        assert fd == 'metadata'
        assert str == 'title=%(title)s - %(artist)s - %(album)s\n'
        return None

    # Suppress error/warning messages
    downloader.report_warning = lambda msg: msg
    downloader.report_warning = lambda msg: msg
    # Patch to_screen and to_stderr to test their outputs
    # ie. Patch out the self variable so that the method
    #     is not dependent on the object

# Generated at 2022-06-12 19:17:34.071942
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    import tempfile
    from os.path import exists, join

    def _make_faketitle(title):
        class FakeInfo:
            def __init__(self, title):
                self._title = title

            def __getitem__(self, k):
                return self._title

            def __setitem__(self, k, v):
                self._title = v
        return FakeInfo(title)

    def _test(title, titleformat, expected_results, assert_results=True):
        pp = MetadataFromTitlePP(FileDownloader({}), titleformat)
        res_info, unused_tmp_filename = pp.run(_make_faketitle(title))

        if assert_results:
            msg = 'expected result %r != actual result %r'

# Generated at 2022-06-12 19:17:38.404696
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    info = {'id': 'abc', 'title': 'abc - title'}
    pp = MetadataFromTitlePP(None, '%(id)s - %(title)s')
    new_info = pp.run(info)[1]
    assert new_info['title'] == 'title'
    assert new_info['id'] == 'abc'


# Generated at 2022-06-12 19:17:46.520438
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from . import YoutubeDL
    ydl = YoutubeDL()
    titleformat = '%(title)s - %(artist)s'
    title = 'Video Title - VEVO'
    info = {'title': title, 'id': '9bZkp7q19f0', 'ext': 'mp4'}
    pp = MetadataFromTitlePP(ydl, titleformat)
    pp.run(info)
    assert info['title'] == 'Video Title'
    assert info['artist'] == 'VEVO'


# Generated at 2022-06-12 19:17:47.135946
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass

# Generated at 2022-06-12 19:17:58.384192
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ..YoutubeDL import YoutubeDL
    from ..extractor.youtube import YoutubeIE

    def process(titleformat, title, expected):
        pp = MetadataFromTitlePP(YoutubeDL({'usetitle': True}), titleformat)
        _, info = pp.run({'title': title})
        assert info['title'] == expected['title']
        assert info['creator'] == expected['creator']
        assert info['album'] == expected['album']

    process('%(title)s', 'ThisIsATest',
            {'title': 'ThisIsATest', 'creator': None, 'album': None})


# Generated at 2022-06-12 19:18:05.935787
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # pylint: disable=too-many-branches
    import youtube_dl
    import json
    import os

    # read the json file
    with open(os.path.join(os.path.dirname(
            os.path.abspath(__file__)), 'metadata_from_title.json')) as data:
        tests = json.load(data)

    for test_number, test in enumerate(tests, start=1):
        info = {
            'title': 'My title',
            'artist': 'My artist',
            'album': 'My album'
        }
        test_info = {
            'title': test['title'],
            'artist': 'My artist',
            'album': 'My album'
        }
        downloader = youtube_dl.YoutubeDL()

# Generated at 2022-06-12 19:18:13.630021
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest

    class TestDownloader(object):
        def __init__(self):
            self.result = None
        def to_screen(self, msg):
            self.result = msg

    class TestInfo(object):
        def __init__(self):
            self.title = ""

    class TestCase(unittest.TestCase):
        def test(self):
            downloader = TestDownloader()
            info = TestInfo()

            # Regex is passed to MetadataFromTitlePP
            test_long_title = "Foo - Foo.mp3"
            info.title = test_long_title
            pp = MetadataFromTitlePP(downloader, "%(title)s - %(ext)s")
            pp.run(info)

# Generated at 2022-06-12 19:18:23.465850
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .ytdl_mocked import FakeYDL
    from .pytest_mock import mock_downloader
    with mock_downloader(FakeYDL) as ydl:
        mp = MetadataFromTitlePP(ydl, 'foo(%(bar)s) %(baz)s')
        assert mp.format_to_regex('foo(%(bar)s) %(baz)s') == 'foo\(%\(\w+\)s\) %\(\w+\)s'

        for title in ['foo(bar) baz', 'foo(bar) baz - qux']:
            info = {'title': title}
            res, info = mp.run(info)
            assert info['bar'] == 'bar'
            assert info['baz'] == 'baz'

# Generated at 2022-06-12 19:18:34.601080
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from . import YoutubeDL

    """test_MetadataFromTitlePP_run.
    """
    def info_dict(title):
        return {'title':title}


# Generated at 2022-06-12 19:18:44.339136
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """Function for unit tests
    """
    import os
    import sys
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.MetadataFromTitle import MetadataFromTitlePP

    class FakeYoutubeDL(YoutubeDL):
        """Fake class for YoutubeDL
        """
        def __init__(self, *args, **kargs):
            class FakeInfo:
                def __init__(self, d):
                    self.__dict__ = d
            self.info = FakeInfo({'title': 'The title of the video'})

        def to_screen(self, message):
            """Fake method for to_screen
            """
            print(message)

   

# Generated at 2022-06-12 19:19:41.126665
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class MockYDL:
        def to_screen(self, message):
            pass
    class MockInfo:
        def __init__(self, title, **kwargs):
            self._info = { 'title' : title }
            for attribute, value in kwargs.items():
                self._info[attribute] = value
        def __getitem__(self, key):
            return self._info[key]
        def __setitem__(self, key, value):
            self._info[key] = value
        def keys(self):
            return self._info.keys()
        def items(self):
            return self._info.items()

    ydl = MockYDL()

    # simple pattern with only one group
    titleformat = '%(title)s'

# Generated at 2022-06-12 19:19:48.132665
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # We need to mock _downloader
    downloader = object()
    # Define test values for info
    info = {
        'title': 'Title of video.mp4',
        }
    # Define the expected output
    expected = [], info
    #
    # Test the method
    #
    # Instantiate a MetadataFromTitlePP object
    # We don't care of the titleformat value
    p = MetadataFromTitlePP(downloader, titleformat='%(title)s')
    # Run the method
    output = p.run(info)
    # Compare output and expected
    assert output == expected
    #
    # Test the method with a titleformat value containing a regex
    #
    # Define test values for info
    info = {
        'title': 'Title of video.mp4',
        }
