

# Generated at 2022-06-12 19:10:06.286156
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.YoutubeDL import YoutubeDL
    from collections import namedtuple

    class DummyFileDownloader(FileDownloader):
        def __init__(self, params, info_dict):
            super(DummyFileDownloader, self).__init__(params)
            self.result_info_dict = info_dict

    # set default date range such that all videos are downloaded
    date_range = DateRange(datetime.datetime(1970, 1, 1),
                           datetime.datetime(2970, 1, 1))

# Generated at 2022-06-12 19:10:15.212382
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pp = MetadataFromTitlePP(None, '[fromtitle] Could not interpret title of video as "test_%(artist)s_%(title)s"')
    assert pp.format_to_regex('test_%(artist)s_%(title)s') == 'test_(?P<artist>.+)_(?P<title>.+)'

    info = { 'title' : 'test_YoYoMa_CelloSuite' }
    success, info = pp.run(info)
    assert 'artist' in info
    assert 'title' in info
    assert info['artist'] == 'YoYoMa'
    assert info['title'] == 'CelloSuite'

    pp = MetadataFromTitlePP(None, '[fromtitle] Could not interpret title of video as "%(title)s"')

# Generated at 2022-06-12 19:10:23.119566
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import os
    os.chdir('..')
    sys.path.insert(0, '..')
    from ydl import YDL
    class Downloader:
        def __init__(self, to_screen):
            self.to_screen = to_screen
    # test 1: normal title
    title = 'Foo - Baz'
    info = {'title': title}
    downloader = Downloader(lambda x: x)
    pp = MetadataFromTitlePP(downloader, '%(artist)s - %(title)s')
    pp.run(info)
    assert info == {'title': 'Baz', 'artist': 'Foo'}

    # test 2: failed parse
    title = 'Baz - Foo'
    info = {'title': title}

# Generated at 2022-06-12 19:10:31.675492
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    def _test(titleformat, title, expected):
        respp = MetadataFromTitlePP(None, titleformat)
        info = {'title': title}
        respp.run(info)[1].update(info)  # TODO: make run return only new info
        return info == expected

    assert _test('%(title)s', 'foo', {'title': 'foo'})

    assert _test('%(artist)s - %(title)s - %(album)s',
                 'Foo artist - foo title - foo album',
                 {'artist': 'Foo artist',
                  'title': 'foo title',
                  'album': 'foo album'})


# Generated at 2022-06-12 19:10:41.803688
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """MetadataFromTitlePP class unit test."""
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.ffmpeg import FFmpegMetadataPP
    downloader = YoutubeDL()

    correct_info = {
        'title': 'test title',
        'artist': 'test artist'
    }
    incorrect_info = {
        'title': 'test title - test artist',
        'artist': 'test artist'
    }
    mp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    other_mp = FFmpegMetadataPP(downloader)

    # Correct title format
    res, new_info = mp.run(correct_info)
    assert new_info['title'] == 'test title'

# Generated at 2022-06-12 19:10:49.196226
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # empty string
    assert MetadataFromTitlePP(None, '').format_to_regex('') == ''

    # string
    assert (MetadataFromTitlePP(None, '"hello world"').
            format_to_regex('"hello world"') ==
            r'hello\ world')

    # string with leading and trailing space
    assert (MetadataFromTitlePP(None, ' "hello world" ').
            format_to_regex(' "hello world" ') ==
            r'\ hello\ world\ ')

    # one key
    assert (MetadataFromTitlePP(None, '%(title)s').
            format_to_regex('%(title)s') ==
            r'(?P<title>.+)')

    # one key with leading and trailing space

# Generated at 2022-06-12 19:10:59.678281
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, '').format_to_regex('') == ''
    assert MetadataFromTitlePP(None, '').format_to_regex('str') == 'str'
    assert MetadataFromTitlePP(None, '').format_to_regex('str%(x)sstr') == 'str(?P<x>.+)str'
    assert MetadataFromTitlePP(None, '').format_to_regex('%(x)s%(y)s') == '(?P<x>.+)(?P<y>.+)'

# Generated at 2022-06-12 19:11:07.022615
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ..YoutubeDL import YoutubeDL
    from .common import FakeYDL
    ydl = FakeYDL()
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s - %(album)s')
    info = {'id': 'zzzzzzzz', 'title': 'New Song - Foo - My Playlist'}
    pp.run(info)
    assert info == {
        'id': 'zzzzzzzz',
        'title': 'New Song - Foo - My Playlist',
        'artist': 'New Song',
        'album': 'My Playlist'
    }


# Generated at 2022-06-12 19:11:17.611489
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '')
    # Test that format_to_regex creates a regex that matches the original format
    titleformat1 = '%(title)s - %(artist)s - %(album)s'
    title1 = 'My title - My artist - My album'
    regex = pp.format_to_regex(titleformat1)
    match = re.match(regex, title1)
    assert match is not None
    for attribute, value in match.groupdict().items():
        if not attribute in ('title', 'artist', 'album'):
            assert False
    # Test that format_to_regex makes the regex non-matching for titles in different format
    title2 = 'My album - My title - My artist'
    assert re.match(regex, title2) is None

# Generated at 2022-06-12 19:11:21.579853
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader

    mftpp = MetadataFromTitlePP(FileDownloader({}), '%(title)s - %(artist)s')

    assert mftpp.run({'title' : 'Foo - Bar'}) == ([], {'title' : 'Foo - Bar', 'artist' : 'Bar'}), "Failed to parse title"

# Generated at 2022-06-12 19:11:34.471131
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .compat import compat_etree_Element
    from .common import FileDownloader

    # create a mock downloader for the duration of this test
    class DummyDownloader(FileDownloader):
        def __init__(self, **kw):
            super(DummyDownloader, self).__init__(
                **{'params': kw.pop('params', None),
                   'progress_hooks': kw.pop('progress_hooks', []),
                   'exception_hooks': kw.pop('exception_hooks', []),
                   'info_dict': kw.pop('info_dict', None),
                   'playlist': kw.pop('playlist', None)})
            self.to_screen_calls = []

        def to_screen(self, message):
            self.to_screen_c

# Generated at 2022-06-12 19:11:42.242584
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Example title: 'Foo - Bar - Baz'
    # Example format: '%(title)s - %(artist)s - %(album)s'
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(album)s')
    info = {'title': 'Foo - Bar - Baz'}
    result = pp.run(info)
    assert info['title'] == 'Foo - Bar - Baz'
    assert info['artist'] == 'Foo'
    assert info['album'] == 'Bar'

# Generated at 2022-06-12 19:11:52.953885
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.downloader import FileDownloader
    from youtube_dl.extractor import InfoExtractor
    from youtube_dl.utils import FileDownloader
    import tempfile

    with tempfile.NamedTemporaryFile() as t:
        ies = InfoExtractor([])
        ies.set_downloader(FileDownloader(params={}))
        info = {'title': 'song - band (album) [extra]'}
        pp = MetadataFromTitlePP(ies, '%(title)s')
        pp.run(info)
        assert info['title'] == 'song'
        assert info['band'] == 'band'
        assert info['album'] == 'album'
        assert not 'extra' in info
        pp = MetadataFromTitlePP(ies, '%(title)s [%(extra)s]')

# Generated at 2022-06-12 19:12:00.026954
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.InfoExtractors import YoutubeIE

    # Test simple regex
    mftpp = MetadataFromTitlePP(YoutubeDL(), '%(title)s')
    info = dict(title='test_title')
    info_out = mftpp.run(info)[1]
    assert info_out['title'] == 'test_title'

    # Test format with spaces
    mftpp = MetadataFromTitlePP(YoutubeDL(), '%(title)s - %(artist)s')
    info = dict(title='test_title - test_artist')
    info_out = mftpp.run(info)[1]
    assert info_out['title'] == 'test_title'
    assert info_out['artist'] == 'test_artist'

    #

# Generated at 2022-06-12 19:12:09.104888
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys

    import pytube

    sys.argv.append('-i')
    sys.argv.append('--no-progress')

    import unittest

    from .common import FakeYDL

    class MetadataFromTitlePPTest(unittest.TestCase):
        def runTest(self):
            ydl = FakeYDL(dict(
                verbose=True,
                postprocessors=[MetadataFromTitlePP(
                    None, '%(artist)s - %(title)s')],
            ))

            url = 'http://example.com/'
            outtmpl = '%(artist)s - %(title)s'
            title = 'metallica - unforgiven'
            ydl.add_default_info_extractors()
            ie = ydl.__getitem__(url)
           

# Generated at 2022-06-12 19:12:18.659025
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import tempfile
    import unittest

    class MockYDL(object):
        def __init__(self):
            self.mytmp = tempfile.NamedTemporaryFile()
            self.params = {'outtmpl': self.mytmp.name}

        def to_screen(self, string):
            assert string
    
        def trouble(self, string):
            assert string
    
    class MockInfo(dict):
        pass

    class MetadataFromTitlePPTest(unittest.TestCase):

        def setUp(self):
            self.ydl = MockYDL()
            self.pp = MetadataFromTitlePP(self.ydl, '%(title)s - %(artist)s')


# Generated at 2022-06-12 19:12:25.794068
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class FakeDl(object):
        def to_screen(self, msg):
            self.logs = getattr(self, 'logs', [])
            self.logs.append(msg)

    title_format = '%(artist)s - %(title)s'
    mftp = MetadataFromTitlePP(FakeDl(), title_format)
    assert mftp.format_to_regex(title_format) == (
        r'(?P<artist>.+)\ \-\ (?P<title>.+)')

    mftp.run({'title': 'Foo - Bar - Baz'})
    assert mftp._downloader.logs == [
        '[fromtitle] Could not interpret title of video as "%s"' % title_format]

    mftp._downloader.logs = []


# Generated at 2022-06-12 19:12:36.561608
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl.downloader
    downloader = youtube_dl.downloader.YoutubeDL({})
    titleformat = '%(title)s - %(artist)s'
    validtitle1 = 'Video title - Artist name'
    validtitle2 = 'Video title - Artist name feat. someone'
    invalidtitle1 = 'Video title - Artist'
    invalidtitle2 = 'Video - title'
    metadata = {'title': validtitle1}
    metadata_expected = {'title': validtitle1, 'artist': 'Artist name'}
    pp = MetadataFromTitlePP(downloader, titleformat)
    metadata = pp.run(metadata)
    assert metadata == ([], metadata_expected)
    metadata = {'title': validtitle2}

# Generated at 2022-06-12 19:12:46.786952
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader

    # Create a downloader and an info dict
    downloader = FileDownloader()
    downloader.params['outtmpl'] = '%(title)s.%(ext)s'

# Generated at 2022-06-12 19:12:58.048055
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    downloader = MockDownloader({
        'outtmpl': '%(title)s-%(id)s.%(ext)s',
        'format': 'bestaudio/best',
    })
    pp = MetadataFromTitlePP(downloader, '%(artist)s - %(title)s')
    info = {
        'title': 'From TitlePP:mock_title',
        'id': 'mock_id',
        'url': 'mock_url',
    }
    [], info = pp.run(info)

# Generated at 2022-06-12 19:13:04.477284
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import tempfile
    import unittest
    import youtube_dl.YoutubeDL

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.ydl = youtube_dl.YoutubeDL({
                'outtmpl': '%(title)s.%(ext)s',
            })
            self.pp = MetadataFromTitlePP(self.ydl, '%(artist)s - %(song)s')


# Generated at 2022-06-12 19:13:12.134487
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    if sys.version_info >= (3, 0):
        from io import StringIO
    else:
        from io import BytesIO as StringIO

    import unittest
    from .common import FakeYDL

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            # there is no stdout by default in unittest
            self.out = StringIO()
            self.ydl = FakeYDL(out=sys.stdout)

        # verify that a complex regex is transformed as expected
        def test_format_to_regex(self):
            pp = MetadataFromTitlePP(self.ydl, '%(video_id)s - %(title)s')

# Generated at 2022-06-12 19:13:18.365686
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Arrange
    test_title = 'This is a test title'
    test_format = 'This is a %(test)s title'
    test_info = {'title' : test_title}
    test_downloader = object()

    pp = MetadataFromTitlePP(test_downloader, test_format)

    # Act
    result, _ = pp.run(test_info)

    # Assert
    assert test_info['test'] == 'test'
    assert not result

# Generated at 2022-06-12 19:13:28.381593
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    downloader = object()
    postprocessor = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    # test a known format
    info = {
        'title': 'title - artist',
        'artist': None,
    }
    postprocessor.run(info)
    assert info['title'] == 'title'
    assert info['artist'] == 'artist'
    postprocessor = MetadataFromTitlePP(downloader, '%(artist)s - %(title)s')
    info = {
        'title': 'title - artist',
        'artist': None,
    }
    postprocessor.run(info)
    assert info['title'] == 'title'
    assert info['artist'] == 'artist'
    # test an unknown format

# Generated at 2022-06-12 19:13:34.878984
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    assert MetadataFromTitlePP.format_to_regex('Test') == 'Test'
    assert MetadataFromTitlePP.format_to_regex('Test%(hello)s') == 'Test(?P<hello>.+)'
    assert MetadataFromTitlePP.format_to_regex('%(hello)sTest') == '(?P<hello>.+)Test'
    assert MetadataFromTitlePP.format_to_regex('Test%(hello)sTest') == 'Test(?P<hello>.+)Test'
    assert MetadataFromTitlePP.format_to_regex('Test%(hello)sTest%(world)s') == 'Test(?P<hello>.+)Test(?P<world>.+)'

# Generated at 2022-06-12 19:13:40.703920
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_downloader = object()
    pp = MetadataFromTitlePP(test_downloader, '%(artist)s - %(title)s')
    title = 'LED ZEPPELIN - STAIRWAY TO HEAVEN'
    info = {'title': title}
    _, info_out = pp.run(info)
    assert info_out['artist'] == 'LED ZEPPELIN'
    assert info_out['title'] == 'STAIRWAY TO HEAVEN'


# Generated at 2022-06-12 19:13:52.161159
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .extractor import gen_extractors
    from .common import FileDownloader

    pp = MetadataFromTitlePP(FileDownloader(gen_extractors(), False), '%(title)s - %(uploader)s')
    assert pp.format_to_regex('%(title)s - %(uploader)s') == '(?P<title>.+)\ \-\ (?P<uploader>.+)'

    from .extractor.youtube import YoutubeIE
    from .extractor.common import InfoExtractor

    extractors = gen_extractors()
    info = YoutubeIE()._real_extract('http://www.youtube.com/watch?v=BaW_jenozKc')
    test_info = {}
    i = InfoExtractor()


# Generated at 2022-06-12 19:14:03.867949
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    youtube_dl_test_instance = None


# Generated at 2022-06-12 19:14:15.009096
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test the method run of class MetadataFromTitlePP
    # with the following parameters
    # Input:
    # info = {'title': 'title1 - title2 - title3: title4'}

    # Expected output:
    # run_return_value = ([], {'title': 'title1 - title2 - title3: title4',
    #                          'artist': 'title1', 'title': 'title2',
    #                          'album': 'title3: title4'})

    # arrange
    import sys
    import unittest
    from youtube_dl.YoutubeDL import YoutubeDL
    from title_from_metadata import MetadataFromTitlePP

    class TestYoutubeDL(YoutubeDL):
        def __init__(self, params={}, auto_init=True):
            self.to_screen_return_

# Generated at 2022-06-12 19:14:25.721033
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, ydl, *args, **kwargs):
            super(MockYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_called = False

        def to_screen(self, msg):
            self.to_screen_called = True

    ydl = MockYoutubeDL(
        {}, {'title': 'gajas', 'ext': 'mp4'}, {})
    pp = MetadataFromTitlePP(ydl, (
        '%(title)s.%(ext)s'))
    pp.run({'title': 'gajas', 'ext': 'mp4'})
    assert ydl.to_screen_called is False

    y

# Generated at 2022-06-12 19:14:38.093042
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    class DummyYDL():
        '''
        A dummy class to simulate a YDL object.
        '''

        def to_screen(self, text):
            '''
            A dummy function to simulate the YDL's to_screen function.
            '''

            print('[fromtitle] %s' % text)

    class DummyInfo():
        def __init__(self, title):
            self.title = title
            self.artist = None
            self.track = None

    # A correct title
    dummy_title = 'Song Title - Song Artist'
    dummy_info = DummyInfo(dummy_title)
    dummy_ydl = DummyYDL()
    dummy_pp = MetadataFromTitlePP(dummy_ydl, '%(title)s - %(artist)s')
    _, info = dummy

# Generated at 2022-06-12 19:14:49.470694
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-12 19:15:00.535539
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s'))
    info = {}
    res, info = ydl.post_processors[0].run(info)
    assert info == {}
    info['title'] = 'test'
    res, info = ydl.post_processors[0].run(info)
    assert info['title'] == 'test'
    info['title'] = 'another test'
    res, info = ydl.post_processors[0].run(info)
    assert info['title'] == 'another test'
    ydl.post_processors[0]._titleformat = '%(title)s - %(artist)s'

# Generated at 2022-06-12 19:15:09.037441
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class MockDownloader(object):
        def to_screen(self, msg):
            print(msg)
    import sys
    import os
    sys.argv = ['youtube-dl', '--metadata-from-title',
                '%(title)s - %(artist)s',
                '--output', '%(title)s',
                '"title:artist"', '"title - artist"',
                ]
    ydl = YoutubeDL(params={})
    pp = MetadataFromTitlePP(MockDownloader(), '%(title)s - %(artist)s')
    info = {'title': 'title - artist'}
    pp.run(info)
    assert info['title'] == 'title'
    assert info['artist'] == 'artist'
    info = {'title': 'title:artist'}
   

# Generated at 2022-06-12 19:15:18.993590
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import Downloader
    from .YoutubeDL import YoutubeDL
    from .extractor import common
    from .PostProcessor.FFmpegMetadataPP import FFmpegMetadataPP

    downloader = Downloader(params={'verbose': True})
    test_output = [
        'Could not interpret title of video as "%(site)s (%(id)s) %(title)s"',
        'parsed site: NA',
        'parsed id: NA',
        'parsed title: NA',
        'parsed uploader: NA',
        'parsed uploader_id: NA',
        'parsed uploader_url: NA',
        'parsed channel: NA',
        'parsed channel_id: NA',
        'parsed channel_url: NA'
    ]

# Generated at 2022-06-12 19:15:30.518868
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.downloader import YoutubeDL
    from youtube_dl import FileDownloader

    # pylint: disable=protected-access
    fd = FileDownloader(YoutubeDL({}))
    format = '%(title)s - %(artist)s'
    title = 'Test Title - Test Artist'
    info = {
        'title': title,
        'id': 'id'
    }
    pp = MetadataFromTitlePP(fd, format)
    info2 = pp._run(info)
    assert info2 is not None
    assert info2['title'] == 'Test Title - Test Artist'
    assert info2['artist'] == 'Test Artist'

    format = '%(title)s '
    title = 'Test Title'

# Generated at 2022-06-12 19:15:40.707953
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import collections

    # For testing, let us create a dummy downloader instance
    class Dummy_downloader_instance:
        def __init__(self):
            self._downloader = None

        def to_screen(self, msg):
            print(msg)

    # Let's use a custom info dict
    info = collections.OrderedDict()
    info["title"] = "This is the title"
    info["artist"] = "This is the artist"
    # Creating instance of MetadataFromTitlePP
    postprocessor = MetadataFromTitlePP(Dummy_downloader_instance(),
                                        "%(title)s")
    # Testing for title
    # Expecting "This is the title" to be returned

# Generated at 2022-06-12 19:15:46.890454
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Initializing MetadataFromTitlePP
    # ffmpegDownloader is a non-instantiable class
    # It is used to initialize attributes
    # in its subclass MetadataFromTitlePP
    # OK to use any class for testing purpose
    youtube_dl_test = "youtube-dl"

# Generated at 2022-06-12 19:15:55.239895
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
  from .downloader import YoutubeDL
  from .compat import compat_urllib_parse_unquote_plus, compat_urlparse
  import os

  # Helper function for checking
  def check_pp(titleformat, urllist, infodict, expected_infodict):
    # Create downloader
    downloader = YoutubeDL(params={'writethumbnail':True})
    downloader.add_info_extractor(lambda x:x)
    # Create PostProcessor
    pp = MetadataFromTitlePP(downloader, titleformat)

    # Call 'run' with url list and info dict
    # and check that the info dict is as expected
    (urls, info) = pp.run(infodict)
    assert info == expected_infodict, (info, expected_infodict)

    # Remove the th

# Generated at 2022-06-12 19:16:03.959156
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class FakeYDL:
        def to_screen(self, s):
            pass

    class FakeInfoDict:
        def __init__(self, title):
            self['title'] = title

    # Test to check if title is parsed correctly.
    title_format = '%(artist)s - %(title)s'
    title = 'The Beatles - Something'
    down = MetadataFromTitlePP(FakeYDL(), title_format)
    info = FakeInfoDict(title)
    down.run(info)
    assert info['artist'] == 'The Beatles'
    assert info['title'] == 'Something'

    # Test to check if value is missing.
    title = 'The Beatles'
    down = MetadataFromTitlePP(FakeYDL(), title_format)
    info = FakeInfoDict(title)
    down

# Generated at 2022-06-12 19:16:15.396380
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from collections import defaultdict
    info = defaultdict(lambda: 'NA')
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(album)s - %(genre)s')
    info['title'] = 'test title - test artist - test album - test genre'
    expected_info = defaultdict(lambda: 'NA',
                                title='test title',
                                artist='test artist',
                                album='test album',
                                genre='test genre')
    actual_info = info.copy()
    pp.run(actual_info)
    assert actual_info == expected_info
    info['title'] = 'test title - test val1'

# Generated at 2022-06-12 19:16:27.061401
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.PostProcessor import PostProcessor
    from youtube_dl.utils import DateRange


# Generated at 2022-06-12 19:16:39.120458
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    info = {'title': 'Lorem ipsum'}
    assert pp.run(info) == ([], {'title': 'Lorem ipsum', 'artist': None})
    info = {'title': 'Lorem - ipsum'}
    assert pp.run(info) == ([], {'title': 'Lorem - ipsum', 'artist': None})
    info = {'title': 'Lorem - ipsum - dolor'}
    assert pp.run(info) == ([], {'title': 'Lorem - ipsum - dolor', 'artist': None})
    info = {'title': 'Lorem - ipsum - sit - amet'}

# Generated at 2022-06-12 19:16:51.173567
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.http import HttpFD
    from .common import parseOpts
    from .test_download import getTestCase
    from .test_match_filter import MatchFilterTest
    _, ydl = parseOpts(('--write-info-json',),
                       {'outtmpl': '%(title)s', 'nooverwrites': True})
    ydl.add_post_processor(
        MetadataFromTitlePP(ydl, '%(title)s - %(artist)s - %(track)s - Sendung vom %(date)s'))

# Generated at 2022-06-12 19:16:57.811101
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl
    import platform
    pp = MetadataFromTitlePP(youtube_dl.YoutubeDL(), '%(artist)s - %(title)s')
    assert pp.run({'title': 'Super Duper Monster Furry Freak'}) == (
        [], {'title': 'Super Duper Monster Furry Freak'})
    assert pp.run({'title': 'Artist - Super Duper Monster Furry Freak'}) == (
        [], {'title': 'Artist - Super Duper Monster Furry Freak'})
    assert pp.run({'title': 'Artist - Super Duper Monster Furry Freak [1234]'}) == (
        [], {'title': 'Artist - Super Duper Monster Furry Freak [1234]'})
    assert pp.run({'title': 'Artist - Super Duper Monster Furry Freak (1234)'})

# Generated at 2022-06-12 19:17:01.645918
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class DummyDownloader:
        def to_screen(self, msg):
            pass
        def report_warning(self, msg):
            pass

    from .postprocessor import PostProcessingError

    # Test the data parsing
    postprocessor = MetadataFromTitlePP(DummyDownloader(),
        '%(artist)s - %(title)s')

    # Test a successful match
    metadata = postprocessor.run({
        'title': 'Foo - Bar',
    })[1]

    assert metadata == {
        'title': 'Bar',
        'artist': 'Foo'
    }

    # Test the string escaping
    postprocessor = MetadataFromTitlePP(DummyDownloader(),
        '%(artist)s - %(title)s')

    # Test a successful match

# Generated at 2022-06-12 19:17:08.208468
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # dummy argument parser
    class ArgParser:
        def __init__(self):
            self.excludes = []

    class Downloader:
        def __init__(self):
            self.to_screen_calls = []

        def to_screen(self, s):
            self.to_screen_calls.append(s)

    class FakeYDL:
        def __init__(self):
            self.params = ArgParser()


# Generated at 2022-06-12 19:17:14.013939
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    info_dict = {'title': 'A title - With Artist'}
    output_dict = {'title': 'A title', 'artist': 'With Artist'}
    test_run = MetadataFromTitlePP(None, '%(title)s - %(artist)s').run(info_dict)
    assert test_run[1] == output_dict

# Generated at 2022-06-12 19:17:21.497059
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    downloader = MockYoutubeDl()
    downloader.params = {'extract_flat': 'invalid_key'}
    titleformat = '%(title)s'

    pp = MetadataFromTitlePP(downloader, titleformat)
    info = {'title': 'The Title'}

    assert (pp.run(info)[1] == {'uploader': 'NA', 'title': 'The Title'})
    assert (pp.run({'title': 'The-Title'})[1] == {'uploader': 'NA', 'title': 'The-Title'})
    assert (pp.run({'title': '  The Title  '})[1] == {'uploader': 'NA', 'title': '  The Title  '})

# Generated at 2022-06-12 19:17:29.316839
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import pytest
    from ytdl.YoutubeDL import YoutubeDL
    from .common import YoutubeDLHandler
    from .postprocessor import SubtitleConverterPP, FFmpegMetadataPP
    
    # downloader
    ydl = YoutubeDL({'verbose':True,
                     'writeautomaticsub':True,
                     'allsubtitles':True,
                     'writesubtitles':True,
                     'continue_dl':True,
                     'noprogress':True,
                     'format':'bestaudio/best',
                     'quiet':True})

    # add postprocessors
    ydl.add_post_processor(FFmpegMetadataPP())
    ydl.add_post_processor(SubtitleConverterPP())

# Generated at 2022-06-12 19:17:49.793577
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl

    downloader = youtube_dl.YoutubeDL({})
    metadata_from_titlePP = MetadataFromTitlePP(
        downloader,
        '%(title)s - %(artist)s - %(album)s - %(track)s'
    )

    # Test 1: full title
    test_title = 'title - artist - album - track'
    info = {'title': test_title}
    metadata_from_titlePP.run(info)

    assert info['title'] == 'title'
    assert info['artist'] == 'artist'
    assert info['album'] == 'album'
    assert info['track'] == 'track'

    # Test 2: missing track
    test_title = 'title - artist - album - '
    info = {'title': test_title}
    metadata_

# Generated at 2022-06-12 19:18:00.957699
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    def _get_result(pp, title, titleformat):
        pp._titleformat = titleformat
        pp._titleregex = (pp.format_to_regex(titleformat)
                          if re.search(r'%\(\w+\)s', titleformat)
                          else titleformat)
        info = {'title': title, 'artist': None, 'album': None}
        return pp.run(info)

    downloader = type('FakeD', (), {'to_screen': lambda *args, **kwargs: None})
    downloader.to_screen = sys.stdout.write
    pp = MetadataFromTitlePP(downloader, '%(artist)s - %(title)s')

# Generated at 2022-06-12 19:18:12.020951
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    import os

# Generated at 2022-06-12 19:18:16.710286
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pp = MetadataFromTitlePP(None,'%(title)s - %(artist)s')
    info = {}
    info['title'] = 'Video title - Artist'
    pp.run(info)
    assert info['title'] == 'Video title'
    assert info['artist'] == 'Artist'


# Generated at 2022-06-12 19:18:25.562766
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL

    myYDL = YoutubeDL({})
    myYDL.add_post_processor(MetadataFromTitlePP(myYDL, '%(title)s-%(artist)s'))
    m = myYDL.postprocessors[-1]

    info = {'title': 'My new title'}
    assert m.run(info) == ([], {'title': 'My new title'})

    info = {'title': 'My new title-by artist'}
    assert m.run(info) == ([], {'title': 'My new title-by artist', 'artist': 'by artist'})

    info = {'title': 'My new title--my own artist'}

# Generated at 2022-06-12 19:18:34.774710
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import subprocess
    import sys
    import unittest

    from .common import FileDownloader

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.downloader = FileDownloader(params={
                'outtmpl': '%(id)s.%(ext)s',
                'nooverwrites': True,
                'quiet': True,
                'restrictfilenames': True,
                'format': 'bestaudio/best',
                'postprocessors': [{
                    'key': 'MetadataFromTitle',
                    'titleformat': self.titleformat,
                }]
            })
            self.downloader.add_info_extractor(
                YoutubeIE(self.downloader))

        def tearDown(self):
            self.downloader.clean

# Generated at 2022-06-12 19:18:44.495842
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl.YoutubeDL import YoutubeDL
    downloader = YoutubeDL()
    processor = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    info = {'title': 'myTitle - myArtist'}
    processor.run(info)
    assert info['title'] == 'myTitle'
    assert info['artist'] == 'myArtist'
    info = {'title': 'myTitle - myArtist - myAlbum - myLabel'}
    processor.run(info)
    assert info['title'] == 'myTitle'
    assert info['artist'] == 'myArtist'
    assert 'album' not in info
    processor = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s - %(album)s')

# Generated at 2022-06-12 19:18:50.100241
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .test import get_test_data_subfolder

    from ..YoutubeDL import YoutubeDL
    from ..extractor.youtube import YoutubeIE

    test_data_folder = get_test_data_subfolder()
    # A video with no explicit metadata or title format
    video_file = test_data_folder.join('youtube-test', 'y_mv_yt.webm')

    ydl = YoutubeDL({
        'writedescription': True,
        'outtmpl': '-',
        'format': 'bestvideo+bestaudio',
        'writethumbnail': True,
        'writeinfojson': True,
        'ignoreerrors': False,
    })

    info = ydl.extract_info(video_file, download=False)

# Generated at 2022-06-12 19:18:58.991079
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    if sys.version_info < (3, 0):
        from io import BytesIO
    else:
        from io import StringIO

    meta = {'title': 'title'}
    meta2 = {'title': 'this is a test'}
    meta3 = {'title': 'This is a Test'}

    # Test 1
    pp = MetadataFromTitlePP(None, '%(title)s')
    res, _ = pp.run(meta)
    assert res == []
    assert meta == {'title': 'title'}

    # Test 2
    pp = MetadataFromTitlePP(None, '%(title)s')
    res, _ = pp.run(meta2)
    assert res == []
    assert meta2 == {'title': 'this is a test'}

    # Test

# Generated at 2022-06-12 19:19:08.311537
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    title = '%(title)s - %(artist)s'
    mft = MetadataFromTitlePP(None, title)
    # Test that the correct regex is generated
    assert mft._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    # Test that a title that matches the regex works
    match = re.match(mft._titleregex, title)
    assert match.group('title') == '%(title)s'
    assert match.group('artist') == '%(artist)s'

    # Test that a title that does not match the regex does not work
    title = '%(title)s - %(artist)s - testing'
    match = re.match(mft._titleregex, title)
    assert match is None


# Generated at 2022-06-12 19:19:31.202397
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass



# Generated at 2022-06-12 19:19:41.003251
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import datetime
    from mock import Mock
    from ydl.downloader import Downloader
    mock_downloader = Mock(spec=Downloader)
    testpp = MetadataFromTitlePP(mock_downloader, '%(artist)s - %(title)s')

    # test: pass None as info
    res = testpp.run(None)
    mock_downloader.to_screen.assert_called_once_with(
                                 '[fromtitle] Could not interpret title of video as "%s"'
                                 % testpp._titleformat)
    assert res == ([], None)

    # test: pass a string as info
    res = testpp.run('test string')

# Generated at 2022-06-12 19:19:48.059048
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    postprocessor = MetadataFromTitlePP(YoutubeDL(), '%(artist)s - %(title)s')
    #
    # Failure case
    #
    info = {'title': 'Not an artist - Not a title'}
    postprocessor.run(info)
    assert info['title'] == 'Not an artist - Not a title'
    assert 'artist' not in info
    #
    # Successful case
    #
    info = {'title': 'An artist - A title'}
    postprocessor.run(info)
    assert info['title'] == 'An artist - A title'
    assert info['artist'] == 'An artist'
    #
    # Failure case (no re.escape)
   

# Generated at 2022-06-12 19:19:55.700108
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class FakeDownloader:
        def to_screen(self, msg):
            pass

    fromtitle = MetadataFromTitlePP(FakeDownloader(), '%(title)s - %(artist)s')
    info = {'title': 'name - author'}
    to_return, info = fromtitle.run(info)
    assert len(to_return) == 0
    assert info.keys() == {'title', 'artist'}
    assert info['title'] == 'name'
    assert info['artist'] == 'author'
