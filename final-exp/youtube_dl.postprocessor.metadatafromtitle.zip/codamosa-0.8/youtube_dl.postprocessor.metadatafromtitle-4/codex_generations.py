

# Generated at 2022-06-12 19:10:06.717111
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-12 19:10:16.582842
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title = MetadataFromTitlePP(None, '%(artist)s_-_%(title)s')
    # Testing method run with a correct title
    assert metadata_from_title.run({'title': 'bob_marley_-_songs_of_freedom'}) == ([], {'title': 'bob_marley_-_songs_of_freedom', 'artist': 'bob_marley', 'title': 'songs_of_freedom'})

    # Testing method run with an incorrect title
    assert metadata_from_title.run({'title': 'bob_marley_-_'}) == ([], {'title': 'bob_marley_-_'})



# Generated at 2022-06-12 19:10:20.832738
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class DummyDownloader():
        def to_screen(self, x):
            print(x)
    video_info = {'title': 'The video title'}
    processor = MetadataFromTitlePP(DummyDownloader(), '%(title)s')
    _, video_info = processor.run(video_info)
    assert video_info == {'title': 'The video title'}
    processor = MetadataFromTitlePP(DummyDownloader(), '%(title)s - %(artist)s')
    _, video_info = processor.run(video_info)
    assert video_info == {'title': 'The video title', 'artist': 'NA'}



# Generated at 2022-06-12 19:10:25.357237
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    fmt = '%(title)s - %(artist)s'
    title = 'Foo - Bar'
    info = {
        'title': title
    }
    pp = MetadataFromTitlePP(None, fmt)
    pp.run(info)
    assert info['title'] == title
    assert info['artist'] == 'Bar'



# Generated at 2022-06-12 19:10:36.253387
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Given
    from ydl.downloader import YDL
    from ydl.options import Options
    from ydl.utils import FileDownloader
    options = Options()
    ydl = YDL(options)
    from ydl.postprocessor import PostProcessor
    from ydl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from ydl.extractor import YoutubeIE
    extractor = YoutubeIE(ydl)
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    info = {'title': 'video title - video artist'}
    # When
    pp.run(info)
    # Then
    assert info['title'] == 'video title'
    assert info['artist'] == 'video artist'



# Generated at 2022-06-12 19:10:44.627489
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test = MetadataFromTitlePP(None, '%(title)s - %(chapter)s - %(track)s - %(artist)s')
    info = {'title': 'title - chapter - track - artist'}
    _, info_updated = test.run(info)
    assert info_updated['title'] == 'title'
    assert info_updated['chapter'] == 'chapter'
    assert info_updated['track'] == 'track'
    assert info_updated['artist'] == 'artist'

    info = {'title': 'title - chapter - track - artist - bonus'}
    _, info_updated = test.run(info)
    assert info_updated['title'] == 'title'
    assert info_updated['chapter'] == 'chapter'
    assert info_updated['track'] == 'track'
    assert info_updated

# Generated at 2022-06-12 19:10:54.953258
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    fmt_to_regex = MetadataFromTitlePP.format_to_regex

# Generated at 2022-06-12 19:11:05.264011
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    if sys.version_info < (3, 0):
        from StringIO import StringIO
    else:
        from io import StringIO
    from ytdl.YoutubeDL import YoutubeDL
    

# Generated at 2022-06-12 19:11:15.213414
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.compat import compat_urlparse
    from youtube_dl import YoutubeDL

    class MockYoutubeDL(YoutubeDL):

        def __init__(self, *_args, **_kwargs):
            super(MockYoutubeDL, self).__init__(*_args, **_kwargs)
            self.to_screen_output = []

        def to_screen(self, msg):
            self.to_screen_output.append(msg)

    url = 'http://www.youtube.com/watch?v=Wg0jf__JLXg'

# Generated at 2022-06-12 19:11:23.533762
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Dummy objects to make necessary calls available
    class DummyYDL:
        def to_screen(self, str):
            pass
    class DummyIE:
        def __init__(self):
            self.downloader = DummyYDL()

    # Create an instance of the MetadataFromTitlePP post-processing class
    pp = MetadataFromTitlePP(DummyIE(), '%(title)s - %(artist)s - %(album)s')

    # ---------------------------------------------------------
    # Test 1: Regex and format string are correctly generated
    # ---------------------------------------------------------
    # Check if attribute _titleregex of the post-processing object
    # is correctly set to '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'
    # which is the regex matching all values

# Generated at 2022-06-12 19:11:37.342283
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Create a dummy downloader
    class DummyDownloader:
        def to_screen(self, msg):
            pass
    # Create a Info Dictionary
    info = {
        'title': 'Test - This is a test!',
        'artist': '',
        'album': '',
    }
    # Assert that the empty values of the info dictionary are empty
    for value in info.values():
        assert value == ''
    # Create the MetadataFromTitlePP object
    mft = MetadataFromTitlePP(DummyDownloader(), '%(artist)s - %(title)s!')
    # Execute run and assert that info was updated
    mft.run(info)
    assert info['artist'] == 'Test'
    assert info['title'] == 'This is a test'
    assert info['album'] == ''

# Generated at 2022-06-12 19:11:45.146404
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest
    import sys

    if sys.version_info < (3, 4, 0):
        print('TODO: Unittest for MetadataFromTitlePP.run '
              'for python > 3.3.0')
        return

    class MockInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(MockInfoDict, self).__init__(*args, **kwargs)
            self.pop(None, None)

        def __getitem__(self, key):
            if key in self:
                return self.get(key)
            else:
                raise KeyError('MockInfoDict: The key %s does not exist'
                               % key)


# Generated at 2022-06-12 19:11:50.017812
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import Downloader
    downloader = Downloader()
    video = {'title': 'foo - bar'}
    parser = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    _, video = parser.run(video)
    assert video['title'] == 'foo'
    assert video['artist'] == 'bar'

# Generated at 2022-06-12 19:11:58.311446
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.extractor.youtube import YoutubeIE
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import YoutubeDLError
    
    #import sys
    #sys.argv = ['youtube-dl', '-l', 'http://www.youtube.com/watch?v=fhKeHEvMgF8']
    ydl_opts = {}

    ydl = YoutubeDL(ydl_opts)
    test_ie = YoutubeIE(ydl)


# Generated at 2022-06-12 19:12:07.838412
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # define test data
    regex_match_format = '%(title)s - %(artist)s'
    regex_match_ifmt = '%(title)s - %(artist)s'
    regex_match_title = 'title - artist'
    regex_match_infodict = {
        'title': 'title',
        'artist': 'artist',
    }
    regex_no_match_format = '%(title)s - %(artist)s'
    regex_no_match_ifmt = '%(title)s - %(artist)s'
    regex_no_match_title = 'title - artist - album'
    regex_no_match_infodict = {
        'title': 'title',
        'artist': 'artist',
        'album': 'album',
    }
    string_

# Generated at 2022-06-12 19:12:17.515743
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # prepare the input info dict
    info = {'title': 'Foo - Bar'}

    # prepare the downloader object and the related options
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL({'writedescription': False})
    ydl.to_screen = lambda *args, **kargs: (args, kargs)

    # prepare the pp object
    fromtitle_pp = MetadataFromTitlePP(ydl, '%(artist)s - %(song)s')

    # no exceptions should be raised and the info dict should be populated
    assert fromtitle_pp.run(info)[1] == {'title': 'Foo - Bar',
                                         'artist': 'Foo',
                                         'song': 'Bar'}

    # test a non-matching title

# Generated at 2022-06-12 19:12:18.047373
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass

# Generated at 2022-06-12 19:12:25.393643
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # import doctest
    # doctest.testmod()

    import sys
    sys.path.append('..')

    from youtube_dl.YoutubeDL import YoutubeDL


# Generated at 2022-06-12 19:12:34.688723
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import pytube
    downloader = pytube.YoutubeDL(dict(noplaylist=True,quiet=True))
    yt = downloader.extract_info(
        "https://www.youtube.com/watch?v=0uECO5QQOQk",
        download=False
    )
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    out, info = pp.run(yt)
    assert out == []
    assert info['title'] == 'Tiny Dancer'
    assert info['artist'] == 'Elton John'
    assert info['upload_date'] == '20101004'

# Generated at 2022-06-12 19:12:40.413271
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # input values
    info = {'title': 'Umpah Pah - The Beatles'}

    # tested method
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    _, output_info = pp.run(info)

    # asserts
    assert 'artist' in output_info
    assert output_info['artist'] == 'The Beatles'
    assert 'title' in output_info
    assert output_info['title'] == 'Umpah Pah'

# Generated at 2022-06-12 19:12:54.270347
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import os
    import unittest
    class MockYoutubeDL():
        def __init__(self):
            self.to_screen_list = []
        def to_screen(self, msg):
            self.to_screen_list.append(msg)
    class MockInfo():
        def __init__(self):
            self.dict = {'title': 'Test - 1234 - Foo Bar'}
    # import test_utils
    downloader = MockYoutubeDL()
    parser = MetadataFromTitlePP(downloader, '%(title)s - %(track)s - %(artist)s')
    info = MockInfo()
    parser.run(info.dict)

# Generated at 2022-06-12 19:13:01.194145
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import Downloader
    downloader = Downloader(dict())
    pp = MetadataFromTitlePP(downloader, '%(channel)s - %(title)s')
    info = {'title': 'Disco Polo Dance Mix - XxXxXxXxXxXxX'}
    expected = {'title': 'XxXxXxXxXxXxX',
                'channel': 'Disco Polo Dance Mix'}
    actual = pp.run(info)[1]
    assert expected == actual

# Generated at 2022-06-12 19:13:07.728230
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .compat import compat_urllib_error, compat_urllib_request
    from .compat import compat_urllib_error_URLError
    from .compat import compat_urlparse
    from .compat import compat_urllib_parse_unquote
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_str
    from .common import urlhandle
    from .downloader import FakeYDL

    downloader = FakeYDL()
    downloader.params = {'cachedir': False, 'noplaylist': True}
    url = 'http://example.com/file.mp3'
    urlh = urlhandle.BytesURLHandle(url, None, None)
    urlh.url = url

# Generated at 2022-06-12 19:13:12.299896
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    video_info = {'title': 'AnyVideo', 'url': 'AnyUrl', 'id': 'AnyId',
                  'display_id': 'AnyDisplayId'}
    md = MetadataFromTitlePP(None, '%(title)s')
    [], video_info_updated = md.run(video_info)
    assert video_info_updated['title'] == 'AnyVideo'


# Generated at 2022-06-12 19:13:22.633674
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.compat import compat_str
    from six import StringIO
    ydl = YoutubeDL()

    ydl.params['download_archive'] = 'archive.txt'
    stream = StringIO()
    ydl.params['outtmpl'] = '%(video_id)s_%(title)s_%(upload_date)s_%(autonumber)s.%(ext)s'
    ydl.params['writedescription'] = False
    ydl.params['writeannotations'] = False
    ydl.params['no_warnings'] = True
    ydl.params['ignoreerrors'] = True
    ydl.params['start_date'] = DateRange('20100101')
    ydl

# Generated at 2022-06-12 19:13:31.563639
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange

    d = FileDownloader({'simulate': True, 'logger': FileDownloader._logger})


# Generated at 2022-06-12 19:13:38.086756
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    ydl = None
    title = "This is a Test Video Title - YouTube with author"
    titleformat = "%(title)s - YouTube with %(author)s"

    pp = MetadataFromTitlePP(ydl, titleformat)
    info = {'title': title}
    _, info_updated = pp.run(info)

    assert info_updated['title'] == "This is a Test Video Title"
    assert info_updated['author'] == "author"

# Generated at 2022-06-12 19:13:47.916494
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-12 19:13:53.345048
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from collections import OrderedDict
    from ytdl.YoutubeDL import YoutubeDL
    ydl_opts = OrderedDict([('postprocessors', [MetadataFromTitlePP(None, '%(title)s')])])
    ydl = YoutubeDL(ydl_opts)
    info = dict(title='MyTitle')
    results = dict(title='MyTitle')
    assert MetadataFromTitlePP.run(None, info) == ([], results)


# Generated at 2022-06-12 19:13:54.485627
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass



# Generated at 2022-06-12 19:14:04.254375
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    title = 'I have a title with %(special)s in it'
    info = {'title': title}
    mftpp = MetadataFromTitlePP(None, '%(special)s')
    mftpp.format_to_regex = lambda fmt: '\(.*\)' if fmt == '%(special)s' else fmt
    assert mftpp.run(info) == ([], {'title': title, 'special': 'stuff'})

# Generated at 2022-06-12 19:14:14.663200
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test output of class method format_to_regex()
    assert MetadataFromTitlePP._format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    # Test output of class method run()
    assert MetadataFromTitlePP.run({'title':'some title - some artist'}, '%(title)s - %(artist)s') == ({'title':'some title', 'artist':'some artist'}, None)
    assert MetadataFromTitlePP.run({'title':'some title -- some artist'}, '%(title)s - %(artist)s') == ({'title':'some title -- some artist'}, None)

# Generated at 2022-06-12 19:14:24.958046
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl.YoutubeDL import YoutubeDL
    titleformat = '%(title)s - %(artist)s'
    title = 'Foo - Bar'
    ydl = YoutubeDL(dict(writethumbnail=True,
                         writeinfojson=True,
                         infoname='%(id)s.info.json',
                         titleformat=titleformat))
    ydl.add_post_processor(MetadataFromTitlePP(ydl, titleformat))
    info = {'title': title}
    ydl.process_ie_result(info, download=False)
    assert info['title'] == 'Foo'
    assert info['artist'] == 'Bar'

if __name__ == '__main__':
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-12 19:14:25.830665
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass


# Generated at 2022-06-12 19:14:34.686594
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    import unittest
    import mock

    def side_effect_factory(mocked_downloader, mocked_to_screen, mocked_to_stderr, mocked_to_stdout):
        def side_effect(self, msg, *args):
            if self is mocked_to_screen.return_value and args != ():
                if msg == '[fromtitle] Could not interpret title of video as "%s"':
                    mocked_to_screen.assert_any_call('[fromtitle] ' + msg, '%(title)s - %(artist)s')
                    mocked_to_screen.side_effect = None
                    return

# Generated at 2022-06-12 19:14:45.533342
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    info = {'title': 'My Title - My Artist'}
    pp.run(info)
    assert (info['title'] == 'My Title' and
            info['artist'] == 'My Artist')

    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    info = {'title': 'My Title - My Artist - Some more'}
    pp.run(info)
    assert (info['title'] == 'My Title' and
            info['artist'] == 'My Artist')

    pp = MetadataFromTitlePP(None, '%(title)s')
    info = {'title': 'My Title'}
    pp.run(info)

# Generated at 2022-06-12 19:14:50.565486
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class MockDownloader(object):
        def to_screen(self, message):
            assert message == '[fromtitle] parsed foo: bar'
    postprocessor = MetadataFromTitlePP(None, '%(foo)s')
    info = {'title': 'bar'}
    postprocessor._downloader = MockDownloader()
    postprocessor.run(info)

# Generated at 2022-06-12 19:15:01.389909
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    import unittest
    class test_object(object):
        def __init__(self):
            self.to_screen_called = False
        def to_screen(self, string):
            self.to_screen_called = True

    # Test regex matching
    regex = r'(?P<artist>.+)\ \-\ (?P<title>.+)'
    title = 'Foo - Bar'
    match = re.match(regex, title)
    assert match is not None
    assert match.group('artist') == 'Foo'
    assert match.group('title') == 'Bar'

    # Test format_to_regex
    fmt = '%(artist)s - %(title)s'
    regex = '^(?P<artist>.+)\ \-\ (?P<title>.+)$'
   

# Generated at 2022-06-12 19:15:09.615309
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ..downloader.common import FileDownloader
    from ..utils import DateRange

    class FakeInfo(object):
        def __init__(self, title):
            self.title = title

    options = {'format': '%(title)s-%(artist)s-%(date)s-%(id)s'}
    downloader = FileDownloader({'format': 'best'}, options=options)
    pp = MetadataFromTitlePP(downloader, options['format'])
    # valid titles

    info = FakeInfo(title='simple title')
    assert pp.run(info) == ([], {'title': 'simple title'})

    info = FakeInfo(title='title with %')
    assert pp.run(info) == ([], {'title': 'title with %'})


# Generated at 2022-06-12 19:15:19.328376
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import pytest
    from ytdl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s'))
    info = {'title': 'Hello World - Youtubedl'}
    ydl.process_ie_result(info)
    assert info['title'] == 'Hello World'
    assert info['artist'] == 'Youtubedl'
    info = {'title': 'Hello World - Youtubedl -'}
    ydl.process_ie_result(info)
    assert info['title'] == 'Hello World - Youtubedl'
    assert info['artist'] == '-'
    info = {'title': 'Hello World - Youtubedl'}


# Generated at 2022-06-12 19:15:35.829741
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Import here, to prevent from import errors when testing from this directory
    from .__main__ import FileDownloader
    from .common import FileDownloader
    import unittest
    import os.path
    import shutil
    import tempfile
    import sys

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.ydl = FileDownloader({'format': 'best', 'outtmpl': os.path.join(self.tempdir, '%(title)s.%(ext)s'), 'verbose': True, 'logger': self.ydl.logger})
            self.title_pp = MetadataFromTitlePP(self.ydl, '%(title)s - %(artist)s')


# Generated at 2022-06-12 19:15:44.847080
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-12 19:15:47.438114
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert MetadataFromTitlePP.run(None, {}) == ([], {})


# Generated at 2022-06-12 19:15:52.423143
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    downloader = YoutubeDL({'title': '%(title)s'})
    pp = MetadataFromTitlePP(downloader, '%(title)s')
    info = pp.run({'title': 'MetadataFromTitle'})
    assert info == ([], {'title': 'MetadataFromTitle'})


# Generated at 2022-06-12 19:16:01.817225
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys

    import pytest

    from .common import FakeYDL, FakeIE

    if sys.version_info < (3, ):
        pytest.skip('Test is not valid for Python 2.x')

    def format_to_regex(fmt):
        r"""
        Converts a string like
           '%(title)s - %(artist)s'
        to a regex like
           '(?P<title>.+)\ \-\ (?P<artist>.+)'
        """
        lastpos = 0
        regex = ''
        # replace %(..)s with regex group and escape other string parts
        for match in re.finditer(r'%\((\w+)\)s', fmt):
            regex += re.escape(fmt[lastpos:match.start()])

# Generated at 2022-06-12 19:16:11.828200
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Create a MetadataFromTitlePP object with a testing downloader
    class TestDownloader(object):
        def to_screen(self, message):
            pass # do nothing
    from .downloader import Downloader
    downloader = Downloader(TestDownloader())
    metadatapp = MetadataFromTitlePP(downloader, titleformat='%(title)s - %(artist)s')

    # Run the method run with title: 'My title - My artist'
    from .InfoExtractors import YoutubeIE
    yt_info = {
        'id': 'id',
        'title': 'My title - My artist',
        'extractor': YoutubeIE.ie_key()
    }
    result_info = metadatapp.run(yt_info)[1]
    assert result_info['title'] == 'My title'
    assert result_

# Generated at 2022-06-12 19:16:16.827302
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test if MetaDataFromTitlePP can parse the title of a video as:
    #    Artist Name - Video Title - Album Name
    mp4_mp3_video_title = 'Sophie Zelmani - Going Home - Precious Burden'
    from youtube_dl.downloader.common import FileDownloader
    fd = FileDownloader(params={}, cache=None,
                        downloader_opts={'username':''})
    mft = MetadataFromTitlePP(fd, '%(artist)s - %(title)s - %(album)s')
    info = {'title': mp4_mp3_video_title}
    fd.to_screen = lambda s: s.encode('utf-8')
    # print 'video_title', video_title, '\nregex', mft._titleregex


# Generated at 2022-06-12 19:16:27.845608
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test setup
    info = {'title': 'Unittest - MetadataFromTitlePP - Run'}

    # Test execution

    # Test execution with missing attribute
    titleformat = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(None, titleformat)
    pp_output = pp.run(info)
    assert pp_output == ([], info)

    # Test execution with artist in title and missing album
    titleformat = '%(title)s - %(album)s'
    pp = MetadataFromTitlePP(None, titleformat)
    pp_output = pp.run(info)
    assert pp_output == ([], info)

    # Test execution with artist in title and missing albumartist
    titleformat = '%(title)s - %(albumartist)s'

# Generated at 2022-06-12 19:16:39.829260
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ydl.extractor.common import InfoExtractor
    from ydl.utils import DateRange

    options = {
        'simulate': True,
        'format': 'best',
        'writedescription': True,
        'writeinfojson': True,
        'writeannotations': True,
        'writeautomaticsub': True,
        'writeinfoq': True,
    }


# Generated at 2022-06-12 19:16:51.874154
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader


# Generated at 2022-06-12 19:17:20.724498
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.postprocessor import PostProcessor
    import json
    import sys

    title = ('[Anime Land] Shokugeki no Souma S4 EP 23 (720p) - '
             'Shokugeki no Soma Episode 23 (Sub)')
    titleformat = '[%(name)s] %(title)s S%(season_number)s EP %(episode_number)s [%(resolution)s] - %(title)s Episode %(episode_number)s [%(language)s]'
    info = {'title': title}

    class DummyYDL(object):
        def __init__(self, to_screen):
            self.to_screen = to_screen


# Generated at 2022-06-12 19:17:28.691824
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import encode_data_uri

    # Some sample info dicts

# Generated at 2022-06-12 19:17:29.969869
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass

if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-12 19:17:36.148421
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import io
    from ydl.YoutubeDL import YoutubeDL
    from ydl.postprocessor.TestPP import TestPP

    def is_info_with_extracted_metadata(info):
        for attribute, value in [('title', 'Example Title'), ('artist', 'Example Artist'), ('album', 'Example Album')]:
            if attribute not in info or info[attribute] != value:
                return False
        return True

    # Prepare the output of ydl.download(...)

# Generated at 2022-06-12 19:17:47.135483
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class Info(dict):
        def __init__(self):
            self['title'] = 'The title'
    class Downloader:
        def to_screen(self, msg):
            print(msg)
    # test with format string containing one %(id)s group
    pp = MetadataFromTitlePP(Downloader(), '%(id)s')
    info = Info()
    info['title'] = 'The title'
    (result1, result2) = pp.run(info)
    assert result1 == []
    assert result2 == {'title': 'The title'}
    info['title'] = '123'
    (result1, result2) = pp.run(info)
    assert result1 == []
    assert result2 == {'id': '123', 'title': 'The title'}

# Generated at 2022-06-12 19:17:58.380981
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from YoutubeDL import YoutubeDL
    from YoutubeDL.extractor import _parse_mpd_formats

    # Setup a test object
    ydl = YoutubeDL({'restrictfilenames': True, 'writedescription': False,
                     'writeinfojson': False, 'writethumbnail': False,
                     'write_all_thumbnails': False, 'writeautomaticsub': False,
                     'writeannotations': False, 'write_sub': False})
    # Setup an info dict for this test
    info = dict()

    # First test, we will get all the attributes
    info['id'] = 'testid'
    info['title'] = 'this is a test title - with an artist - and an album'
    info['upload_date'] = '20120101'
    info['ext'] = 'mp4'

# Generated at 2022-06-12 19:18:05.936152
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ydl import YDL
    from ydl.postprocessor.common import PostProcessor
    from ydl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    downloader = YDL()
    pp = PostProcessor(downloader)
    pp.add_info_extractor(None) # FakeInfoExtractor
    d = {'title': 'Test title'}
    pp.run(d)
    assert d == {'title': 'Test title'}
    pp.add_post_processor(MetadataFromTitlePP(downloader, '%(title)s'))
    pp.run(d)
    assert d == {'title': 'Test title'}

    pp.add_post_processor(MetadataFromTitlePP(downloader, '%(artist)s'))
    pp.run(d)
    assert d

# Generated at 2022-06-12 19:18:16.072575
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    # Test attributes and metadata with no %(...)s in titleformat
    pp = MetadataFromTitlePP(None, 'mytitle')
    pp.format_to_regex = lambda fmt: fmt
    info = {'title': 'some title'}
    result = pp.run(info)
    assert result[0] == []
    assert info == {'title': 'some title'}

    # Test attributes and metadata with %(...)s in titleformat
    pp = MetadataFromTitlePP(None, '%(title)s')
    pp.format_to_regex = lambda fmt: 'my' + fmt + 'regex'
    info = {'title': 'some title'}
    result = pp.run(info)
    assert result[0] == []

# Generated at 2022-06-12 19:18:25.068518
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest
    import sys
    import os.path

    youtube_dl = sys.modules['youtube_dl']
    youtube_dl.utils = sys.modules['youtube_dl.utils']
    youtube_dl.compat = sys.modules['youtube_dl.compat']

    from youtube_dl import YoutubeDL
    from youtube_dl.compat import compat_str
    from youtube_dl.postprocessor import MetadataFromTitlePP

    class mock_downloader:
        to_screen_calls = []
        def to_screen(this, msg):
            this.to_screen_calls.append(msg)


# Generated at 2022-06-12 19:18:34.673175
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ..YoutubeDL import YoutubeDL

    class MockYoutubeDL(YoutubeDL):
        def __init__(self):
            self.to_screen_messages = []

        def to_screen(self, msg):
            self.to_screen_messages.append(msg)

    pp = MetadataFromTitlePP(MockYoutubeDL(), '%(title)s')

    # 1st test: no match
    info = dict(title='Lorem ipsum dolor sit amet')
    result, new_info = pp.run(info)

    assert len(result) == 0
    assert new_info == info
    assert (pp._downloader.to_screen_messages ==
        ['[fromtitle] Could not interpret title of video as "%(title)s"']
    )

    # 2nd test: match


# Generated at 2022-06-12 19:19:32.140411
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl import Downloader
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor

    class DummyInfoExtractor(InfoExtractor):
        IE_NAME = 'DummyIE'

        def __init__(self, downloader=None, ie_name=None, ie_id=None,
                     standards_compliant=True):
            super(DummyInfoExtractor, self).__init__(
                downloader, ie_name, ie_id, standards_compliant)

        def _real_extract(self, url):
            return {'title': 'DummyTitle'}

    info_extractor = DummyInfoExtractor(YoutubeDL({}))
    downloader = Downloader({})

# Generated at 2022-06-12 19:19:42.019773
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    md = MetadataFromTitlePP(None, "%(artist)s - %(title)s")
    assert md.format_to_regex("%(artist)s - %(title)s") == r'(?P<artist>.+)\ \-\ (?P<title>.+)'
    assert md.format_to_regex("%(artist)s - %(title)s - %(uploader)s") == r'(?P<artist>.+)\ \-\ (?P<title>.+)\ \-\ (?P<uploader>.+)'
    assert md.format_to_regex("(%(artist)s)") == r'\((?P<artist>.+)\)'
    assert md.format_to_regex("%(artist)s") == r'(?P<artist>.+)'

# Generated at 2022-06-12 19:19:48.073022
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import types
    import unittest
    import unittest.mock

    sys.modules['youtube_dl'] = types.ModuleType('youtube_dl')
    import youtube_dl
    sys.modules['youtube_dl.extractor'] = unittest.mock.Mock()
    from youtube_dl.postprocessor import MetadataFromTitlePP

    class MockDownloader(object):
        @staticmethod
        def to_screen(msg):
            print(msg)

    info = {
        'title': 'Foobar - Boobar',
        'artist': 'Foobar',
    }

    mftpp = MetadataFromTitlePP(MockDownloader(), '%(artist)s - %(title)s')

# Generated at 2022-06-12 19:19:54.482888
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    info = {
        'title': 'Hi! - Hello',
        'artist': '',
        'album': '',
    }
    pp.run(info)
    assert info['title'] == 'Hi!'
    assert info['artist'] == 'Hello'
    assert info['album'] == ''
