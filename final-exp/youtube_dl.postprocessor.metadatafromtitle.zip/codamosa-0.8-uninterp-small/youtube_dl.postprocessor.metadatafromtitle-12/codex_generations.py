

# Generated at 2022-06-26 13:44:05.819078
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP('(?P<title>.+)', 'nh5$')
    int_0 = metadata_from_title_p_p_0.__init__()
    str_0 = 'nh5$'
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_0, str_0)
    int_0 = metadata_from_title_p_p_1.__init__()
    str_0 = 'nh5$'
    metadata_from_title_p_p_2 = MetadataFromTitlePP(str_0, str_0)
    int_0 = metadata_from_title_p_p_2.__init__()
    int_0 = metadata_from_title_p_p_2.__init

# Generated at 2022-06-26 13:44:09.458381
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    fmt = '%(title)s - %(artist)s'
    regex = '%(title)s\ \-\ %(artist)s'
    assert regex == MetadataFromTitlePP._format_to_regex(fmt)



# Generated at 2022-06-26 13:44:18.901244
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test case for function run (case 0)
    str_0 = 'nh5$'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = 'nh5$'
    dict_0 = {'title':str_1}
    list_0, dict_1 = metadata_from_title_p_p_0.run(dict_0)
    assert len(list_0) == 0
    assert dict_1 == dict_0


# Generated at 2022-06-26 13:44:31.733934
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-26 13:44:38.102867
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    str_0 = ''
    str_1 = ''
    str_2 = ''
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_1)
    assert (metadata_from_title_p_p_0.format_to_regex(str_2) == str_2)

# Generated at 2022-06-26 13:44:41.144776
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    str_0 = 'nh5$'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)


if __name__ == '__main__':
    test_MetadataFromTitlePP()

# Generated at 2022-06-26 13:44:44.471023
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    arg_0 = {'title': 'test'}
    metadata_from_title_p_p_0 = MetadataFromTitlePP('nh5$', '%(title)s')
    metadata_from_title_p_p_0.run(arg_0)

# Generated at 2022-06-26 13:44:49.982165
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    titleformat_0 = '%(title)s'
    title_0 = 'nh5$'
    info_0 = {}
    info_0['title'] = title_0
    metadata_from_title_p_p_0 = MetadataFromTitlePP(title_0, titleformat_0)
    ret_0, ret_1 = metadata_from_title_p_p_0.run(info_0)



# Generated at 2022-06-26 13:44:53.645448
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'hello'
    assert_equal(MetadataFromTitlePP(str_0, str_0).run(str_0), ([], str_0))


# Generated at 2022-06-26 13:45:00.137833
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'nh5$'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = 'g5U9$'
    dict_0 = {str_1: str_0}
    int_0 = metadata_from_title_p_p_0.run(dict_0)
    #assert int_0 == [], 'AssertionError: 1 != 0, int_0 = ' + str(int_0)



# Generated at 2022-06-26 13:45:10.407671
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'hxf#'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = {
        'extractor': 'jn$@',
        'creator': 'u6*_',
        'thumbnail': 'x6~k',
        'id': '2u6o'
    }
    list_0 = []
    dict_1, dict_2 = metadata_from_title_p_p_0._run(dict_0)
    assert (dict_1 == list_0)
    assert (dict_2 == dict_0)


# Generated at 2022-06-26 13:45:13.438293
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '<span class=\"js-submenu\" title="submenu">submenu</span>'
    str_1 = 'http://www.unsubscribe-link.com'
    metadata_from_title_p_p_0 = Metadat

# Generated at 2022-06-26 13:45:17.903406
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'info[\'title\']'
    match_0 = None
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    assert metadata_from_title_p_p_0 != match_0


# Generated at 2022-06-26 13:45:26.643571
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    title = 'https://www.youtube.com/watch?v=Tl8Q_WyilvM'
    info = {'title': [title]}
    metadata_from_title_p_p_0 = MetadataFromTitlePP(title, title)
    #assert type(metadata_from_title_p_p_0) == 'str'
    #assert metadata_from_title_p_p_0 == 'u'
    assert type(info) == 'dict'
    res = metadata_from_title_p_p_0.run(info)
    #assert type(res) == 'list'
    #assert type(res[0]) == 'list'
    #assert res[0] == []
    #assert type(res[1]) == 'dict'
    #assert res[1] == {'title': [title

# Generated at 2022-06-26 13:45:30.649890
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'X(a)%(b)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = ''
    dict_0 = metadata_from_title_p_p_0.run(str_1)
    assert dict_0[0] == None

# Generated at 2022-06-26 13:45:36.147516
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_1 = 'nh5$'
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_1, str_1)
    metadata_from_title_dict_1 = {
        'title': str_1,
        'upload_date': str_1,
    }
    metadata_from_title_list_1 = []
    metadata_from_title_tuple_1 = (
        metadata_from_title_list_1,
        metadata_from_title_dict_1,
    )
    assert(metadata_from_title_p_p_1.run(metadata_from_title_dict_1) == metadata_from_title_tuple_1)

# Generated at 2022-06-26 13:45:46.891144
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'nh5$'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    m_dict_0 = {
        'ext': 'mp4',
        'title': 'some title',
        'description': 'description',
        'thumbnail': 'https://www.example.com/thumbnail.jpg',
        'formats': [{
            'format_id': '1',
            'filesize': '0B',
            'url': 'https://www.example.com/1.mp4',
            'ext': 'mp4',
            'vcodec': 'avc1.42E01E'
        }]
    }

    metadata_from_title_p_p_0.run(m_dict_0)

# Generated at 2022-06-26 13:45:48.086139
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert callable(MetadataFromTitlePP.run)

# Generated at 2022-06-26 13:45:50.444738
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert metadata_from_title_p_p_0.run(str_0) == ([], str_0)

# Generated at 2022-06-26 13:45:55.977595
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    param_0 = ('title', 'artist')
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, param_0)
    metadata_from_title_p_p_0.run(param_0)


#
# class YoutubeSubtitlePP
#

import xml.etree.ElementTree

import pysrt



# Generated at 2022-06-26 13:45:58.119719
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass


# Generated at 2022-06-26 13:46:06.618278
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    input_0 = {'title': 'sDFsfi4hh4h$'}
    output_0 = {}
    metadata_from_title_p_p_0 = MetadataFromTitlePP('sDFsfi4hh4h$', 'sDFsfi4hh4h$')
    metadata_from_title_p_p_1 = metadata_from_title_p_p_0
    metadata_from_title_p_p_0 = metadata_from_title_p_p_1.run(input_0)
    output_0['title'] = 'sDFsfi4hh4h$'
    assert output_0['title'] == metadata_from_title_p_p_0[1]['title']


# Generated at 2022-06-26 13:46:17.359564
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'nh5$'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = {}
    dict_0['title'] = 'fake@fake.com'
    dict_1 = {}
    dict_1['title'] = 'fake@fake.com'
    dict_2 = {}
    dict_2['title'] = 'fake@fake.com'
    dict_3 = {}
    dict_3['title'] = 'fake@fake.com'
    dict_4 = {}
    dict_4['title'] = 'fake@fake.com'
    dict_5 = {}
    dict_5['title'] = 'fake@fake.com'
    dict_5['format'] = '720p'
    dict_6 = {}
   

# Generated at 2022-06-26 13:46:26.044932
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'Video title - %(artist)s [%(resolution)s@%(vcodec)s]'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = []
    str_1.append('Video title - Artist [720p@h264]')
    str_1.append('Video title - Artist')
    str_2 = {}
    str_2['title'] = 'Video title - Artist [720p@h264]'
    str_2['artist'] = 'Artist'
    str_3 = []
    str_3.append(str_2)
    

# Generated at 2022-06-26 13:46:30.578838
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP('It\\,s\ \\-0 the\ \\\\a\ -o', '%(title)s - %(artist)s')

for i in range(0, 15):
    test_MetadataFromTitlePP_run()
    test_case_0()

# Generated at 2022-06-26 13:46:39.482540
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .compat import compat_urllib_request

    def _fake_urlopen(url):
        return compat_urllib_request.urlopen(url.replace('/v/', '/e/'))

    import youtube_dl
    ydl = youtube_dl.YoutubeDL({'restrictfilenames': True, 'outtmpl': '%(title)s.%(ext)s', 'format': 'bestaudio[ext=mp3]/best[ext=mp4]', 'postprocessors': [{'key': 'FFmpegExtractAudio', 'preferredcodec': 'mp3', 'preferredquality': '192'}, {'key': 'FFmpegMetadata'}]}).format()
    test_case_0()
    test_case_1()
    test_case_2()

# Generated at 2022-06-26 13:46:45.825870
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test for test_case_0
    str_0 = 'nh5$'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    # Test for test_case_1
    str_0 = 'b$'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)

# Generated at 2022-06-26 13:46:49.840889
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    r'''
    Unit test for method run of class MetadataFromTitlePP
    '''
    expected_output_0 = ([], {})

    # Call the tested method
    actual_output = metadata_from_title_p_p_0.run('*=')

    assert actual_output == expected_output_0


# Generated at 2022-06-26 13:46:52.969986
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP('dOUQ9hvYG_0', 'ImKjTbTZmxU')
    metadata_from_title_p_p_0.run(dict())


# Generated at 2022-06-26 13:47:03.290062
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'nh5$'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_0 = '8M4grFbzdM4'
    dict_0 = {'id': str_0}

    # Test case #0
    assert metadata_from_title_p_p_0.run(dict_0) == ([], dict_0)

    # Test case #1
    str_0 = 'U6qwA6pOoJE'
    dict_0 = {'id': str_0}
    assert metadata_from_title_p_p_0.run(dict_0) == ([], dict_0)

    # Test case #2
    str_0 = '0'

# Generated at 2022-06-26 13:47:09.874095
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '_^1_^_'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    info = {'title': '&&_'}
    assert metadata_from_title_p_p_0.run(info) == ([], {'title': '&&_'})


# Generated at 2022-06-26 13:47:13.362236
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    assert_equals(metadata_from_title_p_p_0.run(str_0), ('', str_0))


# Generated at 2022-06-26 13:47:15.659111
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, None)
    assert_equals(metadata_from_title_p_p_0.run(None), ([], None))

# Generated at 2022-06-26 13:47:17.871629
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'nh5$'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.run()


# Generated at 2022-06-26 13:47:27.807242
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    url = 'https://www.youtube.com/watch?v=zDmvhYkJF8k'
    params = {
        'usenetrc': False,
        'username': '',
        'password': '',
    }
    url_0 = url
    metadata_from_title_p_p_0 = MetadataFromTitlePP(url_0, '%(title)s')

# Generated at 2022-06-26 13:47:29.276027
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str, str)

# Generated at 2022-06-26 13:47:30.371611
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert 1 == 1


# Generated at 2022-06-26 13:47:35.298518
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'jxS&JMKX9'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = dict()
    dict_0['title'] = 'nh5$'
    list_0 = list()
    metadata_from_title_p_p_0.run(dict_0)



# Generated at 2022-06-26 13:47:37.923958
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'nh5$'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    # Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-26 13:47:41.501170
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = 'dRvd'
    dict_0 = dict()
    dict_0['title'] = str_1
    metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:47:46.537254
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # TODO: mock fd and call
    pass


# Generated at 2022-06-26 13:47:56.880837
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'NH5$'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)

    str_0 = '6Wtk22mzKmE'
    str_1 = 'YouTube'
    str_2 = 'e4y4__OIE-0'
    str_3 = 'Aloha! This is my first video ever!'
    str_4 = '1'


# Generated at 2022-06-26 13:48:05.206505
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'nh5$'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    # TODO: youtube_dl.downloader.YoutubeDL.to_screen(message, skip_eol=False) -> None
    # TODO: AssertionError: Value 'title' not found in info dict
    # TODO: AssertionError: Value 'artist' not found in info dict
    # TODO: AssertionError: Value 'track' not found in info dict
    # TODO: AssertionError: Value 'album' not found in info dict

# Generated at 2022-06-26 13:48:17.119447
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert Test.simple_run(MetadataFromTitlePP('www.YouTube.com - %(id)s- %(uploader)s - %(title)s')) == ('64rv_6-FZ6o- test - test', {'title': 'test', 'id': '64rv_6-FZ6o', 'uploader': 'test'})
    assert Test.simple_run(MetadataFromTitlePP('www.YouTube.com - %(title)s- %(uploader)s - %(id)s')) == ('64rv_6-FZ6o- test - test', {'title': 'test', 'id': '64rv_6-FZ6o', 'uploader': 'test'})

# Generated at 2022-06-26 13:48:21.033134
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP('nh5$', 'nh5$')
    info = {}
    info['title'] = '%(title)s'
    # Call method run of class MetadataFromTitlePP
    metadata_from_title_p_p_0.run(info)


# Generated at 2022-06-26 13:48:29.760238
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'nh5$'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    info_0 = {'title': 'h4a'}
    list_0 = []
    assert metadata_from_title_p_p_0.run(info_0) == (list_0, info_0)
    to_screen_0 = 'nh5$'
    metadata_from_title_p_p_0._downloader.to_screen(to_screen_0)
    str_1 = 'nh5$'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_1, str_1)
    str_2 = 'h4a'
    info_1 = {'title': str_2}

# Generated at 2022-06-26 13:48:38.004312
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, '%(title)s')
    str_0 = 'x'
    str_1 = '%(title)s'
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_1, str_1)
    list_0 = []
    metadata_from_title_p_p_1.run(metadata_from_title_p_p_0)
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_0, str_0)
    assert True # tested as non-example


# Generated at 2022-06-26 13:48:45.515504
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # If verbose_count is greater than 0, Function 'to_screen' shouldn't be called.
    test_verbose_count = 0
    test_info = {'title': '', 'artist': '', 'release_year': '', 'release_month': '', 'release_day': ''}
    test_metadata_from_title_p_p_0 = MetadataFromTitlePP('', '%(title)s - %(artist)s')
    test_metadata_from_title_p_p_1 = MetadataFromTitlePP('', '%(title)s')
    MetadataFromTitlePP.run(test_metadata_from_title_p_p_0, test_info)
    MetadataFromTitlePP.run(test_metadata_from_title_p_p_1, test_info)
    assert test_verb

# Generated at 2022-06-26 13:48:49.892510
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    dl_0 = type('', (), {})()
    str_0 = 'nh5$'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(dl_0, str_0)
    str_1 = 'dhm$'
    metadata_from_title_p_p_0 = metadata_from_title_p_p_0 if \
        metadata_from_title_p_p_0.run(str_1) else metadata_from_title_p_p_0


# Generated at 2022-06-26 13:48:57.894438
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'nh5$'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = 'ksfx$'
    # Test 1: Test the condition that length of 'title' is 0
    title_1 = ''
    str_2 = 'xz7a'
    info_1 = {str_1:str_2,str_0:title_1}
    assert metadata_from_title_p_p_0.run(info_1) == ([],info_1)

    # Test 2: Test the condition that length of 'title' is 1
    str_3 = 'lkd'
    info_2 = {str_1:str_2,str_0:str_3}
    assert metadata_from_title_p_

# Generated at 2022-06-26 13:49:08.879144
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = {'title' : 'aaaaaaaaaa', 'artist' : 'aaaaaa'}
    metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:49:12.759631
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_2 = MetadataFromTitlePP(
        'nh5$', 'nh5$'
    )
    str_0 = 'cnn'
    list_0 = list()
    dict_0 = dict()
    metadata_from_title_p_p_2.run(
        dict_0
    )



# Generated at 2022-06-26 13:49:21.209777
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    titleformat = '%(title)s - %(artist)s - %(video_id)s'
    titleregex = '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<video_id>.+)'
    info = {
        'title': 'Heaven\'s Door - R.I.P.',
        'uploader': 'Mario',
        'view_count': '100',
    }
    expected_info = {
        'title': 'Heaven\'s Door',
        'artist': 'R.I.P.',
        'uploader': 'Mario',
        'view_count': '100',
    }
    expected_result = []
    metadata_from_title_p_p_0 = MetadataFromTitlePP(titleformat, titleregex)
   

# Generated at 2022-06-26 13:49:23.654869
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_1 = MetadataFromTitlePP()
    # assert_equals(expected, metadata_from_title_p_p_1.run(*args))
    raise NotImplementedError()


# Generated at 2022-06-26 13:49:27.001470
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_1 = 'format string for regex'
    metadata_from_title_p_p = MetadataFromTitlePP(str_1, str_1)
    metadata_from_title_p_p.format_to_regex(str_1)

# Generated at 2022-06-26 13:49:36.005140
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '_a'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = 'g9'
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_1, str_1)
    str_2 = '@p'
    str_3 = 'w0'
    dict_0 = {
        str_2: 'u!',
        str_3: '7%',
    }
    metadata_from_title_p_p_2 = MetadataFromTitlePP(str_2, dict_0)
    str_4 = '$%'
    dict_1 = {
        str_3: str_2,
        str_4: str_0,
    }
    metadata_from_

# Generated at 2022-06-26 13:49:36.888056
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert '%(title)s' == '%(title)s'



# Generated at 2022-06-26 13:49:46.320429
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'a$b'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_1, str_1)
    metadata_from_title_p_p_1.format_to_regex(str_1)
    str_2 = 'nh5$'
    metadata_from_title_p_p_2 = MetadataFromTitlePP(str_2, str_2)
    str_3 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_3 = MetadataFromTitlePP(str_3, str_3)
   

# Generated at 2022-06-26 13:49:52.721958
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(\x00)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    info_0 = {}
    metadata_from_title_p_p_0.run(info_0)
    info_0 = {}
    metadata_from_title_p_p_0.run(info_0)
    info_0 = {}
    metadata_from_title_p_p_0.run(info_0)


# Generated at 2022-06-26 13:49:58.343509
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    expected = {'title': 'nh5$'}
    info = {'title': 'nh5$'}

    metadata_from_title_p_p_0 = MetadataFromTitlePP(info['title'], info['title'])
    actual = metadata_from_title_p_p_0.run(info)

    assert info == actual[1]

# Generated at 2022-06-26 13:50:10.646505
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # AssertionError: KeyError(u'artist',)
    pass


# Generated at 2022-06-26 13:50:19.175154
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '&:>'
    str_0 = str_0

# Generated at 2022-06-26 13:50:19.709013
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert True

# Generated at 2022-06-26 13:50:23.991871
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '#'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    list_0 = []
    dict_0 = dict()
    dict_1 = dict()
    dict_0['title'] = str_0
    dict_1['title'] = str_0
    list_1, dict_2 = metadata_from_title_p_p_0.run(dict_0)
    assert dict_2 == dict_1
    assert list_1 == list_0


# Generated at 2022-06-26 13:50:27.993856
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'RfR5r5r5r5r5'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.run(str_0)


# Generated at 2022-06-26 13:50:29.758004
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert MetadataFromTitlePP.run(str) == None


# Generated at 2022-06-26 13:50:30.625388
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()

# Generated at 2022-06-26 13:50:37.734437
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'nh5$'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = 'nh5$'
    tuple_0 = (str_1,)
    int_0 = 0
    str_2 = 'nh5$'
    str_3 = 'nh5$'
    dict_0 = {str_2: str_3}

# Generated at 2022-06-26 13:50:40.395253
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'nh5$'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    assert metadata_from_title_p_p_0.run(None) == ((), None)

# Generated at 2022-06-26 13:50:40.951116
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()


# Generated at 2022-06-26 13:51:12.978286
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'nh5$'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = 'nh5$'
    dict_0 = {'title': str_1}
    assert metadata_from_title_p_p_0.run(dict_0) == ([], {'title': str_1})


# Generated at 2022-06-26 13:51:13.629181
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert True


# Generated at 2022-06-26 13:51:16.632733
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP('Downloader', 'Downloader')
    metadata_from_title_p_p_0.run('Title')


# Generated at 2022-06-26 13:51:24.575906
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP()
    metadata_from_title_p_p_0._downloader = None
    metadata_from_title_p_p_0._titleformat = 'nh5$'  # TODO
    metadata_from_title_p_p_0._titleregex = 'nh5$'  # TODO
    info_0= {}
    info_1= {'title':'nh5$'}
    info_2={'title':'nh5$', 'artist':'nh5$'}
    res_0 = metadata_from_title_p_p_0.run(info_0)
    res_1 = metadata_from_title_p_p_0.run(info_1)
    res_2 = metadata_from_

# Generated at 2022-06-26 13:51:27.485962
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'nh5$'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_0 = 'foobar'
    str_1 = metadata_from_title_p_p_0.run(str_0)
    assert_equals(str_1, 'foobar')


# Generated at 2022-06-26 13:51:32.673175
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str, str)
    dict_0 = {}
    dict_1 = {'title': str}
    dict_0.update(dict_1)
    list_0 = []
    tuple_0 = (list_0, dict_0)
    return tuple_0 == metadata_from_title_p_p_1.run(dict_0)

# Generated at 2022-06-26 13:51:36.896566
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'nh5$'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = '123456789'
    dict_0 = {'title': str_1}
    metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:51:40.304870
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_1 = None
    # Test cases
    metadata_from_title_p_p_1 = MetadataFromTitlePP(None, None)
    try:
        metadata_from_title_p_p_1.run(None)
    except Exception:
        pass

# Generated at 2022-06-26 13:51:46.359140
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = 'xq1v'
    dict_0 = dict()
    dict_0['title'] = str_1
    dict_0_copy = dict_0.copy()
    list_0 = []
    assert (metadata_from_title_p_p_0.run(dict_0) == (list_0, dict_0_copy))


# Generated at 2022-06-26 13:51:54.851083
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'nh5$'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    long_0 = 100
    long_1 = 200
    boolean_0 = False
    boolean_1 = False
    long_2 = 200
    boolean_2 = False
    long_3 = 300
    url_handle_0 = UrlHandle()
    url_handle_0.set_url('https://www.youtube.com/watch?v=L309n7yyquA')
    url_handle_0.set_followed(True)
    url_handle_0.set_effective_url('https://www.youtube.com/watch?v=L309n7yyquA')
    url_handle_0.set_status(200)
    url_

# Generated at 2022-06-26 13:52:53.293799
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass

# Generated at 2022-06-26 13:52:58.093147
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    f_0 = {'title':'title'}
    assert (MetadataFromTitlePP('downloader', '%(title)s').run(f_0)) == ([], {'title':'title'})


if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:53:02.794390
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str(''), str(''))
    info = {}
    try:
        tuple_0 = metadata_from_title_p_p_0.run(info)
        assert tuple_0 == ([], info)
        assert len(tuple_0) == 2
    except:
        return False



# Generated at 2022-06-26 13:53:03.569559
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()

# Generated at 2022-06-26 13:53:04.621731
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # TODO: Improve this unit test
    assert not test_case_0()

# Generated at 2022-06-26 13:53:08.370366
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p = MetadataFromTitlePP('', '')
    info = {}
    info['title'] = 'MV XUAN MAI - CAM ON TU SUONG'
    str_format = '%(title)s - %(artist)s'
    metadata_from_title_p_p._titleformat = str_format
    metadata_from_title_p_p._titleregex = metadata_from_title_p_p.format_to_regex(str_format)
    metadata_from_title_p_p.run(info)

if __name__ == "__main__":
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:53:11.425675
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'nl9&'
    dict_0 = {'title': 'b{}'}
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.run(dict_0)

# Generated at 2022-06-26 13:53:17.153776
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'nh5$'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_0._titleregex = str_1
    metadata_from_title_p_p_0._titleformat = str_1
    dict_0 = {}
    dict_0['title'] = 'test'
    dict_0['artist'] = 'test'
    metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:53:19.395801
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'd'
    assert_equal(MetadataFromTitlePP.run(str, str_0), (None, None))


# Generated at 2022-06-26 13:53:23.377593
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s - %(artist)s'
    dict_0 = dict()
    dict_0['title'] = 'aA'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0._titleregex = 'aA'
    assert_equal(metadata_from_title_p_p_0.run(dict_0), ([], dict_0))