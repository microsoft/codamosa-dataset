

# Generated at 2022-06-26 13:43:59.062592
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_metadata_from_title_p_p_0 = MetadataFromTitlePP(tuple_0, bool_0)
    test_metadata_from_title_p_p_0.run(dict_0)

# Generated at 2022-06-26 13:44:10.955169
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    tuple_0 = ()
    bool_0 = None
    metadata_from_title_p_p_0 = MetadataFromTitlePP(tuple_0, bool_0)
    metadata_from_title_p_p_1 = MetadataFromTitlePP(tuple_0, bool_0)
    metadata_from_title_p_p_2 = MetadataFromTitlePP(tuple_0, bool_0)
    metadata_from_title_p_p_3 = MetadataFromTitlePP(tuple_0, bool_0)
    metadata_from_title_p_p_4 = MetadataFromTitlePP(tuple_0, bool_0)
    metadata_from_title_p_p_5 = MetadataFromTitlePP(tuple_0, bool_0)
    metadata_from_title_p_p_

# Generated at 2022-06-26 13:44:14.610943
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    tuple_0 = ()
    bool_0 = None
    metadata_from_title_p_p_0 = MetadataFromTitlePP(tuple_0, bool_0)
    dictionary_0 = {'title' : 'Format string %(from)s'}
    tuple_0 = metadata_from_title_p_p_0.run(dictionary_0)
    assert tuple_0 == ([], None)


# Generated at 2022-06-26 13:44:20.896759
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    tuple_0 = ()
    bool_0 = None
    metadata_from_title_p_p_0 = MetadataFromTitlePP(tuple_0, bool_0)
    metadata_from_title_p_p_0.run(tuple_0)
    print(metadata_from_title_p_p_0.format_to_regex(tuple_0))
    print(metadata_from_title_p_p_0.format_to_regex(bool_0))


# Generated at 2022-06-26 13:44:32.328575
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    tuple_0 = ()
    bool_0 = None
    metadata_from_title_p_p_0 = MetadataFromTitlePP(tuple_0, bool_0)
    metadata_from_title_p_p_0.add_info_extractors(tuple_0, tuple_0)
    metadata_from_title_p_p_0.add_default_info_extractors(tuple_0, tuple_0)
    metadata_from_title_p_p_0.add_video_info_extractor(tuple_0, tuple_0)
    metadata_from_title_p_p_0.add_video_info_extractors(tuple_0, tuple_0, tuple_0)
    metadata_from_title_p_p_0.set_downloader(tuple_0)

# Generated at 2022-06-26 13:44:35.738684
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    #tuple_0 = ()
    #bool_0 = None
    #metadata_from_title_p_p_0 = MetadataFromTitlePP(tuple_0, bool_0)
    #metadata_from_title_p_p_0.run()
    pass

# Generated at 2022-06-26 13:44:40.790505
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    tuple_0 = ()
    bool_0 = None
    metadata_from_title_p_p_0 = MetadataFromTitlePP(tuple_0, bool_0)
    dict_0 = {}
    assert (metadata_from_title_p_p_0.run(dict_0) == ([], {}))


# Generated at 2022-06-26 13:44:50.161675
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    tuple_0 = ()
    bool_0 = None
    metadata_from_title_p_p_0 = MetadataFromTitlePP(tuple_0, bool_0)

# Generated at 2022-06-26 13:45:00.780672
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # vars
    u_str_0 = "([A-Za-z0-9+/]{4})*([A-Za-z0-9+/]{4}|[A-Za-z0-9+/]{3}=|[A-Za-z0-9+/]{2}==)"

# Generated at 2022-06-26 13:45:05.306613
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    title_0 = 'video.avi'
    info_0 = {}
    info_0['title'] = title_0
    tuple_0 = ()
    bool_0 = None
    metadata_from_title_p_p_0 = MetadataFromTitlePP(tuple_0, bool_0)
    metadata_from_title_p_p_0.run(info_0)

# Generated at 2022-06-26 13:45:13.572710
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    str_0 = '%(title)s - %(artist)s'
    str_1 = '[a-zA-Z0-9]+'
    metadata_from_title_p_p_2 = MetadataFromTitlePP(str_1, str_0)
    assert metadata_from_title_p_p_2.format_to_regex(str_0) == '(?P<title>.+)\ \-\ (?P<artist>.+)'


if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_format_to_regex()

# Generated at 2022-06-26 13:45:21.999523
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # test case 0
    str_0 = '^`uRP5iZ<k'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = '\x0cT`H:-H@\r\\['
    str_2 = '-\x0b\x19<fC]r'
    if (metadata_from_title_p_p_0.format_to_regex(str_1) != str_2):
        raise Exception("Test case failed: Wrong output for method format_to_regex for input " + str_1)

# Generated at 2022-06-26 13:45:27.953708
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'title - artist'
    str_1 = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, str_0)
    metadata_from_title_p_p_0._format_to_regex = lambda : str_1
    str_2 = 'title - artist'
    dict_0 = {str_2:str_2}
    metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:45:38.293677
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP('&ZU}', 'X[Cj+')
    metadata_from_title_p_p_0.py_get('H\x16<j\x7f')
    metadata_from_title_p_p_0.py_get('Q*')
    str_0 = '\x0cT`H:-H@\r\\['
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = '^`uRP5iZ<k'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_1, str_1)
    str_2 = '%(title)s[0]'

# Generated at 2022-06-26 13:45:40.616355
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pp = MetadataFromTitlePP(None, "Test - %(title)s - Title")
    info = {
        'title': "Test - Hello World - Title",
        'abctitle': "Hello World",
    }
    pp.run(info)



# Generated at 2022-06-26 13:45:41.498444
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert str(test_case_0) == '(?, ' + 'regex' + ')'

# Generated at 2022-06-26 13:45:44.742740
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s.%(ext)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = 'OR'
    str_2 = 'fCx'
    dict_0 = {'title': '', 'ext': ''}
    metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:45:53.862638
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = '\x0cT`H:-H@\r\\['
    str_2 = '%%{(title)s - %(artist)s'
    dict_0 = {'title': str_1, 'artist': str_2}
    list_0 = []
    assert metadata_from_title_p_p_0.run(dict_0) == (list_0, dict_0)

# Generated at 2022-06-26 13:45:56.381097
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pass


if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP()

# Generated at 2022-06-26 13:46:03.623500
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'M'
    str_1 = '8KvF'
    str_2 = '\x7f8\x01\x7f'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_2)
    dict_0 = dict({str_2:str_2, str_1:str_1})
    dict_1 = dict({str_1:str_1, str_2:str_2})
    dict_0[str_2] = str_1
    dict_0[str_1] = str_2
    dict_0[str_2] = dict_1[str_1]
    dict_0[str_1] = dict_1[str_2]
    list_0, dict_0 = metadata_from_title_p

# Generated at 2022-06-26 13:46:16.521618
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '^`uRP5iZ<k'
    str_1 = '\x0cT`H:-H@\r\\['
    str_2 = '\'\xd9\xa5\x95\x99\x07\xb5'
    str_3 = '\x1c%q\xbf8\x94\xa7\xda\xec\xed\xf5\x1b'
    str_4 = '\x13\xaa\xb0\xec\xf0\x1e\x0f\xa1\x03\x8a\xbbM\xf3\x16\xe1'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_1)
    metadata_from_title_p_p_0

# Generated at 2022-06-26 13:46:21.029200
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(1, 3)
    dict_0 = dict()
    dict_0['title'] = '\x0cT`H:-H@\r\\['
    list_0 = []
    metadata_from_title_p_p_0.run(dict_0)



# Generated at 2022-06-26 13:46:23.230078
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(0, 0)
    metadata_from_title_p_p_0.run(0)

# Generated at 2022-06-26 13:46:23.761426
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass

# Generated at 2022-06-26 13:46:32.459292
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP()
    str_0 = '\x13hG:A$'
    # Values to be compared against
    str_1 = '`V\\c\x0fY\\'
    # First test: Test with values with no '%(..)s' in titleformat
    list_arg_0 = []
    dict_arg_0 = {}
    dict_arg_0['title'] = str_1
    str_2 = 'T[T'
    dict_arg_0['artist'] = str_2
    list_arg_0.append(dict_arg_0)
    dict_arg_0 = {}
    dict_arg_0['title'] = str_1
    dict_arg_0['artist'] = str_2
    list_arg_1

# Generated at 2022-06-26 13:46:34.197952
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert True

# Unit tests for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-26 13:46:39.147920
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '\x0cT`H:-H@\r\\['
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = {}
    dict_0['title'] = str_0
    metadata_from_title_p_p_0.run(dict_0)
    assert dict_0['title'] == str_0


# Generated at 2022-06-26 13:46:49.798950
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '\x1d3J\x1c'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.run({'title': 'PPnZEf xhkM'})
    
# Test case for format_to_regex()
#def test_MetadataFromTitlePP_format_to_regex_0():
#    str_0 = '\x1d3J\x1c'
#    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
#    str_1 = '\x0cT`H:-H@\r\\['
#    assert_equal(
#        metadata_from_title_p_p_

# Generated at 2022-06-26 13:46:52.311270
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pp_0 = MetadataFromTitlePP(str_0, str_1)
    str_0 = ''
    dict_0 = {}
    pp_0.run(dict_0)


# Generated at 2022-06-26 13:46:58.869208
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    title = 'test title'
    info = {'title': title}

    mft = MetadataFromTitlePP('test_hook', '%(title)s')
    [], info = mft.run(info)
    assert info['title'] == title

    mft = MetadataFromTitlePP('test_hook', '%(title)s - %(artist)s')
    [], info = mft.run(info)
    assert info['title'] == title
    assert 'artist' not in info

    info['title'] = title + ' - test artist'
    mft = MetadataFromTitlePP('test_hook', '%(title)s - %(artist)s')
    [], info = mft.run(info)
    assert info['title'] == title
    assert info['artist'] == 'test artist'

    info

# Generated at 2022-06-26 13:47:05.427045
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    title = 'test string'
    match = re.match(r'(?P<a>\w+)\s+(?P<b>\w+)', title)
    assert match is not None
    assert match.groupdict()['a'] == 'test'
    assert match.groupdict()['b'] == 'string'

# Generated at 2022-06-26 13:47:11.463182
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Init a object of class MetadataFromTitlePP
    # We have to init an object of class YoutubeDL first
    youtube_dl_0 = class_YoutubeDL()

    # Calling the constructor of class MetadataFromTitlePP
    # Call the method run of class MetadataFromTitlePP
    metadata_from_title_p_p_0 = MetadataFromTitlePP(youtube_dl_0, '')
    metadata_from_title_p_p_0.run({})

# Generated at 2022-06-26 13:47:12.051081
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()

# Generated at 2022-06-26 13:47:13.618431
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test case #0
    test_case_0()


# Generated at 2022-06-26 13:47:17.689260
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_1 = '!@@lfNx1'
    dict_0 = dict([('D', '\x10')])
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_1, str_1)
    list_0 = []
    list_1 = metadata_from_title_p_p_0.run(dict_0)
    assert (list_1 == ([], dict_0)) == True


# Generated at 2022-06-26 13:47:19.405972
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()
    test.test_from_title()

# Generated at 2022-06-26 13:47:28.257450
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(album)s - %(track)s - %(title)s.%(ext)s')
    info = {
        'title': 'test artist - test album - 02 - test title.ext',
        'upload_date': '20170208',
    }
    pp.run(info)

    assert info['ext'] == 'ext'
    assert info['artist'] == 'test artist'
    assert info['album'] == 'test album'
    assert info['track'] == '02'
    assert info['title'] == 'test title'


if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:47:37.191362
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '+qkXJ1<j\x0c'
    metadata_from_title_p_p_0 = MetadataFromTitlePP('PY#uk', ']\x1f\x1d\x1e%c')
    str_1 = ' '
    str_2 = '\tcW\x03\x1cR.'
    str_3 = '\x10\x1ak\x0c\x1aO'
    str_4 = '\t\x0f\x12\x1b\x1f'
    str_5 = '\t\x0f\x12\x1b\x1f'
    str_6 = '\t\x0f\x12\x1b\x1f'

# Generated at 2022-06-26 13:47:45.046182
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Prepare
    str_0 = 'I`Wq3b[\x0eGzZ'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = {'description': 'description', 'thumbnail': 'thumbnail', 'webpage_url': 'webpage_url', 'track': 'track', 'title': 'title', 'artist': 'artist', 'ext': 'ext', 'dislike_count': 'dislike_count', 'upload_date': 'upload_date', 'like_count': 'like_count', 'duration': 'duration', 'playlist': 'playlist', 'playlist_index': 'playlist_index', 'url': 'url'}

# Generated at 2022-06-26 13:47:48.862910
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
  # Setup
  downloader = None
  fmt = None
  pp = MetadataFromTitlePP(downloader, fmt)
  info = {}
  # Procedure Call
  pp.run(info)
  # Verification
  return


# Generated at 2022-06-26 13:48:01.515524
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    def check_assertions(info_0):
        assert info_0['title'] == 'Eo6TzT6iRrQ'

    str_0 = 'C^kxwlm[#>'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = 'Eo6TzT6iRrQ'
    dict_0 = {'title': str_1}
    check_assertions(metadata_from_title_p_p_0.run(dict_0)[1])

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 13:48:06.594276
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s asd %(dse)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = '\x0cT`H:-H@\r\\['
    str_2 = '%(title)s asd %(dse)s'
    dict_0 = {'title': str_2, 'dse': str_1}
    assert metadata_from_title_p_p_0.run(dict_0) == ([], {'title': str_2, 'dse': str_1})


# Generated at 2022-06-26 13:48:18.703661
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test fixture
    title_format = '%(title)s - %(artist)s'
    metadata_from_title_pp = MetadataFromTitlePP('downloader', title_format)

# Generated at 2022-06-26 13:48:24.960865
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'Y\rp\x0b'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = '^`uRP5iZ<k'
    str_2 = '\x0cT`H:-H@\r\\['
    str_3 = '`d\x7f\x10#\x16'
    str_4 = '1\n)l\x1cS'
    str_5 = 'cl\\'
    str_6 = '\x1a*\x17\x10'
    str_7 = '\x1e\x1a'
    str_8 = '\x03\x06'
    str_9 = 'KD'
    str_10 = '$K'

# Generated at 2022-06-26 13:48:35.001029
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    title = '3 - LAUGHING WITH - Regina Spektor'
    info = {'title': title}
    titleformat = '%(tracknumber)s - %(title)s - %(artist)s'
    titleregex = '(?P<tracknumber>.+)\ \-\ (?P<title>.+)\ \-\ (?P<artist>.+)'
    metadata_from_title_p_p_0 = MetadataFromTitlePP('downloader', titleformat)
    metadata_from_title_p_p_0._titleregex = titleregex
    expected_result = ([], {'tracknumber': '3', 'title': 'LAUGHING WITH', 'artist': 'Regina Spektor', 'title': title})
    result = metadata_from_title_p_p_0.run(info)
    assert result

# Generated at 2022-06-26 13:48:42.895479
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '6U%s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, '-')
    str_1 = '%(upload_date)s - %(title)s'
    str_2 = 'RA'
    str_3 = 'B:d'
    metadata_from_title_p_p_0._titleformat = str_1
    metadata_from_title_p_p_0._titleregex = metadata_from_title_p_p_0.format_to_regex(str_1)
    metadata_from_title_p_p_0.run(({'title': str_2},))
    metadata_from_title_p_p_0.run((str_3,))


# Generated at 2022-06-26 13:48:45.569012
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_2 = 'm;@}5'
    str_3 = '%(title)s'
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_3, str_3)
    metadata_from_title_p_p_1.run(str_2)

if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:48:48.415087
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'OBCi'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dictionary_0 = {'title': 'qjxWJ'}
    tuple_0 = (list_0, dictionary_0)
    assert tuple_0 == metadata_from_title_p_p_0.run(dictionary_0)


# Generated at 2022-06-26 13:48:52.327046
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'b8%(uploader)s_%(upload_date)s_%(title)s_%(id)s_%(ext)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = {
        'ext': 'youtube-dl_test',
        'id': 'youtube-dl_test'
    }
    metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:49:00.886801
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'jd_vS1]7#x^'
    # Form a string for use as the format for MetadataFromTitlePP

# Generated at 2022-06-26 13:49:14.961742
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '*'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.run(None)

# Generated at 2022-06-26 13:49:17.702778
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP('', '')
    dict_0 = {}
    dict_1 = metadata_from_title_p_p_0.run(dict_0)
    assert dict_1 == ([], {})


# Generated at 2022-06-26 13:49:24.906845
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s'
    str_1 = '%(title)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_1)
    metadata_from_title_p_p_0._titleregex = '%(title)s'
    str_2 = 'X'
    str_3 = '&'
    list_0 = []
    dict_0 = {'title': str_3}
    list_1, dict_1 = metadata_from_title_p_p_0.run(dict_0)
    assert (list_1 == list_0)
    assert (dict_1 == dict_0)


# Generated at 2022-06-26 13:49:26.213309
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert True


# Generated at 2022-06-26 13:49:35.235597
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s asdf %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = '%(title)s asdf %(artist)s'
    metadata_from_title_p_p_0.run(str_1)

    str_2 = '%(title)s asdf %(artist)s'
    metadata_from_title_p_p_0.run(str_2)

    str_3 = '%(title)s asdf %(artist)s'
    metadata_from_title_p_p_0.run(str_3)

    str_4 = '%(title)s asdf %(artist)s'
    metadata_from_title_p_p_

# Generated at 2022-06-26 13:49:40.319285
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '\x0cT`H:-H@\r\\['
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = '\x0cT`H:-H@\r\\['
    str_2 = 'W\x0cJG<\nr\x0c\x1a'
    dict_0 = {str_2: str_2, 'title': str_1, 'ext': str_2}
    str_3 = 'LNjf\x1c\x1a\x1d'
    dict_1 = {str_2: str_2, 'title': str_3}
    # self.assertEqual(metadata_from_title_p_p_0.run(dict_1), (list

# Generated at 2022-06-26 13:49:44.833320
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '^`uRP5iZ<k'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = '\x0cT`H:-H@\r\\['
    metadata_from_title_p_p_0.run(str_1)

# Generated at 2022-06-26 13:49:49.522146
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'c\x03\t#\x0ep'
    assert_raises_regexp = (MetadataFromTitlePP, AssertionError)
    with assert_raises_regexp:
        obj_0 = MetadataFromTitlePP(str_0, str_0)
        obj_0.run(str_0)

# Generated at 2022-06-26 13:49:59.994336
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP('', str_0)
    str_1 = 'u-7K\x12zZ\x06'
    metadata_from_title_p_p_0.run({str_1: str_0})
    str_0 = '^`uRP5iZ<k'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = '\x0cT`H:-H@\r\\['
    metadata_from_title_p_p_0.run({str_1: str_0})
    str_0 = '\x0cT`H:-H@\r\\['


# Generated at 2022-06-26 13:50:08.826014
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor import gen_extractors
    from .utils import sanitize_open

    from io import BytesIO

    # test regex
    mftpp = MetadataFromTitlePP(
        FileDownloader(gen_extractors(), progress_hooks=[]),
        '[%(uploader)s] %(creator)s - %(title)s')
    # setup
    d = {'title': '[Youtube-DL] test_uploader - test_creator - test_title'}
    # run
    mftpp.run(d)
    # check
    assert d['creator'] == 'test_uploader'
    assert d['uploader'] == 'test_creator'
    assert d['title'] == 'test_title'

    # test format

# Generated at 2022-06-26 13:50:35.079391
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'C{=e^0'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = '92z@wFY\x17'
    str_2 = '_x\x1eE'
    str_3 = '\x10\\wQ'
    str_4 = 'l9\x17\x10\x13'
    str_5 = 'Hc%w'
    str_6 = '\x0b|3\x16\x7f\x0b'
    str_7 = '\x7f\x2c\x7f'
    str_8 = '\x15\x05O\x1a'

# Generated at 2022-06-26 13:50:42.073252
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, None)
    str_0 = 'h]\\0{\\w&sbF'
    str_1 = '\x0cT`H:-H@\r\\['
    str_2 = 'w\x15I\n#[U\x0b\x0f'
    str_3 = '`\rp\r\x14\r\r\r'
    assert (metadata_from_title_p_p_0.run(str_0) == [None, None])



# Generated at 2022-06-26 13:50:48.131532
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '<>qk\x7f|9\x15i\x11\x00\x7f'
    str_1 = 'w\x1c\x1d'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_1, str_1)
    metadata_from_title_p_p_0.format_to_regex(str_0)


# Generated at 2022-06-26 13:50:49.871500
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p = MetadataFromTitlePP(['', ''], '')
    metadata_from_title_p_p.run()

# Generated at 2022-06-26 13:50:58.317957
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    str_0 = '%(artist)s - %(title)s [%(id)s].%(ext)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)

    str_1 = '\x0cT`H:-H@\r\\['

# Generated at 2022-06-26 13:51:05.062243
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'XH\x7f4'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = '\x00\n'
    str_2 = '\x00\n'
    str_3 = '\x00\n'
    str_4 = '\x00\n'
    str_5 = '\x00\n'
    str_6 = '\x00\n'
    str_7 = '\x00\n'
    str_8 = '\x00\n'
    str_9 = '\x00\n'
    str_10 = '\x00\n'
    str_11 = '\x00\n'
    str_12 = '\x00\n'


# Generated at 2022-06-26 13:51:11.901932
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    if __debug__:
        str_0 = '^`uRP5iZ<k'
        metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
        str_1 = '\x0cT`H:-H@\r\\['
        metadata_from_title_p_p_0.run(str_1)
        str_2 = '\x0cT`H:-H@\r\\['
        metadata_from_title_p_p_0.run(str_2)
        str_3 = '\x0cT`H:-H@\r\\['


# Generated at 2022-06-26 13:51:16.085052
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    i = {'title': 'simple title'}
    pp = MetadataFromTitlePP(None, '%(title)s')
    _, i2 = pp.run(i)
    assert i2['title'] == 'simple title'
    _, i2 = pp.run(i)
    assert i2['title'] == 'simple title'


# Generated at 2022-06-26 13:51:16.567593
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass



# Generated at 2022-06-26 13:51:24.176505
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s.%(ext)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = 'Y_;c'
    metadata_from_title_p_p_0._titleregex = str_1
    bool_0 = False
    metadata_from_title_p_p_0.to_screen(bool_0)
    metadata_from_title_p_p_0.to_screen(bool_0)
    bool_1 = True
    metadata_from_title_p_p_0.to_screen(bool_1)
    bool_2 = True
    metadata_from_title_p_p_0.to_screen(bool_2)

# Generated at 2022-06-26 13:52:15.527235
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Set up test data
    downloader = ''
    info = {'title': ''}

    metadata_from_title_p_p_0 = MetadataFromTitlePP(downloader, str_1)
    # Invoke method
    metadata_from_title_p_p_0.run(info)
    # Check results



# Generated at 2022-06-26 13:52:16.253001
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()


# Generated at 2022-06-26 13:52:18.992600
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, None)
    info = {}
    try:
        metadata_from_title_p_p_0.run(info)
        assert False
    except NotImplementedError:
        assert True


# Generated at 2022-06-26 13:52:27.031300
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '^`uRP5iZ<k'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    int_0 = 20
    metadata_from_title_p_p_0.num_downloads = int_0
    str_1 = '\x0cT`H:-H@\r\\['
    metadata_from_title_p_p_0.trouble = str_1
    str_2 = 'jZ'
    info = {'title': str_2}
    str_3 = '-e;/'
    metadata_from_title_p_p_0.titleformat = str_3
    metadata_from_title_p_p_0.downloader = str_2

# Generated at 2022-06-26 13:52:34.397094
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(
        '\x9b\x8b\x89\x98\x90\x91\x8b\x99\x95\x9b\x8a\x89\x89',
        '\x9b\x8b\x89\x98\x90\x91\x8b\x99\x95\x9b\x8a\x89\x89')
    metadata_from_title_p_p_0.run(
        '\x9b\x8b\x89\x98\x90\x91\x8b\x99\x95\x9b\x8a\x89\x89')


# Generated at 2022-06-26 13:52:39.417143
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    titleformat = '%(extractor)s - %(display_id)s - %(id)s - %(upload_date)s - %(title)s - %(duration)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, titleformat)
    metadata_from_title_p_p_0.run(None)

# Generated at 2022-06-26 13:52:47.524921
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    str_0 = '\x0c[5W\x15\x01\x0e\n\x14W\x12\x1c\x0eM\x01\x02\x16\n\x1e'
    str_1 = '\x16\x13QP\x0e\x0f\r\x15]\x1a\x0e\n\x13\x04\x15\x11\x1e'
    str_2 = '\x0e\x12\x13\x1a\x0f\x1e\x04\x1f\x0f\x02\x13\x0f\x02\x1e'

# Generated at 2022-06-26 13:52:53.576870
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '\x0cT`H:-H@\r\\['
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = 'E.=_^'
    str_2 = 'QT<C^K9{'
    dict_0 = {'title': str_1, str_0: '\x0cT`H:-H@\r\\[', 'id': 'E.=_^'}
    metadata_from_title_p_p_0.run(dict_0)



# Generated at 2022-06-26 13:53:03.394098
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '='
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    list_0 = []
    list_1 = []

# Generated at 2022-06-26 13:53:10.051275
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test cases
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, '')
    assert metadata_from_title_p_p_0.run(None) == ([], None)
    # Test case 1
    metadata_from_title_p_p_1 = MetadataFromTitlePP(None, '')
    info_0 = {}
    assert metadata_from_title_p_p_1.run(info_0) == ([], {})
    # Test case 2
    metadata_from_title_p_p_2 = MetadataFromTitlePP(None, '')
    metadata_from_title_p_p_2._titleregex = re.compile('(?:(?=^)|(?<=^)).+(?:(?<=^)|(?=^))')
    info_