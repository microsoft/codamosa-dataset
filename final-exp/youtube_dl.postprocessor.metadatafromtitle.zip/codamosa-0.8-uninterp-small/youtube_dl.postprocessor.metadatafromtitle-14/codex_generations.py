

# Generated at 2022-06-26 13:44:07.000572
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, None)
    metadata_from_title_p_p_1 = None
    metadata_from_title_p_p_2 = metadata_from_title_p_p_0.format_to_regex(metadata_from_title_p_p_1)


# Generated at 2022-06-26 13:44:11.342557
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
	metadata_from_title_p_p_0 = None
	metadata_from_title_p_p_1 = MetadataFromTitlePP(metadata_from_title_p_p_0, metadata_from_title_p_p_0)
	metadata_from_title_p_p_2 = metadata_from_title_p_p_1.format_to_regex(metadata_from_title_p_p_0)
	return metadata_from_title_p_p_2

# Generated at 2022-06-26 13:44:12.664160
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-26 13:44:15.934367
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Initialize
    metadata_from_title_p_p_0 = None
    metadata_from_title_p_p_1 = MetadataFromTitlePP(metadata_from_title_p_p_0, metadata_from_title_p_p_0)
    info_0 = {}
    metadata_from_title_p_p_1._downloader = None
    # Call method run of class MetadataFromTitlePP
    metadata_from_title_p_p_1.run(info_0)


# Generated at 2022-06-26 13:44:23.038824
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-26 13:44:31.583955
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    titleformat = '%(title)s - %(artist)s'
    titleformat_r = '%(title)s\\ \\-\\ %(artist)s'
    titleformat_r_r = "(?P<title>.+)\\ \\-\\ (?P<artist>.+)"
    regex = MetadataFromTitlePP.format_to_regex(titleformat)
    assert titleformat_r_r == regex

if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_format_to_regex()

# Generated at 2022-06-26 13:44:39.545226
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = None
    metadata_from_title_p_p_1 = MetadataFromTitlePP(metadata_from_title_p_p_0, metadata_from_title_p_p_0)
    info_0 = dict()
    info_0['title'] = str()
    assert(metadata_from_title_p_p_1.run(info_0) == (list(), info_0))


# Generated at 2022-06-26 13:44:40.449380
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()

# Generated at 2022-06-26 13:44:44.819470
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = None
    metadata_from_title_p_p_1 = MetadataFromTitlePP(metadata_from_title_p_p_0, metadata_from_title_p_p_0)
    metadata_from_title_p_p_1.run({'title': metadata_from_title_p_p_0})


# Generated at 2022-06-26 13:44:49.983030
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = None
    metadata_from_title_p_p_1 = MetadataFromTitlePP(metadata_from_title_p_p_0, metadata_from_title_p_p_0)
    empty_python_dict_0 = {}
    metadata_from_title_p_p_1.run(empty_python_dict_0)


# Generated at 2022-06-26 13:45:02.361461
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = None
    metadata_from_title_p_p_1 = MetadataFromTitlePP(metadata_from_title_p_p_0, metadata_from_title_p_p_0)
    metadata_from_title_p_p_2 = {"title": metadata_from_title_p_p_0}
    metadata_from_title_p_p_3 = metadata_from_title_p_p_1.run(metadata_from_title_p_p_2)
    assert isinstance(metadata_from_title_p_p_3, tuple) and (len(metadata_from_title_p_p_3) == 2)


# Generated at 2022-06-26 13:45:08.176959
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    #
    # Test cases
    #

    # Test case 0:
    titleformat = '%(title)s - %(artist)s'
    expected_regex = '(?P<title>.+) - (?P<artist>.+)'
    actual_regex = MetadataFromTitlePP(None, titleformat).format_to_regex(titleformat)
    assert actual_regex == expected_regex, 'Expected %s but got %s' % (expected_regex, actual_regex)

    # Test case 1:
    titleformat = '%(title)s - %(artist)s'
    expected_regex = '(?P<title>.+) - (?P<artist>.+)'
    actual_regex = MetadataFromTitlePP(None, titleformat).format_to_regex(titleformat)
   

# Generated at 2022-06-26 13:45:15.881166
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = None
    metadata_from_title_p_p_1 = MetadataFromTitlePP(metadata_from_title_p_p_0, metadata_from_title_p_p_0)
    metadata_from_title_p_p_2 = test_case_0()
    metadata_from_title_p_p_3 = metadata_from_title_p_p_1.run(metadata_from_title_p_p_2)
    # (list, dict) -> bool
    assert isinstance(metadata_from_title_p_p_3, bool)



# Generated at 2022-06-26 13:45:20.217573
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # Initially, the regex for %(title)s - %(artist)s is '(?P<title>.+)\ \-\ (?P<artist>.+)'
    metadata_from_title_p_p_0 = None
    metadata_from_title_p_p_1 = MetadataFromTitlePP(metadata_from_title_p_p_0, '%(title)s - %(artist)s')
    metadata_from_title_p_p_2 = metadata_from_title_p_p_1._titleregex
    assert metadata_from_title_p_p_2 == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    # Now, the regex for %(title)s - %(artist)s is '(?P<title>.+)\ \-\ (?P<artist>.+)

# Generated at 2022-06-26 13:45:26.164691
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    metadata_from_title_p_p_0 = None
    metadata_from_title_p_p_1 = MetadataFromTitlePP(metadata_from_title_p_p_0, metadata_from_title_p_p_0)
    metadata_from_title_p_p_2 = metadata_from_title_p_p_1.format_to_regex('%(title)s - %(artist)s')
    assert metadata_from_title_p_p_2 == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'


# Generated at 2022-06-26 13:45:31.286697
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = None
    metadata_from_title_p_p_1 = MetadataFromTitlePP(metadata_from_title_p_p_0, metadata_from_title_p_p_0)
    metadata_from_title_p_p_2 = None
    metadata_from_title_p_p_3 = metadata_from_title_p_p_1.run(metadata_from_title_p_p_2)


# Generated at 2022-06-26 13:45:40.894199
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = None
    metadata_from_title_p_p_1 = MetadataFromTitlePP(metadata_from_title_p_p_0, metadata_from_title_p_p_0)

    # unit test case 0
    info = {}
    info_0_2 = {}
    info_0_1 = info_0_2
    info_0_0 = [metadata_from_title_p_p_0, info_0_1]
    ret = metadata_from_title_p_p_1.run(info)
    assert ret == info_0_0


# Generated at 2022-06-26 13:45:47.030684
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # the following statement causes an error due to mismatch of number of arguments
    # metadata_from_title_p_p_0 = MetadataFromTitlePP(metadata_from_title_p_p_0)
    metadata_from_title_p_p_1 = MetadataFromTitlePP(metadata_from_title_p_p_0, metadata_from_title_p_p_0)


# Generated at 2022-06-26 13:45:48.537904
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    metadata_from_title_p_p_0 = None
    metadata_from_title_p_p_1 = MetadataFromTitlePP(metadata_from_title_p_p_0, metadata_from_title_p_p_0) # noqa: F841


# Generated at 2022-06-26 13:45:54.878069
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = None
    metadata_from_title_p_p_1 = MetadataFromTitlePP(metadata_from_title_p_p_0, metadata_from_title_p_p_0)
    metadata_from_title_p_p_2 = metadata_from_title_p_p_1.run(metadata_from_title_p_p_0)


# Generated at 2022-06-26 13:46:01.815291
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # AssertionError: Assertion failed when testing run() method of MetadataFromTitlePP class
    test_case_0()

# Generated at 2022-06-26 13:46:09.422002
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, None)
    metadata_from_title_p_p_1 = metadata_from_title_p_p_0.run({'title': ''})
    assert metadata_from_title_p_p_1 == ([], {'title': ''}), 'Failed to assert that (<generator object at 0x...>, {\'title\': \'\'}) is (<generator object at 0x...>, {\'title\': \'\'})'


# Generated at 2022-06-26 13:46:10.956427
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()



# Generated at 2022-06-26 13:46:16.680334
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = None
    metadata_from_title_p_p_1 = MetadataFromTitlePP(metadata_from_title_p_p_0, metadata_from_title_p_p_0)
    metadata_from_title_p_p_2 = metadata_from_title_p_p_1.run(metadata_from_title_p_p_0)

    # No assert yet
    # TODO


# Generated at 2022-06-26 13:46:17.239186
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass

# Generated at 2022-06-26 13:46:24.363927
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # create object
    metadata_from_title_p_p_0 = None
    metadata_from_title_p_p_1 = MetadataFromTitlePP(metadata_from_title_p_p_0, metadata_from_title_p_p_0)

    # add a test case
    info = {}
    info['title'] = 'hello world'
    info['id'] = 'hello world'
    ret_val_list, ret_val_info = metadata_from_title_p_p_1.run(info)
    # add assertions
    assert ret_val_list == []
    assert ret_val_info == info



# Generated at 2022-06-26 13:46:28.944413
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, None)
    metadata_from_title_p_p_1 = dict()
    metadata_from_title_p_p_2 = metadata_from_title_p_p_0.run(metadata_from_title_p_p_1)
    assert metadata_from_title_p_p_1 is metadata_from_title_p_p_2[1]
    assert isinstance(metadata_from_title_p_p_2[0], list)



# Generated at 2022-06-26 13:46:35.084961
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = None
    info_dict = {'title': ''}
    test_MetadataFromTitlePP_run_1 = metadata_from_title_p_p_0
    metadata_from_title_p_p_1 = MetadataFromTitlePP(test_MetadataFromTitlePP_run_1, test_MetadataFromTitlePP_run_1)
    metadata_from_title_p_p_1.run(info_dict)


# Generated at 2022-06-26 13:46:38.980568
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = None
    metadata_from_title_p_p_1 = MetadataFromTitlePP(metadata_from_title_p_p_0, metadata_from_title_p_p_0)
    info_0 = {}
    metadata_from_title_p_p_1.run(info_0)

# Generated at 2022-06-26 13:46:45.457991
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = None
    metadata_from_title_p_p_1 = MetadataFromTitlePP(metadata_from_title_p_p_0, metadata_from_title_p_p_0)
    info_0 = {'title': 'title'}
    assert metadata_from_title_p_p_1.run((info_0,)) == ([], info_0)

# Generated at 2022-06-26 13:47:02.272339
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'l2_%(title)s_foo%(ext)s'
    str_1 = 'foobar.mp4'
    dict_0 = {}
    dict_0['title'] = str_1
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    tup_0 = metadata_from_title_p_p_0.run(dict_0)
    class_tup_0 = tup_0.__class__
    class_tup_1 = tuple.__class__
    assert class_tup_0 == class_tup_1
    assert tup_0 == ()
    class_dict_0 = dict_0.__class__
    class_dict_1 = dict.__class__
    assert class_dict_0

# Generated at 2022-06-26 13:47:03.535578
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()


# Generated at 2022-06-26 13:47:07.042188
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP()
    info = {}
    info['title'] = 'Toys+-+Big+Boys+-+intro.mkv'
    metadata_from_title_p_p_0.run(info)


# Generated at 2022-06-26 13:47:07.568617
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass

# Generated at 2022-06-26 13:47:09.644063
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    print("Test run not implemented yet")
    assert false


# Generated at 2022-06-26 13:47:14.972788
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'IbCD}MsGepx'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    info_0 = {
        'uploader_id': '%(uploader)s',
        'title': '%(uploader)s - %(title)s'
    }
    metadata_from_title_p_p_0.run(info_0)


# Generated at 2022-06-26 13:47:20.157664
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '6J1CfUaKDy'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = dict()
    dict_0['title'] = str_0
    list_0 = []
    list_1 = []
    dict_2 = dict()
    dict_2['title'] = str_0
    dict_2['artist'] = str_0
    list_1.append(dict_2)
    list_0.append(list_1)
    list_0.append(dict_0)
    list_2 = metadata_from_title_p_p_0.run(dict_0)
    str_1 = list_0[1]['artist']

# Generated at 2022-06-26 13:47:29.671310
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    title = 'test'
    format = '%(title)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(title, format)
    info = {u'title': u'test'}
    metadata_from_title_p_p_0.run(info)
    title = 'test test'
    format = '%(title)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(title, format)
    info = {u'title': u'test'}
    metadata_from_title_p_p_0.run(info)
    title = 'test test'
    format = '%(title)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(title, format)

# Generated at 2022-06-26 13:47:37.280970
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # test 0
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    test0_info = {'title': 'Test title'}
    test0_expected_return_value = ([], {'title': 'Test title'})
    test0_actual_return_value = pp.run(test0_info)
    if test0_actual_return_value != test0_expected_return_value:
        print('Test 0 failed')
        print('Expected: ' + str(test0_expected_return_value))
        print('Actual:   ' + str(test0_actual_return_value))

# Generated at 2022-06-26 13:47:41.464904
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test no. 0
    str_0 = 'IbCD}MsGepx'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = {'title': 'title'}
    assert metadata_from_title_p_p_0.run({'title': 'title'}) == ([], dict_0)


# Generated at 2022-06-26 13:47:51.420036
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # TEST CASE FOR POSITIVE FLOW
    str_0 = '-1'
    str_1 = str_0
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_1, str_0)
    #TODO: modify the code here to test the method run of class MetadataFromTitlePP
    raise NotImplementedError("Please implement the method MetadataFromTitlePP.run method for positive flow testing.")


# Generated at 2022-06-26 13:47:51.970729
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert True



# Generated at 2022-06-26 13:48:02.071138
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'K}EZ:*b\\O>'
    str_1 = 'y|}h(Pz_Lf'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_0, str_1)
    dictionary_0 = {'%(title)s': 'value_0'}
    dictionary_1 = {'key_1': '%(title)s'}

    ret_val_0, ret_val_1 = metadata_from_title_p_p_0.run(dictionary_0)
    assert ret_val_0 == []
    assert ret_val_1.get('title') == 'value_0'

    ret_val_

# Generated at 2022-06-26 13:48:08.517668
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert metadata_from_title_p_p_0

if __name__ == '__main__':
    metadata_from_title_p_p_0 = MetadataFromTitlePP(0, 0)
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:48:13.585265
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.run(info_0)


if __name__ == '__main__':
    # test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:48:17.423118
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP('', '')
    info = {}
    assert metadata_from_title_p_p_0.run(info) == ([], info)

# Generated at 2022-06-26 13:48:22.945803
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'R%9lF@tn\u0019'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    list_0 = []
    dict_0 = {'title': 'e{b[D|TvMY-W_', 'K;G%': 'Eo"QS)WYJP', 'nH&': '"?$?3%;8W%'}
    metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:48:32.946156
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
	title = 'title'
	titleformat = '%(title)s - %(artist)s'
	metadata_from_title_p_p_0 =	MetadataFromTitlePP(title, titleformat)
	
	if title == None:
		raise Exception('Cannot continue')
	
	match = re.match(metadata_from_title_p_p_0._titleregex, title)
	
	if match == None:
		metadata_from_title_p_p_0._downloader.to_screen(
			'[fromtitle] Could not interpret title of video as "%s"'
			% metadata_from_title_p_p_0._titleformat)
		return [], info
	for attribute, value in match.groupdict().items():
		info[attribute] = value
	

# Generated at 2022-06-26 13:48:39.264946
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    '''
    Unit test for method run of class MetadataFromTitlePP
    '''
    metadata_from_title_p_p_1 = MetadataFromTitlePP('Q9o5kpcZf', 'Ps_1BwYF_')
    str_1 = 'RlP4f4XEt'
    dict_2 = {}
    str_2 = 'pm'
    dict_2[str_2] = str_1
    int_0 = metadata_from_title_p_p_1.run(dict_2)[0]
    assert(int_0 == 0)


# Generated at 2022-06-26 13:48:41.261895
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, '')
    metadata_from_title_p_p_0.run({})


# Generated at 2022-06-26 13:48:49.591259
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP('UZl6TKv6T8k', 'Hasbro Studios Shorts')
    metadata_from_title_p_p_1 = MetadataFromTitlePP(None, None)
    metadata_from_title_p_p_2 = MetadataFromTitlePP('Hasbro Studios.', 'Hasbro Studios Shorts')

# Generated at 2022-06-26 13:48:52.144300
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'IbCD}MsGepx'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    info_0 = {}
    assert metadata_from_title_p_p_0.run(info_0) == [], info_0


# Generated at 2022-06-26 13:49:00.700483
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'IbCD}MsGepx'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = metadata_from_title_p_p_0.format_to_regex('%(title)s - %(artist)s')
    str_1 = 'N[5fK)NkY!q'
    dict_1 = {'artist': str_1, 'title': str_1, 'album': str_1, 'track': str_1}
    list_0 = []
    return_value_0 = metadata_from_title_p_p_0.run(dict_1)
    assert (return_value_0 == [list_0, dict_1])

test_case_0()

# Generated at 2022-06-26 13:49:08.703712
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_1 = '%(title)s'
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_1, str_1)
    str_2 = 'KIZ - '
    dict_0 = {'title': str_2}
    dict_1 = metadata_from_title_p_p_1.run(dict_0)
    assert dict_1 == ([], {'title': str_2})
    str_3 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_2 = MetadataFromTitlePP(str_3, str_3)
    str_4 = 'KIZ - '
    dict_2 = metadata_from_title_p_p_2.run({'title': str_4})

# Generated at 2022-06-26 13:49:12.314235
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'IbCD}MsGepx'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)

    # Call the run method of class MetadataFromTitlePP
    metadata_from_title_p_p_0.run(None)


# Generated at 2022-06-26 13:49:17.202624
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP('https://example.com/video.mp4', '%(title)s - %(artist)s')
    str_0 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_0.format_to_regex(str_0)
    metadata_from_title_p_p_0.run('test_title')

# Generated at 2022-06-26 13:49:25.469468
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'Splice - %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = 'Splice - %(artist)s'
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_1, str_1)
    # Test normal run
    dict_0 = {'%(title)s - %(artist)s': 'Splice - %(artist)s'}
    list_0, dict_1 = metadata_from_title_p_p_0.run(dict_0)
    # Test error
    # Test error
    # Test error
    # Test error
    # Test error
    # Test error
    # Test error


# Generated at 2022-06-26 13:49:33.379527
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'L8Svw2N1Gz}'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = '7V[X&'
    str_2 = 'xKx!WG0%c'
    str_3 = 'QZ&Tt'
    str_4 = 'B7g#'
    dict_0 = {str_1: str_2, str_3: str_4}
    list_0, dict_1 = metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:49:34.386887
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    result_0 = test_case_0()


# Generated at 2022-06-26 13:49:37.052186
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Initializing arguments
    vardict = {'title': 'beef'}
    metadata_from_title_p_p_0 = MetadataFromTitlePP(pardict, 'beef')
    metadata_from_title_p_p_0.run(vardict)


# Generated at 2022-06-26 13:49:55.099604
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    info_0 = {'format': 's', 'title': 's', 'ext': 's', 'vcodec': 's'}
    metadata_from_title_p_p_0 = MetadataFromTitlePP('J59Zti', '4?$%<`')
    title_format_0 = metadata_from_title_p_p_0._titleformat
    metadata_from_title_p_p_0.run(info_0)



# Generated at 2022-06-26 13:50:05.297713
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'MfiyOgGxE'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = ''
    str_2 = ''
    str_3 = ''
    str_4 = ''
    # params: dict, dict
    dict_0 = dict()
    dict_0_key_dict = dict()
    dict_0_key_dict.update({str_1:str_2})
    dict_0_key_dict.update({str_3:str_4})
    dict_0.update({str_1:dict_0_key_dict})
    dict_0_key_dict = dict()
    dict_0_key_dict.update({str_1:str_2})
    dict_0_key_

# Generated at 2022-06-26 13:50:11.760795
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'bXhTK0uVpTu'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = {'title': 'dxSzG08KxDg', 'description': 'dxSzG08KxDg'}
    list_0 = []
    dict_0 = metadata_from_title_p_p_0.run(dict_0)
    assert dict_0[0] == list_0
    assert dict_0[1]['title'] == 'dxSzG08KxDg'
    assert dict_0[1]['description'] == 'dxSzG08KxDg'


# Generated at 2022-06-26 13:50:12.869993
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()

# Generated at 2022-06-26 13:50:14.776041
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, 'h#lT;s7qra4')

# Generated at 2022-06-26 13:50:22.967624
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'YsDjn}elF'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_0 = 'C:\\Users\\Wgu\\Downloads\\MP3\\%(uploader)s\\%(upload_date)s - %(title)s.%(ext)s'
    metadata_from_title_p_p_0._titleregex = str_0
    str_0 = '4NPp^z,4'
    info_0 = {str_0:str_0, str_0:(str_0 + str_0), str_0:'o^Kx', str_0:'YsDjn}elF', str_0:str_0}

# Generated at 2022-06-26 13:50:27.023535
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'IbCD}MsGepx'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.run(str_0)

# Generated at 2022-06-26 13:50:27.993097
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert True


# Generated at 2022-06-26 13:50:30.431937
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()

if __name__ == '__main__':
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:50:33.912537
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'IbCD}MsGepx'
    dict_0 = dict()
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.run(dict_0)



# Generated at 2022-06-26 13:51:10.722551
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    print('Test run method')
    print('Not implemented yet')


# Unit test code
if __name__ == '__main__':
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:51:11.412461
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()

# Generated at 2022-06-26 13:51:19.106097
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    # From global namespace import class MetadataFromTitlePP
    from youtube_dl.postprocessor import MetadataFromTitlePP

    # Declare variable metadata_from_title_p_p_0 of type MetadataFromTitlePP
    
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)

    # Declare variable info_0 of type dict
    info_0 = {}

    # Invoke method run of class MetadataFromTitlePP with argument metadata_from_title_p_p_0
    # Assign the return value of the method to variable returned_1
    returned_1 = metadata_from_title_p_p_0.run(info_0)
    assert returned_1 == ([], info_0)


if __name__ == '__main__':
    test_case_0

# Generated at 2022-06-26 13:51:26.904622
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP('J}`{+m[fuZ', 'MSz%(title)s')
    assert metadata_from_title_p_p_0.run('title') == ([], 'title')
    metadata_from_title_p_p_1 = MetadataFromTitlePP('q', 'h%(title)s')
    assert metadata_from_title_p_p_1.run('title') == ([], 'title')
    metadata_from_title_p_p_2 = MetadataFromTitlePP('iW\h2;$', 'T%(title)s')
    assert metadata_from_title_p_p_2.run('title') == ([], 'title')

# Generated at 2022-06-26 13:51:30.143973
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str, str_0)
    metadata_from_title_p_p_0.run(str)

# Generated at 2022-06-26 13:51:38.492516
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'nBfD}'
    str_1 = 'pyp0'
    str_2 = 'C^Zw5'
    str_3 = 'X9B^yH'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_1)
    str_4 = 'jIq3'
    str_5 = 'Jw)@'
    str_6 = 'c%n]a'
    str_7 = '+J:C'
    str_8 = '_+Y2'
    str_9 = '1%B6'
    str_10 = 'Vu0$'
    str_11 = 'D^K_v'
    str_12 = 'T*h/'
    str_13 = '?bM'

# Generated at 2022-06-26 13:51:48.807711
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP('', '')
    metadata_from_title_p_p_1 = MetadataFromTitlePP('', '')
    metadata_from_title_p_p_2 = MetadataFromTitlePP('', '')
    print(metadata_from_title_p_p_2.run(str))
    print(metadata_from_title_p_p_1.run(str))
    print(metadata_from_title_p_p_0.run(str))
    assert metadata_from_title_p_p_0.run(str) == ([], {})
    assert metadata_from_title_p_p_1.run(str) == ([], {})

# Generated at 2022-06-26 13:51:49.333820
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass

# Generated at 2022-06-26 13:51:53.855683
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'IbCD}MsGepx'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = 'IbCD}MsGepx'
    dict_0 = {'title': str_1}
    tuple_0 = metadata_from_title_p_p_0.run(dict_0)
    assert (tuple_0 == ([], dict_0))

# Generated at 2022-06-26 13:51:59.779016
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'PyPb'
    str_1 = 'MgQa'

# Generated at 2022-06-26 13:53:20.587002
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'IbCD}MsGepx'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_0 = 'Hecka good - The best'
    str_1 = 'title'
    str_2 = 'Hecka good'
    str_3 = 'artist'
    str_4 = 'The best'
    t_dict_0 = {}
    t_dict_0['title'] = str_0
    str_5 = '%(title)s - %(artist)s'
    str_6 = 'Hecka good - The best'
    metadata_from_title_p_p_0.run(t_dict_0)
    t_dict_0[str_1]

# Generated at 2022-06-26 13:53:28.406467
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Tests with an empty title
    info = {}
    title = ''
    str_0 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(title, str_0)
    assert metadata_from_title_p_p_0.format_to_regex(str_0) == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    metadata_from_title_p_p_0.run(info)
    for key, value in info.items():
        #print("[%s]: %s" % (key, value))
        assert value is None
    info = {}
    title = ''
    str_0 = '%(title)s'
    metadata_from_title_p_p_0 = Met

# Generated at 2022-06-26 13:53:32.543595
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP('VtG8x4f4JJM', '%(title)s')

    metadata_from_title_p_p_0.run('kw8QQk1Bk0w')

if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:53:41.064076
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor import YoutubeIE
    from .extractor.youtube import YoutubePlaylistIE
    from .utils import ExtractorError, get_info_extractor, unescapeHTML
    from .compat import compat_urllib_request
    try:
        if not hasattr(compat_urllib_request, 'urlopen'):
            raise Exception('skip')
    except (AttributeError, ImportError):
        return
    metadata_from_title_p_p_0 = MetadataFromTitlePP(FileDownloader(),
                                                    '%(uploader)s')
    try:
        status = extractor_0.suitable(FileDownloader(), url_0)
    except (OptParseError):
        status = None

# Generated at 2022-06-26 13:53:44.537380
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import re

    str_1 = 'CQ)XR!D=C1O!O'
    str_2 = ']Dp%]0'
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_1, str_2)
    dict_0 = {'title': '9d[YiBn%#'}
    dict_1 = metadata_from_title_p_p_1.run(dict_0)
    assert re.escape(str_2) == r'\]Dp\%\]0'


# Generated at 2022-06-26 13:53:52.134143
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_unit_test_0 = 'a)'
    dict_unit_test_0 = {'title': 'a)'}
    metadata_from_title_p_p_unit_test_0 = MetadataFromTitlePP(str_unit_test_0, str_unit_test_0)
    assert metadata_from_title_p_p_unit_test_0.run(dict_unit_test_0) == [], dict_unit_test_0

    str_unit_test_1 = 'a'
    dict_unit_test_1 = {'title': 'aa'}
    metadata_from_title_p_p_unit_test_1 = MetadataFromTitlePP(str_unit_test_1, str_unit_test_1)

# Generated at 2022-06-26 13:53:55.258146
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    downloader = None # TODO: implement
    titleformat = None # TODO: implement
    result_0 = MetadataFromTitlePP(downloader, titleformat)
    info = {} # TODO: implement
    result_1 = result_0.run(info)
    expected_result_0 = []
    assert result_1 == expected_result_0
