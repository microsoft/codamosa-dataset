

# Generated at 2022-06-26 13:44:06.021831
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'x-k_T1TGW4vY8V4WTsD9'
    str_1 = 'S8syhW)p\t0 5B\'+;.m+}s'
    str_2 = 'c$!v*8"1kdQjK(R0[v)2'
    str_3 = 'fJd7VvN-S8pNbrH}$l[c'
    str_4 = 'djt*1J|>!n5m{Z?-1Z<h'
    str_5 = 'Y*0Sk(c=UTXQ2+:RlcD0'
    str_6 = 'a>PGA-0_zsU6pJU9?+~O'

# Generated at 2022-06-26 13:44:11.346179
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Local variables
    locale.getpreferredencoding()
    # Setup
    locale.getpreferredencoding()
    info = 'TejhW)p\t0 5B\'+;.m+}s'
    post_processor_0 = MetadataFromTitlePP(info, info)
    # Invoke method
    result_0 = post_processor_0.run([])
    # Verify outcome
    assert result_0[0] == []
    assert result_0[1] == info


# Generated at 2022-06-26 13:44:14.844497
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'o{RJ5^5G}z1'
    str_1 = '['


# Unit tests for class MetadataFromTitlePP

# Generated at 2022-06-26 13:44:21.022751
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = "TejhW)p\t0 5B'+;.m+}s"
    set_0 = {str_0, str_0}
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, set_0)
    metadata_from_title_p_p_0.format_to_regex(str_0)
    metadata_from_title_p_p_0.format_to_regex(str_0)

# Generated at 2022-06-26 13:44:25.238511
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP("N,^Z:>F9|W? '", '%(artist)s')



# Generated at 2022-06-26 13:44:30.827279
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    file_path = "parsed_data/test_MetadataFromTitlePP_run.txt"
    output = open(file_path, "w")
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, None)
    metadata_from_title_p_p_0.run(None)
    output.close()


# Generated at 2022-06-26 13:44:39.171076
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = "TejhW)p\t0 5B'+;.m+}s"
    set_0 = {str_0, str_0}
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, set_0)
    dict_0 = {'a', 'b', 'c'}
    dict_1 = metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:44:47.893055
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = "TejhW)p\t0 5B'+;.m+}s"
    set_1 = {str_0, str_0}
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, set_1)

    str_1 = "M%R@)F+2,Zh$4xwm-U%cYU6VnU#b,*{z5+Urb5'\"Vu9n<>J7,aF`"
    set_2 = {str_1, str_1}
    str_2 = "M%R@)K,Zh$4xwm-U%cYU6VnU#b,*{z5+Urb5'\"Vu9n<>J7,aF`"


# Generated at 2022-06-26 13:44:58.326127
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    str_0 = "bI&_ZvT8-zW~&"
    set_0 = {str_0, str_0}
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, set_0)
    str_1 = "5[5\tDEH7'#xc4,q3@V|l*_"
    set_1 = {str_1, str_1}
    metadata_from_title_p_p_0.format_to_regex(str_1)
    # AssertionError: "'5[5\\tDEH7'#xc4,q3@V|l*_' not contains '%(\w+)s'"

# Generated at 2022-06-26 13:45:05.062688
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = "TejhW)p\t0 5B'+;.m+}s"
    set_0 = {str_0, str_0}
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, set_0)
    dict_0 = {str_0: str_0}
    dict_0 = metadata_from_title_p_p_0.run(dict_0)
    bool_0 = bool(dict_0)
    bool_1 = bool(dict_0)
    bool_2 = bool(dict_0)
    bool_3 = bool(dict_0)


# Generated at 2022-06-26 13:45:11.794416
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # test case 0
    title = ''
    info = {}
    ins = MetadataFromTitlePP(downloader, titleformat)
    ins.run(info)
    assert info['title'] == ''
    assert info['artist'] == ''
    assert info['album'] == ''
    assert info['track'] == ''

# Generated at 2022-06-26 13:45:15.645133
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader

    titleformat = '%(title)s - %(artist)s'
    test_case_0()
    test_case_0()
    metadata_from_title_processer = MetadataFromTitlePP(FileDownloader({}), titleformat)
    info = dict()
    title = 'the title'
    info['title'] = title
    assert_output(metadata_from_title_processer, (info, ))


# Generated at 2022-06-26 13:45:16.838731
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass


# Generated at 2022-06-26 13:45:19.977336
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    with pytest.raises(Exception):
        test_case_0()

# Check that the '%(title)s' string in the titleformat variable is
# properly converted to a regular expression group.

# Generated at 2022-06-26 13:45:27.891191
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import builtins
    from .common import FileDownloader
    from .common import PostProcessor

    class Test_PostProcessor(PostProcessor):
        def run(self, info): pass

    downloader = FileDownloader({})
    postprocessor = Test_PostProcessor(downloader)
    # Test default value of arg info
    info = 'Zl'
    postprocessor.run(info)

    # Test default value of arg info
    info = '[S'
    postprocessor.run(info)

    # Test default value of arg info
    info = '1d3'
    postprocessor.run(info)

    # Test default value of arg info
    info = 'hglC'
    postprocessor.run(info)

    # Test default value of arg info
    info = 'm'
    postprocessor.run(info)

# Generated at 2022-06-26 13:45:29.763504
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    title = 'abc'
    titleformat = 'abc'
    MetadataFromTitlePP(downloader, titleformat)
    MetadataFromTitlePP(downloader, titleformat).run(info)


# Generated at 2022-06-26 13:45:32.119723
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    info_0 = MetadataFromTitlePP(None, None)
    info_1 = { 'title' : str_0 }

    info_0.run(info_1)


# Generated at 2022-06-26 13:45:37.939369
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-26 13:45:43.870523
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .downloader import Downloader
    from .extractor import YoutubeIE
    from .postprocessor import FFmpegMetadataPP
    from .utils import compat_urllib_error

    downloader = Downloader(params=dict())
    downloader.add_info_extractor(YoutubeIE())
    titleformat = '%(title)s'
    postprocessor = MetadataFromTitlePP(downloader, titleformat)

# Generated at 2022-06-26 13:45:48.210598
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-26 13:45:56.424242
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    codec = 'title="foo"'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(codec, str(codec))
    codec = 'title="bar"'
    metadata_from_title_p_p_0.run(str(codec))


# Generated at 2022-06-26 13:46:02.218025
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = "N,^Z:>F9|W? '"
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)

    meta_data_dict_0 = {"title": "N,^Z:>F9|W? '"}
    meta_data_dict_1 = {}

    metadata_from_title_p_p_0.run(meta_data_dict_0)
    metadata_from_title_p_p_0.run(meta_data_dict_1)


# Generated at 2022-06-26 13:46:02.985233
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass


# Generated at 2022-06-26 13:46:14.628644
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = "N,^Z:>F9|W? '"
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = "N,^Z:>F9|W? '"
    dict_0 = {'title': str_1}
    (list_0, dict_1) = metadata_from_title_p_p_0.run(dict_0)
#
# def test_case_1():
#     str_0 = "%(title)s - %(artist)s"
#     metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
#     str_1 = "#1s "
#     dict_0 = {'title': str_1}
#    

# Generated at 2022-06-26 13:46:22.452394
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Unit test for method run of class MetadataFromTitlePP
    str_0 = "%(title)s"
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = "L0%X]X9ru"
    list_0 = list()
    dict_0 = dict()
    metadata_from_title_p_p_0.run(list_0, dict_0)
    metadata_from_title_p_p_0.run(list_0, dict_0)
    metadata_from_title_p_p_0.run(list_0, dict_0)

# Tests for class MetadataFromTitlePP

# Generated at 2022-06-26 13:46:29.135414
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    fname_0 = MetadataFromTitlePP.format_to_regex("%(title)s - %(artist)s")
    fname_1 = MetadataFromTitlePP.format_to_regex("%(title)s")
    fname_2 = MetadataFromTitlePP.format_to_regex("%(title)s - %(artist)s - %(title)s")
    fname_3 = MetadataFromTitlePP.format_to_regex("%(title)s [%(year)s]")
    fname_4 = MetadataFromTitlePP.format_to_regex("%(name)s - %(title)s | %(composer)s")
    fname_5 = MetadataFromTitlePP.format_to_regex("%(title)s")
    fname_

# Generated at 2022-06-26 13:46:35.936017
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, str_0)
    dict_0 = {}
    dict_0['title'] = 'hello world'
    dict_0['artist'] = 'ytdl team'
    metadata_from_title_p_p_0.run(dict_0)
    assert dict_0['title'] == 'hello world'
    assert dict_0['artist'] == 'ytdl team'


# Generated at 2022-06-26 13:46:39.652220
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = "N,^Z:>F9|W? '"
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    word_0 = {  }
    assert metadata_from_title_p_p_0.run(word_0) == ([], word_0)


# Generated at 2022-06-26 13:46:46.267019
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = "PB.5.23"
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = "\\/8n$QI_"
    dict_0 = {str_0: str_1}
    dict_1 = metadata_from_title_p_p_0.run(dict_0)
    assert dict_0 is dict_1


# Generated at 2022-06-26 13:46:52.543567
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = "N,^Z:>F9|W? '"
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_2 = ''
    dict_1 = {'title': str_2}
    list_0 = []
    tuple_0 = (list_0, dict_1)
    str_1 = 'title'
    str_2 = 'NA'
    assert(metadata_from_title_p_p_0.run(tuple_0) == None)



# Generated at 2022-06-26 13:46:55.126812
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert True


# Generated at 2022-06-26 13:46:56.566359
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP("/b1", "%(title)s.%(ext)s")



# Generated at 2022-06-26 13:47:00.181781
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = "c%(abc)s - %(def)s"
    str_1 = "cab - ds"
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, str_0)
    str_2 = 'cab - ds'
    dict_0 = {'title': str_2}
    metadata_from_title_p_p_0.run(dict_0)

test_case_0()
test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:47:10.438009
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = "%(uploader)s - %(title)s [%(id)s].%(ext)s"
    str_1 = "foo.%(ext)s"
    str_2 = "foo.%(id)s"
    str_3 = "%(foo)s.%(ext)s"
    str_4 = "%(foo)s.%(ext)s"
    str_5 = "%(foo)s"
    str_6 = "foo-%(ext)s"
    str_7 = "foo-%(id)s"
    str_8 = "foo-%(foo)s"
    int_0 = 0
    str_9 = "foo-%(bar)s.%(ext)s"

# Generated at 2022-06-26 13:47:15.732164
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = "N,^Z:>F9|W? '"
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = "N,^Z:>F9|W? '"
    dict_0 = dict()
    dict_0['title'] = str_1
    test_case_1(metadata_from_title_p_p_0, dict_0)


# Generated at 2022-06-26 13:47:19.555579
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = "N,^Z:>F9|W? '"
    str_1 = "N,^Z:>F9|W? '"
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_1)
    metadata_from_title_p_p_0.format_to_regex(str_0)
    metadata_from_title_p_p_0.run(str_0)

if __name__ == '__main__':
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:47:25.627893
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = "N,^Z:>F9|W? '"
    str_1 = "N,^Z:>F9|W? '"
    str_2 = "N,^Z:>F9|W? '"
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_1)
    dict_0 = {"title": str_2}
    metadata_from_title_p_p_0.run(dict_0)



# Generated at 2022-06-26 13:47:35.096562
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = "N,^Z:>F9|W? '"
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = 'c4'
    str_2 = 'P]#'
    str_3 = 'K[\f'
    str_4 = '4dk'
    str_5 = 'J.(`'
    str_6 = 'N+j'
    int_0 = 769
    str_7 = 'dGX9'
    str_8 = '+j=6'
    str_9 = '7Vv'
    str_10 = 'j1f!_'
    str_11 = '~B'
    str_12 = ':kf'

# Generated at 2022-06-26 13:47:39.851663
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = "N,^Z:>F9|W? '"
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = "sT>T:q3|e+"
    dictionary_0 = {'a': str_1}
    list_0 = []
    metadata_from_title_p_p_0.run(dictionary_0)
    assert list_0 == []



# Generated at 2022-06-26 13:47:43.145046
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = ''
    str_1 = ''
    dict_0 = dict(title='title')
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_1)
    metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:47:48.015692
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, str_0)
    metadata_from_title_p_p_0.run(info_0)


# Generated at 2022-06-26 13:47:49.642071
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert callable(MetadataFromTitlePP.run)


# Generated at 2022-06-26 13:47:55.938318
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'Q5G#ZPA>5&>?Y'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = 'YQ[,'
    dict_0 = dict()
    dict_0['title'] = str_1
    list_0 = []
    list_1 = metadata_from_title_p_p_0.run(dict_0)
    assert list_0 == list_1


# Generated at 2022-06-26 13:48:04.913686
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = "N,^Z:>F9|W? '"
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    # A test object of type Downloader
    downloader_0 = object()
    int_0 = 0
    # A test object of type InfoExtractor
    info_extractor_0 = object()
    # A test object of type DownloadInfo
    download_info_0 = object()
    # A test object of type FileDownloader
    file_downloader_0 = object()
    str_1 = "2>4gZ3E"
    # A test object of type FileDownloader
    file_downloader_1 = object()
    # A test object of type XAttrMetadataPP
    x_attr_metadata_p_p

# Generated at 2022-06-26 13:48:10.537198
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = "N,^Z:>F9|W? '"
    map_0 = {}
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.run(map_0)


# Generated at 2022-06-26 13:48:19.395582
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = "N,^Z:>F9|W? '"
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = {}
    dict_0['title'] = 'N,^Z:>F9|W? '
    list_0 = []
    dict_1 = {}
    dict_1['title'] = 'N,^Z:>F9|W? '
    list_1 = metadata_from_title_p_p_0.run(dict_0, dict_1)
    assert list_0 == list_1


# Generated at 2022-06-26 13:48:27.611007
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    format_to_regex_1_result = (
        MetadataFromTitlePP.format_to_regex(
            '%(title)s - %(artist)s'))
    assert format_to_regex_1_result == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    str_0 = "N,^Z:>F9|W? '"
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_0 = '%(title)s - %(artist)s'
    assert metadata_from_title_p_p_0._titleregex == str_0
    str_0 = "N,^Z:>F9|W? '"
    metadata_from_title_p_p

# Generated at 2022-06-26 13:48:34.521013
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = "N,^Z:>F9|W? '"
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = "!@#$%^&*()_+{}:\"<>?/.,';[]-=\`"
    map_0 = {str_0: str_1, str_1: str_1}
    metadata_from_title_p_p_0.run(map_0)


# Generated at 2022-06-26 13:48:41.255104
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = "N,^Z:>F9|W? '"
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = "N,^Z:>F9|W? '"
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_0, str_1)
    str_2 = "N,^Z:>F9|W? '"
    metadata_from_title_p_p_2 = MetadataFromTitlePP(str_0, str_2)
    pass


# Generated at 2022-06-26 13:48:46.454172
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = "N,^Z:>F9|W? '"
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = "This is the title"
    dict_0 = {'title': str_1}
    metadata_from_title_p_p_0.run(dict_0)

if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()
    test_case_0()

# Generated at 2022-06-26 13:48:54.560839
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test: no groups but some extra characters in title
    # Result: no metadata
    str_0 = "N,^Z:>F9|W? '"
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = "N,^Z:>F9|W? '"
    str_2 = "N,^Z:>F9|W? '"
    dict_0 = {'title': str_1, 'id': str_2}
    list_0 = []
    tuple_0 = metadata_from_title_p_p_0.run(dict_0)
    assert tuple_0 == (list_0, dict_0)

    # Test: no groups in title but some extra characters in regex
    # Result: no metadata
   

# Generated at 2022-06-26 13:49:03.185318
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import os.path
    import sys
    import pytest
    try:
        title = sys.argv[1]
        titleformat = sys.argv[2]
        expected_title = sys.argv[3]
        expected_artist = sys.argv[4]
    except IndexError:
        raise pytest.UsageError('Usage: %s <title> <titleformat> <expected_title> <expected_artist>' % os.path.basename(sys.argv[0]))

    metadata_from_title_p_p_0 = MetadataFromTitlePP(title, titleformat)
    pp_result = metadata_from_title_p_p_0.run({'title': title})
    assert len(pp_result) == 2
    assert pp_result[0] == []

# Generated at 2022-06-26 13:49:06.659073
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = "N,^Z:>F9|W? '"
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    tuple_0 = {}
    assert (metadata_from_title_p_p_0.run(tuple_0) == ([], {}))

# Generated at 2022-06-26 13:49:13.671959
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-26 13:49:16.656601
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP("", "")
    assert metadata_from_title_p_p_0.run("") is None


# Generated at 2022-06-26 13:49:17.406585
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()


# Generated at 2022-06-26 13:49:25.962575
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    print("Testing MetadataFromTitlePP.run...")
    str_0 = "N,^Z:>F9|W? '"
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = {'title': 'title'}
    dict_1 = dict_0
    str_1 = "(?P<title>.+)"
    metadata_from_title_p_p_0._titleregex = str_1
    tuple_0 = ("[fromtitle] parsed {0}: {1}", 'title', title)

    assert metadata_from_title_p_p_0.run(dict_0) == ([], dict_1)
    assert metadata_from_title_p_p_0._titleregex == str_1
    assert metadata_from

# Generated at 2022-06-26 13:49:32.665773
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = "N,^Z:>F9|W? '"
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = dict()
    dict_0['title'] = 'foobar'
    dict_1 = dict()
    dict_1['title'] = 'foo'
    metadata_from_title_p_p_0.run(dict_0)
    metadata_from_title_p_p_0.run(dict_1)


# Generated at 2022-06-26 13:49:36.068303
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = None # Should be initialized the class for run this test
    str_0 = "N,^Z:>F9|W? '"
    dict_0 = {"title":str_0}
    assert metadata_from_title_p_p_0.run(dict_0) == ([], dict_0)


# Generated at 2022-06-26 13:49:40.002616
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s'
    str_1 = '%(title)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_1)
    info = {'title': "Fw\x8a'1Z\x86\x0c6"}
    res_0 = [
    ]
    res_1 = {'title': "Fw\x8a'1Z\x86\x0c6"}
    res_2 = metadata_from_title_p_p_0.run(info)

    assert res_2 == (res_0, res_1)

# Generated at 2022-06-26 13:49:52.364585
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = "N,^Z:>F9|W? '"
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = "N,^Z:>F9|W? '"
    dictionary_0 = {}
    dictionary_0['title'] = str_1
    list_0 = []
    assert metadata_from_title_p_p_0.run(dictionary_0) == (list_0, dictionary_0)

# Generated at 2022-06-26 13:49:58.330513
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    info_dict = {'title': 'foo - bar'}
    assert metadata_from_title_p_p_0.run(info_dict) == ([], {'title': 'foo - bar'})


# Generated at 2022-06-26 13:50:08.025368
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = "N,^Z:>F9|W? '"
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = {"v": "I_K>;-", "S": "/PZ|", "E": "T.N9%"}
    str_1 = "N,^Z:>F9|W? '"
    dict_1 = {"title": str_1, "v": "I_K>;-", "S": "/PZ|", "E": "T.N9%"}
    dict_0 = metadata_from_title_p_p_0.run(dict_0)
    assert dict_0[0] == {}
    assert dict_0[1] == dict_1


# Generated at 2022-06-26 13:50:10.879766
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, '')
    args_0 = {'title': 'title'}
    metadata_from_title_p_p_0.run(args_0)


# Generated at 2022-06-26 13:50:19.398213
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = "N,^Z:>F9|W? '"
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = "R0xBD*!Sc"
    str_2 = "UB$t-#m:"
    list_0 = []
    dict_0 = {'title': str_2, str_0: str_1}
    list_1, dict_1 = metadata_from_title_p_p_0.run(dict_0)
    # Expected output:
    # [], {'title': 'UB$t-#m:', 'N,^Z:>F9|W? ': 'R0xBD*!Sc'}

# Generated at 2022-06-26 13:50:21.015415
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP("", "")
    metadata_from_title_p_p_0.run("")


# Generated at 2022-06-26 13:50:22.385361
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert callable(getattr(MetadataFromTitlePP, 'run'))


# Generated at 2022-06-26 13:50:32.420031
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-26 13:50:33.058755
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert True


# Generated at 2022-06-26 13:50:37.367614
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pattern = r'%\((\w+)\)s'
    str_0 = "N,^Z:>F9|W? '"
    str_1 = "N,^Z:>F9|W? '"
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_1)
    info = {'title': "N,^Z:>F9|W? '"}
    metadata_from_title_p_p_0.run(info)

# Generated at 2022-06-26 13:50:57.130026
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = "N,^Z:>F9|W? '"
    str_1 = "N,^Z:>F9|W? '"
    # Call the run method of the class
    result_data, result_info = MetadataFromTitlePP.run(str_0, str_1)

test_MetadataFromTitlePP_run()
test_case_0()

# Generated at 2022-06-26 13:51:00.044700
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Arrange
    str_0 = "N,^Z:>F9|W? '"
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)

    assert_equals(expected, actual)

# Generated at 2022-06-26 13:51:01.655221
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert True

if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:51:08.714981
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = "N,^Z:>F9|W? '"
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = "N,^Z:>F9|W? '"
    str_2 = "'"
    str_3 = 'KX9>F~A+Tv|K_|H*-P&8,Q2c%R+]^s'
    str_4 = 'Q2c%R+]^s'
    str_5 = '.0'
    str_6 = '+%c'
    str_7 = '+%c'
    str_8 = '1'
    str_9 = 'C,X9b<'
    str_10 = 'C,X9b<'


# Generated at 2022-06-26 13:51:17.004973
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = "N,^Z:>F9|W? '"
    str_1 = ""
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_1)
    str_0 = "N,^Z:>F9|W? '"
    str_1 = "N,^Z:>F9|W? '"
    dict_0 = {}
    dict_0['title'] = str_1
    dict_0 = {}
    dict_0['title'] = str_0
    metadata_from_title_p_p_0._titleregex = str_0
    metadata_from_title_p_p_0._titleformat = str_0
    metadata_from_title_p_p_0._titleregex = str_0
    metadata_from

# Generated at 2022-06-26 13:51:20.738114
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = "N,^Z:>F9|W? '"
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = {"title":"Testsite"}
    assert(metadata_from_title_p_p_0.run({}) == ([], {}))

# Generated at 2022-06-26 13:51:27.553278
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = "N,^Z:>F9|W? '"
    # Create an instance of class MetadataFromTitlePP
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    # Declare object 'dict_0' of type 'dict'
    dict_0 = {}
    # Declare object 'list_0' of type 'list'
    list_0 = []
    # Call method 'run' of class MetadataFromTitlePP with arguments (dict_0) and
    # assign the method's return value to 'tuple_0'
    tuple_0 = metadata_from_title_p_p_0.run(dict_0)
    # Assert that the type of 'tuple_0' is 'tuple'

# Generated at 2022-06-26 13:51:33.768563
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = {'title': 'Cummi Flu - Wenn es Nacht wird', 'artist': 'Cummi Flu'}
    assert metadata_from_title_p_p_0.run({'title': 'Cummi Flu - Wenn es Nacht wird'}) == ([], dict_0)


# Generated at 2022-06-26 13:51:39.146088
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    title = 'MetadataFromTitlePP'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(title, title)
    metadata_from_title_p_p_0.run(title)
    # AssertionError: 'Could not interpret title of video as "%(title)s" 
    # on line 285 of metadatafromtitle.py


if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:51:45.264438
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    match_0 = re.match("N,^Z:>F9|W? '", "'N,^Z:>F9|W? '")
    info_0 = info_0
    title_0 = "'N,^Z:>F9|W? '"
    info_0['title'] = title_0
    _, info_1 = metadata_from_title_p_p_0.run(info_0)
    assert info_1 == info_0


# Generated at 2022-06-26 13:52:27.898063
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, None)
    dict_0 = dict()
    dict_0['title'] = str()
    dict_1 = dict()
    dict_1['title'] = '+'
    dict_1['title'] = ''
    dict_1['title'] = 'Z*Im9Q7!GJA'
    dict_1['title'] = '`4O"O[OUWh'
    dict_1['title'] = '_|;O"G>Yh<'
    dict_1['title'] = 'm!%*'
    dict_1['title'] = 'P'
    dict_1['title'] = 'iF'
    dict_1['title'] = 'B'
    dict_1['title'] = 'f'
    dict

# Generated at 2022-06-26 13:52:31.644627
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = "N,^Z:>F9|W? '"
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = {'title': str_0}
    metadata_from_title_p_p_0.run(dict_0)

# Generated at 2022-06-26 13:52:35.563821
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-26 13:52:43.125867
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'C:\\Users\\vitaly\\PycharmProjects\\youtube-dl\\youtube_dl\\postprocessor\\tests\\test%(track-number)s.mkv'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.recognize_download = MetadataFromTitlePP_recognize_download
    dict_0 = dict()
    dict_0['titl'] = str_0
    metadata_from_title_p_p_0.run(dict_0)



# Generated at 2022-06-26 13:52:46.722082
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = "N,^Z:>F9|W? '"
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.run(str_0)


# Generated at 2022-06-26 13:52:49.936997
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = "21.8 - 9.9.9"
    str_1 = "21.8 - 9.9.9"
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_1)
    metadata_from_title_p_p_0.run(str_0)


# Generated at 2022-06-26 13:52:52.406974
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP()
    metadata_info_0 = metadata_from_title_p_p_0.run(metadata_info_0)


# Generated at 2022-06-26 13:52:56.475989
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    f = open("test_MetadataFromTitlePP_run.out", 'w')
    test_case_0()
    f.close()
    return 0


if __name__ == '__main__':
    sys.exit(test_MetadataFromTitlePP_run())

# Generated at 2022-06-26 13:52:58.973581
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = "N,^Z:>F9|W? '"
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)


# Generated at 2022-06-26 13:53:03.913962
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = "N,^Z:>F9|W? '"
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_1.run(str_0)
