

# Generated at 2022-06-26 13:44:09.710901
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '!@#$%^&*()'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = dict()
    dict_0['title'] = str_0
    dict_1 = dict()
    dict_1['title'] = str_0
    list_0 = metadata_from_title_p_p_0.run(dict_1)
    assert len(list_0) == 2
    assert list_0[0] == []
    assert list_0[1] == dict_0


# Generated at 2022-06-26 13:44:18.380666
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '!'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_0, str_1)

if __name__ == "__main__":
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:44:23.018279
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    info_0 = dict()
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str, str)
    metadata_from_title_p_p_0.info = info_0
    metadata_from_title_p_p_0.info = dict()
    metadata_from_title_p_p_0.info = dict()
    metadata_from_title_p_p_0.run(info_0)
    metadata_from_title_p_p_0.run(info_0)
    metadata_from_title_p_p_0.run(info_0)

# Unit tests for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-26 13:44:28.518853
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.format_to_regex(str_0)


# Generated at 2022-06-26 13:44:34.839324
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '!'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = dict()
    dict_0['title'] = str_0
    list_0 = []
    info = dict_0
    return_value = metadata_from_title_p_p_0.run(info)
    assert list_0 == return_value[0]
    assert dict_0 == return_value[1]


# Generated at 2022-06-26 13:44:42.983325
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    info = {'title': 'TheLegend27'}

    metadata_from_title_p_p_0 = MetadataFromTitlePP(str, str)
    metadata_from_title_p_p_0.run(info)

    assert(metadata_from_title_p_p_0._titleregex == '(.*)')
    assert(metadata_from_title_p_p_0._titleformat == '(.*)')
    assert(info['title'] == 'TheLegend27')

if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:44:49.021631
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    str_0 = '!'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)

    assert metadata_from_title_p_p_0.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'


if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_format_to_regex()

# Generated at 2022-06-26 13:44:59.549611
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    metadata_from_title_p_p_format_to_regex_0 = MetadataFromTitlePP('1', '1')
    regex_format_to_regex_0 = r'\(\.+\)'
    assert regex_format_to_regex_0 == metadata_from_title_p_p_format_to_regex_0.format_to_regex('%s')
    metadata_from_title_p_p_format_to_regex_1 = MetadataFromTitlePP('1', '1')
    regex_format_to_regex_1 = r'title'
    assert regex_format_to_regex_1 == metadata_from_title_p_p_format_to_regex_1.format_to_regex('title')

# Generated at 2022-06-26 13:45:06.824154
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '!'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    list_0 = []

# Generated at 2022-06-26 13:45:13.789397
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # tests with %(title)s
    test_case_0 = ('%(title)s', 'test title', {'title': 'test title'})
    # tests with %(title)s - %(artist)s
    test_case_1 = ('%(title)s - %(artist)s', 'test title - test artist', {'title': 'test title', 'artist': 'test artist'})
    # test with %(title)s - %(artist)s - %(dupa)s
    test_case_2 = ('%(title)s - %(artist)s - %(dupa)s', 'test title - test artist - test dupa', {'title': 'test title', 'artist': 'test artist', 'dupa': 'test dupa'})
    # test with %(title)s - %(xxx)

# Generated at 2022-06-26 13:45:20.834701
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    var_0 = dict()
    var_1 = list()
    obj_0 = MetadataFromTitlePP(var_0, "")
    var_1 += obj_0.run(var_0)
    print(var_1)


# Generated at 2022-06-26 13:45:21.462639
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    var_0 = dict()


# Generated at 2022-06-26 13:45:26.778025
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    var_1 = MetadataFromTitlePP(var_0, '%(title)s - %(artist)s')
    var_2 = dict()
    var_2['title'] = 'foo - bar'
    var_3 = var_1.run(var_2)
    assert var_3[0] == [], 'Failed assertions 1'
    assert var_3[1]['artist'] == 'bar', 'Failed assertions 2'
    assert var_3[1]['title'] == 'foo', 'Failed assertions 3'


# Generated at 2022-06-26 13:45:31.042950
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    var_1 = dict()
    var_2 = dict()
    var_2["title"] = "abcd"
    var_3 = re.match(r'%\(\w+\)s', '%(title)s')
    var_4 = PostProcessor.__init__(var_1, var_2)

# Unit tests for _init_ method of class MetadataFromTitlePP

# Generated at 2022-06-26 13:45:35.664337
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    var_0 = MetadataFromTitlePP()
    var_1 = test_case_0()
    var_2 = var_0.run(var_1)
    assert var_1 == var_2

# Generated at 2022-06-26 13:45:37.215155
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    var_0 = dict()
    var_0['title'] = 'title'


# Generated at 2022-06-26 13:45:48.300909
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Input variables
    var_0 = None
    # Output variables
    var_1 = list()
    var_2 = dict()

    # Test 0: simple case, single item

    # Input variables
    var_0 = None
    var_0 = {'title': 'Video title - here'}
    # Output variables
    var_1 = list()
    var_2 = dict()

    # Tested function
    var_0.setdefault('_type', 'video')
    var_1, var_2 = MetadataFromTitlePP(var_0, "%(title)s").run(var_0)
    if var_1 == list():
        if var_0 == dict():
            if var_2 == dict():
                pass

# Generated at 2022-06-26 13:45:50.001058
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    var_0 = MetadataFromTitlePP()
    var_0.run()



# Generated at 2022-06-26 13:45:59.951395
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    var_1 = dict()
    var_1['title'] = 'test_title'
    var_2 = MetadataFromTitlePP(var_1, var_1)
    var_3 = var_2.run(var_1)
    if var_3[0] != []:
        print ('Failed test #0')
        print ('Expected: (%s,)') % ([],)
        print ('Received: (%s,)') % (var_3,)
    if var_3[1] != {'title': 'test_title'}:
        print ('Failed test #1')
        print ('Expected: (%s,)') % ({'title': 'test_title'},)
        print ('Received: (%s,)') % (var_3[1],)

# Global Variables
var_0 = dict()
var

# Generated at 2022-06-26 13:46:05.586350
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pp = MetadataFromTitlePP(None, '%(title)s')
    info = {'title': 'some title'}
    pp.run(info)
    assert 'title' in info
    assert info['title'] == 'some title'
    info = {'title': 'some title - some artist'}
    pp.run(info)
    assert 'title' in info
    assert 'artist' in info
    assert info['title'] == 'some title'
    assert info['artist'] == 'some artist'
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == 'some title'
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    info = {'title': 'some title - some artist'}

# Generated at 2022-06-26 13:46:17.399030
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    var_0 = MetadataFromTitlePP(
        None,
        'https://www.youtube.com/watch?v=1v6LV2y6XJE')

    var_1 = dict(
        {
            'title': 'Katy Perry - Bon Appétit (Official) ft. Migos',
            'id': '1v6LV2y6XJE'
        }
    )

    var_2, var_3 = var_0.run(var_1)

    assert var_1['title'] == var_3['title']
    assert var_1['id'] == var_3['id']
    assert var_1['artist'] == var_3['artist']
    assert var_1['song'] == var_3['song']

# Generated at 2022-06-26 13:46:22.858705
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    var_0 = MetadataFromTitlePP('test_arg_0', 'test_arg_1')
    var_1 = dict()
    var_2 = var_0.run(var_1)
    assert var_2 == ([], {}), "Return value should be ([], {})"

if __name__ == "__main__":
    print("Here are the manual test functions")
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:46:25.326520
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    case_id = 'run'

    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-26 13:46:25.961346
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()

# Generated at 2022-06-26 13:46:33.559146
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import json

    # Test case 0
    var_0 = dict()
    var_1 = MetadataFromTitlePP(var_0, var_0)
    var_2 = dict()
    var_2['title'] = str()
    var_3 = var_1.run(var_2)
    assert var_3[0] == []
    var_4 = var_1.run(var_2)[1]
    assert var_4 == var_2

# Unit test execution
if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:46:41.222314
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    titleformat = '%(title)s - %(artist)s'
    downloader = var_0['downloader']
    titleregex = '(?P<title>.+)\ \-\ (?P<artist>.+)'

    # Testing with title: Mr. Big, format: %(title)s - %(artist)s
    var_0['title'] = 'Mr. Big'

    # Testing with title: [Hello World], format: %(title)s - %(artist)s
    var_0['title'] = '[Hello World]'

    # Testing with title: 耳をすませば, format: %(title)s - %(artist)s
    var_0['title'] = '耳をすませば'

    # Testing with title: [Hello] World, format: %(title)s

# Generated at 2022-06-26 13:46:51.380097
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # setup
    pp = MetadataFromTitlePP(None, '%(id)s')
    pp._titleregex = '%(id)s'
    info = dict()
    info['title'] = 'tt0944947'

    # execute
    pp.run(info)

    # assertions
    assert info['id'] == 'tt0944947'

if __name__ == '__main__':
    import sys
    import nose
    lang = sys.argv[1]
    if lang == 'case':
        nose.runmodule(globals(), argv=[sys.argv[0], '-vv', '-s', '-x', '--pdb'])

# Generated at 2022-06-26 13:46:58.256711
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-26 13:47:00.432142
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    var_1 = MetadataFromTitlePP(None, None)
    var_2 = {}
    var_3 = {}


# Generated at 2022-06-26 13:47:05.426226
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test 0
    var_0 = dict()
    # Test 1
    var_1 = dict()
    # Test 2
    var_2 = dict()

if __name__ == '__main__':

    # Test 0
    var_0 = dict()

    # Test 1
    var_1 = dict()

    # Test 2
    var_2 = dict()

# Generated at 2022-06-26 13:47:10.196225
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    var_0 = dict()
    var_1 = MetadataFromTitlePP('', '%(title)s - %(artist)s')
    var_1.run(var_0)
    return var_1

# Generated at 2022-06-26 13:47:13.360892
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    var_1 = MetadataFromTitlePP(None, None)
    var_2 = var_1.run({'title': ''})
    assert len(var_2) == 2
    assert var_2[0] == []
    

# Generated at 2022-06-26 13:47:14.180162
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # test case 0:
    var_0 = dict()

# Generated at 2022-06-26 13:47:16.123460
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    print("test_MetadataFromTitlePP_run")
    var_0 = MetadataFromTitlePP("test")
    var_0.run("test")


# Generated at 2022-06-26 13:47:19.035350
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    var_1 = MetadataFromTitlePP(test_case_0(), None)
    var_1.run(dict())


# Generated at 2022-06-26 13:47:23.718133
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    var_1 = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    var_2 = dict()
    var_2['title'] = 'foo bar'
    var_3, var_4 = var_1.run(var_2)
    assert var_3 == []
    assert var_4 == {'artist': 'bar', 'title': 'foo bar'}


# Generated at 2022-06-26 13:47:25.074918
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    var_1 = MetadataFromTitlePP(None, None,)
    return


# Generated at 2022-06-26 13:47:29.237852
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """Unit test for method run of class MetadataFromTitlePP"""
    obj = MetadataFromTitlePP(
        downloader=None,
        titleformat='%(title)s')
    assert obj.run(info={'title': 'abc'}) == ([], {
        'title': 'abc'})


# Generated at 2022-06-26 13:47:32.814231
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    var_0 = dict()
    var_0['title'] = 'foo_bar'

    var_1 = MetadataFromTitlePP(None, '%(title)s')
    var_1.run(var_0)
    assert var_0['title'] == 'foo_bar'


# Generated at 2022-06-26 13:47:36.209573
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    title = '1. Track 1 - Artist 1'
    mp3 = PostProcessor(title)

    assert mp3.title == '1. Track 1 - Artist 1', "Track name not read correctly, read: %s" % mp3.title


# Generated at 2022-06-26 13:47:45.430863
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    youtube_dl_object = youtube_dl_object_1()
    MetadataFromTitlePP_object = MetadataFromTitlePP(youtube_dl_object, var_0)
    MetadataFromTitlePP_object.run(var_0)
    # assert result

# Generated at 2022-06-26 13:47:52.040630
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    var_0 = MetadataFromTitlePP(None, '%(playlist_index)s')
    var_0.format_to_regex('%(test)s')
    var_1 = MetadataFromTitlePP(None, '%(test)s')
    var_1.format_to_regex('%(test)s - %(test)s')
    var_2 = MetadataFromTitlePP(None, '%(test)s - %(test)s')


# Generated at 2022-06-26 13:47:59.389691
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    var_0 = dict()
    var_1 = MetadataFromTitlePP(var_0, '%(title)s - %(artist)s')
    var_2 = {'title': 'test.mp3'}
    var_3 = ['test.mp3 - test.mp3']
    test_case_0()
    assert var_1.run(var_2) == (var_3, var_2)

if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:48:06.493732
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    var_0 = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    var_1 = {
        'title': 'Title - Artist'
    }
    var_2 = var_0.run(var_1)
    if var_2[0] != []:
        print('[!] MetadataFromTitlePP.run() - 0')

# Test #1
# Set:
    var_0 = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    var_1 = {
        'title': 'Title - Artist'
    }
    var_2 = var_1
    var_3 = var_0
# Call:
    var_4 = var_3.run(var_2)
# Check:

    var_5 = var_4

# Generated at 2022-06-26 13:48:10.592170
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    print('Should not fail, please ignore.')
    for i in range(4):
        test_case_0()

if __name__ == '__main__':
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:48:15.077787
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    var_0 = MetadataFromTitlePP()
    var_1 = MetadataFromTitlePP()
    var_2 = MetadataFromTitlePP()
    test_case_0()

# Testing the Python implementation to make sure that it is consistent with
# the C implementation

# Generated at 2022-06-26 13:48:18.288933
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_obj = MetadataFromTitlePP()
    test_obj.run(var_0)


if __name__ == '__main__':
    test_case_0()

# End of file

# Generated at 2022-06-26 13:48:18.805627
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()

# Generated at 2022-06-26 13:48:20.494479
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    var_0 = MetadataFromTitlePP('var_1', 'var_2')
    var_3 = dict()
    assert var_0.run(var_3) == ([], var_3)


# Generated at 2022-06-26 13:48:24.330813
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    var_0 = MetadataFromTitlePP(None, "")
    var_1 = {'title': 'Title', 'id': 'ID'}
    var_2, var_3 = var_0.run(var_1)
    assert(var_3 == {'title': 'Title', 'id': 'ID'})


# Generated at 2022-06-26 13:48:32.049603
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # set up
    var_0 = re.escape('%(artist)s')
    var_1 = re.escape(' - ')
    var_2 = re.escape('%(title)s')
    var_3 = var_0 + '\\ \\-\\ ' + var_2
    assert var_3 == '%\\(artist\\)s\\ \\\\-\\ %\\(title\\)s'


# Generated at 2022-06-26 13:48:33.094537
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    _test_case_0()
    pass

# Generated at 2022-06-26 13:48:33.882047
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert test_case_0() == (list(), dict())

# Generated at 2022-06-26 13:48:40.028690
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    var_0 = dict()
    pp = MetadataFromTitlePP(var_0, var_0)
    pp.run(var_0)

# test_case_0:
try:
    test_case_0()
except Exception as e:
    print('unexpected exception: %s' % e)
# test_MetadataFromTitlePP_run:
try:
    test_MetadataFromTitlePP_run()
except Exception as e:
    print('unexpected exception: %s' % e)

# vim: expandtab shiftwidth=4 tabstop=4

# Generated at 2022-06-26 13:48:40.821882
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass


# Generated at 2022-06-26 13:48:48.184015
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    var_0 = dict()
    var_0['title'] = 'abc'
    var_0['id'] = 'id123'
    var_0['age_limit'] = 18
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    var_1 = pp.run(var_0)
    assert var_1[0] == []
    assert var_1[1]['title'] == 'abc'
    assert var_1[1]['id'] == 'id123'
    assert var_1[1]['age_limit'] == 18
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    var_1 = pp.run(var_0)
    assert var_1[0] == []
    assert var_1

# Generated at 2022-06-26 13:48:49.743135
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    try:
        pytube_utility.MetadataFromTitlePP.run(var_0)
    except:
        print ("Test failed")
    

# Generated at 2022-06-26 13:48:57.681168
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from python_ptrace.debugger.debugger import Debugger
    from python_ptrace.tracer.tracer import PtraceTracer
    from python_ptrace.tools.memreader import read_data
    from python_ptrace.tools.datatype import CString, DataTypes
    from ptrace.error import PtraceError
    from ptrace.ctypes_tools import process_is_64bits
    from ctypes import c_char, c_long, c_int, c_char_p, POINTER
    from ptrace.func_call import FunctionCallOptions
    from ptrace.syscall import SYSCALL_NAMES, SyscallOptions
    from ptrace.debugger.memory_mapping import MemoryMapping
    
    var_4 = Debugger()
    var

# Generated at 2022-06-26 13:49:06.039018
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    case_0_title = 'test.mp4'
    case_0_titleformat = '%(title)s'
    case_0_fmt = 'test.mp4'
    case_0_downloader = dict()
    case_0_info = dict()
    case_0_info['title'] = case_0_title
    mft = MetadataFromTitlePP(case_0_downloader, case_0_titleformat)
    case_0_regex = re.compile(mft._titleregex)
    match = case_0_regex.match(case_0_title)
    result_a, result_b = mft.run(case_0_info)

    assert type(result_a) == list
    assert type(result_b) == dict

# Generated at 2022-06-26 13:49:14.478676
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    var_1 = '%(title)s - %(artist)s'
    var_2 = '%(title)s - %(artist)s'
    var_3 = '%(title)s - %(artist)s'
    var_4 = '%(title)s - %(artist)s'
    var_5 = '%(title)s - %(artist)s'
    var_6 = '%(title)s - %(artist)s'
    var_7 = '%(title)s - %(artist)s'
    var_8 = '%(title)s - %(artist)s'
    var_9 = '%(title)s - %(artist)s'
    var_10 = '%(title)s - %(artist)s'

# Generated at 2022-06-26 13:49:17.271459
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert False # TODO: implement your test here


# Generated at 2022-06-26 13:49:25.578474
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP('', '')
    # testing conversion of format to regex
    str_0 = '%(title)s'
    str_1 = '%(artist)s'
    str_2 = '%(title)s - %(artist)s'
    str_3 = '%(title)s - %(artist)s - %(duration)s'
    str_4 = '%(title)s - %(artist)s - %(duration)s - %(upload_date)s'
    str_5 = '%(title)s - %(artist)s - %(duration)s - %(upload_date)s - %(id)s'

# Generated at 2022-06-26 13:49:32.030906
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    info = dict(title='Florence + The Machine - Cosmic Love')
    info = pp.run(info)[1]
    assert info['artist'] == 'Florence + The Machine'
    assert info['title'] == 'Cosmic Love'


if __name__ == '__main__':
    from pytest import main

    main(['-x', '--pdb', __file__])

# Generated at 2022-06-26 13:49:35.021415
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    titleformat_0 = '%(title)s - %(artist)s'

    # Create an instance of MetadataFromTitlePP
    metadata_from_title_p_p_0 = MetadataFromTitlePP(titleformat_0, titleformat_0)

    # Call function run of metadata_from_title_p_p_0
    metadata_from_title_p_p_0.run(titleformat_0)

# Generated at 2022-06-26 13:49:36.848417
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '!'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)


# Generated at 2022-06-26 13:49:40.548208
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    info_dict_0 = {'title': str_0}
    metadata_from_title_p_p_0.run(info_dict_0)

# Generated at 2022-06-26 13:49:47.921121
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'testcase_0'
    list_0 = []
    dict_0 = {}
    dict_0[str_0] = str_0
    list_1 = []
    dict_2 = {}
    dict_2['title'] = str_0
    dict_2[str_0] = str_0
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0._titleregex = str_0
    list_2, dict_3 = metadata_from_title_p_p_0.run(dict_2)
    assert list_2 == list_1
    assert dict_3 == dict_0


# Generated at 2022-06-26 13:49:55.415444
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    info_0 = {}
    metadata_from_title_p_p_0 = MetadataFromTitlePP(1, 1)
    exception_1 = None
    try:
        metadata_from_title_p_p_0.run(info_0)
    except Exception as exception_1:
        print('Exception caught while running unit test for method run of class MetadataFromTitlePP:', exception_1)

if __name__ == '__main__':
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:50:02.948985
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    info_1 = {'title': 'uploader name - title'}
    metadata_from_title_p_p_1 = MetadataFromTitlePP('uploader', 'title')
    info_2 = {'title': 'title - uploader name'}
    metadata_from_title_p_p_2 = MetadataFromTitlePP('uploader', 'title')

if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()


# Tests for the format_to_regex function

# Generated at 2022-06-26 13:50:07.413075
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '!!! TEST !!!'
    dict_0 = {}
    dict_0['title'] = str_0
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    assert_equals(metadata_from_title_p_p_0.run(dict_0), ([], dict_0))

test_case_0()

# Generated at 2022-06-26 13:50:18.592145
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Unit test for method run of class MetadataFromTitlePP
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_0 = ''
    str_1 = ''
    metadata_from_title_p_p_0._titleformat = str_0
    metadata_from_title_p_p_0._titleregex = re.escape(str_0)
    metadata_from_title_p_p_0._titleformat = str_1
    metadata_from_title_p_p_0._titleregex = re.escape(str_1)
    try:
        metadata_from_title_p_p_0.run(dict())
    except:
        pass


# Generated at 2022-06-26 13:50:24.531812
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'iTunes_podcast_by_Yusuf_Cat_Stevens.mp4'
    metadata_from_title_p_p_0 = MetadataFromTitlePP('youtube-dl', str_0)
    metadata_from_title_p_p_0._titleformat = '%(artist)s_-_%(title)s.mp3'
    info_0 = {'title': 'It\'s A Beautiful Day - White Bird'}
    metadata_from_title_p_p_0.run(info_0)
    # assert metadata_from_title_p_p_0._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-26 13:50:26.915429
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test case 0
    str_0 = '!'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)


# Generated at 2022-06-26 13:50:27.545557
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass

# Generated at 2022-06-26 13:50:33.638568
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP('!', '%(title)s - %(artist)s')
    dict_0 = {'id': 'BCeqVN_bLNw', 'uploader': 'blabla', 'title': 'bla - bla', 'upload_date': '20190115'}
    metadata_from_title_p_p_0.run(dict_0)

# Generated at 2022-06-26 13:50:36.661431
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '!'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = dict()
    dict_0['title'] = '!'

    assert metadata_from_title_p_p_0.run(dict_0) == ([], dict_0)

# Generated at 2022-06-26 13:50:38.716150
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP()
    metadata_from_title_p_p_0.run(info=None)

# Generated at 2022-06-26 13:50:48.586539
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # setup
    run_0 = object()
    metadata_from_title_p_p_0 = MetadataFromTitlePP(run_0, run_0)
    str_1 = '!'
    dict_0 = {'title': 'hello'}
    # on call
    # on method call
    # on call
    # on method call
    # on call
    # on method call
    
    str_2 = '!'
    metadata_from_title_p_p_0._titleformat = str_2
    # on call
    # on method call
    str_3 = '!'
    metadata_from_title_p_p_0._titleregex = str_3
    # on call
    # on method call
    str_4 = 'hello'
    dict_1 = {'title': str_4}


# Generated at 2022-06-26 13:50:57.062936
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '!'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = collections.OrderedDict()
    dict_0['title'] = 'test'
    dict_0['artist'] = 'test'
    dict_1 = dict_0.copy()
    str_1 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_0, str_1)
    dict_0['title'] = 'test'
    dict_0['artist'] = 'test'
    dict_1 = dict_0.copy()
    str_2 = '%(title)s'
    metadata_from_title_p_p_2 = MetadataFromTitlePP

# Generated at 2022-06-26 13:51:02.339673
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'Ѫ'
    str_1 = '{to the %(title)s: %(author)s - %(title)s}'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_1)
    dict_0 = {'extra': 'Ѫ'}
    metadata_from_title_p_p_0.run(dict_0)
    print(dict_0)

if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:51:13.105598
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str(), str())
    str_0 = '!'
    str_1 = '!'
    metadata_from_title_p_p_0.format_to_regex(str_0)
    metadata_from_title_p_p_0.run(str_1)

# c: 1160
# vim: expandtab

# Generated at 2022-06-26 13:51:17.365376
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str, str)
    dict_0 = {}
    dict_0['title'] = 'title'
    dict_1 = metadata_from_title_p_p_0.run(dict_0)
    assert dict_1 == ([], {'title':'title'})


# Generated at 2022-06-26 13:51:19.350157
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '!'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    list_0 = []
    dict_0 = {}

# Generated at 2022-06-26 13:51:27.116556
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    print('test_MetadataFromTitlePP_run')
    # create an instance of MetadataFromTitlePP with a format string
    fmt = '%(title)s by %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, fmt)

    # test a video title that is correctly parsed by the regex
    info = {'title': 'Jingle Bells by Foo Bar'}
    metadata_from_title_p_p_0.run(info)
    # verify that the metadata dictionary was changed as expected
    assert info['title'] == 'Jingle Bells'
    assert info['artist'] == 'Foo Bar'
    # TODO: add verification of other attributes

    # test a title with an incorrect format
    info = {'title': 'Jingle Bells (Foo Bar)'}

# Generated at 2022-06-26 13:51:36.114299
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '!T'
    # [fromtitle] Could not interpret title of video as "%s"
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = {'title': '.!999'}
    # [fromtitle] Could not interpret title of video as "%s"
    # [] False
    assert metadata_from_title_p_p_0.run(dict_0) == ([], dict_0)
    str_1 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_0, str_1)
    dict_1 = {'title': '.!999'}

# Generated at 2022-06-26 13:51:39.843137
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%'
    str_1 = '!'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_1, str_0)
    info_0 = {'title': str_1}
    metadata_from_title_p_p_0.run(info_0)


# Generated at 2022-06-26 13:51:43.349959
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    p_p = MetadataFromTitlePP(str_0, str_1)
    metadata_from_title_p_p = p_p
    p_p.run(dict_0)


# Generated at 2022-06-26 13:51:52.256341
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    bool_0 = bool()
    bool_0 = bool()
    bool_0 = bool()
    bool_0 = bool()
    bool_0 = bool()
    bool_0 = bool()
    bool_0 = bool()
    bool_0 = bool()
    bool_0 = bool()
    metadata_from_title_p_p_0.run(bool_0)
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_5 = bool()
    bool_5 = bool()
    bool

# Generated at 2022-06-26 13:51:55.410397
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    info = {}
    info['title'] = 'test_title'
    metadata_from_title_p_p_0.run(info)


# Generated at 2022-06-26 13:51:57.021443
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '!'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)


# Generated at 2022-06-26 13:52:17.680348
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Declarations
    str_0 = '%(title)s'
    dict_0 = {'title': 'title'}
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_0, str_0)

    # Assertions
    if __debug__:
        assert not 'fromtitle_pp' in sys.modules, \
            'Function run of class MetadataFromTitlePP not recreated'
        assert metadata_from_title_p_p_0._titleformat == '%(title)s', \
            'Function run of class MetadataFromTitlePP not recreated'
        assert metadata_from_title_p_p_0._titleregex == metadata_from_title_

# Generated at 2022-06-26 13:52:18.197104
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert test_case_0() is None

# Generated at 2022-06-26 13:52:24.498611
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test the default case
    str_0 = '%(title)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = {'title': 'My test title'}
    dict_1 = {'title': 'My test title'}
    assert metadata_from_title_p_p_0._titleformat == str_0
    assert metadata_from_title_p_p_0._titleregex == 'My test title'
    assert metadata_from_title_p_p_0.format_to_regex(str_0) == 'My test title'
    assert metadata_from_title_p_p_0.run(dict_0) == ([], dict_1)
    # Test another case

# Generated at 2022-06-26 13:52:25.707804
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '!'
    metadata_from_title_p_p_0 = MetadataFromTitl

# Generated at 2022-06-26 13:52:33.914673
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '<?xml version="1.0" encoding="UTF-8"?><a>string</a>'
    str_1 = '='
    str_2 = '&&'
    str_3 = 'string'
    str_4 = '.'
    str_5 = '<?xml version="1.0" encoding="UTF-8"?><a>string</a>'
    str_6 = '?'
    str_7 = 'string'
    str_8 = '.'
    str_9 = '.'
    str_10 = '.'
    str_11 = '.'
    str_12 = '.'
    str_13 = '.'
    str_14 = 'string'
    str_15 = 'string'
    list_0 = []
    dict_3 = {}
    list_1 = ['string']
   

# Generated at 2022-06-26 13:52:39.114408
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_1 = MetadataFromTitlePP('a', 'a')
    metadata_from_title_p_p_1.run('a')
    assert_equals(metadata_from_title_p_p_1._titleformat, 'a')
    assert_equals(metadata_from_title_p_p_1._titleregex, 'a')


# Generated at 2022-06-26 13:52:44.653033
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    info_0 = {}
    str_0 = '!!!!'
    info_0['title'] = str_0
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, '!!!!')
    metadata_from_title_p_p_1 = metadata_from_title_p_p_0.run(info_0)
    assert(metadata_from_title_p_p_1 == ([], info_0))
    assert(metadata_from_title_p_p_1 == ([], info_0))

# Generated at 2022-06-26 13:52:49.755948
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    format = '%(title)s - %(artist)s'
    regex = '(?P<title>.+) - (?P<artist>.+)'
    pp = MetadataFromTitlePP(object(), format)
    info = {'title': 'Video - Foo'}
    ret, new_info = pp.run(info)
    assert info == {'title': 'Video - Foo'}
    assert new_info == {'title': 'Video', 'artist': 'Foo'}

    pp = MetadataFromTitlePP(object(), regex)
    info = {'title': 'Video - Foo'}
    ret, new_info = pp.run(info)
    assert info == {'title': 'Video - Foo'}
    assert new_info == {'title': 'Video', 'artist': 'Foo'}


# Generated at 2022-06-26 13:52:51.738795
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass


if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:52:58.842097
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    print('*** Testcase MetadataFromTitlePP.run ***')
    # Setup
    title_0 = unicode('title_0')
    str_0 = '%(title)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    info_0 = {u'title': title_0}
    expected_0 = ([], info_0)
    # Test
    actual_0 = metadata_from_title_p_p_0.run(info_0)
    # Verify
    assert actual_0 == expected_0


# Generated at 2022-06-26 13:53:24.822124
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '!'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)

if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:53:29.957557
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    dict_0 = dict()
    dict_0["title"] = 'foobar'

    metadata_from_title_p_p_0 = MetadataFromTitlePP("foo", "foo")

    list_0, dict_1 = metadata_from_title_p_p_0.run(dict_0)

    assert dict_1["title"] == "foobar"
    assert list_0 == []



# Generated at 2022-06-26 13:53:36.869685
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test case 0
    str_0 = '!'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = dict()
    dict_0['title'] = '''The%(movie)s'''
    dict_0['movie'] = ''
    list_0 = list()
    dict_1 = dict()
    dict_2 = dict()
    dict_2['title'] = '''The%(movie)s'''
    dict_1['movie'] = ''
    assert_equals((list_0, dict_1), metadata_from_title_p_p_0.run(dict_2))

# Generated at 2022-06-26 13:53:40.527230
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '!'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    # Test fails due to type check failure
    with pytest.raises(TypeError):
        metadata_from_title_p_p_0.run(metadata_from_title_p_p_0)

# Generated at 2022-06-26 13:53:42.098039
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    if __name__ == '__main__':
        test_case_0()
    if __name__ == '__main__':
        test_case_1()


# Generated at 2022-06-26 13:53:45.263043
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_1 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_1, str_1)
    str_2 = 'The Dark Knight Rises - Trailer 3 [HD]'
    dict_0 = {'title': str_2}
    assert metadata_from_title_p_p_1.run(dict_0)


# Generated at 2022-06-26 13:53:52.814088
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class CollectPPOutput(PostProcessor):
        def __init__(self):
            self._postprocessors = []

        def run(self, info):
            self._postprocessors.append(info)

    ftdpp = MetadataFromTitlePP(CollectPPOutput(), '%(title)s')
    ftdpp.run({'title': 'test title'})
    assert ftdpp.run({'title': 'test title'}) == ({}, {
        'title': 'test title',
        'title': 'test title'
    })
    assert ftdpp.run({
        'title': 'test title'
    }) == ([], {
        'title': 'test title',
        'title': 'test title'
    })

# Generated at 2022-06-26 13:53:55.596864
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
	str_0 = '!'
	metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)

	dic_0 = {'title': str_0}
	arr_0 = metadata_from_title_p_p_0.run(dic_0)

	return arr_0

