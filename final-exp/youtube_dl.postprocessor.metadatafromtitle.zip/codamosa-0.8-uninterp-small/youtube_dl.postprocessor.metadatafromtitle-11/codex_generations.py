

# Generated at 2022-06-26 13:43:58.824334
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert 101 == 101

# Generated at 2022-06-26 13:44:10.906978
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():

    # test 0
    str_0 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(0, str_0)
    str_1 = metadata_from_title_p_p_0.format_to_regex(str_0)
    # expected: '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert str_1 == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    # test 1
    str_0 = '%(artist)s - %(title)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(0, str_0)
    str_1 = metadata_from_title_p_p_0.format_to

# Generated at 2022-06-26 13:44:19.867933
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import PostProcessor, _extract_info


# Generated at 2022-06-26 13:44:28.733207
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    float_0 = 677.5
    str_0 = '%(title)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_0, str_0)
    str_1 = 'abc'
    # {'title': str_1} to be passed
    assert metadata_from_title_p_p_0.run(str_1) is not None


# Generated at 2022-06-26 13:44:37.478164
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    '''
    Check that metadata is correctly extracted

    Args:
        title (str): Title to be tested
        regex (str): regex to be tested
        expect (str): the expected result.
    '''
    def check_title(title, regex, expect):
        mp = MetadataFromTitlePP(None, regex)
        info = {'title': title}
        mp.run(info)
        assert info == expect

    check_title('abc', 'abc', {'title': 'abc'})
    check_title('"abc"', '"abc"', {'title': '"abc"'})
    check_title('a%c', 'a%%c', {'title': 'a%c'})
    check_title('a%c', 'a%c', {'title': 'a%c'})
    check_title

# Generated at 2022-06-26 13:44:46.609215
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    float_0 = -593.3
    str_0 = 'mp4-mid'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_0, str_0)
    list_0 = []
    dict_0 = {'thumbnail': 'http://google.com/thumb.jpg', 'id': 'aSzjK8I88c4', 'duration': '302', 'ext': 'ts', 'title': 'Dmitrii Gornostaev - Spasibo, chto zhivoi (original soundtrack) (Official Video)', 'url': 'http://google.com/vid.ts', 'webpage_url': 'http://google.com/vid.html', 'view_count': '99989'}
    tuple_0 = (list_0, dict_0)
    assert tuple_

# Generated at 2022-06-26 13:44:51.149712
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    float_0 = -593.3
    str_0 = 'mp4-mid'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_0, str_0)
    assert_true(isinstance(metadata_from_title_p_p_0, MetadataFromTitlePP))


# Generated at 2022-06-26 13:44:58.371454
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(artist)s'
    str_1 = 'mp4-mid'
    int_0 = 0
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_1)
    metadata_from_title_p_p_0.run(int_0)

if __name__ == '__main__':
    test_case_0();
    test_MetadataFromTitlePP_run();

# Generated at 2022-06-26 13:45:01.358890
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    dict_0 = dict()
    dict_0['title'] = 'Random title'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(dict_0, dict_0)
    metadata_from_title_p_p_0.run(dict_0)

# Generated at 2022-06-26 13:45:02.369313
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # TODO: Implement your test case here.
    pass


# Generated at 2022-06-26 13:45:07.248664
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test cases

    # Case 0
    test_case_0()


if __name__ == '__main__':
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:45:12.287317
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    float_0 = -593.3
    str_0 = 'mp4-mid'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_0, str_0)

    list_0 = []
    dict_0 = {}
    list_1, dict_1 = metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:45:22.511121
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    float_0 = -711.8
    str_0 = 'mpeg4'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_0, str_0)
    dict_0 = dict()
    dict_0['title'] = '%(title)s - %(artist)s'
    dict_1 = dict()
    dict_1['title'] = '%(title)s - %(artist)s'
    dict_0['description'] = dict_1
    dict_1 = dict()
    dict_1['title'] = '%(title)s - %(artist)s'
    dict_0['thumbnail'] = dict_1
    dict_1 = dict()
    dict_1['title'] = '%(title)s - %(artist)s'

# Generated at 2022-06-26 13:45:26.777898
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    title = 'Le titre'
    info = {'title': title}
    mft = MetadataFromTitlePP(None, '%(title)s')
    (formats, info) = mft.run(info)
    assert info['title'] == title

if __name__ == "__main__":
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:45:31.338154
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    expected_str_0 = '[fromtitle] Could not interpret title of video as "title - artist"'
    str_0 = 'mp4-mid'
    metadata_from_title_p_p_0 = MetadataFromTitlePP('mp4-mid', str_0)
    assert expected_str_0 == metadata_from_title_p_p_0.run('mp4-mid')

if __name__ == '__main__':

    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:45:39.657623
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    float_0 = -593.3
    str_0 = 'mp4-mid'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_0, str_0)
    pytest.assume(metadata_from_title_p_p_0 is not None)
    # ---
    set_0 = set()
    str_1 = 'mp4-mid'
    pytest.assume(str_1 == 'mp4-mid')
    pytest.assume(False)



# Generated at 2022-06-26 13:45:50.986118
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-26 13:46:00.656155
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    float_0 = -983.8
    str_0 = 'rst'
    str_1 = 'mp3_r'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_0, str_0)
    dict_0 = {'title': 'mp3', 'artist': 'mp4'}
    metadata_from_title_p_p_0.run(dict_0)
    dict_1 = {'title': 'mp3', 'artist': 'mp4', 'album': 'mp4'}
    metadata_from_title_p_p_0.run(dict_1)
    dict_2 = {'title': 'mp4', 'artist': 'mp4', 'album': 'mp4'}

# Generated at 2022-06-26 13:46:01.737462
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    MetadataFromTitlePP - run method
    """
    pass

# Generated at 2022-06-26 13:46:13.027477
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Initialization of a MetadataFromTitlePP instance
    _0_float = -593.3
    _0_str = 'mp4-mid'
    _0_metadata_from_title_p_p = MetadataFromTitlePP(_0_float, _0_str)
    # Initialization of a dict
    _0_dict = dict()
    # Initialization of a str
    _0_str = 'title'
    # Initialization of a str
    _0_str = 'artist'
    # Initialization of a str
    _0_str = 'album'
    # Initialization of a str
    _0_str = 'track'
    # Initialization of a str
    _0_str = 'year'
    # Initialization of a str
    _0_str = 'genre'
    # Set value at dict[

# Generated at 2022-06-26 13:46:17.754118
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    print('Testing function run of class MetadataFromTitlePP')
    metadata_from_title_p_p_0 = MetadataFromTitlePP(0, 'raw')
    metadata_from_title_p_p_0.run()


# Generated at 2022-06-26 13:46:24.203571
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    # Set up local variables
    str_0 = 'mp4-mid'
    float_0 = -593.3
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_0, str_0)
    str_0 = 'mp4-mid'
    float_0 = -593.3
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_0, str_0)

    # Call method under test
    metadata_from_title_p_p_0.run(None)


# Generated at 2022-06-26 13:46:26.802686
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Create a instance of MetadataFromTitlePP class
    metadata_from_title_p_p_0 = MetadataFromTitlePP()
    # Call run method of instance
    metadata_from_title_p_p_0.run()

# Generated at 2022-06-26 13:46:28.138336
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """Test run"""
    MetadataFromTitlePP.run()

# Generated at 2022-06-26 13:46:33.275137
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    title = 'Wall Street Journal - How to Play Local Video Files on Your Chromecast'
    info = {'title': title}
    titleformat = '%(title)s - %(journal)s - %(year)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(test_case_0, titleformat)
    metadata_from_title_p_p_0.run(info)

# Generated at 2022-06-26 13:46:33.856764
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass

# Generated at 2022-06-26 13:46:38.911479
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    float_0 = -593.3
    str_0 = 'mp4-mid'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_0, str_0)
    dict_0 = {'filtercodes': 'fps=60,scale=640:360,setsar=1/1'}
    metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:46:40.856706
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass
    #assert callable(metadata_from_title_p_p_0.run)


# Generated at 2022-06-26 13:46:44.418980
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    float_0 = 1018.25
    str_0 = 'ogg-audio-only'
    assert hasattr(MetadataFromTitlePP(float_0, str_0), 'run')

# Generated at 2022-06-26 13:46:49.633019
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    float_0 = -593.3
    str_0 = 'mp4-mid'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_0, str_0)
    output_0 = []
    list_0 = []
    output_1 = metadata_from_title_p_p_0.run(list_0)
    assert str(output_1).strip() == str(output_0).strip()

# Generated at 2022-06-26 13:46:59.193389
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    float_0 = -593.3
    str_0 = 'mp4-mid'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_0, str_0)
    title_0 = 'parsed site: youtube.com'
    dict_0 = {'site': 'youtube.com'}
    str_1 = 'mp4-mid'
    dict_1 = {'title': 'parsed site: youtube.com'}
    assert metadata_from_title_p_p_0.run(dict_1) == ([], dict_0)


# Generated at 2022-06-26 13:47:04.222262
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    # Expected result
    expected = ( [],
                 [ 'aa', 'bb', 'cc' ] )

    # Code to test
    metadata_from_title_p_p_0 = MetadataFromTitlePP()

    # Invoke method and check result
    assert(metadata_from_title_p_p_0.run( 'aa', 'bb', 'cc') == expected)

# Generated at 2022-06-26 13:47:05.792057
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert 1 == 1

test_MetadataFromTitlePP_run()
test_case_0()

# Generated at 2022-06-26 13:47:06.650268
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()

# Generated at 2022-06-26 13:47:16.054987
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    float_0 = -30.5
    str_0 = 'mp4-mid'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_0, str_0)
    str_1 = 'mp3-mid'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_0, str_1)
    float_1 = -1865.4
    str_2 = 'mp4-mid'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_1, str_2)
    str_3 = 'mp3-mid'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_1, str_3)
    float_2 = -657.9

# Generated at 2022-06-26 13:47:21.925379
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    float_0 = -593.3
    str_0 = 'mp4-mid'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_0, str_0)
    file_0 = open('/tmp/test_file', 'r')
    info_0 = file_0.read()
    info_1 = metadata_from_title_p_p_0.run(info_0)



# Generated at 2022-06-26 13:47:27.567111
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    float_0 = -987.5
    str_0 = '%(title)s.%(ext)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_0, str_0)
    str_1 = 'mp4-mid'
    dict_0 = {'ext': str_1}
    metadata_from_title_p_p_0.run(dict_0)

# Generated at 2022-06-26 13:47:30.218266
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP()
    assert (metadata_from_title_p_p_0.run('fggck') is [])


# Generated at 2022-06-26 13:47:38.812305
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import Downloader
    from ..YoutubeIE import YoutubeIE
    from ..YoutubePlaylistIE import YoutubePlaylistIE
    from ..YoutubeChannelIE import YoutubeChannelIE
    from ..extractor import youtube_dl
    from ..utils import DateRange

    class DateRangeIE(youtube_dl.InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(DateRangeIE, self).__init__(*args, **kwargs)
            self.expected_date_range = None
            self.date_range = None

        def _real_initialize(self):
            self.expected_date_range = DateRange(self._match_id(self._VALID_URL).group(1))

        def report_date_range(self, date_range):
            self.date_range = date_range

# Generated at 2022-06-26 13:47:40.525100
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()
    # Tested in test_TitlePP

# Generated at 2022-06-26 13:47:50.359925
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    float_0 = -593.3
    str_0 = 'mp4-mid'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_0, str_0)

    m_f_t_p_p_0 = metadata_from_title_p_p_0.run(str_0)


# Generated at 2022-06-26 13:47:55.581869
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    float_0 = 798.5
    str_0 = 'x1080-1400k-64k-svq3'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_0, str_0)
    info_0 = {}
    info_0['title'] = '1080'
    metadata_from_title_p_p_0.run(info_0)



# Generated at 2022-06-26 13:48:04.720718
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
  t1 = ("""
      [fromtitle] parsed title: Foo
      [fromtitle] parsed artist: Bar
      [fromtitle] parsed album: Baz
      """)

  t2 = ("""
      [fromtitle] parsed title: Foo
      [fromtitle] parsed artist: Bar
      [fromtitle] Could not interpret title of video as "%%(title)s - %%(artist)s - %%(album)s"
      """)
  assert MetadataFromTitlePP('foo', '%%(title)s')._titleregex == '(?P<title>.+)'
  assert MetadataFromTitlePP('foo', '%%(title)s - %%(artist)s - %%(album)s')._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'

# Generated at 2022-06-26 13:48:10.027723
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    fmt = '%(title)s - %(artist)s'
    mp = MetadataFromTitlePP(None, fmt)
    info = {'title': 'mytitle - myartist'}
    res, info = mp.run(info)
    assert info['title'] == 'mytitle - myartist'
    assert info['artist'] == 'myartist'

# Generated at 2022-06-26 13:48:16.855596
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    float_0 = -593.3
    str_0 = 'mp4-mid'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_0, str_0)
    str_1 = 'mp4-mid'
    map_0 = {'title': str_1}
    list_0 = []
    metadata_from_title_p_p_0.run(map_0)


# Generated at 2022-06-26 13:48:24.114862
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    float_0 = float(0)
    float_1 = float(1)
    float_2 = float(2)
    float_3 = float(3)
    float_4 = float(4)
    float_5 = float(5)
    float_6 = float(6)
    float_7 = float(7)
    float_8 = float(8)
    float_9 = float(9)
    float_10 = float(10)
    float_11 = float(11)
    float_12 = float(12)
    float_13 = float(13)
    float_14 = float(14)
    float_15 = float(15)
    float_16 = float(16)
    str_0 = 'mp4-mid'
    metadata_from_title_p_p_0 = MetadataFromTitle

# Generated at 2022-06-26 13:48:34.110065
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s - %(artist)s'
    str_1 = '%(a)s - %(b)s'
    str_2 = '%(title)s'
    str_3 = '%(title)s - %(season_number)s - %(episode)s - %(artist)s'
    str_4 = '%(title)s - %(season_number)s - %(episode)s - %(artist)s'
    float_0 = 101.0
    str_5 = 'mp4'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_0, str_5)
    info_0 = {'title': ''}

# Generated at 2022-06-26 13:48:37.469661
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'mp4-mid'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0)
    assert isinstance(metadata_from_title_p_p_0.run(), tuple) == True


# Generated at 2022-06-26 13:48:45.039349
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    downloader = 466.71
    titleformat = '%(title)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(downloader, titleformat)

    # format_to_regex(titleformat)
    titleformat_tmp = titleformat
    if re.search(r'%\(\w+\)s', titleformat_tmp):
        str_0 = '%(title)s'
        str_1 = '%(title)s'
        match_result_0 = re.match(str_0, str_1)
        if match_result_0 is None:
            titleformat = str_1
    else:
        titleformat = titleformat_tmp

    # run(info)
    info = {}
    info['title'] = 'Hello World'
    info_tmp = info


# Generated at 2022-06-26 13:48:50.214870
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    float_0 = -593.3
    str_0 = 'mp4-mid'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_0, str_0)
    dict_0 = {'title': 'House: Title', 'artist': 'DJ Producer'}
    ret_val_0, ret_val_1 = metadata_from_title_p_p_0.run(dict_0)
    assert ret_val_0 == [] and ret_val_1 == {'title': 'House: Title', 'artist': 'DJ Producer'}


# Generated at 2022-06-26 13:49:06.336750
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    float_0 = 9.397235e+37
    str_0 = 'X-default'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_0, str_0)
    info = {}
    info['title'] = 'TEST'
    list_0, info = metadata_from_title_p_p_0.run(info)


# Generated at 2022-06-26 13:49:14.999621
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    float_0 = -593.3
    str_0 = 'mp4-mid'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_0, str_0)
    int_0 = 0
    list_0 = []
    str_1 = '-v'

# Generated at 2022-06-26 13:49:19.302006
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    float_0 = -593.3
    str_0 = 'mp4-mid'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_0, str_0)
    dict_0 = {'title': 'mp4-mid'}
    metadata_from_title_p_p_run_0 = metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:49:27.667856
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test case where MetadataFromTitlePP can't interpret title of video
    ytdl_0 = YouTubeDL()

# Generated at 2022-06-26 13:49:32.653873
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = test_case_0()
    str_0 = 'title'
    list_0 = []
    dict_0 = {str_0: list_0}
    tuple_0 = ()
    assert tuple_0 == metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:49:34.044519
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()

if __name__ == '__main__':
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:49:42.835829
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-26 13:49:46.141591
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    float_0 = MetadataFromTitlePP(0.183, '0B0')
    dict_0 = float_0.run('%(title)s')

if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:49:52.480543
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    float_0 = -593.3
    str_0 = 'mp4-mid'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_0, str_0)
    dict_0 = {}
    dict_0['title'] = 'mp4-mid'
    list_0, dict_0 = metadata_from_title_p_p_0.run(dict_0)
    assert dict_0 == {}
    assert list_0 == []


# Generated at 2022-06-26 13:50:03.726742
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'mp4-mid'
    bool_0 = True
    float_0 = -593.3
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_0, str_0)
    str_1 = 'mp4_mid'
    str_2 = 'mp4_mid'
    str_3 = 'mp4_mid'
    str_4 = 'mp4_mid'
    str_5 = 'mp4_mid'
    str_6 = 'mp4_mid'
    str_7 = 'mp4_mid'
    bool_1 = bool_0
    str_8 = 'mp4_mid'
    str_9 = 'mp4_mid'
    str_10 = 'mp4_mid'
    str_11 = 'mp4_mid'
   

# Generated at 2022-06-26 13:50:26.963715
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()
    print('Test for method run of class MetadataFromTitlePP: %s'
          % ('Succeeded' if True else 'Failed'))


# Generated at 2022-06-26 13:50:31.336459
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    float_0 = -235.9
    str_0 = '720p'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_0, str_0)
    # TODO

if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-26 13:50:34.494438
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    float_0 = 0.8
    str_0 = 'mp4-mid'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_0, str_0)
    dict_0 = {}
    metadata_from_title_p_p_0.run(dict_0)

# Generated at 2022-06-26 13:50:37.994696
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    regex_0 = '%(title)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_0, str_0)
    str_1 = 'abcd'
    dict_0 = metadata_from_title_p_p_0.format_to_regex(regex_0)
    metadata_from_title_p_p_0.run('', dict_0, str_1)

# Generated at 2022-06-26 13:50:47.960490
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    int_1 = -670
    str_0 = '0.97'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(int_1, str_0)

    metadata = {}
    metadata['title'] = 'Titre de la vidéo'
    metadata['artist'] = 'Artiste'
    metadata['album'] = 'Album'

    metadata_from_title_p_p_0._titleformat = '%(artist)s - %(title)s - %(album)s'
    metadata_from_title_p_p_0._titleregex = '(?P<artist>.+)\ \-\ (?P<title>.+)\ \-\ (?P<album>.+)'


# Generated at 2022-06-26 13:50:56.422537
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_0, str_0)

# Generated at 2022-06-26 13:50:59.566304
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    float_0 = -593.3
    str_0 = 'mp4-mid'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_0, str_0)
    dict_0 = {}
    metadata_from_title_p_p_0.run(dict_0)

# Generated at 2022-06-26 13:51:06.754383
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    float_0 = -593.3
    str_0 = 'mp4-mid'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_0, str_0)
    str_1 = '$2.99'
    int_0 = 1
    str_2 = 'None'
    str_3 = '2017-01-13'
    str_4 = 'http://youtube.com'
    str_5 = 'http://youtube.com'
    str_6 = 'None'
    str_7 = 'mov'
    str_8 = 'None'
    str_9 = 'None'
    int_1 = 2
    str_10 = 'None'
    str_11 = 'None'
    str_12 = 'category'
    str_13 = 'None'
    str

# Generated at 2022-06-26 13:51:11.999364
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    list_0 = ['720p', '', '{}']
    list_1 = ['GB', '', '[]']
    metadata_from_title_p_p_0 = MetadataFromTitlePP(list_0, list_1)
    dict_0 = {}
    dict_0['title'] = '{[()]}'
    # Implementation of method run from class MetadataFromTitlePP
    metadata_from_title_p_p_0.run(dict_0)
    assert dict_0['title'] == '{[()]}'

# Generated at 2022-06-26 13:51:15.617802
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    float_0 = -593.3
    str_0 = 'mp4-mid'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_0, str_0)
    metadata_from_title_p_p_0.run('mp4-mid-mp4')


# Generated at 2022-06-26 13:52:12.855401
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Global variables
    float_0 = -593.3
    str_0 = 'mp4-mid'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_0, str_0)

    # Local variables
    info = {}

    # Test case
    metadata_from_title_p_p_0.run(info)

# Generated at 2022-06-26 13:52:19.191089
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    float_0 = -768.9
    str_0 = 'wav'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_0, str_0)
    tuple_0 = ('wav', 'mp3')
    dict_0 = {'uploader_id': 'k9jbxn2dp8',
              'title': 'test'}

    metadata_from_title_p_p_0.run(dict_0)
    assert dict_0 == {'upload_date': 'k9jbxn2dp8', 'uploader_id': 'test',
                      'title': 'test'}

# Generated at 2022-06-26 13:52:19.897841
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert(True)



# Generated at 2022-06-26 13:52:28.336573
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    # Testing class init method to get the metadata for a video
    int_0 = -3
    str_0 = 'flv'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(int_0, str_0)
    str_1 = 'gzip'
    str_2 = 'mp3'

# Generated at 2022-06-26 13:52:32.148035
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    title_0 = 'mp4-mid'
    info_0 = {
        'title': title_0
    }
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_0, title_0)
    metadata_from_title_p_p_0.run(info_0)

# Generated at 2022-06-26 13:52:41.098806
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    float_0 = -593.3
    str_0 = 'mp4-mid'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_0, str_0)
    list_0 = []
    dict_0 = {'title': 'Title', 'id': 'Id', 'url': 'Url', 'playlist_title': 'Playlist_title', 'duration': 'Duration', '_type': '_type', 'creator': 'Creator', 'extractor': 'Extractor', 'thumbnail': 'Thumbnail', 'upload_date': 'Upload_date'}
    list_1, dict_1 = metadata_from_title_p_p_0.run(list_0, dict_0)
    print(list_1)
    print(dict_1)


# Generated at 2022-06-26 13:52:48.252636
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    float_0 = -593.3
    str_0 = 'Xme'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_0, str_0)
    str_1 = '-1'
    str_2 = '-1'
    str_3 = 'mp4-mid'
    str_4 = 'mp4-mid'
    str_5 = 'mp4-mid'
    str_6 = 'mp4-mid'
    str_array_0 = [str_1, str_2, str_3, str_4, str_5, str_6]
    str_7 = '-1'
    str_8 = '-1'
    str_9 = 'mp4-mid'
    str_10 = 'mp4-mid'

# Generated at 2022-06-26 13:52:57.609852
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    float_0 = -593.3
    str_0 = 'mp4-mid'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_0, str_0)

    str_1 = 'mp4-mid'
    str_2 = 'mp4-mid'
    str_3 = 'mp4-mid'
    list_0 = [str_1, str_2, str_3]

    str_4 = 'mp4-mid'
    str_5 = 'mp4-mid'
    str_6 = 'mp4-mid'
    list_1 = [str_4, str_5, str_6]

    str_7 = 'mp4-mid'
    str_8 = 'mp4-mid'
    str_9 = 'mp4-mid'
    list_

# Generated at 2022-06-26 13:52:58.974597
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    video_info = MetadataFromTitlePP()
    video_info.run()


# Generated at 2022-06-26 13:53:05.769676
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    float_0 = -687.49
    str_0 = '!e\u01b3\xf3\u01e3\x9b\xf9\xda'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(float_0, str_0)
    dict_0 = dict()
    dict_1 = dict()
    dict_0['title'] = 'Cats pewd.ipsum'
    list_0 = []
    assert (metadata_from_title_p_p_0.run(dict_0) ==
            (list_0, dict_1))
