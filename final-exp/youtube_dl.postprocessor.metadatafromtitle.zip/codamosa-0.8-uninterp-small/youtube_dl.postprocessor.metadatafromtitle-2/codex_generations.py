

# Generated at 2022-06-26 13:44:05.027212
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    f_0 = 3.2
    int_0 = 1066
    set_0 = {int_0, int_0}
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, set_0)
    float_0 = f_0
    metadata_from_title_p_p_0._titleformat = float_0
    metadata_from_title_p_p_0._titleregex = '%(title)s - %(artist)s'
    int_1 = metadata_from_title_p_p_0._titleregex
    int_2 = metadata_from_title_p_p_0._titleformat
    metadata_from_title_p_p_0.format_to_regex(metadata_from_title_p_p_0._titleformat)

    return

# Generated at 2022-06-26 13:44:08.785826
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    int_0 = 1066
    set_0 = {int_0, int_0}
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, set_0)
    metadata_from_title_p_p_0.format_to_regex('%(title)s - %(artist)s')

# Generated at 2022-06-26 13:44:12.993903
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Check if the result is correct
    assert True

test_case_0()
test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:44:22.210001
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    int_0 = 1066
    set_0 = {int_0, int_0}
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, set_0)
    dict_0 = {}
    dict_0["txt"] = "/home/ubuntu/workspace/scraper/scraper/downloader.py"
    dict_0["block_size"] = 1066
    dict_0["num_segments"] = 1066
    dict_0["test"] = 1066
    dict_0["url"] = 1066
    dict_0["retries"] = 1066
    dict_0["testname"] = 1066
    dict_0["playliststart"] = 1066
    dict_0["playlistend"] = 1066
    dict_0["playlist_items"] = 1066


# Generated at 2022-06-26 13:44:32.693325
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftpp = MetadataFromTitlePP('m', 'f')
    # Simple string.
    assert mftpp.format_to_regex('stuff') == 'stuff'
    # Escaped characters.
    assert mftpp.format_to_regex('st\\uff') == 'st\\\\uff'
    # Simple %(key)s.
    assert mftpp.format_to_regex('%(a)s') == '(?P<a>.+)'
    # Simple %(key)s at the end of the string.
    assert mftpp.format_to_regex('abb%(a)s') == 'abb(?P<a>.+)'
    # Simple %(key)s at the beginning of the string.

# Generated at 2022-06-26 13:44:41.239510
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    set_0 = {int_0, int_0}
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, set_0)
    info = [{"title":"it is a title"}]
    metadata_from_title_p_p_0.run(info)
    assert info[0]["title"] is not None

if __name__ == '__main__':
    int_0 = 1066
    set_0 = {int_0, int_0}
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, set_0)
    info = [{"title": "it is a title"}]
    metadata_from_title_p_p_0.run(info)
    assert info[0]["title"] is not None

# Generated at 2022-06-26 13:44:49.859667
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = None
    set_0 = {1066, 1066}
    str_0 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_0)
    dict_0 = {'format': 'best', 'webpage_url': 'http://www.youtube.com/watch?v=z4JUm0Bq9AM', 'id': 'z4JUm0Bq9AM'}
    metadata_from_title_p_p_0.run(dict_0)

if __name__ == '__main__':
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:44:50.793994
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    check_0 = test_case_0()

# Generated at 2022-06-26 13:44:53.777797
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert MetadataFromTitlePP.run('MetadataFromTitlePP', {}) == ([], {})

# Test file

# Generated at 2022-06-26 13:45:02.782019
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    if __name__ == '__main__':
        int_0 = 1066
        set_0 = {int_0, int_0}
        metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, set_0)
        str_0 = '%(title)s - %(artist)s'
        str_1 = metadata_from_title_p_p_0.format_to_regex(str_0)
        assert (str_1 == '(?P<title>.+)\\ \-\\ (?P<artist>.+)')
        str_2 = '%(a)s'
        str_3 = metadata_from_title_p_p_0.format_to_regex(str_2)
        assert (str_3 == '(?P<a>.+)')
        str_

# Generated at 2022-06-26 13:45:13.861886
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'o'
    str_1 = '?H[p>|Fx'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_1)
    str_2 = 'rY`z}R!'
    str_3 = '?H[p>|Fx'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_2, str_3)
    set_0 = set()
    str_4 = '?H[p>|Fx'
    metadata_from_title_p_p_1 = MetadataFromTitlePP(set_0, str_4)


# Generated at 2022-06-26 13:45:21.286788
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    set_0 = set()
    str_0 = ' '
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_0)
    str_0 = 'will be long enough?'
    info_0 = {'title': str_0}
    metadata_from_title_p_p_1 = metadata_from_title_p_p_0.run(info_0)
    assert metadata_from_title_p_p_1 == ([], {}), 'Failed at test_MetadataFromTitlePP_run'

# Generated at 2022-06-26 13:45:23.660601
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_2 = MetadataFromTitlePP(object,dict)
    #assert metadata_from_title_p_p_2.run('s') is None
    assert True


# Generated at 2022-06-26 13:45:28.942577
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '<ng:VL/\\~&'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = dict()
    dict_0['title'] = '}vA'
    tuple_0 = (dict_0, dict_0)
    metadata_from_title_p_p_0.run(dict_0)
    # Empty method body
    return tuple_0


# Generated at 2022-06-26 13:45:34.293259
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    # Test calls
    set_0 = set()
    str_0 = '>qq6a"pq3v'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_0)
    dict_0 = dict()
    metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:45:42.856505
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    set_0 = set()
    str_0 = '<ng:VL/\\~&'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_0)
    dict_0 = dict()
    dict_0['title'] = 'nw^z'
    dict_0 = metadata_from_title_p_p_0.run(dict_0)
    # AssertionError: sets differ: {'title': 'nw^z'} != {}
    # assert dict_0 == {}

if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:45:54.540125
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    set_0 = set()
    str_0 = '<ng:VL/\\~&'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_0)
    dict_0 = dict()
    dict_0['title'] = 'AAPL'
    dict_0['?ext?'] = '.mp4'
    dict_0['format'] = '22'
    dict_0['alt_format'] = '22'
    dict_0['upload_date'] = '20141125'
    dict_0['uploader'] = 'CNN'
    list_0 = list()
    dict_0['id'] = 'AAPL'
    dict_0['display_id'] = 'AAPL'

# Generated at 2022-06-26 13:46:02.822120
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    set_0 = set()
    str_0 = '<ng:VL/\\~&'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_0)
    str_1 = '<ng:VL/\\~&'
    str_2 = '<ng:VL/\\~&'
    str_3 = '<ng:VL/\\~&'
    str_4 = '<ng:VL/\\~&'
    str_5 = '<ng:VL/\\~&'
    str_6 = '<ng:VL/\\~&'
    str_7 = '<ng:VL/\\~&'
    str_8 = '<ng:VL/\\~&'
    str_9 = '<ng:VL/\\~&'
    str_

# Generated at 2022-06-26 13:46:06.618462
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set(), '<ng:VL/\\~&')
    attr = metadata_from_title_p_p_0.run(dict())



# Generated at 2022-06-26 13:46:15.042850
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    num_0 = {'title': '<ng:VL/\\~&'}
    set_0 = set()
    str_0 = '<ng:VL/\\~&'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_0)
    # Call method on instance
    actual = [metadata_from_title_p_p_0.run(num_0)]
    expected = ([], {'title': '<ng:VL/\\~&'})
    assert actual.sort() == expected.sort()


# Generated at 2022-06-26 13:46:22.137186
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    set_0 = set()
    str_0 = '<ng:VL/\\~&'
    dict_0 = dict()
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_0)
    metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:46:25.605251
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    set_0 = set()
    str_0 = '<ng:VL/\\~&'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_0)
    metadata_from_title_p_p_0.run()



# Generated at 2022-06-26 13:46:35.690416
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    set_0 = set()
    str_0 = 'Xct XZf$2d'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_0)
    dict_0 = dict()
    dict_0['title'] = '*{Ch\'`L]%'
    dict_0['url'] = '<ng:VL/\\~&'
    str_1 = '<ng:VL/\\~&'
    dict_1 = dict()
    dict_1['url'] = '<ng:VL/\\~&'
    dict_1['title'] = '*{Ch\'`L]%'
    dict_2 = dict()
    dict_2['url'] = '<ng:VL/\\~&'

# Generated at 2022-06-26 13:46:41.413550
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import collections
    metadata_from_title_p_p_0 = MetadataFromTitlePP('hGWX', 'o`mU`')
    metadata_from_title_p_p_1 = MetadataFromTitlePP('jdv?', 'Lu/P')
    metadata_from_title_p_p_2 = MetadataFromTitlePP(metadata_from_title_p_p_0, 'Lu/P')
    metadata_from_title_p_p_0.run(metadata_from_title_p_p_1)
    str_0 = metadata_from_title_p_p_2
    assert (str_0 is not None)


# Generated at 2022-06-26 13:46:51.503440
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    set_0 = set()
    str_0 = '1X7H\x19Z\x7fqCS\x12z7!\x0f\x7f'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_0)
    dict_0 = {}
    str_1 = 'xyp@ts^^F/^'
    dict_0['title'] = str_1

# Generated at 2022-06-26 13:46:55.039161
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    p_dic_0 = {'title': 'Title'}
    metadata_from_title_p_p_0 = MetadataFromTitlePP('', '')
    metadata_from_title_p_p_0.format_to_regex = lambda x: 'Value'
    metadata_from_title_p_p_0.run(p_dic_0)


# Generated at 2022-06-26 13:46:58.310465
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    set_0 = set()
    str_0 = '<ng:VL/\\~&'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_0)

    assert_equals(metadata_from_title_p_p_0.run({'title':'jh2k6'}), ([], {'title':'jh2k6'}))

# Generated at 2022-06-26 13:47:08.492485
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    title_0 = 'A[b]c'
    str_0 = '%(title)s'
    str_1 = '(?P<title>.*)'
    map_0 = {'title': ''}
    set_0 = set()
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_0)
    metadata_from_title_p_p_0._titleregex = str_1
    metadata_from_title_p_p_0._titleformat = str_0
    metadata_from_title_p_p_0._formatter = {'title': None}
    info_0 = metadata_from_title_p_p_0.run(title_0)
    assert info_0 == (map_0, title_0)


# Generated at 2022-06-26 13:47:11.381613
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    set_0 = set()
    str_0 = 'k>2'
    metadata_from_title_p_p_0 = MetadataFromTitlePP.run(set_0, str_0)



# Generated at 2022-06-26 13:47:14.912144
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    set_0 = set()
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, 'Z')
    list_0 = []
    dict_0 = {'title': 'R'}
    dict_1 = {}
    list_1 = metadata_from_title_p_p_0.run((dict_1, dict_0))
    assert list_0 == list_1
    assert dict_1 == {}
    assert dict_0 == {'title': 'R'}


# Generated at 2022-06-26 13:47:27.797360
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-26 13:47:34.457359
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    set_0 = set()
    str_0 = '    *1O&"U[Q'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_0)
    str_1 = 'mhoF>|Y?A'
    dict_0 = {str_1: 'qzD:|;n4'}
    list_0 = []
    dict_0 = metadata_from_title_p_p_0.run(dict_0)
    assert dict_0 == (list_0, dict_0)


# Generated at 2022-06-26 13:47:36.543325
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Preparation
    str_0 = '<ng:VL/\\~&'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, str_0)

    # Invocation
    metadata_from_title_p_p_0.run(str_0)

    # Assertions


# Case 0
test_case_0()

# Generated at 2022-06-26 13:47:44.318925
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    set_0 = set()
    str_0 = '<ng:VL/\\~&'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_0)
    list_0 = []
    dict_0 = {}
    tuple_0 = (list_0, dict_0)
    tuple_1 = metadata_from_title_p_p_0.run(tuple_0)
    assert isinstance(tuple_1, tuple)
    assert len(tuple_1) == 2
    assert isinstance(tuple_1[0], list)
    assert len(tuple_1[0]) == 0
    assert isinstance(tuple_1[1], dict)
    assert len(tuple_1[1]) == 0


# Generated at 2022-06-26 13:47:47.507670
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set(), '<ng:VL/\\~&')
    metadata_from_title_p_p_0.run({})

# Generated at 2022-06-26 13:47:52.797609
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    c_0 = {}
    metadata_from_title_p_p_0 = MetadataFromTitlePP(c_0, '%(title)s')
    (set_0, c_1) = metadata_from_title_p_p_0.run(c_0)


if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:47:57.303392
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    set_0 = set()
    str_0 = '<ng:VL/\\~&'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_0)

    # Assert
    assert (dict_0 == metadata_from_title_p_p_0.run())

# Generated at 2022-06-26 13:48:04.829168
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    set_0 = set()
    str_0 = '<ng:VL/\\~&'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_0)

    dict_0 = {}
    str_0 = '<ng:VL/\\~&'
    dict_0['title'] = str_0
    list_0 = []
    list_1, str_1 = metadata_from_title_p_p_0.run(dict_0)
    assert(len(list_0) == len(list_1))
    assert(str_0 == str_1['title'])
    assert(str_0 == str_1['title'])

# Generated at 2022-06-26 13:48:09.714969
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    set_0 = set()
    str_0 = 'D`*o'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_0)
    dict_0 = {}
    metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:48:20.557855
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'l)\\pyc%'

    # Test case with a long string
    set_0 = set()
    str_1 = 'nYd.1'

    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_1)
    str_2 = 'J"N\u0003)3N_*?X\x0fRc'
    str_3 = '*!\x0c;'
    str_4 = '\\X'
    str_5 = 'R'
    str_6 = '^{*AQ'
    str_7 = 'Z"*'
    str_8 = '#\n4'
    str_9 = 'Ef-L'
    str_10 = 'vI'

# Generated at 2022-06-26 13:48:26.653435
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert True

# Generated at 2022-06-26 13:48:35.575107
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    set_0 = set()
    str_0 = 'B\'TfT#D'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_0)
    str_1 = 'hc%PV]C'
    set_1 = set()
    info_0 = {'title': '5W8'}
    set_1.add(str_1)
    info_1 = {'title': '5W8'}
    output_0 = metadata_from_title_p_p_0.run(info_0)
    #assert set_0 == output_0[0]
    assert info_1 == output_0[1]


# Generated at 2022-06-26 13:48:40.137468
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    print('---- test_run ----')
    str_0 = '<ng:VL/\\~&'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_1.run({'title': 'Title'})


# Generated at 2022-06-26 13:48:43.215145
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Input arguments
    info_0 = 'FAIL'

    # No output

    # Function call
    metadata_from_title_p_p_0 = MetadataFromTitlePP(info_0)
    metadata_from_title_p_p_0.run()


test_case_0()

# Generated at 2022-06-26 13:48:48.053132
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    set_0 = set()
    str_0 = '<ng:VL/\\~&'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_0)
    info = {}
    title = metadata_from_title_p_p_0.run(info)


try:
    import unittest2 as unittest
except ImportError:
    import unittest
if __name__ == "__main__":
    unittest.main()

# Generated at 2022-06-26 13:48:53.296952
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    dict_0 = dict()
    dict_1 = dict()
    str_0 = '.'
    dict_0['title'] = str_0
    dict_1['title'] = '"<ng:VL/\\~&'
    list_0 = list()
    MetadataFromTitlePP.run(dict_1, dict_0) == (list_0, dict_0)
    dict_0['title'] = str_0
    dict_1['title'] = '."'
    MetadataFromTitlePP.run(dict_1, dict_0) == (list_0, dict_0)
    dict_1['title'] = '"<ng:VL/\\~&'
    dict_0['title'] = '."'

# Generated at 2022-06-26 13:48:59.067171
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    set_0 = set()
    str_0 = '<ng:VL/\\~&'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_0)
    dict_0 = {'a': 'b', 'c': 'd', 'e': 'f'}
    list_0, dict_1 = metadata_from_title_p_p_0.run(dict_0)
    assert dict_0.get('e') == dict_1.get('e')


# Generated at 2022-06-26 13:49:05.669674
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'abc'
    dict_0 = {}
    dict_0['title'] = str_0
    set_0 = set()
    str_1 = 'abc'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_1)
    str_2 = 'abc'
    str_3 = 'abc'
    list_0, dict_1 = metadata_from_title_p_p_0.run(dict_0)
    assert dict_1['title'] == str_2
    assert dict_1['0'] == str_3
    assert list_0 == []

# Generated at 2022-06-26 13:49:06.150387
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert True



# Generated at 2022-06-26 13:49:09.600753
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    set_0 = set()
    str_0 = 'utethxkx'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_0)
    metadata_from_title_p_p_0.run(str_0)

# Generated at 2022-06-26 13:49:29.713017
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    set_0 = set()
    str_0 = 'S(?'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_0)
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_0)
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_0)
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_0)
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_0)
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_0)

# Generated at 2022-06-26 13:49:38.861259
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    info = {
        'title': 'Test title',
        'artist': 'Test artist',
        'albumartist': 'Test albumartist',
        'album': 'Test album',
        'track': 'Test track',
        'disc': 'Test disc',
        'date': 'Test date',
        'genre': 'Test genre',
        'format': 'Test format',
    }
    mp3_formats = ['mp3', 'aac']

    # Test format with all attributes
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, '%(artist)s - %(album)s - %(title)s%(ext)s')
    info_0, _ = metadata_from_title_p_p_0.run(info)
    assert len(info_0) == 0

    # Test

# Generated at 2022-06-26 13:49:47.392137
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    dict_0 = dict()
    dict_0['title'] = 'VDleCgQ2YBA'
    dict_0['description'] = '&lACiwJpgc'
    dict_0['tags'] = 'pwYbV;W!hC&'
    dict_0['uploader'] = 'x*h(=i&eKe#'
    dict_0['uploader_id'] = '?Hv$7A'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(dict_0, 'HVOvOISrf=Cx')
    try:
        assert metadata_from_title_p_p_0.run(dict_0) == [[], dict_0]
    except AssertionError:
        raise



# Generated at 2022-06-26 13:49:51.257666
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP({}, None)
    set_0 = set()
    dict_0 = dict()
    metadata_from_title_p_p_0.run(dict_0)

# Generated at 2022-06-26 13:50:02.055626
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    set_0 = set()
    str_0 = '<ng:VL/\\~&'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_0)
    info = {}
    info['title'] = '%(foo)s'
    l_0 = []
    l_1 = []
    l_1.append(info)
    l_2 = []
    l_2.append(l_0)
    l_2.append(l_1)
    info = metadata_from_title_p_p_0.run(info)
    assert l_2 == info

if __name__ == '__main__':
    test_case_0()

    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:50:09.951695
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '9gag.com'
    set_0 = set()
    str_1 = '%(title)s.%(ext)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_1)

# Generated at 2022-06-26 13:50:15.131369
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    set_0 = set()
    str_0 = ':&A]\\-E;'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_0)
    str_1 = '%(title)s - %(artist)s'
    assert metadata_from_title_p_p_0._titleformat == str_1


# Generated at 2022-06-26 13:50:19.769489
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Setup
    dict_0 = dict()
    dict_0['title'] = '%(artist)s - %(title)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(dict_0, dict_0)

    # Invocation
    # Testing exception
    try:
        metadata_from_title_p_p_0.run(dict_0)
    # Expected exception
    except:
        pass
    else:
        assert True, 'Expected Exception'

# Generated at 2022-06-26 13:50:25.131707
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set(),'')
    set_0 = set()
    str_0 = '<ng:VL/\\~&'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_0)
    map_0 = map()

    metadata_from_title_p_p_0.run(map_0)


# Generated at 2022-06-26 13:50:33.984860
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    _author = 'am'
    _title = 'ar'
    _description = 'as'
    _categories = 'at'
    _license = 'au'

    _video_url = 'av'
    _video_id = 'aw'
    _video_title = _author + '-' + _title

    _tbr = 'ax'
    _abr = 'ay'
    _vbr = 'az'

    _ext = 'ba'
    _format_id = 'bb'
    _filesize = 'bc'
    _format = 'bd'

    _webpage_url = 'be'
    _webpage_url_basename = 'bf'

    _thumbnail = 'bg'
    _thumbnail_id = 'bh'

    _uploader = 'bi'

# Generated at 2022-06-26 13:51:16.084343
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass


# Generated at 2022-06-26 13:51:22.347982
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # set_0 is used to store the information of a video
    set_0 = set()
    str_0 = '<ng:VL/\\~&'
    # Creates a MetadataFromTitlePP object
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_0)
    # Creates a dictionary
    set_1 = {'title': '<ng:VL/\\~&', 'url': '<ng:VL/\\~&'}
    # Runs the run method
    metadata_from_title_p_p_0.run(set_1)


# Generated at 2022-06-26 13:51:24.190377
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert callable(MetadataFromTitlePP.run), \
           "Method `run` of class MetadataFromTitlePP is not callable"


# Generated at 2022-06-26 13:51:29.300058
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Testcase 1 (str_0)
    set_0 = set()
    str_0 = '>K/?|'
    dict_0 = {}
    dict_0['title'] = '=V?x3'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_0)
    [list_0, dict_0] = metadata_from_title_p_p_0.run(dict_0)

    # Testcase 2 (str_0)
    set_0 = set()
    str_0 = 'f^8Y'
    dict_0 = {}
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_0)
    [list_0, dict_0] = metadata_from_title_p_p_

# Generated at 2022-06-26 13:51:29.964672
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert 1 == 0

# Generated at 2022-06-26 13:51:37.807461
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-26 13:51:43.923777
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    set_0 = set()
    str_0 = '<ng:VL/\\~&'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_0)
    dict_0 = {'title': '"m\\>\\*#@\":Z:5U'}
    result = metadata_from_title_p_p_0.run(dict_0)
    assert result[0] == []


# Generated at 2022-06-26 13:51:52.866137
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    int_0 = 35

# Generated at 2022-06-26 13:51:57.154549
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    arg0 = {'title': 'test'}
    metadata_from_title_p_p_0 = MetadataFromTitlePP('', '%(title)s - %(artist)s')

    try:
        metadata_from_title_p_p_0.run(arg0);
    except Exception as err:
        print(err)
        

# Generated at 2022-06-26 13:52:03.319808
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    downloaded_information_0 = {
        'title': 'hello',
        '_duration_hms': 'hello',
        '_duration_ts': 'hello',
        'thumbnail': 'hello',
        'url': 'hello',
        'webpage_url': 'hello',
        'ext': 'hello',
        'format': 'hello',
        'player_url': 'hello',
        'uploader': 'hello',
        'upload_date': 'hello',
        'description': 'hello',
        'uploader_url': 'hello',
        'location': 'hello',
        'categories': 'hello',
        'tags': 'hello',
        'subtitles': 'hello',
        'automatic_captions': 'hello'
    }
    metadata_from_title_p_p_0 = MetadataFromTitlePP

# Generated at 2022-06-26 13:52:53.614548
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, '')
    metadata_from_title_p_p_0.run(None)


# Generated at 2022-06-26 13:53:00.922924
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # pass
    set_0 = set()
    str_0 = '<ng:VL/\\~&'
    int_0 = 6
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_0)
    info = {'title': '', 'height': int_0}
    metadata_from_title_p_p_0.run(info)


if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:53:02.037411
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 13:53:06.934265
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    set_0 = set()
    str_0 = '<ng:VL/\\~&'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_0)
    list_0 = []
    dict_0 = dict()
    dict_0['title'] = '5.5+5.5'
    list_1, dict_1 = metadata_from_title_p_p_0.run(dict_0)
    assert(list_0 == list_1)
    assert(dict_0 == dict_1)


# Generated at 2022-06-26 13:53:13.751993
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    set_0 = set()
    str_0 = '<ng:VL/\\~&'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_0)

# Generated at 2022-06-26 13:53:21.381931
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-26 13:53:29.915537
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    set_0 = set()
    str_0 = '<ng:VL/\\~&'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_0)
    info_0 = {}
    info_1 = {}

# Generated at 2022-06-26 13:53:33.373338
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    set_0 = set()
    str_0 = '<ng:VL/\\~&'
    str_1 = '<ng:VL/\\~&'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(set_0, str_0)
    metadata_from_title_p_p_0._titleformat = str_1


# Generated at 2022-06-26 13:53:39.724356
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'optimal'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = 'k3>^f'
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_0, str_1)
    assert_equals(metadata_from_title_p_p_0.run(str_1), (None, None))
    assert_equals(metadata_from_title_p_p_1.run(str_0), (None, None))


# Generated at 2022-06-26 13:53:41.435544
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass


if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()