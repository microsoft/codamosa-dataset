

# Generated at 2022-06-26 13:44:02.033494
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    str_0 = 'sGv+8W/jM(ZT'
    str_1 = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_1)
    str_2 = '%(title)s - %(artist)s'
    regex_0 = metadata_from_title_p_p_0.format_to_regex(str_2)
    assert regex_0 == str_1


# Generated at 2022-06-26 13:44:05.298505
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    post_processor = Test_MetadataFromTitlePP.metadata_from_title_p_p_0
    info = {'title': Test_MetadataFromTitlePP.str_0}
    result = post_processor.run(info)


# Generated at 2022-06-26 13:44:13.117319
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    str_1 = '%(title)s - %(artist)s'
    list_1 = []
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_1, list_1)

    assert metadata_from_title_p_p_1._titleformat == str_1
    assert metadata_from_title_p_p_1._titleregex == '%(title)s - %(artist)s'

    str_2 = '%(title)s - %(artist)s - %(album)s'
    list_2 = []
    metadata_from_title_p_p_2 = MetadataFromTitlePP(str_2, list_2)

    assert metadata_from_title_p_p_2._titleformat == str_2
    assert metadata_from_title_p_p

# Generated at 2022-06-26 13:44:18.569010
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'JCGceem]bzI\t}{+9Y'
    list_0 = []
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, list_0)
    metadata_from_title_p_p_0.run(list_0)

# Generated at 2022-06-26 13:44:31.649898
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class_variable_0 = MetadataFromTitlePP()
    class_variable_1 = None
    str_0 = 'P8b'
    class_variable_2 = {
        'title': str_0,
        'thumbnail': '3q}G',
        'duration': 'w)',
        'webpage_url_basename': 'FcI'
    }
    str_1 = 'b\.%\(\w+\)sI'
    tuple_0 = ()
    tuple_1 = (str_1, )
    tuple_2 = ()
    tuple_3 = (class_variable_2, )
    tuple_4 = (tuple_0, tuple_1, tuple_2, tuple_3)
    class_variable_3 = tuple_4
    class_variable_4 = class_variable_0.run

# Generated at 2022-06-26 13:44:39.326008
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test for testing empty string
    str_0 = ""
    list_0 = []
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, list_0)
    metadata_from_title_p_p_0.run(metadata_from_title_p_p_0)
    # Test for testing null string
    str_0 = None
    list_0 = []
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, list_0)
    metadata_from_title_p_p_0.run(metadata_from_title_p_p_0)
    # Test for testing null string
    str_1 = None
    list_0 = []

# Generated at 2022-06-26 13:44:40.239753
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()


# Generated at 2022-06-26 13:44:41.133773
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # TODO TEST ME
    pass


# Generated at 2022-06-26 13:44:49.775718
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Initializes the variables
    str_0 = 'JCGceem]bzI\t}{+9Y'
    list_0 = []
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, list_0)
    list_1 = []
    str_1 = 'z}'
    int_0 = 100
    int_1 = 6
    str_2 = '%(title)s'
    # Executes the code
    tuple_0 = metadata_from_title_p_p_0.run(list_1)
    # Test if the result is correct
    assert tuple_0[0] == list_1
    assert tuple_0[1] == list_1


# Generated at 2022-06-26 13:44:54.922439
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = ''
    list_0 = []
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, list_0)
    info_0 = []
    list_0 = metadata_from_title_p_p_0.run(info_0)



# Generated at 2022-06-26 13:45:07.152635
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    title_0 = 'P4G3q4o'
    f_0 = {}
    f_0['title'] = title_0
    titleformat_0 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(titleformat_0, titleformat_0)
    titleformat_0 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(titleformat_0, titleformat_0)
    titleformat_0 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(titleformat_0, titleformat_0)

# Generated at 2022-06-26 13:45:17.275814
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'C00G-\n5r\x0c'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_0 = 'C00G-\n5r\x0c'
    dict_0 = dict()
    list_0 = ['C00G-\n5r\x0c']
    dict_0['title'] = str_0
    assert metadata_from_title_p_p_0.run((dict_0, list_0)) == ((), dict_0)
    str_1 = 'C00G-\n5r\x0c'
    dict_0['title'] = str_1

# Generated at 2022-06-26 13:45:21.163215
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    fmt = '%(title)s - %(artist)s'
    titleformat = '%(title)s - %(artist)s'


if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:45:23.239233
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP('', '')
    assert metadata_from_title_p_p_0.run('') == ([], '')

# Generated at 2022-06-26 13:45:29.900198
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'C00G-\n5r\x0c'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)

    str_0 = 'C00G-\n5r\x0c'
    dict_0 = {'title': str_0}
    dict_1 = metadata_from_title_p_p_0.run(dict_0)
    assert type(dict_1) is tuple, 'Return value should be of type "tuple".'
    assert len(dict_1) == 2, 'Return value should contain two items.'



# Generated at 2022-06-26 13:45:36.472473
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(re.escape, re.escape)
    str_0 = '7VuJ\n\x00\nU6G,\n\x00\x00N6\x0c\n\x00'
    str_1 = 'U'
    str_2 = '\x00\x00\x00'
    str_3 = '\x0c'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_1, str_0)
    assert metadata_from_title_p_p_0.format_to_regex(str_1) == '\\x00'

# Generated at 2022-06-26 13:45:47.493252
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-26 13:45:58.080860
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'C00G-\n5r\x0c'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    info_0 = {'title': 'C00G-\n5r\x0c'}
    str_1 = 'C00G-\n5r\x0c'
    str_2 = 'C00G-\n5r\x0c'
    str_3 = str_0
    str_4 = str_2
    str_5 = 'C00G-\n5r\x0c'
    str_6 = 'C00G-\n5r\x0c'
    str_7 = str_0
    str_8 = str_6

# Generated at 2022-06-26 13:46:00.690677
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    fmt = '%(title)s - %(artist)s'
    p = MetadataFromTitlePP(fmt, fmt)
    p.run({})

test_case_0()
test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:46:07.200913
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'C00G-\n5r\x0c'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = 'C00G-\n5r\x0c'
    dict_0 = {str_1:str_1}
    list_0 = []
    dict_1 = metadata_from_title_p_p_0.run(dict_0)

    assert len(list_0) == len(dict_1)


# Generated at 2022-06-26 13:46:17.075387
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'UG#'
    str_1 = '\x0c\x0b0y\x07\x07\x0c'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.format_to_regex(str_1)
    str_2 = '\x0c\x07\x0f\t\x0b\r\t\r'
    metadata_from_title_p_p_0.format_to_regex(str_2)

# Generated at 2022-06-26 13:46:25.827199
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'C00G-\n5r\x0c'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = 'C00G-\n5r\x0c'
    str_2 = '\n'
    str_3 = '\x0c'
    str_4 = 'C'
    str_5 = 'G-'
    dict_0 = {'artist': str_4, 'title': str_5}
    dict_1 = {'artist': None, 'title': None}
    list_arg_0 = [None]
    dict_2 = {'title': dict_0}
    dict_3 = {'title': dict_1}
    (list_ret_0, dict_ret_0)

# Generated at 2022-06-26 13:46:35.980905
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    title_0 = '\u0b1c\u0b05\u0b28\u0b4d\u0b5c\u0b3f\u0b15\u0b40 \u0b28\u0b3f\u0b30\u0b3e\u0b1c \u0b2a\u0b3e\u0b32\u0b32\u0b3f\u0b07 - Bangla New Natok - Full HD - Ft.Tahsan&Tisha'
    info_0 = {
        'creator': 'NA',
        'title': title_0,
        'series': 'NA',
        'description': 'NA',
        'season': 'NA',
        'episode': 'NA',
    }
    metadata_from_title_p_

# Generated at 2022-06-26 13:46:40.773849
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    format_to_regex_0 = '%(title)s-%(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(format_to_regex_0, format_to_regex_0)
    result_0 = metadata_from_title_p_p_0.run(format_to_regex_0)
    assert result_0 == metadata_from_title_p_p_0.format_to_regex(result_0)

# Test case for class MetadataFromTitlePP

# Generated at 2022-06-26 13:46:46.934667
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # print('Test run 1')
    str_0 = 'C00G-\n5r\x0c'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)

    str_0 = 'C00G-\n5r\x0c'
    metadata_from_title_p_p_0.run(str_0)


# Generated at 2022-06-26 13:46:49.220909
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str, str)
    metadata_from_title_p_p_0.run(str)


# Generated at 2022-06-26 13:46:54.777676
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'C00G-\n5r\x0c'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    # Test raise?
    # assert_raises(Exception, metadata_from_title_p_p_0.run, (str_0,))
    metadata_from_title_p_p_0.run(str_0)

if __name__ == '__main__':
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:46:55.477518
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass


# Generated at 2022-06-26 13:46:56.652850
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # === assertions ===
    # ---
    assert 1 == 1 # dummy assertion to avoid no tests error



# Generated at 2022-06-26 13:47:02.025505
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'C00G-\n5r\x0c'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    list_0 = []

# Generated at 2022-06-26 13:47:12.523296
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'C00G-\n5r\x0c'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0._titleregex = 'C00G-\n5r\x0c'
    dict_0 = dict()
    dict_0['title'] = 'C00G-\n5r\x0c'
    m_list_0, dict1 = metadata_from_title_p_p_0.run(dict_0)
    assert m_list_0 == []


# Generated at 2022-06-26 13:47:15.913775
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    var_1 = lambda arg_0: arg_0.__setitem__(str(0), None)
    var_1()
    str_0 = 'Aq?\x11>%\x9e\x84\x91\xc6\x1cDf[\xa0\x07\x1e\x93"\x15\xd8'
    int_0 = 0
    while True:
        int_0 += 1
        if not int_0 <= 0: break

test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:47:17.640972
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # TODO: Setup test data

    # Call method
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str, str)
    metadata_from_title_p_p_0.run(str)

    # Verification



# Generated at 2022-06-26 13:47:24.739686
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    metadata_from_title_p_p = MetadataFromTitlePP(str, str)

    resulta = metadata_from_title_p_p.run('!_z|>!q')

    assert resulta[1] == '!_z|>!q'

    metadata_from_title_p_p_0 = MetadataFromTitlePP('=r~o', '=r~o')

    resultb = metadata_from_title_p_p_0.run('a@$t')

    assert resultb[1] == 'a@$t'


# Generated at 2022-06-26 13:47:28.922454
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    title = u'%(title)s'
    info = {u'title': u'%(title)s'}
    metadata_from_title_p_p_0 = MetadataFromTitlePP(title, title)
    metadata_from_title_p_p_0.run(info)


# Generated at 2022-06-26 13:47:31.260589
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    post_processor_0 = MetadataFromTitlePP(str_0, str_0)
    post_processor_0.run(list_0)


# Generated at 2022-06-26 13:47:36.557996
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test case 0 - multiple regex on the same string
    metadata_from_title_p_p_0 = MetadataFromTitlePP('%(title)s - %(artist)s', '%(title)s - %(artist)s')
    str_0 = "MetadataFromTitlePP.run('TESTTESTTEST')"
    metadata_from_title_p_p_0.run(str_0)


# Generated at 2022-06-26 13:47:38.584470
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'z'
    assert MetadataFromTitlePP(str_0, str_0).run(str_0) == ([], str_0)


# Generated at 2022-06-26 13:47:47.184214
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_1 = 'Xp'
    str_2 = 'un1j_!1>\t2\x00\x00\x00\xc9\n'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_1, str_2)
    dict_1 = {'title': str_1, 'ext': str_2, 'id': str_2, 'display_id': str_1}
    list_0 = []
    metadata_from_title_p_p_0.run(dict_1)
    dict_2 = dict_1
    dict_2['title'] = str_2
    dict_2[str_1] = str_1
    dict_2[str_2] = str_2
    dict_2['id'] = str_2
    dict_2

# Generated at 2022-06-26 13:47:57.469707
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '\n\x07\x02\t\x0f\n\x07\x02\x0b6\x19'

# Generated at 2022-06-26 13:48:06.641382
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    attr = [ 'title', 'id' ]
    metadata_from_title_p_p_0 = MetadataFromTitlePP(
        '', '%(id)s')
    metadata_from_title_p_p_0._titleregex = '%(id)s'
    metadata_from_title_p_p_0._downloader = 'ytdl-downloader'
    metadata_from_title_p_p_0._titleformat = '%(id)s'
    obj_0 = {'id': (''), 'title':('video_id')}
    metadata_from_title_p_p_0.run(obj_0)
    assert not [ attr[i] for i in range(0, len(attr)) if obj_0[attr[i]] != '' ]

# vim: tabstop

# Generated at 2022-06-26 13:48:15.433463
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'C00G-\n5r\x0c'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)

    d_0 = {'title': 'C00G-\n5r\x0c'}

    list_0 = []

    tuple_0 = metadata_from_title_p_p_0.run(d_0)

    assert tuple_0 == (list_0, d_0)

# Test method format_to_regex

# Generated at 2022-06-26 13:48:22.406012
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Input variables initialization
    str_0 = 'C00G-\n5r\x0c'
    str_1 = 'y\'h|'
    str_2 = '9'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_1)
    str_3 = '0.4+'
    str_4 = '0]0'
    str_5 = 'q'
    str_6 = 'T'
    # Call the method run of class MetadataFromTitlePP
    metadata_from_title_p_p_0.run(str_3)


# Generated at 2022-06-26 13:48:28.130274
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'Fo5AG5A\x0c/\x0c"\x0c'
    dict_0 = {}
    dict_0['title'] = str_0
    return_value_0 = [None, dict_0]
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    assert return_value_0 is metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:48:34.407515
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'C00G-\n5r\x0c'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = dict()
    list_0 = list()
    dict_0['title'] = 'C00G-\n5r\x0c'
    list_0.append(dict_0)
    metadata_from_title_p_p_0.run(list_0)

# Generated at 2022-06-26 13:48:42.573630
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.run({'title': '', 'artist': ''})
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.run({'title': str_0, 'artist': str_0})
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.run({'title': '', 'artist': ''})
    metadata_from_title_p_p_0.run

# Generated at 2022-06-26 13:48:49.627071
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '/tmp/'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = ''

# Generated at 2022-06-26 13:48:57.190090
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'C00G-\n5r\x0c'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = 'C00G-\n5r\x0c'
    str_2 = 'C00G-\n5r\x0c'
    dict_3 = {str_1: str_2}
    str_4 = 'C00G-\n5r\x0c'
    str_5 = ''
    tuple_0 = (str_4, str_5)
    metadata_from_title_p_p_0.run(dict_3)
    assert tuple_0 == (str_4, str_5)


# Generated at 2022-06-26 13:49:01.777314
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Simple test
    str_0 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = {}
    dict_0['title'] = 'Title'
    dict_0['artist'] = 'Artist'
    metadata_from_title_p_p_0.run(dict_0)

# Generated at 2022-06-26 13:49:07.847446
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'C00G-\n5r\x0c'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = dict()
    dict_0['title'] = 'C00G-\n5r\x0c'
    dict_0 = metadata_from_title_p_p_0.run(dict_0)
    assert (dict_0 == 0)

if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:49:18.758046
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP('C00G-\n5r\x0c')
    str_0 = 'C00G-\n5r\x0c'
    dict_0 = {'title': str_0}
    dict_1 = {}
    assert metadata_from_title_p_p_0.run(dict_0, dict_1) == ([], dict_0)

# Generated at 2022-06-26 13:49:25.470561
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test the case where the title does not match the format
    str_0 = 'C00G-\n5r\x0c'
    assert_equal(MetadataFromTitlePP(str_0, str_0)
                 .run('foobar'), ([], 'foobar'))

    # Test the case where the title matches the format
    str_0 = 'C00G-\n5r\x0c'
    assert_equal(MetadataFromTitlePP(str_0, str_0)
                 .run('foo - bar'), ([], {'title': 'foo', 'artist': 'bar'}))


# Generated at 2022-06-26 13:49:32.029773
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '-%(id)s'
    dict_0 = {}
    dict_0['id'] = str_0
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    list_0 = []
    dict_1 = {}
    dict_1['title'] = str_0
    metadata_from_title_p_p_0.run(dict_1)

test_case_0()
test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:49:40.324630
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test cases
    # '%(title)s - %(artist)s'
    # '%(title)s - %(artist)s'
    # '%(title)s - %(artist)s'
    # '%(title)s - %(artist)s'
    # '%(title)s-%(artist)s'
    # '%(title)s-%(artist)s'
    # '%(title)s - %(artist)s'
    # '%(title)s - %(artist)s'
    # '%(title)s - %(artist)s'
    # '%(title)s - %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP('', '')
    metadata_from_title_p_p_

# Generated at 2022-06-26 13:49:41.184277
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()

# Generated at 2022-06-26 13:49:45.325322
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'C00G-\n5r\x0c'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.format_to_regex(str_0)


# Generated at 2022-06-26 13:49:55.585375
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_1 = 'C00G-\n5r\x0c'
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_1, str_1)
    str_2 = 'Mg-9iGo5H5A'
    str_3 = 'http://www.youtube.com/watch?v=Mg-9iGo5H5A'
    str_4 = 'w'
    str_5 = 'B\xc5\x9f\x9c\n\x03j'
    str_6 = 'Digital\x0bE\xc1\x98\x0b\x1a\x07\x0c'

# Generated at 2022-06-26 13:49:58.849558
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    info_0 = {}
    metadata_from_title_p_p_0.run(info_0);


# Generated at 2022-06-26 13:50:08.439404
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-26 13:50:16.276346
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    input_0 = []
    output_0 = []
    str_0 = 'C00G-\n5r\x0c'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    output_0 = metadata_from_title_p_p_0.run(input_0)
    return output_0


if __name__ == '__main__':
    import sys
    import io
    # Redirect stdout to make sure that no extra
    # output is produced
    sys.stdout = io.StringIO()
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:50:34.837243
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'C00G-\n5r\x0c'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = 'JcYuY\t|l4?\x01'
    str_2 = '\x1c|\n`\x1a@R'
    dict_0 = dict()
    dict_0['title'] = str_1
    dict_0['id'] = str_2
    tuple_0 = metadata_from_title_p_p_0.run(dict_0)
    assert len(tuple_0) == 2
    assert tuple_0[0] == ()
    assert tuple_0[1]['title'] == str_1
    assert tuple_0[1]['id'] == str

# Generated at 2022-06-26 13:50:36.380594
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP("", "")
    pass

# Generated at 2022-06-26 13:50:41.506054
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '\x9a\xa2\x05\xec\xaa\x0c\x93'
    str_1 = '\x9a\xa2\x05\xec\xaa\x0c\x93'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_1)
    dict_0 = {}
    dict_0['title'] = '\x9a\xa2\x05\xec\xaa\x0c\x93'
    dict_0['parameter_1'] = '\x9a\xa2\x05\xec\xaa\x0c\x93'
    dict_1 = {}

# Generated at 2022-06-26 13:50:51.295844
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'C00G-\n5r\x0c'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.metadata_from_title_p_p_0 = metadata_from_title_p_p_0
    str_0 = 'C00G-\n5r\x0c'
    str_1 = 'C00G-\n5r\x0c'
    str_2 = 'C00G-\n5r\x0c'
    str_3 = 'C00G-\n5r\x0c'
    list_0 = []
    #str_4 = metadata_from_title_p_p_0.format_to_regex(str_

# Generated at 2022-06-26 13:50:59.467868
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    case_0 = 'C00G-\n5r\x0c'
    str_0 = 'C00G-\n5r\x0c'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = 'C00G-\n5r\x0c'
    str_2 = 'C00G-\n5r\x0c'
    str_3 = 'C00G-\n5r\x0c'
    str_4 = 'C00G-\n5r\x0c'
    str_5 = 'C00G-\n5r\x0c'
    info_0 = {str_1: str_2, str_3: str_4, str_5: case_0}


# Generated at 2022-06-26 13:51:06.690304
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .YoutubeDL import YoutubeDL
    from .PostProcessor import PostProcessor
    from .YoutubeIE import YoutubeIE
    from .extractor import gen_extractors
    from .subtitles import SubtitlesPP
    from .youtube import YoutubeSubtitlesInfoExtractor

    # Setup downloader and options
    ydl_opts = {'format': 'best[height<=480]'}
    ydl = YoutubeDL(ydl_opts)
    dl = FileDownloader(ydl)

    # Setup test case

# Generated at 2022-06-26 13:51:11.911135
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '(?P<title>.*)\ \-\ (?P<artist>.*)'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = "'_'<\x1d\xe3#\x1aB;-\x08"
    dict_0 = dict()
    dict_0['title'] = str_1
    metadata_from_title_p_p_0.run(dict_0)
# Test for class MetadataFromTitlePP

# Generated at 2022-06-26 13:51:16.885080
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'C00G-\n5r\x0c'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = 'C00G-\n5r\x0c'
    dict_0 = {'metadata_from_titlepp_run': str_1}
    metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:51:18.092828
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert MetadataFromTitlePP.run('g') == ([], 'g')


# Generated at 2022-06-26 13:51:19.317774
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 13:51:54.053305
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    title = 'UNIT TEST - title'
    info = {'title': title}
    metadata_from_title_p_p = MetadataFromTitlePP(None, '%(title)s')
    metadata_from_title_p_p.run(info)
    assert info[u'title'] == title

    metadata_from_title_p_p = MetadataFromTitlePP(None, '%(nonexistent)s')
    metadata_from_title_p_p.run(info)
    assert u'nonexistent' not in info

    metadata_from_title_p_p = MetadataFromTitlePP(None, '%(title)s - UNIT TEST')
    metadata_from_title_p_p.run(info)
    assert info[u'title'] == title

# Generated at 2022-06-26 13:51:56.706063
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'C00G-\n5r\x0c'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.run(list())


# Generated at 2022-06-26 13:51:57.587914
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert not MetadataFromTitlePP.run(None, None)

# Generated at 2022-06-26 13:51:58.679757
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert callable(MetadataFromTitlePP.run)


# Generated at 2022-06-26 13:52:03.230313
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    arg_0 = {}
    # arg_0[0] = unkown value
    # arg_0[0] = unkown value
    metadata_from_title_p_p_0 = MetadataFromTitlePP(arg_0, arg_0)
    arg_0[0] = None
    arg_1 = arg_0[0]
    arg_2 = arg_0[0]
    arg_3 = arg_0[0]
    arg_4 = metadata_from_title_p_p_0.run(arg_1, arg_2, arg_3)
    

# Generated at 2022-06-26 13:52:10.777253
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_p_0 = '%(title)s - %(artist)s'
    str_p_1 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_p_0 = MetadataFromTitlePP(str_p_0, str_p_1)
    str_p_2 = 'Still Alive - Portal'
    dict_p_0 = {'title':str_p_2}
    dict_p_1, dict_p_2 = metadata_from_title_p_p_p_0.run(dict_p_0)
    assert (dict_p_1 == [] and dict_p_2['title'] == 'Still Alive'
            and dict_p_2['artist'] == 'Portal')


# Generated at 2022-06-26 13:52:18.924809
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = ':G'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = 'p\x08\x13\x05\nX\n'
    dict_0 = {'title': str_1, 'a': str_1, 'b': str_1, 'c': str_1, 'extractor': str_1}
    list_0 = []
    list_1 = []
    list_2 = []
    list_2.append(str_1)
    list_2.append(str_1)
    list_3 = []
    list_3.append(str_1)
    list_3.append(str_1)
    list_3.append(str_1)

# Generated at 2022-06-26 13:52:19.385779
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass

# Generated at 2022-06-26 13:52:22.948412
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Arrange
    str_0 = 'C00G-\n5r\x0c'
    str_1 = 'C00G-\n5r\x0c'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_1)

    # Act
    metadata_from_title_p_p_0.run('C00G-\n5r\x0c')


# Generated at 2022-06-26 13:52:30.897815
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = './%(title)s.%(ext)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_0 = 'C00G-\n5r\x0c'
    str_1 = 'C00G-\n5r\x0c'
    dictionary_0 = {}
    dictionary_0['title'] = str_0
    dictionary_0['ext'] = str_1
    dictionary_0['artist'] = str_0
    dictionary_0['album'] = str_0
    expected_1 = []
    expected_2 = dictionary_0
    actual_1, actual_2 = metadata_from_title_p_p_0.run(dictionary_0)
    assert expected_1 == actual_1
   

# Generated at 2022-06-26 13:53:29.852325
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    post_processor_0 = MetadataFromTitlePP(None, None)
    post_processor_0.run(None)


# Generated at 2022-06-26 13:53:36.190909
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'C00G-\n5r\x0c'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    info_0 = {}
    info_0['title'] = 'C00G-\n5r\x0c'
    tuple_0 = metadata_from_title_p_p_0.run(info_0)
    assert info_0 == {'title': 'C00G-\n5r\x0c'}
    assert tuple_0 == ([], info_0)



# Generated at 2022-06-26 13:53:41.842036
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s - %(artist)s'
    metadata_from_title_p_p = MetadataFromTitlePP('downloader', str_0)
    str_2 = 'C00G-\n5r\x0c'
    str_3 = 'C00G-\n5r\x0c'
    dict_0 = {'title': str_3, 'artist': str_2}
    metadata_from_title_p_p.run(dict_0)
    assert dict_0 == {'title': str_3, 'artist': str_2}

# Generated at 2022-06-26 13:53:46.602458
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'nq7k-_?D'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = dict()
    dict_0['title'] = 'Lorem ipsum dolor sit amet, consectetur adipisicing elit'
    dict_1 = dict()
    dict_2 = dict()
    dict_2['description'] = 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.'
    int_0 = metadata_from_title_p_p_0.run(dict_2)[0]

# Generated at 2022-06-26 13:53:47.416757
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test case #0
    test_case_0()



# Generated at 2022-06-26 13:53:55.089691
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'C00G-\n5r\x0c'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    title_0 = ''
    info_0 = {}
    title_1 = ''
    info_1 = {}
    title_2 = ''
    info_2 = {}
    title_3 = ''
    info_3 = {}
    title_4 = ''
    info_4 = {}
    title_5 = ''
    info_5 = {}
    title_6 = ''
    info_6 = {}
    title_7 = ''
    info_7 = {}
    title_8 = ''
    info_8 = {}
    title_9 = ''
    info_9 = {}
    title_10 = ''
    info_10