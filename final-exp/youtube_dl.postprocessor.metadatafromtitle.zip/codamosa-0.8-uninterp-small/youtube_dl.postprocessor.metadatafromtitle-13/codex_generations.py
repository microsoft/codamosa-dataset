

# Generated at 2022-06-26 13:44:02.927488
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '@`\\6[P\\Eq!C"ge'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = {}
    metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:44:07.195881
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '@`\\6[P\\Eq!C"ge'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    list_0 = []
    dict_0 = {}
    metadata_from_title_p_p_0.run(dict_0)



# Generated at 2022-06-26 13:44:13.302806
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '+"Q"F:5'
    str_0 = 'x#(,!<'
    str_0 = 'F;\\|B:>#,\\'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_0 = '%(title)s'
    info_0 = {'title': str_0}
    srt_0 = ()
    info_1 = metadata_from_title_p_p_0.run(info_0)
    assert srt_0 == info_1

# Generated at 2022-06-26 13:44:19.838812
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    str_0 = 'S#9"dCf_'
    str_1 = '2Y3Z'
    assert MetadataFromTitlePP(str_0, str_1).format_to_regex(str_1) == '(?P<2Y3Z>.+)'

if __name__ == '__main__':
    test_case_0()

    test_MetadataFromTitlePP_format_to_regex()

# Generated at 2022-06-26 13:44:32.082206
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '@`\\6[P\\Eq!C"ge'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    int_0 = -476289836
    int_1 = -912521565
    int_2 = int_0 + int_1
    list_0 = []
    str_1 = 'PF?@>1H'
    if str_0 is None:
        raise ValueError

# Generated at 2022-06-26 13:44:35.915165
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP('\\Fdw"@Q![V', '\\Fdw"@Q![V')
    metadata_from_title_p_p_0.run({'title': '\\Fdw"@Q![V'})

# Generated at 2022-06-26 13:44:40.875570
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    _test_case_0()
    _test_case_1()
    _test_case_2()
    _test_case_3()
    _test_case_4()
    _test_case_5()
    _test_case_6()
    _test_case_7()

# Test case 0

# Generated at 2022-06-26 13:44:43.153457
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, '')
    metadata_from_title_p_p_0.run(None)
    pass

# Generated at 2022-06-26 13:44:53.909520
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    r'''Test the format_to_regex() method (case 0).'''
    # case 0
    str_0 = '%(title)s'
    regex_0 = '(?P<title>.+)'
    assert MetadataFromTitlePP.format_to_regex(str_0) == regex_0

    r'''Test the format_to_regex() method (case 1).'''
    # case 1
    str_1 = 'hello%(title)shello'
    regex_1 = 'hello(?P<title>.+)hello'
    assert MetadataFromTitlePP.format_to_regex(str_1) == regex_1

    r'''Test the format_to_regex() method (case 2).'''
    # case 2

# Generated at 2022-06-26 13:44:54.878312
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pass


# Generated at 2022-06-26 13:45:00.949600
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'm5P5K'
    str_1 = 'hc%(artist)s%(title)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_1)



# Generated at 2022-06-26 13:45:10.739147
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '@`\\6[P\\Eq!C"ge'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_0 = '\\(?P<test>.+)\\ \-\\ (?P<artist>.+)'
    str_1 = str_0
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_1, str_1)
    str_0 = '%(title)s - %(artist)s'
    str_2 = str_0
    metadata_from_title_p_p_2 = MetadataFromTitlePP(str_2, str_2)
    metadata_from_title_p_p_2._titleregex

test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:45:15.823637
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s - %(artist)s'
    str_1 = 'file:///C:/Users/Benjamin/Desktop/'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_1, str_0)
    str_2 = 'file:///C:/Users/Benjamin/Desktop/'
    dict_0 = {}
    dict_0['title'] = 'Bam Bam Bam'
    tuple_0 = (dict_0, dict_0)
    assert_equal(tuple_0, metadata_from_title_p_p_0.run(dict_0))



# Generated at 2022-06-26 13:45:20.147060
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP._format_to_regex(MetadataFromTitlePP, '%(title)s - %(artist)s') == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'
    assert MetadataFromTitlePP._format_to_regex(MetadataFromTitlePP, '%(title)s - %(artist)s ') == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)\\ '
    assert MetadataFromTitlePP._format_to_regex(MetadataFromTitlePP, '%(title)s') == '(?P<title>.+)'

# Generated at 2022-06-26 13:45:20.451040
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    impo

# Generated at 2022-06-26 13:45:28.147522
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP.format_to_regex('%(title)s - %(artist)s -  -  -') == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ \ \-\ \-'
    assert MetadataFromTitlePP.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert MetadataFromTitlePP.format_to_regex('%(title)s - ') == '(?P<title>.+)\ \-'

# Generated at 2022-06-26 13:45:33.524501
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)

    # Call method run of class MetadataFromTitlePP
    print('Call method run of class MetadataFromTitlePP')
    metadata_from_title_p_p_0.run(str_0)


# Generated at 2022-06-26 13:45:37.132080
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP.format_to_regex('%(title)s - %(artist)s', '%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-26 13:45:43.413230
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    filepath_0 = '/home/danilo/Music/Scream.mp3'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, None)
    list_0 = []
    dict_0 = {'title': 'Scream', 'artist': 'Michael Jackson'}
    metadata_from_title_p_p_0.run(dict_0)

if __name__ == '__main__':
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:45:52.574054
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    str_0 = 'JE'
    # str_1 = '%(title)s%(ext)s'
    str_1 = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    str_2 = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert metadata_from_title_p_p_0.format_to_regex(str_0) == str_1
    assert metadata_from_title_p_p_0.format_to_regex(str_1) == str_2


# Generated at 2022-06-26 13:46:02.904705
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    from .common import FileDownloader
    from .common import InfoExtractor
    from .common import compat_urllib_request

    # test_set_downloader_0
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    urllib_request_0 = compat_urllib_request.Request('http://www.youtube.com/')
    test_value_0 = FileDownloader(urllib_request_0, 'youtube-dl', 'test', metadata_from_title_p_p_0, None, None, None)
    metadata_from_title_p_p_0.set_downloader(test_value_0)
    # test_set_downloader_1
    metadata_from_title_p_p_

# Generated at 2022-06-26 13:46:14.589300
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'L-R]_I,C/rX'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = 'V_|'
    dict_0 = {
        'title': str_1,
        'uploader': str_1,
        'upload_date': str_1
    }
    assert_raises(Exception, metadata_from_title_p_p_0._MetadataFromTitlePP__titleregex, dict_0)
    dict_1 = {
        'title': str_1,
        'uploader': str_1,
        'upload_date': str_1
    }

# Generated at 2022-06-26 13:46:23.393792
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '/jSSE7*!%(title)s.mp4'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = '-#Z}Xft:jB_%(title)s.mp4'
    dict_0 = {'title': str_1}
    list_0 = []
    metadata_from_title_p_p_0.run(dict_0)
    assert(dict_0 == {'title': str_1})
    assert(list_0 == [])
    str_2 = '%(title)s.mp4'
    dict_1 = {'title': str_2}
    metadata_from_title_p_p_0.run(dict_1)

# Generated at 2022-06-26 13:46:29.558228
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'I-Tunes Converted'
    str_1 = ''
    str_0 = '%(title)s - %(artist)s'
    str_2 = 'Test title with %(artist)s - %(title)s'
    str_1 = "Something with 'quotes' %% escaped % and !"
    str_3 = '%(title)s - %(artist)s'
    str_4 = '%(artist)s - %(title)s'
    str_2 = '%(title)s%(artist)s'
    str_3 = '%(title)s%%%(artist)s'
    str_5 = '%(artist)s - %(title)s'
    str_6 = '%(artist)s - %(title)s'

# Generated at 2022-06-26 13:46:38.772415
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '@`\\6[P\\Eq!C"ge'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = "\\-\\[u\7\\`\\(b\n"
    dict_0 = dict()
    dict_0['title'] = str_1
    dict_1 = metadata_from_title_p_p_0.run(dict_0)
    str_2 = '\\-\\[u\7\\`\\(b\n'
    dict_2 = dict()
    dict_2['title'] = str_2
    str_3 = '\\-\\[u\7\\`\\(b\n'
    dict_2['title'] = str_3

# Generated at 2022-06-26 13:46:49.345487
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '&[C0q,G'
    str_1 = 'T\\TW\\xO~<X,rZ\\?8'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = dict()
    dict_0['author'] = None
    dict_0['title'] = '%(title)s - %(artist)s - %(subtitle)s'
    metadata_from_title_p_p_0._titleregex = '(?P<artist>.+)'
    dict_1 = dict_0.copy()
    dict_1['series'] = 'ZD\\*C\\=O'
    dict_1['artist'] = 'hQO1\\w\\!6U'
    dict_1['subtitle']

# Generated at 2022-06-26 13:46:53.424458
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '@`\\6[P\\Eq!C"ge'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = '6\\:2Sf&o6'
    print(metadata_from_title_p_p_0.run(str_1))


# Generated at 2022-06-26 13:47:03.983072
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = ''
    str_1 = '%(title)s - %(artist)s'

# Generated at 2022-06-26 13:47:08.370058
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    title = 'title'
    info = {
        'title': 'title'
    }
    title_format = '(?P<title>.+)'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(title, title_format)
    metadata_from_title_p_p_0.run(info)


# Generated at 2022-06-26 13:47:15.088182
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'Mt#QfY~.R'
    dict_0 = {str_0: str_0, 'X': 'F', 'b': str_0, 'r': ']Q<', 'm': str_0, '_': 'Gz', 's': 'hW', '8': 'm+'}
    metadata_from_title_p_p_0 = MetadataFromTitlePP(dict_0, str_0)
    metadata_from_title_p_p_0.run({'title': 'C"ge'})


# Generated at 2022-06-26 13:47:27.295870
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'Y0c%O?B;+'
    str_1 = '"O=jnrO%;N:b'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_1)
    str_1 = '`X{E~$F4_'
    str_2 = ')A'
    str_3 = 'K"$y^'
    str_4 = 'M|-~x8Ye'
    str_5 = 'r'
    str_6 = 'WK!v'
    str_7 = '7d(mr=N'
    str_8 = '-'
    str_9 = 'q'
    str_10 = 'Lg'
    str_11 = 'G'

# Generated at 2022-06-26 13:47:34.971444
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '@`\\6[P\\Eq!C"ge'
    str_1 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_1)
    str_2 = 'An example title - Example Artist'
    dict_0 = {'title': str_2}
    list_0 = metadata_from_title_p_p_0.run(dict_0)
    dict_1 = {'title': str_2, 'artist': 'Example Artist'}
    assert list_0 == ([], dict_1)


# Generated at 2022-06-26 13:47:39.175163
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '@`\\6[P\\Eq!C"ge'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_info_0 = {'title': 'test'}
    [[], metadata_info_0] == metadata_from_title_p_p_0.run(metadata_info_0)


# Generated at 2022-06-26 13:47:43.358584
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '|yf%c>@qM~'
    str_1 = '5[,VkxEK{|r'
    dict_0 = {
        'asdf': 'asdf',
        'views': '100',
        'uploader_id': '1',
        'title': str_0,
    }
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_1, str_1)
    tuple_0 = metadata_from_title_p_p_0.run(dict_0)
    print(tuple_0)

test_case_0()
test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:47:53.165404
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # test case 0
    str_0 = '@`\\6[P\\Eq!C"ge'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = '>\\qd?'
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_0, str_1)
    metadata_from_title_p_p_2 = MetadataFromTitlePP(str_0, str_1)
    metadata_from_title_p_p_3 = MetadataFromTitlePP(str_0, str_1)
    metadata_from_title_p_p_4 = MetadataFromTitlePP(str_0, str_1)
    str_2 = '4W8BV[K'
    metadata_from_

# Generated at 2022-06-26 13:47:54.551224
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # TODO: Make the tests
    return True


# Generated at 2022-06-26 13:48:00.452019
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '@`\\6[P\\Eq!C"ge'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    info = {}
    return_value_0 = metadata_from_title_p_p_0.run(info)
    assert (return_value_0 == ([], info)), "return_value_0 does not match the expected value"



# Generated at 2022-06-26 13:48:06.931105
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test with failing regex
    class InfoFake(object):
        title = '%(invalid_group_name)s'
    class DownloaderFake(object):
        def __init__(self):
            self.entries = []

        def to_screen(self, message):
            self.entries.append(message)
    downloader_fake_0 = DownloaderFake()
    metadata_from_title_p_p_0 = MetadataFromTitlePP(downloader_fake_0, '%(invalid_group_name)s')
    info_fake_0 = InfoFake()

    metadata_from_title_p_p_0.run(info_fake_0)

# Generated at 2022-06-26 13:48:17.119097
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '|<E\\@0;2a\\ -Ab\\3%C`'
    str_1 = '\\1y\\&^g\\(#%<Bf\\-H'
    str_2 = '\"J4\\a+\\!('
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, '%(title)s - %(artist)s')
    metadata_from_title_p_p_0.run({'title': str_1})
    metadata_from_title_p_p_0.run({'title': str_2})


# Generated at 2022-06-26 13:48:24.254739
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '@`\\6[P\\Eq!C"ge'
    str_1 = '!@E9k6sRnhv"sA'
    str_2 = 'h`\\6[P\\Eq!C"ge'
    str_3 = '!@E9k6sRnhv"sA'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_2, str_2)
    info = dict()
    info['title'] = str_1
    info['artist'] = str_0
    str_5 = (str_1 + ' - ' + str_0)
    info['title'] = str_5
    str_6 = metadata_from_title_p_p_0.run(info)
    print(str_6)

# Generated at 2022-06-26 13:48:36.590953
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, None)

    if __name__ == '__main__':
        test_case_0()


# Generated at 2022-06-26 13:48:39.917617
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.run([str_0])


# Generated at 2022-06-26 13:48:47.363029
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = ''
    str_1 = '$\\ZR\\)G?&'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_1)
    metadata_from_title_p_p_1 = metadata_from_title_p_p_0
    metadata_from_title_p_p_2 = metadata_from_title_p_p_1
    metadata_from_title_p_p_3 = metadata_from_title_p_p_2
    metadata_from_title_p_p_4 = metadata_from_title_p_p_3
    metadata_from_title_p_p_5 = metadata_from_title_p_p_4
    metadata_from_title_p_p_6 = metadata_from_title_p_p

# Generated at 2022-06-26 13:48:53.832218
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-26 13:49:02.243819
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # SETUP VARIABLES FOR TEST
    str_0 = '@`\\6[P\\Eq!C"ge'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = '@`\\6[P\\Eq!C"ge'
    str_2 = '8\\YWkm5`5`x\\R\\;0>|H_\\y[c'
    str_3 = '@`\\6[P\\Eq!C"ge'
    str_4 = '@`\\6[P\\Eq!C"ge'
    str_5 = 'F^fzG'
    str_6 = 'y:h{nt1"<$vX8W'

# Generated at 2022-06-26 13:49:10.658046
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'D=wCn@`\\6[P\\Eq!C"ge'
    dict_0 = dict(a='v3/+g%c8*!_>f', b=['v3/+g%c8*!_>f', 'xyz'], c=str_0, d=str_0, e=str_0, f=str_0)
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    list_0, dict_1 = metadata_from_title_p_p_0.run(dict_0)

# Generated at 2022-06-26 13:49:16.369081
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Create an instance of PostProcessor
    # Call method run of PostProcessor instance
    #
    # Does nothing but doesn't raise any exception
    metadata_from_title_p_p_0 = MetadataFromTitlePP(
        'vLpYk1\\qzF?', 'w4&n7J[*]Zq')
    metadata_from_title_p_p_0.run('bksmE`R/')

# Unit tests for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-26 13:49:22.915708
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    info_0 = {'title': 'https-youtubevideosorg'}
    str_0 = '%(title)s'
    str_1 = '%(title)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_1)
    metadata_from_title_p_p_0.run(info_0)
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_0, str_1)
    metadata_from_title_p_p_1.run(info_0)
    assert info_0['title'] == 'https-youtubevideosorg'

# Generated at 2022-06-26 13:49:29.166937
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    title_0 = 'g\\E\\M'
    str_0 = '5g5'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(title_0, str_0)
    title_1 = ' \\u?7_o\\=J'
    str_1 = 'qrp'
    metadata_from_title_p_p_1 = MetadataFromTitlePP(title_1, str_1)
    assert metadata_from_title_p_p_0 != metadata_from_title_p_p_1


# Generated at 2022-06-26 13:49:33.869553
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    title_0 = '_\\'
    info_0 = {'title': title_0}
    metadata_from_title_p_p_0 = MetadataFromTitlePP('%(title)s', title_0)
    metadata_from_title_p_p_0.run(info_0)

# Generated at 2022-06-26 13:49:44.442908
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s - %(artist)s'
    dict_0 = {'title':str_0, 'artist':str_0}
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:49:50.369694
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    p_0 = MetadataFromTitlePP(str_0, str_0)
    p_0 = p_0.run(p_0.info)

if __name__ == '__main__':
    str_0 = '@`\\6[P\\Eq!C"ge'
    p_0 = MetadataFromTitlePP(str_0, str_0)
    p_0 = p_0.run(p_0.info)
    print(p_0)

# Generated at 2022-06-26 13:49:58.892543
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    info = {}

    # Pass: info is empty
    [], info_0 = metadata_from_title_p_p_0.run(info)
    assert info_0 == {}

    # Error: info does not have required attributes
    assert_raises(KeyError, metadata_from_title_p_p_0.run, info)


if __name__ == "__main__":
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:50:02.990894
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'q[\"4p\\'
    str_1 = '%(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_1)


# Generated at 2022-06-26 13:50:06.812295
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    print("Testing MetadataFromTitlePP.run")
    str_0 = '@`\\6[P\\Eq!C"ge'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.run(dict())


# Generated at 2022-06-26 13:50:13.167025
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    title = 'The Best Song'
    title_re = 'The Best Song'
    titleformat = title_re + '_%(artist)s_%(album)s_%(track)s_%(year)s_%(genre)s_%(ext)s'
    # fmt: off
    match = re.match(title_re + r'_%\((\w+)\)s',
                     titleformat)
    # fmt: on

    # finditer
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, None)
    match = re.match(title_re + '_%(artist)s', titleformat)

# Generated at 2022-06-26 13:50:20.511953
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '#/<0-8GZc9q]fTL{!RS1'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = '#/<0-8GZc9q]fTL{!RS1'
    meta_0 = metadata_from_title_p_p_0.format_to_regex(str_1)
    assert meta_0 == metadata_from_title_p_p_0._titleregex
    str_2 = 'lf1uVg9}o=Q#c7R\\0`'
    info_0 = {'title': str_2}
    tup_0 = metadata_from_title_p_p_0.run(info_0)
    assert tup

# Generated at 2022-06-26 13:50:27.201222
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_1 = '@`\\6[P\\Eq!C"ge'
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_1, str_1)
    str_2 = 'H\\L-R$gU6fKUc%HZ'
    dict_0 = dict()
    dict_0['title'] = (str_2)
    dict_0['thumbnail'] = (str_2)
    dict_0['tracknumber'] = (str_1)
    dict_0['uploader'] = (str_2)
    dict_0['uploader_url'] = (str_1)
    dict_0['id'] = (str_2)
    dict_0['upload_date'] = (str_1)

# Generated at 2022-06-26 13:50:35.779001
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '0120-0760_c%(upload)s'
    str_1 = '0120-0760_c%(upload)s'
    str_2 = '0120-0760_c%(upload)s'
    str_3 = '0120-0760_c%(upload)s'

# Generated at 2022-06-26 13:50:39.966199
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Input parameters
    info_0 = dict()
    info_0['title'] = '@`\\6[P\\Eq!C"ge'
    titleformat = '@`\\6[P\\Eq!C"ge'

    metadata_from_title_p_p_0 = MetadataFromTitlePP(info_0, titleformat)
    list_0, dict_0 = metadata_from_title_p_p_0.run(info_0)


if __name__ == '__main__':
    test_case_0()
    # test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:50:57.460542
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '1Gz=\\m\\f'
    regex_0 = '[A-Z][a-z]*'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, regex_0)
    str_1 = '8fT'
    info_0 = {"title": str_1}
    metadata_from_title_p_p_0.run(info_0)

if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:51:03.160115
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'F7"b\\[=J\\d}87Aa)u'
    assert isinstance(str_0, str)
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    assert isinstance(metadata_from_title_p_p_0, MetadataFromTitlePP)

    # AssertionError: No attribute '_titleregex' found in <MetadataFromTitlePP
    # instance at 0x7fc41c86f540>
    # assert hasattr(metadata_from_title_p_p_0, '_titleregex')

# Generated at 2022-06-26 13:51:04.030703
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass



# Generated at 2022-06-26 13:51:09.497849
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_1 = '@`\\6[P\\Eq!C"ge'
    str_2 = '@`\\6[P\\Eq!C"ge'
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_1, str_2)
    list_0 = []
    dict_0 = {'title': '@`\\6[P\\Eq!C"ge'}
    assert metadata_from_title_p_p_1.run(dict_0) == (list_0, dict_0)


# Generated at 2022-06-26 13:51:12.768881
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '@`\\6[P\\Eq!C"ge'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0 = None
    assert(False)


# Generated at 2022-06-26 13:51:21.173361
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '@`\\6[P\\Eq!C"ge'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)

# Generated at 2022-06-26 13:51:24.715511
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test case 0
    str_0 = '%(title)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)

    metadata_from_title_p_p_0.run(str_0)

    # Test case 1
    str_0 = '%(title)s-%(artist)s'
    str_1 = 'Emancipate yourself from mental slavery'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_0, str_0)

    metadata_from_title_p_p_0.run(str_0)

    metadata_from_title_p_p_1.run

# Generated at 2022-06-26 13:51:28.539096
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_1 = '@`\\6[P\\Eq!C"ge'
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_1, str_1)
    int_0 = 0
    str_0 = '@`\\6[P\\Eq!C"ge'
    metadata_from_title_p_p_1.run(int_0)
    metadata_from_title_p_p_1.run(str_0)
    metadata_from_title_p_p_1.run([])


# Generated at 2022-06-26 13:51:37.157843
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test sample of the input argument info
    info_0 = {}
    # Test sample of the input argument title
    title_0 = 's'
    # Test sample of the input argument self
    self_0 = '1'
    # Test sample of the input argument raw_title
    raw_title_0 = '0'
    # Test sample of the input argument titleformat
    titleformat_0 = '3'
    # Test sample of the input argument format
    format_0 = '4'
    # Test sample of the input argument fmt
    fmt_0 = '5'
    # Test sample of the input argument regex
    regex_0 = '2'
    # Test sample of the input argument match
    match_0 = 'N7V'
    # Test sample of the input argument lastpos
    lastpos_0 = '!'
    #

# Generated at 2022-06-26 13:51:46.285962
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'R\\P4+Bt\\\\{\\W$c#' # b'S\P4+Bt\{\W$c#'
    obj_0 = MetadataFromTitlePP(str_0, str_0)

# Generated at 2022-06-26 13:52:21.274271
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = "jrz;$(T\\`=Jp:jrz;$(T\\`=Jp:jrz;$(T\\`=Jp:jrz;$(T\\`=Jp:"
    str_1 = "jrz;$(T\\`=Jp:jrz;$(T\\`=Jp:jrz;$(T\\`=Jp:jrz;$(T\\`=Jp:"
    str_2 = "jrz;$(T\\`=Jp:jrz;$(T\\`=Jp:jrz;$(T\\`=Jp:jrz;$(T\\`=Jp:"

# Generated at 2022-06-26 13:52:28.336915
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0
    info_0 = {'title': str_0}
    var_0 = metadata_from_title_p_p_0.run(info_0)
    var_1 = (var_0[0], var_0[1])
    assert var_1 == ([], {'artist': '%(artist)s', 'title': '%(title)s'}), 'AssertionError'

# Generated at 2022-06-26 13:52:31.872506
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'O"rn"6&P]6ip'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    assert [], metadata_from_title_p_p_0.run({'title': ''})



# Generated at 2022-06-26 13:52:40.825552
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test a simple title
    metadata_from_title_p_p_0 = MetadataFromTitlePP('downloader', '%(title)s')
    dict_0 = { 'title': 'title' }
    dict_1 = dict_0.copy()
    del dict_1['title']

    metadata_from_title_p_p_0.run(dict_0)

    # Test with missing title field
    metadata_from_title_p_p_1 = MetadataFromTitlePP('downloader', '%(title)s')

    metadata_from_title_p_p_1.run(dict_1)

    # Test with an artist and title
    metadata_from_title_p_p_2 = MetadataFromTitlePP('downloader', '%(artist)s - %(title)s')
    dict_2

# Generated at 2022-06-26 13:52:41.338143
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
  assert True

# Generated at 2022-06-26 13:52:47.789258
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'HELLO WORLD'
    str_1 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_1)
    str_2 = 'hello title'
    str_3 = 'Yay Artist!'
    dict_0 = {'title': str_2, 'artist': str_3}
    list_0 = []
    metadata_from_title_p_p_0.run(dict_0)
    assert list_0 == []
    assert dict_0['title'] == str_2
    assert dict_0['artist'] == str_3


# Generated at 2022-06-26 13:52:56.975508
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Case 0
    str_0 = '@`\\6[P\\Eq!C"ge'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    # Unit test for method run of class MetadataFromTitlePP
    # Case 0
    str_0 = '@`\\6[P\\Eq!C"ge'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)

# Generated at 2022-06-26 13:52:58.327797
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()

# vim: tabstop=4 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-26 13:53:06.390054
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    # Test Case 0
    str_0 = '5H5E5O5L5L5O5W5R5D5W5A5C5H5I5V5E5A5W5E5L5L5P5R5O5G5R5A5M5M5E5R5S5M5E5T5A5D5A5T5A5A5A5A'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = {'title': 'hello world'}

    expected_0 = [], {'title': 'hello world'}
    actual_0 = metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:53:13.183030
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'c%(title)s b%(artist)s a%(album)s w%(track)s v%(tracknumber)s x%(tracknumber)s u%(year)s t%(genre)s s%(isrc)s r%(disc)s q%(discnumber)s z%(duration)s y%(location)s i%(website)s o%(publisher)s p%(copyright)s l%(date)s k%(playlist)s j%(playlist_index)s h%(albumartist)s g%(artists)s f%(creator)s e%(genre)s d%(description)s'
    str_1 = 'f%(aprob)s e%(artist)s d%(artists)s c%(genre)s'
