

# Generated at 2022-06-26 13:44:03.756407
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'SamK,'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = {}
    dict_0['test_key'] = 'test_value'
    dict_1 = {'test_key_0': dict_0}
    dict_0['test_key'] = dict_1
    str_1 = 'YouTube'
    dict_0['title'] = str_1
    str_2 = ''
    dict_0['_filename'] = str_2
    tuple_0 = ('', dict_0)
    metadata_from_title_p_p_0.run(tuple_0)


# Generated at 2022-06-26 13:44:12.015395
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    str_0 = 'SamK,'
    str_1 = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    str_2 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_2)
    str_3 = '(?P<a>.+)'
    str_4 = '%(a)s'
    str_5 = '(?P<b>.+)'
    str_6 = '%(b)s'
    str_7 = '%(c)s'
    str_8 = '%(d)s'
    str_9 = '%(e)s'
    str_10 = '%(f)s'

# Generated at 2022-06-26 13:44:16.764436
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'SamK,'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)

    # Input variables
    str_0 = 'first_name'
    str_1 = 'last_name'
    str_2 = 'Sam,K'
    str_3 = '"%(first_name)s,%(last_name)s"'
    str_4 = '%(first_name)s,%(last_name)s'

    # Output variables
    str_5 = 'Kamal'
    str_6 = 'Sam'

    # Call to function
    metadata_from_title_p_p_0.run(str_0, str_1, str_2, str_3, str_4, str_5, str_6)

   

# Generated at 2022-06-26 13:44:19.872748
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP.format_to_regex(MetadataFromTitlePP, '%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-26 13:44:28.801994
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Parameters
    info_0 = {}

    # Functions
    test_case_0()
    test_MetadataFromTitlePP_format_to_regex()
    # No output
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.run(info_0)


# Generated at 2022-06-26 13:44:34.280177
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    str_0 = '%(title)s - %(artist)s'
    str_1 = r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    metadata_from_title_p_p_0 = MetadataFromTitlePP('', str_0)
    assert metadata_from_title_p_p_0.format_to_regex(str_0) == str_1


# Generated at 2022-06-26 13:44:40.874419
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Input parameters
    str_0 = 'SamK,'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    info = {'title': 'SamK,'}
    # Expected output
    expected = ([], [])

    # Execute function
    actual = metadata_from_title_p_p_0.run(info)

    # Check output
    assert actual == expected

# Generated at 2022-06-26 13:44:44.902860
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'SamK,'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = 'SamK'
    dict_0 = {'SamK': str_1}
    dict_1 = dict_0
    dict_1 = dict_1


# Generated at 2022-06-26 13:44:49.559053
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(artist)s - %(title)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = 'john cena'
    str_2 = 'cena'
    str_3 = '%(artist)s - %(title)s'
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_3, str_3)
    str_4 = 'cena - john'
    str_5 = 'john'
    str_6 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_2 = MetadataFromTitlePP(str_6, str_6)
    str_7 = 'john - cena'
    str_8

# Generated at 2022-06-26 13:45:00.222942
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p = MetadataFromTitlePP("SamK,", "SamK,")
    dict_0 = dict()
    dict_1 = dict()
    dict_1[''] = "SamK,"
    dict_0[''] = "SamK,"
    new_info = metadata_from_title_p_p.run(dict_0)
    dict_1[''] = "SamK,"
    dict_0[''] = "SamK,"
    dict_1[''] = "SamK,"
    dict_0[''] = "SamK,"
    dict_1[''] = "SamK,"
    dict_0[''] = "SamK,"
    dict_1[''] = "SamK,"
    dict_0[''] = "SamK,"
    dict_1

# Generated at 2022-06-26 13:45:04.811498
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    tftpp_0 = MetadataFromTitlePP()
    t_dummy_0 = {'title': 'Some Video Title'}

    tftpp_0.run(t_dummy_0)

# Generated at 2022-06-26 13:45:08.150227
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_titlePP_0 = MetadataFromTitlePP(None, None)
    assert_raises(TypeError, metadata_from_titlePP_0.run, None)


# Generated at 2022-06-26 13:45:17.987907
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s - %(artist)s'
    str_1 = '%(title)s - %(artist)s'
    str_2 = '%(title)s - %(artist)s'
    str_3 = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    int_4 = 0
    class_5 = (python_getopt.GetoptError, AttributeError)
    def side_effect_func_6(str_0):
        if (str_0 == '%(title)s - %(artist)s'):
            return (str_1, str_2)
        return str_3
    # set up the testing environment
    # assume some fixture have already been setup
    class_0 = MetadataFromTitlePP
    class_1 = object

# Generated at 2022-06-26 13:45:22.117445
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    regex = MetadataFromTitlePP.format_to_regex('%(title)s - %(artist)s')
    match = re.match(regex,'This Is The Title - This Is The Artist')
    assert match.groupdict() == {'title': 'This Is The Title','artist': 'This Is The Artist'}

# Generated at 2022-06-26 13:45:27.163034
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s - %(artist)s'
    str_1 = '%(artist)s'
    str_2 = '%(comment)s'
    str_3 = '%(title)s'
    str_4 = '%(artist)s'
    str_5 = '%(comment)s'
    str_6 = '%(title)s'
    str_7 = '%(artist)s'
    str_8 = '%(comment)s'
    pass

# Generated at 2022-06-26 13:45:28.767885
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    # test_case_0
    str_0 = '%(title)s - %(artist)s'
    pp_0 = MetadataFromTitlePP(str_0)

# Generated at 2022-06-26 13:45:32.634013
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s - %(artist)s'
    str_1 = 'dummy - vid'
    postprocessor_0 = MetadataFromTitlePP()
    info_0 = {'title': 'dummy - vid'}
    postprocessor_0.run(info_0)

if __name__ == '__main__':
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:45:34.030637
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    mftpp = MetadataFromTitlePP(test_case_0(), str_0)
    mftpp.run()
    pass

# Generated at 2022-06-26 13:45:44.386351
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s - %(artist)s'
    str_1 = '%(artist)s - %(title)s'
    str_2 = '%(title)s-%(artist)s'
    str_3 = '%(title)s-%(artist)s-%(album)s'
    str_4 = '%(title)s'
    str_5 = '%(title)s - %(artist)s - %(album)s'
    str_6 = '%(title)s [%(artist)s - %(album)s]'
    str_7 = '%(artist)s - [%(album)s] %(title)s'
    str_8 = '%(title)s'

# Generated at 2022-06-26 13:45:49.721316
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    m = MetadataFromTitlePP(None, None)
    assert m.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'
#    d.assertEquals(m.run(None), [], None)

# Generated at 2022-06-26 13:45:54.835164
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ..YoutubeDL import YoutubeDL
    from ..extractor import YoutubeIE
    pp = MetadataFromTitlePP(YoutubeDL())
    ie = YoutubeIE()
    title = 'Test Video 2015 - Test Artist'
    info = ie.extract('https://www.youtube.com/watch?v=BaW_jenozKc')
    info['title'] = title
    pp.run(info)
    assert info['title'] == 'Test Video 2015'
    assert info['artist'] == 'Test Artist'

# Generated at 2022-06-26 13:46:02.568643
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    titleformat_0 = '%(title)s - %(artist)s'
    _0 = (PostProcessor, _downloader, titleformat_0)
    titleformat_1 = '%(title)s - %(artist)s'
    (match_0, match_1, match_2) = (re.match(_0, titleformat_1),
                                   re.match(_0, titleformat_1),
                                   re.match(_0, titleformat_1))
    (attribute_0, value_0) = (None, None)
    (_downloader, info) = (None, (title,))
    assert (match_2 is None)


if __name__ == '__main__':
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:46:14.189105
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s - %(artist)s'
    str_1 = '%(title)s'
    str_2 = '%(uploader)s - %(title)s'
    str_3 = '%(upload_date)s - %(title)s'
    str_4 = '%(uploader)s - %(upload_date)s - %(title)s'
    str_5 = '%(uploader)s - [%(upload_date)s] - %(title)s'
    str_6 = '%(uploader)s - %(title)s [%(id)s]'
    str_7 = '%(uploader)s - %(title)s [%(id)s][%(format_id)s]'

# Generated at 2022-06-26 13:46:16.726513
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()


if __name__ == '__main__':
    test_cases = [
        test_case_0,
    ]

    for test_case in test_cases:
        test_case()

# Generated at 2022-06-26 13:46:22.252959
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    _titleformat = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP('', _titleformat)
    pp.format_to_regex(_titleformat)
    _titleregex = pp._titleregex
    info = {
        'title': 'One - Metallica',
    }
    pp.run(info)
    assert info['artist'] == 'Metallica'
    assert info['title'] == 'One'



# Generated at 2022-06-26 13:46:26.258667
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    d = Downloader()
    m = MetadataFromTitlePP(d, str_0)
    info = {
        'title': 'How to fake the moon landing - NASA',
        'text': '',
    }
    m.run(info)
    assert info['artist'] == 'NASA'
    assert info['title'] == 'How to fake the moon landing'

# Generated at 2022-06-26 13:46:29.701725
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s - %(artist)s'
    obj_0 = MetadataFromTitlePP(PostProcessor(''), str_0)
    assert not obj_0.run('')


# Generated at 2022-06-26 13:46:35.772592
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Initialize static objects
    info = dict()
    info['title'] = 'Foo, Bar'
    downloader = None

    # Call the function
    res = MetadataFromTitlePP(downloader, '%(title)s').run(info)
    
    # Assert the result
    assert res[0] == []
    assert res[1].keys() == ['title']
    assert res[1]['title'] == 'Foo, Bar'



# Generated at 2022-06-26 13:46:36.309395
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass

# Generated at 2022-06-26 13:46:42.512922
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    # class PostProcessor
    def run(self, info):
        pass

    # class MetadataFromTitlePP
    def run(self, info):
        pass

    #
    class InfoDict(dict):

        def __init__(self, *args, **kwargs):
            super(InfoDict, self).__init__(*args, **kwargs)

        def __getattribute__(self, name):
            if name in self:
                return self[name]
            else:
                return super(InfoDict, self).__getattribute__(name)

        def __setattr__(self, name, value):
            self[name] = value


    # Test case 0
    str_0 = '%(title)s - %(artist)s'

# Generated at 2022-06-26 13:46:53.348882
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # metadata_from_title_p_p_0 = MetadataFromTitlePP('SamKarlo-Blog', 'SamKarlo-Blog')
    # info = 'assign result'
    # assert metadata_from_title_p_p_0.run(info) == ([], 'assign result')

    metadata_from_title_p_p_1 = MetadataFromTitlePP('SamKarlo-Blog', 'SamKarlo-Blog')
    info = 'assign result'
    assert metadata_from_title_p_p_1.run(info) == ([], 'assign result')

    metadata_from_title_p_p_2 = MetadataFromTitlePP('SamKarlo-Blog', 'SamKarlo-Blog')
    info = 'assign result'

# Generated at 2022-06-26 13:47:02.191941
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'SamK,'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = dict()
    dict_0['title'] = 'SamK,'
    dict_0['f'] = 'SamK,'
    list_0 = list()
    dict_1 = metadata_from_title_p_p_0.run(dict_0)

# Generated at 2022-06-26 13:47:06.436150
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'SamK,'
    
    # Invoke run of MetadataFromTitlePP with correct parameter
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    info_0 = {}
    metadata_from_title_p_p_0.run(info_0)

# Generated at 2022-06-26 13:47:11.821171
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'YOUTUBE_TITLE'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.run(str_0)
    # AssertionError


if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:47:14.896840
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'SamK,'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    # The generic behaviour is yet unknown, no test to be added.
    pass

# Generated at 2022-06-26 13:47:17.770779
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP()
    str_0 = 'SamK,'
    map_0 = {'title': str_0, 'artist': str_0}
    metadata_from_title_p_p_0.run(map_0)


# Generated at 2022-06-26 13:47:27.797646
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass
    # title = ''
    # info = {
    #     'title': '',
    #     'uploader': '',
    #     'creator': '',
    #     'timestamp': '',
    #     'upload_date': '',
    #     'channel': '',
    #     'track': '',
    #     'artist': '',
    #     'album': '',
    #     'album_artist': '',
    #     'release_year': '',
    #     'track_number': '',
    #     'track_year': '',
    #     'location': '',
    #     'video_id': '',
    #     'format': '',
    #     'ext': '',
    #     'duration': '',
    #     'view_count':

# Generated at 2022-06-26 13:47:32.619792
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP('SamK,', 'SamK,')
    title = 'test'
    str_0 = '^test$'
    dict_0 = {'title': title, 'regex': str_0}
    list_0 = []
    list_1 = metadata_from_title_p_p_0.run(dict_0)
    assert list_0 == list_1


# Generated at 2022-06-26 13:47:36.326766
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)

# Test of method format_to_regex for class MetadataFromTitlePP

# Generated at 2022-06-26 13:47:44.107845
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '21'
    int_0 = -1
    str_1 = '15'
    str_2 = '%(title)s - %(artist)s'
    str_3 = 'SamK,'
    str_4 = 'SamK,'
    str_5 = 'SamK,'
    str_6 = 'SamK,'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_1)
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_2, str_3)
    str_7 = 'title'
    str_8 = 'artist'
    str_9 = '%s%s' % (str_7, str_8)
    metadata_from_title_p_p_2 = MetadataFromTitlePP

# Generated at 2022-06-26 13:47:58.811749
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '.*'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)

    str_1 = 'SamK,'
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_1, str_1)

    str_2 = 'SamK,'
    metadata_from_title_p_p_2 = MetadataFromTitlePP(str_2, str_2)
    str_3 = 'SamK,'
    metadata_from_title_p_p_3 = MetadataFromTitlePP(str_3, str_3)
    metadata_from_title_p_p_2.format_to_regex = lambda x : x
    expected = ([], {'title': 'SamK,'})
    actual = metadata_from_title

# Generated at 2022-06-26 13:47:59.681993
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    raise NotImplementedError()


# Generated at 2022-06-26 13:48:06.290815
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Create an instance of MetadataFromTitlePP
    metadata_from_title_p_p_0 = MetadataFromTitlePP(MetadataFromTitlePP, 4267)

    str_0 = 'AD'
    str_1 = 'Q'
    dict_0 = dict({'\x00\x00\x00\x00\x00\x00\x00':'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'})
    # Call method run of metadata_from_title_p_p_0 instance
    metadata_from_title_p_p_0.run(str_1, dict_0)

# Generated at 2022-06-26 13:48:13.138024
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'SamK,'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    info_0 = {'title': str_0}
    metadata_from_title_p_p_0.run(info_0)
    print('argument : ' + repr(str_0))
    print('argument : ' + repr(info_0))


# Generated at 2022-06-26 13:48:22.627763
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Local variable 'metadata'
    # Call to run(...)
    # Processing the call arguments (line 35)
    # Obtaining an instance of the builtin type 'dict' (line 35)
    dict_0 = get_builtin_python_type_instance(stypy.reporting.localization.Localization(__file__, 35, 20), 'dict')
    # Processing the call keyword arguments (line 35)
    kwargs_1 = {}
    # Getting the type of 'metadata_from_title_p_p_0' (line 35)
    metadata_from_title_p_p_0_0 = module_type_store.get_type_of(stypy.reporting.localization.Localization(__file__, 35, 4), 'metadata_from_title_p_p_0', False)
    # Obtaining the

# Generated at 2022-06-26 13:48:23.475620
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()

# Generated at 2022-06-26 13:48:24.924621
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    print ('Test case 1: ' + ': {')
    test_case_0()
    print ('}')

# Generated at 2022-06-26 13:48:35.011794
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(id)s-%(title)s.%(ext)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP('', str_0)

    #  '%(title)s - %(artist)s'
    str_1 = '%(title)s - %(artist)s'
    regex_0 = metadata_from_title_p_p_0.format_to_regex(str_1)
    str_2 = 'Song1'
    str_3 = 'Artist1'
    str_4 = str_2 + ' - ' + str_3
    match_0 = re.match(regex_0, str_4)
    str_5 = 'title'
    str_6 = 'artist'

# Generated at 2022-06-26 13:48:42.902433
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'foo'
    dict_0 = {}
    dict_0['title'] = str_0
    dict_0['title'] = str_0
    dict_0[str_0] = str_0
    dict_0['title'] = str_0
    dict_0[str_0] = str_0
    dict_0[str_0] = dict_0
    metadata_from_title_p_p_0 = MetadataFromTitlePP(dict_0, str_0)
    metadata_from_title_p_p_0.run(dict_0)
    dict_0['title'] = dict_0
    dict_0[str_0] = str_0
    dict_0[str_0] = str_0
    dict_0['title'] = dict_0

# Generated at 2022-06-26 13:48:46.418581
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str, str)
    metadata_from_title_p_p_0.run(self)

if __name__ == '__main__':
    print(test_case_0.__doc__)
    test_case_0()
    print('Done testing')

# Generated at 2022-06-26 13:49:04.536536
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'SamK,OoZT,vR1j'
    dict_0 = {'a': 'v', 'c': 'D', 'b': 'f'}
    str_1 = 'Lq3u'
    str_2 = 'R'
    str_3 = 'M'
    dict_1 = {str_2: 'c', str_3: 'm', 'f': 'g', 'e': 'z'}
    str_4 = ';0^'
    str_5 = '5g5'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_2 = dict_0
    dict_2['title'] = str_1
    dict_2['upload_date'] = str_2
    dict_3

# Generated at 2022-06-26 13:49:08.280063
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    post_processor_1 = MetadataFromTitlePP(0, 0)
    test_video_info_1 = {}
    test_video_info_1['title'] = 'SamK,'
    info_1 = post_processor_1.run(test_video_info_1)
    assert ('gdict' == info_1)


# Generated at 2022-06-26 13:49:15.408781
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'YT_TEST_STRING_'
    str_1 = 'YT_TEST_STRING_'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_1)
    str_2 = 'YT_TEST_STRING_'
    dict_0 = {'title': str_2}
    list_0 = []
    tuple_0 = (list_0, dict_0)
    list_1 = []
    tuple_1 = (list_1, dict_0)
    assert tuple_0 == metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:49:23.149925
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(re.compile(r'^(?:https?://)?(?:www\.)?(?:youtu\.be/|youtube\.com(?:/embed/|/v/|/watch\?v=|/watch\?.+&v=))((\w|-){11})(?:\S+)?$'), re.compile(r'^(?:https?://)?(?:www\.)?(?:youtu\.be/|youtube\.com(?:/embed/|/v/|/watch\?v=|/watch\?.+&v=))((\w|-){11})(?:\S+)?$'))

# Generated at 2022-06-26 13:49:29.129565
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'hello hello'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = 'hello hello'
    str_2 = 'hello hello'
    list_0 = []
    dict_0 = {str_1: str_2}
    list_1, dict_1 = metadata_from_title_p_p_0.run(dict_0)
    return (list_0 == list_1) and (dict_0 == dict_1)


# Generated at 2022-06-26 13:49:38.263454
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '2F'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)

    dict_0 = dict()
    dict_0['title'] = 'A'
    dict_1 = dict_0
    dict_1['title'] = 'A'
    dict_2 = dict_1
    dict_2['title'] = 'A'
    dict_3 = dict_2
    dict_3['title'] = 'A'
    dict_4 = dict_3
    dict_4['title'] = 'A'
    dict_5 = dict_4
    dict_5['title'] = 'A'

    list_0 = list()
    list_0.append(dict_5)
    list_0.append(dict_5)
    list_0

# Generated at 2022-06-26 13:49:42.927497
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    p_1 = {'teste': 'teste'} # dictionary

    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, None)
    _, returned_1 = metadata_from_title_p_p_0.run(p_1)

    assert returned_1 == {'teste': 'teste'}

# Generated at 2022-06-26 13:49:45.325265
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()

test_MetadataFromTitlePP_run()

if __name__ == '__main__':
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:49:52.208467
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Setup
    str_0 = 'SamK,'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    
    # Pre-conditions
    # AssertionError(str_0) (pre-condition)

    # Test
    metadata_from_title_p_p_0.run()
    # Post-conditions
    assert metadata_from_title_p_p_0 is not None # dummy statement for traceability
    # AssertionError(str_0) (post-condition)



# Generated at 2022-06-26 13:50:03.480153
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'SamK,'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = 'title'
    int_0 = 5
    int_1 = 5
    int_2 = 5
    int_3 = 5
    int_4 = 5
    list_0 = [str_0, int_0, int_1, int_2, int_3, int_4]
    str_2 = 'a'
    int_5 = 1
    int_6 = 1
    int_7 = 1
    int_8 = 1
    int_9 = 1
    list_1 = [str_2, int_5, int_6, int_7, int_8, int_9]
    str_3 = 'v'
    int

# Generated at 2022-06-26 13:50:25.018588
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Initializing required variables
    str_0 = 'SamK,'
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_0, str_0)
    info_0 = {'title': 'this is a title'}

    # Calling function to test
    metadata_from_title_p_p_1.run('this is a title')



# Generated at 2022-06-26 13:50:28.067069
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.run()



# Generated at 2022-06-26 13:50:31.372642
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str(), str())
    d = dict()
    metadata_from_title_p_p_0.run(d)


# Generated at 2022-06-26 13:50:33.701139
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    try:
        raise TypeError()
    except TypeError:
        pass

if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:50:37.209519
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, None)
    dict_0 = {}
    dict_0['title'] = 'SamK,'

    MetadataFromTitlePP.run(metadata_from_title_p_p_0, dict_0)
    assert dict_0['title'] == 'SamK,'


# Generated at 2022-06-26 13:50:40.415372
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_1 = 'SamK,'
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_1, str_1)
    info_0 = {'title': str_1}
    value_0 = {}
    value_1 = metadata_from_title_p_p_1.run(info_0)
    assert (value_1[0] == value_0)
    assert (value_1[1] == info_0)


# Generated at 2022-06-26 13:50:48.203412
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'SamK,'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = '%(title)s - %(artist)s'
    str_2 = 'Test\ \-'
    list_0 = []
    dictionary_0 = {}
    dictionary_0['title'] = str_2
    tuple_0 = (list_0, dictionary_0)
    metadata_from_title_p_p_0.run(dictionary_0)

# Generated at 2022-06-26 13:50:50.398131
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.run(var_0)


# Generated at 2022-06-26 13:50:55.403560
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'ZT#q-Y#'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    bytes_0 = b''
    metadata_from_title_p_p_0.run(bytes_0)

if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:51:02.515043
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test case 0
    str_0 = 'SamK,'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    info_0 = {}
    info_0['title'] = 'Szalony Kolekcjoner - Super Mario Bros.'
    str_1 = '%(title)s - %(artist)s'
    str_2 = '(?P<title>.+) - (?P<artist>.+)'
    assert (metadata_from_title_p_p_0.format_to_regex(str_1) == str_2)
    list_0, dict_0 = metadata_from_title_p_p_0.run(info_0)
    assert (dict_0['title'] == 'Szalony Kolekcjoner')

# Generated at 2022-06-26 13:51:51.060952
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import Downloader
    from .extractor.common import InfoExtractor

    titleformat = '%(artist)s - %(title)s'
    title = 'SamK - Hello World'
    info = {'title': title}
    ydl = Downloader()
    ydl.add_info_extractor(InfoExtractor())
    ydl.add_post_processor(MetadataFromTitlePP(ydl, titleformat))
    results, info = ydl.process_ie_result(info, download=False)
    assert info['artist'] == 'SamK'
    assert info['title'] == 'Hello World'
    assert results == []

# Generated at 2022-06-26 13:51:55.258518
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'Samk'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    info = {
        'title': '',
        'uploader': 'Samk',
    }
    assert metadata_from_title_p_p_0.run(info) == ([], {
        'title': '',
        'uploader': 'Samk',
    })

# Generated at 2022-06-26 13:51:57.533884
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    assert_equal(expected, metadata_from_title_p_p_0.run(info))
    # AssertionError: The two objects are not equal



# Generated at 2022-06-26 13:51:59.824242
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    # Test case 0
    str_0 = 'SamK,'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    info_0 = {}
    metadata_from_title_p_p_0.run(info_0)


# Generated at 2022-06-26 13:52:00.842443
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # instantiated class MetadataFromTitlePP
    pass


# Generated at 2022-06-26 13:52:06.288888
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'SamK,'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_0 = {
        'title': '',
    }
    info_0 = {
        'title': '',
    }
    metadata_from_title_p_p_0.run(info_0)

if __name__ == '__main__':
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:52:12.010523
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # FIXME: temporary disabled
    return
    str_0 = 'SamK,'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.add_extra_info({'title': 'test'})
    assert metadata_from_title_p_p_0.run({'title': 'test', 'formats': ['720p']}) == ([], {'title': 'test', 'formats': ['720p']}), 'incorrect run of class MetadataFromTitlePP'

# Generated at 2022-06-26 13:52:19.793139
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(asciititle)s%(upload_date)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.format_to_regex('%(asciititle)s%(upload_date)s')
    str_1 = '%(title)s'
    dict_0 = {'title': 'SamK,'}
    metadata_from_title_p_p_0.run(dict_0)
    str_2 = '%- %('
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_2, str_2)
    metadata_from_title_p_p_0.format_to_regex(str_2)


# Generated at 2022-06-26 13:52:24.955043
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP('SamK,', str_0)
    dict_0 = {'artist': None, 'title': 'test video'}
    assert(metadata_from_title_p_p_0.run(dict_0) == [(None, None, None)])


"""Unit test for module, to run enter 'python -m test.test_MetadataFromTitlePP' in console."""
if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:52:30.742472
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    __DUMMY_DOWNLOADER__ = None
    __DUMMY_INFO__ = {'title': 'SamK, - JohnDoe'}
    __DUMMY_RESULT__ = ([], {'title': 'SamK, - JohnDoe', 'artist': 'JohnDoe'})

    test = MetadataFromTitlePP(__DUMMY_DOWNLOADER__, '%(artist)s - %(title)s')

    output = test.run(__DUMMY_INFO__)
    assert output == __DUMMY_RESULT__