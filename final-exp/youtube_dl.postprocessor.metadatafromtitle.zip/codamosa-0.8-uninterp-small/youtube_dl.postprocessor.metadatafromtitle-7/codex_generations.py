

# Generated at 2022-06-26 13:44:05.856048
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    string_0 = '[fromtitle] Could not interpret title of video as "%s"'
    string_2 = '[fromtitle] parsed %s: %s'
    string_0 = b'\xa0\x9b\x06\xdd\xdb\xfa\xcdx\xc8\xd5\xc6\x1d\x0b\x16f\xeb\xdd\xee\xbb\xc8o\xa6'
    string_1 = '\x03\x90\xfb\x93\xee\xed\xb2\xbe\xd5\x9d\x85\x8c\xdd\x89\x88\x06\x8d\xed\x9a\x9b'

# Generated at 2022-06-26 13:44:08.671739
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    param_0 = {}
    metadata_from_title_p_p_0 = MetadataFromTitlePP(arguments, '%(title)s')
    var_0 = metadata_from_title_p_p_0.run(param_0)

# Generated at 2022-06-26 13:44:20.960491
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_1 = '\x95\xfc\x91\xbf\xb8\x9f\xed\t\xf2\x96\x84\x88\xcc\x1e\xd1\x85\xb0\x01\xb7'

# Generated at 2022-06-26 13:44:23.098075
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    assert callable(MetadataFromTitlePP)


# Generated at 2022-06-26 13:44:32.940965
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .compat import compat_urllib_request
    from .compat import compat_urllib_error
    import io
    import json
    import shutil
    import sys
    import tempfile
    import unittest

    # Test variables
    temp_dir = tempfile.mkdtemp(suffix='-test_MetadataFromTitlePP_run')
    temp_file = tempfile.NamedTemporaryFile(mode='wb', dir=temp_dir)
    temp_filename = temp_file.name

    try:
        assert not os.path.exists(temp_filename)

    except AssertionError:
        raise AssertionError
    finally:
        assert os.path.exists(temp_filename)

        # Test data

# Generated at 2022-06-26 13:44:37.091400
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Disabled, still unfinished
    return
    # TODO: examples and testing
    test_case_0()


if __name__ == '__main__':
    test_MetadataFromTitlePP()

# Generated at 2022-06-26 13:44:39.908694
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert callable(getattr(MetadataFromTitlePP, "run", None))

    # Call test_case_0
    test_case_0()


# Generated at 2022-06-26 13:44:47.268344
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test case for invalid input
    str_0 = '3b1{IQM]d:nfKleL ='
    bytes_0 = b'\x8fVTR\x92\xb4r\xc2\xd7\x93JE\x1c\xa3\x99\xefS\xc8'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, bytes_0)
    exception_0 = None
    try:
        metadata_from_title_p_p_0.run({bytes_0: str_0})
    except Exception as exception_0:
        pass


# Generated at 2022-06-26 13:44:58.503364
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'His Majesty\'s Secret Service'
    str_1 = '\xfe\\'
    str_2 = '\\jK'
    bytes_0 = b'\x00\x04ff\x12\xdb\x82\x1d\r\x82\x1a\x9a'
    bytes_1 = b'\xbf\x1a\x8d\x08\x04\xd3\x9d\x11\xea\x82\x92a\xbd'
    bytes_2 = b'\x06\x9d\x8c\x15\xd4\x0f\xaf\xa7\x9d\x82\x9d\x1c'

# Generated at 2022-06-26 13:45:00.557519
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()


if __name__ == '__main__':
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:45:04.290745
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    x = MetadataFromTitlePP(None, None)
    assert x.run(None) == ([], None)


# Generated at 2022-06-26 13:45:14.116017
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # TODO: move this test to test.py
    return
    titleformat = test_case_0()
    video = test_case_0()
    assert(re.match(MetadataFromTitlePP.format_to_regex(titleformat), video) is not None)

    titleformat = test_case_0()
    regex = r'ùÝÓ\x96\x92ÀÖ\x92\x91\x97\x92\x9eO\x1fû\x89>\x02\x1d\x8dÖ\x8d\x9f\x01'
    assert(MetadataFromTitlePP.format_to_regex(titleformat) == regex)

if __name__ == '__main__':
    test_MetadataFromTitlePP()

# Generated at 2022-06-26 13:45:18.829751
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # string(string, string)

    # Test for Test Class have no exception
    Test_0 = MetadataFromTitlePP(None, '')
    Test_1 = MetadataFromTitlePP(None, str_0)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 13:45:19.875438
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    assert true


# Generated at 2022-06-26 13:45:27.830907
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():

    ts = MetadataFromTitlePP()
    assert ts.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)', 'Test case failed.'
    assert ts.format_to_regex('%(title)s') == '(?P<title>.+)', 'Test case failed.'
    assert ts.format_to_regex('%(title)s - %(artist)s - %(album)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)', 'Test case failed.'
    return 'test_MetadataFromTitlePP_format_to_regex completed.'

testcases = [test_MetadataFromTitlePP_format_to_regex]

# Generated at 2022-06-26 13:45:29.286097
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    a = MetadataFromTitlePP(downloader, titleformat)
    return (a)



# Generated at 2022-06-26 13:45:35.348774
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    titleformat = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(None, titleformat)
    if pp.format_to_regex(titleformat) != '(?P<title>.+)\ \-\ (?P<artist>.+)':
        return False
    title = 'title - artist'
    info = {'title': title}
    pp.run(info)
    if info['artist'] != 'artist':
        return False
    if info['title'] != 'title':
        return False
    return True

if __name__ == "__main__":
    if test_MetadataFromTitlePP_run():
        print('ok')
    else:
        print('ko')

# Generated at 2022-06-26 13:45:36.254515
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex(): pass  # dummy method


# Generated at 2022-06-26 13:45:44.718316
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '\x95ü\x91¿¸\x9fí\tò\x96\x84\x88Ì\x1eÑ\x85°\x01·'
    str_1 = '\x99ë\x89ü\x95\x8e\x8d\x96\x80\x9f\x8e\x01ë\x95n'
    str_2 = '\x95ü\x91¿¸\x9fí\tò\x96\x84\x88Ì\x1eÑ\x85°\x01·'


# Generated at 2022-06-26 13:45:51.558018
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    info = {'title': 'Test Title - Test Artist'}
    titleformat = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(None, titleformat)
    assert pp._titleformat == titleformat
    assert pp._titleregex == 'Test\ Title\ -\ Test\ Artist'
    pp.run(info)
    assert info['title'] == 'Test Title'
    assert info['artist'] == 'Test Artist'

# Generated at 2022-06-26 13:46:00.337682
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    str_0 = 'JDOq{_<,1=?\x0b>DGFXVb'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, str_0)
    dict_0 = {'title': '_eMW_)d9\\M~\x15M\\w\x08\x00\\'}
    metadata_from_title_p_p_0.run(dict_0)
    pass

# Generated at 2022-06-26 13:46:04.836150
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = True
    str_0 = 'y@P9gExJQ`jd.G/Hj$0}!=o!H%m\tL;Q8V+W&'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, str_0)
    dict_0 = {}
    dict_0['title'] = '3dsD#2U@+(6j+f6Y\rBDyRl6e}r'
    dict_1, dict_2 = metadata_from_title_p_p_0.run(dict_0)

# Generated at 2022-06-26 13:46:05.404080
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass

# Generated at 2022-06-26 13:46:10.869144
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert True
    # bool_0 = False
    # str_0 = 'JDOq{_<,1=?\x0b>DGFXVb'
    # metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, str_0)


# Generated at 2022-06-26 13:46:14.629686
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    str_0 = 'LxW#n\x1bAft>SE<:JX8W'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, str_0)


# Generated at 2022-06-26 13:46:16.807665
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, None)
    metadata_from_title_p_p_0.run(dict())


# Generated at 2022-06-26 13:46:19.210940
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert True == True
    pass


if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:46:27.349961
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    str_0 = '\x0cH.Yv,9g\x1aZ\x1c<\x1b0S\x1a\x18\x18\x0cD6\x0f\x1c<,86\x0b?S\x12\x08\x18\x0b;4\x0f\x1c<,8,?D\x02\x0c\x0e'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, str_0)
    str_1 = '(?P<artist>.+)'
    str_2 = '(?P<title>.+)'
    metadata_from_title_p_p_0._titleregex = str_2

# Generated at 2022-06-26 13:46:33.232364
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = True
    str_0 = 'M)8*P;\n&=\'+1XS)5'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, str_0)
    info_0 = {}
    metadata_from_title_p_p_0.run(info_0)


if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:46:37.268187
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, '%(title)s')
    info = {'title': ''}
    metadata_from_title_p_p_1 = metadata_from_title_p_p_0.run(info)


# Generated at 2022-06-26 13:46:49.227352
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    args_0 = {}
    args_0['title'] = 'BQADBAADIwEAAl7LXQABPHHWZBhPeRQI'
    bool_0 = False
    str_0 = '%(id)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, str_0)
    args_1 = []
    return_value_0 = metadata_from_title_p_p_0.run(args_0)
    assert return_value_0 == (args_1, {'id': 'BQADBAADIwEAAl7LXQABPHHWZBhPeRQI'})


# Generated at 2022-06-26 13:46:51.040501
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    str_0 = 'JDOq{_<,1=?\x0b>DGFXVb'
    dict_0 = None
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, str_0)
    metadata_from_title_p_p_0.run(dict_0)

# Generated at 2022-06-26 13:46:57.348979
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    str_0 = 'JDOq{_<,1=?\x0b>DGFXVb'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, str_0)
    str_0 = 'JDOq{_<,1=?\x0b>DGFXVb'
    dict_0 = {'title': str_0}
    metadata_from_title_p_p_0.run(dict_0)
    assert str_0 == 'JDOq{_<,1=?\x0b>DGFXVb'
    assert dict_0 == {'title': str_0}


# Generated at 2022-06-26 13:47:01.631002
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    fmt = '[fromtitle] parsed %s: %s'
    title = 'Русский текст'
    expected = '[fromtitle] parsed title: Русский текст'
    assert fmt % ('title', title) == expected

# Generated at 2022-06-26 13:47:06.557393
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = True
    str_0 = './MediaDownloader.py -l'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, str_0)
    bool_0 = False
    list_0 = []
    metadata_from_title_p_p_0.run(list_0)

test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:47:15.981664
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    str_0 = '`YVirse>%\x1dfZc'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, str_0)
    dict_0 = {'upload_date': '20170809', 'id': 'de2tA0NtH_4', 'age_limit': 0, 'duration': '0:00', 'categories': ['Entertainment'], 'uploader': 'T-Series', 'title': None}
    list_0 = metadata_from_title_p_p_0.run(dict_0)
    # assert len(list_0) == 0
    # assert dict_0 == {'upload_date': '20170809', 'id': 'de2tA0NtH_4', 'age_limit

# Generated at 2022-06-26 13:47:26.263867
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from common import FakeYDL
    ydl = FakeYDL()
    metadata_from_title_p_p = MetadataFromTitlePP(ydl, '%(title)s')

    # test an invalid title
    info = {}
    info['title'] = 'this is a title'
    expected_info = {}
    expected_info['title'] = 'this is a title'

    processed_info, processed_info = metadata_from_title_p_p.run(info)
    assert processed_info == expected_info
    assert processed_info == expected_info

    # test a valid title
    info = {}
    info['title'] = 'here is the title'
    expected_info = {}
    expected_info['title'] = 'here is the title'

    processed_info, processed_info = metadata_from_title_p

# Generated at 2022-06-26 13:47:35.455944
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    str_0 = 'y'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, str_0)
    dict_0 = {'<': 'c%', 'f': '\x1b'}
    dict_0['<'] = '\x11\rX\x05\x1d\x16\x02\x1a\x1e'
    dict_0['h'] = '\t\x1b\x02/\x0eo\x1a\x04\x01'
    dict_0['\x1c'] = '\x14\x06\x07\x0fP\x03\x13\x16'

# Generated at 2022-06-26 13:47:37.892802
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'u'
    dict_0 = dict()
    dict_0['title'] = str_0
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, None)
    list_0 = metadata_from_title_p_p_0.run(dict_0)
    assert list_0 == ([], dict_0)

# Generated at 2022-06-26 13:47:42.626089
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    str_0 = 'The+%(artist)s+-+%(title)s+%(year)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, str_0)
    metadata_from_title_p_p_0.run(dict())


if __name__ == '__main__':
    for test in (test_case_0, test_MetadataFromTitlePP_run):
        test()

# Generated at 2022-06-26 13:47:58.850871
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, None)
    dict_0 = dict()
    dict_0['title'] = 'U6AnTlzofvo'
    format_to_regex_0 = metadata_from_title_p_p_0.format_to_regex(0)
    list_0, dict_1 = metadata_from_title_p_p_0.run(dict_0)
    format_to_regex_1 = metadata_from_title_p_p_0.format_to_regex(0)
    list_0, dict_1 = metadata_from_title_p_p_0.run(dict_0)
    list_0, dict_1 = metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:48:06.200938
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-26 13:48:18.370860
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = True
    str_0 = '\x7f'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, str_0)
    dict_0 = {}
    dict_0['title'] = 'Vz8uUP]{n-7UwNW6Ux;s%|'
    dict_0['artist'] = 'h_X-Rz]j~\x1a\x18\x1d\x19\x05\x01\x0c\x18\x06\x1b\x11\x1f\x04\x16'

# Generated at 2022-06-26 13:48:25.788576
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor import YoutubeIE
    
    titleformat = "%(artist)s - %(title)s"
    ydl = FileDownloader({})
    pp = MetadataFromTitlePP(ydl, titleformat)
    assert(pp.format_to_regex(titleformat) == '(?P<artist>.+)\ \-\ (?P<title>.+)')
    ydl.add_info_extractor(YoutubeIE())

    info = {'title': 'Test'}
    pp.run(info)
    assert(info['artist'] is None)
    assert(info['title'] == 'Test')

    info = {'title': 'Ray Charles - Hit the Road Jack'}
    pp.run(info)
    assert(info['artist'] == 'Ray Charles')

# Generated at 2022-06-26 13:48:33.707883
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    str_0 = '5#|$5#|$5#|$5#|$5#|$'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, str_0)
    dict_0 = {}
    actual_result = metadata_from_title_p_p_0.run(dict_0)
    expected_result = []
    assert actual_result == expected_result


if __name__ == '__main__':
    test_case_0() 
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:48:35.878579
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    return


if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:48:40.642119
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = True
    str_0 = 'L6\x15F\n\x11'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, str_0)
    dict_0 = dict()
    dict_0['title'] = '51H\x01\r#=\r\r\x00M'
    metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:48:45.107744
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    str_0 = 'E#><\x0b?bFwgokWc^v@nn'
    list_0 = []
    dict_0 = {}
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, str_0)
    # TODO: Create a dict and append it to list_0
    metadata_from_title_p_p_0.run(list_0)


# Generated at 2022-06-26 13:48:51.084993
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    str_0 = 'JDOq{_<,1=?\x0b>DGFXVb'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, str_0)
    str_0 = 'r2O8bwz)\x1a\x7f?\x14lV\x0fY%\x7f}o6U'
    dict_0 = {'title': '', 'artist': 'o6U'}
    list_0 = []
    assert ((metadata_from_title_p_p_0.run(dict_0) == (list_0, dict_0)),
            'AssertionError : 10')

# Generated at 2022-06-26 13:48:57.604615
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'mqd5D5fkG0;[=\x14`%\x02B\x0b'
    # assert test_MetadataFromTitlePP_run
    dict_0 = dict()
    dict_0['title'] = 'hello world'

    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, '%(title)s')
    (lst_0, dict_1) = metadata_from_title_p_p_0.run(dict_0)

test_case_0()
test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:49:19.200724
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    str_0 = 'JDOq{_<,1=?\x0b>DGFXVb'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, str_0)

    str_1 = 'U\x1b+f#\x7f%\x02\xa6\x05\x0f\x16\x1b\x1f'
    str_2 = '\x16\x13\x06\x08PI{\x14\nf\x06\x08\x16'
    bool_1 = False
    dict_0 = {}
    dict_0['title'] = str_1
    dict_0['id'] = str_2
    list_0 = []
    list_1 = metadata_from_title

# Generated at 2022-06-26 13:49:23.118782
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = True
    str_0 = '\x1d\x1c'
    dict_0 = dict()
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, str_0)
    list_0 = list()
    metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:49:28.192229
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    str_0 = 'Kj#,G<q3t)5(jhS1t{'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, str_0)
    dict_0 = {}
    list_0 = []
    metadata_from_title_p_p_0.run(list_0, dict_0)


# Generated at 2022-06-26 13:49:35.235707
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    str_0 = 'JDOq{_<,1=?\x0b>DGFXVb'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, str_0)
    dict_0 = {'title': 'F!rE\x0c\\\x03\r@\x02^]\x0f\x1e'}
    metadata_from_title_p_p_0.run(dict_0)

test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:49:36.385109
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert True


# Generated at 2022-06-26 13:49:45.907304
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    str_0 = 'Yd-5)5@-3wIzC(Z}SKfM'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, str_0)
    metadata_from_title_p_p_0.run('Yd-5)5@-3wIzC(Z}SKfM')

if __name__ == '__main__':
    from cmstestsuite.test_case import TestCase
    from cmstestsuite.test_list import TestList
    from cmstestsuite.test_tools import get_error_info

    test_list = TestList()

    test_list.add_test_case(TestCase('test_case_0', test_case_0))

# Generated at 2022-06-26 13:49:51.284961
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'P'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_0 = '-L'
    bool_0 = False
    dict_0 = dict()
    dict_0.setdefault('title', bool_0)
    metadata_from_title_p_p_0.run(dict_0)

# Generated at 2022-06-26 13:50:02.449222
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    str_0 = '\tH]j*"]O;<\x0byD\x05'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, str_0)
    str_1 = 'VQ,:\x1c'
    str_2 = 'C"F"P\x19[5\x1eq\x1b'
    str_3 = '\rP\r'

# Generated at 2022-06-26 13:50:07.874772
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # test_case_0()

    titleformat = '%(artist)s - %(title)s'
    mft = MetadataFromTitlePP(None, titleformat)
    assert mft._titleregex == r'(?P<artist>.+)\ \-\ (?P<title>.+)'

    title = 'Metallica - Nothing Else Matters'
    info = {'title': title}
    _, info = mft.run(info)
    assert info['artist'] == 'Metallica'

# Generated at 2022-06-26 13:50:11.812446
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Initialization of input variables
    metadata_from_title_p_p_0 = MetadataFromTitlePP
    info_0 = ''
    # Call of method run of class MetadataFromTitlePP
    result_0, result_1 = metadata_from_title_p_p_0.run(info_0)

# Generated at 2022-06-26 13:50:36.764607
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    # Arrange
    title = "xxxxx%(uploader)sxxxxxxx"
    titleformat = "%(uploader)s"
    pp = MetadataFromTitlePP(None, titleformat)

    expected = {'title': 'xxxxx%(uploader)sxxxxxxx', 'uploader': 'yyyyy'}

    # Act
    result = pp.run({'title': title, 'uploader': 'yyyyy'})

    # Assert
    assert result == ([], expected)


# Generated at 2022-06-26 13:50:39.820613
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP()
    dict_0 = {}
    dict_0 = metadata_from_title_p_p_0.run(dict_0)
    assert dict_0 == {'title': ''}


# Generated at 2022-06-26 13:50:46.532705
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(True, "A great video - Joe")
    dict_0 = {'title': "A great video - Joe"}
    dict_1 = dict()
    dict_0.update(dict_1)
    list_0, dict_3 = metadata_from_title_p_p_0.run(dict_0)
    assert dict_3 == {'title': 'A great video - Joe', 'artist': 'Joe'}

# Generated at 2022-06-26 13:50:55.291863
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    str_0 = 'JDOq{_<,1=?\x0b>DGFXVb'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, str_0)
    dict_0 = dict()
    dict_0['title'] = '&8Ww-!F***@wlKd'
    dict_0['thumbnail'] = '},K>*t0-H!o4wzg(il'
    dict_0['id'] = 'S7;)P<,C\t?M|>faY'
    dict_0['age_limit'] = 7
    dict_0['license'] = 'SPI-L'

# Generated at 2022-06-26 13:51:02.203142
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = True
    str_0 = '_n,w8&>R+I2n\x17'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, str_0)
    str_1 = '_n,w8&>R+I2n\x17'
    int_0 = 64
    list_0 = []
    for i in range(0, int_0):
        list_0.append('p16y4')
    map_0 = {}
    for i in range(0, int_0):
        map_0[list_0[i]] = list_0[i]
    metadata_from_title_p_p_0.run(map_0)
    

# Generated at 2022-06-26 13:51:09.467041
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    str_0 = 'JDOq{_<,1=?\x0b>DGFXVb'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, str_0)
    info_0 = {}
    str_1 = 'eiXymjmeE>|\r'
    info_0['title'] = str_1
    info_0['artist'] = str_1
    bool_1 = bool_0
    list_0 = []
    if bool_1:
        list_0.append(info_0)
    else:
        list_0.append(str_1)
    (list_1, dict_0) = metadata_from_title_p_p_0.run(info_0)

# Generated at 2022-06-26 13:51:10.811284
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 13:51:15.615549
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    str_0 = 'Uiyd6U\x7f9[\x7f\x1aH'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, str_0)
# ValueError: MetadataFromTitlePP: invalid value for titleformat: 'Uiyd6U\x7f9[\x7f\x1aH'


# Generated at 2022-06-26 13:51:16.385316
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()
    return None

# Generated at 2022-06-26 13:51:24.282463
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    var_0 = 'zjGLZ\x7fj\x17\x1c\x0b\x06\x07\x0c\x1d\x1e\x1f\x1c\x1b\x1c\n\x0c'
    var_1 = '1@Jb_?j]V7c\x0e~V\x13\x07\x0f\x1f>#\x1e\x1a\x1a\r\x0f\x0e\x06'
    var_2 = {'title': '#3: Mr. Death', 'duration': 159, 'filesize': '1.25M', 'upload_date': '20110121'}

# Generated at 2022-06-26 13:52:30.342508
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(False, 'JDOq{_<,1=?\x0b>DGFXVb')

# Generated at 2022-06-26 13:52:36.949548
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    str_0 = 'JDOq{_<,1=?\x0b>DGFXVb'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, str_0)
    dict_0 = {'title': 'title', 'format': 'format',
              '_filename': 'filename'}
    tuple_0 = (['title', 'format', 'filename'], {'title': 'title',
               'format': 'format', '_filename': 'filename'})
    assert metadata_from_title_p_p_0.run(dict_0) == tuple_0

# Generated at 2022-06-26 13:52:38.153795
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert True

# Generated at 2022-06-26 13:52:39.149562
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert callable(MetadataFromTitlePP.run)

# Generated at 2022-06-26 13:52:45.834281
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    str_0 = 'JDOq{_<,1=?\x0b>DGFXVb'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, str_0)
    initialized_ordered_dict_0 = {'format': str_0, 'n_entries': 2839, 
                                  'title': '*kDxO&O!_W#Ke8*Q%F+E'}
    metadata_from_title_p_p_0.run(initialized_ordered_dict_0)


# Generated at 2022-06-26 13:52:52.557867
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = True
    str_0 = 'dC!Q;O-qgC~WAywNO|\x7f>hN%'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, str_0)
    metadata_from_title_p_p_0._titleformat = 'NA'
    metadata_from_title_p_p_0._titleregex = ('NA' if re.search('%\(\w+\)s', 'NA') else 'NA')
    map_0 = {}
    map_0['title'] = 'NA'
    tuple_0 = (metadata_from_title_p_p_0.run(map_0), map_0)

# Generated at 2022-06-26 13:53:02.498171
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = True
    str_0 = '\x1bGd\x07\x00\x01\x1d\x0c\x0e\x1f\x1d\x0e\x12\x1b\x0d\x0e\x1f\x1b\x0f\x1b\x0c\x0f\x19\x1b\x07\x0f\x0e\x1d\x1b\x0c\x1d\x19\x0c\x0f\x1e\x1d'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, str_0)
    metadata_from_title_p_p_1 = metadata_from_title_p_p_0


# Generated at 2022-06-26 13:53:08.959074
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = True

# Generated at 2022-06-26 13:53:13.753165
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    str_0 = 'JDOq{_<,1=?\x0b>DGFXVb'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, str_0)
    dict_0 = {'title': 'T'}
    list_0 = []
    list_1 = metadata_from_title_p_p_0.run(dict_0)
    assert list_1 == (list_0, dict_0)


# Generated at 2022-06-26 13:53:16.610137
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = None
    info_0 = None
    i_0 = metadata_from_title_p_p_0.run(info_0)
    assert i_0 == ([], {})