

# Generated at 2022-06-26 13:44:02.031294
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    int_0 = 1983
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, int_0)
    metadata_from_title_p_p_0._titleformat = '%(year)s'
    metadata_from_title_p_p_0.format_to_regex(metadata_from_title_p_p_0._titleformat)
    metadata_from_title_p_p_0.run(metadata_from_title_p_p_0._titleregex)

# Generated at 2022-06-26 13:44:10.465522
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    m_f_t_p_p_0 = MetadataFromTitlePP(True, True)
    dict_0 = {}
    dict_1 = {}
    dict_0['title'] = 'the title'
    m_f_t_p_p_0._titleformat = '%(title)s - %(artist)s'
    m_f_t_p_p_0.format_to_regex(m_f_t_p_p_0._titleformat)
    m_f_t_p_p_0._titleregex = r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    list_0, dict_1 = m_f_t_p_p_0.run(dict_0)
    # Should return a dictionary with title, artist and url as keys


# Generated at 2022-06-26 13:44:21.478319
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Note that this test function is not affected by the changes made to method
    # MetadataFromTitlePP.format_to_regex. Those changes are only covered in
    # test_case_2.
    bool_0 = False
    int_0 = 1983
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, int_0)
    dict_0 = {}
    list_0 = []
    dict_1 = metadata_from_title_p_p_0.run(dict_0)
    assert dict_1 is not None
    # Verifying that list_0 == dict_1[0]
    assert list_0 == dict_1[0]
    # Verifying that dict_0 is dict_1[1]
    assert dict_0 is dict_1[1]



# Generated at 2022-06-26 13:44:32.466714
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    bool_0 = False
    int_0 = 1983
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, int_0)
    string_0 = "ABC"
    string_1 = "[0-9][ABC]"
    string_2 = "(?P<title>[0-9][ABC])"
    string_3 = "A-Z"
    string_4 = "A-Z"
    string_5 = "(?P<title>A-Z)"
    assert(metadata_from_title_p_p_0.format_to_regex(string_0) == string_1)
    assert(metadata_from_title_p_p_0.format_to_regex(string_2) == string_3)

# Generated at 2022-06-26 13:44:35.810292
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    int_0 = 1983
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, int_0)

    assert(metadata_from_title_p_p_0.run({}) == ([], {}))

# Generated at 2022-06-26 13:44:40.489330
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    int_0 = 1983
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, int_0)
    assert_equal(metadata_from_title_p_p_0.run(bool_0), ([], bool_0))


# Generated at 2022-06-26 13:44:44.514118
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    str_0 = '%(song)s'
    test_case_0()
    # Test case for regex %(..)s format
    # Test case for normal format
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
# Test method for run of class MetadataFromTitlePP

# Generated at 2022-06-26 13:44:49.145032
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    str_0 = '%(title)s - %(artist)s'
    regex = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, None)
    assert regex == metadata_from_title_p_p_0.format_to_regex(str_0)

# Generated at 2022-06-26 13:45:00.012887
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    int_0 = 1983
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, int_0)
    metadata_0 = {
        'title': 'fucking title',
        'artist': 'fucking artist'
    }
    bool_0, metadata_0 = metadata_from_title_p_p_0.run(metadata_0)
    assert bool_0 is False, "'bool_0' should be 'False' but is '%s'" % bool_0
    assert metadata_0['title'] == 'fucking title', "'metadata_0['title']' should be '%s' but is '%s'" % (
             'fucking title', metadata_0['title'])

# Generated at 2022-06-26 13:45:07.095949
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    print("MetadataFromTitlePP_format_to_regex")
    metadata_from_title_p_p_0 = MetadataFromTitlePP(
        False, '%(title)s - %(artist)s')
    assert metadata_from_title_p_p_0.format_to_regex(
        '%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(
        False, 'foo_%(title)s_baz - %(artist)s')

# Generated at 2022-06-26 13:45:14.818619
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # setUp
    titleformat_0 = '%(song)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(titleformat_0, titleformat_0)
    info = {'title': 'Song title'}
    #Method run has not been mocked. Call to run of MetadataFromTitlePP not performed
    #assert_equal([], metadata_from_title_p_p_0.run(info))

# Generated at 2022-06-26 13:45:21.449114
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP('titleformat', 'titleformat')
    info_0 = {}
    metadata_from_title_p_p_0.run(info_0)

    assert_equals(info_0['titleformat'], 'titleformat')
    #self._downloader.to_screen('[fromtitle] parsed %s: %s' % (attribute, value if value is not None else 'NA'))


# Generated at 2022-06-26 13:45:29.400397
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(song)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = 'song'
    dict_0 = {str_1: str_1}
    list_0 = []
    list_1 = metadata_from_title_p_p_0.run(dict_0)
    str_2 = 'song'
    assert list_0 == list_1, 'AssertionError'
    str_3 = '[fromtitle] parsed %s: %s'
    # str_4 = str_3 % (str_1, str_1 if str_1 is not None else 'NA')
    # XXX no idea why this doesn't work
    # assert list_0 == list_1, 'AssertionError'



# Generated at 2022-06-26 13:45:36.119128
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    title = 'Love song'
    info = {'title': title, '_filename': 'Love song'}

# Generated at 2022-06-26 13:45:40.303092
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = ''
    map_0 = {}
    
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    tuple_0 = metadata_from_title_p_p_0.run(map_0)



# Generated at 2022-06-26 13:45:48.041799
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(song)s'
    str_1 = '%(album)s'
    str_2 = 'test_value'
    list_0 = []
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_1)
    dict_0 = {'song': str_2}
    metadata_from_title_p_p_0.run(dict_0)
    assert(dict_0['song'] == str_2)
    return 'success'


# Generated at 2022-06-26 13:45:48.967312
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()

if __name__ == '__main__':
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:45:50.388353
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert_equals()


# Generated at 2022-06-26 13:45:52.619136
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert True == False, "Unit test for method run of class MetadataFromTitlePP failed"



# Generated at 2022-06-26 13:45:56.851760
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(song)s'
    dict_0 = dict(song='song')
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.run(dict_0)



# Generated at 2022-06-26 13:46:06.103962
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '\'%(title)s\''
    str_1 = '\t(sgs'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_1, str_0)
    str_2 = '\t(sgs'
    dict_0 = {'title': str_2}
    metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:46:16.848495
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '\t(sgs'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = '\t(sgs'
    int_0 = 10
    str_2 = str_1 * int_0
    dict_0 = {str_1: str_2}
    str_3 = '\t(sgs'
    dict_1 = {str_1: dict_0, str_1: dict_0, str_3: str_2}
    str_4 = '\t(sgs'
    tuple_0 = (str_4,)
    str_5 = '\t(sgs'
    dict_2 = {str_5: dict_1}

# Generated at 2022-06-26 13:46:25.610504
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = ''
    str_1 = 'temp/'

# Generated at 2022-06-26 13:46:35.690152
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '\t(sgs'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = '\t(sgs'
    dict_0 = {
        '\t(sgs': (
        str_1, str_0, ), }
    metadata_from_title_p_p_0._titleregex = str_0
    metadata_from_title_p_p_0._titleformat = str_1
    assert metadata_from_title_p_p_0.format_to_regex(str_1) == str_0
    str_2 = '\t(sgs'

# Generated at 2022-06-26 13:46:38.980742
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '\t(sgs'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = '\t(sgs'
    metadata_from_title_p_p_0.run(str_1)


# Generated at 2022-06-26 13:46:49.635658
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    _str_0 = '\t(sgs'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(_str_0, _str_0)
    assert ('%(title)s' ==
            metadata_from_title_p_p_0.format_to_regex('%(title)s')), 'expected %(title)s, got %(title)s'
    assert ('(?P<title>.+)' ==
            metadata_from_title_p_p_0.format_to_regex('%(title)s')), 'expected "(?P<title>.+)", got "(?P<title>.+)"'

# Generated at 2022-06-26 13:46:52.777791
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'This is the title'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)

if __name__ == "__main__":
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:46:59.178727
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    print("Testing run...")

    # Populate values needed to instantiate a MetadataFromTitlePP
    # instance
    str_0 = '\t(sgs'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)

    # Create a dictionary object from a list object
    dict_0 = dict(zip(["a", "b"], [1, 2]))

    # Precondition: dictionary object should not contain key "a"
    if "a" not in dict_0:
        print("PASS: Precondition successful")
    else:
        raise Exception('Precondition failed.')

    # Expected result: key "a" set to 1
    metadata_from_title_p_p_0.run(dict_0)
    expected_result = 1

# Generated at 2022-06-26 13:47:03.901030
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, '%(artist)s')
    assert (metadata_from_title_p_p_0.run({'title': '%(artist)s'}) == ([], {'artist': '%(artist)s', 'title': '%(artist)s'}))

# Generated at 2022-06-26 13:47:08.340320
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '\t(sgs'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)

    str_1 = ''
    dict_0 = dict(title=str_1)
    metadata_from_title_p_p_0.run(dict_0)

# Generated at 2022-06-26 13:47:15.512754
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s.%(ext)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_0 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)


if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:47:19.872592
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    title_0 = 'Vorlesungen ueber Zahlentheorie - Teil 01'
    fmt_0 = '%(title)s'
    downloader_0 = None
    metadata_from_title_p_p_0 = MetadataFromTitlePP(downloader_0, fmt_0)
    assert metadata_from_title_p_p_0._titleformat == fmt_0
    assert metadata_from_title_p_p_0._titleregex == '(?P<title>.+)'
    info_0 = {'title': title_0}
    test_case_helper_0(metadata_from_title_p_p_0, info_0)


# Generated at 2022-06-26 13:47:23.295849
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.run('\t(sgs')

# Generated at 2022-06-26 13:47:24.104349
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
  assert True == True


# Generated at 2022-06-26 13:47:29.788281
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = '%(title)s - %(artist)s'
    dict_0 = {'title': str_1}
    metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:47:38.619098
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '\t(sgs'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    # ydl object not initialised
    # Values used for assertion
    str_1 = '\t(sgs'
    str_2 = '\t(sgs'
    str_3 = ''
    str_4 = ''
    tuple_0 = (str_1, str_2, str_3, str_4)
    # Call to run
    # AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: Ass

# Generated at 2022-06-26 13:47:43.657671
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '[fromtitle] parsed %s: %s'
    str_1 = 'title: sgs'
    str_2 = 'artist: NA'
    str_3 = 'title'
    str_4 = 'NA'
    str_5 = 'artist'
    str_6 = 'NA'
    str_7 = '\t(sgs'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_7, str_7)
    map_0 = {str_3: str_1, str_5: str_4}
    metadata_from_title_p_p_0._downloader.to_screen = lambda *args: None
    list_0 = []
    metadata_from_title_p_p_0.run(map_0)

# Generated at 2022-06-26 13:47:50.185771
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '\t(sgs'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = '\t(sgs'
    # Test case for method run of class MetadataFromTitlePP
    # Test case for a method run of class MetadataFromTitlePP
    metadata_from_title_p_p_0.run(str_1)

test_case_0()
test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:47:55.393765
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '\t(sgs'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    int_0 = metadata_from_title_p_p_0.run(str_0)
    if int_0 == True:
        print("Test Case 0 Passed")
    else:
        print("Test Case 0 Failed")


# Generated at 2022-06-26 13:48:04.584670
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    # Initialization of MetadataFromTitlePP object
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)

    # Call method run
    metadata_from_title_p_p_0.run(str_0)


if __name__ == "__main__":
    import sys
    import doctest

    class DummyDownloader(object):
        def __init__(self, *args):
            self.args = args
        def to_screen(self, msg):
            print(msg)

    def run_doctest():
        import doctest
        doctest.testmod(sys.modules[__name__])


# Generated at 2022-06-26 13:48:18.902988
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # [1]
    # str_0, str_1, str_2, dict_0, dict_1, str_3, str_4, list_0, dict_2, dict_3
    str_0 = '\t(sgs'
    str_1 = 'title'
    str_2 = '%(title)s - %(artist)s'
    dict_0 = {
        'title': str_0,
        'artist': '',
    }
    dict_1 = {
        '\t(sgs': '',
    }
    str_3 = 'title'
    str_4 = '\t(sgs'
    list_0 = []
    dict_2 = {
        '\t(sgs': '',
        'title': '',
        'artist': '',
    }

# Generated at 2022-06-26 13:48:21.497241
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP('', '\t(sgs')
    assert metadata_from_title_p_p_0.run(['title']) == ([], ['title'])


# Generated at 2022-06-26 13:48:23.963431
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Input Parameters.
    # info - Metadata passed to the plugin.
    # Expected Result.
    # Nothing.
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, '')
    metadata_from_title_p_p_0.run({'title': None})



# Generated at 2022-06-26 13:48:26.493966
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '\t(sgs'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)


# Generated at 2022-06-26 13:48:36.408276
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Check if the metadata is present.
    metadata_from_title_p_p = MetadataFromTitlePP('01:23:45', dict())
    assert isinstance(metadata_from_title_p_p, MetadataFromTitlePP,
                      'metadata_from_title_p_p is not an instance of MetadataFromTitlePP')
    # AssertionError: metadata_from_title_p_p is not an instance of MetadataFromTitlePP
    # Check if the titleformat is correct.
    metadata_from_title_p_p_1 = MetadataFromTitlePP(dict(), '%(title)s - %(artist)s')

# Generated at 2022-06-26 13:48:38.410712
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    # TODO: test case



# Generated at 2022-06-26 13:48:40.822953
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    try:
        assert True # TODO: implement your test here
    except AssertionError as e:
        print("[!] A test failed: %s" % e)
        raise e


# Generated at 2022-06-26 13:48:48.215338
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # The regex could match, but the group names don't match our format
    metadata_format = '%(artist)s'
    title = 'Foo Fighters'
    title_regex = r'(?P<title>.+)'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, metadata_format)
    metadata_from_title_p_p_0._titleregex = title_regex
    assert metadata_from_title_p_p_0.run({'title': title}) == ([], {})

    # The regex could match, but the group names don't match our format
    metadata_format = '%(artist)s'
    title = 'Foo Fighters'
    title_regex = r'(?P<foo>.+)'
    metadata_from_title_p_p_1

# Generated at 2022-06-26 13:48:53.766862
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 't1'
    str_1 = 't2'
    class_0 = type(asc_chr(ord('a') // 4))
    class_1 = type(asc_chr(ord('b') // 4))
    class_2 = type(asc_chr(ord('c') // 4))
    metadata_from_title_p_p_0 = MetadataFromTitlePP(class_0, str_0)
    array_0 = []
    assert_equal(metadata_from_title_p_p_0.run(array_0), (array_0, array_0))

    class_3 = type(asc_chr(ord('d') // 4))
    metadata_from_title_p_p_1 = MetadataFromTitlePP(class_1, str_1)
    dictionary_

# Generated at 2022-06-26 13:48:59.584923
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'mGt'
    str_1 = '\t('
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_1)
    dict_0 = dict()
    dict_0['title'] = 'tLg'
    dict_1 = dict()
    dict_1['title'] = 'tLg'
    dict_1 = metadata_from_title_p_p_0.run(dict_0, dict_1)

# Generated at 2022-06-26 13:49:11.668975
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    print("Testing MetadataFromTitlePP.run() with the following assertions:")
    print("\tFail with no title in info")
    print("\tFail with a title not matching titleformat")
    print("\tFail with a title matching titleformat but with no groups")
    print("\tFail with a title matching titleformat but with groups not in titleformat")
    print("\tSuccess with a title matching titleformat and with groups in titleformat")
    return True

if __name__ == "__main__":
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:49:17.373120
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '\t(sgs'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    info_0 = {}
    str_1 = '\t(sgs'
    info_0['title'] = str_1
    metadata_from_title_p_p_0_run_0 = metadata_from_title_p_p_0.run(info_0)
    return metadata_from_title_p_p_0_run_0



# Generated at 2022-06-26 13:49:25.923938
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '/%(title)s%(uploader)s%(format_id)s'
    str_1 = '%(title)s%(uploader)s%(format_id)s'
    dict_0 = {}
    dict_1 = {}
    dict_1['title'] = '%(title)s%(uploader)s%(format_id)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_1)
    assert_equal(metadata_from_title_p_p_0._format_to_regex(), None)
    assert_equal(metadata_from_title_p_p_0._titleregex, '%(title)s%(uploader)s%(format_id)s')
    dict_2 = {}


# Generated at 2022-06-26 13:49:29.702525
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '\t(sgs'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    info_dict_0 = {}
    info_dict_0['title'] = 'Spotlight (2015)'
    metadata_from_title_p_p_0.run(info_dict_0)


# Generated at 2022-06-26 13:49:37.675583
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'i\x11}'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)

    # __run__ expected 1 1
    list_0 = [1]
    dict_0 = {1: 1}

    int_0, dict_1 = metadata_from_title_p_p_0.run(dict_0)
    # Verifying if str_0 is inside list_1

    # Verifying if dict_0 and dict_1 are equal
    assert(dict_0 == dict_1)

    # Verifying if int_0 is equal to 0
    assert(int_0 == 0)


# Generated at 2022-06-26 13:49:41.915688
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '\t(sgs'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = '\t(sgs'
    metadata_from_title_p_p_0.run(str_1)

# Generated at 2022-06-26 13:49:46.633470
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '\t(sgs'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = {}
    dict_0.clear()
    dict_0[str_0] = str_0
    list_0 = []
    list_0.clear()
    metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:49:49.578114
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test case 0
    pass
# Test cases for function format_to_regex
# The last match should also be accepted

# Generated at 2022-06-26 13:49:55.309565
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '\t(sgs'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = '\t(sgs'
    metadata_from_title_p_p_0.format_to_regex(str_1)
    metadata_from_title_p_p_0.run(str_0)


# Generated at 2022-06-26 13:50:03.896534
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s - %(artist)s'
    str_1 = 'title'
    str_2 = 'artist'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_1)
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_0, str_2)
    str_3 = 'some title - some artist'
    info = {'title': str_3}
    metadata_from_title_p_p_1.run(info)
    metadata_from_title_p_p_0.run(info)


# Generated at 2022-06-26 13:50:17.821580
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s-%(artist)s'
    dict_0 = dict()
    dict_1 = dict()
    dict_1['title'] = 'test test'
    dict_0['title'] = 'test test'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.run(dict_0)

# Generated at 2022-06-26 13:50:25.422250
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    # Test case for When title of video can not be interpreted as titleformat
    metadata_from_title_p_p_0 = MetadataFromTitlePP(
        "Could not interpret title of video as %s",
        "%(artist)s - %(track)s - %(title)s")

# Generated at 2022-06-26 13:50:26.198173
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass


# Generated at 2022-06-26 13:50:26.989348
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert(True)



# Generated at 2022-06-26 13:50:30.812877
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.run(str_0)


# Generated at 2022-06-26 13:50:31.373833
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert True  # constructed


# Generated at 2022-06-26 13:50:34.236857
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '\t(sgs'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = { }
    dict_0['title'] = str_0
    tuple_0 = (dict_0, dict_0)
    assert tuple_0 == metadata_from_title_p_p_0.run(dict_0)

# Generated at 2022-06-26 13:50:43.059276
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '#'
    str_1 = ' '
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_1, str_1)
    list_0 = []
    dict_0 = {'a':metadata_from_title_p_p_0, 'b':list_0, 'c':str_0, 'd':str_0, 'e':str_1}
    list_1, dict_1 = MetadataFromTitlePP.run(metadata_from_title_p_p_0, dict_0)
    assert(len(dict_1['c']) == len(dict_0['c']))
    assert(len(dict_1['d']) == len(dict_0['d']))
    assert(dict_0['c'] == dict_1['c'])

# Generated at 2022-06-26 13:50:49.826369
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '\t(sgs'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = dict()
    dict_0['title'] = '\t(sgs'
    list_0 = list()
    data = metadata_from_title_p_p_0.run(dict_0, list_0)

if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:50:54.379664
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '\t(sgs'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.run(str_0)


if __name__ == '__main__':

    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:51:19.226268
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, None)
    metadata_from_title_p_p_0.run(None)


# Generated at 2022-06-26 13:51:27.010090
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    # Init of class arguments for test 0
    title = '\t(sgs'

# Generated at 2022-06-26 13:51:30.975323
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    print('Testing MetadataFromTitlePP.run...')
    data = ['a', 'b', 'c', 'd']
    metadata_from_title_p_p = MetadataFromTitlePP(data, data)
    metadata_from_title_p_p.run(data)

# Generated at 2022-06-26 13:51:35.156024
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    print('%c Unit test - MetadataFromTitlePP.run, line %d' % (9, 11))
    str_0 = '\t(sgs'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.run(str_0)


# Generated at 2022-06-26 13:51:39.307637
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '\t\t'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = {}
    metadata_from_title_p_p_0.run(dict_0)


if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:51:48.155563
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '\t(sgs'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = '\t(sgs'
    metadata_from_title_p_p_0._titleformat = str_1
    str_2 = '\t(sgs'
    metadata_from_title_p_p_0._titleregex = str_2
    list_0 = []
    dict_0 = {'\t(sgs': list_0}
    assert metadata_from_title_p_p_0.run(dict_0) == ([], {})


# Generated at 2022-06-26 13:51:50.277337
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '\t(sgs'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)


# Generated at 2022-06-26 13:51:56.936050
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert func_1(str_1, str_1) is not None
    assert func_1(str_2, str_2) is not None
    assert func_1(str_3, str_3) is not None
    assert func_1(str_4, str_4) is not None
    assert func_1(str_5, str_5) is not None
    assert func_1(str_6, str_6) is not None
    assert func_1(str_7, str_7) is not None
    assert func_1(str_8, str_8) is not None
    assert func_1(str_9, str_9) is not None
    assert func_1(str_10, str_10) is not None


# Generated at 2022-06-26 13:51:58.259297
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()

if __name__ == '__main__':
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:52:01.832707
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    info = {'title': 'Metallica - Enter Sandman'}
    assert metadata_from_title_p_p.run(info) == ([], {'artist': 'Metallica', 'title': 'Enter Sandman'})

# Generated at 2022-06-26 13:52:52.881871
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '\t(sgs'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = {'title': str_0}
    assert(metadata_from_title_p_p_0.run((dict_0)) == ([], {'title': str_0}))

# Generated at 2022-06-26 13:53:02.783728
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s - %(artist)s - %(album)s'
    str_1 = '%(title)s - %(artist)s'
    str_2 = '%(artist)s'
    str_3 = '%(title)s - %(artist)s - %(album)s'
    str_4 = '%(title)s - %(artist)s - %(album)s'
    str_5 = '%(title)s - %(artist)s - %(album)s'
    str_6 = '%(title)s - %(artist)s - %(album)s'
    str_7 = '%(title)s - %(artist)s'
    str_8 = '%(artist)s'

# Generated at 2022-06-26 13:53:03.879934
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test case for object instantiation
    test_case_0()



# Generated at 2022-06-26 13:53:08.944083
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    list_0_0 = []
    dict_0_0 = {}
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, None)
    metadata_from_title_p_p_0.run(dict_0_0)


if __name__ == '__main__':
    import sys
    import py_compile
    if len(sys.argv) > 1:
        py_compile.compile(sys.argv[1])
    else:
        py_compile.compile('postprocessor_fromtitle.py')
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:53:10.400306
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()

# vim: tabstop=8 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-26 13:53:15.393686
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    def test_impl(titleformat):
        pp = MetadataFromTitlePP(None, titleformat)
        info = {'title': 'abc - xyz'}
        pp.run(info)
        return info

    assert test_impl('%(title)s') == {'title': 'abc - xyz'}
    assert test_impl('%(title)s - %(whatever)s') == {
        'title': 'abc',
        'whatever': 'xyz',
    }


if __name__ == '__main__':
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:53:20.178794
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '\t(sgs'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = '\t(sgs'
    dict_0 = MetadataFromTitlePP(str_1, str_0).run(str_0)
    assert dict_0 == ([], str_0), 'Assertion failed'


# Generated at 2022-06-26 13:53:27.941457
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # number of test cases
    nr_cases = 2
    
    
    titleformat = "%(title)s - %(artist)s"
    
    # case 0
    info_0 = {'title': 'title'}
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, titleformat)
    [out_0, info_0] = metadata_from_title_p_p_0.run(info_0)
    assert out_0 == []
    assert info_0 == {'title': 'title'}
    
    # case 1
    info_1 = {'title': 'title - artist'}
    metadata_from_title_p_p_1 = MetadataFromTitlePP(None, titleformat)
    [out_1, info_1] = metadata_from_title

# Generated at 2022-06-26 13:53:32.002967
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '\t(sgs'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = {"title": '\t(sgs', "artist": '\t(sgs'}
    assert metadata_from_title_p_p_0.run(dict_0) == ([], dict_0)



# Generated at 2022-06-26 13:53:40.620119
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from pytube import extractor
    from pytube import downloader
    from pytube.compat import compat_urllib_request
    from pytube.helpers import install_opener
    from pytube.helpers import parse_qs
    from pytube.helpers import unescape
    from pytube.helpers import urlencode_postdata
    from pytube.helpers import USER_AGENT
    from pytube.helpers import yt_url_splitter
    from pytube.info import InfoExtractor
    from pytube import util
    import sys
    import urllib

    if sys.version_info[0] < 3:
        compat_str = unicode  # NOQA
    else:
        compat_str = str
