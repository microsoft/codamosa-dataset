

# Generated at 2022-06-26 13:44:09.014351
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Test for constructor with 3 args: Downloader, str, int
    bytes_0 = b'^-\xa0\xb7\xff\r\xc9\xbcUP\x87\xc2\xd4Z\x91\xfc'
    set_0 = set()
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bytes_0, set_0)

if __name__ == "__main__":
    test_case_0()
    test_MetadataFromTitlePP()

# Generated at 2022-06-26 13:44:21.021322
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bytes_0 = b'^-\xa0\xb7\xff\r\xc9\xbcUP\x87\xc2\xd4Z\x91\xfc'
    set_0 = set()
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bytes_0, set_0)

# Generated at 2022-06-26 13:44:30.725688
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # TODO: mock the downloader class
    bytes_0 = b'6\xdb\x1a\x83\xcf:G\x8d8\x0e\x9e\x9c\x8c\xf7A\xbd\xa5\x1e\xb05\x98'
    set_0 = set()
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bytes_0, set_0)

    metadata_from_title_p_p_0.run(set_0)
    return


# Generated at 2022-06-26 13:44:41.492938
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    bytes_0 = b'^-\xa0\xb7\xff\r\xc9\xbcUP\x87\xc2\xd4Z\x91\xfc'
    set_0 = set()
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bytes_0, set_0)
    metadata_from_title_p_p_0._titleformat = '%(title)s - %(artist)s'
    assert_equal(metadata_from_title_p_p_0.format_to_regex(metadata_from_title_p_p_0._titleformat), '(?P<title>.+)\ \-\ (?P<artist>.+)')



# Generated at 2022-06-26 13:44:50.825898
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bytes_0 = b'\x1f\x91\x1d'
    int_0 = 0
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bytes_0, int_0)
    str_0 = '"\x06o\x8d\x1a\x0c\x0e\x8d'

# Generated at 2022-06-26 13:45:01.415198
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-26 13:45:11.350883
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    bytes_0 = b'\x04\x1d\xad\xdd\x91\xe2\xd3\rk\xf8\x99\x02\xe1'
    set_0 = set()
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bytes_0, set_0)

    # positive tests
    assert metadata_from_title_p_p_0.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert metadata_from_title_p_p_0.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert metadata_

# Generated at 2022-06-26 13:45:16.753258
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-26 13:45:21.367838
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bytes_0 = b'^-\xa0\xb7\xff\r\xc9\xbcUP\x87\xc2\xd4Z\x91\xfc'
    set_0 = set()
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bytes_0, set_0)
    str_0 = ""

# Generated at 2022-06-26 13:45:28.769019
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bytes_0 = b'\xfb\x19\x9f\xf5\x91\x84\xb4\x19\xa2\xd1\x1f\x9e\x14\x0c'
    set_0 = set()
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bytes_0, set_0)
    dict_0 = dict()
    dict_0[0] = 0
    dict_1 = dict()
    dict_1[0] = 0
    dict_1['\x0c'] = 0
    dict_0[b''] = 0
    dict_1['\x0c'] = dict_0[b'']
    dict_1[b'\x0c'] = 0

# Generated at 2022-06-26 13:45:42.618509
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP.format_to_regex(bytes_0, bytes_1) == bytes_2
    assert MetadataFromTitlePP.format_to_regex(bytes_0, bytes_1) == bytes_2
    assert MetadataFromTitlePP.format_to_regex(bytes_0, bytes_1) == bytes_2
    assert MetadataFromTitlePP.format_to_regex(bytes_0, bytes_1) == bytes_2
    MetadataFromTitlePP.format_to_regex(bytes_0, bytes_1) == bytes_4
    assert MetadataFromTitlePP.format_to_regex(bytes_0, bytes_1) == bytes_2
    assert MetadataFromTitlePP.format_to_regex(bytes_0, bytes_1) == bytes_2
    assert Metadata

# Generated at 2022-06-26 13:45:47.113176
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bytes_0 = b'D\x05\xf6K\xc1\x9d\x90\xcb\x1f\x94\x8a\x9a\xa0\x0f*'
    set_0 = set()
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bytes_0, set_0)
    dict_0 = {'A': 1, 'B': 2, 'C': 3}
    dict_1 = dict_0
    dict_2 = {'D': 4, 'E': 5, 'F': 6}
    dict_3 = dict_2
    dict_4 = {'C': 3, 'A': 1, 'B': 2}
    dict_5 = dict_4

    assert dict_2 == dict_3
    assert dict_1 == dict

# Generated at 2022-06-26 13:45:50.446011
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    bytes_0 = b'I\xe7\x83\xe4\x873\xfc\xf7\x19\x1f\xfd\x18\xb7\x05\x80'
    set_0 = set()
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bytes_0, set_0)
    str_0 = '%(title)s - %(artist)s'
    regex_0 = metadata_from_title_p_p_0.format_to_regex(str_0)
#    assert 'NA' in metadata_from_title_p_p_0.run(regex_0) is False

# Generated at 2022-06-26 13:46:00.232686
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bytes_1 = b'\xbb\xdc\xcb\xf8\xc5\xe0\x18\x9a\x01\xeb\x90\xd0'
    set_1 = set()
    metadata_from_title_p_p_1 = MetadataFromTitlePP(bytes_1, set_1)
    info_1 = {}
    info_1['id'] = b'_\x96\x02\x0b\x05\x92\x0b\xcf\xc7\x83\x0c\x8e\xba'
    info_1['title'] = b'\x96\x02\x0b\x05\x92\x0b\xcf\xc7\x83\x0c\x8e\xba'

# Generated at 2022-06-26 13:46:11.161795
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    lines_0 = [
        'ph',
        'xu'
    ]
    for line_0 in lines_0:
        print(line_0)
    bytes_0 = b'*\x9e\xec\x83\x8f\x82m\xd7\x83\xb9\x9a\x07h\xeb\x02\x8f\xe1\xdb\xcc\x9f\x9c\x1b'
    bytes_1 = b'\xce\x04\x0b\xfa\x9e'
    set_0 = {
        bytes_1: bytes_0
    }
    bytes_2 = b'\x99y\xbb\x04\xc1\xb2\x13'
    metadata_from_title_p_p

# Generated at 2022-06-26 13:46:12.687521
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    assert(len(str(MetadataFromTitlePP)) > 0)

# Generated at 2022-06-26 13:46:14.093267
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    def test_it():
        assert True

    test_it()

# Generated at 2022-06-26 13:46:19.162634
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bytes_0 = b'^-\xa0\xb7\xff\r\xc9\xbcUP\x87\xc2\xd4Z\x91\xfc'
    set_0 = set()
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bytes_0, set_0)

    assert metadata_from_title_p_p_0.run(dict()) == ([], {})


# Generated at 2022-06-26 13:46:24.441455
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bytes_0 = b'^-\xa0\xb7\xff\r\xc9\xbcUP\x87\xc2\xd4Z\x91\xfc'
    set_0 = set()
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bytes_0, set_0)
    dict_0 = dict(title = '!-')
    metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:46:29.155041
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    bytes_0 = b'^-\xa0\xb7\xff\r\xc9\xbcUP\x87\xc2\xd4Z\x91\xfc'
    set_0 = set()
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bytes_0, set_0)
    bytes_0 = b'%(title)s - %(artist)s'
    assert metadata_from_title_p_p_0.format_to_regex(bytes_0) == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'


# Generated at 2022-06-26 13:46:37.649187
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bytes_0 = None
    str_0 = '208.90.112.0/22'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = {}
    dict_0 = metadata_from_title_p_p_0.run(dict_0)


if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:46:43.263580
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bytes_0 = None
    str_0 = '208.90.112.0/22'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.run(bytes_0)

# Test case for MetadataFromTitlePP


# Generated at 2022-06-26 13:46:45.781015
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    print("Testing MetadataFromTitlePP.__init__")
    test_case_0()
    print("Test case passed")



# Generated at 2022-06-26 13:46:54.237945
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bytes_0 = None
    str_0 = '208.90.112.0/22'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = {'title': 'SESAME ALERT!', 'artist': 'Sesame Street'}
    dict_1 = dict_0
    dict_2 = dict_0
    dict_3 = dict_0
    dict_4 = dict_0
    dict_5 = {'artist': 'Sesame Street', 'title': 'SESAME ALERT!'}
    dict_6 = dict_5
    dict_7 = dict_5
    dict_8 = dict_5
    dict_9 = dict_5

# Generated at 2022-06-26 13:47:04.945386
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'http://t.co/tRbPV7jK'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)

# Generated at 2022-06-26 13:47:11.744918
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bytes_0 = None
    str_0 = '208.90.112.0/22'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    info_0 = {}
    str_1 = ''
    tuple_0 = (str_1, info_0)
    try:
        assert tuple_0 == metadata_from_title_p_p_0.run(info_0)
        print('pass')
    except AssertionError:
        print('fail')


# Generated at 2022-06-26 13:47:15.257354
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    titleformat_0 = '%(id)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(titleformat_0, titleformat_0)
    regex_0 = metadata_from_title_p_p_0.format_to_regex(titleformat_0)
    assert regex_0 == r'(?P<id>.+)', 'Expected r\'(?P<id>.+)\' , but the method format_to_regex return %s' % regex_0


# Generated at 2022-06-26 13:47:18.008555
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    bytes_0 = None
    str_0 = '#EXTINF:-1$PREFIX$TITLE$SUFFIX'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    result = metadata_from_title_p_p_0.format_to_regex(str_0)
    assert result == '\\#EXTINF:-1(?P<PREFIX>.+)\\$TITLE'


# Generated at 2022-06-26 13:47:22.987030
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bytes_0 = None
    str_0 = '208.90.112.0/22'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    (bytes_1, dict_0) = metadata_from_title_p_p_0.run({})
    assert(bytes_1, dict_0)


# Generated at 2022-06-26 13:47:24.418277
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    try:
        test_case_0()
    except Exception:
        assert False


# Generated at 2022-06-26 13:47:36.589632
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    title_0 = 'title'
    title_1 = None
    title_2 = 'title'
    title_3 = 'title'
    title_4 = '%(title)s'
    title_5 = '%(title)s'
    str_0 = 'title'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(title_1, title_2)
    str_1 = '%(title)s'
    metadata_from_title_p_p_1 = MetadataFromTitlePP(title_3, str_1)
    str_2 = '%(title)s'
    metadata_from_title_p_p_2 = MetadataFromTitlePP(title_4, str_2)
    str_3 = '%(title)s'
    metadata_from_title_

# Generated at 2022-06-26 13:47:42.844530
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    info_0 = {'title': 'test', 'format': 'test', 'ext': 'test', 'n_files': 1, 'playlist_index': 1}
    metadata_from_title_p_p_0 = MetadataFromTitlePP('test', 'test')
    metadata_from_title_p_p_0._titleregex = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    metadata_from_title_p_p_0._titleformat = '%(title)s - %(artist)s'
    metadata_from_title_p_p_0.run(info_0)

# Generated at 2022-06-26 13:47:43.729469
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert(test_case_0())

# Generated at 2022-06-26 13:47:47.464565
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = None
    dict_0 = {}
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:47:54.672556
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert (MetadataFromTitlePP.format_to_regex('%(title)s - %(artist)s') ==
            '(?P<title>.+)\ \-\ (?P<artist>.+)')
    assert (MetadataFromTitlePP.format_to_regex('%(title)s')
            == '(?P<title>.+)')
    assert (MetadataFromTitlePP.format_to_regex('%(title)s - %(title)s')
            == '(?P<title>.+)\ \-\ (?P<title>.+)')

# Generated at 2022-06-26 13:48:04.110314
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bytes_0 = None
    str_0 = 'nJQun8Y4sl4'
    str_1 = 'c%24(title)s-%(artist)s.mp3'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_1)
    str_2 = 'Mp4'
    str_3 = 'c%24(title)s-%(artist)s.mp3'
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_2, str_3)
    str_4 = '1'
    str_5 = 'ZoqCZi6RV8M'
    metadata_from_title_p_p_1._titleformat = str_5

# Generated at 2022-06-26 13:48:12.338733
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bytes_0 = None
    str_0 = '208.90.112.0/22'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = {}
    dict_0['title'] = '223.20.0.10'
    dict_0['title'] = '0.0.0.0/8'
    list_0, dict_0 = metadata_from_title_p_p_0.run(dict_0)

# Generated at 2022-06-26 13:48:17.958820
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bytes_0 = None
    str_0 = '208.90.112.0/22'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = dict()

    # Call MetadataFromTitlePP_run
    # Output: [], dict_0



# Generated at 2022-06-26 13:48:21.818251
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    downloader = Downloader()
    titleformat = '%(title)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(downloader, titleformat)
    title = "This is a test title"
    info = {
        'title': title
    }
    metadata_from_title_p_p_0.run(info)


# Generated at 2022-06-26 13:48:24.254772
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bytes_0, str_0)
    metadata_from_title_p_p_0.run(str_0)


# Generated at 2022-06-26 13:48:33.470864
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = collections.OrderedDict()
    str_1 = '%(title)s - %(artist)s'
    dict_0['title'] = str_1
    dict_1 = metadata_from_title_p_p_0.run(dict_0)
    assert dict_1[0] == []

# Generated at 2022-06-26 13:48:37.420876
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bytes_0 = None
    str_0 = '208.90.112.0/22'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    mappingproxy_0 = {}
    metadata_from_title_p_p_0.run(mappingproxy_0)


# Generated at 2022-06-26 13:48:41.338626
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '208.90.112.0/22'
    dict_0 = {}
    dict_1 = {'title': None}
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.run(dict_1)


# Generated at 2022-06-26 13:48:46.571551
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = None
    dict_0 = dict()
    # TypeError: expected string or buffer
    # metadata_from_title_p_p_0 = MetadataFromTitlePP(dict_0, str_0)
    # metadata_from_title_p_p_0.run(dict_0)

    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_1.run(dict_0)


# Generated at 2022-06-26 13:48:47.009348
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass

# Generated at 2022-06-26 13:48:52.585100
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    info = {
        'title': 'test'
    }
    titleformat = '%(title)s'

    metadata_from_title_p_p = MetadataFromTitlePP(None, titleformat)
    assert metadata_from_title_p_p.run(info) == [], info

    titleformat = '%(title)s - %(artist)s'
    info = {
        'title': 'test - yt-dl'
    }
    metadata_from_title_p_p = MetadataFromTitlePP(None, titleformat)
    assert metadata_from_title_p_p.run(info) == [], info

    titleformat = '%(artist)s - %(title)s'
    info = {
        'title': 'yt-dl - test'
    }
    metadata_from_title

# Generated at 2022-06-26 13:48:58.313252
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    print('')
    args_0 = None
    kwargs_0 = {'info': {'title': 'Cute kittens - Amazing cats'}}
    expected_0 = ([], {'artist': 'Amazing cats', 'title': 'Cute kittens - Amazing cats'})
    actual_0 = MetadataFromTitlePP('', '%(title)s - %(artist)s').run(**kwargs_0)
    print(actual_0)
    print('')
    assert actual_0 == expected_0


# Generated at 2022-06-26 13:49:06.506717
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor.common import InfoExtractor
    from .compat import compat_str
    title = 'happy birthday'
    video_id = 'XI5HHk2tbvE'
    video_url = 'https://www.youtube.com/watch?v=XI5HHk2tbvE'

# Generated at 2022-06-26 13:49:08.497588
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # test case 0
    test_case_0()

if __name__ == '__main__':
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:49:10.170147
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bytes_0 = None
    assert False # TODO: implement your test here


# Generated at 2022-06-26 13:49:16.557480
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bytes_0 = None
    str_0 = '208.90.112.0/22'
    dict_0 = dict()
    dict_0['title'] = str_0
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    assert_equals(metadata_from_title_p_p_0.run(dict_0), ([], dict_0))


# Generated at 2022-06-26 13:49:21.972007
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    metadata_from_title_p_p_0 = MetadataFromTitlePP('1.59.1', '1.59.1')

    bytes_0 = None

    str_0 = '208.90.112.0/22'

    dict_0 = {}

    dict_0['title'] = str_0

    dict_1 = {}

    dict_1['title'] = str_0

    dict_2 = metadata_from_title_p_p_0.run(dict_1)

    assert (dict_0 == dict_2)

# Generated at 2022-06-26 13:49:29.050300
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP()
    str_0 = None
    dict_0 = {'format': str_0, 'id': 'test', 'ext': 'mp4', 'title': str_0, 'uploader': str_0, 'duration': 0, 'webpage_url': str_0, 'playlist_index': 0, 'playlist_id': str_0, 'fulltitle': str_0}
    metadata_from_title_p_p_0.run(dict_0)

if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:49:38.197138
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    title_0 = 'The Beatles - Paperback writer'
    title_1 = 'The Who - My Generation'

    regex_0 = '(?P<artist>.+)\ \-\ (?P<title>.+)'
    regex_1 = '^(?P<artist>.+)\ \-\ (?P<title>.+)$'
    regex_2 = '(?P<artist>.+)-(?P<title>.+)'

    titleformat_0 = '%(artist)s - %(title)s'
    titleformat_1 = '%(title)s - %(artist)s'

    def test_case_0():

        def test_case_0():
            metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, titleformat_0)
            metadata_from_title_p_p

# Generated at 2022-06-26 13:49:41.876513
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = None
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.run(str_0)


# Generated at 2022-06-26 13:49:48.806298
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = None
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    int_0 = 0
    str_1 = None

# Generated at 2022-06-26 13:49:55.547447
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bytes_0 = None
    str_0 = '208.90.112.0/22'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    info = {}
    expected_result = [], {}
    actual_result = metadata_from_title_p_p_0.run(info)

    assert actual_result == expected_result, 'Expected: %r, Actual: %r' % (expected_result, actual_result)


# Generated at 2022-06-26 13:49:56.428275
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert True == True



# Generated at 2022-06-26 13:50:04.623207
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    m_downloader_0 = None
    titleformat_0 = '%(title)s - %(artist)s'
    m_metadata_from_title_p_p_0 = MetadataFromTitlePP(m_downloader_0, titleformat_0)
    m_info_0 = {'title': 'The title', 'artist': 'The artist'}
    m_metadata_from_title_p_p_0.format_to_regex = mock.Mock(return_value='')
    m_metadata_from_title_p_p_0.run(m_info_0)

# Generated at 2022-06-26 13:50:07.722298
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bytes_0 = None
    str_0 = '208.90.112.0/22'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.run()


# Generated at 2022-06-26 13:50:12.194148
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)

# Generated at 2022-06-26 13:50:19.553624
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test cases
    metadata_from_title_p_p_0 = MetadataFromTitlePP("- %(uploader)s", "%(id)s - %(upload_date)s - %(title)s - %(uploader)s.%(ext)s")
    info_0 = {}
    metadata_from_title_p_p_0.run(info_0)

    metadata_from_title_p_p_0 = MetadataFromTitlePP("%(title)s - %(artist)s", "%- %(uploader)s")
    info_0 = {}
    metadata_from_title_p_p_0.run(info_0)

# Basic unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-26 13:50:28.146721
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case = [
            [['8.8.8.8', '8.8.4.4'], ['8.8.8.8', '8.8.4.4']],
            [['208.90.112.0/22'], ['208.90.112.0/22']],
            [['::1', '2001:4860:4860::8888', '2001:4860:4860::8844'], ['::1', '2001:4860:4860::8888', '2001:4860:4860::8844']]
    ]
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, None)
    for test in test_case:
        assert metadata_from_title_p_p_0.run(test) == True


# Generated at 2022-06-26 13:50:33.339792
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = bool()
    bytes_0 = None
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bytes_0, bool_0)
    metadata_from_title_p_p_0.run(bytes_0)

if __name__ == '__main__':
    test_case_0()
#    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:50:34.986741
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bytes_0 = None
    str_0 = '208.90.112.0/22'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)

# Generated at 2022-06-26 13:50:39.017438
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bytes_0 = None
    str_0 = '208.90.112.0/22'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = dict()
    metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:50:43.026810
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    # Setup mock objects
    temp_0 = {}
    downloader_0 = mock.Mock()
    downloader_0.to_screen.return_value = None
    metadata_from_title_p_p_0 = MetadataFromTitlePP(downloader_0, temp_0)


# Generated at 2022-06-26 13:50:48.028130
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = None
    str_1 = 'abcdefghijklmnopqrstuvwxyz'
    bytes_0 = bytearray(range(256))
    str_2 = 'MetadataFromTitlePP.run'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_2)

# Generated at 2022-06-26 13:50:56.484470
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bytes_0 = None
    str_0 = '208.90.112.0/22'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = '-p'
    dict_0 = {'title': '208.90.112.0/22', '(artist)': '208.90.112.0/22', 'format': '208.90.112.0/22', '%(title)s': '208.90.112.0/22', '%(artist)s': '208.90.112.0/22', 'album': '208.90.112.0/22', 'genre': '208.90.112.0/22', '(title)': '208.90.112.0/22'}
    assert metadata_from_title

# Generated at 2022-06-26 13:51:00.371717
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bytes_0 = None
    str_0 = 'x\x86\x15'
    str_1 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_1)
    dict_0 = {}
    dict_0 = metadata_from_title_p_p_0.run(dict_0)

# Generated at 2022-06-26 13:51:07.553594
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()

test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:51:13.068324
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bytes_0 = None
    str_0 = '208.90.112.0/22'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    list_0 = []
    dict_0 = {}
    dict_0['title'] = str_0
    tuple_0 = (list_0, dict_0)
    tuple_1 = metadata_from_title_p_p_0.run(dict_0)
    assert tuple_1 == tuple_0

# Test for fromtitle module

# Generated at 2022-06-26 13:51:21.578612
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bytes_0 = None
    str_0 = '208.90.112.0/22'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)

    info_dict_0 = {}
    metadata_from_title_p_p_0.run(info_dict_0)

    test_info_dict_0 = {'title': 'Omg'}
    metadata_from_title_p_p_0.run(test_info_dict_0)

    test_info_dict_1 = {'title': 'Omg - Abc'}
    metadata_from_title_p_p_0.run(test_info_dict_1)

    test_info_dict_2 = {'title': 'Omg - Abc - Def'}
    metadata_

# Generated at 2022-06-26 13:51:25.357741
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP('123.123.123.123/24', '123.123.123.123/24')
    bytes_0 = None
    metadata_from_title_p_p_0.run(bytes_0)

# Module level function to test class MetadataFromTitlePP and raise Assertion Error

# Generated at 2022-06-26 13:51:34.835367
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bytes_0 = None
    str_0 = None

# Generated at 2022-06-26 13:51:35.612327
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass


# Generated at 2022-06-26 13:51:39.834120
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    r_0 = _fixture_metadata_from_title_p_p_0.run(_fixture_info_0)
    r_1 = _fixture_metadata_from_title_p_p_1.run(_fixture_info_0)
    r_2 = _fixture_metadata_from_title_p_p_2.run(_fixture_info_0)


# Generated at 2022-06-26 13:51:49.409886
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, "kafka")
    info_0 = {'formats': []}
    metadata_from_title_p_p_0._titleregex = '"kafka"'
    metadata_from_title_p_p_0._titleformat = "kafka"
    metadata_from_title_p_p_0._downloader = None
    metadata_from_title_p_p_0._downloader = None
    info_0['title'] = "kafka"
    [], info_1 = metadata_from_title_p_p_0.run(info_0)
    assert(info_1['title'] == 'kafka')


# Generated at 2022-06-26 13:51:53.665035
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bytes_0 = None
    str_0 = '208.90.112.0/22'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    # test for the first run
    metadata_from_title_p_p_0.run()
    # test for the second run
    metadata_from_title_p_p_0.run()


# Generated at 2022-06-26 13:51:58.562121
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bytes_0 = None
    str_0 = '208.90.112.0/22'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = '208.90.112.0/22'
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_0, str_1)
    metadata_from_title_p_p_0.run(metadata_from_title_p_p_1)


# Generated at 2022-06-26 13:52:11.736727
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()

# Generated at 2022-06-26 13:52:12.921065
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert False # TODO: implement your test here


# Generated at 2022-06-26 13:52:18.958518
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bytes_0 = None
    str_0 = 'ad58e.p'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    info = {
        'title': 'something',
        'artist': 'someone'
    }
    expected_result_1 = ([], {
        'title': 'something',
        'artist': 'someone'
    })
    actual_result_1 = metadata_from_title_p_p_0.run(info)

    assert expected_result_1 is None
    assert actual_result_1 is None



# Generated at 2022-06-26 13:52:25.247876
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = (
        'RT @bit_player: Great lecture by @psychemedia on the technical and ethical issues for news orgs in the post-Snowden era.')
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = (
        'RT @bit_player: Great lecture by @psychemedia on the technical and ethical issues for news orgs in the post-Snowden era.')
    dict_0 = {'id': str_1}
    metadata_from_title_p_p_0.run(dict_0)
    assert dict_0['id'] == str_1

# Generated at 2022-06-26 13:52:31.644880
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bytes_0 = None
    str_0 = '208.90.112.0/22'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = {'title': str_0}
    ret_val_0, ret_val_1 = metadata_from_title_p_p_0.run(dict_0)
    assert ret_val_0 == []
    assert ret_val_1 == {'title': str_0}

test_case_0()
test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:52:40.204955
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bytes_0 = None
    int_0 = 209390448
    int_1 = 208898047
    str_0 = '%(artist)s - %(title)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_2 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_3 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_4 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_5 = Met

# Generated at 2022-06-26 13:52:42.799686
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    with pytest.raises(NotImplementedError):
        metadata_from_title_p_p = MetadataFromTitlePP()
        metadata_from_title_p_p.run()


# Generated at 2022-06-26 13:52:47.567542
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bytes_0 = None
    str_0 = '208.90.112.0/22'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = dict()
    dict_0['title'] = str_0
    list_0 = []
    dict_1 = metadata_from_title_p_p_0.run(dict_0)
    assert dict_0 == dict_1[1]

# Generated at 2022-06-26 13:52:52.696989
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    titleformat = '%(title)s - %(artist)s'
    title = 'Ex.%20-%20You%20(Are%20Special)'
    info = {'title': title}
    metadata_from_title_p_p_0 = MetadataFromTitlePP(titleformat, titleformat)
    metadata_from_title_p_p_0.run(info)

if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:52:57.270203
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    # TODO: test with assert


if __name__ == "__main__":
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:53:22.633472
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, None)
    metadata_from_title_p_p_0.format_to_regex = lambda a0: None
    bytes_0 = None
    str_0 = '208.90.112.0/22'
    metadata_from_title_p_p_0.run(str_0)



# Generated at 2022-06-26 13:53:30.410326
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bytes_0 = None
    str_0 = '208.90.112.0/22'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    int_0 = 0
    bytes_1 = None
    str_2 = '1.0.0.0/8'
    str_3 = 'x'
    str_4 = '1.0.0.0/8'
    dict_0 = metadata_from_title_p_p_0.run(int_0)
    assert str_3 in dict_0
    assert str_4 in dict_0

test_case_0()
test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:53:36.008971
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    title = 'The National (feat. Sufjan Stevens) - Fake Empire'
    fmt = '%(artist)s - %(track)s (%(album)s)'
    regex = 'The National \(feat. Sufjan Stevens\) - Fake Empire'
    info = {}
    info['title'] = title
    postprocessor_0 = MetadataFromTitlePP(info, fmt)
    postprocessor_0_run = postprocessor_0.run(info)
    assert info['regex'] == regex


# Generated at 2022-06-26 13:53:40.496346
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bytes_0 = None
    str_0 = 'fO9c4O4'
    str_1 = '208.90.112.0/22'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_1)
    bool_0 = False
    # Execute test case
    metadata_from_title_p_p_0.run(bool_0)


# Generated at 2022-06-26 13:53:42.465692
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bytes_0 = None
    str_0 = '208.90.112.0/22'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)


# Generated at 2022-06-26 13:53:45.108853
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bytes_0 = None
    str_0 = 'UuQ6jKdJHAw'
    int_0 = 16
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)

    metadata_from_title_p_p_0.run(bytes_0)


# Generated at 2022-06-26 13:53:47.149846
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(0, ' ')
    # TODO: Extend test case
    # metadata_from_title_p_p_0.run()

# Generated at 2022-06-26 13:53:53.586770
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bytes_0 = None
    str_0 = '208.90.112.0/22'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = 'MeHfBxQb3qc'
    dict_0 = {}
    dict_0['title'] = 'MeHfBxQb3qc'
    tuple_0 = (bytes_0, dict_0)
    tuple_1 = metadata_from_title_p_p_0.run(dict_0)
    assert(tuple_0 == tuple_1)
