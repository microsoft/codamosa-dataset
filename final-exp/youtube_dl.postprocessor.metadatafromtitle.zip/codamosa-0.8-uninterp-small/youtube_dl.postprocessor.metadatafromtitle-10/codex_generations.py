

# Generated at 2022-06-26 13:44:01.663195
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    test_case_0()

# Generated at 2022-06-26 13:44:06.448170
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = True
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    metadata_from_title_p_p_0.run(bool_0)


# Generated at 2022-06-26 13:44:07.733054
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    match = test_case_0()

# Generated at 2022-06-26 13:44:10.855082
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    string_0 = '%(title)s - %(artist)s'
    string_1 = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    class_0 = MetadataFromTitlePP('', '')
    assert class_0.format_to_regex(string_0) == string_1

# Generated at 2022-06-26 13:44:13.663053
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    test_case_0()

if __name__ == '__main__':
    test_MetadataFromTitlePP()

# Generated at 2022-06-26 13:44:18.456732
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    dic_0 = {}
    metadata_from_title_p_p_0.run(dic_0)

# Generated at 2022-06-26 13:44:20.992311
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    metadata_from_title_p_p_0.run([])
    metadata_from_title_p_p_0.run({})


# Generated at 2022-06-26 13:44:26.575497
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    metadata_from_title_p_p_0.run(bool_0)


# Generated at 2022-06-26 13:44:32.056605
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    str_0 = 'description'
    dict_0 = {'description': str_0}
    list_0 = []
    list_1 = metadata_from_title_p_p_0.run(dict_0)
    assert len(list_1) == 2
    assert len(list_1[0]) == 0


# Generated at 2022-06-26 13:44:39.574557
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # Test case metadata
    metadata = {}
    metadata['description'] = 'Unit test for method format_to_regex of class MetadataFromTitlePP'
    metadata['expected_result'] = {}
    metadata['expected_result']['description'] = 'Unit test executed succesfully'
    metadata['expected_result']['pass'] = True
    metadata['expected_result']['result'] = None

    # Test case configuration
    title_format = '%(title)s - %(artist)s'

    # Expected result
    expected_result = 'Unit test executed succesfully'

    # Test case

# Generated at 2022-06-26 13:44:43.453470
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    str_0 = None
    metadata_from_title_p_p_0.run(str_0)


# Generated at 2022-06-26 13:44:47.716787
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    __DUMMY0__ = {}
    __DUMMY0__['title'] = 'any string'
    assert type(metadata_from_title_p_p_0.run(__DUMMY0__)) == tuple


# Generated at 2022-06-26 13:44:58.976646
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    dict_0 = {}
    dict_0['title'] = str()
    list_0 = []
    list_1 = []
    list_1.append(dict_0)
    list_1.append(dict_0)
    list_1.append(dict_0)
    list_1.append(dict_0)
    list_1.append(dict_0)
    list_1.append(dict_0)
    list_1.append(dict_0)
    list_1.append(dict_0)
    list_1.append(dict_0)
    list_1.append(dict_0)
    list_1.append(dict_0)


# Generated at 2022-06-26 13:45:03.137008
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test case for re.match(regex, string)
    # regex  - A regex string
    # string - A string
    assert re.match(MetadataFromTitlePP.format_to_regex("%(timestamp)s - %(title)s.flv"),
                    "1507154600 - This is a YouTube-DL test video.flv")

# vim: tabstop=8 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-26 13:45:13.469586
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test 1
    metadata_from_title_p_p_1 = MetadataFromTitlePP(
        "downloader", "this is a sample string")
    f_1 = metadata_from_title_p_p_1.run(
        {"title": "this is a sample string", "this": "das ist ein Beispiel"})
    assert f_1 == ([], {"title": "this is a sample string",
                        "this": "das ist ein Beispiel"})
    # Test 2
    metadata_from_title_p_p_2 = MetadataFromTitlePP(
        "downloader2", "this is a sample string")

# Generated at 2022-06-26 13:45:15.835678
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP('test')
    metadata_from_title_p_p_0.run({})

# Generated at 2022-06-26 13:45:19.153814
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    re_match_0 = re.match(bool_0, bool_0)
    metadata_from_title_p_p_0._titleregex = re_match_0
    info_0 = {}
    metadata_from_title_p_p_0.run(info_0)

if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:45:19.710458
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass

# Generated at 2022-06-26 13:45:23.156186
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    info_0 = {'title': 'Webinar Replay: Extend React Native with Native Modules and the Android NDK'}
    metadata_from_title_p_p_0.run(info_0)

if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:45:27.801161
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    dict_0 = dict()
    dict_1 = dict_0
    dict_0['title'] = bool_0
    metadata_from_title_p_p_0.run(dict_1)


if __name__ == '__main__':
        test_case_0()
        test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:45:34.763833
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
	# TODO: implement this test
	bool_0 = False
	metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
	test_info = metadata_from_title_p_p_0.run(list())
	assert (test_info == ([], list()))

# Generated at 2022-06-26 13:45:36.783108
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()
# End of unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-26 13:45:42.120775
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Input arguments
    info = {}
    info['title'] = 'Title'

    # Expected output
    expected_info = {}
    expected_info['title'] = 'Title'

    # Perform the test
    metadata_from_title_p_p_0 = MetadataFromTitlePP(expected_info, info)
    metadata_from_title_p_p_0.run(info)


# Generated at 2022-06-26 13:45:53.709962
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    title = 'X-Men Origins: Wolverine (2009) HD 720p'
    input_value_info_dict = {'title': title,
                             'tags': [],
                             'description': ''}


# Generated at 2022-06-26 13:45:55.845738
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    assert True

test_MetadataFromTitlePP_run()


# Generated at 2022-06-26 13:45:57.842623
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert True


if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:46:04.419810
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test 0
    titleformat_0 = '%(artist)s'
    bool_0 = False
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, titleformat_0)
    dict_0 = {'title': 'foo'}
    list_0 = []
    info_0 = metadata_from_title_p_p_0.run(dict_0)
    print(info_0)
    assert info_0 == (list_0, dict_0)
    
    # Test 1
    titleformat_0 = '%(artist)s'
    bool_0 = False
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, titleformat_0)
    dict_0 = {'title': 'foo - bar'}
    list

# Generated at 2022-06-26 13:46:09.867566
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    title_0 = '%(title)s: %(description)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, title_0)
    info_0 = {'description': 'hello'}
    metadata_from_title_p_p_0.run(info_0)


# Generated at 2022-06-26 13:46:14.878012
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import VideoInfo
    info = VideoInfo({'title': 'Foo - Bar'})
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    _, info = pp.run(info)
    assert info['artist'] == 'Bar'
    assert info['title'] == 'Foo'



# Generated at 2022-06-26 13:46:23.683265
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, str_0)
    assert metadata_from_title_p_p_0._titleformat == str_0
    assert metadata_from_title_p_p_0._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    str_0 = '%(title)s - %(artist)s - %(album)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, str_0)
    assert metadata_from_title_p_p_0._titleformat == str_0

# Generated at 2022-06-26 13:46:25.593936
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert True
# test_case_0()

# Generated at 2022-06-26 13:46:26.083092
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass

# Generated at 2022-06-26 13:46:30.578284
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    dict_0 = {'title': bool_0, 'id': bool_0}
    metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:46:31.467332
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()


# Generated at 2022-06-26 13:46:37.075013
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    map_0 = {"title": "a", "test": "b"}
    map_1 = {}
    result_0, result_1 = metadata_from_title_p_p_0.run(map_0)
    assert result_0 == [] and result_1 == map_1


# Generated at 2022-06-26 13:46:41.538730
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    dict_0 = {}
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    metadata_from_title_p_p_0.run(dict_0)




# Generated at 2022-06-26 13:46:47.197115
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    str_0 = ""
    dictionary_0 = {"title": str_0}
    tuple_0 = metadata_from_title_p_p_0.run(dictionary_0)
    assert len(tuple_0) == 2

# Generated at 2022-06-26 13:46:49.797152
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    metadata_from_title_p_p_0.run('title')

# Generated at 2022-06-26 13:46:52.310291
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    metadata_from_title_p_p_0.run()

# Generated at 2022-06-26 13:46:55.038654
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    _MetadataFromTitlePP = MetadataFromTitlePP(None, '')
    bool_0 = False
    info_0 = {}
    _MetadataFromTitlePP.run(info_0)


# Generated at 2022-06-26 13:46:59.897888
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, None)
    metadata_from_title_p_p_0.run(None)


# Generated at 2022-06-26 13:47:06.273424
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # This function tests for the following cases:
    # Case 0:
    bool_0 = False
    dict_0 = {'title': 'PyBitmessage: Decentralized, encrypted, peer-to-peer, trustless communications.'}
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    tuple_0 = (list(), dict_0)
    assert metadata_from_title_p_p_0.run(dict_0) == tuple_0

# Generated at 2022-06-26 13:47:10.033121
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    info_0 = {}
    metadata_from_title_p_p_0.run(info_0)

# Generated at 2022-06-26 13:47:17.922173
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Parameterized test case
    case_0 = [
        {
            'title': 'abc',
            'ext': 'mkv',
            'id': '1234'
        },
        {
            'title': 'abc',
            'ext': 'mkv',
            'id': '1234'
        }
    ]
    case_1 = [
        {
            'title': 'Sun Ra - Space Is The Place',
            'ext': 'mkv',
            'id': '1234'
        },
        {
            'title': 'Sun Ra - Space Is The Place',
            'artist': 'Sun Ra',
            'ext': 'mkv',
            'id': '1234',
            'track': 'Space Is The Place'
        }
    ]
    metadata_from_title_p_p_

# Generated at 2022-06-26 13:47:21.689697
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    metadata_from_title_p_p_0.run({'title': 'the title', 'album': 'the album', 'artist': 'the artist'})

# Generated at 2022-06-26 13:47:27.062044
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    Test method run of class MetadataFromTitlePP,
    """
    try:
        str_0 = str()
        metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
        metadata_from_title_p_p_0.run(False)
    except:
        print("Unable to test")

# Generated at 2022-06-26 13:47:28.803610
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # 

    import pytest

    with pytest.raises(Exception):
        MetadataFromTitlePP.run(None,None)

# Generated at 2022-06-26 13:47:34.262098
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    print("\n***Testing method run of class MetadataFromTitlePP***")

    bool_0 = False

    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)

    try:
        #Test block_0 of run
        metadata_from_title_p_p_0.run(None)
    except:
        print("Exception caught when calling run on MetadataFromTitlePP")



# Generated at 2022-06-26 13:47:36.732879
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    metadata_from_title_p_p_0.run(info_0)


# Generated at 2022-06-26 13:47:38.424445
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()

if __name__ == '__main__':
    # Test method:
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:47:49.699445
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    titleformat = '%(title)s - %(artist)s'
    titleregex = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    title = 'title - artist'
    info = {'title': title}
    result_info = {'title': title, 'artist': 'artist'}
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, titleformat)
    assert metadata_from_title_p_p_0._titleformat == titl

# Generated at 2022-06-26 13:47:54.788352
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    titleformat = '%(page_title)s'
    downloader_0 = None
    # section2
    metadata_from_title_p_p_0 = MetadataFromTitlePP(downloader_0, titleformat)
    info_0 = {}
    # section3
    # section4
    assert metadata_from_title_p_p_0.run(info_0) == ([],{})


# Generated at 2022-06-26 13:48:04.214574
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    info = {}
    metadata_from_title_p_p_0.run(info)
    i = 0
    while i <= 5:
        info = {}
        metadata_from_title_p_p_0.run(info)
        i = i + 1
    info = {}
    metadata_from_title_p_p_0.run(info)
    i = 0
    while i <= 5:
        info = {}
        metadata_from_title_p_p_0.run(info)
        i = i + 1
    i = 0
    while i <= 5:
        info = {}
        metadata_from_title_p_p_0.run(info)
        i = i + 1

# Generated at 2022-06-26 13:48:08.405407
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    title = 'hello world'
    info = {'title': title}
    p = MetadataFromTitlePP(None, '%(title)s')
    [], info_new = p.run(info)
    assert info_new['title'] == title


# Generated at 2022-06-26 13:48:13.435966
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    titleformat = '%(artist)s - %(title)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(titleformat, titleformat)
    info = {'title': 'title'}
    info_0 = info
    metadata_from_title_p_p_0.run(info_0)


# Generated at 2022-06-26 13:48:15.191144
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # TODO - should be removed
    pass

# Generated at 2022-06-26 13:48:19.706775
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    metadata_from_title_p_p_0.run({})

if __name__ == '__main__':
    import cProfile
    cProfile.run('test_case_0()')

# Generated at 2022-06-26 13:48:28.170847
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    dict_0 = dict({})
    dict_0['title'] = 'Songs to Wear Pants To - The Stage is Set for the Creation of a New Age of Music'
    retval_1, retval_2 = metadata_from_title_p_p_0.run(dict_0)
    assert retval_1 == []

# Generated at 2022-06-26 13:48:32.092948
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    metadata_from_title_p_p_0.run(bool_0)


# Generated at 2022-06-26 13:48:35.309743
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = True
    if (bool_0):
        metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
        metadata_from_title_p_p_0.run(bool_0)

# Generated at 2022-06-26 13:48:50.565282
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    dict_0 = dict()
    dict_0['title'] = 'test'
    list_0 = []
    tuple_0 = (list_0, dict_0)
    assert tuple_0 == metadata_from_title_p_p_0.run({})
    dict_0['title'] = 'test - test'
    list_1 = []
    tuple_1 = (list_1, dict_0)
    assert tuple_1 == metadata_from_title_p_p_0.run({})
    dict_0['title'] = 'test - test - test'
    list_2 = []
    tuple_2 = (list_2, dict_0)
    assert tuple_

# Generated at 2022-06-26 13:48:58.955136
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-26 13:49:02.068942
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    result = metadata_from_title_p_p_0.run(bool_0)
    assert [] == result
    assert 0 == result


# Generated at 2022-06-26 13:49:08.737358
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    titleformat = '%(title)s - %(artist)s'
    title = 'abcdef'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, titleformat)
    bool_0 = bool_0
    bool_0 = bool_0
    list_0 = []
    dict_0 = {
        'title': title,
        'artist': 'b',
    }
    # Check if the result of method run is correct or not
    assert_equal(metadata_from_title_p_p_0.run(dict_0), (list_0, dict_0))


# Generated at 2022-06-26 13:49:12.348509
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = True
    dict_0 = dict()
    dict_0['title'] = 'foo'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, '%(title)s - %(artist)s')
    metadata_from_title_p_p_0.run(dict_0)

# Generated at 2022-06-26 13:49:16.691637
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    info_0 = {}
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    metadata_from_title_p_p_0.run(info_0)

# Unit tests for class MetadataFromTitlePP
# test_MetadataFromTitlePP_run()
# test_case_0()

# Generated at 2022-06-26 13:49:21.549795
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    emoji = chr(128514)
    title = '%(title)s ' + emoji
    metadata_from_title_p_p_0 = MetadataFromTitlePP('downloader', title)
    info = {'title': 'foo bar'}
    assert metadata_from_title_p_p_0.run(info) == ([], {'title': 'foo bar', 'title ': emoji})

test_MetadataFromTitlePP_run()
test_case_0()

# Generated at 2022-06-26 13:49:29.855190
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # PostProcessorMetadataFromTitlePP
    metadata_from_title_p_p_0 = MetadataFromTitlePP(..., ...)
    # Information dict

# Generated at 2022-06-26 13:49:35.838812
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    dict_0 = dict()
    dict_0['title'] = bool_0
    metadata_from_title_p_p_0._format_to_regex(bool_0)
    list_0 = []
    dict_0 = metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:49:36.874961
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert callable(MetadataFromTitlePP.run)

# Generated at 2022-06-26 13:50:03.727060
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    dict_0 = {u'id': u'youtube-75a7dOaO2A0', u'title': u'Skiing in the snow', u'webpage_url': u'Youtube webpage url for video-id: youtube-75a7dOaO2A0', u'description': u'Skiing in the snow'}
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    metadata_from_title_p_p_0.format_to_regex(u'%(title)s - %(artist)s')
    metadata_from_title_p_p_0.run(dict_0)

# Generated at 2022-06-26 13:50:04.592799
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()


# Generated at 2022-06-26 13:50:08.586302
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    print(metadata_from_title_p_p_0.run()[-1])

if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:50:17.562799
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = True
    dict_0 = {'title': '', 'upload_date': '20181229', 'playliststart': '1', 'playlist_id': None, 'view_count': '47', 'annotations': None, 'track': None, 'playlist_uploader': None, 'uploader': '喜马拉雅FM', 'playlist_title': None, 'playlistend': None, 'uploader_id': '4609612', 'display_id': '2700001006020', 'id': '2700001006020', 'extractor': '喜马拉雅FM'}
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    assert metadata_from_title_p_p_0

# Generated at 2022-06-26 13:50:21.106354
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP("1", "2")
    string_0 = "3"
    # On failed match, returns empty dict
    assert metadata_from_title_p_p_0.run(string_0) == ([], {})


# Generated at 2022-06-26 13:50:27.610661
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_1 = False
    metadata_from_title_p_p_1 = MetadataFromTitlePP(bool_1, bool_1)
    dict_0 = {}
    dict_0['title'] = '0:0:0:0:0:0:0:1'
    dict_0_copy = dict(dict_0)
    dict_0['fromtitle'] = None
    dict_0['fromtitle'] = None
    dict_0['fromtitle'] = None
    dict_0['fromtitle'] = None
    dict_0['fromtitle'] = None
    dict_1, dict_2 = metadata_from_title_p_p_1.run(dict_0)
    assert (dict_0 == dict_0_copy)
    assert (dict_1 == [])

# Generated at 2022-06-26 13:50:28.569481
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # TODO
    pass

# Generated at 2022-06-26 13:50:33.521370
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    dict_0 = {'title': 'abc'}
    metadata_from_title_p_p_0.format_to_regex(bool_0)
    metadata_from_title_p_p_0.run(dict_0)

# Generated at 2022-06-26 13:50:40.914686
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test case 0
    bool_0 = True
    bool_1 = True
    str_0 = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    dict_0 = {'thumbnail': 'http://img.youtube.com/vi/BaW_jenozKc/default.jpg', 'description': 'md5:f77e76cdf0d603b1c7a35dd8aef01e0c', 'age_limit': 0, 'upload_date': '20121002', 'uploader': 'ecken', 'title': 'Barely Political - The Key of Awesome #66: Katy Perry - Wide Awake Parody'}

# Generated at 2022-06-26 13:50:45.054341
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    dict_0 = collections.OrderedDict()
    dict_0['title'] = 'foo'
    dict_0['artist'] = 'bar'
    dict_1 = collections.OrderedDict()
    list_0 = []
    metadata_from_title_p_p_0.run(dict_0)
    metadata_from_title_p_p_0.run(dict_1)
    metadata_from_title_p_p_0.run(dict_1)
    metadata_from_title_p_p_0.run(dict_1)


# Generated at 2022-06-26 13:51:37.327383
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    titleformat = '%(uploader)s - %(title)s-%(id)s'
    metadata_from_title_p_p = MetadataFromTitlePP(None, titleformat)
    info = {'title': 'Test Uploader - Test Title-12345', 'ext': 'mp3'}
    result = metadata_from_title_p_p.run(info)
    assert result == ([], {'title': 'Test Uploader - Test Title', 'ext': 'mp3', 'id': '12345', 'uploader': 'Test Uploader'}), 'incorrect output'


# Generated at 2022-06-26 13:51:41.362589
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Arrange
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    info = {}
    
    # Act
    metadata_from_title_p_p_0.run(info)

    # Assert



# Generated at 2022-06-26 13:51:50.809425
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    bool_1 = bool(bool_0)
    bool_2 = bool_0
    bool_3 = bool_1
    dict_0 = dict()
    dict_0.update(('title', 'Video Title'))
    dict_1 = dict()
    dict_1.update(dict_0)

    # Test case 0
    # [description] Tests the case where the regex and the title format are the same
    # [expected] The dict returned is the same as the dict passed
    assert MetadataFromTitlePP.run(dict_0, bool_0, bool_3) == dict_1, 'test_case_0 failed'

    dict_2 = dict()
    dict_2.update(dict_1)

    # Test case 1
    # [description] Tests the case where the regex is the same as

# Generated at 2022-06-26 13:51:54.556453
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    dictionary_0 = {}
    dictionary_0['title'] = 'AAA'
    tuple_0 = metadata_from_title_p_p_0.run(dictionary_0)
    assert tuple_0 == ([], {})


# Generated at 2022-06-26 13:51:55.955994
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    pytest.skip('no impl yet')
    MetadataFromTitlePP(bool_0, bool_0)


# Generated at 2022-06-26 13:51:56.639686
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass

# Generated at 2022-06-26 13:51:57.559320
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 13:52:02.142852
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    string_0 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, string_0)
    string_1 = 'Definitely real song title - Fake artist'
    map_0 = {'title': string_1}
    metadata_from_title_p_p_0.run(map_0)

# Tests for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-26 13:52:06.539626
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test case: test_case_0
    # Function: MetadataFromTitlePP.run
    # Tests that video title is correctly parsed.
    bool_0 = False
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)

    metadata_from_title_p_p_0.format_to_regex()

# Generated at 2022-06-26 13:52:12.010617
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_1 = MetadataFromTitlePP(None, None)
    bool_1 = True
    m_0 = {}
    if bool_1:
        m_0['title'] = 'United States of Eurasia'
    if not bool_1:
        m_0['title'] = 'NA'
    m_1 = None
    [], m_2 = metadata_from_title_p_p_1.run(m_0)
    assert (m_1 == m_2)


# Generated at 2022-06-26 13:53:51.121969
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(False, False)
    assert metadata_from_title_p_p_0.run in globals()


# Generated at 2022-06-26 13:53:53.345709
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(False, False)
    metadata_from_title_p_p_0.run({"Title":"Title"})

test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:53:58.650286
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    title = 'foo - bar'
    info = {'title': title}
    filename = 'file'
    ext = '.ext'
    info['fulltitle'] = title
    info['alt_title'] = title
    titleformat = '%(artist)s - %(track)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, titleformat)
    metadata_from_title_p_p_0.run(info)

if __name__ == '__main__':
    test_MetadataFromTitlePP_run()