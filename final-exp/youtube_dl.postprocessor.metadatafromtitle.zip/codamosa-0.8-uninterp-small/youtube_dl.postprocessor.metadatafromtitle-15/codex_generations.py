

# Generated at 2022-06-26 13:43:59.510592
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, None)
    assert metadata_from_title_p_p_0.run(None) is (None, None)

# Generated at 2022-06-26 13:44:05.596032
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # input
    fmt = '%(author)s - %(title)s'

    # expected result
    expected_res = '(?P<author>.+)\ \-\ (?P<title>.+)'

    # actual result
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, None)
    actual_res = metadata_from_title_p_p_0.format_to_regex(fmt)

    assert actual_res == expected_res
    print('MetadataFromTitlePP.format_to_regex() TEST PASSED')

# Generated at 2022-06-26 13:44:08.570840
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    bool_0 = True
    assert type(MetadataFromTitlePP(bool_0, bool_0)) is MetadataFromTitlePP

# Generated at 2022-06-26 13:44:11.756328
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = True
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    dict_0 = {}
    dict_0['title'] = bool_0
    metadata_from_title_p_p_0.run(dict_0)

if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:44:16.026097
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    string_0 = '%(title)s_-_%(artist)s'
    string_1 = '(?P<title>.+)_-_(?P<artist>.+)'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(string_0, string_0)
    metadata_from_title_p_p_0.format_to_regex(string_0)
    bool_0 = metadata_from_title_p_p_0._titleregex == string_1

if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_format_to_regex()

# Generated at 2022-06-26 13:44:21.307316
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = True
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)

    dict_0 = dict()
    dict_0['title'] = "Crazy Frog - Axel F (Official Video)"
    result = metadata_from_title_p_p_0.run(dict_0)
    assert result == ([], {'artist': 'Crazy Frog',
                           'title': 'Crazy Frog - Axel F (Official Video)'})

# Generated at 2022-06-26 13:44:22.806119
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    test_case_0()


# Generated at 2022-06-26 13:44:30.926216
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Init
    bool_0 = True
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    str_0 = 'fmt_string'
    dict_0 = {'title': str_0}

    # Test
    metadata_from_title_p_p_0.run(dict_0)


if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:44:38.467192
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP()
    info_0 = {"title": "Super Mario - Full Game Walkthrough"}
    metadata_from_title_p_p_0.run(info_0)
    assert info_0['title'] == 'Super Mario - Full Game Walkthrough'
    assert info_0['artist'] == 'Full Game Walkthrough'


# Generated at 2022-06-26 13:44:45.190547
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    fmt = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(None, fmt)
    fmt_0 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, fmt_0)
    title = 'The Matrix - Keanu Reeves'
    metadata = {'title': title}
    metadata_from_title_p_p_0.run(metadata)
    assert metadata['title'] == 'The Matrix'
    assert metadata['artist'] == 'Keanu Reeves'


# Generated at 2022-06-26 13:44:53.778185
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = True
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    metadata_tuple_0 = ()
    metadata_dict_0 = {}
    #assert  (metadata_from_title_p_p_0.run(metadata_dict_0) == (metadata_tuple_0, metadata_dict_0))


# Generated at 2022-06-26 13:44:58.890710
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = True
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    dict_0 = {'title': 'xyz'}
    dict_1, dict_2 = metadata_from_title_p_p_0.run(dict_0)
    assert dict_2 == {'title': 'xyz'}


# Generated at 2022-06-26 13:45:08.240687
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test case with the following values:
    #   info.title = 'My little Pony - La magia de la amistad'
    #   info.track = 4
    #   info.track_total = 5
    #   info.artist = 'Me'
    #   info.album = 'La granja'
    #   info.album_artist = 'You'
    #   info.date = None
    #   info.disc = 2
    #   info.disc_total = 3
    #   info.format = 'mp3'
    #   info.genre = 'Music'
    #   info.titleformat = '%(track)s - %(artist)s - %(album)s - %(disc)s'
    #   info.track_above_limit = False
    metadata_from_title_p_p_

# Generated at 2022-06-26 13:45:10.615484
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = True
    bool_1 = True
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)


# Generated at 2022-06-26 13:45:14.655766
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    dict_0 = dict()
    dict_0['title'] = 'title'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, '%(title)s')
    metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:45:20.751480
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, str())

    # Creation of a dictionary with the variable info
    info = dict()
    # Defining the values of the info dictionary
    info['title'] = 'titulo'

    # Invocation of the method run of the class MetadataFromTitlePP
    metadata_from_title_p_p_0.run(info)

# Generated at 2022-06-26 13:45:25.124308
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, None)
    info_0 = {}
    info_0['title'] = 'Test'
    metadata_from_title_p_p_0._titleregex = '(?P<a>.*)'
    (list_0, info_0) = metadata_from_title_p_p_0.run(info_0)



# Generated at 2022-06-26 13:45:25.978128
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert(False), "Unit test not implemented."

# Generated at 2022-06-26 13:45:36.593688
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    class MockInfo(object):
        def __init__(self):
            self._title = None
            self._info = {}

        @property
        def title(self):
            return self._title

        @title.setter
        def title(self, value):
            self._title = value

        def __getitem__(self, key):
            return self._info[key]

        def __setitem__(self, key, value):
            self._info[key] = value

    class MockDownloader(object):
        def __init__(self):
            self._screen = []

        def to_screen(self, text):
            self._screen.append(text)


# Generated at 2022-06-26 13:45:47.639134
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, None)
    info_0 = dict()
    info_0['title'] = 'Cup Song - Pitch Perfect\u200b - Lulu and the Lampshades - Beatbox Cover - 1, 2, 3, Go'
    metadata_from_title_p_p_0.run(info_0)
    #assert info_0['title'] == 'Cup Song - Pitch Perfect\u200b - Lulu and the Lampshades - Beatbox Cover - 1, 2, 3, Go'
    #assert info_0['artist'] == 'Cup Song - Pitch Perfect\u200b - Lulu and the Lampshades - Beatbox Cover - 1, 2, 3, Go'
    assert info_0.get('title') != None
    assert info_0.get

# Generated at 2022-06-26 13:45:56.423787
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = ''
    str_1 = ''
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_1, str_0)
    dict_0 = dict({'url' : str_0, 'ext' : '.mp3', 'title' : str_0})
    assert metadata_from_title_p_p_0.run(dict_0) == ([], {}), 'Invalid return value for MetadataFromTitlePP.run'

# Generated at 2022-06-26 13:46:02.111662
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'https://www.youtube.com/watch?v=eNfQ2wW8oJk&list=PLbpi6ZahtOH5eLl7xRpUmjmVOVOCo0yTR'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    class_0 = {'title': 'test_title'}
    assert metadata_from_title_p_p_0.run(class_0) == [], class_0


# Generated at 2022-06-26 13:46:06.146356
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(MetadataFromTitlePP, MetadataFromTitlePP)
    info_0 = {}
    metadata_from_title_p_p_0.run(info_0)


# Generated at 2022-06-26 13:46:15.249567
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = ''
    str_1 = ''
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_1)
    dict_0 = {}
    info = dict_0
    list_0 = []
    tuple_0 = ()
    str_2 = 'MetadataFromTitlePP_run'
    dict_0['title'] = str_2
    list_1, info = metadata_from_title_p_p_0.run(info)
    assert(list_1 == list_0)
    assert(len(info) == 0)
    
    

# Generated at 2022-06-26 13:46:16.766799
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    print(
        '===== Unit test for MetadataFromTitlePP.run =====')
    test_case_0()

# Generated at 2022-06-26 13:46:23.922082
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = ''
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = 'abcde'
    dict_0 = {'title': str_1}
    str_2 = ''
    str_3 = '%(artist)s - %(title)s'
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_2, str_3)
    list_0 = []
    assert metadata_from_title_p_p_1.run(dict_0) == tuple([list_0, dict_0])

# Generated at 2022-06-26 13:46:26.293450
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP.MetadataFromTitlePP('','')
    metadata_from_title_p_p_0.run(dict())


# Generated at 2022-06-26 13:46:32.252485
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = ''
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    # dictionary info
    # key str <type 'str'>
    # value str <type 'str'>
    # key int <type 'int'>
    # value bool <type 'bool'>
    info = {'asd': 'qwe', 5: True}
    metadata_from_title_p_p_0.run(info)

# Generated at 2022-06-26 13:46:37.382475
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = ''
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = dict()
    dict_0['title'] = str_0
    tuple_0 = (dict_0, dict_0)
    assert tuple_0 == metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:46:38.185728
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Check return value of run
    pass

# Generated at 2022-06-26 13:46:43.621256
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP("", "")
    metadata_from_title_p_p_0.run({'title': "", 'no_error': 0})


# Generated at 2022-06-26 13:46:51.870449
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    url_0 = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    format_0 = '%(title)s - %(artist)s - %(album)s - %(track)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(url_0, format_0)
    title_0 = 'title'
    metadata_0 = {}
    metadata_0['title'] = title_0
    info_0 = []
    info_0.append(metadata_0)
    info_0.append(metadata_0)
    assert metadata_from_title_p_p_0.run(info_0) == ([], info_0)

# Generated at 2022-06-26 13:46:55.541668
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = ''
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    # Type Errors are checked by isinstance().
    dict_0 = dict()
    tuple_0 = tuple()
    tuple_1 = metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:47:01.721318
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_1 = MetadataFromTitlePP('loremipsumdolorsitamet',
                                                    'loremipsumdolorsitamet')
    dict_0 = {'title': 'loremipsumdolorsitamet'}
    assert metadata_from_title_p_p_1.run(dict_0) == ([], {'title': 'loremipsumdolorsitamet'})


# Generated at 2022-06-26 13:47:07.271006
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = ''
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = {}
    dict_1 = {}
    dict_1['title'] = str_0
    dict_0['title'] = dict_1['title']
    tuple_0 = (list_0, dict_0)
    assert tuple_0 == metadata_from_title_p_p_0.run(dict_1)


# Generated at 2022-06-26 13:47:16.629943
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test case where 0 < len(info['title']) < len(self._titleregex),
    # and either self._titleregex is a simple string or all %()s in
    # self._titleformat are literals
    str_0 = ''
    str_1 = '%(title)s'
    str_2 = '%(title)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_0, str_1)
    metadata_from_title_p_p_2 = MetadataFromTitlePP(str_0, str_2)
    map__0 = {}
    map__1 = {}
    map__0['title'] = 'abc'
    map

# Generated at 2022-06-26 13:47:27.295907
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s - %(sitename)s.%(ext)s'
    str_1 = '%(title)s-%(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    # AssertionError: {'id': '1FjkEI531*$', 'ext': 'mp4', 'sitename': 'YouTube', 'title': 'test-test-test'} ?= {'id': '1FjkEI531*$', 'ext': 'mp4', 'sitename': 'YouTube', 'title': 'test-test-test', 'artist': 'test'}

# Generated at 2022-06-26 13:47:32.748862
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test variables and values
    info = {'title': 'Test'}
    str_0 = '%(title)s'

    # Init class
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)

    # Run method
    output_list, output_dict = metadata_from_title_p_p_0.run(info)

    # Assertion
    assert output_list == [] and output_dict['title'] == 'Test'


# Generated at 2022-06-26 13:47:37.959830
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = ''
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = dict()
    dict_0['title'] = str_0
    tuple_0 = metadata_from_title_p_p_0.run(dict_0)

if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:47:39.955737
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()
    # TODO: fix this test
    # assert_equal(expected, actual)
    raise Exception('Not implemented')


# Generated at 2022-06-26 13:47:46.625493
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    dict_0 = {}
    str_0 = ''
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_2 = 'Hello, world'
    dict_0['title'] = str_2
    list_0, dict_1 = metadata_from_title_p_p_0.run(dict_0)
    assert dict_1['title'] == 'Hello, world'

# Generated at 2022-06-26 13:47:47.550387
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert 1 == 1



# Generated at 2022-06-26 13:47:57.804870
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = ''
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    info_0 = {}
    metadata_from_title_p_p_0.run(info_0)
    info_1 = {'title': '1\n2'}
    metadata_from_title_p_p_0.run(info_1)
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_0, '%(title)s - %(title)s')
    info_2 = {'title': '1\n2'}
    metadata_from_title_p_p_1.run(info_2)
    str_1 = '%(title)s - %(title)s'
    metadata_from_title_

# Generated at 2022-06-26 13:48:01.313940
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, None)
    dict_0 = {'title': ''}
    assert_equals(metadata_from_title_p_p_0.run(dict_0), [])


# Generated at 2022-06-26 13:48:04.350747
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = ''
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    assert type(metadata_from_title_p_p_0.run(str_0)) is tuple


# Generated at 2022-06-26 13:48:05.700626
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert callable(MetadataFromTitlePP.run)

# Generated at 2022-06-26 13:48:17.863733
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '/'
    str_1 = ''
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_1)
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_0, str_1)
    str_2 = ''
    metadata_from_title_p_p_2 = MetadataFromTitlePP(str_1, str_2)
    dictionary_0 = {}

# Generated at 2022-06-26 13:48:22.288572
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = ''
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)

    dict_0 = {}
    dict_0['title'] = str_0
    dict_1 = {}
    dict_1['title'] = str_0

    assert (metadata_from_title_p_p_0.run(
        dict_0) == ([], dict_1))

# Generated at 2022-06-26 13:48:30.783031
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    expected_format_to_regex_0 = ''.join(['(?P<title>.+)',
                                          '\\ \-\\ ',
                                          '(?P<artist>.+)'])
    str_0 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, str_0)
    assert metadata_from_title_p_p_0._titleformat == str_0
    assert metadata_from_title_p_p_0._titleregex == expected_format_to_regex_0

if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:48:38.970521
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = None
    str_1 = ''
    str_2 = None
    str_3 = ''
    str_4 = None
    str_5 = ''
    str_6 = None
    str_7 = ''
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_1, str_3)
    metadata_from_title_p_p_0.run(str_5)
    print('str_0')
    print('str_1')
    print('str_2')
    print('str_3')
    print('str_4')
    print('str_5')
    print('str_6')
    print('str_7')

# Generated at 2022-06-26 13:48:42.398965
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # code for testing run
    return


# Generated at 2022-06-26 13:48:49.032874
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = ''

    title_0 = 'Some Title'
    match = re.match('.+', 'Some Title')
    if match is None:
        str_1 = 'Could not interpret title of video as "%s"' % str_0
        print(str_1)

    metadata_from_title_p_p_0 = MetadataFromTitlePP('', '')
    list_0 = []
    info = {'title': title_0}
    return_value = metadata_from_title_p_p_0.run(info)
    assert return_value == (list_0, info)

if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:48:54.061025
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'H'
    str_1 = 'H'
    empty_dict_0 = {}
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_1)
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_0, str_1)
    metadata_from_title_p_p_2 = MetadataFromTitlePP(str_0, str_1)
    metadata_from_title_p_p_1.run(empty_dict_0)
    metadata_from_title_p_p_2.run(empty_dict_0)
    metadata_from_title_p_p_0.run(empty_dict_0)


# Generated at 2022-06-26 13:49:02.785504
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert MetadataFromTitlePP.run() is None
    str_0 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_0 = 'Metallica - nothing else matters'
    str_1 = '%(title)s - %(artist)s'
    str_2 = 'Metallica - nothing else matters'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_1)
    assert metadata_from_title_p_p_0.run(str_2) is None
    str_0 = '%(title)s - %(artist)s'

# Generated at 2022-06-26 13:49:04.744037
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = ''
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)


# Generated at 2022-06-26 13:49:07.596381
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = ''
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    info_0 = {}
    metadata_from_title_p_p_0.run(info_0)


# Generated at 2022-06-26 13:49:13.470815
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = {}
    dict_0['title'] = 'foo'
    dict_0['artist'] = 'bar'
    tuple_0 = None
    tuple_0 = metadata_from_title_p_p_0.run(dict_0)


if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:49:15.046719
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    instance_0 = test_case_0()

# Generated at 2022-06-26 13:49:17.246458
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    try:
        test_case_0()
    except(TypeError, AssertionError) as e:
        print(e)
        assert False



test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:49:22.431271
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    title = 'This is a test %(foo)s'
    info = {}
    metadata_from_title_p_p = MetadataFromTitlePP(None, title)
    for case in ['bar', 'bar bar', 'bar - bar']:
        info['title'] = 'This is a test ' + case
        (metadata, metadata_from_title_p_p), info = metadata_from_title_p_p.run(info)

    return metadata, metadata_from_title_p_p, info, title

# Generated at 2022-06-26 13:49:28.874768
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()


# Generated at 2022-06-26 13:49:38.061021
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = ''
    str_1 = '%(title)s_(%(id)s).f'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_1)
    dict_0 = {'id': '233227', 'title': 'Делай Ноги - С Золотым Человеком'}
    assert metadata_from_title_p_p_0.run([dict_0])[0][0]['id'] == '233227'

# Generated at 2022-06-26 13:49:44.334350
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = ''
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_0 = ''
    dict_0 = {'title': str_0}
    assert (metadata_from_title_p_p_0.run(dict_0) == ([], {'title': str_0}))
    print("Test case 0 passed")

test_case_0()
test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:49:46.758939
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = ''
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    assert metadata_from_title_p_p_0.run(str_0)


# Generated at 2022-06-26 13:49:51.248998
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = ''
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = dict()
    dict_0['title'] = str_0
    metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:49:56.784809
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = ''
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = ''
    dict_0 = {
        str_0: str_1
    }
    assert_equals(
        list_0,
        metadata_from_title_p_p_0.run(dict_0)
    )

# Generated at 2022-06-26 13:50:02.653287
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
	str_0 = ''
	str_1 = '%(title)s - %(artist)s'
	metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_1)
	dictionary_0 = {'title': 'foo'}
	dictionary_0 = metadata_from_title_p_p_0.run(dictionary_0)

# Generated at 2022-06-26 13:50:07.452924
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = 'My song'
    dict_0 = {'title': str_1}
    list_1 = []
    metadata_from_title_p_p_0.run(dict_0)
    return list_1

# Generated at 2022-06-26 13:50:08.772244
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test for method run of class MetadataFromTitlePP
    # Not working
    return None


# Generated at 2022-06-26 13:50:09.540869
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass




# Generated at 2022-06-26 13:50:21.412250
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = ''
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.format_to_regex(str_0)
    metadata_from_title_p_p_0.run(dict())


if __name__ == '__main__':
    str_0 = ''
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.format_to_regex(str_0)
    metadata_from_title_p_p_0.run(dict())



# Generated at 2022-06-26 13:50:25.641711
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = ''
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)

    metadataFromTitle_run_dict = {}

    metadata_from_title_p_p_0.run(metadataFromTitle_run_dict)



# Generated at 2022-06-26 13:50:31.793414
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '[%(title)s]%(autogenerated)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = {}
    str_1 = 'aaaaa'
    dict_0['title'] = str_1
    dict_0['autogenerated'] = 'dl'
    list_0 = []
    dict_1 = metadata_from_title_p_p_0.run(dict_0)

# Generated at 2022-06-26 13:50:37.311657
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = ',12,Oetf - Tt,Tt,7,2.1.0,New,22'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = ''
    str_2 = ''
    # Test for ValueError
    try:
        metadata_from_title_p_p_0.run(str_1)
    except ValueError:
        pass
    try:
        metadata_from_title_p_p_0.run(str_2)
    except ValueError:
        pass
    return


# Generated at 2022-06-26 13:50:47.061687
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = ''
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    
    str_0 = ''
    dict_0 = {}
    assert_equals(metadata_from_title_p_p_0.run(dict_0),
                  ([], dict_0))
    
    str_0 = ''
    dict_0 = {}
    dict_0['title'] = 'blah'
    assert_equals(metadata_from_title_p_p_0.run(dict_0),
                  ([], dict_0))
    
    str_0 = '%(title)s - %(artist)s'
    dict_0 = {}
    dict_0['title'] = 'foo - bar'

# Generated at 2022-06-26 13:50:48.857527
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()

if __name__ == '__main__':
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:50:53.434167
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = ''
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = dict()
    dict_0['title'] = str_0
    # assert_equal(metadata_from_title_p_p_0.run(dict_0), ([], dict_0))


# Generated at 2022-06-26 13:50:57.866454
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = ''
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    int_0 = 0
    map_0 = {int_0: int_0}
    list_0 = []
    list_1 = metadata_from_title_p_p_0.run(map_0)
    assert(list_0 == list_1)


# Generated at 2022-06-26 13:51:01.248626
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    #NOTE: DON'T CARE ABOUT PARAMETER info
    info = None

    # call method run of class MetadataFromTitlePP
    metadata_from_title_p_p_0 = MetadataFromTitlePP()
    metadata_from_title_p_p_0.run(info)



#FIXME: add some tests for class MetadataFromTitlePP

# Generated at 2022-06-26 13:51:07.595692
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Input Params
    info = {
        'title': 'Foo - Bar',
        'ext': 'mp3',
        'format': 'mp3'
    }

    # Expected Results
    expected_result = ([], {
        'title': 'Foo - Bar',
        'ext': 'mp3',
        'format': 'mp3'
    })

    # Build test object
    metadata_from_title_p_p_0 = MetadataFromTitlePP('', '%(title)s - %(artist)s')

    # Execute method
    actual_result = metadata_from_title_p_p_0.run(info)

    # Verify results
    assert expected_result == actual_result

# Generated at 2022-06-26 13:51:21.670361
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-26 13:51:28.085876
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .extractor import youtube
    str_0 = ''
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0._downloader = youtube.YoutubeIE()
    str_1 = '%(title)s.%(ext)s'
    metadata_from_title_p_p_0._titleformat = str_1
    str_2 = '%(title)s.%(ext)s'
    metadata_from_title_p_p_0._titleregex = str_2
    list_0 = list()
    dict_0 = {'title': 'test_title'}
    metadata_from_title_p_p_0.run(dict_0)
    assert metadata_from_title_p_

# Generated at 2022-06-26 13:51:37.021846
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_1 = ''
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_1, str_1)
    dict_2 = dict()
    dict_2['title'] = ''
    dict_2['url'] = ''
    dict_2['_filename'] = ''
    dict_2['ext'] = ''
    dict_2['fulltitle'] = ''
    dict_2['id'] = ''
    dict_2['uploader'] = ''
    dict_2['upload_date'] = ''
    dict_2['uploader_id'] = ''
    dict_2['location'] = ''
    dict_2['stitle'] = ''
    dict_2['display_id'] = ''
    dict_2['age_limit'] = ''
    dict_2['extractor_key'] = ''


# Generated at 2022-06-26 13:51:45.373392
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(title)s - %(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = 'wtvrvlvl'
    info_0 = '%(title)s - %(artist)s'
    str_2 = 'wtvrvlvl'
    metadata_from_title_p_p_0._format_to_regex(str_2)
    metadata_from_title_p_p_0._titleregex = str_1
    str_3 = 'wtvrvlvl'
    metadata_from_title_p_p_0.run(info_0)

# Generated at 2022-06-26 13:51:51.075749
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    print('running test')
    mftp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert mftp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    info = {'title': 'Test Title - Test Artist'}
    mftp.run(info)
    assert info == {
        'title': 'Test Title',
        'artist': 'Test Artist'
    }

# Generated at 2022-06-26 13:51:55.323262
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = ''
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = ''
    dict_0 = {'downloader': str_1}
    metadata_from_title_p_p_0.run(dict_0)


if __name__ == '__main__':
    import sys
    sys.exit(main(sys.argv))

# Generated at 2022-06-26 13:51:57.630015
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = ''
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = {}
    dict_1 = metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:52:01.031379
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    with open('tests/input/blah.txt') as file_0:
        str_0 = file_0.read()
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.run(str_0)

# Generated at 2022-06-26 13:52:09.239355
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test case 0
    metadata_from_title_p_p_0 = MetadataFromTitlePP(
        '', '%(show)s - %(episode_number)s')
    info_0 = {
        'title':
        'The.Big.Bang.Theory.S01E01.E02.720p.BluRay.x264-SiNNERS'
    }

    # Call the run method of class MetadataFromTitlePP with the
    # defined parameters.
    ret_val_0 = metadata_from_title_p_p_0.run(info_0)

# Generated at 2022-06-26 13:52:12.456602
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = ''
    dict_0 = dict()
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:52:40.038650
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str, index)
    str_0 = ''
    assert_raises(SystemExit, metadata_from_title_p_p_0.run, str_0)
    pass


# Generated at 2022-06-26 13:52:44.749817
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = ''
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)

    dict_0 = dict()
    dict_0['title'] = 'I am the title'
    list_0 = []
    metadata_from_title_p_p_0.run(dict_0)
    assert list_0 == []


# Test cases for class MetadataFromTitlePP

# Generated at 2022-06-26 13:52:48.022526
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = ''
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dictionary_0 = {"title": str_0}
    tuple_0 = ()
    tuple_1 = metadata_from_title_p_p_0.run(dictionary_0)



# Generated at 2022-06-26 13:52:49.840418
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert callable(MetadataFromTitlePP.run)
    assert isinstance(MetadataFromTitlePP.run, types.MethodType)


# Generated at 2022-06-26 13:52:52.881966
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = _set_up_MetadataFromTitlePP()
    info_map = {'title': 'Test - Title'}
    metadata_from_title_p_p_0.run(info_map)



# Generated at 2022-06-26 13:52:55.844767
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = ''
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)


# Generated at 2022-06-26 13:52:57.679051
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    info_0 = {}
    assert(MetadataFromTitlePP.run(info_0) == [])

# Generated at 2022-06-26 13:53:05.866187
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test case 0:
    str_0 = ''
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    # Test case 1:
    str_1 = ''
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_1, str_1)
    # Test case 2:
    str_2 = ''
    metadata_from_title_p_p_2 = MetadataFromTitlePP(str_2, str_2)
    # Test case 3:
    str_3 = ''
    metadata_from_title_p_p_3 = MetadataFromTitlePP(str_3, str_3)
    # Test case 4:
    str_4 = ''
    metadata_from_title_p_p_4 = MetadataFromTitle

# Generated at 2022-06-26 13:53:08.875888
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = ''
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = ''
    dict_0 = {'title':str_1}
    assert metadata_from_title_p_p_0.run(dict_0) == ([], {'title':str_1})

# Generated at 2022-06-26 13:53:16.248809
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = ''
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = collections.OrderedDict()
    dict_0['title'] = str_0
    metadata_from_title_p_p_0.run(dict_0)
    dict_0['title'] = str_0
    metadata_from_title_p_p_0.run(dict_0)
    dict_0['title'] = str_0
    metadata_from_title_p_p_0.run(dict_0)
    dict_0['title'] = str_0
    metadata_from_title_p_p_0.run(dict_0)
    dict_0['title'] = str_0
    metadata_from_title_p_p_