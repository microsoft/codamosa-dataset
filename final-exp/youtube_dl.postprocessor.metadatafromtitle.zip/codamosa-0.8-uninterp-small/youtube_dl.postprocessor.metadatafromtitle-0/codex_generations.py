

# Generated at 2022-06-26 13:44:01.678602
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    info = dict()
    title = info.get('title', None)
    match = re.match(bool_0, title)
    for attribute, value in match.groupdict().items():
        info[attribute] = value
    return [], info


# Generated at 2022-06-26 13:44:03.690502
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)


# Generated at 2022-06-26 13:44:08.682471
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, None)

    metadata_from_title_p_p_0.format_to_regex(('%(title)s - %(artist)s'))
    assert ('(?P<title>.+)\\ \\-\\ (?P<artist>.+)' == metadata_from_title_p_p_0._titleregex)
    # TODO: write more tests
    pass

# Generated at 2022-06-26 13:44:12.860792
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert True == True


if __name__ == '__main__':
    test_MetadataFromTitlePP_run()
    test_case_0()

# Generated at 2022-06-26 13:44:21.435596
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, '%(title)s - %(artist)s')
    bool_0 = True
    str_0 = metadata_from_title_p_p_0.format_to_regex('%(title)s - %(artist)s')
    bool_0 = True
    str_1 = metadata_from_title_p_p_0.format_to_regex('%(title)s%(artist)s')
    dic0 = {}
    list_0 = []
    tuple_0 = (list_0, dic0)
    list_0, dic0 = metadata_from_title_p_p_0.run(dic0)

# Generated at 2022-06-26 13:44:22.879166
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()

# Generated at 2022-06-26 13:44:31.482482
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    bool_0 = False
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    str_0 = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert_equals(str_0, metadata_from_title_p_p_0.format_to_regex('%(title)s - %(artist)s'))
    assert_equals(str_0, metadata_from_title_p_p_0.format_to_regex(str_0))

# Generated at 2022-06-26 13:44:40.197709
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test parameters
    info = {
        'name': 'name',
        'title': 'title'
    }
    # expected output
    expected = ({},
                {
                    'name': 'name',
                    'title': 'title'
                })
    # instantiate
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    # run and compare actual output to expected output
    assert metadata_from_title_p_p_0.run(info) == expected


# Generated at 2022-06-26 13:44:46.904305
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    dict_0 = {"title": "a", "description": "b"}
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    str_0 = metadata_from_title_p_p_0.format_to_regex("(?P<title>.+)\ \-\ (?P<artist>.+)")
    bool_1 = bool_0
    metadata_from_title_p_p_0.run(dict_0)


if __name__ == '__main__':
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:44:55.774747
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    bool_0 = False
    metadata_from_title_p_p_0 = MetadataFromTitlePP(bool_0, bool_0)
    dict_0 = dict()
    dict_0['title'] = bool_0
    dict_0_copy = dict(dict_0)
    list_0 = []
    list_0_copy = list(list_0)
    assert(list_0 == list_0_copy)
    assert(dict_0 == dict_0_copy)
    return metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:45:00.993102
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    info_0 = {}
    metadata_from_title_p_p_0 = MetadataFromTitlePP('https://stackoverflow.com', 'https://stackoverflow.com')
    # TODO: complete this unit test
    assert False


# Generated at 2022-06-26 13:45:01.658996
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()

# Generated at 2022-06-26 13:45:05.912858
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '70.0.3530.4'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = {}
    metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:45:10.241232
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run(): 
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, '0')
    metadata_from_title_p_p_0.run(None)

if __name__ == '__main__':
    test_case_0()
    # test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:45:20.482229
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # title matching %(name)s - %(title)s - %(index)02d.%(ext)s
    titleformat = '%(name)s/%(name)s - %(title)s - %(index)02d.%(ext)s'
    title = 'name/name - title - 01.ext'
    metadata_from_title_p_p_1 = MetadataFromTitlePP(None, titleformat)
    assert metadata_from_title_p_p_1._titleregex == 'name/name\ \-\ title\ \-\ [0-9]{1,2}.ext'
    assert metadata_from_title_p_p_1._titleformat == titleformat

# Generated at 2022-06-26 13:45:21.785579
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert_equal(test_case_0())


if __name__ == '__main__':
    import pytest
    pytest.main()

# Generated at 2022-06-26 13:45:25.442731
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '70.0.3530.4'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = {}
    dict_0['title'] = '70.0.3530.4'
    metadata_from_title_p_p_0.run(dict_0)

# Generated at 2022-06-26 13:45:26.812746
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert False # TODO: implement your test here


# Generated at 2022-06-26 13:45:28.122231
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    # Default args
    res = MetadataFromTitlePP.run()


# Generated at 2022-06-26 13:45:30.972152
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP('70.0.3530.4', '70.0.3530.4')
    metadata_from_title_p_p_0.run('70.0.3530.4')


# Generated at 2022-06-26 13:45:37.878842
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP('', '')
    info_0 = {'title': ''}
    metadata_from_title_p_p_0.run(info_0)

# Generated at 2022-06-26 13:45:41.296516
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '70.0.3530.4'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = {'title': '70.0.3530.4'}
    try:
        metadata_from_title_p_p_0.run(dict_0)
    except Exception as err:
        print(err)


# Generated at 2022-06-26 13:45:48.880299
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test case 1
    title = 'data/YouTube - 10 Unforgettable YouTube Moments.mp4'
    info = {'title': title}
    metadata_from_title_p_p_0 = MetadataFromTitlePP("'%(title)s'", title)
    (r_1, i_1) = metadata_from_title_p_p_0.run(info)
    assert(r_1 == [])
    assert(i_1['title'] == 'data/YouTube - 10 Unforgettable YouTube Moments')


# Generated at 2022-06-26 13:45:52.705470
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(None, '', '', '', '')
    # TODO
    assert(False), 'Not implemented'


# Generated at 2022-06-26 13:46:01.550141
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'u8c%5'
    str_1 = 'G/b:K'
    str_2 = 'Nx-CK'
    str_3 = '2}$wM'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_2, str_2)
    metadata_from_title_p_p_1.run(dict())
    str_4 = 'S(8TJ'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_4, str_0)
    dict_0 = dict()
    dict_0['title'] = str_0
    dict_0['artist'] = str_1


# Generated at 2022-06-26 13:46:12.859308
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '70.0.3530.4'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = '70.0.3530.4'
    dict_1 = {'title': str_1, 'title': str_1}
    metadata_from_title_p_p_0.run(dict_1)
    str_2 = '70.0.3530.4'
    dict_2 = {'title': str_2, 'title': str_2}
    metadata_from_title_p_p_0.run(dict_2)
    str_3 = '70.0.3530.4'
    dict_3 = {'title': str_3, 'title': str_3}
    metadata_from

# Generated at 2022-06-26 13:46:21.923218
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    print('\n>>> Test Case 0\n')
    test_case_0()
    print('\n>>> Test Case 1\n')
    str_0 = ''
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_0 = '%(title)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_0 = '%(title)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_0 = '%(title)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)

# Generated at 2022-06-26 13:46:27.289716
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '70.0.3530.4'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    list_0 = []
    dict_0 = {}
    list_0, dict_0 = metadata_from_title_p_p_0.run(dict_0)
    list_1 = []
    dict_1 = {}
    list_0, dict_0 = metadata_from_title_p_p_0.run(dict_1)

# Generated at 2022-06-26 13:46:37.033252
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '70.0.3530.4'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)

    dict_0 = {}
    dict_0['vcodec'] = '70.0.3530.4'
    dict_0['uploader'] = '70.0.3530.4'
    dict_0['playlist'] = None
    dict_0['_filename'] = '70.0.3530.4'
    dict_0['_type'] = '70.0.3530.4'
    dict_0['autonumber'] = None
    dict_0['uploader_id'] = '70.0.3530.4'
    dict_0['webpage_url'] = '70.0.3530.4'


# Generated at 2022-06-26 13:46:42.372697
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    title = 'Test Title'
    info = {
        'title': title,
        '_filename': 'Test Title on YT.mp4'
    }
    expected = {
        'title': title,
        '_filename': 'Test Title on YT.mp4'
    }
    metadata_from_title_p_p_0 = MetadataFromTitlePP(
        '', '%(title)s - %(artist)s')
    actual = metadata_from_title_p_p_0.run(info)
    assert actual == [], 'Failed to assert that actual is equal to []'
    assert info == expected, 'Failed to assert that info is equal to expected'


# Generated at 2022-06-26 13:46:53.498402
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert MetadataFromTitlePP.run(None, '') is None, "MetadataFromTitlePP.run"


# Test that empty attribute is registered by default
# Test that %Y %m %d %H %M %S is translated as '%Y-%m-%d-%H-%M-%S'
# Test that %Y %m %d %H %M is translated as '%Y-%m-%d_%H-%M'
# Test that %Y %m %d %H is translated as '%Y-%m-%d_%H'
# Test that %Y %m %d is translated as '%Y-%m-%d'
# Test that %Y %m is translated as '%Y-%m'
# Test that %Y is translated as '%Y'
# Test that %Y %m %

# Generated at 2022-06-26 13:46:58.616927
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '70.0.3530.4'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    assert False # TODO: implement your test here


if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:46:59.817017
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_case_0()

# Generated at 2022-06-26 13:47:10.074316
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-26 13:47:16.527536
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '05 - Do It Like That - R3hab Remix.flac'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = '%(title)s.%(ext)s'
    list_0 = metadata_from_title_p_p_0.format_to_regex(str_1)
    metadata_from_title_p_p_0.run(dict())

if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:47:20.216002
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert metadata_from_title_p_p_0.run() == ([], ), 'Expected ([], ), but got: %s' % metadata_from_title_p_p_0.run()


# Generated at 2022-06-26 13:47:22.345836
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Input parameters for the test
    downloader = '70.0.3530.4'
    info = {'title': '70.0.3530.4'}
    
    metadata_from_title_p_p_0 = MetadataFromTitlePP(downloader, None)
    
    metadata_from_title_p_p_0.run(info)


# Generated at 2022-06-26 13:47:27.605994
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '70.0.3530.4'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    assert_equals(metadata_from_title_p_p_0.run("https://www.youtube.com/watch?v=YQHsXMglC9A"), [])

# Generated at 2022-06-26 13:47:31.490792
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '70.0.3530.4'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = dict()
    dict_0[str_0] = str_0
    metadata_from_title_p_p_0.run(dict_0)

# Generated at 2022-06-26 13:47:36.477182
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '70.0.3530.4'
    str_1 = '70.0.3530.4'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_1, str_0)
    int_0 = 5
    value_0 = metadata_from_title_p_p_0.run(int_0)



# Generated at 2022-06-26 13:47:44.320389
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP('6ZFajNUvK8U', '6ZFajNUvK8U')
    info_0 = {}
    list_0 = []
    metadata_from_title_p_p_0.run(info_0)

# Generated at 2022-06-26 13:47:46.388164
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert_equal(metadata_from_title_p_p_0.run(str_0), (list(), str_0))

# Generated at 2022-06-26 13:47:52.715437
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '70.0.3530.4'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    list_0 = []
    # AssertionError: [] != {'title': '70.0.3530.4'}
    assert metadata_from_title_p_p_0.run({'title': '70.0.3530.4'}) == (list_0, list_0)


# Generated at 2022-06-26 13:47:54.828223
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert MetadataFromTitlePP.run(metadata_from_title_p_p_0, str_0) == ([], str_0)


# Generated at 2022-06-26 13:48:04.248576
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pp = MetadataFromTitlePP('test', '%(title)s - %(artist)s')
    assert pp.run({'title': 'Artist Name - Song Title'}) == ([], {'artist': 'Artist Name', 'title': 'Song Title'})
    assert pp.run({'title': 'Doobie Brothers - What a Fool Believes'}) == ([], {'artist': 'Doobie Brothers', 'title': 'What a Fool Believes'})
    assert pp.run({'title': 'Doobie Brothers - What a Fool Believes - iTunes'}) == ([], {'artist': 'Doobie Brothers', 'title': 'What a Fool Believes - iTunes'})

# Generated at 2022-06-26 13:48:06.971252
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    p_0 = _MetadataFromTitlePP_run_p_0()
    t_0 = MetadataFromTitlePP(p_0, p_0)
    t_0.run(p_0)



# Generated at 2022-06-26 13:48:17.702366
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '70.0.3530.4'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    title_0 = 'description'
    info_0 = {'title': title_0}
    audio_filename_0 = 'writer'
    list_0 = ['description', audio_filename_0, title_0, 'creator']
    expected_output_0 = list_0, info_0
    actual_output_0 = metadata_from_title_p_p_0.run(info_0)
    assert actual_output_0 == expected_output_0


# Generated at 2022-06-26 13:48:20.552052
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '70.0.3530.4'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = 'This is a test'
    dict_0 = dict({'foo': str_1, 'title': str_1})
    ret_0, ret_1 = metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:48:24.105112
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_1 = MetadataFromTitlePP(None, None)
    info_1 = {}
    flag_1 = assert_(metadata_from_title_p_p_1.run(info_1) == ([], {}))
    return flag_1


# Generated at 2022-06-26 13:48:34.073534
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert True
    # Testing 
    class _Dummy:
        pass
        
    dummy_downloader = _Dummy()
    dummy_downloader.to_screen = lambda x: None
    str_0 = '70.0.3530.4'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(dummy_downloader, str_0)
    metadata_from_title_p_p_0_info =  {'title': '70.0.3530.4'}
    metadata_from_title_p_p_0_res = metadata_from_title_p_p_0.run(metadata_from_title_p_p_0_info)
    assert metadata_from_title_p_p_0_res[0] == []
    assert metadata_from_title_p

# Generated at 2022-06-26 13:48:43.263703
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Setup
    downloader = None
    titleformat = '%(id)s.%(ext)s'
    pp = MetadataFromTitlePP(downloader, titleformat)
    info = {'title': '70.0.3530.4'}

    # Exercise
    pp.run(info)

    # Verify
    assert info == {'id': '70.0.3530.4', 'title': '70.0.3530.4'}

# Generated at 2022-06-26 13:48:49.263551
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '70.0.3530.4'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    info = {}
    info['title'] = '70.0.3530.4'
    metadata_from_title_p_p_0.run(info)
    info['title'] = '70.0.3530.4 + port'
    metadata_from_title_p_p_0.run(info)
    info['title'] = '70.0.3530.4 + other'
    metadata_from_title_p_p_0.run(info)



# Generated at 2022-06-26 13:48:56.658397
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '70.0.3530.4'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = dict(str_0='70.0.3530.4')
    dict_1 = dict_0.copy()
    empty_list = []
    dict_1.update(empty_list=empty_list)
    dict_2 = dict_1.copy()
    dict_2.update(dict_1=dict_1)
    dict_2.update(empty_list=empty_list)
    dict_3 = dict_2.copy()
    dict_4 = dict_3.copy()
    dict_4.update(dict_3=dict_3)
    dict_5 = dict_4.copy()
    dict_

# Generated at 2022-06-26 13:49:01.173886
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    info_0 = dict()
    title_0 = '70.0.3530.4'
    info_0['title'] = title_0
    metadata_from_title_p_p_0.run(info_0)


# Generated at 2022-06-26 13:49:02.157329
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 13:49:06.183417
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '70.0.3530.4'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = dict()
    dict_0['title'] = str_0
    metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:49:09.628688
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '70.0.3530.4'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.run(attr_0)



# Generated at 2022-06-26 13:49:17.570956
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '70.0.3530.4'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = '70.0.3530.4'
    str_2 = '70.0.3530.4'
    str_3 = '70.0.3530.4'
    metadata_from_title_p_p_0._downloader = str_3
    str_4 = '70.0.3530.4'
    str_5 = '70.0.3530.4'
    str_6 = '70.0.3530.4'
    metadata_from_title_p_p_0._titleregex = str_6
    str_7 = '70.0.3530.4'
    str

# Generated at 2022-06-26 13:49:21.631023
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '70.0.3530.4'
    dict_0 = dict()
    dict_0['title'] = str_0
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:49:29.322497
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'ChromeDriver'
    str_1 = '70.0.3530.4'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_1)
    str_2 = 'xxx'
    str_3 = 'xxx'
    str_4 = 'xxx'
    str_5 = 'xxx'
    info_0 = (('display_id', str_2), ('title', str_3), ('webpage_url', str_4), ('cached_uploader', str_5))
    info_1 = metadata_from_title_p_p_0.run(info_0)
    assert(isinstance(info_1, tuple))


# Generated at 2022-06-26 13:49:45.025381
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '70.0.3530.4'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = 'tile'
    str_2 = 'title'
    dict_0 = {'title': str_1}
    metadata_from_title_p_p_0.run(dict_0)
    dict_0['title'] = str_2
    metadata_from_title_p_p_0.run(dict_0)



# Generated at 2022-06-26 13:49:50.662707
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '70.0.3530.4'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = {'title': str_0}
    list_0 = []
    tuple_0 = (list_0, dict_0)
    assert metadata_from_title_p_p_0.run(dict_0) == tuple_0


# Generated at 2022-06-26 13:49:58.164032
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '70.0.3530.4'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = {}
    dict_0['title'] = '70.0.3530.4'
    info_0 = [dict_0, dict_0]
    metadata_from_title_p_p_0.run(info_0)


if __name__ == '__main__':
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:50:01.980462
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(int(), int())
    metadata_from_title_p_p_0.run(int())
    return

# Generated at 2022-06-26 13:50:07.166623
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '70.0.3530.4'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_0 = '69.0.3497.115'
    str_1 = '59.0.3071.115'
    dict_0 = {str_0: str_1}
    metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:50:10.323278
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '70.0.3530.4'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    map_0 = {'count': 2, 'something': 'else'}
    metadata_from_title_p_p_0.run(map_0)

# Generated at 2022-06-26 13:50:15.209928
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    print('')
    print('unit_test: class MetadataFromTitlePP method: run')
    import sys
    metadata_from_title_p_p = MetadataFromTitlePP(sys.stdout, str())
    info = dict(title = str())
    info = metadata_from_title_p_p.run(info)
    print('Pass')


# Generated at 2022-06-26 13:50:17.784723
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    data_dir = '../youtube_dl/test/test_data'
    post_processor = MetadataFromTitlePP(data_dir, '%(title)s')
    post_processor.run({'title': 'my title'})

# Generated at 2022-06-26 13:50:21.334963
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '70.0.3530.4'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    info_0 = {}
    metadata_from_title_p_p_0.run(info_0)


# Generated at 2022-06-26 13:50:25.543114
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '70.0.3530.4'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = 'The.Vampire.Diaries.S08E15.720p.HDTV.x264-FLEET[ettv]'
    dict_0 = {'title': str_1}
    metadata_from_title_p_p_0.run(dict_0)

# Generated at 2022-06-26 13:50:54.096981
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """Unit test for method run of class MetadataFromTitlePP"""

    metadata_from_title_p_p_0 = MetadataFromTitlePP('', '')
    metadata_from_title_p_p_0.format_to_regex = (lambda metadata_from_title_p_p_0, fmt: fmt)
    dict_0 = dict()
    assert metadata_from_title_p_p_0.run(dict_0) == ([], dict_0)

    metadata_from_title_p_p_0 = MetadataFromTitlePP('', '')
    metadata_from_title_p_p_0.format_to_regex = (lambda metadata_from_title_p_p_0, fmt: fmt)
    dict_0 = dict()

# Generated at 2022-06-26 13:51:01.579376
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # set up test case
    metadata_from_title_p_p_0 = MetadataFromTitlePP('70.0.3530.4', '70.0.3530.4')
    metadata_from_title_p_p_0.downloader = '70.0.3530.4'
    metadata_from_title_p_p_0.open = lambda path, mode='r': path

    class TestLiteral(str):
        def read(self):
            return self

    class TestInfo(dict):
        def __init__(self, title):
            self['title'] = title

    # Test Case: Missing data
    info = TestInfo(
        '%(title)s - %(artist)s')

# Generated at 2022-06-26 13:51:05.504081
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '70.0.3530.4'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_0 = 'true'
    dict_0 = {
        'title': str_0,
        str_0: str_0,
    }
    list_0, dict_0 = metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:51:11.456638
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '70.0.3530.4'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = {'title': '70.0.3530.4', 'artist': 'NA'}
    dict_1 = {'title': '70.0.3530.4'}
    try:
        metadata_from_title_p_p_0.run(dict_1)
    except Exception as _exc:
        print('Ignoring exception: ' + str(_exc))


# Generated at 2022-06-26 13:51:19.166917
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-26 13:51:25.118532
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '70.0.3530.4'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    str_1 = '0.0.0.0'
    str_2 = '0.0.0.0'
    info = metadata_from_title_p_p_0._run(str_1, str_2)
    assert info == ('0.0.0.0', '0.0.0.0')


# Generated at 2022-06-26 13:51:26.914155
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.run(str_0)

# Generated at 2022-06-26 13:51:33.971000
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
  str_0 = 'MP3'
  url_0 = 'https://i.ytimg.com/vi/BoEKaAx4Dy4/maxresdefault.jpg'
  metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, url_0)
  str_1 = 'MP3'
  dict_0 = {'title': str_1}
  metadata_from_title_p_p_0.run(dict_0)

if __name__ == "__main__":
    test_case_0()
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:51:42.538166
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '%(notitle)s%(title)s%(artist)s'
    metadata_from_title_p_p_0 = MetadataFromTitlePP('https://127.0.0.1', str_0)
    dict_0_0 = {'title': 'Luis Fonsi'}
    str_0_0 = '%(title)s'
    metadata_from_title_p_p_0_0 = MetadataFromTitlePP('https://127.0.0.1', str_0_0)
    dict_0 = {'title': 'Luis Fonsi'}
    class_0 = metadata_from_title_p_p_0_0.run(dict_0)
    dict_0 = {}
    dict_0['title'] = 'Luis Fonsi'
   

# Generated at 2022-06-26 13:51:49.407840
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # check if title value is passed correctly
    assert(MetadataFromTitlePP.run(MetadataFromTitlePP, {"title": 'abc'})
           == ([], {'title': 'abc'}))
    # check if a groupdict match returns the correct key, value pair
    assert(MetadataFromTitlePP.run(MetadataFromTitlePP,
                                   {"title": 'acc-bbc'})
           == ([], {'title': 'acc-bbc', 'artist': 'acc'}))


# Generated at 2022-06-26 13:52:46.809889
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '70.0.3530.4'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = dict()
    dict_0['title'] = str_0
    tuple_0 = ()
    tuple_0 = metadata_from_title_p_p_0.run(dict_0)
    str_1 = '70.0.3530.4'
    dict_0['title'] = str_1
    tuple_0 = metadata_from_title_p_p_0.run(dict_0)
    str_2 = '70.0.3530.4'
    dict_0['title'] = str_2
    tuple_0 = metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:52:49.774042
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    info = {}
    info_0 = {'title': '70.0.3530.4'}
    metadata_from_title_p_p_0 = MetadataFromTitlePP(info_0, info_0)
    metadata_from_title_p_p_0.run(info)


# Generated at 2022-06-26 13:52:58.910389
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-26 13:53:04.153458
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # test_case_0
    str_0 = '70.0.3530.4'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    # test_case_1
    str_1 = 'Lg%(title)s.mp4'
    metadata_from_title_p_p_1 = MetadataFromTitlePP(str_1, str_1)


# Generated at 2022-06-26 13:53:06.284623
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = 'title'
    dict_0 = {}
    dict_0['title'] = str_0
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    metadata_from_title_p_p_0.run(dict_0)


# Generated at 2022-06-26 13:53:10.847307
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    x = (
        '%(uploader)s - %(title)s [%(id)s].%(ext)s',
        'Test uploader - Test title [XyZ123].mp4',
        {'ext': 'mp4', 'uploader': 'Test uploader', 'id': 'XyZ123',
         'title': 'Test title'})
    metadata_from_title_p_p_0 = MetadataFromTitlePP(*x)
    metadata_from_title_p_p_0.run(x)



# Generated at 2022-06-26 13:53:13.353536
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert_equal(metadata_from_title_p_p_0.run(str_0, str_0), ([], str_0), 'Test run function result')


if __name__ == '__main__':
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-26 13:53:19.414357
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    str_0 = '70.0.3530.4'
    metadata_from_title_p_p_0 = MetadataFromTitlePP(str_0, str_0)
    dict_0 = metadata_from_title_p_p_0.__init__(str_0, str_0)
    dict_0 = dict()
    dict_0['title'] = '70.0.3530.4'
    list_0 = metadata_from_title_p_p_0.run(dict_0)
    assert list_0[0] == []

# Generated at 2022-06-26 13:53:21.381666
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_p_p_0_instance = MetadataFromTitlePP('', '')
    assert_raises(NotImplementedError, metadata_from_title_p_p_0_instance.run, None)

# Generated at 2022-06-26 13:53:25.821565
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    arg0_0 = '74.0.3729.6'
    expected_0 = ([], '74.0.3729.6')
    actual_0 = MetadataFromTitlePP(arg0_0, arg0_0).run('74.0.3729.6')
    compare_0 = expected_0 == actual_0
    if not compare_0:
        raise AssertionError('Expected {}, but got {}'.format(expected_0, actual_0))

