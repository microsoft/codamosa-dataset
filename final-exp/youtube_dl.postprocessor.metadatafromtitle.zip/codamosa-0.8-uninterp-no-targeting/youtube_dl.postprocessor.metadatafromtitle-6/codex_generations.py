

# Generated at 2022-06-22 09:21:02.517273
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    a = MetadataFromTitlePP(None, '%(asdf)s - %(foobar)s')
    assert a._titleformat == '%(asdf)s - %(foobar)s'
    assert a._titleregex == r'(?P<asdf>.+)\ \-\ (?P<foobar>.+)'



# Generated at 2022-06-22 09:21:12.764842
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')

# Generated at 2022-06-22 09:21:23.057487
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ydl.version import __version__
    from ydl.utils import Downloader
    from ydl.compat import compat_str

    class MockInfo:
        title = 'video - title'
        artist = ''
        track = ''
        album = ''
        genre = ''
        date = ''
        description = ''
        thumbnail = ''
        ext = ''

    # titleformat with regex
    titleformat = '%(artist)s - %(track)s'
    info = MockInfo()
    pp = MetadataFromTitlePP(Downloader(downloader_options={}), titleformat)
    assert pp.format_to_regex(titleformat) == '(?P<artist>.+)\ \-\ (?P<track>.+)'
    pp.run(info)
    assert info['artist'] == 'video'

# Generated at 2022-06-22 09:21:28.866686
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class DummyDownloader:
        def to_screen(self, text):
            pass
    mftpp = MetadataFromTitlePP(DummyDownloader(), 'Artist - Title')

    test_metadata = {}

    result1, res_meta1 = mftpp.run(
        {'title': 'The Artist - The Title', 'ext': 'mp4'})
    assert res_meta1 == {
        'title': 'The Title', 'ext': 'mp4', 'artist': 'The Artist'}

    result2, res_meta2 = mftpp.run(
        {'title': 'The Artist - The Title - A Version', 'ext': 'mp4'})
    assert res_meta2 == {
        'title': 'The Title - A Version', 'ext': 'mp4', 'artist': 'The Artist'}

    result

# Generated at 2022-06-22 09:21:40.242416
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(artist)s')
    assert pp._titleformat == '%(artist)s', pp._titleformat
    assert pp._titleregex == '(?P<artist>.+)', pp._titleregex

    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleformat == '%(title)s', pp._titleformat
    assert pp._titleregex == '(?P<title>.+)', pp._titleregex

    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s', pp._titleformat
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)', pp._

# Generated at 2022-06-22 09:21:45.738611
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    test_titleformat = '%(title)s - %(artist)s'
    regex = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, test_titleformat)._titleregex == regex


# Generated at 2022-06-22 09:21:55.692807
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    class DummyDownloader:
        def to_screen(self, message):
            return

    assert MetadataFromTitlePP(DummyDownloader(), '').format_to_regex('') == ''
    assert MetadataFromTitlePP(DummyDownloader(), '%(title)s - %(artist)s').format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(DummyDownloader(), '%(part_number)s/%(part_number)s').format_to_regex('%(part_number)s/%(part_number)s') == '(?P<part_number>.+)/(?P<part_number>.+)'

# Generated at 2022-06-22 09:22:05.104264
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .YoutubeDL import YoutubeDL
    from .extractor.common import InfoExtractor

    downloader = YoutubeDL({})
    class MockIE(InfoExtractor):
        _VALID_URL = r''
        _TITLE = r''

    info = MockIE._fetch_video_info(downloader)
    pp = MetadataFromTitlePP(downloader, "%(title)s - %(artist)s").run(info)

    print("Unit test for constructor of class MetadataFromTitlePP")
    print("    Test is passed if two empty lines are output")
    print("================")
    print("")


# Generated at 2022-06-22 09:22:13.888451
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest

    class TestDownloader(object):
        def __init__(self):
            self.to_screen_messages = []
        def to_screen(self, msg):
            self.to_screen_messages.append(msg)

    def check_title(title, titleformat, expected_metadata, expected_to_screen_messages):
        info = {'title': title}
        dl = TestDownloader()

        pp = MetadataFromTitlePP(dl, titleformat)
        metadata, info = pp.run(info)
        to_screen_messages = [msg for msg in dl.to_screen_messages if msg.startswith('[fromtitle]')]

        assert expected_metadata == metadata
        assert expected_to_screen_messages == to_screen_messages

    # successful parse

# Generated at 2022-06-22 09:22:20.748197
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert MetadataFromTitlePP.format_to_regex('bla %(title)s bla') == 'bla\ (?P<title>.+)\ bla'
    assert MetadataFromTitlePP.format_to_regex('bla %(title)s bla - %(artist)s') == 'bla\ (?P<title>.+)\ bla\ \-\ (?P<artist>.+)'

# Generated at 2022-06-22 09:22:35.076824
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl import YoutubeDL
    from youtube_dl.utils import DateRange
    ydl = YoutubeDL(DateRange('20120101', '20120201'))

    # MetadataFromTitlePP
    info_no_issue = {
        'id': '3ZmXqqTSl0c',
        'title': '$uicideBoy$ - My Liver Will Handle What My Heart Can’t',
        'url': 'https://www.youtube.com/watch?v=3ZmXqqTSl0c',
        'ext': 'mp4',
        'format': '137 - 1920x1080 (1080p)',
        'player_url': 'https://www.youtube.com/watch?v=3ZmXqqTSl0c',
    }

# Generated at 2022-06-22 09:22:45.431867
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from collections import namedtuple
    from ydl import YoutubeDL

    # build a fake YoutubeDL object for testing run method
    ydl = YoutubeDL()
    ydl.to_screen = print

    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    info = namedtuple('info', ('title',))('')
    pp.run(info)
    assert info.title is None
    assert info.artist is None
    info = namedtuple('info', ('title',))('title - artist')
    pp.run(info)
    assert info.title == 'title'
    assert info.artist == 'artist'

    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s- %(artist)s')
    info = namedtuple

# Generated at 2022-06-22 09:22:53.806340
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftpp = MetadataFromTitlePP(None, '')
    assert mftpp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert mftpp.format_to_regex('%(title)s - %(artist)s [%(year)i]') == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \[(?P<year>.+)\]'

# Generated at 2022-06-22 09:23:03.637459
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .compat import u
    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest
    from .extractor import get_info_extractor


    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self._fromtitle = MetadataFromTitlePP(
                get_info_extractor('test', 'test'), '%(title)s')

        def test_format_to_regex(self):
            self.assertEqual(
                self._fromtitle.format_to_regex('%(title)s'), r'(?P<title>.+)')

# Generated at 2022-06-22 09:23:12.542188
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .common import YoutubeDL
    ydl = YoutubeDL()
    tfm = YouTubeSubtitlesIE.extract_subtitles.test_MetadataFromTitlePP
    assert tfm(ydl, "Interpret title of video as %(artist)s - %(title)s",
               "The Beatles - Lady Madonna",
               {'title': 'The Beatles - Lady Madonna',
                'artist': 'The Beatles',
                'title': 'Lady Madonna'})
    assert tfm(ydl, "%(artist)s - %(title)s",
               "Lady Madonna",
               {}, 'Could not interpret')
    assert tfm(ydl, "%(artist)s - %(title)s",
               "(X-MAS) Lady Madonna",
               {}, 'Could not interpret')

# Generated at 2022-06-22 09:23:19.514242
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    ydl = object()
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    info = {'title': 'Ludovico Einaudi - Una Mattina - Live At TodaysArt Festival'}
    res, _ = pp.run(info)
    assert len(res) == 0
    assert info['title'] == 'Ludovico Einaudi - Una Mattina - Live At TodaysArt Festival'
    assert info['artist'] == 'Ludovico Einaudi'
    # TODO: Add more test cases

# Generated at 2022-06-22 09:23:29.982577
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    pp = MetadataFromTitlePP(None, '%(foo)s - %(bar)s')
    assert pp._titleformat == '%(foo)s - %(bar)s'
    assert pp._titleregex == r'(?P<foo>.+)\ \-\ (?P<bar>.+)'

    pp = MetadataFromTitlePP(None, '=== %(foo)s ===')
    assert pp._titleformat == '=== %(foo)s ==='
    assert pp._titleregex == r

# Generated at 2022-06-22 09:23:39.813415
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    from ytdl.downloader import Downloader
    from ytdl.postprocessor import PostProcessor
    from ytdl.FileDownloader import FileDownloader

    if sys.version_info[0] >= 3:
        unicode = str

    def add_info_dict(**kwargs):
        def _add_info_dict(d, key, value):
            if value:
                d[key] = unicode(value)
        return lambda d, fd: _add_info_dict(d, **kwargs)

    class FakeFileDownloader(FileDownloader):
        def __init__(self, ydl, filename, info_dict):
            FileDownloader.__init__(self, ydl, {'filename': filename})
            self.info = dict(info_dict)


# Generated at 2022-06-22 09:23:51.181430
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from_title = MetadataFromTitlePP('downloader', '%(title)s - %(artist)s')
    assert from_title.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+) - (?P<artist>.+)'
    assert from_title.format_to_regex('%(title)s -%(artist)s') == '(?P<title>.+) -(?P<artist>.+)'
    assert from_title.format_to_regex('%(artist)s - %(title)s') == '(?P<artist>.+) - (?P<title>.+)'

# Generated at 2022-06-22 09:24:00.134029
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    pp = MetadataFromTitlePP(None, '(?P<title>.+) - (?P<artist>.+)')
    assert pp._titleformat == '(?P<title>.+) - (?P<artist>.+)'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-22 09:24:16.639605
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from ytdl.downloader import Downloader
    dl = Downloader('youtube-dl', {})

    mft = MetadataFromTitlePP(dl, '%(title)s -%(artist)s -%(album)s')
    assert mft.format_to_regex('%(title)s -%(artist)s -%(album)s') == \
        r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'

    mft = MetadataFromTitlePP(dl, '%(title)s - (?P<artist>.+)')

# Generated at 2022-06-22 09:24:25.950349
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import unittest
    from ..compat import compat_str, compat_urllib_error
    from ..utils import sanitize_filename

    class TestException(Exception):
        pass

    class Options(object):
        def __init__(self):
            self.download_archive = None

    class Downloader(object):
        def __init__(self):
            self.params = Options()
            self.info_dicts = [{
                'title': 'Video 1 - "Artist 1"',
                'playlist': 'PL1',
                'playlist_title': 'Title 1',
                'playlist_index': 1,
                'url': 'http://example.com/url1.ext',
                'display_id': 'id1',
                'age_limit': 18,
            }]


# Generated at 2022-06-22 09:24:36.849189
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import Downloader


# Generated at 2022-06-22 09:24:47.331212
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .ytdl_test import YoutubeDL

# Generated at 2022-06-22 09:24:56.316790
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pp = MetadataFromTitlePP(None, "%(title)s - %(artist)s")
    data = {'title': 'test'}
    assert pp.run([(None, data)]) == ([], data)
    assert data['title'] == 'test' and data['artist'] is None

    pp = MetadataFromTitlePP(None, "%(title)s - %(artist)s")
    data = {'title': 'test - artist'}
    assert pp.run([(None, data)]) == ([], data)
    assert data['title'] == 'test' and data['artist'] == 'artist'

    pp = MetadataFromTitlePP(None, "%(title)s - %(artist)s")
    data = {'title': 'title - test'}

# Generated at 2022-06-22 09:24:58.182074
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    with pytest.raises(TypeError):
        MetadataFromTitlePP(None, '%(artist)s')



# Generated at 2022-06-22 09:25:02.762791
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class FakeDownloader:
        def to_screen(self, message): pass # do nothing
    downloader = FakeDownloader()
    MetadataFromTitlePP.run(
        downloader,
        {'title': 'The Title - Author Name'},
        '%(title)s - %(author)s'
    )



# Generated at 2022-06-22 09:25:07.987591
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    titleformat = "%(track)s - %(artist)s - %(album)s (%(date)s)"
    titleregex = "%(trackname)s\ -\ %(artist)s\ -\ %(album)s\ \(%(date)s\)"
    t = MetadataFromTitlePP()
    assert t._titleformat == titleformat
    assert t._titleregex == titleregex

# Generated at 2022-06-22 09:25:17.384605
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys

    def to_screen(msg):
        sys.stdout.write(msg + '\n')

    def match_title(title, regex):
        match = re.match(regex, title)
        if match is None:
            to_screen(
                '[fromtitle] Could not interpret title of video as "%s"'
                % titleformat)
            return None
        return match.groupdict()


# Generated at 2022-06-22 09:25:22.404930
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    metadata_from_title_pp = MetadataFromTitlePP(None, None)
    assert metadata_from_title_pp.format_to_regex(r'%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-22 09:25:44.088450
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    sample_title = 'hello world'
    sample_titleformat = '%(title)s - %(foo)s'
    p = MetadataFromTitlePP(None, sample_titleformat)
    regex = p._titleregex
    assert regex == '(?P<title>.+)\ \-\ (?P<foo>.+)', \
        "Unexpected value for _titleregex: '%s'" % regex
    titleformat = p._titleformat
    assert titleformat == sample_titleformat, \
        "Unexpected value for _titleformat: '%s'" % titleformat
    match = re.match(regex, sample_title)
    assert match is None, \
        "Unexpected match for title: '%s' and regex: '%s'" % (sample_title, regex)

    sample_title = 'hello - world'

# Generated at 2022-06-22 09:25:51.442024
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    """
    Simple unit test to see if method format_to_regex of class
    MetadataFromTitlePP works fine.
    """

# Generated at 2022-06-22 09:25:58.594928
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import os
    # This import is needed because metadata_from_title is used as a postprocessor
    import youtube_dl.postprocessor.metadata_from_title

    # Redirect stdout to stderr
    stdout_real = os.sys.stdout
    os.sys.stdout = os.sys.stderr

    # Initialize downloader for unit test
    downloader = youtube_dl.FileDownloader({'quiet' : True,
                                            'outtmpl' : '%(title)s'})

    # Test pattern with named regex groups
    titleformat = '%(title)s - %(artist)s'
    title = 'Never Gonna Give You Up - Rick Astley'

# Generated at 2022-06-22 09:26:05.703631
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest
    import unittest.mock

    abc = MetadataFromTitlePP(unittest.mock.MagicMock(), '%(foo)s.%(bar)s')
    assert abc._titleregex == '(?P<foo>.+)\.(?P<bar>.+)'

    assert abc.run({'title': 'abc.123'}) == ([], {'bar': '123', 'foo': 'abc'})
    assert abc.run({'title': 'abc!'}) == ([], {'bar': None, 'foo': None})

# Generated at 2022-06-22 09:26:12.235344
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    """
    Unit test for constructor of class MetadataFromTitlePP
    """
    assert (MetadataFromTitlePP(None, '%(title)s - %(artist)s')
            ._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)')
    assert (MetadataFromTitlePP(None, '%(title)s %(artist)s')
            ._titleregex == '%\(title\)s\ %\(artist\)s')

# Generated at 2022-06-22 09:26:19.664826
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleregex == '(?P<title>.+)'
    pp = MetadataFromTitlePP(None, '%(title)s%%%(artist)s')
    assert pp._titleregex == '(?P<title>.+)%%(?P<artist>.+)'
    pp = MetadataFromTitlePP(None, 'xx%(title)s%%%(artist)s')
    assert pp._titleregex == 'xx(?P<title>.+)%%(?P<artist>.+)'
    pp = MetadataFromTitlePP(None, '%(title)s%%%(artist)sxx')
    assert pp._titleregex == '(?P<title>.+)%%(?P<artist>.+)xx'
    pp = MetadataFromTitlePP

# Generated at 2022-06-22 09:26:28.696388
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    testcases = [
        ['%(title)s - %(artist)s', '(?P<title>.+)\ \-\ (?P<artist>.+)'],
        ['%(title)s', '(?P<title>.+)'],
        ['%(title)s(%(ext)s)', '(?P<title>.+)(?P<ext>.+)'],
        ['%(title)s - video %(format)s', '(?P<title>.+)\ \-\ video\ (?P<format>.+)'],
        ]
    for fmt, regex in testcases:
        mftpp = MetadataFromTitlePP(None, fmt)
        if not mftpp.format_to_regex(fmt) == regex:
            return False
    return True


# Generated at 2022-06-22 09:26:34.108251
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    p = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert p._titleformat == '%(title)s - %(artist)s'
    assert p._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'



# Generated at 2022-06-22 09:26:43.106159
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """Test that the regex is created correctly"""
    import unittest

    class MockDownloader(object):
        def __init__(self):
            self.to_screen = unittest.mock.Mock()

    downloader = MockDownloader()
    info = {
        'title': 'WhatsApp - My Friends 2017'
    }
    metadata_from_title = MetadataFromTitlePP(
        downloader, '%(title)s - %(year)s'
    )
    metadata_from_title.run(info)
    expected_info = {
        'title': 'WhatsApp - My Friends',
        'year': '2017'
    }
    assert info == expected_info


# Generated at 2022-06-22 09:26:51.329315
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    import pytest

    tftpp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')

    assert tftpp.format_to_regex('%(title)s - %(artist)s') == (
        r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    )

    assert tftpp.format_to_regex('%(artist)s - %(title)s') == (
        r'(?P<artist>.+)\ \-\ (?P<title>.+)'
    )

# Generated at 2022-06-22 09:27:18.319352
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert (MetadataFromTitlePP(None, '%(title)s - %(artist)s')
            ._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)')

# Generated at 2022-06-22 09:27:28.589569
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL

    filename = 'test.mp4'

    # Test that title is parsed
    info = MetadataFromTitlePP(YoutubeDL(), 'Video %(title)s - %(artist)s').run_old(
        {
            'title': 'Video test - artist',
            '_filename': filename,
            'ext': 'mp4',
            'artist': '',
        }
    )[1]
    assert info['title'] == 'test'
    assert info['artist'] == 'artist'

    # Test that %(title)s is not matched on the filename

# Generated at 2022-06-22 09:27:39.010083
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from collections import namedtuple

    class ExampleExtractor(object):
        IE_NAME = 'example'
        _TITLE_RE = r'(?P<title>.+)\ -\ (?P<artist>.+)'

        def _real_extract(self, url):
            video_id = 'VIDEOID'
            video_title = 'Video Title - Artist'

            return {'id': video_id,
                    'title': video_title,
                    'extractor': self.IE_NAME}

        def _extract_info_dict(self, info_dict):
            return info_dict

    InfoDict = namedtuple('InfoDict', ['get', '__getitem__'])

# Generated at 2022-06-22 09:27:49.615413
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ydl_setup import YDL

    # Test the regex-based titleformat
    ydl_opts = {
        'metadatafromtitle': '%(title)s-%(artist)s'
    }
    ydl = YDL(ydl_opts)

    title = 'abc-def'
    info = {'title': title}
    mftpp = MetadataFromTitlePP(ydl, ydl_opts['metadatafromtitle'])
    _, info = mftpp.run(info)

    assert info['artist'] == 'def'
    assert info['title'] == 'abc'

    # Test the straight string titleformat
    ydl_opts = {
        'metadatafromtitle': 'abc-def'
    }
    ydl = YDL(ydl_opts)


# Generated at 2022-06-22 09:27:55.315491
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Create an instance of the MetadataFromTitlePP class and use it on a
    # dictionary object. The dictionary object should be changed and the
    # inputs should be returned unchanged.
    import copy
    info = {'title': 'This is a test title - with a dash'}
    pp = MetadataFromTitlePP(None, '%(title)s - %(with)s %(dash)s')
    res, info = pp.run(copy.deepcopy(info))
    assert(len(res) == 0)
    assert(info['title'] == 'This is a test title - with a dash')
    assert(info['with'] == 'with')
    assert(info['dash'] == 'dash')



# Generated at 2022-06-22 09:28:05.824998
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from . import YoutubeDL
    from .downloader import FileDownloader
    from .postprocessor import FFmpegMetadataPP
    from .extractor import get_info_extractor
    from .compat import compat_str

    downloader = FileDownloader(dict())
    ie_mock = get_info_extractor(downloader, compat_str('youtube'))
    ie_mock.set_downloader(downloader)
    downloader.add_info_extractor(ie_mock)
    ffmpeg_pp = FFmpegMetadataPP(downloader)
    downloader.add_post_processor(ffmpeg_pp)


# Generated at 2022-06-22 09:28:17.209369
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    import sys
    import os.path

    sys.path.append(os.path.dirname(os.path.dirname(__file__)))

    from YDL.postprocessor.MetadataFromTitlePP import MetadataFromTitlePP

    mftpp = MetadataFromTitlePP(None, None)


# Generated at 2022-06-22 09:28:24.855228
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL(params={})
    mp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    info = {'title': 'Title - Artist'}
    assert mp.run(info) == ([], {'title': 'Title', 'artist': 'Artist'})
    # unicode in title (from utf8)

# Generated at 2022-06-22 09:28:34.906638
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # pylint: disable=import-outside-toplevel
    from .downloader import YoutubeDL
    """
    Test parsing of metadata from title
    """
    output = """INFO: fromtitle: parsed title: Some title
INFO: fromtitle: parsed artist: Some artist
INFO: fromtitle: parsed album: Some album
INFO: fromtitle: parsed release_date: Some date
"""
    downloader = YoutubeDL(dict(writedescription=True))
    processor = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s - %(album)s - %(release_date)s')
    info = dict(title='Some title - Some artist - Some album - Some date')
    # pylint: disable=protected-access
    info_result = processor._execute_tests(info)[1]

# Generated at 2022-06-22 09:28:44.645172
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor.common import InfoExtractor
    from .extractor.youtube import YoutubeIE
    from .compat import compat_str
    from .utils import UNICODE_DASH_CHAR
    from .compat import compat_urlparse

    ie = InfoExtractor(FileDownloader())

    # Initialize an instance of MetadataFromTitlePP
    mft = MetadataFromTitlePP(ie._downloader, '%(title)s-%(artist)s')

    # Create a test video
    test_video_id = '9bZkp7q19f0'
    test_video = ie.url_result(compat_urlparse.urljoin(YoutubeIE.ie_key(), test_video_id), YoutubeIE.ie_key())
    test_video_info = test_

# Generated at 2022-06-22 09:29:33.874845
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    expected = r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp._titleregex == expected


# Generated at 2022-06-22 09:29:44.618270
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-22 09:29:51.260621
# Unit test for constructor of class MetadataFromTitlePP

# Generated at 2022-06-22 09:30:01.466105
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .utils import FakeYDL
    ydl = FakeYDL()
    pp = MetadataFromTitlePP(ydl, '%(track)s - %(artist)s - %(title)s %(album)s')

    assert pp.run({'title': '3.  My Loneliness'})[1] == {
        'track': '3', 'title': 'My Loneliness', 'artist': '', 'album': ''}
    assert pp.run({'title': 'At My Best (feat. Hailee Steinfeld)'})[1] == {
        'track': '', 'title': 'At My Best (feat. Hailee Steinfeld)',
        'artist': '', 'album': ''}

# Generated at 2022-06-22 09:30:11.559026
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import sys
    print(sys.version)
    print(sys.version_info)
    mftpp = MetadataFromTitlePP(None, '%(something)s')
    assert(mftpp._titleformat == '%(something)s')
    assert(mftpp._titleregex == '(?P<something>.+)')

    mftpp = MetadataFromTitlePP(None, 'something%(something)s')
    assert(mftpp._titleformat == 'something%(something)s')
    assert(mftpp._titleregex == 'something(?P<something>.+)')

    mftpp = MetadataFromTitlePP(None, 'something%(something)smore')
    assert(mftpp._titleformat == 'something%(something)smore')

# Generated at 2022-06-22 09:30:19.920389
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_str
    

# Generated at 2022-06-22 09:30:25.917159
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    titleformat = '%(artist)s - %(title)s'
    title = 'Some Artist - Some Title'
    ydl = type('DummyYdl', (object,), {'to_screen': lambda s: None})
    pp = MetadataFromTitlePP(ydl, titleformat)
    (result, info) = pp.run({'title': title})
    assert result == []
    assert 'artist' in info
    assert info['artist'] == 'Some Artist'
    assert 'title' in info
    assert info['title'] == 'Some Title'

# Generated at 2022-06-22 09:30:36.988820
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    format_to_regex = MetadataFromTitlePP.format_to_regex

    # Test with a single group
    assert format_to_regex('%(artist)s') == r'(?P<artist>\.+)'
    assert format_to_regex(r'prefix %(artist)s suffix') == r'prefix (?P<artist>\.+) suffix'

    # Test with multiple groups
    assert format_to_regex('%(title)s - %(artist)s') == r'(?P<title>\.+)\ \-\ (?P<artist>\.+)'

    # Test with a group having a default value

# Generated at 2022-06-22 09:30:42.303794
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, None)
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'
    assert 'foo' in pp.format_to_regex('foo')

# Generated at 2022-06-22 09:30:51.296699
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)

    fmt = '%(title)s'
    regex = pp.format_to_regex(fmt)
    assert regex == '(?P<title>.+)', 'Failed to convert %s to %s' % (fmt, regex)

    fmt = '%(title)s - %(artist)s'
    regex = pp.format_to_regex(fmt)
    assert regex == '(?P<title>.+)\ \-\ (?P<artist>.+)', 'Failed to convert %s to %s' % (fmt, regex)

    fmt = '%(title)s - %(artist)s - %(created)s'
    regex = pp.format_to_regex(fmt)