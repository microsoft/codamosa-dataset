

# Generated at 2022-06-22 09:21:03.667011
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    """
    Unit test for constructor of class MetadataFromTitlePP
    """
    downloader = object()
    titleformat = "%(artist)s - %(title)s"
    processor = MetadataFromTitlePP(downloader, titleformat)
    assert processor._titleformat == titleformat
    assert processor._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'

# Generated at 2022-06-22 09:21:08.969552
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # test with a regex
    one = MetadataFromTitlePP(None, '%(title)s')
    two = MetadataFromTitlePP(None, '%(upload_date)s %(title)s')
    # test with a constant
    three = MetadataFromTitlePP(None, 'foo')
    assert one._titleregex == '(?P<title>.+)'
    assert two._titleregex == '(?P<upload_date>.+)\ (?P<title>.+)'
    assert three._titleregex == 'foo'


# Generated at 2022-06-22 09:21:15.460011
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    """ Run all unit tests for class MetadataFromTitlePP """

    # Initialize attributes
    d = None
    titleformat = r'%(title)s'
    titleregex = r'(?P<title>.+)'

    # Try constructor with invalid titleformat
    try:
        MetadataFromTitlePP(d, titleformat)
        ok = False
    except AssertionError:
        ok = True
    assert ok

    # Try constructor with valid titleformat
    try:
        MetadataFromTitlePP(d, titleregex)
        ok = True
    except AssertionError:
        ok = False
    assert ok


# Generated at 2022-06-22 09:21:26.950093
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .extractor import GenYoutubeIE
    from .extractor import YoutubeIE

    downloader = None
    # Tests are expected to work on youtube videos
    ie = YoutubeIE(downloader)
    info = ie.extract('https://www.youtube.com/watch?v=BaW_jenozKc')

    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')

    [], info = pp.run(info)

    assert info['title'] == 'The best of Mozart'
    assert info['artist'] == 'Wolfgang Amadeus Mozart'

    # Tests are expected to work on youtube videos
    ie = YoutubeIE(downloader)
    info = ie.extract('https://www.youtube.com/watch?v=cLy-4s0zTb4')



# Generated at 2022-06-22 09:21:35.196900
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-22 09:21:40.795666
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert pp.format_to_regex(' %(title)s') == '\\ (?P<title>.+)'
    assert pp.format_to_regex('%(title)s ') == '(?P<title>.+)\\ '
    assert pp.format_to_regex(' %(title)s ') == '\\ (?P<title>.+)\\ '

# Generated at 2022-06-22 09:21:48.033614
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # init class
    fmt = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(None, fmt)
    # init info
    info = {'title': 'Flying high - The Police'}
    # run method
    info = pp.run(info)[1]
    # check result
    assert(info['title'] == 'Flying high')
    assert(info['artist'] == 'The Police')

# Generated at 2022-06-22 09:21:58.491741
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    dl = object()
    pp = MetadataFromTitlePP(dl, '%(title)s - %(artist)s')
    info = {'title': 'Video title - Artist name'}
    info_out = {}
    [], info_out = pp.run(info)
    assert info_out['title'] == 'Video title'
    assert info_out['artist'] == 'Artist name'

    pp = MetadataFromTitlePP(dl, '%(title)s - %(artist)s')
    info = {'title': 'Video title - Artist name (remix)'}
    info_out = {}
    [], info_out = pp.run(info)
    assert info_out['title'] == 'Video title'
    assert info_out['artist'] == 'Artist name (remix)'

    pp = MetadataFrom

# Generated at 2022-06-22 09:22:06.026456
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl.YoutubeDL import YoutubeDL

    class FakeInfoDict(dict):
        pass

    info = FakeInfoDict({'title': 'mytitle - myartist'})

    titleformat = '%(artist)s - %(title)s'
    pp = MetadataFromTitlePP(YoutubeDL(), titleformat)

    assert info['artist'] == 'myartist'
    assert info['title'] == 'mytitle - myartist'

    pp.run(info)

    assert info['artist'] == 'myartist'
    assert info['title'] == 'mytitle'

# Generated at 2022-06-22 09:22:14.389311
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .youtube_dl.YoutubeDL import YoutubeDL

    # Testing regex feature and addition of metadata from title
    regex = '%(title)s - %(artist)s'
    title = 'Smells Like Teen Spirit - Nirvana'
    info = {'title': title}

    ydl_opts = {
        'postprocessors': [
            {'key': 'MetadataFromTitlePP', 'titleformat': regex},
        ],
    }

    ydl = YoutubeDL(ydl_opts)
    postprocessors = ydl.downloader.post_processors
    postprocessors[0]._titleregex = regex
    ydl.process_info(info)

    assert info['title'] == title
    assert info['artist'] == 'Nirvana'

    # Testing matching of title

# Generated at 2022-06-22 09:22:27.429558
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from common import FileDownloader
    ydl = FileDownloader()
    info = {'title': 'Test - test title - property  -  Hallo Welt'}

# Generated at 2022-06-22 09:22:32.452850
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    p = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert(p._titleformat == '%(title)s - %(artist)s')
    assert(p._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)')


# Generated at 2022-06-22 09:22:44.471166
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    import pytest

# Generated at 2022-06-22 09:22:52.343447
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class MetadataFromTitlePPTest(MetadataFromTitlePP):
        def _print_video_info(self, info):
            print(info)

    titleformat = '%(title)s by %(artist)s'
    pp = MetadataFromTitlePPTest(None, titleformat)
    pp.run({'title': 'ABC by 123'})
    pp.run({'title': 'ABC by 123 by 456'})
    pp.run({'title': 'ABC 123'})

# Generated at 2022-06-22 09:23:01.625691
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    class DownloaderMockup:
        def to_screen(self, msg):
            pass

    # List of (format, expected regex)
    cases = [('%(title)s - %(artist)s', '(?P<title>.+)\ \-\ (?P<artist>.+)'),
             ('%(title)s', '(?P<title>.+)'),
             ('%(tle)s', '%(tle)s'),
             ('%(title)%(title)s', '%(title)%(title)s')]
    for testcase in cases:
        assert testcase[1] == MetadataFromTitlePP(
            DownloaderMockup(), testcase[0]).format_to_regex(testcase[0])

# Generated at 2022-06-22 09:23:06.974290
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '%(title)s'

    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '%(title)s'

# Generated at 2022-06-22 09:23:10.302312
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    fmt = '%(title)s - %(artist)s'
    regex = '(?P<title>.+)\\ \-\\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, "xyz").format_to_regex(fmt) == regex


# Generated at 2022-06-22 09:23:14.775132
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Enable debug messages
    import youtube_dl
    youtube_dl.utils.std_headers['debug'] = True

    # Execute method
    m = MetadataFromTitlePP(None, '%(\w+)s')
    m.run({'title': 'Expected title'})

# Generated at 2022-06-22 09:23:26.648572
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    Tests MetadataFromTitlePP for all variations of self._titleregex
    """
    class DummyDownloader:
        def to_screen(self, txt):
            print(txt)
    from .embedded_subs import EmbeddedSubtitlePP
    #
    # Test case: Regular expression without any format strings
    #
    metatitleregex = r'^(?P<artist>.*)\s*-\s*(?P<title>.*)\s*$'
    mftpp = MetadataFromTitlePP(DummyDownloader(), metatitleregex)
    info = {'title': 'Mark Knopfler - Why Aye Man'}
    mftpp.run(info)

# Generated at 2022-06-22 09:23:38.114048
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # simple case
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    # % in string not followed by (...)s
    pp = MetadataFromTitlePP(None, '%title - %(artist)s')
    assert pp._titleregex == '%title\ \-\ (?P<artist>.+)'

    # no %(...)s in string
    pp = MetadataFromTitlePP(None, '%title - %artist')
    assert pp._titleregex == '%title\ \-\ %artist'

    # string is regex

# Generated at 2022-06-22 09:23:47.693024
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP.format_to_regex(
        '%(title)s') == r'(?P<title>.+)'
    assert MetadataFromTitlePP.format_to_regex(
        '%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP.format_to_regex(
        '%(title)s - %(artist)s - %(album)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'


# Generated at 2022-06-22 09:23:57.424947
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # initialize the test
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')

    # test the method format_to_regex
    assert pp.format_to_regex('hi') == 'hi'
    assert pp.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    # test the constructor
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-22 09:24:08.189920
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    p = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert p._titleformat == '%(title)s - %(artist)s'
    assert p._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    p = MetadataFromTitlePP(None, '%(title)s')
    assert p._titleformat == '%(title)s'
    assert p._titleregex == r'(?P<title>.+)'

    # string that doesn't need escaping
    p = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert p._titleformat == '%(title)s - %(artist)s'

# Generated at 2022-06-22 09:24:19.927989
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import sys
    import unittest

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.fmt = '%(title)s - %(artist)s'
            self.title = 'Hello (World) - Some Artist'

        def test_regex_conversion(self):
            p = MetadataFromTitlePP(None, self.fmt)
            regex = p._titleregex
            match = re.match(regex, self.title)
            self.assertIsNotNone(match, 'Test title does not match title format')
            for attribute, value in match.groupdict().items():
                self.assertEqual(value, 'Hello (World)')
                self.assertEqual(attribute, 'title')


# Generated at 2022-06-22 09:24:27.430524
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # pylint: disable=unused-variable
    # variables are used for testing
    """
    Test for method run of class MetadataFromTitlePP

    """
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    import os

    class FakeInfo:
        def __init__(self, title):
            self.title = title

    class FakeYoutubeDL:
        def __init__(self, start_time, end_time):
            self.params = {}
            self.params['start_time'] = start_time
            self.params['end_time'] = end_time
            self.to_screen_output = []
            self.to_screen_output_expected = []


# Generated at 2022-06-22 09:24:36.417018
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-22 09:24:45.694049
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # Test for error
    fmt = '%(title)s - %(artist)s'
    regex = r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, fmt).format_to_regex(fmt) == regex
    # Test for no error
    fmt = '%(title)s - %(artist)s %(%(title)s'
    regex = r'(?P<title>.+)\ \-\ (?P<artist>.+)\ %\(%\(title\)s'
    assert MetadataFromTitlePP(None, fmt).format_to_regex(fmt) == regex


# Generated at 2022-06-22 09:24:53.724283
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert(pp._titleformat == '%(title)s - %(artist)s')
    assert(pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)')

    pp = MetadataFromTitlePP(None, '%(title)s')
    assert(pp._titleformat == '%(title)s')
    assert(pp._titleregex == '(?P<title>.+)')

    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(album)s')
    assert(pp._titleformat == '%(title)s - %(artist)s - %(album)s')

# Generated at 2022-06-22 09:25:02.910524
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.YoutubeDL import YoutubeDL
    downloader = YoutubeDL()
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    # Valid input
    info = {'title': 'title'}
    pp.run(info)
    assert info == {'title': 'title'}
    info = {'title': 'title - artist'}
    pp.run(info)
    assert info == {'title': 'title', 'artist': 'artist'}
    # Invalid input
    info = {'title': 'title'}
    pp.run(info)
    assert info == {'title': 'title'}

# Generated at 2022-06-22 09:25:12.353168
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-22 09:25:22.731261
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleregex == '(?P<title>.+) - (?P<artist>.+)'

    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(album)s')
    assert pp._titleregex == '(?P<title>.+) - (?P<artist>.+) - (?P<album>.+)'

    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleregex == '(?P<title>.+)'

    pp = MetadataFromTitlePP(None, '%(title)s by %(artist)s')
    assert pp._titleregex == '(?P<title>.+) by (?P<artist>.+)'

# Generated at 2022-06-22 09:25:28.771305
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    downloader = None
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    pp = MetadataFromTitlePP(downloader, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '%(title)s'

# Generated at 2022-06-22 09:25:37.360923
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import pytest
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.version import __version__
    downloader = FileDownloader(params={})
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    info = {'title': 'Pouet'}
    with pytest.raises(ValueError):
        pp.run(info)


# Generated at 2022-06-22 09:25:41.725612
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert (MetadataFromTitlePP(None, '%(title)s - %(artist)s')
                ._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)')
    assert (MetadataFromTitlePP(None, '%(title)s')._titleregex
            == '(?P<title>.+)')


# Generated at 2022-06-22 09:25:45.727307
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    # test regex with escaped characters
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s [\(\)]')
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \[\\\(\)\]'

    # test regex with escaped characters inside %(...)s
    pp = MetadataFromTitlePP(None, '%(title)s - [\(\)]')

# Generated at 2022-06-22 09:25:54.870606
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == r'(?P<title>.+)'
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'

# Generated at 2022-06-22 09:26:04.305325
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '')
    assert pp.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s [%(year)s]') == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \[(?P<year>.+)\]'

# Generated at 2022-06-22 09:26:14.541132
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class DummyDownloader(object):
        def to_screen(self, msg):
            self.msg = msg

    # test 1
    titleformat = '%(title)s - %(artist)s'
    title = 'test - test2'
    mdftpp = MetadataFromTitlePP(DummyDownloader(), titleformat)

    info = {'title': title}
    result, info = mdftpp.run(info)

    assert result == []
    assert 'artist' in info
    assert info['artist'] == 'test2'

# Test for method format_to_regex

# Generated at 2022-06-22 09:26:24.030087
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mft = MetadataFromTitlePP(None, None)
    assert mft.format_to_regex('foo %(bar)s baz') == 'foo\ (?P<bar>.+)\ baz'
    assert mft.format_to_regex('foo %(b..r)s baz') == 'foo\ (?P<b..r>.+)\ baz'
    assert mft.format_to_regex('foo %(baz)s') == 'foo\ (?P<baz>.+)'
    assert mft.format_to_regex('%(baz)s baz') == '(?P<baz>.+)\ baz'
    assert mft.format_to_regex('%(baz)s') == '(?P<baz>.+)'


# Generated at 2022-06-22 09:26:30.385264
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    testcases = [
        ('%(title)s - %(artist)s', r'(?P<title>.+)\ \-\ (?P<artist>.+)'),
        ('%(track)s. %(title)s', r'(?P<track>.+)\.(?P<title>.+)'),
        ('%(track)s.%(title)s', r'(?P<track>.+)\.(?P<title>.+)'),
    ]
    for idx, (format, expected_regex) in enumerate(testcases, start=1):
        actual_regex = pp.format_to_regex(format)

# Generated at 2022-06-22 09:26:45.050419
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    titleformat = '%(title)s - %(artist)s'
    titleregex = r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    title = 'te.st - artist'
    info = {'title': title}
    pp = MetadataFromTitlePP(None, titleformat)
    pp.format_to_regex = lambda x: titleregex
    pp.run(info)
    assert info['title'] == 'te.st'
    assert info['artist'] == 'artist'
    # This time with a titleformat containing no regex group
    titleformatnonregex = '%(title)s - %(artist)s'
    title = 'te.st - artist'
    info = {'title': title}

# Generated at 2022-06-22 09:26:52.108718
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # We test the method with a format string that contains all the
    # possible tokens
    fmt = '%(uploader)s.%(title)s.%(ext)s'
    # and the expected regular expression
    expected_regex = r'(?P<uploader>.+)\.(?P<title>.+)\.(?P<ext>.+)'
    pp = MetadataFromTitlePP(None, fmt)
    regex = pp.format_to_regex(fmt)
    assert regex == expected_regex


# Generated at 2022-06-22 09:27:03.279773
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.downloader.YoutubeDL import YoutubeDL

    from .common import FileDownloader

    metadata = {'title': 'VIDEO_TITLE - ARTIST'}
    ydl = YoutubeDL({'writethumbnail': True, 'writeautomaticsub': True, 'writeinfojson': True, 'outtmpl': '%(title)s.%(ext)s'})
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    pp.run(metadata)
    assert metadata['title'] == 'VIDEO_TITLE'
    assert metadata['artist'] == 'ARTIST'

    metadata = {'title': 'VIDEO_TITLE - ARTIST - ALBUM'}

# Generated at 2022-06-22 09:27:14.878700
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .common import FileDownloader
    ydl = FileDownloader(None)

    # verify that titleformat is saved as expected
    mftpp = MetadataFromTitlePP(ydl, "%(artist)s - %(title)s [%(id)s]")
    assert isinstance(mftpp, MetadataFromTitlePP)
    assert mftpp._titleformat == "%(artist)s - %(title)s [%(id)s]"

    # verify that titleregex is created as expected:
    # with %(..)s without escaping
    mftpp = MetadataFromTitlePP(ydl, "%(artist)s - %(title)s [%(id)s]")

# Generated at 2022-06-22 09:27:21.914077
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    class Options(object):
        def __init__(self):
            self.format = '%(title)s - %(artist)s'
            self.verbose = False

    from ytdl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({'extract_flat': 'in_the_same_dir', 'writethumbnail': False})
    pp = MetadataFromTitlePP(ydl, Options().format)
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    pp = MetadataFromTitlePP(ydl, 'Test Title')
    assert pp._titleregex == 'Test Title'

# Generated at 2022-06-22 09:27:27.072481
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.utils import DateRange
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL(params={'noplaylist': True})
    ydl.add_post_processor(
        MetadataFromTitlePP(ydl, '%(artist)s - %(title)s - %(album)s - %(tracknumber)s'))
    info = ydl.extract_info(
        'https://www.youtube.com/watch?v=fJ9rUzIMcZQ&list=PL70DEC2B0568B5469',
        download=False)
    assert info['artist'] == 'The Roots'
    assert info['title'] == 'The Fire (Feat. John Legend)'
    assert info['album'] == 'How I Got Over'
    assert info['tracknumber']

# Generated at 2022-06-22 09:27:29.142294
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mp = MetadataFromTitlePP(object, None)
    fmt = "%(title)s - %(artist)s - %(date)s"
    regex = (r'(?P<title>.+)\ \-\ ' +
             r'(?P<artist>.+)\ \-\ ' +
             r'(?P<date>.+)')
    assert mp.format_to_regex(fmt) == regex

# Generated at 2022-06-22 09:27:39.351292
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '')

    # test simple string attributes
    assert pp.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s - %(album)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'

    # test escape of special characters

# Generated at 2022-06-22 09:27:44.929924
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Arrange
    mftpp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    info = {'title': 'TestTitle - ArtistOfTest'}

    # Act
    [], info = mftpp.run(info)

    # Assert
    assert info['title'] == 'TestTitle - ArtistOfTest'
    assert info['artist'] == 'ArtistOfTest'

# Generated at 2022-06-22 09:27:54.972200
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)

    assert pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('abcd - %(artist)s') == r'abcd\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert pp.format_to_regex('%(artist)s') == r'(?P<artist>.+)'

# Generated at 2022-06-22 09:28:09.316223
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from unittest.mock import Mock
    downloader_mock = Mock(to_screen=Mock())
    postprocessor = MetadataFromTitlePP(downloader_mock, '%(title)s - %(artist)s')
    info = {'id': 'ar123',
            'title': 'The title - The artist',
            'format': 'bestaudio',
            'formats': [{'ext': 'm4a'}],
            'extractor': 'youtube'}
    expected_info = {'id': 'ar123',
                     'title': 'The artist',
                     'artist': 'The title',
                     'format': 'bestaudio',
                     'formats': [{'ext': 'm4a'}],
                     'extractor': 'youtube'}

# Generated at 2022-06-22 09:28:20.155373
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # Test 1: Simple
    titleformat = '%(title)s'
    regex = MetadataFromTitlePP(None, titleformat).format_to_regex(titleformat)
    assert regex == '(?P<title>.+)'

    # Test 2: Simple with escaping
    titleformat = r'%(title)s \- %(year)s'
    regex = MetadataFromTitlePP(None, titleformat).format_to_regex(titleformat)
    assert regex == r'(?P<title>.+)\ \-\ (?P<year>\d+)'

    # Test 3: Simple with optional parts
    titleformat = r'%(artist)s - %(title)s \(%(year)s\)'
    regex = MetadataFromTitlePP(None, titleformat).format_to_regex(titleformat)

# Generated at 2022-06-22 09:28:27.447112
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    info = {
        'title': 'Das Lied von der Erde - Der Einsame im Herbst - Gustav Mahler'
    }

    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')

    metadata, info = pp.run(info)
    assert metadata == []
    assert info['title'] == 'Das Lied von der Erde'
    assert info['artist'] == 'Gustav Mahler'

# Generated at 2022-06-22 09:28:37.732807
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftpp = MetadataFromTitlePP('dummy_downloader', '%(title)s - %(artist)s')
    # pass valid format
    assert mftpp.format_to_regex('%(title)s - %(artist)s') \
        == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    # pass valid format with parenthesis
    assert mftpp.format_to_regex('%(title)s - %(artist)s (remix)') \
        == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \(remix\)'
    # pass invalid format and receive unchanged string

# Generated at 2022-06-22 09:28:46.359410
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Initialize instance of class MetadataFromTitlePP with parameters
    # titleformat=%(title)s - %(artist)s
    # and downloader instance
    # which is not needed to test constructor of MetadataFromTitlePP
    test = MetadataFromTitlePP('titleformat=%(title)s - %(artist)s', '')

    # expected value of _titleformat
    # if MetadataFromTitlePP constructor works as expected
    titleformat = '%(title)s - %(artist)s'

    # expected value of _titleregex
    # if MetadataFromTitlePP constructor works as expected
    titleregex = '(?P<title>.+)\ \-\ (?P<artist>.+)'

    # test if _titleformat and _titleregex
    # are set by constructor as expected

# Generated at 2022-06-22 09:28:51.031812
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class DummyYdl():
        def to_screen(self, txt):
            pass
    ydl = DummyYdl()
    pp = MetadataFromTitlePP(ydl, '%(artist)s - %(title)s')
    info = {'title': 'Ronan Keating - If Tomorrow Never Comes'}
    _, info_o = pp.run(info)
    for attr in ['artist', 'title']:
        assert info_o[attr] == info[attr].split()[info[attr].count(' ')]

    pp2 = MetadataFromTitlePP(ydl, '%(artist)s - [%(title)s]')
    info = {'title': 'Ronan Keating - [If Tomorrow Never Comes]'}
    _, info_o = pp2.run(info)

# Generated at 2022-06-22 09:29:01.395972
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Basic test for constructor of class MetadataFromTitlePP
    import unittest
    from unittest import TestCase
    import sys

    dummy_downloader = TestCase(sys.argv)

    titleformat = '%(title)s - %(artist)s'
    metadata_from_title_pp = MetadataFromTitlePP(dummy_downloader, titleformat)
    assert metadata_from_title_pp._titleformat == titleformat
    assert metadata_from_title_pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    titleformat = '%(title)s'
    metadata_from_title_pp = MetadataFromTitlePP(dummy_downloader, titleformat)
    assert metadata_from_title_pp._titleformat == titleformat
    assert metadata

# Generated at 2022-06-22 09:29:05.374971
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.PostProcessor import PostProcessor
    from youtube_dl.InfoExtractors import YoutubeIE
    downloader = YoutubeDL()
    downloader.add_info_extractor(YoutubeIE())
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    assert pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s %(duration)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ (?P<duration>.+)'
    assert pp

# Generated at 2022-06-22 09:29:13.348061
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # First test
    titleformat = 'Songs From The Road: %(artist)s'
    test_titleformat = MetadataFromTitlePP.format_to_regex(titleformat)
    assert test_titleformat == r'Songs From The Road:\ (?P<artist>.+)'
    # Second test
    titleformat = '%(title)s'
    test_titleformat = MetadataFromTitlePP.format_to_regex(titleformat)
    assert test_titleformat == r'(?P<title>.+)'

# Generated at 2022-06-22 09:29:22.391814
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    test_cases = [
        ('%(artist)s - %(title)s', '(?P<artist>.+)\ \-\ (?P<title>.+)'),
        ('%(artist)s - %(title)s', '(?P<artist>.+)\ \-\ (?P<title>.+)'),
        ('%(artist)s - %(title)s', '(?P<artist>.+)\ \-\ (?P<title>.+)'),
        ('%(artist)s  %(title)s', '(?P<artist>.+)\ \ \ (?P<title>.+)'),
        ('%(artist)s - %(title)s', '(?P<artist>.+)\ \-\ (?P<title>.+)'),
    ]
    for titleformat, titleregex in test_cases:
        assert MetadataFromTitle

# Generated at 2022-06-22 09:29:36.112069
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    titleformat = '%(artist)s - %(title)s'
    output = MetadataFromTitlePP(FileDownloader(), titleformat)
    assert output.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert output.run({'title': 'SOLIDEMO - Pride of Tomorrow'}) == ([], {'title': 'SOLIDEMO - Pride of Tomorrow', 'artist': 'SOLIDEMO'})

# Generated at 2022-06-22 09:29:42.521458
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    f = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert f.run({'title': 'Test'})[1] == {'title': 'Test'}
    assert f.run({'title': 'Test - Test'})[1] == {'title': 'Test', 'artist': 'Test'}
    assert f.run({'title': 'Test - Test - Test'})[1] == {'title': 'Test', 'artist': 'Test - Test'}

# Generated at 2022-06-22 09:29:49.930374
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    metadata_pp = MetadataFromTitlePP(None, '')

    assert metadata_pp.format_to_regex('') == ''
    assert metadata_pp.format_to_regex('%(a)s') == '(?P<a>.+)'
    assert metadata_pp.format_to_regex('%%(a)s') == '%%(a)s'
    assert metadata_pp.format_to_regex('%%%(a)s') == '%%%(a)s'
    assert metadata_pp.format_to_regex('%%%%(a)s') == '%%%%(a)s'
    assert metadata_pp.format_to_regex('a') == 'a'

# Generated at 2022-06-22 09:30:00.668476
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, '').format_to_regex('%(a)s') == '(?P<a>.+)'
    assert MetadataFromTitlePP(None, '').format_to_regex('%(a)s%(b)s') == '(?P<a>.+)(?P<b>.+)'
    assert MetadataFromTitlePP(None, '').format_to_regex('%(a)s%(b)s%(c)s') == '(?P<a>.+)(?P<b>.+)(?P<c>.+)'
    assert MetadataFromTitlePP(None, '').format_to_regex('%(a)s - %(b)s') == '(?P<a>.+)\ \-\ (?P<b>.+)'
    assert MetadataFromTitle

# Generated at 2022-06-22 09:30:11.199690
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)

    assert re.match(r'^(?P<title>.+)\ \-\ (?P<artist>.+)$',
                    pp.format_to_regex('%(title)s - %(artist)s')) is not None

    assert re.match(r'^(?P<title>.+)$',
                    pp.format_to_regex('%(title)s')) is not None

    assert re.match(r'^(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)$',
                    pp.format_to_regex('%(title)s - %(artist)s - %(album)s')) is not None

# Generated at 2022-06-22 09:30:19.344206
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    import unittest
    class FormatToRegexTest(unittest.TestCase):
        def setUp(self):
            self._pp = MetadataFromTitlePP(None, None)

        def test_format_to_regex_basic(self):
            self.assertEqual(self._pp.format_to_regex('abc'), 'abc')

        def test_format_to_regex_simple_name(self):
            self.assertEqual(self._pp.format_to_regex('%(title)s'),
                             '(?P<title>.+)')

        def test_format_to_regex_string_before_name(self):
            self.assertEqual(self._pp.format_to_regex('%(title)s_123'),
                             '(?P<title>.+)_123')

# Generated at 2022-06-22 09:30:27.423730
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    ydl._downloader = lambda *args, **kargs: None
    ydl._screen = lambda *args, **kargs: None
    ydl.to_screen = lambda *args, **kargs: None
    from youtube_dl.extractor import YoutubeIE
    youtube_ie = YoutubeIE()
    ydl.add_info_extractor(youtube_ie)

    # Test with simple %(title)s case

# Generated at 2022-06-22 09:30:35.454648
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftpp = MetadataFromTitlePP(None, '')
    assert '%\(title\)s' == mftpp.format_to_regex('%(title)s')
    assert '%\(title\)s - %\(artist\)s' == mftpp.format_to_regex('%(title)s - %(artist)s')
    assert '%\(title\)s - %\(artist\)s and %\(album\)s' == mftpp.format_to_regex('%(title)s - %(artist)s and %(album)s')

# Generated at 2022-06-22 09:30:43.281382
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # test case 1
    mftpp = MetadataFromTitlePP(None, "%(title)s - %(artist)s")
    assert (mftpp._titleregex ==
            r'(?P<title>.+)\ \-\ (?P<artist>.+)')
    # test case 2
    mftpp = MetadataFromTitlePP(None, "%(uploader)s - %(title)s")
    assert (mftpp._titleregex ==
            r'(?P<uploader>.+)\ \-\ (?P<title>.+)')
    # test case 3
    mftpp = MetadataFromTitlePP(None, "%(upload_date)s - %(uploader)s - %(title)s")

# Generated at 2022-06-22 09:30:51.715471
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ..YoutubeDL import YoutubeDL
    import sys
    import io

    # redirect stdout to get it in a string
    sys.stdout = io.StringIO()
    downloader = YoutubeDL(dict(simulate=True))
    metadata_from_title = MetadataFromTitlePP(downloader
                                              , '%(artist)s - %(track)s - %(title)s')
    metadata_from_title.run({'title': 'Metallica - Creeping Death - Live'})
    out = sys.stdout.getvalue()
    sys.stdout.close()
    sys.stdout = sys.__stdout__

    # check that the output is as expected
    # we ignore the first line output since it is the start time
    out = out.splitlines()