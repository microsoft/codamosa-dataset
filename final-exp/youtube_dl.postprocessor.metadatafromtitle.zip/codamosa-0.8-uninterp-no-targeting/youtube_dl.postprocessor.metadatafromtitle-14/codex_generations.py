

# Generated at 2022-06-22 09:21:04.236451
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass


# Generated at 2022-06-22 09:21:08.818549
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    regex = pp.format_to_regex('%(title)s - %(artist)s')
    assert regex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-22 09:21:16.458529
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import ydl_core
    
    ydl = ydl_core.YoutubeDL()
    pp = MetadataFromTitlePP(ydl, '%(title)s %(artist)s')
    
    info = {
        'title': 'Amazing title aa bb cc',
        'artist': '',
    }
    assert pp.run(info) == ([], {
        'title': 'Amazing title',
        'artist': 'aa bb cc',
        })
    
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    
    info = {
        'title': 'Amazing title - aa bb cc',
        'artist': '',
    }

# Generated at 2022-06-22 09:21:21.456667
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, 'foo (bar)')
    # no match
    assert not pp._titleregex.match('bar')
    # match
    m = pp._titleregex.match('bar (foo)')
    assert m is not None
    assert m.groupdict() == {'bar': 'foo'}



# Generated at 2022-06-22 09:21:30.655031
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from ..YoutubeDL import YoutubeDL
    from ..YoutubeDL.utils import DateRange

    ytdl = YoutubeDL({'writedescription': True, 'writeinfojson': True, 'writethumbnail': True, 'writeautomaticsub': True})
    # test with simple format string
    mpp = MetadataFromTitlePP(ytdl, '%(title)s')
    assert mpp._titleregex == '(?P<title>.+)'
    # test with format string containing an extra string
    mpp = MetadataFromTitlePP(ytdl, '%(title)s - %(artist)s')
    assert mpp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    # test with format string containing an extra string and a named group
    mpp = MetadataFrom

# Generated at 2022-06-22 09:21:41.164619
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL


# Generated at 2022-06-22 09:21:48.596231
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadatafromtitlepp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    title_string = 'Test title - Test artist'
    info = {'title': title_string}
    metadatafromtitlepp.run(info)
    assert info['title'] == 'Test title'
    assert info['artist'] == 'Test artist'

if __name__ == '__main__':
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-22 09:21:54.203566
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():

    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(year)s')
    assert pp._titleformat == '%(title)s - %(artist)s - %(year)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<year>.+)'


# Generated at 2022-06-22 09:22:05.426053
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    def test_format(format, regex):
        actual_regex = MetadataFromTitlePP._MetadataFromTitlePP__format_to_regex(format)
        assert actual_regex == regex, \
            'Failed to convert format %s to regex %s, got %s' % (format, regex, actual_regex)
    test_format('%(title)s - %(artist)s', '(?P<title>.+)\ \-\ (?P<artist>.+)')
    test_format('title: %(title)s', 'title:\ (?P<title>.+)')
    test_format('%(year)s - %(title)s', '(?P<year>.+)\ \-\ (?P<title>.+)')

# Generated at 2022-06-22 09:22:14.002343
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    titleformat = '%(artist)s - %(track)s'
    titleregex = MetadataFromTitlePP(None, titleformat)._titleregex
    assert titleregex == r'(?P<artist>.+)\ \-\ (?P<track>.+)'
    titleformat = '%(weird/attribute)s - %(artist)s'
    titleregex = MetadataFromTitlePP(None, titleformat)._titleregex
    assert titleregex == r'(?P<weird\/attribute>.+)\ \-\ (?P<artist>.+)'
    titleformat = '(?P<year>\d\d\d\d) - %(artist)s'
    titleregex = MetadataFromTitlePP(None, titleformat)._titleregex

# Generated at 2022-06-22 09:22:21.244163
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    titleformat = '%(title)s - %(artist)s'
    titlereg = r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    mftpp = MetadataFromTitlePP(None, titleformat)
    assert titlereg == mftpp._titleregex


# Generated at 2022-06-22 09:22:31.122324
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import pytest
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import sanitize_filename

    ydl = YoutubeDL(params={'outtmpl': '%(title)s.%(ext)s'})
    info = {'title': 'sometitle'}
    ydl_pp = MetadataFromTitlePP(ydl, '%(title)s')
    assert ydl_pp.run(info)[1]['title'] == sanitize_filename('sometitle')

    # no match
    ydl_pp = MetadataFromTitlePP(ydl, '%(artist)s - %(title)s')
    assert ydl_pp.run(info)[1]['artist'] == ''


# Generated at 2022-06-22 09:22:39.752050
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp._titleformat == '%(artist)s - %(title)s'
    assert pp._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'

    pp = MetadataFromTitlePP(None, '%(artistfile)s - %(titlefile)s (mv)')
    assert pp._titleformat == '%(artistfile)s - %(titlefile)s (mv)'
    assert pp._titleregex == '(?P<artistfile>.+)\ \-\ (?P<titlefile>.+)\ \(mv\)'

    pp = MetadataFromTitlePP(None, '%(uploader_id)s - %(track_number)s')
    assert pp

# Generated at 2022-06-22 09:22:47.776061
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .YoutubeDL import YoutubeDL
    from .extractor.common import InfoExtractor

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, params):
            super(FakeYoutubeDL, self).__init__(params)
            self.to_screen_strs = []
            self.to_stderr_strs = []
            self.to_screen_called = 0
            self.to_stderr_called = 0

        def to_screen(self, msg):
            self.to_screen_strs.append(msg)
            self.to_screen_called += 1

        def to_stderr(self, msg):
            self.to_stderr_strs.append(msg)
            self.to_stderr_called += 1


# Generated at 2022-06-22 09:22:58.939867
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ydl import YoutubeDL

    def title_to_metadata_cb(d):
        d = dict(d)
        d.setdefault('title', '')
        return d

    def metadata_to_title_cb(d):
        return d.get('title', '')

    def hook_cb(d):
        d = dict(d)
        d.setdefault('info', {})
        d['info']['all_urls'] = d['info'].get('urls', [])
        return d

    ydl = YoutubeDL({'titleformat': '%(title)s - %(artist)s'})
    ydl.add_post_processor(MetadataFromTitlePP(ydl, ydl.params['titleformat']))

# Generated at 2022-06-22 09:23:04.703565
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    tftpp = MetadataFromTitlePP(None, '%(title)s')
    testformat = '%(title)s - %(artist)s'
    testregex = tftpp.format_to_regex(testformat)
    assert testregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'



# Generated at 2022-06-22 09:23:13.140170
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.downloader import Downloader
    from youtube_dl.postprocessor import PostProcessor
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl import FileDownloader
    from youtube_dl.utils import DateRange

    class FakeYoutubeDL(FileDownloader):
        def __init__(self, params):
            FileDownloader.__init__(self, params)

        def report_warning(self, message):
            pass

        def to_screen(self, message):
            pass

        def trouble(self, message):
            pass

    class FakeInfoDict:
        def __init__(self):
            self.filename = 'some_filename'
            self.fulltitle = 'some title'
            self.video_id = 'some id'
            self.url = 'http://someurl.com'

# Generated at 2022-06-22 09:23:24.928027
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '')
    assert '\a - \b' == pp.format_to_regex('\a - \b')
    assert 'a\[b - c\[d' == pp.format_to_regex('a[b - c[d')
    regex = pp.format_to_regex('%(a)s - %(b)s')
    assert 'a - b' == re.match(regex, 'a - b').groupdict()['b']
    assert 'a - b' == re.match(regex, 'a - b').groupdict()['a']
    assert 'aa - b' == re.match(regex, 'aa - b').groupdict()['b']
    assert 'aa - b' == re.match(regex, 'aa - b').group

# Generated at 2022-06-22 09:23:37.505747
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor import YoutubeIE
    from .postprocessor import FFmpegExtractAudioPP
    from .postprocessor import FFmpegMetadataPP
    from .postprocessor import FFmpegVideoConvertorPP

    # Create a test downloader object to reuse common code such as
    # obtaining a file name given title and info dict
    test_downloader = FileDownloader({})

    # Test with a title matching format string
    ie = YoutubeIE({})
    info = {
        'id': 'an id',
        'ext': 'mp4',
        'title': 'This is a title - with an artist',
    }
    filename = test_downloader.prepare_filename(info)

    # Test that the title is parsed correctly

# Generated at 2022-06-22 09:23:42.060174
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'


if __name__ == '__main__':
    test_MetadataFromTitlePP()

# Generated at 2022-06-22 09:23:51.736924
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    obj = MetadataFromTitlePP({}, "")
    assert obj.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert obj.format_to_regex('[%(title)s] %(artist)s - %(album)s') == r'\[(?P<title>.+)\]\ (?P<artist>.+)\ \-\ (?P<album>.+)'

# Generated at 2022-06-22 09:23:59.719894
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test data
    video_info = {'title': 'Title - Artist - Quality'}
    # Expected result
    expected_result = [], {
        'title': 'Title - Artist - Quality',
        'artist': 'Artist',
        'quality': 'Quality'}

    # Initializing test object
    post_processor = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(quality)s')
    # Testing method
    result = post_processor.run(video_info)
    assert result == expected_result


# Generated at 2022-06-22 09:24:05.063960
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    regex = r'(?P<art>\w+)\ \-\ (?P<title>.+)\ \-\ (?P<url>.+)'
    re.match(regex, 'this - is a - test').groupdict()

# Generated at 2022-06-22 09:24:14.720221
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    tests = [
        ('%(title)s',             '(?P<title>.+)'),
        ('%(title)s - %(artist)s', '(?P<title>.+)\ \-\ (?P<artist>.+)'),
        ('%(meta)s - %(meta)s',    '(?P<meta>.+)\ \-\ (?P<meta>.+)'),
        ('%(t)s - %(a)s',          '(?P<t>.+)\ \-\ (?P<a>.+)'),
        ('%%(title)s',            '%%(title)s'),
    ]
    for titleformat, regex in tests:
        assert pp.format_to_regex(titleformat) == regex



# Generated at 2022-06-22 09:24:22.840603
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # This call should fail without exception but log a warning instead.
    titleformat = '%(artist)s - %(title)s'
    MetadataFromTitlePP(None, titleformat)

    # This call should succeed without exception.
    titleformat = '%(artist)s - %(title)s - %(album)s'
    titleformat_regex = r'(?P<artist>.+)\ \-\ (?P<title>.+)\ \-\ (?P<album>.+)'
    pp = MetadataFromTitlePP(None, titleformat)
    assert pp._titleregex == titleformat_regex

# Generated at 2022-06-22 09:24:32.039287
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    class DummyDownloader(object):
        def to_screen(self, *args, **kwargs):
            return

    author = 'Foo'
    title = 'Bar'
    titleformat = '%(title)s - %(artist)s'
    info = {'title' : title}

    downloader = DummyDownloader()
    pp = MetadataFromTitlePP(downloader, titleformat)
    info = pp.run(info)
    assert info[0] == {}
    assert info[1]['title'] == title
    assert info[1]['artist'] == author

# Generated at 2022-06-22 09:24:42.498756
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    class FakeInfoExtractor:
        pass

    class FakeYDL(FileDownloader):
        def to_screen(self, msg):
            # print(msg)
            pass

# Generated at 2022-06-22 09:24:48.422811
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    import unittest
    class Test(unittest.TestCase):
        def test(self):
            self.assertEqual(MetadataFromTitlePP(None, '%(title)s - %(artist)s').format_to_regex('%(title)s - %(artist)s')
                             , '(?P<title>.+)\ \-\ (?P<artist>.+)')
            self.assertEqual(MetadataFromTitlePP(None, '%(title)s - %(artist)s').format_to_regex('%(title)s -')
                             , '(?P<title>.+)\ \-')

# Generated at 2022-06-22 09:24:56.761588
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    def format_to_regex(fmt):
        # see MetadataFromTitlePP.format_to_regex
        lastpos = 0
        regex = ''
        for match in re.finditer(r'%\((\w+)\)s', fmt):
            regex += re.escape(fmt[lastpos:match.start()])
            regex += r'(?P<' + match.group(1) + '>.+)'
            lastpos = match.end()
        if lastpos < len(fmt):
            regex += re.escape(fmt[lastpos:])
        return regex

    assert format_to_regex('') == ''
    assert format_to_regex('%%(title)s') == '%%\(title\)s'
    assert format_to_regex('%(title)s')

# Generated at 2022-06-22 09:25:07.111937
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    class TestMetadataFromTitlePP(MetadataFromTitlePP):
        def __init__(self):
            super(TestMetadataFromTitlePP, self).__init__(None, None)

    tmftpp = TestMetadataFromTitlePP()
    assert tmftpp.format_to_regex(
        '%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    # If it's not a format string, it should be returned unaltered
    assert tmftpp.format_to_regex('Random string') == 'Random string'

    # If the format contains characters to be escaped, they should be as well
    assert tmftpp.format_to_regex(r'Random\string') == r'Random\\string'

    # This

# Generated at 2022-06-22 09:25:18.287147
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # empty format
    pp = MetadataFromTitlePP(None, '')
    assert pp._titleformat == ''
    assert pp._titleregex is None

    # simple format
    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == r'(?P<title>.+)'

    # format with spaces
    pp = MetadataFromTitlePP(None, '%(title)s is %(title)s')
    assert pp._titleformat == '%(title)s is %(title)s'
    assert pp._titleregex == r'(?P<title>.+)\ is\ (?P=title)'

    # format with special characters

# Generated at 2022-06-22 09:25:29.271615
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .compat import compat_test_case, compat_test_main

    class TestMetadataFromTitlePP(compat_test_case.TestCase):
        def setUp(self):
            self.pp = MetadataFromTitlePP(None, None)

        def test_basic_conversion(self):
            fmt = '%%(%s)s' % ')s - %('.join(['title', 'artist'])
            self.assertEqual(self.pp.format_to_regex(fmt),
                             r'(?P<title>.+)\ \-\ (?P<artist>.+)')

        def test_escape_literals(self):
            fmt = '%(title)s - [] [:?;] {'

# Generated at 2022-06-22 09:25:35.280913
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    mp = MetadataFromTitlePP('', '%(title)s - %(artist)s')
    title = 'Title - Artist'
    info = {}
    info['title'] = title
    _, info = mp.run(info)
    assert 'title' in info, "title attribute should have been added to info"
    assert 'artist' in info, "artist attribute should have been added to info"
    assert info['title'] == 'Title', "title attribute should be 'Title'"
    assert info['artist'] == 'Artist', "artist attribute should be 'Artist'"

    mp = MetadataFromTitlePP('', '%(title)s - %(artist)s - another test')
    title = 'Title - Artist - another test'
    info = {}
    info['title'] = title
    _, info = mp.run(info)
   

# Generated at 2022-06-22 09:25:44.464095
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')

    # Regex for %(title)s - %(artist)s should be
    # '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    # Regex for %(title)s - %(artist)s should be
    # '(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-22 09:25:51.443981
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_request
    from .downloader.common import FileDownloader
    from .utils import urlopener


# Generated at 2022-06-22 09:25:57.969735
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    downloader = None
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    title = 'Lil Wayne - Mirror ft. Bruno Mars'
    expected_metadata = {
        'title': 'Lil Wayne',
        'artist': 'Mirror ft. Bruno Mars'
    }
    info = {'title': title}
    empty_list = []
    # test if run() method returns what we expect
    result_list, result_info = pp.run(info)
    assert result_list == empty_list
    assert result_info == expected_metadata

# Unit tests for format_to_regex() method of class MetadataFromTitlePP

# Generated at 2022-06-22 09:25:58.632464
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass

# Generated at 2022-06-22 09:26:07.539557
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import types
    import sys
    test_youtube_dl = types.ModuleType('youtube_dl')
    test_youtube_dl.utils = types.ModuleType('utils')
    test_youtube_dl.utils.std_headers = {}  # dummy

    def to_screen(s):
        sys.stderr.write(s + '\n')
    test_youtube_dl.to_screen = to_screen

    downloader = test_youtube_dl
    titleformat = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(downloader, titleformat)

    info = {'title': 'Test title - Artist\'s name'}
    pp.run(info)
    if info.get('title', None) is not None:
        raise Exception('Unexpected title metadata in info')

# Generated at 2022-06-22 09:26:17.259149
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .youtube import YoutubeIE
    from .common import FileDownloader
    titleformat = '%(title)s'
    id = '__testid__'
    # test MetadataFromTitlePP.run()
    def test_run(title, expected_title):
        ydl = FileDownloader({
            'usenetrc': '',
            'username': '',
            'password': '',
            'videopassword': '',
        })
        ydl.add_info_extractor(YoutubeIE())
        ydl.params.update({
            'videopassword': '',
            'outtmpl': 'test.%(ext)s',
            'format': 'best',
            'forcetitle': True,
        })

# Generated at 2022-06-22 09:26:25.098039
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s')._titleformat == '%(title)s - %(artist)s'
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)')._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, '%(title)s')._titleregex == '%\(title\)s'

# Generated at 2022-06-22 09:26:42.658243
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class InfoDict(dict):
        def __getattr__(self, name):
            return self[name]
        def __setattr__(self, name, value):
            self[name] = value

    class Downloader:
        def to_screen(self, *args, **kwargs):
            pass


# Generated at 2022-06-22 09:26:53.450168
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from io import BytesIO
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import sanitize_title
    from youtube_dl.compat import compat_urlretrieve
    from youtube_dl.compat import compat_etree_parse
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse

    class MockDownloader:
        pass

    downloader = MockDownloader()
    titleformat = '%(testA)s - %(testB)s'
    pp = MetadataFromTitlePP(downloader, titleformat)
    assert re.match(pp._titleregex, 'ABCD - xyz') is not None

# Generated at 2022-06-22 09:27:02.846160
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ..YoutubeDL import YoutubeDL
    from .common import FileDownloader
    from .extractor import gen_extractors


# Generated at 2022-06-22 09:27:09.565233
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP('dummy', '%(artist)s - %(song)s')
    assert pp._titleformat == '%(artist)s - %(song)s', 'title format string not set correctly'
    assert pp._titleregex == '(?P<artist>.+)\ \-\ (?P<song>.+)', 'title format regex not set correctly'

# Generated at 2022-06-22 09:27:17.302832
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    from ydl.YDL import YDL
    class TestYDL(YDL):
        def to_screen(self, msg):
            print(msg)

    y = TestYDL()
    y.add_post_processor(MetadataFromTitlePP(y, '%(title)s - %(artist)s'))
    y.preprocess_info({'title': 'my title - my artist'})
    y.postprocessors[0].run({'title': 'my title - my artist'})


if __name__ == '__main__':
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-22 09:27:27.902350
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .common import FileDownloader
    from .extractor import gen_extractors


# Generated at 2022-06-22 09:27:36.967435
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP("test", "%(artist)s, %(title)s")
    assert pp._titleregex == '(?P<artist>.+),\ (?P<title>.+)'

    pp = MetadataFromTitlePP("test", "%(artist)s - %(title)s")
    assert pp._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'

    pp = MetadataFromTitlePP("test", "Test")
    assert pp._titleregex == 'Test'

    pp = MetadataFromTitlePP("test", "Test.Test")
    assert pp._titleregex == 'Test\.Test'

# Generated at 2022-06-22 09:27:40.473141
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    regex = MetadataFromTitlePP(None, '%(artist)s - %(title)s').format_to_regex('%(artist)s - %(title)s')
    assert r'(?P<artist>.+)\ \-\ (?P<title>.+)' == regex

# Generated at 2022-06-22 09:27:51.055228
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl
    import tempfile
    import os

    # Testing parameters and data
    title = 'My Title - Artist - Album [Other Info]'
    titleformat = '%(title)s - %(artist)s - %(album)s [%(other)s]'
    expected_data = {
        'title': 'My Title',
        'artist': 'Artist',
        'album': 'Album',
        'other': 'Other Info'
    }
    temp_dir = tempfile.mkdtemp(prefix="youtube_dl_test_")

    # create a YoutubeDL object and prepare test
    ydl = youtube_dl.YoutubeDL({'outtmpl': os.path.join(temp_dir, '%(title)s-%(id)s.%(ext)s')})
    pp = MetadataFrom

# Generated at 2022-06-22 09:27:59.858641
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mp = MetadataFromTitlePP(None, '%(videoid)s')
    if mp.format_to_regex('%(videoid)s') != r'(?P<videoid>.+)':
        raise Exception('Test failed')

    mp = MetadataFromTitlePP(None, '%(videoid)s%(author)s')
    if mp.format_to_regex('%(videoid)s%(author)s') != r'(?P<videoid>.+)(?P<author>.+)':
        raise Exception('Test failed')

    mp = MetadataFromTitlePP(None, 'a%(videoid)sb%(author)sc')

# Generated at 2022-06-22 09:28:24.904556
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import Downloader
    from .compat import compat_urlparse

    # Initialize a test downloader
    downloader = Downloader(params={})
    downloader.to_screen = lambda s: s


# Generated at 2022-06-22 09:28:34.938864
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import pytest

    # Empty video title raises an error
    with pytest.raises(AssertionError):
        MetadataFromTitlePP(None, '%(title)s')

    # Invalid title format raises an error
    with pytest.raises(AssertionError):
        MetadataFromTitlePP(None, '%(title)s - %(artist)s')

    # No variable fields in title format
    pp = MetadataFromTitlePP(None, 'Test')
    assert pp._titleformat == 'Test'
    assert pp._titleregex == 'Test'

    # One variable field
    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '(?P<title>.+)'

    # Two variable

# Generated at 2022-06-22 09:28:43.765094
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import youtube_dl
    mp = MetadataFromTitlePP(youtube_dl.YoutubeDL(), '%(character)s')
    pat = mp._titleregex
    assert pat == '%\\(character\\)s'
    assert re.match(pat, '+')
    assert not re.match(pat, '+ ')
    mp = MetadataFromTitlePP(youtube_dl.YoutubeDL(), '%(character)s - %(title)s')
    pat = mp._titleregex
    assert pat == '(?P<character>.+)\\ \\-\\ (?P<title>.+)'
    assert not re.match(pat, '+')
    assert re.match(pat, '+ - ')

# Generated at 2022-06-22 09:28:50.185686
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '%(title)s'
    pp = MetadataFromTitlePP(None, '%(title)s %(artist)s')
    assert pp._titleformat == '%(title)s %(artist)s'
    assert pp._titleregex == '%(title)s\ %(artist)s'

# Generated at 2022-06-22 09:28:54.819797
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    class _Downloader(object):
        _ydl = None

    ydl = _Downloader()

    pp1 = MetadataFromTitlePP(ydl, '%(title)s')
    assert pp1._titleregex == '(?P<title>.+)'
    pp2 = MetadataFromTitlePP(ydl, '%(artist)s - %(title)s')
    assert pp2._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'
    # if format string contains no "%(...)s" - use it as regex
    pp3 = MetadataFromTitlePP(ydl, '^\d+\.')
    assert pp3._titleregex == '^\d+\.'

# Generated at 2022-06-22 09:29:02.781054
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import pytest
    class MockDownloader():
        def to_screen(self, text):
            pass
    
    class MockInfo():
        def __init__(self, title):
            self['title'] = title
    
    fmt = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(MockDownloader(), fmt)
    info = MockInfo('Artist - Title')
    result, info = pp.run(info)
    
    # tests
    assert result == ([], info)
    assert info['artist'] == 'Artist'
    assert info['title'] == 'Title'


# Generated at 2022-06-22 09:29:14.555502
# Unit test for constructor of class MetadataFromTitlePP

# Generated at 2022-06-22 09:29:23.210293
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    from ytdl.YoutubeDL import YoutubeDL

    # Test 1: Check parsing of title in titleformat: "%(title)s - %(artist)s"
    # title: "Dirrty - Christina Aguilera Featuring Redman (Official Video)"
    test_info = {'title': 'Dirrty - Christina Aguilera Featuring Redman (Official Video)'}
    test_downloader = YoutubeDL()
    test_output = ([], {'title': 'Dirrty', 'artist': 'Christina Aguilera Featuring Redman (Official Video)'})
    MetadataFromTitlePP(test_downloader, '%(title)s - %(artist)s').run(test_info)
    assert test_info == test_output[1], 'test 1'

    # Test 2: Check parsing of title in titleformat: "%(title)s-

# Generated at 2022-06-22 09:29:27.516646
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # test the regex conversion of format strings
    titleformat = '%(uploader)s - %(upload_date)s - %(title)s'
    exp_regex = '(?P<uploader>.+)\ \-\ (?P<upload_date>.+)\ \-\ (?P<title>.+)'
    pp = MetadataFromTitlePP(None, titleformat)
    assert pp._titleregex == exp_regex

# Generated at 2022-06-22 09:29:35.293191
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    return
    from collections import namedtuple
    from .compat import compat_http_client
    from .compat import compat_urllib_error
    from .compat import compat_urllib_request
    from .utils import fake_getinfo
    from .YoutubeDL import YoutubeDL
    Downloader = namedtuple('Downloader', 'params')
    urlopen_mock = compat_http_client.HTTPConnection
    Downloader.to_screen = lambda x: x
    Downloader.report_warning = lambda x: x
    Downloader.report_error = lambda x: x
    # Test 2

# Generated at 2022-06-22 09:30:19.419672
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '')

# Generated at 2022-06-22 09:30:24.652375
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class Info_mock:
        def __init__(self):
            self.title = 'blabla'
            self.artist = 'blublu'

    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    info = Info_mock()
    pp.run(info)
    assert info.title == 'blabla'
    assert info.artist == 'blublu'



# Generated at 2022-06-22 09:30:36.095915
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Set up mock Downloader
    class MockDownloader(object):
        def __init__(self):
            self.results = []

        def to_screen(self, result):
            self.results.append(result)

    mock_downloader = MockDownloader()

    # Run MetadataFromTitlePP.run() for test input

# Generated at 2022-06-22 09:30:47.562521
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    if not hasattr(MetadataFromTitlePP, 'format_to_regex'):
        return
    pp = MetadataFromTitlePP(None, '')
    assert pp.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s (%(uploader)s)') == r'(?P<title>.+)\ \((?P<uploader>.+)\)'

# Generated at 2022-06-22 09:30:57.200636
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    metadatapp = MetadataFromTitlePP(None, None)
    tests = [
        # format string, expected regex
        ['', ''],
        ['%(title)s', '(?P<title>.+)'],
        ['%(title)s - %(artist)s', '(?P<title>.+)\ \-\ (?P<artist>.+)'],
        ['$foo - %(artist)s', '\$foo\ \-\ (?P<artist>.+)']
    ]
    for fmt, exp in tests:
        get = metadatapp.format_to_regex(fmt)
        assert get == exp, 'Expected regex for "%s": "%s", got "%s"' % (fmt, exp, get)
