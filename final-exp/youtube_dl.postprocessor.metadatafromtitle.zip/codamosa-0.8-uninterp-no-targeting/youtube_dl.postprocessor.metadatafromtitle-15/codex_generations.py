

# Generated at 2022-06-22 09:21:11.789002
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .youtube_dl import YoutubeDL
    from .YoutubeIE import YoutubeIE
    from .extractor.common import InfoExtractor
    ydl = YoutubeDL()
    ydl.add_info_extractor(YoutubeIE(ydl))

    titleformat = '%(title)s - %(artist)s'
    m_titleformat = re.escape(titleformat)
    m_titleregex = r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    title = 'This is a test - John Doe'
    m_title = re.escape(title)
    meta = {'id': 'abc', 'url': 'http://somevideo/', 'title': title}

# Generated at 2022-06-22 09:21:13.385389
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    mftpp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert mftpp._titleformat == '%(artist)s - %(title)s'
    assert mftpp._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'


# Generated at 2022-06-22 09:21:22.915820
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .youtube_dl import YoutubeDL

    # Call with valid format string
    r = re.compile('(?P<title>.+) - (?P<artist>.+)')
    pp = MetadataFromTitlePP(YoutubeDL(), '%(title)s - %(artist)s')
    assert pp._titleregex == r

    # Call with invalid format string
    try:
        pp = MetadataFromTitlePP(YoutubeDL(), 'Title: %(title)s')
    except ValueError as e:
        assert e.args[0] == 'Format string contains no regex group'
    else:
        assert False, 'ValueError not raised'


if __name__ == '__main__':
    test_MetadataFromTitlePP()

# Generated at 2022-06-22 09:21:32.248449
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({'writesubtitles': True})
    ydl.add_default_info_extractors()

    class FakeDl:
        def to_screen(self, msg):
            print('[fromtitle] ' + msg)

    dl = FakeDl()

    video_title = 'SomeCoolMusic - Some Cool Music - This is a Title'
    info = {'id': 'V0N2lJjRV7', 'title': video_title}
    metadata_from_title_pp = MetadataFromTitlePP(dl, '%(artist)s - %(track)s - %(title)s')
    metadata_from_title_pp.run(info)

    assert info.get('artist') == 'SomeCoolMusic'

# Generated at 2022-06-22 09:21:39.551911
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Check if a regular expression is built for titleformat not containing
    # %(...)s groups
    pp = MetadataFromTitlePP('youtube-dl', '%(title)s')
    assert pp._titleregex == '%(title)s'

    # Check if a regular expression is built for titleformat containing
    # %(...)s groups
    pp = MetadataFromTitlePP('youtube-dl', '%(title)s - %(artist)s')
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-22 09:21:49.511529
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    tests = [('%(title)s - %(artist)s', '(?P<title>.+)\ \-\ (?P<artist>.+)'),
             ('%(artist)s - %(title)s', '(?P<artist>.+)\ \-\ (?P<title>.+)')]
    for test in tests:
        actual = MetadataFromTitlePP(None, test[0]).format_to_regex(test[0])
        assert actual == test[1], 'format_to_regex returned %s instead of %s' % (actual, test[1])


# Generated at 2022-06-22 09:21:54.765978
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .downloader import YoutubeDL
    unittest.TestCase.maxDiff = None
    youtube = YoutubeDL({'quiet': True})
    youtube.process_info({
        'title': 'titletest - artisttest',
        '_filename': 'titletest - artisttest.mp4'})
    youtube.postprocessors[0].run({
        'title': 'titletest - artisttest',
        '_filename': 'titletest - artisttest.mp4',
        'artist': 'foo',
        'title1': 'bar'})


# Generated at 2022-06-22 09:22:06.470292
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    Tests the method MetadataFromTitlePP.run
    """
    from youtube_dl.downloader.common import FileDownloader


# Generated at 2022-06-22 09:22:10.563595
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    obj = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    result = obj.format_to_regex('%(title)s - %(artist)s')
    assert result == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)', result



# Generated at 2022-06-22 09:22:21.658088
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader import Downloader
    from youtube_dl.postprocessor.ffmpeg import FFmpegPostProcessor
    from youtube_dl.utils import DateRange

    expected = {
        'artist': 'Toto',
        'title': 'Africa',
        'track': '01',
        'tracknumber': '01',
        'album': 'Toto IV',
        'year': '1982',
    }


# Generated at 2022-06-22 09:22:33.780466
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP("youtube-dl", "%(title)s - %(artist)s")
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)', \
        "_titleregex is " + pp._titleregex + " instead of (?P<title>.+)\ \-\ (?P<artist>.+)"
    pp = MetadataFromTitlePP("youtube-dl", "some fixed title")
    assert pp._titleregex == "some fixed title", \
        "_titleregex is " + pp._titleregex + " instead of some fixed title"

# Generated at 2022-06-22 09:22:45.029541
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    titleformat = '%(title)-(artist)-(title2)s'
    title = 'abc-xyz-123'
    info = {'title': title}
    downloader = {'to_screen' : lambda x: None}
    metadataFromTitlePP = MetadataFromTitlePP(downloader, titleformat)
    metadataFromTitlePP.run(info)
    assert info == {'title': title, 'title2': '123', 'artist': 'xyz'}
    title = '123'
    info = {'title': title}
    try:
        metadataFromTitlePP.run(info)
        assert False
    except:
        assert True
    assert info == {'title': title}
    titleformat = '%(title)s'
    title = 'a b c'
    metadataFromTitlePP = MetadataFrom

# Generated at 2022-06-22 09:22:56.112443
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    downloader = FakeDownloader()
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s - %(album)s')
    assert pp.format_to_regex('%(title)s - %(artist)s - %(album)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s - %(album)s - %(date)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)\ \-\ (?P<date>.+)'

# Generated at 2022-06-22 09:23:02.234609
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    test_format_to_regex = MetadataFromTitlePP._MetadataFromTitlePP__format_to_regex.im_func
    assert test_format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert test_format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert test_format_to_regex('%(title)s -  %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-22 09:23:10.699344
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import sys
    from .compat import compat_str
    test1_titleformat = '%(title)s - %(artist)s'
    test1_title = 'Title of the video - Artist name'
    test1_metadata = {'title': test1_title,
                      'artist': 'Artist name',
                      'titleformat': test1_titleformat}
    test1_titleregex = '(?P<title>.+)\ \-\ (?P<artist>.+)'

    test2_titleformat = '%(title)s - %(artist)s - %(date)s'
    test2_title = 'Title of the video - Artist name - 2017-12-07'

# Generated at 2022-06-22 09:23:18.041050
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '%(title)s'


# Generated at 2022-06-22 09:23:28.993761
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import pytube

# Generated at 2022-06-22 09:23:39.501487
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.downloader import Downloader
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor import common
    from youtube_dl.extractor.common import InfoExtractor
    downloader = Downloader(YoutubeDL({'format': 'bestaudio/best', 'outtmpl': '%(id)s%(ext)s'}))
    downloader.add_info_extractor(common.InfoExtractor(downloader))
    info = {'title': 'VIDEO_TITLE'}
    pp = MetadataFromTitlePP(downloader, '%(title)s')
    assert pp.run(info)[1] == {'title': 'VIDEO_TITLE'}

# Generated at 2022-06-22 09:23:50.350335
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '')

# Generated at 2022-06-22 09:23:57.128983
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    fmt = '%(song)s - %(artist)s'
    regex = '(?P<song>.+)\ \-\ (?P<artist>.+)'
    titlePP = MetadataFromTitlePP(None, fmt)
    regex_test = re.search(r'%\(\w+\)s', fmt)
    assert titlePP._titleregex == regex or regex_test is None
    assert titlePP._titleformat == fmt

# Generated at 2022-06-22 09:24:07.208938
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import sys
    import io

    # Suppress stdout during the test
    savstdout = sys.stdout
    sys.stdout = io.BytesIO()

    # Object construction
    fmt = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(None, fmt)

    # Test function format_to_regex
    assert pp.format_to_regex(fmt) == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    # Test object MetadataFromTitlePP
    match = re.match(pp._titleregex, 'The xx - On Hold')
    assert match is not None
    assert match.groupdict() == {'title': 'The xx', 'artist': 'On Hold'}

    # Restore stdout
    sys.stdout = savstd

# Generated at 2022-06-22 09:24:10.817985
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    info = {'title': 'Foo - Bar'}
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s').run(info)[1] == \
        {'title': 'Foo', 'artist': 'Bar'}

# Generated at 2022-06-22 09:24:18.312326
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    title = 'test - test_title - test artist - test album'
    format = '%(artist)s - %(title)s - %(album)s'
    info = {'title':title}
    pp = MetadataFromTitlePP(None, format)
    dummy, info = pp.run(info)

    assert info['title'] == 'test_title'
    assert info['album'] == 'test album'
    assert info['artist'] == 'test artist'


# Generated at 2022-06-22 09:24:23.054248
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from . import YoutubeDL
    ydl = YoutubeDL({})
    processor = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    assert processor._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    processor = MetadataFromTitlePP(ydl, '%(title)s')
    assert processor._titleregex == '%\(title\)s'

# Generated at 2022-06-22 09:24:34.234156
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    titleformat = '%(title)s.%(ext)s'
    regex = '(?P<title>.+)\\.(?P<ext>.+)'
    assert(MetadataFromTitlePP(None, titleformat)._titleregex == regex)

    titleformat = '%(title)s.ext'
    regex = '(?P<title>.+)\\.ext'
    assert(MetadataFromTitlePP(None, titleformat)._titleregex == regex)

    titleformat = 'title.%(ext)s'
    regex = 'title\\.(?P<ext>.+)'
    assert(MetadataFromTitlePP(None, titleformat)._titleregex == regex)

    titleformat = '%(title)s'
    regex = '(?P<title>.+)'

# Generated at 2022-06-22 09:24:43.696042
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl.extractor.common import InfoExtractor
    downloader = InfoExtractor()
    f = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    info = {'title': 'My title - My artist'}
    result, info = f.run(info)
    assert info['title'] == 'My title'
    assert info['artist'] == 'My artist'

if __name__ == '__main__':
    import nose2
    nose2.main()

# Generated at 2022-06-22 09:24:49.597337
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    """Unit test for the method format_to_regex of the class MetadataFromTitlePP"""
    titleformat = '%(title)s - %(artist)s'
    titleregex = '^(?P<title>.+)\ \-\ (?P<artist>.+)$'
    assert MetadataFromTitlePP(None, titleformat).format_to_regex(titleformat) == titleregex


# Generated at 2022-06-22 09:24:58.192300
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import ydl
    ydl_opts = {
        'simulate': True,
        'quiet': True,
        'outtmpl': '%(title)s - %(artist)s.%(ext)s',
    }

    def _test_get(i):
        info = {
            'title': 'Yellow Submarine - The Beatles',
            'artist': None,
            'ext': None,
        }
        return info

    class _YDummy(object):
        def __init__(self):
            pass

        def to_screen(self, msg):
            print(msg)

        def download(self, info_dict):
            return info_dict

    ydl = ydl
    ydl.PostProcessor = MetadataFromTitlePP
    ydl._get_info_extractor_name_from_url

# Generated at 2022-06-22 09:25:08.229375
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test conversion of %(..)s to regex
    test_fmt_to_regex = MetadataFromTitlePP(True, '').format_to_regex
    assert test_fmt_to_regex('%(title)s') == r'(?P<title>.+)'
    assert test_fmt_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert test_fmt_to_regex('%(title)s %(artist)s') == r'(?P<title>.+)\ (?P<artist>.+)'

# Generated at 2022-06-22 09:25:10.752631
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # TODO: implement unit test
    print(
        "test_MetadataFromTitlePP_run: Unit test not implemented")
    assert False


# Generated at 2022-06-22 09:25:22.661691
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # testing %(title)s
    titleformat = '%(title)s'
    title = 'a title'
    expected_titleregex = '(?P<title>.+)'
    mftpp = MetadataFromTitlePP('', titleformat)
    assert mftpp._titleformat == titleformat
    assert mftpp._titleregex == expected_titleregex
    assert re.match(mftpp._titleregex, title) is not None
    
    # testing %(title)s - %(artist)s
    titleformat = '%(title)s - %(artist)s'
    title = 'a title - an artist'
    expected_titleregex = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    mftpp = MetadataFromTitlePP('', titleformat)
   

# Generated at 2022-06-22 09:25:26.534163
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp._titleformat == '%(artist)s - %(title)s'
    assert pp._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'


# Generated at 2022-06-22 09:25:27.147077
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass

# Generated at 2022-06-22 09:25:33.858644
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    a = MetadataFromTitlePP(None, '')
    assert a.format_to_regex('%(title)s - %(artist)s') == (
        r'(?P<title>.+)\ \-\ (?P<artist>.+)')
    assert a.format_to_regex('%(title)s - %(artist)s') == (
        r'(?P<title>.+)\ \-\ (?P<artist>.+)')
    assert a.format_to_regex('%(title)s') == r'(?P<title>.+)'

# Generated at 2022-06-22 09:25:44.088117
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import pytest

    # Set values

    # 1. Simple case

    titleformat = '%(title)s'
    title = 'Test title'
    info = {
        'title': title,
        'original_title': '',
        'artist': '',
        'album': '',
        'tracknumber': '',
        'genre': '',
        'date': '',
        'creator': '',
        'releaseyear': '',
        'description': '',
        'thumbnail': '',
        'duration': '',
        'webpage_url': '',
        'ext': ''
    }
    # Create object
    metadata_from_title_pp = MetadataFromTitlePP(None, titleformat)

# Generated at 2022-06-22 09:25:51.442516
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # test if method run of class MetadataFromTitlePP correctly parses
    # info['title'] information into info['artist'] and info['track']

    # test string and match dictionary
    title = 'Taylor Swift - Blank Space'
    match = {'artist': 'Taylor Swift', 'track': 'Blank Space'}

    # create a PostProcessor for testing purposes
    from ..YoutubeDL import YoutubeDL
    from .common import FileDownloader
    downloader = FileDownloader({})
    pp = MetadataFromTitlePP(downloader, '%(artist)s - %(track)s')

    # test for regular expression match
    test_match = re.match(pp._titleregex, title)
    assert test_match is not None
    assert test_match.groupdict() == match

    # test extraction of artist and track information
   

# Generated at 2022-06-22 09:25:58.595004
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s')._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, 'TITLE %(title)s END')._titleregex == 'TITLE (?P<title>.+) END'
    assert MetadataFromTitlePP(None, 'TITLE %(title)s %(artist)s END')._titleregex == '(?P<title>.+)\ (?P<artist>.+)\ END'
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(album)s')._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'

# Generated at 2022-06-22 09:26:05.402998
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl
    tmp_downloader = youtube_dl.YoutubeDL()
    tmp_downloader.to_screen = lambda x: x

    # Test that the method returns empty list, as expected, when given the following
    # values of the parameter info.
    test_info = {}
    # test_info['title'] = ''

    pp = MetadataFromTitlePP(tmp_downloader, '%(title)s - %(artist)s')
    assert pp.run(test_info) == ([], test_info)



# Generated at 2022-06-22 09:26:16.639845
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    title = 'MetadataFromTitlePP.test'

    def test_PP(titleformat):
        pp = MetadataFromTitlePP(None, titleformat)
        assert pp._titleregex == titleformat
        pattern = pp._titleregex
        if re.search(r'%\(\w+\)s', titleformat):
            pattern = pp.format_to_regex(titleformat)
        match = re.match(pattern, title)
        if match is None:
            return False
        for groupdict in match.groupdict():
            assert groupdict == 'test'
        return True

    assert test_PP('%(test)s')
    assert test_PP('%(TeSt)s')
    assert test_PP('%-%(TeSt)s-%')

# Generated at 2022-06-22 09:26:28.295612
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    fmt_to_regex = MetadataFromTitlePP(None, None).format_to_regex
    assert fmt_to_regex('foo') == 'foo'
    assert fmt_to_regex('foo%%') == 'foo%'
    assert fmt_to_regex('foo%(bar)s') == r'foo(?P<bar>.+)'
    assert fmt_to_regex('foo%(bar)s%(baz)s') == r'foo(?P<bar>.+)(?P<baz>.+)'
    assert fmt_to_regex('%(foo)s%(foo)s%(foo)s') == r'(?P<foo>.+)(?P<foo>.+)(?P<foo>.+)'

# Generated at 2022-06-22 09:26:45.050767
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # test_MetadataFromTitlePP_run: test of method run in class MetadataFromTitlePP
    from youtube_dl import YoutubeDL
    from youtube_dl.utils import DownloadError

    # given
    pp = MetadataFromTitlePP(YoutubeDL(), '%(title)s - %(artist)s')
    # when
    info = {'title': 'title - artist', 'upload_date': '010203'}
    # then
    assert pp.run(info) == ([], {'title': 'title', 'artist': 'artist', 'upload_date': '010203'})

    # given
    pp = MetadataFromTitlePP(YoutubeDL(), '%(title)s - %(artist)s [%(id)s]')
    # when

# Generated at 2022-06-22 09:26:55.134713
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import ydl

    ydl = ydl.YoutubeDL({'writedescription': True})
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    pp = MetadataFromTitlePP(ydl, 'prefix %(title)s - %(artist)s')
    assert pp._titleformat == 'prefix %(title)s - %(artist)s'
    assert pp._titleregex == r'prefix\ (?P<title>.+)\ \-\ (?P<artist>.+)'

if __name__ == '__main__':
    test_Metadata

# Generated at 2022-06-22 09:26:58.502661
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp._titleregex == r'(?P<artist>.+)\ \-\ (?P<title>.+)'



# Generated at 2022-06-22 09:27:07.271972
# Unit test for constructor of class MetadataFromTitlePP

# Generated at 2022-06-22 09:27:17.683275
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl

    # Relative imports are very crappy, so we use absolute imports
    from tests.test_postprocessor import PostProcessorTestCase

    info = {
        'title': 'abc - def',
    }
    processor = MetadataFromTitlePP(youtube_dl.YoutubeDL({}), '%(title)s')
    processed_info, new_info = processor.run(info)
    postprocessor_testcase = PostProcessorTestCase()
    postprocessor_testcase.assertEqual(new_info, {'title': 'abc - def', 'title': 'abc'})

    info = {
        'title': 'abc - def - ghi',
    }
    processor = MetadataFromTitlePP(youtube_dl.YoutubeDL({}), '%(title)s - %(artist)s')
    processed_

# Generated at 2022-06-22 09:27:25.934445
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Test - default constructor
    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '(?P<title>.+)'

    # Test - constructor with format and regex
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-22 09:27:30.859097
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, None).format_to_regex(
        '%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-22 09:27:40.310662
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from unittest import TestCase

    class TestFormatToRegex(TestCase):
        def test_basic_conversion(self):
            self.assertEqual(MetadataFromTitlePP(None, '%(title)s')._titleregex, r'(?P<title>.+)')
            self.assertEqual(MetadataFromTitlePP(None, '%(artist)s - %(title)s')._titleregex, r'(?P<artist>.+)\ \-\ (?P<title>.+)')
            self.assertEqual(MetadataFromTitlePP(None, '%(artist)s - %(tracknumber)s - %(title)s')._titleregex, r'(?P<artist>.+)\ \-\ (?P<tracknumber>.+)\ \-\ (?P<title>.+)')

# Generated at 2022-06-22 09:27:48.581242
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import Downloader
    downloader = Downloader()
    pp = MetadataFromTitlePP(downloader, '%(artist)s - %(title)s')
    assert pp._titleregex == r'(?P<artist>.+)\ \-\ (?P<title>.+)'

    pp = MetadataFromTitlePP(downloader, 'S%(season_number)02dE%(episode_number)02d')
    assert pp._titleregex == r'S(?P<season_number>\d\d)E(?P<episode_number>\d\d)'

# Generated at 2022-06-22 09:27:53.262742
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp._titleformat == '%(artist)s - %(title)s'
    assert pp._titleregex == r'(?P<artist>.+)\ \-\ (?P<title>.+)'


# Unit tests for format_to_regex

# Generated at 2022-06-22 09:28:18.034354
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ydl.downloader.YoutubeDL import YoutubeDL

    # initialize YoutubeDL
    ydl = YoutubeDL({'downloader': 'fakedl',
                     'fromtitle': '%(title)s - %(artist)s',
                     'quiet': True})

    # initialize PostProcessor with configured YoutubeDL
    pp = MetadataFromTitlePP(ydl)

    # test
    test_info = {'title':'Title of video - Artist'}
    _, info = pp.run(test_info)
    assert info == {'title': 'Title of video', 'artist': 'Artist'}

# Generated at 2022-06-22 09:28:25.011174
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(track)s')
    assert pp._titleformat == '%(artist)s - %(track)s'
    assert pp._titleregex == '(?P<artist>.+)\ \-\ (?P<track>.+)'

    pp = MetadataFromTitlePP(None, '%(artist)s')
    assert pp._titleformat == '%(artist)s'
    assert pp._titleregex == '(?P<artist>.+)'

    pp = MetadataFromTitlePP(None, '%(artist)s %%(track)s')
    assert pp._titleformat == '%(artist)s %%(track)s'
    assert pp._titleregex == '(?P<artist>.+)\ \%\(track\)s'

    pp = Metadata

# Generated at 2022-06-22 09:28:34.969858
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ..compat import compat_str
    from .common import FileDownloader
    from .extractor import YoutubeIE

    class FakeInfoExtractor(YoutubeIE):
        pass
    ie = FakeInfoExtractor()
    pp = MetadataFromTitlePP(FileDownloader({'outtmpl': '%(title)s'}), '%(title)s - %(artist)s')
    info = {'title': 'my title - my artist',
            'ext': 'mp4'}
    infos, info = pp.run(info)
    assert infos == []
    assert info['title'] == 'my title'
    assert info['artist'] == 'my artist'

    pp = MetadataFromTitlePP(FileDownloader({'outtmpl': '%(title)s'}), '%(title)s')
    inf

# Generated at 2022-06-22 09:28:39.557297
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    f='%(title)s %(authors)s'
    m = MetadataFromTitlePP(None, f)
    assert m._titleformat == f
    assert m._titleregex == r'(?P<title>.+)\ (?P<authors>.+)'


# Generated at 2022-06-22 09:28:46.087343
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from mock import Mock
    downloader = Mock()
    titleformat = '%(artist)s - %(title)s'
    titleregex = r'(?P<artist>.+)\ \-\ (?P<title>.+)'
    title = 'Kylie Minogue - Dancing'
    info = {'title': title}
    pp = MetadataFromTitlePP(downloader, titleformat)
    pp._titleregex = titleregex
    new_info = pp.run(info)[1]
    assert new_info['title'] == 'Dancing'
    assert new_info['artist'] == 'Kylie Minogue'


# Generated at 2022-06-22 09:28:56.660908
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s [%(album)s]')
    assert pp._titleformat == '%(artist)s - %(title)s [%(album)s]'
    assert pp._titleregex == '^(?P<artist>.+)\\ \\-\\ (?P<title>.+)\\ \\[(?P<album>.+)\\]$'
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp._titleregex == '^(?P<artist>.+)\\ \\-\\ (?P<title>.+)$'
    pp = MetadataFromTitlePP(None, '%(artist)s ::: %(title)s')

# Generated at 2022-06-22 09:29:07.067866
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    metadata_from_title_pp = MetadataFromTitlePP('', '')
    assert metadata_from_title_pp._titleformat is ''
    assert metadata_from_title_pp._titleregex is ''

    metadata_from_title_pp = MetadataFromTitlePP('', '%(title)s')
    assert metadata_from_title_pp._titleformat is '%(title)s'
    assert metadata_from_title_pp._titleregex is '(?P<title>.+)'

    metadata_from_title_pp = MetadataFromTitlePP('', '%(title)s - %(artist)s')
    assert metadata_from_title_pp._titleformat is '%(title)s - %(artist)s'

# Generated at 2022-06-22 09:29:16.427042
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class DummyDownloader():
        def to_screen(self, msg):
            print(msg)

    titleformat = '%(artist)s - %(track)s - %(title)s'
    title = 'TheArtist - TheTrack - TheTitle'
    info = {'title': title}
    pp = MetadataFromTitlePP(DummyDownloader(), titleformat)
    _, info = pp.run(info)
    assert info['title'] == title
    assert info['artist'] == 'TheArtist'
    assert info['track'] == 'TheTrack'
    titleformat = '%(artist)s - %(track)s - %(title)s - '
    title = 'TheArtist - TheTrack - TheTitle'
    info = {'title': title}

# Generated at 2022-06-22 09:29:24.565900
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, "test")
    assert pp.format_to_regex(r'%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex(r'%(title)s - %(artist)s - %(album)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'

# Generated at 2022-06-22 09:29:33.586734
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.downloader import YoutubeDL
    import sys
    import os
    import tempfile
    import shutil

    if sys.version_info[0] == 2:
        from io import BytesIO as DataIO
    else:
        from io import StringIO as DataIO

    # Create temporary directory in which to collect generated files
    outputdir = tempfile.mkdtemp()

    # Create downloader object with fake files
    ydl_opts = {
        'outtmpl': outputdir + '/%(title)s.%(ext)s',
        'quiet': True
    }
    ydl = YoutubeDL(ydl_opts)
    ydl.add_default_info_extractors()

    # Define metadata we're looking for

# Generated at 2022-06-22 09:30:07.973902
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    test_dict = {'title': 'titl3 - art1st'}
    test_fmt = '%(title)s - %(artist)s'
    f = MetadataFromTitlePP(None, test_fmt)
    _, info = f.run(test_dict)
    assert info['artist'] == 'art1st'



# Generated at 2022-06-22 09:30:16.109537
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # Asserts method MetadataFromTitlePP.format_to_regex() converts string
    # '%(title)s - %(artist)s' to regex '(?P<title>.+)\ \-\ (?P<artist>.+)'
    import unittest
    class TestFormatToRegex(unittest.TestCase):
        def setUp(self):
            self.downloader = object()
            self.fmt = '%(title)s - %(artist)s'
            self.p = MetadataFromTitlePP(self.downloader, self.fmt)


# Generated at 2022-06-22 09:30:23.232546
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    titleformat = '%(title)s - %(artist)s'
    assert MetadataFromTitlePP(None, titleformat).run({
        'title': 'My Title'
    }) == ([], {
        'title': 'My Title'
    })
    assert MetadataFromTitlePP(None, titleformat).run({
        'title': 'My Title - My Artist'
    }) == ([], {
        'title': 'My Title - My Artist',
        'artist': 'My Artist'
    })
    assert MetadataFromTitlePP(None, titleformat).run({
        'title': 'This is not a valid title format'
    }) == ([], {
        'title': 'This is not a valid title format'
    })


# Generated at 2022-06-22 09:30:26.838158
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Should return a MetadataFromTitlePP class object
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    # Should fail
    assert not MetadataFromTitlePP(None, '%(title)s - %(artist)s')

# Generated at 2022-06-22 09:30:37.914908
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-22 09:30:43.164339
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-22 09:30:48.346326
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # check if the method MetadataFromTitlePP.format_to_regex works
    # for the given string %(title)s - %(artist)s
    assert (
        MetadataFromTitlePP(None, None).format_to_regex('%(title)s - %(artist)s')
        == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    )

# Generated at 2022-06-22 09:30:56.295375
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """ Test case for method run of class MetadataFromTitlePP.
    """
    from .downloader import Downloader
    test_fmt = '%(title)s - %(artist)s'
    test_title = 'Titulo del video - Artista del video'
    test_dict = {'title': test_title}
    pp = MetadataFromTitlePP(None, test_fmt)
    results = pp.run(test_dict)
    assert results[1]['title'] == 'Titulo del video'
    assert results[1]['artist'] == 'Artista del video'

