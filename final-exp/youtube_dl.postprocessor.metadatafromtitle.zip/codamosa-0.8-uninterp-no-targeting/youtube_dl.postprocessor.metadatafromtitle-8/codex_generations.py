

# Generated at 2022-06-22 09:21:13.314077
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp.format_to_regex('') == ''
    assert pp.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'
    assert pp.format_to_regex('%%(title)s') == '%%(title)s'
    assert pp.format_to_regex('%(title)s%(artist)s') == '(?P<title>.+)(?P<artist>.+)'

# Generated at 2022-06-22 09:21:23.599760
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    fmt = '%(title)s - %(track)s - %(artist)s'
    m = MetadataFromTitlePP(None, fmt)
    assert re.match(m._titleregex, 'Title - 01 - Artist') is not None
    assert re.match(m._titleregex, 'Title - 01 - Artist - Video') is not None
    assert re.match(m._titleregex, 'Title - 01 - Artist - Video - another') is not None

    fmt = '%(title)s'
    m = MetadataFromTitlePP(None, fmt)
    assert re.match(m._titleregex, 'Title - 01 - Artist') is not None
    assert re.match(m._titleregex, 'Title - 01 - Artist - Video') is not None

# Generated at 2022-06-22 09:21:32.592268
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from_title = MetadataFromTitlePP(None, None)
    def test(fmt, regex):
        """Test that format_to_regex generates the specified regex"""
        assert from_title.format_to_regex(fmt) == regex
    # test all regex flags and escaping
    test(r"%(title)s - %(artist)s",
         r"(?P<title>.+)\ \-\ (?P<artist>.+)")
    test(r"%(a)sb",
         r"(?P<a>\(\?P=a\)*\(b|$\))")
    test(r"a(?P<a>b)c",
         r"a\(b\)c")
    test(r"(?P<a>b)",
         r"\(b\)")
    test

# Generated at 2022-06-22 09:21:40.788504
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftpp = MetadataFromTitlePP(None, None)
    assert mftpp.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert mftpp.format_to_regex('XY%(title)sZW') == 'XY(?P<title>.+)ZW'
    assert mftpp.format_to_regex('XY%(title)sZW%(author)sYX') == 'XY(?P<title>.+)ZW(?P<author>.+)YX'

if __name__ == '__main__':
    test_MetadataFromTitlePP_format_to_regex()

# Generated at 2022-06-22 09:21:52.037583
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    p = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert p.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert p.format_to_regex('%(title)s - %(artist)s - %(album)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'
    p = MetadataFromTitlePP(None, '%(title)s')
    assert p.format_to_regex('%(title)s') == r'(?P<title>.+)'

# Generated at 2022-06-22 09:22:04.388574
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(
        None,
        "%(title)s - %(artist)s - %(genre)s - %(songnum)s - %(year)s")
    assert pp.format_to_regex(
        "%(title)s - %(artist)s - %(genre)s - %(songnum)s - %(year)s") == (
            r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<genre>.+)\ \-\ (?P<songnum>.+)\ \-\ (?P<year>.+)')
    assert pp.format_to_regex("abc") == r'abc'
    assert pp.format_to_regex("%(foo)s") == r'(?P<foo>.+)'


# Generated at 2022-06-22 09:22:13.410032
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert 'title' in pp.__dict__
    assert pp.__dict__['title'] == '%(title)s - %(artist)s'
    assert 'titleregex' in pp.__dict__
    assert pp.__dict__['titleregex'] == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    pp = MetadataFromTitlePP(None, '%(title)s')
    assert 'title' in pp.__dict__
    assert pp.__dict__['title'] == '%(title)s'
    assert 'titleregex' in pp.__dict__
    assert pp.__dict__['titleregex'] == '(?P<title>.+)'

    pp = Met

# Generated at 2022-06-22 09:22:23.333102
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(artist)s-%(album)s')
    assert pp._titleformat == '%(artist)s-%(album)s'
    assert pp._titleregex == r'(?P<artist>.+)\-(?P<album>.+)'

    pp = MetadataFromTitlePP(None, '%(artist)s - %(album)s')
    assert pp._titleformat == '%(artist)s - %(album)s'
    assert pp._titleregex == r'(?P<artist>.+)\ \-\ (?P<album>.+)'

    pp = MetadataFromTitlePP(None, '%(artist)s - %(album)s')
    assert pp._titleformat == '%(artist)s - %(album)s'
    assert pp._

# Generated at 2022-06-22 09:22:35.031882
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    assert MetadataFromTitlePP(None, '%(title)s')._titleregex == '(?P<title>.+)'
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s')._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, '%(artist)s - %(title)s')._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'
    assert MetadataFromTitlePP(None, '%(artist)s - %(title)s [>%(cross)s<]')._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)\ \[\>\(?P<cross>.+)\<\]'

# Generated at 2022-06-22 09:22:45.403149
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.PostProcessor import PostProcessor
    from youtube_dl.Downloader import FakeDownloader

    class TestPostProcessor(PostProcessor):
        def __init__(self, ie):
            PostProcessor.__init__(self, ie, downloader=FakeDownloader())

        def run(self, info):
            info['title'] = 'testtitle'
            return [], info

    pp = TestPostProcessor(None)
    pp_from_title = MetadataFromTitlePP(pp, '%(title)s')
    ydl = YoutubeDL({'postprocessors': [pp, pp_from_title]})

# Generated at 2022-06-22 09:22:58.025620
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-22 09:23:08.831350
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    ydl_opts = {'nooverwrites': True}

    class DownloaderMock(object):
        def __init__(self):
            self._to_screen_calls = []

        def to_screen(self, message):
            self._to_screen_calls.append(message)

        def get_to_screen_calls(self):
            return self._to_screen_calls

    downloader_mock = DownloaderMock()
    title_pp = MetadataFromTitlePP(downloader_mock, '%(title)s%(foo)s')

    # The title does not match the regex pattern
    info = {'title': 'abc'}
    [], info = title_pp.run(info)
    assert info.get('title') == 'abc'

# Generated at 2022-06-22 09:23:20.183865
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Note:
    # This unit test keeps track of implementation changes.
    # The following constants have to be adjusted as required.
    test_title = "SOMETHING SOMETHING COMPLEX SOMETHING SOMETHING"
    test_config = {'formats': 'bestaudio', 'outtmpl': '%(title)s.%(ext)s',
                   'noplaylist': True}
    test_result = {'title': test_title}
    # what the tests should produce:

# Generated at 2022-06-22 09:23:30.515949
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    test = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert test.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert test.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert test.format_to_regex(' - %(artist)s') == r'\ \-\ (?P<artist>.+)'
    assert test.format_to_regex('%(a)s - %(b)s') == r'(?P<a>.+)\ \-\ (?P<b>.+)'

# Generated at 2022-06-22 09:23:40.168674
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest, pytest
    from youtube_dl.compat import compat_shlex_quote
    from youtube_dl.utils import DownloadError


# Generated at 2022-06-22 09:23:48.788819
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl
    downloader = youtube_dl.YoutubeDL(params={})
    p = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    info = {'title': 'foo - bar'}
    # Test without metadata
    info_out = p.run(info)[1]
    if info_out['title'] is not 'foo - bar':
        raise AssertionError('wrong title')
    if info_out['artist'] is not 'bar':
        raise AssertionError('wrong artist')
    # Test with existing metadata
    info['title'] = 'baz - qux'
    info_out = p.run(info)[1]
    if info_out['title'] is not 'baz - qux':
        raise AssertionError('wrong title')
   

# Generated at 2022-06-22 09:23:53.199528
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    fmt = '%(title)s_%(artist)s_%(album)s_%(track)s.%(ext)s'
    assert MetadataFromTitlePP(None, fmt)._titleregex == r'.+_.+_.+_.+.\w+'


# Generated at 2022-06-22 09:24:02.949727
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from youtube_dl.extractor.youtube import YoutubeIE
    pp = MetadataFromTitlePP(YoutubeIE, '%(artist)s::%(title)s')
    assert pp.format_to_regex('%(artist)s::%(title)s') == r'(?P<artist>.+)::(?P<title>.+)'
    assert pp.format_to_regex('%(artist)s-%(title)s') == r'(?P<artist>.+)-(?P<title>.+)'
    assert pp.format_to_regex('%(artist)s - %(title)s') == r'(?P<artist>.+)\ \-\ (?P<title>.+)'

# Generated at 2022-06-22 09:24:13.510072
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .downloader import getDownloader
    d = getDownloader('PTZRACe4PQ4')
    mp4 = '%(title)s.mp4'
    mp4_regex = '^(?P<title>.+)\.mp4$'
    m4a = '%(title)s.m4a'
    m4a_regex = '^(?P<title>.+)\.m4a$'
    fmt = '%(artist)s - %(title)s.%(ext)s'
    fmt_regex = '^(?P<artist>.+)\ \-\ (?P<title>.+)\.(?P<ext>\w+)$'

# Generated at 2022-06-22 09:24:19.892158
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class TestDownloader(object):
        def to_screen(self, value):
            pass

    info = {
        'title': 'Test Title - Test Artist'
    }

    pp = MetadataFromTitlePP(TestDownloader(), '%(title)s - %(artist)s')
    _, new_info = pp.run(info)

    assert 'artist' in new_info
    assert new_info['artist'] == 'Test Artist'


# Generated at 2022-06-22 09:24:34.193045
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, '%(a)s').format_to_regex('%(a)s') == '(?P<a>.+)'
    assert MetadataFromTitlePP(None, '%(a)s?').format_to_regex('%(a)s?') == '(?P<a>.)'
    assert MetadataFromTitlePP(None, '%(a)s%(b)s').format_to_regex('%(a)s%(b)s') == '(?P<a>.+)(?P<b>.+)'
    assert MetadataFromTitlePP(None, '%(a)s(*).%(b)s').format_to_regex('%(a)s(*).%(b)s') == '(?P<a>.+)(?P<b>.+)'

# Generated at 2022-06-22 09:24:46.076932
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None,
        "%(title)s - %(artist)s")
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    pp = MetadataFromTitlePP(None,
        "%(title)s - %(artist)s - %(bla)s - %(blub)s - %(c)s")
    assert pp._titleregex == \
        '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<bla>.+)\ \-\ (?P<blub>.+)\ \-\ (?P<c>.+)'
    pp = MetadataFromTitlePP(None,
        " %(artist)s - %(title)s ")
    assert pp._title

# Generated at 2022-06-22 09:24:53.942689
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import get_testcases
    from .testcases import testcases_test
    from .extractor import choose_extractor

    testcases = get_testcases(testcases_test, 'test')
    test_class = MetadataFromTitlePP
    test_method = test_class.run.__func__
    
    for test_case in testcases:
        video_id = test_case['_video_id']
        video_extractor = choose_extractor(video_id)
        video_title = video_extractor.get_video_title(video_id)
        info = {'title': video_title}
        
        if test_case['_fromtitle'] is None:
            fromtitle = None
        else:
            fromtitle = test_class(None, test_case['_fromtitle'])
        

# Generated at 2022-06-22 09:25:03.501256
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from . downloader import FakeYDL
    from .extractor import get_info_extractor
    ydl = FakeYDL()
    pp = MetadataFromTitlePP(ydl, '%(title)s_%(artist)s')
    assert pp._titleformat == '%(title)s_%(artist)s'
    assert pp._titleregex == '(?P<title>.+)_(?P<artist>.+)'
    ydl.params['extract_flat'] = 'invalid_task'
    ie = get_info_extractor(ydl, 'http://example.com/test')
    assert 'metadata_from_title' not in ie._downloader.std_out


# Generated at 2022-06-22 09:25:09.163426
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

# Unit tests for format_to_regex method of class MetadataFromTitlePP

# Generated at 2022-06-22 09:25:19.647009
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ..YoutubeDL import YoutubeDL
    from .extractor.common import InfoExtractor
    ie = InfoExtractor()
    ie._downloader = YoutubeDL(params={})
    assert ie._downloader.params.get('usenetrc', False) is False
    mftpp = MetadataFromTitlePP(ie._downloader, '%(id)s')
    assert mftpp.format_to_regex('%(id)s') == r'(?P<id>.+)'
    assert mftpp.format_to_regex('%(id)s-%(title)s') == r'(?P<id>.+)\-(?P<title>.+)'

# Generated at 2022-06-22 09:25:29.944057
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # TODO: Replace this with a parametrized test
    # example 1
    titleformat = '%(title)s - %(artist)s'
    title = 'Video title - Video artist'
    info = {'title': title}
    mftpp = MetadataFromTitlePP(None, titleformat)
    expected_info = {'title': 'Video title',
                     'artist': 'Video artist'}
    result_info = mftpp.run(info)[1]
    assert result_info == expected_info
    # example 2
    titleformat = '%(artist)s - %(title)s'
    title = 'Video artist - Video title'
    info = {'title': title}
    mftpp = MetadataFromTitlePP(None, titleformat)

# Generated at 2022-06-22 09:25:37.615632
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .extractor import get_info_extractor

    def check_format_to_regex(fmt, regex):
        ie = get_info_extractor('test')
        pp = MetadataFromTitlePP(ie, fmt)
        assert pp._titleregex == regex, 'Expected "%s" but returned "%s"' % (regex, pp._titleregex)

    check_format_to_regex('%(title)s', r'(?P<title>.+)')
    check_format_to_regex('%(title)s - %(artist)s', r'(?P<title>.+)\ \-\ (?P<artist>.+)')

# vim: tabstop=4 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-22 09:25:43.233420
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import json
    def dummy_download(self, *args, **kwargs): return True
    m = MetadataFromTitlePP(dummy_download, '%(artist)s - %(song)s')
    assert(m._titleformat == '%(artist)s - %(song)s')
    assert(m._titleregex == (r'(?P<artist>.+)\ \-\ (?P<song>.+)'))
    m = MetadataFromTitlePP(dummy_download, '%(artist)s - %(song)s a song')
    assert(m._titleformat == '%(artist)s - %(song)s a song')
    assert(m._titleregex == (r'(?P<artist>.+)\ \-\ (?P<song>.+)\ a\ song'))

# Generated at 2022-06-22 09:25:44.737299
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # TODO Invent appropriate unit test
    pass


# Generated at 2022-06-22 09:25:58.421366
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test 1: no regex groups
    p = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert not p.run({'title': 'video title'})[1]

    # Test 2: parsing simple title
    p = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert {'title': 'title of the video',
            'artist': 'the artist'} == p.run({'title': 'title of the video - the artist'})[1]

    # Test 3: parsing complex title
    p = MetadataFromTitlePP(None,
                            '%(track_number)s - %(title)s (the album - %(year)s)')

# Generated at 2022-06-22 09:26:07.462787
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    test_cases = [
        ('%(title)s - %(artist)s',
         'a - b',
         {'title': 'a', 'artist': 'b'}),
        ('a - b',
         'a - b',
         {}),
        ('%(title)s',
         'argument - argument',
         {'title': 'argument - argument'}),
        ('%(title)s - %(artist)s',
         'argument - argument',
         {}),
        ('a - b',
         'a - b',
         {}),
    ]

    for format_, title, expected in test_cases:
        downloader = object()
        pp = MetadataFromTitlePP(downloader, format_)
        assert pp._titleformat == format_
        if format_ != title:
            assert pp._

# Generated at 2022-06-22 09:26:18.308165
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    Unit test for method run of class MetadataFromTitlePP
    Verify that method format_to_regex correctly converts the format string
    to regular expression and that the resulting regular expression is used
    correctly in method run
    """
    from .youtube_dl import YoutubeDL

    title = 'Artist - Song Title'
    titleformat = '%(artist)s - %(song)s'

    # Mock attributes of YoutubeDL
    ydl = YoutubeDL()
    ydl.params = {'forcejson': True}
    class MockIE:
        def __init__(self, result):
            self._result = result
        def extract(self, *args, **kwargs):
            return self._result

    video = {'title': title}

# Generated at 2022-06-22 09:26:28.159520
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mf = MetadataFromTitlePP(None, None)
    tests = {
        '%(title)s - %(artist)s': '(?P<title>.+)\ \-\ (?P<artist>.+)',
        '%(title)s': '(?P<title>.+)',
        '%(title)s -%(artist)s': '(?P<title>.+)\ \-\(?P<artist>.+)',
        '%(title)s-%(artist)s': '(?P<title>.+)-(?P<artist>.+)',
        '%(title)s-': '(?P<title>.+)-',
    }
    for fmt, regex in tests.items():
        assert mf.format_to_regex(fmt) == regex

# Generated at 2022-06-22 09:26:39.335055
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from test import get_test_data
    import os.path
    import subprocess

    def write_json_file(json_str, json_file):
        with open(json_file, 'wb') as f:
            f.write(json_str.encode('utf-8'))

    def parse_json(json_file):
        import json
        with open(json_file) as f:
            return json.load(f)

    def download_json(json_file, json_url, options=[]):
        cmd = ['youtube-dl'] + options + ['--dump-json', json_url]
        pid = subprocess.Popen(cmd, stdout=open(json_file, 'wb'))
        retcode = pid.wait()

# Generated at 2022-06-22 09:26:46.651845
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    c = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert c._titleformat == '%(title)s - %(artist)s'
    assert c._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    c = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(tracknumber)s')
    assert c._titleformat == '%(title)s - %(artist)s - %(tracknumber)s'
    assert c._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<tracknumber>.+)'

    c = MetadataFromTitlePP(None, '%(title)s')
    assert c._titleformat

# Generated at 2022-06-22 09:26:50.897223
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    titleformat = '%(title)s - %(artist)s'
    titleregex = '(?P<title>.+) - (?P<artist>.+)'
    m_obj = MetadataFromTitlePP(None, titleformat)
    assert(titleregex == m_obj._titleregex)


# Generated at 2022-06-22 09:27:02.079997
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    PP = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    info1 = {'title':'foo', 'url':'http://example.org/video1', 'ext': 'mp4'}
    info2 = {'title':'foo - bar', 'url':'http://example.org/video2', 'ext': 'mp4'}
    info3 = {'title':'foo - bar - baz', 'url':'http://example.org/video3', 'ext': 'mp4'}
    info4 = {'title':'foo - bar - baz - qux', 'url':'http://example.org/video4', 'ext': 'mp4'}

# Generated at 2022-06-22 09:27:13.995808
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import collections
    import pytest
    from youtube_dl.YoutubeDL import YoutubeDL

    class downloader:
        def __init__(self):
            self.to_screen = lambda x: print(x, file=sys.stderr)

        def trouble(self):
            if hasattr(self, 'saved_trouble'):
                return self.saved_trouble.pop(0)
            else:
                return collections.defaultdict(lambda: None)

    def test(fmt, title, expected):
        pp = MetadataFromTitlePP(downloader(), fmt)
        info = downloader().trouble()
        info['title'] = title
        output, output_info = pp.run(info)
        assert len(output) == 0
        assert output_info == expected

    test

# Generated at 2022-06-22 09:27:25.846309
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(album)s')
    assert pp._titleformat == '%(title)s - %(artist)s - %(album)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'

    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    pp = MetadataFromTitlePP(None, '%(title)s')

# Generated at 2022-06-22 09:27:48.528050
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from ..downloader import YoutubeDL
    title_format = '%(title)s-%(artist)s'
    ydl = YoutubeDL({'writethumbnail': True, 'quiet': True})
    pp = MetadataFromTitlePP(ydl, title_format)
    assert pp._titleformat == title_format
    assert pp._titleregex == '(?P<title>.+)-(?P<artist>.+)'

    title_format = '%(title)s'
    ydl = YoutubeDL({'writethumbnail': True, 'quiet': True})
    pp = MetadataFromTitlePP(ydl, title_format)
    assert pp._titleformat == title_format
    assert pp._titleregex == '(?P<title>.+)'


# Generated at 2022-06-22 09:27:53.216644
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.YoutubeDL import YoutubeDL
    youtube_dl = YoutubeDL({})
    titleformat = '%(title)s'
    MetadataFromTitlePP(youtube_dl, titleformat)
    titleformat = '%(title)s - %(artist)s'
    MetadataFromTitlePP(youtube_dl, titleformat)



# Generated at 2022-06-22 09:28:01.675379
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)

    # Test with simple example
    titleformat = '%(title)s - %(artist)s'
    expected = r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert expected == pp.format_to_regex(titleformat)

    # Test with example with escaped %
    titleformat = '%%(title)s - %(artist)s'
    expected = r'\%(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert expected == pp.format_to_regex(titleformat)

    # Test with example with escaped )
    titleformat = '%(title)s - %(artist)s \) '

# Generated at 2022-06-22 09:28:07.005364
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    config = """
    -f 22+vorbis
    -o "%(title)s-%(artist)s.%(ext)s"
    """
    config = YoutubeDL(config).params
    mp = MetadataFromTitlePP('', config['outtmpl'])
    assert mp._titleregex == \
        '(?P<title>.+).(?P<artist>.+).(?P<ext>.+)'

# Generated at 2022-06-22 09:28:15.134618
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl
    import unittest

    # downloaded info
    info = {'title': 'ZAZ - Je Veux'}

    # expected results
    expected_info = {'title': 'ZAZ - Je Veux',
                     'artist': 'ZAZ'}

    # create instance of PostProcessor
    pp = MetadataFromTitlePP(youtube_dl.YoutubeDL({}),
                             '%(artist)s - %(title)s')
    pp.run(info)

    # compare results
    assert info == expected_info

# Generated at 2022-06-22 09:28:23.874207
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    class Dummy:
        @staticmethod
        def to_screen(message):
            print(message)
    downloader = Dummy()
    pp = MetadataFromTitlePP(downloader, '%(artist)s - %(title)s')
    regex = pp.format_to_regex('%(artist)s - %(title)s')
    assert regex == '(?P<artist>.+)\ \-\ (?P<title>.+)'
    regex = pp.format_to_regex('%(artist)s')
    assert regex == '(?P<artist>.+)'
    regex = pp.format_to_regex('%(artist)s - %(title)s - %(album)s')

# Generated at 2022-06-22 09:28:34.808571
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import FileDownloader
    from .extractor import gen_extractors
    metadataFromTitlePP = MetadataFromTitlePP(FileDownloader({}), '%(title)s - %(artist)s')

    assert metadataFromTitlePP.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert metadataFromTitlePP.format_to_regex('%(foo)s - %(bar)s') == r'(?P<foo>.+)\ \-\ (?P<bar>.+)'

    metadataFromTitlePP._downloader.gen_extractor = gen_extractors()

# Generated at 2022-06-22 09:28:39.991394
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert pp.format_to_regex('prefix%(title)ssuffix') == (
        r'prefix(?P<title>.+)suffix')

# Generated at 2022-06-22 09:28:47.953979
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    class FakeDownloader:
        def to_screen(self, text):
            pass

    class FakeInfo:
        def __init__(self, title, artist=None, album=None, tracknumber=None):
            self['title'] = title
            if artist:
                self['artist'] = artist
            if album:
                self['album'] = album
            if tracknumber:
                self['tracknumber'] = tracknumber

    # test blank title
    downloader = FakeDownloader()
    pp = MetadataFromTitlePP(downloader, '%(artist)s - %(title)s')
    info = FakeInfo('')
    res, info = pp.run(info)
    assert info['artist'] is None
    assert info['title'] is ''

    # test title given for single elements
    downloader = FakeDownloader()


# Generated at 2022-06-22 09:28:56.662347
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, '%(title)s')._titleregex == '(?P<title>.+)'
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s')._titleregex == \
           '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s [%(id)s]')._titleregex == \
           '(?P<title>.+)\ \-\ (?P<artist>.+)\ \[(?P<id>.+)\]'


# Generated at 2022-06-22 09:29:26.947018
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    testformat = '%(artist)s - %(title)s'
    testregex = '(?P<artist>.+)\ \-\ (?P<title>.+)'
    pp = MetadataFromTitlePP(None, testformat)
    assert pp._titleregex == testregex

# Generated at 2022-06-22 09:29:34.973563
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .downloader import Downloader
    from .extractor import SearchInfoExtractor
    from .compat import compat_str

    def test(titleformat, testval, expected):
        downloader = Downloader()
        downloader.add_info_extractor(SearchInfoExtractor())
        downloader.set_context(SearchInfoExtractor.IE_NAME, ie_key='ytsearch')
        downloader.set_context(SearchInfoExtractor.SEARCH_KEY, search_key='query')
        downloader.to_screen = lambda *_: None
        pp = MetadataFromTitlePP(downloader=downloader, titleformat=titleformat)
        result = pp.run({'title': testval, 'extractor': 'ytsearch'})
        assert result[1]['uploader'] == expected['uploader']

# Generated at 2022-06-22 09:29:41.890403
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s-%(artist)s')
    assert pp._titleformat == '%(title)s-%(artist)s'
    assert pp._titleregex == '(?P<title>.+)\-(?P<artist>.+)'
    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '%\(title\)s'


# Generated at 2022-06-22 09:29:43.781091
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    parser = MetadataFromTitlePP('dummy', '%(title)s')

# Generated at 2022-06-22 09:29:54.948015
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # We can't actually use PyUnit on a class method, so we'll define a dummy class
    class Dummy(object):
        @staticmethod
        def assertEqual(a, b):
            if a != b:
                raise Exception('%r != %r' % (a, b))

    # This is the test suite
    p = MetadataFromTitlePP(Dummy(), '%(title)s - %(artist)s')
    Dummy.assertEqual(p.format_to_regex('%(title)s - %(artist)s'),
                      r'(?P<title>.+)\ \-\ (?P<artist>.+)')

    p = MetadataFromTitlePP(Dummy(), '[%(title)s]-[%(artist)s]')

# Generated at 2022-06-22 09:30:01.453921
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    obj = MetadataFromTitlePP(None, None)
    fmt = '%(title)s - %(artist)s'
    regex = obj.format_to_regex(fmt)
    assert regex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    match = re.match(regex, 'title - artist')
    assert match is not None
    assert match.groupdict() == {'title': 'title', 'artist': 'artist'}

# Generated at 2022-06-22 09:30:11.559613
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .. import YoutubeDL
    ydl = YoutubeDL({})
    pp = MetadataFromTitlePP(ydl, '%(artist)s - %(title)s')
    assert pp._titleformat == '%(artist)s - %(title)s'
    assert pp._titleregex == '(?P<artist>.+)\\ \\-\\ (?P<title>.+)'
    pp = MetadataFromTitlePP(ydl, 'Foo - Bar')
    assert pp._titleformat == 'Foo - Bar'
    assert pp._titleregex == 'Foo\\ \\-\\ Bar'
    pp = MetadataFromTitlePP(ydl, 'Foo - Bar %(artist)s')
    assert pp._titleformat == 'Foo - Bar %(artist)s'

# Generated at 2022-06-22 09:30:18.350503
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    assert pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s%(frob)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)%(frob)s'
    assert pp.format_to_regex('%(artist)s - %(title)s') == r'(?P<artist>.+)\ \-\ (?P<title>.+)'

# Generated at 2022-06-22 09:30:25.107822
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    """
    Performs a series of tests on the MetadataFromTitle constructor
    """
    import youtube_dl.YoutubeDL

    ydl = youtube_dl.YoutubeDL({})
    result = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')._titleregex
    assert result == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    result = MetadataFromTitlePP(ydl, '%(title)s')._titleregex
    assert result == '(?P<title>.+)'

    result = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s - %(album)s')._titleregex

# Generated at 2022-06-22 09:30:36.392473
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    """test_MetadataFromTitlePP"""
    from ytdl import YoutubeDL
    ydl = YoutubeDL()
    assert MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    assert MetadataFromTitlePP(ydl, '%(title)s')
    assert MetadataFromTitlePP(ydl, '%(title)s %(artist)s')
    assert MetadataFromTitlePP(ydl, '%(title)s by %(artist)s')
    assert MetadataFromTitlePP(ydl, '%(title)s by %(artist)s ')
    assert MetadataFromTitlePP(ydl, ' %(title)s by %(artist)s ')
    assert MetadataFromTitlePP(ydl, ' %(title)s %(artist)s ')
   