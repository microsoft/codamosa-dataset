

# Generated at 2022-06-22 09:21:06.082568
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    titleformat = '%(title)s - %(artist)s'
    titleregex = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    t = MetadataFromTitlePP(None, titleformat)
    assert t._titleformat == titleformat
    assert t._titleregex == titleregex

# Generated at 2022-06-22 09:21:15.671277
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleregex == r'(?P<title>.+)'
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(album)s')
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'

# Generated at 2022-06-22 09:21:27.153588
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s')._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, '%(title)s')._titleregex == r'(?P<title>.+)'
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(artist)s')._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-22 09:21:34.167009
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    obj = MetadataFromTitlePP(None, None)
    assert obj.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert obj.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-22 09:21:42.828576
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import tempfile
    import os

    # Create the noop downloader and postprocessor to be used
    downloader = object()
    postprocessor = MetadataFromTitlePP(downloader, '%(artist)s-%(title)s')

    # Test run for valid input and output
    valid_input = {'title': 'Artist-Input-Title'}
    postprocessor.run(valid_input)
    assert valid_input == {'title': 'Artist-Input-Title',
                           'artist': 'Artist',
                           'title': 'Input-Title'}

    # Test run for invalid input and output
    invalid_input = {'title': 'Artist-Input-Title-With-Regex'}
    postprocessor.run(invalid_input)

# Generated at 2022-06-22 09:21:48.689485
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    titleformat = '%(uploader)s - %(title)s'
    format_to_regex = MetadataFromTitlePP.format_to_regex
    regex = '(?P<uploader>.+)\ \-\ (?P<title>.+)'
    assert(format_to_regex(titleformat) == regex)

# vim:set shiftwidth=4 softtabstop=4 expandtab textwidth=79:

# Generated at 2022-06-22 09:21:52.954088
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    class MockYoutubeDL(object):
        def to_screen(self, message):
            pass

    youtube_dl = MockYoutubeDL()
    pp = MetadataFromTitlePP(youtube_dl, '%(title)s - %(artist)s')

    actual = pp.run({'id': '1234567890', 'title': 'A title - An artist'})
    expected = ({}, {'id': '1234567890', 'title': 'A title - An artist',
                     'artist': 'An artist'})

    assert expected == actual



# Generated at 2022-06-22 09:22:02.637314
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .test import get_testdownloader

    # Mock downloader
    dl = get_testdownloader()
    # Test without regex
    title_pp = MetadataFromTitlePP(dl, '%(title)s - %(artist)s')
    assert title_pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    # Test with regex
    title_pp = MetadataFromTitlePP(dl, '%(title)s - test: (?P<foo>.+)')
    assert title_pp._titleregex == '(?P<title>.+)\ -\ test: \((?P<foo>.+)\)'


# Generated at 2022-06-22 09:22:11.092904
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest
    import tempfile
    import os

    class MockDownloader():
        def __init__(self, to_screen):
            self.to_screen = to_screen
            self.to_screen_count = 0

    class MetadataFromTitlePPTest(unittest.TestCase):
        def setUp(self):
            self.assertTrue(os.path.exists(tempfile.gettempdir()))
            self.filename = os.path.join(tempfile.gettempdir(),
                    'MetadataFromTitlePPTest_unit_test.txt')

        def tearDown(self):
            if os.path.isfile(self.filename):
                os.remove(self.filename)
            self.assertFalse(os.path.exists(self.filename))


# Generated at 2022-06-22 09:22:21.705936
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .YoutubeDL import YoutubeDL

    d = YoutubeDL()
    d.params['simulate'] = True
    d.add_post_processor(
        MetadataFromTitlePP(d, '%(artist)s - %(title)s'))
    results = d.extract_info(
        'http://example.com/', download=False,
        ie_key='Youtube',
        title='The Album Leaf - The Light (from "Into The Blue Again")')
    assert len(results['entries']) == 1
    entry = results['entries'][0]
    assert entry['artist'] == 'The Album Leaf'
    assert entry['title'] == 'The Light (from "Into The Blue Again")'

# Generated at 2022-06-22 09:22:29.208932
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    titleformat = '%(title)s - %(artist)s'
    titleregex = '(?P<title>.+) - (?P<artist>.+)'
    testPP = MetadataFromTitlePP('', titleformat)
    regex = testPP.format_to_regex(titleformat)
    assert regex == titleregex


# Generated at 2022-06-22 09:22:40.404989
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    options = {'simulate': True}
    ydl = FileDownloader(options)

    # check a list of formats and their corresponding titles
    # title does not match a format
    mp = MetadataFromTitlePP(ydl, '%(title)s')
    info = {'title': 'foo'}
    assert mp.run(info)[1] == {'title': 'foo'}
    # title matches simple format
    mp = MetadataFromTitlePP(ydl, '%(title)s')
    info = {'title': 'foo - bar'}
    assert mp.run(info)[1] == {'title': 'foo - bar'}
    # title matches composite format

# Generated at 2022-06-22 09:22:50.377249
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    mdft = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert mdft._titleformat == '%(title)s - %(artist)s'
    assert mdft._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    mdft = MetadataFromTitlePP(None, '%(artist)s - %(title)s - %(album)s')
    assert mdft._titleformat == '%(artist)s - %(title)s - %(album)s'
    assert mdft._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)\ \-\ (?P<album>.+)'


# Generated at 2022-06-22 09:23:00.485024
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import json
    import pytest
    import youtube_dl.YoutubeDL
    test_title = 'test - %(title)s - %(artist)s.%(ext)s'
    test_name = 'test - Foo - Bar.mkv'
    test_info = json.load(open('test/test.json'))
    test_downloader = youtube_dl.YoutubeDL()
    test_pp = MetadataFromTitlePP(test_downloader, test_title)
    [out, info] = test_pp.run(test_info)
    assert (info['title'] == 'Foo') and \
           (info['artist'] == 'Bar') and \
           (info['ext'] == 'mkv')

# Generated at 2022-06-22 09:23:06.974216
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # class MockLogger:
    #     def to_screen(self, msg):
    #         print(msg)

    class MockInfoDict:
        def __init__(self, title):
            self.title = title
            self.artist = None

    # logger = MockLogger()
    title = 'Kamasi Washington - Fists of Fury EPK'
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    info_dict = MockInfoDict(title)
    pp.run(info_dict)
    assert info_dict.title == title
    assert info_dict.artist == 'Kamasi Washington'
    title = 'The Fall of Gondolin - J.R.R. Tolkien - New Audio Drama'
    info_dict = MockInfoDict(title)
   

# Generated at 2022-06-22 09:23:17.852391
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    import unittest
    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.pp = MetadataFromTitlePP(None, None)

        def test_format_to_regex(self):
            testlist = [
                ('%(artist)s', re.compile(r'(?P<artist>.+)')),
                ('%(artist)s %(track)s%(title)s', re.compile(r'(?P<artist>.+)\ (?P<track>.+)\(?P<title>.+\)?')),
                ('.*%(track)s%(title)s.*', re.compile(r'\..*(?P<track>.+)\(?P<title>.+\)?')),
            ]

# Generated at 2022-06-22 09:23:25.078810
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    for fmt, regex in [
            ('%(title)s - %(artist)s',
             r'(?P<title>.+)\ \-\ (?P<artist>.+)'),
            ('%(title)s',
             r'(?P<title>.+)'),
            ('%(title)s -',
             r'(?P<title>.+)\ \-')]:
        mpp = MetadataFromTitlePP(None, fmt)
        assert mpp._titleregex == regex

# Generated at 2022-06-22 09:23:31.287806
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    titleformat = r'%(title)s - %(artist)s'
    titleregex = MetadataFromTitlePP(None, titleformat).format_to_regex(titleformat)
    assert titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Unit tests for method run of class MetadataFromTitlePP

# Generated at 2022-06-22 09:23:36.772364
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP("test", "%(title)s - %(artist)s")
    # Test the following keys of pp._titleformat
    assert pp._titleformat == "%(title)s - %(artist)s"
    # Test the following keys of pp._titleregex
    assert pp._titleregex == '(?P<title>.+) - (?P<artist>.+)'

# Generated at 2022-06-22 09:23:47.685429
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    metadataFromTitlePP = MetadataFromTitlePP(None, '')
    assert metadataFromTitlePP.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert metadataFromTitlePP.format_to_regex('%(title)s %(artist)s -') == '(?P<title>.+) (?P<artist>.+) -'
    assert metadataFromTitlePP.format_to_regex(r'%(artist)s \--- /%(title)s') == r'(?P<artist>.+) \--- /(?P<title>.+)'
    assert metadataFromTitlePP.format_to_regex('%(title)s - %(artist)s \/') == '(?P<title>.+) - (?P<artist>.+) \/'
    # Check for escape of percent signs

# Generated at 2022-06-22 09:23:54.589746
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    regex = pp.format_to_regex('%(artist)s - %(title)s')
    assert regex == '(?P<artist>.+)\ \-\ (?P<title>.+)'

# Generated at 2022-06-22 09:24:03.917663
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-22 09:24:14.342731
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    downloader = YoutubeDL({})

    pp = MetadataFromTitlePP(downloader, '%(artist)s - %(track)s')
    assert pp.run({'title': 'The Beatles - Here comes the sun'}) == (
        [], {'artist': 'The Beatles', 'track': 'Here comes the sun'})

    pp = MetadataFromTitlePP(downloader, '%(track)s by %(artist)s')
    assert pp.run({'title': 'Here comes the sun by The Beatles'}) == (
        [], {'artist': 'The Beatles', 'track': 'Here comes the sun'})

    pp = MetadataFromTitlePP(downloader, '%(artist)s - %(title)s')

# Generated at 2022-06-22 09:24:24.319740
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    if '%(title)s - %(artist)s' != MetadataFromTitlePP(None, '%(title)s - %(artist)s').format_to_regex('%(title)s - %(artist)s'):
        raise Exception("ERROR:  MetadataFromTitlePP_format_to_regex")
    if '.*' != MetadataFromTitlePP(None, '.*').format_to_regex('.*'):
        raise Exception("ERROR:  MetadataFromTitlePP_format_to_regex")
    if '.*' != MetadataFromTitlePP(None, '.*').format_to_regex('.*'):
        raise Exception("ERROR:  MetadataFromTitlePP_format_to_regex")


# Generated at 2022-06-22 09:24:33.242397
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    import re
    from .common import PostProcessor
    from .subtitles import SubtitlesPP
    from .ffmpeg import FFmpegExtractAudioPP
    from .metadatafromtitle import MetadataFromTitlePP
    postprocessors = [
        FFmpegExtractAudioPP(),
        SubtitlesPP(),
        MetadataFromTitlePP(None, '%(title)s - %(artist)s')]
    postprocessor = postprocessors[-1]
    assert re.match(
        postprocessor.format_to_regex(postprocessor._titleformat),
        'title - artist')



# Generated at 2022-06-22 09:24:43.630054
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl import YoutubeDL
    from youtube_dl.version import __version__
    from youtube_dl.postprocessor import FFmpegMetadataPP

    test_metadata = {'uploader': 'Uploader',
           'upload_date': '20120204',
           'title': 'Video title - Subtitle',
           'id': '1234567890'}

    ydl_opts = {
        'outtmpl': '%(id)s.%(ext)s',
        'skip_download': True,
    }

    ydl = YoutubeDL(ydl_opts)
    ydl.add_post_processor(FFmpegMetadataPP())
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s - %(subtitle)s'))
    res = ydl

# Generated at 2022-06-22 09:24:54.130319
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    Test method run of MetadataFromTitlePP
    """
    import sys
    import os

    import pytube
    from pytube import PostProcessor
    from pytube.extract import apply_descrambler, parse_video_info
    from pytube.exceptions import RegexMatchError

    class MockDownloader(object):
        """Mock class for downloader"""

        def __init__(self):
            self.screen_out = []

        def to_screen(self, text):
            """Mock method for to_screen of downloader"""
            self.screen_out.append(text)

    class MockPostProcessor(PostProcessor):
        """Mock class for PostProcessor"""
        def __init__(self, downloader):
            self.downloader = downloader


# Generated at 2022-06-22 09:25:04.837906
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    Test method run of class MetadataFromTitlePP
    """
    import unittest
    import sys
    import os.path
    from youtube_dl.utils import prepend_extension
    if sys.version_info.major == 2:
        import __builtin__ as builtins
    else:
        import builtins

    class MockDownloader:
        def __init__(self):
            self.to_screen_string_list = []

        def to_screen(self, msg):
            self.to_screen_string_list.append(msg)

        def report_warning(self, msg):
            return

    class MockYDL:
        def __init__(self):
            self.tmpfilename = 'tmp'


# Generated at 2022-06-22 09:25:13.941472
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import ydl_opts

    pp = MetadataFromTitlePP(ydl_opts.YoutubeDL({}), '%(title)s - %(artist)s')
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    pp = MetadataFromTitlePP(ydl_opts.YoutubeDL({}), '%(title)s')
    assert pp._titleregex == '%\\(title\\)s'

    pp = MetadataFromTitlePP(ydl_opts.YoutubeDL({}), '%(title)s %(id)s')
    assert pp._titleregex == r'(?P<title>.+)\ (?P<id>.+)'


# Generated at 2022-06-22 09:25:21.198063
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    class MockDownloader(object):
        def to_screen(self, str):
            print(str)

    pp = MetadataFromTitlePP(MockDownloader(), '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    pp = MetadataFromTitlePP(MockDownloader(), 'foo')
    assert pp._titleformat == 'foo'
    assert pp._titleregex == 'foo'



# Generated at 2022-06-22 09:25:34.697360
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftpp = MetadataFromTitlePP("dummy_downloader", "dummy_titleformat")

    # Test with a simple format string that contains only %(...)s parts
    assert mftpp.format_to_regex("%(title)s - %(artist)s") == \
        r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    # Test with a format string that contains a literal '%' character
    assert mftpp.format_to_regex("% perc% - %(artist)s") == \
        r'%\ perc%\ \-\ (?P<artist>.+)'

    # Test with a format string that contains a literal ')' character
    assert mftpp.format_to_regex("Test with a closing paren) - %(artist)s")

# Generated at 2022-06-22 09:25:44.228520
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # Test with empty string
    mftpp = MetadataFromTitlePP(None, "")
    assert(mftpp.format_to_regex("") == "")

    # Test with simple string
    mftpp = MetadataFromTitlePP(None, "simple string")
    assert(mftpp.format_to_regex("simple string") == "simple string")

    # Test with string containing a special character
    mftpp = MetadataFromTitlePP(None, "string with %(special)s character")
    assert(mftpp.format_to_regex("string with %(special)s character") == "string with %\\(special\\)s character")

    # Test with simple format string
    mftpp = MetadataFromTitlePP(None, "%(title)s")

# Generated at 2022-06-22 09:25:48.533842
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'

    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleregex == '%\(title\)s'

# Generated at 2022-06-22 09:25:51.701561
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, None).format_to_regex(r'%(title)s - %(artist)s') \
        == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-22 09:25:58.925157
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    # Testing MetadataFromTitlePP for a single video
    downloader = YoutubeDL({'writedescription': True, 'writesubtitles': True, 'writeinfojson': True, 'writeannotations': True, 'verbose': True, 'quiet': False})
    res = MetadataFromTitlePP(downloader, '%(title)s')
    res._downloader.to_screen('[test_MetadataFromTitlePP] testing constructor of MetadataFromTitlePP with single video')
    res._downloader.to_screen(res._titleformat)
    res._downloader.to_screen(res._titleregex)


# Generated at 2022-06-22 09:26:07.661470
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class FakeYDL:
        def to_screen(self, msg):
            pass

    class FakeInfoDict:
        def __init__(self, title):
            self.title = title

    def test(title, fmt, metadata):
        ydl = FakeYDL()
        metadata = metadata.copy()
        metadata['title'] = title
        test_info = FakeInfoDict(title)
        pp = MetadataFromTitlePP(ydl, fmt)
        pp_info = pp.run(test_info)

        for key in metadata:
            assert key in pp_info
            assert pp_info[key] == metadata[key]

    # This tests may not be complete, but it's better than nothing
    #
    # Test 1: %(id)s

# Generated at 2022-06-22 09:26:17.317750
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s%(ext)s')
    assert pp._titleformat == '%(artist)s - %(title)s%(ext)s'
    assert pp._titleregex == r'(?P<artist>.+)\ \-\ (?P<title>.+)(?P<ext>\..+)'

# Generated at 2022-06-22 09:26:28.354538
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftpp = MetadataFromTitlePP(None, None)
    assert mftpp.format_to_regex('%(title)s - %(artist)s') \
           == '(?P<title>.+)\\ \-\\ (?P<artist>.+)'
    assert mftpp.format_to_regex('%(title)s - %(artist)s - foo') \
           == '(?P<title>.+)\\ \-\\ (?P<artist>.+)\\ \-\\ foo'
    assert mftpp.format_to_regex('.%(title)s.') \
           == '\.(?P<title>.+)\.'
    assert mftpp.format_to_regex('A title (%(title)s)') \
           == 'A title \((?P<title>.+)\)'
   

# Generated at 2022-06-22 09:26:34.978050
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Should not raise an exception
    MetadataFromTitlePP(None, '%(title)s')
    MetadataFromTitlePP(None, '%(foo)s')
    # Should raise an exception
    try:
        MetadataFromTitlePP(None, '%(title')
    except ValueError:
        pass
    else:
        assert False, 'Exception not raised'


# Generated at 2022-06-22 09:26:44.308900
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import ytdl_util as util
    downloader = util.Downloader()
    pp = MetadataFromTitlePP(downloader, '%(artist)s - %(title)s')
    assert pp._titleformat == '%(artist)s - %(title)s'
    assert pp._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'

    pp = MetadataFromTitlePP(downloader, '%(artist)s - %(title)s')
    assert pp._titleformat == '%(artist)s - %(title)s'
    assert pp._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'


# Generated at 2022-06-22 09:26:58.222958
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    print(pp._titleregex)
    pp = MetadataFromTitlePP(None, '%(title)s-%(artist)s')
    print(pp._titleregex)

# Generated at 2022-06-22 09:27:05.061361
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Example with one regex group
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    # Example with two groups of the same name
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(title)s')

# Generated at 2022-06-22 09:27:16.497167
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    class DummyDownloader:
        def to_screen(self, msg):
            print(msg)

    # Test regexes with %(..)s form
    fmt = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(DummyDownloader(), fmt)
    assert pp._titleformat == fmt
    regex = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp._titleregex == regex

    # Test regexes with plain text
    fmt = ' - '
    pp = MetadataFromTitlePP(DummyDownloader(), fmt)
    assert pp._titleformat == fmt
    regex = ' - '
    assert pp._titleregex == regex


# When monkey-patching os.getenv, DO NOT USE os.environ.get, because it will


# Generated at 2022-06-22 09:27:27.236129
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    M = MetadataFromTitlePP
    assert M.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert M.format_to_regex('%(title)s - %(creator)s') == '(?P<title>.+)\ \-\ (?P<creator>.+)'
    assert M.format_to_regex('%(creator)s - %(title)s') == '(?P<creator>.+)\ \-\ (?P<title>.+)'
    assert M.format_to_regex('%(creator)s - %(title)s - %(title)s') == '(?P<creator>.+)\ \-\ (?P<title>.+)\ \-\ (?P<title>.+)'

# Generated at 2022-06-22 09:27:38.310984
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import logging

    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleregex == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'

    pp = MetadataFromTitlePP(None, '(?P<artist>.+?) - (?P<title>.+)')
    assert pp._titleregex == '(?P<artist>.+?)\\ \\-\\ (?P<title>.+)'

    pp = MetadataFromTitlePP(None, '%(artist)s - %(type)s - %(title)s')
    assert pp._titleregex == '(?P<artist>.+)\\ \\-\\ (?P<type>.+)\\ \\-\\ (?P<title>.+)'


# Generated at 2022-06-22 09:27:49.196078
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({
        'quiet': True,
        'writesubtitles': True,
        'writeautomaticsub': True,
        'allsubtitles': True,
        'postprocessors': [{
            'key': 'MetadataFromTitle',
            'titleformat': '%(title)s - %(artist)s'
        }],
        'format': 'bestvideo+bestaudio/best',
        'outtmpl': 'test_%(title)s_%(artist)s_%(ext)s'
    })
    ydl.add_default_info_extractors()

# Generated at 2022-06-22 09:27:55.330175
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    m = MetadataFromTitlePP(None, 'title - artist')
    assert m._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    m = MetadataFromTitlePP(None, 'title')
    assert m._titleregex == r'title'
    m = MetadataFromTitlePP(None, ' (?P<title>.+) ')
    assert m._titleregex == r'\ (?P<title>.+)\ '



# Generated at 2022-06-22 09:28:05.823929
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    import sys
    from youtube_dl.utils import DateRange
    from youtube_dl.YoutubeDL import YoutubeDL

    class MockDownloader(YoutubeDL):
        def __init__(self):
            super(MockDownloader, self).__init__()
            self.to_screen_images = []

        def to_screen(self, what):
            self.to_screen_images.append(what)

    downloader = MockDownloader()
    pp = MetadataFromTitlePP(downloader, '%(artist)s - %(title)s')

    info = {
        'title': 'I see you (Album Version) - Leona Lewis',
        'duration': 123,
        'upload_date': '20080718'
    }
    results, newinfo = pp.run(info)


# Generated at 2022-06-22 09:28:17.209376
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .downloader import YoutubeDL
    from .extractor import gen_extractors
    downloader = YoutubeDL(params={'simulate': True,
                                   'ignoreerrors': True,
                                   'forcejson': True,
                                   'noplaylist': True,
                                   })
    downloader.add_default_info_extractors()
    gen_extractors(downloader)
    downloader.params['fromtitle'] = '%(artist)s - %(year)s'
    postprocessor1 = MetadataFromTitlePP(downloader, downloader.params['fromtitle'])

    # Example of video title: "Fifth Harmony - BO$$"

# Generated at 2022-06-22 09:28:21.603677
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    fmt = '%(title)s - %(artist)s - %(album)s'
    result = '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'
    assert MetadataFromTitlePP.format_to_regex(
        fmt) == result, 'Failed assertion'

# Generated at 2022-06-22 09:28:46.888956
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    result = MetadataFromTitlePP.format_to_regex('%(title)s - %(artist)s')
    assert result == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    result = MetadataFromTitlePP.format_to_regex('%(title)2s - %(artist)2s')
    assert result == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    result = MetadataFromTitlePP.format_to_regex('%(title)5s - %(artist)5s')
    assert result == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    result = MetadataFromTitlePP.format_to_regex('%(title)s')

# Generated at 2022-06-22 09:28:56.732627
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl.YoutubeDL
    import youtube_dl.extractor.common
    class FakeInfoDict(dict):
        pass
    def to_screen(*args, **kargs):
        pass
    ydl = youtube_dl.YoutubeDL({'quiet': True})
    pp = MetadataFromTitlePP(ydl, "%(chapter)s\t%(artist)s\t%(title)s")
    info = FakeInfoDict({'title': '1\tPink Floyd\tAnother Brick in the Wall'})
    pp.run(info)
    assert info['chapter'] == '1'
    assert info['artist'] == 'Pink Floyd'
    assert info['title'] == 'Another Brick in the Wall'


# Generated at 2022-06-22 09:29:06.657797
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    assert pp.format_to_regex(r'%(title)s') == '(?P<title>.+)'
    assert pp.format_to_regex(r'%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex(r'%(title)s') in pp.format_to_regex(r'%(title)s - %(artist)s')
    assert pp.format_to_regex(r'%(title)s - %(artist)s') in pp.format_to_regex(r'%(title)s')



# Generated at 2022-06-22 09:29:09.062287
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass

# Generated at 2022-06-22 09:29:21.140725
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # test object
    class FakeDownloader(object):
        def __init__(self):
            self.to_screen = print
    post_processor = MetadataFromTitlePP(
        FakeDownloader(), '%(title)s - %(artist)s')

    # test input and expected output

# Generated at 2022-06-22 09:29:29.836262
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    d = lambda x: None
    d.to_screen = lambda x: None
    assert MetadataFromTitlePP(d, '%(title)s - %(artist)s')._titleregex == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'
    assert MetadataFromTitlePP(d, 'Test title')._titleregex == 'Test title'
    assert MetadataFromTitlePP(d, '%(title)s')._titleregex == '(?P<title>.+)'


# Generated at 2022-06-22 09:29:36.161496
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from expecter import expect
    from pytube.downloader import Downloader
    import sys

    # Objects initialization
    downloader = Downloader(sys.stdout)
    metadatafromitlepp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')

    # Initialization of the test variables
    info = {
        'title': 'La La Land - La La Land Cast'
    }
    expected_info = {
        'title': 'La La Land',
        'artist': 'La La Land Cast'
    }

    metadata_from_title_pp, info = metadatafromitlepp.run(info)

    expect(info) == expected_info

# Generated at 2022-06-22 09:29:40.748867
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, r'Video - %(year)s - %(artist)s')
    assert pp._titleformat == r'Video - %(year)s - %(artist)s'
    assert pp._titleregex == r'Video\ -\ (?P<year>.+)\ -\ (?P<artist>.+)'

# Generated at 2022-06-22 09:29:50.811283
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl
    import unittest

    metadata_from_title_pp = MetadataFromTitlePP(
        'Downloader', '%(title)s - %(artist)s - %(date)s')
    arg_info = {'title': 'sometitle'}
    res_info = metadata_from_title_pp.run(arg_info)[1]
    assert (res_info['title'] == 'sometitle' and 'artist' not in res_info and
            'date' not in res_info)

    metadata_from_title_pp = MetadataFromTitlePP(
        'Downloader', '%(title)s - %(artist)s - %(date)s')
    arg_info = {'title': 'sometitle - someartist'}
    res_info = metadata_from_title_

# Generated at 2022-06-22 09:29:55.731409
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import unescapeHTML

    def assertParse(format_, expected):
        assert expected == MetadataFromTitlePP(None, format_)._titleregex

    assertParse('%(title)s', '(?P<title>.+)')
    assertParse('%(title)s - %(artist)s', '(?P<title>.+) - (?P<artist>.+)')

    assertParse(
        '%(title)s-%(artist)s',
        '(?P<title>.+)\\-(?P<artist>.+)')
    assertParse(
        '%(title)s - %(artist)s - %(milestone)s',
        '(?P<title>.+) - (?P<artist>.+) - (?P<milestone>.+)')

# Generated at 2022-06-22 09:30:48.819530
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from test import unittest

    class TestMetadataFromTitlePP(MetadataFromTitlePP):
        def __init__(self):
            super(TestMetadataFromTitlePP, self).__init__(None, None)

    fmt2rgx = TestMetadataFromTitlePP().format_to_regex

    class Test(unittest.TestCase):
        def test(self, fmt, fmt2rgx=fmt2rgx, expected=None):
            self.assertEqual(expected, fmt2rgx(fmt))


# Generated at 2022-06-22 09:30:58.746735
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # returns a function which can be used to test the metadata
    class FakeInfo:
        def __init__(self):
            self.data = dict()

        def __getitem__(self, key):
            return self.data[key]

        def __setitem__(self, key, value):
            self.data[key] = value

    class FakeDownloader:
        def __init__(self, input_tuples, output_tuples):
            self.input_tuples = input_tuples
            self.output_tuples = output_tuples

        def to_screen(self, message):
            assert message == self.input_tuples.pop(0)

    def test(input_, output):
        info = FakeInfo()
        info.data['title'] = input_