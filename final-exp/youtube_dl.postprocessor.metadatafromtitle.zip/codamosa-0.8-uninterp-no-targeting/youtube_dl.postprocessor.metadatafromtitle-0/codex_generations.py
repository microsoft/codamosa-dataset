

# Generated at 2022-06-22 09:21:11.454398
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl_server.downloader import Downloader
    from ytdl_server.compat import compat_http_client

    downloader = Downloader()
    downloader.tocurlopt = lambda *a: ''
    downloader.http_read_video_info = lambda *a: ''
    downloader.report_warning = lambda *a: None
    downloader.report_error = lambda *a: None
    downloader.add_default_extra_info = lambda *a: None
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')

# Generated at 2022-06-22 09:21:15.738524
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    assert MetadataFromTitlePP(None, 'test')._titleregex == 'test'
    regex = MetadataFromTitlePP(None, '%(title)s - %(artist)s')._titleregex
    assert regex == '(?P<title>.+)\ \-\ (?P<artist>.+)'



# Generated at 2022-06-22 09:21:20.421633
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    mdpp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert (mdpp._titleregex ==
            r'(?P<title>.+)\ \-\ (?P<artist>.+)')


# Generated at 2022-06-22 09:21:30.043887
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    r = MetadataFromTitlePP(None, '').format_to_regex
    assert r('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert r('%(title)s') == r'(?P<title>.+)'
    # This test fails as the result is right now (?P<title>.+)\ (%(\d\+)\)
    #assert r('%(title)s (%(\\d+)s)') == r'(?P<title>.+)\ \((?P<\\d+>.+)\)'
    assert r('%(title)sr %(year)d') == r'(?P<title>.+)\ r\ (?P<year>\d+)'

# Generated at 2022-06-22 09:21:38.115359
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    mft = MetadataFromTitlePP(None, "%(title)s.%(ext)s")
    assert mft._titleformat == "%(title)s.%(ext)s"
    assert mft._titleregex == '(?P<title>.+)\.(?P<ext>.+)'

    mft = MetadataFromTitlePP(None, "foo%(title)sbar")
    assert mft._titleformat == "foo%(title)sbar"
    assert mft._titleregex == 'foo(?P<title>.+)bar'

# Generated at 2022-06-22 09:21:40.970568
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    mppo = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s').format_to_regex('%(title)s - %(artist)s')
    assert(mppo == r'(?P<title>.+)\ \-\ (?P<artist>.+)')


# Generated at 2022-06-22 09:21:52.076069
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(album)s')
    assert isinstance(pp, PostProcessor)
    # check if regex was successfully constructed from title format
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'

    # check with format that does not contain groups
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert isinstance(pp, PostProcessor)
    # check if format was copied to regex attribute
    assert pp._titleregex == '%(title)s\ \-\ %(artist)s'

    # check with format that does not contain string parts

# Generated at 2022-06-22 09:22:03.561509
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import ydl_test

    downloader = ydl_test.FakeYDL()
    downloader.params['metadatafromtitle'] = 'Test: %(test)s'
    pp = MetadataFromTitlePP(downloader, downloader.params['metadatafromtitle'])

    info = {'title': 'Test: testvalue'}
    pp.run(info)

    assert 'test' in info
    assert info['test'] == 'testvalue'
    assert len(downloader.msgs) == 2
    assert downloader.msgs[0] == '[fromtitle] parsed test: testvalue'
    assert 'Could not interpret title of video as "Test: %(test)s"'
    assert downloader.msgs[1] == downloader.msgs[1]

# Generated at 2022-06-22 09:22:11.342793
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    if pp._titleformat != '%(artist)s - %(title)s':
        raise AssertionError('Wrong format: {0} is not {1}'.format(
                                                pp._titleformat,
                                                '%(artist)s - %(title)s'))
    if pp._titleregex != r'(?P<artist>.+)\ \-\ (?P<title>.+)':
        raise AssertionError('Wrong regex: {0} is not {1}'.format(
                                            pp._titleregex,
                                            r'(?P<artist>.+)\ \-\ (?P<title>.+)'))


# Generated at 2022-06-22 09:22:22.364111
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP.format_to_regex(
        '%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP.format_to_regex(
        '%(title)s by %(artist)s') == '(?P<title>.+)\ by\ (?P<artist>.+)'
    assert MetadataFromTitlePP.format_to_regex(
        '%(uploader)s :: %(title)s.%(ext)s') == '(?P<uploader>.+)\ \:\:(?P<title>.+)\.(?P<ext>.+)'

# Generated at 2022-06-22 09:22:34.969777
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    argv = ['-f', '%(title)s',
            '-o', '%(title)s.%(ext)s',
            'http://www.youtube.com/watch?v=UVlKZqTlT1U']
    def option(key):
        for index, value in enumerate(argv):
            if value == key and index + 1 < len(argv):
                return argv[index + 1]
        return None
    def setOption(key, value):
        argv.append(value)
    meth = MetadataFromTitlePP.run
    assert meth(locals(), {'title': 'Cute pug is Cute'}) == ([], {
        'title': 'Cute pug is Cute'
    })

# Generated at 2022-06-22 09:22:43.582693
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    cases = [
        ('%(title)s', r'(?P<title>.+)'),
        ('%(title)s - %(artist)s', r'(?P<title>.+)\ \-\ (?P<artist>.+)'),
        ('%(artist)s - %(title)s', r'(?P<artist>.+)\ \-\ (?P<title>.+)')
        ]
    for titleformat, regex in cases:
        assert pp.format_to_regex(titleformat) == regex


# Generated at 2022-06-22 09:22:54.490805
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    '''
    Tests the method run of class MetadataFromTitlePP
    '''
    import sys
    import tempfile
    class MockDownloader(object):
        def __init__(self):
            pass
        def to_screen(self, line):
            pass
        
    class MockYDL(object):
        def __init__(self):
            self.downloader = MockDownloader()
    
    def test1(mock_YDL, expected_result):
        title = 'Abdel Halim Hafez - الليلة الكبيرة - الحلقة العاشرة - صباح الفاتح'
        info = {'title': title}
        titleformat = '%(title)s - %(artist)s'
        p = Metadata

# Generated at 2022-06-22 09:23:03.065306
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    test_cases = {
        # test that escaping works
        '%%(title)s': '\%\(title\)s',
        # test that non-format strings are escaped
        '%(title)s - %(artist)s': r'\(title\)s\ \-\ \(artist\)s',
        # test the actual format conversion
        '%(title)s - %(artist)s - %(track)s': r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<track>.+)',
    }
    for fmt, regex in test_cases.items():
        assert MetadataFromTitlePP(None, fmt)._titleregex == regex

# Generated at 2022-06-22 09:23:12.154143
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    metadataPP = MetadataFromTitlePP(None, None)
    assert metadataPP.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert metadataPP.format_to_regex('foo') == r'foo'
    assert metadataPP.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert metadataPP.format_to_regex('%(title)s - %(artist)s - %(date)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<date>.+)'
    assert metadataPP.format_to_regex('%(title)s %(artist)s')

# Generated at 2022-06-22 09:23:21.303795
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-22 09:23:31.368041
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    class FakeInfo(dict):
        def __init__(self, title):
            dict.__init__(self)
            self['title'] = title

    class FakeYoutubeDL(object):
        def __init__(self):
            self.to_screen_calls = []

        def to_screen(self, message):
            self.to_screen_calls.append(message)

    class FakeOption(object):
        def __init__(self, titleformat):
            self.titleformat = titleformat

    class FakeOptions(object):
        def __init__(self, titleformat):
            self.postprocessor_args = [FakeOption(titleformat)]

    class FakeIE(object):
        def __init__(self):
            self.downloader = FakeYoutubeDL()
            self.options = None


# Generated at 2022-06-22 09:23:39.209111
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    t = MetadataFromTitlePP(None, r'blah - %(title)s - more stuff')
    assert (t._titleregex == r'blah\ \-\ (?P<title>.+)\ \-\ more\ stuff')
    t = MetadataFromTitlePP(None, r'%(title)s')
    assert (t._titleregex == r'(?P<title>.+)')
    t = MetadataFromTitlePP(None, r'%(title)s - %(artist)s')
    assert (t._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)')

# Generated at 2022-06-22 09:23:48.212427
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .compat import compat_str

    pp = MetadataFromTitlePP(None, compat_str(''))

# Generated at 2022-06-22 09:23:57.767917
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    assert MetadataFromTitlePP._titleregex == ''
    assert MetadataFromTitlePP._titleformat == ''
    mftpp = MetadataFromTitlePP(None, '')
    assert mftpp._titleregex == ''
    assert mftpp._titleformat == ''
    mftpp = MetadataFromTitlePP(None, '%(title)s')
    assert mftpp._titleregex == r'(?P<title>.+)'
    assert mftpp._titleformat == '%(title)s'
    mftpp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert mftpp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-22 09:24:12.222929
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    ydl = None
    titlefmt = '%(title)s by %(artist)s'
    pp = MetadataFromTitlePP(ydl, titlefmt)
    assert lambda s: pp._titleregex == '(?P<title>.+)\ by\ (?P<artist>.+)'
    titlefmt = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(ydl, titlefmt)
    assert pp._titleregex == titlefmt
    titlefmt = '%(title)s [%(description)s]'
    pp = MetadataFromTitlePP(ydl, titlefmt)
    assert pp._titleregex == '(?P<title>.+)\ \[(?P<description>.+)\]'

# Unit tests for _format_to_regex()

# Generated at 2022-06-22 09:24:16.629950
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    titleformat = '%(test)s - %(test_two)s'
    expected_regex = '(?P<test>.+)\ \-\ (?P<test_two>.+)'
    assert MetadataFromTitlePP.format_to_regex(titleformat) == expected_regex

# Generated at 2022-06-22 09:24:21.646473
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    with_percentage_format = '%(title)s - %(artist)s'
    without_percentage_format = '%title - %artist'
    _ = MetadataFromTitlePP(None, with_percentage_format)
    _ = MetadataFromTitlePP(None, without_percentage_format)


# Generated at 2022-06-22 09:24:34.122780
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # Test video title
    title = 'My video title - how can I help you?'
    # Check if title is interpreted as specified in format_to_regex
    # Note: Expect failure, since from_title feature is currently disabled
    assert ('(?P<title>.+)\\ \\-\\ (?P<artist>.+)' ==
            MetadataFromTitlePP(None, '%(title)s - %(artist)s')._titleregex)
    assert ('(?P<artist>.+) - (?P<title>.+)' ==
            MetadataFromTitlePP(None, '%(artist)s - %(title)s')._titleregex)

# Generated at 2022-06-22 09:24:44.744251
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    regex = '%(title)s_-_%(artist)s'
    trans = MetadataFromTitlePP(None, regex)
    assert trans._titleformat == regex
    assert trans._titleregex == '%(title)s_-_%(artist)s'
    regex = '%(title)s_-_%(artist)s_-_%(album)s'
    exp_regex = '(?P<title>.+)_-_(?P<artist>.+)_-_(?P<album>.+)'
    trans = MetadataFromTitlePP(None, regex)
    assert trans._titleformat == regex
    assert trans._titleregex == exp_regex


# Generated at 2022-06-22 09:24:54.057526
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    p = MetadataFromTitlePP(None, None)

    for s in ['%(title)s',
              '%(title)s - %(artist)s',
              '%(title)s - %(artist)s - %(duration)s',
              '%(duration)s - %(title)s - %(artist)s']:
        match = re.match(p.format_to_regex(s), s)
        assert match is not None, 'pattern %s does not match' % s
        assert match.groups() == (None,) * (s.count('%(...)s') - 1), \
            'pattern %s does not match correctly' % s

# Generated at 2022-06-22 09:25:04.790544
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .compat import unittest

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.pp = MetadataFromTitlePP(None, None)

        def test_format_to_regex(self):
            self.assertEqual(self.pp.format_to_regex(
                '%(title)s - %(artist)s'),
                             r'(?P<title>.+)\ \-\ (?P<artist>.+)')
            self.assertEqual(self.pp.format_to_regex(
                r'%(title)s - %(artist)s'),
                             r'(?P<title>.+)\ \-\ (?P<artist>.+)')

# Generated at 2022-06-22 09:25:13.904788
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import FileDownloader
    from .extractor import gen_extractors


# Generated at 2022-06-22 09:25:22.657008
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Import
    from youtube_dl.version import __version__
    from youtube_dl.utils import ordered_dict
    from collections import OrderedDict
    # Create class
    metadata_from_title_pp = MetadataFromTitlePP(None,
        '%(artist)s - %(title)s/%(date)s/%(album)s')

    # Test with a normal case
    info = OrderedDict()
    info['title'] = 'Hello - World/2014/Foo'
    expected_output = ordered_dict(
        {'artist': 'Hello',
         'title': 'World',
         'date': '2014',
         'album': 'Foo'})
    expected_output_str = expected_output  # it's an OrderedDict
    expected_info = OrderedDict()

    #

# Generated at 2022-06-22 09:25:27.115730
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    dl = lambda *args, **kwargs: None
    pp = MetadataFromTitlePP(dl, '%(title)s - %(artist)s')
    regex = pp.format_to_regex(pp._titleformat)
    print(regex)
    assert regex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-22 09:25:43.994444
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-22 09:25:53.602965
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.downloader.Downloader import Downloader
    from youtube_dl.downloader.FileDownloader import FileDownloader
    from youtube_dl.YoutubeDL import YoutubeDL
    postprocessor = MetadataFromTitlePP(YoutubeDL(), '%(artist)s - %(title)s')
    info = {'title': 'Foo - Bar',
            'playlist': 'plop',
            'playlist_title': 'plaf',
            'format_id': 'baz'}
    info_out = info.copy()
    info_out['artist'] = 'Foo'
    info_out['title'] = 'Bar'
    dl = Downloader(FileDownloader(postprocessors=[postprocessor]), '')
    dl.to_screen = lambda x: x
    assert postprocessor.run(info)

# Generated at 2022-06-22 09:26:05.744805
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftpp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')

# Generated at 2022-06-22 09:26:16.895359
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import FileDownloader
    downloader = FileDownloader({})
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s - %(genre)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<genre>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format

# Generated at 2022-06-22 09:26:28.325651
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    import unittest
    class Test(unittest.TestCase):
        def setUp(self):
            self.mftpp = MetadataFromTitlePP(None, None)

        def test_regex_escape(self):
            self.assertEqual(self.mftpp.format_to_regex('filename'),
                             'filename')
            self.assertEqual(self.mftpp.format_to_regex('file*name'),
                             'file\*name')
            self.assertEqual(self.mftpp.format_to_regex('file/name/'),
                             'file/name/')
            self.assertEqual(self.mftpp.format_to_regex('file/(name)'),
                             'file/\\(name\\)')

# Generated at 2022-06-22 09:26:33.382950
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftpp = MetadataFromTitlePP(None, None)
    if mftpp.format_to_regex('%(artist)s - %(title)s') != '(?P<artist>.+)\ \-\ (?P<title>.+)':
        raise ValueError

# Generated at 2022-06-22 09:26:39.733375
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    print(test_MetadataFromTitlePP.__doc__)
    fmt = '%(title)s - %(artist)s - %(album)s'
    mftpp = MetadataFromTitlePP(None, fmt)
    regex = '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'
    assert mftpp._titleformat == fmt
    assert mftpp._titleregex == regex
    print('Ok')



# Generated at 2022-06-22 09:26:45.255662
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Test simple string
    proc = MetadataFromTitlePP(None, 'Foo Bar')
    assert proc._titleformat == 'Foo Bar'
    assert proc._titleregex == 'Foo Bar'

    # Test simple string with space
    proc = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert proc._titleformat == '%(title)s - %(artist)s'
    assert proc._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-22 09:26:53.454957
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    downloader = None
    formats = [
        ('%(title)s - %(artist)s', r'(?P<title>.+)\ \-\ (?P<artist>.+)'),
        ('%(artist)s - %(title)s', r'(?P<artist>.+)\ \-\ (?P<title>.+)'),
        ('%(artist)s_-_%(title)s', r'(?P<artist>.+)\_\-(?P<title>.+)')
    ]
    for (format, regex) in formats:
        pp = MetadataFromTitlePP(downloader, format)
        assert pp._titleformat == format
        assert pp._titleregex == regex

# Generated at 2022-06-22 09:27:02.882383
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP.format_to_regex(r'%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP.format_to_regex(r'%(title)s') == r'(?P<title>.+)'
    assert MetadataFromTitlePP.format_to_regex(r'%(title)s - T.O.Y.') == r'(?P<title>.+)\ \-\ T\.O\.Y\.'
    assert MetadataFromTitlePP.format_to_regex(r'T.O.Y. - %(title)s') == r'T\.O\.Y\.\ \-\ (?P<title>.+)'



# Generated at 2022-06-22 09:27:26.860608
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    def _assert_regexp_equals(mft, expected):
        assert mft._titleformat == expected
        assert mft._titleregex == expected

    mft1 = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    _assert_regexp_equals(mft1, '%(title)s - %(artist)s')

    mft2 = MetadataFromTitlePP(None, '%(title)s')
    _assert_regexp_equals(mft2, '%(title)s')

    mft3 = MetadataFromTitlePP(None, 'Foo - %(title)s - Bar')
    _assert_regexp_equals(mft3, 'Foo - %(title)s - Bar')

    mft4 = Met

# Generated at 2022-06-22 09:27:38.268383
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, r'%(title)s - %(artist)s')
    assert pp._titleformat == r'%(title)s - %(artist)s'
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    pp = MetadataFromTitlePP(None, r'%(artist)s - %(title)s')
    assert pp._titleformat == r'%(artist)s - %(title)s'
    assert pp._titleregex == r'(?P<artist>.+)\ \-\ (?P<title>.+)'

    pp = MetadataFromTitlePP(None, r'%(artist)s- %(title)s')

# Generated at 2022-06-22 09:27:49.149549
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # verify that constructors work as expected
    # MetadataFromTitlePP(downloader, titleformat)
    pp = MetadataFromTitlePP(None, '%(title)s')
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(album)s')

    # verify that format_to_regex() works as expected

# Generated at 2022-06-22 09:27:58.333852
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '')
    assert pp.format_to_regex('') == ''
    assert pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%%%(title)s%%.-%(artist)s') == r'\%\%(?P<title>.+)\%\%\.-(?P<artist>.+)'
    assert pp.format_to_regex('%%%(title)s%%.-') == r'\%\%(?P<title>.+)\%\%\.-'

# Generated at 2022-06-22 09:28:09.033081
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import __builtin__
    class FakeDownloader:
        to_screen_list = []
        def to_screen(self, msg):
            self.to_screen_list.append(msg)
    downloader = FakeDownloader()
    pp = MetadataFromTitlePP(downloader, '%(title)s')
    info = {
        'title': 'This is a title',
    }
    pp.run(info)
    assert info['title'] == 'This is a title'
    assert downloader.to_screen_list == ['[fromtitle] parsed title: This is a title']
    downloader.to_screen_list = []
    info = {
        'title': 'This is a title',
    }
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')

# Generated at 2022-06-22 09:28:19.954305
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    assert pp.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert pp.format_to_regex('%(artist)s - %(title)s') == r'(?P<artist>.+)\ \-\ (?P<title>.+)'
    assert pp.format_to_regex('%(artist)s - %(title)s - %(album)s') == r'(?P<artist>.+)\ \-\ (?P<title>.+)\ \-\ (?P<album>.+)'
    assert pp.format_to_regex('%(artist)s [%(title)s]') == r'(?P<artist>.+)\ \[(?P<title>.+)\]'


# Generated at 2022-06-22 09:28:31.065843
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import io
    import mock
    from .common import FileDownloader

    # Mock FileDownloader
    with mock.patch.object(sys, 'stdout', io.StringIO()) as mocked_stdout:
        # Mock info dict
        info = {'title': 'foo',
                'desc': 'bar'}
        # Test 1
        MetadataFromTitlePP(FileDownloader({}), '%(title)s').run(info)
        assert mocked_stdout.getvalue() == '[fromtitle] parsed title: foo\n'

        # Test 2
        info = {'title': 'foo - bar',
                'desc': 'bar'}
        MetadataFromTitlePP(FileDownloader({}), '%(title)s - %(desc)s').run(info)
        assert mocked_stdout.get

# Generated at 2022-06-22 09:28:41.472785
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mf = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert mf.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\\ \-\\ (?P<artist>.+)'
    assert mf.format_to_regex('%(title)s - %(artist)s - %(album)s - %(date)s') == '(?P<title>.+)\\ \-\\ (?P<artist>.+)\\ \-\\ (?P<album>.+)\\ \-\\ (?P<date>.+)'
    assert mf.format_to_regex('%(title)s') == '(?P<title>.+)'

# Generated at 2022-06-22 09:28:48.868473
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    import unittest

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.fmt_to_regex = MetadataFromTitlePP(None, None).format_to_regex

        def test_empty(self):
            self.assertEqual(self.fmt_to_regex(''), '')

        def test_no_vars(self):
            self.assertEqual(self.fmt_to_regex('no vars'), 'no vars')

        def test_one_var(self):
            self.assertEqual(
                self.fmt_to_regex('one %(var)s'),
                'one (?P<var>.+)')


# Generated at 2022-06-22 09:28:59.506449
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """Function test_MetadataFromTitlePP_run
    """

    import sys
    class DummyYoutubeDL:
        def __init__(self):
            self.to_screen_buffer = []
        def to_screen(self, msg):
            self.to_screen_buffer.append(msg)

    info = {
        'id': '8dABWg7vRw0',
        'title': '09. Let There Be Rock',
        'ext': 'mp3',
        'uploader': 'AC/DC Official',
        'creator': 'AC/DC',
        'artist': 'AC/DC',
        'album': 'Let There Be Rock'
    }

    # Using complex regex to parse title

# Generated at 2022-06-22 09:29:34.596595
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    mft = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    regex = mft._titleregex
    assert regex == r'(?P<artist>.+)\ \-\ (?P<title>.+)', regex
    mft = MetadataFromTitlePP(None, ' %(artist)s - %(title)s ')
    regex = mft._titleregex
    assert regex == r'\ (?P<artist>.+)\ \-\ (?P<title>.+)\ ', regex
    mft = MetadataFromTitlePP(None, ' %(artist)s -     %(title)s ')
    regex = mft._titleregex

# Generated at 2022-06-22 09:29:44.898605
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .compat import compat_urllib_request

    # Simulate FileDownloader
    class FakeFileDownloader(FileDownloader):
        def to_screen(self, message):
            print(message)

    # Simulate info dict
    info = {
        'title': 'Video Title - Artist'
    }

    # Simulate request response
    class FakeRequest:
        def __init__(self, read_func):
            self.read_func = read_func
        def read(self):
            return self.read_func()

    # Simulate urllib.request
    class FakeUrllibRequest:
        def urlopen(self, url):
            return FakeRequest(lambda: '{}')

    fd = FakeFileDownloader({}, {}, {})

# Generated at 2022-06-22 09:29:55.821527
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    instance = MetadataFromTitlePP('dummy', 'dummy')
    assert r'(?P<title>.+)\ \-\ (?P<artist>.+)' == instance.format_to_regex('%(title)s - %(artist)s')
    assert r'(?P<attribute>.+)' == instance.format_to_regex('%(attribute)s')
    assert r'prefix(\?P<attribute>.+)' == instance.format_to_regex('prefix%(attribute)s')
    assert r'(?P<attribute>.+)\suffix' == instance.format_to_regex('%(attribute)ssuffix')
    assert r'(?P<attribute>.+)\-more' == instance.format_to_regex('%(attribute)s-more')

# Generated at 2022-06-22 09:29:59.017012
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mf = MetadataFromTitlePP(None, None)

    assert mf.format_to_regex(r'%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-22 09:30:07.407630
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import youtube_dl

    def run_pp(title, fmt, **expectation):
        ydl = youtube_dl.YoutubeDL(dict(nocheckcertificate=True))
        ydl.params['titleformat'] = fmt
        ydl.params['writeinfojson'] = True
        ydl.add_default_info_extractors()
        ydl.add_post_processor(MetadataFromTitlePP(ydl, fmt))
        ie = ydl.extract_info('http://example.com', download=False)
        ydl.process_ie_result(ie, download=False)

        assert ie['title'] == title, 'Title was not parsed correctly'
        for attr, value in expectation.items():
            assert ie[attr] == value, '%s was not parsed correctly' % attr



# Generated at 2022-06-22 09:30:13.751335
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # test regular expression
    mftpp = MetadataFromTitlePP({}, '')

    assert mftpp.format_to_regex('%(title)s - %(artist)s') == \
        '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'

    # now test function itself
    assert mftpp.format_to_regex('%(title)s - %(artist)s') == \
        re.compile('(?P<title>.+)\\ \\-\\ (?P<artist>.+)').pattern

# Generated at 2022-06-22 09:30:21.630777
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    metatitle = MetadataFromTitlePP(None, None)

    assert metatitle.format_to_regex('foo') == 'foo'
    assert metatitle.format_to_regex('%(artist)s') == '(?P<artist>.+)'
    assert metatitle.format_to_regex('%(artist)s - %(title)s') == '(?P<artist>.+)\ \-\ (?P<title>.+)'
    assert metatitle.format_to_regex('Foo - %(artist)s - %(title)s') == 'Foo\ \-\ (?P<artist>.+)\ \-\ (?P<title>.+)'

# Generated at 2022-06-22 09:30:27.349259
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # The arguments are ignored in the MetadataFromTitlePP.run() under test
    downloader = None
    titleformat = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(downloader, titleformat)
    info = { 'title' : 'A Great Song - by A. N. Artist', 'artist' : None }
    exp_info = { 'title' : 'A Great Song', 'artist' : 'by A. N. Artist' }
    res, info_out = pp.run(info)
    assert res == []
    assert info_out == exp_info


# Generated at 2022-06-22 09:30:38.470289
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({
        'postprocessors': [{
            'key': 'MetadataFromTitlePP',
            'titleformat': '%(title)s - %(artist)s',
        }],
        'logger': YoutubeDL.std_logger,
        'progress_hooks': [],
    })
    ydl._report_error = lambda *x: None
    ydl._downloader = None

    info = {'title': 'Numb - Linkin Park'}
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    assert pp.run(info) == ([], {'title': 'Numb', 'artist': 'Linkin Park'})

    # titleformat regex is not modified if it does not

# Generated at 2022-06-22 09:30:45.707056
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+) - (?P<artist>.+)'

    pp = MetadataFromTitlePP(None, 'Simple title')
    assert pp._titleformat == 'Simple title'
    assert pp._titleregex == 'Simple title'

