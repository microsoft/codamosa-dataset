

# Generated at 2022-06-22 09:21:11.540358
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import youtube_dl
    import shutil

    ydl = youtube_dl.YoutubeDL()
    meta_extractor = MetadataFromTitlePP(ydl, '%(title)s-%(artist)s-%(album)s')

    # Test if titleformat with one %(foo)s is converted to regex
    assert meta_extractor._titleregex == '(?P<title>.+)\-(?P<artist>.+)\-(?P<album>.+)'

    # Test if titleformat without %(foo)s is left untouched
    titleformat = 'foo bar baz'
    meta_extractor = MetadataFromTitlePP(ydl, titleformat)
    assert meta_extractor._titleregex == titleformat

    # Test if titleformat with several %(foo)s is converted to regex

# Generated at 2022-06-22 09:21:17.877984
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    titleformat_test_cases = {
        '%(one)s - %(two)s': r'(?P<one>.+)\ \-\ (?P<two>.+)',
        '%(one)s-%(two)s': r'(?P<one>.+)-(?P<two>.+)',
        '%(one)s': r'(?P<one>.+)'
    }

    pp = MetadataFromTitlePP(None, None) # dummy init


# Generated at 2022-06-22 09:21:28.038968
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    import unittest
    from ..extractor.common import InfoExtractor
    class TestMetadataFromTitlePP(unittest.TestCase):
        def test_format_to_regex(self):
            cases = [
                ('%(title)s', '(?P<title>.+)'),
                ('%(title)s - %(artist)s', '(?P<title>.+)\ \-\ (?P<artist>.+)'),
                ('%(artist)s - %(title)s', '(?P<artist>.+)\ \-\ (?P<title>.+)'),
                ('%(artist)s - %(title)s - %(album)s', '(?P<artist>.+)\ \-\ (?P<title>.+)\ \-\ (?P<album>.+)'),
            ]

# Generated at 2022-06-22 09:21:36.323029
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP('', '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    pp = MetadataFromTitlePP('', 'title')
    assert pp._titleformat == 'title'
    assert pp._titleregex == 'title'

# Generated at 2022-06-22 09:21:41.308534
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp._titleformat == '%(artist)s - %(title)s'
    assert pp._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'

    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s [%(id)s]')
    assert pp._titleformat == '%(artist)s - %(title)s [%(id)s]'
    assert pp._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)\ \[(?P<id>.+)\]'


# Generated at 2022-06-22 09:21:52.112463
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    class MockDownloader():
        def to_screen(self, message):
            pass

    downloader = MockDownloader()
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    assert(pp.format_to_regex('%(title)s - %(artist)s') ==
           r'(?P<title>.+)\ \-\ (?P<artist>.+)')
    assert(pp.format_to_regex('%(title)s-%(artist)s') ==
           r'(?P<title>.+)-(?P<artist>.+)')
    assert(pp.format_to_regex('%(title)s %(artist)s') ==
           r'(?P<title>.+)\ (?P<artist>.+)')

# Generated at 2022-06-22 09:22:01.062741
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    downloader = FakeYDL()
    pp = MetadataFromTitlePP(downloader, '%(artist)s - %(title)s')

    info = {'title': 'Black Sabbath - War Pigs'}
    pp.run(info)
    assert info == {'title': 'Black Sabbath - War Pigs', 'artist': 'Black Sabbath'}

    # no match
    info = {'title': 'Black Sabbath - War Pigs - Paranoid'}
    pp.run(info)
    assert info == {'title': 'Black Sabbath - War Pigs - Paranoid'}


# Generated at 2022-06-22 09:22:08.966890
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Testing constructor of correct regexes
    regexes = [
        (r'%(title)s - %(artist)s - %(album)s',
         r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'),
        (r'%(title)s', r'(?P<title>.+)'),
    ]
    for titleformat, expected_regex in regexes:
        instance = MetadataFromTitlePP(None, titleformat)
        assert instance._titleregex == expected_regex, 'regex %r != %r' % (expected_regex, instance._titleregex)


# Generated at 2022-06-22 09:22:18.925145
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.YoutubeDL import YoutubeDL
    from StringIO import StringIO
    from .downloader import Downloader
    ydl = YoutubeDL({})
    ydl.add_default_info_extractors()
    ie = ydl.get_info_extractor('Youtube')

# Generated at 2022-06-22 09:22:28.567685
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    class MockInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(MockInfoDict, self).__init__(*args, **kwargs)
            self['title'] = None
            self['artist'] = None
            self['album'] = None
            self['track'] = None
            self['disc'] = None

    infodict = MockInfoDict()
    titleformat = '%(artist)s - %(title)s'
    mpp = MetadataFromTitlePP(None, titleformat)
    infodict['title'] = 'Video by Artist'
    mpp.run(infodict)
    assert infodict['title'] is not None


# Generated at 2022-06-22 09:22:35.645346
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .downloader import YoutubeDL
    pp = MetadataFromTitlePP(YoutubeDL(), 'bla%(title)sbla')
    assert pp._titleformat == 'bla%(title)sbla'
    assert pp._titleregex == '(?P<title>.+)'


# Generated at 2022-06-22 09:22:45.551536
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import Downloader

    downloader = Downloader()

    titleformat = '%(title)s - %(artist)s'
    title = 'Sigur Rós - "Vidrar vel til loftárása"'
    titleregex = r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    postprocessor = MetadataFromTitlePP(downloader, titleformat)

    assert postprocessor._titleformat == titleformat
    assert postprocessor._titleregex == titleregex

    info = {'title': title}
    postprocessor.run(info)
    assert info == {
        'title': 'Sigur Rós',
        'artist': '"Vidrar vel til loftárása"'
    }



# Generated at 2022-06-22 09:22:56.632388
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class FakeYDL:
        def to_screen(self, msg):
            print(msg)

    print('test 1:')
    ydl = FakeYDL()
    postproc = MetadataFromTitlePP(ydl, '(?P<title>.+) - (?P<artist>.+)')
    info = { 'title' : 'SomeTitle - SomeArtist' }
    postproc.run(info)
    if info['title'] != 'SomeTitle - SomeArtist' or info['artist'] != 'SomeArtist':
        raise AssertionError()

    print('test 2:')
    ydl = FakeYDL()
    postproc = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    info = { 'title' : 'SomeTitle - SomeArtist' }
    postproc.run(info)

# Generated at 2022-06-22 09:23:08.345248
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from_title = MetadataFromTitlePP(None, None)
    assert from_title.format_to_regex('foo') == 'foo'
    assert from_title.format_to_regex('%(foo)s') == '(?P<foo>.+)'
    assert from_title.format_to_regex('%(foo)s%(bar)s') == '(?P<foo>.+)(?P<bar>.+)'
    assert from_title.format_to_regex('%(foo)s - %(bar)s') == '(?P<foo>.+)\ \-\ (?P<bar>.+)'
    assert from_title.format_to_regex('%(foo)s "%(bar)s') == '(?P<foo>.+)\ \"(?P<bar>.+)'

# Generated at 2022-06-22 09:23:19.634253
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mp = MetadataFromTitlePP("", '')
    assert mp.format_to_regex("test video") == "test video"
    assert mp.format_to_regex("test video %(id)s something") == "test video (?P<id>.+) something"
    assert mp.format_to_regex("test video %(id)s something %(key)s") == "test video (?P<id>.+) something (?P<key>.+)"
    assert mp.format_to_regex("test video - %(id)s something - %(key)s") == "test video - (?P<id>.+) something - (?P<key>.+)"

# Generated at 2022-06-22 09:23:25.013541
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    """
    Test if method format_to_regex(self,fmt): of class MetadataFromTitlePP
    works as expected.
    """
    obj = MetadataFromTitlePP(None, '')

    assert obj.format_to_regex('') == ''
    assert obj.format_to_regex('%s') == '%s'
    assert obj.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert obj.format_to_regex('%s - %s') == '%s\ \-\ %s'

# Generated at 2022-06-22 09:23:31.565641
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    testobj = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    testfunc = testobj.format_to_regex
    assert testfunc('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert testfunc('%(title)s') == r'(?P<title>.+)'

# Generated at 2022-06-22 09:23:38.548417
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    Unit test for method run of class MetadataFromTitlePP
    """
    downloader = FakeDownloader()
    metadata_from_title_pp = MetadataFromTitlePP(downloader, '%(artist)s - %(title)s')
    key_list, info = metadata_from_title_pp.run({'title': 'Royksopp - Eple'})
    assert key_list == []
    assert info['title'] == 'Eple'
    assert info['artist'] == 'Royksopp'


# Generated at 2022-06-22 09:23:49.803173
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftpp = MetadataFromTitlePP(None, None)
    assert '%(title)s' == mftpp.format_to_regex(r'%(title)s')
    assert '%(title)s' == mftpp.format_to_regex('%(title)s')
    assert '(%(title)s)' == mftpp.format_to_regex('(%(title)s)')
    assert r'%\(title\)s' == mftpp.format_to_regex(r'%\(title\)s')
    assert r'\(%\(title\)s\)' == mftpp.format_to_regex(r'\(%\(title\)s\)')

# Generated at 2022-06-22 09:23:58.706485
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # No %(something)s in titleformat
    no_placeholder = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert no_placeholder._titleregex == '%\(title\)s\ \-\ %\(artist\)s'
    # One %(something)s in titleformat
    one_placeholder = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert one_placeholder._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-22 09:24:13.234115
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .test import get_test_converter
    from ytdl import YoutubeDL

    ydl = YoutubeDL(params={'sid': 'test_MetadataFromTitlePP_run', 'dump_single_json': True},
                    converter=get_test_converter(
                        {'id': 'test_MetadataFromTitlePP_run'},
                        {'title': 'Title - artist', 'description': 'description'}))
    m = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    info = {'title': 'Title - artist', 'description': 'description'}
    info = m.run(info)
    assert info[0] == {}
    assert info[1]['title'] == 'Title'
    assert info[1]['artist'] == 'artist'

# Generated at 2022-06-22 09:24:17.337972
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'



# Generated at 2022-06-22 09:24:26.307828
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-22 09:24:37.115861
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from . import FileDownloader
    from .extractor import YoutubeIE
    from .cache import YoutubeInfoCache

    downloader = FileDownloader({})
    downloader.add_info_extractor(YoutubeIE(downloader))
    downloader.add_info_extractor(MetadataFromTitlePP(downloader,
                                                      '%(artist)s - %(title)s'))
    downloader.set_info_cache(YoutubeInfoCache())

    # URL and expected metadata of a song on youtube
    url = 'https://www.youtube.com/watch?v=t7Gzs9sCgFk'

# Generated at 2022-06-22 09:24:46.235668
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import ydl
    ydl_obj = ydl.YoutubeDL()
    info = {
        'id': '1234567890',
        'ext': 'mp4',
    }


# Generated at 2022-06-22 09:24:49.619035
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleregex == ('(?P<title>.+)\ \-\ (?P<artist>.+)')


# Generated at 2022-06-22 09:24:56.835560
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    m = MetadataFromTitlePP(None, None)
    assert m.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert m.format_to_regex('%(title)s-%(artist)s') == '(?P<title>.+)\-(?P<artist>.+)'
    assert m.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert m.format_to_regex('%(title)s - %(artist)s - %(date)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<date>.+)'

# Generated at 2022-06-22 09:25:04.414419
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    p = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert p._titleformat == '%(artist)s - %(title)s'
    assert p._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'

    p = MetadataFromTitlePP(None, '%(videoid)s - %(title)s')
    assert p._titleregex == '(?P<videoid>.+)\ \-\ (?P<title>.+)'

    p = MetadataFromTitlePP(None, '%(videoid)s')
    assert p._titleregex == '(?P<videoid>.+)'

    p = MetadataFromTitlePP(None, 'test')
    assert p._titleformat == 'test'
    assert p._titlere

# Generated at 2022-06-22 09:25:12.420966
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    tests = [
        ('%(artist)s - %(title)s', '(?P<artist>.+)\\ \\-\\ (?P<title>.+)'),
        ('%(artist)s', '(?P<artist>.+)'),
        ('%(artist)', '%(artist)'),
        ('%(artist)s %', '(?P<artist>.+)\\ %'),
        ('%', '%'),
        ('', ''),
        ('%(artist', '%(artist')
    ]
    for fmt, regex in tests:
        assert pp.format_to_regex(fmt) == regex

# Generated at 2022-06-22 09:25:19.310802
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    p = MetadataFromTitlePP(None, None)
    assert p.format_to_regex('%(id)s') == '(?P<id>.+)'
    assert p.format_to_regex('%(title)s%(id)s') == '(?P<title>.+)(?P<id>.+)'
    assert p.format_to_regex('%(title)s %(id)s') == '(?P<title>.+) (?P<id>.+)'

# Generated at 2022-06-22 09:25:34.728034
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    import unittest
    class TestMetadataFromTitlePP(unittest.TestCase):
        def test(self):
            from .common import PostProcessor
            postprocessor = MetadataFromTitlePP(None, None)

# Generated at 2022-06-22 09:25:44.256441
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    titleformat = '%(title)s_%(artist)s'
    titleregex = '(?P<title>.+)_(?P<artist>.+)'
    title = titleformat % {'artist': 'Ed Sheeran', 'title': 'Thinking out loud'}
    info = {'title': title}
    metadata_from_title_pp = MetadataFromTitlePP('dummy', titleformat)
    assert metadata_from_title_pp._titleformat == titleformat
    assert metadata_from_title_pp._titleregex == titleregex
    assert titleformat in title
    assert titleregex in title
    titlematch = re.match(titleregex, title)
    assert titlematch is not None
    assert titlematch.group('artist') == 'Ed Sheeran'

# Generated at 2022-06-22 09:25:51.442153
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    class FakeInfoDict(object):
        def __init__(self):
            self.__dict__ = dict()

    class FakeYDL(object):
        def to_screen(self, message):
            print(message)

    # test building regex from format string
    format_strings = ['%(uploader)s',
                      '%(uploader_id)s',
                      '%(uploader)- %(uploader_id)s',
                      '%(uploader)s - %(uploader_id)s',
                      '%(uploader)s - %(uploader_id)s - %(id)s',
                      '%(uploader)s - %(uploader_id)s - %(id)s - %(node)s']
    info = FakeInfoDict()

# Generated at 2022-06-22 09:25:57.528409
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from youtube_dl.YoutubeDL import YoutubeDL
    c = MetadataFromTitlePP(YoutubeDL({}), '%(title)s - %(artist)s')
    assert (c.format_to_regex('%(title)s - %(artist)s') ==
            '(?P<title>.+)\ \-\ (?P<artist>.+)')
    
if __name__ == '__main__':
    for name in dir():
        if name.startswith('test_'):
            print('Running %s...' % name)
            eval(name)()
            print('OK.')
    print('Done.')

# Generated at 2022-06-22 09:26:04.387769
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    titleformat = '[%(upload_date)s][%(id)]s-%(title)s-%(creator)s'
    mfpp = MetadataFromTitlePP(None, titleformat)
    regex = (r'\[(?P<upload_date>.+)\]\[%(id)]s\-(?P<title>.+)\-'
             r'(?P<creator>.+)')
    assert regex == mfpp.format_to_regex(titleformat)



# Generated at 2022-06-22 09:26:11.530332
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert isinstance  (pp, PostProcessor)
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-22 09:26:19.249532
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .compat import compat_basestring

    from .common import FileDownloader
    from .extractor import youtube_dl
    import types

    def _dummy_extract_info(self, url):
        return {'title': 'My title'}

    # Monkey-patch.
    old_extract_info = youtube_dl.extractor.Extractor.extract

    youtube_dl.extractor.Extractor.extract = types.MethodType(_dummy_extract_info, youtube_dl.extractor.Extractor)
    downloader = FileDownloader({'usetitle': True, 'quiet': True})
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(chapter)s - %(duration)s')
    pp.run(info={})

# Generated at 2022-06-22 09:26:28.016960
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    """
    >>> MetadataFromTitlePP(None, '%(title)s - %(artist)s')._titleregex
    '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'
    >>> MetadataFromTitlePP(None, '%(title)s')._titleregex
    '%\\(title\\)s'
    >>> MetadataFromTitlePP(None, '%(title)s')._titleformat
    '%(title)s'
    >>> MetadataFromTitlePP(None, '%(title)s %(artist)s')._titleformat
    '%(title)s %(artist)s'
    """

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 09:26:31.013879
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    Unit test for method run of class MetadataFromTitlePP
    """

# Generated at 2022-06-22 09:26:40.761227
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import YoutubeDL
    from .extractor import YoutubeIE
    from .compat import compat_urllib_request

    # test_get_info
    result = YoutubeIE._get_info(YoutubeDL(), {
        'url': 'https://www.youtube.com/watch?v=BaW_jenozKc',
        'extractor': 'youtube'
    })
    assert result['title'] == 'youtube-dl test video "\'/\\ä↭𝕐'

    # test_get_title_from_json

# Generated at 2022-06-22 09:26:58.236751
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from_title = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert from_title.format_to_regex('abcd - efg') == 'abcd\ \-\ efg'
    assert from_title.format_to_regex('abcd - efg') == 'abcd\ \-\ efg'
    assert from_title.format_to_regex('abcd - efg') == 'abcd\ \-\ efg'
    assert (from_title.format_to_regex('%(title)s - %(artist)s')
            == '(?P<title>.+)\ \-\ (?P<artist>.+)')

# Generated at 2022-06-22 09:27:01.751603
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    titleformat = '%(title)s - %(artist)s'

    expected_titleregex = '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'
    titlepp = MetadataFromTitlePP(None, titleformat)
    assert titlepp._titleregex == expected_titleregex

# Generated at 2022-06-22 09:27:13.650713
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.FileDownloader import FileDownloader
    from test.test_utils import FakeYdl
    from test.test_utils import MockYTLogger
    from argparse import Namespace
    from youtube_dl.utils import encode_str

    downloader = FileDownloader(None, FakeYdl(params=Namespace()))
    downloader.params.test = True
    downloader.params.usenetrc = False
    downloader.params.username = None
    downloader.params.password = None
    downloader.params.videopassword = None
    downloader.params.ap_mso = None
    downloader.params.ap_username = None
    downloader.params.ap_password = None
    downloader.params.ap_list = False

# Generated at 2022-06-22 09:27:25.741249
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL

    ydl = YoutubeDL({})
    ydl.add_default_info_extractors()

    info = {}
    info['title'] = 'This is a test of a very very long title with spaces'
    fmt = '%(title)s'
    pp = MetadataFromTitlePP(ydl, fmt)
    title = info['title']
    assert title == pp.run(info)[1]['title']
    assert info['title'] == 'This is a test of a very very long title with spaces'

    fmt = '%(title)s - %(id)s'
    pp = MetadataFromTitlePP(ydl, fmt)
    info = {}
    info['title'] = 'This is a test - 12345'

# Generated at 2022-06-22 09:27:36.695955
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    mp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert mp._titleformat == '%(title)s - %(artist)s'
    assert mp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    mp = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(album)s')
    assert mp._titleformat == '%(title)s - %(artist)s - %(album)s'
    assert mp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'

# Generated at 2022-06-22 09:27:43.367530
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .common import FileDownloader
    downloader = FileDownloader('', None)
    pp = MetadataFromTitlePP(downloader, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '(?P<title>.+)'
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    pp = MetadataFromTitlePP(downloader, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '(?P<title>.+)'

# Generated at 2022-06-22 09:27:53.611428
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import Downloader
    pp = MetadataFromTitlePP(None, '')
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert pp.format_to_regex('%(title)s -') == '(?P<title>.+)\ \-'
    assert pp.format_to_regex(' - %(title)s') == '\-\ (?P<title>.+)'
    assert pp.format_to_regex('%(title)s %(title)s') == '(?P<title>.+)\ (?P<title>.+)'

# Generated at 2022-06-22 09:28:04.100865
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    Test if method run returns the expected output with given input.
    """
    from .common import FakeYDL
    import unittest

    class TestMetadataFromTitlePP(unittest.TestCase):
        """
        A test class for running unit test on method run of class MetadataFromTitlePP.
        """
        @classmethod
        def setUpClass(cls):
            """
            Setup for test class TestMetadataFromTitlePP.
            """
            cls.title = 'Metadata From Title'
            cls.info = {'title': cls.title, 'fulltitle': cls.title}
            cls.downloader = FakeYDL()


# Generated at 2022-06-22 09:28:15.565798
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from ytdl.extractor import YoutubeIE
    from ytdl.postprocessor import FFmpegMetadataPP
    from ytdl.downloader import YoutubeDL
    metadata = ['title', 'artist', 'extractor']
    downloader = YoutubeDL({'writethumbnail': False, 'writeautomaticsub': False,
                            'writedescription': False, 'writesubtitles': False,
                            'writeinfojson': False, 'writethumbnail': False})
    pp = FFmpegMetadataPP(downloader, metadata, None, None)
    mtt = MetadataFromTitlePP(downloader, pp.get_title_format(YoutubeIE))

# Generated at 2022-06-22 09:28:23.986437
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .extractor.common import InfoExtractor
    from .utils import get_testdata_file
    from .compat import compat_urlparse

    class MockDownloader(object):
        def to_screen(self, *args, **dargs):
            print(args[0])

    class MockInfoExtractor(InfoExtractor):
        def report_warning(self, message):
            pass
    
    d = MockDownloader()
    d.add_info_extractor(MockInfoExtractor('mock_ie'))
    mft = MetadataFromTitlePP(d, '%(title)s - %(artist)s')
    info = {}
    info['id'] = 'foo'
    info['title'] = 'title - artist'
    info['upload_date'] = '1970-01-01'

# Generated at 2022-06-22 09:28:34.958272
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    fmt = '%(title)s - %(artist)s'
    regex = MetadataFromTitlePP(None, fmt).format_to_regex(fmt)
    assert re.match(regex, 'Foo - Bar')
    assert re.match(regex, 'Foo - Bar - Baz')
    assert re.match(regex, 'Foo') is None

# Generated at 2022-06-22 09:28:39.852832
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    inst = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert inst._titleformat == '%(title)s - %(artist)s'
    assert inst._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-22 09:28:46.889343
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import FileDownloader

    downloader = FileDownloader({})
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    assert pp.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('(%(title)s) - %(artist)s') == r'\((?P<title>.+)\)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-22 09:28:57.509727
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    def test(fmt, expected_result):
        result = MetadataFromTitlePP(None, fmt).format_to_regex(fmt)
        assert result == expected_result, (
            'result = %s expected_result = %s'
            % (result, expected_result))

    # Test regex from the documentation
    fmt = '%(title)s - %(artist)s'
    test(fmt, r'(?P<title>.+)\ \-\ (?P<artist>.+)')

    # Same with literal characters escaped
    fmt = '%(title)s - \%(artist)s'
    test(fmt, r'(?P<title>.+)\ \-\\\%\(artist\)s')

    # Same with literal characters escaped and python argument

# Generated at 2022-06-22 09:29:07.417826
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    def run_test(titleformat, title, expected):
        mftpp = MetadataFromTitlePP(None, titleformat)
        actual = mftpp.run({'title': title})

        if actual == expected:
            return True
        else:
            print('Error: MetadataFromTitlePP() failed to parse '
                  'a title string.\nExpected: ' + str(expected)
                  + '\nActual: ' + str(actual) + '\n')
            return False

    # Test with single-word metadata
    assert(run_test('%(artist)s', 'Dire Straits', ([], {'title': 'Dire Straits', 'artist': 'Dire Straits'})) == True)

# Generated at 2022-06-22 09:29:12.369361
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    """
    Unit test for constructor of class MetadataFromTitlePP
    """
    from _YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-22 09:29:15.559321
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    titleformat = '%(title)s - %(artist)s'
    regex = MetadataFromTitlePP(None, titleformat).format_to_regex(titleformat)
    assert regex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    titleformat = '%(title)s'
    regex = MetadataFromTitlePP(None, titleformat).format_to_regex(titleformat)
    assert regex == r'(?P<title>.+)'


# Generated at 2022-06-22 09:29:23.917367
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    testCases = [
        {'fmt': '%(title)s',
         'regex': r'(?P<title>.+)'},
        {'fmt': '%(title)s - %(artist)s',
         'regex': r'(?P<title>.+)\ \-\ (?P<artist>.+)'},
        {'fmt': '%(title)s - %(artist)s - %(album)s',
         'regex': r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'}
    ]

    for testCase in testCases:
        fromtitle = MetadataFromTitlePP(None, None)

# Generated at 2022-06-22 09:29:29.445088
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP('none', '%(title)s - %(artist)s [%(id)s]')
    assert pp._titleformat == '%(title)s - %(artist)s [%(id)s]'
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \[(?P<id>.+)\]'



# Generated at 2022-06-22 09:29:37.546065
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(foo)s - %(bar)s')
    assert pp.format_to_regex('%(foo)s - %(bar)s') == '(?P<foo>.+)\ \-\ (?P<bar>.+)'

    pp = MetadataFromTitlePP(None, '%(foo)s - %(bar)s - more stuff')
    assert pp.format_to_regex('%(foo)s - %(bar)s - more stuff') == '(?P<foo>.+)\ \-\ (?P<bar>.+)\ \-\ more\ stuff'

    pp = MetadataFromTitlePP(None, '%(foo)s - %(bar)s - more stuff')

# Generated at 2022-06-22 09:29:56.520312
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    def get_mock_get_thumbnail(url):
        def get_thumbnail(path):
            class MockUrlRequest:
                def __init__(self, url):
                    self._url = url

                def read(self):
                    return 'thumbnail'

                def close(self):
                    pass

            if re.search(r'http://test.test/test\.test', self._url) is None:
                raise IOError()
            return MockUrlRequest(self._url)
        return get_thumbnail

    class MockYDL:
        def __init__(self):
            self._screen_file = open('./screen.txt', 'w')

        def to_screen(self, text):
            print(text)

        def to_stdout(self, text):
            print(text)


# Generated at 2022-06-22 09:30:05.363135
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleregex == '(?P<title>.+)'
    pp = MetadataFromTitlePP(None, '%(title)s %(artist)s')
    assert pp._titleregex == '(?P<title>.+)\ (?P<artist>.+)'
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(album)s')

# Generated at 2022-06-22 09:30:12.900896
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    titleformat = '%(uploader)s - %(uploader_id)s - %(title)s [%(id)s]'
    mftpp = MetadataFromTitlePP(None, titleformat)
    regex = mftpp.format_to_regex(titleformat)
    assert re.match(regex, 'foo - bar - title [baz]') is not None
    assert re.match(regex, 'foo - ') is None
    assert re.match(regex, 'foo - bar - title') is None
    assert re.match(regex, 'foo - bar - title [baz] x') is None
    assert re.match(regex, 'foo - bar - title [baz x]') is None

# Generated at 2022-06-22 09:30:20.917572
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    try:
        from test import test_support
    except ImportError:
        return

    test_support.requires('network')

    # Test empty title
    info = {'title': ''}
    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp.run(info) == ([], info)

    # Test title with no metadata
    info = {'title': 'Something'}
    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp.run(info) == ([], info)

    # Test title with metadata
    info = {'title': 'Something - Something Else'}
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')

# Generated at 2022-06-22 09:30:28.085853
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-22 09:30:38.922149
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test default format if no format is given.
    # This test will fail if the default format is changed.
    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleregex == r'(?P<title>.+)'
    assert pp.run({'title': 'foo'}) == ([], {'title': 'foo'})

    # Test literal formats.
    pp = MetadataFromTitlePP(None, 'foo - bar')
    assert pp.run({'title': 'foo - bar'}) == ([], {'title': 'foo - bar'})
    assert pp.run({'title': 'foo bar'}) == ([], {'title': 'foo bar'})

    # Test regex formats.

# Generated at 2022-06-22 09:30:49.541361
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    PP = MetadataFromTitlePP(None, None)
    sample = {}
    sample['simple'] = ('%(foobar)s', '(?P<foobar>.+)')
    sample['prefix'] = ('foobar_%(foobar)s', 'foobar_(?P<foobar>.+)')
    sample['suffix'] = ('%(foobar)s_foobar', '(?P<foobar>.+)_foobar')
    sample['prefix2'] = ('foobar_%(foobar)s_barfoo', 'foobar_(?P<foobar>.+)_barfoo')
    sample['suffix2'] = ('foo%(foo)sbar%(bar)s', 'foo(?P<foo>.+)bar(?P<bar>.+)')

# Generated at 2022-06-22 09:30:55.314222
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # assuming that this test is run in the root dir of youtube-dl
    mftpp = MetadataFromTitlePP(None, '%(uploader_id)s - %(upload_date)s - %(title)s')
    assert mftpp._titleregex == '(?P<uploader_id>.+)\ \-\ (?P<upload_date>.+)\ \-\ (?P<title>.+)'