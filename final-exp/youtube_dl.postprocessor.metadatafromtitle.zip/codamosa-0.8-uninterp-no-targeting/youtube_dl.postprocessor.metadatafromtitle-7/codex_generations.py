

# Generated at 2022-06-22 09:21:12.326108
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.downloader import Downloader
    from youtube_dl.utils import FileDownloader
    pp = MetadataFromTitlePP(
        FileDownloader(Downloader(), {}), 'a - b - c')
    assert pp._titleformat == 'a - b - c'
    assert pp._titleregex == r'(?P<a>.+)\ \-\ (?P<b>.+)\ \-\ (?P<c>.+)'

    pp = MetadataFromTitlePP(
        FileDownloader(Downloader(), {}), r'a - b - c')
    assert pp._titleformat == r'a - b - c'
    assert pp._titleregex == r'a\ \-\ b\ \-\ c'


# Generated at 2022-06-22 09:21:18.328812
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    assert pp.format_to_regex('') == ''
    assert pp.format_to_regex('a') == 'a'
    assert pp.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert pp.format_to_regex('%(title)s-%(artist)s') == '(?P<title>.+)-(?P<artist>.+)'


# Generated at 2022-06-22 09:21:28.393673
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ..YoutubeDL import YoutubeDL
    from .common import parse_extraction_info

    downloader = YoutubeDL({})
    downloader.to_screen = lambda *args, **kargs: None

    # Test 1 - Test parsing title with regex
    test_ext_info1 = parse_extraction_info(
        r'''{"title": "Leandro Rios - Amigas Cheetahs"}''')
    metatitle = MetadataFromTitlePP(downloader, r'%(title)s')
    metatitle.run(test_ext_info1)
    assert test_ext_info1['title'] == 'Leandro Rios'
    assert test_ext_info1['artist'] == 'Amigas Cheetahs'

    # Test 2 - Test parsing title with string
    test_ext_info2 = parse_ext

# Generated at 2022-06-22 09:21:40.204875
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .extractor import gen_extractors
    gen_extractors()

    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp.format_to_regex('%(artist)s - %(title)s') == '^(?P<artist>.+)\\ \\-\\ (?P<title>.+)$'

    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s - %(album)s')
    assert pp.format_to_regex('%(artist)s - %(title)s - %(album)s') == '^(?P<artist>.+)\\ \\-\\ (?P<title>.+)\\ \\-\\ (?P<album>.+)$'


# Generated at 2022-06-22 09:21:52.002681
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    from collections import namedtuple
    from unittest import TestCase
    from ydl.postprocessor import MetadataFromTitlePP
    Downloader = namedtuple('Downloader', ['to_screen'])
    # We are going to simulate a downloader which prints its output
    # to a list
    Output = []
    def to_screen(text):
        Output.append(text)
    # For testing purposes, let's make sure errors don't raise exceptions
    Downloader.raise_error = False
    Downloader.to_screen = to_screen
    Info = {'title': 'my title is this'}
    # A simple test with a format that does not need regex
    mftpp = MetadataFromTitlePP(Downloader, '%(title)s')
    mftpp.run(Info)

# Generated at 2022-06-22 09:21:59.212506
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, "%(artist)s").format_to_regex(
        "%(artist)s") == "(?P<artist>.+)"
    assert MetadataFromTitlePP(None, "%(artist)s - %(song)s").format_to_regex(
        "%(artist)s - %(song)s") == "(?P<artist>.+)\ \-\ (?P<song>.+)"

# Generated at 2022-06-22 09:22:09.088323
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp.format_to_regex('%(artist)s - %(title)s') == r'(?P<artist>.+)\ \-\ (?P<title>.+)'
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(album)s')

# Generated at 2022-06-22 09:22:18.656888
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    downloader = object()
    titleformat = '%(title)s - %(artist)s'
    postprocess = MetadataFromTitlePP(downloader, titleformat)
    info = {'title': 'foo - bar'}
    expected_info = {
        'title': 'foo',
        'artist': 'bar'
    }
    warnings = []
    assert (postprocess.run(info) == (warnings, expected_info))

    info = {'title': 'foo'}
    expected_info = {'title': 'foo'}
    assert (postprocess.run(info) == (warnings, expected_info))

    info = {}
    expected_info = {}
    assert (postprocess.run(info) == (warnings, expected_info))

# Generated at 2022-06-22 09:22:30.067219
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test run with complex format with empty replacement
    info = {'title': 'ABCDEF - GHIJKL'}
    pp = MetadataFromTitlePP(None, '%(foo)s - %(bar)s')
    pp_result = pp.run(info)
    assert pp_result == ([], info)
    # check if we have done the desired replacements
    assert info['foo'] == 'ABCDEF'
    assert info['bar'] == 'GHIJKL'
    # Test run with complex format with non-empty replacement
    info = {'title': 'ABCDEF - GHIJKL', 'foo': 'FOOBAR'}
    pp = MetadataFromTitlePP(None, '%(foo)s - %(bar)s')
    pp_result = pp.run(info)

# Generated at 2022-06-22 09:22:38.946371
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, '').format_to_regex(
        '%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    assert MetadataFromTitlePP(None, '').format_to_regex(
        '%(title) %(artist) - %(album)') == r'(?P<title>.+)\ (?P<artist>.+)\ \-\ (?P<album>.+)'

    assert MetadataFromTitlePP(None, '').format_to_regex(
        '%(title)s - %(artist)s - %(album)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'

   

# Generated at 2022-06-22 09:22:45.068881
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    assert pp.format_to_regex('%(title)s - %(artist)s') == \
        '(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-22 09:22:56.001646
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import os
    import ydl_info

    info = ydl_info.YDLInfoDict({'title': 'my_title_is_this'})
    ch = MetadataFromTitlePP(None, '%(title)s')
    ch.run(info)
    assert info['title'] == 'my_title_is_this'
    #
    info = ydl_info.YDLInfoDict({'title': 'this:is:a:title'})
    ch = MetadataFromTitlePP(None, '%(title)s')
    ch.run(info)
    assert info['title'] == 'this:is:a:title'
    #
    info = ydl_info.YDLInfoDict({'title': 'another:title'})

# Generated at 2022-06-22 09:23:02.154436
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.PostProcessor import PostProcessor

    testcases = [
        {
            'titleformat': '%(title)s',
            'title': 'Testtitle',
            'expected': {'title': 'Testtitle'},
        },
        {
            'titleformat': '%(title)s - %(artist)s',
            'title': 'Testtitle - Testartist',
            'expected': {'title': 'Testtitle', 'artist': 'Testartist'},
        },
        {
            'titleformat': '%(title)s - %(artist)s',
            'title': 'Testtitle - Testartist - BadPattern',
            'expected': {'title': 'Testtitle - Testartist - BadPattern'},
        },
    ]


# Generated at 2022-06-22 09:23:10.395633
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .downloader import YoutubeDL
    from .compat import (
        compat_str, compat_shlex_split, compat_urlparse, compat_urllib_request)

    url = 'http://test.test/test'
    ydl = YoutubeDL()
    ydl.add_default_info_extractors()
    downloader = ydl.downloader
    downloader.add_info_extractor(
        YoutubeDL(ydl, {'writethumbnail': True,
                        'usenetrc': False, 'verbose': True,
                        'simulate': True}))
    opener = compat_urllib_request.build_opener()

# Generated at 2022-06-22 09:23:15.105759
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(song)s')
    assert (pp.format_to_regex('%(artist)s - %(song)s') ==
            r'(?P<artist>.+)\ \-\ (?P<song>.+)')

# Generated at 2022-06-22 09:23:23.089975
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from .compat import str, compat_urlparse

    def YoutubeDL_to_screen(self, msg):
        pass

    YoutubeDL.to_screen = YoutubeDL_to_screen

    def YoutubeDL_extract_info(self, url, download):
        return {'title': 'The Title', 'upload_date': '20170109', 'id': '123', 'ext': 'mp4'}

    YoutubeDL.extract_info = YoutubeDL_extract_info

    def YoutubeDL_report_warning(self, msg):
        pass

    YoutubeDL.report_warning = YoutubeDL_report_warning

    def YoutubeDL_prepare_filename(self, info):
        return info['id'] + '.' + info['ext']

    YoutubeDL.prepare_filename = Youtube

# Generated at 2022-06-22 09:23:27.803800
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    info = {
        'title': 'This title is for test in MetadataFromTitlePP.run()'
    }

    class DummyYDL(object):
        def __init__(self):
            self.files_num = 0
            self.files_dic = {}
        def to_screen(self, msg):
            self.files_dic[self.files_num] = msg
            self.files_num =+ 1

    class PP(MetadataFromTitlePP):
        def __init__(self, downloader, titleformat):
            self._titleformat = titleformat
            self._titleregex = (self.format_to_regex(titleformat)
                                if re.search(r'%\(\w+\)s', titleformat)
                                else titleformat)

    ydl = DummyYDL()


# Generated at 2022-06-22 09:23:38.760603
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from collections import OrderedDict

    expected = OrderedDict()
    expected['title'] = 'This is the title of the video'
    expected['artist'] = 'The Artist'
    expected['year'] = '1991'
    expected['extra'] = 'The Extra'
    expected['title_extra'] = 'This is the title of the video - The Extra'
    expected['title_year'] = 'This is the title of the video (1991)'
    expected['title_artist'] = ('This is the title of the video by ' +
                                'The Artist')

    downloader = FakeDownloader(expected)
    for (titleformat, expected_info) in expected.items():
        pp = MetadataFromTitlePP(downloader, titleformat)
        info = {}
        info['title'] = expected_info
        (_, info) = pp

# Generated at 2022-06-22 09:23:42.772954
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    regex = pp._titleregex
    assert regex == '(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-22 09:23:51.268649
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP('dummydownloader', '%(artist)s - %(title)s')
    assert pp._titleformat == '%(artist)s - %(title)s'
    assert pp._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'

    pp = MetadataFromTitlePP('dummydownloader', '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '%(title)s'

# Generated at 2022-06-22 09:24:03.275949
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest
    import youtube_dl
    class MockDownloader():
        def to_screen(self, msg):
            pass
    from_title_pp = MetadataFromTitlePP(MockDownloader(), '[%(title)s]')


# Generated at 2022-06-22 09:24:11.062012
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # test simple substitution
    mpp = MetadataFromTitlePP(None, '%(title)s')
    assert mpp.format_to_regex('%(title)s') == '(?P<title>.+)'

    # test double substitution
    mpp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert mpp.format_to_regex('%(artist)s - %(title)s') \
        == '(?P<artist>.+)\ \-\ (?P<title>.+)'



# Generated at 2022-06-22 09:24:17.926518
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    """
    Test the method format_to_regex of class MetadataFromTitlePP
    """
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'


# vim:sw=4:ts=4:et:

# Generated at 2022-06-22 09:24:26.380419
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    postprocessor = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert(postprocessor._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)')
    postprocessor = MetadataFromTitlePP(None, '%(title)s')
    assert(postprocessor._titleregex == '(?P<title>.+)')
    postprocessor = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert(postprocessor._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)')
    postprocessor = MetadataFromTitlePP(None, '%(artist)s')
    assert(postprocessor._titleregex == '(?P<artist>.+)')

# Generated at 2022-06-22 09:24:35.266109
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl

    title = 'Title - Artist'
    video_info = {
        'title': title
    }

    dl = youtube_dl.YoutubeDL()
    mp = MetadataFromTitlePP(dl, '%(title)s - %(artist)s')
    dl.to_screen = lambda msg: print(msg)
    mp.run(video_info)

    if video_info['title'] != 'Title':
        print(
            'test_MetadataFromTitlePP_run: '
            'video_info["title"] should be "Title"; got "%s" instead'
            % video_info['title'])

# Generated at 2022-06-22 09:24:38.783322
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pass


# Generated at 2022-06-22 09:24:43.863564
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from ..common import Downloader
    test = Downloader()
    fromtitle = MetadataFromTitlePP(test, '%(title)s - %(artist)s')
    assert '^(?P<title>.+) - (?P<artist>.+)$' == test_fromtitle._titleregex
    # Note: ^ and $ will be added by re.match in run

# Generated at 2022-06-22 09:24:54.309151
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import pytest

    with pytest.raises(TypeError):
        # Invalid titleformat
        MetadataFromTitlePP(None, titleformat='%s')

    with pytest.raises(ValueError):
        # Invalid titleformat
        MetadataFromTitlePP(None, titleformat='%(title)s')

    # titleformat without regex but with %%
    pp = MetadataFromTitlePP(None, titleformat='%(title)s - %(artist)s%%')
    title = 'I am a title'
    assert pp.format_to_regex(pp._titleformat) == title

    # titleformat without regex
    pp = MetadataFromTitlePP(None, titleformat='%(title)s - %(a)s')
    title = 'I am a title'

# Generated at 2022-06-22 09:25:04.887259
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import pytest
    from ytdl import YoutubeDL
    ydl = YoutubeDL()
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s'))
    assert ydl._post_processors[0].run({'title': 'foo'}) == ([], {'title': 'foo'})
    assert ydl._post_processors[0].run({'title': 'foo'*10}) == ([], {'title': 'foo'*10})
    # Use a titleformat that does not match the title
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s'))

# Generated at 2022-06-22 09:25:10.204357
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # default constructor
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

# Unit tests for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-22 09:25:22.096528
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest
    import sys
    import os
    import inspect
    import pickle

    # fake downloader class
    class FakeDownloader():
        def to_screen(self, s):
            print(s)

    # fake info dict
    filename = os.path.abspath(
                os.path.join(os.path.dirname(os.path.abspath(__file__)),
                             "testfile.mp4"))
    info_dict = {'id': '12345',
                 'title': 'This is a %(test)s!',
                 '_filename': filename,
                 'ext': 'mp4'}

    # test
    pp = MetadataFromTitlePP(FakeDownloader(), "%(test)s")

# Generated at 2022-06-22 09:25:31.497497
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '')
    assert pp.format_to_regex(r'%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex(r'%(title)s.mp4') == r'(?P<title>.+)\.mp4'
    assert pp.format_to_regex(r'video:%(title)s') == r'video:(?P<title>.+)'
    assert pp.format_to_regex(r'Part %(partnum)d - %(title)s') == r'Part\ (?P<partnum>\d+)\ \-\ (?P<title>.+)'

# Generated at 2022-06-22 09:25:39.375669
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '(?P<title>.+)'

    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    pp = MetadataFromTitlePP(None, '[From Title] %(title)s - %(artist)s')
    assert pp._titleformat == '[From Title] %(title)s - %(artist)s'

# Generated at 2022-06-22 09:25:47.827916
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .compat import compat_urllib_parse_unquote
    
    class FakeDownloader:
        def __init__(self):
            self.to_screen_messages = []

        def to_screen(self, msg):
            self.to_screen_messages.append(msg)
        
    fake_downloader = FakeDownloader()
    
    fake_youtube_dl_instance = PostProcessor(fake_downloader)
    
    ffmpeg_metadata_pp = MetadataFromTitlePP(fake_youtube_dl_instance, '%(title)s - %(artist)s')
    
    assert ffmpeg_metadata_pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    

# Generated at 2022-06-22 09:25:51.392819
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mft = MetadataFromTitlePP(None, None)
    assert mft.format_to_regex("%(title)s - %(artist)s") == r'(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-22 09:25:58.570823
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Test for constructor of class MetadataFromTitlePP.
    fmt = '%(title)s - %(artist)s'
    mft = MetadataFromTitlePP('downloader', fmt)
    assert mft._titleformat == fmt

    # Test format_to_regex
    # simple format
    fmt = '%(title)s - %(artist)s'
    regex = mft.format_to_regex(fmt)
    assert regex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    fmt = '%(title)s'
    regex = mft.format_to_regex(fmt)
    assert regex == r'(?P<title>.+)'

    fmt = '%(album)s'

# Generated at 2022-06-22 09:26:07.516606
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from . import FileDownloader
    from .extractor import get_info_extractor, YoutubeIE
    from .compat import compat_str

    ie = get_info_extractor(YoutubeIE.ie_key())
    downloader = FileDownloader({'format': 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/mp4',
                                 'noplaylist' : True,
                                 'outtmpl': '%(id)s%(ext)s'})
    downloader.add_info_extractor(ie)
    metadata_pp = MetadataFromTitlePP(downloader,
                                      '%(artist)s - %(title)s - %(album)s')

    video_id = 'OvpYgYwTQbM' # value from test_YoutubeIE_suitable

# Generated at 2022-06-22 09:26:17.258440
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from tests.mock import MockYDL
    class DebugLogger(object):
        def debug(self, msg):
            print(msg)

    fake_ydl = MockYDL()
    fake_ydl.add_info_extractor(MockInfoExtractor())


# Generated at 2022-06-22 09:26:22.480917
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, '').format_to_regex(
        '%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-22 09:26:27.615101
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    downloader = object()
    metadata_from_title_pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    assert metadata_from_title_pp._titleformat == '%(title)s - %(artist)s'
    assert metadata_from_title_pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'



# Generated at 2022-06-22 09:26:43.367143
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Import here to avoid adding test-dependency on 'unittest' and 'random'
    from __main__ import FakeYDL
    #
    expected_dict = {'title': 'Avicii - Wake Me Up (Official Video)',
                     'artist': 'Avicii',
                     'track': 'Wake Me Up',
                     'upload_date': None,
                     'timestamp': None,
                     'epoch': None,
                     'id': 'XYZ'}
    info = expected_dict.copy()
    ydl = FakeYDL()
    pp = MetadataFromTitlePP(ydl,
                             '%(artist)s - %(track)s (%(title)s)')
    result = pp.run(info)
    assert len(result) == 2
    assert result[0] == []
    assert result

# Generated at 2022-06-22 09:26:51.026896
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    mp = MetadataFromTitlePP('downloader', '%(artist)s - %(title)s')
    assert mp._titleformat == '%(artist)s - %(title)s'
    assert mp._titleregex == r'(?P<artist>.+)\ \-\ (?P<title>.+)'
    mp = MetadataFromTitlePP('downloader', '%(title)s')
    assert mp._titleformat == '%(title)s'
    assert mp._titleregex == '%\\(title\\)s'


# Generated at 2022-06-22 09:26:57.265054
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    titleformat = '%(title)s - %(artist)s'
    metafromtitle_pp = MetadataFromTitlePP(None, titleformat)
    regex = metafromtitle_pp.format_to_regex(titleformat)
    assert regex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-22 09:27:03.545212
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '')
    assert pp.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s-%(title)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)\-(?P<title>.+)'

# Generated at 2022-06-22 09:27:15.065512
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # "basic" case
    titleformat = '%(title)s - %(artist)s'
    expected_regex = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    actual_regex = MetadataFromTitlePP(None, titleformat).format_to_regex(titleformat)
    assert expected_regex == actual_regex, (expected_regex, actual_regex)

    # case with empty input string
    titleformat = ''
    expected_regex = ''
    actual_regex = MetadataFromTitlePP(None, titleformat).format_to_regex(titleformat)
    assert expected_regex == actual_regex, (expected_regex, actual_regex)

    # case with no %(...)s
    titleformat = 'video title - artist name'


# Generated at 2022-06-22 09:27:23.092022
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Create a object of class Downloader
    downloader = object
    # Create a object of class MetadataFromTitlePP with formats
    fromtitlePP = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    # Create a dictionary with all metadata for a video
    info = {'title': 'Hello - World',
            'uploader': 'Eminem',
            'url': 'https://www.youtube.com/watch?v=45LZ5JGZwYw'}
    # Call method run of fromtitlePP with info as argument
    fromtitlePP.run(info)
    tmp = info['title']
    # Check if title value is correct
    assert info['title'] == 'Hello'
    # Check if artist value is correct
    assert info['artist'] == 'World'
    #

# Generated at 2022-06-22 09:27:28.565264
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    instance = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert instance.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'

# Generated at 2022-06-22 09:27:39.009967
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, "%(title)s")
    if pp._titleformat != "%(title)s":
        raise RuntimeError("Title format mismatch")
    if pp._titleregex != "(?P<title>.+)":
        raise RuntimeError("Title regex mismatch")

    pp = MetadataFromTitlePP(None, "foo - %(title)s")
    if pp._titleformat != "foo - %(title)s":
        raise RuntimeError("Title format mismatch")
    if pp._titleregex != "foo\ \-\ (?P<title>.+)":
        raise RuntimeError("Title regex mismatch")

    pp = MetadataFromTitlePP(None, "%(title)s - foo")
    if pp._titleformat != "%(title)s - foo":
        raise RuntimeError("Title format mismatch")

# Generated at 2022-06-22 09:27:48.915669
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '')

    fmt = '%(title)s - %(artist)s - %(album)s'
    regex = '(?P<title>.+)\\ \-\\ (?P<artist>.+)\\ \-\\ (?P<album>.+)'
    assert pp.format_to_regex(fmt) == regex

    fmt = '%(name)s - %(title)s - %(artist)s - %(album)s'
    regex = '(?P<name>.+)\\ \-\\ (?P<title>.+)\\ \-\\ (?P<artist>.+)\\ \-\\ (?P<album>.+)'
    assert pp.format_to_regex(fmt) == regex

# Generated at 2022-06-22 09:27:56.096767
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    downloader = None
    p = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')

    # Test '%(title)s - %(artist)s'
    p._titleformat = '%(title)s - %(artist)s'
    p._titleregex = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert p._titleformat == '%(title)s - %(artist)s'
    assert p._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-22 09:28:18.911687
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange


# Generated at 2022-06-22 09:28:26.916497
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # TODO: Refactor the singleton downloader
    downloader = object()
    pp = MetadataFromTitlePP(downloader, '%(artist)s - %(title)s')

# Generated at 2022-06-22 09:28:37.229836
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ..utils import DateRange
    from ..YoutubeDL import YoutubeDL
    from .common import FileDownloader
    class DummyInfoDict(dict):
        def __getitem__(self, key):
            if key == 'title':
                return 'value of title'
            raise KeyError('no key %s' % key)
        def __contains__(self, key):
            if key == 'title':
                return True
            return False

    ydl = YoutubeDL({
        'writethumbnail': True,
        'writeinfojson': True,
    })

# Generated at 2022-06-22 09:28:42.726403
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():

    with open('../testfiles/mp4.info', 'r') as info_file:
        info = json.load(info_file)

    mftpp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')

    test_info = mftpp.run(info)[1]

    assert test_info['artist'] == 'maudit'
    assert test_info['title'] == 'Hamish Macbeth 3x2 - L'

# Generated at 2022-06-22 09:28:49.945774
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # MetadataFromTitlePP.format_to_regex will do this
    # string.replace('%(title)s', '(?P<title>.+)')
    #            .replace('%(artist)s', '(?P<artist>.+)')
    #            .replace(re.escape(' - '), '\ \-\ ')
    #            .replace(re.escape(' Ft. '), '\ Ft\.\ ')
    #            .replace('%(like_count)s', '(?P<like_count>.+)')
    #            .replace('%(dislike_count)s', '(?P<dislike_count>.+)')
    metadata_from_title_pp = MetadataFromTitlePP(None, None)

    titleformat = '%(title)s - %(artist)s'
    regex = metadata_from

# Generated at 2022-06-22 09:28:53.386018
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    f = MetadataFromTitlePP
    assert f(None, '%(artist)s - %(title)s')


if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-22 09:29:03.400331
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    downloader = object()
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')

    info = {'title': 'The Title - The Artist'}
    out, info = pp.run(info)
    assert out == []
    assert info == {'title': 'The Title', 'artist': 'The Artist'}

    info = {'title': 'The Title'}
    out, info = pp.run(info)
    assert out == []
    assert info == {'title': 'The Title'}

    info = {'title': 'The Title - The Artist - Extra'}
    out, info = pp.run(info)
    assert out == []
    assert info == {'title': 'The Title', 'artist': 'The Artist - Extra'}


# Generated at 2022-06-22 09:29:10.629960
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    md = MetadataFromTitlePP(None, '%(artist)s - %(song)s')
    assert md._titleformat == '%(artist)s - %(song)s'
    assert md._titleregex == r'(?P<artist>.+)\ \-\ (?P<song>.+)'

# Unit test run method of class MetadataFromTitlePP

# Generated at 2022-06-22 09:29:17.809658
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    assert pp.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'


if __name__ == '__main__':
    test_MetadataFromTitlePP_format_to_regex()

# Generated at 2022-06-22 09:29:25.666125
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(album)s')
    assert pp._titleformat == '%(title)s - %(artist)s - %(album)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'

    pp = MetadataFromTitlePP(None, '%(title)s')

# Generated at 2022-06-22 09:29:56.376644
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class MockDownloader():
        def __init__(self):
            self.screen_output = []
        def to_screen(self, message):
            self.screen_output.append(message)

    class MockInfo():
        title = ''
        def __init__(self):
            self.keys = []
        def __setitem__(self, key, value):
            self.keys.append(key)
            self.__dict__[key] = value

    class MockExtractor():
        def __init__(self, info):
            self.info = info

    # Test with format containing %(..)s
    info = MockInfo()
    info['title'] = 'test - test2'
    downloader = MockDownloader()
    extractor = MockExtractor(info)

# Generated at 2022-06-22 09:30:04.333520
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, None).format_to_regex('') == ''
    assert MetadataFromTitlePP(None, None).format_to_regex('Foo') == 'Foo'
    assert (MetadataFromTitlePP(None, None).format_to_regex(
        'Foo%(bar)sBaz') == r'Foo(?P<bar>.+)Baz')
    assert (MetadataFromTitlePP(None, None).format_to_regex(
        'Foo%(bar)sBaz%(qux)s') == r'Foo(?P<bar>.+)Baz(?P<qux>.+)')



# Generated at 2022-06-22 09:30:14.807087
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import unittest

    class MetadataFromTitlePPTest(unittest.TestCase):
        def setUp(self):
            self.titleformat = '%(title)s - %(artist)s'
            self.downl = object()
            self.processor = MetadataFromTitlePP(self.downl, self.titleformat)

        def assertAttributes(self, attr, value):
            self.assertEqual(value, getattr(self.processor, '_' + attr))

        def test_attribute_titleformat_contains_percent_parentheses(self):
            self.titleformat = '%(title)s'
            self.assertRaises(AssertionError, MetadataFromTitlePP,
                              self.downl, self.titleformat)


# Generated at 2022-06-22 09:30:17.349022
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import inspect
    pp = sys.modules[__name__]
    assert inspect.ismethod(pp.MetadataFromTitlePP.run)


# Generated at 2022-06-22 09:30:24.472404
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.postprocessor.common import PostProcessor
    import copy
    import mock
    import sys


# Generated at 2022-06-22 09:30:31.472894
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert MetadataFromTitlePP.run(
        None,
        {'title': 'Simple test title'}) == ([], {'title': 'Simple test title'})
    assert MetadataFromTitlePP.run(
        None,
        {'title': 'Test title - with hyphen'}) == ([],
                                                   {'title': 'Test title - with hyphen'})
    assert MetadataFromTitlePP.run(
        None,
        {'title': 'Test title - with hyphen for real'}) == ([],
                                                            {'title': 'Test title - with hyphen for real'})
    assert MetadataFromTitlePP.run(
        None,
        {'title': 'Test title - with hyphen'}) == ([],
                                                   {'title': 'Test title - with hyphen'})
    assert Metadata

# Generated at 2022-06-22 09:30:35.016813
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, None).format_to_regex(
        '%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'



# Generated at 2022-06-22 09:30:46.534704
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    def check(fmt, regex):
        assert MetadataFromTitlePP(None, None).format_to_regex(fmt) == regex

    d = {'title': 'The Title', 'artist': 'A. N. Artist'}

# Generated at 2022-06-22 09:30:56.925155
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .downloader import Downloader
    from .compat import compat_str

    downloader = Downloader()
    title_format = '%(title)s - %(artist)s'
    test_title = 'Bad Example - Example Artist'
    mdftpp = MetadataFromTitlePP(downloader, title_format)
    assert mdftpp._titleformat == title_format
    assert mdftpp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    title = compat_str(test_title)
    match = re.match(mdftpp._titleregex, title)
    assert match is not None
    assert match.groupdict()['title'] == 'Bad Example'
    assert match.groupdict()['artist'] == 'Example Artist'