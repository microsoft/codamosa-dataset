

# Generated at 2022-06-22 09:21:08.336707
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    """Test method format_to_regex of class MetadataFromTitlePP"""
    input_fmt = '%(title)s - %(artist)s'
    expected_output_regex = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    from .postprocessor import MetadataFromTitlePP
    pp = MetadataFromTitlePP(None, input_fmt)
    assert pp.format_to_regex(input_fmt) == expected_output_regex

# Generated at 2022-06-22 09:21:14.524403
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Empty title
    MetadataFromTitlePP(None, '%(title)s - %(artist)s')

    # Missing element in title
    MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(lyrics)s')

    # Bad format
    MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(lyrics)s%')

    # Normal use
    MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(lyrics)s%%')


# Generated at 2022-06-22 09:21:26.577154
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # pylint: disable=unused-variable
    import test_utils
    from youtube_dl.extractor.generic import YoutubeIE
    ie = YoutubeIE()

    # pylint: disable=protected-access
    # test basic parsing
    mp = MetadataFromTitlePP(ie._downloader, '%(artist)s - %(title)s')
    assert mp.run({'id': 'a', 'title': 'foo - bar'}) == ([], {'artist': 'foo', 'title': 'bar', 'id': 'a'})

    # test custom metadatas
    mp = MetadataFromTitlePP(ie._downloader, '%(track)s - %(title)s')

# Generated at 2022-06-22 09:21:38.773706
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    tests = {
        # input: (output, variables)
        '': ('', []),
        'foobar': ('foobar', []),
        'foo%(bar)s%(baz)s': ('foo(?P<bar>.+)(?P<baz>.+)', ['bar', 'baz']),
        '%(foo)s_%(bar)s': ('(?P<foo>.+)_(?P<bar>.+)', ['foo', 'bar'])
    }

    for fmt, (expected, vars) in tests.items():
        p = MetadataFromTitlePP(None, fmt)
        assert p.format_to_regex(fmt) == expected
        assert p._variables == vars


# Generated at 2022-06-22 09:21:51.811002
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FakeYDL
    # Test for null video
    class TestYDL(FakeYDL):
        def __init__(self):
            super(TestYDL, self).__init__()
            self.info = dict()
        def to_screen(self, msg):
            pass
    ydl = TestYDL()
    mp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    assert mp.run(ydl.info)[1] == dict()

    # Test for video with title
    ydl.info = {'title': 'The Title'}
    assert mp.run(ydl.info)[1] == {'title': 'The Title'}

    # Test for video with title and metadata

# Generated at 2022-06-22 09:21:57.850199
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    titleformat = "foo, %(title)s, %(bar)s and again %(bar)s, %(artist)s"
    regex = MetadataFromTitlePP.format_to_regex(titleformat)
    assert regex == '(?P<title>.+), (?P<bar>.+), (?P<bar>.+) and again (?P<bar>.+), (?P<artist>.+)'

# Generated at 2022-06-22 09:22:04.115366
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    sample_titleformat = '%(title)s - %(artist)s'
    sample_titleregex = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    u = MetadataFromTitlePP(None, sample_titleformat)
    assert u._titleformat == sample_titleformat
    assert u._titleregex == sample_titleregex



# Generated at 2022-06-22 09:22:09.200778
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    downloader = None
    titleformat = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(downloader, titleformat)
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'



# Generated at 2022-06-22 09:22:18.954262
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .downloader import Downloader
    from .extractor.common import InfoExtractor
    from .youtube_dl.YoutubeDL import YoutubeDL

    downloader = Downloader(YoutubeDL({}))
    downloader.add_info_extractor(InfoExtractor(downloader))

    # Empty string
    assert MetadataFromTitlePP(downloader, '').format_to_regex('') == ''

    # String with no %(..)s
    assert MetadataFromTitlePP(downloader, 'abcdef').format_to_regex('abcdef') == 'abcdef'

    # String with 1 %(..)s
    assert MetadataFromTitlePP(downloader, '%(title)s').format_to_regex('%(title)s') == '(?P<title>.+)'

    # String with 2 %(

# Generated at 2022-06-22 09:22:30.282502
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-22 09:22:44.883106
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl.YoutubeDL import YoutubeDL
    from ytdl.extractor import common

    def fake_downloader_to_screen(message):
        print(message)

    def fake_download(self, url_list, params, **kargs):
        fake_download.filename = url_list[0]

    def fake_get_info(self, url):
        assert url == "http://example.com/video.mpg"
        info = {
            'id': '123456789',
            'title': "The %(title)s Title %(title_number)s",
            'playlist_index': '10',
            'url': url,
            'ext': 'mp4',
            'format': 'best',
            'format_id': None
        }

# Generated at 2022-06-22 09:22:56.001810
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # REs that match string depending on format
    formats = ['%(title)s',
               '%(title)s - %(artist)s',
               '%(title)s by %(artist)s'
               ]
    for format in formats:
        regex = MetadataFromTitlePP(None, format).format_to_regex(format)
        assert re.match(regex, format % {'title': 'foo', 'artist': 'bar'})

    # Invalid format
    try:
        MetadataFromTitlePP(None, '%(title)s').format_to_regex(format)
        assert False, 'Should not be reached'
    except re.error:
        pass

    # Format with unmatched closing parenthesis

# Generated at 2022-06-22 09:22:59.497494
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from ytdl.postprocessor import MetadataFromTitlePP

    mftpp = MetadataFromTitlePP(None, None)
    assert 'title.*artist' == mftpp.format_to_regex('%(title)s - %(artist)s')
    assert 'title.*artist' == mftpp.format_to_regex('%(title)s - [%(artist)s]')

# Generated at 2022-06-22 09:23:06.803963
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from YoutubeDL import YoutubeDL
    from pprint import pprint

    # test format without args
    pp = MetadataFromTitlePP(YoutubeDL(), 'bla')
    assert pp._titleregex == 'bla'

    #  test format with args
    pp = MetadataFromTitlePP(YoutubeDL(), '%(title)s - %(artist)s')
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'



# Generated at 2022-06-22 09:23:17.858378
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    mftPP = MetadataFromTitlePP(None, '%(title)s, %(artist)s, %(album)s')

    # handle example string okay
    input_dict = {'title': 'Metallica - Master Of Puppets, Live Earth, 2007-Jul-07'}
    _, output_dict = mftPP.run(input_dict)
    assert len(output_dict) == 4, 'unexpected dictionary length'
    assert output_dict['title'] == 'Metallica - Master Of Puppets'
    assert output_dict['artist'] == 'Live Earth'
    assert output_dict['album'] == '2007-Jul-07'

    # fail on missing bracket
    input_dict = {'title': 'The Big Bang Theory, 2x06, The Cooper-Hofstadter Polarization'}
    _, output

# Generated at 2022-06-22 09:23:28.809486
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, "%(artist)s, %(title)s")
    assert pp.format_to_regex("%(artist)s, %(title)s") == '(?P<artist>.+), (?P<title>.+)'
    assert pp.format_to_regex("%(title)s, %(ext)s") == '(?P<title>.+), (?P<ext>.+)'
    assert pp.format_to_regex("%(default)s %(title)s") == '%(default)s (?P<title>.+)'
    assert pp.format_to_regex("%(title)s") == '(?P<title>.+)'

# Generated at 2022-06-22 09:23:35.382165
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.YoutubeDL import YoutubeDL

    ydl = YoutubeDL()
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'



# Generated at 2022-06-22 09:23:46.444647
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from collections import namedtuple
    infodata = namedtuple('infodata', ['title'])
    MetadataFromTitle = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    info = infodata('This is a test - Test Artist')
    MetadataFromTitle.run(info)
    assert info.title == 'This is a test'
    assert info.artist == 'Test Artist'
    MetadataFromTitle.format_to_regex('%(title)s - %(artist)s')

    MetadataFromTitle = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    info = infodata('sony-musiq-malayalam-channel-title')
    MetadataFromTitle.run(info)

# Generated at 2022-06-22 09:23:52.633443
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    dl = DummyDownloader()
    pp = MetadataFromTitlePP(dl, '%(artist)s - %(title)s')
    info = {'title': 'Artist Name - Song Title'}
    assert pp.run(info) == ([], {'title': 'Artist Name - Song Title', 'artist': 'Artist Name', 'title_value': 'Song Title'})


# Generated at 2022-06-22 09:24:02.505116
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    """
    Make sure the constructor works as expected
    """
    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '(?P<title>.+)'

    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    pp = MetadataFromTitlePP(None, '%(title) (artist)')
    assert pp._titleformat == '%(title) (artist)'
    assert pp._titleregex == '%\(title\) \(artist\)'

# Unit

# Generated at 2022-06-22 09:24:13.900334
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    sys.modules['__main__'].to_screen = lambda s: None
    sys.modules['__main__'].params = lambda: None
    from .common import FileDownloader
    downloader = FileDownloader({})
    pp = MetadataFromTitlePP(downloader, "%(title)s - %(artist)s")
    info = {'title': 'Lilies of the Valley - David Lanz'}
    res, info = pp.run(info) # --> [], {'title': 'Lilies of the Valley', 'artist': 'David Lanz'}

# Generated at 2022-06-22 09:24:22.841173
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    test_cases = (
        ('%(title)s - %(artist)s',
         '(?P<title>.+)\ \-\ (?P<artist>.+)'),
        ('%(artist)s - %(title)s',
         '(?P<artist>.+)\ \-\ (?P<title>.+)'),
        ('%(artist)s / %(title)s',
         '(?P<artist>.+)\ \/\ (?P<title>.+)'),
    )
    for titleformat, regex in test_cases:
        pp = MetadataFromTitlePP(None, titleformat)
        assert pp._titleformat == titleformat
        assert pp._titleregex == regex

# Generated at 2022-06-22 09:24:34.197349
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, '').format_to_regex('') == ''
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s').format_to_regex(
        '%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s').format_to_regex(
        '%(title)s - %(title)s') == '(?P<title>.+)\ \-\ (?P<title>.+)'

# Generated at 2022-06-22 09:24:41.110540
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    downloader = None
    titleformat = '%(title)s'
    pp = MetadataFromTitlePP(downloader, titleformat)
    assert pp._titleformat == titleformat
    assert pp._titleregex == '(?P<title>.+)'


# Generated at 2022-06-22 09:24:50.814249
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    class DummyYDL(object):
        def to_screen(self, *args, **kargs):
            pass

    ydl = DummyYDL()
    info = {'title': 'Some unworkable title'}

    p = MetadataFromTitlePP(ydl, '%(foo)s - %(bar)s')
    r, i = p.run(info)
    assert info == i  # no changes to the title
    assert None is r  # no result

    info = {'title': 'T1 - T2'}
    p = MetadataFromTitlePP(ydl, '%(foo)s - %(bar)s')
    r, i = p.run(info)
    assert info == i  # no changes to the title
    assert None is r  # no result


# Generated at 2022-06-22 09:24:56.448754
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    testcases = [('%(title)s', '(?P<title>.+)'),
                 ('%(title)s - %(artist)s', '(?P<title>.+)\ \-\ (?P<artist>.+)')]
    for fmt, regex in testcases:
        assert MetadataFromTitlePP(None, fmt)._titleregex == regex

# Generated at 2022-06-22 09:25:06.820864
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)

    assert pp.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(artist)s - %(title)s - %(album)s') == '(?P<artist>.+)\ \-\ (?P<title>.+)\ \-\ (?P<album>.+)'
    assert pp.format_to_regex('%(random)s - %(title)s') == '(?P<random>.+)\ \-\ (?P<title>.+)'
    assert pp.format_to_re

# Generated at 2022-06-22 09:25:11.820662
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    titleformat = '%(artist)s - %(title)s'
    metadatafromtitlepp = MetadataFromTitlePP(None, titleformat)

    titleformat_e = '%\\(artist\\)s\\ \\-\\ %\\(title\\)s'
    assert metadatafromtitlepp._titleformat == titleformat
    assert metadatafromtitlepp._titleregex == titleformat_e


# Generated at 2022-06-22 09:25:18.671390
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """Tests MetadataFromTitlePP.run"""

    import youtube_dl
    from youtube_dl.YoutubeDL import YoutubeDL

    # Create a downloader and set its options
    ydl = YoutubeDL({'outtmpl': '%(id)s', 'writethumbnail': True,
                     'write_all_thumbnails': True, 'writesubtitles': True,
                     'writeautomaticsub': True, 'allsubtitles': True})
    # Create a downloader phase
    phase = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    # Run the phase
    phase.run(
        {'title': 'Amadeus - Mozart & Salieri', 'id': '1', 'format': 'best'})

# Generated at 2022-06-22 09:25:27.286450
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    info = {
        'title': 'How do you like this band - It is good, right?',
        'uploader': 'someone',
    }
    expected = {
        'title': 'How do you like this band',
        'uploader': 'someone',
        'band': 'It is good, right?',
    }
    titleformat = '%(title)s - %(band)s'
    downloader = object()  # not used
    pp = MetadataFromTitlePP(downloader, titleformat)
    result = pp.run(info)
    assert result == ([], expected)


# Generated at 2022-06-22 09:25:35.393119
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl.YoutubeDL import YoutubeDL
    from .extractor.common import SearchInfoExtractor
    from ytdl.PostProcessor import PostProcessingError
    # Simulate YoutubeDL object and SearchInfoExtractor object
    ydl = YoutubeDL(params={'simulate': True})
    ydl.report_warning = lambda *args, **kwargs: None
    ie = SearchInfoExtractor()
    ie._downloader = ydl
    # Simulate the info dict to be returned by the SearchInfoExtractor

# Generated at 2022-06-22 09:25:43.518098
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    p = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert p is not None
    assert '<MetadataFromTitlePP' in repr(p)
    assert p._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    p = MetadataFromTitlePP(None, '(?P<artist>.+) - (?P<title>.+)')
    assert p is not None
    assert '<MetadataFromTitlePP' in repr(p)
    assert p._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'


# Generated at 2022-06-22 09:25:53.238456
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    obj = MetadataFromTitlePP(None, '%(foo)s - %(bar)s')
    assert obj.format_to_regex('%(foo)s - %(bar)s') == r'(?P<foo>.+)\ \-\ (?P<bar>.+)'
    assert obj.format_to_regex('prefix - %(bar)s - %(foo)s - suffix') == r'prefix\ \-\ (?P<bar>.+)\ \-\ (?P<foo>.+)\ \-\ suffix'
    assert obj.format_to_regex('%(foo)s') == r'(?P<foo>.+)'

# Generated at 2022-06-22 09:26:05.741722
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftpp = MetadataFromTitlePP(None, None)

    result = mftpp.format_to_regex('%(title)s - %(artist)s')
    expected = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert result == expected, 'result != expected'

    result = mftpp.format_to_regex('%(title)s - %(artist)s - ')
    expected = '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ '
    assert result == expected, 'result != expected'

    result = mftpp.format_to_regex(' - %(title)s - %(artist)s')

# Generated at 2022-06-22 09:26:16.895801
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mp = MetadataFromTitlePP(None, 'asd%(title)s-%(artist)s')
    assert mp.format_to_regex('asd%(title)s-%(artist)s') == r'asd(?P<title>.+)\-(?P<artist>.+)'
    mp = MetadataFromTitlePP(None, "asd%(title)s'-'%(artist)s")
    assert mp.format_to_regex("asd%(title)s'-'%(artist)s") == r"asd(?P<title>.+)\-'\-(?P<artist>.+)"
    mp = MetadataFromTitlePP(None, r'%(title)s[%(artist)s]')

# Generated at 2022-06-22 09:26:22.481751
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # Returns a dictionary containing the tests
    return {
        '%(title)s - %(artist)s':
            r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    }


# Generated at 2022-06-22 09:26:32.752704
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftpp = MetadataFromTitlePP(None, "%(title)s - %(artist)s")
    # Test a simple use case
    assert mftpp.format_to_regex(mftpp._titleformat) == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    # Test empty string
    mftpp = MetadataFromTitlePP(None, "")
    assert mftpp.format_to_regex(mftpp._titleformat) == ""
    # Test null string
    mftpp = MetadataFromTitlePP(None, None)
    assert mftpp.format_to_regex(mftpp._titleformat) == ""
    # Test double %%
    mftpp = MetadataFromTitlePP(None, "%%")
    assert mftpp.format_to

# Generated at 2022-06-22 09:26:41.884815
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from_title = MetadataFromTitlePP(None, None)

    assert from_title.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert from_title.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert from_title.format_to_regex('%(title)s - %(artist)s - %(year)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<year>.+)'

# Generated at 2022-06-22 09:26:47.347754
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    fmt = '%(title)s - %(artist)s'
    regex = '(?P<title>.+)\\ -\\ (?P<artist>.+)'
    assert MetadataFromTitlePP.format_to_regex(fmt) == regex

# Generated at 2022-06-22 09:26:51.070667
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    fmt = r'%(title)s \ %(artist)s'
    regex = r'(?P<title>.+)\ \ (?P<artist>.+)'
    assert MetadataFromTitlePP('',fmt).format_to_regex(fmt) == regex

# Generated at 2022-06-22 09:27:01.751785
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ..YoutubeDL import YoutubeDL
    from .common import FileDownloader
    from .extractor import YoutubeIE

    class FakeInfoDict:
        pass

    titleformat = '%(title)s - %(artist)s'
    info = FakeInfoDict()
    info.title = 'test title - test artist'
    info.format = 'bestvideo+bestaudio'
    ie = YoutubeIE(YoutubeDL())
    pp = MetadataFromTitlePP(FileDownloader(YoutubeDL()), titleformat)
    res, info = pp.run(info)
    assert info.title == 'test title'
    assert info.artist == 'test artist'

# Generated at 2022-06-22 09:27:13.651510
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .compat import compat_str

    def check_results(pp, dl, title, expected_metadata, expected_final_title):
        info = dict(title=title)
        results, info = pp.run(info)

        assert results == [], "Unexpected results %r" % results
        assert info['title'] == expected_final_title, (
            "Unexpected final title %r" % info['title'])
        for name, value in expected_metadata.items():
            assert info[name] == value, (
                "Unexpected metadata '%s' value %r" % (name, info[name]))

    def run_tests():
        class MockDL(FileDownloader):
            def to_screen(self, msg):
                print(msg)

        dl = MockDL

# Generated at 2022-06-22 09:27:15.375509
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass

# Generated at 2022-06-22 09:27:26.225429
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '')

# Generated at 2022-06-22 09:27:37.283687
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp._titleformat == '%(artist)s - %(title)s'
    assert pp._titleregex == '(?P<artist>.+)\\ \\-\\ (?P<title>.+)'
    
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s [%(bitrate)s]')
    assert pp._titleformat == '%(artist)s - %(title)s [%(bitrate)s]'
    assert pp._titleregex == '(?P<artist>.+)\\ \\-\\ (?P<title>.+)\\ \\[(?P<bitrate>.+)\\]'


# Generated at 2022-06-22 09:27:42.069234
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s').format_to_regex(
        '%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-22 09:27:49.432878
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP.format_to_regex('%(artist)s') == '(?P<artist>.+)'
    assert (MetadataFromTitlePP.format_to_regex('%(artist)s - %(title)s') ==
            '(?P<artist>.+)\ \\-\ (?P<title>.+)')
    assert (MetadataFromTitlePP.format_to_regex('%(artist)s/%(title)s') ==
            '(?P<artist>.+)/(?P<title>.+)')

# Generated at 2022-06-22 09:27:55.922466
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    class Downloader:
        def to_screen(self, msg):
            pass

    downloader = Downloader()
    # Test regex and groupname extraction from  titleformat
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    assert pp._titleregex == '(?P<title>.+)\\ \-\\ (?P<artist>.+)'
    # Test regex and groupname extraction from  titleformat with numbers in groups
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist1)s')
    assert pp._titleregex == '(?P<title>.+)\\ \-\\ (?P<artist1>.+)'
    # Test regex and groupname extraction from  titleformat with non-word characters

# Generated at 2022-06-22 09:28:06.341331
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import os
    from .common import FileDownloader
    class FakeYDL(FileDownloader):
        def __init__(self, *kargs, **kwargs):
            self.to_screen_list = []
            FileDownloader.__init__(self, *kargs, **kwargs)

        def to_screen(self, msg):
            self.to_screen_list.append(msg)

    def test(titleformat, title, expected_info):
        if not expected_info:
            sys.exit('Test failed: wrong video title "%s" for format "%s"'
                     % (title, titleformat))
        tmp_file = 'metadata_from_title_pp_test_file'
        if os.path.exists(tmp_file):
            os.remove(tmp_file)

# Generated at 2022-06-22 09:28:17.352657
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    test_MetadataFromTitlePP = MetadataFromTitlePP(
        None, '%(title)s - %(artist)s')
    fmt = test_MetadataFromTitlePP.format_to_regex('%(title)s - %(artist)s')
    match = re.match(fmt, 'title - artist')
    assert match.group('title') == 'title'
    assert match.group('artist') == 'artist'
    fmt = test_MetadataFromTitlePP.format_to_regex(
        '%(artist)s - %(title)s - ABC')
    match = re.match(fmt, 'artist - title - ABC')
    assert match.group('title') == 'title'
    assert match.group('artist') == 'artist'

# Generated at 2022-06-22 09:28:30.785528
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    video_info = {
        'title': 'My video - This is a title.'
    }

    class Downloader(object):
        def to_screen(self, arg):
            pass

    class PP(MetadataFromTitlePP):
        def __init__(self, titleformat):
            super(PP, self).__init__(Downloader(), titleformat)

    pp = PP('%(title)s - %(artist)s')
    return pp.run(video_info)



# Generated at 2022-06-22 09:28:41.232083
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys

    class FakeInfo(dict):
        def __init__(self, title):
            super(FakeInfo, self).__init__()
            self['title'] = title

    class FakeDownloader(object):
        def __init__(self):
            self.output = []
            self.info = None

        def to_screen(self, msg):
            self.output.append(msg)

    def do_test(title, format, expected):
        downloader = FakeDownloader()
        metadata_from_title = MetadataFromTitlePP(downloader, format)
        downloader.info = FakeInfo(title)
        metadata_from_title.run(downloader.info)

# Generated at 2022-06-22 09:28:48.722043
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """Checks that method run works as expected"""
    import ydl_opts

    # Create instance of MetadataFromTitlePP class
    metadata_from_title_pp = MetadataFromTitlePP(ydl_opts, '%(title)s')

    # Create an object representing the results of an extraction
    # We use the following values:
    #   'id': 'abcdef',
    #   'title': 'Bomfunk MC&apos;s - Freestyler',
    #   'duration': 3.0,
    #   '_filename': 'Bomfunk MC&apos;s - Freestyler.webm',
    #   'ext': 'webm'

# Generated at 2022-06-22 09:28:59.360534
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(album)s')
    assert pp.format_to_regex(pp._titleformat) == pp._titleregex

    # Matching title
    info = {
        'title': 'Sample Title - Sampler Artist - Sampler Album',
    }
    pp.run(info)
    assert info['title'] == 'Sample Title'
    assert info['artist'] == 'Sampler Artist'
    assert info['album'] == 'Sampler Album'

    # Non-matching title
    info = {
        'title': 'Sample Title',
    }
    pp.run(info)
    assert info['title'] == 'Sample Title'
    assert 'artist' not in info
    assert 'album' not in info

# Generated at 2022-06-22 09:29:05.100263
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # input
    fmt = "%(title)s - %(artist)s"

    # expected output
    regex = "(?P<title>.+)\ \-\ (?P<artist>.+)"

    # get output
    pp = MetadataFromTitlePP(None, fmt)
    actual_regex = pp.format_to_regex(fmt)

    # assert
    assert actual_regex == regex


# Generated at 2022-06-22 09:29:15.400077
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import mock
    downloader, info = mock.MagicMock(), mock.MagicMock()
    downloader.to_screen.side_effect = (lambda x: x)
    downloader.to_stderr.side_effect = (lambda x: x)
    titleformat = '%(artist)s - %(title)s'
    titleregex = '(?P<artist>.+)\ \-\ (?P<title>.+)'

# Generated at 2022-06-22 09:29:18.204371
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s')._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-22 09:29:25.931883
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import re
    from .common import FileDownloader
    from .compat import compat_urllib_request as urllib_request
    from .extractor import gen_extractors
    from .postprocessor import FFmpegMetadataPP

    downloader = FileDownloader()
    downloader.params.update({
        'logger': downloader.stdout_display,
        'nooverwrites': True,
        'quiet': True,
    })
    # fake urlopen
    def fake_urlopen(request):
        return urllib_request.urlopen(request)
    downloader.urlopen = fake_urlopen
    # fake gen_extractor
    def fake_gen_extractor(info_dict):
        class X:
            def __init__(self, downloader):
                self.downloader = downloader

# Generated at 2022-06-22 09:29:33.011537
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    titleformat = '%(title)s %(episode)s'
    titleformat = MetadataFromTitlePP._format_to_regex(titleformat)
    # Test 1: titleformat corresponds to title
    title = 'MyVideo Title 3'
    match = re.match(titleformat, title)
    assert match is not None
    assert match.groupdict().get('title') == 'MyVideo Title'
    assert match.groupdict().get('episode') == '3'
    # Test 2: titleformat doesn't correspond to title
    title = 'MyVideo'
    match = re.match(titleformat, title)
    assert match is None

# Generated at 2022-06-22 09:29:43.813197
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP('youtube-dl', '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    # Test titleformat contains no %(..)s
    pp = MetadataFromTitlePP('youtube-dl', 'test_title')
    assert pp._titleformat == 'test_title'
    assert pp._titleregex == 'test_title'

    # Test titleformat contains %%s
    pp = MetadataFromTitlePP('youtube-dl', '%%s - %(title)s')
    assert pp._titleregex == '[%]s\ \-\ (?P<title>.+)'

    # Test titleformat contains %

# Generated at 2022-06-22 09:30:04.188175
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    tests = [
        ['%(title)s - %(artist)s', '(?P<title>.+)\ \-\ (?P<artist>.+)'],
        ['abc', 'abc'],
        ['%(title)s', '(?P<title>.+)'],
        ['%(title)s - %(artist)s - %%(album)s', r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'],

    ]
    for test in tests:
        assert MetadataFromTitlePP(None, test[0])._titleregex == test[1]


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 09:30:14.698683
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    import pytest

    assert (MetadataFromTitlePP(None, '%(title)s - %(artist)s')._titleregex
            == '(?P<title>.+)\ \-\ (?P<artist>.+)')
    assert (MetadataFromTitlePP(None, '%(title)s')._titleregex
            == '(?P<title>.+)')
    assert (MetadataFromTitlePP(None, '%(title)s %(artist)s')._titleregex
            == '(?P<title>.+)\ (?P<artist>.+)')
    assert (MetadataFromTitlePP(None, '%(title)s %(artist)s %(album)s')._titleregex
            == '(?P<title>.+)\ (?P<artist>.+)\ (?P<album>.+)')


# Generated at 2022-06-22 09:30:22.444851
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Test with a regular expression containing no %(...s)s parts
    titleregex = "^\[by\ [^\]]*\]\ (?P<title>.+)$"
    titleformat = titleregex
    metadatafromtitlepp = MetadataFromTitlePP(None, titleformat)
    assert metadatafromtitlepp._titleformat == titleformat
    assert metadatafromtitlepp._titleregex == titleregex

    # Test with a regular expression containing %(...s)s parts
    titleformat = "%(title)s - %(artist)s - %(album)s"

# Generated at 2022-06-22 09:30:29.530399
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-22 09:30:33.059360
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert (MetadataFromTitlePP.format_to_regex(r'%(title)s - %(artist)s')
            == r'(?P<title>.+)\ \-\ (?P<artist>.+)')


# Generated at 2022-06-22 09:30:44.660894
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .. import YoutubeDL
    ydl = YoutubeDL()
    ydl.add_default_info_extractors()

    def test(titleformat, title, expected_info):
        pp = MetadataFromTitlePP(ydl, titleformat)
        info = {'title': title}
        pp.run(info)
        assert info == expected_info

    test('%(title)s', 'foo', {'title': 'foo'})
    test('foo%(title)sbar', 'baz', {'title': 'baz'})
    test('%(title)s', 'foo - bar', {'title': 'foo - bar'})
    test('%(title)s - %(artist)s', 'foo - bar', {'title': 'foo', 'artist': 'bar'})

# Generated at 2022-06-22 09:30:55.684011
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl
    import json

    # Print json representation of all provided arguments see _runactual