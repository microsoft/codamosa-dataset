

# Generated at 2022-06-22 09:21:11.497919
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    import unittest
    import sys
    import tempfile
    import shutil
    from ytdl.utils import DateRange
    from ytdl.YoutubeDL import YoutubeDL

    downloaded = {'title': '', 'duration': 1, 'upload_date': DateRange.max}
    metadatafield = {'title': '', 'creator': '', 'album': ''}

    titleformat = ''
    infofield = {}

    class DummyYDL:
        def to_screen(self, msg):
            print(msg)
            pass

        def to_stderr(self, msg):
            print(msg)
            pass

    class DummyPostProcessor:
        def __init__(self, downloader):
            pass

        def run(self, infos):
            return infos, {}


# Generated at 2022-06-22 09:21:22.155375
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    # Import unittest TestCase class to test method run of class MetadataFromTitlePP
    from sys import version_info
    if version_info < (3,4,0):
        from unittest2 import TestCase
    else:
        from unittest import TestCase

    class MetadataFromTitlePP_run_TestCase(TestCase):
        class FakeInfo():
            def __init__(self):
                self['title'] = "test title"
        class FakeDownloader():
            def __init__(self):
                self.to_screen_message = None

            def to_screen(self, message):
                self.to_screen_message = message

        # Test case to check if method run of class MetadataFromTitlePP
        # parse title when title contains %(key)s attribute,
        # and key is any word beginning with

# Generated at 2022-06-22 09:21:31.401572
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    p = MetadataFromTitlePP(None, None)
    assert (p.format_to_regex('%(title)s - %(artist)s') ==
            r'(?P<title>.+)\ \-\ (?P<artist>.+)')

# Generated at 2022-06-22 09:21:41.484376
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    Tests method run of class MetadataFromTitlePP
    """
    # Path to python script to call
    test_script_filepath = os.path.abspath(
        os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'youtube_dl_test.py')
    )
    # Path to save test result to
    test_result_filepath = os.path.join(
        tempfile.gettempdir(),
        'youtube_dl_test_result_%s.json' % (str(uuid.uuid4()))
    )
    # Video url to test
    test_video_url = 'https://www.youtube.com/watch?v=i_lcmYlzNIk'
    # Run test and save result to file
   

# Generated at 2022-06-22 09:21:49.509735
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Test with extended titleformat
    titleformat = '%(title)s - %(artist)s'
    mp = MetadataFromTitlePP(None, titleformat)
    assert mp.format_to_regex(titleformat) == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    # Test with simple titleformat
    titleformat = 'Vevo - Hot This Week'
    mp = MetadataFromTitlePP(None, titleformat)
    assert mp.format_to_regex(titleformat) == titleformat

# Generated at 2022-06-22 09:21:53.021863
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    fmt_regex_pairs = [
        ('%(title)s - %(artist)s', r'(?P<title>.+)\ \-\ (?P<artist>.+)')
    ]
    for fmt, regex in fmt_regex_pairs:
        assert pp.format_to_regex(fmt) == regex

# Generated at 2022-06-22 09:22:04.610524
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl
    def _sanity_check_info(info):
        assert('title' in info)
        assert('artist' in info)
        assert('album' in info)
        assert('track' in info)
        assert('tracknumber' in info)
    ydl_opts = {
        'metadatafromtitle': '%(artist)s - %(track)s - %(title)s',
    }
    def _test_MetadataFromTitlePP_run(test_info, expected_info):
        pp = MetadataFromTitlePP(youtube_dl.YoutubeDL(ydl_opts),
                                 ydl_opts['metadatafromtitle'])
        pp.run(test_info)
        _sanity_check_info(test_info)
        assert(test_info == expected_info)


# Generated at 2022-06-22 09:22:13.565734
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # simplest case
    fmt = '%(title)s'
    regex = '(?P<title>.+)'
    assert MetadataFromTitlePP(None, fmt).format_to_regex(fmt) == regex

    # two fields
    fmt = '%(title)s - %(artist)s'
    regex = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, fmt).format_to_regex(fmt) == regex

    # fields with other characters
    fmt = '%(title)s - %(artist)s - %(album)s'
    regex = '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'

# Generated at 2022-06-22 09:22:24.120269
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    p = MetadataFromTitlePP(None, '%(key1)s - %(key2)s')
    assert p.format_to_regex('%(key1)s - %(key2)s') == r'(?P<key1>.+)\ \-\ (?P<key2>.+)'

    p = MetadataFromTitlePP(None, '%(key1)s - %(key2)s - %(key3)s')
    assert p.format_to_regex('%(key1)s - %(key2)s - %(key3)s') == r'(?P<key1>.+)\ \-\ (?P<key2>.+)\ \-\ (?P<key3>.+)'


# Generated at 2022-06-22 09:22:35.119600
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    m = MetadataFromTitlePP(None, None)
    assert m.format_to_regex('%(a)s') == r'(?P<a>.+)'
    assert m.format_to_regex('%(a)s - %(b)s') == r'(?P<a>.+)\ \-\ (?P<b>.+)'
    assert m.format_to_regex('%(a)s - %(b)s - %(c)s') == r'(?P<a>.+)\ \-\ (?P<b>.+)\ \-\ (?P<c>.+)'

# Generated at 2022-06-22 09:22:49.881871
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    Tests method run() of class MetadataFromTitlePP
    """
    import youtube_dl.YoutubeDL
    from six import StringIO
    dl = youtube_dl.YoutubeDL(dict(writethumbnail=False,
                                   writeautomaticsub=False,
                                   outtmpl='NA'))
    dl.params['logger'] = dl.to_stdout = StringIO()
    in_info = dict(title='What are the odds?')
    out_info = MetadataFromTitlePP(dl, '%(title)s').run(in_info)[1]
    assert out_info['title'] == 'What are the odds?'
    assert dl.to_stdout.getvalue() == '[fromtitle] parsed title: What are the odds?\n'
    dl.to_stdout

# Generated at 2022-06-22 09:22:58.617620
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .common import FakeDownloader
    from .compat import str

    class MockYDL:
        def to_screen(self, message):
            pass

    class MockIE:
        def __init__(self, ie_dict, ie_key, ie_name):
            pass

        def download(self, **kwargs):
            pass

    ie = MockIE({}, {}, 'mock_ie')
    ie_result = ie.download()
    ydl = MockYDL()
    dl = FakeDownloader(ydl, ie_result)
    metadata_dict = []

    metadata = MetadataFromTitlePP(dl, '%(title)s - %(artist)s')

    # invalid titleformat
    metadata._titleformat = 'foo'
    metadata._titleregex = 'foo'

# Generated at 2022-06-22 09:23:09.191445
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mft = MetadataFromTitlePP(None, '%(title)s')
    assert(mft.format_to_regex('%(title)s') == r'(?P<title>.+)')
    assert(mft.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)')
    assert(mft.format_to_regex('%(title)s - %(artist)s - %(album)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)')

# Generated at 2022-06-22 09:23:13.548663
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, r'%(artist)s - %(title)s')

    assert pp._titleformat == r'%(artist)s - %(title)s'
    assert pp._titleregex == r'(?P<artist>.+)\ \-\ (?P<title>.+)'


# Generated at 2022-06-22 09:23:25.371295
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import PostProcessor

    pp = PostProcessor('dummy')
    processor = MetadataFromTitlePP(pp, '')
    assert processor.format_to_regex(
        '%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert processor.format_to_regex(
        '%(title)s') == r'(?P<title>.+)'
    assert processor.format_to_regex(
        '%(title)s.%(ext)s') == r'(?P<title>.+)\.(?P<ext>.+)'

# Generated at 2022-06-22 09:23:34.113258
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    mftpp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    if mftpp._titleformat != '%(title)s - %(artist)s':
        raise AssertionError('Title format is incorrect: ' + mftpp._titleformat)
    if mftpp._titleregex != '(?P<title>.+)\ \-\ (?P<artist>.+)':
        raise AssertionError('Regex format is incorrect: ' + mftpp._titleregex)



# Generated at 2022-06-22 09:23:38.730089
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    filename = '%(title)s-%(artist)s.mp3'
    pp = MetadataFromTitlePP(None, filename)
    assert pp._titleformat == filename
    assert pp._titleregex == '(?P<title>.+)\-(?P<artist>.+)\.mp3'


# Generated at 2022-06-22 09:23:49.940819
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    info = {'title': 'I am a Title'}
    pp = MetadataFromTitlePP('', '%(title)s')
    assert pp.run(info) == ([], {'title': 'I am a Title'})
    # Test format with keywords
    info = {'title': 'I am a Title'}
    pp = MetadataFromTitlePP('', '%(title)s')
    assert pp.run(info) == ([], {'title': 'I am a Title'})
    # Test format without keywords
    info = {'title': 'I am a Title'}
    pp = MetadataFromTitlePP('', 'I am a Title')
    assert pp.run(info) == ([], {'title': 'I am a Title'})
    # Test format with unused keywords

# Generated at 2022-06-22 09:24:00.857840
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    tftpp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert tftpp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    tftpp = MetadataFromTitlePP(None, '%(title)s [%(artist)s]')
    assert tftpp._titleregex == r'(?P<title>.+)\ \[(?P<artist>.+)\]'

    tftpp = MetadataFromTitlePP(None, '%(title)s')
    assert tftpp._titleregex == '%(title)s'

    tftpp = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(uploader)s')
    assert tftpp._title

# Generated at 2022-06-22 09:24:08.782046
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    def run_test(titleformat, title, expected_regex, expected_info):
        log = []
        downloader = DummyYDL({})
        pp = MetadataFromTitlePP(downloader, titleformat)
        info = {'title': title}
        results = pp.run(info)
        assert pp._titleformat == titleformat
        assert pp._titleregex == expected_regex
        if expected_info is None:
            assert info == {'title': title}
        else:
            assert info == expected_info
        return log

    def p(s):
        return s.replace('(', '\(').replace(')', '\)')

    class DummyYDL(object):
        def __init__(self, opts):
            self.opts = opts


# Generated at 2022-06-22 09:24:22.701383
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    downloader = object()
    pp = MetadataFromTitlePP(downloader, '%(artist)s - %(title)s')
    assert pp._titleformat == '%(artist)s - %(title)s'
    assert pp._titleregex == r'(?P<artist>.+)\ \-\ (?P<title>.+)'
    pp = MetadataFromTitlePP(downloader, '(?P<artist>[^-]+) - (?P<title>.+)')
    assert pp._titleformat == '(?P<artist>[^-]+) - (?P<title>.+)'
    assert pp._titleregex == r'(?P<artist>[^-]+) - (?P<title>.+)'

# Generated at 2022-06-22 09:24:34.192979
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    from .common import FileDownloader
    from .extractor import gen_extractors

    def extractor_get(url):
        class FakeInfoExtractor:
            def __init__(self):
                self.IE_NAME = 'fakeie'
                self.ie = self
                self.sub_langs = {}
                self.supported_languages = []
                self.lang_list = []
                self.info = {'id': 'test', 'title': 'TestTitle1 - initial title'}

        return FakeInfoExtractor()


# Generated at 2022-06-22 09:24:42.097319
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    titleformat = '%(title)s - %(artist)s'
    metadatafromtitlepp = MetadataFromTitlePP(None, titleformat)
    regex = metadatafromtitlepp.format_to_regex(titleformat)
    assert regex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-22 09:24:51.412509
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-22 09:25:02.666448
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    titleformat = '%(title)s--%(source)s--%(source_url)s'
    titlepattern = '%(title)s--(?P<source>.+)--(?P<source_url>.+)'
    titleformat_regex = '%(title)s--%(source)s--%(source_url).+'
    titlepattern_regex = '%(title)s--(?P<source>.+)--(?P<source_url).+'

    # Title format pattern
    titleformat_re = MetadataFromTitlePP(None, titleformat)._titleregex
    assert titleformat_re == titlepattern, (
        '%r != %r' % (titleformat_re, titlepattern))

    # Title format regex

# Generated at 2022-06-22 09:25:12.144733
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftpp = MetadataFromTitlePP(None, '')
    assert mftpp.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert mftpp.format_to_regex('%(title)s %(artist)s') == r'(?P<title>.+)\ (?P<artist>.+)'
    assert mftpp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert mftpp.format_to_regex('%(title)s') == mftpp.format_to_regex('%(title)s ')
    assert mftpp.format_to_regex(' %(title)s') != m

# Generated at 2022-06-22 09:25:20.036937
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s')._titleformat == '%(title)s - %(artist)s'
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s')._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, 'foo')._titleformat == 'foo'
    assert MetadataFromTitlePP(None, 'foo')._titleregex == 'foo'


# Generated at 2022-06-22 09:25:26.683321
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import tempfile
    downloader = object()
    titleformat = '%(title)s - %(artist)s - %(album)s'
    title = 'abc - df - ff'
    info = { 'title': title }
    pp = MetadataFromTitlePP(downloader, titleformat)
    pp.run(info)
    
    assert info.get('title') == title
    assert info.get('artist') == 'df'
    assert info.get('album') == 'ff'

# Generated at 2022-06-22 09:25:35.704891
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # test for non-regex
    assert (MetadataFromTitlePP(None, 'abc - %(artist)s')
            ._titleregex == 'abc\ \-\ (?P<artist>.+)')

    # test for regex
    assert (MetadataFromTitlePP(None, 'abc - (?P<artist>.+)')
            ._titleregex == 'abc\ \-\ (?P<artist>.+)')

    # test for regex with escaped "%" character
    assert (MetadataFromTitlePP(None, 'abc - %(percentage)s \%')
            ._titleregex == r'abc\ \-\ (?P<percentage>.+)\ \%')

    # test for regex with escaped "(" character

# Generated at 2022-06-22 09:25:41.415304
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    mp = MetadataFromTitlePP(None, '-%(title)s-')
    assert mp._titleformat == '-%(title)s-'
    assert mp._titleregex == r'\-\(?P<title>.+\)s\-'

    mp = MetadataFromTitlePP(None, 'my-%(title)s-%(id)s')
    assert mp._titleformat == 'my-%(title)s-%(id)s'
    assert mp._titleregex == r'my\-\(?P<title>.+\)s\-\(?P<id>.+\)s'

    mp = MetadataFromTitlePP(None, 'my-%(title)s')
    assert mp._titleformat == 'my-%(title)s'

# Generated at 2022-06-22 09:25:51.344463
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    def test_case(title, expected_regex):
        pp = MetadataFromTitlePP(None, title)
        assert pp._titleformat == title
        assert pp._titleregex == expected_regex

    # Test with a title format with all attributes
    test_case(
        '%(title)s - %(artist)s',
        r'(?P<title>.+)\ \-\ (?P<artist>.+)')

    # Test with a title format with no attributes
    test_case(
        'Foo - Bar',
        r'Foo\ \-\ Bar')

    # Test with a title format with more than one of the same attribute
    # such as %(title)s - %(artist)s and %(artist)s - %(title)s

# Generated at 2022-06-22 09:25:59.207359
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest

    class FakeInfo(object):
        def __init__(self, title):
            self._title = title

        def __setitem__(self, key, value):
            self.__dict__[key] = value

        def __getitem__(self, key):
            return self.__dict__[key]

    class FakeYoutubeDL(object):
        def to_screen(self, msg):
            print(msg)

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.info = FakeInfo('A - Stupid - Title')
            self.ydl = FakeYoutubeDL()
            self.pp = MetadataFromTitlePP(self.ydl,
                '%(first)s - %(second)s - %(last)s')

       

# Generated at 2022-06-22 09:26:07.770807
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    class FakeDl(object):
        def __init__(self, test):
            self.test = test

        def to_screen(self, msg):
            # print msg
            pass

    for titleformat, title, expect_regex in [
            ('%(title)s - %(artist)s', 'Title - Artist',
             r'(?P<title>.+)\ \-\ (?P<artist>.+)'),
            ('%(title)s - %(artist)s', 'Title - Artist - something',
             r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ something')
        ]:

        p = MetadataFromTitlePP(
            FakeDl(None), titleformat)

        regex = p.format_to_regex(titleformat)
        assert regex == expect

# Generated at 2022-06-22 09:26:17.346449
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    dl_obj = YoutubeDL()
    dl_obj.add_default_info_extractors()

    pp_obj = MetadataFromTitlePP(dl_obj,
        '%(artist)s - %(track)s - %(title)s - %(album)s')
    pp_obj.run({'tracknumber': '10', 'track':'10',
        'title': 'test title', 'track_total': '12'})
    assert pp_obj._titleregex == r'(?P<artist>.+)\ \-\ (?P<track>.+)\ \-\ (?P<title>.+)\ \-\ (?P<album>.+)'


# Generated at 2022-06-22 09:26:27.501703
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    manager = None
    class TestMetadataFromTitlePP(MetadataFromTitlePP):
        @property
        def to_screen(obj):
            return obj._to_screen
        @to_screen.setter
        def to_screen(obj, value):
            obj._to_screen = value

    def test_to_screen(text):
        assert text == '[fromtitle] parsed title: The Title'
    metadata = {'title': 'The Title'}
    test_object = TestMetadataFromTitlePP(manager, '%(title)s')
    test_object._to_screen = test_to_screen
    results = test_object.run(metadata)
    assert results == ([], {'title': 'The Title'})

# Generated at 2022-06-22 09:26:38.535547
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    m = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert m._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    m = MetadataFromTitlePP(None, '%%%(title)s - %(artist)s%%')
    assert m._titleregex == r'%(?P<title>.+)\ \-\ (?P<artist>.+)%'
    m = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert m._titleregex == r'(?P<artist>.+)\ \-\ (?P<title>.+)'
    m = MetadataFromTitlePP(None, '%(artist)s - %(title)s - %(year)s')

# Generated at 2022-06-22 09:26:42.649727
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-22 09:26:53.450905
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import FileDownloader
    dl = FileDownloader(params={})
    pp = MetadataFromTitlePP(dl, '%(title)s - %(artist)s')
    assert pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s - %(album)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'

# Generated at 2022-06-22 09:27:02.882317
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # empty format
    assert MetadataFromTitlePP(None, '').format_to_regex('') == ''

    # no placeholders
    assert MetadataFromTitlePP(None, 'abc').format_to_regex('abc') == 'abc'

    # single placeholder
    assert ((MetadataFromTitlePP(None, '%(title)s').format_to_regex('%(title)s'))
            == '(?P<title>.+)')

    # multiple placeholders
    assert ((MetadataFromTitlePP(None, '%(title)s - %(artist)s')
             .format_to_regex('%(title)s - %(artist)s'))
            == '(?P<title>.+)\ \-\ (?P<artist>.+)')

    # multiple placeholders with escaping

# Generated at 2022-06-22 09:27:14.560707
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl
    # Test for only one group "%(title)s"
    pp = MetadataFromTitlePP(youtube_dl.YoutubeDL({}), '%(title)s')

    info = {
        'title' : 'Attila - Number 10',
    }
    # The expected output for MetadataFromTitlePP:
    # [fromtitle] parsed title: Attila - Number 10
    expected_out = []
    expected_info = {
        'title' : 'Attila - Number 10',
        'title' : 'Attila - Number 10'
    }
    assert (pp.run(info) == (expected_out, expected_info))

    # Test for two groups "%(artist)s-%(title)s"

# Generated at 2022-06-22 09:27:22.670075
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import unittest

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            import youtube_dl

            class MockYDL(object):
                def to_screen(self, msg):
                    print(msg)

            self.ydl = MockYDL()
            self.pp = MetadataFromTitlePP(self.ydl,
                                          '%(playlist_index)s - %(title)s')

        def test_format_to_regex(self):
            self.assertEqual(self.pp.format_to_regex(
                '%(playlist_index)s - %(title)s'),
                '(?P<playlist_index>.+)\ \-\ (?P<title>.+)')

    unittest.main()



# Generated at 2022-06-22 09:27:34.664583
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .common import FileDownloader
    from .options import Options
    ydl_opts = {
        'writedescription': True,
        'writeinfojson': True,
        'writethumbnail': True,
        'writeautomaticsub': True,
        'writeannotations': True,
        'write_all_thumbnails': True,
        'writesubtitles': True,
        'write_all_subs': True,
    }
    ydl = FileDownloader(ydl_opts)
    info = {
        'title': 'TITLE - ARTIST',
        'description': 'DESCRIPTION',
        'artist': 'ARTIST',
        'track': 'TRACK',
        'id': 'ID',
        'playlist': 'PLAYLIST',
    }


# Generated at 2022-06-22 09:27:42.510355
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-22 09:27:49.475797
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftpp = MetadataFromTitlePP(None, None)
    assert(mftpp.format_to_regex('(?P<title>.+)') == '(?P<title>.+)')
    assert(mftpp.format_to_regex('%(title)s') == '(?P<title>.+)')
    assert(mftpp.format_to_regex('%(title)s - %(artist)s')
           == '(?P<title>.+)\ \-\ (?P<artist>.+)')

# Generated at 2022-06-22 09:27:55.921380
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    fmt = '%(title)s - %(artist)s'
    regex = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    p = MetadataFromTitlePP(None, fmt)
    assert p.format_to_regex(fmt) == regex

    fmt = '%(title)s %(artist)s other stuff'
    regex = '(?P<title>.+)\ (?P<artist>.+)\ other\ stuff'
    p = MetadataFromTitlePP(None, fmt)
    assert p.format_to_regex(fmt) == regex

    fmt = 'only %(title)s'
    regex = 'only\ (?P<title>.+)'
    p = MetadataFromTitlePP(None, fmt)
    assert p.format_to_regex(fmt)

# Generated at 2022-06-22 09:28:06.340352
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .youtube_dl.extractor.youtube import YoutubeIE
    from .youtube_dl.utils import sanitize_filename
    from .youtube_dl.YoutubeDL import YoutubeDL
    from .youtube_dl.compat import compat_str

    class FakeInfo(dict):
        def __init__(self, d):
            super(FakeInfo, self).__init__(**d)

        def __getitem__(self, key):
            return super(FakeInfo, self).__getitem__(compat_str(key))

    class FakeYDL(YoutubeDL):
        def __init__(self, yie):
            super(FakeYDL, self).__init__()
            self._ies = [yie]

        def to_screen(self, msg):
            pass


# Generated at 2022-06-22 09:28:17.817251
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    assert pp.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(artist)s - %(title)s') == r'(?P<artist>.+)\ \-\ (?P<title>.+)'
    assert pp.format_to_regex('(%(artist)s - %(title)s)') == r'\(\(?P<artist>.+\)\\\ \-\\\ \(?P<title>.+\)\)'
    assert pp.format_to_re

# Generated at 2022-06-22 09:28:24.926593
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import FileDownloader
    pp = MetadataFromTitlePP(FileDownloader({}), '')
    assert pp.format_to_regex('no conversions') == 'no conversions'
    assert pp.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

#

# Generated at 2022-06-22 09:28:31.612482
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    ydl = object()

    MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')

    MetadataFromTitlePP(ydl, '%(artist)s - %(title)s')

    MetadataFromTitlePP(ydl, '%(artist)s')

    MetadataFromTitlePP(ydl, '%(artist)s - %(title)s - %(month)s')


# Generated at 2022-06-22 09:28:41.629374
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP('dummy', '%(asdf)s/%(fdsa)s')
    assert pp._titleregex == r'(?P<asdf>.+)/(?P<fdsa>.+)'
    pp = MetadataFromTitlePP('dummy', '%(asdf)s/%(fdsa)s/%(qwerty)s')
    assert pp._titleregex == r'(?P<asdf>.+)/(?P<fdsa>.+)/%\(qwerty\)s'
    pp = MetadataFromTitlePP('dummy', '%(asdf)s/%(fdsa)s/%(qwerty)s-hahaha')

# Generated at 2022-06-22 09:28:54.672395
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    import unittest
    unittest.test('test_' + MetadataFromTitlePP('', '').format_to_regex.__name__, MetadataFromTitlePP('', ''))



# Generated at 2022-06-22 09:29:04.778996
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    from .common import FakeYDL
    from .xattrpp import XAttrMetadataPP

    # Test with simple titleformat '%(artist)s - %(title)s'
    titleformat = '%(artist)s - %(title)s'
    title = 'Paul Kalkbrenner - Sky and Sand'

    downloader = FakeYDL()
    metadata_pp = XAttrMetadataPP(downloader)
    fromtitle_pp = MetadataFromTitlePP(downloader, titleformat)
    original_info = {'title': title}

    # run metadata_pp to prepare metadata_filename
    dummy = metadata_pp.run(original_info)
    metadata_filename = original_info['fulltitle'] + u'.info.json'

    # run fromtitle_pp to extract metadata from title
    new

# Generated at 2022-06-22 09:29:14.853749
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftpp = MetadataFromTitlePP(None, None)
    assert mftpp.format_to_regex('a b c') == r'a\ b\ c'
    assert mftpp.format_to_regex('a %(b)s c') == r'a\ (?P<b>.+)\ c'
    assert mftpp.format_to_regex('a %(b)s c %(d)s') == r'a\ (?P<b>.+)\ c\ (?P<d>.+)'
    assert mftpp.format_to_regex(r'a %(b)s c %(d)s \(e\)') == r'a\ (?P<b>.+)\ c\ (?P<d>.+)\ \(e\)'

# Generated at 2022-06-22 09:29:20.769580
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp.run({'title': 'Test 1 - Test 2'}) == ([], {'artist': 'Test 1', 'title': 'Test 2'})
    assert pp.run({'title': 'Test 1 - Test 2 - Test 3'}) == ([], {'artist': 'Test 1 - Test 2', 'title': 'Test 3'})
    assert pp.run({'title': 'Test 1'}) == ([], {})

# Generated at 2022-06-22 09:29:28.094426
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pp = MetadataFromTitlePP(None, titleformat='%(title)s - (%(artist)s)')
    title = 'Test title - (Test artist)'
    match = re.match(pp._titleregex, title)

    # Check that metadata is extracted
    assert match.group('title') == 'Test title'
    assert match.group('artist') == 'Test artist'

# Generated at 2022-06-22 09:29:35.594660
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl
    import sys
    import io
    out = io.StringIO()
    downloader = youtube_dl.YoutubeDL({})
    downloader.to_screen = lambda s: out.write(s + '\n')
    pp = MetadataFromTitlePP(downloader, '%(artist)s - %(title)s')
    info = {
        'title': 'Four Seasons - Summer'
    }
    pp.run(info)

    assert info == {
        'artist': 'Four Seasons',
        'title': 'Summer',
    }
    assert out.getvalue() == (
        '[fromtitle] parsed artist: Four Seasons\n'
        '[fromtitle] parsed title: Summer\n'
    )
    out.seek(0)
    out.truncate(0)

# Generated at 2022-06-22 09:29:45.175881
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    class Downloader(object):
        def to_screen(self, info):
            pass

    format = '%(title)s - %(track)s - %(artist)s'
    title = 'MyTitle - 12 - MyArtist'
    video_info = {'title': title}
    postprocessor = MetadataFromTitlePP(Downloader(), format)

    # The postprocessor is to return an empty list and a dict with metadata
    metadata = {}

    postprocessor.run(video_info)

    assert video_info == video_info, "video info should be unchangeable"

    assert metadata['title'] == 'MyTitle', "title should be 'MyTitle'"
    assert metadata['track'] == '12', "track should be '12'"
    assert metadata['artist'] == 'MyArtist', "artist should be 'MyArtist'"



# Generated at 2022-06-22 09:29:54.631744
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    downloader = object()
    pp = MetadataFromTitlePP(downloader, '%(artist)s | %(title)s')
    assert pp._titleformat == '%(artist)s | %(title)s'
    assert pp._titleregex == r'(?P<artist>.+)\ \|\ (?P<title>.+)'
    pp = MetadataFromTitlePP(downloader, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '%(title)s'
    pp = MetadataFromTitlePP(downloader, 'Title')
    assert pp._titleformat == 'Title'
    assert pp._titleregex == 'Title'



# Generated at 2022-06-22 09:30:01.878953
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    titleformat = '%(artist)s-%(title)s'
    metadata_from_title_pp = MetadataFromTitlePP(None, titleformat)
    title = 'The Beatles-Yellow Submarine'

    assert metadata_from_title_pp.format_to_regex(titleformat) == r'(?P<artist>.+)\-(?P<title>.+)'
    assert metadata_from_title_pp._titleregex == r'(?P<artist>.+)\-(?P<title>.+)'
    assert re.match(metadata_from_title_pp._titleregex, title) is not None

# Generated at 2022-06-22 09:30:08.938876
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .downloader import VideoDownloader
    from .extractor import YoutubeIE
    from .postprocessor import PostProcessor
    from .common import FileDownloader
    from .proxies import VideoProxyFactory
    from .compat import compat_urllib_parse_urlparse, compat_urlparse
    from .cache import FileCache
    from .utils import format_bytes
    import types

    video_id = '4cxn_yDcejY'
    video_filename = '4cxn_yDcejY.webm' # unescape(video_filename)

    class _YoutubeDL(object):
        def __init__(self, params, proxies, cache):
            self.params = params
            self.proxies = proxies
            self.cache = cache

    # Define class VideoDownloader

# Generated at 2022-06-22 09:30:45.852213
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl

    info = {'title': 'Wieder mal nen Tag verschenkt'}

    # method run of class MetadataFromTitlePP should add attribute artist
    # with value 'Böhse Onkelz' to the given info dict
    titleformat = '%(title)s - %(artist)s'
    titleregex = '%(title)s\ \-\ %(artist)s'
    test_pp = MetadataFromTitlePP(youtube_dl, titleformat)
    result_info, result_addinfos = test_pp.run(info)
    assert (
        result_info
        == {
            'title': 'Wieder mal nen Tag verschenkt',
            'artist': 'Böhse Onkelz'
        })
    assert result_addinfos == {}

   

# Generated at 2022-06-22 09:30:53.894577
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Set downloader
    downloader = {}
    downloader['to_screen'] = print
    # Set info
    info = {}
    info['title'] = 'John Lennon - Happy Xmas'
    # Set postprocessor
    postprocessor = MetadataFromTitlePP(downloader, '%(artist)s - %(title)s')
    # Execute method run of postprocessor
    postprocessor.run(info)
    expected_info = {}
    expected_info['title'] = 'Happy Xmas'
    expected_info['artist'] = 'John Lennon'
    assert info == expected_info
