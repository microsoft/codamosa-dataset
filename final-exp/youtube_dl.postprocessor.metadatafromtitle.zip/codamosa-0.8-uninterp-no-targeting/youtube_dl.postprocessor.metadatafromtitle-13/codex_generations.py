

# Generated at 2022-06-22 09:21:05.488946
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    titleformat = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(None, titleformat)
    assert pp._titleformat == titleformat
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'



# Generated at 2022-06-22 09:21:14.727718
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .youtube_dl import YoutubeDL
    from .extractor import get_info_extractor

    def validate_res(info, expected_info):
        for attr, value in expected_info.items():
            if attr not in info:
                print("Missing attr '{}' in info".format(attr))
                return False
            elif info[attr] != value:
                print("Invalid value '{}' for attr '{}'.".format(info[attr], attr))
                return False
        return True

    def validate(url, regex, expected_info):
        ie = get_info_extractor(url)
        pp = MetadataFromTitlePP(YoutubeDL(), regex)
        info = {'webpage_url': url}
        info.update(ie.extract(url))
        pp.run

# Generated at 2022-06-22 09:21:26.632186
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-22 09:21:39.509975
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ..YoutubeDL import YoutubeDL
    ydl = YahooDL()
    mftpp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    info = {'title': 'test - song'}
    assert (mftpp.run(info), info) == ([], {'title': 'test - song', 'artist': 'song'})

    info = {'title': 'test - song - artist'}
    assert (mftpp.run(info), info) == ([], {'title': 'test - song - artist', 'artist': 'song - artist'})

    info = {'title': 'test -'}
    assert (mftpp.run(info), info) == ([], info)

    mftpp = MetadataFromTitlePP(ydl, '%(title)s')

# Generated at 2022-06-22 09:21:51.893171
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    fd = FileDownloader(
        {}, YoutubeDL(
            {
                'titleformat': '%(title)s - %(artist)s',
                'writethumbnail': True,
                'quiet': True,
                'continuedl': True,
                'nooverwrites': True,
                'format': 'best',
            }
        )
    )
    pp = MetadataFromTitlePP(fd, '%(title)s - %(artist)s')

# Generated at 2022-06-22 09:22:04.390143
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .youtube_dl.YoutubeDL import YoutubeDL
    dl = YoutubeDL({'writethumbnail': True})
    titleformat = '%(artist)s - %(title)s'
    metadata_from_title = MetadataFromTitlePP(dl, titleformat)
    assert(metadata_from_title._titleformat == titleformat)
    assert(metadata_from_title._titleregex ==
           r'(?P<artist>.+)\ \-\ (?P<title>.+)')
    titleformat = '%(title)s'
    metadata_from_title = MetadataFromTitlePP(dl, titleformat)
    assert(metadata_from_title._titleformat == titleformat)
    assert(metadata_from_title._titleregex ==
           r'(?P<title>.+)')

# Generated at 2022-06-22 09:22:13.409651
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    #
    # Dictionary 'info'
    #
    info = {
        'title': '1. asdf - name1',
        'ext': 'mp4',
        'format': 'fullhd',
        }

    #
    # Downloader instance (mocked)
    #
    class MockYoutubeDL:
        def to_screen(self, *args, **params):
            pass

    youtube_dl = MockYoutubeDL()

    #
    # MetadataFromTitlePP object
    #
    titleformat = '%(title)s - %(name)s'
    metadata_from_title_pp = MetadataFromTitlePP(youtube_dl, titleformat)

    #
    # Test run() method
    #
    metadata_from_title_pp.run(info)

    #
    # Testing expected values
   

# Generated at 2022-06-22 09:22:20.656836
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    test_patterns = [
        ('%(title)s_%(artist)s', '(?P<title>.+)_(?P<artist>.+)'),
        ('%(title)s_%(artist)s.%(ext)s', '(?P<title>.+)_(?P<artist>.+)\.(?P<ext>.+)')
    ]
    for (format, expected_regex) in test_patterns:
        regex = MetadataFromTitlePP(None, format)._titleregex
        assert(regex == expected_regex)


# Generated at 2022-06-22 09:22:32.349569
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    import sys

    class DummyYDL:
        def __init__(self, out=sys.stdout):
            self.to_screen = lambda s: out.write('%s\n' % s)

    dl = FileDownloader(DummyYDL())
    # check if no attributes are set
    data = {'title': 'title'}
    p = MetadataFromTitlePP(dl, '[%(title)s]')
    [], data = p.run(data)
    assert data['title'] == 'title'

    # check if single attribute is set from title
    data = {'title': 'title'}
    p = MetadataFromTitlePP(dl, '%(title)s')
    [], data = p.run(data)

# Generated at 2022-06-22 09:22:41.754429
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp._titleformat == '%(artist)s - %(title)s'
    assert pp._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'

    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '%(title)s'



# Generated at 2022-06-22 09:22:53.388270
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, r'%(title)s - %(artist)s')
    assert pp.format_to_regex(r'%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex(r'(?P<title>.+)\ \-\ (?P<artist>.+)') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-22 09:23:03.320326
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FakeYDL
    from .downloader import external_downloader

    def test(title, titleformat, regex, metadata):
        ydl = FakeYDL()
        ydl.params['writethumbnail'] = 'foo'
        pp = MetadataFromTitlePP(ydl, titleformat)
        pp._titleregex = regex
        info = {'title': title}

        retval, newinfo = pp.run(info)
        assert newinfo == {'title': title, 'thumbnail': 'foo'}
        newinfo.update(metadata)
        assert retval == [], retval

    # The '%(title)s' and '%(uploader)s' are identifiers to be replaced with
    # the corresponding title or uploader names.  The uploaded date is
    # extracted from the '%(upload_date

# Generated at 2022-06-22 09:23:12.343488
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Mockup a downloader object
    class FakeDownloader(object):
        def to_screen(self, *args, **kwargs):
            pass
    downloader_obj = FakeDownloader()

    # Create object
    titleformat = '%(title)s - %(artist)s - %(album)s - %(date)s'
    obj = MetadataFromTitlePP(downloader_obj, titleformat)

    # Test run method
    info = {
        'title': 'test_title - test_artist - test_album - test_date'
    }
    [], info = obj.run(info)
    assert info['title'] == 'test_title - test_artist - test_album - test_date'
    assert info['artist'] == 'test_artist'
    assert info['album'] == 'test_album'

# Generated at 2022-06-22 09:23:23.949764
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '')


# Generated at 2022-06-22 09:23:32.608685
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import logging


# Generated at 2022-06-22 09:23:36.805774
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    p = MetadataFromTitlePP(None, None)
    assert p.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'



# Generated at 2022-06-22 09:23:40.000481
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import json
    import sys
    sys.path.insert(0, '..')
    from youtube_dl import Youtub

# Generated at 2022-06-22 09:23:48.683269
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    """ Test constructor of class MetadataFromTitlePP """
    class DummyYDL(object):
        def to_screen(self, msg):
            print(msg)

    # Test without regex
    ydl = DummyYDL()
    pp = MetadataFromTitlePP(ydl, "%(title)s - %(artist)s")
    assert(pp._titleformat == "%(title)s - %(artist)s")
    assert(pp._titleregex == "%(title)s - %(artist)s")

    # Test with regex
    ydl = DummyYDL()
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    assert(pp._titleformat == '%(title)s - %(artist)s')

# Generated at 2022-06-22 09:23:59.969358
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    p = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')

    info = {
        'title': 'my video - song:awesome',
    }
    p.run(info)
    assert info == {
        'title': 'my video - song:awesome',
        'artist': 'song:awesome',
    }

    info = {
        'title': 'my video - song:awesome - foo',
    }
    p.run(info)
    assert info == {
        'title': 'my video - song:awesome - foo',
    }

    info = {
        'title': 'my video - song:awesome - foo:bar:baz',
    }
   

# Generated at 2022-06-22 09:24:07.441723
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    m = MetadataFromTitlePP(None, '')
    assert m.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert m.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-22 09:24:23.166444
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .test import get_test_desc
    test_desc = get_test_desc()
    from .downloader import YoutubeDL
    from .postprocessor import PostProcessor
    ydl = YoutubeDL(test_desc)
    pp = PostProcessor(ydl)

    assert pp.format_to_regex('%(title)s - %(artist)s') == \
           '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert pp.format_to_regex('%(title)s.mp3') == '(?P<title>.+).mp3'



# Generated at 2022-06-22 09:24:34.223780
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # TODO add more test cases
    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert pp.format_to_regex('%(title)') == '%(title)'
    assert pp.format_to_regex('%(title)s %(album)s') == '(?P<title>.+)\ (?P<album>.+)'
    assert pp.format_to_regex('%(title)s - %(album)s') == '(?P<title>.+)\ \-\ (?P<album>.+)'

# Generated at 2022-06-22 09:24:43.956190
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    fmt = '%(title)s - %(artist)s'
    assert pp.format_to_regex(fmt) == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    fmt = 'u[%(uploader)s] - %(title)s'
    assert pp.format_to_regex(fmt) == 'u\[(?P<uploader>.+)\]\ \-\ (?P<title>.+)'

# Generated at 2022-06-22 09:24:54.377021
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import io
    import sys
    import tempfile
    from youtube_dl.YoutubeDL import YoutubeDL

    # create temporary file to simulate stdout
    f = tempfile.TemporaryFile()
    sys.stdout = io.TextIOWrapper(f)

    # method run() of class MetadataFromTitlePP
    def test_run(fmt, title, expected):
        pp = MetadataFromTitlePP(YoutubeDL(), fmt)
        info = {'title': title}
        pp.run(info)
        assert info == expected

    # test run() method
    test_run('%(title)s', 'My Video Title', {'title': 'My Video Title'})

# Generated at 2022-06-22 09:25:02.848368
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    metadata = {
        'title': '%(title)s - %(artist)s',
        'ext': 'webm',
        'format': 'unknown',
        'upload_date': '20150805',
        'uploader': 'test'
    }

    metadata_to_title = re.compile(
        MetadataFromTitlePP(None, metadata['title'])._titleregex)
    assert metadata_to_title.match(metadata['title']) is not None

    metadata['artist'] = "John Doe"
    metadata['track'] = "Test Track"
    metadata['title'] = "%(track)s - %(artist)s"
    metadata_to_title = re.compile(
        MetadataFromTitlePP(None, metadata['title'])._titleregex)
    assert metadata_to_title.match

# Generated at 2022-06-22 09:25:12.312821
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(series)s.S%(season_number)s.E%(episode_number)s')
    assert pp._titleregex == '^(?P<series>.+?)\.S(?P<season_number>.+?)\.E(?P<episode_number>.+?)$'

    pp = MetadataFromTitlePP(None, '%(tracknumber)02d - %(artist)s - %(title)s')
    assert pp._titleregex == '^(?P<tracknumber>.+?)\ \-\ (?P<artist>.+?)\ \-\ (?P<title>.+?)$'

    pp = MetadataFromTitlePP(None, '%(my_format)s')

# Generated at 2022-06-22 09:25:19.538747
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp._titleformat == '%(artist)s - %(title)s'
    assert pp._titleregex == r'(?P<artist>.+)\ \-\ (?P<title>.+)'
    assert pp.format_to_regex('%(artist)s - %(title)s') == r'(?P<artist>.+)\ \-\ (?P<title>.+)'

# Generated at 2022-06-22 09:25:25.554581
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.YoutubeDL import YoutubeDL

    ydl = YoutubeDL()
    mftpp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')

    assert mftpp._titleformat == '%(title)s - %(artist)s'
    assert mftpp._titleregex == '(?P<title>.+)\s-\s(?P<artist>.+)'


# Generated at 2022-06-22 09:25:34.779524
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import pytube.extract
    import pytube.postprocessor

    def run(format, title, expected_result):
        pp = pytube.postprocessor.MetadataFromTitlePP(None, format)
        info = { 'title': title }
        results = pp.run(info)
        if expected_result != info:
            return False

    # test various format strings
    if not run(
        '%(artist)s - %(track)s - %(title)s',
        'Lili Thalia',
        { 'title': 'Lili Thalia' }):
        return False

# Generated at 2022-06-22 09:25:44.257760
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    Unit test for method run of class MetadataFromTitlePP
    """
    from . import YoutubeDL

    info = {}
    ydl = YoutubeDL({})

    fmt1 = '%(title)s - %(artist)s'
    fmt2 = 'blah %(title)s - %(artist)s and %(uploader)s'

    # Test case 1
    title1 = 'blah something - artist'
    pp = MetadataFromTitlePP(ydl, fmt1)
    pp.run(info)

    assert info['title'] == 'something'
    assert info['artist'] == 'artist'
    assert info['uploader'] == None

    # Test case 2
    title2 = 'blah something - artist and someone'
    pp = MetadataFromTitlePP(ydl, fmt2)

# Generated at 2022-06-22 09:26:06.099357
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .test import get_test_json

    TEST_JSON1 = get_test_json('youtube')
    TEST_JSON2 = get_test_json('youtube_format_stream')
    TEST_JSON3 = get_test_json('youtube_age_restriction')
    TEST_JSON4 = get_test_json('youtube_private')

    # Prepare
    class MockDownloader:
        def to_screen(self, message):
            print(message)
    mock_downloader = MockDownloader()
    metadata_from_title_pp = MetadataFromTitlePP(
        mock_downloader, '%(title)s - %(artist)s')

    # Test with json from youtube
    info = {'title': 'The title of the video'}

# Generated at 2022-06-22 09:26:17.269403
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.utils import DownloadError
    from youtube_dl.YoutubeDL import YoutubeDL
    class DummyYDL(YoutubeDL):
        def to_screen(self_, *args, **kwargs):
            pass

    dl = DummyYDL()
    dl.params['writedescription'] = True
    dl.params['writeinfojson'] = True
    dl.params['writethumbnail'] = True
    dl.params['writeautomaticsub'] = True
    dl.params['skip_download'] = True

    # check that the output files are correctly produced
    def check_output_files(info):
        assert set(['title', 'artist', 'album', 'tracknumber']) <= set(info)
        assert info['title'] == 'title'

# Generated at 2022-06-22 09:26:20.838372
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """Test method 'run' of class MetadataFromTitlePP."""
    assert True


# Generated at 2022-06-22 09:26:29.207618
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from collections import namedtuple
    Test = namedtuple('Test', ['string', 'expected_regex'])
    tests = [
        Test('test', 'test'),
        Test('%(title)s - %(artist)s', '(?P<title>.+)\ \-\ (?P<artist>.+)'),
        Test('%(title)s%(artist)s%(test)s', '(?P<title>.+)'
             '(?P<artist>.+)'
             '(?P<test>.+)')]

    pp = MetadataFromTitlePP(None, None)
    for t in tests:
        regex = pp.format_to_regex(t.string)

# Generated at 2022-06-22 09:26:39.920330
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # simple test for method format_to_regex
    assert MetadataFromTitlePP({}, '%(name)s').format_to_regex('%(name)s') == '(?P<name>.+)'
    # more complex test for method format_to_regex
    assert (MetadataFromTitlePP({}, '%(name)s - %(title)s').format_to_regex(
                '%(name)s - %(title)s')
            == '(?P<name>.+)\ \-\ (?P<title>.+)')

    # simple test for attribute _titleregex
    assert MetadataFromTitlePP({}, '%(title)s')._titleregex == '(?P<title>.+)'
    # more complex test for attribute _titleregex

# Generated at 2022-06-22 09:26:44.695427
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp._titleregex == r'(?P<artist>.+)\ \-\ (?P<title>.+)'
    info = {'title': 'TEst - tEsT'}
    assert pp.run(info) == ([], {'title': 'TEst - tEsT', 'artist': 'TEst', 'title': 'tEsT'})

# Generated at 2022-06-22 09:26:52.737058
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Dummy downloader object
    class DummyDownloader:
        def to_screen(self, line):
            print(line)
    dl = DummyDownloader()
    # Dummy info object
    info = {'title': 'Dummy video Title'}
    pp = MetadataFromTitlePP(dl, '%(dummy)s')
    pp.run(info)
    info['title'] = 'Dummy video Title - Dummy artist'
    pp = MetadataFromTitlePP(dl, '%(title)s - %(artist)s')
    pp.run(info)

# test_MetadataFromTitlePP_run()

# Generated at 2022-06-22 09:27:03.808382
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # test with one replacement
    obj = MetadataFromTitlePP('', '%(title)s - %(artist)s')
    assert obj.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    # test with two replacement
    obj = MetadataFromTitlePP('', '%(foo)s this is a %(bar)s')
    assert obj.format_to_regex('%(foo)s this is a %(bar)s') == r'(?P<foo>.+)\ this\ is\ a\ (?P<bar>.+)'
    # test with three replacement
    obj = MetadataFromTitlePP('', 'abc %(foo)s this is a %(bar)s def')
    assert obj

# Generated at 2022-06-22 09:27:08.637941
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mft = MetadataFromTitlePP(None, None)
    assert(mft.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)')

# Generated at 2022-06-22 09:27:18.579122
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import Downloader
    from .common import FileDownloader

    downloader = Downloader(params={})
    processor = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    info = {'title': 'the title - the artist',
            'ext': 'mp3',
            'format': 'best',
            'format_id': 'best',
            'watch_url':'www.youtube.com/watch?v=hY7m5jjJ9mM',
            'playlist':None,
            'playlist_index':None,
            'playlist_id':None,
            'playlist_title':None}
    processor.run(info)

    assert info.get('title') == 'the title'
    assert info.get('artist') == 'the artist'



# Generated at 2022-06-22 09:27:30.274657
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '')
    assert pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-22 09:27:38.728948
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    metadatafromtitlepp = MetadataFromTitlePP(None, None)
    assert metadatafromtitlepp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert metadatafromtitlepp.format_to_regex('%(title)s -') == '(?P<title>.+)\ \-'
    assert metadatafromtitlepp.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert metadatafromtitlepp.format_to_regex('%(title)s%%') == '(?P<title>.+)%'


# Generated at 2022-06-22 09:27:45.686216
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.downloader import Downloader
    from youtube_dl.YoutubeDL import YoutubeDL

    ydl = YoutubeDL({'logger': Downloader})

    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')

    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'



# Generated at 2022-06-22 09:27:53.259265
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.tests.test_postprocessor import MockYDL

# Generated at 2022-06-22 09:28:04.059962
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import tempfile
    import os
    # mock downloader obj
    class MockYDL:
        def __init__(self):
            self.stdout = sys.stdout
            self.tempdir = tempfile.mkdtemp()
        def to_screen(self, info):
            pass
        def to_tempfile(self, info):
            temp_file_handle, temp_file_name = tempfile.mkstemp(dir=self.tempdir)
            os.close(temp_file_handle)
            with open(temp_file_name, 'w') as f:
                f.write(info)
            return temp_file_name

    f = MetadataFromTitlePP(MockYDL(), '%(artist)s - %(title)s')

# Generated at 2022-06-22 09:28:15.514260
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import re
    from .compat import compat_urllib_parse
    from .extractor import gen_extractors
    from .downloader import YoutubeDL
    # Title patterns
    titlepattern_no_duplicates = {
        '%(title)s': 'youtube-dl',
        '%(artist)s - %(title)s': 'The artist - the song',
        '%(title)s%(ext)s': 'youtube-dl.txt',
        '%(title)s by %(artist)s': 'the song by the artist'
    }

# Generated at 2022-06-22 09:28:23.985876
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from . import YoutubeDL
    inst = YoutubeDL({})
    pp = MetadataFromTitlePP(inst, '%(artist)s - %(title)s')

    assert pp._titleformat == '%(artist)s - %(title)s'
    assert pp._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'

    pp = MetadataFromTitlePP(inst, '%(asdf)s - %(fdsa)s')

    assert pp._titleformat == '%(asdf)s - %(fdsa)s'
    assert pp._titleregex == '(?P<asdf>.+)\ \-\ (?P<fdsa>.+)'

    pp = MetadataFromTitlePP(inst, '%(title)s')


# Generated at 2022-06-22 09:28:31.454151
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Create instance of class MetadataFromTitlePP
    titleformat = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(None, titleformat)
    # Check _titleformat
    assert pp._titleformat == titleformat
    # Check _titleregex
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'



# Generated at 2022-06-22 09:28:41.590009
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ..YoutubeDL import YoutubeDL
    from ..utils import DateRange
    from .common import FileDownloader
    downloader = FileDownloader({})
    downloader.params = {
        'writedescription': True,
        'writethumbnail': True,
        'writeinfojson': True,
    }
    downloader.add_info_extractor(
        YoutubeDL({'keepvideo': True}))
    downloader.add_info_extractor(YoutubeDL({
        'keepvideo': True,
        'usenetrc': False,
        'username': 'un',
        'password': 'pw',
        'videopassword': 'vp',
    }))
    extractors = downloader._ies
    for ie in extractors:
        ie.set_downloader(downloader)

    # Test that

# Generated at 2022-06-22 09:28:48.219300
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from collections import namedtuple
    from types import ModuleType
    from ytdl.postproc import MetadataFromTitlePP

    VideoInfo = namedtuple('VideoInfo', ['title'])
    Downloader = namedtuple('Downloader', ['to_screen'])
    pp = MetadataFromTitlePP(Downloader(print), '%(artist)s - %(title)s')

    info = VideoInfo('')
    pp.run(info)
    assert info.artist == 'NA' and info.title == 'NA'

    info = VideoInfo('Chrisspy - How To: Colorful Cut Crease')
    pp.run(info)
    assert info.artist == 'Chrisspy' and info.title == 'How To: Colorful Cut Crease'

    info = VideoInfo('Title')

# Generated at 2022-06-22 09:29:00.685161
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    mp = MetadataFromTitlePP(None, 'Test - %(artist)s')
    info = {'title': 'Test - J. Random'}
    mp.run(info)
    assert info == {'title': 'Test - J. Random',
                    'artist': 'J. Random'}

# Generated at 2022-06-22 09:29:05.651068
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    downloader = object()
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    info = {}
    info['title'] = 'a title - some artist'
    [], info = pp.run(info)
    assert info['title'] == 'a title'
    assert info['artist'] == 'some artist'


# Generated at 2022-06-22 09:29:15.616134
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import unittest
    import sys

    class TestMetadataFromTitlePP(unittest.TestCase):
        def test_conversion(self):
            self.assertEqual(MetadataFromTitlePP.format_to_regex(
                '%(title)s - %(artist)s'),
                r'(?P<title>.+)\ \-\ (?P<artist>.+)')
            self.assertEqual(MetadataFromTitlePP.format_to_regex(
                '%(title)s -  %(artist)s'),
                r'(?P<title>.+)\ \-\ \ (?P<artist>.+)')

    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(TestMetadataFromTitlePP))

    unittest.TextTestRunner

# Generated at 2022-06-22 09:29:23.948605
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    assert YoutubeDL().process_ie_result(
        {'id': '1234', 'title': 'A test - title'},
        download=False) == \
        [{'id': '1234', 'title': 'A test - title', 'artist': 'title'}]
    assert YoutubeDL().process_ie_result(
        {'id': '1234', 'title': 'A test - title'},
        download=False,
        extra_pp_kwargs={'titleformat': '%(title)s (length: %(duration)s)'}) == \
        [{'id': '1234', 'title': 'A test - title',
          'title_test': 'A test', 'duration': 'title'}]
    assert YoutubeDL().process_ie_result

# Generated at 2022-06-22 09:29:33.166735
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """Test cases for method run of class MetadataFromTitlePP"""

    class FakeYdl:
        def to_screen(self, message):
            print(message)
        # end of FakeYdl

    from .getinfo import YoutubeInfoExtractor
    from .compat import compat_str

    def assert_MetadataFromTitlePP_run(titleformat, title, expected):
        """
        Tests if the method MetadataFromTitlePP.run extract the correct metadata
        from title.

        Asserts if the metadata is not the same as the expected metadata.
        """

        class FakeYdl:
            def to_screen(self, message):
                print(message)
            # end of FakeYdl

        ydl = FakeYdl()
        ydl.to_screen('titleformat: %s' % repr(titleformat))
        ydl

# Generated at 2022-06-22 09:29:42.251298
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    cls = MetadataFromTitlePP(None, '')
    # Simple case
    assert cls.format_to_regex('%(title)s') == '(?P<title>.+)'
    # Multiple groups
    assert cls.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    # No substitutions
    assert cls.format_to_regex('abcdefg') == 'abcdefg'
    # Empty string
    assert cls.format_to_regex('') == ''


# Generated at 2022-06-22 09:29:52.575028
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})

    pp = MetadataFromTitlePP(ydl, '%(title)s (%(artist)s - %(track)s)')
    pp.run({'title': 'blablabla (artist - song)'})

    pp = MetadataFromTitlePP(ydl, '%(track)s/%(artist)s/%(title)s')
    pp.run({'title': 'title/artist/track'})

    pp = MetadataFromTitlePP(ydl, '%(track)s/%(artist)s/%(title)s')
    pp.run({'title': 'title/artist/track/something else'})


# Generated at 2022-06-22 09:29:57.180712
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-22 09:30:02.895066
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(hello)s - %(world)s')
    assert pp.format_to_regex('%(hello)s - %(world)s') == '(?P<hello>.+)\ \-\ (?P<world>.+)'
    assert pp.format_to_regex('%(hello)s - %(world)s') == '(?P<hello>.+)\ \-\ (?P<world>.+)'

# Generated at 2022-06-22 09:30:11.595871
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mft = MetadataFromTitlePP(None, None)
    if mft.format_to_regex('%(title)s - %(artist)s') != r'(?P<title>.+)\ \-\ (?P<artist>.+)':
        raise ValueError('Test for method format_to_regex of class MetadataFromTitlePP failed')
    # same test with some escape characters
    if mft.format_to_regex('%(title)s - %(artist)s {{ %(artist)s }}') != r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \{\{.+\}\}':
        raise ValueError('Test for method format_to_regex of class MetadataFromTitlePP failed')

# Generated at 2022-06-22 09:30:44.307044
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert (MetadataFromTitlePP(None, None).format_to_regex('a %(title)s')
            == r'a (?P<title>.+)')
    assert (MetadataFromTitlePP(None, None).format_to_regex('%(title)s a')
            == r'(?P<title>.+)\ a')
    assert (MetadataFromTitlePP(None, None).format_to_regex('%(title)s')
            == r'(?P<title>.+)')
    assert (MetadataFromTitlePP(None, None).format_to_regex('a %(title)s a')
            == r'a (?P<title>.+)\ a')

# Generated at 2022-06-22 09:30:50.385526
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .downloader import Downloader
    downloader = Downloader(use_proxy=False)
    def _screen(s):
        print(s)

    downloader.to_screen = _screen

    mftpp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    info = {
        'title': 'test - test',
    }

    mftpp.run(info)

    assert info == {
        'title': 'test - test',
        'artist': 'test',
    }

# Generated at 2022-06-22 09:30:57.546536
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """Test method run of class MetadataFromTitlePP"""
    # Set up parameters
    downloader = None
    titleformat = "%(title)s - %(artist)s"
    info = {'title':"Test title - test artist"}
    attributes = ["title", "artist"]

    pp = MetadataFromTitlePP(downloader, titleformat)

    # Run method
    _, result = pp.run(info)

    # Check results
    for attribute in attributes:
        assert attribute in result
        assert result[attribute] == info[attribute]
