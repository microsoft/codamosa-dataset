

# Generated at 2022-06-22 09:21:05.882323
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    m = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    expected = r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert m.format_to_regex(m._titleformat) == expected

# Generated at 2022-06-22 09:21:14.979631
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import pytest

    assert MetadataFromTitlePP._run_test(
        {'title': 'xyz'},
        '[fromtitle] Could not interpret title of video as "xyz"',
        {},
    )
    assert MetadataFromTitlePP._run_test(
        {'title': 'xyz'},
        '[fromtitle] Could not interpret title of video as "xyz"'
        ) == (None,{})
    assert MetadataFromTitlePP._run_test(
        {'title': 'xyz', 'titleformat': '%(title)s'},
        '[fromtitle] parsed title: xyz',
        {'title': 'xyz', 'titleformat': '%(title)s'},
    )

# Generated at 2022-06-22 09:21:26.623325
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # add mocked downloader to MetadataFromTitlePP
    import youtube_dl.downloader.common
    youtube_dl.downloader.common.to_screen = lambda msg: None
    # instantiate MetadataFromTitlePP
    mftpp = MetadataFromTitlePP(None,'%(title)s - %(uploader)s')
    # test
    info = { 'title': 'Foo Bar - John Doe' }
    print(mftpp.run(info))
    assert info['title'] == 'Foo Bar'
    assert info['uploader'] == 'John Doe'
    # test failure
    info = { 'title': 'Foo Bar - John Doe - 1234' }
    mftpp.run(info)
    assert not 'title' in info
    assert not 'uploader' in info
    # test wrong order of

# Generated at 2022-06-22 09:21:39.468553
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    class Downloader:
        def to_screen(self, msg):
            sys.stderr.write(msg + '\n')
    date_range = DateRange('today')
    downloader = Downloader()

# Generated at 2022-06-22 09:21:47.837273
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Test 1 Python 2
    titleformat = b"%(title)s"
    downloader = MetadataFromTitlePP(None, titleformat)
    assert downloader._titleregex == b"(?P<title>.+)"

    # Test 2 Python 3
    titleformat = "%(title)s"
    downloader = MetadataFromTitlePP(None, titleformat)
    assert downloader._titleregex == "(?P<title>.+)"

# Generated at 2022-06-22 09:21:52.016935
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    d = {'title': 'Foo - Bar'}
    m = MetadataFromTitlePP({}, '%(title)s - %(artist)s')
    res1, res2 = m.run(d)
    assert res1 == []
    assert res2['title'] == 'Foo'
    assert res2['artist'] == 'Bar'

# Generated at 2022-06-22 09:22:03.127282
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    testcases = [
        # (format, regex)
        ('%(title)s', r'(?P<title>.+)'),
        ('%(title)s by %(artist)s', r'(?P<title>.+)\ by\ (?P<artist>.+)'),
        ('%(title)s - %(artist)s / %(composer)s', r'(?P<title>.+)\ -\ (?P<artist>.+)\ \/\ (?P<composer>.+)'),
    ]
    for fmt, regex in testcases:
        pp = MetadataFromTitlePP(None, fmt)
        assert pp._titleformat == fmt
        assert pp._titleregex == regex

# Generated at 2022-06-22 09:22:05.588223
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    titleformat = '%(title)s - %(artist)s'
    titleregex = '^(?P<title>.+) - (?P<artist>.+)$'
    title = 'Title - Artist'
    pp = MetadataFromTitlePP(None, titleformat)
    regex = pp.format_to_regex(titleformat)
    assert re.match(regex, title) is not None
    assert regex == titleregex

# Generated at 2022-06-22 09:22:14.086105
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import ydl_extractor_test
    test = ydl_extractor_test.YDLTest()

    test.downloader.params.update(ydl_extractor_test.PARAMS_TEMPLATE)
    test.downloader.params['postprocessor_args'] = ['--metadata-from-title', '%(artist)s - %(title)s']

    test.downloader.cache.update({
        'https://api.github.com/repos/ytdl-org/youtube-dl/contents/'
        'youtube_dl/extractor/common.py?ref=master':
        '{"name": "common.py", "size": 20, "download_url": "https://example.com/common.py"}'})


# Generated at 2022-06-22 09:22:24.819080
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # setup
    downloader = None
    titleformat = '%(title)s - %(artist)s'
    title = 'Title - Artist'
    assert re.match(MetadataFromTitlePP(downloader, titleformat)._titleregex, title)

    titleformat = 'A%(title)sB - A%(artist)sB'
    title = 'ATitleB - AArtistB'
    assert re.match(MetadataFromTitlePP(downloader, titleformat)._titleregex, title)

    titleformat = '%(title)s - %(artist)s - %(key)s'
    title = 'ATitleB - AArtistB - AKeyB'
    regex = MetadataFromTitlePP(downloader, titleformat)._titleregex
    assert re.match(regex, title)

# Generated at 2022-06-22 09:22:37.803218
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import prepare_filename
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import MetadataFromTitlePP

    # Prepare test inputs
    titleformat = '%(artist)s - %(title)s'
    regex = MetadataFromTitlePP.format_to_regex(titleformat)
    regex_matcher = re.compile(regex)
    pre_info = {
        'id': 'foo',
        'title': 'x',
        'ext': 'mp3',
        'format': 'audio',
        'format_id': 'audio',
        'url': 'URL',
    }

    # Case 1: Title does not contains 'artist' and 'title'
    info = pre_info.copy()


# Generated at 2022-06-22 09:22:44.354516
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test a title that matches the regex
    assert MetadataFromTitlePP(None, '%(title)s').run(
        {'title': 'Test Title'}) == ([], {'title': 'Test Title',
                                          'title': 'Test Title'})

    # Test a title that does match the regex
    assert MetadataFromTitlePP(None, '%(title)s').run(
        {'title': 'Fail Title'}) == ([], {'title': 'Fail Title'})


# Generated at 2022-06-22 09:22:53.581048
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # testing constructor of class MetadataFromTitlePP
    pp = MetadataFromTitlePP(None, '')
    # test for valid regular expression string
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    # test for invalid regular expression string
    pp = MetadataFromTitlePP(None, '%(title)s_%(artist)s')
    assert pp._titleregex == '%(title)s_%(artist)s'



# Generated at 2022-06-22 09:23:03.480452
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    match = "1_2345_01-05-2001__111_01-05-2001.mpg"
    info = {
        'title': match,
    }
    titleformat = '%(episode_number)s_%(match_id)s_%(start_date)s__%(free_match_id)s_%(start_date)s.%(ext)s'
    metadata_from_title = MetadataFromTitlePP(None, titleformat=titleformat)
    expected = {
        'title': match,
        'episode_number': '1',
        'match_id': '2345',
        'start_date': '01-05-2001',
        'free_match_id': '111',
        'ext': 'mpg'
    }

# Generated at 2022-06-22 09:23:12.459855
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    tft = MetadataFromTitlePP(None, '')
    test_cases = [
        ('%(title)s', '(?P<title>.+)'),
        ('a %(title)s b %(artist)s c', 'a\ (?P<title>.+)\ b\ (?P<artist>.+)\ c'),
        ('%(title)s-%(artist)s', '(?P<title>.+)\-(?P<artist>.+)'),
        ('%(\x08\x08\x08\x08)s', '%(\x08\x08\x08\x08)s'),
    ]
    for input in test_cases:
        expected = test_cases[input]
        actual = tft.format_to_regex(input)

# Generated at 2022-06-22 09:23:19.453853
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .downloader import _get_info_extractor
    MetadataFromTitlePP._get_info_extractor = staticmethod(_get_info_extractor)
    regex = (MetadataFromTitlePP(None, '%(title)s').format_to_regex(
        '%(title)s - %(artist)s'))
    match = re.match(regex, 'test_title - test_artist')
    assert match.group('title') == 'test_title'
    assert match.group('artist') == 'test_artist'
    match = re.match(regex, 'test_title - test_artist - more_text')
    assert match.group('title') == 'test_title'
    assert match.group('artist') == 'test_artist - more_text'

# Generated at 2022-06-22 09:23:29.891893
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    test_cases = [
        ['%(title)s',r'(?P<title>.+)'],
        ['%(title)s - %(artist)s',r'(?P<title>.+)\ \-\ (?P<artist>.+)'],
        ['%(title)s - %(artist)s - %(album)s',r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'],
        ['%(title)s - %(artist)s - %(somedate)s',r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<somedate>.+)'],
    ]
    pp = MetadataFromTitlePP(None,None)

# Generated at 2022-06-22 09:23:32.956855
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, '%(title)s').format_to_regex(
        '%(title)s') == '(?P<title>.+)'


# Generated at 2022-06-22 09:23:43.561122
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # test default behaviour
    mft = MetadataFromTitlePP(None, '%(title)s')
    assert mft._titleformat == '%(title)s'
    assert mft._titleregex == '(?P<title>.+)'

    # test static regex
    mft = MetadataFromTitlePP(None, 'test')
    assert mft._titleformat == 'test'
    assert mft._titleregex == 'test'

    # test regex building with 2 groups
    mft = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert mft._titleformat == '%(title)s - %(artist)s'
    assert mft._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-22 09:23:54.803205
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)

    # no %(..)s
    assert pp.format_to_regex('%(title)') == '%(title)'
    # one %(..)s
    assert pp.format_to_regex('%(title)s') == '(?P<title>.+)'
    # two %(..)s
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    # test escaping of \ - .

# Generated at 2022-06-22 09:23:59.641902
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-22 09:24:06.192863
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import sys
    import io
    import os
    import youtube_dl.YoutubeDL
    saved_stdout = sys.stdout
    out = sys.stdout = io.StringIO()

    pp = MetadataFromTitlePP(youtube_dl.YoutubeDL(), '%(artist)s - %(title)s')
    assert pp._titleformat == '%(artist)s - %(title)s'
    assert pp._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'

    pp = MetadataFromTitlePP(youtube_dl.YoutubeDL(), 'some text')
    assert pp._titleformat == 'some text'
    assert pp._titleregex == r'some\ text'

    sys.stdout = saved_stdout


# Generated at 2022-06-22 09:24:15.289448
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .test import get_test_downloader, get_test_suite
    from .compat import compat_str


# Generated at 2022-06-22 09:24:21.887043
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    m = MetadataFromTitlePP(None, 'Some artist - Some title')
    assert "Some artist - Some title" == m._titleformat
    assert isinstance(m._titleregex, basestring)

    m = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert '%(title)s - %(artist)s' == m._titleformat
    assert not isinstance(m._titleregex, basestring)


# Generated at 2022-06-22 09:24:34.122285
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    def _test_format_to_regex(fmt, regex):
        pp = MetadataFromTitlePP(None, fmt)

# Generated at 2022-06-22 09:24:44.513778
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .common import Downloader
    # Test no keywords
    fmt = 'This is the title'
    pp = MetadataFromTitlePP(Downloader(), fmt)
    assert pp._titleformat == fmt
    assert pp._titleregex == fmt

    # Test one keyword
    fmt = '[%(id)s] This is the title'
    pp = MetadataFromTitlePP(Downloader(), fmt)
    assert pp._titleformat == fmt
    assert pp._titleregex == '\[(?P<id>.+)\]\ This\ is\ the\ title'

    # Test more keywords
    fmt = '[%(date)s] %(title)s'
    pp = MetadataFromTitlePP(Downloader(), fmt)
    assert pp._titleformat == fmt

# Generated at 2022-06-22 09:24:54.839760
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from_title_PP = MetadataFromTitlePP(None, None)

    assert from_title_PP.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert from_title_PP.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert from_title_PP.format_to_regex('%(title)s - %(artist)s [%(year)s]') == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \[(?P<year>.+)\]'

# Generated at 2022-06-22 09:24:59.683794
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    mftpp = MetadataFromTitlePP(None, '%(title)s_%(artist)s')
    titleformat = mftpp._titleformat
    assert titleformat == '%(title)s_%(artist)s'
    titleregex = mftpp._titleregex
    assert titleregex == '(?P<title>.+)_(?P<artist>.+)'


# Generated at 2022-06-22 09:25:06.612578
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # assert format_to_regex test
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s')._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, r'%(title)s\ -\ %(artist)s')._titleregex == r'(?P<title>.+)\\\ \-\\\\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, '%(title)s \- %(artist)s')._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, '%(title)s')._titleregex == '(?P<title>.+)'
    assert Metadata

# Generated at 2022-06-22 09:25:13.672733
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # A successful constructions with a replete format string
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    # A successful constructions with a simple format string
    assert MetadataFromTitlePP(None, '%(title)s')
    # A successful constructions with a string having no %(...)s
    assert MetadataFromTitlePP(None, 'the title')



# Generated at 2022-06-22 09:25:26.845838
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    assert hasattr(MetadataFromTitlePP, 'format_to_regex')
    m1 = MetadataFromTitlePP(None, '%(title)s')
    assert m1._titleformat == '%(title)s'
    assert m1._titleregex == '(?P<title>.+)'
    m2 = MetadataFromTitlePP(None, 'title')
    assert m2._titleformat == 'title'
    assert m2._titleregex == 'title'
    m3 = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert m3._titleformat == '%(title)s - %(artist)s'
    assert m3._titleregex == '(?P<title>.+)\ \\-\ (?P<artist>.+)'

# Unit tests for run()

# Generated at 2022-06-22 09:25:34.976565
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mp = MetadataFromTitlePP(None, None)
    assert mp.format_to_regex(r'%(title)s - %(artist)s') == \
        r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert mp.format_to_regex(r'%(title)s') == r'(?P<title>.+)'
    assert mp.format_to_regex(r'(%(title)s)') == r'\((?P<title>.+)\)'
    assert mp.format_to_regex(r'Foo (bar %% baz)') == r'Foo\ \(bar\ \%\ baz\)'

# Generated at 2022-06-22 09:25:44.336961
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s (%(year)s)') == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \((?P<year>.+)\)'

# Generated at 2022-06-22 09:25:47.715874
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    titleformat = '%(title)s - %(artist)s'
    regex = '(?P<title>.+)\\ \-\\ (?P<artist>.+)'
    assert(MetadataFromTitlePP(None, titleformat)._titleregex == regex)


# Generated at 2022-06-22 09:25:57.049657
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import assemble_title
    import youtube_dl
    title = 'My Videos playlist (1/2) - The Best of YouTube'
    info = {'title': title}
    titleformat = '%(playlist_title)s (%(playlist_index)s/%(playlist_size)s) - %(playlist_uploader)s'

    # Initialize the PP object and call run
    ydl = youtube_dl.YoutubeDL(youtube_dl.FileDownloader())
    pp = MetadataFromTitlePP(ydl, titleformat)
    _, info = pp.run(info)

    # For every attribute that is parsed, check that the value is correct
    # according to the assemble_title function.
    # This is quite a fragile approach and might break at some point.

# Generated at 2022-06-22 09:25:58.313275
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pass


# Generated at 2022-06-22 09:26:07.380903
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    regex = pp.format_to_regex('%(title)s - %(artist)s')
    assert regex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    match = re.match(regex, 'random title - random artist')
    assert match is not None
    assert match.groupdict()['title'] == 'random title'
    assert match.groupdict()['artist'] == 'random artist'
    match = re.match(regex, 'random title - random artist - random stuff')
    assert match is None
    regex = pp.format_to_regex('%(title)s - %(artist)s - %(album)s')

# Generated at 2022-06-22 09:26:16.794254
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .postprocessor import MetadataFromTitlePP
    assert MetadataFromTitlePP(None, '%(title)s').format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert MetadataFromTitlePP(None, ' %(title)s ').format_to_regex(' %(title)s ') == r'\ (?P<title>.+)\ '
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s').format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-22 09:26:22.824996
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .downloader import YoutubeDL
    ydl = YoutubeDL()
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(name)s'))

if __name__ == '__main__':
    test_MetadataFromTitlePP()

# Generated at 2022-06-22 09:26:25.220813
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # We want to test that the constructor of MetadataFromTitlePP does not
    # raise any exception
    MetadataFromTitlePP(object, "Format for %(title)s")

# Generated at 2022-06-22 09:26:40.088178
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import YoutubeDL
    pp = MetadataFromTitlePP(YoutubeDL(), '%(title)s - %(artist)s')
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert pp.format_to_regex('%(title)s %(title)s') == '(?P<title>.+)\ (?P<title>.+)'
    assert pp.format_to_regex('Hello%%%(title)s%(title)s') == 'Hello%(?P<title>.+)(?P<title>.+)'
    assert pp.format_to_re

# Generated at 2022-06-22 09:26:46.960397
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from pytube import Youtube
    youtube = Youtube('http://www.youtube.com/watch?v=BaW_jenozKc')
    # 1. Test if string conversion works with only one group
    assert MetadataFromTitlePP(youtube, '%(title)s').format_to_regex(
        '%(title)s') == r'(?P<title>.+)'
    # 2. Test if string conversion works with two groups
    assert MetadataFromTitlePP(youtube, '%(title)s - %(artist)s').format_to_regex(
        '%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    # 3. Test if string conversion works with string parts

# Generated at 2022-06-22 09:26:56.618909
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl.YoutubeDL
    import youtube_dl.postprocessor.common
    titleformat = '%(title)s - %(artist)s'
    info = {'title': 'This is a test title - John Doe'}
    pp = MetadataFromTitlePP(youtube_dl.YoutubeDL({}), titleformat)
    _, info = pp.run(info)
    assert info['title'] == 'This is a test title'
    assert info['artist'] == 'John Doe'
    # Check that NA values are handled correctly
    titleformat = '%(title)s - %(artist)s - %(ext)s'
    pp = MetadataFromTitlePP(youtube_dl.YoutubeDL({}), titleformat)
    _, info = pp.run(info)

# Generated at 2022-06-22 09:26:59.862913
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    downloader = lambda : None
    downloader.to_screen = lambda x: None
    mp = MetadataFromTitlePP(downloader, '%(chapter)s - %(artist)s')
    assert mp



# Generated at 2022-06-22 09:27:03.332387
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp._titleformat == '%(artist)s - %(title)s'
    assert pp._titleregex == r'(?P<artist>.+)\ \-\ (?P<title>.+)'



# Generated at 2022-06-22 09:27:14.916677
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .downloader import VideoInfo
    from .downloader import Downloader
    from .cache import FileCache

    # initialise dummy Downloader instance
    info_dict = {
        'id': '1234567890',
        'ext': 'mp4',
        'title': 'Test Title',
        'format': 'Test Format',
        'formats': ['Test Format'],
        'duration': 3
    }
    downloader = Downloader(FileCache())
    info = VideoInfo(downloader, downloader.cache, info_dict)

    # test %(title)s - %(artist)s
    titleformat = '%(title)s - %(artist)s'
    regex = '(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-22 09:27:22.962124
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '%(title)s'
    pp = MetadataFromTitlePP(None, '%(\w+)s')
    assert pp._titleformat == '%(\w+)s'
    assert pp._titleregex == '%(\w+)s'

# Generated at 2022-06-22 09:27:31.607988
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp._titleformat == '%(artist)s - %(title)s'
    assert pp._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'
    pp = MetadataFromTitlePP(None, 'No metadata in title')
    assert pp._titleformat == 'No metadata in title'
    assert pp._titleregex == 'No metadata in title'


# Generated at 2022-06-22 09:27:39.803874
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, 'test')
    assert pp.format_to_regex('%(title)s - %(artist)s') == \
        '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(artist)s and %(title)s') == \
        '(?P<artist>.+)\ and\ (?P<title>.+)'
    assert pp.format_to_regex('%(title)s - > %(artist)s') == \
        '(?P<title>.+)\ \-\ \>\ (?P<artist>.+)'


# Generated at 2022-06-22 09:27:50.398652
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    outputs = []
    pp = MetadataFromTitlePP(None, '%(title)s by %(artist)s')
    def to_screen(msg):
        outputs.append(msg)
    pp._downloader.to_screen = to_screen

    # All attributes are available
    footage = {'title': 'title1 by artist1'}
    result, info = pp.run(footage)
    assert len(result) == 0
    assert info == {'title': 'title1', 'artist': 'artist1'}
    expected = [
        '[fromtitle] parsed title: title1',
        '[fromtitle] parsed artist: artist1',
    ]
    assert outputs == expected
    outputs.clear()

    # Missing artist attribute
    footage = {'title': 'title1'}

# Generated at 2022-06-22 09:28:02.500495
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    titleformat = '%(title)s - %(artist)s'
    titleregex = '(?P<title>.+)\\ -\\ (?P<artist>.+)'
    mp = MetadataFromTitlePP(None, titleformat)
    assert mp.format_to_regex(titleformat) == titleregex

# Generated at 2022-06-22 09:28:11.566311
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    class FakeDownloader():
        def to_screen(self, msg):
            print('FakeDownloader: ' + msg)

    titleformat = '%(title)s - %(artist)s'
    title = 'This is the title - artist'
    fd = FakeDownloader()
    pp = MetadataFromTitlePP(fd, titleformat)

    match = re.match(pp._titleregex, title)
    assert(match)
    for attribute, value in match.groupdict().items():
        assert(attribute == 'title' and value == 'This is the title')
        assert(attribute == 'artist' and value == 'artist')

# Generated at 2022-06-22 09:28:22.683560
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mft = MetadataFromTitlePP(None, '')

    assert mft.format_to_regex('') == ''
    assert mft.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert mft.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert mft.format_to_regex('o_0 - %(title)s') == 'o_0\ \-\ (?P<title>.+)'
    assert mft.format_to_regex('%(artist)s - o_0 %(title)s') == '(?P<artist>.+)\ \-\ o_0\ (?P<title>.+)'

# Generated at 2022-06-22 09:28:34.163191
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    results = []
    downloader = FakeInfoDict({'title': 'my title', 'description': 'my desc.'})
    downloader.to_screen = lambda s: results.append(s)
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(description)s')
    info = {}
    pp.run(info)
    assert info.get('title') == 'my title'
    assert info.get('description') == 'my desc.'
    assert results[0] == '[fromtitle] Could not interpret title of video as "%s"'
    assert results[1] == '[fromtitle] parsed title: my title'
    assert results[2] == '[fromtitle] parsed description: my desc.'

    results = []

# Generated at 2022-06-22 09:28:44.057484
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ydl.utils import DateRange
    from ydl.extractor import get_info_extractor
    import os

    class MockDownloader():
        def to_screen(self, msg):
            print(msg)

    ie = get_info_extractor('test')
    ie.extract_info = lambda url, download: {'id': 'test_id',
                                             'title': 'Test title - Test artist'}
    ie.add_progress_hook = lambda x: None
    downloader = MockDownloader()
    downloader.params = {'outtmpl': '%(title)s.%(ext)s',
                         'usenetrc': False,
                         'verbose': True,
                         'date': DateRange(None),
                         'playlistend': None,
                         'playliststart': None}


# Generated at 2022-06-22 09:28:50.345545
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s').format_to_regex(
        '%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, '%(title)s').format_to_regex(
        '%(title)s') == '(?P<title>.+)'
    assert MetadataFromTitlePP(None, '%(title)s').format_to_regex(
        '') == ''
    assert MetadataFromTitlePP(None, '%(title)s').format_to_regex(
        'title') == 'title'

# Generated at 2022-06-22 09:28:50.998910
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass

# Generated at 2022-06-22 09:28:55.049775
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    metadataFromTitlePP = MetadataFromTitlePP(None, None)
    assert metadataFromTitlePP.format_to_regex(r'%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-22 09:29:00.732241
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    downloader = object()
    titleformat = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(downloader, titleformat)
    info = {
        'title': 'Test - This is a Test'
    }
    result = pp.run(info)
    assert result == ([], {
        'title': 'Test - This is a Test',
        'artist': 'This is a Test',
    })

# Generated at 2022-06-22 09:29:10.116334
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL

    ydl = YoutubeDL({})

    info = {'title': 'Some Title'}
    titleformat = '%(title)s'
    pp = MetadataFromTitlePP(ydl, titleformat)
    result, info = pp.run(info)
    assert (
        info['title'] == 'Some Title'
        and len(result) == 0)

    info = {'title': 'Some Title'}
    titleformat = '%(title)s_%(asd)s'
    pp = MetadataFromTitlePP(ydl, titleformat)
    result, info = pp.run(info)
    assert (
        'title' in info
        and 'asd' not in info
        and len(result) == 0)


# Generated at 2022-06-22 09:29:33.089734
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    class MockDownloader:
        def __init__(self):
            self.logs = []

        def to_screen(self, msg):
            self.logs.append(msg)

    downloader = MockDownloader()
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    regex = pp.format_to_regex('%(title)s - %(artist)s')
    assert regex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-22 09:29:43.902541
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    import pytest
    mftpp = MetadataFromTitlePP(None, None)
    assert mftpp.format_to_regex(r'ABC') == r'ABC'
    assert mftpp.format_to_regex(r'%(artist)s - %(title)s') == r'(?P<artist>.+)\ -\ (?P<title>.+)'
    assert mftpp.format_to_regex(r'Artist is named %(artist)s') == r'Artist\ is\ named\ (?P<artist>.+)'

if __name__ == '__main__':
    # Some quick tests
    mpp = MetadataFromTitlePP(None, r'')
    assert mpp.format_to_regex(r'ABC') == r'ABC'
    assert mpp.format_to

# Generated at 2022-06-22 09:29:50.773588
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-22 09:29:59.201628
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    """
    Test that the MetadataFromTitlePP constructors work
    """
    # Test that the regular MetadataFromTitlePP constructor works
    MetadataFromTitlePP(None, '%(title)s')

    # Test that the regex MetadataFromTitlePP constructor works
    MetadataFromTitlePP(None, '%(title)s\ \-\ %(artist)s')

    # Test that a constructor call with an invalid regex raises an exception
    from .extractor import DownloadError
    try:
        MetadataFromTitlePP(None, '%')
    except DownloadError:
        pass



# Generated at 2022-06-22 09:30:06.868769
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, None).format_to_regex(
        '%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, None).format_to_regex(
        '%(title)s - %(artist)s - %(year)s') == \
        r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<year>.+)'
    assert MetadataFromTitlePP(None, None).format_to_regex(
        '%(title)s') == r'(?P<title>.+)'

# Generated at 2022-06-22 09:30:13.247748
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    metadatafromtitlepp = MetadataFromTitlePP(None, '%(title)s')
    assert metadatafromtitlepp.format_to_regex('%(title)s') == r'(?P<title>.+)'

    metadatafromtitlepp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert (metadatafromtitlepp.format_to_regex('%(title)s - %(artist)s')
            == r'(?P<title>.+)\ \-\ (?P<artist>.+)')



# Generated at 2022-06-22 09:30:21.226829
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    assert re.match(MetadataFromTitlePP(None,
        '%(title)s - %(artist)s')._titleregex, 'Titla - Artista')
    assert re.match(MetadataFromTitlePP(None,
        '%(title)s - %(artist)s')._titleregex, 'Titla - Artista - More')
    assert re.match(MetadataFromTitlePP(None,
        'Titla - Artista')._titleregex, 'Titla - Artista')
    assert re.match(MetadataFromTitlePP(None,
        'Titla - Artista')._titleregex, 'Titla - Artista - More')

# Generated at 2022-06-22 09:30:27.557702
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    assert pp.format_to_regex(r'%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex(r'%(title)s - %(artist)s - %(album)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'
    assert pp.format_to_regex(r'%(title)s') == r'(?P<title>.+)'

# Generated at 2022-06-22 09:30:38.620680
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    # A YoutubeDL instance is needed to use `to_screen`
    ydl = YoutubeDL()
    mftpp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    info = {'title': 'myTitle - myArtist'}
    mftpp.run(info)
    assert info == {'title': 'myTitle - myArtist', 'artist': 'myArtist'}
    mftpp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    info = {'title': 'myTitle - myArtist - bla'}
    assert mftpp.run(info)[1] == info

# Generated at 2022-06-22 09:30:49.317602
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest
    import unittest.mock as mock

    class MockDownloader(object):
        def to_screen(self, s):
            pass

    class TestCase(unittest.TestCase):
        def test_metadata(self):
            pp = MetadataFromTitlePP(
                None, '%(title)s - %(artist)s')
            info = {'title': 'Foo - Bar'}
            pp.run(info)
            self.assertEqual(info['title'], 'Foo')
            self.assertEqual(info['artist'], 'Bar')

        def test_no_metadata(self):
            pp = MetadataFromTitlePP(
                None, '%(title)s - %(artist)s')
            info = {'title': 'Foo'}