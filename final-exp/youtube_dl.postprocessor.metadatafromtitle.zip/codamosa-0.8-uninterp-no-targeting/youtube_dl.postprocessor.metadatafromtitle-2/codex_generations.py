

# Generated at 2022-06-22 09:21:12.686169
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    t = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert t._titleformat == '%(title)s - %(artist)s'
    assert t._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    t = MetadataFromTitlePP(None, '%(asd)s - %(qwe)s')
    assert t._titleformat == '%(asd)s - %(qwe)s'
    assert t._titleregex == '(?P<asd>.+)\ \-\ (?P<qwe>.+)'

    t = MetadataFromTitlePP(None, '%(title)s')
    assert t._titleformat == '%(title)s'

# Generated at 2022-06-22 09:21:22.963025
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None)
    assert pp.format_to_regex(r'%(artist)s - %(title)s') == r'(?P<artist>.+)\ \-\ (?P<title>.+)'
    assert pp.format_to_regex(r'%(artist)s - %(title)s - %(year)s') == r'(?P<artist>.+)\ \-\ (?P<title>.+)\ \-\ (?P<year>.+)'
    assert pp.format_to_regex(r'%(artist)s - %(year)s') == r'(?P<artist>.+)\ \-\ (?P<year>.+)'

# Generated at 2022-06-22 09:21:32.272398
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import unittest
    import sys

    if sys.version_info[0] == 2:
        def assertRegex(s1, s2):
            assert re.search(s2, s1) is not None

        def assertNotRegex(s1, s2):
            assert re.search(s2, s1) is None

    class MetadataFromTitlePPTest(unittest.TestCase):
        def test_format_to_regex(self):
            pp = MetadataFromTitlePP(None, None)

            # Regular strings
            self.assertRegex(pp.format_to_regex('test'), '^test$')
            self.assertRegex(pp.format_to_regex('test%(a)s'), '^test%\\(a\\)s$')

            # Regular strings with %(

# Generated at 2022-06-22 09:21:41.670863
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .downloader import YoutubeDL

    title = 'The Doors - People Are Strange'

# Generated at 2022-06-22 09:21:49.674509
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP('downloader', '%(artist)s - %(title)s')
    assert pp._titleformat == '%(artist)s - %(title)s'
    assert pp._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'

    pp = MetadataFromTitlePP('downloader', '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '%(title)s'



# Generated at 2022-06-22 09:21:54.998163
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Import being done here just to avoid messing with PYTHONPATH
    # if someone wants to import the module in some other way.
    from ..YoutubeDL import YoutubeDL
    from ..compat import compat_str
    # A dictionary containing a title and other available metadata
    info = {'title': 'Test Title'}

    # Initialize the postprocessor
    pp = MetadataFromTitlePP(YoutubeDL(), "%(title)s")

    # Test for a title that matches the regex
    info['title'] = 'Test Title'
    pp.run(info)
    assert info['title'] == 'Test Title'


    # Test for a title that does not match the regex
    info['title'] = 'No Match Here'
    pp.run(info)
    assert info['title'] == 'No Match Here'


    # Test for

# Generated at 2022-06-22 09:21:56.332884
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    MetadataFromTitlePP(None, '%(title)s - %(artist)s')

# Generated at 2022-06-22 09:22:07.513268
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class _FakeDownloader(object):
        def to_screen(self, msg):
            pass

    fake_downloader = _FakeDownloader()

    pp = MetadataFromTitlePP(fake_downloader, '%(a)s - %(b)s')
    info = {}

    info['title'] = 'foo - bar'
    pp.run(info)
    assert info == {'title': 'foo - bar', 'a': 'foo', 'b': 'bar'}

    info['title'] = 'foo - bar - baz'
    pp.run(info)
    assert info == {'title': 'foo - bar - baz', 'a': 'foo', 'b': 'bar - baz'}

    pp = MetadataFromTitlePP(fake_downloader, '%(a)s')
    info = {}


# Generated at 2022-06-22 09:22:18.827399
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader

# Generated at 2022-06-22 09:22:30.440137
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    p = MetadataFromTitlePP('fake_downloader', 'fake_title')
    assert p.format_to_regex('%(a)s') == '(?P<a>.+)'
    assert p.format_to_regex('%(a)s - %(b)s') == '(?P<a>.+)\ \-\ (?P<b>.+)'
    assert p.format_to_regex('%(a)s - %(b)s - ') == '(?P<a>.+)\ \-\ (?P<b>.+)\ \-\ '
    assert p.format_to_regex('%(a)s - %(b)s - ') == '(?P<a>.+)\ \-\ (?P<b>.+)\ \-\ '
    assert p.format_to_

# Generated at 2022-06-22 09:22:45.067843
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # pylint: disable=unused-argument
    def run(self, info):
        return info

    # Test no conversion for formatting specification without %(...)s
    instance = MetadataFromTitlePP('youtube-dl', '%(uploader)s')
    assert instance.format_to_regex('%(uploader)s') == '%(uploader)s'
    setattr(MetadataFromTitlePP, 'run', run)
    info = {'title': 'John Doe'}
    err_msg = 'MetadataFromTitlePP_run method failed'
    assert MetadataFromTitlePP.run(instance, info) == info, err_msg

    # Test for no formatting specification
    instance = MetadataFromTitlePP('youtube-dl', '%(uploader)s')

# Generated at 2022-06-22 09:22:55.617702
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(site)s')
    assert pp._titleformat == '%(title)s - %(site)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<site>.+)'

    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '%(title)s'

    pp = MetadataFromTitlePP(None, '%(title)s - site')
    assert pp._titleformat == '%(title)s - site'
    assert pp._titleregex == '(?P<title>.+)\ \-\ site'


# Generated at 2022-06-22 09:23:04.914688
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Set up dummy objects
    ydl = type('YDL', (object,), dict(to_screen = lambda *a, **kw: None))()
    pp = MetadataFromTitlePP(
        ydl, '%(uploader)s - %(track)s - %(artist)s (%(year)i).%(ext)s')
    info = dict(uploader='The Who', track='Baba O\'Riley',
                artist='The Who', year='1971', ext='flac',
                title='The Who - Baba O\'Riley - The Who (1971).flac')

    # Run the processing
    _, info = pp.run(info)

    # Check the result
    assert info['uploader'] == 'The Who'
    assert info['track'] == 'Baba O\'Riley'

# Generated at 2022-06-22 09:23:13.230214
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from . import FakeYDL
    from .extractor import YoutubeIE

    ydl = FakeYDL()
    ydl.add_info_extractor(YoutubeIE())

    # Youtube title:
    #   <literal>The Weeknd - Can’t Feel My Face (Audio)</literal>
    # Title regex:
    #   <literal>The\ Weeknd\ -\ Can’t\ Feel\ My\ Face\ \(Audio\)</literal>
    titleformat = 'The Weeknd - Can’t Feel My Face (Audio)'

# Generated at 2022-06-22 09:23:21.924709
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None,
                             '%(title)s - %(artist)s [%(website)s-%(year)s]')

    assert(pp._titleformat == '%(title)s - %(artist)s [%(website)s-%(year)s]')
    assert(pp._titleregex ==
           r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \[(?P<website>.+)\-(?P<year>.+)\]')


# Generated at 2022-06-22 09:23:27.318588
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    test_cases = [
        ('%(title)s', r'(?P<title>.+)'),
        ('%(title)s - %(artist)s', r'(?P<title>.+)\ \-\ (?P<artist>.+)'),
        ('%(title)s-%(artist)s', r'(?P<title>.+)\-(?P<artist>.+)'),
        ('', ''),
        ('-', r'\-')
    ]
    titleregexs = [MetadataFromTitlePP(None, fmt).format_to_regex(fmt)
                   for fmt in list(zip(*test_cases))[0]]
    assert titleregexs == list(zip(*test_cases))[1]

# Generated at 2022-06-22 09:23:37.505445
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    test_cases = {
        '%(title)s - %(artist)s': r'(?P<title>.+)\ \-\ (?P<artist>.+)',
        '%(id)s - %(title)s': r'(?P<id>.+)\ \-\ (?P<title>.+)',
    }
    for fmt, expected in test_cases.items():
        test_case = MetadataFromTitlePP(None, fmt)
        assert re.match(expected, test_case._titleregex)
        assert test_case._titleregex == test_case.format_to_regex(fmt)


# Generated at 2022-06-22 09:23:48.752435
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    obj = MetadataFromTitlePP(None, None)
    assert obj.format_to_regex('%(title)s - %(artist)s') == '%(title)s\\ \\-\\ %(artist)s'
    assert obj.format_to_regex('%(title)s - %(rest)s') == '%(title)s\\ \\-\\ %(rest)s'
    assert obj.format_to_regex('%(title)s') == '%(title)s'
    assert obj.format_to_regex('') == ''
    assert obj.format_to_regex('%(title)s - %(rest)s - %(rest2)s') == '%(title)s\\ \\-\\ %(rest)s\\ \\-\\ %(rest2)s'
    assert obj

# Generated at 2022-06-22 09:24:00.009891
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    class Dummy_Downloader():
        def __init__(self):
            self.to_screen_list = []

        def to_screen(self, msg):
            self.to_screen_list.append(msg)

    d = Dummy_Downloader()
    pp = MetadataFromTitlePP(d, '%(title)s')
    assert '%(title)s' == pp._titleformat
    assert '(?P<title>.+)' == pp._titleregex

    pp = MetadataFromTitlePP(d, '%(title)s - %(artist)s')
    assert '%(title)s - %(artist)s' == pp._titleformat
    assert '(?P<title>.+)\ \-\ (?P<artist>.+)' == pp._titleregex


# Generated at 2022-06-22 09:24:07.988010
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from metadata_from_title import MetadataFromTitlePP
    mpp = MetadataFromTitlePP(None, None)

    assert mpp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert mpp.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert mpp.format_to_regex('%(title)s - ') == r'(?P<title>.+)\ \-'
    assert mpp.format_to_regex(' - %(title)s') == r'\-\ (?P<title>.+)'

# Generated at 2022-06-22 09:24:20.453447
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import FileDownloader
    downloader = FileDownloader({})
    pp = MetadataFromTitlePP(downloader, '%(artist)s - %(title)s')
    title = pp.format_to_regex('%(artist)s - %(title)s')
    assert title == r'(?P<artist>.+)\ \-\ (?P<title>.+)'



# Generated at 2022-06-22 09:24:26.114058
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import prepare_mock_downloader
    from . import YoutubeIE

    ydl = prepare_mock_downloader({},
                                  {'url': 'http://example.com',
                                   'title': 'Unit Test Title - Unit Test Artist'})

    ie = YoutubeIE(ydl)
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s'))

    ie.extract(url='http://example.com',
               ie_key=ie.ie_key())

    assert ydl.downloader.meta['title'] == 'Unit Test Title'
    assert ydl.downloader.meta['artist'] == 'Unit Test Artist'


# Generated at 2022-06-22 09:24:29.917926
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleregex == '(?P<title>.+) - (?P<artist>.+)'

# Generated at 2022-06-22 09:24:40.570477
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()

    # Method format_to_regex is a static method
    # for simplicity it is tested as a part of class MetadataFromTitlePP
    # because of this class has already all required dependencies

    testCases = [
        # (titleformat, regex)
        ('%(title)s - %(artist)s', r'(?P<title>.+)\ \-\ (?P<artist>.+)'),
        ('%(title)s', r'(?P<title>.+)'),
        ('%(title)sx%(artist)s', r'(?P<title>.+)x(?P<artist>.+)'),
        ('%(title)sx', r'(?P<title>.+)x')
    ]


# Generated at 2022-06-22 09:24:50.321441
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class FakeDownloader(object):
        def __init__(self):
            self.to_screen_calls = []

        def to_screen(self, text):
            self.to_screen_calls.append(text)

    dl = FakeDownloader()

    # Test with "%(title)s - %(artist)s" and
    # info['title']="Testtitle - Testartist"

    info = {'title': 'Testtitle - Testartist'}
    pp = MetadataFromTitlePP(dl, '%(title)s - %(artist)s')

    pp.run(info)

    assert info['title'] == 'Testtitle'
    assert info['artist'] == 'Testartist'

# Generated at 2022-06-22 09:24:58.860207
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # input data
    info_input = {'title': 'abc - 2016'}
    titleregex_input = '(?P<name>.*)\ \-\ (?P<year>\d*)'
    # expected output data
    info_output = {'title': 'abc - 2016', 'name': 'abc', 'year': '2016'}
    # create object under test
    pp = MetadataFromTitlePP(None, titleregex_input)
    # run test
    assert pp.run(info_input) == ([], info_output)
    assert pp.run(info_input)[1]['title'] == info_output['title']
    assert pp.run(info_input)[1]['name'] == info_output['name']

# Generated at 2022-06-22 09:25:03.123279
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert MetadataFromTitlePP(None, '%(artist)s - %(title)s').run({'title': 'foo - bar'}) == ([], {'artist': 'foo', 'title': 'bar'})
    assert MetadataFromTitlePP(None, '%(artist)s - %(title)s').run({'title': 'foo'}) == ([], {'title': 'foo'})


# Generated at 2022-06-22 09:25:13.140227
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mfTP = MetadataFromTitlePP(None, None)
    assert mfTP.format_to_regex('Album: %(album)s') == r'Album:\ (?P<album>.+)'
    assert mfTP.format_to_regex('Album - %(artist)s - Song: %(title)s') == r'Album\ \-\ (?P<artist>.+)\ \-\ Song:\ (?P<title>.+)'
    assert mfTP.format_to_regex('Artist: %(artist)s, Title: %(title)s, Album: %(album)s') == r'Artist:\ (?P<artist>.+),\ Title:\ (?P<title>.+),\ Album:\ (?P<album>.+)'

# Generated at 2022-06-22 09:25:18.293251
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # type: () -> None
    mtt = MetadataFromTitlePP(None, '%(foo)s - %(bar)s')
    assert mtt.format_to_regex('%(foo)s - %(bar)s') == '(?P<foo>.+)\ \-\ (?P<bar>.+)'

# Generated at 2022-06-22 09:25:29.271555
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import Downloader
    import yaml

    yaml_spec = """
        title: "[Doki] NagiAsu - 04 (1280x720 h264 AAC) [3098C39D].mkv"
        description: "TV anime Nagi no Asukara"
        uploader: "-Doki-"
        """

    objPP = MetadataFromTitlePP(Downloader(),
                                '%(uploader)s - %(title)s')
    expected_results = [
        '[fromtitle] parsed uploader: -Doki-',
        '[fromtitle] parsed title: Nagi no Asukara - 04 (1280x720 h264 AAC) [3098C39D].mkv'
    ]

    dct = yaml.load(yaml_spec)
    dct_results, dct_info = obj

# Generated at 2022-06-22 09:25:41.490833
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    p1 = MetadataFromTitlePP(None, None)
    assert p1.format_to_regex('abc') == 'abc'
    assert p1.format_to_regex('%(abc)s') == '(?P<abc>.+)'
    assert p1.format_to_regex('%(abc)s%(def)s') == '(?P<abc>.+)(?P<def>.+)'
    assert p1.format_to_regex('%(abc)s %(def)s') == '(?P<abc>.+)\ (?P<def>.+)'

# Generated at 2022-06-22 09:25:52.631368
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    class FakeYoutubeDL:
        def to_screen(self, msg): print("msg:" + msg)
    pp = MetadataFromTitlePP(FakeYoutubeDL(), '%(artist)s - %(title)s')
    assert pp.format_to_regex("") == ""
    assert pp.format_to_regex("abc") == "abc"
    assert pp.format_to_regex("%(artist)s - %(title)s") == (
        r'(?P<artist>.+)\ \-\ (?P<title>.+)')
    assert pp.format_to_regex("%(artist)s - %(title)s - abcd") == (
        r'(?P<artist>.+)\ \-\ (?P<title>.+)\ \-\ abcd')

    assert pp._title

# Generated at 2022-06-22 09:26:00.283273
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # pylint: disable=protected-access
    # assertEqual() is overrided in the unit test
    assert MetadataFromTitlePP(None, '%(artist)s - %(title)s')._titleregex == (r'(?P<artist>.+)\ \-\ (?P<title>.+)')
    assert MetadataFromTitlePP(None, '%(artist)s - %(title)s')._titleformat == '%(artist)s - %(title)s'

    assert MetadataFromTitlePP(None, '%(artist)s - %(title)s - %(album)s')._titleregex == (r'(?P<artist>.+)\ \-\ (?P<title>.+)\ \-\ (?P<album>.+)')

# Generated at 2022-06-22 09:26:06.064270
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp.format_to_regex('Some title - Some artist') == (
        r'(?P<title>.+)\ \-\ (?P<artist>.+)')
    assert pp.format_to_regex('%%(title)s - %(artist)s') == (
        r'%\(title\)s\ \-\ (?P<artist>.+)')


# Generated at 2022-06-22 09:26:17.225099
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # normal case
    assert(MetadataFromTitlePP(None, '%(title)s - %(artist)s')
           ._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)')

    # only one group
    assert(MetadataFromTitlePP(None, '%(title)s')
           ._titleregex == '(?P<title>.+)')

    # no groups
    assert(MetadataFromTitlePP(None, 'non-title-format')
           ._titleregex == 'non-title-format')

    # groups in incorrect order
    assert(MetadataFromTitlePP(None, '%(artist)s - %(title)s')
           ._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)')

    # backslash escaping


# Generated at 2022-06-22 09:26:28.325812
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from sys import stderr
    from io import StringIO

    # Class metatdata (see parent class PostProcessor)
    class_name = 'MetadataFromTitlePP'
    name = 'fromtitle'
    description = 'Parse metadata out of the title'

    # Arguments for the method run
    info = {'title': 'DummyTitle'}

    results = []
    results.append(
        {
            # Arguments unchanged
            'info': info.copy(),
            # Return empty list
            'result': [],
            # Target for output streams
            'stderr': StringIO(),
            # Print to stderr, debug level 'notice'
            'stderr_output': '[fromtitle] Could not interpret title of video as "DummyFormat"\n'
        })

# Generated at 2022-06-22 09:26:34.156385
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    p = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert re.match(p._titleregex, 'One More Time - Daft Punk')
    assert p._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'



# Generated at 2022-06-22 09:26:42.201895
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    dldr = object()
    pp = MetadataFromTitlePP(dldr, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    pp = MetadataFromTitlePP(dldr, 'some string')
    assert pp._titleformat == 'some string'
    assert pp._titleregex == 'some string'


# Generated at 2022-06-22 09:26:50.940711
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == r'(?P<title>.+)'

# Generated at 2022-06-22 09:27:00.120954
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert ('(?P<artist>.+)\ \-\ (?P<title>.+)' ==
            MetadataFromTitlePP(None, '%(artist)s - %(title)s').format_to_regex(
                '%(artist)s - %(title)s'))
    assert ('(?P<artist>.+)\ \-\ (?P<title>.+)' ==
            MetadataFromTitlePP(None, 'blabla %(artist)s - %(title)s blabla').format_to_regex(
                'blabla %(artist)s - %(title)s blabla'))

# Generated at 2022-06-22 09:27:16.537315
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FakeYDL
    from .compat import compat_urllib_parse_unquote

    ydl = FakeYDL()
    ydl.params['format'] = 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'
    ydl.params['metadatafromtitle'] = '%(artist)s - %(track)s - %(title)s'

    pp = MetadataFromTitlePP(ydl, ydl.params.get('metadatafromtitle'))

    info_dict = {'title': compat_urllib_parse_unquote('Queen - Don\'t Stop Me Now (Official Video)')}
    pp.run(info_dict)

# Generated at 2022-06-22 09:27:20.281577
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test for method MetadataFromTitlePP.run
    # Assume that
    #     self._downloader.to_screen has printed the correct result
    return

if __name__ == '__main__':
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-22 09:27:30.059886
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import unittest

    # Dummy class for storing YouTubeDL options
    class YDL_Options(object):
        def __init__(self):
            self.verbose = True

    class YDL_Downloader(object):
        def __init__(self):
            self.params = {}

        def to_screen(self, str):
            pass

    class TestDummy(unittest.TestCase):
        def test_constructor(self):
            # title format: "%(artist)s - %(title)s"
            pp = MetadataFromTitlePP(YDL_Downloader(), r'%\(artist\)s - %\(title\)s')
            self.assertEqual(pp._titleformat, r'%(artist)s - %(title)s')

# Generated at 2022-06-22 09:27:39.801952
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor.common import InfoExtractor
    class MockIE(InfoExtractor):
        def __init__(self, downloader=None):
            self.downloaded_info_dicts = []

        @staticmethod
        def suitable(url):
            return True

        def download_result_hook(self, ie, info_dict):
            self.downloaded_info_dicts.append(info_dict)

    # Prepare FileDownloader object
    downloader = FileDownloader(params={})
    downloader.add_info_extractor(MockIE())

    # Prepare MetadataFromTitlePP object
    titleformat = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(downloader, titleformat)

    # Test a string matching titleformat
   

# Generated at 2022-06-22 09:27:50.403346
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    postprocessor = lambda d, t: MetadataFromTitlePP(d, t)


# Generated at 2022-06-22 09:27:56.359698
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor import YoutubeIE
    from .compat import compat_urllib_request
    import youtube_dl

    info = {'title': 'abc - xyz'}
    pp = MetadataFromTitlePP(FileDownloader({}), '%(title)s')
    pp.run(info)
    assert 'title' in info
    assert info['title'] == 'abc'

    info = {'title': 'abc - xyz'}
    pp = MetadataFromTitlePP(FileDownloader({}), '%(title)s - %(something)s')
    pp.run(info)
    assert 'title' in info and 'something' in info
    assert info['title'] == 'abc'
    assert info['something'] == 'xyz'


# Generated at 2022-06-22 09:27:56.914265
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass

# Generated at 2022-06-22 09:28:07.005648
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import FileDownloader
    from .YoutubeDL import YoutubeDL
    from .compat import compat_str
    from .extractor import get_info_extractor
    from .postprocessor import PostProcessingError
    from .utils import WrappedFile

    def _fakedl(filename, **kwargs):
        with open(filename, 'rb') as f:
            return WrappedFile(f, 'rb', kwargs)

    def _fakepp(filename, info):
        return filename, info

    def run_test(ytdl, titleformat, video_id, video_title, expected_regex):
        # mock _fetch_metadata method
        info = {'title': video_title}
        ytdl._fetch_metadata = lambda *args, **kwargs: info
        # mock downloader
        y

# Generated at 2022-06-22 09:28:18.390447
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    print('Testing title regex compilation and parsing')

    # Test 1: single value
    title_pp = MetadataFromTitlePP(None, '%(title)s')
    regex = title_pp._titleregex
    assert regex == r'(?P<title>.+)'

    title = 'Angra - Angels Cry'
    match = re.match(regex, title)
    assert match.groups() == ('Angels Cry',)
    assert match.groupdict() == {'title': 'Angels Cry'}

    # Test 2: several values
    title_pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    regex = title_pp._titleregex
    assert regex == r'(?P<artist>.+)\ \-\ (?P<title>.+)'


# Generated at 2022-06-22 09:28:26.529051
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .compat import compat_urllib_request

    # Test 1: get one simple attribute from title
    regex = 'title: (?P<title>.+)'
    title = 'title: foo'
    expected_subs = {'title': 'foo'}
    actual_subs = {}

    downloader = compat_urllib_request.FancyURLopener()
    pp = MetadataFromTitlePP(downloader, regex)
    _, subs = pp.run({'title': title})
    actual_subs.update(subs)

    assert expected_subs == actual_subs

    # Test 2: get two attributes from title (order is not important)
    regex = '%(artist)s - %(title)s'
    title = 'foo - bar'

# Generated at 2022-06-22 09:28:45.926121
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ydl import YDL
    from ydl.version import __version__
    from collections import namedtuple

    YdlInfo = namedtuple(
        'YdlInfo',
        'title artist album tracknumber creator')

    y = YDL()
    y.params['extract_flat'] = 'in_playlist'
    y.params['format'] = 'best'


# Generated at 2022-06-22 09:28:56.661309
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Set class attributes of a dummy PostProcessor
    PostProcessor.pp_args = ['fromtitle']
    PostProcessor.pp_kwargs = {'titleformat': '%(title)s - %(artist)s'}

    # Simulate downloader and video
    downloader = object()
    video = object()
    video.title = 'Lena - Satellite'
    video.player_url = 'http://example.com/'
    video.player_config_args = ()

    # Create class object
    pp = MetadataFromTitlePP(downloader, PostProcessor.pp_kwargs['titleformat'])

    # Call method to test
    info = {}
    video.__dict__.update(info)
    PostProcessor.run(pp, video)

    # Check if info has been updated

# Generated at 2022-06-22 09:29:07.068067
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    """
    Checks that MetadataFromTitlePP.format_to_regex() works as expected.
    """
    test_format = '%(artist)s - %(song)s'
    test_regex = r'(?P<artist>.+)\ \-\ (?P<song>.+)'
    mp3pp = MetadataFromTitlePP(None, test_format)
    assert mp3pp._titleregex == test_regex

    test_format = '%(artist)s - %(song)s [%(quality)s]'
    test_regex = r'(?P<artist>.+)\ \-\ (?P<song>.+)\ \[(?P<quality>.+)\]'
    mp3pp = MetadataFromTitlePP(None, test_format)

# Generated at 2022-06-22 09:29:16.427457
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import ytdl_suite
    test_str = ytdl_suite.get_test_string()
    downloader = ytdl_suite.test_downloader_class(params={'videopassword': 'secret'})

    # Create MetadataFromTitlePP object with some format string
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(album)s')

    # Create dictionary of video informations.
    # Note: The title is taken from the format string.

# Generated at 2022-06-22 09:29:23.563628
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, None).format_to_regex(
        '%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, None).format_to_regex(
        'hulahop.%(ext)s') == 'hulahop\.(?P<ext>.+)'
    assert MetadataFromTitlePP(None, None).format_to_regex(
        'bla-bla-bla.%(ext)s?extra') == 'bla\-bla\-bla\.(?P<ext>.+)\?extra'

# Generated at 2022-06-22 09:29:30.560979
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mft = MetadataFromTitlePP(None, None)
    assert mft.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert mft.format_to_regex('%(title)s (?P<artist>.*)') == r'(?P<title>.+)\ \(?P<artist>.*\)'
    assert mft.format_to_regex('%(title)s') == r'(?P<title>.+)'

# Generated at 2022-06-22 09:29:37.661089
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # Asserts the string converted to a regex is the expected regex
    def _assert_fmt_to_regex(fmt, regex):
        assert MetadataFromTitlePP(None, fmt).format_to_regex(fmt) == regex

    # Test with a simple string without any metadata field
    _assert_fmt_to_regex('foo', 'foo')
    # Test with string containing only one metadata field
    _assert_fmt_to_regex('%(foo)s', '(?P<foo>.+)')
    # Test with string containing only two metadata fields
    _assert_fmt_to_regex('%(foo)s%(bar)s', '(?P<foo>.+)(?P<bar>.+)')
    # Test with a string containing metadata fields, separators, and some
    # metadata fields with

# Generated at 2022-06-22 09:29:47.361439
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.downloader import YoutubeDL
    from youtube_dl.YoutubeDL import YoutubeDL
    from .YoutubeDL import YoutubeDL
    from .common import FileDownloader
    from .FileDownloader import FileDownloader
    from .extractor.youtube import YoutubeIE
    from .extractor.common import InfoExtractor
    from .InfoExtractor import InfoExtractor
    from .jsinterp import JSInterpreter
    from .postprocessor.ffmpeg import FFmpegExtractAudioPP
    from .postprocessor.ffmpeg import FFmpegVideoConvertor
    from .postprocessor.ffmpeg import FFmpegMergerPP
    from .postprocessor.common import PostProcessingError
    from .xattrpp import XAttrMetadataPP
    from .embedthumbnail import EmbedThumbnailPP
    from .postprocessor import get_postprocessor

   

# Generated at 2022-06-22 09:29:52.670539
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(object(), '')
    assert pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert pp.format_to_regex('') == ''



# Generated at 2022-06-22 09:29:57.286341
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp._titleformat == '%(artist)s - %(title)s'
    assert pp._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'



# Generated at 2022-06-22 09:30:22.135451
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl.YoutubeDL
    import tests
    downloader = youtube_dl.YoutubeDL({
        'format': 'best',
        'quiet': True,
        'forcefilename': True,
    })
    tests.get_testcases_from_annotations(
        MetadataFromTitlePP(downloader, '%(title)s - %(artist)s'),
        downloader)

# Generated at 2022-06-22 09:30:29.420112
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys


# Generated at 2022-06-22 09:30:39.374438
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ..YoutubeDL import YoutubeDL
    from collections import defaultdict
    defaultinfo = defaultdict(lambda: '',
                              title='title',
                              description='description',
                              uploader='uploader',
                              view_count='view_count')

    #Test with regex without named groups
    pp_regex = MetadataFromTitlePP(YoutubeDL({}), '%(title)s')
    assert pp_regex.run(defaultinfo)[1] == defaultinfo

    #Test with regex with named groups
    pp_regex = MetadataFromTitlePP(YoutubeDL({}), '%(title)s - %(description)s')
    assert pp_regex.run(defaultinfo)[1] == defaultinfo


# Generated at 2022-06-22 09:30:45.017488
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-22 09:30:56.137534
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    assert pp.format_to_regex('%(title)s - %(artist)s') == \
        '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s - %(album)s') == \
        '(?P<title>.+)\\ \\-\\ (?P<artist>.+)\\ \\-\\ (?P<album>.+)'
    assert pp.format_to_regex('abc%(title)s - %(artist)s - %(album)s') == \
        'abc(?P<title>.+)\\ \\-\\ (?P<artist>.+)\\ \\-\\ (?P<album>.+)'
    assert pp.format_to