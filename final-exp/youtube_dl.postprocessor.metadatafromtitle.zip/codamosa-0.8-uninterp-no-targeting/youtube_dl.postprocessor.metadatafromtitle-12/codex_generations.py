

# Generated at 2022-06-22 09:21:11.497148
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    m = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert(m._titleregex == r'(?P<artist>.+)\ \-\ (?P<title>.+)')
    m = MetadataFromTitlePP(None, '%(artist)s -')
    assert(m._titleregex == r'(?P<artist>.+)\ \-')
    m = MetadataFromTitlePP(None, '- %(title)s')
    assert(m._titleregex == r'\-\ (?P<title>.+)')
    # ordering of groups is maintained
    m = MetadataFromTitlePP(None, '%(title)s - %(artist)s -')

# Generated at 2022-06-22 09:21:22.155685
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .extractor import gen_extractors

    def _make_result(title):
        return {'title': title, 'id': 'test_id',
                'extractor': 'test_extractor'}

    _downloader = gen_extractors()[0]._downloader
    _downloader.params['writethumbnail'] = False
    _downloader.params['writesubtitles'] = False
    _downloader.params['writeautomaticsub'] = False

    _metadata = MetadataFromTitlePP(_downloader, '%(title)s - %(artist)s')
    assert _metadata.run(_make_result('my title - my artist')) == ([],
                                                                   {'artist': 'my artist', 'title': 'my title'})


# Generated at 2022-06-22 09:21:29.653644
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from_title_pp = MetadataFromTitlePP(None,
        '%(title)s - %(artist)s - %(album)s')
    assert from_title_pp.format_to_regex('%(title)s - %(artist)s - %(album)s') == '.+\ \-\ .+\ \-\ .+'
    assert from_title_pp.format_to_regex('%(artist)s - %(title)s') == '.+\ \-\ .+'
    assert from_title_pp.format_to_regex('%(title)s') == '.+'

# Generated at 2022-06-22 09:21:37.101396
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    '''
    Constructor of MetadataFromTitlePP class.
    '''
    downloader = None
    titleformat = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(downloader, titleformat)
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'



# Generated at 2022-06-22 09:21:42.437085
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    _dp = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(term)s')
    assert _dp._titleformat == '%(title)s - %(artist)s - %(term)s'
    assert _dp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<term>.+)'

    _dp = MetadataFromTitlePP(None, '%(title)s')
    assert _dp._titleformat == '%(title)s'
    assert _dp._titleregex == '%(title)s'

    _dp = MetadataFromTitlePP(None, 'foobar')
    assert _dp._titleformat == 'foobar'
    assert _dp._titleregex == 'foobar'


#

# Generated at 2022-06-22 09:21:49.760942
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    assert MetadataFromTitlePP.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s')._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, 'foo')._titleregex == 'foo'

# Generated at 2022-06-22 09:21:56.230608
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    mft = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert mft
    assert mft._titleformat == '%(title)s - %(artist)s'
    assert mft._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    mft = MetadataFromTitlePP(None, '%(title)s - %(artist)s %(title)s')
    assert mft._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)\ (?P<title>.+)'
    mft = MetadataFromTitlePP(None, '%(title)s')
    assert mft._titleregex == '(?P<title>.+)'

# Generated at 2022-06-22 09:22:07.423011
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftpp = MetadataFromTitlePP(None, "")

# Generated at 2022-06-22 09:22:15.816337
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from ydl.downloader import YoutubeDL
    dll = YoutubeDL()

    for titleformat in ['%(uploader)s', '%(title)s - %(artist)s']:
        pp = MetadataFromTitlePP(dll, titleformat)
        assert pp._titleformat == titleformat
        if re.search(r'%\(\w+\)s', titleformat):
            assert pp._titleregex == pp.format_to_regex(titleformat)
        else:
            assert pp._titleregex == titleformat


# Generated at 2022-06-22 09:22:26.967444
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    name = 'MetadataFromTitlePP'
    dl = DummyYDL({'outtmpl': '%(title)s.%(ext)s'})
    mp = MetadataFromTitlePP(dl, '%(Artist)s - %(Title)s')
    assert mp.name == name
    assert mp._titleformat == '%(Artist)s - %(Title)s'
    assert mp._titleregex == '(?P<Artist>.+)\ \-\ (?P<Title>.+)'

    # Check title regex conversion

# Generated at 2022-06-22 09:22:40.758262
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    import unittest
    class Test(unittest.TestCase):
        def test_it(self):
            from .common import PostProcessor
            pp = PostProcessor(None)
            self.assertEquals(pp.format_to_regex('%(title)s'), '(?P<title>.+)')
            self.assertEquals(pp.format_to_regex('%(title)s - %(artist)s'), '(?P<title>.+)\ \-\ (?P<artist>.+)')
            self.assertEquals(pp.format_to_regex(' %(title)s'), '\ (?P<title>.+)')
            self.assertEquals(pp.format_to_regex('%(title)s '), '(?P<title>.+)\ ')
    unittest.main()

# Generated at 2022-06-22 09:22:49.621183
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # init an object
    pp = MetadataFromTitlePP(None, "%(title)s - %(artist)s - %(album)s")
    # test
    assert pp.run({'title': "My title - My artist - My album"})[1] == {
        'title': 'My title', 'artist': 'My artist', 'album': 'My album'}
    assert pp.run({'title': "My title - My artist - My album"})[1] != {
        'title': 'My title', 'artist': 'My artist'}
    # test with an unparseable title
    assert pp.run({'title': "My title - My artist"})[1] == {'title': 'My title - My artist'}

# Generated at 2022-06-22 09:22:58.559900
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import ydl_utils

    class FakeDl:
        @staticmethod
        def to_screen(*args): pass

    class FakeInfo:
        def __init__(self, title):
            self['title'] = title

    # test with format without named groups
    pp = MetadataFromTitlePP(FakeDl(), '%(uploader)s')
    # test with string that doesn't match format
    info1 = [FakeInfo('abc'), FakeInfo('abc')]
    assert pp.run(info1) == ([], info1)
    # test with string that matches format
    info2 = [FakeInfo('xyz'), FakeInfo('xyz')]
    assert pp.run(info2) == ([], {'uploader': 'xyz'})

    # test with format with named groups

# Generated at 2022-06-22 09:23:09.151303
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test that the title is correctly extracted and formatted
    ydl = object()
    pp = MetadataFromTitlePP(ydl, "Title: %(title)s - %(artist)s")
    info1 = {'title': 'Title: Test Title - Test Artist'}
    _, result1 = pp.run(info1)
    assert result1['title'] == 'Test Title'
    assert result1['artist'] == 'Test Artist'

    # Test that the title is not extracted when no metadata is present
    info2 = {'title': 'Test Title - Test Artist'}
    _, result2 = pp.run(info2)
    assert result2['title'] is None
    assert result2['artist'] is None

    # Test that both MPEG-4 and MPEG-4 Dash URLs are present

# Generated at 2022-06-22 09:23:20.161487
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL

    # Constant shared among tests
    TITLE_FORMAT_1 = '%(title)s - %(artist)s'

    # Test with a valid title
    title_test = ('Bad English - When I See You Smile (1989) (HD 720p)')
    info_test = {'title': title_test}
    ydl_test = YoutubeDL()
    mf_pp = MetadataFromTitlePP(ydl_test, TITLE_FORMAT_1)
    _, info = mf_pp.run(info_test)
    assert info['title'] is None, info['title']
    assert info['artist'] is None, info['artist']

    # Test with a invalid title
    title_test = ('Bad English - When I See You Smile')

# Generated at 2022-06-22 09:23:30.477195
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Set up downloader
    downloader = 'downloader'

    # Set up info
    metadata = {'title': 'Mr. President - Coco Jambo'}
    expected_metadata = {'title': 'Mr. President - Coco Jambo',
                         'artist': 'Mr. President',
                         'song': 'Coco Jambo'}

    # Set up MetadataFromTitlePP object
    titleformat1 = '%(artist)s - %(song)s'
    titleformat2 = '%(title)s'
    for titleformat in [titleformat1, titleformat2]:
        pp = MetadataFromTitlePP(downloader, titleformat)
        (_list, info) = pp.run(metadata)
        assert info == expected_metadata

    # Set up MetadataFromTitlePP object

# Generated at 2022-06-22 09:23:40.137670
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import sys

    def _print(*args, **kwargs):
        print(args)

    inst = MetadataFromTitlePP(None, '%(artist)s')
    if inst is None:
        sys.exit(1)
    assert inst._titleformat == '%(artist)s'
    assert inst._titleregex == r'(?P<artist>.+)'

    inst = MetadataFromTitlePP(None, '%(artist)s-%(song)s')
    if inst is None:
        sys.exit(1)
    assert inst._titleformat == '%(artist)s-%(song)s'
    assert inst._titleregex == r'(?P<artist>.+)\-(?P<song>.+)'


# Generated at 2022-06-22 09:23:48.755411
# Unit test for constructor of class MetadataFromTitlePP

# Generated at 2022-06-22 09:23:55.347294
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Test constructor of MetadataFromTitlePP
    # It must be set correctly the format for title (preceded by %(..)s ) and
    # the regular expression used for matching
    fmt = "%(title)s - %(artist)s"
    regex = "(?P<title>.+)\ \-\ (?P<artist>.+)"
    pp = MetadataFromTitlePP(None, fmt)
    assert(regex == pp._titleregex)


# Generated at 2022-06-22 09:24:04.356937
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    class TestMetadataFromTitlPP(unittest.TestCase):
        def test_extract(self):
            titleformat = '%(title)s - %(artist)s'
            info = { 'title': 'Test - Foo Bar' }
            pp = MetadataFromTitlePP(None, titleformat)
            _, info = pp.run(info)
            
            self.assertEqual(info['title'], 'Test')
            self.assertEqual(info['artist'], 'Foo Bar')

        def test_no_extract(self):
            titleformat = '%(title)s - %(artist)s'
            info = { 'title': 'Test - Foo Bar', 'artist': 'Foo' }

# Generated at 2022-06-22 09:24:18.959538
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-22 09:24:26.984925
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-22 09:24:32.329797
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    mftpp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    info = {
        'title': 'Rage Against The Machine - Killing In The Name',
    }
    mftpp.run(info)
    assert info['artist'] == 'Rage Against The Machine'
    assert info['title'] == 'Killing In The Name'

# Generated at 2022-06-22 09:24:42.799003
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    assert MetadataFromTitlePP(None, "").to_regex_string() == ""
    assert MetadataFromTitlePP(None, "123").to_regex_string() == "123"
    assert MetadataFromTitlePP(None, "123%(title)s456").to_regex_string() == "123(?P<title>.+)456"
    assert MetadataFromTitlePP(None, "123%(title)s").to_regex_string() == "123(?P<title>.+)"
    assert MetadataFromTitlePP(None, "%(title)s456").to_regex_string() == "(?P<title>.+)456"
    assert MetadataFromTitlePP(None, "%(title)s").to_regex_string() == "(?P<title>.+)"

# Generated at 2022-06-22 09:24:48.586266
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    import unittest
    class TestCase(unittest.TestCase):
        def setUp(self):
            self.test_obj = MetadataFromTitlePP(None, None)

        def test_case1(self):
            format_string = '%(title)s - %(artist)s'
            regex = self.test_obj.format_to_regex(format_string)
            self.assertEqual(regex, '(?P<title>.+)\ \-\ (?P<artist>.+)')

        def test_case2(self):
            format_string = '%(title)s - %(artist)s - %(album)s'
            regex = self.test_obj.format_to_regex(format_string)

# Generated at 2022-06-22 09:24:56.866650
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class FakeYDL(object):
        def to_screen(self, msg):
            print(msg)

    class FakeInfoDict(dict):
        pass

    pp = MetadataFromTitlePP(FakeYDL(), '%(title)s - %(artist)s')
    info = FakeInfoDict()

    info['title'] = 'Lorem - Ipsum'
    video_info, video_info_new = pp.run(info)
    assert video_info == []
    assert video_info_new == {'title': 'Lorem', 'artist': 'Ipsum'}

    info['title'] = 'Lorem-Ipsum'
    video_info, video_info_new = pp.run(info)
    assert video_info == []

# Generated at 2022-06-22 09:25:02.068781
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    info = {'title': 'Video - Title'}
    pp = MetadataFromTitlePP(None, titleformat='%(title)s - %(artist)s')
    result = pp.run(info)
    assert(result[1]['title'] == 'Video')
    assert(result[1]['artist'] == 'Title')
    pp = MetadataFromTitlePP(None, titleformat='%(title)s')
    result = pp.run(info)
    assert(result[1] == info)

# Generated at 2022-06-22 09:25:13.386398
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .common import FileDownloader
    from .compat import compat_urllib_parse_urlparse

    ydl = FileDownloader({'format': 'best[protocol=https]'})
    ydl.add_info_extractor(u'Dummy')
    url = 'https://www.youtube.com/watch?v=6YCEh6sEzV0'
    ie = ydl._ies[0]
    # get fake info
    info = ie._real_extract(compat_urllib_parse_urlparse(url))
    assert info['title'] == '1'
    # apply postprocessor
    titleformat = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(ydl, titleformat)
    _, info = pp.run(info)

# Generated at 2022-06-22 09:25:22.548855
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.utils import DateRange
    from youtube_dl.downloader import YoutubeDL

    def ydl(*a, **k):
        pass


# Generated at 2022-06-22 09:25:32.315246
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .YoutubeDL import YoutubeDL
    from .compat import compat_str

    assert 'abc' == MetadataFromTitlePP(YoutubeDL(), 'abc').format_to_regex('abc')
    assert 'abc\ \-\ def' == MetadataFromTitlePP(YoutubeDL(), 'abc - def').format_to_regex('abc - def')
    assert 'A\ B\ \-\ C\ D' == MetadataFromTitlePP(YoutubeDL(), 'A B - C D').format_to_regex('A B - C D')

# Generated at 2022-06-22 09:25:41.443052
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    fmt = '%(artist)s - %(title)s'
    regex = MetadataFromTitlePP(None, fmt).format_to_regex(fmt)
    assert regex == r'(?P<artist>.+)\ \-\ (?P<title>.+)'

    fmt = '%(title)s'
    regex = MetadataFromTitlePP(None, fmt).format_to_regex(fmt)
    assert regex == r'(?P<title>.+)'

    fmt = '%(title)s-%(title)s'
    regex = MetadataFromTitlePP(None, fmt).format_to_regex(fmt)
    assert regex == r'(?P<title>.+)\-(?P<title>.+)'

    fmt = '%(title)s.%(title)s'
   

# Generated at 2022-06-22 09:25:47.410131
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from pytube.postprocessor import MetadataFromTitlePP

    fmt = '%(title)s - %(artist)s'
    regex = '^(?P<title>.+)\\ \-\\ (?P<artist>.+)$'

    assert MetadataFromTitlePP.format_to_regex(MetadataFromTitlePP, fmt) == regex

# Generated at 2022-06-22 09:25:55.738985
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    mp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    info = {
        'title': 'AC/DC - Back in Black'
    }
    mp.run(info)
    assert info['artist'] == 'AC/DC'
    assert info['title'] == 'Back in Black'

    mp = MetadataFromTitlePP(None, '%(title)s.%(ext)s')
    info = {
        'title': 'AC/DC - Back in Black'
    }
    mp.run(info)
    assert info['title'] == 'AC/DC - Back in Black.%(ext)s'

# Generated at 2022-06-22 09:26:04.387846
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(author)s - %(title)s')
    assert pp._titleformat == '%(author)s - %(title)s', 'error in constructor'
    assert pp._titleregex == '(?P<author>.+)\ \-\ (?P<title>.+)', 'error in constructor'

    pp = MetadataFromTitlePP(None, '%(author)s')
    assert pp._titleformat == '%(author)s', 'error in constructor'
    assert pp._titleregex == '%(author)s', 'error in constructor'

test_MetadataFromTitlePP()

# Generated at 2022-06-22 09:26:13.019887
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    postprocessor = MetadataFromTitlePP(None, '%(title)s')
    assert postprocessor.format_to_regex('%(title)s') == '(?P<title>.+)'

    postprocessor = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert postprocessor.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-22 09:26:20.085325
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Create a MetadataFromTitlePP object
    from youtube_dl import YoutubeDL
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor import MetadataFromTitlePP
    info = {'title': ' '}
    ydl = YoutubeDL()
    pp = MetadataFromTitlePP(ydl)

    # Empty title
    info_copy = info.copy()
    pp.run(info_copy)
    assert info == info_copy

    # Title with one group
    info = {'title': 'test value - '}
    m = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    pp.run(info)
    assert info['title'] == 'test value'

    # Title with two groups

# Generated at 2022-06-22 09:26:25.980673
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .abc import FakeYDL
    from .abc import DummyDownloader
    titleformat = '%(artist)s - %(song)s'
    downloader = DummyDownloader(FakeYDL())
    pp = MetadataFromTitlePP(downloader, titleformat)
    regex = re.compile('^(?P<artist>.+)\ \-\ (?P<song>.+)$')
    assert pp._titleregex == regex.pattern


# Generated at 2022-06-22 09:26:31.157813
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    import sys
    import pytest
    # If running unit tests, make it possible to import python modules
    # from parent directory
    sys.path.insert(0, '..')
    from postprocessor import MetadataFromTitlePP

    def get_regex(fmt):
        return MetadataFromTitlePP(None, fmt)._titleregex

    assert get_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert get_regex('%(title)s %(artist)s') == r'(?P<title>.+)\ (?P<artist>.+)'

# Generated at 2022-06-22 09:26:37.507658
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    class DummyDownloader:
        def to_screen(self, x):
            assert False, 'to_screen method should not be called'

    postprocessor = MetadataFromTitlePP(DummyDownloader(), '%(title)s - %(artist)s')
    assert postprocessor._titleformat == '%(title)s - %(artist)s'
    assert postprocessor._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-22 09:26:45.660531
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import Downloader
    from .downloader import FileDownloader
    from .extractor.common import InfoExtractor
    import sys
    import os
    import tempfile
    import shutil

    class DummyFileDownloader(FileDownloader):
        def __init__(self, *args, **kargs):
            super(DummyFileDownloader, self).__init__(*args, **kargs)
            self.to_screen = lambda *args, **kargs: None

    class DummyYoutubeIE(InfoExtractor):
        IE_NAME = 'DummyYoutubeIE'
        _VALID_URL = r'https?://.*/(?P<id>\w+)'


# Generated at 2022-06-22 09:27:01.545401
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .html import extractor
    from .extractor import Extractor
    from .YoutubeDL import YoutubeDL

    downloader = YoutubeDL({})


# Generated at 2022-06-22 09:27:11.527295
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, r'%(artist)s - %(song)s')
    assert pp._titleformat == pp._titleregex == r'%(artist)s - %(song)s'

    pp = MetadataFromTitlePP(None, r'%(artist)s - %(song)s - %(year)s')
    assert pp._titleformat == r'%(artist)s - %(song)s - %(year)s'
    assert pp._titleregex == r'(?P<artist>.+)\ \-\ (?P<song>.+)\ \-\ (?P<year>.+)'

# Generated at 2022-06-22 09:27:20.627441
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '')
    r = pp.format_to_regex('%(artist)s - %(title)s')
    assert re.match(r, 'foo - bar').groupdict()['artist'] == 'foo'
    assert re.match(r, 'foo - bar').groupdict()['title'] == 'bar'

    r = pp.format_to_regex('%(artist)s - %(title)s - %(album)s')
    assert re.match(r, 'foo - bar - baz').groupdict()['artist'] == 'foo'
    assert re.match(r, 'foo - bar - baz').groupdict()['title'] == 'bar'
    assert re.match(r, 'foo - bar - baz').groupdict()['album'] == 'baz'

# Generated at 2022-06-22 09:27:30.314356
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    test = MetadataFromTitlePP(None, '')
    assert test.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert test.format_to_regex('%(title)s - %(artist)s - %(duration)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<duration>.+)'

# Generated at 2022-06-22 09:27:39.981184
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-22 09:27:44.300741
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    extractor = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    expected_regex = r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert extractor._titleregex == expected_regex



# Generated at 2022-06-22 09:27:52.530404
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    class DummyDownloader():
        def to_screen(self, s):
            return None

    ydl = DummyDownloader()
    # Check conversion of format string to regex
    pp = MetadataFromTitlePP(ydl, r'%(title)s - %(artist)s')
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    # Check conversion of format string to regex with escaping
    pp = MetadataFromTitlePP(ydl, r'%(title)s-%(artist)s')
    assert pp._titleregex == r'(?P<title>.+)-(?P<artist>.+)'
    pp = MetadataFromTitlePP(ydl, r'%(title)s - %(artist)s')
    assert pp._titlere

# Generated at 2022-06-22 09:27:59.475630
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    titleformat = '%(title)s - %(artist)s'
    titleregex = MetadataFromTitlePP(None, titleformat)._titleregex
    assert re.match(titleregex, 'Some title - Some artist') is not None
    assert re.match(titleregex, 'Some title - ') is not None
    assert re.match(titleregex, ' - Some artist') is None
    assert re.match(titleregex, 'Some title') is None


# Generated at 2022-06-22 09:28:08.920790
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == r'(?P<title>.+)'

    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp._titleformat == '%(artist)s - %(title)s'
    assert pp._titleregex == r'(?P<artist>.+)\ \-\ (?P<title>.+)'

    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == r'(?P<title>.+)'


# Generated at 2022-06-22 09:28:19.908956
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    dl = type('dummy', (object,), {'to_screen': print})()

    # not format string, no match
    p = MetadataFromTitlePP(dl, 'not a format string')
    info = {'title': 'not a format string'}
    p.run(info)
    assert info == {'title': 'not a format string'}

    # wrong format string, no match
    p = MetadataFromTitlePP(dl, '%(title)s')
    info = {'title': 'wrong format string'}
    p.run(info)
    assert info == {'title': 'wrong format string'}

    # correct string, result as expected
    p = MetadataFromTitlePP(dl, '%(title)s - %(artist)s')

# Generated at 2022-06-22 09:28:39.918802
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    import unittest
    tests = [
        # The test string, the expected output
        ['%(artist)s - %(title)s', '(?P<artist>.+)\ \-\ (?P<title>.+)'],
        ['%(artist)s - %(title)s - %(album)s', '(?P<artist>.+)\ \-\ (?P<title>.+)\ \-\ (?P<album>.+)'],
    ]
    for fmt, expected in tests:
        mtt = MetadataFromTitlePP(None, fmt)
        result = mtt.format_to_regex(fmt)
        assert result == expected
    print('MetadataFromTitlePP.format_to_regex looks good!')

# Generated at 2022-06-22 09:28:47.889730
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Test case 1
    titleformat = '%(title)s - %(artist)s'
    titleregex = r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    # Expected output
    expected_titleregex = titleregex

    # Actual output
    mpft = MetadataFromTitlePP(None, titleformat)
    actual_titleregex = mpft._titleregex

    # Assertion
    assert expected_titleregex == actual_titleregex, 'Regex does not match'

    # Test case 2
    titleformat = '%(title)s - %(artist)s'
    titleregex = r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    # Expected output
    expected_titleregex = titleregex



# Generated at 2022-06-22 09:28:54.620877
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    tftest = MetadataFromTitlePP(None, '%(artist)s - %(title)s - %(#)03d')
    assert tftest._titleformat == '%(artist)s - %(title)s - %(#)03d'
    assert tftest._titleregex == r'(?P<artist>.+)\ \-\ (?P<title>.+)\ \-\ (?P<#>\d+)'



# Generated at 2022-06-22 09:29:04.733764
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    #import sys
    #sys.path.append("D:/_work/PyCharmProjects/youtube-dl/")
    import unittest
    import os
    import json
    from youtube_dl.PostProcessor.MetadataFromTitlePP import MetadataFromTitlePP
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self):
            YoutubeDL.__init__(self, {'writesubtitles': True})
            self.my_infos = []
            self.my_titles = []
            self.my_metadata = []

        def to_screen(self, msg):
            pass

        def to_stdout(self, msg):
            pass


# Generated at 2022-06-22 09:29:07.833698
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    regex = r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp._titleregex == regex


# Generated at 2022-06-22 09:29:16.453288
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Python 2
    from .common import FileDownloader
    titleformat = '%(autonumber)s-%(title)s-%(container)s'
    title = '10-this is a test title-mp4'

    metadata = {'title': title, 'autonumber': 0}
    # Instantiate downloader with a custom config (see test/test_configuration)
    downloader = FileDownloader({
        'outtmpl': '%(title)s-%(id)s.%(ext)s',
        'postprocessors': [{
            'key': 'MetadataFromTitle',
            'titleformat': titleformat,
        }],
    })
    postprocessor = MetadataFromTitlePP(downloader, titleformat)
    result, metadata = postprocessor.run(metadata)

# Generated at 2022-06-22 09:29:24.566928
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    pp = MetadataFromTitlePP(None, '%(artist)s')
    assert pp._titleformat == '%(artist)s'
    assert pp._titleregex == '(?P<artist>.+)'
    pp = MetadataFromTitlePP(None, '%(title)s-%(title)s')
    assert pp._titleformat == '%(title)s-%(title)s'
    assert pp._titleregex == '(?P<title>.+)-(?P<title>.+)'

# Unit

# Generated at 2022-06-22 09:29:33.281264
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Test to make sure that the regex created matches the format
    assert MetadataFromTitlePP(None, '%(artist)s - %(title)s')._titleregex == (
        '(?P<artist>.+)\ \-\ (?P<title>.+)')

    # Test to make sure that we can extract data from the format
    info = {'title': 'Artist - Title'}
    testPP = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    _, info = testPP.run(info)
    assert info == {'title': 'Title', 'artist': 'Artist'}


# Generated at 2022-06-22 09:29:38.950642
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None,
                               r'%(title)s - %(artist)s').format_to_regex(
                               r'%(title)s - %(artist)s'
                               ) == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-22 09:29:47.597006
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    import pytest

    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    pp = MetadataFromTitlePP(None, '%(test)s')
    assert pp.format_to_regex('%(test)s') == '(?P<test>.+)'

    pp = MetadataFromTitlePP(None, '%(test)s   ')
    assert pp.format_to_regex('%(test)s   ') == '(?P<test>.+)   '

    pp = MetadataFromTitlePP(None, '   %(test)s')
    assert pp.format_to_

# Generated at 2022-06-22 09:30:11.780823
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s')._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-22 09:30:19.891122
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .common import Downloader
    d = Downloader()

    info = {
        'title': 'The Title - The Artist',
        'webpage_url': 'https://www.youtube.com/watch?v=id',
        'id': 'id',
        'extractor': 'youtube:watch'
    }
    pp = MetadataFromTitlePP(d, '%(title)s - %(artist)s')
    pp.run(info)
    assert info['title'] == 'The Title'
    assert info['artist'] == 'The Artist'

    info = {
        'title': 'The Title - The Artist - The Album',
        'webpage_url': 'https://www.youtube.com/watch?v=id',
        'id': 'id',
        'extractor': 'youtube:watch'
    }


# Generated at 2022-06-22 09:30:27.516159
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from ytdl.extractor.common import YoutubeIE
    from ytdl.downloader.common import FileDownloader

    # Test: %(title)s - %(artist)s (Format)
    titleformat = '%(title)s - %(artist)s'
    regex = r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    metadata_from_title_pp = MetadataFromTitlePP(FileDownloader({}), titleformat)

    # Test: %(title)s - %(artist)s
    assert metadata_from_title_pp._titleregex == regex

    # Test: %(title)s - another string - %(artist)s
    titleformat = '%(title)s - another string - %(artist)s'

# Generated at 2022-06-22 09:30:30.086667
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    unit_test(pp._titleformat, pp._titleregex)



# Generated at 2022-06-22 09:30:37.479099
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Test 1
    titleformat = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(None, titleformat)
    assert pp._titleformat == titleformat
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    # Test 2
    titleformat = '%(title)s'
    pp = MetadataFromTitlePP(None, titleformat)
    assert pp._titleformat == titleformat
    assert pp._titleregex == titleformat


# Generated at 2022-06-22 09:30:48.510856
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import FileDownloader
    from .extractor import gen_extractors
    gen_extractors()
    pp = MetadataFromTitlePP(FileDownloader(), '%(upload_date)s')
    assert (pp.format_to_regex('bla bla %(upload_date)s fasel') ==
            r'bla\ bla\ (?P<upload_date>.+) fasel')
    assert (pp.format_to_regex('%(upload_date)s') ==
            r'(?P<upload_date>.+)')
    assert (pp.format_to_regex('bla%(upload_date)sbla') ==
            r'bla(?P<upload_date>.+)bla')

# Generated at 2022-06-22 09:30:54.983834
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Create a MetadataPP
    mp = MetadataFromTitlePP(None, '%(artist)s')
    # Create a sample info
    info = {
        'title': 'Metallica, Foo Fighters'
    }
    # Run the method, and check that it works
    assert mp.run(info)[1] == {
        'title': 'Metallica, Foo Fighters',
        'artist': 'Metallica, Foo Fighters'
    }


# Generated at 2022-06-22 09:31:05.207328
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .compat import compat_str
    from .postprocessor import metadata_from_title