

# Generated at 2022-06-22 09:21:06.281354
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import tempfile
    from youtube_dl.YoutubeDL import YoutubeDL
    titleformat = "%(title)s - %(artist)s"
    info = dict(title='My - title')
    # test is not applicable since we neither retrieve a file nor use --simulate
    pp = MetadataFromTitlePP(
        YoutubeDL(params={
            'writethumbnail': True,
            'simulate': True,
        }), titleformat)
    assert re.match(
        pp.format_to_regex(titleformat), info['title']) is None
    info['title'] = 'My - title - Feat. A'
    assert re.match(
        pp.format_to_regex(titleformat), info['title']) is not None
    pp.run(info)

# Generated at 2022-06-22 09:21:13.934478
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from collections import OrderedDict

    dl = YoutubeDL()
    dl.params['postprocessors'] = [{'key': 'MetadataFromTitlePP',
                                    'titleformat': '%(title)s - %(artist)s'}]
    info = OrderedDict([('title', 'An Awesome Song - Foo')])

    pp = dl.get_postprocessor(info)
    _, info = pp.run(info)

    assert info['artist'] == 'Foo'
    assert info['title'] == 'An Awesome Song'

# Generated at 2022-06-22 09:21:21.581239
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    pp = MetadataFromTitlePP(ydl, "%(title)s - %(artist)s")
    assert '%(title)s' in pp._titleformat
    assert '%(artist)s' in pp._titleformat
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-22 09:21:28.354852
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    class Dummy:
        def to_screen(self, msg):
            print(msg)

    downloader = Dummy()
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    pp = MetadataFromTitlePP(downloader, '%(title)s')
    assert pp._titleregex == '(?P<title>.+)'


# Generated at 2022-06-22 09:21:36.649782
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    mfTPP = MetadataFromTitlePP(None,
                                '%(artist)s - %(title)s [%(category)s] [%(upload_date)s]')
    # Test correct parse of date format
    assert mfTPP._titleregex == (
        '(?P<artist>.+)\\ \\-\\ (?P<title>.+)\\ \\[(?P<category>.+)\\]\\ \\[(?P<upload_date>.+)\\]')


# Generated at 2022-06-22 09:21:44.111161
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    methods_under_test = [
        ('downloader', 'YoutubeDL', 'yt_downloader'),
        ('postprocessors', 'MetadataFromTitlePP', 'metadatafromtitlepp'),
    ]

    def get_instance():
        from .common import downloader_factory
        from .extractor import gen_extractors
        from .postprocessor import gen_pp

        downloader = downloader_factory(gen_extractors(), gen_pp())
        pp = downloader.pp_confs.get('metadatafromtitlepp').get('pp', None)
        assert isinstance(pp, MetadataFromTitlePP)
        return pp._titleregex


# Generated at 2022-06-22 09:21:52.026341
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl import YoutubeDL
    from youtube_dl.utils import DateRange
    from .extractor.youtube import YoutubeIE
    downloader = YoutubeDL({})
    downloader.add_info_extractor(YoutubeIE())
    info = downloader.extract_info(
        'https://www.youtube.com/watch?v=Ey0f_A8Oa_A', download=False)
    assert not any(x.startswith('fromtitle') for x in info)
    info = MetadataFromTitlePP(downloader, '%(artist)s - %(title)s').run(info)[1]
    assert info.get('title') == 'The Chainsmokers & Coldplay - Something Just Like This (Lyric)'
    assert info.get('artist') == 'The Chainsmokers & Coldplay'

# Generated at 2022-06-22 09:22:04.387876
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader

    title = 'Some title, containing the artist name and the track name, 00:01:00'

    def check_complete(f):
        info = {'title': title}
        fmt = '%(artist)s - %(track)s'
        pp = MetadataFromTitlePP(f, fmt)
        pp.run(info)
        assert info['artist'] == 'Some title, containing the artist name'
        assert info['track'] == 'and the track name, 00:01:00'

    def check_missing_fields(f):
        info = {'title': 'Some title'}
        fmt = '%(artist)s - %(track)s'
        pp = MetadataFromTitlePP(f, fmt)
        pp.run(info)

# Generated at 2022-06-22 09:22:09.123384
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    ydl = object()
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'



# Generated at 2022-06-22 09:22:13.271376
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    assert MetadataFromTitlePP(
        None, '%(title)s - %(artist)s')._titleregex == (
            r'(?P<title>.+)\ \-\ (?P<artist>.+)')
    assert MetadataFromTitlePP(
        None, '%(artist)s')._titleregex == (
            r'(?P<artist>.+)')


# Generated at 2022-06-22 09:22:25.900842
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Uncomment and run the following code to test the method
    '''
    from __main__ import MetadataFromTitlePP
    downloader = None
    titleformat = '%(title)s - %(artist)s'
    titleregex = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    title = 'Zee - Ayman Nageeb'
    info = {'title': title}
    test = MetadataFromTitlePP(downloader, titleformat)
    regex = test._titleregex
    assert regex == titleregex
    a, b = test.run(info)
    for key, value in b.iteritems():
        print key, '=', value
    '''

# Generated at 2022-06-22 09:22:35.813683
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # when format contains no regex group
    mf1 = MetadataFromTitlePP(None, '%(title)s')
    assert mf1._titleformat == '%(title)s'
    assert mf1._titleregex == '%(title)s'

    # when format contains more than one regex group
    mf2 = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert mf2._titleformat == '%(title)s - %(artist)s'
    assert mf2._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    # when format contains non printable characters
    mf3 = MetadataFromTitlePP(None, '%(title)s\x00\x01')
    assert mf3._

# Generated at 2022-06-22 09:22:45.881684
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    mftpp = MetadataFromTitlePP('dummy downloader',
                                '%(artist)s - %(title)s')

    # Case 1: Title not of shape "artist - title"
    info = {}
    info['title'] = 'Unconventional title'
    result = mftpp.run(info)
    assert result == ([], info), (
        'Function should return ([], info) when title does not match expected format'
    )

    # Case 2: Title of shape "artist - title"
    info = {}
    info['title'] = 'Artist - Title'
    expected_info = {}
    expected_info['artist'] = 'Artist'
    expected_info['title'] = 'Title'
    result = mftpp.run(info)

# Generated at 2022-06-22 09:22:56.821743
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    mftpp = MetadataFromTitlePP(None, r'%(title)s')
    info = {
        'title': 'test',
        '_filename': 'video.mp4',
        'format': 'best'
    }
    list_empty = []
    assert mftpp.run(info) == (list_empty, info)
    assert info['title'] == 'test'
    mftpp = MetadataFromTitlePP(None, r'%(title)s %(test)s')
    info = {
        'title': 'test test',
        '_filename': 'video.mp4',
        'format': 'best'
    }
    list_empty = []
    assert mftpp.run(info) == (list_empty, info)
    assert info['title'] == 'test'
    assert info

# Generated at 2022-06-22 09:22:59.698648
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    song = MetadataFromTitlePP(
        downloader=None,
        titleformat='%(title)s - %(artist)s'
    )
    assert isinstance(song, MetadataFromTitlePP)

# Generated at 2022-06-22 09:23:09.858600
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # There are only whitespaces in the string, so no regex groups are added
    assert MetadataFromTitlePP(None, '   ').format_to_regex('   ') == '   '

    # There is no special format string "%(..)s" in the string, so the string
    # is escaped and no groups are added
    assert (MetadataFromTitlePP(None, ' - ').format_to_regex(' - ') ==
            r'\-\ \-' and
            MetadataFromTitlePP(None, ' a ').format_to_regex(' a ') ==
            r'\ a\ ')

    # There is one special format string "%(..)s" in the string, so the
    # string is escaped and one group is added

# Generated at 2022-06-22 09:23:20.928697
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class _InfoDict(dict):
        pass
    import sys
    _downloader = object()
    _downloader.to_screen = sys.stderr.write
    _downloader_mutables = ['to_screen']
    # assign _downloader to self for using in MetadataFromTitlePP
    # this is a workaround replacing the full functionality of YoutubeDL
    self = _downloader
    # assign to _InfoDict to make it available as global variable in
    # MetadataFromTitlePP
    InfoDict = _InfoDict
    # call method __init__ of MetadataFromTitlePP
    pp = MetadataFromTitlePP(self, '%(artist)s - %(title)s')
    assert hasattr(pp, '_titleformat')
    assert hasattr(pp, '_titleregex')
    assert pp._

# Generated at 2022-06-22 09:23:28.992390
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    mftpp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert mftpp._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'
    mftpp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert mftpp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    mftpp = MetadataFromTitlePP(None, 'abcabcabcabc')
    assert mftpp._titleregex == 'abcabcabcabc'

# Generated at 2022-06-22 09:23:39.501323
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    _, info = MetadataFromTitlePP(None,
                                  '%(title)s - %(artist)s')\
                        .run({'title': 'title - artist'})
    assert info['title'] == 'title'
    assert info['artist'] == 'artist'

    _, info = MetadataFromTitlePP(None,
                                  '%(title)s - %(artist)s')\
                        .run({'title': 'title - artist with - minues'})
    assert info['title'] == 'title'
    assert info['artist'] == 'artist with - minues'

    _, info = MetadataFromTitlePP(None,
                                  '%(title)s - %(artist)s')\
                        .run({'title': 'no match'})
    assert info['title'] == 'no match'
   

# Generated at 2022-06-22 09:23:48.708815
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, None).format_to_regex(
        '%(title)s - %(artist)s') == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, None).format_to_regex(
        '%(title)s - %(artist)s - (acoustic cover)') == (
            '(?P<title>.+)\\ \\-\\ (?P<artist>.+)\\ \\-\\ '
            '\((?P<acoustic>[^()]*)\)')

# Generated at 2022-06-22 09:24:01.132366
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, '').format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert MetadataFromTitlePP(None, '').format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, '').format_to_regex('%(title)s - %(artist)s - %(album)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'

# Generated at 2022-06-22 09:24:12.187207
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, '').format_to_regex(
        'nothing to group here') == 'nothing to group here'
    assert MetadataFromTitlePP(None, '').format_to_regex(
        '%(title)s - %(author)s') == '(?P<title>.+)\\ \\-\\ (?P<author>.+)'
    assert MetadataFromTitlePP(None, '').format_to_regex(
        '%(title)s - %(author)s - %(date)s') == (
            '(?P<title>.+)\\ \\-\\ (?P<author>.+)\\ \\-\\ (?P<date>.+)')

# Generated at 2022-06-22 09:24:13.474138
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # TODO: do it
    pass

# Generated at 2022-06-22 09:24:23.956569
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    fmt = '%(title)s - %(artist)s'
    regex = (r'(?P<title>.+)\ \-\ (?P<artist>.+)'
             if re.search(r'%\(\w+\)s', fmt)
             else fmt)
    title = 'Song title - Artist name'
    match = re.match(regex, title)
    assert match is not None
    assert match.groupdict() == {'title': 'Song title', 'artist': 'Artist name'}

    fmt = '%(title)s'
    regex = (r'(?P<title>.+)'
             if re.search(r'%\(\w+\)s', fmt)
             else fmt)
    title = 'Song title'
    match = re.match(regex, title)

# Generated at 2022-06-22 09:24:28.446604
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftPP = MetadataFromTitlePP(None, None)
    assert mftPP.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\\ \-\\ (?P<artist>.+)'
    assert mftPP.format_to_regex('%(title)s') == '(?P<title>.+)'

# Generated at 2022-06-22 09:24:38.955026
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .downloader import Downloader
    from .extractor import YoutubeIE
    from .postprocessor import FFmpegExtractAudioPP

    downloader = Downloader({
        'extractors': [YoutubeIE.ie_key()],
        'postprocessors': [FFmpegExtractAudioPP.pp_key()],
        'fromtitle': '%(artist)s - %(title)s'
    })
    downloader.add_info_extractor(YoutubeIE())
    downloader.add_post_processor(FFmpegExtractAudioPP())
    downloader.add_post_processor(MetadataFromTitlePP(downloader, '%(artist)s - %(title)s'))


# Generated at 2022-06-22 09:24:48.559314
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl
    import tempfile
    import shutil
    from .utils import make_mock_ydl

    tempdir = tempfile.mkdtemp()
    try:
        ydl = make_mock_ydl(tempdir)
        pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
        info = {'title': 'The title - The artist'}
        pp.run(info)
        assert info['title'] == 'The title'
        assert info['artist'] == 'The artist'
        assert ydl.msgs == ['[fromtitle] parsed title: The title',
                             '[fromtitle] parsed artist: The artist']

    finally:
        shutil.rmtree(tempdir)


# Generated at 2022-06-22 09:24:55.473832
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    regex = MetadataFromTitlePP(None, '%(artist)s - %(title)s')._titleregex
    assert_(regex == r'(?P<artist>.+)\ \-\ (?P<title>.+)')
    regex = MetadataFromTitlePP(None, '%(title)s')._titleregex
    assert_(regex == r'(?P<title>.+)')
    regex = MetadataFromTitlePP(None, '%(a)s%(b)s')._titleregex
    assert_(regex == r'(?P<a>.+)(?P<b>.+)')

# Generated at 2022-06-22 09:25:05.864301
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-22 09:25:14.748284
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Positive test cases
    MetadataFromTitlePP(None, '%(id)s%(uploader)s')
    MetadataFromTitlePP(None, '%(id)s - %(uploader)s')
    MetadataFromTitlePP(None, '%(id)s - %(upload_date)s - %(uploader)s')
    # Negative test cases
    try:
        MetadataFromTitlePP(None, '%(id)s - %(uploader')
        assert False, 'MetadataFromTitlePP() should have failed'
    except RegexMatchError:
        pass
    try:
        MetadataFromTitlePP(None, '%(id)s - %(uploader)')
        assert False, 'MetadataFromTitlePP() should have failed'
    except RegexMatchError:
        pass
   

# Generated at 2022-06-22 09:25:27.144001
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Simple case without regex groups
    pp = MetadataFromTitlePP(None, 'abcde')
    assert pp._titleformat == 'abcde'
    assert pp._titleregex == 'abcde'

    # regex group
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    # regex group with escape
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s [%(date)s]')
    assert pp._titleformat == '%(title)s - %(artist)s [%(date)s]'
    assert pp._title

# Generated at 2022-06-22 09:25:36.010914
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    def _test(titleformat, title, titleregex, info):
        dl = type('FakeYDL', (object,), {})()
        setattr(dl, 'to_screen', lambda x: None)
        mp = MetadataFromTitlePP(dl, titleformat)
        assert mp._titleformat == titleformat
        assert mp._titleregex == titleregex
        assert mp.run([], info) == ([], info)

    _test('%(artist)s - %(title)s', 'Foo - Bar',
          r'(?P<artist>.+)\ \-\ (?P<title>.+)',
          {'title': 'Foo - Bar'})

# Generated at 2022-06-22 09:25:44.513204
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.YoutubeDL import YoutubeDL
    dl = YoutubeDL({})
    # Test MetadataFromTitlePP
    pp = MetadataFromTitlePP(dl, '%(title)s - %(artist)s')
    expected_titleregex = r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp._titleregex == expected_titleregex

    # Test MetadataFromTitlePP with no %(foo)s patterns
    pp = MetadataFromTitlePP(dl, 'foo')
    expected_titleregex = 'foo'
    assert pp._titleregex == expected_titleregex

    # Test MetadataFromTitlePP with nested %(foo)s patterns

# Generated at 2022-06-22 09:25:55.384615
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, 'Abc').format_to_regex('Abc') == 'Abc'
    assert MetadataFromTitlePP(None, 'Abc-%(title)s').format_to_regex('Abc-%(title)s') == 'Abc\\-\\(?P<title>.+\\)'
    assert MetadataFromTitlePP(None, '%(title)s').format_to_regex('%(title)s') == '(?P<title>.+)'
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s').format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'

# Generated at 2022-06-22 09:26:05.885750
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    # Method run of class MetadataFromTitlePP should return normal
    def test_run_normal(capsys):
        downloader = object()
        metadata_from_title_pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
        info = {'title': 'Title for test - Artist for test'}
        result, info_out = metadata_from_title_pp.run(info)
        assert result == []
        assert info_out == {'title': 'Title for test', 'artist': 'Artist for test'}
        out, err = capsys.readouterr()
        assert out == ("[fromtitle] parsed title: Title for test\n"
                       "[fromtitle] parsed artist: Artist for test\n")
        assert err == ""

    # Method run of class MetadataFromTitlePP

# Generated at 2022-06-22 09:26:06.613103
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pass

# Generated at 2022-06-22 09:26:11.784915
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(author)s')
    assert pp._titleformat == '%(title)s - %(author)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<author>.+)'

# Unit tests for function MetadataFromTitlePP.format_to_regex

# Generated at 2022-06-22 09:26:19.384817
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ydl.downloader.YoutubeDL import YoutubeDL
    from ydl.postprocessor.ffmpeg import FFmpegMetadataPP

    dl = YoutubeDL()
    dl._setup_opts({})
    pp = FFmpegMetadataPP(dl)
    pp._setup_opts({'writethumbnail': True})
    pp.run(None)
    assert not pp.available()
    pp._pp_args = '-f bestvideo'
    assert pp.available()

# Generated at 2022-06-22 09:26:28.570631
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Example of the titleformat string:
    #     '%(title)s - %(artist)s'
    # Example of the expected titleregex string:
    #     '(?P<title>.+)\ \-\ (?P<artist>.+)'
    # Note that '-' is escaped as '\-' in the titleregex string.

    titleformat1 = '%(title)s - %(artist)s'
    titleregex1 = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    mftpp = MetadataFromTitlePP(None, titleformat1)
    assert (mftpp._titleformat == titleformat1 and
            mftpp._titleregex == titleregex1)

    titleformat2 = '%(title)s'

# Generated at 2022-06-22 09:26:39.733343
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL

    class DummyYoutubeDL:
        @property
        def params(self):
            return {}

        def to_screen(self, text): pass

    # Input  : "Titre de la vidéo - 09/09/2013"
    # Expected output : {"upload_date" : "20130909", "title" : "Titre de la vidéo"}
    ydl = YoutubeDL(params={})
    pp = MetadataFromTitlePP(DummyYoutubeDL(), '%(title)s - %(upload_date)s')
    info = {"title" : "Titre de la vidéo - 09/09/2013"}

# Generated at 2022-06-22 09:26:53.477720
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, str())
    assert pp.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert pp.format_to_regex('%(ti)stle)s') == r'%\(ti\)stle\)s'
    assert pp.format_to_regex('%(t)s%(i)s') == r'%\(t\)s%\(i\)s'
    assert pp.format_to_regex('%(t)s %(i)s') == r'%\(t\)s\ (?P<i>.+)'

# Generated at 2022-06-22 09:27:00.477836
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Test format to regex with percentage sign
    mftpp_1 = MetadataFromTitlePP(None, '%(*.mp3)s')
    # Test format to regex simple
    mftpp_2 = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert mftpp_1._titleregex == '%\(\.\*\.mp3\)s'
    assert mftpp_2._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-22 09:27:06.000592
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl.downloader
    import youtube_dl.extractor
    downloader = youtube_dl.downloader.Downloader(youtube_dl.YoutubeDL())

    def test(formatstr, title, expected):
        info = {'title': title}
        mp = MetadataFromTitlePP(downloader, formatstr)
        mp.run(info)
        assert info['song'] == expected

    test('%(song)s', 'Havana - Camila Cabello', 'Havana')
    test('%(song)s', 'Camila Cabello - Havana', None)
    test('"%(song)s"', '"Havana" - Camila Cabello', 'Havana')
    test('"%(song)s"', 'Camila Cabello - "Havana"', None)

# Generated at 2022-06-22 09:27:12.657731
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    downloader = None # not used
    titleformat = '%(title)s - %(artist)s'
    metadata_from_title_pp = MetadataFromTitlePP(downloader, titleformat)
    # Test 'format_to_regex'
    assert metadata_from_title_pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    return True


# Generated at 2022-06-22 09:27:21.373384
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-22 09:27:26.692444
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .compat import compat_etree_Element, compat_HTTPError, compat_urllib_parse_unquote

    from .extractor import YoutubeIE
    from .compat import compat_urllib_request
    from .downloader import FileDownloader

    data = compat_urllib_request.urlopen(
        'https://www.youtube.com/watch?v=WmJmm0eWS38').read().decode('utf-8')
    ie = YoutubeIE()
    info = ie._real_extract('https://www.youtube.com/watch?v=WmJmm0eWS38', data)
    # Utility to get an element from a list
    def get_element(list, elem):
        for element in list:
            if element.tag == elem:
                return element
        return None


# Generated at 2022-06-22 09:27:38.227338
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, '%(one)s - %(two)s').format_to_regex('%(one)s - %(two)s') == r'(?P<one>.+)\ \-\ (?P<two>.+)'
    assert MetadataFromTitlePP(None, '%(one)s - %(two)s - %(three)s').format_to_regex('%(one)s - %(two)s - %(three)s') == r'(?P<one>.+)\ \-\ (?P<two>.+)\ \-\ (?P<three>.+)'

# Generated at 2022-06-22 09:27:49.104014
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    tests = [
        {
            'titleformat' : '%(artist)s - %(song)s',
            'title' : 'Queen - Bohemian Rhapsody',
            'metadata' : {
                'artist' : 'Queen',
                'song' : 'Bohemian Rhapsody',
            }
        },
        {
            'titleformat' : '%(song)s',
            'title' : 'Bohemian Rhapsody',
            'metadata' : {
                'song' : 'Bohemian Rhapsody',
            }
        },
        {
            'titleformat' : '%(song)s - %(album)s',
            'title' : 'Bohemian Rhapsody',
            'metadata' : {
            }
        },
    ]
    for test in tests:
        pp

# Generated at 2022-06-22 09:27:54.840900
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, "%(title)s - %(artist)s")
    assert pp._titleformat == "%(title)s - %(artist)s"
    assert pp._titleregex == "(?P<title>.+)\ \-\ (?P<artist>.+)"

    pp = MetadataFromTitlePP(None, "TEST")
    assert pp._titleformat == "TEST"
    assert pp._titleregex == "TEST"

# Generated at 2022-06-22 09:27:57.760590
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    titleformat = '%(title)s - %(artist)s'
    assert MetadataFromTitlePP._format_to_regex(titleformat) == '(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-22 09:28:14.660782
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    # test simple format
    titleformat = '%(artist)s'
    pp = MetadataFromTitlePP(ydl, titleformat)
    assert pp._titleformat == titleformat
    assert pp._titleregex == titleformat
    # test format with a single %(..)s pattern
    titleformat = '%(title)s'
    pp = MetadataFromTitlePP(ydl, titleformat)
    assert pp._titleformat == titleformat
    assert pp._titleregex == r'(?P<title>.+)'
    # test format with two %(..)s patterns
    titleformat = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(ydl, titleformat)
    assert pp._title

# Generated at 2022-06-22 09:28:23.773157
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    import pytest
    titleformat = '%(artist)s - %(title)s'
    pp = MetadataFromTitlePP(YoutubeDL(), titleformat)
    info = {
        'title': 'Andrew Bird - Tenuousness',
        'track': '10',
    }
    info_list, new_info = pp.run(info)
    assert len(info_list) == 0
    assert new_info == {
        'title': 'Tenuousness',
        'artist': 'Andrew Bird',
        'track': '10',
    }
    titleformat = '%(artist)s [%(title)s]'
    pp = MetadataFromTitlePP(YoutubeDL(), titleformat)

# Generated at 2022-06-22 09:28:34.774022
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # MetadataFromTitlePP receive info as parameter in method run
    # and return [], info
    #
    # Title without format, no conversion
    info = {'title': 'Test title'}
    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp.run(info) == ([], {'title': 'Test title'})
    #
    # Title with format, conversion good, return new info
    info = {'title': 'Test title'}
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp.run(info) == ([], {'title': 'Test title', 'artist': ' - '})
    #
    # Title with format, conversion bad, return old info
    info = {'title': 'Test title'}
   

# Generated at 2022-06-22 09:28:43.827290
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    u"""
    Tests if the format_to_regex method returns the expected result for
    different input formats.
    """
    assert MetadataFromTitlePP(None,'').format_to_regex('') == ''
    assert MetadataFromTitlePP(None,'abcd').format_to_regex('abcd') == 'abcd'
    assert MetadataFromTitlePP(None,'%(title)s - %(artist)s').format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\\ \-\\ (?P<artist>.+)'

# Generated at 2022-06-22 09:28:50.226351
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-22 09:29:00.636929
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import json
    import os

    class DummyInfo:
        def __init__(self, www_youtube_com_watch_v_videoid, videoid, title):
            self.www_youtube_com_watch_v_videoid = {
                'url': 'https://www.youtube.com/watch?v=' + videoid,
                'title': title,
                'id': videoid
            }
            self.title = self.www_youtube_com_watch_v_videoid['title']
            self.videoid = self.www_youtube_com_watch_v_videoid['id']

    class DummyDownloader:
        def __init__(self, youtube_dl):
            self._youtube_dl = youtube_dl

        def to_screen(self, message):
            print(message)


# Generated at 2022-06-22 09:29:10.039072
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP.format_to_regex("%(title)s - %(artist)s [%(ext)s]") == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \[(?P<ext>.+)\]'
    assert MetadataFromTitlePP.format_to_regex("%(title)s - %(artist)s\ [%(ext)s]") == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \\[(?P<ext>.+)\]'
    assert MetadataFromTitlePP.format_to_regex("%(title)s") == '(?P<title>.+)'
    assert MetadataFromTitlePP.format_to_regex("%(ext)s") == '(?P<ext>.+)'
    assert Metadata

# Generated at 2022-06-22 09:29:20.516502
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    downloader = object()
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    pp = MetadataFromTitlePP(downloader, '%(title)s -')
    assert pp._titleformat == '%(title)s -'

    pp = MetadataFromTitlePP(downloader, '%(title)s')
    assert pp._titleformat == '%(title)s'


# Unit tests for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-22 09:29:32.620634
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from youtube_dl.YoutubeDL import YoutubeDL
    import youtube_dl.extractor.common
    youtube_dl.extractor.common.FILE_FORMATS = {'16', '17', '18', '22', '34', '35', '36', '37', '38', '43', '44', '45', '46', '82', '83', '84', '85', '89', '92', '93', '94', '95', '96', '100', '101', '102', '132', '151', '264'}
    pp = MetadataFromTitlePP(YoutubeDL({}), '%(title)s - %(artist)s')

# Generated at 2022-06-22 09:29:41.279931
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert (MetadataFromTitlePP(None,"%(title)s - %(artist)s").format_to_regex(
        "%(title)s - %(artist)s")
        ==
        r'(?P<title>.+)\ \-\ (?P<artist>.+)'
        )
    assert (MetadataFromTitlePP(None,"%(title)s").format_to_regex("%(title)s")
        ==
        r'(?P<title>.+)'
        )
    assert (MetadataFromTitlePP(None,"%(artist)s - %(title)s").format_to_regex(
        "%(artist)s - %(title)s")
        ==
        r'(?P<artist>.+)\ \-\ (?P<title>.+)'
        )

# Generated at 2022-06-22 09:30:01.973305
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    def test(titleformat):
        return MetadataFromTitlePP(None, titleformat)._titleregex

    assert test('') == ''
    assert test('%(title)s') == '(?P<title>.+)'
    assert test('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert test('%(title)s - %(artist)s - %(album)s') == ('(?P<title>.+)\ \-\ '
                                                         '(?P<artist>.+)\ \-\ '
                                                        '(?P<album>.+)')

# Generated at 2022-06-22 09:30:08.963340
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # Init with dummy values
    pp = MetadataFromTitlePP(None, None)

    # Test first use case
    fmt = '%(title)s - %(artist)s'
    regex = pp.format_to_regex(fmt)
    assert regex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    # Test second use case
    fmt = '%(title)s - %(artist)s - %(album)s'
    regex = pp.format_to_regex(fmt)
    assert regex == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'

    # Test escaping in use case
    fmt = '%(title)s!%(artist)s'
    regex = pp

# Generated at 2022-06-22 09:30:17.201964
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftpp = MetadataFromTitlePP(None, None)
    fmt_to_regex = mftpp.format_to_regex

    assert fmt_to_regex('%(title)s') == r'(?P<title>.+)'
    assert fmt_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert fmt_to_regex('%(artist)s - %(title)s') == r'(?P<artist>.+)\ \-\ (?P<title>.+)'

# Generated at 2022-06-22 09:30:24.392883
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Test titleformat with regex pattern
    titleformat = '%(\w+) - (\w+) - %(\w+) %\(\w+\)s'
    regex = (r'(?P<>\w+)\ \-\ (\w+)\ \-\ (?P<>\w+)\ '
             r'%(\(\w+\)\s)'
             r'%(\((\w+)\)\s)')
    metaparser = MetadataFromTitlePP(None, titleformat)

    assert metaparser._titleformat == titleformat
    assert metaparser._titleregex == regex

    # Test titleformat without regex pattern
    titleformat = ' (\w+) - (\w+) - %(\w+)'
    metaparser = MetadataFromTitlePP(None, titleformat)


# Generated at 2022-06-22 09:30:31.422427
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from . import YoutubeDL
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_request
    from .compat import compat_urllib_parse

    titleformat = '%(title)s - %(artist)s'
    titleregex = titleformat.replace('%(title)s', '(?P<title>.+)')
    titleregex = titleregex.replace('%(artist)s', '(?P<artist>.+)')

    pp = MetadataFromTitlePP(YoutubeDL(), titleformat)
    assert pp._titleformat == titleformat
    assert pp._titleregex == titleregex

    # Test format_to_regex
    newformat = titleformat.replace('%(artist)s', 'blabla')

# Generated at 2022-06-22 09:30:33.714887
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp is not None


# Generated at 2022-06-22 09:30:44.098131
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftpp = MetadataFromTitlePP(None, None)
    assert mftpp.format_to_regex('%(name)s') == '(?P<name>.+)'
    assert mftpp.format_to_regex('%(year)4d') == '%(year)4d'
    assert mftpp.format_to_regex('%(name)s/%(year)4d') == '(?P<name>.+)/%(year)4d'
    assert mftpp.format_to_regex('%(name)s:%(year)4d-%(category)s') == '(?P<name>.+):%(year)4d-(?P<category>.+)'

# Generated at 2022-06-22 09:30:45.115375
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass



# Generated at 2022-06-22 09:30:51.206264
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(test)s-%(test2)s')
    regex = pp.format_to_regex('%(test)s-%(test2)s')
    match = re.match(regex, 'abc-def')
    assert match.group('test') == 'abc'
    assert match.group('test2') == 'def'

# Generated at 2022-06-22 09:31:00.145640
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.YoutubeDL import YoutubeDL
    pp = MetadataFromTitlePP(YoutubeDL(), '%(artist)s - %(title)s')
    assert(pp._titleformat == '%(artist)s - %(title)s')
    assert(pp._titleregex == '(?P<artist>.+)\ \\-\ (?P<title>.+)')

    pp = MetadataFromTitlePP(YoutubeDL(), '%(title)s - %(artist)s')
    assert(pp._titleformat == '%(title)s - %(artist)s')
    assert(pp._titleregex == '(?P<title>.+)\ \\-\ (?P<artist>.+)')

    pp = MetadataFromTitlePP(YoutubeDL(), '%(title)s')