

# Generated at 2022-06-18 15:37:26.671374
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-18 15:37:34.550351
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s - %(album)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'

# Generated at 2022-06-18 15:37:44.759539
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, message):
            self.to_screen_calls.append(message)

    ydl = FakeYDL()
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    info = {'title': 'foo - bar'}
    pp.run(info)

# Generated at 2022-06-18 15:37:55.307899
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    pp = MetadataFromTitlePP(ydl, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '%(title)s'
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s - %(album)s')

# Generated at 2022-06-18 15:38:05.810661
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    assert pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s - %(album)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'
    assert pp.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert pp.format_to_regex('%(title)s - ') == r'(?P<title>.+)\ \-'

# Generated at 2022-06-18 15:38:16.679993
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import os
    import tempfile
    import shutil
    from ydl.downloader.common import FileDownloader

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()
    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    temp_file.close()
    # Create a temporary file
    temp_file2 = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    temp_file2.close()

    # Create a downloader
    ydl = FileDownloader({'outtmpl': temp_file.name,
                          'quiet': True,
                          'simulate': True,
                          'format': 'best',
                          'logger': sys.stdout})



# Generated at 2022-06-18 15:38:28.969585
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            super(FakeInfoExtractor, self).__init__(downloader)
            self._type = 'fake'


# Generated at 2022-06-18 15:38:40.015526
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.downloader = object()
            self.titleformat = '%(title)s - %(artist)s'
            self.pp = MetadataFromTitlePP(self.downloader, self.titleformat)

        def test_run_no_match(self):
            info = {'title': 'foo'}
            self.assertEqual(self.pp.run(info), ([], info))

        def test_run_match(self):
            info = {'title': 'foo - bar'}
            self.assertEqual(self.pp.run(info), ([], {'title': 'foo', 'artist': 'bar'}))


# Generated at 2022-06-18 15:38:47.022791
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ytdl_server.downloader import Downloader
    from ytdl_server.extractor import YoutubeIE

    class MockInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(MockInfoDict, self).__init__(*args, **kwargs)
            self.setdefault('title', 'NA')

    class MockYoutubeIE(YoutubeIE):
        def _real_extract(self, url):
            return MockInfoDict({'title': 'Test Title - Test Artist'})

    class MockDownloader(Downloader):
        def __init__(self, *args, **kwargs):
            super(MockDownloader, self).__init__(*args, **kwargs)
            self.to_screen_buffer = []

# Generated at 2022-06-18 15:38:58.100216
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import os
    import tempfile
    import shutil
    import unittest

    from ydl.downloader.common import FileDownloader
    from ydl.postprocessor.common import PostProcessor
    from ydl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class MockDownloader(FileDownloader):
        def __init__(self, params):
            FileDownloader.__init__(self, params)
            self.to_screen_messages = []

        def to_screen(self, message):
            self.to_screen_messages.append(message)

    class MockPostProcessor(PostProcessor):
        def __init__(self, downloader):
            PostProcessor.__init__(self, downloader)
            self.run_called = False


# Generated at 2022-06-18 15:39:11.966415
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)

    class MockPostProcessor(PostProcessor):
        def __init__(self, *args, **kwargs):
            super(MockPostProcessor, self).__init__(*args, **kwargs)
            self.run_calls = []


# Generated at 2022-06-18 15:39:22.066297
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)

    class MockPostProcessor(PostProcessor):
        def __init__(self, *args, **kwargs):
            super(MockPostProcessor, self).__init__(*args, **kwargs)
            self.run_calls = []


# Generated at 2022-06-18 15:39:28.973197
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftpp = MetadataFromTitlePP(None, None)
    assert mftpp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert mftpp.format_to_regex('%(title)s - %(artist)s - %(album)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'
    assert mftpp.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert mftpp.format_to_regex('%(title)s - %(artist)s - %(album)s - %(year)s') == r

# Generated at 2022-06-18 15:39:40.451629
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    assert pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s - %(album)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'

# Generated at 2022-06-18 15:39:49.322821
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor import gen_extractors
    from .compat import compat_urllib_request

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    def _fake_urlopen(request):
        return compat_urllib_request.urlopen(request, timeout=15)

    downloader = FileDownloader({})
    downloader.report_warning = lambda msg: None
    downloader.to_screen = lambda msg: None
    downloader.urlopen = _fake_urlopen

# Generated at 2022-06-18 15:40:00.874807
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest

    class MockYDL(object):
        def to_screen(self, msg):
            print(msg)

    class MockInfo(dict):
        def __init__(self, title):
            self['title'] = title

    class TestMetadataFromTitlePP(unittest.TestCase):
        def test_run(self):
            ydl = MockYDL()
            pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
            info = MockInfo('foo - bar')
            pp.run(info)
            self.assertEqual(info['title'], 'foo')
            self.assertEqual(info['artist'], 'bar')

    unittest.main(argv=sys.argv[:1])

# Generated at 2022-06-18 15:40:08.081815
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import DownloadError
    from youtube_dl.utils import ExtractorError
    from youtube_dl.utils import format_bytes
    from youtube_dl.utils import format_seconds
    from youtube_dl.utils import sanitize_filename
    from youtube_dl.utils import std_headers
    from youtube_dl.utils import unescapeHTML
    from youtube_dl.utils import unescapeURL
    from youtube_dl.utils import unescapeURL_python
    from youtube_dl.utils import unescapeURL_unicode
    from youtube_dl.utils import unescapeURL_utf8
    from youtube_dl.utils import unescapeURL_unicode_python

# Generated at 2022-06-18 15:40:18.156511
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.PostProcessor import PostProcessor
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)

    class FakePP(PostProcessor):
        def __init__(self, *args, **kwargs):
            super(FakePP, self).__init__(*args, **kwargs)
            self.run_calls = []


# Generated at 2022-06-18 15:40:28.532663
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test 1: Test if the method run of class MetadataFromTitlePP works as expected
    # when the titleformat is '%(title)s - %(artist)s' and the title is 'Test - Test'
    # The expected result is that the method returns an empty list and a dictionary
    # with the keys 'title' and 'artist' and the values 'Test' and 'Test'
    # respectively.
    downloader = None
    titleformat = '%(title)s - %(artist)s'
    title = 'Test - Test'
    info = {'title': title}
    metadata_from_title_pp = MetadataFromTitlePP(downloader, titleformat)
    result = metadata_from_title_pp.run(info)
    assert result == ([], {'title': 'Test', 'artist': 'Test'})

   

# Generated at 2022-06-18 15:40:36.984773
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '%(title)s'

    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(album)s')
    assert pp._titleformat == '%(title)s - %(artist)s - %(album)s'

# Generated at 2022-06-18 15:40:47.961444
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')

        def test_run_with_match(self):
            info = {'title': 'title - artist'}
            expected_info = {'title': 'title', 'artist': 'artist'}
            self.assertEqual(self.pp.run(info), ([], expected_info))

        def test_run_without_match(self):
            info = {'title': 'title'}
            self.assertEqual(self.pp.run(info), ([], info))

    unittest.main(argv=sys.argv[:1])

# Unit test

# Generated at 2022-06-18 15:40:59.733990
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeInfoExtractor, self).__init__(*args, **kwargs)
            self._downloader = YoutubeDL(params={'outtmpl': '%(title)s'})

    ie = FakeInfoExtractor({})
    info = {'title': 'Test Title - Test Artist'}
    pp = MetadataFromTitlePP(ie._downloader, '%(title)s - %(artist)s')
    pp.run(info)
    assert info['title'] == 'Test Title'
    assert info['artist'] == 'Test Artist'



# Generated at 2022-06-18 15:41:11.854244
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import json
    import unittest
    import unittest.mock as mock

    from ydl.downloader import Downloader
    from ydl.postprocessor import MetadataFromTitlePP

    class MockYDL(object):
        def __init__(self):
            self.params = {
                'simulate': True,
                'quiet': True,
                'format': 'best',
                'outtmpl': '%(title)s-%(id)s.%(ext)s',
            }

        def to_screen(self, msg):
            print(msg)


# Generated at 2022-06-18 15:41:21.968499
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor import FFmpegMetadataPP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            self.downloader = downloader

        def _real_extract(self, url):
            return {'id': 'test', 'title': 'Test - Title'}

    class FakeFileDownloader(FileDownloader):
        def __init__(self, ydl, params):
            self.ydl = ydl


# Generated at 2022-06-18 15:41:29.572642
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ydl.downloader.common import FileDownloader

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.downloader = FileDownloader(params={})
            self.downloader.to_screen = lambda x: sys.stdout.write(x + '\n')

        def test_run(self):
            pp = MetadataFromTitlePP(self.downloader,
                                     '%(title)s - %(artist)s')
            info = {'title': 'Test Title - Test Artist'}
            pp.run(info)
            self.assertEqual(info['title'], 'Test Title')
            self.assertEqual(info['artist'], 'Test Artist')

    unittest.main()

# Generated at 2022-06-18 15:41:40.046652
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.compat import compat_str

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []
            self.to_screen_msgs = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)
            self.to

# Generated at 2022-06-18 15:41:50.619990
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    from ytdl.YoutubeDL import YoutubeDL
    from ytdl.PostProcessor import PostProcessor
    from ytdl.FileDownloader import FileDownloader

    class MockInfo(dict):
        def __init__(self, title):
            self['title'] = title

    class MockYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)


# Generated at 2022-06-18 15:41:58.234646
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'test'
        _VALID_URL = r'https?://.+'


# Generated at 2022-06-18 15:42:06.726219
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP

    # Test 1

# Generated at 2022-06-18 15:42:16.483196
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)


# Generated at 2022-06-18 15:42:27.399620
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE

    # Test 1
    # Test with a titleformat that matches the title
    # and returns the title as the value of the attribute 'title'
    titleformat = '%(title)s'
    title = 'Test title'
    info = {'title': title}

# Generated at 2022-06-18 15:42:38.240022
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange

    # Test 1
    # Test with a titleformat that does not contain any %(..)s
    titleformat = '%(title)s - %(artist)s'
    title = 'title - artist'
    info = {'title': title}

# Generated at 2022-06-18 15:42:44.689612
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.compat import compat_str
    from datetime import datetime
    from collections import OrderedDict

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name, ie_id):
            self._type = 'fake'
            self._WORKING = True
            self.ie_name = ie_name
            self.ie_id = ie_id
            self._downloader = None
            self._ies = []

        def _real_initialize(self):
            pass


# Generated at 2022-06-18 15:42:55.394186
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # Create a YoutubeDL object

# Generated at 2022-06-18 15:43:04.576273
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from datetime import date

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            super(FakeInfoExtractor, self).__init__(downloader)


# Generated at 2022-06-18 15:43:15.433433
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP

    # Create a YoutubeDL object

# Generated at 2022-06-18 15:43:26.963984
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name):
            InfoExtractor.__init__(self, ie_name)


# Generated at 2022-06-18 15:43:32.956354
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP

    # Create a YoutubeDL object

# Generated at 2022-06-18 15:43:42.065857
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE

    # Test 1
    # Test if the method run of class MetadataFromTitlePP works correctly
    # when the title of the video matches the format
    #
    # Test 1.1
    # Test if the method run of class MetadataFromTitlePP works correctly
    # when the format is a regex
    #
    # Test 1.1.1
    # Test if the method run of class MetadataFromTitlePP works correctly
    # when the format is a regex and the title of the video matches the format
    #
    # Test 1.1.1.1
    # Test if the method run of class MetadataFromTitlePP works correctly


# Generated at 2022-06-18 15:43:50.363374
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor import YoutubeIE
    from .compat import compat_str

    # Test with a Youtube video
    downloader = FileDownloader({
        'format': 'best',
        'outtmpl': '%(title)s.%(ext)s',
        'postprocessors': [{
            'key': 'MetadataFromTitle',
            'titleformat': '%(title)s - %(artist)s',
        }],
    })
    ie = YoutubeIE(downloader)
    info = ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')
    assert info['title'] == 'youtube-dl test video "\'/\\ä↭𝕐'
    assert info['artist'] == 'Philipp Hagemeister'
    assert info

# Generated at 2022-06-18 15:44:05.340817
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # Create a YoutubeDL object

# Generated at 2022-06-18 15:44:16.420303
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl.YoutubeDL import YoutubeDL
    from ytdl.postprocessor.ffmpeg import FFmpegMetadataPP
    from ytdl.postprocessor.xattrpp import XAttrMetadataPP
    from ytdl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from ytdl.postprocessor.metadatafromtitle import MetadataFromTitlePP


# Generated at 2022-06-18 15:44:23.367745
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    from ytdl_server.downloader import Downloader
    from ytdl_server.extractor import YoutubeIE
    from ytdl_server.postprocessor import FFmpegMetadataPP
    from ytdl_server.postprocessor import FFmpegExtractAudioPP
    from ytdl_server.postprocessor import FFmpegVideoConvertorPP
    from ytdl_server.postprocessor import FFmpegEmbedSubtitlePP
    from ytdl_server.postprocessor import FFmpegMergerPP
    from ytdl_server.postprocessor import MetadataFromTitlePP


# Generated at 2022-06-18 15:44:33.699822
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    import datetime

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeInfoExtractor, self).__init__(*args, **kwargs)
            self._downloader = YoutubeDL(params={})

    ie = FakeInfoExtractor(downloader=None)
    pp = MetadataFromTitlePP(ie._downloader, '%(title)s - %(artist)s')

# Generated at 2022-06-18 15:44:43.529652
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, message, skip_eol=False):
            self.to_screen_calls.append(message)


# Generated at 2022-06-18 15:44:50.606283
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.compat import compat_str
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class MockInfoExtractor(InfoExtractor):
        def __init__(self, downloader, ie_id):
            super(MockInfoExtractor, self).__init__(downloader, ie_id)
            self.num_downloads = 0

        def _real_extract(self, url):
            self.num_downloads += 1

# Generated at 2022-06-18 15:45:01.969017
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.compat import compat_str

    class FakeInfoDict(dict):
        def __init__(self, title):
            self['title'] = title

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)

    # Test with a regex that matches

# Generated at 2022-06-18 15:45:10.214742
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import common

    class FakeInfoExtractor(common.InfoExtractor):
        def __init__(self, ie_name, ie_id):
            super(FakeInfoExtractor, self).__init__(ie_name, ie_id)


# Generated at 2022-06-18 15:45:21.481714
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # Create a YoutubeDL object

# Generated at 2022-06-18 15:45:31.257523
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ydl.postprocessor import MetadataFromTitlePP

    class TestMetadataFromTitlePP(unittest.TestCase):
        def test_run(self):
            # Test with a regex that matches the title
            titleformat = '%(title)s - %(artist)s'
            title = 'title - artist'
            info = {'title': title}
            pp = MetadataFromTitlePP(None, titleformat)
            pp.run(info)
            self.assertEqual(info['title'], 'title')
            self.assertEqual(info['artist'], 'artist')

            # Test with a regex that does not match the title
            titleformat = '%(title)s - %(artist)s'
            title = 'title - artist - album'

# Generated at 2022-06-18 15:45:52.373408
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # test with a video that has no metadata

# Generated at 2022-06-18 15:45:59.178392
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeInfoExtractor, self).__init__(*args, **kwargs)
            self._downloader = YoutubeDL(params={'writedescription': True})


# Generated at 2022-06-18 15:46:08.374472
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name):
            super(FakeInfoExtractor, self).__init__(ie_name)


# Generated at 2022-06-18 15:46:17.936025
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    info = {'title': 'Foo - Bar'}
    pp.run(info)
    assert info['title'] == 'Foo'
    assert info['artist'] == 'Bar'

    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    info = {'title': 'Foo - Bar - Baz'}
    pp.run(info)
    assert info['title'] == 'Foo'
    assert info['artist'] == 'Bar - Baz'

    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')

# Generated at 2022-06-18 15:46:25.515366
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name, ie_id):
            super(FakeInfoExtractor, self).__init__(ie_name, ie_id)


# Generated at 2022-06-18 15:46:35.991176
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    from ytdl.YoutubeDL import YoutubeDL
    from ytdl.PostProcessor import PostProcessor
    from ytdl.compat import compat_str

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_called = False
            self.to_screen_msg = None

        def to_screen(self, msg):
            self.to_screen_called = True
            self.to_screen_msg = msg

    ydl = FakeYDL({'logger': sys.stdout})
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')

# Generated at 2022-06-18 15:46:46.835932
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE

    # Test with a simple titleformat
    titleformat = '%(title)s - %(artist)s'
    titleregex = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    title = 'title - artist'
    info = {'title': title}
    pp = MetadataFromTitlePP(YoutubeDL({'usenetrc': False, 'verbose': False}), titleformat)
    pp.run(info)
    assert info['title'] == title
    assert info['artist'] == 'artist'

    # Test with a more complex titleformat

# Generated at 2022-06-18 15:46:55.250902
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor import FFmpegMetadataPP

    # Create a YoutubeDL object

# Generated at 2022-06-18 15:47:05.489139
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP


# Generated at 2022-06-18 15:47:16.731542
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)
