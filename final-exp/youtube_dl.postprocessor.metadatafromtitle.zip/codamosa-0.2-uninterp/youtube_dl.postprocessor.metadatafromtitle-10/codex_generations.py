

# Generated at 2022-06-18 15:37:30.704207
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    from ytdl.YoutubeDL import YoutubeDL
    from ytdl.PostProcessor import PostProcessor
    from ytdl.compat import compat_str

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_buffer = []

        def to_screen(self, message):
            self.to_screen_buffer.append(message)

    class MockPostProcessor(PostProcessor):
        def __init__(self, *args, **kwargs):
            super(MockPostProcessor, self).__init__(*args, **kwargs)
            self.run_buffer = []


# Generated at 2022-06-18 15:37:42.037311
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.youtube import YoutubeIE

    # Test with a simple titleformat
    titleformat = '%(title)s'
    title = 'Video title'
    info = {'title': title}
    ydl = YoutubeDL({'writedescription': True, 'writeinfojson': True,
                     'writethumbnail': True, 'writeautomaticsub': True,
                     'skip_download': True, 'format': 'bestvideo+bestaudio/best',
                     'postprocessors': [{
                         'key': 'MetadataFromTitle',
                         'titleformat': titleformat,
                     }],
                     'extractors': [{
                         'key': 'Youtube',
                         'ie': YoutubeIE.ie_key(),
                     }]})

# Generated at 2022-06-18 15:37:49.431034
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange

    # Test 1
    # Test with a titleformat with no regex groups
    titleformat = '%(title)s'
    title = 'test title'
    info = {'title': title}
    pp = MetadataFromTitlePP(FileDownloader(YoutubeDL()), titleformat)
    assert pp.run(info) == ([], info)

    # Test 2
    # Test with a titleformat with regex groups
    titleformat = '%(title)s - %(artist)s'
    title = 'test title - test artist'
    info = {'title': title}
    pp = MetadataFromTitlePP(FileDownloader(YoutubeDL()), titleformat)


# Generated at 2022-06-18 15:37:57.807385
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    assert pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s - %(album)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'

# Generated at 2022-06-18 15:38:08.770049
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    ydl.add_default_info_extractors()
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s'))
    ydl.params['extract_flat'] = 'in_playlist'
    ydl.params['simulate'] = True
    ydl.params['quiet'] = True
    ydl.params['format'] = 'bestaudio'
    ydl.params['outtmpl'] = '%(title)s - %(artist)s.%(ext)s'
    ydl.params['writethumbnail'] = True
    ydl.params['writeinfojson'] = True
    ydl.params['writesubtitles'] = True
   

# Generated at 2022-06-18 15:38:18.272157
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen = lambda x: None


# Generated at 2022-06-18 15:38:29.513669
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Test with a simple format string
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    # Test with a format string that does not contain %(..)s
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    # Test with a format string that contains a literal %(..)s
    pp = MetadataFromTitlePP

# Generated at 2022-06-18 15:38:40.566523
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # Test with a format string that contains no %(..)s
    fmt = '%(title)s - %(artist)s'
    regex = MetadataFromTitlePP(None, fmt).format_to_regex(fmt)
    assert regex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    # Test with a format string that contains %(..)s
    fmt = '%(title)s - %(artist)s'
    regex = MetadataFromTitlePP(None, fmt).format_to_regex(fmt)
    assert regex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    # Test with a format string that contains %(..)s and other characters

# Generated at 2022-06-18 15:38:47.349892
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import json

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary python file
    temp_file = os.path.join(temp_dir, 'temp.py')

# Generated at 2022-06-18 15:38:59.009459
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ytdl_server.postprocessor import MetadataFromTitlePP

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.downloader = object()
            self.metadata_from_title_pp = MetadataFromTitlePP(self.downloader, '%(title)s - %(artist)s')

        def test_run(self):
            info = {
                'title': 'The Title - The Artist',
            }
            self.metadata_from_title_pp.run(info)
            self.assertEqual(info['title'], 'The Title')
            self.assertEqual(info['artist'], 'The Artist')


# Generated at 2022-06-18 15:39:12.350219
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            super(FakeInfoExtractor, self).__init__(downloader)
            self.ie_key = 'fake'

        def _real_extract(self, url):
            return {'title': 'Fake title'}

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, params):
            super(FakeYoutubeDL, self).__init__(params)
            self.extractor = FakeInfoExtractor(self)


# Generated at 2022-06-18 15:39:22.488656
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.PostProcessor import PostProcessor
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen = lambda x: None


# Generated at 2022-06-18 15:39:29.177405
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeInfoExtractor, self).__init__(*args, **kwargs)
            self.IE_NAME = 'fake'


# Generated at 2022-06-18 15:39:40.647729
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    from ytdl.YoutubeDL import YoutubeDL
    from ytdl.PostProcessor import PostProcessor
    from ytdl.compat import compat_str

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, message):
            self.to_screen_calls.append(message)

    class MockPostProcessor(PostProcessor):
        def __init__(self, *args, **kwargs):
            super(MockPostProcessor, self).__init__(*args, **kwargs)
            self.run_calls = []


# Generated at 2022-06-18 15:39:49.428461
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeInfoExtractor, self).__init__(*args, **kwargs)
            self._downloader = YoutubeDL({})

        def _real_extract(self, url):
            return {'id': 'test', 'title': 'test - test'}

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYoutubeDL, self).__init__(*args, **kwargs)
            self.extractor = FakeInfoExtractor(self)

    ydl = Fake

# Generated at 2022-06-18 15:40:00.913035
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import os
    import tempfile
    import shutil
    from ydl.downloader.common import FileDownloader
    from ydl.postprocessor.common import PostProcessor
    from ydl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a FileDownloader object
    ydl = FileDownloader({'outtmpl': os.path.join(tmpdir, '%(title)s-%(id)s.%(ext)s'),
                          'quiet': True})

    # Create a PostProcessor object
    pp = PostProcessor(ydl)

    # Create a MetadataFromTitlePP object
    mftpp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')

# Generated at 2022-06-18 15:40:08.102976
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP

    # Create a YoutubeDL object
    ydl = YoutubeDL({
        'outtmpl': '%(title)s-%(id)s.%(ext)s',
        'writethumbnail': True,
        'quiet': True,
        'simulate': True,
        'format': 'bestaudio/best',
        'postprocessors': [{
            'key': 'FFmpegMetadata'
        }],
        'logger': YoutubeDL.logger_class('test_logger', True)
    })

    # Create a YoutubeIE object


# Generated at 2022-06-18 15:40:18.196062
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import tempfile
    import os
    import shutil
    import unittest
    from ydl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from ydl.downloader.common import FileDownloader
    from ydl.compat import compat_str

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.filename = 'test.mp4'

    class FakeYDL(object):
        def __init__(self):
            self.params = {'writethumbnail': True, 'outtmpl': '%(title)s.%(ext)s'}
            self.to_screen = lambda *args: None


# Generated at 2022-06-18 15:40:28.567719
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ydl.downloader.common import FileDownloader

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.downloader = FileDownloader(params={})
            self.downloader.to_screen = lambda x: sys.stdout.write(x + '\n')
            self.downloader.to_stderr = lambda x: sys.stderr.write(x + '\n')

        def test_run(self):
            pp = MetadataFromTitlePP(self.downloader, '%(title)s - %(artist)s')
            info = {'title': 'The Title - The Artist'}
            pp.run(info)
            self.assertEqual(info['title'], 'The Title')
           

# Generated at 2022-06-18 15:40:37.016567
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.params = {}

    class FakeFD(FileDownloader):
        def __init__(self, *args, **kwargs):
            super(FakeFD, self).__init__(*args, **kwargs)
            self.to_

# Generated at 2022-06-18 15:40:50.819358
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import common
    from youtube_dl.postprocessor import MetadataFromTitlePP

    # Create a YoutubeDL object
    ydl = YoutubeDL({'writedescription': True, 'writeinfojson': True, 'writethumbnail': True, 'writeautomaticsub': True, 'skip_download': True})

    # Create a MetadataFromTitlePP object
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')

    # Create a YoutubeDL object
    ydl = YoutubeDL({'writedescription': True, 'writeinfojson': True, 'writethumbnail': True, 'writeautomaticsub': True, 'skip_download': True})

    # Create a YoutubeDL

# Generated at 2022-06-18 15:41:01.094185
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    import datetime

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeInfoExtractor, self).__init__(*args, **kwargs)
            self._downloader = YoutubeDL(params={})

    ie = FakeInfoExtractor({})
    ie.add_info_extractor(
        'test',
        [{'re': '.*', 'format': 'test'}],
        ['title'],
        ['title'])
    ie.set_downloader(YoutubeDL({}))

    # Test with a regex that matches the title

# Generated at 2022-06-18 15:41:12.693798
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.PostProcessor import PostProcessor
    from youtube_dl.utils import DateRange
    from youtube_dl.compat import compat_str

    class FakeInfoDict(dict):
        def __init__(self, title, **kwargs):
            super(FakeInfoDict, self).__init__(**kwargs)
            self['title'] = title

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)


# Generated at 2022-06-18 15:41:22.883631
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from unittest import TestCase

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name):
            super(FakeInfoExtractor, self).__init__(ie_name)
            self.ie_name = ie_name

        def _real_extract(self, url):
            return {'id': '123', 'title': 'Test - Title'}


# Generated at 2022-06-18 15:41:31.199274
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.youtube import YoutubeIE
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import sanitize_open

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_called_with = []

        def to_screen(self, msg):
            self.to_screen_called_with.append(msg)


# Generated at 2022-06-18 15:41:41.641669
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.compat import compat_str

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)

# Generated at 2022-06-18 15:41:52.614514
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    import datetime

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_called = []

        def to_screen(self, msg):
            self.to_screen_called.append(msg)


# Generated at 2022-06-18 15:42:03.937219
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.filename = 'test.mp4'

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen = lambda *args, **kwargs: None


# Generated at 2022-06-18 15:42:15.357387
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import pytest
    from ytdl.YoutubeDL import YoutubeDL
    from ytdl.postprocessor.common import PostProcessor
    from ytdl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_messages = []

        def to_screen(self, msg):
            self.to_screen_messages.append(msg)

    class FakePostProcessor(PostProcessor):
        def __init__(self, *args, **kwargs):
            super(FakePostProcessor, self).__init__(*args, **kwargs)

# Generated at 2022-06-18 15:42:25.584973
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.youtube import YoutubeIE

    # Test with a simple titleformat
    titleformat = '%(title)s'
    title = 'Test title'
    info = {'title': title}

# Generated at 2022-06-18 15:42:49.231888
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test with a regex that matches
    titleformat = '%(title)s - %(artist)s'
    title = 'Video Title - Video Artist'
    info = {'title': title}
    pp = MetadataFromTitlePP(None, titleformat)
    _, info = pp.run(info)
    assert info['title'] == 'Video Title'
    assert info['artist'] == 'Video Artist'

    # Test with a regex that does not match
    titleformat = '%(title)s - %(artist)s'
    title = 'Video Title'
    info = {'title': title}
    pp = MetadataFromTitlePP(None, titleformat)
    _, info = pp.run(info)
    assert info['title'] == title
    assert 'artist' not in info

    # Test with a regex that matches

# Generated at 2022-06-18 15:42:58.863353
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.filename = 'test.mp4'

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)

# Generated at 2022-06-18 15:43:07.317739
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ytdl_server.downloader import Downloader

    class MockDownloader(Downloader):
        def to_screen(self, msg):
            sys.stdout.write(msg + '\n')

    class TestMetadataFromTitlePP(unittest.TestCase):
        def test_run(self):
            downloader = MockDownloader()
            pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
            info = {'title': 'The Title - The Artist'}
            pp.run(info)
            self.assertEqual(info['title'], 'The Title')
            self.assertEqual(info['artist'], 'The Artist')

    unittest.main()


# Generated at 2022-06-18 15:43:18.375341
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.PostProcessor import PostProcessor
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            self.to_screen_calls = []
            super(FakeYDL, self).__init__(*args, **kwargs)

        def to_screen(self, message):
            self.to_screen_calls.append(message)

    class FakePP(PostProcessor):
        def __init__(self, *args, **kwargs):
            self.run_calls = []
            super(FakePP, self).__init__(*args, **kwargs)


# Generated at 2022-06-18 15:43:29.412498
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.utils import DateRange

    # Create a YoutubeDL object
    ydl = YoutubeDL({'outtmpl': '%(id)s%(ext)s',
                     'writedescription': True,
                     'writeinfojson': True,
                     'writethumbnail': True,
                     'writeautomaticsub': True,
                     'writeannotations': True,
                     'skip_download': True,
                     'format': 'bestaudio/best',
                     'postprocessors': [{
                         'key': 'MetadataFromTitle',
                         'titleformat': '%(title)s - %(artist)s'
                     }]})

    # Create a YoutubeIE object
    ie = YoutubeIE(ydl)

   

# Generated at 2022-06-18 15:43:37.381500
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeInfoExtractor, self).__init__(*args, **kwargs)
            self._title = '%(title)s - %(artist)s'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'title': self._title,
                'url': url,
                'ext': 'mp4',
                'upload_date': '20120101',
                'uploader': 'test'
            }


# Generated at 2022-06-18 15:43:47.273191
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    import youtube_dl.YoutubeDL

    class MockYoutubeDL(youtube_dl.YoutubeDL.YoutubeDL):
        def __init__(self, *args, **kwargs):
            self.to_screen_messages = []
            super(MockYoutubeDL, self).__init__(*args, **kwargs)

        def to_screen(self, message):
            self.to_screen_messages.append(message)

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.ydl = MockYoutubeDL()
            self.pp = MetadataFromTitlePP(self.ydl, '%(title)s - %(artist)s')


# Generated at 2022-06-18 15:43:58.415218
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP

    def test_run(titleformat, title, expected_info):
        ydl = YoutubeDL({'writethumbnail': True, 'outtmpl': '%(id)s'})
        ydl.add_default_info_extractors()
        ydl.add_info_extractor(YoutubeIE())
        ydl.add_post_processor(FFmpegMetadataPP())
        ydl.add_post_processor(MetadataFromTitlePP(ydl, titleformat))
        ydl.params['usenetrc'] = False
        ydl.params['username'] = None
        ydl.params['password']

# Generated at 2022-06-18 15:44:07.176718
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_str
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.downloader.common import FileDownloader

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name):
            super(FakeInfoExtractor, self).__init__(ie_name)


# Generated at 2022-06-18 15:44:18.229059
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.postprocessor import FFmpegMetadataPP


# Generated at 2022-06-18 15:44:50.924046
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.utils import DateRange
    from youtube_dl.compat import compat_str

    # Test 1: Test that the method run of class MetadataFromTitlePP
    #         correctly parses the title of a video into metadata
    #         when the title format is given as a string

# Generated at 2022-06-18 15:45:02.053677
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            super(FakeInfoExtractor, self).__init__(downloader)


# Generated at 2022-06-18 15:45:10.262990
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.compat import compat_str

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, message, skip_eol=False):
            self.to_screen_calls.append(message)


# Generated at 2022-06-18 15:45:21.483360
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeInfoExtractor, self).__init__(*args, **kwargs)
            self._downloader = YoutubeDL(params={'writedescription': True})


# Generated at 2022-06-18 15:45:31.257403
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # create a YoutubeDL object
    ydl = YoutubeDL({})
    # create a FileDownloader object
    fd = FileDownloader(ydl, {'outtmpl': '%(title)s.%(ext)s'})
    # create a YoutubeIE object
    ie = YoutubeIE(ydl)
    # add it to the FileDownloader object
    fd.add_info_extractor(ie)
    # create a FFmpegMetadataPP object
    ff

# Generated at 2022-06-18 15:45:41.530135
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import common
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # Create a YoutubeDL object
    ydl = YoutubeDL({'writedescription': True, 'writeinfojson': True, 'writethumbnail': True, 'writeautomaticsub': True, 'outtmpl': '%(id)s.%(ext)s'})
    # Create a downloader object

# Generated at 2022-06-18 15:45:51.841654
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            InfoExtractor.__init__(self, downloader)
            self.ie_key = 'fake'


# Generated at 2022-06-18 15:45:57.968535
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ytdl.YoutubeDL import YoutubeDL

    class FakeInfoDict(dict):
        def __init__(self, title):
            self['title'] = title

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self):
            self.to_screen_called = False

        def to_screen(self, msg):
            self.to_screen_called = True

    class TestMetadataFromTitlePP(unittest.TestCase):
        def test_run(self):
            # Test with a regex
            info = FakeInfoDict('title - artist')
            ydl = FakeYoutubeDL()
            pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
            pp.run(info)

# Generated at 2022-06-18 15:46:07.196361
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            super(FakeInfoExtractor, self).__init__(downloader)
            self._type = 'fake'


# Generated at 2022-06-18 15:46:16.227778
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP


# Generated at 2022-06-18 15:47:19.061664
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.compat import compat_str

    # Create a FileDownloader object
    ydl = FileDownloader({'format': 'best',
                          'outtmpl': '%(title)s-%(id)s.%(ext)s',
                          'nooverwrites': True,
                          'quiet': True,
                          'simulate': True,
                          'logger': FileDownloader.std_logger,
                          'progress_hooks': [],
                          'extractors': [YoutubeIE()],
                          'postprocessors': [MetadataFromTitlePP(ydl, '%(title)s')]})

