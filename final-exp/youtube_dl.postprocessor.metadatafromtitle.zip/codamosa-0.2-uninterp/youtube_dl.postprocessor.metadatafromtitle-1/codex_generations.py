

# Generated at 2022-06-18 15:37:32.584830
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '')
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s - %(album)s') == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)\\ \\-\\ (?P<album>.+)'

# Generated at 2022-06-18 15:37:43.276300
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.downloader.http.http_req_download import HttpRequest
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            super(FakeInfoExtractor, self).__init__(downloader)
            self._type = 'fake'

        def _real_extract(self, url):
            return {'id': 'fakeid', 'title': 'faketitle'}


# Generated at 2022-06-18 15:37:50.010196
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class TestInfoExtractor(InfoExtractor):
        def __init__(self, downloader=None):
            super(TestInfoExtractor, self).__init__(downloader)


# Generated at 2022-06-18 15:37:59.595734
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.http import HttpFD

    # Create a downloader
    ydl = YoutubeDL({
        'noplaylist': True,
        'simulate': True,
        'quiet': True,
        'format': 'bestaudio/best',
        'outtmpl': '%(title)s.%(ext)s',
        'writethumbnail': True,
        'postprocessors': [{
            'key': 'MetadataFromTitle',
            'titleformat': '%(artist)s - %(title)s',
        }],
    })
    ydl.add_default_info_extractors()

    # Create a fake file-

# Generated at 2022-06-18 15:38:10.813478
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange
    from youtube_dl.compat import compat_str

    class TestPP(PostProcessor):
        def __init__(self, downloader):
            super(TestPP, self).__init__(downloader)
            self.test_info = None

        def run(self, info):
            self.test_info = info
            return [], info

    class TestYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(TestYDL, self).__init__(*args, **kwargs)
            self.test_pp = TestPP(self)
            self.add_post_processor(self.test_pp)



# Generated at 2022-06-18 15:38:19.512218
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    pp = MetadataFromTitlePP(ydl, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '%(title)s'
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s - %(album)s')

# Generated at 2022-06-18 15:38:29.957277
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.PostProcessor import PostProcessor
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import common
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(common.InfoExtractor):
        IE_NAME = 'fake'
        _VALID_URL = r'https?://.+'


# Generated at 2022-06-18 15:38:40.981718
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    """
    Test the constructor of class MetadataFromTitlePP.
    """
    from youtube_dl.downloader import Downloader
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    ydl.add_post_processor(MetadataFromTitlePP(Downloader(ydl), '%(title)s'))
    ydl.add_post_processor(MetadataFromTitlePP(Downloader(ydl), '%(title)s - %(artist)s'))
    ydl.add_post_processor(MetadataFromTitlePP(Downloader(ydl), '%(title)s - %(artist)s - %(album)s'))

# Generated at 2022-06-18 15:38:52.367718
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            self.downloader = downloader

        def _real_extract(self, url):
            return {'id': 'testid', 'title': 'testtitle'}

    class FakeFileDownloader(FileDownloader):
        def __init__(self, ydl, params):
            self.ydl = ydl
            self.params = params
            self.to

# Generated at 2022-06-18 15:39:02.493146
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange

    ydl = YoutubeDL({'writedescription': True, 'writeinfojson': True, 'writethumbnail': True, 'writeautomaticsub': True, 'skip_download': True})
    ydl.add_default_info_extractors()
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s'))
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s - %(album)s'))

# Generated at 2022-06-18 15:39:19.899004
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP


# Generated at 2022-06-18 15:39:27.599514
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    ydl = YoutubeDL({'writedescription': True, 'writeinfojson': True, 'writethumbnail': True, 'writeautomaticsub': True, 'skip_download': True, 'simulate': True, 'outtmpl': '%(id)s'})
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s'))

    # Test that the

# Generated at 2022-06-18 15:39:38.912101
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange

    ydl = YoutubeDL({})
    ydl.add_default_info_extractors()
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s'))
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s - %(album)s'))
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s - %(album)s - %(track)s'))

# Generated at 2022-06-18 15:39:48.190136
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP


# Generated at 2022-06-18 15:39:59.548177
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.PostProcessor import PostProcessor
    from youtube_dl.utils import DateRange
    import datetime

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, message):
            self.to_screen_calls.append(message)


# Generated at 2022-06-18 15:40:07.086941
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor import gen_extractors
    from .compat import compat_urllib_request
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_error
    from .compat import compat_http_client
    from .compat import compat_cookiejar
    from .compat import compat_str
    from .compat import compat_urlparse
    from .compat import compat_struct_pack
    from .compat import compat_struct_unpack
    from .compat import compat_chr
    from .compat import compat_ord
    from .compat import compat_urllib_parse_urlencode
    from .compat import compat_urllib_parse_unquote
    from .compat import compat_urllib

# Generated at 2022-06-18 15:40:17.248127
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test with a regex that matches the title
    titleformat = '%(title)s - %(artist)s'
    title = 'Test title - Test artist'
    info = {'title': title}
    pp = MetadataFromTitlePP(None, titleformat)
    _, info = pp.run(info)
    assert info['title'] == 'Test title'
    assert info['artist'] == 'Test artist'

    # Test with a regex that does not match the title
    titleformat = '%(title)s - %(artist)s'
    title = 'Test title'
    info = {'title': title}
    pp = MetadataFromTitlePP(None, titleformat)
    _, info = pp.run(info)
    assert info['title'] == title
    assert 'artist' not in info

    # Test with

# Generated at 2022-06-18 15:40:27.640440
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.youtube import YoutubeIE
    from youtube_dl.utils import DateRange

    ydl = YoutubeDL({'writedescription': True,
                     'writeinfojson': True,
                     'writethumbnail': True,
                     'writeannotations': True,
                     'writeautomaticsub': True,
                     'skip_download': True,
                     'simulate': True,
                     'format': 'bestvideo[height<=?1080]+bestaudio/best',
                     'outtmpl': '%(id)s.%(ext)s',
                     'postprocessors': [{
                         'key': 'MetadataFromTitle',
                         'titleformat': '%(title)s - %(artist)s',
                     }]})
    ydl.add_default

# Generated at 2022-06-18 15:40:33.793448
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.pop('_type', None)

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)


# Generated at 2022-06-18 15:40:41.613043
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.compat import compat_str

    class FakeDownloader:
        def __init__(self):
            self.to_screen_list = []

        def to_screen(self, msg):
            self.to_screen_list.append(msg)

    class FakeInfo:
        def __init__(self, title):
            self.title = title

    def test_run(titleformat, title, expected_info):
        downloader = FakeDownloader()
        info = FakeInfo(title)
        pp = MetadataFromTitlePP(downloader, titleformat)
        pp.run(info)
        assert info.__dict__ == expected_info

# Generated at 2022-06-18 15:40:59.882996
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest
    import sys
    import os
    import tempfile
    import shutil
    import json
    from ydl.downloader import Downloader
    from ydl.postprocessor import MetadataFromTitlePP

    class TestDownloader(Downloader):
        def __init__(self, params):
            super(TestDownloader, self).__init__(params)

        def to_screen(self, msg):
            print(msg)

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:41:11.939608
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader=None, ie_key=None, ie_desc=None):
            super(FakeInfoExtractor, self).__init__(downloader, ie_key, ie_desc)
            self.num_downloads = 0

        def _real_extract(self, url):
            self.num_downloads += 1

# Generated at 2022-06-18 15:41:22.055352
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange

    # Test 1:
    # Test with a titleformat that does not contain any %(..)s
    # The titleformat is '%(title)s - %(artist)s'
    # The title is 'Test Title - Test Artist'
    # The expected result is that the title is not changed
    # and the artist is set to 'Test Artist'

# Generated at 2022-06-18 15:41:30.704726
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeInfoExtractor, self).__init__(*args, **kwargs)
            self._downloader = YoutubeDL(params={})


# Generated at 2022-06-18 15:41:41.249526
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            self.downloader = downloader

        def _real_extract(self, url):
            return {'title': 'foo - bar'}

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, params):
            self.params = params
            self.to_screen_called = False

        def to_screen(self, msg):
            self.to_screen_called = True

    ie = FakeInfoExtractor(FakeYoutubeDL({}))
    ie.add_info_extractor

# Generated at 2022-06-18 15:41:52.329391
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            super(FakeInfoExtractor, self).__init__(downloader)
            self._type = 'fake'


# Generated at 2022-06-18 15:42:03.529387
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    from ydl.downloader import Downloader
    from ydl.postprocessor import PostProcessor
    from ydl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    # Create temporary downloader
    ydl = Downloader({'outtmpl': tmpfile.name, 'quiet': True, 'logger': Downloader.std_logger})
    # Create temporary postprocessor
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    # Create temporary info dict

# Generated at 2022-06-18 15:42:14.987971
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ydl.postprocessor.common import PostProcessor
    from ydl.downloader.common import FileDownloader
    from ydl.compat import compat_str

    class MockDownloader(FileDownloader):
        def __init__(self, params):
            FileDownloader.__init__(self, params)
            self.to_screen_messages = []

        def to_screen(self, message):
            self.to_screen_messages.append(message)

    class MockInfo(dict):
        def __init__(self, title):
            dict.__init__(self)
            self['title'] = title

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.downloader = MockDownloader({})
           

# Generated at 2022-06-18 15:42:25.549465
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create a temporary python script
    fd, tmpscript = tempfile.mkstemp(dir=tmpdir, suffix='.py')

# Generated at 2022-06-18 15:42:36.249988
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)

    class MockPostProcessor(PostProcessor):
        def __init__(self, *args, **kwargs):
            super(MockPostProcessor, self).__init__(*args, **kwargs)
            self.run_calls = []


# Generated at 2022-06-18 15:43:00.637168
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange
    from youtube_dl.compat import compat_str

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_messages = []

        def to_screen(self, message):
            self.to_screen_messages.append(message)

    class MockPostProcessor(PostProcessor):
        def __init__(self, *args, **kwargs):
            super(MockPostProcessor, self).__init__(*args, **kwargs)
            self.run_called = False



# Generated at 2022-06-18 15:43:08.470600
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            super(FakeInfoExtractor, self).__init__(downloader)
            self._type = 'fake'

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, params):
            super(FakeYoutubeDL, self).__init__(params)
            self._ies = [FakeInfoExtractor(self)]
            self._download_retcode = 0
            self._num_downloads = 0
            self._screen_file = None
            self._screen_file = open('/dev/null', 'w')

    ydl = FakeYoutubeDL

# Generated at 2022-06-18 15:43:18.482804
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import common

    # Test with a simple title format
    titleformat = '%(title)s'
    title = 'Test title'
    info = {'title': title}
    pp = MetadataFromTitlePP(YoutubeDL(), titleformat)
    pp.run(info)
    assert info['title'] == title

    # Test with a more complex title format
    titleformat = '%(title)s - %(artist)s'
    title = 'Test title - Test artist'
    info = {'title': title}
    pp = MetadataFromTitlePP(YoutubeDL(), titleformat)
    pp.run(info)
    assert info['title'] == 'Test title'

# Generated at 2022-06-18 15:43:29.414079
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'test'
        _VALID_URL = r'https?://.+'


# Generated at 2022-06-18 15:43:37.391012
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ydl.YoutubeDL import YoutubeDL
    from ydl.postprocessor.common import PostProcessor
    from ydl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            pass

        def to_screen(self, msg):
            sys.stdout.write(msg + '\n')

    class MockPostProcessor(PostProcessor):
        def __init__(self, *args, **kwargs):
            pass

        def run(self, info):
            return [], info

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.ydl = MockYoutubeDL()

# Generated at 2022-06-18 15:43:47.309646
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.compat import compat_str

    # Create a YoutubeDL object

# Generated at 2022-06-18 15:43:58.425416
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, message):
            self.to_screen_calls.append(message)

    class MockPostProcessor(PostProcessor):
        def __init__(self, *args, **kwargs):
            super(MockPostProcessor, self).__init__(*args, **kwargs)
            self.run_calls = []


# Generated at 2022-06-18 15:44:07.175167
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.postprocessor import FFmpegExtractAudioPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # Mock YoutubeDL object

# Generated at 2022-06-18 15:44:18.216854
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeInfoExtractor, self).__init__(*args, **kwargs)
            self._downloader = YoutubeDL(params={})

    class FakePostProcessor(PostProcessor):
        def __init__(self, *args, **kwargs):
            super(FakePostProcessor, self).__init__(*args, **kwargs)


# Generated at 2022-06-18 15:44:27.639071
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            self.downloader = downloader


# Generated at 2022-06-18 15:45:06.986766
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader, *args, **kwargs):
            super(FakeInfoExtractor, self).__init__(downloader, *args, **kwargs)
            self._title = '%(title)s - %(artist)s'


# Generated at 2022-06-18 15:45:17.573477
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import os
    import tempfile
    import shutil
    import unittest
    from ydl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.downloader = FakeYDL()
            self.downloader.params['outtmpl'] = os.path.join(self.tmpdir, '%(title)s.%(ext)s')

        def tearDown(self):
            shutil.rmtree(self.tmpdir)

        def test_run(self):
            info = {
                'title': 'The Title - The Artist',
                'ext': 'mp4',
            }

# Generated at 2022-06-18 15:45:27.386843
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            self.downloader = downloader

        def _real_extract(self, url):
            return {'id': 'fakeid', 'title': 'faketitle'}

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYoutubeDL, self).__init__(*args, **kwargs)
            self.extractor = FakeInfoExtractor(self)

    def test_run(titleformat, expected_info):
        ydl

# Generated at 2022-06-18 15:45:36.556330
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name):
            super(FakeInfoExtractor, self).__init__(ie_name)


# Generated at 2022-06-18 15:45:44.205990
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)

# Generated at 2022-06-18 15:45:53.635613
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            self.downloader = downloader


# Generated at 2022-06-18 15:46:00.060454
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name):
            super(FakeInfoExtractor, self).__init__(ie_name)
            self.ie_name = ie_name


# Generated at 2022-06-18 15:46:09.084205
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.compat import compat_str
    from datetime import date

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader=None):
            super(FakeInfoExtractor, self).__init__(downloader)
            self._matching_regexes = ['http://example.com/test']


# Generated at 2022-06-18 15:46:18.866813
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            super(FakeInfoExtractor, self).__init__(downloader)
            self._type = 'fake'


# Generated at 2022-06-18 15:46:26.147814
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ytdl.YoutubeDL import YoutubeDL

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_list = []

        def to_screen(self, msg):
            self.to_screen_list.append(msg)

    class TestMetadataFromTitlePP(unittest.TestCase):
        def test_run(self):
            ydl = MockYoutubeDL()
            pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
            info = {'title': 'Test Title - Test Artist'}
            pp.run(info)