

# Generated at 2022-06-18 15:37:27.842757
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test with a regex containing a group
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    info = {'title': 'Test title - Test artist'}
    pp.run(info)
    assert info['title'] == 'Test title'
    assert info['artist'] == 'Test artist'

    # Test with a regex not containing a group
    pp = MetadataFromTitlePP(None, 'Test title - Test artist')
    info = {'title': 'Test title - Test artist'}
    pp.run(info)
    assert info['title'] == 'Test title - Test artist'
    assert 'artist' not in info

    # Test with a regex not matching the title
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    info

# Generated at 2022-06-18 15:37:30.651234
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-18 15:37:41.993679
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s')._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, '%(title)s')._titleregex == '(?P<title>.+)'
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(album)s')._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'

# Generated at 2022-06-18 15:37:52.386886
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import FileDownloader
    from .extractor import gen_extractors
    from .postprocessor import gen_pp_from_info_dicts

    # Test with a simple format
    titleformat = '%(title)s - %(artist)s'
    titleregex = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(FileDownloader(gen_extractors(), gen_pp_from_info_dicts()), titleformat)._titleregex == titleregex

    # Test with a format containing special characters
    titleformat = '%(title)s - %(artist)s - (?P<year>\d+)'

# Generated at 2022-06-18 15:38:01.984859
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ydl.postprocessor import MetadataFromTitlePP

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.downloader = MockYDL()
            self.pp = MetadataFromTitlePP(self.downloader, '%(title)s - %(artist)s')

        def test_run(self):
            info = {'title': 'foo - bar'}
            self.pp.run(info)
            self.assertEqual(info['title'], 'foo')
            self.assertEqual(info['artist'], 'bar')

    class MockYDL(object):
        def to_screen(self, msg):
            pass


# Generated at 2022-06-18 15:38:13.758618
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import FileDownloader
    pp = MetadataFromTitlePP(FileDownloader({}), '%(title)s - %(artist)s')
    assert pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s - %(album)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'

# Generated at 2022-06-18 15:38:23.372426
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            super(FakeInfoExtractor, self).__init__(downloader)
            self._type = 'fake'
            self._TITLE = 'Fake'


# Generated at 2022-06-18 15:38:34.285774
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    pp = MetadataFromTitlePP(ydl, '%(artist)s - %(title)s')
    assert pp._titleformat == '%(artist)s - %(title)s'
    assert pp._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'
    pp = MetadataFromTitlePP(ydl, '%(artist)s - %(title)s - %(album)s')
    assert pp._titleformat == '%(artist)s - %(title)s - %(album)s'
    assert pp._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)\ \-\ (?P<album>.+)'
    pp = Met

# Generated at 2022-06-18 15:38:43.698664
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.postprocessor import FFmpegMetadataPP

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)


# Generated at 2022-06-18 15:38:55.726303
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # Test 1: Test parsing of title
    # Test 1.1: Test parsing of title with regex
    titleformat = '%(artist)s - %(title)s'
    titleregex = '(?P<artist>.+) - (?P<title>.+)'
    title = 'Test Artist - Test Title'
    info = {'title': title}
    pp = MetadataFromTitlePP(FileDownloader(YoutubeDL()), titleformat)
    pp.run(info)
    assert info['artist'] == 'Test Artist'

# Generated at 2022-06-18 15:39:05.240134
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test with a titleformat that contains no regex group
    titleformat = '%(title)s - %(artist)s'
    title = 'My title - My artist'
    info = {'title': title}
    pp = MetadataFromTitlePP(None, titleformat)
    pp.run(info)
    assert info['title'] == title
    assert info['artist'] == 'My artist'

    # Test with a titleformat that contains a regex group
    titleformat = '%(title)s - %(artist)s'
    title = 'My title - My artist'
    info = {'title': title}
    pp = MetadataFromTitlePP(None, titleformat)
    pp.run(info)
    assert info['title'] == title
    assert info['artist'] == 'My artist'

    # Test with a titleformat

# Generated at 2022-06-18 15:39:13.080319
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader, name):
            super(FakeInfoExtractor, self).__init__(downloader)
            self._name = name


# Generated at 2022-06-18 15:39:23.138118
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    import os
    import tempfile

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a YoutubeDL object

# Generated at 2022-06-18 15:39:32.566862
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP

    # Test with a video that has a title that matches the titleformat
    # and a video that does not match the titleformat

# Generated at 2022-06-18 15:39:43.261903
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import DownloadError

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader, name):
            super(FakeInfoExtractor, self).__init__(downloader, name)


# Generated at 2022-06-18 15:39:51.259569
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            InfoExtractor.__init__(self, downloader)
            self._type = 'fake'
            self._TITLE = 'Fake'

        def _real_extract(self, url):
            return {'id': 'fakeid', 'title': 'Fake title - Fake artist'}

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYoutubeDL, self).__

# Generated at 2022-06-18 15:40:01.967015
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_called = False
            self.to_screen_msg = None

        def to_screen(self, msg):
            self.to_screen_called = True
            self.to_screen_msg = msg


# Generated at 2022-06-18 15:40:13.978517
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    import datetime
    import unittest

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)

    class FakeIE(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeIE, self).__init__(*args, **kwargs)
            self.title = 'Test title'


# Generated at 2022-06-18 15:40:24.583876
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from datetime import date

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)


# Generated at 2022-06-18 15:40:32.211291
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeInfoExtractor, self).__init__(*args, **kwargs)
            self._type = 'fake'

    class FakePostProcessor(PostProcessor):
        def __init__(self, *args, **kwargs):
            super(FakePostProcessor, self).__init__(*args, **kwargs)
            self._type

# Generated at 2022-06-18 15:40:42.350771
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class TestIE(InfoExtractor):
        def __init__(self, downloader=None, ie_key=None, ie_info=None):
            super(TestIE, self).__init__(downloader, ie_key, ie_info)


# Generated at 2022-06-18 15:40:50.111432
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange
    from youtube_dl.compat import compat_str

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, message, skip_eol=False):
            self.to_screen_calls.append(message)

    class MockPostProcessor(PostProcessor):
        def __init__(self, *args, **kwargs):
            super(MockPostProcessor, self).__init__(*args, **kwargs)
            self

# Generated at 2022-06-18 15:41:00.673365
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    info = {'title': 'test - test'}
    pp.run(info)
    assert info['title'] == 'test'
    assert info['artist'] == 'test'
    info = {'title': 'test - test - test'}
    pp.run(info)
    assert info['title'] == 'test - test'
    assert info['artist'] == 'test'
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s - %(album)s')
    info = {'title': 'test - test - test'}
    pp.run(info)
    assert info

# Generated at 2022-06-18 15:41:12.310443
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl.YoutubeDL import YoutubeDL
    from ytdl.PostProcessor import PostProcessor
    from ytdl.compat import compat_str
    from ytdl.extractor.common import InfoExtractor
    from ytdl.utils import sanitize_filename

    # Create a fake InfoExtractor
    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader=None, ie_key=None, ie_desc=None):
            super(FakeInfoExtractor, self).__init__(downloader, ie_key, ie_desc)
            self.num_downloads = 0

        def _real_extract(self, url):
            self.num_downloads += 1

# Generated at 2022-06-18 15:41:22.450637
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # Create a YoutubeDL object

# Generated at 2022-06-18 15:41:30.993060
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.compat import compat_str

    class FakeDownloader(YoutubeDL):
        def __init__(self):
            self.to_screen_calls = []
            self.to_screen_data = []

        def to_screen(self, message, skip_eol=False):
            self.to_screen_calls.append(message)
            self.to_screen_data.append(skip_eol)

    class FakePostProcessor(PostProcessor):
        def __init__(self, downloader):
            self.downloader = downloader

        def run(self, info):
            return [], info

    downloader = FakeDownloader()
    postprocessor = MetadataFromTitle

# Generated at 2022-06-18 15:41:41.489604
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange

    class TestPP(PostProcessor):
        def run(self, info):
            return [], info


# Generated at 2022-06-18 15:41:52.454514
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, params):
            super(MockYoutubeDL, self).__init__(params)
            self.to_screen_called = False
            self.to_screen_message = None

        def to_screen(self, message):
            self.to_screen_called = True
            self.to_screen_message = message

    class MockPostProcessor(PostProcessor):
        def __init__(self, downloader):
            super(MockPostProcessor, self).__init__(downloader)
            self.run_called = False
            self.run_info = None


# Generated at 2022-06-18 15:42:03.702557
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen = lambda *args, **kwargs: None


# Generated at 2022-06-18 15:42:15.138711
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP

    # Create a YoutubeDL object

# Generated at 2022-06-18 15:42:27.243768
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.compat import compat_str


# Generated at 2022-06-18 15:42:38.020115
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeInfoExtractor, self).__init__(*args, **kwargs)
            self._downloader = YoutubeDL({})

    ie = FakeInfoExtractor({})
    ie.add_info_extractor(
        'test',
        [{'re': '.*', 'extractors': [{'title': '%(title)s - %(artist)s'}]}])
    ie._downloader.add_post_processor(MetadataFromTitlePP(ie._downloader, '%(title)s - %(artist)s'))



# Generated at 2022-06-18 15:42:48.265276
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import os
    import tempfile
    import shutil
    from ydl.YdlUtils import YdlUtils
    from ydl.YdlLogger import YdlLogger
    from ydl.YdlDownloader import YdlDownloader
    from ydl.YdlInfoExtractors import YdlInfoExtractors

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a logger
    logger = YdlLogger()
    logger.set_downloader(YdlDownloader(YdlUtils(), YdlInfoExtractors()))

    # Create a MetadataFromTitlePP object
    pp = MetadataFromTitlePP(logger, '%(title)s - %(artist)s')

    # Test with a valid title

# Generated at 2022-06-18 15:42:57.953822
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange

    class MockInfoExtractor(InfoExtractor):
        def __init__(self, downloader, name):
            super(MockInfoExtractor, self).__init__(downloader)
            self._name = name


# Generated at 2022-06-18 15:43:06.595410
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class TestPP(PostProcessor):
        def run(self, info):
            return [], info

    ydl = YoutubeDL({'writedescription': True, 'writethumbnail': True, 'writeinfojson': True, 'writeannotations': True})
    ydl.add_post_processor(TestPP(ydl))
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s'))
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(artist)s - %(title)s'))
    ydl.add_

# Generated at 2022-06-18 15:43:17.890558
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.compat import compat_str
    from io import BytesIO

    # Create a YoutubeDL object

# Generated at 2022-06-18 15:43:29.202458
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeInfoExtractor, self).__init__(*args, **kwargs)
            self._title = 'Test title'

        def _real_extract(self, url):
            return {'id': 'testid', 'title': self._title}


# Generated at 2022-06-18 15:43:37.165434
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.utils import DateRange
    from datetime import date

    # Test with a regex that matches the title
    ydl = YoutubeDL({'writethumbnail': True, 'writesubtitles': True, 'writeautomaticsub': True, 'skip_download': True, 'format': 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'})
    ydl.add_default_info_extractors()
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s'))

# Generated at 2022-06-18 15:43:47.071230
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import gen_extractors
    from youtube_dl.postprocessor import gen_pp_confs
    from youtube_dl.postprocessor.common import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # Create a YoutubeDL object

# Generated at 2022-06-18 15:43:52.523925
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    def test_run(titleformat, title, expected_info):
        ydl = YoutubeDL({'writedescription': True, 'writeinfojson': True})
        dl = FileDownloader(ydl, {'outtmpl': '%(id)s'})
        pp = MetadataFromTitlePP(dl, titleformat)
        info = FakeInfoDict({'id': 'test', 'title': title})

# Generated at 2022-06-18 15:44:08.261250
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.youtube import YoutubeIE
    from youtube_dl.utils import DateRange

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    # Test with a simple format
    ydl = YoutubeDL({'writedescription': True, 'writeinfojson': True, 'outtmpl': '%(title)s.%(ext)s'})
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(YoutubeIE())

# Generated at 2022-06-18 15:44:19.033174
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor import FFmpegMetadataPP


# Generated at 2022-06-18 15:44:28.301723
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor import FFmpegMetadataPP

    # Create a YoutubeDL object

# Generated at 2022-06-18 15:44:38.736959
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor


# Generated at 2022-06-18 15:44:47.483541
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a YoutubeDL object
    ydl_opts = {
        'format': 'bestaudio/best',
        'outtmpl': os.path.join(temp_dir, '%(title)s-%(id)s.%(ext)s'),
        'postprocessors': [{
            'key': 'MetadataFromTitle',
            'titleformat': '%(title)s - %(artist)s',
        }],
    }
    ydl = YoutubeDL(ydl_opts)

    # Test 1: titleformat = '%(title)s - %(artist)s'
    # title = 'The

# Generated at 2022-06-18 15:44:58.497230
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE

    # Test with a video that has a title that matches the format
    # '%(title)s - %(artist)s'
    def _test_run_match(titleformat):
        ydl = YoutubeDL({'writethumbnail': True, 'outtmpl': '%(id)s'})
        ydl.add_info_extractor(YoutubeIE())
        ydl.add_post_processor(MetadataFromTitlePP(ydl, titleformat))
        ydl.params['usenetrc'] = False
        ydl.params['username'] = None
        ydl.params['password'] = None
       

# Generated at 2022-06-18 15:45:08.104584
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.youtube import YoutubeIE

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self


# Generated at 2022-06-18 15:45:19.272237
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.PostProcessor import PostProcessor
    from youtube_dl.compat import compat_str

    class TestPP(PostProcessor):
        def __init__(self, downloader):
            super(TestPP, self).__init__(downloader)
            self.run_called = False

        def run(self, info):
            self.run_called = True
            return [], info

    ydl = YoutubeDL({'writedescription': True})
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    tpp = TestPP(ydl)
    ydl.add_post_processor(pp)
    ydl.add_post_processor(tpp)


# Generated at 2022-06-18 15:45:29.012752
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.filename = 'test.mp4'

    # Test with a simple format
    ydl = YoutubeDL({'writethumbnail': True, 'writeinfojson': True, 'simulate': True})
    ydl.add_default_info_extractors()
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s'))

# Generated at 2022-06-18 15:45:39.382340
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.extractor.youtube import YoutubeIE
    from youtube_dl.utils import DateRange

    # Create a YoutubeDL object
    ydl = YoutubeDL({'writedescription': True, 'writeinfojson': True, 'writethumbnail': True, 'writeautomaticsub': True, 'writeannotations': True})
    # Create a FileDownloader object
    fd = FileDownloader(ydl, {'simulate': True, 'quiet': True, 'outtmpl': '%(id)s'})
    # Create a YoutubeIE object
    ie = YoutubeIE(ydl)
    # Add the info extractor to the FileDownloader object
    fd.add_info_extractor(ie)

   

# Generated at 2022-06-18 15:46:06.115669
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE

    ydl = YoutubeDL({'writedescription': True, 'writeinfojson': True, 'writethumbnail': True, 'writeautomaticsub': True, 'skip_download': True})
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(YoutubeIE())
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s'))

    ydl.download(['https://www.youtube.com/watch?v=BaW_jenozKc'])

# Generated at 2022-06-18 15:46:14.447732
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.youtube import YoutubeIE
    from youtube_dl.utils import DateRange

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen = lambda *args, **kwargs: None

    ydl = FakeYoutubeDL(params={'writethumbnail': True, 'writeinfojson': True})

# Generated at 2022-06-18 15:46:23.189187
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import os
    import tempfile
    import shutil
    from ydl.downloader import Downloader
    from ydl.postprocessor import PostProcessor
    from ydl.extractor import get_info_extractor

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create a temporary file
    tmp_file = tempfile.NamedTemporaryFile(dir=tmp_dir, delete=False)
    tmp_file.close()

    # Create a downloader
    ydl = Downloader({'outtmpl': tmp_file.name,
                      'quiet': True,
                      'logger': Downloader.get_default_logger()})

    # Create a postprocessor
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')



# Generated at 2022-06-18 15:46:34.181765
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    def test_postprocessor(self, info):
        return [], info


# Generated at 2022-06-18 15:46:44.686032
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            self.downloader = downloader


# Generated at 2022-06-18 15:46:53.354541
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeInfoExtractor, self).__init__(*args, **kwargs)
            self._downloader = YoutubeDL(params={})

    ie = FakeInfoExtractor()
    pp = MetadataFromTitlePP(ie._downloader, '%(title)s - %(artist)s')
    info = {'title': 'Foo - Bar'}
    pp.run(info)
    assert info['title'] == 'Foo - Bar'
    assert info['artist'] == 'Bar'
    info = {'title': 'Foo - Bar - Baz'}
    pp.run(info)

# Generated at 2022-06-18 15:47:04.452506
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeInfoExtractor, self).__init__(*args, **kwargs)
            self._downloader = YoutubeDL(params={})

    class FakePostProcessor(PostProcessor):
        def __init__(self, *args, **kwargs):
            super(FakePostProcessor, self).__init__(*args, **kwargs)
            self._downloader = YoutubeDL(params={})

    ie

# Generated at 2022-06-18 15:47:15.380775
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    from .downloader import YoutubeDL
    from .extractor import YoutubeIE

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_called = False

        def to_screen(self, msg):
            self.to_screen_called = True

    class MockYoutubeIE(YoutubeIE):
        def __init__(self, *args, **kwargs):
            super(MockYoutubeIE, self).__init__(*args, **kwargs)
            self.extract_called = False

        def _real_extract(self, url):
            self.extract_called = True