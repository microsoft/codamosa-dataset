

# Generated at 2022-06-18 15:37:32.318213
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    assert pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s - %(album)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'

# Generated at 2022-06-18 15:37:43.024895
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.PostProcessor import PostProcessor
    from youtube_dl.utils import DateRange

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self['title'] = 'Title'
            self['artist'] = 'Artist'
            self['album'] = 'Album'
            self['track'] = 'Track'
            self['track_number'] = 'TrackNumber'
            self['genre'] = 'Genre'
            self['date'] = 'Date'
            self['creator'] = 'Creator'
            self['release_date'] = 'ReleaseDate'
            self['upload_date'] = 'UploadDate'
            self

# Generated at 2022-06-18 15:37:49.931575
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ydl.downloader import Downloader
    from ydl.postprocessor import PostProcessor
    from ydl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeDownloader(Downloader):
        def __init__(self, *args, **kwargs):
            super(FakeDownloader, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)


# Generated at 2022-06-18 15:37:58.020507
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name, ie_id):
            super(FakeInfoExtractor, self).__init__(ie_name, ie_id)
            self._type = 'fake'


# Generated at 2022-06-18 15:38:09.047265
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.youtube import YoutubeIE

    ydl = YoutubeDL({'quiet': True})
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(YoutubeIE())
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s'))

    # Test with a video that has the title 'Artist - Title'
    info = ydl.extract_info('https://www.youtube.com/watch?v=BaW_jenozKc', download=False)
    assert info['title'] == 'Artist - Title'
    assert info['artist'] == 'Artist'

    # Test with a video that has the title 'Title - Artist'
    info

# Generated at 2022-06-18 15:38:18.453679
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '')
    assert pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s - %(album)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'

# Generated at 2022-06-18 15:38:29.556260
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import FileDownloader
    downloader = FileDownloader({})
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s - %(album)s') == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)\\ \\-\\ (?P<album>.+)'

# Generated at 2022-06-18 15:38:40.615470
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s'))
    info = {'title': 'Title - Artist'}
    ydl.process_ie_result(info)
    assert info['title'] == 'Title'
    assert info['artist'] == 'Artist'
    info = {'title': 'Title - Artist - Album'}
    ydl.process_ie_result(info)
    assert info['title'] == 'Title'
    assert info['artist'] == 'Artist'
    assert 'album' not in info
    info = {'title': 'Title - Artist - Album - Year'}
    ydl.process_ie_result(info)
    assert info

# Generated at 2022-06-18 15:38:51.884627
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.compat import compat_str
    from datetime import datetime

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeInfoExtractor, self).__init__(*args, **kwargs)
            self.ie_key = 'fake'


# Generated at 2022-06-18 15:39:02.105248
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor import YoutubeIE
    from .extractor.common import InfoExtractor
    from .utils import compat_urllib_request


# Generated at 2022-06-18 15:39:16.053682
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ytdl_server.downloader import Downloader

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.downloader = Downloader(params={})
            self.downloader.to_screen = lambda msg: sys.stdout.write(msg + '\n')

        def test_run(self):
            info = {'title': 'test title'}
            pp = MetadataFromTitlePP(self.downloader, '%(title)s')
            pp.run(info)
            self.assertEqual(info, {'title': 'test title'})

            info = {'title': 'test title'}

# Generated at 2022-06-18 15:39:24.732078
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader, *args, **kwargs):
            super(FakeInfoExtractor, self).__init__(downloader, *args, **kwargs)
            self._downloader = downloader


# Generated at 2022-06-18 15:39:35.473437
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            self.downloader = downloader

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, params):
            self.params = params
            self.extractor = FakeInfoExtractor(self)

    ydl = FakeYoutubeDL({'writethumbnail': True, 'writeinfojson': True})
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s'))


# Generated at 2022-06-18 15:39:45.473763
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange

    class FakeInfo:
        def __init__(self, title):
            self.title = title

    class FakeYDL:
        def __init__(self):
            self.to_screen = lambda x: None

    def test(title, titleformat, expected_info):
        ydl = FakeYDL()
        pp = MetadataFromTitlePP(ydl, titleformat)
        info = FakeInfo(title)
        pp.run(info)
        assert info.__dict__ == expected_info

    test('foo - bar', '%(title)s - %(artist)s', {'title': 'foo', 'artist': 'bar'})

# Generated at 2022-06-18 15:39:52.550465
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl.YoutubeDL import YoutubeDL
    from ytdl.PostProcessor import PostProcessor
    from ytdl.FileDownloader import FileDownloader
    from ytdl.InfoExtractors import YoutubeIE

    # Create a YoutubeDL object
    ydl = YoutubeDL({})
    # Create a FileDownloader object
    fd = FileDownloader(ydl, {'outtmpl': '%(title)s-%(id)s.%(ext)s'})
    # Create a PostProcessor object
    pp = PostProcessor(fd)
    # Create a MetadataFromTitlePP object
    mftpp = MetadataFromTitlePP(fd, '%(title)s - %(artist)s')
    # Create a YoutubeIE object
    yt = YoutubeIE(ydl)
    # Create a

# Generated at 2022-06-18 15:40:02.961637
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ytdl.YoutubeDL import YoutubeDL
    from ytdl.PostProcessor import PostProcessor
    from ytdl.compat import compat_str

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, params):
            super(MockYoutubeDL, self).__init__(params)
            self.to_screen_messages = []

        def to_screen(self, message):
            self.to_screen_messages.append(message)

    class MockPostProcessor(PostProcessor):
        def __init__(self, downloader):
            super(MockPostProcessor, self).__init__(downloader)
            self.run_called = False

        def run(self, info):
            self.run_called = True


# Generated at 2022-06-18 15:40:14.762607
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.common import MetadataFromTitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegExtractAudioPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegVideoConvertorPP

    # Create a YoutubeDL object

# Generated at 2022-06-18 15:40:25.413167
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest
    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.downloader = object()
            self.pp = MetadataFromTitlePP(self.downloader, '%(title)s - %(artist)s')

        def test_run_with_match(self):
            info = {'title': 'The title - The artist'}
            expected_info = {'title': 'The title', 'artist': 'The artist'}
            self.assertEqual(self.pp.run(info), ([], expected_info))

        def test_run_without_match(self):
            info = {'title': 'The title'}
            self.assertEqual(self.pp.run(info), ([], info))

    unittest.main()

# Generated at 2022-06-18 15:40:32.718962
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE


# Generated at 2022-06-18 15:40:39.653637
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ytdl_server.compat import compat_str

    class MockDownloader(object):
        def __init__(self):
            self.to_screen_output = []

        def to_screen(self, msg):
            self.to_screen_output.append(msg)

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.downloader = MockDownloader()
            self.pp = MetadataFromTitlePP(self.downloader, '%(title)s - %(artist)s')

        def test_run_with_match(self):
            info = {'title': 'Title - Artist'}
            self.pp.run(info)

# Generated at 2022-06-18 15:40:55.937910
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)


# Generated at 2022-06-18 15:41:03.318258
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP

    # Create a YoutubeDL object

# Generated at 2022-06-18 15:41:14.283328
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.compat import compat_str
    from tempfile import NamedTemporaryFile
    from datetime import datetime
    import os


# Generated at 2022-06-18 15:41:24.482937
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            InfoExtractor.__init__(self, downloader)
            self._type = 'fake'

        def _real_extract(self, url):
            return {'id': 'fakeid', 'title': 'faketitle'}

    class FakePostProcessor(PostProcessor):
        def run(self, info):
            return [], info

    y

# Generated at 2022-06-18 15:41:34.694532
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            super(FakeInfoExtractor, self).__init__(downloader)
            self.ie_key = 'fake'

        def _real_extract(self, url):
            return {'id': 'fakeid', 'title': 'faketitle'}

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_called = False

        def to_screen(self, msg):
            self

# Generated at 2022-06-18 15:41:42.945288
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ydl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')

        def test_run(self):
            info = {'title': 'test title - test artist'}
            self.pp.run(info)
            self.assertEqual(info['title'], 'test title')
            self.assertEqual(info['artist'], 'test artist')

    suite = unittest.TestLoader().loadTestsFromTestCase(TestMetadataFromTitlePP)
    result = unittest.TextTestRunner(stream=sys.stderr, verbosity=2).run

# Generated at 2022-06-18 15:41:53.914286
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name):
            super(FakeInfoExtractor, self).__init__(ie_name)
            self.ie_key = ie_name


# Generated at 2022-06-18 15:42:04.576343
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.postprocessor import FFmpegMetadataPP

    # Test with a titleformat that contains a regex group
    titleformat = '%(title)s - %(artist)s'
    title = 'Test title - Test artist'
    info = {'title': title}

# Generated at 2022-06-18 15:42:15.769751
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import DateRange

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            self.downloader = downloader


# Generated at 2022-06-18 15:42:25.627752
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.PostProcessor import PostProcessor
    from youtube_dl.InfoExtractors import YoutubeIE

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)

    class FakeInfoExtractor(YoutubeIE):
        def __init__(self, *args, **kwargs):
            super(FakeInfoExtractor, self).__init__(*args, **kwargs)
            self.ie_key = 'fake'


# Generated at 2022-06-18 15:42:44.584088
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.youtube import YoutubeIE
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # Test 1: Test parsing of titleformat '%(title)s - %(artist)s'
    #         with title 'Test title - Test artist'
    #         and expected result {'title': 'Test title', 'artist': 'Test artist'}
    titleformat = '%(title)s - %(artist)s'
    title = 'Test title - Test artist'
    expected_result = {'title': 'Test title', 'artist': 'Test artist'}
    ydl = YoutubeDL({'writethumbnail': True, 'outtmpl': '%(id)s'})
    ydl

# Generated at 2022-06-18 15:42:54.995227
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            self.downloader = downloader


# Generated at 2022-06-18 15:43:04.377473
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange
    from datetime import datetime

    class TestPP(PostProcessor):
        def __init__(self, downloader):
            super(TestPP, self).__init__(downloader)
            self.test_info = None

        def run(self, info):
            self.test_info = info
            return [], info

    class TestYDL(YoutubeDL):
        def __init__(self, params):
            super(TestYDL, self).__init__(params)
            self.test_info = None

        def process_info(self, info_dict):
            self.test_info = info_dict

# Generated at 2022-06-18 15:43:15.297869
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import common
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(common.InfoExtractor):
        IE_NAME = 'test'
        _VALID_URL = r'https?://.+'


# Generated at 2022-06-18 15:43:26.700393
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.compat import compat_str
    from datetime import datetime
    from collections import namedtuple

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeInfoExtractor, self).__init__(*args, **kwargs)
            self.ie_key = 'fake'


# Generated at 2022-06-18 15:43:32.881077
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor import FFmpegMetadataPP


# Generated at 2022-06-18 15:43:41.989540
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeInfoExtractor, self).__init__(*args, **kwargs)
            self._type = 'fake'


# Generated at 2022-06-18 15:43:50.338453
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            super(FakeInfoExtractor, self).__init__(downloader)
            self._type = 'fake'
            self._TITLE = 'Fake'


# Generated at 2022-06-18 15:44:00.648715
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.params = {}
            self.cache = {}


# Generated at 2022-06-18 15:44:08.374434
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.youtube import YoutubeIE
    from youtube_dl.utils import DateRange


# Generated at 2022-06-18 15:44:42.215201
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ydl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')

        def test_run(self):
            info = {'title': 'The Title - The Artist'}
            self.pp.run(info)
            self.assertEqual(info['title'], 'The Title')
            self.assertEqual(info['artist'], 'The Artist')

    suite = unittest.TestLoader().loadTestsFromTestCase(TestMetadataFromTitlePP)
    result = unittest.TextTestRunner(stream=sys.stderr, verbosity=2).run

# Generated at 2022-06-18 15:44:49.901431
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            self.downloader = downloader


# Generated at 2022-06-18 15:45:01.629365
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ydl.downloader import Downloader
    from ydl.postprocessor import PostProcessor
    from ydl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class MockDownloader(Downloader):
        def __init__(self):
            self.to_screen_called = False

        def to_screen(self, msg):
            self.to_screen_called = True

    class MockPostProcessor(PostProcessor):
        def __init__(self):
            self.run_called = False

        def run(self, info):
            self.run_called = True

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.downloader = MockDownloader()
            self.postprocessor = MockPostProcessor()


# Generated at 2022-06-18 15:45:10.018740
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.PostProcessor import PostProcessor
    from youtube_dl.utils import DateRange
    from youtube_dl.compat import compat_str

    class TestPP(PostProcessor):
        def run(self, info):
            return [], info

    ydl = YoutubeDL({'writedescription': True, 'writeinfojson': True, 'writethumbnail': True, 'writeautomaticsub': True, 'skip_download': True, 'format': 'best', 'outtmpl': '%(id)s', 'postprocessors': [{'key': 'MetadataFromTitlePP', 'titleformat': '%(title)s - %(artist)s'}, TestPP()]})
    ydl.add_default_info_extractors()
    ydl.add

# Generated at 2022-06-18 15:45:21.399782
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor import gen_extractors
    from .compat import compat_str

    class FakeInfoDict(dict):
        pass

    def test_run(titleformat, title, expected_info):
        downloader = FileDownloader({})
        downloader.add_info_extractor(gen_extractors()[0])
        pp = MetadataFromTitlePP(downloader, titleformat)
        info = FakeInfoDict({'title': title})
        pp.run(info)
        assert info == expected_info

    test_run(
        '%(title)s - %(artist)s',
        'Test - Test',
        FakeInfoDict({'title': 'Test', 'artist': 'Test'}))

# Generated at 2022-06-18 15:45:31.189412
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeInfoExtractor, self).__init__(*args, **kwargs)
            self._downloader = YoutubeDL(params={})


# Generated at 2022-06-18 15:45:41.529223
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor import gen_extractors
    from .compat import compat_urllib_request

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.defaults = {}


# Generated at 2022-06-18 15:45:51.842404
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.PostProcessor import PostProcessor
    from youtube_dl.utils import DateRange
    from datetime import datetime

    class FakeDownloader(YoutubeDL):
        def __init__(self):
            YoutubeDL.__init__(self)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)

        def to_stderr(self, msg):
            pass

        def to_console_title(self, msg):
            pass

        def trouble(self, msg=None, tb=None):
            pass

        def report_warning(self, msg):
            pass


# Generated at 2022-06-18 15:45:58.731810
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    import datetime
    import unittest

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_messages = []

        def to_screen(self, message):
            self.to_screen_messages.append(message)

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self['title'] = 'title'
            self['upload_date'] = 'upload_date'

# Generated at 2022-06-18 15:46:08.003745
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.compat import compat_str
    from unittest import TestCase

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name, ie_id):
            super(FakeInfoExtractor, self).__init__(
                FileDownloader(params={}))
            self._type = 'fake'
            self._name = ie_name
            self._id = ie_id


# Generated at 2022-06-18 15:47:06.945821
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.filename = 'test.mp4'

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_called = False
            self.to_screen_msg = ''

        def to_screen(self, msg):
            self.to_screen_called = True
            self.to_screen_msg = msg


# Generated at 2022-06-18 15:47:18.064619
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.postprocessor import FFmpegMetadataPP

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []
            self.to_screen_title_calls = []

        def to_screen(self, message, skip_eol=False, check_quiet=False):
            self.to_screen_calls.append(message)
