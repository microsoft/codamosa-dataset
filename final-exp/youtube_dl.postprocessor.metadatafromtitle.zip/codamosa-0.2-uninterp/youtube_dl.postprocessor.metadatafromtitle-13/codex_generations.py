

# Generated at 2022-06-18 15:37:33.276708
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.PostProcessor import PostProcessor
    from youtube_dl.FileDownloader import FileDownloader
    from youtube_dl.InfoExtractors import YoutubeIE
    from youtube_dl.utils import DateRange
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urlparse
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat_urllib_parse_unquote

# Generated at 2022-06-18 15:37:43.887892
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ydl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from ydl.downloader.common import FileDownloader
    from ydl.compat import compat_str

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.ydl = FileDownloader({})
            self.ydl.to_screen = lambda x: sys.stdout.write(x + '\n')

        def test_run(self):
            # Test with a titleformat that contains %(..)s
            titleformat = '%(title)s - %(artist)s'
            pp = MetadataFromTitlePP(self.ydl, titleformat)
            info = {'title': 'Test Title - Test Artist'}

# Generated at 2022-06-18 15:37:50.453045
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP


# Generated at 2022-06-18 15:37:58.347188
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'testid',
                'title': 'testtitle',
                'ext': 'mp4',
            }

    class FakePostProcessor(PostProcessor):
        def run(self, info):
            return [], info


# Generated at 2022-06-18 15:38:09.414715
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert pp.format_to_regex('%(title)s -') == '(?P<title>.+)\\ \\-'
    assert pp.format_to_regex('%(title)s - %(artist)s - %(album)s') == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)\\ \\-\\ (?P<album>.+)'

# Generated at 2022-06-18 15:38:18.660178
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.filename = 'test.mp4'

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)


# Generated at 2022-06-18 15:38:29.556630
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP

    # Test with a video that has a title that can be parsed

# Generated at 2022-06-18 15:38:40.610574
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            self.downloader = downloader


# Generated at 2022-06-18 15:38:51.842782
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor import FFmpegMetadataPP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            self.downloader = downloader

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, params):
            self.params = params
            self.extractor = FakeInfoExtractor(self)

        def to_screen(self, msg):
            pass


# Generated at 2022-06-18 15:39:02.068712
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import FileDownloader
    from .extractor import gen_extractors
    from .utils import match_filter_func

    # Create a FileDownloader object
    ydl = FileDownloader({})
    ydl.add_info_extractor(gen_extractors())
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s'))

    # Test the method format_to_regex
    assert ydl.post_processors[0].format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    # Test the method run
    ydl.params['matchtitle'] = '%(title)s - %(artist)s'
   

# Generated at 2022-06-18 15:39:13.079214
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.youtube import YoutubeIE
    from youtube_dl.utils import DateRange
    from youtube_dl.postprocessor import FFmpegMetadataPP

    # Test with a simple title format
    ydl = YoutubeDL({'writethumbnail': True, 'restrictfilenames': True, 'quiet': True, 'format': 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', 'outtmpl': '%(title)s.%(ext)s', 'postprocessors': [{'key': 'FFmpegMetadata'}, {'key': 'MetadataFromTitle', 'titleformat': '%(title)s'}]})
    ydl.add_default_info_extractors()
    y

# Generated at 2022-06-18 15:39:23.136829
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ytdl.YoutubeDL import YoutubeDL

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.ydl = MockYoutubeDL()
            self.pp = MetadataFromTitlePP(self.ydl, '%(title)s - %(artist)s')


# Generated at 2022-06-18 15:39:32.566165
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # Test 1:
    #   - Test that the method run of class MetadataFromTitlePP
    #     correctly parses the title of a video and stores the
    #     parsed values in the info dictionary.
    #   - Test that the method run of class FFmpegMetadataPP
    #     correctly stores the parsed values in the metadata of
    #     the video file.
    #   - Test that the method run of class FFmpegMetadataPP
    #     correctly stores the parsed values in the metadata of
    #     the audio file.

    # Create a

# Generated at 2022-06-18 15:39:43.262190
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest
    from collections import namedtuple
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_messages = []
            self.to_stderr_messages = []

        def to_screen(self, message):
            self.to_screen_messages.append(message)


# Generated at 2022-06-18 15:39:49.143516
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ytdl.YoutubeDL import YoutubeDL
    from ytdl.PostProcessor import PostProcessor
    from ytdl.compat import compat_str

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, params):
            self.params = params

        def to_screen(self, msg):
            pass

    class MockPostProcessor(PostProcessor):
        def __init__(self, downloader):
            self.downloader = downloader

        def run(self, info):
            return [], info

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.downloader = MockYoutubeDL({})

# Generated at 2022-06-18 15:40:00.635574
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP

    # Create a YoutubeDL object

# Generated at 2022-06-18 15:40:07.917126
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.compat import compat_str
    from datetime import datetime

    # Test with a titleformat that does not contain any %(..)s
    titleformat = '%(title)s - %(artist)s'
    titleregex = titleformat
    title = 'Test Title - Test Artist'

# Generated at 2022-06-18 15:40:18.016997
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP

    ydl = YoutubeDL({'writedescription': True, 'writeinfojson': True,
                     'writethumbnail': True, 'writeautomaticsub': True,
                     'skip_download': True, 'format': 'bestaudio/best',
                     'outtmpl': '%(id)s.%(ext)s',
                     'postprocessors': [{
                         'key': 'FFmpegMetadata'
                     }]})
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(YoutubeIE())

# Generated at 2022-06-18 15:40:28.414377
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.compat import compat_str


# Generated at 2022-06-18 15:40:36.774736
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader=None, ie_key=None, ie_desc=None):
            super(FakeInfoExtractor, self).__init__(downloader, ie_key, ie_desc)
            self._downloader = downloader


# Generated at 2022-06-18 15:40:50.280643
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name):
            super(FakeInfoExtractor, self).__init__(ie_name)


# Generated at 2022-06-18 15:41:00.734672
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            super(FakeInfoExtractor, self).__init__(downloader)
            self.IE_NAME = 'fake'

        def _real_extract(self, url):
            return {'title': 'Fake title'}

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYoutubeDL, self).__init__(*args, **kwargs)
            self.extractors = [FakeInfoExtractor(self)]


# Generated at 2022-06-18 15:41:12.354061
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.pop('_type', None)
            self.pop('_filename', None)
            self.pop('_duration', None)
            self.pop('_elapsed', None)
            self.pop('_percent_str', None)
            self.pop('_eta_str', None)
            self.pop('_speed_str', None)
            self.pop('_total_bytes_str', None)
            self

# Generated at 2022-06-18 15:41:22.495133
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import tempfile
    import unittest
    from ydl.downloader import Downloader
    from ydl.postprocessor import MetadataFromTitlePP

    class FakeYDL(object):
        def __init__(self):
            self.to_screen = sys.stdout.write

    class FakeInfo(object):
        def __init__(self, title):
            self['title'] = title

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.ydl = FakeYDL()
            self.pp = MetadataFromTitlePP(self.ydl, '%(title)s - %(artist)s')

        def test_run(self):
            info = FakeInfo('title - artist')
            self.pp.run(info)

# Generated at 2022-06-18 15:41:30.998707
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP

    ydl = YoutubeDL({'writethumbnail': True, 'writeautomaticsub': True, 'skip_download': True, 'format': 'bestaudio/best', 'outtmpl': '%(title)s.%(ext)s', 'postprocessors': [{'key': 'FFmpegMetadata'}, {'key': 'MetadataFromTitle', 'titleformat': '%(title)s - %(artist)s'}]})
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(YoutubeIE())

# Generated at 2022-06-18 15:41:41.488668
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ytdl_server.downloader import Downloader
    from ytdl_server.extractor import YoutubeIE


# Generated at 2022-06-18 15:41:52.454262
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            self.downloader = downloader

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self):
            self.extractor = FakeInfoExtractor(self)
            self.params = {}
            self.to_screen = lambda x: None

    ydl = FakeYoutubeDL()
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s'))
    info = {'title': 'test title - test artist'}

# Generated at 2022-06-18 15:42:03.702343
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.youtube import YoutubeIE
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.utils import DateRange

    # Test 1: Test that the method run of class MetadataFromTitlePP
    #         correctly parses the title of a video
    #         and adds the parsed information to the info dict
    #         of the video.
    #         The title of the video is
    #         'The title of the video - The artist of the video'
    #         and the titleformat is '%(title)s - %(artist)s'
    #         The info dict of the video should contain the keys
    #         'title' and 'artist' with the values

# Generated at 2022-06-18 15:42:15.136984
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange

    class TestPP(PostProcessor):
        def __init__(self, downloader):
            super(TestPP, self).__init__(downloader)
            self.test_info = None

        def run(self, info):
            self.test_info = info
            return [], info


# Generated at 2022-06-18 15:42:20.376027
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name):
            super(FakeInfoExtractor, self).__init__(ie_name)


# Generated at 2022-06-18 15:42:41.049707
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader import HttpFD
    from youtube_dl.postprocessor import FFmpegMetadataPP

    ydl = YoutubeDL({'writedescription': True, 'writeinfojson': True, 'writethumbnail': True, 'writeautomaticsub': True, 'skip_download': True, 'simulate': True, 'format': 'bestvideo+bestaudio/best'})
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(YoutubeIE())
    ydl.add_post_processor(FFmpegMetadataPP())

# Generated at 2022-06-18 15:42:52.591001
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP

    # Create a YoutubeDL object

# Generated at 2022-06-18 15:43:02.165258
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.compat import compat_str

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)

    class MockInfoExtractor(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(MockInfoExtractor, self).__init__(*args, **kwargs)

# Generated at 2022-06-18 15:43:09.311771
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange

    # Test with a simple title
    downloader = YoutubeDL({'writethumbnail': True, 'writesubtitles': True,
                            'writeautomaticsub': True, 'subtitleslangs': ['en'],
                            'skip_download': True, 'format': 'best',
                            'outtmpl': '%(id)s', 'nooverwrites': True,
                            'simulate': True, 'age_limit': 18,
                            'min_views': 10, 'max_views': 1000,
                            'daterange': DateRange('20120101', '20120131')})

# Generated at 2022-06-18 15:43:15.846027
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_called = 0
            self.to_screen_msg = ''

        def to_screen(self, msg):
            self.to_screen_called += 1
            self.to_screen_msg = msg

    ydl = MockYoutubeDL({})

# Generated at 2022-06-18 15:43:27.339256
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange

    # Test with a titleformat that contains no %(..)s
    titleformat = '%(title)s - %(artist)s'
    title = 'My title - My artist'
    info = {'title': title}
    pp = MetadataFromTitlePP(YoutubeDL({}), titleformat)
    pp.run(info)
    assert info['title'] == title
    assert 'artist' not in info

    # Test with a titleformat that contains %(..)s
    titleformat = '%(title)s - %(artist)s'
    title = 'My title - My artist'
    info = {'title': title}
    pp = MetadataFromTitlePP(YoutubeDL({}), titleformat)
    pp

# Generated at 2022-06-18 15:43:35.779596
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader=None):
            super(FakeInfoExtractor, self).__init__(downloader)

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, params):
            super(FakeYoutubeDL, self).__init__(params)
            self.params = params
            self.extractor = FakeInfoExtractor(self)


# Generated at 2022-06-18 15:43:43.919470
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # Create a downloader

# Generated at 2022-06-18 15:43:50.229953
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name):
            super(FakeInfoExtractor, self).__init__(ie_name)
            self.ie_key = ie_name


# Generated at 2022-06-18 15:44:00.523094
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.PostProcessor import PostProcessor
    from youtube_dl.utils import DateRange

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self['title'] = 'Foo - Bar'

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)


# Generated at 2022-06-18 15:44:33.554594
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.compat import compat_str
    from datetime import datetime

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeInfoExtractor, self).__init__(*args, **kwargs)
            self.ie_key = 'fake'


# Generated at 2022-06-18 15:44:43.371837
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ytdl_server.downloader import Downloader
    from ytdl_server.extractor import YoutubeIE
    from ytdl_server.postprocessor import FFmpegMetadataPP
    from ytdl_server.postprocessor import FFmpegExtractAudioPP
    from ytdl_server.postprocessor import FFmpegVideoConvertorPP
    from ytdl_server.postprocessor import MetadataFromTitlePP
    from ytdl_server.postprocessor import EmbedThumbnailPP
    from ytdl_server.postprocessor import FFmpegMergerPP


# Generated at 2022-06-18 15:44:50.530011
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.youtube import YoutubeIE
    from youtube_dl.utils import DateRange

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen = lambda *args, **kwargs: None

    class FakeYoutubeIE(YoutubeIE):
        def __init__(self, *args, **kwargs):
            super(FakeYoutubeIE, self).__

# Generated at 2022-06-18 15:45:01.966671
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)

    class MockPostProcessor(PostProcessor):
        def __init__(self, *args, **kwargs):
            super(MockPostProcessor, self).__init__(*args, **kwargs)
            self.run_calls = []


# Generated at 2022-06-18 15:45:10.213186
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeInfoExtractor, self).__init__(*args, **kwargs)
            self._downloader = YoutubeDL(params={'writedescription': True})

    ie = FakeInfoExtractor(downloader=None)

# Generated at 2022-06-18 15:45:21.481564
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    def test_run(titleformat, title, expected_info):
        ydl = YoutubeDL({'writethumbnail': True, 'writeinfojson': True})
        ydl.add_default_info_extractors()
        ydl.add_info_extractor(YoutubeIE())
        ydl.add_post_

# Generated at 2022-06-18 15:45:31.258371
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.extractor.youtube import YoutubeIE
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # Test with a titleformat that does not contain any regex group
    titleformat = '%(title)s - %(artist)s'
    title = 'title - artist'
    info = {'title': title}
    pp = MetadataFromTitlePP(FileDownloader(YoutubeDL()), titleformat)
    pp.run(info)
    assert info['title'] == title
    assert info['artist'] == 'artist'

    # Test with a titleformat that contains a regex group
    titleformat = '%(title)s - %(artist)s - %(track)s'

# Generated at 2022-06-18 15:45:41.543247
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor import gen_extractors
    from .utils import DateRange

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    def test_run(titleformat, title, expected_info):
        downloader = FileDownloader({})
        downloader.add_info_extractor(gen_extractors()[0])

# Generated at 2022-06-18 15:45:51.842407
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import DownloadError
    from youtube_dl.utils import ExtractorError
    from youtube_dl.utils import format_bytes
    from youtube_dl.utils import format_seconds
    from youtube_dl.utils import sanitize_open
    from youtube_dl.utils import std_headers
    from youtube_dl.utils import urlopen
    from youtube_dl.version import __version__

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []


# Generated at 2022-06-18 15:45:58.033883
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ytdl.YoutubeDL import YoutubeDL
    from ytdl.PostProcessor import PostProcessor
    from ytdl.compat import compat_str

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            self.to_screen_buffer = []
            super(MockYoutubeDL, self).__init__(*args, **kwargs)

        def to_screen(self, message):
            self.to_screen_buffer.append(message)

    class MockPostProcessor(PostProcessor):
        def __init__(self, *args, **kwargs):
            self.run_buffer = []
            super(MockPostProcessor, self).__init__(*args, **kwargs)


# Generated at 2022-06-18 15:46:49.306208
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import common
    from youtube_dl.postprocessor import FFmpegMetadataPP

    class FakeInfoExtractor(common.InfoExtractor):
        def __init__(self, ie_name):
            super(FakeInfoExtractor, self).__init__(ie_name)


# Generated at 2022-06-18 15:46:56.830218
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor import FFmpegMetadataPP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name):
            super(FakeInfoExtractor, self).__init__(ie_name)


# Generated at 2022-06-18 15:47:06.533038
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import os
    import tempfile
    import shutil
    from ydl.YdlUtils import YdlUtils
    from ydl.YdlLogger import YdlLogger
    from ydl.YdlConfig import YdlConfig
    from ydl.YdlFileDownloader import YdlFileDownloader
    from ydl.YdlInfoExtractors import YdlInfoExtractors
    from ydl.YdlPostProcessors import YdlPostProcessors

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create a dummy config file
    config_file = os.path.join(tmp_dir, 'config')

# Generated at 2022-06-18 15:47:17.665393
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # Create a YoutubeDL object

# Generated at 2022-06-18 15:47:24.491669
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.http import HttpFD
    from io import BytesIO
    from unittest import TestCase

    class DummyYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(DummyYDL, self).__init__(*args, **kwargs)
            self.to_screen_buffer = ''

        def to_screen(self, message, skip_eol=False):
            self.to_screen_buffer += message + ('\n' if not skip_eol else '')
