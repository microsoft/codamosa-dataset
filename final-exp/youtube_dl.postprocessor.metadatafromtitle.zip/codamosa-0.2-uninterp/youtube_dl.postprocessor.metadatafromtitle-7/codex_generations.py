

# Generated at 2022-06-18 15:37:29.964454
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor import FFmpegMetadataPP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name, ie_id):
            super(FakeInfoExtractor, self).__init__(ie_name, ie_id)
            self.ie_name = ie_name
            self.ie_id = ie_id

        def _real_initialize(self):
            pass


# Generated at 2022-06-18 15:37:41.187231
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from collections import defaultdict

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name, ie_id):
            super(FakeInfoExtractor, self).__init__(ie_name, ie_id)


# Generated at 2022-06-18 15:37:51.604729
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import FileDownloader
    import unittest

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.downloader = FileDownloader({})
            self.pp = MetadataFromTitlePP(self.downloader, '')

        def test_format_to_regex(self):
            self.assertEqual(
                self.pp.format_to_regex('%(title)s - %(artist)s'),
                r'(?P<title>.+)\ \-\ (?P<artist>.+)')

# Generated at 2022-06-18 15:38:01.852093
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ytdl_server.downloader import Downloader
    from ytdl_server.extractor import YoutubeIE

    class MockYoutubeIE(YoutubeIE):
        def __init__(self, downloader):
            super(MockYoutubeIE, self).__init__(downloader)

# Generated at 2022-06-18 15:38:13.670206
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            self.downloader = downloader


# Generated at 2022-06-18 15:38:23.179296
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import unittest
    import doctest
    import collections
    import json

    from .common import FileDownloader
    from .extractor import gen_extractors
    from .utils import DateRange

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp(prefix='youtube-dl-test-')

    # Download a video
    url = 'https://www.youtube.com/watch?v=BaW_jenozKc'
    filename = os.path.join(tmpdir, '%(title)s-%(id)s.%(ext)s')

# Generated at 2022-06-18 15:38:34.128163
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange
    from youtube_dl.compat import compat_str

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self['title'] = 'Test title'
            self['upload_date'] = '20140301'
            self['ext'] = 'mp4'

        def __getitem__(self, key):
            return super(FakeInfoDict, self).__getitem__(key)

        def __setitem__(self, key, value):
            super(FakeInfoDict, self).__setitem__(key, value)

# Generated at 2022-06-18 15:38:38.125003
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-18 15:38:46.004217
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.compat import compat_str

    # Create a downloader

# Generated at 2022-06-18 15:38:57.039423
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import Downloader
    from .extractor import gen_extractors
    from .postprocessor import gen_pp

    downloader = Downloader()
    downloader.add_info_extractor(gen_extractors())
    downloader.add_post_processor(gen_pp(downloader))

    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s') == '(?P<title>.+)'

# Generated at 2022-06-18 15:39:11.314637
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.PostProcessor import PostProcessor
    from youtube_dl.InfoExtractors import YoutubeIE

    # Test with a titleformat that has no regex groups
    titleformat = '%(title)s - %(artist)s'
    title = 'Test title - Test artist'
    info = {'title': title}
    ydl = YoutubeDL({'writethumbnail': True, 'quiet': True})
    ydl.add_info_extractor(YoutubeIE())
    pp = MetadataFromTitlePP(ydl, titleformat)
    pp.run(info)
    assert info['title'] == title
    assert info['artist'] == 'Test artist'

    # Test with a titleformat that has regex groups

# Generated at 2022-06-18 15:39:21.251969
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.compat import compat_str
    from tempfile import NamedTemporaryFile
    from datetime import datetime

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name):
            super(FakeInfoExtractor, self).__init__(ie_name)
            self.ie_name = ie_name


# Generated at 2022-06-18 15:39:28.481065
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import os
    import tempfile
    import shutil
    import unittest

    from ydl.downloader import Downloader
    from ydl.postprocessor import PostProcessor
    from ydl.postprocessor.common import FFmpegMetadataPP

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.filename = 'test.mp4'


# Generated at 2022-06-18 15:39:39.875599
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            super(FakeInfoExtractor, self).__init__(downloader)
            self.ie_key = 'fake'

    class FakeFileDownloader(FileDownloader):
        def __init__(self, ydl, params):
            super(FakeFileDownloader, self).__init__(ydl, params)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)


# Generated at 2022-06-18 15:39:48.866634
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.PostProcessor import PostProcessor
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.compat import compat_str
    from io import BytesIO

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)


# Generated at 2022-06-18 15:40:00.383209
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.compat import compat_str


# Generated at 2022-06-18 15:40:07.726476
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP

    # Create a downloader

# Generated at 2022-06-18 15:40:17.773550
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE

    # Test 1: Test that the method run of class MetadataFromTitlePP
    #         works correctly when the title of the video matches the
    #         format specified in the constructor.
    #
    #         The title of the video is 'The title of the video - The artist of the video'
    #         The format specified in the constructor is '%(title)s - %(artist)s'
    #         The method run should return a dictionary with the following key-value pairs:
    #             'title' : 'The title of the video'
    #             'artist' : 'The artist of the video'
    #
    #         The

# Generated at 2022-06-18 15:40:28.173214
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeInfoExtractor, self).__init__(*args, **kwargs)
            self.IE_NAME = 'fake'

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYoutubeDL, self).__init__(*args, **kwargs)
            self.extractor = FakeInfoExtractor(self)

    def test_run(titleformat, title, expected_info):
        ydl = FakeYoutubeDL()

# Generated at 2022-06-18 15:40:36.302484
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            super(FakeInfoExtractor, self).__init__(downloader)
            self._type = 'fake'


# Generated at 2022-06-18 15:40:49.870210
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    from ydl.downloader import Downloader
    from ydl.postprocessor import PostProcessor
    from ydl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    tmpfile.write(b'foo')
    tmpfile.close()

    # Create a temporary file
    tmpfile2 = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    tmpfile2.write(b'foo')
    tmpfile2.close()

    # Create a temporary file
    tmpfile3 = tempfile.Named

# Generated at 2022-06-18 15:41:00.499934
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.youtube import YoutubeIE
    from youtube_dl.utils import DateRange

    # Create a YoutubeDL object
    ydl = YoutubeDL({
        'outtmpl': '%(title)s',
        'writethumbnail': True,
        'quiet': True,
        'simulate': True,
        'skip_download': True,
        'format': 'bestaudio/best',
        'postprocessors': [{
            'key': 'MetadataFromTitle',
            'titleformat': '%(title)s - %(artist)s',
        }],
    })

    # Create a YoutubeIE object
    ie = YoutubeIE(ydl)

    # Create a test video

# Generated at 2022-06-18 15:41:12.141612
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # Create a downloader object
    ydl = YoutubeDL({'writedescription': True, 'writeinfojson': True, 'writethumbnail': True, 'writeannotations': True, 'writeautomaticsub': True, 'skip_download': True})
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(YoutubeIE())

    # Create a fake file

# Generated at 2022-06-18 15:41:22.274587
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl.YoutubeDL import YoutubeDL
    from ytdl.PostProcessor import PostProcessor
    from ytdl.compat import compat_str
    from ytdl.extractor.common import InfoExtractor


# Generated at 2022-06-18 15:41:30.856777
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import common as ext_common
    from youtube_dl.postprocessor import FFmpegMetadataPP

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)

# Generated at 2022-06-18 15:41:41.388870
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.compat import compat_str

    # Test with a single video
    ydl = YoutubeDL({'writedescription': True, 'writeinfojson': True, 'simulate': True})
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(YoutubeIE())
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s'))
    ydl.params['usenetrc'] = False
    ydl.params['username'] = None

# Generated at 2022-06-18 15:41:52.327912
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader, ie_key):
            super(FakeInfoExtractor, self).__init__(downloader)
            self._ie_key = ie_key

        def _real_extract(self, url):
            return {'id': 'fakeid', 'title': 'faketitle'}

    class FakePostProcessor(PostProcessor):
        def __init__(self, downloader):
            super

# Generated at 2022-06-18 15:42:03.528936
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.youtube import YoutubeIE
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.utils import DateRange

    ydl = YoutubeDL({'writethumbnail': True, 'writeinfojson': True, 'writedescription': True, 'writeannotations': True, 'writeautomaticsub': True, 'skip_download': True})
    ydl.add_info_extractor(YoutubeIE())
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s'))

    ydl.download(['http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert ydl.get_info_extractor

# Generated at 2022-06-18 15:42:14.987794
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            super(FakeInfoExtractor, self).__init__(downloader)
            self.ie_key = 'fake'


# Generated at 2022-06-18 15:42:25.549505
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP


# Generated at 2022-06-18 15:42:43.951238
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            self.downloader = downloader

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, params):
            self.params = params
            self.to_screen_called = False
            self.to_screen_msg = None

        def to_screen(self, msg):
            self.to_screen_called = True
            self.to_screen_msg = msg

    # Test 1: titleformat is a regex

# Generated at 2022-06-18 15:42:54.373055
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP


# Generated at 2022-06-18 15:43:04.007882
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.youtube import YoutubeIE
    from youtube_dl.utils import DateRange

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen = lambda x: None


# Generated at 2022-06-18 15:43:14.730367
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP

    # Create a downloader

# Generated at 2022-06-18 15:43:25.791214
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class TestYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(TestYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_buffer = []

        def to_screen(self, message):
            self.to_screen_buffer.append(message)


# Generated at 2022-06-18 15:43:32.494225
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_urllib_parse_unquote
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat_urllib_parse_urlencode
    from youtube_dl.compat import compat_urllib_parse_urlsplit
    from youtube_dl.compat import compat_urllib_request_urlopen
    from youtube_dl.compat import compat_urllib_error

# Generated at 2022-06-18 15:43:41.441774
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            InfoExtractor.__init__(self, downloader)
            self._type = 'fake'


# Generated at 2022-06-18 15:43:50.075898
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.youtube import YoutubeIE
    from youtube_dl.utils import DateRange
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class MockInfoExtractor(YoutubeIE):
        def __init__(self, ie_name):
            super(MockInfoExtractor, self).__init__(ie_name)


# Generated at 2022-06-18 15:44:00.335557
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self


# Generated at 2022-06-18 15:44:08.213084
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self


# Generated at 2022-06-18 15:44:40.235176
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.youtube import YoutubeIE
    from youtube_dl.utils import DateRange


# Generated at 2022-06-18 15:44:48.573207
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor import gen_extractors
    from .compat import compat_str

    def _test_run(title, titleformat, expected_info):
        downloader = FileDownloader({})
        downloader.add_info_extractor(gen_extractors()[0])
        pp = MetadataFromTitlePP(downloader, titleformat)
        info = {'title': title}
        pp.run(info)
        for key, value in expected_info.items():
            assert info[key] == value

    _test_run('foo', '%(title)s', {'title': 'foo'})
    _test_run('foo - bar', '%(title)s - %(artist)s', {'title': 'foo', 'artist': 'bar'})
    _

# Generated at 2022-06-18 15:44:59.706416
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # Create a downloader

# Generated at 2022-06-18 15:45:09.054008
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.postprocessor import FFmpegMetadataPP

    # Test with a video with a title that matches the format
    # '%(title)s - %(artist)s'
    video_id = '9bZkp7q19f0'

# Generated at 2022-06-18 15:45:20.430514
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ytdl.YoutubeDL import YoutubeDL
    from ytdl.PostProcessor import PostProcessor
    from ytdl.compat import compat_str

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, params):
            super(MockYoutubeDL, self).__init__(params)
            self.to_screen_messages = []

        def to_screen(self, message):
            self.to_screen_messages.append(message)

    class MockPostProcessor(PostProcessor):
        def __init__(self, downloader):
            super(MockPostProcessor, self).__init__(downloader)

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self

# Generated at 2022-06-18 15:45:25.895614
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # Test 1: Test parsing of title with regex
    # Test 1.1: Test parsing of title with regex and no metadata

# Generated at 2022-06-18 15:45:34.263375
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange

# Generated at 2022-06-18 15:45:43.086138
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader import HttpFD
    from youtube_dl.postprocessor import FFmpegMetadataPP

    # Create a YoutubeDL object

# Generated at 2022-06-18 15:45:52.751108
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name):
            super(FakeInfoExtractor, self).__init__(ie_name)


# Generated at 2022-06-18 15:45:59.495104
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)

# Generated at 2022-06-18 15:46:51.876264
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)


# Generated at 2022-06-18 15:46:58.281647
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import DateRange

# Generated at 2022-06-18 15:47:07.450547
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import unittest
    import ydl_opts

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.outfile = os.path.join(self.tmpdir, 'out')
            self.errfile = os.path.join(self.tmpdir, 'err')
            self.out = open(self.outfile, 'w')
            self.err = open(self.errfile, 'w')
            self.downloader = FakeYDL(ydl_opts.YDL({}), self.out, self.err)

        def tearDown(self):
            self.out.close()

# Generated at 2022-06-18 15:47:18.576240
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader, *args, **kwargs):
            super(FakeInfoExtractor, self).__init__(downloader, *args, **kwargs)
            self.ie_key = 'fake'

        def _real_extract(self, url):
            return {'id': 'fake', 'title': 'fake'}

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []
