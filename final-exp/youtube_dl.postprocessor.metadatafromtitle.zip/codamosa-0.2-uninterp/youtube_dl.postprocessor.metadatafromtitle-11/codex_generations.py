

# Generated at 2022-06-18 15:37:30.527332
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '(?P<title>.+)'
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(album)s')
    assert pp._titleformat == '%(title)s - %(artist)s - %(album)s'

# Generated at 2022-06-18 15:37:41.805962
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '%(title)s'

    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(album)s')
    assert pp._titleformat == '%(title)s - %(artist)s - %(album)s'

# Generated at 2022-06-18 15:37:52.170012
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({'writethumbnail': False, 'quiet': True})
    ydl.add_default_info_extractors()
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s'))
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s'))
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s - %(album)s'))
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s - %(album)s - %(track)s'))
    ydl

# Generated at 2022-06-18 15:37:59.407604
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP

    def test_run(title, titleformat, expected_metadata):
        downloader = FileDownloader({
            'outtmpl': '%(id)s',
            'format': 'bestaudio/best',
            'postprocessors': [
                {
                    'key': 'FFmpegMetadata',
                },
                {
                    'key': 'MetadataFromTitle',
                    'titleformat': titleformat,
                },
            ],
            'logger': YoutubeDL(YoutubeDL.params)
        })

# Generated at 2022-06-18 15:38:10.599129
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name):
            super(FakeInfoExtractor, self).__init__(ie_name)


# Generated at 2022-06-18 15:38:19.402317
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeInfoExtractor, self).__init__(*args, **kwargs)
            self.IE_NAME = 'fake'


# Generated at 2022-06-18 15:38:29.816306
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import DownloadError

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            super(FakeInfoExtractor, self).__init__(downloader)
            self._type = 'fake'


# Generated at 2022-06-18 15:38:40.864326
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor import gen_extractors
    from .compat import compat_str
    from .compat import compat_urllib_request
    from .compat import compat_urllib_parse

    # Create a FileDownloader instance
    downloader = FileDownloader({})
    downloader.add_info_extractor(gen_extractors()[0])

    # Create a MetadataFromTitlePP instance
    titleformat = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(downloader, titleformat)

    # Test with a video that has a title that matches the titleformat
    url = 'https://www.youtube.com/watch?v=BaW_jenozKc'

# Generated at 2022-06-18 15:38:52.202135
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ytdl.YoutubeDL import YoutubeDL

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_messages = []

        def to_screen(self, message):
            self.to_screen_messages.append(message)

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.downloader = MockYoutubeDL()
            self.pp = MetadataFromTitlePP(self.downloader, '%(title)s - %(artist)s')


# Generated at 2022-06-18 15:39:02.355450
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.youtube import YoutubeIE

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.setdefault('title', 'NA')

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)


# Generated at 2022-06-18 15:39:13.215261
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP

    # Create a YoutubeDL object
    ydl = YoutubeDL({'writedescription': True, 'writeinfojson': True, 'writethumbnail': True, 'writeautomaticsub': True, 'skip_download': True, 'format': 'bestvideo+bestaudio/best', 'outtmpl': '%(id)s.%(ext)s', 'postprocessors': [{'key': 'FFmpegMetadata'}]})

    # Create a FileDownloader object

# Generated at 2022-06-18 15:39:16.667546
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP


# Generated at 2022-06-18 15:39:25.212189
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE

    def test_downloader(ydl, *args, **kwargs):
        ydl.params['outtmpl'] = '%(title)s'
        ydl.params['writethumbnail'] = True
        ydl.params['writeinfojson'] = True
        ydl.params['writedescription'] = True
        ydl.params['writeannotations'] = True
        ydl.params['writeautomaticsub'] = True
        ydl.params['skip_download'] = True

# Generated at 2022-06-18 15:39:36.008943
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    from ytdl.YoutubeDL import YoutubeDL
    from ytdl.PostProcessor import PostProcessor
    from ytdl.compat import compat_str

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_messages = []

        def to_screen(self, message):
            self.to_screen_messages.append(message)

    class MockPostProcessor(PostProcessor):
        def __init__(self, *args, **kwargs):
            super(MockPostProcessor, self).__init__(*args, **kwargs)
            self.run_calls = []


# Generated at 2022-06-18 15:39:45.923406
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import os
    import tempfile
    import shutil
    import unittest
    import youtube_dl.YoutubeDL
    import youtube_dl.extractor.common
    import youtube_dl.postprocessor.metadatafromtitle

    class MockInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(MockInfoDict, self).__init__(*args, **kwargs)
            self.filename = 'dummy.mp4'

    class MockYDL(youtube_dl.YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYDL, self).__init__(*args, **kwargs)
            self.to_screen_called = False

        def to_screen(self, msg):
            self.to_screen

# Generated at 2022-06-18 15:39:52.780121
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name):
            super(FakeInfoExtractor, self).__init__(ie_name)


# Generated at 2022-06-18 15:40:03.105100
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # Test with a titleformat that contains a regex group
    titleformat = '%(title)s - %(artist)s'
    title = 'The Title - The Artist'
    expected_info = {
        'title': 'The Title',
        'artist': 'The Artist',
    }
    ydl = YoutubeDL({'writethumbnail': True, 'outtmpl': '%(id)s'})
    ydl.add_default_info_extractors()
   

# Generated at 2022-06-18 15:40:14.954023
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            InfoExtractor.__init__(self, downloader)
            self._type = 'fake'
            self._TITLE = 'Fake'


# Generated at 2022-06-18 15:40:25.579939
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ytdl.YoutubeDL import YoutubeDL

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_messages = []

        def to_screen(self, message):
            self.to_screen_messages.append(message)

    class MockInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(MockInfoDict, self).__init__(*args, **kwargs)
            self['title'] = 'title'

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.ydl

# Generated at 2022-06-18 15:40:32.819901
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            super(FakeInfoExtractor, self).__init__(downloader)
            self.ie_key = 'fake'


# Generated at 2022-06-18 15:40:48.067569
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange

    # Create a YoutubeDL object
    ydl = YoutubeDL({'writedescription': True, 'writeinfojson': True, 'writethumbnail': True, 'writeautomaticsub': True, 'skip_download': True})

    # Create a MetadataFromTitlePP object
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')

    # Test with a title that matches the regex
    info = {'title': 'Test Title - Test Artist'}
    pp.run(info)
    assert info['title'] == 'Test Title'
    assert info['artist'] == 'Test Artist'

    # Test with a title that does not match the regex
    info = {'title': 'Test Title'}


# Generated at 2022-06-18 15:40:59.734494
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            super(FakeInfoExtractor, self).__init__(downloader)
            self._type = 'fake'
            self._TITLE_RE = r'(?P<title>.*)'

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, params):
            super(FakeYoutubeDL, self).__init__(params)
            self.extractor = FakeInfoExtractor(self)

    ydl = FakeYoutubeDL({})
    pp = MetadataFromTitlePP(ydl, '%(title)s')


# Generated at 2022-06-18 15:41:11.866998
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            super(FakeInfoExtractor, self).__init__(downloader)
            self._type = 'fake'
            self._TITLE = 'Fake title'
            self._DESCRIPTION = 'Fake description'
            self._UPLOAD_DATE = '20120101'
            self._DURATION = 10


# Generated at 2022-06-18 15:41:19.854523
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange

    # Test data

# Generated at 2022-06-18 15:41:29.595602
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            self.downloader = downloader


# Generated at 2022-06-18 15:41:40.085977
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import gen_extractors


# Generated at 2022-06-18 15:41:50.711774
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.downloader.http import HttpDownloader
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.downloader.external import ExternalFD
    from youtube_dl.downloader.external import ExternalDownloader
    from youtube_dl.downloader.f4m import F4mFD
    from youtube_dl.downloader.f4m import F4mDownloader
    from youtube_dl.downloader.fragment import FragmentFD
    from youtube_dl.downloader.fragment import FragmentDownloader
   

# Generated at 2022-06-18 15:41:58.261572
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            super(FakeInfoExtractor, self).__init__(downloader)
            self._type = 'fake'
            self._TITLE_RE = r'(?P<title>.+)'

# Generated at 2022-06-18 15:42:06.752812
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name):
            super(FakeInfoExtractor, self).__init__(ie_name)

        def _real_extract(self, url):
            return {'id': 'test', 'title': 'test - test - test'}


# Generated at 2022-06-18 15:42:16.482785
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            self.downloader = downloader


# Generated at 2022-06-18 15:42:39.791273
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.compat import compat_str
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name):
            InfoExtractor.__init__(self, ie_name)


# Generated at 2022-06-18 15:42:51.408422
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name):
            super(FakeInfoExtractor, self).__init__(ie_name)


# Generated at 2022-06-18 15:43:01.045972
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.utils import DateRange


# Generated at 2022-06-18 15:43:08.725689
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.filename = 'test.mp4'


# Generated at 2022-06-18 15:43:18.650908
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.youtube import YoutubeIE
    from youtube_dl.utils import DateRange

    ydl = YoutubeDL({'writedescription': True, 'writeinfojson': True})
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(YoutubeIE())
    ydl.params['daterange'] = DateRange('20120101')
    ydl.params['usenetrc'] = False
    ydl.params['username'] = None
    ydl.params['password'] = None
    ydl.params['videopassword'] = None
    ydl.params['quiet'] = True
    ydl.params['forcejson'] = True
    ydl.params['simulate'] = True
    ydl

# Generated at 2022-06-18 15:43:29.443858
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from datetime import date

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            super(FakeInfoExtractor, self).__init__(downloader)
            self._type = 'fake'

    class FakeDownloader(YoutubeDL):
        def __init__(self, params):
            super(FakeDownloader, self).__init__(params)
            self.extractor = FakeInfoExtractor(self)

    # Test with a simple format
    ydl = FakeDownloader({'writethumbnail': True, 'outtmpl': '%(id)s'})

# Generated at 2022-06-18 15:43:37.412019
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.compat import compat_str

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self['title'] = 'This is a title'
            self['uploader'] = 'This is an uploader'
            self['upload_date'] = '20150505'
            self['extractor'] = 'This is an extractor'
            self['id'] = 'This is an id'

# Generated at 2022-06-18 15:43:47.401296
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.compat import compat_str


# Generated at 2022-06-18 15:43:58.415792
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor import gen_extractors
    from .compat import compat_str

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    def test_run(titleformat, title, expected_info):
        downloader = FileDownloader({})
        downloader.add_info_extractor(gen_extractors()[0])
        pp = MetadataFromTitlePP(downloader, titleformat)
        info = FakeInfoDict({'title': title})
        pp.run(info)
        for key, value in expected_info.items():
            assert info[key] == value


# Generated at 2022-06-18 15:44:07.185660
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            self.downloader = downloader

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, params):
            self.params = params
            self.to_screen = lambda *args, **kargs: None
            self.to_stdout = lambda *args, **kargs: None
            self.to_stderr = lambda *args, **kargs: None
            self.extractors = [FakeInfoExtractor(self)]

    def test(title, titleformat, expected):
        y

# Generated at 2022-06-18 15:44:41.841872
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ydl.downloader import Downloader
    from ydl.postprocessor import PostProcessor
    from ydl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class TestDownloader(Downloader):
        def __init__(self):
            self.to_screen_buffer = []

        def to_screen(self, message):
            self.to_screen_buffer.append(message)

    class TestPostProcessor(PostProcessor):
        def __init__(self, downloader):
            super(TestPostProcessor, self).__init__(downloader)

        def run(self, info):
            return [], info

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.downloader = TestDownloader()


# Generated at 2022-06-18 15:44:48.946172
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name, ie_id):
            super(FakeInfoExtractor, self).__init__(ie_name, ie_id)


# Generated at 2022-06-18 15:45:00.132693
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            super(FakeInfoExtractor, self).__init__(downloader)
            self._type = 'fake'


# Generated at 2022-06-18 15:45:09.395610
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    import os
    import tempfile
    import shutil
    import json

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    temp_file.close()

    # Create a YoutubeDL object

# Generated at 2022-06-18 15:45:20.771521
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE

    # Test 1:
    #   titleformat = '%(title)s - %(artist)s'
    #   title = 'This is a title - This is an artist'
    #   expected_info = {'title': 'This is a title', 'artist': 'This is an artist'}
    titleformat = '%(title)s - %(artist)s'
    title = 'This is a title - This is an artist'
    expected_info = {'title': 'This is a title', 'artist': 'This is an artist'}


# Generated at 2022-06-18 15:45:25.984817
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import common
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # Test 1:
    #   - titleformat: '%(title)s - %(artist)s'
    #   - title: 'Title - Artist'
    #   - expected:
    #       - info['title'] = 'Title'
    #       - info['artist'] = 'Artist'
    #       - info['track'] = None
    #       - info['album'] = None
    #       - info['genre'] = None
    #       - info['date'] = None
    #       - info['track_number'] = None
   

# Generated at 2022-06-18 15:45:34.262921
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # Create a YoutubeDL object

# Generated at 2022-06-18 15:45:43.086024
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            self.downloader = downloader


# Generated at 2022-06-18 15:45:52.750711
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.compat import compat_str
    from tempfile import NamedTemporaryFile
    from datetime import datetime
    import os
    import shutil
    import sys
    import unittest

    class TestInfoExtractor(InfoExtractor):
        def __init__(self, downloader=None, ie_key=None, ie_name=None):
            super(TestInfoExtractor, self).__init__(downloader, ie_key, ie_name)

# Generated at 2022-06-18 15:45:59.494944
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP

    # Create a downloader

# Generated at 2022-06-18 15:46:56.612684
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ydl.postprocessor import MetadataFromTitlePP

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')

        def test_run(self):
            info = {'title': 'The Title - The Artist'}
            self.pp.run(info)
            self.assertEqual(info['title'], 'The Title')
            self.assertEqual(info['artist'], 'The Artist')

    suite = unittest.TestLoader().loadTestsFromTestCase(TestMetadataFromTitlePP)
    result = unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-18 15:47:06.398005
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange
    from youtube_dl.compat import compat_str

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.filename = 'filename'

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.params = {}
            self.to_screen_calls = []

        def to_screen(self, message):
            self.to_screen_calls.append(message)

# Generated at 2022-06-18 15:47:17.544843
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.youtube import YoutubeIE
    from youtube_dl.utils import DateRange

    # Test 1: titleformat = '%(title)s - %(artist)s'
    #         title = 'The Title - The Artist'
    #         expected output: {'title': 'The Title', 'artist': 'The Artist'}
    ydl = YoutubeDL({'writethumbnail': False, 'quiet': True, 'format': 'bestaudio/best',
                     'postprocessors': [{
                         'key': 'MetadataFromTitle',
                         'titleformat': '%(title)s - %(artist)s'
                     }]})
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(YoutubeIE())

# Generated at 2022-06-18 15:47:24.428130
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen = lambda s: None

    class FakePP(PostProcessor):
        def __init__(self, *args, **kwargs):
            super(FakePP, self).__init__(*args, **kwargs)
