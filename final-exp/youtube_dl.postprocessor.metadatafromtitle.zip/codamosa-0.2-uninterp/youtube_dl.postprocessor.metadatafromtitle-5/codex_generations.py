

# Generated at 2022-06-18 15:37:29.433943
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegExtractAudioPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # Create a YoutubeDL object

# Generated at 2022-06-18 15:37:36.141811
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s - %(album)s') == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)\\ \\-\\ (?P<album>.+)'

# Generated at 2022-06-18 15:37:41.899690
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-18 15:37:52.256421
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import common
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(common.InfoExtractor):
        IE_NAME = 'fake'
        _VALID_URL = r'https?://.+'


# Generated at 2022-06-18 15:38:01.944825
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    pp = MetadataFromTitlePP(ydl, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '%(title)s'
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s - %(album)s')

# Generated at 2022-06-18 15:38:13.709928
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ydl.utils import DateRange

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYDL(object):
        def __init__(self):
            self.to_screen_called = False
            self.to_screen_msg = None

        def to_screen(self, msg):
            self.to_screen_called = True
            self.to_screen_msg = msg

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.ydl = FakeYDL()

# Generated at 2022-06-18 15:38:23.283481
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.PostProcessor import PostProcessor
    from youtube_dl.utils import DateRange
    from youtube_dl.compat import compat_str

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen = lambda *args, **kwargs: None

    class FakePP(PostProcessor):
        def __init__(self, *args, **kwargs):
            super

# Generated at 2022-06-18 15:38:34.182274
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.compat import compat_str
    from datetime import datetime

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            self.downloader = downloader


# Generated at 2022-06-18 15:38:43.625066
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s - %(album)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'

# Generated at 2022-06-18 15:38:55.602351
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ydl.downloader.common import FileDownloader

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.downloader = FileDownloader(params={})
            self.downloader.to_screen = lambda x: sys.stdout.write(x + '\n')

        def test_run(self):
            pp = MetadataFromTitlePP(self.downloader, '%(title)s - %(artist)s')
            info = {'title': 'test title - test artist'}
            pp.run(info)
            self.assertEqual(info['title'], 'test title')
            self.assertEqual(info['artist'], 'test artist')

    unittest.main()

# Generated at 2022-06-18 15:39:05.541699
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name):
            super(FakeInfoExtractor, self).__init__(ie_name)

        def _real_extract(self, url):
            return {'id': 'testid', 'title': 'testtitle'}

    class FakePostProcessor(PostProcessor):
        def __init__(self, pp_name):
            super(FakePostProcessor, self).__init__(pp_name)


# Generated at 2022-06-18 15:39:13.177758
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name):
            super(FakeInfoExtractor, self).__init__(ie_name)
            self.ie_name = ie_name


# Generated at 2022-06-18 15:39:23.137180
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.PostProcessor import PostProcessor
    from youtube_dl.FileDownloader import FileDownloader
    from youtube_dl.utils import DateRange

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.filename = 'test.mp4'

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)

# Generated at 2022-06-18 15:39:32.566754
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    import datetime

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            super(FakeInfoExtractor, self).__init__(downloader)
            self.ie_key = 'fake'


# Generated at 2022-06-18 15:39:43.310866
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.PostProcessor import PostProcessor
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import gen_extractors
    from youtube_dl.compat import compat_str

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
           

# Generated at 2022-06-18 15:39:49.232557
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'test'
        _VALID_URL = r'(?i)^https?://.*\.test$'


# Generated at 2022-06-18 15:40:00.793944
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # Test 1:
    #   - titleformat: '%(title)s - %(artist)s'
    #   - title: 'Test - Test'
    #   - expected result:
    #       - info['title']: 'Test'
    #       - info['artist']: 'Test'
    #       - info['track']: None
    #       - info['album']: None
    #       - info['genre']: None
    #       - info['date']: None
    #       - info['track_number']: None

# Generated at 2022-06-18 15:40:08.028754
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE


# Generated at 2022-06-18 15:40:18.110588
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)



# Generated at 2022-06-18 15:40:28.495142
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.compat import compat_str
    from datetime import datetime

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            super(FakeInfoExtractor, self).__init__(downloader)
            self.ie_key = 'fake'


# Generated at 2022-06-18 15:40:39.691837
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen = lambda msg: None


# Generated at 2022-06-18 15:40:48.202137
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class TestInfoExtractor(InfoExtractor):
        def __init__(self, downloader=None):
            super(TestInfoExtractor, self).__init__(downloader)


# Generated at 2022-06-18 15:40:59.735060
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.compat import compat_str


# Generated at 2022-06-18 15:41:11.853639
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ydl.YdlLogger import YdlLogger
    from ydl.YdlUtils import YdlUtils
    from ydl.YdlInfoExtractors import YdlInfoExtractors
    from ydl.YdlPostProcessors import YdlPostProcessors
    from ydl.YdlDownloader import YdlDownloader

    class MockYdlUtils(YdlUtils):
        def __init__(self):
            super(MockYdlUtils, self).__init__()
            self.to_screen_called = False
            self.to_screen_args = []

        def to_screen(self, message):
            self.to_screen_called = True
            self.to_screen_args.append(message)


# Generated at 2022-06-18 15:41:21.967495
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    import youtube_dl.YoutubeDL

    class MockYoutubeDL(youtube_dl.YoutubeDL):
        def __init__(self, *args, **kwargs):
            self.to_screen_list = []
            super(MockYoutubeDL, self).__init__(*args, **kwargs)

        def to_screen(self, msg):
            self.to_screen_list.append(msg)

    class TestMetadataFromTitlePP(unittest.TestCase):
        def test_run(self):
            ydl = MockYoutubeDL()
            pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
            info = {'title': 'test title - test artist'}
            pp.run(info)

# Generated at 2022-06-18 15:41:30.639957
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.filename = 'test.mp4'
            self.title = 'test title'
            self.url = 'http://example.com/test'
            self.webpage_url = 'http://example.com/test_page'
            self.fulltitle = 'test fulltitle'
            self.ext = 'mp4'
            self.format = 'test format'
            self.format_id = 'test format id'
            self.format_note = 'test format note'

# Generated at 2022-06-18 15:41:41.213727
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # Test with a titleformat that contains a regex group

# Generated at 2022-06-18 15:41:52.329184
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegMetadataPP


# Generated at 2022-06-18 15:42:03.529716
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE

    # Test with a simple title format
    titleformat = '%(title)s'
    title = 'Test Title'
    info = {'title': title}

# Generated at 2022-06-18 15:42:14.948803
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from datetime import datetime

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            super(FakeInfoExtractor, self).__init__(downloader)
            self.IE_NAME = 'fake'


# Generated at 2022-06-18 15:42:29.409495
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeInfoExtractor, self).__init__(*args, **kwargs)
            self._title = '%(title)s - %(artist)s'


# Generated at 2022-06-18 15:42:39.869489
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name):
            super(FakeInfoExtractor, self).__init__(ie_name)
            self.ie_key = ie_name


# Generated at 2022-06-18 15:42:51.500488
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.youtube import YoutubeIE
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # Test with a titleformat that contains a regex group
    titleformat = '%(title)s - %(artist)s'
    title = 'Test Title - Test Artist'
    info = {'title': title}
    pp = MetadataFromTitlePP(YoutubeDL({}), titleformat)
    pp.run(info)
    assert info['title'] == title
    assert info['artist'] == 'Test Artist'

    # Test with a titleformat that does not contain a regex group
    titleformat = 'Test Title - Test Artist'
    title = 'Test Title - Test Artist'
    info = {'title': title}
    pp = Metadata

# Generated at 2022-06-18 15:43:01.125557
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.youtube import YoutubeIE
    from youtube_dl.utils import DateRange
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # Test with a simple title format
    ydl = YoutubeDL({'writedescription': True,
                     'writeinfojson': True,
                     'writethumbnail': True,
                     'writeautomaticsub': True,
                     'subtitleslangs': ['en'],
                     'outtmpl': '%(id)s.%(ext)s',
                     'postprocessors': [{
                         'key': 'MetadataFromTitle',
                         'titleformat': '%(title)s - %(artist)s',
                     }]})
    ie = YoutubeIE(ydl)
    y

# Generated at 2022-06-18 15:43:08.763009
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name):
            super(FakeInfoExtractor, self).__init__(ie_name)


# Generated at 2022-06-18 15:43:18.651195
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor import gen_extractors
    from .compat import compat_urllib_request

    class FakeYDL(object):
        def __init__(self):
            self.extractors = gen_extractors()

# Generated at 2022-06-18 15:43:29.444393
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name, ie_id):
            super(FakeInfoExtractor, self).__init__(ie_name, ie_id)


# Generated at 2022-06-18 15:43:37.410075
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP

    # Create a YoutubeDL object

# Generated at 2022-06-18 15:43:47.307459
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import DownloadError
    from youtube_dl.utils import ExtractorError
    from youtube_dl.utils import MaxDownloadsReached
    from youtube_dl.utils import RegexNotFoundError
    from youtube_dl.utils import UnavailableVideoError
    from youtube_dl.utils import UnsupportedError
    from youtube_dl.utils import XAttrMetadataError
    from youtube_dl.utils import format_bytes
    from youtube_dl.utils import format_seconds
    from youtube_dl.utils import sanitize_filename
    from youtube_dl.utils import std_headers
    from youtube_dl.utils import write_string


# Generated at 2022-06-18 15:43:58.415700
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.compat import compat_str

    def test_titleformat(titleformat, title, expected_result):
        ydl = YoutubeDL({
            'writethumbnail': True,
            'skip_download': True,
            'simulate': True,
            'format': 'bestvideo+bestaudio/best',
            'outtmpl': '%(id)s',
            'postprocessors': [
                {
                    'key': 'MetadataFromTitle',
                    'titleformat': titleformat,
                },
                {
                    'key': 'FFmpegMetadata',
                },
            ],
        })

# Generated at 2022-06-18 15:44:23.120435
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.extractor.youtube import YoutubeIE
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # Create a downloader
    ydl = YoutubeDL({'quiet': True})
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(YoutubeIE())
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s'))
    fd = FileDownloader(ydl, {'simulate': True, 'quiet': True})

    # Test

# Generated at 2022-06-18 15:44:33.421491
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange

    class TestPP(PostProcessor):
        def __init__(self, downloader):
            super(TestPP, self).__init__(downloader)
            self.test_info = None

        def run(self, info):
            self.test_info = info
            return [], info

    ydl = YoutubeDL({'writedescription': True, 'writeinfojson': True,
                     'outtmpl': '%(title)s-%(id)s.%(ext)s'})
    pp = TestPP(ydl)
    ydl.add_post_processor(pp)

# Generated at 2022-06-18 15:44:43.253231
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.compat import compat_str

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self['title'] = 'title'
            self['artist'] = 'artist'
            self['album'] = 'album'
            self['track'] = 'track'
            self['track_number'] = 'track_number'
            self['genre'] = 'genre'
            self['date'] = 'date'
            self['creator'] = 'creator'
            self['release_date'] = 'release_date'
            self

# Generated at 2022-06-18 15:44:48.125952
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s'))
    info = {'title': 'test - foo'}
    pp_result = ydl.run_post_processors(info)
    assert pp_result['title'] == 'test'
    assert pp_result['artist'] == 'foo'

# Generated at 2022-06-18 15:44:59.154169
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # Create a YoutubeDL object

# Generated at 2022-06-18 15:45:08.661113
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name):
            super(FakeInfoExtractor, self).__init__(ie_name)
            self.ie_name = ie_name

        def _real_extract(self, url):
            return {'id': 'fakeid', 'title': 'faketitle', 'ext': 'fakeext'}

    class FakePostProcessor(PostProcessor):
        def __init__(self, pp_name):
            super(FakePostProcessor, self).__

# Generated at 2022-06-18 15:45:20.048039
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.compat import compat_str


# Generated at 2022-06-18 15:45:29.833975
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.compat import compat_str
    from io import BytesIO

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            super(FakeInfoExtractor, self).__init__(downloader)
            self._downloader = downloader


# Generated at 2022-06-18 15:45:40.289764
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.youtube import YoutubeIE
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # Test with a titleformat that does not contain any regex group
    titleformat = '%(title)s - %(artist)s'
    title = 'Test title - Test artist'
    info = {'title': title}
    ydl = YoutubeDL({'postprocessors': [{
        'key': 'MetadataFromTitle',
        'titleformat': titleformat,
    }]})
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(YoutubeIE())
    pp = MetadataFromTitlePP(ydl, titleformat)
    pp.run(info)

# Generated at 2022-06-18 15:45:50.559368
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.youtube import YoutubeIE

    class FakeInfoExtractor(object):
        IE_NAME = 'test'
        _VALID_URL = r'https?://.+'

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYoutubeDL, self).__init__(*args, **kwargs)
            self.extractor = FakeInfoExtractor()

    class FakePostProcessor(PostProcessor):
        def run(self, info):
            return [], info

    ydl = FakeYoutubeDL()

# Generated at 2022-06-18 15:46:35.959984
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl.YoutubeDL import YoutubeDL
    from ytdl.PostProcessor import PostProcessor
    from ytdl.compat import compat_str

    class MockYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)

    ydl = MockYDL()
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    info = {'title': 'Foo - Bar'}
    pp.run(info)
    assert info['title'] == 'Foo'
    assert info

# Generated at 2022-06-18 15:46:46.839021
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            super(FakeInfoExtractor, self).__init__(downloader)
            self._type = 'fake'


# Generated at 2022-06-18 15:46:55.286094
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import DownloadError
    from youtube_dl.utils import ExtractorError
    from youtube_dl.utils import format_bytes
    from youtube_dl.utils import format_seconds
    from youtube_dl.utils import sanitize_filename
    from youtube_dl.utils import std_headers
    from youtube_dl.utils import unescapeHTML
    from youtube_dl.utils import urlencode_postdata
    from youtube_dl.utils import urlopen
    from youtube_dl.utils import USER_AGENT
    from youtube_dl.utils import write_string
    from youtube_dl.utils import xpath_text
    from youtube_dl.utils import xpath

# Generated at 2022-06-18 15:47:05.524578
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_called = False

        def to_screen(self, msg):
            self.to_screen_called = True


# Generated at 2022-06-18 15:47:16.721920
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import unittest

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.outfile = os.path.join(self.tmpdir, 'out.txt')
            self.errfile = os.path.join(self.tmpdir, 'err.txt')
            self.out = open(self.outfile, 'w')
            self.err = open(self.errfile, 'w')
            self.pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')

        def tearDown(self):
            self.out.close()
            self.err.close()
            shut