

# Generated at 2022-06-18 15:37:29.693910
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.downloader.http import HttpFD

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []
            self.to_stderr_calls = []
            self.to_console_title_calls = []

        def to_screen(self, message, skip_eol=False):
            self.to_screen_calls.append(message)


# Generated at 2022-06-18 15:37:40.810495
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import FileDownloader
    from .extractor import gen_extractors
    from .postprocessor import gen_pp_descriptions

    pp = MetadataFromTitlePP(FileDownloader({}), '%(title)s - %(artist)s')
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s - %(album)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'
    assert pp

# Generated at 2022-06-18 15:37:48.876741
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Test with a simple format string
    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '(?P<title>.+)'

    # Test with a more complex format string
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-18 15:37:57.427971
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.postprocessor import FFmpegMetadataPP

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_called = False

        def to_screen(self, msg):
            self.to_screen_called = True


# Generated at 2022-06-18 15:38:08.398436
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import DownloadError
    from youtube_dl.utils import ExtractorError
    from youtube_dl.utils import MaxDownloadsReached
    from youtube_dl.utils import PostProcessingError
    from youtube_dl.utils import UnavailableVideoError
    from youtube_dl.utils import UnsupportedError
    from youtube_dl.utils import XAttrMetadataError
    from youtube_dl.utils import match_filter_func
    from youtube_dl.utils import sanitize_open
    from youtube_dl.utils import write_string
    from youtube_dl.utils import write_json_file
    from youtube_dl.utils import read_json_file

# Generated at 2022-06-18 15:38:18.009280
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import common
    from youtube_dl.postprocessor import MetadataFromTitlePP

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen = lambda *args, **kwargs: None

    class FakeExtractor(common.InfoExtractor):
        IE_NAME = 'fake'
        _VALID_

# Generated at 2022-06-18 15:38:29.513587
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import FileDownloader
    pp = MetadataFromTitlePP(FileDownloader(None), '%(title)s - %(artist)s')
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s - %(album)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'

# Generated at 2022-06-18 15:38:40.566546
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.filename = 'foo.mp4'

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)

    ydl = FakeYoutubeDL()

# Generated at 2022-06-18 15:38:51.759029
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            self.downloader = downloader


# Generated at 2022-06-18 15:39:01.996834
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl.YoutubeDL import YoutubeDL
    from ytdl.extractor.common import InfoExtractor
    from ytdl.utils import DateRange


# Generated at 2022-06-18 15:39:13.056598
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.compat import compat_str
    from youtube_dl.extractor import YoutubeIE

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    def test_run_helper(titleformat, title, expected_info):
        ydl = YoutubeDL({'quiet': True, 'skip_download': True})
        ydl.add_default_info_extractors()
        ydl.add_info_extractor(YoutubeIE())
        ydl.params['writethumbnail'] = False

# Generated at 2022-06-18 15:39:23.138510
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)



# Generated at 2022-06-18 15:39:32.566784
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP


# Generated at 2022-06-18 15:39:43.262214
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    ie = YoutubeIE()
    ie.extract('https://www.youtube.com/watch?v=BaW_jenozKc')
    info = ie.result


# Generated at 2022-06-18 15:39:51.230849
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.compat import compat_str


# Generated at 2022-06-18 15:40:01.966710
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.compat import compat_str
    from datetime import datetime
    from tempfile import NamedTemporaryFile


# Generated at 2022-06-18 15:40:13.978293
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ydl.downloader.common import FileDownloader
    from ydl.postprocessor.common import PostProcessor
    from ydl.postprocessor.fromtitle import MetadataFromTitlePP

    class MockDownloader(FileDownloader):
        def __init__(self, *args, **kwargs):
            super(MockDownloader, self).__init__(*args, **kwargs)
            self.to_screen_messages = []

        def to_screen(self, message):
            self.to_screen_messages.append(message)

    class MockPostProcessor(PostProcessor):
        def __init__(self, *args, **kwargs):
            super(MockPostProcessor, self).__init__(*args, **kwargs)
            self.run_called = False

# Generated at 2022-06-18 15:40:24.583064
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.compat import compat_str

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)


# Generated at 2022-06-18 15:40:32.211208
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.PostProcessor import PostProcessor
    from youtube_dl.InfoExtractors import YoutubeIE

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_called = False
            self.to_screen_msg = None

        def to_screen(self, msg):
            self.to_screen_called = True
            self.to_screen_msg = msg

    class MockPostProcessor(PostProcessor):
        def __init__(self, *args, **kwargs):
            super(MockPostProcessor, self).__init__(*args, **kwargs)

# Generated at 2022-06-18 15:40:39.338223
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name):
            InfoExtractor.__init__(self, ie_name)


# Generated at 2022-06-18 15:40:54.142325
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name, ie_id):
            super(FakeInfoExtractor, self).__init__(ie_name, ie_id)


# Generated at 2022-06-18 15:41:02.614194
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            InfoExtractor.__init__(self, downloader)
            self._type = 'fake'


# Generated at 2022-06-18 15:41:14.027062
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.PostProcessor import PostProcessor
    from youtube_dl.utils import DateRange
    from datetime import datetime

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self['title'] = 'The title'
            self['upload_date'] = '20150630'
            self['uploader'] = 'The uploader'
            self['description'] = 'The description'
            self['categories'] = ['The category']
            self['tags'] = ['The tag']
            self['duration'] = 60
            self['view_count'] = 1000
            self['like_count'] = 100

# Generated at 2022-06-18 15:41:24.224548
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    ydl = YoutubeDL({'writethumbnail': True, 'writedescription': True, 'writeinfojson': True, 'writeannotations': True, 'writeautomaticsub': True, 'skip_download': True, 'simulate': True, 'format': 'bestvideo+bestaudio/best'})
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(YoutubeIE())

# Generated at 2022-06-18 15:41:34.190536
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader=None):
            super(FakeInfoExtractor, self).__init__(downloader)
            self._type = 'fake'

    class FakePostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            super(FakePostProcessor, self).__init__(downloader)

        def run(self, info):
            return [], info


# Generated at 2022-06-18 15:41:42.714913
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            super(FakeInfoExtractor, self).__init__(downloader)
            self._type = 'fake'

    class FakeFileDownloader(FileDownloader):
        def __init__(self, ydl, params):
            super(FakeFileDownloader, self).__init__(ydl, params)
            self.to_screen_calls = []

        def to_screen(self, message, skip_eol=False):
            self.to_screen_calls.append(message)

    ydl

# Generated at 2022-06-18 15:41:53.695500
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            self.downloader = downloader


# Generated at 2022-06-18 15:42:04.511988
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name):
            super(FakeInfoExtractor, self).__init__(ie_name)


# Generated at 2022-06-18 15:42:15.769241
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)


# Generated at 2022-06-18 15:42:25.617637
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self


# Generated at 2022-06-18 15:42:46.946746
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.PostProcessor import PostProcessor
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import common
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(common.InfoExtractor):
        IE_NAME = 'test'
        _VALID_URL = r'(?i)^https?://.*'


# Generated at 2022-06-18 15:42:56.621187
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.compat import compat_str
    from tempfile import NamedTemporaryFile
    from datetime import datetime

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name):
            super(FakeInfoExtractor, self).__init__(ie_name)
            self.ie_name = ie_name


# Generated at 2022-06-18 15:43:05.578111
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # Test with a simple title format
    titleformat = '%(title)s - %(artist)s'
    titleregex = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    title = 'Song Title - Artist Name'
    info = {'title': title}

# Generated at 2022-06-18 15:43:16.694585
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    from ytdl.YoutubeDL import YoutubeDL
    from ytdl.PostProcessor import PostProcessor
    from ytdl.compat import compat_str

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            self.to_screen_calls = []
            super(FakeYDL, self).__init__(*args, **kwargs)

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)

    class FakePP(PostProcessor):
        def __init__(self, *args, **kwargs):
            self.run_calls = []
            super(FakePP, self).__init__(*args, **kwargs)

        def run(self, info):
            self.run_c

# Generated at 2022-06-18 15:43:28.113905
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name):
            super(FakeInfoExtractor, self).__init__(ie_name)


# Generated at 2022-06-18 15:43:36.732049
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE

    # Test 1
    titleformat = '%(title)s - %(artist)s'
    title = 'Test Title - Test Artist'
    info = {'title': title}
    pp = MetadataFromTitlePP(FileDownloader(YoutubeDL()), titleformat)
    pp.run(info)
    assert info['title'] == 'Test Title'
    assert info['artist'] == 'Test Artist'

    # Test 2
    titleformat = '%(title)s - %(artist)s'
    title = 'Test Title - Test Artist'
    info = {'title': title}
    pp = MetadataFrom

# Generated at 2022-06-18 15:43:44.516377
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    from ytdl.YoutubeDL import YoutubeDL
    from ytdl.PostProcessor import PostProcessor
    from ytdl.FileDownloader import FileDownloader
    from ytdl.compat import compat_str
    from ytdl.extractor.common import InfoExtractor
    from ytdl.utils import std_headers


# Generated at 2022-06-18 15:43:50.691116
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange
    import datetime
    import unittest

    class TestPP(PostProcessor):
        def __init__(self, downloader):
            super(TestPP, self).__init__(downloader)
            self.test_info = None

        def run(self, info):
            self.test_info = info
            return [], info

    class TestYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(TestYDL, self).__init__(*args, **kwargs)
            self.test_pp = TestPP(self)
            self.add_post_processor(self.test_pp)


# Generated at 2022-06-18 15:44:01.011917
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.postprocessor import FFmpegMetadataPP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeInfoExtractor, self).__init__(*args, **kwargs)
            self._title = '%(title)s - %(artist)s'

        def _real_extract(self, url):
            return {
                'id': 'testid',
                'title': self._title,
                'ext': 'mp4',
            }

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super

# Generated at 2022-06-18 15:44:08.557209
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor

    class TestInfoExtractor(InfoExtractor):
        def __init__(self, downloader=None, ie_key=None, ie_desc=None):
            super(TestInfoExtractor, self).__init__(downloader, ie_key, ie_desc)


# Generated at 2022-06-18 15:44:41.929210
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    import datetime

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeInfoExtractor, self).__init__(*args, **kwargs)
            self._downloader = YoutubeDL(params={})

    ie = FakeInfoExtractor(downloader=YoutubeDL({}))
    ie.add_info_extractor(MetadataFromTitlePP(ie._downloader, '%(title)s - %(artist)s'))

# Generated at 2022-06-18 15:44:49.694666
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # Test with a single video

# Generated at 2022-06-18 15:45:01.392566
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []
            self.to_screen_msgs = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)
            self.to_screen_msgs.append(msg)

    class FakePP(PostProcessor):
        def __init__(self, *args, **kwargs):
            super(FakePP, self).__init

# Generated at 2022-06-18 15:45:09.847309
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import DownloadError

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            super(FakeInfoExtractor, self).__init__(downloader)
            self._type = 'fake'


# Generated at 2022-06-18 15:45:21.238200
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.youtube import YoutubeIE
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # Test with a title that can be interpreted as a date
    class TestYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(TestYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_called = False
            self.to_screen_msg = None

        def to_screen(self, msg):
            self.to_screen_called = True
            self.to_screen_msg = msg


# Generated at 2022-06-18 15:45:31.011312
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.downloader.common import FileDownloader

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name):
            InfoExtractor.__init__(self, ie_name)

        def _real_extract(self, url):
            return {'id': '123', 'title': 'Title - Artist', 'ext': 'mp4'}

    class FakePostProcessor(PostProcessor):
        def __init__(self, pp_name):
            PostProcessor.__init__(self, pp_name)


# Generated at 2022-06-18 15:45:41.454087
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.extractor.youtube import YoutubeIE
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name):
            super(FakeInfoExtractor, self).__init__(ie_name)


# Generated at 2022-06-18 15:45:51.842122
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl.YoutubeDL import YoutubeDL
    from ytdl.PostProcessor import PostProcessor
    from ytdl.compat import compat_str

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)

    ydl = FakeYoutubeDL()
    pp = MetadataFrom

# Generated at 2022-06-18 15:45:58.732348
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE

    # Create a downloader

# Generated at 2022-06-18 15:46:08.004012
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange
    from youtube_dl.compat import compat_str

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen = lambda *args, **kwargs: None


# Generated at 2022-06-18 15:47:05.293028
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.compat import compat_str

    # Create a test downloader

# Generated at 2022-06-18 15:47:16.722102
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.postprocessor import FFmpegMetadataPP

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)
