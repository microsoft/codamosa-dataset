

# Generated at 2022-06-18 15:37:32.510796
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-18 15:37:43.223143
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor import YoutubeIE
    from .compat import compat_str

    # Test 1: titleformat = '%(title)s - %(artist)s'
    #         title = 'Test - Test'
    #         expected result:
    #             info['title'] = 'Test'
    #             info['artist'] = 'Test'
    titleformat = '%(title)s - %(artist)s'
    title = 'Test - Test'
    info = {'title': title}
    downloader = FileDownloader({})
    downloader.add_info_extractor(YoutubeIE(downloader))
    pp = MetadataFromTitlePP(downloader, titleformat)
    pp.run(info)
    assert info['title'] == 'Test'
    assert info['artist']

# Generated at 2022-06-18 15:37:49.983990
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # Test with a simple format
    fmt = '%(title)s - %(artist)s'
    regex = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, fmt).format_to_regex(fmt) == regex

    # Test with a more complex format
    fmt = '%(title)s - %(artist)s - %(album)s'
    regex = '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'
    assert MetadataFromTitlePP(None, fmt).format_to_regex(fmt) == regex

    # Test with a format with a literal %
    fmt = '%(title)s - %(artist)s - %%(album)s'
   

# Generated at 2022-06-18 15:37:59.552840
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self['title'] = 'Test title'

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []


# Generated at 2022-06-18 15:38:10.771748
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP


# Generated at 2022-06-18 15:38:19.489704
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.postprocessor import FFmpegMetadataPP

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_called = False

        def to_screen(self, msg):
            self.to_screen_called = True


# Generated at 2022-06-18 15:38:29.902830
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.youtube import YoutubeIE
    from youtube_dl.utils import DateRange

    # Test with a simple title format
    ydl = YoutubeDL({'writedescription': True, 'writeinfojson': True, 'writethumbnail': True, 'writeautomaticsub': True, 'outtmpl': '%(title)s.%(ext)s'})
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(YoutubeIE())
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s'))
    ydl.params['usenetrc'] = False
    ydl.params['username'] = 'test'

# Generated at 2022-06-18 15:38:40.941995
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.downloader.external import ExternalFD
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # Test with a Youtube video

# Generated at 2022-06-18 15:38:52.328111
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.youtube import YoutubeIE
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegMetadataPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_called = False

        def to_screen(self, msg):
            self.to_screen_called = True


# Generated at 2022-06-18 15:39:02.448149
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ..YoutubeDL import YoutubeDL
    from ..utils import DateRange
    from ..extractor import gen_extractors
    from ..compat import compat_str

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen = lambda x: None

    class FakeExtractor(object):
        IE_NAME = 'FakeExtractor'

# Generated at 2022-06-18 15:39:11.980835
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import json
    import unittest

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary python file
    fd, pyfile = tempfile.mkstemp(suffix='.py', dir=tmpdir)

# Generated at 2022-06-18 15:39:22.069348
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader=None):
            super(FakeInfoExtractor, self).__init__(downloader)
            self._type = 'fake'


# Generated at 2022-06-18 15:39:28.967266
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ytdl.YoutubeDL import YoutubeDL

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_messages = []

        def to_screen(self, msg):
            self.to_screen_messages.append(msg)

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.ydl = MockYoutubeDL()
            self.ydl.params['writethumbnail'] = True
            self.ydl.params['writeinfojson'] = True
            self.ydl.params['writedescription'] = True

# Generated at 2022-06-18 15:39:40.455218
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange

    ydl = YoutubeDL({
        'writedescription': True,
        'writeinfojson': True,
        'writethumbnail': True,
        'writeautomaticsub': True,
        'subtitleslangs': ['en'],
        'skip_download': True,
        'format': 'bestaudio/best',
        'outtmpl': '%(id)s',
        'postprocessors': [{
            'key': 'MetadataFromTitle',
            'titleformat': '%(title)s - %(artist)s',
        }],
    })
    ydl.add_default_info_extractors()

# Generated at 2022-06-18 15:39:49.322810
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeInfoExtractor, self).__init__(*args, **kwargs)
            self._downloader = YoutubeDL({})


# Generated at 2022-06-18 15:40:00.873397
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl.YoutubeDL import YoutubeDL
    from ytdl.PostProcessor import PostProcessor
    from ytdl.compat import compat_str

    class MockYoutubeDL(YoutubeDL):
        def __init__(self):
            super(MockYoutubeDL, self).__init__()
            self.to_screen_called = False

        def to_screen(self, msg):
            self.to_screen_called = True

    class MockPostProcessor(PostProcessor):
        def __init__(self):
            super(MockPostProcessor, self).__init__(MockYoutubeDL())

        def run(self, info):
            return [], info

    # Test with a regex that matches
    info = {'title': 'Test - Title'}
    pp = MockPostProcessor()

# Generated at 2022-06-18 15:40:08.080812
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    from ytdl_server.compat import compat_str
    from ytdl_server.YoutubeDL import YoutubeDL
    from ytdl_server.postprocessor.common import PostProcessor
    from ytdl_server.utils import encodeFilename

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_called = False

        def to_screen(self, msg):
            self.to_screen_called = True

    class FakePostProcessor(PostProcessor):
        def __init__(self, *args, **kwargs):
            super(FakePostProcessor, self).__init__(*args, **kwargs)
            self.run

# Generated at 2022-06-18 15:40:18.154547
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(object):
        IE_NAME = 'test'
        _VALID_URL = r'(?:https?://)?(?:www\.)?test\.com/'

# Generated at 2022-06-18 15:40:28.532803
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange

    # Test 1: Test with a titleformat that does not contain any %(..)s
    #         and a title that does not match the titleformat

# Generated at 2022-06-18 15:40:36.985148
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ytdl.YoutubeDL import YoutubeDL
    from ytdl.postprocessor.ffmpeg import FFmpegMetadataPP
    from ytdl.postprocessor.xattrpp import XAttrMetadataPP


# Generated at 2022-06-18 15:40:51.100250
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.downloader.http import HttpDownloader
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor import FFmpegExtractAudioPP
    from youtube_dl.postprocessor import FFmpegVideoConvertorPP
    from youtube_dl.postprocessor import FFmpegEmbedSubtitlePP
    from youtube_dl.postprocessor import XAttrMetadataPP
    from youtube_dl.postprocessor import EmbedThumbnailPP
    from youtube_dl.postprocessor import FixupPP
    from youtube_dl.postprocessor import PostProcessor
    from youtube_dl.postprocessor import FFmpeg

# Generated at 2022-06-18 15:41:01.265894
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor import gen_extractors
    from .compat import compat_str

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    downloader = FileDownloader({})
    downloader.add_info_extractor(gen_extractors()[0])
    downloader.add_post_processor(MetadataFromTitlePP(downloader, '%(title)s - %(artist)s'))

# Generated at 2022-06-18 15:41:12.862908
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange
    import os

    class TestPostProcessor(PostProcessor):
        def run(self, info):
            return [], info

    class TestYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(TestYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, message):
            self.to_screen_calls.append(message)


# Generated at 2022-06-18 15:41:23.056256
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ytdl.YoutubeDL import YoutubeDL

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, params):
            self.params = params
            self.to_screen_messages = []

        def to_screen(self, message):
            self.to_screen_messages.append(message)


# Generated at 2022-06-18 15:41:31.366035
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP

    # Test with a video with a title that matches the format
    test_video_id = '9bZkp7q19f0'
    test_video_title = 'PSY - GANGNAM STYLE(강남스타일) M/V'
    test_video_artist = 'PSY'
    test_video_upload_date = '20121109'
    test_video_uploader = 'officialpsy'
    test_video_uploader_id = 'UCM6QsBQd9v3XKp6yhXxpSgQ'


# Generated at 2022-06-18 15:41:41.671627
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ydl.postprocessor.common import PostProcessor

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')


# Generated at 2022-06-18 15:41:52.613329
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import youtube_dl
    from youtube_dl.utils import DateRange
    from youtube_dl.compat import compat_str


# Generated at 2022-06-18 15:42:03.905267
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl.YoutubeDL import YoutubeDL
    from ytdl.PostProcessor import PostProcessor
    from ytdl.utils import DateRange

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)


# Generated at 2022-06-18 15:42:15.319682
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.PostProcessor import PostProcessor
    from youtube_dl.FileDownloader import FileDownloader

    class MockYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYDL, self).__init__(*args, **kwargs)
            self.to_screen_called = False
            self.to_screen_msg = None

        def to_screen(self, msg):
            self.to_screen_called = True
            self.to_screen_msg = msg

    class MockPostProcessor(PostProcessor):
        def __init__(self, *args, **kwargs):
            super(MockPostProcessor, self).__init__(*args, **kwargs)
            self.run_

# Generated at 2022-06-18 15:42:25.584081
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # Test 1: Test parsing of title
    # Expected result:
    #   info['artist'] = 'Artist'
    #   info['title'] = 'Title'
    #   info['track'] = '1'
    #   info['album'] = 'Album'
    #   info['genre'] = 'Genre'
    #   info['date'] = '2016'
    #   info['track_number'] = '1'
    #   info['album_artist'] = 'Album Artist'
    #   info['disc_number

# Generated at 2022-06-18 15:42:50.260449
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.youtube import YoutubeIE

    # Test 1
    downloader = YoutubeDL({'writedescription': True, 'writeinfojson': True})
    downloader.add_info_extractor(YoutubeIE())
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    info = {'title': 'Test title - Test artist'}
    pp.run(info)
    assert info['title'] == 'Test title'
    assert info['artist'] == 'Test artist'

    # Test 2
    downloader = YoutubeDL({'writedescription': True, 'writeinfojson': True})
    downloader.add_info_extractor(YoutubeIE())

# Generated at 2022-06-18 15:42:59.884026
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    import datetime
    import os
    import tempfile

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a YoutubeDL object

# Generated at 2022-06-18 15:43:08.052810
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeInfoExtractor, self).__init__(*args, **kwargs)
            self._title = '%(title)s - %(artist)s'

        def _real_extract(self, url):
            return {'id': 'testid', 'title': self._title}


# Generated at 2022-06-18 15:43:18.412705
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor import gen_extractors
    from .compat import compat_str

    # Test case 1
    # Test case 1.1
    # Test case 1.1.1
    # Test case 1.1.1.1
    # Test case 1.1.1.1.1
    # Test case 1.1.1.1.1.1
    # Test case 1.1.1.1.1.1.1
    # Test case 1.1.1.1.1.1.1.1
    # Test case 1.1.1.1.1.1.1.1.1
    # Test case 1.1.1.1.1.1.1.1.1.1
    # Test case 1.1.1.1.1.1.1.

# Generated at 2022-06-18 15:43:29.413693
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            pass


# Generated at 2022-06-18 15:43:37.379744
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import tempfile
    import unittest
    from ytdl.YoutubeDL import YoutubeDL

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_called = False
            self.to_screen_msg = None

        def to_screen(self, msg):
            self.to_screen_called = True
            self.to_screen_msg = msg

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.setdefault('title', None)


# Generated at 2022-06-18 15:43:47.269205
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeInfoExtractor, self).__init__(*args, **kwargs)
            self._title = '%(title)s - %(artist)s'


# Generated at 2022-06-18 15:43:52.611754
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl.YoutubeDL import YoutubeDL
    from ytdl.PostProcessor import PostProcessor
    from ytdl.compat import compat_str
    from ytdl.utils import DateRange


# Generated at 2022-06-18 15:44:02.914442
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name):
            super(FakeInfoExtractor, self).__init__(ie_name)


# Generated at 2022-06-18 15:44:11.487742
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange

    ydl = YoutubeDL({
        'writethumbnail': True,
        'writeinfojson': True,
        'writedescription': True,
        'writeannotations': True,
        'writeautomaticsub': True,
        'allsubtitles': True,
        'skip_download': True,
        'format': 'bestvideo+bestaudio/best',
        'outtmpl': '%(id)s',
        'postprocessors': [{
            'key': 'MetadataFromTitle',
            'titleformat': '%(title)s - %(artist)s',
        }],
    })

    # Test with a video with title 'title - artist'

# Generated at 2022-06-18 15:44:47.079486
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.postprocessor import FFmpegMetadataPP

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)


# Generated at 2022-06-18 15:44:57.957042
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange

    # Test with a titleformat that does not contain any %(..)s
    titleformat = '%(title)s - %(artist)s'
    title = 'My Title - My Artist'
    info = {'title': title}
    pp = MetadataFromTitlePP(YoutubeDL(), titleformat)
    pp.run(info)
    assert info['title'] == title
    assert info['artist'] == 'My Artist'

    # Test with a titleformat that contains %(..)s
    titleformat = '%(title)s - %(artist)s'
    title = 'My Title - My Artist'
    info = {'title': title}
    pp = MetadataFromTitlePP(YoutubeDL(), titleformat)
   

# Generated at 2022-06-18 15:45:07.715010
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_called = False

        def to_screen(self, *args, **kwargs):
            self.to_screen_called = True

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.ydl = MockYoutubeDL({'writedescription': True})
            self.pp = MetadataFromTitlePP(self.ydl, '%(title)s - %(artist)s')


# Generated at 2022-06-18 15:45:18.714517
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            super(FakeInfoExtractor, self).__init__(downloader)
            self._type = 'fake'


# Generated at 2022-06-18 15:45:28.431734
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.compat import compat_str


# Generated at 2022-06-18 15:45:38.320703
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor import gen_extractors
    from .compat import compat_urllib_request

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self['extractor'] = 'youtube'
            self['extractor_key'] = 'Youtube'
            self['webpage_url'] = 'http://www.youtube.com/watch?v=BaW_jenozKc'
            self['webpage_url_basename'] = 'BaW_jenozKc'
            self['id'] = 'BaW_jenozKc'
            self['title'] = 'youtube-dl test video "\'/\\ä↭'

# Generated at 2022-06-18 15:45:44.794208
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import gen_extractors
    from youtube_dl.postprocessor import gen_pp_confs

    # Create a downloader

# Generated at 2022-06-18 15:45:54.019995
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange

    class DummyYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(DummyYDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)

    class DummyPP(PostProcessor):
        def __init__(self, *args, **kwargs):
            super(DummyPP, self).__init__(*args, **kwargs)
            self.run_calls = []

        def run(self, info):
            self.run_calls

# Generated at 2022-06-18 15:46:00.438319
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor import gen_extractors
    from .compat import compat_str

    # Create a FileDownloader object
    ydl = FileDownloader({})
    ydl.params['simulate'] = True
    ydl.params['nooverwrites'] = True
    ydl.params['outtmpl'] = '%(title)s-%(id)s.%(ext)s'
    ydl.params['writedescription'] = True
    ydl.params['writeinfojson'] = True
    ydl.params['writethumbnail'] = True
    ydl.params['writeautomaticsub'] = True
    ydl.params['subtitleslangs'] = ['en']
    ydl.params['writesubtitles'] = True
    ydl.params

# Generated at 2022-06-18 15:46:09.355362
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.PostProcessor import PostProcessor

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_called = False

        def to_screen(self, msg):
            self.to_screen_called = True

    class MockPostProcessor(PostProcessor):
        def __init__(self, *args, **kwargs):
            super(MockPostProcessor, self).__init__(*args, **kwargs)
            self.run_called = False

        def run(self, info):
            self.run_called = True

    ydl = MockYoutubeDL()
    pp

# Generated at 2022-06-18 15:47:09.682233
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange
    import datetime

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_buffer = []

        def to_screen(self, msg):
            self.to_screen_buffer.append(msg)

    class MockPostProcessor(PostProcessor):
        def __init__(self, *args, **kwargs):
            super(MockPostProcessor, self).__init__(*args, **kwargs)
            self.run_buffer = []


# Generated at 2022-06-18 15:47:19.941625
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.PostProcessor import PostProcessor
    from youtube_dl.utils import DateRange
    from youtube_dl.compat import compat_str
    from datetime import datetime

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)