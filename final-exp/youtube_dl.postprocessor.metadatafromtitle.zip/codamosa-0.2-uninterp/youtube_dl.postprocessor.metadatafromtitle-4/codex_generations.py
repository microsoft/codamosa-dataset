

# Generated at 2022-06-18 15:37:29.322789
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    pp = MetadataFromTitlePP(ydl, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '%(title)s'
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s - %(album)s')

# Generated at 2022-06-18 15:37:40.340626
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeInfoExtractor, self).__init__(*args, **kwargs)
            self._downloader = YoutubeDL(params={})

    ie = FakeInfoExtractor(downloader=YoutubeDL(params={}))
    ie.add_info_extractor(FakeInfoExtractor(ie))
    ie.add_info_extractor(FakeInfoExtractor(ie))
    ie.add_info_extractor(FakeInfoExtractor(ie))
    ie.add_info_extractor(FakeInfoExtractor(ie))
    ie.add_info

# Generated at 2022-06-18 15:37:50.802436
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE

    # Test with a single video
    ydl = YoutubeDL({'writethumbnail': True, 'writeinfojson': True, 'simulate': True, 'quiet': True})
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(YoutubeIE())
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s'))
    ydl.download(['https://www.youtube.com/watch?v=BaW_jenozKc'])

# Generated at 2022-06-18 15:37:58.575477
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({'writethumbnail': True, 'quiet': True})
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s'))
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s - %(album)s'))
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s - %(album)s - %(track)s'))

# Generated at 2022-06-18 15:38:09.729719
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s - %(album)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'

# Generated at 2022-06-18 15:38:18.833666
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP


# Generated at 2022-06-18 15:38:29.642338
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s - %(album)s') == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)\\ \\-\\ (?P<album>.+)'

# Generated at 2022-06-18 15:38:40.699399
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s - %(album)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'

# Generated at 2022-06-18 15:38:52.017542
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.filename = 'test.mp4'

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)

# Generated at 2022-06-18 15:39:02.178100
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange

    # Test 1: Test with a titleformat that contains no %(..)s
    titleformat = '%(title)s - %(artist)s'
    title = 'Test Title - Test Artist'
    info = {'title': title}

# Generated at 2022-06-18 15:39:15.505829
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE

    # Create a downloader
    ydl = YoutubeDL({'outtmpl': '%(title)s-%(id)s.%(ext)s'})
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(YoutubeIE())
    ydl.params['writedescription'] = True
    ydl.params['writeinfojson'] = True
    ydl.params['writethumbnail'] = True
    ydl.params['write_all_thumbnails'] = True
    ydl.params['writesubtitles'] = True

# Generated at 2022-06-18 15:39:24.269986
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE

    # Create a YoutubeDL object
    ydl = YoutubeDL({'writedescription': True, 'writeinfojson': True, 'writethumbnail': True, 'writeautomaticsub': True, 'simulate': True, 'skip_download': True, 'format': 'bestvideo+bestaudio/best'})

    # Create a FileDownloader object

# Generated at 2022-06-18 15:39:34.626925
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange

    class TestPP(PostProcessor):
        def __init__(self, downloader):
            super(TestPP, self).__init__(downloader)
            self.test_info = None

        def run(self, info):
            self.test_info = info
            return [], info


# Generated at 2022-06-18 15:39:44.872688
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP

    ydl = YoutubeDL({
        'simulate': True,
        'outtmpl': '%(title)s',
        'writethumbnail': True,
        'postprocessors': [{
            'key': 'FFmpegMetadata',
        }, {
            'key': 'MetadataFromTitle',
            'titleformat': '%(artist)s - %(title)s',
        }],
    })
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(YoutubeIE())
    ydl.add_post_processor(FFmpegMetadataPP())


# Generated at 2022-06-18 15:39:52.230960
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor import YoutubeIE
    from .compat import compat_str

    # Test 1: titleformat = '%(title)s - %(artist)s'
    #         title = 'Test - Test'
    #         expected result: info['title'] = 'Test'
    #                          info['artist'] = 'Test'
    titleformat = '%(title)s - %(artist)s'
    title = 'Test - Test'
    info = {'title': title}
    downloader = FileDownloader({})
    pp = MetadataFromTitlePP(downloader, titleformat)
    pp.run(info)
    assert info['title'] == 'Test'
    assert info['artist'] == 'Test'

    # Test 2: titleformat = '%(title)s - %(

# Generated at 2022-06-18 15:40:02.701670
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # Create a FileDownloader object
    ydl = YoutubeDL({})
    fd = FileDownloader(ydl, {'outtmpl': '%(title)s'})

    # Create a MetadataFromTitlePP object
    titleformat = '%(title)s - %(artist)s'
    mftpp = MetadataFromTitlePP(fd, titleformat)

    # Create an InfoExtractor object

# Generated at 2022-06-18 15:40:14.725195
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor

    class MockInfoExtractor(InfoExtractor):
        def __init__(self, ie_name, ie_id):
            super(MockInfoExtractor, self).__init__(ie_name, ie_id)


# Generated at 2022-06-18 15:40:25.367289
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP

    # Test with a video that has a title that matches the regex
    # and a video that does not match the regex

# Generated at 2022-06-18 15:40:32.692218
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from tempfile import NamedTemporaryFile
    from os import remove
    from os.path import exists

    class MockInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {'id': 'testid', 'title': 'testtitle'}

    class MockPostProcessor(PostProcessor):
        def run(self, info):
            return [], info


# Generated at 2022-06-18 15:40:39.633545
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange
    from youtube_dl.compat import compat_str

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.params = {}
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)

# Generated at 2022-06-18 15:40:56.463619
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name):
            super(FakeInfoExtractor, self).__init__(ie_name)

        def _real_extract(self, url):
            return {'id': 'testid', 'title': 'testtitle'}

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self):
            super(FakeYoutubeDL, self).__init__({})

        def to_screen(self, msg):
            pass

    ie = FakeInfoExtractor('test')
    ydl

# Generated at 2022-06-18 15:41:03.514756
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import common
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.compat import compat_str


# Generated at 2022-06-18 15:41:14.410363
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.compat import compat_str

    def test_run(title, titleformat, expected_info):
        ydl = YoutubeDL({'writedescription': True, 'writeinfojson': True,
                         'writethumbnail': True, 'writeautomaticsub': True,
                         'outtmpl': '%(id)s', 'nooverwrites': True,
                         'postprocessors': [{
                             'key': 'MetadataFromTitlePP',
                             'titleformat': titleformat,
                         }]})
        ydl.add_default_info_extractors()

# Generated at 2022-06-18 15:41:24.609960
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from datetime import datetime
    from unittest import TestCase

    class TestYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(TestYDL, self).__init__(*args, **kwargs)
            self.to_screen_buffer = []

        def to_screen(self, s):
            self.to_screen_buffer.append(s)

    class TestPP(MetadataFromTitlePP):
        def __init__(self, *args, **kwargs):
            super(TestPP, self).__init__(*args, **kwargs)
            self.run_buffer = []


# Generated at 2022-06-18 15:41:34.874934
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {'id': 'testid', 'title': 'testtitle', 'ext': 'mp4'}

    class FakePostProcessor(PostProcessor):
        def run(self, info):
            return [], info


# Generated at 2022-06-18 15:41:38.783427
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange

    class FakeInfoDict:
        def __init__(self, title):
            self.title = title

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            pass

        def to_screen(self, msg):
            print(msg)

    class FakeFileDownloader(FileDownloader):
        def __init__(self, *args, **kwargs):
            pass

    class FakePostProcessor(PostProcessor):
        def __init__(self, *args, **kwargs):
            pass

    # Test with a simple title format


# Generated at 2022-06-18 15:41:44.891190
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor import gen_extractors
    from .compat import compat_str

    # Create a FileDownloader object
    fd = FileDownloader({})
    fd.params['writedescription'] = True
    fd.params['writeinfojson'] = True
    fd.params['outtmpl'] = '%(title)s-%(id)s.%(ext)s'
    fd.add_info_extractor(gen_extractors()[0])

    # Create a MetadataFromTitlePP object
    mftpp = MetadataFromTitlePP(fd, '%(title)s-%(id)s.%(ext)s')

    # Test the run method

# Generated at 2022-06-18 15:41:55.554631
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            self.downloader = downloader

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, params):
            self.params = params
            self.to_screen = lambda x: None

    # Test with a simple titleformat
    titleformat = '%(title)s - %(artist)s'
    title = 'Test title - Test artist'
    info = {'title': title}
    ydl = FakeYoutubeDL({'writethumbnail': True, 'writeinfojson': True})
    ie = FakeInfoExtractor(ydl)
   

# Generated at 2022-06-18 15:42:05.528075
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            InfoExtractor.__init__(self, downloader)


# Generated at 2022-06-18 15:42:15.904022
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor import gen_extractors
    from .postprocessor import gen_pp

    # Create a downloader instance
    ydl = FileDownloader({})
    ydl.add_info_extractor(gen_extractors()[0])
    ydl.add_post_processor(gen_pp()[0])

    # Create a MetadataFromTitlePP instance
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')

    # Test run method
    info = {'title': 'Test Title - Test Artist'}
    pp.run(info)
    assert info['title'] == 'Test Title'
    assert info['artist'] == 'Test Artist'

    # Test run method with invalid title

# Generated at 2022-06-18 15:42:39.791285
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.compat import compat_str

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)

    class MockPostProcessor(PostProcessor):
        def __init__(self, *args, **kwargs):
            super(MockPostProcessor, self).__init__(*args, **kwargs)
            self.run_calls = []


# Generated at 2022-06-18 15:42:51.408884
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name):
            self._type = ie_name


# Generated at 2022-06-18 15:43:01.042339
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP

    # Test with a simple title format

# Generated at 2022-06-18 15:43:08.713691
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.postprocessor import FFmpegMetadataPP


# Generated at 2022-06-18 15:43:18.620344
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.postprocessor import FFmpegMetadataPP


# Generated at 2022-06-18 15:43:29.454200
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeInfoExtractor, self).__init__(*args, **kwargs)
            self._downloader = YoutubeDL(params={'writedescription': True})


# Generated at 2022-06-18 15:43:37.411431
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            super(FakeInfoExtractor, self).__init__(downloader)
            self.IE_NAME = 'fake'


# Generated at 2022-06-18 15:43:47.307249
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor import YoutubeIE
    from .compat import compat_str

    # Test with a title that matches the format
    info = {'title': 'Test - Test'}
    pp = MetadataFromTitlePP(FileDownloader({}), '%(title)s - %(artist)s')
    assert pp.run(info) == ([], {'title': 'Test', 'artist': 'Test'})

    # Test with a title that does not match the format
    info = {'title': 'Test - Test'}
    pp = MetadataFromTitlePP(FileDownloader({}), '%(artist)s - %(title)s')
    assert pp.run(info) == ([], info)

    # Test with a title that matches the format and contains a dash

# Generated at 2022-06-18 15:43:58.415742
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.PostProcessor import PostProcessor
    from youtube_dl.utils import DateRange
    from youtube_dl.compat import compat_str

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_messages = []

        def to_screen(self, message):
            self.to_screen_messages.append(message)

    class MockPostProcessor(PostProcessor):
        def __init__(self, *args, **kwargs):
            super(MockPostProcessor, self).__init__(*args, **kwargs)
            self.run_called = False

       

# Generated at 2022-06-18 15:44:07.175311
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            self.downloader = downloader


# Generated at 2022-06-18 15:44:43.222898
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.PostProcessor import PostProcessor
    from youtube_dl.FileDownloader import FileDownloader
    from youtube_dl.InfoExtractors import YoutubeIE
    from youtube_dl.utils import DateRange

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_called = []

        def to_screen(self, msg):
            self.to_screen_called.append(msg)

    class FakePP(PostProcessor):
        def __init__(self, *args, **kwargs):
            super(FakePP, self).__init__(*args, **kwargs)
            self.run_

# Generated at 2022-06-18 15:44:50.460847
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor import FFmpegMetadataPP

    # Create a YoutubeDL object
    ydl = YoutubeDL({
        'outtmpl': '%(title)s-%(id)s.%(ext)s',
        'writethumbnail': True,
        'quiet': True,
        'format': 'bestvideo+bestaudio/best',
        'postprocessors': [{
            'key': 'FFmpegMetadata',
        }, {
            'key': 'MetadataFromTitle',
            'titleformat': '%(title)s - %(artist)s',
        }],
    })



# Generated at 2022-06-18 15:45:01.966971
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from collections import namedtuple

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name):
            super(FakeInfoExtractor, self).__init__(ie_name)
            self.ie_name = ie_name

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, params):
            super(FakeYoutubeDL, self).__init__(params)
            self.params = params
            self.to_screen_calls = []

        def to_screen(self, message):
            self.to_screen_c

# Generated at 2022-06-18 15:45:10.216133
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl.YoutubeDL import YoutubeDL
    from ytdl.PostProcessor import PostProcessor
    from ytdl.compat import compat_str

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_list = []

        def to_screen(self, msg):
            self.to_screen_list.append(msg)

    class MockPostProcessor(PostProcessor):
        def __init__(self, *args, **kwargs):
            super(MockPostProcessor, self).__init__(*args, **kwargs)
            self.run_list = []

        def run(self, info):
            self.run_

# Generated at 2022-06-18 15:45:21.482506
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.compat import compat_str
    from datetime import date
    from unittest import TestCase

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, message):
            self.to_screen_calls.append(message)


# Generated at 2022-06-18 15:45:31.257885
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.youtube import YoutubeIE

    class FakeInfoExtractor(object):
        IE_NAME = 'test'

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYoutubeDL, self).__init__(*args, **kwargs)
            self.extractor = FakeInfoExtractor()

    def test_run(titleformat, title, expected_info):
        ydl = FakeYoutubeDL()
        pp = MetadataFromTitlePP(ydl, titleformat)
        info = {'title': title}
        pp.run(info)
        assert info == expected_

# Generated at 2022-06-18 15:45:41.541567
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen = lambda x: None


# Generated at 2022-06-18 15:45:51.841181
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange

    # Test with a simple format
    titleformat = '%(title)s - %(artist)s'
    title = 'Test title - Test artist'
    info = {'title': title}
    pp = MetadataFromTitlePP(FileDownloader(YoutubeDL()), titleformat)
    pp.run(info)
    assert info['title'] == title
    assert info['artist'] == 'Test artist'

    # Test with a more complex format
    titleformat = '%(title)s - %(artist)s - %(album)s'
    title = 'Test title - Test artist - Test album'
    info = {'title': title}
    pp = Metadata

# Generated at 2022-06-18 15:45:57.996022
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, message):
            self.to_screen_calls.append(message)


# Generated at 2022-06-18 15:46:07.233237
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor import FFmpegMetadataPP


# Generated at 2022-06-18 15:47:07.906331
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.compat import compat_str

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, message):
            self.to_screen_calls.append(message)


# Generated at 2022-06-18 15:47:18.954564
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.postprocessor import FFmpegMetadataPP

    # Create a YoutubeDL object