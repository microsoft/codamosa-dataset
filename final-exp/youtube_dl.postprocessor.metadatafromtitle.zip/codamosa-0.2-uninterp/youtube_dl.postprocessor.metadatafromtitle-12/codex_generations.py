

# Generated at 2022-06-18 15:37:30.450088
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange
    from datetime import date

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen = lambda *args, **kwargs: None


# Generated at 2022-06-18 15:37:36.760601
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s - %(album)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'

# Generated at 2022-06-18 15:37:47.652467
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s - %(album)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'

# Generated at 2022-06-18 15:37:56.551068
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor import FFmpegMetadataPP

    # Create a YoutubeDL object

# Generated at 2022-06-18 15:38:07.810549
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeInfoExtractor, self).__init__(*args, **kwargs)
            self.IE_NAME = 'fake'


# Generated at 2022-06-18 15:38:17.578724
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s - %(album)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'

# Generated at 2022-06-18 15:38:29.469236
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.PostProcessor import PostProcessor
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen = lambda *args, **kwargs: None


# Generated at 2022-06-18 15:38:40.523617
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '%(title)s'
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(album)s')
    assert pp._titleformat == '%(title)s - %(artist)s - %(album)s'

# Generated at 2022-06-18 15:38:51.717341
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s - %(album)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'

# Generated at 2022-06-18 15:39:01.962206
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.youtube import YoutubeIE
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    def test_run(title, titleformat, expected):
        ydl = YoutubeDL({'writethumbnail': True,
                         'writesubtitles': True,
                         'writeautomaticsub': True,
                         'outtmpl': '%(id)s',
                         'postprocessors': [{
                             'key': 'MetadataFromTitle',
                             'titleformat': titleformat,
                         }]})
        ydl.add_default_info_extractors()
        ydl.add_info_extractor(YoutubeIE())

# Generated at 2022-06-18 15:39:14.820993
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # Test that the method run of class MetadataFromTitlePP
    # correctly parses the title of a video and sets the
    # corresponding metadata fields.
    #
    # The test is performed by downloading a video from youtube
    # and checking that the metadata fields are set correctly.

    # The title of the video is
    # '%(title)s - %(artist)s'
    # where title and artist are the metadata fields.
    # The video is
    # 'https://www.youtube.com/watch?v=9bZkp7

# Generated at 2022-06-18 15:39:23.762227
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name):
            super(FakeInfoExtractor, self).__init__(ie_name)


# Generated at 2022-06-18 15:39:33.565356
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name):
            super(FakeInfoExtractor, self).__init__(ie_name)


# Generated at 2022-06-18 15:39:44.199523
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            InfoExtractor.__init__(self, downloader)
            self._type = 'fake'
            self._TITLE = 'Fake'


# Generated at 2022-06-18 15:39:51.815638
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ytdl_server import YoutubeDL

    class MockYoutubeDL(YoutubeDL):
        def to_screen(self, msg):
            sys.stderr.write(msg + '\n')

    class MockInfoDict(dict):
        def __init__(self, title):
            self['title'] = title

    class TestMetadataFromTitlePP(unittest.TestCase):
        def test_run(self):
            ydl = MockYoutubeDL()
            pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
            info = MockInfoDict('title - artist')
            pp.run(info)
            self.assertEqual(info['title'], 'title')

# Generated at 2022-06-18 15:40:02.395322
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.compat import compat_str


# Generated at 2022-06-18 15:40:14.444200
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test with a regex that matches
    downloader = object()
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    info = {'title': 'The Title - The Artist'}
    pp.run(info)
    assert info['title'] == 'The Title'
    assert info['artist'] == 'The Artist'

    # Test with a regex that doesn't match
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    info = {'title': 'The Title'}
    pp.run(info)
    assert info['title'] == 'The Title'
    assert 'artist' not in info

    # Test with a regex that doesn't contain any group

# Generated at 2022-06-18 15:40:25.043747
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.PostProcessor import PostProcessor
    from youtube_dl.utils import DateRange
    from datetime import date
    import unittest

    class TestPostProcessor(PostProcessor):
        def __init__(self, downloader):
            super(TestPostProcessor, self).__init__(downloader)
            self.ran = False

        def run(self, info):
            self.ran = True
            return [], info

    class TestYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(TestYoutubeDL, self).__init__(*args, **kwargs)
            self.pp = TestPostProcessor(self)


# Generated at 2022-06-18 15:40:32.466102
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self['title'] = 'Fake title'

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.info_dict = FakeInfo

# Generated at 2022-06-18 15:40:39.501193
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name):
            super(FakeInfoExtractor, self).__init__(ie_name)


# Generated at 2022-06-18 15:40:49.597569
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    ydl = YoutubeDL({'writedescription': True, 'writeinfojson': True})
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s'))
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s'))
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(artist)s - %(title)s'))
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(artist)s - %(title)s - %(album)s'))
    ydl.add_post_processor

# Generated at 2022-06-18 15:41:00.264941
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name, ie_id):
            super(FakeInfoExtractor, self).__init__(ie_name, ie_id)


# Generated at 2022-06-18 15:41:12.014229
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ydl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.downloader = object()
            self.pp = MetadataFromTitlePP(self.downloader, '%(title)s - %(artist)s')

        def test_run(self):
            info = {'title': 'title - artist'}
            self.assertEqual(self.pp.run(info), ([], {'title': 'title', 'artist': 'artist'}))

        def test_run_no_match(self):
            info = {'title': 'title'}
            self.assertEqual(self.pp.run(info), ([], {'title': 'title'}))

# Generated at 2022-06-18 15:41:22.165291
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ytdl_server.downloader import Downloader
    from ytdl_server.extractor import YoutubeIE

    class FakeYoutubeIE(YoutubeIE):
        def __init__(self, downloader=None, ie_key=None, *args, **kwargs):
            super(FakeYoutubeIE, self).__init__(downloader, ie_key, *args, **kwargs)
            self.title = 'Test Title'

    class FakeDownloader(Downloader):
        def __init__(self, *args, **kwargs):
            super(FakeDownloader, self).__init__(*args, **kwargs)
            self.to_screen_called = False

        def to_screen(self, message):
            self.to_screen_called = True


# Generated at 2022-06-18 15:41:30.765553
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    import datetime
    import unittest

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, params):
            super(MockYoutubeDL, self).__init__(params)
            self.to_screen_buffer = []

        def to_screen(self, message):
            self.to_screen_buffer.append(message)

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.ydl = MockYoutubeDL({})

        def test_basic(self):
            info = {
                'title': 'Test - Artist - Album'
            }

# Generated at 2022-06-18 15:41:41.318122
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE

    # Test with a simple title format
    titleformat = '%(title)s'
    title = 'Video Title'
    info = {'title': title}
    downloader = FileDownloader(YoutubeDL({'writedescription': True}), {})
    pp = MetadataFromTitlePP(downloader, titleformat)
    pp.run(info)
    assert info['title'] == title

    # Test with a more complex title format
    titleformat = '%(title)s - %(artist)s'
    title = 'Video Title - Artist'
    info = {'title': title}
    downloader = File

# Generated at 2022-06-18 15:41:52.328380
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.filename = 'test.mp4'

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_called = False

        def to_screen(self, msg):
            self.to_screen_called = True


# Generated at 2022-06-18 15:42:03.528773
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from youtube_dl.utils import DateRange
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP


# Generated at 2022-06-18 15:42:14.948338
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ydl.downloader.common import FileDownloader
    from ydl.postprocessor.common import PostProcessor
    from ydl.postprocessor.fromtitle import MetadataFromTitlePP

    class MockDownloader(FileDownloader):
        def __init__(self):
            super(MockDownloader, self).__init__(None)
            self.to_screen_messages = []

        def to_screen(self, message):
            self.to_screen_messages.append(message)

    class MockPostProcessor(PostProcessor):
        def __init__(self, downloader):
            super(MockPostProcessor, self).__init__(downloader)
            self.run_called = False

        def run(self, info):
            self.run_called = True

# Generated at 2022-06-18 15:42:25.551311
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP

    # Test with a video that has no metadata
    ydl = YoutubeDL({'writethumbnail': True, 'outtmpl': '%(id)s.%(ext)s'})
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(YoutubeIE())
    ydl.add_post_processor(FFmpegMetadataPP())
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s'))
    ydl.params['writedescription'] = True
    ydl.params['writeinfojson'] = True
   

# Generated at 2022-06-18 15:42:38.696769
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.postprocessor import FFmpegMetadataPP

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)


# Generated at 2022-06-18 15:42:49.567003
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.compat import compat_str
    from youtube_dl.extractor import common
    from youtube_dl.extractor.youtube import YoutubeIE

    class FakeInfoExtractor(common.InfoExtractor):
        IE_NAME = 'fake'
        _VALID_URL = r'https?://.+'


# Generated at 2022-06-18 15:42:59.229880
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor import YoutubeIE
    from .compat import compat_str
    from .utils import encodeFilename


# Generated at 2022-06-18 15:43:07.603114
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name, ie_id):
            self.ie_name = ie_name
            self.ie_id = ie_id

        def _real_initialize(self):
            pass


# Generated at 2022-06-18 15:43:18.376112
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.utils import DateRange

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)


# Generated at 2022-06-18 15:43:29.412234
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import pytest
    from ytdl.YoutubeDL import YoutubeDL
    from ytdl.utils import DateRange

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_calls = []

        def to_screen(self, message):
            self.to_screen_calls.append(message)

    class MockInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(MockInfoDict, self).__init__(*args, **kwargs)
            self.setdefault('title', 'title')
            self.setdefault('artist', 'artist')

# Generated at 2022-06-18 15:43:37.379383
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.compat import compat_str
    from datetime import datetime

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name):
            super(FakeInfoExtractor, self).__init__(ie_name)


# Generated at 2022-06-18 15:43:47.306206
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            super(FakeInfoExtractor, self).__init__(downloader)
            self.IE_NAME = 'fake'


# Generated at 2022-06-18 15:43:58.415918
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            super(FakeInfoExtractor, self).__init__(downloader)
            self.IE_NAME = 'fake'


# Generated at 2022-06-18 15:44:07.175256
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ytdl.YoutubeDL import YoutubeDL
    from ytdl.PostProcessor import PostProcessor
    from ytdl.compat import compat_str

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_messages = []

        def to_screen(self, message):
            self.to_screen_messages.append(message)

    class MockPostProcessor(PostProcessor):
        def __init__(self, *args, **kwargs):
            super(MockPostProcessor, self).__init__(*args, **kwargs)
            self.run_called = False


# Generated at 2022-06-18 15:44:21.246409
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            self.downloader = downloader


# Generated at 2022-06-18 15:44:31.534833
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # Create a FileDownloader object
    ydl = YoutubeDL({})
    dl = FileDownloader(ydl, {'outtmpl': '%(title)s'})

    # Create a MetadataFromTitlePP object
    pp = MetadataFromTitlePP(dl, '%(title)s - %(artist)s')

    # Create a PostProcessor object
    post_processor = PostProcessor(dl, {})

    # Create a test video

# Generated at 2022-06-18 15:44:41.426130
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor import gen_extractors
    from .compat import compat_str

    def _run_test(titleformat, title, expected_info):
        downloader = FileDownloader({})
        downloader.add_info_extractor(gen_extractors()[0])
        downloader.add_post_processor(MetadataFromTitlePP(downloader, titleformat))
        info = {'title': title}
        downloader.process_info(info)
        assert info == expected_info

    _run_test('%(title)s', 'foo', {'title': 'foo'})
    _run_test('%(title)s', 'foo - bar', {'title': 'foo'})

# Generated at 2022-06-18 15:44:49.351882
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.compat import compat_str

    # Test 1: Test that the method run of class MetadataFromTitlePP
    #         returns the expected results
    #
    # Input data
    #
    # info = {
    #     'title': 'Video Title - Artist Name',
    #     'ext': 'mp4',
    #     'format': 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best',
    #     'format_id': 'bestvideo[ext=mp4]+bestaudio[ext=m4

# Generated at 2022-06-18 15:45:00.598070
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            super(FakeInfoExtractor, self).__init__(downloader)
            self._type = 'fake'


# Generated at 2022-06-18 15:45:09.669970
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor import FFmpegMetadataPP

    # Test 1
    ydl = YoutubeDL({
        'format': 'bestaudio/best',
        'postprocessors': [{
            'key': 'MetadataFromTitle',
            'titleformat': '%(title)s - %(artist)s',
        }],
        'verbose': True,
    })
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(YoutubeIE())
    ydl.add_post_processor(FFmpegMetadataPP())

# Generated at 2022-06-18 15:45:21.112113
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor import gen_extractors
    from .compat import compat_str

    class MockInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(MockInfoDict, self).__init__(*args, **kwargs)
            self['title'] = None

    class MockYDL(object):
        def __init__(self):
            self.extractors = gen_extractors()

# Generated at 2022-06-18 15:45:30.883276
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.compat import compat_str

    class MockInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            super(MockInfoExtractor, self).__init__(downloader)
            self.ie_key = 'mock'


# Generated at 2022-06-18 15:45:41.310534
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE

    # Test 1: Test parsing of title

# Generated at 2022-06-18 15:45:51.435819
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.downloader.common import FileDownloader

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name):
            super(FakeInfoExtractor, self).__init__(ie_name)


# Generated at 2022-06-18 15:46:09.300764
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.compat import compat_str
    from datetime import datetime

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeInfoExtractor, self).__init__(*args, **kwargs)
            self.IE_NAME = 'test'

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYoutubeDL, self).__init__(*args, **kwargs)
            self.extractor = FakeInfoExtractor(self)


# Generated at 2022-06-18 15:46:19.139129
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl_server.compat import compat_str
    from ytdl_server.YoutubeDL import YoutubeDL
    from ytdl_server.utils import DateRange


# Generated at 2022-06-18 15:46:25.208703
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.postprocessor import FFmpegMetadataPP

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_called = False

        def to_screen(self, msg):
            self.to_screen_called = True


# Generated at 2022-06-18 15:46:35.960466
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {'id': 'testid', 'title': 'testtitle'}

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYoutubeDL, self).__init__(*args, **kwargs)
            self.extractor = FakeInfoExtractor(self)


# Generated at 2022-06-18 15:46:46.835605
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor import YoutubeIE
    from .compat import compat_str

    # Test with a video with a title that matches the format
    downloader = FileDownloader({})
    downloader.add_info_extractor(YoutubeIE())
    downloader.params['writethumbnail'] = False
    downloader.params['writeinfojson'] = False
    downloader.params['forcetitle'] = True
    downloader.params['forceid'] = True
    downloader.params['forcethumbnail'] = True
    downloader.params['forceurl'] = True
    downloader.params['forceformat'] = True
    downloader.params['simulate'] = True
    downloader.params['format'] = 'best'

# Generated at 2022-06-18 15:46:55.249387
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {'id': 'test', 'title': 'test - test - test'}

    class FakePostProcessor(PostProcessor):
        def run(self, info):
            return [], info

    ydl = YoutubeDL({'outtmpl': '%(id)s%(ext)s', 'writedescription': True, 'writeinfojson': True})
    ydl.add_info_extractor(FakeInfoExtractor())
    ydl

# Generated at 2022-06-18 15:47:05.487497
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor

    class FakeInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {'id': 'testid', 'title': 'testtitle'}

    ydl = YoutubeDL({'writedescription': True, 'writeinfojson': True, 'writethumbnail': True, 'writeautomaticsub': True, 'skip_download': True, 'format': 'bestaudio/best', 'outtmpl': '%(id)s', 'nooverwrites': True, 'postprocessors': [{
        'key': 'MetadataFromTitle',
        'titleformat': '%(title)s - %(artist)s',
    }]})

# Generated at 2022-06-18 15:47:16.722446
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name):
            super(FakeInfoExtractor, self).__init__(ie_name)


# Generated at 2022-06-18 15:47:23.941259
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from ytdl.YoutubeDL import YoutubeDL
    from ytdl.PostProcessor import PostProcessor

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen_called = False
            self.to_screen_msg = ''

        def to_screen(self, msg):
            self.to_screen_called = True
            self.to_screen_msg = msg

    class MockPostProcessor(PostProcessor):
        def __init__(self, *args, **kwargs):
            super(MockPostProcessor, self).__init__(*args, **kwargs)