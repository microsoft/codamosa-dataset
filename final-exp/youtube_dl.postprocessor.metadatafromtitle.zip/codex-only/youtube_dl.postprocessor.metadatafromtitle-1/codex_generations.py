

# Generated at 2022-06-24 14:10:56.264145
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-24 14:11:06.701410
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import youtube_dl

    class MockLogger():
        def __init__(self):
            self.messages = []
        def to_screen(self, msg):
            self.messages.append(msg)

    class MockYDL():
        def __init__(self, logger):
            self.logger = logger

    def test(titleformat, testcases):
        ydl = MockYDL(MockLogger())
        pp = MetadataFromTitlePP(ydl, titleformat)
        for title, expected in testcases:
            ydl.logger.messages = []
            info = dict(title=title)
            pp.run(info)
            actual = {'title': info['title']}
            # urlencode title to ignore minor differences in case in URL

# Generated at 2022-06-24 14:11:17.415331
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import tempfile
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    ydl.add_info_extractor('youtube')
    with tempfile.NamedTemporaryFile(mode='w+t', delete=False) as f:
        ydl.to_stdout = lambda s: f.write(s + '\n')
        m = MetadataFromTitlePP(ydl, config.get('MetadataFromTitlePP', 'format'))
        info = {
            'title': 'New Title',
            'uploader': config.get('MetadataFromTitlePP', 'uploader'),
            'extractor': 'youtube',
        }
        m.run(info)
        f.seek(0)
        actual_output = f.read()

# Generated at 2022-06-24 14:11:27.036848
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    if sys.version_info < (3, 0):
        from io import BytesIO as StringIO
    else:
        from io import StringIO
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.PostProcessor import PostProcessor

    class Downloader(object):
        def to_screen(self, string):
            print(string)

    # Pretty-print dict
    def dict_to_string(d, level=0):
        from binascii import unhexlify
        s = ''
        for key, value in sorted(d.items()):
            if isinstance(key, str):
                key = unhexlify(key.encode('ascii')).decode('utf-8')

# Generated at 2022-06-24 14:11:37.938406
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from . import FakeYDL
    from .compat import compat_urlparse
    from .extractor import VideoExtractor
    assert hasattr(VideoExtractor, '_download_webpage_handle')
    assert hasattr(VideoExtractor, '_real_extract')
    ydl = FakeYDL(
        dict(
            source_address='127.0.0.1',
            simulate=True,
            metadata_from_title=r'%(artist)s - %(title)s',
        )
    )

    # expected string

# Generated at 2022-06-24 14:11:46.494128
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    fmt = '%(title)s - %(artist)s'
    regex = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, fmt).format_to_regex(fmt) == regex
    fmt = '%(title)s - %(artist)s - %(album)s - %(track)s'
    regex = '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)\ \-\ (?P<track>.+)'
    assert MetadataFromTitlePP(None, fmt).format_to_regex(fmt) == regex

# Generated at 2022-06-24 14:11:54.580493
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .common import FakeYDL
    ydl = FakeYDL()
    pp = MetadataFromTitlePP(ydl, '%(chapter)s - %(title)s - %(artist)s')
    pp.run({'title': '1 - Foo - Bar'})

    regex = pp._titleregex
    assert regex == '(?P<chapter>.+)\\ \\-\\ (?P<title>.+)\\ \\-\\ (?P<artist>.+)'

    res = re.match(regex, '1 - Foo - Bar').groupdict()
    assert res == {'artist': 'Bar', 'chapter': '1', 'title': 'Foo'}



# Generated at 2022-06-24 14:11:59.453821
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, "%(artist)s - %(title)s")
    assert pp._titleregex == r'^(?P<artist>.+)\ \-\ (?P<title>.+)'
    pp = MetadataFromTitlePP(None, "mytitle")
    assert pp._titleregex == '^mytitle'



# Generated at 2022-06-24 14:12:09.573558
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pm = MetadataFromTitlePP(None, '%(title)s-%(artist)s-%(ext)s')

    # The regex for "%(title)s - %(artist)s" should be
    # "(?P<title>.+)\ \-\ (?P<artist>.+)"

    # Compare the regex for a simple string
    assert pm.format_to_regex('abcd') == 'abcd'
    # Compare the regex for different complex string
    assert pm.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-24 14:12:17.244850
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test class initialization
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({'from_title': '%(artist)s - %(title)s'})
    pp = MetadataFromTitlePP(ydl, '%(artist)s - %(title)s')

    # Test title parsing
    info = {'title': 'Surgeon - I Sleep On Your Shoulder'}
    res = pp.run(info)
    assert res == ([], {'title': 'Surgeon - I Sleep On Your Shoulder',
                        'artist': 'Surgeon',
                        'track': 'I Sleep On Your Shoulder'})

    # Test title parsing with optional and mandatory groups
    ydl = YoutubeDL({'from_title': '%(artist)s - %(album)s - %(track)s'})
    pp

# Generated at 2022-06-24 14:12:21.787915
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest

    class FakeDownloader(object):
        def to_screen(self, msg):
            # print(msg, file=sys.stderr)
            pass

    class MetadataFromTitlePPTest(unittest.TestCase):
        def test_MetadataFromTitlePP_run(self):
            downloader = FakeDownloader()
            titleformat = '%(uploader)s - %(title)s'
            video_title = 'test1 - test2'
            metadata = {'title': video_title}
            metadata_result = {'title': video_title, 'uploader': 'test1'}

            pp = MetadataFromTitlePP(downloader, titleformat)
            result = pp.run(metadata)


# Generated at 2022-06-24 14:12:32.169179
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Create a PostProcessor object
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')

    # Test
    #
    # Test 1
    #
    # Test attributes:
    #   None
    # Test input:
    #   title = 'The Multiparty System, 1945-1951'
    # Test expected output:
    #   info['title'] = 'The Multiparty System, 1945-1951'
    #   info['artist'] = 'NA'
    info = {}
    info['title'] = 'The Multiparty System, 1945-1951'
    result, info = pp.run(info)
    assert info['title'] == 'The Multiparty System, 1945-1951'
    assert info['artist'] is None

    # Test
    #
    # Test

# Generated at 2022-06-24 14:12:39.202293
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import youtube_dl
    ydl = youtube_dl.YoutubeDL()
    res = MetadataFromTitlePP(ydl, '%(artist)s - %(title)s').run({
        'id': 'abc123',
        'title': 'First title',
        'uploader': 'First artist'})
    assert not res[0]
    assert res[1] == {
        'artist': 'First artist',
        'id': 'abc123',
        'title': 'First title',
        'uploader': 'First artist',
    }
    sys.stderr.write('[fromtitle] parsed artist: First artist\n')
    sys.stderr.write('[fromtitle] parsed title: First title\n')

# Generated at 2022-06-24 14:12:47.556284
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    assert re.match(pp.format_to_regex('%(title)s-%(artist)s'), 'test-test2')
    assert re.match(pp.format_to_regex('%(title)s-%(artist)s'), 'test-test2 extra')
    assert re.match(pp.format_to_regex('%(title)s %(artist)s'), 'test test2')
    assert re.match(pp.format_to_regex('%(title)s %(artist)s'), 'test test2 extra extra')
    assert re.match(pp.format_to_regex('%(%(title)s %(artist)s)s'), 'test test2')

# Generated at 2022-06-24 14:12:57.155627
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    """
    A test for method MetadataFromTitlePP.format_to_regex.
    """
    import unittest
    class TestMetadataFromTitlePP(unittest.TestCase):
        """
        Test case for method MetadataFromTitlePP.format_to_regex
        """
        def setUp(self):
            """
            Set up unit test
            """
            self.fromtitle = MetadataFromTitlePP(None, None)

        def test_main(self):
            """
            Test method MetadataFromTitlePP.format_to_regex
            """

# Generated at 2022-06-24 14:13:06.589343
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    print('Testing method format_to_regex of class MetadataFromTitlePP')
    pp = MetadataFromTitlePP(None, '')
    
    # Test 1: string without %(...)s
    fmt = 'This is the title'
    print('  Test 1: string without %(...)s')
    regex = pp.format_to_regex(fmt)
    print('    fmt: %s' % fmt)
    print('    regex: %s' % regex)
    
    # Test 2: simpler string with %(...)s
    fmt = '%(title)s - %(artist)s'
    print('  Test 2: simpler string with %(...)s')
    regex = pp.format_to_regex(fmt)
    print('    fmt: %s' % fmt)

# Generated at 2022-06-24 14:13:13.882998
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .downloader import YoutubeDL
    titleformat = '%(title)s - %(artist)s'
    title = 'Magic - Coldplay'
    youtubeDL = YoutubeDL()
    metadataFromTitlePP = MetadataFromTitlePP(youtubeDL, titleformat)
    assert metadataFromTitlePP.format_to_regex(titleformat) == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    info = {'title': title}
    _, info = metadataFromTitlePP.run(info)
    assert (info['title'], info['artist']) == ('Magic', 'Coldplay')

# Generated at 2022-06-24 14:13:22.812521
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # pylint: disable=missing-docstring
    # test regex
    titleformat = '%(title)s - %(artist)s'
    titleregex = MetadataFromTitlePP(None, titleformat).format_to_regex(titleformat)
    assert titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    info = {'title': 'Title - Artist'}
    metadata, info_out = MetadataFromTitlePP(None, titleformat).run(info)
    assert metadata == []
    assert info == info_out
    assert info['title'] == 'Title'
    assert info['artist'] == 'Artist'

if __name__ == '__main__':
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-24 14:13:33.407580
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # pylint: disable=protected-access
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({'outtmpl': '%(title)s.mp3'})
    ydl._downloader.to_screen = lambda *a,**k: None
    ydl.params['mimetype'] = 'audio/webm'
    info = {'title': 'YouTube Mix - Tom Rosenthal - Go Solo'}
    MetadataFromTitlePP(ydl, '%(playlist_title)s - %(artist)s - %(song)s').run(info)
    assert info == {
        'title': 'YouTube Mix - Tom Rosenthal - Go Solo',
        'artist': 'Tom Rosenthal',
        'song': "Go Solo",
        'playlist_title': 'YouTube Mix',
    }
   

# Generated at 2022-06-24 14:13:41.665498
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp._titleformat == '%(artist)s - %(title)s'
    assert pp._titleregex == '^(?P<artist>.+) - (?P<title>.+)$'

    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '^%\(title\)s$'

    pp = MetadataFromTitlePP(None, '%%(title)s')
    assert pp._titleformat == '%%(title)s'
    assert pp._titleregex == '^%%\(title\)s$'


# Generated at 2022-06-24 14:13:48.763281
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl.downloader
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.YoutubeDL import extractor
    from youtube_dl.extractor.youtube import YoutubeIE
    from .common import prepare_mock_downloader
    from .common import FakeInfoExtractor

    class FakeExtractor(FakeInfoExtractor):
        @classmethod
        def _extract(cls, url):
            return {'id': 'id', 'title': 'title'}

    class TestExtractor(extractor.YoutubeIE):
        IE_NAME = 'test'
        IE_DESC = 'Test extractor'
        _VALID_URL = r'https?://test.com/watch\?v=(?P<id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 14:13:55.427349
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    mp = MetadataFromTitlePP(None, 'Odin - %(artist)s - %(title)s')
    assert mp._titleformat == 'Odin - %(artist)s - %(title)s'
    assert mp._titleregex == (r'Odin\ \-\ (?P<artist>.+)\ \-\ '
                              r'(?P<title>.+)')



# Generated at 2022-06-24 14:14:03.423615
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Mocks
    class MockDownloader():
        def to_screen(self, message):
            pass

    downloader = MockDownloader()
    pp = MetadataFromTitlePP(downloader, "%(title)s - %(artist)s")

    # Test
    assert pp.run({'title': 'This is a test'}) == ([], {'title': 'This is a test'})

    # Test
    assert pp.run({'title': 'This is a test - With artist'}) == ([], {'title': 'This is a test - With artist', 'artist': 'With artist'})

    # Test
    assert pp.run({'title': 'This is not a test'}) == ([], {'title': 'This is not a test'})

# Generated at 2022-06-24 14:14:09.521207
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    downloader = YoutubeDL({})
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    info = {'title': 'Django Unchained - Official Trailer (HD) - YouTube - Google Chrome'}
    pp.run(info)
    assert info['title'] == 'Django Unchained - Official Trailer (HD)'
    assert info['artist'] == 'YouTube - Google Chrome'

# Generated at 2022-06-24 14:14:13.531196
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    instance = MetadataFromTitlePP(None, None)
    assert instance.format_to_regex('%(title)s - %(artist)s') == \
           r'(?P<title>.+)\ \-\ (?P<artist>.+)'



# Generated at 2022-06-24 14:14:23.784757
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    p = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert p._titleformat == '%(artist)s - %(title)s'
    assert p._titleregex == r'(?P<artist>.+)\ \-\ (?P<title>.+)'
    p = MetadataFromTitlePP(None, 'Some Format')
    assert p._titleregex == 'Some Format'
    p = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert p._titleformat == '%(title)s - %(artist)s'
    p = MetadataFromTitlePP(None, '%(title)s - %(artist)s%(title)s')

# Generated at 2022-06-24 14:14:27.132266
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    titleformat = '%(artist)s - %(title)s'
    x = MetadataFromTitlePP(None, titleformat)
    assert x is not None
    assert x._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'



# Generated at 2022-06-24 14:14:36.630573
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import sys
    downloader = sys
    sys.to_screen = lambda s: s
    p = MetadataFromTitlePP(downloader, '%(artist)s - %(title)s')
    assert p._titleformat == '%(artist)s - %(title)s'
    assert p._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'
    p = MetadataFromTitlePP(downloader, '%(title)s')
    assert p._titleformat == '%(title)s'
    assert p._titleregex == '(?P<title>.+)'
    p = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s - %(uploader)s')

# Generated at 2022-06-24 14:14:44.773326
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from . import FakeYDL
    from .test_common import get_test_simpledownloader

    for title in ['foo bar', 'foo bar baz', 'foo bar baz pop']:
        ydl = FakeYDL()
        pp = MetadataFromTitlePP(ydl, '%(title)s')
        info = {'title': title}
        pp.run(info)
        assert info['title'] == title

    ydl = FakeYDL()
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    info = {'title': 'foo bar'}
    pp.run(info)
    assert info['title'] == 'foo bar'

    ydl = FakeYDL()
    sd = get_test_simpledownloader()
    pp = MetadataFrom

# Generated at 2022-06-24 14:14:51.034279
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    class FakeInfo:
        def __init__(self, title):
            self.title = title

    class FakeDownloader:
        def __init__(self):
            self.to_screen = lambda *args: None

    # test with ungrouped
    metadata_from_title = MetadataFromTitlePP(FakeDownloader(), '%(artist)s')
    assert metadata_from_title.format_to_regex('%(artist)s') == '(?P<artist>.+)'
    # test with grouped
    metadata_from_title = MetadataFromTitlePP(FakeDownloader(), '%(title)s - %(artist)s')

# Generated at 2022-06-24 14:14:53.657517
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    p = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    regex = p.format_to_regex('%(title)s - %(artist)s %(abc)s')
    assert regex == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ (?P<abc>.+)'



# Generated at 2022-06-24 14:15:03.331172
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .compat import compat_urllib_parse
    titleformat = '%(title)s - %(artist)s'
    title = 'Test title - Test artist'
    url = 'http://vimeo.com/78091343'
    youtube_dl = None # TODO
    metadataPP = MetadataFromTitlePP(youtube_dl, titleformat)

    info = {
        'url': url,
        'title': title,
        'ext': 'mp4',
        }

    (new_info, ) = metadataPP.run(info)

    assert new_info['title'] == info['title']
    assert new_info['artist'] == 'Test artist'
    assert not 'ext' in new_info

# Generated at 2022-06-24 14:15:11.649492
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    def check_format_to_regex(fmt, expected_regex):
        pp = MetadataFromTitlePP(None, fmt)
        assert pp.format_to_regex(fmt) == expected_regex
    check_format_to_regex('%(title)s', '(?P<title>.+)')
    check_format_to_regex('foo %(title)s bar %(artist)s',
                          'foo\ (?P<title>.+)\ bar\ (?P<artist>.+)')
    check_format_to_regex('foo (bar) %(title)s',
                          'foo\ \(bar\)\ (?P<title>.+)')

# Generated at 2022-06-24 14:15:19.607592
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import pytube
    from pytube.compat import compat_urllib_request
    from pytube.compat import compat_urllib_parse
    ydl = pytube.downloader.YouTubeDownloader({}, sys.stdout)

    fmt = '%(title)s - %(artist)s'
    meta = MetadataFromTitlePP(ydl, fmt)

    info = {
        'title': 'asdf - asdfasdf'
    }
    print(meta.run(info))
    assert info['title'] == 'asdf - asdfasdf'
    assert info['artist'] == 'asdfasdf'

    fmt2 = '%(title)s - %(artist)s - %(album)s'
    meta2 = MetadataFromTitlePP(ydl, fmt2)

   

# Generated at 2022-06-24 14:15:27.386409
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Unit test to test the transformation of a format string
# like "%(title)s - %(artist)s" to a regex like
# "(?P<title>.+)\ \-\ (?P<artist>.+)"

# Generated at 2022-06-24 14:15:31.673611
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftpp = MetadataFromTitlePP(None, None)
    assert (mftpp.format_to_regex('%(title)s - %(artist)s') ==
            r'(?P<title>.+)\ \-\ (?P<artist>.+)')

# Generated at 2022-06-24 14:15:40.377582
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    """
    Test that the MetadataFromTitlePP constructor works as expected.
    """
    d = None  # Dummy downloader
    pp = MetadataFromTitlePP(d, 'Format: %(title)s')
    assert pp
    pp = MetadataFromTitlePP(d, 'Format: %(title)s - %(artist)s')
    assert pp
    pp = MetadataFromTitlePP(d, 'Format: %(title)s - %(artist)s - %(bogus)s')
    assert pp
    pp = MetadataFromTitlePP(d, '%(title)s')
    assert pp
    pp = MetadataFromTitlePP(d, '%(title)s - %(artist)s')
    assert pp

# Generated at 2022-06-24 14:15:52.061043
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)

    test_fmt = '%(title)s - %(artist)s'
    expected_regex = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex(test_fmt) == expected_regex

    test_fmt = '%(title)s - %(artist)s - %(title)s'
    expected_regex = '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<title>.+)'
    assert pp.format_to_regex(test_fmt) == expected_regex

    test_fmt = '%(artist)s - %(title)s - %(year)s - %(random)s'


# Generated at 2022-06-24 14:15:59.726838
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Test our format_to_regex function
    assert MetadataFromTitlePP(None, 'blabla').format_to_regex(r'%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, 'blabla').format_to_regex(r'foo%(title)sbar%(artist)s') == r'foo(?P<title>.+)bar(?P<artist>.+)'

# Generated at 2022-06-24 14:16:09.648600
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-24 14:16:19.865026
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftpp = MetadataFromTitlePP(None, None)
    assert mftpp.format_to_regex("%(title)s - %(artist)s") == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert mftpp.format_to_regex("%(artist)s - %(title)s") == '(?P<artist>.+)\ \-\ (?P<title>.+)'
    assert mftpp.format_to_regex("%(artist)s - %(title)s - %(year)s") == '(?P<artist>.+)\ \-\ (?P<title>.+)\ \-\ (?P<year>.+)'

# Generated at 2022-06-24 14:16:28.101107
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None,
        '%(title)s - %(artist)s')._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None,
        '%(artist)s - %(title)s')._titleregex == r'(?P<artist>.+)\ \-\ (?P<title>.+)'
    assert MetadataFromTitlePP(None,
        '%(artist)s - %(title)s - %(album)s')._titleregex == r'(?P<artist>.+)\ \-\ (?P<title>.+)\ \-\ (?P<album>.+)'

# Generated at 2022-06-24 14:16:34.706299
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    """
    >>> t = MetadataFromTitlePP(None, '%(title)s')
    >>> t._titleformat == '%(title)s'
    True
    >>> t._titleregex == '(?P<title>.+)'
    True
    >>> t = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    >>> t._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'
    True
    >>> t = MetadataFromTitlePP(None, 'test')
    >>> t._titleregex == 'test'
    True
    """
    pass


# Generated at 2022-06-24 14:16:44.472402
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-24 14:16:48.610853
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # create a instance of the downloader class
    # to get access to some log functions
    from youtube_dl.downloader import Downloader
    dl = Downloader(params={"verbose":True})

    # create a instance of the pp class
    pp = MetadataFromTitlePP(dl, '%(title)s - %(artist)s')

    # run the postprocessor
    res, info = pp.run({'title': 'Title - Artist'})

    # check result
    expected = {'title': 'Title', 'artist': 'Artist'}
    assert info == expected, "title and artist postprocessing not working"

# Generated at 2022-06-24 14:16:54.112301
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.InfoExtractors import YoutubeIE

    # test_MetadataFromTitlePP_run - Simple case
    ydl = YoutubeDL({'writedescription': True, 'writeinfojson': True})
    ie = YoutubeIE(ydl)
    info = {'id': '12345', 'title': 'Title - Artist', 'extractor_key': 'Youtube'}
    ie._real_initialize()
    pp = MetadataFromTitlePP(ydl, "%(title)s - %(artist)s")
    res, info = pp.run(info)
    assert info['title'] == 'Title'
    assert info['artist'] == 'Artist'

    # test_MetadataFromTitlePP_run - Default title format

# Generated at 2022-06-24 14:17:00.344526
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .common import FileDownloader
    from .extractor import gen_extractors
    from .utils import unescapeHTML

    # normal
    pp = MetadataFromTitlePP(FileDownloader(), '%(title)s - %(artist)s')
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    # ignore single % sign
    pp = MetadataFromTitlePP(FileDownloader(), 'title % artist')
    assert pp._titleregex == r'title % artist'

    # multiple %% should be escaped
    pp = MetadataFromTitlePP(FileDownloader(), 'title % %% % artist')
    assert pp._titleregex == r'title \% \% \% \% \% artist'

    # extractors with empty metadata field
    info = {}


# Generated at 2022-06-24 14:17:07.902670
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Arrange
    metadata = {'title': 'title_value - artist_value'}
    titleformat = '%(title)s - %(artist)s'

    # Act
    metadata_from_titlePP = MetadataFromTitlePP(None, titleformat)
    result = metadata_from_titlePP.run(metadata)

    # Assert
    assert isinstance(result, tuple)
    assert result[0] == []
    assert result[1] == {'title': 'title_value', 'artist': 'artist_value'}


# Generated at 2022-06-24 14:17:16.381613
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Get a MetadataFromTitlePP object
    mp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')

    # Input: title: 'Test - Title'
    info = {'title': 'Test - Title'}
    # Expected output: info: {'artist': 'Test', 'title': 'Title'}
    assert mp.run(info)[1] == {'artist': 'Test', 'title': 'Title'}

    # Input: title: 'Test - '
    info = {'title': 'Test - '}
    # Expected output: info: {'artist': 'Test', 'title': ''}
    assert mp.run(info)[1] == {'artist': 'Test', 'title': ''}

    # Input: title: 'Artist - Test'

# Generated at 2022-06-24 14:17:24.884672
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    mftpp = MetadataFromTitlePP(None, '%(uploader)s - %(title)s')
    assert '%(uploader)s - %(title)s' == mftpp._titleformat
    assert r'(?P<uploader>.+)\ \-\ (?P<title>.+)' == mftpp._titleregex

    mftpp = MetadataFromTitlePP(None, '%(date)s%(uploader)s%(title)s')
    assert '%(date)s%(uploader)s%(title)s' == mftpp._titleformat
    assert r'(?P<date>.+)(?P<uploader>.+)(?P<title>.+)' == mftpp._titleregex


# Generated at 2022-06-24 14:17:30.398819
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # test all format strings and compare output to expected output
    format_strings = ['%(title)s', '%(artist)s - %(title)s', '%(artist)s - %(title)s - %(year)s', '%(artist)s - %(title)s - %(year)s - %(notinformat)s']
    test_info = {'title': 'Nekfeu - Mouhahaha', 'artist': 'Nekfeu', 'year': '2015', 'notinformat': 'notinformat'}

# Generated at 2022-06-24 14:17:40.716149
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    original_info = {'title': 'Kittens singing "The Wheels on the Bus"'}

    # format is empty
    pp = MetadataFromTitlePP(None, '')
    actual_info = original_info.copy()
    pp.run(actual_info)
    assert actual_info == original_info

    # format is equal to title
    pp = MetadataFromTitlePP(None, original_info['title'])
    actual_info = original_info.copy()
    pp.run(actual_info)
    assert actual_info == original_info

    # format contains no regex group but is a substring of title
    pp = MetadataFromTitlePP(None, 'The Wheels on the Bus')
    actual_info = original_info.copy()
    pp.run(actual_info)
    assert actual_info == original_info



# Generated at 2022-06-24 14:17:48.993780
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    def test(titleformat, expect_regex):
        pp = MetadataFromTitlePP(None, titleformat)
        if pp._titleregex != expect_regex:
            print('FAIL: _titleregex does not match for titleformat %s' %
                  titleformat)
            print('EXPECT: %s' % expect_regex)
            print('ACTUAL: %s' % pp._titleregex)
        else:
            print('SUCCESS: _titleregex matches for titleformat %s' %
                  titleformat)

    test('%(title)s - %(artist)s',
         r'(?P<title>.+)\ \-\ (?P<artist>.+)')

# Generated at 2022-06-24 14:17:57.884120
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest
    import shutil
    import os
    import tempfile
    import sys
    from ydl.utils.cmd_utils import CmdError
    from ydl.utils.cmd_utils import CmdUtils

    # Test methods of class CmdUtils
    class Mockdownloader(object):
        """
        Class to mock downloader object
        """
        def to_screen(self, msg):
            print(msg)

        def to_stderr(self, msg):
            print(msg, file=sys.stderr)

    class MockDownloader(object):
        """
        Class to mock downloader
        """
        def __init__(self):

            self.cmdUtils = CmdUtils()
            self.tmpdir = tempfile.mkdtemp()
            self.downloader = Mockdownload

# Generated at 2022-06-24 14:18:06.898731
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Test with a title format without %(attributes)s
    pp = MetadataFromTitlePP(None, 'XXX YYY')
    assert pp._titleformat == 'XXX YYY'
    assert pp._titleregex == 'XXX YYY'
    # Test with a title format with %(attributes)s
    pp = MetadataFromTitlePP(None, '%(artist)s -- %(title)s')
    assert pp._titleformat == '%(artist)s -- %(title)s'
    assert pp._titleregex == '(?P<artist>.+)\\\ \-\-\\\ (?P<title>.+)'


# Generated at 2022-06-24 14:18:17.330354
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    Tests method run of class MetadataFromTitlePP.
    """
    from youtube_dl.downloader import FakeYDL
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.version import __version__

    # Test with empty title format
    ydl = FakeYDL({'title': 'title'})
    pp = MetadataFromTitlePP(ydl, '')
    res = pp.run({'title': 'title'})
    assert res == ([], {'title': 'title'})
    assert ydl.debug_printings == ['[fromtitle] Could not interpret title of video as ""']

    # Test with FFmpegMetadataPP
    ydl = FakeYDL({'title': 'title', 'ext': 'mkv'})

# Generated at 2022-06-24 14:18:27.429740
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    # construct regex to extract title and artist from a video title
    if 'title' not in pp._titleregex:
        raise AssertionError('title field not in regex')
    if 'artist' not in pp._titleregex:
        raise AssertionError('artist field not in regex')
    # regex must not contain any %(...)s
    if re.match(pp._titleregex.replace('(?P<title>.+)', ''), '%(title)s') is not None:
        raise AssertionError('%(...)s is not removed from the regex')

    # test format_to_regex function
    # check if %(title)s was converted to (?P<title>.+)

# Generated at 2022-06-24 14:18:30.047790
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # TODO: Add more test cases
    assert MetadataFromTitlePP(None, '%(artist)s - %(title)s').format_to_regex(
        '%(artist)s - %(title)s') == '(?P<artist>.+)\\ \-\\ (?P<title>.+)'



# Generated at 2022-06-24 14:18:36.359351
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')


# Generated at 2022-06-24 14:18:40.760578
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    assert pp.format_to_regex('%(title)s - %(artist)s') == (r'(?P<title>.+)\ '
                                                            r'\-\ (?P<artist>.+)'
                                                            )


# Generated at 2022-06-24 14:18:47.939363
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftp = MetadataFromTitlePP(None, None)
    assert mftp.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert mftp.format_to_regex('%(title)s -- %(uploader)s') == '(?P<title>.+)\ \-\-\ (?P<uploader>.+)'
    assert mftp.format_to_regex('author: %(uploader)s, song: %(title)s') == 'author\:\ (?P<uploader>.+),\ song\:\ (?P<title>.+)'
    assert mftp.format_to_regex('%(title)s') == '(?P<title>.+)'

# Generated at 2022-06-24 14:18:56.324338
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    pp = MetadataFromTitlePP(None, '%(id)s')
    assert pp._titleformat == '%(id)s'
    assert pp._titleregex == '(?P<id>.+)'

    pp = MetadataFromTitlePP(None, '%(title)s - %(id)s')
    assert pp._titleformat == '%(title)s - %(id)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<id>.+)'



# Generated at 2022-06-24 14:18:59.779535
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    assert MetadataFromTitlePP(
        None, '%(title)s - %(name)s')._titleformat == '%(title)s - %(name)s'
    assert MetadataFromTitlePP(None, '')._titleformat == ''
    assert MetadataFromTitlePP(None, 'a')._titleformat == 'a'



# Generated at 2022-06-24 14:19:09.000793
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    c = MetadataFromTitlePP(None, 'a - b')
    assert c.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert c.format_to_regex('art-ist') == 'art\-ist'
    assert c.format_to_regex('artist') == 'artist'
    assert c.format_to_regex('artist - %(title)s') == 'artist\ \-\ (?P<title>.+)'

# Generated at 2022-06-24 14:19:13.348731
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    metadata_from_title_pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert metadata_from_title_pp._titleformat == '%(title)s - %(artist)s'
    assert metadata_from_title_pp._titleregex == (
        r'(?P<title>.+)\ \-\ (?P<artist>.+)')

# Generated at 2022-06-24 14:19:21.354531
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Create a video info
    info = {
        'title': 'The Artist - The Title',
        'description': 'The description',
    }
    # Create a MetadataFromTitlePP
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s - %(description)s')
    # Test MetadataFromTitlePP
    info_ = pp.run(info)[1]
    assert info_['artist'] == 'The Artist'
    assert info_['title'] == 'The Title'
    assert info_['description'] == 'The description'


# Generated at 2022-06-24 14:19:30.954668
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import unittest

    class TestMetadataFromTitlePP(unittest.TestCase):
        def test_format_to_regex(self):
            class DummyYoutubeDL(object):
                def __init__(self):
                    self.to_screen = lambda x: x
            ydl = DummyYoutubeDL()
            pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')

            self.assertEqual(pp.format_to_regex('%(title)s - %(artist)s'),
                             '(?P<title>.+)\ \-\ (?P<artist>.+)')

        def test_run(self):
            class DummyYoutubeDL(object):
                def __init__(self):
                    self.to_screen = lambda x: x
           

# Generated at 2022-06-24 14:19:36.705398
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .youtube_dl.YoutubeDL import YoutubeDL
    from .youtube_dl.utils import DateRange
    from .downloader import Downloader
    from io import BytesIO
    class FakeDl(Downloader):
        def __init__(self):
            self.to_screen_args = []
        def to_screen(self, *args):
            self.to_screen_args.append(args)
        def report_warning(self, *args):
            self.to_screen_args.append(args)
    fdl = FakeDl()
    dl = YoutubeDL({})
    dl.add_post_processor(MetadataFromTitlePP(fdl, '%(artist)s - %(title)s'))

# Generated at 2022-06-24 14:19:45.405153
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    obj = MetadataFromTitlePP(None, '%(title)s')
    assert obj.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert obj.format_to_regex('abc %(title)s') == r'abc\ (?P<title>.+)'
    assert obj.format_to_regex('%(title)s abc') == r'(?P<title>.+)\ abc'
    assert obj.format_to_regex('%(title)s abc %(artist)s') == r'(?P<title>.+)\ abc\ (?P<artist>.+)'

# Generated at 2022-06-24 14:19:51.628908
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '')
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert pp.format_to_regex('%(title)s%(artist)s') == '(?P<title>.+)(?P<artist>.+)'


# Generated at 2022-06-24 14:20:02.469836
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    from .YoutubeDL import YoutubeDL
    from .PostProcessor import PostProcessor

    class MockInfoDict(dict):
        def __init__(self, dict_):
            dict.__init__(dict_)
            self.get = dict_.get
            self.keys = dict_.keys
            self.__getitem__ = dict_.__getitem__
            self.__setitem__ = dict_.__setitem__

    class MockDownloader(object):
        def to_screen(self, msg):
            pass

    # Tests
    class TestMetadataFromTitlePP(MetadataFromTitlePP):
        def __init__(self):
            super(TestMetadataFromTitlePP, self).__init__(MockDownloader(),
                                                          '%(title)s')

        def run(self, info):
            return

# Generated at 2022-06-24 14:20:11.382856
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    class DummyDownloader:
        def __init__(self):
            self.to_screen_calls = []
        def to_screen(self, msg):
            self.to_screen_calls.append(msg)

    titleformat = '%(series)s - %(season)02d - %(episode)02d - %(title)s'
    title = 'Dummy Series - 01 - 02 - Dummy Episode'
    pp = MetadataFromTitlePP(DummyDownloader(), titleformat)

    result = pp.format_to_regex(titleformat)
    assert result == r'(?P<series>.+)\ \-\ (?P<season>\d{2})\ \-\ (?P<episode>\d{2})\ \-\ (?P<title>.+)'

# Generated at 2022-06-24 14:20:21.659444
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    test_cases = (
        ('%(title)s', r'(?P<title>.+)'),
        ('%(title)s - %(artist)s', r'(?P<title>.+)\ \-\ (?P<artist>.+)'),
        ('%(title)s by %(artist)s on %(album)s',
         r'(?P<title>.+)\ by\ (?P<artist>.+)\ on\ (?P<album>.+)'),
    )
    for test_fmt, test_result in test_cases:
        result = pp.format_to_regex(test_fmt)

# Generated at 2022-06-24 14:20:28.869256
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.postprocessor import PostProcessor
    from youtube_dl import YoutubeDL
    ydl = YoutubeDL()

    pp = MetadataFromTitlePP(ydl, '%(test)s')
    res = pp.run({'title': 'abc'})
    assert res == ([], {})

    pp = MetadataFromTitlePP(ydl, '%(test)s')
    res = pp.run({'title': 'a %(test)s b'})
    assert res == ([], {'test': 'a %(test)s b'})

    pp = MetadataFromTitlePP(ydl, '%(test)s')
    return pp.run({'title': 'a %(test)s %(test)s b'})

# Generated at 2022-06-24 14:20:30.658023
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .downloader import FileDownloader

# Generated at 2022-06-24 14:20:40.143271
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)

    assert(pp.format_to_regex('%(title)s - %(artist)s') ==
           '(?P<title>.+)\\ \\-\\ (?P<artist>.+)')
    assert(pp.format_to_regex('%(title)s') == '(?P<title>.+)')
    assert(pp.format_to_regex('%(title)s foo') == '(?P<title>.+)\\ foo')
    assert(pp.format_to_regex('%(title)s foo %(artist)s') ==
           '(?P<title>.+)\\ foo\\ (?P<artist>.+)')

# Generated at 2022-06-24 14:20:46.246356
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    m = MetadataFromTitlePP(None, '%(title)s')
    assert m._titleregex == '(?P<title>.+)'

    m = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert m._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    m = MetadataFromTitlePP(None, '%(title)s - %(artist)s [%(genre)s]')
    assert m._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \[(?P<genre>.+)\]'

    m = MetadataFromTitlePP(None, '%(title)s - [%(genre)s]')

# Generated at 2022-06-24 14:20:56.226173
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    def run(self):
        pass
    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '(?P<title>.+)'
    pp = MetadataFromTitlePP(None, '%(id)s')
    assert pp._titleformat == '%(id)s'
    assert pp._titleregex == '(?P<id>.+)'
    pp = MetadataFromTitlePP(None, '%(title)s - %(id)s')
    assert pp._titleformat == '%(title)s - %(id)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<id>.+)'