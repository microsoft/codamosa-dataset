

# Generated at 2022-06-24 14:10:57.284934
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader

    # Run test
    # We will use an instance of FileDownloader, but any other downloader
    # class would work, too.
    downloader = FileDownloader()
    titleformat = '%(title)s [%(id)s] - %(uploader)s'
    titleregex = (MetadataFromTitlePP.format_to_regex(titleformat)
                  if re.search(r'%\(\w+\)s', titleformat)
                  else titleformat)
    pp = MetadataFromTitlePP(downloader, titleformat)

    # Test format to regex
    assert titleregex == r'(?P<title>.+)\ \[(?P<id>.+)\]\ \-\ (?P<uploader>.+)'

    # Test matching for non-matching title

# Generated at 2022-06-24 14:11:07.630949
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from io import BytesIO
    from subprocess import call

    class Mock(object):
        def __init__(self):
            self.stdout = sys.stdout
            self.stdout_buffer = BytesIO()

        def to_screen(self, message):
            self.stdout_buffer.write(message.encode('utf-8', 'replace') + b'\n')

        def __del__(self):
            self.stdout.write(self.stdout_buffer.getvalue().decode(
                self.stdout.encoding, 'replace'))
            self.stdout.flush()


# Generated at 2022-06-24 14:11:15.168628
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(album)s - %(playlist)s')
    assert pp.format_to_regex('%(album)s - %(playlist)s') == r'(?P<album>.+)\ \-\ (?P<playlist>.+)'
    assert pp.format_to_regex('%(album)s - %(playlist)s') == pp._titleregex

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 14:11:24.996362
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Test 1
    obj = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert obj._titleformat == '%(title)s - %(artist)s'
    assert obj._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    # Test 2
    obj = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(album)s')
    assert obj._titleformat == '%(title)s - %(artist)s - %(album)s'
    assert obj._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'


# Generated at 2022-06-24 14:11:29.824833
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    assert MetadataFromTitlePP(None, '%(title)s')._titleregex == '(?P<title>.+)'
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s')._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-24 14:11:39.937651
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, 'test')._titleregex == 'test'
    assert MetadataFromTitlePP(None, 'test abc')._titleregex == 'test\ abc'
    assert (MetadataFromTitlePP(None, 'test %(foo)s')
            ._titleregex == r'test\ (?P<foo>.+)')
    assert (MetadataFromTitlePP(None, '%(a)s %(b)s %(c)s %(d)s')
            ._titleregex == r'(?P<a>.+)\ (?P<b>.+)\ (?P<c>.+)\ (?P<d>.+)')

# Generated at 2022-06-24 14:11:45.863718
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP.format_to_regex('%(artist)s - %(album)s') == '(?P<artist>.+)\ \-\ (?P<album>.+)'
    assert MetadataFromTitlePP.format_to_regex('%(artist)s') == '(?P<artist>.+)'
    assert MetadataFromTitlePP.format_to_regex('%(artist)s [at] %(date)s') == '(?P<artist>.+)\ \\[at\\]\ (?P<date>.+)'

# Generated at 2022-06-24 14:11:55.624088
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    m = MetadataFromTitlePP(None, None)
    assert m.format_to_regex('') == ''
    assert m.format_to_regex('abc') == 'abc'
    assert (m.format_to_regex('%(title)s')
            == r'(?P<title>.+)')
    assert (m.format_to_regex(' %(title)s\t')
            == r'\ (?P<title>.+)\t')
    assert (m.format_to_regex(' - %(title)s - ')
            == r'\ \-\ (?P<title>.+)\ \-\ ')

# Generated at 2022-06-24 14:12:05.987885
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import Downloader
    # verify that some formats are converted correctly

# Generated at 2022-06-24 14:12:14.411064
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    """
    Unit test for MetadataFromTitlePP constructor
    """
    # example of format string, but we'll only test a few parts of it
    titleformat = '%(title)s - %(artist)s | %(album)s [%(date)s]'
    uut = MetadataFromTitlePP(None, titleformat)

    # test regex for matching whole format string
    regex = uut._titleregex
    assert re.match(regex, 'song - artist | album [date]')
    assert re.match(regex, ' -  |  [date]')
    assert re.match(regex, 'song -')
    assert re.match(regex, 'song - artist | album [')
    assert re.match(regex, ' -  |  [')

# Generated at 2022-06-24 14:12:21.734331
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import pytube
    downloader = pytube.YoutubeDL()
    titleformat = '%(title)s - %(artist)s'
    metadata = {
        'title': 'This is a title - with Artist and another - field',
        'artist': None,
    }
    pp = MetadataFromTitlePP(downloader, titleformat)
    expected = {
        'title': 'This is a title - with Artist and another - field',
        'artist': 'with Artist and another - field',
    }
    _, result = pp.run(metadata)
    assert result == expected

# Generated at 2022-06-24 14:12:32.080571
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    def check_run(titleformat, title, expected_output):
        test_downloader = object()
        pp = MetadataFromTitlePP(test_downloader, titleformat)

        pp_result = pp.run({'title': title})
        assert pp_result == expected_output, (
                'Unexpected result for input: titleformat=%s, title=%s' %
                (titleformat, title))


# Generated at 2022-06-24 14:12:32.646714
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass

# Generated at 2022-06-24 14:12:40.276391
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # Instance needed for to_screen method
    class FakeYDL:
        def __init__(self):
            self.to_screen = lambda s: None
    fake_YDL = FakeYDL()

    # Case 1: no substitution
    titleformat = 'Testvideo'
    titleregex = MetadataFromTitlePP(fake_YDL, titleformat)._titleregex
    # For title '' the regex should match, but there should be no groups
    assert re.match(titleregex, '').groups() == ()
    # For title 'Testvideo' the regex should match, and the group should be
    # equal to the title
    assert re.match(titleregex, titleformat).groups() == (titleformat,)

    # Case 2: two substitutions
    titleformat = '%(title)s - %(artist)s'


# Generated at 2022-06-24 14:12:51.992167
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    import unittest

    from .youtube_dl.extractor.common import InfoExtractor

    class TestMetadataFromTitlePP(MetadataFromTitlePP):
        # Override run method, because this method is not intended to be used.
        def run(self, info):
            return info

    class TestInfoExtractor(InfoExtractor):
        # Override extract method, because extract method is not intended to be used.
        def extract(self, url):
            return {}

    class MetadataFromTitlePPUnitTest(unittest.TestCase):
        def test_format_to_regex(self):
            # test if implementation of format_to_regex is working (does it produce the same result?)
            dl = TestInfoExtractor(dict())

# Generated at 2022-06-24 14:13:02.217485
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-24 14:13:06.926806
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None,'%(title)s_%(artist)s')
    assert pp.format_to_regex('%(title)s_%(artist)s') == '(?P<title>.+)_(?P<artist>.+)'

# Generated at 2022-06-24 14:13:15.776647
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    fmt = '%(abc)s - %(xyz)s - %(title1)s - %(title2)s - %(title3)s'
    regex = '(?P<abc>.+) - (?P<xyz>.+) - (?P<title1>.+) - (?P<title2>.+) - (?P<title3>.+)'
    instance = MetadataFromTitlePP(None, fmt)
    assert instance._titleregex == regex
    fmt = '%(abc)s - %(xyz)s - %(title1)'
    regex = '(?P<abc>.+) - (?P<xyz>.+) - (?P<title1>.+)'
    instance = MetadataFromTitlePP(None, fmt)
    assert instance._titleregex == regex

# Generated at 2022-06-24 14:13:25.825293
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    fmt = '%(title)s - %(artist)s'
    regex = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert regex == MetadataFromTitlePP.format_to_regex(fmt)

    fmt = '%(title)s - %(artist)s - %(album)s'
    regex = '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'
    assert regex == MetadataFromTitlePP.format_to_regex(fmt)

    fmt = '%(title)s'
    regex = '(?P<title>.+)'
    assert regex == MetadataFromTitlePP.format_to_regex(fmt)

    fmt = '%(title)s -'

# Generated at 2022-06-24 14:13:36.028709
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # create a downloader object
    from youtube_dl.downloader import Downloader
    dl = Downloader({})
    # don't write to stdout
    dl.to_screen = lambda x: None

    # create a pp object
    pp = MetadataFromTitlePP(dl, '%(artist)s - %(title)s')
    # create a sample info object
    info = {
        'id': 'id',
        'ext': 'ext',
        'title': 'The artist - The title',
        'duration': 'duration'
    }
    # run pp
    infos, info = pp.run(info)

    # check info was parsed correctly
    assert infos == []
    assert info['artist'] == 'The artist'
    assert info['title'] == 'The title'

# Generated at 2022-06-24 14:13:39.907232
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import FakeYDL
    pp = MetadataFromTitlePP(FakeYDL(), '%(title)s - %(artist)s')
    r = pp.format_to_regex('%(title)s - %(artist)s')
    assert r == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-24 14:13:47.675838
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.utils import DateRange
    test_pp = MetadataFromTitlePP(None, r'%(title)s - %(artist)s')
    info = {'title': 'TestTitle - TestArtist'}
    assert [] == test_pp.run(info)[0]
    assert {'title': 'TestTitle', 'artist': 'TestArtist'} == info

    test_pp = MetadataFromTitlePP(None, r'%(title)s')
    info = {'title': 'TestTitle'}
    assert [] == test_pp.run(info)[0]
    assert {'title': 'TestTitle'} == info

    test_pp = MetadataFromTitlePP(None, r'%(artist)s')
    info = {'title': 'TestTitle - TestArtist'}
    assert [] == test_

# Generated at 2022-06-24 14:13:59.030728
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.utils import DateRange
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.youtube import YoutubeIE

    # Initialize
    downloader = YoutubeDL({})
    # Fake downloader.
    downloader.params['outtmpl'] = '%(title)s.%(ext)s'
    downloader.add_info_extractor(YoutubeIE())
    downloader.add_default_info_extractors()

    # Test
    p = MetadataFromTitlePP(downloader,
            '%(title)s - %(artist)s - %(track)s - %(album)s')

# Generated at 2022-06-24 14:14:05.510746
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    import unittest
    test = MetadataFromTitlePP(None, None)
    test._downloader = unittest.TestCase()

    test.test_1 = '%(title)s - %(artist)s'
    test.test_2 = '%(title)s - %(artist)s [%(year)s]'
    test.test_3 = '%(title)s - %(artist)s [%(year)s.'
    test.test_4 = '%(title)s - %(artist)s [%(year)d] %(album)s'
    test.test_5 = '%(title)s %(foo)s %(bar)s'


# Generated at 2022-06-24 14:14:15.562459
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ydl.downloader import Downloader
    from ydl.compat import compat_str
    from ydl.postprocessor import JSONPP
    from ydl.extractor import YoutubeIE
    from ydl.info import InfoExtractor

    def add_info_extractor(clazz):
        InfoExtractor._ies.add(clazz)

    # prepare test configuration
    add_info_extractor(YoutubeIE)

    test_title = 'foo - bar'
    test_url = 'http://www.youtube.com/watch?v=BaW_jenozKc'

    def _make_result(expected):
        # prepare expected result
        expected['_type'] = 'url'
        expected['webpage_url'] = test_url

# Generated at 2022-06-24 14:14:25.764595
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from collections import namedtuple
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor import common

    class FakeInfoDict(dict):
        def __getitem__(self, key):
            return dict.__getitem__(self, key)

    FakeInfo = namedtuple('FakeInfo', ['__getitem__'])

    class FakeExtractor(common.InfoExtractor):
        IE_DESC = 'fake ie'
        IE_NAME = 'fakeie'

        def __init__(self):
            super(FakeExtractor, self).__init__()

        def _real_extract(self, url):
            return {
                '_type': 'url',
                'url': url,
                'title': 'title - artist',
            }


# Generated at 2022-06-24 14:14:33.840276
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.PostProcessor import PostProcessor
    info = {
        'title': 'This is a title',
        'id': 'This is an id',
        'url': 'This is a url'
    }
    ydl = YoutubeDL({})
    MetadataFromTitlePP(ydl, '%(title)s %% %% id: %(id)s').run(info)
    assert (info == {
        'title': 'This is a title %% %% id: This is an id',
        'id': 'This is an id',
        'url': 'This is a url'
    })


# Generated at 2022-06-24 14:14:38.407477
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # given
    titleformat = '%(title)s - %(artist)s'
    # when
    regex = MetadataFromTitlePP(None, titleformat).format_to_regex(titleformat)
    # then
    assert regex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-24 14:14:42.663187
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    static_test_values = {
        '%(title)s - %(artist)s':
            r'(?P<title>.+)\ \-\ (?P<artist>.+)',
        '%(title)s - %(artist)s - %(release)s':
            r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<release>.+)',
    }

    for fmt, regex in static_test_values.items():
        assert MetadataFromTitlePP(None, fmt).format_to_regex(fmt) == regex

# Generated at 2022-06-24 14:14:52.275470
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-24 14:15:03.136437
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from collections import namedtuple
    downloader = namedtuple('Downloader', ['to_screen'])

    # Test with no meta information
    info = {'title': 'Foo Bar',
            'description': ''}
    metafromtitle = MetadataFromTitlePP(
        downloader, '%(title)s - %(description)s')
    info_out, new_info = metafromtitle.run(info)
    assert info_out == []
    assert info == new_info

    # Test with meta information
    info = {'title': 'Foo Bar - Description: Hello world',
            'description': ''}
    metafromtitle = MetadataFromTitlePP(
        downloader, '%(title)s - %(description)s')

# Generated at 2022-06-24 14:15:12.821248
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .downloader import FileDownloader
    from .extractor import YoutubeIE
    from .common import FileDownloaderTest
    test = FileDownloaderTest()
    test.add_info_extractor(YoutubeIE)
    ydl = FileDownloader(test, {}, {'title': 'From Title Test'})
    mftpp = MetadataFromTitlePP(ydl)
    titleformat_list = ['%(title)s', '%(title)s - %(uploader)s']
    string_list = ['From Title Test', 'From Title Test - Test Uploader']
    assert mftpp.format_to_regex(titleformat_list[0]) == r'(?P<title>.+)'

# Generated at 2022-06-24 14:15:20.279683
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # pylint: disable=protected-access
    assert MetadataFromTitlePP._MetadataFromTitlePP__format_to_regex(
        '%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP._MetadataFromTitlePP__format_to_regex(
        '%(title)s -  - %(artist)s') == '(?P<title>.+)\ \-\  \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP._MetadataFromTitlePP__format_to_regex(
        '%(title)s - %(artist)s -') == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-'
    assert MetadataFromTitlePP

# Generated at 2022-06-24 14:15:31.766425
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    expected = r'foo\ \(bar\)\ (?P<group>.+)'
    # Test simple string
    test = pp.format_to_regex('foo (bar) %(group)s')
    assert test == expected
    # Test Unicode string
    test = pp.format_to_regex(u'foo (bar) %(group)s')
    assert test == expected
    # Test list of strings
    test = pp.format_to_regex(['foo (bar) ', '%(group)s'])
    assert test == expected
    # Test "list of" Unicode string
    test = pp.format_to_regex(u'foo (bar) %(group)s'.split())
    assert test == expected


# Generated at 2022-06-24 14:15:36.411343
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    titleformat = '%(title)s - %(artist)s'
    downloader = None
    pp = MetadataFromTitlePP(downloader, titleformat)
    expected = r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp._titleregex == expected
    assert pp._format_to_regex(titleformat) == expected

# Generated at 2022-06-24 14:15:42.881808
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.compat import compat_str

    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    info = {'title': 'Ariana Grande - Problem ft. Iggy Azalea'}

    assert pp.run(info)[1] == {'title': 'Ariana Grande - Problem ft. Iggy Azalea',
                               'artist': 'Ariana Grande'}

    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    info = {'title': 'Problem - Ariana Grande ft. Iggy Azalea'}
    assert pp.run(info)[1] == {'title': 'Problem - Ariana Grande ft. Iggy Azalea'}


# Generated at 2022-06-24 14:15:54.249169
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    """Unit test for constructor of class MetadataFromTitlePP"""

    # Test regular expression parsing
    def test_format_to_regex(titleformat, expected_regex):
        pp = MetadataFromTitlePP(None, titleformat)
        if pp._titleregex != expected_regex:
            raise AssertionError(
                'Failed to parse titleformat. Expected: %s Got: %s'
                % (expected_regex, pp._titleregex))

    test_format_to_regex('%(a)s - %(b)s', r'(?P<a>.+)\ \-\ (?P<b>.+)')
    test_format_to_regex('%(a)s%(b)s', r'(?P<a>.+)(?P<b>.+)')
    test

# Generated at 2022-06-24 14:16:03.646805
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Test with simple format
    mftpp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert mftpp._titleformat == '%(artist)s - %(title)s'
    assert mftpp._titleregex == '(?P<artist>.+)\\ \\-\\ (?P<title>.+)'
    # Test with complex format
    mftpp = MetadataFromTitlePP(None, '%(title)s [Video %(video_id)s]')
    assert mftpp._titleformat == '%(title)s [Video %(video_id)s]'
    assert mftpp._titleregex == '(?P<title>.+)\\ \\[Video\\ (?P<video_id>.+)\\]'

#Unit test for format_to_regex

# Generated at 2022-06-24 14:16:06.680560
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    regex = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp._titleregex == regex


# Generated at 2022-06-24 14:16:11.494735
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(title)s')
    # re.escape not in python 2.4
    assert pp.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert pp.format_to_regex('%(title)s.%(ext)s') == '(?P<title>.+)\.(?P<ext>.+)'
    assert pp.format_to_regex('%(title)s-%(artist)s') == '(?P<title>.+)\-(?P<artist>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-24 14:16:22.087496
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor import gen_extractors
    from .compat import compat_str

    def make_temp_file(title):
        with open(title.replace(' ', 'n'), 'wb') as f:
            f.write(b'blabla')

    def title_to_info(title):
        make_temp_file(title)
        with open(title.replace(' ', 'n'), 'rb') as f:
            return c.process_video_result('dummy_format', [], {'title': title}, fd=f)

    c = FileDownloader({})
    c.add_info_extractor(gen_extractors()[0])

# Generated at 2022-06-24 14:16:22.807707
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pass

# Generated at 2022-06-24 14:16:26.238888
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, r'%(artist)s - %(title)s')
    assert pp.format_to_regex(r'%(artist)s - %(title)s') == '(?P<artist>.+)\ \-\ (?P<title>.+)'

# Generated at 2022-06-24 14:16:34.577096
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    test_cases = [
        ('%(title)s - %(artist)s', '^(?P<title>.+)\ \-\ (?P<artist>.+)$'),
        ('%(title)s - %(artist)s - %(album)s',
         '^(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)$'),
        ('%(title)s', '^(?P<title>.+)$'),
        ('%(title)s.mp4', '^(?P<title>.+)\.mp4$'),
        ('%(title)s-%(album)s', '^(?P<title>.+)\-(?P<album>.+)$')
    ]

    for titleformat, titleregex in test_cases:
        m

# Generated at 2022-06-24 14:16:40.211637
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None,'%(title)s-%(artist)s').format_to_regex(
        '%(title)s-%(artist)s') == '(?P<title>.+)-(?P<artist>.+)'
    assert MetadataFromTitlePP(None,'%(title)s').format_to_regex(
        '%(title)s') == '(?P<title>.+)'
    assert MetadataFromTitlePP(None,'%(artist_dash)s').format_to_regex(
        '%(artist_dash)s') == '(?P<artist_dash>.+)'
    assert MetadataFromTitlePP(None,'%(artist_paren)s').format_to_regex(
        '%(artist_paren)s') == '(?P<artist_paren>.+)'

# Generated at 2022-06-24 14:16:50.249073
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    def run_test(titleformat, title, expected_titleformat, expected_titleregex):
        pp = MetadataFromTitlePP(None, titleformat)
        assert pp._titleformat == expected_titleformat
        assert pp._titleregex == expected_titleregex
        match = re.match(pp._titleregex, title)
        assert match is not None

    run_test('%(title)s', 'The Title', '%(title)s', r'(?P<title>.+)')
    run_test('%(title)s - %(artist)s', 'The Title - The Artist',
             '%(title)s - %(artist)s', r'(?P<title>.+)\ \-\ (?P<artist>.+)')

# Generated at 2022-06-24 14:16:58.364784
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import youtube_dl
    ydl = youtube_dl.YoutubeDL({})
    assert 0 == ydl.set_option('matchtitle', '%(title)s - %(artist)s')
    assert 0 == ydl.set_option('noplaylist', True)
    assert 0 == ydl.set_option('restrictfilenames', True)

# Generated at 2022-06-24 14:17:08.867193
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import Downloader, FileDownloader
    from .extractor.youtube import YoutubeIE
    import sys

    # In order to pass the test, uncomment the lines below
    # class FakeLogger(object):
    #     def debug(self, *args, **kwargs):
    #         print(args, kwargs)

    #     def warning(self, *args, **kwargs):
    #         print(args, kwargs)

    #     def error(self, *args, **kwargs):
    #         print(args, kwargs)

    # FakeLogger = FakeLogger()

    info = {}
    # Provided by youtube
    info['title'] = 'Title as provided by youtube %(uploader)s %(upload_date)s'

# Generated at 2022-06-24 14:17:16.852828
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():

    class FakeInfo(dict):
        pass

    class FakeYdl(object):
        @staticmethod
        def to_screen(msg):
            print(msg)

    # Test that constructor of MetadataFromTitlePP works as expected

    # Test with a titleformat containing only a string
    titleformat = '%(abcd)s'
    title = 'Some Video'
    info = FakeInfo({'title' : title})
    fake_ydl = FakeYdl()
    instance = MetadataFromTitlePP(fake_ydl, titleformat)
    assert instance._titleformat == titleformat
    assert instance._titleregex == 'Some\ Video'

    # Test with a titleformat containing a %(title)s
    titleformat = '%(title)s - %(abcd)s'
    title = 'Beautiful Song'
    info

# Generated at 2022-06-24 14:17:27.535696
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL(dict(writethumbnail=True, quiet=True))
    metadata = {'id': 'abc'}
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    pp.run(metadata)
    assert metadata == {'id': 'abc', 'title': 'abc', 'artist': 'abc'}

    ydl = YoutubeDL(dict(writethumbnail=True, quiet=True))
    metadata = {'id': 'abc'}
    pp = MetadataFromTitlePP(ydl, '')
    pp.run(metadata)
    assert metadata == {'id': 'abc', 'title': 'abc'}

    ydl = YoutubeDL(dict(writethumbnail=True, quiet=True))
   

# Generated at 2022-06-24 14:17:38.633241
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    import unittest

    class Test(unittest.TestCase):
        def test(self):
            f = MetadataFromTitlePP(None, '%(title)s - %(artist)s').format_to_regex

# Generated at 2022-06-24 14:17:48.043078
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from ..YoutubeDL import YoutubeDL
    pp = MetadataFromTitlePP(YoutubeDL(), '')

    assert pp._titleformat == ''
    assert pp._titleregex == ''

    pp = MetadataFromTitlePP(YoutubeDL(), '%(title)s')
    assert pp._titleregex == '\(?P<title>.+\)?'

    pp = MetadataFromTitlePP(YoutubeDL(), '%(title)s - %(artist)s')
    assert pp._titleregex == '\(?P<title>.+\)\ \-\ \(?P<artist>.+\)?'
    
    pp = MetadataFromTitlePP(YoutubeDL(), '%(artist)s - %(title)s')

# Generated at 2022-06-24 14:17:54.500355
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class DummyInfo():
        pass
    dummy_info = DummyInfo()
    dummy_info.title = 'This is a title - very nice'
    downloader = DummyInfo()
    downloader.to_screen = lambda msg: msg
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    pp.run(dummy_info)
    assert dummy_info.title == 'This is a title - very nice'
    assert dummy_info.artist == 'very nice'

# Generated at 2022-06-24 14:18:04.905710
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    import threading
    import time
    import logging
    import shutil

    # Mockup code
    class MockupLogger(object):
        def debug(self, message): pass

        def warning(self, message): pass

    class MockupYoutubeDL(object):
        def __init__(self):
            self._callbacks = {}
            self.to_screen = logging.info
            self.to_stdout = sys.stdout
            self.to_stderr = sys.stderr

        def process_ie_result(self, result, download, extra_info): pass

        def add_info_extractor(self, ie): pass

        def set_progress_hook(self, callback):
            self._callbacks['progress'] = callback


# Generated at 2022-06-24 14:18:13.083829
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, 'a - b(%(c)s)').format_to_regex('a - b(%(c)s)') == 'a - b\(\.\+\)'
    assert MetadataFromTitlePP(None, 'a - b(%(c)s)').format_to_regex('a - b(%(c)s) - d') == 'a - b\(\.\+\) - d'
    assert MetadataFromTitlePP(None, 'a - b(%(c)s)').format_to_regex('a - b(%(c)s) - %(d)s') == 'a - b\(\.\+\) - \(\.\+\)'

# Generated at 2022-06-24 14:18:21.040801
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    mftpp = MetadataFromTitlePP(None, None)
    assert mftpp._titleformat is None
    assert mftpp._titleregex is None

    mftpp = MetadataFromTitlePP(None, 'foo')
    assert mftpp._titleformat == 'foo'
    assert mftpp._titleregex == 'foo'

    mftpp = MetadataFromTitlePP(None, '%(bar)s')
    assert mftpp._titleformat == '%(bar)s'
    assert mftpp._titleregex == '(?P<bar>.+)'

    mftpp = MetadataFromTitlePP(None, '%(bar)s %(foo)s')
    assert mftpp._titleformat == '%(bar)s %(foo)s'

# Generated at 2022-06-24 14:18:30.222242
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():

    title_pp = MetadataFromTitlePP(None, '')
    # single group case:
    assert title_pp.format_to_regex('%(title)s') == '(?P<title>.+)'
    # single group at the beginning:
    assert title_pp.format_to_regex('%(title)s - foo') == '(?P<title>.+)\ \-\ foo'
    # single group at the end:
    assert title_pp.format_to_regex('foo - %(title)s') == 'foo\ \-\ (?P<title>.+)'
    # single group in the middle:
    assert title_pp.format_to_regex('foo - %(title)s - bar') == 'foo\ \-\ (?P<title>.+)\ \-\ bar'
    # multiple

# Generated at 2022-06-24 14:18:38.415030
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s')._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s')._titleregex == '%(title)s - %(artist)s'
    assert not re.search(r'%\(\w+\)s', '%(title)s - %(artist)s')


# Generated at 2022-06-24 14:18:46.628717
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .downloader import Downloader
    from .compat import compat_str  # pylint: disable=no-name-in-module

    mpp = MetadataFromTitlePP(None, '')

# Generated at 2022-06-24 14:18:55.625169
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    titleformat = '%(id)s-%(title)s-%(uploader)s'
    class Mock_PostProcessor:
        def to_screen(self, *args, **kwargs):
            print("Console output: " + str(args))
    class Mock_YDL:
        def __init__(self, config_val):
            self.config = config_val
        def to_screen(self, *args, **kwargs):
            print("Console output: " + str(args))
    class Mock_InfoDict:
        def __init__(self, info_dict):
            self.__dict__.update(info_dict)
    title = 'i-like-dogs-jasonlee'
    info_dic = {'title': title}

# Generated at 2022-06-24 14:18:56.282560
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pass


# Generated at 2022-06-24 14:18:59.125184
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    downloader = object()
    post_processor = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    assert post_processor._titleformat == '%(title)s - %(artist)s'
    assert post_processor._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-24 14:19:10.787446
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .extractor import get_info_extractor
    from .utils import match_filter_func
    from ..compat import compat_urllib_request

    # default string
    titleformat = '%(title)s - %(artist)s'
    titleregex = \
    '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'
    pp = MetadataFromTitlePP(None, titleformat)
    assert pp._titleformat == titleformat
    assert pp.format_to_regex(titleformat) == titleregex
    assert pp._titleregex == titleregex
    # test the default string
    t1 = 'Testvideo - Foo'
    assert re.match(titleregex, t1) is not None

    # special characters

# Generated at 2022-06-24 14:19:15.784449
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    import pytest
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp.format_to_regex('%(title)s - %(artist)s') == \
        '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s - %(album)s') == \
        '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'

# Generated at 2022-06-24 14:19:26.212138
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Test with simple string
    mp = MetadataFromTitlePP('downloader', '%(title)s - %(artist)s')
    assert mp._titleformat == '%(title)s - %(artist)s'
    assert mp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    # Test with string that has no %(...)s
    mp = MetadataFromTitlePP('downloader', 'abc')
    assert mp._titleformat == 'abc'
    assert mp._titleregex == 'abc'

    # Test with string that has %(...)s as escaped %
    mp = MetadataFromTitlePP('downloader', '%%(title)s - %(artist)s')
    assert mp._titleformat == '%%(title)s - %(artist)s'
    assert mp

# Generated at 2022-06-24 14:19:32.689689
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-24 14:19:38.082442
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    format = '%(title)s - %(artist)s'
    regex = r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, format)._titleregex == regex

    format = 'bla bla bla'
    regex = 'bla bla bla'
    assert MetadataFromTitlePP(None, format)._titleregex == regex

    # test different formats

# Generated at 2022-06-24 14:19:46.216487
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    processor = MetadataFromTitlePP(None, None)
    assert (processor.format_to_regex('%(title)s - %(artist)s')
            == r'(?P<title>.+)\ \-\ (?P<artist>.+)')
    assert processor.format_to_regex('abc %(title)s def') == r'abc\ (?P<title>.+)\ def'
    assert processor.format_to_regex('a %(title)s%(title2)s b') == r'a\ (?P<title>.+)(?P<title2>.+)\ b'
    assert processor.format_to_regex('%(title)s') == r'(?P<title>.+)'

# Generated at 2022-06-24 14:19:54.632196
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    DummyDownloader = DummyYDL()
    DummyDownloader.add_info_extractor(DummyIE())

    # Test 1: %(artist)s - %(title)s
    pp = MetadataFromTitlePP(DummyDownloader, '%(artist)s - %(title)s')
    assert pp._titleregex == r'(?P<artist>.+)\ \-\ (?P<title>.+)'

    # Test 2: %(artist)s - %(title)s %(something)s
    pp = MetadataFromTitlePP(DummyDownloader, '%(artist)s - %(title)s %(something)s')
    assert pp._titleregex == r'(?P<artist>.+)\ \-\ (?P<title>.+)\ (?P<something>.+)'

   

# Generated at 2022-06-24 14:20:05.750432
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange

    import xml.etree.ElementTree as ET
    from collections import namedtuple
    from unittest.mock import MagicMock

    info = {'title': 'my title'}


# Generated at 2022-06-24 14:20:13.826089
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    """Unit test for method format_to_regex of class MetadataFromTitlePP"""
    import unittest
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert pp.format_to_regex('%(title)s - %(title)s') == r'(?P<title>.+)\ \-\ (?P<title>.+)'

# Generated at 2022-06-24 14:20:25.072852
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest

    downloader = unittest.mock.Mock()

    def to_screen(text):
        print(text, file=sys.stderr)

    downloader.configure_mock(to_screen=to_screen)
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')

    info = {'title': 'test title - test artist'}
    # test the single output of a sucessful run()
    assert pp.run(info)[1] == {'title': 'test title', 'artist': 'test artist'}

    # test the parsing of multiple occurences of the same attribute
    pp = MetadataFromTitlePP(downloader, '%(artist)s - %(artist)s')

# Generated at 2022-06-24 14:20:35.086406
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .options import opts
    from .downloader import YoutubeDL
    from .compat import compat_str
    ydl = YoutubeDL(opts)
    # Test without %(..)s
    titleformat = '%(title)s - %(artist)s'
    titleregex = '%(title)s\ \-\ %(artist)s'
    mftpp = MetadataFromTitlePP(ydl, titleformat)
    assert mftpp._titleregex == titleregex

    # Test with %(..)s
    titleformat = '%(title)s - %(artist)s'
    titleregex = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    mftpp = MetadataFromTitlePP(ydl, titleformat)
    assert mftpp._titlere

# Generated at 2022-06-24 14:20:40.330087
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(track)s - %(title)s')
    assert pp._titleregex == r'(?P<artist>.+)\ \-\ (?P<track>.+)\ \-\ (?P<title>.+)'
    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleregex == '%\\(title\\)s'


# Generated at 2022-06-24 14:20:44.435724
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    title = 'Caligula - Part 9[HD]'
    titleformat = '%(artist)s - %(title)s[%(format)s]'
    pp = MetadataFromTitlePP(None, titleformat)
    actual_info = pp.run({'title':title})
    expected_info = ({'artist': 'Caligula', 'title': 'Part 9', 'format': 'HD'}, {})
    assert expected_info == actual_info


# Generated at 2022-06-24 14:20:53.431184
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # pylint: disable=line-too-long
    regex = MetadataFromTitlePP(None, '%(title)s - %(artist)s')._titleregex
    assert regex == '(?P<title>.+)\\ -\\ (?P<artist>.+)'
    regex = MetadataFromTitlePP(None, '%(author)s - %(title)s')._titleregex
    assert regex == '(?P<author>.+)\\ -\\ (?P<title>.+)'
    regex = MetadataFromTitlePP(None, '%(title)s')._titleregex
    assert regex == '%\\(title\\)s'
    regex = MetadataFromTitlePP(None, '%(title)s - - %(artist)s')._titleregex