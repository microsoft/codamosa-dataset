

# Generated at 2022-06-24 14:10:58.887334
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp.format_to_regex('%(title)s') == r'(?P<title>.+)'
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    pp = MetadataFromTitlePP(None, 'foo%(title)sbar')
    assert pp.format_to_regex('foo%(title)sbar') == r'foo(?P<title>.+)bar'

# Generated at 2022-06-24 14:11:09.130091
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import YoutubeDL
    pp_before = MetadataFromTitlePP(YoutubeDL(), '%(title)s - %(artist)s')
    pp_after = MetadataFromTitlePP(YoutubeDL(), '%(title)s - %(artist)s')
    pp_no_match = MetadataFromTitlePP(YoutubeDL(), '%(title)s')
    assert pp_before.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\\ \\\-\\ (?P<artist>.+)'
    assert pp_after.format_to_regex('%(artist)s - %(title)s') == '(?P<artist>.+)\\ \\\-\\ (?P<title>.+)'
    assert pp_no_match.format_to_regex

# Generated at 2022-06-24 14:11:20.110457
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import dict_representation as dictrepr
    from youtube_dl.compat import compat_str

    def test_format(titleformat, title, expected_dict):
        # Build the test
        ydl = YoutubeDL()
        ydl.add_post_processor(MetadataFromTitlePP(ydl, titleformat))
        ydl.add_default_info_extractors()

        # Run the test
        info = {'title': compat_str(title)}
        expected_info = info.copy()
        expected_info.update(expected_dict)
        results, info = ydl.extract_info(None, download=False, process=False, extra_info={'title': title})
        assert expected_info == info


# Generated at 2022-06-24 14:11:24.532594
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    expected = r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    actual = pp.format_to_regex('%(title)s - %(artist)s')
    assert actual == expected, actual

# Generated at 2022-06-24 14:11:35.936569
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    Unit test for method run of class MetadataFromTitlePP
    """
    import sys
    import unittest
    import types

    class MetadataFromTitlePP_run_TestCase(unittest.TestCase):
        def setUp(self):
            from youtube_dl import YoutubeDL
            from youtube_dl.postprocessor import MetadataFromTitlePP
            self.metadataFromTitlePP = MetadataFromTitlePP(YoutubeDL(),
                    '%(title)s - %(artist)s - %(album)s')

        def test_nonmatching_title_should_return_info_unchanged(self):
            info = {'title': 'abcde'}
            result, info = self.metadataFromTitlePP.run(info)
            self.assertEqual(info, {'title': 'abcde'})

       

# Generated at 2022-06-24 14:11:39.096355
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    m = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert m._titleformat == '%(title)s - %(artist)s'
    assert m._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'



# Generated at 2022-06-24 14:11:45.893249
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    Test the run method of this class.
    Return True if the test case passed, False otherwise.
    """
    # Import modules needed for this test
    import sys
    if sys.version_info >= (3, 0):
        # Python 3 code in this block
        from io import StringIO
    else:
        # Python 2 code in this block
        from StringIO import StringIO

    # Mock the downloader class
    class MockYoutubeDL(object):

        """Mock the downloader class"""

        def to_screen(self, msg):
            """Mock the to_screen method of youtube_dl.YoutubeDL()"""

            print(msg)

    # Mock the info dict of the file to be downloaded
    info = {'title': 'Title - Artist'}

    # Create an instance of the postprocessor

# Generated at 2022-06-24 14:11:51.319431
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    mft = MetadataFromTitlePP(ydl, '%(track)s')

    assert mft._titleformat == '%(track)s'
    assert mft._titleregex == '(?P<track>.+)'

    # Test format_to_regex
    assert mft.format_to_regex('%(track)s, %(artist)s') == '(?P<track>.+), (?P<artist>.+)'
    assert mft.format_to_regex('mytitle') == 'mytitle'



# Generated at 2022-06-24 14:12:01.321128
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL

    def _test_metadata_from_title(title, titleformat, attr_dict):
        class FakeYDL:
            def __init__(self, attr_dict):
                self.info = attr_dict
                self.to_screen_called = False

            def to_screen(self, msg):
                self.to_screen_called = True

        ydl = FakeYDL(attr_dict)
        pp = MetadataFromTitlePP(ydl, titleformat)
        _, res = pp.run({'title': title})
        return ydl.to_screen_called, res


# Generated at 2022-06-24 14:12:07.893241
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from_title = MetadataFromTitlePP(None, None)
    r = from_title.format_to_regex('%(title)s-by-%(artist)s')
    assert re.match(r, 'abc-by-def').group('title') == 'abc'
    assert re.match(r, 'abc-by-def').group('artist') == 'def'
    assert re.match(r, 'abc-by-def-ghi').group('artist') == 'def-ghi'

# Generated at 2022-06-24 14:12:11.239947
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.YoutubeDL import YoutubeDL
    titleformat = '%(title)s - %(artist)s'
    titleregex = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    pp = MetadataFromTitlePP(YoutubeDL(), titleformat)
    assert pp._titleformat == titleformat
    assert pp._titleregex == titleregex

# Unit tests for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-24 14:12:22.089499
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    fttrpp = MetadataFromTitlePP(None, '')
    assert fttrpp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert fttrpp.format_to_regex('%(artist)s - %(album)s') == '(?P<artist>.+)\ \-\ (?P<album>.+)'
    assert fttrpp.format_to_regex('(%(artist)s)') == '\((?P<artist>.+)\)'
    assert fttrpp.format_to_regex('%(artist)s') == '(?P<artist>.+)'

# Generated at 2022-06-24 14:12:27.184327
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from_title = MetadataFromTitlePP(None, None)
    assert from_title.format_to_regex('%(title)s - %(artist)s') == \
        '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert from_title.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert from_title.format_to_regex('%(title)s - blabla') == \
        '(?P<title>.+)\ \-\ blabla'
    assert from_title.format_to_regex('blabla - %(title)s') == \
        'blabla\ \-\ (?P<title>.+)'

# Generated at 2022-06-24 14:12:36.982472
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.utils import DateRange

    dl = MockYoutubeDL({
        'simulate': True,
        'quiet': True,
        'skip_download': True,
        'simulate': True,
        'writethumbnail': True,
        'writeautomaticsub': True,
        'writeinfojson': True,
        'skip_download': True,
        'continuedl': True,
        'logger': MockLogger(),
        'outtmpl': '%(title)s.%(ext)s',
    })
    dl.params['writedescription'] = True
    dl.to_screen = lambda s: None
    # Create a MetadataFromTitlePP instance
    pp = MetadataFromTitlePP(dl, '%(title)s - %(artist)s')
    assert pp._

# Generated at 2022-06-24 14:12:45.814359
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    if sys.version_info >= (3, 0):
        from unittest.mock import MagicMock
    else:
        from mock import MagicMock

    def _mock_get_filenames():
        return ['Talk:2014_WikiConference_North_America-quotes.ogv']

    info = { 'title': 'Talk:2014_WikiConference_North_America-quotes.ogv' }

    video_url = 'http://upload.wikimedia.org/wikipedia/commons/' + info['title']

    ytdl = MagicMock()
    ytdl.params = {'quiet': True, 'noplaylist': True}
    ytdl.get_filenames = _mock_get_filenames

# Generated at 2022-06-24 14:12:56.025532
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # This class has no __init__ method, thus we call object.__init__
    # directly.
    pp = MetadataFromTitlePP.__new__(MetadataFromTitlePP)
    pp.run = MetadataFromTitlePP.run
    pp._downloader = object()
    pp._titleformat = '%(title)s - %(artist)s'
    pp._titleregex = r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    # Should match the title and split the data into expected fields
    info = {'title': 'Artist - Song Title'}
    files, meta = pp.run(info)
    assert files == []
    assert meta['title'] == 'Song Title'
    assert meta['artist'] == 'Artist'

    # Should raise an exception if the regex can't be compiled

# Generated at 2022-06-24 14:13:04.829815
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    downloader = object
    titleformat = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(downloader, titleformat)

    # Case1: Success: parse metadata
    title = 'my song - my artist'
    info = {'title': title}
    result, info = pp.run(info)
    assert info['title'] == 'my song'
    assert info['artist'] == 'my artist'

    # Case2: Failure: do not parse metadata
    title = 'my song'
    info = {'title': title}
    result, info = pp.run(info)
    assert info['title'] == 'my song'
    assert 'artist' not in info

    # Case3: Mixed success: parse metadata

# Generated at 2022-06-24 14:13:14.618745
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    test_strings = [('%(title)s', r'(?P<title>.+)'),
                    ('%(title)s - %(artist)s', r'(?P<title>.+)\ \-\ (?P<artist>.+)'),
                    ('test %(title)s test', r'test\ (?P<title>.+)\ test'),
                    ('[Special]%(title)s-%(artist)s', r'\[Special\](?P<title>.+)\-(?P<artist>.+)'),
                    ('%(title)s', r'(?P<title>.+)')]
    fmt_pp = MetadataFromTitlePP(object, '%(title)s')

# Generated at 2022-06-24 14:13:21.294153
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl
    metadata_from_title = MetadataFromTitlePP(None, 'Test - %(artist)s - %(song)s')
    assert metadata_from_title._titleregex == 'Test\ \-\ (?P<artist>.+)\ \-\ (?P<song>.+)'
    info = {'title': 'Test - Artist - Song'}
    assert metadata_from_title.run(info) == ([], {'title': 'Test - Artist - Song', 'artist': 'Artist', 'song': 'Song'})



# Generated at 2022-06-24 14:13:28.680302
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import YoutubeDL

    titleformat = '%(title)s - %(artist)s'
    ydl = YoutubeDL({})
    pp = MetadataFromTitlePP(ydl, titleformat)
    regex = pp.format_to_regex(titleformat)
    match = re.match(regex, 'Title - Artist', re.DOTALL)
    assert match is not None
    assert 'title' in match.groupdict()
    assert match.groupdict()['title'] == 'Title'
    assert 'artist' in match.groupdict()
    assert match.groupdict()['artist'] == 'Artist'

# Generated at 2022-06-24 14:13:31.873590
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(title)s')
    res = pp.format_to_regex('%(title)s')
    assert res == r'(?P<title>.+)'

    pp = MetadataFromTitlePP(None, '%(a)s - %(b)s')
    res = pp.format_to_regex('%(a)s - %(b)s')
    assert res == r'(?P<a>.+)\ \-\ (?P<b>.+)'


# Generated at 2022-06-24 14:13:41.701572
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from ..YoutubeDL import YoutubeDL
    ytdl = YoutubeDL()
    assert(MetadataFromTitlePP(ytdl, '%(title)s - %(artist)s') is not None)
    assert(MetadataFromTitlePP(ytdl, '%(title)s') is not None)
    assert(MetadataFromTitlePP(ytdl, '%(artist)s') is not None)
    assert(MetadataFromTitlePP(ytdl, '%(artist)s - %(title)s') is not None)
    assert(MetadataFromTitlePP(ytdl,
                               '%(a)s - %(b)s - %(c)s - %(d)s - %(e)s') is not None)

# Generated at 2022-06-24 14:13:48.777169
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest
    import sys
    import youtube_dl

    class MockDownloader(object):
        @staticmethod
        def to_screen(message):
            sys.stdout.write(message + '\n')

    class TestMetadataFromTitlePP(unittest.TestCase):
        def test_OK(self):
            input = {'title': 'A - B - C - D'}
            output = {'title': 'A - B - C - D',
                      'artist': 'A',
                      'album': 'B',
                      'track': 'C',
                      'ext': 'D'}
            titleformat = '%(artist)s - %(album)s - %(track)s - %(ext)s'
            pp = MetadataFromTitlePP(MockDownloader(), titleformat)

# Generated at 2022-06-24 14:13:59.997520
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class Downloader(object):
        def to_screen(self, msg):
            print(msg)

    class Info(dict):
        pass

    titleformat = '%(title)s - %(artist)s - %(track)s'
    title = 'Fall down - will.i.am - track 13'
    info = Info({'title': title})
    downloader = Downloader()
    pp = MetadataFromTitlePP(downloader, titleformat)
    pp.run(info)

    titleformat = '%(part)s.%(ext)s'
    title = '4.mp4'
    info = Info({'title': title})
    downloader = Downloader()
    pp = MetadataFromTitlePP(downloader, titleformat)
    pp.run(info)


# Generated at 2022-06-24 14:14:11.548220
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Video title structure
    #   - video_title - video_title2 / video_artist
    title_format = '%(title)s - %(title2)s / %(artist)s'
    # Regex to get the title data from the video title
    #   - Full regex with all groups:
    #       (?P<title>.+)\ \-\ (?P<title2>.+)\ \/\ (?P<artist>.+)
    #   - Regex without the unused groups:
    #       (?P<title>.+)
    title_regex = '%(title)s'
    # Video title to parse (with unicode chars)
    video_title = 'The video title - The video title 2 / The video artist'
    # Creating the instance of class MetadataFromTitlePP
    downloader = None
    pp

# Generated at 2022-06-24 14:14:21.784618
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import collections
    import unittest.mock as mock

    test_info = collections.OrderedDict([
        ('title', 'title'),
        ('description', 'description'),
        ('url', 'url'),
        ('upload_date', 'upload_date'),
        ('uploader', 'uploader'),
        ('uploader_id', 'uploader_id'),
        ('uploader_url', 'uploader_url'),
        ('location', 'location'),
        ('categories', 'categories'),
        ('tags', 'tags'),
        ('album', 'album'),
        ('artist', 'artist'),
        ('track', 'track'),
        ('disc', 'disc'),
        ('release_year', 'release_year'),
    ])
    info = collections.OrderedDict(test_info)
    downloader = mock.Mock()

# Generated at 2022-06-24 14:14:30.392473
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import FileDownloader
    from .extractor.common import InfoExtractor

    class TestExtractor(InfoExtractor):
        _VALID_URL = ''
        _TEST = {
            'title': 'foo - bar',
            'info_dict': {}
        }

        def _real_extract(self, url):
            return self._TEST

    # Test with a format string containing no %(..)s
    postprocessor = MetadataFromTitlePP(FileDownloader({}), 'title')
    assert postprocessor._titleregex == 'title'
    assert postprocessor.format_to_regex('title') == 'title'

    # Test with an empty format string
    postprocessor = MetadataFromTitlePP(FileDownloader({}), '')
    assert postprocessor._titleregex == ''
    assert postprocessor

# Generated at 2022-06-24 14:14:35.399767
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    format = '%(artist)s - %(title)s%(ext)s'
    input = 'Artist - Title.mp4'
    pp = MetadataFromTitlePP(None, format)
    actual = pp.run({'title': input})[1]
    expected = {'artist': 'Artist', 'title': 'Title', 'ext': '.mp4' }
    assert actual == expected


# Generated at 2022-06-24 14:14:38.967768
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    info = {'title': 'author - title'}
    actual = pp.run(info)
    expected = ([], {'artist': 'author', 'title': 'title'})
    assert actual == expected


# Generated at 2022-06-24 14:14:45.048628
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    test = MetadataFromTitlePP('youtube-dl', '%(title)s - %(artist)s')
    test_a = MetadataFromTitlePP('youtube-dl', '%(title)s')
    test_b = MetadataFromTitlePP('youtube-dl', '%(artist)s')
    test_c = MetadataFromTitlePP('youtube-dl', '%(title)s - %(artist)s - %(album)s')

    assert test._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert test_a._titleregex == '(?P<title>.+)'
    assert test_b._titleregex == '(?P<artist>.+)'

# Generated at 2022-06-24 14:14:51.727098
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    fmt = '%(title)s - %(artist)s'
    regex = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, fmt).format_to_regex(fmt) == regex

    fmt = 'my title - %(artist)s'
    regex = r'my\ title\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, fmt).format_to_regex(fmt) == regex

# Generated at 2022-06-24 14:14:58.372382
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    '''
    Unit test for MetadataFromTitlePP.__init__
    '''
    pp = MetadataFromTitlePP(None, '%(artist)s - %(track)s')
    assert pp._titleformat == '%(artist)s - %(track)s'
    assert pp._titleregex == '(?P<artist>.+)\ \-\ (?P<track>.+)'
    pp = MetadataFromTitlePP(None, '%(artist)s')
    assert pp._titleformat == '%(artist)s'
    assert pp._titleregex == '(?P<artist>.+)'
    pp = MetadataFromTitlePP(None, '%(artist)s - %(track)s - %(year)d')

# Generated at 2022-06-24 14:15:08.364495
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from sys import version_info
    from io import BytesIO
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.FileDownloader import FileDownloader
    from youtube_dl.utils import _background_worker_Thread
    _background_worker_Thread._setup_threading()
    ydl = YoutubeDL({'outtmpl': '/dev/null', 'quiet': True, 'progress_hooks': []})
    ydl.add_default_info_extractors()
    fd = FileDownloader(ydl, {'url': 'foobar', 'title': 'foo - bar - baz'})
    pp = MetadataFromTitlePP(ydl, '%(artist)s - %(title)s - %(album)s')
    info = fd._prepare_info({})

# Generated at 2022-06-24 14:15:14.187527
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import unittest.mock

    mp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert r'(?P<title>.+)\ \-\ (?P<artist>.+)' == mp._titleregex
    mp = MetadataFromTitlePP(None, '%(title)s-%(artist)s')
    assert r'(?P<title>.+)\-(?P<artist>.+)' == mp._titleregex

# Generated at 2022-06-24 14:15:17.551712
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftpp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert mftpp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-24 14:15:18.866579
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert MetadataFromTitlePP(None, None).run(None) == ([], None), "Test failed"

# Generated at 2022-06-24 14:15:30.105135
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .ytdl_url import YoutubeDL
    from .utils import match_filter_func

    dl = YoutubeDL()
    dl.add_info_extractor(None)
    pp = MetadataFromTitlePP(dl,
            r'%(upload_date)s'
            r'-%(uploader_id)s'
            r'-%(id)s'
            r'-%(title)s'
            r'__%(uploader)s')
    info = {
        'title': '2017-10-06-ABCDEFGHIJK___foo',
    }
    pp.run(info)

# Generated at 2022-06-24 14:15:38.288759
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    def helper(titleformat, expected_titleregex):
        pp = MetadataFromTitlePP(None, titleformat)
        assert pp._titleformat == titleformat
        assert pp._titleregex == expected_titleregex

    # test regex
    helper('%(title)s - %(artist)s', r'(?P<title>.+)\ \-\ (?P<artist>.+)')
    # test regex with escaped chars
    helper(r'%(title)s \- %(artist)s', r'(?P<title>.+)\\\ \-\ (?P<artist>.+)')
    # test fixed string
    helper('fixed string', 'fixed string')


# Generated at 2022-06-24 14:15:48.843032
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    p = MetadataFromTitlePP({}, '%(artist)s - %(title)s')
    assert p._titleformat == '%(artist)s - %(title)s'
    assert p._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'
    p = MetadataFromTitlePP({}, '(?P<artist>.+)\ \-\ (?P<title>.+)')
    assert p._titleformat == '(?P<artist>.+)\ \-\ (?P<title>.+)'
    assert p._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'


# Generated at 2022-06-24 14:15:56.103743
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import unittest

    class TestMetadataFromTitlePP(unittest.TestCase):
        def test_convert_format_to_regex(self):
            self.assertEqual(
                MetadataFromTitlePP(None, '%(title)s - %(artist)s')._titleregex,
                '(?P<title>.+)\ \-\ (?P<artist>.+)'
            )

    unittest.main()

if __name__ == '__main__':
    test_MetadataFromTitlePP()

# Generated at 2022-06-24 14:16:06.972263
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # simple case, no %(..)s
    title = 'Foo'
    metadata = {'title': title}
    mpp = MetadataFromTitlePP(None, title)
    # unittest runs on Python 2.6
    assert hasattr(mpp, '_titleformat')
    assert hasattr(mpp, '_titleregex')
    assert mpp._titleformat == title
    assert mpp._titleregex == title
    assert mpp.run(metadata) == ([], metadata)

    # %(..)s case
    title = '%(artist)s - (%(album)s) - %(title)s'
    metadata = {'title': 'Foo - (Bar) - Baz'}
    mpp = MetadataFromTitlePP(None, title)
    assert mpp._titleformat == title


# Generated at 2022-06-24 14:16:11.492708
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # test that a string without VARS is unchanged
    assert MetadataFromTitlePP._format_to_regex('string without vars') == 'string without vars'
    # test that a string with a single VAR is converted properly
    assert MetadataFromTitlePP._format_to_regex('a string with a %(var)s') == 'a string with a (?P<var>.+)'
    # test that a string with a two VARS is converted properly
    assert MetadataFromTitlePP._format_to_regex('a string with a %(var)s and a %(another_var)s') == 'a string with a (?P<var>.+) and a (?P<another_var>.+)'
    # test that a string with a random VAR is converted properly
    assert MetadataFromTitlePP._format_to_regex

# Generated at 2022-06-24 14:16:19.297714
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor import gen_extractors

    def title_info(videoname):
        dl = FileDownloader({})
        dl.add_info_extractor(gen_extractors()[0](dl))
        i = {'title': videoname}
        i = PostProcessor(dl).run(i)[1]
        return i


# Generated at 2022-06-24 14:16:27.672741
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    pp = MetadataFromTitlePP(ydl, '%(artist)s - %(title)s')
    info = {}
    assert pp.run(info) == ([], {'title': 'NA', 'artist': 'NA'})
    info = dict(title='Artist - Title')
    assert pp.run(info) == (
        [], {'title': 'Artist - Title', 'artist': 'Artist'})
    assert pp.run(
        dict(title='Artist - Title', artist='')) == (
            [], {'title': 'Artist - Title', 'artist': 'Artist'})

# Generated at 2022-06-24 14:16:35.610557
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .downloader import FileDownloader
    from .extractor import YoutubeIE
    from .utils import sanitize_open

    def _fake_sanitize_open(spec):
        assert spec['ie_key'] == YoutubeIE.ie_key()
        assert spec['outtmpl'] == '%(title)s.%(ext)s'
        assert spec['noplaylist'] is True
        return sanitize_open(spec)

    url = 'https://www.youtube.com/watch?v=0Bmhjf0rKe8'
    titleformat = '%(artist)s-%(title)s'
    postproc = MetadataFromTitlePP(None, titleformat)
    with postproc:
        fd = FileDownloader({'noplaylist': True})

# Generated at 2022-06-24 14:16:45.309417
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    m = MetadataFromTitlePP(None, '%(title)s')
    if m._titleregex != r'(?P<title>.+)':
        raise ValueError('test 1')
    m = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    if m._titleregex != r'(?P<title>.+)\ \-\ (?P<artist>.+)':
        raise ValueError('test 2')
    m = MetadataFromTitlePP(None, 'foo')
    if m._titleregex != r'foo':
        raise ValueError('test 3')
    m = MetadataFromTitlePP(None, r'\w+')
    if m._titleregex != r'\w+':
        raise ValueError('test 4')


# Generated at 2022-06-24 14:16:49.627625
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    M = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert M.run({'title': 'title - artist'}) == ([], {'title': 'title - artist', 'artist': 'artist'})


# Generated at 2022-06-24 14:16:55.442325
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    assert pp.format_to_regex(
        'a') == 'a'
    assert pp.format_to_regex(
        '%(title)s') == '(?P<title>.+)'
    assert pp.format_to_regex(
        '%(title)s - %(name)s') == '(?P<title>.+)\ \-\ (?P<name>.+)'

# Generated at 2022-06-24 14:17:00.178435
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    assert MetadataFromTitlePP(
        None, '%(title)s - %(artist)s')._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, 'title %(title)s')._titleregex == r'title\ \%\(title\)s'


# Generated at 2022-06-24 14:17:09.728155
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Setup
    from ..YoutubeDL import YoutubeDL
    class FakeInfo(dict):
        def __init__(self, *args, **kwargs):
            self.update(*args, **kwargs)
    downloader = YoutubeDL()
    downloader.to_screen = lambda x: None
    metaPP = MetadataFromTitlePP(downloader,
                                 '%(title)s - %(artist)s')
    info = FakeInfo({'title': 'Only My Railgun - fripSide'})

    # Test
    metaPP.run(info)

    # Validation
    assert 'title' in info and info['title'] == 'Only My Railgun'
    assert 'artist' in info and info['artist'] == 'fripSide'



# Generated at 2022-06-24 14:17:17.887350
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    Test the run method of MetadataFromTitlePP
    """
    # Return a test object of class MetadataFromTitlePP
    def new_MetadataFromTitlePP(titleformat, title):
        """
        Return a new test object of class MetadataFromTitlePP
        """
        class TestDownloader(object):
            def to_screen(self, text):
                pass

        test_downloader = TestDownloader()
        test_metadatafromtitle = MetadataFromTitlePP(
            downloader=test_downloader, titleformat=titleformat)
        info = {'title': title}
        return test_metadatafromtitle, info

    # Test if method run of MetadataFromTitlePP
    # returns a list of warnings and a dictionary of metadata

    # Return a dictionary with the expected meta data

# Generated at 2022-06-24 14:17:27.564678
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-24 14:17:38.634039
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl import YoutubeDL
    from youtube_dl.YoutubeDL import YoutubeDL as YoutubeDLAlias
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.utils import DateRange
    postprocessors = [MetadataFromTitlePP(YoutubeDLAlias(), '%(title)s'), FFmpegMetadataPP(YoutubeDLAlias())]

# Generated at 2022-06-24 14:17:45.446464
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    m = MetadataFromTitlePP(
        downloader=None,
        titleformat='%(title)s - %(artist)s')

    expected_regex = r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert m._titleregex == expected_regex

    info = {'title': 'WiseUp - Aimee Mann'}
    expected_info = {'title': 'WiseUp', 'artist': 'Aimee Mann'}

    assert m.run(info)[1] == expected_info

# Generated at 2022-06-24 14:17:52.529368
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    desc = (
        'Test for constructor of class MetadataFromTitlePP.'
        ' The constructor should correctly convert title format to a regex'
        ' and create a regex from this format. This regex should be used to'
        ' parse the title and extract metadata.'
    )
    expected_metadata = {'fld1': 'val1', 'fld2': 'val2', 'fld3': 'val3'}

    def dummy_downloader(info):
        assert info == expected_metadata

    format = '%(fld1)s - %(fld2)s %(fld3)s'
    regex = r'(?P<fld1>.+)\ \-\ (?P<fld2>.+)\ (?P<fld3>.+)'

# Generated at 2022-06-24 14:18:00.194676
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .compat import compat_urllib_parse_unquote
    from .downloader import FakeYDL
    ydl = FakeYDL()

    # Test without regex
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    info = {
        'title': 'TITLE - ARTIST - ALBUM'
    }
    metadata, new_info = pp.run(info)
    assert metadata == []
    assert new_info['title'] == 'TITLE - ARTIST - ALBUM'
    assert new_info['artist'] == 'ARTIST'

    # Test with regex
    pp = MetadataFromTitlePP(ydl, 'foo%(bar)s')
    info = {
        'title': 'fooBAR'
    }

# Generated at 2022-06-24 14:18:05.572283
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    Tests if in the run function of MetadataFromTitlePP the format is
    correctly interpreted.
    """
    print('Test MetadataFromTitlePP.run()')
    # No test for a working downloader, since it is mokey patched
    title = ('File name for a 2014-02-12 Matchday with a - '
             'Test info for a 2014-02-12 Matchday')
    info = {'title': title}

    # full test with two attributes
    titleformat = '%(date)s Matchday with a - %(desc)s'
    regex = '^(?P<date>\d\d\d\d\-\d\d\-\d\d) Matchday with a - ' \
            '(?P<desc>.+)$'
    pp = MetadataFromTitlePP(None, titleformat)



# Generated at 2022-06-24 14:18:10.714611
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None,
        '%(genre)s - %(artist)s - %(title)s').format_to_regex(
            '%(genre)s - %(artist)s - %(title)s') == \
            '(?P<genre>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<title>.+)'


# Generated at 2022-06-24 14:18:19.775629
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(object(), '%(title)s - %(artist)s')
    assert pp._titleregex == '(?P<title>.+) - (?P<artist>.+)'
    pp = MetadataFromTitlePP(object(), '%(title)s')
    assert pp._titleregex == '(?P<title>.+)'
    pp = MetadataFromTitlePP(object(), '%(title)s - %(artist)s - %(album)s')
    assert pp._titleregex == '(?P<title>.+) - (?P<artist>.+) - (?P<album>.+)'
    pp = MetadataFromTitlePP(object(), '%(title)s - %(artist)s - %(album)s - %(year)s')

# Generated at 2022-06-24 14:18:29.166965
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    from io import StringIO

    class TestMetadataFromTitlePP_run(unittest.TestCase):

        def setUp(self):
            self.out = StringIO()
            self.saved_stdout = sys.stdout
            sys.stdout = self.out

        def tearDown(self):
            self.out.close()
            sys.stdout = self.saved_stdout

        def test_metadata_from_title_pp_run(self):
            # See https://github.com/rg3/youtube-dl/issues/6769
            titleformat = '%(uploader)s - %(title)s'
            title = 'Test - Test'
            info = {'title': title}

# Generated at 2022-06-24 14:18:35.548178
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import FileDownloader
    pp = MetadataFromTitlePP(FileDownloader({}), '')

# Generated at 2022-06-24 14:18:45.042943
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    titleformat = '%(title)s'
    obj = MetadataFromTitlePP(None, titleformat)
    assert obj._titleformat == titleformat
    assert obj._titleregex == r'(?P<title>.+)'

    titleformat = '%(title)s - %(artist)s'
    obj = MetadataFromTitlePP(None, titleformat)
    assert obj._titleformat == titleformat
    assert obj._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    titleformat = '%(title)s - %(artist)s - %(album)s - %(year)s'
    obj = MetadataFromTitlePP(None, titleformat)
    assert obj._titleformat == titleformat

# Generated at 2022-06-24 14:18:54.304027
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    assert MetadataFromTitlePP(None, '')._titleformat == ''
    assert MetadataFromTitlePP(None, '')._titleregex == ''
    assert MetadataFromTitlePP(None, '%(title)s')._titleformat == '%(title)s'
    assert MetadataFromTitlePP(None, '%(title)s')._titleregex == '(?P<title>.+)'
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s')._titleformat == '%(title)s - %(artist)s'
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s')._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-24 14:19:01.311779
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP('dummy', '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    pp = MetadataFromTitlePP('dummy', '%(title)s_%(artist)s')
    assert pp._titleformat == '%(title)s_%(artist)s'
    assert pp._titleregex == '(?P<title>.+)\_(?P<artist>.+)'
    pp = MetadataFromTitlePP('dummy', '%(title)s - %(artist)s - %(album)s')

# Generated at 2022-06-24 14:19:11.618283
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP('downloader', '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'

    pp = MetadataFromTitlePP('downloader', '%(title)s - %(artist)s - %(album)s')
    assert pp._titleformat == '%(title)s - %(artist)s - %(album)s'
    assert pp._titleregex == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)\\ \\-\\ (?P<album>.+)'


# Generated at 2022-06-24 14:19:13.973366
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    x = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert x._titleformat == '%(title)s - %(artist)s'
    assert x._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-24 14:19:16.573951
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp is not None
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-24 14:19:21.549237
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    titleformat = '%(title)s - %(artist)s'
    expected = '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'
    actual = MetadataFromTitlePP.format_to_regex(titleformat)
    assert expected == actual

# Generated at 2022-06-24 14:19:29.180015
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    converter = MetadataFromTitlePP(None, '')
    assert converter.format_to_regex('') == ''
    assert converter.format_to_regex('asdf') == 'asdf'
    assert converter.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert converter.format_to_regex('%(title)s%%') == '(?P<title>.+)%'
    assert converter.format_to_regex('%%%(title)s') == '%(?P<title>.+)'

# Generated at 2022-06-24 14:19:37.054910
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftpp = MetadataFromTitlePP(None, 'whatever')

    # Test common cases
    assert mftpp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert mftpp.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert mftpp.format_to_regex('%(title)s%(artist)s') == r'(?P<title>.+)(?P<artist>.+)'
    assert mftpp.format_to_regex('%(title)s%(artist)s%(title)s') == r'(?P<title>.+)(?P<artist>.+)(?P<title>.+)'

# Generated at 2022-06-24 14:19:45.677490
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    downloader = YoutubeDL()
    downloader.add_post_processor(MetadataFromTitlePP(downloader, '%(title)s'))
    assert downloader.post_processors[0].run(
        {'title': 'TEST'})[1] == {'title': 'TEST'}
    downloader.add_post_processor(MetadataFromTitlePP(downloader, '%(artist)s - %(title)s'))
    assert downloader.post_processors[1].run(
        {'title': 'TEST'})[1] == {'artist': None, 'title': 'TEST'}

# Generated at 2022-06-24 14:19:54.219494
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.__main__ import YoutubeDL

    downloader = YoutubeDL({})

    pp = MetadataFromTitlePP(downloader, '%(artist)s - %(title)s')
    assert pp.run({'title': 'foo - foo'}) == ([], {'artist': 'foo', 'title': 'foo'})
    assert pp.run({'title': 'foo - '}) == ([], {'artist': 'foo', 'title': 'foo - '})
    assert pp.run({'title': 'foo -'}) == ([], {'artist': 'foo', 'title': 'foo -'})
    assert pp.run({'title': 'foo - bar - foo'}) == ([], {'artist': 'foo', 'title': 'foo - bar - foo'})


# Generated at 2022-06-24 14:20:05.078927
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest
    import shutil
    import sys
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.infoextractors.generic import URLIE
    from youtube_dl.utils import DateRange

    # Create a dummy class for YoutubeDL
    class MyYoutubeDL(YoutubeDL):
        def to_screen(self, msg):
            pass
        @staticmethod
        def format_resolution(res):
            return res
    # Create dummy url list
    url1 = 'http://url1.com/video.html'
    url2 = 'http://url2.com/video.html'
    # Create a dummy class for PostProcessor
    class MyPostProcessor(MetadataFromTitlePP):
        def __init__(self, downloader, titleformat):
            self._downloader = downloader


# Generated at 2022-06-24 14:20:13.347121
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-24 14:20:24.526693
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class FakeDict:
        def __init__(self):
            self.d = {}
            self.m = ""
        def __getitem__(self, key): return self.d[key]
        def __setitem__(self, key, value): self.d[key] = value
        def to_screen(self, msg): self.m += msg + "\n"
    p = MetadataFromTitlePP(FakeDict(), "%(title)s - %(artist)s")
    info = {"title": "I - You"}
    p.run(info)
    assert p._downloader.m == "[fromtitle] parsed title: I\n[fromtitle] parsed artist: You\n"
    assert info == {"title": "I - You", "artist": "You"}
    p._downloader.m = ""
    info

# Generated at 2022-06-24 14:20:34.829586
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(group1)s - %(group2)s')
    assert pp.format_to_regex('%(group1)s - %(group2)s') == r'(?P<group1>.+)\ \-\ (?P<group2>.+)'
    assert pp.format_to_regex('%(group1)s - %(group2)s - %(group3)s') == r'(?P<group1>.+)\ \-\ (?P<group2>.+)\ \-\ (?P<group3>.+)'

# Generated at 2022-06-24 14:20:40.548401
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # test with no %(..)s in fmt
    titleformat = 'hoge'
    pp = MetadataFromTitlePP(None, titleformat)
    assert pp.format_to_regex(titleformat) == titleformat

    # test with %(..)s in fmt
    titleformat = '%(artist)s - %(title)s'
    pp = MetadataFromTitlePP(None, titleformat)
    regex = pp.format_to_regex(titleformat)
    assert re.match(regex, 'hoge - fuga').groupdict() == {'artist': 'hoge', 'title': 'fuga'}

# Generated at 2022-06-24 14:20:50.331444
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    m = MetadataFromTitlePP([], "%(id)s")
    assert m._titleformat == '%(id)s'
    assert m._titleregex == '(?P<id>.+)'

    m = MetadataFromTitlePP([], "%(id)s - %(title)s")
    assert m._titleformat == '%(id)s - %(title)s'
    assert m._titleregex == '(?P<id>.+)\ \-\ (?P<title>.+)'

    m = MetadataFromTitlePP([], "%(id)s & %(uploader)s: %(title)s")
    assert m._titleformat == '%(id)s & %(uploader)s: %(title)s'

# Generated at 2022-06-24 14:20:59.962534
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class MockDownloader():
        to_screen_count = 0
        def to_screen(self, message):
            if message.startswith('[fromtitle] parsed'):
                self.to_screen_count += 1

    title = 'Foo - Bar - Qux'
    fmt = '%(title)s - %(artist)s - %(song)s'

    mock_downloader = MockDownloader()
    post_processor = MetadataFromTitlePP(mock_downloader, fmt)

    info = {'title': title}
    _, info = post_processor.run(info)

    assert info['title'] == 'Foo'
    assert info['artist'] == 'Bar'
    assert info['song'] == 'Qux'
    assert mock_downloader.to_screen_count == 3
