

# Generated at 2022-06-24 14:10:59.266446
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import os
    import shutil
    import tempfile
    import youtube_dl

    def fake_downloader(ydl):
        return ydl

    outtmpl = '%(title)s-%(artist)s-%(album)s'
    tmp_dir = tempfile.mkdtemp(prefix='%s-' % __name__)
    tmp_file = os.path.join(tmp_dir, '%(id)s.%(ext)s')

# Generated at 2022-06-24 14:11:09.200379
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test MetadataFromTitlePP
    class FakeInfo():
        def __init__(self):
            self.__dict__['title'] = 'title_video - artist_video'
            self.__init__()

    class FakeYoutubeDL():
        def __init__(self):
            self.to_screen = print

    fake_youtube_dl = FakeYoutubeDL()
    metadata_pp = MetadataFromTitlePP(fake_youtube_dl, '%(title)s - %(artist)s')
    fake_info = FakeInfo()
    (new_info, new_downloaded) = metadata_pp.run(fake_info)

    assert fake_info['title'] == 'title_video - artist_video'
    assert fake_info['artist'] == 'artist_video'
    assert new_info == []
    assert new

# Generated at 2022-06-24 14:11:20.159401
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test simple matching format
    test_title = 'title'
    test_titleformat = '%(title)s'
    assert MetadataFromTitlePP(None, test_titleformat).run({'title': test_title})[1] == {'title': test_title}
    # Test simple matching format with additional text
    test_titleformat = 'Prefix %(title)s'
    assert MetadataFromTitlePP(None, test_titleformat).run({'title': test_title})[1] == {'title': 'title'}
    # Test simple matching format with alternative additional text
    test_titleformat = 'Prefix %(title)s Other'
    assert MetadataFromTitlePP(None, test_titleformat).run({'title': test_title})[1] == {'title': 'title'}
    # Test simple

# Generated at 2022-06-24 14:11:23.687125
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    PP = MetadataFromTitlePP(
        lambda s: None, '%(title)s - %(artist)s')
    assert PP._titleregex == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'


# Generated at 2022-06-24 14:11:35.222608
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # Define metadata and output strings
    titleformat = '%(artist)s - %(track)s - %(title)s.%(ext)s'
    regex = '^(?P<artist>.+)\\ -\\ (?P<track>.+)\\ -\\ (?P<title>.+)\\.(?P<ext>.+)$'
    title = 'The Knife - We Share Our Mothers\' Health - Silent Shout.mp3'

    # Test method
    mftpp = MetadataFromTitlePP(None, titleformat)
    result = mftpp.format_to_regex(titleformat)

    if result == regex:
        print('Test passed: format_to_regex()')
    else:
        print('Test failed: format_to_regex()')

# Generated at 2022-06-24 14:11:43.150121
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from collections import namedtuple

    # test for titleformat with regex groups
    titleformat = '%(title)s (%(subtitle)s)'
    title = 'Title (subtitle)'
    info = {'title': title}
    match = MetadataFromTitlePP.format_to_regex(titleformat)
    regex = r'(?P<title>.+)\ \((?P<subtitle>.+)\)'
    assert match == regex
    match = re.match(match, title)
    assert match.groupdict() == {'title': 'Title', 'subtitle': 'subtitle'}

    # test for titleformat with regex groups
    titleformat = '%(title)s - %(subtitle)s'
    title = 'Title - subtitle'
    info = {'title': title}
    match = MetadataFromTitle

# Generated at 2022-06-24 14:11:52.894506
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    test the MetadataFromTitlePP class.
    """
    from ydl.YDLDownloader import YDLDownloader
    from ydl.YDLInfoExtractors import YDLSimpleInfoExtractor
    from ydl.YDLUtils import FakeYDL
    temp_ie = YDLSimpleInfoExtractor(FakeYDL())
    temp_pp = MetadataFromTitlePP(temp_ie, '%(title)s %(id)s')


# Generated at 2022-06-24 14:12:00.047276
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import json
    import copy
    import youtube_dl

    info = {'title': 'Bacon - Eggs - SPAM'}
    config = {'outtmpl': '%(title)s.%(ext)s',
              'postprocessors': [{
                  'key': 'MetadataFromTitle',
                  'format': '%(artist)s - %(title)s',
              }]}
    ydl = youtube_dl.YoutubeDL(config)

    # Constructor should take config and info as input parameters
    mft = MetadataFromTitlePP(ydl, config['postprocessors'][0]['format'])

    # Run function should call re.match with the `_titleregex`
    # and return a new info

# Generated at 2022-06-24 14:12:08.264935
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    """Test that MetadataFromTitlePP constructor works as expected"""
    from youtube_dl.downloader.common import FakeYDL
    pp = MetadataFromTitlePP(FakeYDL(), '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    pp = MetadataFromTitlePP(FakeYDL(), 'blabla')
    assert pp._titleformat == 'blabla'
    assert pp._titleregex == 'blabla'

# Generated at 2022-06-24 14:12:13.610219
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    import tempfile
    import shutil

    with tempfile.NamedTemporaryFile() as tmp_f:
        tmp_d = tempfile.mkdtemp(suffix='', prefix='youtube-dl-test-')

# Generated at 2022-06-24 14:12:19.961274
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    fmt = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert fmt.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert fmt.format_to_regex('%( ) - %(artist)s') == r'%\ \(\) - %\(artist\)s'

# Generated at 2022-06-24 14:12:26.845710
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import YouTubeDL
    from .extractor import get_info_extractor

    def get_title_format(info):
        return ydl.params['outtmpl'].split('.')[0].split('%(title)s')[0]

    ydl = YouTubeDL({'outtmpl': '%(title)s.%(ext)s'})
    ydl.add_info_extractor(get_info_extractor('generic'))

    def test_post_processor(title, expected_values, expected_title):
        assert isinstance(ydl.params['postprocessors'][0], MetadataFromTitlePP)
        ydl.params['postprocessors'][0]._titleformat = get_title_format(None)
        ydl.params['postprocessors'][0]._titleregex = y

# Generated at 2022-06-24 14:12:32.514256
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .test import get_test_data

    import json

    testdata = json.loads(get_test_data())['MetadataFromTitlePP']

    tester = MetadataFromTitlePP(None, '')
    for test in testdata:
        assert tester.format_to_regex(test['template']) == test['regex']


# Generated at 2022-06-24 14:12:40.177150
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    ydl = YoutubeDL({'outtmpl': '%(title)s'})
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s'))
    info = {
        'title': 'Test - Test Title',
        'artist': '',
        'track_number': '',
        'album': None,
    }
    ydl.to_screen = lambda x: print(x)
    ydl.post_processors[0].run(info)
    assert info['title'] == 'Test - Test Title'
    assert info['artist'] == 'Test'
    assert info['track_number'] == ''

# Generated at 2022-06-24 14:12:47.683542
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ydl.YdlUtils import YdlUtils
    import unittest.mock
    metadata = ['title',
                'artist',
                'genre',
                'track',
                'album',
                'discnumber',
                'disctotal',
                'tracknumber',
                'tracktotal',
                'date',
                'group']
    # base object
    ydl = unittest.mock.Mock(YdlUtils)
    ydl.to_screen.return_value = None

    # object under test
    fttpp = MetadataFromTitlePP(ydl, '%(artist)s - %(title)s')

    # expected result
    expected_info = {}
    for m in metadata:
        expected_info[m] = None

    # input to object

# Generated at 2022-06-24 14:12:54.168778
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    def checkformat(titleformat, title, expected_out):
        class MockDownloader(object):
            def to_screen(self, txt):
                nonlocal out
                out += txt + '\n'
        dl = MockDownloader()
        pp = MetadataFromTitlePP(dl, titleformat)
        info = {'title': title, 'ext': 'mp3'}
        ret, info = pp.run(info)
        out = out.rstrip('\n')
        assert out == expected_out
        return info

    out = ''
    info = checkformat('%(title)s', 'test', 'parsed title: test\n')
    assert info == {'title': 'test', 'ext': 'mp3'}

    out = ''

# Generated at 2022-06-24 14:13:04.072216
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    class _FakeInfoDict(object):
        def __init__(self):
            self._attributes = {}

        def __getitem__(self, key):
            return self._attributes[key]

        def __setitem__(self, key, value):
            self._attributes[key] = value

    class _FakeDownloader(object):
        def to_screen(self, *args, **kwargs):
            pass

    # Test 1: "%(title)s - %(artist)s" -> "Test Song - Test Artist"
    # Expected output: title="Test Song", artist="Test Artist"
    info_dict = _FakeInfoDict()
    downloader = _FakeDownloader()
    metadata_from_title_pp = MetadataFromTitlePP(downloader, "%(title)s - %(artist)s")

# Generated at 2022-06-24 14:13:11.008936
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    m = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert m.format_to_regex('%(artist)s - %(title)s') == r'(?P<artist>.+)\ \-\ (?P<title>.+)'
    assert m.format_to_regex('%(artist)s [blub] %(title)s') == r'(?P<artist>.+)\ \[blub\]\ (?P<title>.+)'

# Generated at 2022-06-24 14:13:16.329177
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '')
    assert pp.format_to_regex(r'%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex(r'%(title)s - %(1)s - %(number)s') == r'(?P<title>.+)\ \-\ (?P<1>.+)\ \-\ (?P<number>.+)'

# Generated at 2022-06-24 14:13:23.409602
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    titleformat = '%(title)s - %(artist)s'
    titleregex = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP.format_to_regex(None, titleformat) == titleregex
    titleformat = '%(title)s - %(artist)s - %(id)s'
    titleregex = '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<id>.+)'
    assert MetadataFromTitlePP.format_to_regex(None, titleformat) == titleregex


# Generated at 2022-06-24 14:13:29.871734
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    downloader = object()
    test_pp = MetadataFromTitlePP(downloader, '%(artist)s - %(title)s')
    info = {'title': 'The artist - The title'}
    infos, new_info = test_pp.run(info)
    # Title should be empty now
    assert new_info['title'] == ''
    # Artist and title should be parsed
    assert new_info['artist'] == 'The artist'
    assert new_info['title'] == 'The title'

# Generated at 2022-06-24 14:13:35.428202
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(track)s - %(title)s')
    regex = pp.format_to_regex('%(artist)s - %(track)s - %(title)s')
    assert regex == '(?P<artist>.+)\ \-\ (?P<track>.+)\ \-\ (?P<title>.+)'

# Generated at 2022-06-24 14:13:44.205984
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest
    import sys
    if sys.version_info < (3, 0):
        from StringIO import StringIO
    else:
        from io import StringIO

    def _build_downloader(to_screen_value=''):
        #pylint: disable=too-many-locals
        class _FakeYDL:
            def __init__(self, to_screen_value):
                self.to_screen_value = to_screen_value
                self.params = dict()
            def to_screen(self, message):
                self.to_screen_value += message
        class _FakeInfo:
            def __init__(self, info_dict):
                self.__dict__['info'] = info_dict

# Generated at 2022-06-24 14:13:55.290780
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    inst = MetadataFromTitlePP(None, '')

    # simple string
    assert inst.format_to_regex('simple string') == 'simple string'

    # no conversion
    assert inst.format_to_regex('%(no)ssssssssssss') == '%(no)ssssssssssss'

    # full conversion
    assert inst.format_to_regex('%(full)s') == '(?P<full>.+)'

    # complicated conversion
    assert inst.format_to_regex(
        '%(one)s - %(two)s - %(three)s %(four)s'
    ) == '(?P<one>.+)\ \-\ (?P<two>.+)\ \-\ (?P<three>.+)\ (?P<four>.+)'

    #

# Generated at 2022-06-24 14:14:03.885035
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import youtube_dl
    ydl = youtube_dl.YoutubeDL()
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(artist)s - %(title)s'))
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s'))
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s'))
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s'))
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(artist)s'))

    # Test that MetadataFromTitlePP constructor can handle %(uploader_id)s
   

# Generated at 2022-06-24 14:14:12.586319
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    Checks if run method works correctly
    """
    # Todo: find a better way to test this method
    try:
        from pytube import YouTube
    except ImportError:
        YouTube = object
    class fake_downloader:
        def to_screen(self, msg):
            print(msg)

    class test_video:
        def __init__(self, title):
            self.title = title

    fake_downloader = fake_downloader()
    info = {}
    p = MetadataFromTitlePP(fake_downloader, '%(title)s - %(uploader)s')
    video = test_video('Test title - Test uploader')
    p.run(info)
    assert info == {'title':video.title,'uploader':'Test uploader'}


# Generated at 2022-06-24 14:14:22.876938
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    ydl = YoutubeDL({})
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    assert isinstance(pp, PostProcessor)
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    pp = MetadataFromTitlePP(ydl, 'artist %(artist)s song %(title)s year %(year)s')
    assert pp._titleregex == 'artist (?P<artist>.+) song (?P<title>.+) year (?P<year>.+)'


# Generated at 2022-06-24 14:14:31.666735
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    a = '%(title)s - %(artist)s'
    assert MetadataFromTitlePP(None, a)._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    b = '%(artist)s - %(title)s'
    assert MetadataFromTitlePP(None, b)._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'
    c = '%(id)s - %(title)s - %(artist)s'
    assert MetadataFromTitlePP(None, c)._titleregex == '(?P<id>.+)\ \-\ (?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-24 14:14:39.131843
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    fmt_to_regex = MetadataFromTitlePP(None, '').format_to_regex
    assert fmt_to_regex('') == ''
    assert fmt_to_regex('abc') == 'abc'
    assert fmt_to_regex('%(abc)s') == '(?P<abc>.+)'
    assert fmt_to_regex('abc %(def)s') == 'abc (?P<def>.+)'
    assert fmt_to_regex(' %(abc)s ') == '\ (?P<abc>.+)\ '
    assert fmt_to_regex(' %(abc)s%%(def)s') == '\ (?P<abc>.+)\%(def)s'

# Generated at 2022-06-24 14:14:44.607612
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.downloader import Downloader
    from youtube_dl.YoutubeDL import YoutubeDL
    from tempfile import mkstemp

    ydl = YoutubeDL(ydl_opts={'logger': Downloader})
    # Downloader instance for retrieving information about available formats
    dl = Downloader({'quiet': True}, ydl)

    info = {
        'title': 'foo   -   bar  baz',
        'non_existent': 'something',
    }
    fd, filepath = mkstemp(suffix='metadata_from_title')

    result_info = None

# Generated at 2022-06-24 14:14:50.881583
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import encodeArgument

    # Test cases

# Generated at 2022-06-24 14:14:58.590956
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    ydl = object()
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    pp = MetadataFromTitlePP(ydl, 'my title')
    assert pp._titleformat == 'my title'
    assert pp._titleregex == 'my title'


# Test for constructor of class format_to_regex

# Generated at 2022-06-24 14:15:08.524209
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s')._titleformat == '%(title)s - %(artist)s'
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s')._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, '%(title)s')._titleformat == '%(title)s'
    assert MetadataFromTitlePP(None, '%(title)s')._titleregex == '%(title)s'
    assert MetadataFromTitlePP(None, '%(title)s')._titleregex == '(?P<title>.+)'

# Generated at 2022-06-24 14:15:17.516666
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import FileDownloader
    dl = FileDownloader({})
    pp = MetadataFromTitlePP(dl, '%(title)s - %(artist)s')
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s_-%(artist)s') == '(?P<title>.+)_-(?P<artist>.+)'
    assert pp.format_to_regex('%%(title)s') == '%%(title)s'
    assert pp.format_to_regex('%(title)s%s') == '(?P<title>.+)%s'

# Generated at 2022-06-24 14:15:20.414071
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl import YoutubeDL
    titleformat = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(YoutubeDL(), titleformat)
    assert pp._titleformat == titleformat
    assert pp._titleregex ==  r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-24 14:15:29.658520
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    test_cases = [
        ("hello", "hello"),
        ("hello%(title)s", "hello(?P<title>.+)"),
        ("hello%(title)s%(artist)s", "hello(?P<title>.+)(?P<artist>.+)"),
        ("%(title)s%(artist)s", "(?P<title>.+)(?P<artist>.+)")
    ]

    for test_case in test_cases:
        m = MetadataFromTitlePP(None, test_case[0])
        assert m.format_to_regex(test_case[0]) == test_case[1]

# Generated at 2022-06-24 14:15:39.137290
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # imports needed for test
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.downloader.http import HttpFD

    # initialization
    class FakeYDL(object):
        def __init__(self):
            self._ydl_opts = None
        def to_screen(self, msg):
            pass
    pp = MetadataFromTitlePP(FakeYDL(), '%(artist)s - %(title)s')
    info = {'title': 'Metallica - Nothing Else Matters', 'filename': 'blabla.mp3'}
    # test run before initialization of instance variables
    # should create a warning on the screen
    pp.run(info)

    # regular case
    pp = MetadataFromTitlePP(FakeYDL(), '%(artist)s - %(title)s')

# Generated at 2022-06-24 14:15:46.135125
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL(dict(writedescription=True, writeannotations=True))
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    assert pp._titleregex == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'

# Generated at 2022-06-24 14:15:51.931097
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    test_regex_actual = MetadataFromTitlePP(None,
        '%(title)s - %(artist)s (Live)').format_to_regex(
        '%(title)s - %(artist)s (Live)')

    test_regex_expected = '(?P<title>.+) - (?P<artist>.+) \\(Live\\)'

    assert test_regex_actual == test_regex_expected

# Generated at 2022-06-24 14:15:57.834705
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    info = {'title': 'foo title - foo artist'}
    errors, output = pp.run(info)
    assert not errors
    assert output['title'] == 'foo title'
    assert output['artist'] == 'foo artist'


# Generated at 2022-06-24 14:16:08.157975
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import io

    class FakeDownloader():
        def __init__(self):
            self.to_screen_buffer = io.StringIO()
            self.to_screen_saved = sys.stdout
            sys.stdout = self.to_screen_buffer
        def to_screen(self, msg):
            sys.stdout.write(msg + '\n')
        def to_screen_restore(self):
            sys.stdout = self.to_screen_saved
        def to_screen_clear(self):
            self.to_screen_saved.truncate(0)
            self.to_screen_saved.seek(0)


# Generated at 2022-06-24 14:16:16.928515
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """MetadataFromTitlePP_run"""
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')


# Generated at 2022-06-24 14:16:25.646384
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import copy
    class FakeDownloader(object):
        def __init__(self):
            self.to_screen_messages = []

        def to_screen(self, msg):
            self.to_screen_messages.append(msg)

    downloader = FakeDownloader()

    formats = [
        '%(title)s - %(artist)s',
    ]
    for fmt in formats:
        pp = MetadataFromTitlePP(downloader, fmt)
        info = {'title': ''}

        info_copy = copy.deepcopy(info)
        result = pp.run(info)
        assert info == info_copy, 'Test failed for format %s' % fmt


# Generated at 2022-06-24 14:16:32.251608
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '')
    assert '\\(\\?P<title\\>.+\\)\\ \\-\\ \\(\\?P<artist\\>.+\\)' == pp.format_to_regex('%(artist)s - %(title)s')
    assert '\\(\\?P<title\\>.+\\)\\ \\-\\ \\(\\?P<artist\\>.+\\)\\ \\-\\ \\(\\?P<year\\>.+\\)' == pp.format_to_regex('%(artist)s - %(title)s - %(year)s')

# Generated at 2022-06-24 14:16:38.594828
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    metadata_from_titlePP = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert (metadata_from_titlePP.format_to_regex('%(title)s - %(artist)s')
            == '(?P<title>.+)\ \-\ (?P<artist>.+)')
    assert metadata_from_titlePP.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert (metadata_from_titlePP.format_to_regex(
            '%(author)s - %(title)s %(asd)s')
            == '(?P<author>.+)\ \-\ (?P<title>.+)\ (?P<asd>.+)')

# Generated at 2022-06-24 14:16:48.096066
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import YoutubeDL
    from .extractor.youtube import YoutubeIE
    ydl = YoutubeDL()
    ydl.add_info_extractor(YoutubeIE())
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    assert pp._titleregex == '(?P<title>.+) - (?P<artist>.+)'
    pp = MetadataFromTitlePP(ydl, '%(title)s')
    assert pp._titleregex == '(?P<title>.+)'
    pp = MetadataFromTitlePP(ydl, '%(title)s - ')
    assert pp._titleregex == '(?P<title>.+) - '

# Generated at 2022-06-24 14:16:55.959894
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl.extractor.youtube import YoutubeIE


# Generated at 2022-06-24 14:17:04.632172
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    test_cases = {
        '%(title)s - %(artist)s':
            '(?P<title>.+)\\ \-\\ (?P<artist>.+)',
        '%(title)s':
            '(?P<title>.+)',
        '%(): %()':
            '\%\(\)\\:\\ \%\(\)',
    }
    # create a MetadataFromTitlePP instance for convenience
    obj = MetadataFromTitlePP(None, None)
    for fmt, regex in test_cases.items():
        assert regex == obj.format_to_regex(fmt)


# Generated at 2022-06-24 14:17:13.254989
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # test creation of regex
    fmt = '%(title)s - %(artist)s'
    regex = (r'(?P<title>.+)\ \-\ (?P<artist>.+)')
    assert MetadataFromTitlePP(None, fmt)._titleregex == regex
    assert MetadataFromTitlePP(None, regex)._titleregex == regex

    # test that titleformat is parsed correctly
    fmt = '%(title)s - %(artist)s'
    titleformat = 'My Title - My Artist'
    info = {'title': titleformat}
    expectedinfo = {'title': 'My Title', 'artist': 'My Artist'}
    assert MetadataFromTitlePP(None, fmt).run(info)[1] == expectedinfo

    # test that titleformat is parsed correctly

# Generated at 2022-06-24 14:17:21.600269
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(author)s - %(title)s')
    assert pp._titleformat == '%(author)s - %(title)s'
    assert pp._titleregex == '(?P<author>.+)\ \-\ (?P<title>.+)'

    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '%(title)s'

    pp = MetadataFromTitlePP(None, '%(title)s - %(author)s')
    assert pp._titleformat == '%(title)s - %(author)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<author>.+)'

   

# Generated at 2022-06-24 14:17:28.641125
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor import YoutubeIE
    from .postprocessor import FFmpegPostProcessor
    from .compat import compat_str

    info = {'title': 'Owl City - Vanilla Twilight'}

    downloader = FileDownloader({})
    downloader.add_info_extractor(YoutubeIE())
    ff_pp = FFmpegPostProcessor(downloader)
    from_title_pp = MetadataFromTitlePP(downloader, '%(title)s')

    # Test if it does nothing when no format is specified
    from_title_pp = MetadataFromTitlePP(downloader, '')
    _, info = from_title_pp.run(info)
    assert info == {'title': 'Owl City - Vanilla Twilight'}

    # Test if it does nothing when the format is

# Generated at 2022-06-24 14:17:33.859721
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Arrange
    downloader = None
    titleformat = '%(title)s'
    tester = MetadataFromTitlePP(downloader, titleformat)
    # Assert
    assert 'title' in tester._titleregex


# Generated at 2022-06-24 14:17:41.794724
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '%(title)s'
    pp = MetadataFromTitlePP(None, 'a')
    assert pp._titleformat == 'a'
    assert pp._titleregex == 'a'

# Generated at 2022-06-24 14:17:49.830645
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    mftPP = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert mftPP._titleregex == r'(?P<artist>.+)\ \-\ (?P<title>.+)'
    mftPP = MetadataFromTitlePP(None, '%(title)s')
    assert mftPP._titleregex == r'%\(title\)s'
    mftPP = MetadataFromTitlePP(None, '%(artist)s')
    assert mftPP._titleregex == r'%\(artist\)s'
    mftPP = MetadataFromTitlePP(None, '%(artist)s_%(title)s')
    assert mftPP._titleregex == (
        r'(?P<artist>.+)\_(?P<title>.+)')

# Generated at 2022-06-24 14:17:57.427978
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    obj = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert 'La\ Cumbia' == re.match(
        obj.format_to_regex('%(title)s - %(artist)s'),
        'La Cumbia - Azucar Moreno').group('title')
    assert 'La Cumbia - Azucar Moreno' == re.match(
        obj.format_to_regex('%(title)s - %(artist)s'),
        'La Cumbia - Azucar Moreno').group(0)

# Generated at 2022-06-24 14:17:58.568278
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass


# Generated at 2022-06-24 14:18:08.201771
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    obj = MetadataFromTitlePP(None, '')
    assert obj.format_to_regex('%(title)s') == '%(title)s'
    assert obj.format_to_regex('%a') == '%a'
    assert obj.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert obj.format_to_regex('%(title)s - %(artist)s - %(album)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'

# Generated at 2022-06-24 14:18:16.880137
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    tftpp = MetadataFromTitlePP(None, None)
    test_cases = {
        '%(title)s': r'(?P<title>.+)',
        'foo%(title)s': r'foo(?P<title>.+)',
        '%(title)sbar': r'(?P<title>.+)bar',
        '%(title)s - %(artist)s': r'(?P<title>.+)\ \-\ (?P<artist>.+)',
        '%(title)s - %(artist)s - %(album)s': (
            r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)')
    }

# Generated at 2022-06-24 14:18:26.939432
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():

    # check clean title
    title = 'Video title 2017'
    title_fmt = '%(title)s'
    regex_fmt = '^(?P<title>.+)$'
    mdft = MetadataFromTitlePP(None, title_fmt)
    assert mdft._titleformat == title_fmt
    assert mdft._titleregex == regex_fmt

    # check title with artist
    title = 'Video title 2017 - Artist Name'
    title_fmt = '%(title)s - %(artist)s'
    regex_fmt = '^(?P<title>.+)\ \-\ (?P<artist>.+)$'
    mdft = MetadataFromTitlePP(None, title_fmt)
    assert mdft._titleformat == title_fmt
    assert mdft._titleregex

# Generated at 2022-06-24 14:18:34.005751
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest

    import youtube_dl

    class FakeDownloader(object):
        def __init__(self, post_processors):
            self.post_processors = post_processors
            self.ytdl = youtube_dl.YoutubeDL({
                'writedescription': True,
                'writeinfojson': True,
                'writethumbnail': True,
                'writeautomaticsub': True,
                'simulate': True,
                'format': 'bestaudio/best',
                'postprocessors': post_processors,
            })

        def to_screen(self, msg):
            print(msg)

        def report_warning(self, msg):
            print(msg)


# Generated at 2022-06-24 14:18:43.822813
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .compat import StringIO
    from .downloader import Downloader
    # Method run is not tested with integration tests due to its
    # complexity and the high number of different outputs.
    # This method tests as much as possible corner cases by unit testing.

    # Create a new instance of MetadataFromTitlePP and a new downloader
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    dl = Downloader(params={'nooverwrites': True})
    # Add a test video
    dl.add_info_extractor(dict(
        ie_key='Generic',
        ie={'id': 'test', 'title': __name__ + ' - test'},
        downloader=dl
    ))
    # Prepare a fake output
    out = StringIO()
    # Set

# Generated at 2022-06-24 14:18:53.817052
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ..YoutubeDL import YoutubeDL
    import sys

    class MockYoutubeDL(YoutubeDL):
        def __init__(self):
            super(MockYoutubeDL, self).__init__()
            self.to_screen_messages = []

        def to_screen(self, message):
            self.to_screen_messages.append(message)

    class MockInfoDict(dict):
        def __init__(self):
            pass

    def make_info_dict(title):
        info = MockInfoDict()
        info['title'] = title
        return info


# Generated at 2022-06-24 14:19:03.412905
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Instantiate an instance of the class
    pp = MetadataFromTitlePP('downloader', "%(title)s")
    pp_regex = MetadataFromTitlePP('downloader', "%(title)s - %(artist)s")

    # Check for a case where title format is "%(title)s" and title of video is
    # "Hello World"
    info = {'title' : 'Hello World'}
    expected_info = info.copy()
    pp.run(info)
    assert expected_info == info
    # Check for a case where title format is "%(title)s - %(artist)s" and title
    # of video is "Hello World - YTDownloader"
    expected_info = {'title' : 'Hello World', 'artist' : 'YTDownloader'}

# Generated at 2022-06-24 14:19:10.582834
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl.YoutubeDL import YoutubeDL
    pp = MetadataFromTitlePP(YoutubeDL(), "%(title)s - %(artist)s")
    info = {'title': '20,000 days - Yosi Piamenta'}
    [], updated_info = pp.run(info)
    assert updated_info == {
        'title': '20,000 days',
        'artist': 'Yosi Piamenta'
    }


# Generated at 2022-06-24 14:19:17.676517
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .youtube import YoutubeDL
    from .utils import DateRange

    # Test 1: re-parse date
    info = {
        'title': '%(upload_date)s'
    }
    dl = FileDownloader({
        'noprogress': True,
        'outtmpl': '%(upload_date)s',
        'postprocessors': [{
            'key': 'MetadataFromTitle',
        }],
        'verbose': True,
    })
    ydl = YoutubeDL(dl.params)
    ydl.add_default_info_extractors()
    ydl.process_ie_result(info, download=False)
    assert(dl.params['outtmpl'] == '%(upload_date)s')

# Generated at 2022-06-24 14:19:27.061419
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # unit test for class constructor
    assert MetadataFromTitlePP('downloader', 'mytitle')._titleformat == 'mytitle'
    # unit test for formatting format
    assert MetadataFromTitlePP('downloader', 'mytitle - %(author)s')._titleregex == 'mytitle\ \-\ (?P<author>.+)'
    # unit test for using regex as format
    assert MetadataFromTitlePP('downloader', 'mytitle - (?P<author>.)')._titleregex == 'mytitle\ \-\ (?P<author>.+)'
    # unit test for using regex as format (with escape character)
    assert MetadataFromTitlePP('downloader', 'mytitle - \\w')._titleregex == 'mytitle\ \-\ \\w'
    # unit test for format_to_regex

# Generated at 2022-06-24 14:19:32.930240
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp._titleformat == '%(artist)s - %(title)s'
    assert pp._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'
    pp = MetadataFromTitlePP(None, 'blabla')
    assert pp._titleformat == 'blabla'
    assert pp._titleregex == 'blabla'


# Unit tests for method format_to_regex

# Generated at 2022-06-24 14:19:39.866145
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .__main__ import ytdl_hook
    from .__main__ import ytdl_hook_for_test
    from .__main__ import run_ytdl_hook_for_test
    import types
    import sys

    prev_value = getattr(ytdl_hook, '_hooks', None)

    # create a mock class to replace the VideoDownloader class
    class TestVideoDownloader(object):
        def __init__(self):
            self.to_screen_messages = []

        def to_screen(self, msg):
            self.to_screen_messages.append(msg)

    # replace the VideoDownloader class
    ytdl_hook._VideoDownloader = TestVideoDownloader

    # create a mock class to replace the InfoExtractor class

# Generated at 2022-06-24 14:19:50.603168
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    metadatapp = MetadataFromTitlePP(None, '')
    fmt = '%(title)s - %(artist)s'
    assert metadatapp.format_to_regex(fmt) == '(?P<title>.+) - (?P<artist>.+)'
    fmt = '%(title)s - %(artist)s [%(id)s]'
    assert metadatapp.format_to_regex(fmt) == '(?P<title>.+) - (?P<artist>.+) \[(?P<id>.+)\]'
    fmt = '%(title)s'
    assert metadatapp.format_to_regex(fmt) == '(?P<title>.+)'
    fmt = '(?P<title>.+) - (?P<artist>.+) [%(id)s]'
    assert metadatapp.format

# Generated at 2022-06-24 14:19:57.875885
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    import youtube_dl
    import youtube_dl.postprocessor
    import os.path

    # Set up a downloader
    D = youtube_dl.YoutubeDL({})
    D.to_screen = lambda *xs: xs
    D.to_stderr = lambda *xs: xs

    # Set up a PostProcessor
    titleformat = '%(autonumber)s-%(uploader)s-%(title)s'
    PP = youtube_dl.postprocessor.MetadataFromTitlePP(D, titleformat)

    # Set up a dummy info dictionary
    info = {'uploader': 'a', 'title': 'b'}

    # Test matching
    info['title'] = '10-a-b'

# Generated at 2022-06-24 14:20:07.959064
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    class MockInfo:
        def __init__(self, title):
            self['title'] = title
    def test(testfmt, testtitle, expected):
        pp = MetadataFromTitlePP(None, testfmt)
        info = MockInfo(testtitle)
        pp.run([], info)
        assert info == expected
    # single %(..)s in title
    test('%(title)s', 'testtitle', {'title': 'testtitle'})
    # no %(..)s in title
    test('title', 'testtitle', {})
    # multiple %(..)s in title
    test('%(title)s - %(album)s', 'testtitle - testalbum',
         {'title': 'testtitle', 'album': 'testalbum'})
    # multiple %(..)s in title

# Generated at 2022-06-24 14:20:13.073579
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader import HttpFD

    ydl = YoutubeDL({'outtmpl': '%(title)s', 'writedescription': True, 'writeinfojson': True})
    ydl.add_default_info_extractors()
    dl = HttpFD(ydl, {})
    ie = YoutubeIE(ydl)
    pp = MetadataFromTitlePP(dl, '%(title)s - %(artist)s')
    # extract file name from title
    info = {'id': '123', 'title': 'Hello - World'}
    (new_info, new_added) = pp.run(info)
    assert info['title'] == 'Hello - World'

# Generated at 2022-06-24 14:20:22.703550
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # titleformat: %(title)s - %(artist)s
    titleformat = '%(title)s - %(artist)s'
    # regex : (?P<title>.+)\ \-\ (?P<artist>.+)
    regex = r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    # create object of class MetadataFromTitlePP
    mpp = MetadataFromTitlePP(None, titleformat)

    # test format_to_regex function by comparing the value of object variable
    # _titleregex with the expected value (regex)
    assert mpp._titleregex == regex


# Generated at 2022-06-24 14:20:26.482498
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    mdftpp = MetadataFromTitlePP(None, '%(artist)s - %(track)s')
    assert mdftpp._titleformat == '%(artist)s - %(track)s'
    assert mdftpp._titleregex == '(?P<artist>.+)\ \-\ (?P<track>.+)'



# Generated at 2022-06-24 14:20:33.976008
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex(pp._titleformat) == pp._titleregex
    pp = MetadataFromTitlePP(None, 'test')
    assert pp._titleformat == 'test'
    assert pp._titleregex == 'test'


# Generated at 2022-06-24 14:20:42.428577
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import pytest
    from .common import InfoExtractor

    # Create fake downloader
    from .test import FakeYDL
    from .downloader import YoutubeDL
    YoutubeDL.params = {}
    downloader = FakeYDL()

    class TestIE(InfoExtractor):
        def __init__(self, downloader=None):
            super(TestIE, self).__init__(downloader)
        def _real_extract(self, url):
            return {'id': 'test_id'}, None

    ie = TestIE(downloader=downloader)

    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')


# Generated at 2022-06-24 14:20:52.083757
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    # Test for proper parsing of title as expected
    ydl = YoutubeDL({})
    mdftpp = MetadataFromTitlePP(ydl, '%(artist)s - %(title)s')
    parsed, info = mdftpp.run({
        'id': '123',
        'title': 'Artist Name - Title of the video'
    })
    assert info['artist'] == 'Artist Name'
    assert info['title'] == 'Title of the video'
    # Test for no parsing when title not as expected
    ydl = YoutubeDL({})
    mdftpp = MetadataFromTitlePP(ydl, '%(artist)s - %(title)s')