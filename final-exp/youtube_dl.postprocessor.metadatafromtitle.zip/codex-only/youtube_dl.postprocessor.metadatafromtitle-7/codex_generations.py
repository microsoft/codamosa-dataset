

# Generated at 2022-06-24 14:10:56.114089
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from ytdl import options
    from ytdl.extractor import YoutubeIE

    p = MetadataFromTitlePP(None, '%(title)s - %(artist)s')

    assert p._titleformat == '%(title)s - %(artist)s'
    assert p._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    p = MetadataFromTitlePP(None, '%(title)s')

    assert p._titleformat == '%(title)s'
    assert p._titleregex == r'%\(\w+\)s'

    p = MetadataFromTitlePP(None, '%(upload_date)s')

    assert p._titleformat == '%(upload_date)s'

# Generated at 2022-06-24 14:11:06.617210
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-24 14:11:17.417578
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Downloader is unused, so we instantiate a dummy one
    from youtube_dl.downloader.common import FileDownloader
    youtube_dl = FileDownloader({})
    metadata_from_title_pp = MetadataFromTitlePP(
        youtube_dl, 'name - %(artist)s - %(title)s')

    test_info = {'title': 'name - artist - title'}
    expected_return = ({}, {'title': 'name - artist - title',
                            'artist': 'artist',
                            'title': 'title'})
    returned_info = metadata_from_title_pp.run(test_info)
    assert (returned_info == expected_return)

    test_info = {'title': 'name - artist'}

# Generated at 2022-06-24 14:11:27.041815
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # title format: "Song Name - Artist - Album"
    tft = MetadataFromTitlePP("FakeDownloader", "%(song)s - %(artist)s - %(album)s")

    # 1st test

# Generated at 2022-06-24 14:11:37.980487
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Test with default titleformat
    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '(?P<title>.+)'

    # Test with %(..)s regex
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    # Test without %(..)s regex
    pp = MetadataFromTitlePP(None, 'title')
    assert pp._titleformat == 'title'
    assert pp._titleregex == 'title'


# Generated at 2022-06-24 14:11:46.535330
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    def check_format_to_regex(format, regex):
        pp = MetadataFromTitlePP(None, format)
        if pp._titleregex != regex:
            raise AssertionError('%s -> %s != %s' % (format, pp._titleregex, regex))

    # Test with no groups
    check_format_to_regex("test", "test")
    check_format_to_regex("test (test)", "test \\(test\\)")
    # Test with groups
    check_format_to_regex("%(title)s - %(artist)s", "(?P<title>.+)\\ \\-\\ (?P<artist>.+)")

# Generated at 2022-06-24 14:11:53.135152
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    titleformat = '%(artist)s - %(title)s'
    titleregex = (re.compile(r'(?P<artist>.+)\ \-\ (?P<title>.+)')
                  if re.search(r'%\(\w+\)s', titleformat)
                  else titleformat)

    mftpp = MetadataFromTitlePP(None, titleformat)
    assert mftpp is not None
    assert mftpp._titleformat == titleformat
    assert mftpp._titleregex == titleregex


# Generated at 2022-06-24 14:12:00.299569
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from nose.tools import assert_true, assert_equal, assert_false
    from ydl.postprocessor.common import PostProcessor

    class MockDownloader():
        def __init__(self):
            self._log = []
        def to_screen(self, str):
            self._log.append(str)

    PP = MetadataFromTitlePP(MockDownloader(), '%(artist)s - %(title)s - %(album)s')
    # No match
    assert_false(PP.run({'title': 'foo'})[1].get('artist'))
    assert_equal("[fromtitle] Could not interpret title of video as \"%(artist)s - %(title)s - %(album)s\"\n",
                 PP._downloader._log[0])
    # Match

# Generated at 2022-06-24 14:12:10.192039
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .test import get_test_downloader
    dl = get_test_downloader('http://www.youtube.com/watch?v=BaW_jenozKc')
    mp = MetadataFromTitlePP(dl, '%(track)s - %(artist)s')
    info = {'title': 'Blink-182 - All The Small Things'}
    res = mp.run(info)
    assert len(res) == 2
    assert 'track' in res[1].keys()
    assert res[1]['track'] == 'All The Small Things'
    assert 'title' not in res[1].keys()
    assert res[1]['artist'] == 'Blink-182'

    info = {'title': 'A Badly Formatted Title'}
    res = mp.run(info)
    assert len

# Generated at 2022-06-24 14:12:13.973795
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '(?P<title>.+)'



# Generated at 2022-06-24 14:12:23.512264
# Unit test for constructor of class MetadataFromTitlePP

# Generated at 2022-06-24 14:12:28.187829
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from tempfile import NamedTemporaryFile
    fd = NamedTemporaryFile(mode='w')
    fd.write('{"title": "Adele - Hello"}')
    fd.flush()
    from ydl.downloader import FDInfoLoader
    from ydl.YoutubeDL import YoutubeDL
    downloader = YoutubeDL({}, FDInfoLoader(fd))

    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    info = {}
    info['title'] = 'Adele - Hello'
    assert pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-24 14:12:37.687874
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    import sys
    import tempfile
    import shutil
    import re

    class _FakeInfo:
        def __init__(self, title):
            self._title = title

        def __getitem__(self, name):
            if name == 'title':
                return self._title
            raise KeyError(name)

        def __setitem__(self, name, value):
            if name == 'title':
                self._title = value
            else:
                raise KeyError(name)

    class _FakeDownloader:
        def __init__(self):
            self._out = []

        def to_screen(self, text):
            self._out.append(text)

    dir = tempfile.mkdtemp()
    old_stdout = sys.stdout

# Generated at 2022-06-24 14:12:42.385982
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    downloader = object()
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    info = {'title': 'My Title - My Artist'}
    assert pp.run(info) == ([], {'title': 'My Title - My Artist',
                                 'artist': 'My Artist'})

# Generated at 2022-06-24 14:12:49.462644
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from . import YoutubeDL
    return YoutubeDL(dict(simulate=True)).add_default_info_extractors().add_post_processor(MetadataFromTitlePP(YoutubeDL(dict()), '%(title)s - %(artist)s')).extract_info(
        'https://www.youtube.com/watch?v=BaW_jenozKc')['title'] == 'Avicii - Waiting For Love'

# Generated at 2022-06-24 14:12:55.937189
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # Test 1
    processor1 = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert processor1._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)', 'Test 1'

    # Test 2
    processor2 = MetadataFromTitlePP(None, '%(title)s')
    assert processor2._titleregex == '(?P<title>.+)', 'Test 2'

    # Test 3
    processor3 = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(album)s')
    assert processor3._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)', 'Test 3'

# Generated at 2022-06-24 14:13:04.763172
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():

    from youtube_dl.YoutubeDL import YoutubeDL

    class MockInfo:
        def __init__(self, name, url, title):
            self.name = name
            self.url = url
            self.title = title

    # Test parsing of %(title)s
    downloader = YoutubeDL({})
    info = MockInfo(
        name='video_name.mp4', url='http://example.com/vidoe_file.mp4',
        title='Song Title - Artist Name - 2013')
    pp = MetadataFromTitlePP(downloader, '%(title)s')
    metadata, info = pp.run(info)
    assert info.get('artist') == 'Artist Name'
    assert info.get('title') == 'Song Title'

    # Test parsing of %(extractor)s
    downloader = YoutubeDL

# Generated at 2022-06-24 14:13:11.569394
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s_%(album)s_%(artist)s.mp3')
    assert pp._titleregex == '(?P<title>.+)_(?P<album>.+)_(?P<artist>.+\.mp3)', (
        'Assertion failed: %r != %r' % (
            pp._titleregex, '(?P<title>.+)_(?P<album>.+)_(?P<artist>.+\.mp3)'))


# Generated at 2022-06-24 14:13:21.537804
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    assert (pp.format_to_regex('foo%(bar)s') == r'foo(?P<bar>.+)')
    assert (pp.format_to_regex('foo%(bar)sbar') == r'foo(?P<bar>.+)bar')
    assert (pp.format_to_regex('foo%(bar)sbar%(baz)s') == r'foo(?P<bar>.+)bar(?P<baz>.+)')
    assert (pp.format_to_regex('foo%(bar)s%(baz)sbar') == r'foo(?P<bar>.+)(?P<baz>.+)bar')

# Generated at 2022-06-24 14:13:32.191027
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl
    def rel_call(path):
        return path
    ydl = youtube_dl.YoutubeDL({
        'quiet': True,
        'outtmpl': '%(title)s-%(id)s.%(ext)s',
        'postprocessors': [{
            'key': 'MetadataFromTitlePP',
            'format': '%(season_number)s/%(episode_number)s %(title)s',
        }],
        'ffmpeg_location': rel_call,
        'executable': rel_call,
        'ignoreerrors': '',
    })
    def _download_webpage(url, *args, **kwargs):
        return b'{"title": "S01E02 Title"}'


# Generated at 2022-06-24 14:13:41.741323
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import os
    from .extractor import gen_extractors

    def _run_test(titleformat, title, expected_info):
        info = {'title': title}
        downloader = MockYoutubeDL(params={})
        pp = MetadataFromTitlePP(downloader, titleformat)
        pp.run(info)

        assert info == expected_info, (
            'Failed to parse metadata expected %r got %r' % (expected_info, info))

    # Run extraction tests
    gen_extractors()  # Load extractors
    base_path = os.path.join(os.path.dirname(__file__), 'tests', 'test_data', 'metadata_from_title')

# Generated at 2022-06-24 14:13:48.800025
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    pp = MetadataFromTitlePP(YoutubeDL(), '%(artist)s - %(title)s')
    result, data = pp.run({'title': 'foo - bar'})
    assert data.get('title', None) == 'foo'
    assert data.get('artist', None) == 'bar'
    assert result == ([], data)
    result, data = pp.run({'title': 'bar'})
    assert result == ([], data)
    pp = MetadataFromTitlePP(YoutubeDL(), '%(title)s - %(artist)s')
    result, data = pp.run({'title': 'foo - bar'})
    assert data.get('title', None) == 'foo'
    assert data.get('artist', None) == 'bar'

# Generated at 2022-06-24 14:13:59.958070
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = lambda x, y: MetadataFromTitlePP(x, y)
    FROMTITLE_TESTS = [
        # titleformat, expected_titleregex
        ('%(title)s - %(artist)s', '(?P<title>.+)\ \-\ (?P<artist>.+)'),
        ('%(title)s', '(?P<title>.+)'),
        ('[%(title)s]', '\[(?P<title>.+)\]'),
        ('%(title)s[%(artist)s]', '(?P<title>.+)\[(?P<artist>.+)\]'),
    ]

    for titleformat, expected_titleregex in FROMTITLE_TESTS:
        assert pp(None, titleformat)._titleregex == expected_titleregex



# Generated at 2022-06-24 14:14:11.515307
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    print(MetadataFromTitlePP(None, None).format_to_regex(''))
    print(MetadataFromTitlePP(None, None).format_to_regex('foo'))
    print(MetadataFromTitlePP(None, None).format_to_regex('%(title)s'))
    print(MetadataFromTitlePP(None, None).format_to_regex('%(title)sver.'))
    print(MetadataFromTitlePP(None, None).format_to_regex('ver.%(title)s'))
    print(MetadataFromTitlePP(None, None).format_to_regex('foo%(title)sbar'))
    print(MetadataFromTitlePP(None, None).format_to_regex('foo%(title)sbar%(artist)s'))


# Generated at 2022-06-24 14:14:20.940832
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Init
    pp = MetadataFromTitlePP({}, '%(artist)s - %(album)s - [%(year)s]')

    # No regex match
    assert pp._titleregex == '(?P<artist>.+)\ \-\ (?P<album>.+)\ \-\ \[(?P<year>.+)\]'

    # Regex match
    assert pp._titleregex == '%(title)s - %(artist)s'

    # Regex match with no %(foo)s in format
    pp = MetadataFromTitlePP({}, '%(title)s - %(artist)s')
    assert pp._titleregex == '%(title)s - %(artist)s'


# Generated at 2022-06-24 14:14:25.211502
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    tftpp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    regex = tftpp.format_to_regex('%(title)s - %(artist)s')
    assert regex == '(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-24 14:14:29.367425
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # Given
    titleformat = '%(title)s - %(artist)s'

    # When
    regex = MetadataFromTitlePP(None, titleformat).format_to_regex(titleformat)

    # Then
    assert regex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-24 14:14:37.752314
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.downloader import FakeYDL
    youtube_dl = FakeYDL()
    pp = MetadataFromTitlePP(youtube_dl, '%(title)s - %(artist)s')
    assert(pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)')
    pp = MetadataFromTitlePP(youtube_dl, '%(title)s')
    assert(pp._titleregex == '%(title)s')
    pp = MetadataFromTitlePP(youtube_dl, "20 - Ashes Remain - What I've Become")
    assert(pp._titleregex == "20\ \-\ Ashes\ Remain\ \-\ What\ I've\ Become")


# Generated at 2022-06-24 14:14:39.875859
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleregex == '(?P<title>.+) - (?P<artist>.+)'



# Generated at 2022-06-24 14:14:43.897167
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP._format_to_regex('foo') == 'foo'
    assert MetadataFromTitlePP._format_to_regex('%(title)s') == '(?P<title>.+)'
    assert (MetadataFromTitlePP._format_to_regex(
        '%(title)s - %(type)s') == '(?P<title>.+)\ \-\ (?P<type>.+)')
    assert (MetadataFromTitlePP._format_to_regex(
        '%(title)s - ') == '(?P<title>.+)\ \-\ ')

# Generated at 2022-06-24 14:14:53.889331
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-24 14:14:57.826194
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    m = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert m._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'


# Generated at 2022-06-24 14:15:07.589316
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, '').format_to_regex(
        '%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, '').format_to_regex('%(title)s') == (
        r'(?P<title>.+)')
    assert MetadataFromTitlePP(None, '').format_to_regex('%(title)s - %(artist)s - %(album)s - %(track)s') == (
        r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)\ \-\ (?P<track>.+)')


# Generated at 2022-06-24 14:15:16.624779
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    """
    Test if format_to_regex does what it should do.
    """
    mftpp = MetadataFromTitlePP(None, None)
    assert (mftpp.format_to_regex('%(title)s - %(artist)s')
            == '(?P<title>.+)\ \-\ (?P<artist>.+)')
    assert (mftpp.format_to_regex('%(title)s - %(artist)s - %(album)s')
            == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)')

# Generated at 2022-06-24 14:15:24.699293
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from youtube_dl.YoutubeDL import YoutubeDL
    downloader = YoutubeDL()
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert pp.format_to_regex('%(title)s - ') == '(?P<title>.+)\ \-'

# Generated at 2022-06-24 14:15:28.653570
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .extractor import Extractor
    from .downloader import Downloader
    from .compat import compat_str
    e = Extractor()
    d = Downloader()
    d.add_info_extractor(e)
    e.add_post_processor(MetadataFromTitlePP(d,'%(title)s'))
    info = {}
    res = e.post_process(info, [])
    assert res == ([],{})
    info['title'] = 'foo'
    res = e.post_process(info, [])
    assert res[1]['title'] == 'foo'
    res = e.post_process(info, [])
    assert res[1]['title'] == 'foo'

# Generated at 2022-06-24 14:15:34.334653
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ydl.downloader.YoutubeDL import YoutubeDL
    from ydl.downloader.extractor import gen_extractor
    from ydl.utils import get_cachedir
    from mock import Mock
    from ydl.utils import urljoin

    titleformat = '%(title)s -- %(timestamp)s'
    title = 'Test title -- 2015-01-19'
    expected = {'title': 'Test title', 'timestamp': '2015-01-19'}
    regex = '(?P<title>.+)\\ --\\ (?P<timestamp>.+)'

    # test data
    outtmpl = '%(title)s.%(ext)s'
    test_url = 'http://www.youtube.com/watch?v=BaW_jenozKc'

# Generated at 2022-06-24 14:15:41.965054
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    import unittest
    import re

    class TestFormatToRegex(unittest.TestCase):
        def test_constant(self):
            fmt = 'foo'
            obj = MetadataFromTitlePP(None, fmt)
            regex = r'foo'
            self.assertEqual(obj.format_to_regex(fmt), regex)
            self.assertEqual(re.match(regex, fmt).groupdict(), {})

        def test_format_one_variable(self):
            fmt = '%(title)s'
            obj = MetadataFromTitlePP(None, fmt)
            regex = r'(?P<title>.+)'
            self.assertEqual(obj.format_to_regex(fmt), regex)

# Generated at 2022-06-24 14:15:45.055099
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, r'%(artist)s - %(title)s')
    assert pp._titleformat == r'%(artist)s - %(title)s'
    assert pp._titleregex == r'(?P<artist>.+)\ \-\ (?P<title>.+)'
    pp = MetadataFromTitlePP(None, r'%(title)s')
    assert pp._titleformat == r'%(title)s'
    assert pp._titleregex == r'%\(title\)s'



# Generated at 2022-06-24 14:15:45.868868
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass

# Generated at 2022-06-24 14:15:56.255100
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """Just a few test cases"""
    import sys
    class NullFD(object):
        softspace=0
        def close(self):
            pass
        def write(self, txt):
            pass
        def isatty(self):
            return False
        def flush(self):
            pass
    class Downloader(object):
        def __init__(self):
            self.to_screen_buffer = ''
        def to_screen(self, txt):
            self.to_screen_buffer += txt
    downloader = Downloader()
    sys.stdout = NullFD()   # to suppress output to stdout
    import test

    # Test case 1
    input_args = {"title" : "My video title - my video artist" }

# Generated at 2022-06-24 14:16:07.057229
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    youtube_dl = {}
    # Set method 'to_screen' and attribute 'params' for youtube_dl
    youtube_dl.to_screen = lambda x: None
    youtube_dl.params = {}
    youtube_dl.params['metadatafromtitle'] = '%(artist)s - %(title)s - %(album)s'
    metadata_from_title_pp = MetadataFromTitlePP(youtube_dl, '')

    info = {'title': 'The Dark Knight Rises - Trailer 3 [HD]', 'description': 'description of The Dark Knight Rises - Trailer 3 [HD]'}

# Generated at 2022-06-24 14:16:11.545899
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .downloader import Downloader
    fmt = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(Downloader(), fmt)
    assert pp.format_to_regex(fmt) == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    fmt = '%(title)s'
    pp = MetadataFromTitlePP(Downloader(), fmt)
    assert pp.format_to_regex(fmt) == r'(?P<title>.+)'
    fmt = '%(title)s_%(something)s_%(artist)s - %(track)s %(title)s'
    pp = MetadataFromTitlePP(Downloader(), fmt)

# Generated at 2022-06-24 14:16:19.357603
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert (pp._titleformat == '%(title)s - %(artist)s')
    assert (pp._titleregex == '(?P<title>.+) - (?P<artist>.+)')
    pp = MetadataFromTitlePP(None, '%(title)s by %(artist)s')
    assert (pp._titleformat == '%(title)s by %(artist)s')
    assert (pp._titleregex == '(?P<title>.+) by (?P<artist>.+)')
    pp = MetadataFromTitlePP(None, 'blah')
    assert (pp._titleformat == 'blah')
    assert (pp._titleregex == 'blah')



# Generated at 2022-06-24 14:16:23.791204
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    downloader = object()
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    assert pp
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-24 14:16:29.565429
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '')
    assert pp.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert pp.format_to_regex('%(title)s.%(foo)s') == r'(?P<title>.+)\.(?P<foo>.+)'
    assert pp.format_to_regex('%(title)s%(foo)s') == r'(?P<title>.+)(?P<foo>.+)'
    assert pp.format_to_regex('a%(title)sb') == r'a(?P<title>.+)b'

# Generated at 2022-06-24 14:16:37.409783
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    class Mock():
        def to_screen(self, msg):
            print('[fromtitle] ' + msg)
    # Test empty input string
    downloader = Mock()
    pp = MetadataFromTitlePP(downloader, '')
    assert pp.format_to_regex('') == ''
    # Test input string with format but no actual '%(<name>)s' tags
    pp = MetadataFromTitlePP(downloader, 'abc')
    assert pp.format_to_regex('abc') == 'abc'
    # Test a format string with some '%(<name>)s' tags
    pp = MetadataFromTitlePP(downloader, '%(foo)s - %(bar)s - %(baz)s')

# Generated at 2022-06-24 14:16:42.216735
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    example_format = '%(ab)s - %(cd)s'
    regex = '(?P<ab>.+)\ \-\ (?P<cd>.+)'
    m = MetadataFromTitlePP('dummy', example_format)
    assert m.format_to_regex(example_format) == regex


# Generated at 2022-06-24 14:16:48.530444
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pp = MetadataFromTitlePP(None, '%(title)s')
    result = pp.run({'title': 'Test'})
    assert result == ([], {'title': 'Test'})

    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    result = pp.run({'title': 'Test - Test artist'})
    assert result == ([], {'title': 'Test', 'artist': 'Test artist'})


# Generated at 2022-06-24 14:16:56.258627
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(album)s')
    assert pp._titleformat == '%(title)s - %(artist)s - %(album)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'

    pp = MetadataFromTitlePP(None, '%(title)s')

# Generated at 2022-06-24 14:17:07.152560
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    class DummyInfo(object):
        def __init__(self):
            self.title = None

    class DummyYDL(object):
        def __init__(self):
            self.to_screen = None

    ydl = DummyYDL()
    info = DummyInfo()
    info.title = 'MyVideo'
    mypp = MetadataFromTitlePP(ydl, '%(title)s')
    mypp.run(info)
    assert info.title == 'MyVideo'
    info.title = 'MyVideo - MyArtist'
    mypp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    mypp.run(info)
    assert info.title == 'MyVideo'
    assert info.artist == 'MyArtist'


# Generated at 2022-06-24 14:17:13.310986
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from ytdl_server import YtdlServer
    yds = YtdlServer()
    yds.add_postprocessor(MetadataFromTitlePP(yds, '%(title)s - %(artist)s'))
    assert yds.postprocessors[0]._titleformat == '%(title)s - %(artist)s'
    assert (yds.postprocessors[0]._titleregex ==
            r'(?P<title>.+)\ \-\ (?P<artist>.+)')


# Generated at 2022-06-24 14:17:21.669594
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP('dummy', '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    pp = MetadataFromTitlePP('dummy', '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '%\(title\)s'
    pp = MetadataFromTitlePP('dummy', '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '%\(title\)s'
    pp = MetadataFromTitlePP('dummy', 'something else')
   

# Generated at 2022-06-24 14:17:25.460406
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mpp = MetadataFromTitlePP(None, None)
    match = re.match(mpp.format_to_regex('%(title)s - %(artist)s'),
                     'title - artist')
    assert match is not None
    for field in ['title', 'artist']:
        assert match.group(field) == field

# Generated at 2022-06-24 14:17:30.138070
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .common import FakeDownloader
    from .compat import encodeFilename
    downloader = FakeDownloader()
    pp = MetadataFromTitlePP(downloader, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == r'(?P<title>.+)'
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-24 14:17:33.379045
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from ytdl_from_title.YoutubeDL import YoutubeDL
    ytdl = YoutubeDL({})
    pp = MetadataFromTitlePP(ytdl, '%(title)s - %(artist)s')

# Generated at 2022-06-24 14:17:40.564301
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import FakeYDL

    fake_dl = FakeYDL()
    pp = MetadataFromTitlePP(fake_dl, '')

    def test(fmt, regex, name2):
        regex = '^' + regex + '$'
        if regex != pp.format_to_regex(fmt):
            raise AssertionError(
                'Expected "%s" but got "%s"'
                % (regex, pp.format_to_regex(fmt)))
    # Test with a single named group
    test('%(title)s', r'(?P<title>.+)',
         'The format "%(title)s" should be interpreted as regex "(?P<title>.+)"')
    # Test with multiple named groups

# Generated at 2022-06-24 14:17:44.274469
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .postprocessor import PostProcessor
    pp = MetadataFromTitlePP(None, "")
    assert pp.format_to_regex("%(title)s - %(artist)s") == "(?P<title>.+)\\ \\-\\ (?P<artist>.+)"

# Generated at 2022-06-24 14:17:48.635603
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    downloader = None
    assert MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')._titleregex == \
           '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'

# Generated at 2022-06-24 14:17:52.959256
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp.format_to_regex('%(title)s - %(artist)s') == (
        r'(?P<title>.+)\ \-\ (?P<artist>.+)')

# Generated at 2022-06-24 14:18:00.519614
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp._titleformat == '%(artist)s - %(title)s'
    assert pp._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'

    pp = MetadataFromTitlePP(None, 'a%(artist)s - %(title)s')
    assert pp._titleformat == 'a%(artist)s - %(title)s'
    assert pp

# Generated at 2022-06-24 14:18:05.319311
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    assert (pp.format_to_regex('%(title)s - %(artist)s')
            == '(?P<title>.+)\ \-\ (?P<artist>.+)')
    assert pp.format_to_regex('%(title)s - %(artist)s - %(title)s') == (
        '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<title>.+)'
    )
    assert pp.format_to_regex('%(title)s') == '(?P<title>.+)'


# Unit tests for class MetadataFromTitlePP

# Generated at 2022-06-24 14:18:15.126138
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    """
    Unit test for method format_to_regex of class MetadataFromTitlePP.
    """
    
    postprocessor = MetadataFromTitlePP(None, '')
    test_data = [
        ('%(title)s', '%(title)s'),
        ('%(author)s', '%(author)s'),
        ('%(artist)s', '%(artist)s'),
        ('%(album)s', '%(album)s'),
        ('%(uploader)s', '%(uploader)s'),
    ]
    for title_format, regex in test_data:
        title_regex = postprocessor.format_to_regex(title_format)

# Generated at 2022-06-24 14:18:17.298003
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    ydl = MetadataFromTitlePP(None, '%(title)s')
    ydl = MetadataFromTitlePP(None, '%(title)s - %(artist)s')

# Generated at 2022-06-24 14:18:20.395711
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp.format_to_regex('%(title)s') == r'(?P<title>.+)'



# Generated at 2022-06-24 14:18:29.876537
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    import tempfile

    config = {'outtmpl': tempfile.mkstemp()[1]}
    downloader = FileDownloader(config, {})
    postprocessor = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')


# Generated at 2022-06-24 14:18:36.520277
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    tests = (
        {'in': '%(title)s', 'out': r'(?P<title>.+)'},
        {'in': '%(title)s - %(artist)s', 'out': r'(?P<title>.+)\ \-\ (?P<artist>.+)'},
        {'in': '%(title)s - %(artist)s - %(album)s',
         'out': r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'},
    )
    mftpp = MetadataFromTitlePP(None, None)

    def assert_test(testdef):
        regex = mftpp.format_to_regex(testdef['in'])

# Generated at 2022-06-24 14:18:45.585443
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class FakeDownloader(object):
        def __init__(self):
            self.screen = []

        def to_screen(self, stuff):
            return self.screen.append(stuff)

    mp = MetadataFromTitlePP(FakeDownloader(), '%(title)s - %(artist)s')
    info = {'title': 'Test title - Test artist'}
    info = mp.run(info)[1]
    assert info['title'] == 'Test title'
    assert info['artist'] == 'Test artist'
    assert mp._downloader.screen == []

    mp = MetadataFromTitlePP(FakeDownloader(), '%(title)s - %(artist)s')
    info = {'title': 'Test title - Test artist - more stuff'}
    info = mp.run(info)[1]

# Generated at 2022-06-24 14:18:55.000013
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.compat import compat_etree_fromstring
    from youtube_dl.YoutubeDL import YoutubeDL
    mpp = MetadataFromTitlePP(YoutubeDL(), '%(title)s-%(artist)s')
    assert mpp is not None
    mpp = MetadataFromTitlePP(YoutubeDL(), '%(title)s')
    assert mpp is not None
    title = 'abcdef-ghijkl'
    info = {'title': title}
    metadata = (compat_etree_fromstring('''<ns0:tags xmlns:ns0="yt:bulk:upload"><ns0:tag>gdata_test=test</ns0:tag></ns0:tags>'''),)
    def to_screen(msg):
        pass
    mpp._downloader.to_screen

# Generated at 2022-06-24 14:18:59.688064
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    # test format_to_regex
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    # test run (this part only tests the regex)
    assert pp.run({'title': 'foo - bar'})[1] == {'title': 'foo', 'artist': 'bar'}

# Generated at 2022-06-24 14:19:11.344527
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from ytdl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({'format': 'bestaudio/best',
                     'postprocessors': [{
                         'key': 'MetadataFromTitle',
                         'titleformat': '%(artist)s - %(title)s'
                     }]})
    pp = ydl.get_postprocessor(None)
    assert pp.__class__ == MetadataFromTitlePP
    assert pp._titleformat == '%(artist)s - %(title)s'
    assert pp._titleregex == r'(?P<artist>.+)\ \-\ (?P<title>.+)'


# Generated at 2022-06-24 14:19:16.881033
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    fmt_regex_pairs = (
        ('%(title)s', '\(?P<title>\.\+\)?'),
        ('%(title)s - %(artist)s', '\(?P<title>\.\+\)\\\ \-\\\ \(?P<artist>\.\+\)?'),
        ('%(uploader)s - %(title)s [%(id)s]',
         '\(?P<uploader>\.\+\)\\\ \-\\\ \(?P<title>\.\+\)\\\ \[\(?P<id>\.\+\)?'),
        )
    for fmt, regex in fmt_regex_pairs:
        assert MetadataFromTitlePP.format_to_regex(fmt) == regex

# Generated at 2022-06-24 14:19:26.993843
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import subprocess
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor import get_info_extractor
    from .common import stdout_bytes_to_str

    def _get_test_titles():
        # Get test titles from dependency youtube_dl/extractor/common.py
        content = subprocess.check_output([sys.executable, '-c',
            'import extractor.common as M; print(M._TEST_TITLES)'],
            env=dict(PYTHONPATH=':'.join(sys.path)),
            universal_newlines=True)
        return eval(content)

    # Run unit test of method run of class MetadataFromTitlePP

# Generated at 2022-06-24 14:19:35.286869
# Unit test for constructor of class MetadataFromTitlePP

# Generated at 2022-06-24 14:19:40.671144
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    test_cases = [
        # (input, expected)
        ("%(title)s/%(artist)s", r'(?P<title>.+)/(?P<artist>.+)'),
        ("", r'^$'),
    ]
    for titleformat, regex in test_cases:
        assert MetadataFromTitlePP(None, titleformat)._titleregex == regex


# Generated at 2022-06-24 14:19:51.382460
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .downloader import YoutubeDL
    from .extractor import YoutubeIE
    from .extractor import ExtractorError
    from collections import OrderedDict as od

    # Test normal use of MetadataFromTitlePP
    # ======================================
    # Setup
    downloader = YoutubeDL()
    downloader.add_info_extractor(YoutubeIE())
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')

# Generated at 2022-06-24 14:19:58.338492
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s')._titleregex \
        == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, '%(title)s')._titleregex \
        == r'(?P<title>.+)'
    assert MetadataFromTitlePP(None, '%(title)s %(artist)s')._titleregex \
        == r'(?P<title>.+)\ (?P<artist>.+)'

# Generated at 2022-06-24 14:20:04.627878
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Test the regex creation
    regex = MetadataFromTitlePP.format_to_regex('%(title)s - %(artist)s')
    assert regex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    # Test the regex creation without named groups
    regex = MetadataFromTitlePP.format_to_regex('Video - Title')
    assert regex == r'Video\ \-\ Title'


# Generated at 2022-06-24 14:20:13.059992
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FakeInfoExtractor
    from .extractor import gen_extractor

    class FakeYoutubeIE(FakeInfoExtractor):
        _TITLE = 'Test - Title'

        def _real_extract(self, url):
            return {
                '_type': 'url_transparent',
                'url': url,
                'id': 'test_id',
                'title': self._TITLE,
            }

    ie = FakeYoutubeIE(gen_extractor(u'http://www.youtube.com/',
        FakeYoutubeIE))

    pp = MetadataFromTitlePP(None, '%(title)s')

# Generated at 2022-06-24 14:20:18.171786
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    _fromtitle = MetadataFromTitlePP(None, None)
    _format = '%(oink)s - %(foo)s - %(bar)s'
    _regex = r'(?P<oink>.+)\ \-\ (?P<foo>.+)\ \-\ (?P<bar>.+)'
    assert _fromtitle.format_to_regex(_format) == _regex

# Generated at 2022-06-24 14:20:27.386691
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mft = MetadataFromTitlePP(None, None)

    assert mft.format_to_regex('%(foo)s') == '(?P<foo>.+)'
    assert mft.format_to_regex('%(foo)s-%(bar)s') == '(?P<foo>.+)-(?P<bar>.+)'
    assert mft.format_to_regex('%(foo)s-%(bar)s-') == '(?P<foo>.+)-(?P<bar>.+)-'
    assert mft.format_to_regex('%(foo)s-%(bar)s%(baz)s') == '(?P<foo>.+)-(?P<bar>.+)%(baz)s'

# Generated at 2022-06-24 14:20:32.448616
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    assert MetadataFromTitlePP(None, '%(title)s')._titleregex.pattern == r'(?P<title>.+)'
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s')._titleregex.pattern == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-24 14:20:41.265121
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_str

    def test_helper(cls, input_, expected):
        downloader = YoutubeDL()
        downloader.to_screen = lambda x: None
        pp = cls(downloader, '%(title)s - %(artist)s')
        result = pp.run({'title': input_})
        if expected is None:
            assert result == ([], {})
        else:
            assert result == ([], {'title': expected[0], 'artist': expected[1]})

    test_helper(MetadataFromTitlePP, 'a', None)
    test_helper(MetadataFromTitlePP, 'a - b', ('a', 'b'))

# Generated at 2022-06-24 14:20:51.155924
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # Test some simple cases
    test_cases = [
        ('%(title)s', '(?P<title>.+)'),
        ('The title is: %(title)s', 'The title is: (?P<title>.+)'),
        ('%(title)s - %(artist)s', '(?P<title>.+)\ \-\ (?P<artist>.+)'),
    ]

    # Test a real case: format of the title from the postprocessor from the
    # "youtube" extractor
    youtube_extractor = YoutubeDL({}).extractors[0]