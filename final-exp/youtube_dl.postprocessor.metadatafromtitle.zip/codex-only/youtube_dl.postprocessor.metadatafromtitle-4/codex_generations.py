

# Generated at 2022-06-24 14:10:57.500400
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s')._titleregex == '(?P<title>.+) \- (?P<artist>.+)'
    assert MetadataFromTitlePP(None, '%(title)s')._titleregex == '(?P<title>.+)'
    assert MetadataFromTitlePP(None, 'test')._titleregex == 'test'
    assert MetadataFromTitlePP(None, 'test%(foo)s')._titleregex == 'test\%\(foo\)s'

# Generated at 2022-06-24 14:11:07.864139
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import PostProcessor
    pp = MetadataFromTitlePP(None, '%(a)s - %(b)s')
    assert pp.format_to_regex('test') == 'test'
    assert pp.format_to_regex('test %(f)s') == 'test\ (?P<f>.+)'
    assert pp.format_to_regex('%(a)s %(b)s') == '(?P<a>.+)\ (?P<b>.+)'
    assert pp.format_to_regex('%(a)s %(b)s %(a)s') == '(?P<a>.+)\ (?P<b>.+)\ (?P<a>.+)'

# Generated at 2022-06-24 14:11:16.907674
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    pp = MetadataFromTitlePP(None, 'Simple Title')
    assert pp._titleformat == 'Simple Title'
    assert pp._titleregex == 'Simple Title'

    pp = MetadataFromTitlePP(None, r'Simple/Title')
    assert pp._titleformat == r'Simple/Title'
    assert pp._titleregex == r'Simple\/Title'


# Generated at 2022-06-24 14:11:26.651293
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    def _setUp(self, titleformat):
        self._titleformat = titleformat
        self._titleregex = (self.format_to_regex(titleformat)
                            if re.search(r'%\(\w+\)s', titleformat)
                            else titleformat)

    def _run(self, title):
        info = { 'title': title }
        match = re.match(self._titleregex, title)
        if match is None:
            pass
        for attribute, value in match.groupdict().items():
            info[attribute] = value
        return info

    # Create a class that inherits from MetadataFromTitlePP and
    #

# Generated at 2022-06-24 14:11:30.836910
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftpp = MetadataFromTitlePP(None, None)
    res = mftpp.format_to_regex('%(title)s - %(artist)s')
    assert res == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'

# Generated at 2022-06-24 14:11:38.069564
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .extractor import YoutubeIE

    mp = MetadataFromTitlePP(YoutubeIE(), '%(title)s - %(artist)s')
    assert mp._titleregex == (
        r'(?P<title>.+)\ \-\ (?P<artist>.+)')
    mp = MetadataFromTitlePP(YoutubeIE(), '%(artist)s - %(title)s')
    assert mp._titleregex == (
        r'(?P<artist>.+)\ \-\ (?P<title>.+)')

# Generated at 2022-06-24 14:11:45.172676
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # pylint: disable=missing-docstring
    import sys
    import unittest
    import ydl_test_python
    sys.modules['ydl'] = ydl_test_python

    from ydl_test_python import (Downloader, FakeYDL)
    from postprocessor import MetadataFromTitlePP

    class Test(unittest.TestCase):
        def setUp(self):
            self.downloader = Downloader(FakeYDL())
            # pylint: disable=protected-access
            self.downloader.post_processors[0]._downloader = self.downloader

        def test_format_to_regex(self):
            # pylint: disable=protected-access
            ppp = MetadataFromTitlePP(None, '')

# Generated at 2022-06-24 14:11:55.128075
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from_title = MetadataFromTitlePP(None, '')
    assert from_title.format_to_regex('abc') == 'abc'
    assert from_title.format_to_regex('(?P<title>foo)') == '(?P<title>foo)'
    assert from_title.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert from_title.format_to_regex('%%(title)s') == '%%(title)s'
    assert from_title.format_to_regex(
        '%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-24 14:12:00.093211
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    m = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert m._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    m = MetadataFromTitlePP(None, '%(title)s')
    assert m._titleregex == '%(title)s'

# Generated at 2022-06-24 14:12:10.028795
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import unittest

    class FakeInfo(dict):
        def __init__(self, title):
            self['title'] = title

    class FakeYDL(object):
        def to_screen(self, msg):
            pass

        def report_error(self, msg):
            pass

    class TestMetadataFromTitlePP(unittest.TestCase):
        def test_constructor(self):
            fromtitle = MetadataFromTitlePP(FakeYDL(), '%(title)s')
            self.assertEqual(fromtitle._titleregex, r'(?P<title>.+)')

            fromtitle = MetadataFromTitlePP(FakeYDL(), r'%(title)s  -  %(artist)s')

# Generated at 2022-06-24 14:12:20.713071
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import mock, compat_urllib_request, compat_http_client
    import json
    import os

    # Mock-up the downloader
    ydl = mock.Mock()
    ydl.to_screen = mock.Mock()
    ydl.params = {
        'outtmpl': '%(title)s.%(ext)s',
        'writethumbnail': True,
        'writeinfojson': True,
    }

    # Mock-up the requests
    urlopen = mock.Mock()
    urlopen.return_value.__enter__ = lambda s: s
    urlopen.return_value.__exit__ = mock.Mock()

# Generated at 2022-06-24 14:12:27.280481
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    i = MetadataFromTitlePP(None, '%(title)s')
    assert '^(?P<title>.+)$' == i._titleregex

    i = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert '^(?P<title>.+)\ \-\ (?P<artist>.+)$' == i._titleregex

    i = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(album)s')
    assert '^(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)$' == i._titleregex

    i = MetadataFromTitlePP(None, '%(title)s - %(album)s - %(artist)s')


# Generated at 2022-06-24 14:12:32.253407
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    format = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(None, format)
    assert pp._titleformat == format
    assert pp._titleregex  == r'(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-24 14:12:35.845887
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # Test: Title format with only one field
    titleformat = '%(title)s'
    expected_regex = r'(?P<title>.+)'
    assert (expected_regex ==
            MetadataFromTitlePP.format_to_regex(titleformat))


# Generated at 2022-06-24 14:12:40.454204
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    ydl = object()
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    info = {'title': 'title - artist'}
    result = pp.run(info)

    assert result == ([], {'title': 'title - artist', 'artist': 'artist'})


# Generated at 2022-06-24 14:12:52.003432
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-24 14:13:02.203188
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    #pylint: disable=import-error
    #pylint: disable=maybe-no-member
    #pylint: disable=too-few-public-methods
    from youtube_dl.YoutubeDL import YoutubeDL
    class FakeInfo:
        pass
    class FakeYDL:
        def to_screen(self, mess):
            pass
        def extract_info(self, url):
            return FakeInfo
    # Create a temporary file to use for testing
    test_info = FakeInfo()
    test_info.title = 'Test title'
    test_info.title = 'Test title'
    test_info.artist = 'Test artist'
    test_info.album_artist = None
    test_info.album = 'Test album'
    test_info.track_number = '2'

# Generated at 2022-06-24 14:13:12.981663
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import tempfile
    import unittest
    import ydl_core

    class YDLDummy(ydl_core.YDL):

        def to_screen(self, *args, **kwargs):
            pass

    class TestMetadataFromTitlePP(unittest.TestCase):

        def setUp(self):
            self.ydl = YDLDummy()
            self.ydl.params = {}

        def test_format_to_regex(self):
            titleformat = '%(title)s - %(artist)s'
            titleregex = '(?P<title>.+) \- (?P<artist>.+)'
            self.assertEqual(
                MetadataFromTitlePP(self.ydl, titleformat)._titleregex, titleregex)


# Generated at 2022-06-24 14:13:22.696312
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .compat import mock
    from .downloader import Downloader
    from .postprocessor import PostProcessor

    def run(titleformat, expected):
        metadata_from_title_pp = MetadataFromTitlePP(
            mock.Mock(Downloader), titleformat)
        assert expected == metadata_from_title_pp._titleregex

    run('%(title)s - %(artist)s', '(?P<title>.+)\ \-\ (?P<artist>.+)')
    run('Trailer %(title)s-%(artist)s', r'Trailer\ (?P<title>.+)\-(?P<artist>.+)')
    run('Trailer %(title)s - %(artist)s', r'Trailer\ (?P<title>.+)\ \-\ (?P<artist>.+)')
   

# Generated at 2022-06-24 14:13:33.325456
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from ..YoutubeDL import YoutubeDL
    def _test(titleformat):
        ydl = YoutubeDL()
        pp = MetadataFromTitlePP(ydl, titleformat)
        ydl.to_screen = lambda x: None
        return pp
    # Test %(..)s
    pp = _test('%(title)s')
    assert pp._titleregex == '(?P<title>.+)'
    assert pp._titleformat == '%(title)s'
    # Test %x
    pp = _test('%(title)s %(a)s %(b)s')
    assert pp._titleregex == '(?P<title>.+) (?P<a>.+) (?P<b>.+)'
    assert pp._titleformat == '%(title)s %(a)s %(b)s'


# Generated at 2022-06-24 14:13:41.002677
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    PP = MetadataFromTitlePP(None, None)
    tests = [
        ('%(title)s - %(artist)s',
         r'(?P<title>.+)\ \-\ (?P<artist>.+)'),
        ('%(title)s', r'(?P<title>.+)'),
        ('%(title)s - %(artist)s - %(album)s',
         r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'),
    ]
    for i in range(len(tests)):
        fmt, regex = tests[i]
        assert PP.format_to_regex(fmt) == regex

# Generated at 2022-06-24 14:13:47.675667
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from collections import namedtuple
    from types import SimpleNamespace as ns

    from .common import Downloader
    from .postprocessor_run import FakeFile

    def test_case(title, titleformat, expected_output):
        # Fake a Downloader instance and register a FakeFile
        downloader = Downloader({})
        postprocessor = MetadataFromTitlePP(downloader, titleformat)
        test_input = namedtuple('TestInput', ['title', 'filename'])(
            title, 'test_file')
        postprocessor.run(test_input._asdict())
        assert downloader.file_downloaded == expected_output

    # Successful parsing
    def parse_title(title):
        # extract the title
        return title.split(' - ', 1)[0]


# Generated at 2022-06-24 14:13:48.246129
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass # TODO

# Generated at 2022-06-24 14:13:55.715513
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    PP = MetadataFromTitlePP('testdownloader', '%(title)s - %(artist)s')
    info = {'title': 'test - testartist'}
    _, info_after_pp = PP.run(info)
    assert info_after_pp['title'] == 'test'
    assert info_after_pp['artist'] == 'testartist'

if __name__ == '__main__':
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-24 14:13:59.715517
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    fmt = '%(title)s - %(artist)s'
    p = MetadataFromTitlePP(None, fmt)
    assert p._titleformat == fmt
    assert p._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'



# Generated at 2022-06-24 14:14:05.585502
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    m = MetadataFromTitlePP(None, None)
    assert m.format_to_regex('%(category)s/%(name)s - %(date)s - %(time)s.%(ext)s') == \
        '(?P<category>.+)/(?P<name>.+)\ \-\ (?P<date>.+)\ \-\ (?P<time>.+)\.(?P<ext>.+)'
    assert m.format_to_regex('%(category)s/%(name)s - %(date)s.%(ext)s') == \
        '(?P<category>.+)/(?P<name>.+)\ \-\ (?P<date>.+)\.(?P<ext>.+)'

# Generated at 2022-06-24 14:14:10.837274
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, "Foo - %(artist)s - %(song)s")
    assert pp._titleformat == "Foo - %(artist)s - %(song)s"
    assert pp._titleregex == '(Foo\ \-\ )(?P<artist>.+)\ \-\ (?P<song>.+)'


if __name__ == '__main__':
    test_MetadataFromTitlePP()

# Generated at 2022-06-24 14:14:21.038843
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    metadata_from_title_PP = MetadataFromTitlePP({'format': '%(author)s'}, '')
    assert metadata_from_title_PP.format_to_regex('%(author)s') == '(?P<author>.+)'
    assert metadata_from_title_PP.format_to_regex('%(title)s - %(author)s') == '(?P<title>.+)\ \-\ (?P<author>.+)'
    assert metadata_from_title_PP.format_to_regex('%(title)s - %(author)s - %(id)s') == '(?P<title>.+)\ \-\ (?P<author>.+)\ \-\ (?P<id>.+)'

# Generated at 2022-06-24 14:14:27.246218
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Simple match without groups
    pp = MetadataFromTitlePP(None, 'title')
    assert pp._titleregex == 'title'

    # Simple match with groups
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    # No match
    pp = MetadataFromTitlePP(None, 'title - artist')
    assert pp._titleregex == 'title\ \-\ artist'

# Generated at 2022-06-24 14:14:36.743191
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import sys

    # Unicode literals are not defined in Python 2.5,
    # so encode the test string in Latin-1.
    if sys.version_info[0] == 2 and sys.version_info[1] == 5:
        test_template = u'%(title)s, %(artist)s - %(album)s'.encode('Latin-1')
        test_title = u'Hello, World! - My Album'.encode('Latin-1')
        after_title = u'Hello, World! - My Album'.encode('Latin-1')
        after_artist = u'World'.encode('Latin-1')
        after_album = u'My Album'.encode('Latin-1')

# Generated at 2022-06-24 14:14:44.838289
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    ydl = MockYDL()
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    info = {'title': 'Wake Me Up - Avicii'}
    einfo = {'title': 'Wake Me Up', 'artist': 'Avicii'}
    extrainfo = {}
    pp.run(info)
    assert info == einfo
    assert extrainfo == {}

    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s - %(year)s')
    info = {'title': 'Wake Me Up - Avicii - 2013'}
    einfo = {'title': 'Wake Me Up', 'artist': 'Avicii', 'year': '2013'}
    pp.run(info)


# Generated at 2022-06-24 14:14:51.110171
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys

    def mock_downloader(screen_out):
        def _write_string(message):
            if sys.version_info >= (3, 0):
                screen_out.update({'result': screen_out['result'] + message + '\n'})
            else:
                screen_out.update({'result': screen_out['result'] + message.decode('utf-8') + '\n'})

        class downloader(object):
            def to_screen(self, message):
                _write_string(message)

            def to_stderr(self, message):
                _write_string(message)

        return downloader()

    # Test a simple title
    info = {'title': 'Test title'}

    titleformat = '%(title)s'

# Generated at 2022-06-24 14:14:56.350661
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.youtube import YoutubeIE

    # Input data
    test_input = [{
        'title': '- Artist - Title',
        'ext': 'mp3',
    }]
    # Expected results
    test_expected = [{
        'artist': 'Artist',
        'title': 'Title',
        'ext': 'mp3',
    }]

    downloader = YoutubeDL({'quiet': True,
                            'no_warnings': True,
                            'titleformat': '%(artist)s - %(title)s'})
    downloader.add_info_extractor(YoutubeIE())
    downloader.add_post_processor(MetadataFromTitlePP(downloader, downloader.params['titleformat']))
    results

# Generated at 2022-06-24 14:15:05.050932
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, "")

# Generated at 2022-06-24 14:15:15.939136
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-24 14:15:20.962950
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    class FakeDownloader():
        verbose = False
        def to_screen(param):
            pass

    downloader = FakeDownloader()

    titleformat = '%(title)s - %(artist)s'
    titleregex = (r'(?P<title>.+)\ \-\ (?P<artist>.+)'
                  if re.search(r'%\(\w+\)s', titleformat)
                  else titleformat)
    pp = MetadataFromTitlePP(downloader, titleformat)

    assert pp._titleformat == titleformat
    assert pp._titleregex == titleregex


# Generated at 2022-06-24 14:15:32.182077
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    mp4_downloader = None
    mp4_titleformat = '%(title)s + %(artist)s'
    mp4_titleregex = '(?P<title>.+)\ \+\ (?P<artist>.+)'
    mp4 = MetadataFromTitlePP(mp4_downloader, mp4_titleformat)
    assert mp4._titleformat == mp4_titleformat
    assert mp4._titleregex == mp4_titleregex

    test_titleformat = '%(title)s - %(artist)s - %(album)s'
    test_titleregex = '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'
    test = MetadataFromTitlePP(mp4_downloader, test_titleformat)
    assert test

# Generated at 2022-06-24 14:15:39.484596
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    test_cases = {
        '%(title)s - %(artist)s': r'(?P<title>.+)\ \-\ (?P<artist>.+)',
        '%(artist)s - %(album)s': r'(?P<artist>.+)\ \-\ (?P<album>.+)',
        '%(title)s': r'(?P<title>.+)',
    }
    pp = MetadataFromTitlePP(None, '%(title)s')
    for titleformat, expected in test_cases.items():
        result = pp.format_to_regex(titleformat)
        assert result == expected

# Generated at 2022-06-24 14:15:51.580666
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    obj = MetadataFromTitlePP(None, 'meta')
    assert obj.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert obj.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert obj.format_to_regex('%(title)s - %(artist)s - %(album)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'

# Generated at 2022-06-24 14:15:58.803935
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .Extractor import gen_extractors
    from .downloader import YoutubeDL
    pp = MetadataFromTitlePP(YoutubeDL({}, gen_extractors()), '%(title)s')
    assert pp.format_to_regex('a%% %(title)s b%(id)s%%') == 'a%\ \\(?P<title>.+\\)\ b\\(?P<id>.+\\)%'

# Generated at 2022-06-24 14:16:08.382975
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl
    class DummyYoutubedl(object):
        def to_screen(self, *args):
            pass
    #

# Generated at 2022-06-24 14:16:18.191138
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    print("MetadataFromTitlePP.test_MetadataFromTitlePP()")

    downloader = None
    titleformat = '%(artist)s - %(title)s'
    pp = MetadataFromTitlePP(downloader, titleformat)
    assert '%(title)s' == pp._titleformat
    assert '%(artist)s\ \-\ %(title)s' == pp._titleregex

    titleformat = '%(album)s'
    pp = MetadataFromTitlePP(downloader, titleformat)
    assert '%(album)s' == pp._titleformat
    assert '%(album)s' == pp._titleregex

    titleformat = '%(album)s - %(track)s - %(title)s - %(artist)s'

# Generated at 2022-06-24 14:16:21.600592
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    m = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert(r'(?P<title>.+)\ \-\ (?P<artist>.+)' == m._titleregex)
    return True


# Generated at 2022-06-24 14:16:29.382709
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    metadata_from_title_pp = MetadataFromTitlePP(None, None)

    assert metadata_from_title_pp.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert metadata_from_title_pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert metadata_from_title_pp.format_to_regex('[%(artist)s] %(title)s') == r'\[(?P<artist>.+)\]\ (?P<title>.+)'

# Generated at 2022-06-24 14:16:35.559746
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():

    metadata_from_titlepp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert metadata_from_titlepp._titleformat == '%(title)s - %(artist)s'
    assert metadata_from_titlepp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    metadata_from_titlepp = MetadataFromTitlePP(None, '%(title)s')
    assert metadata_from_titlepp._titleformat == '%(title)s'
    assert metadata_from_titlepp._titleregex == '(?P<title>.+)'


# Generated at 2022-06-24 14:16:44.263414
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    m = MetadataFromTitlePP(None, None)
    assert m.format_to_regex(r'%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert m.format_to_regex(r'%(title)s - %(artist)s - %(album)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'
    assert m.format_to_regex(r'%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-24 14:16:49.550998
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    downloader = {}
    x = MetadataFromTitlePP(downloader, '')

    assert x.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert x.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert x.format_to_regex('%(artist)s - %(title)s') == '(?P<artist>.+)\ \-\ (?P<title>.+)'
    assert x.format_to_regex('%(abc)s - %(def)s - %(ghi)s') == '(?P<abc>.+)\ \-\ (?P<def>.+)\ \-\ (?P<ghi>.+)'

# Generated at 2022-06-24 14:16:58.053475
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FakeYDL
    from .common import FileDownloader
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_id, ie_name, ie_description=None):
            super(FakeInfoExtractor, self).__init__(gen_extractors())
            self.ie_id = ie_id
            self.ie_name = ie_name
            self.ie_description = ie_description


# Generated at 2022-06-24 14:17:08.585614
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert (MetadataFromTitlePP(None, '').format_to_regex('')
            == '')
    assert (MetadataFromTitlePP(None, '%(title)s - %(artist)s').format_to_regex(
                '%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)')
    assert (MetadataFromTitlePP(None, '%(title)s - %(artist)s').format_to_regex(
                '%(artist)s - %(title)s') == '(?P<artist>.+)\ \-\ (?P<title>.+)')

# Generated at 2022-06-24 14:17:16.794252
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Exact match test
    titleformat = '%(title)s - %(artist)s'
    titleformat_exact_regex = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    titleformat_regex = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    title = 'Video Title - Video Artist'
    test_title_match = re.match(titleformat_exact_regex, title)
    assert test_title_match is not None
    assert test_title_match.groupdict() == {
        'title': 'Video Title',
        'artist': 'Video Artist'
    }
    # test_mdft = MetadataFromTitlePP(titleformat)
    # assert test_mdft._titleformat == titleformat
    # assert test_md

# Generated at 2022-06-24 14:17:24.036452
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    class DummyDownloader:
        def to_screen(self, msg):
            pass

    # no regex in titleformat => no regex in titleregex
    pp = MetadataFromTitlePP(DummyDownloader(), 'test1234')
    assert isinstance(pp._titleregex, str)
    assert pp._titleregex == 'test1234'

    # regex in titleformat => regex in titleregex
    pp = MetadataFromTitlePP(DummyDownloader(), '%(id)s: %(title)s')
    assert isinstance(pp._titleregex, str)
    assert pp._titleregex == '(?P<id>.+): (?P<title>.+)'

# Generated at 2022-06-24 14:17:33.776626
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import pytest
    MetadataPP = MetadataFromTitlePP

    # these tests are too unspecific to be covered  by the code coverage
    # tool, therefore their coverage is ignored
    # pylint: disable=W0612

    # they are also too simple to really benefit from unit tests, but
    # since they are invoked by the main unit test, we do it anyway
    # pylint: disable=R0201


# Generated at 2022-06-24 14:17:41.014565
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():

    title_format = '%(title)s-%(site)s'
    mft = MetadataFromTitlePP(None, title_format)
    assert mft._titleformat == title_format
    assert mft._titleregex == '(?P<title>.+)-(?P<site>.+)'

    title_format = '%(title)s'
    mft = MetadataFromTitlePP(None, title_format)
    assert mft._titleformat == title_format
    assert mft._titleregex == '(?P<title>.+)'



# Generated at 2022-06-24 14:17:49.138555
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            self.to_screen_calls = []
            super(FakeYDL, self).__init__(*args, **kwargs)

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)

    ydl = FakeYDL({})
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s'))

    info = {
        'title': 'Video Title',
    }

    ydl.process_ie_result(info, None)
    assert info == {
        'title': 'Video Title',
    }

# Generated at 2022-06-24 14:17:57.965731
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.downloader.YoutubeDL import YoutubeDL
    # Test 1 : simple case
    pp = MetadataFromTitlePP(YoutubeDL(), '%(artist)s - %(title)s')
    res = pp.run({'title' : 'Lorde - Royals'})
    assert res[1]['title'] == 'Royals'
    assert res[1]['artist'] == 'Lorde'
    # Test 2 : %(...)s not in order
    pp = MetadataFromTitlePP(YoutubeDL(), '%(title)s (by %(artist)s)')
    res = pp.run({'title' : 'Royals (by Lorde)'})
    assert res[1]['title'] == 'Royals'
    assert res[1]['artist'] == 'Lorde'
    # Test 3 : %

# Generated at 2022-06-24 14:18:09.015452
# Unit test for constructor of class MetadataFromTitlePP

# Generated at 2022-06-24 14:18:13.197821
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    expected = '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'
    assert pp._titleregex == expected


# Generated at 2022-06-24 14:18:19.344525
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import FileDownloader

    pp = MetadataFromTitlePP(FileDownloader(), '')
    assert pp.format_to_regex('%(title)s - %(artist)s') == (
        r'(?P<title>.+)\ \-\ (?P<artist>.+)')
    assert pp.format_to_regex('%(title)s - %(artist)s [%(album)s]') == (
        r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \[(?P<album>.+)\]')

# Generated at 2022-06-24 14:18:28.895399
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest
    import sys
    import os
    import ydl_opts
    import ydl

    class DummyDown(ydl.YoutubeDL):
        def __init__(self, params={}):
            for key, val in params.items():
                setattr(self, key, val)

        def to_screen(self, msg, *args):
            sys.stdout.write(msg % args)

    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.fmt = r'%(title)s - %(artist)s'
            self.title = r'My Title - My Artist'
            self.down = DummyDown(ydl_opts.params)
            self.down.params['dump_single_json'] = True
            self

# Generated at 2022-06-24 14:18:35.337033
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(blubb)s')
    assert pp._titleformat == '%(title)s - %(artist)s - %(blubb)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<blubb>.+)'
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    pp = MetadataFromTitlePP(None, 'no metadata in title')

# Generated at 2022-06-24 14:18:36.535100
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 14:18:45.584490
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    test_formats = [
        ('%(title)s - %(artist)s',
         '(?P<title>.+)\ \-\ (?P<artist>.+)'),
        ('Test %(title)s',
         'Test\ (?P<title>.+)'),
        ('%(title)s - test',
         '(?P<title>.+)\ \-\ test'),
        ('%(title)s%(title)s',
         '(?P<title>.+)(?P<title>.+)'),
        ('%(title)s %%(title)s',
         '(?P<title>.+)\ \%\(title\)s'),
    ]

    for fmt, regex in test_formats:
        assert MetadataFromTitlePP.format_to_regex(fmt) == regex

# Generated at 2022-06-24 14:18:52.254165
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # example of input string:
    # "%(artist)s - %(title)s"
    #
    # example of output regex:
    # "(?P<artist>.+)\ \-\ (?P<title>.+)"
    #
    pp = MetadataFromTitlePP(None, "%(artist)s - %(title)s")
    assert pp.format_to_regex("%(artist)s - %(title)s") == "(?P<artist>.+)\ \-\ (?P<title>.+)"

# Generated at 2022-06-24 14:18:54.798228
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    titleformat = '%(artist)s - %(title)s'
    from youtube_dl.downloader import Downloader
    from youtube_dl.YoutubeDL import YoutubeDL

# Generated at 2022-06-24 14:18:57.839465
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    metadata_from_title = MetadataFromTitlePP(None, '%(artist)s-%(title)s')
    regex = '(?P<artist>.+)\-(?P<title>.+)'
    assert metadata_from_title._titleregex == regex


# Generated at 2022-06-24 14:19:09.179013
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest
    class FakeConfig():
        def __init__(self,name,value):
            self.name = name
            self.value = value
        def get(self,section,option):
            if section == 'General' and option == self.name:
                return self.value

    class FakeYDL():
        def __init__(self,value):
            self.value = value
        def to_screen(self,value):
            if value == self.value:
                return
        def postproc(self):
            return []

    class MetadataFromTitlePPTestCase(unittest.TestCase):
        def setUp(self):
            self.downloader = FakeYDL('[fromtitle] Could not interpret title of video as "Foo"')
            self.metadata = ['run']

# Generated at 2022-06-24 14:19:16.132226
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Unit test for method run of class MetadataFromTitlePP
    title = r'The Last of Us Part II - First Look Trailer'
    # Note below that the attribute title will be parsed but not used,
    #  that is, the attribute will not be stored in the dictionary info
    titleformat = r'%(title)s - %(game)s'
    regex = (
        r'(?P<title>.+)\ \-\ (?P<game>.+)'
    )
    match = re.match(regex, title)
    assert match is not None
    info = {}
    for attribute, value in match.groupdict().items():
        info[attribute] = value
    assert 'game' in info

# Generated at 2022-06-24 14:19:25.591178
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP('dummy', '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '(?P<title>.+)'

    pp = MetadataFromTitlePP('dummy', 'test_string')
    assert pp._titleformat == 'test_string'
    assert pp._titleregex == 'test_string'

    pp = MetadataFromTitlePP('dummy', '%(title)s-%(artist)s')
    assert pp._titleformat == '%(title)s-%(artist)s'
    assert pp._titleregex == '(?P<title>.+)\-(?P<artist>.+)'


# Generated at 2022-06-24 14:19:33.901065
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    """
    Unit test for constructor of class MetadataFromTitlePP.
    """
    # Test for titleformat as regex
    titleformat = r'%(title)s - %(artist)s'
    titleregex = r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    mftpp = MetadataFromTitlePP(None, titleformat)
    assert mftpp._titleformat == titleformat
    assert mftpp._titleregex == titleregex

    # Test for titleformat without %(..)s
    titleformat = r'abc - 123'
    titleregex = r'abc\ -\ 123'
    mftpp = MetadataFromTitlePP(None, titleformat)
    assert mftpp._titleformat == titleformat
    assert mftpp._titleregex == titleregex


# Generated at 2022-06-24 14:19:43.860446
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class dummy_downloader():
        title = 'A dummy downloader'

        def to_screen(self, string):
            return

    # we need an object to be able to instantiate PostProcessor
    class dummy_pp():
        def __init__(self, downloader):
            self.downloader = downloader
            self.info = {
                        'title' : 'Parsed title. Artist - Album'
                    }

    instance = MetadataFromTitlePP(dummy_downloader(), '%(title)s - Artist - Album')
    instance.run(dummy_pp(dummy_downloader()).info)

# Generated at 2022-06-24 14:19:46.767288
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mft = MetadataFromTitlePP(None, None)
    assert mft.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'


# Generated at 2022-06-24 14:19:50.559834
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, "%(title)s")  # dummy downloader is not used
    assert pp._titleformat == "%(title)s"
    assert pp._titleregex == "(?P<title>.+)"
    pp = MetadataFromTitlePP(None, "%(title)s - %(artist)s")
    assert pp._titleformat == "%(title)s - %(artist)s"
    assert pp._titleregex == "(?P<title>.+)\ \-\ (?P<artist>.+)"


# Generated at 2022-06-24 14:19:55.619062
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    # test instantiation
    # EXCEPTION-SAFE CODE
    try:
        pp = MetadataFromTitlePP(None, '%(title)s-%(artist)s')
    except Exception:
        # if instantiation fails, we can't continue with testing
        assert False
    # EXCEPTION-SAFE CODE

    # test extracting all metadata
    info = {'title': 'title-artist-album-track'}
    pp.run(info)
    assert info == {'title': 'title-artist-album-track', 'title': 'title', 'artist': 'artist', 'track': 'track'}

    # test extracting partial metadata
    info = {'title': 'title-artist'}
    pp.run(info)

# Generated at 2022-06-24 14:20:04.761500
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    eq_(
        pp.format_to_regex('%(title)s - %(artist)s'),
        r'(?P<title>.+)\ \-\ (?P<artist>.+)')
    eq_(
        pp.format_to_regex('%(title)s'),
        r'(?P<title>.+)')
    eq_(
        pp.format_to_regex('My title: %(title)s'),
        r'My title:\ (?P<title>.+)'
    )

if __name__ == '__main__':
    import nose
    nose.core.runmodule()

# Generated at 2022-06-24 14:20:13.133885
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '(?P<title>.+)'
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp._titleformat == '%(artist)s - %(title)s'
    assert pp._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'
    pp = MetadataFromTitlePP(None, 'Foobar - %(title)s - %(artist)s')
    assert pp._titleformat == 'Foobar - %(title)s - %(artist)s'

# Generated at 2022-06-24 14:20:24.282054
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .downloader import FakeYDL
    downloader = FakeYDL()
    ydl = downloader.ydl
    pp = MetadataFromTitlePP(downloader, '%(artist)s - %(title)s')
    title = 'Billie Eilish - ocean eyes'
    assert pp.run({'title': title}) == ([], {'title': title, 'artist': 'Billie Eilish', 'title': 'ocean eyes'})
    pp = MetadataFromTitlePP(downloader, '%(title)s')
    title = 'ocean eyes'
    assert pp.run({'title': title}) == ([], {'title': title, 'title': 'ocean eyes'})
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(track_number)s')

# Generated at 2022-06-24 14:20:34.472095
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    downloader = FakeYDL()

    # case 1: %(title)s - %(artist)s
    titleformat = '%(title)s - %(artist)s'
    title = 'title - artist'
    info = {'title': title}
    pp = MetadataFromTitlePP(downloader, titleformat)
    # title must be untouched, artist must be parsed from title
    assert titleformat == pp._titleformat
    assert pp._titleregex == 'title\ \-\ artist'
    assert title == info['title']
    assert 'artist' not in info
    assert pp.run(info) == ([], {'title': 'title', 'artist': 'artist'})

    # case 2: %(title)s - %(artist)s
    titleformat = '%(title)s - %(artist)s'


# Generated at 2022-06-24 14:20:42.661442
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import os
    import pytest
    from .common import FileDownloader
    from .extractor import get_info_extractor

    # A dummy file downloader object
    class DummyFileDownloader(FileDownloader):
        def __init__(self, params, outtmpl='test_%(id)s.%(ext)s'):
            super(DummyFileDownloader, self).__init__(params, outtmpl)
            self.to_screen_calls = []

        def to_screen(self, message):
            self.to_screen_calls.append('[fromtitle] ' + message)

        def download(self, url_list):
            assert url_list == []
            return True


    # A function to test the run method

# Generated at 2022-06-24 14:20:47.935380
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    def check(titleformat, titleregex):
        pproc = MetadataFromTitlePP(None, titleformat)
        assert pproc._titleformat == titleformat
        assert pproc._titleregex == titleregex

    check('%(title)s', r'(?P<title>.+)')
    check(r'%(title)s', r'(?P<title>.+)')
    check('%(title)s - %(artist)s', r'(?P<title>.+)\ \-\ (?P<artist>.+)')
    check('%(title)s \- %(artist)s', r'(?P<title>.+)\ \-\ (?P<artist>.+)')

# Generated at 2022-06-24 14:20:57.517068
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.JsInterpreter import JSInterpreter
    jsi = JSInterpreter(YoutubeDL())
    downloader = jsi.downloader
    downloader_dummy = YoutubeDL(
        params={'continuedl': True, 'nooverwrites': True, 'quiet': True, 'simulate': True})

    mf = MetadataFromTitlePP(downloader, "%(title)s - %(artist)s")
    mf.run({'title': 'tit - art', 'webpage_url': 'http://www.youtube.com/watch?v=videoid'})