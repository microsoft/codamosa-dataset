

# Generated at 2022-06-24 14:10:55.148408
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .downloader import FakeYDL
    md_pp = MetadataFromTitlePP(FakeYDL(), 'xxx')
    assert md_pp.format_to_regex('abc') == r'abc'
    assert md_pp.format_to_regex('%(abc)s') == r'(?P<abc>.+)'
    assert md_pp.format_to_regex('%(abc)s%(def)s') == r'(?P<abc>.+)(?P<def>.+)'
    assert md_pp.format_to_regex('%(abc)sx%(def)s') == r'(?P<abc>.+)x(?P<def>.+)'
    assert md_pp.format_to_regex('%(abc)s%(def)sy%(ghi)s')

# Generated at 2022-06-24 14:11:00.053202
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    metadata_from_title = MetadataFromTitlePP(None, None)
    assert metadata_from_title.format_to_regex(
        '%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert metadata_from_title.format_to_regex('some_title') == r'some_title'

# Generated at 2022-06-24 14:11:09.830269
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .extractor.common import Downloader
    from .compat import str

    downloader = Downloader(None)

    # Some tests for the conversion from format string to regex
    assert MetadataFromTitlePP(downloader, '%(title)s')._titleregex == '(?P<title>.+)'
    assert MetadataFromTitlePP(downloader, '%(title)s abcd')._titleregex == '(?P<title>.+)\ abcd'
    assert MetadataFromTitlePP(downloader, 'abcd %(title)s')._titleregex == 'abcd\ (?P<title>.+)'
    assert MetadataFromTitlePP(downloader, 'abcd %(title)s xyz')._titleregex == 'abcd\ (?P<title>.+)\ xyz'

    # Some tests for the extraction

# Generated at 2022-06-24 14:11:20.529509
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import tempfile
    old_stderr = sys.stderr
    temp = tempfile.TemporaryFile()
    sys.stderr = temp
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp._titleformat == '%(artist)s - %(title)s'
    assert pp._titleregex == r'(?P<artist>.+)\ \-\ (?P<title>.+)'
    title_video1_info = {'title': 'artist2 - title2'}
    # If a metadata title format is defined, the information in it
    # are added to the video_info
    assert pp.run(title_video1_info) == ([], {'artist': 'artist2', 'title': 'title2'})
    #

# Generated at 2022-06-24 14:11:24.412571
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')

    expected_titleregex = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp._titleregex == expected_titleregex


# Generated at 2022-06-24 14:11:31.105788
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    m4tpp = MetadataFromTitlePP(None, '')
    assert m4tpp.format_to_regex("%(title)s") == "(?P<title>.+)"
    assert m4tpp.format_to_regex("%(title)s - %(artist)s") == "(?P<title>.+) - (?P<artist>.+)"
    assert m4tpp.format_to_regex("%(title)s %(artist)s") == "(?P<title>.+) (?P<artist>.+)"
    assert m4tpp.format_to_regex("%%%(title)s%(artist)s") == "%(?P<title>.+)(?P<artist>.+)"

# Generated at 2022-06-24 14:11:40.861811
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import fake_info_dict
    info = fake_info_dict()
    # test format of three groups
    titleformat = '%(title)s - %(artist)s - %(album)s'
    # test that title is parsed correctly
    title = 'Title - Artist - Album'
    info = fake_info_dict({'title': title})
    test_pp = MetadataFromTitlePP(None, titleformat)
    result = test_pp.run(info)[1]
    assert result['title'] == 'Title'
    assert result['artist'] == 'Artist'
    assert result['album'] == 'Album'
    # test that title is not parsed correctly
    title = 'Title - Artist'
    info = fake_info_dict({'title': title})

# Generated at 2022-06-24 14:11:49.129184
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Variable that will be used to test run(info) method
    info = {'title': 'test_content'}

    # Variable that will be used as downloader in __init__ method call
    downloader = {'to_screen': (lambda message:
                                test_print('to_screen', message))}

    # Variable that will be used as titleformat in __init__ method call
    titleformat = '%(content)s'

    # Object under method test
    metadata_from_title_pp = MetadataFromTitlePP(
        downloader, titleformat)

    # Test case when regex of object can not find value of content attribute
    titleformat = '%(content)s'
    metadata_from_title_pp = MetadataFromTitlePP(
        downloader, titleformat)

# Generated at 2022-06-24 14:11:53.229794
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    d = lambda: None
    d.to_screen = lambda s: s
    mft = MetadataFromTitlePP(d, '%(title)s - %(artist)s')
    assert mft.run({'title': 'test - test'}) == ([], {'title': 'test', 'artist': 'test'})

# Generated at 2022-06-24 14:11:57.387284
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .common import FileDownloader

    # Create object
    dl = FileDownloader({})
    pp = MetadataFromTitlePP(dl, '%(title)s')
    dl.add_post_processor(pp)

    # Check that it didn't blow up
    assert isinstance(dl, FileDownloader)
    assert isinstance(pp, MetadataFromTitlePP)
    assert dl._post_processors == [pp]


# Generated at 2022-06-24 14:12:06.681667
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    testcases = {
        '%(title)s - %(artist)s': r'(?P<title>.+)\ \-\ (?P<artist>.+)',
        'Just a video title': r'Just\ a\ video\ title',
        'Just %(test)s': r'Just\ (?P<test>.+)',
        '%(test)s': r'(?P<test>.+)',
        '': r'',
    }
    pp = MetadataFromTitlePP(None, '%(title)s')
    for fmt, expected in testcases.items():
        actual = pp.format_to_regex(fmt)
        assert actual == expected


# Generated at 2022-06-24 14:12:14.933936
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import youtube_dl
    from youtube_dl.utils import sanitize_filename

    test_cases = [
        {
            'format': '%(uploader)s uploaded on %(upload_date)s the video %(title)s',
            'title': 'Foo uploader uploaded on 2017-03-07 the video Foo',
            'expected_regex': 'Foo\ uploader\ uploaded\ on\ 2017\-03\-07\ the\ video\ Foo',
        },
        {
            'format': '%(uploader)s - %(title)s [%(id)s]',
            'title': 'Foo - Foo [foobar]',
            'expected_regex': 'Foo\ \-\ Foo\ \[foobar\]',
        }
    ]


# Generated at 2022-06-24 14:12:21.855206
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class FakeDownloader():
        def to_screen(self, msg):
            print(msg)

    info = {'title' : 'a - b'}
    ydl = FakeDownloader()
    pp = MetadataFromTitlePP(ydl, '%(a)s - %(b)s')

    assert info == pp.run(info)[1]

    info = {'title': 'ab'}
    pp = MetadataFromTitlePP(ydl, '%(a)s - %(b)s')

    assert info == pp.run(info)[1]

# Generated at 2022-06-24 14:12:25.105251
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from youtube_dl.postprocessor import MetadataFromTitlePP
    expected = '(?P<artist>.+)\ \-\ (?P<title>.+)'
    actual = MetadataFromTitlePP(None, '%(artist)s - %(title)s')._titleregex
    assert expected == actual



# Generated at 2022-06-24 14:12:35.808794
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    tftpp = MetadataFromTitlePP(None, None)
    testcases = [
        ('%(title)s - %(artist)s', '(?P<title>.+)\ \-\ (?P<artist>.+)'),
        ('%(title)s', '(?P<title>.+)'),
        ('%(title)s - ', '(?P<title>.+)\ \-\ '),
        ('aa %(title)s bb', 'aa\ (?P<title>.+)\ bb'),
        ('[%(title)s]', '\[(?P<title>.+)\]'),
        ('%(title)s - %(artist)s - %(title)s', '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<title>.+)')
    ]

# Generated at 2022-06-24 14:12:43.933506
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    test_format_to_regex_pairs = [
        ('%(title)s', '(?P<title>.+)'),
        ('- %(artist)s -', '-\ (?P<artist>.+)\ -'),
        ('%(title)s - %(artist)s', '(?P<title>.+)\ \-\ (?P<artist>.+)'),
        ('%(title)s- %(artist)s', '(?P<title>.+)-\ (?P<artist>.+)'),
    ]
    for test_pair in test_format_to_regex_pairs:
        fmt, regex = test_pair
        assert MetadataFromTitlePP.format_to_regex(fmt) == regex

# Generated at 2022-06-24 14:12:50.551851
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    fmt = '[%(artist)s] %(title)s  %(album)s (%(year)s)'
    regex = r'\[(?P<artist>.+)\]\ (?P<title>.+)\ (?P<album>.+)\ \((?P<year>.+)\)'

    assert MetadataFromTitlePP(None, fmt).format_to_regex(fmt) == regex

# Generated at 2022-06-24 14:12:59.040716
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Create test object
    ffmpeg_titleformat = '%(title)s - %(artist)s'
    MetadataFromTitlePP_object = MetadataFromTitlePP(None, ffmpeg_titleformat)

    # Test all results of method run
    test_title = 'abcde - fghij'
    expected = {'title': 'abcde', 'artist': 'fghij'}
    assert MetadataFromTitlePP_object.run({'title': test_title})[1] == expected

    test_title = 'something else'
    expected = {}
    assert MetadataFromTitlePP_object.run({'title': test_title})[1] == expected

    ffmpeg_titleformat = '%(title)s - %(artist)s - %(album)s'
    MetadataFromTitlePP_object = MetadataFrom

# Generated at 2022-06-24 14:13:03.052328
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    fmt = '%(title)s - %(artist)s'
    regex = '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'
    mpp = MetadataFromTitlePP(None, fmt)
    assert(mpp.format_to_regex(fmt) == regex)


# Generated at 2022-06-24 14:13:13.596700
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # test single group
    pp = MetadataFromTitlePP(None, '%(title)s')
    # regex matches no group
    assert pp.run({'title': ''}) == ([], {})
    # regex matches group
    assert pp.run({'title': 'a'}) == ([], {'title': 'a'})

    # test multiple groups
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    # regex matches groups
    assert pp.run({'title': 'a', 'artist': 'b'}) == ([], {'title': 'a', 'artist': 'b'})
    assert pp.run({'title': 'a - b', 'artist': 'c - d'}) == ([], {'title': 'a', 'artist': 'b'})
    # regex matches

# Generated at 2022-06-24 14:13:23.072005
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-24 14:13:33.325427
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    for (format, expected) in [('%(title)s', r'(?P<title>.+)'),
                               ('%(title)s - %(artist)s', r'(?P<title>.+)\ \-\ (?P<artist>.+)'),
                               ('%(title)s - %(artist)s / %(album)s', r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \/\ (?P<album>.+)')]:
        converter = MetadataFromTitlePP(None, format)
        assert converter._titleregex == expected, (
            "MetadataFromTitlePP._titleregex is '%s', expected '%s'" %
            (converter._titleregex, expected))


# Generated at 2022-06-24 14:13:40.328425
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s.mp3')
    assert pp._titleformat == '%(artist)s - %(title)s.mp3'
    assert pp._titleregex == '(?P<artist>.+)\\ \\-\\ (?P<title>.+)\\.mp3'
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp._titleregex == '(?P<artist>.+)\\ \\-\\ (?P<title>.+)'
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s - %(title)s')

# Generated at 2022-06-24 14:13:47.774939
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .YoutubeDLHook import YoutubeDL
    from .extractor.common import InfoExtractor
    from .utils import DateRange

    titleformat = '%(author)s - %(title)s'
    title = 'test author - test title'
    regex = 'test\ author\ -\ test\ title'
    info = {'title': title}
    extractor = InfoExtractor()
    extractor.add_info_extractor(
        YoutubeDL(
            FileDownloader(
                params={"outtmpl": "%(id)s%(ext)s"}
            )
        )
    )
    pp = MetadataFromTitlePP(extractor._ydl, titleformat)
    pp.run(info)
    

# Generated at 2022-06-24 14:13:59.123333
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert (pp._titleformat == '%(title)s - %(artist)s'
            and pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)')

    pp = MetadataFromTitlePP(None, '%(title)s')
    assert (pp._titleformat == '%(title)s'
            and pp._titleregex == '(?P<title>.+)')

    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(album)s')

# Generated at 2022-06-24 14:14:07.198869
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class fake_downloader:
        def to_screen(self, text):
            pass
    downloader = fake_downloader()
    text = 'Sesame Street: Turn Around (Stop Look and Listen) (Elmo@Sesamestreet.Org)'
    info = {'title': text}
    pp = MetadataFromTitlePP(downloader, "%(title)s")
    pp.run(info)
    assert info['title'] == 'Sesame Street: Turn Around (Stop Look and Listen)'


# Generated at 2022-06-24 14:14:14.190970
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    metadata_from_title_pp = MetadataFromTitlePP(None, '%(title)s')
    assert metadata_from_title_pp._titleformat == '%(title)s'
    assert metadata_from_title_pp._titleregex == '(?P<title>.+)'

    metadata_from_title_pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert metadata_from_title_pp._titleformat == '%(title)s - %(artist)s'
    assert metadata_from_title_pp._titleregex == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'

    metadata_from_title_pp = MetadataFromTitlePP(None, '%(title)s')

# Generated at 2022-06-24 14:14:20.372187
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_str

    def trace_hook(obj):
        if 'title' in obj:
            obj['title'] = compat_str(obj['title'])

    config = {
        'verbose': True,
        'logger': YoutubeDL()._org_logger,
        'download_archive': 'archive.txt',
        'format': 'best',
    }
    ydl = YoutubeDL(config)
    ydl.add_info_extractor('test')
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s'))
    ydl._hook_manager.remove_unit(trace_hook)

# Generated at 2022-06-24 14:14:24.337096
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(song)s')
    assert pp._titleformat == '%(artist)s - %(song)s'
    assert pp._titleregex == '(?P<artist>.+)\ \-\ (?P<song>.+)'


# Generated at 2022-06-24 14:14:28.420958
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    mftpp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert mftpp._titleformat == '%(title)s - %(artist)s'
    assert mftpp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-24 14:14:33.135247
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    fmt = '%%(title)s - %%(artist)s - %%(album)s'
    r = MetadataFromTitlePP(None, fmt)
    assert(r._titleformat == fmt)
    assert(r._titleregex == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)\\ \\-\\ (?P<album>.+)')



# Generated at 2022-06-24 14:14:41.591574
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    assert MetadataFromTitlePP(None, '%(chapter)s')._titleregex == '(?P<chapter>.+)'
    assert MetadataFromTitlePP(None, '%(episode)s')._titleregex == '(?P<episode>.+)'
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s')._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(album)s')._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'


# Generated at 2022-06-24 14:14:44.838300
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    fmt = '%(artist)s - %(title)s'
    regex = '(?P<artist>.+)\ \-\ (?P<title>.+)'
    assert MetadataFromTitlePP(None, fmt).format_to_regex(fmt) == regex



# Generated at 2022-06-24 14:14:54.866320
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import FileDownloader
    from .extractor import gen_extractors
    from .compat import compat_str, text_type

    # test for unicode literal support
    test_format = '%(title)s - %(artist)s'
    test_format_unicode = compat_str(test_format)
    assert isinstance(test_format_unicode, text_type)
    # test for conversion error
    test_format_invalid = '%(title)s - %(artist)s'
    # test for conversion of simple %s to regex group
    test_format_plainpercent = '%s - %(artist)s'
    # test for already existing regex group
    test_format_regex = '(?P<title>.+) - %(artist)s'
    # test for already existing regex group and

# Generated at 2022-06-24 14:15:04.206554
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert MetadataFromTitlePP(None, '%(artist)s - %(title)s').run(
        {'title': 'J. S. Bach - Fuge G-moll BWV 578'})[1] == \
        {'title': 'Fuge G-moll BWV 578', 'artist': 'J. S. Bach'}
    assert MetadataFromTitlePP(None, '%(artist)s-%(title)s').run(
        {'title': 'J. S. Bach - Fuge G-moll BWV 578'})[1] == \
        {'title': 'J. S. Bach - Fuge G-moll BWV 578'}

# Generated at 2022-06-24 14:15:13.768097
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor import gen_extractors
    from .downloader import YoutubeDL

    youtube_dl = YoutubeDL()
    youtube_dl.params['writethumbnail'] = False
    youtube_dl.params['simulate'] = True
    youtube_dl.params['skip_download'] = True
    youtube_dl.params['logger'] = FileDownloader()
    for ie in gen_extractors():
        youtube_dl.add_info_extractor(ie)

    # test 1
    format = '%(title)s.%(ext)s'
    ydl = FileDownloader(params=youtube_dl.params, info_dict={
        'id': 'test',
        'ext': 'mp4',
        'title': 'TEST TITLE'
        })

# Generated at 2022-06-24 14:15:20.216906
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from_title = MetadataFromTitlePP(None, None)
    assert from_title.format_to_regex('bla bla') == 'bla bla'
    assert from_title.format_to_regex('%()s') == '%\(\)\s'
    assert from_title.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert from_title.format_to_regex('%(a)s %(title)s %(b)s') == '(?P<a>.+)\ (?P<title>.+)\ (?P<b>.+)'
    assert from_title.format_to_regex(r'\%(title)s') == r'\\%\(title\)s'

# Generated at 2022-06-24 14:15:31.766492
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import os.path

    from ytdl.extractor.youtube import YoutubeIE
    from ytdl.downloader import Downloader

    ie = YoutubeIE()
    test_video_id = 'BaW_jenozKc'
    info = ie.extract(test_video_id)
    test_file = os.path.join(
        os.path.dirname(__file__), 'test_data', '%s.mp4' % test_video_id)
    dl = Downloader(info, {}, test_file)
    pp = MetadataFromTitlePP(dl, '%(title)s - %(artist)s')
    info = pp.run(info)
    assert info['title'] == 'youtube-dl test video "'
    assert info['artist'] == '" for youtube-dl'

# Generated at 2022-06-24 14:15:40.434032
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    assert pp.format_to_regex('blabla') == 'blabla'
    assert pp.format_to_regex('bla%(a)sblabla') == 'bla(?P<a>.+)blabla'
    assert pp.format_to_regex('bla%(a)sblabla%(b)s') == 'bla(?P<a>.+)blabla(?P<b>.+)'
    assert pp.format_to_regex('bla%(a)sbla%(b)sbla%(c)s') == 'bla(?P<a>.+)bla(?P<b>.+)bla(?P<c>.+)'

# Generated at 2022-06-24 14:15:52.103286
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor import YoutubeIE

    downloader = FileDownloader()
    downloader.add_info_extractor(YoutubeIE())
    downloader.add_post_processor(MetadataFromTitlePP(downloader,
        '%(artist)s - %(song)s'))
    info = downloader.extract_info('http://www.youtube.com/watch?v=G59tYK-ZUDs')
    assert ('artist', 'Bruno Mars') in info.items()
    assert ('song', 'It Will Rain') in info.items()

    downloader = FileDownloader()
    downloader.add_info_extractor(YoutubeIE())

# Generated at 2022-06-24 14:16:00.396394
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    import re

    mft = MetadataFromTitlePP(None, None)
    fmt = {
        'title': '%(foo)s - %(bar)s',
        'match': 'foo\ \-\ bar',
        'regex': r'(?P<foo>.+)\ \-\ (?P<bar>.+)',
        'regex_match': {
         'foo': 'foo',
         'bar': 'bar'
        },
        'match_no_groups': 'foo - bar',
    }

    # test formating
    assert mft.format_to_regex(fmt['title']) == fmt['regex']

    # test regex matching
    match = re.match(fmt['regex'], fmt['match'])
    assert match is not None

# Generated at 2022-06-24 14:16:10.050079
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    downloader = object
    pp = MetadataFromTitlePP(downloader, '%(artist)s - %(song)s')
    info = {'title': 'abc - def'}
    result = pp.run(info)

    # one empty part, info is updated
    assert result == ([], dict(title='abc - def', artist='abc', song='def'))
    assert pp._titleregex == '(?P<artist>.+)\ \-\ (?P<song>.+)'

    pp = MetadataFromTitlePP(downloader, '%(artist)s - %(song)s')
    info = {'title': 'abc - def - ghi'}
    result = pp.run(info)

    # one empty part, info is updated

# Generated at 2022-06-24 14:16:11.342490
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    MetadataFromTitlePP(None, '%(title)s - %(artist)s')



# Generated at 2022-06-24 14:16:15.828769
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    assert pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('No metadata') == r'No\ metadata'

# Generated at 2022-06-24 14:16:25.034084
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class MetadataFromTitlePP_stub(MetadataFromTitlePP):
        def __init__(self, downloader):
            super(MetadataFromTitlePP_stub, self).__init__(downloader)
        def _get_title(self):
            return self._title

    def _test(test_case, title, title_format, expected_dict):
        downloader = type('downloader_stub', (object,), {
            'to_screen': lambda *args, **kwargs: None,
        })()
        pp = MetadataFromTitlePP_stub(downloader)
        pp._title = title
        pp._titleformat = title_format
        pp._titleregex = pp.format_to_regex(title_format)
        out_dict = {}

# Generated at 2022-06-24 14:16:33.545104
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    format = '%(title)s - %(artist)s'
    mft_pp = MetadataFromTitlePP(None, format)
    regex = mft_pp.format_to_regex(format)

    format = '%(artist)s - %(title)s'
    mft_pp = MetadataFromTitlePP(None, format)
    regex = mft_pp.format_to_regex(format)

    format = '%(artist)s - %(title)s - %(album)s'
    mft_pp = MetadataFromTitlePP(None, format)
    regex = mft_pp.format_to_regex(format)

    format = '%(artist)s - %(title)s - %(year)s'

# Generated at 2022-06-24 14:16:39.858647
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from_title = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert from_title.format_to_regex('%%(test)s') == '%%\(test\)s'
    assert (from_title.format_to_regex('%(test)s - 2')
            == '(?P<test>.+)\ \-\ 2')
    assert (from_title.format_to_regex('%(title)s - 2 - %(artist)s')
            == '(?P<title>.+)\ \-\ 2\ \-\ (?P<artist>.+)')
    assert (from_title.format_to_regex('%(title) (artist)s')
            == '(?P<title>.+) \(artist\)s')

# Generated at 2022-06-24 14:16:40.800448
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass
    # TODO


# Generated at 2022-06-24 14:16:50.774589
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftppp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')

    assert '^bla$' == mftppp.format_to_regex('bla')
    assert '(?P<title>.+) - (?P<artist>.+)' == mftppp.format_to_regex('%(title)s - %(artist)s')
    assert '%%(title)s %%(title)s' == mftppp.format_to_regex('%%(title)s %%(title)s')
    assert '(?P<title>.+) %(title)s' == mftppp.format_to_regex('%(title)s %(title)s')
    assert '%(title)s (?P<title>.+)' == mftppp.format

# Generated at 2022-06-24 14:16:54.402075
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Test if the class constructor raises an error if the titleformat is invalid
    titleformat = '%(title)s - %(artist)s'
    try:
        MetadataFromTitlePP(None, titleformat)
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-24 14:17:04.384294
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import FileDownloader
    from .extractor import LinkExtractor
    from .postprocessor import FFmpegMetadataPP, FFmpegVideoConvertor
    from .ytdl_configuration import extract_element
    from .YoutubeDL import YoutubeDL


# Generated at 2022-06-24 14:17:13.077333
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftpp = MetadataFromTitlePP(None, None)
    assert mftpp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert mftpp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert mftpp.format_to_regex('%(title)s%(artist)s%(title)s') == '(?P<title>.+)(?P<artist>.+)(?P<title>.+)'

# Generated at 2022-06-24 14:17:22.043947
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    testcases = [
        ('[%(title)s]', r'\[(?P<title>.+)\]'),
        ('%(title)s - %(artist)s', r'(?P<title>.+)\ \-\ (?P<artist>.+)'),
        ('%(title)s %(title)s', r'(?P<title>.+)\ (?P<title>.+)'),
        ('%(title)s - %(artist)s - %(title)s', r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<title>.+)'),
        (r'%(t)s', r'%(t)s'),
    ]
    for testcase, expected in testcases:
        m = MetadataFromTitlePP(None, testcase)

# Generated at 2022-06-24 14:17:28.911513
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert pp.format_to_regex('start of the song %(title)s') == r'start\ of\ the\ song\ (?P<title>.+)'
    assert pp.format_to_regex('%(artist)s - %(title)s') == r'(?P<artist>.+)\ \-\ (?P<title>.+)'

# Generated at 2022-06-24 14:17:38.837061
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, None).format_to_regex(
        '%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, None).format_to_regex(
        '%(title)s') == r'(?P<title>.+)'
    assert MetadataFromTitlePP(None, None).format_to_regex(
        '%(title)s - %(artist)s - %(album)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'

# Generated at 2022-06-24 14:17:43.872756
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    t = MetadataFromTitlePP(None, None)
    assert 'https?:\/\/foo\.bar' == t.format_to_regex('https://foo.bar')
    assert 'https?:\/\/foo\.bar' == t.format_to_regex('%(webpage_url)s')
    assert 'bla\%2Fbla' == t.format_to_regex('bla%%2Fbla')
    assert r'bla%2Fbla' == t.format_to_regex('bla%(\w+)Fbla')

    assert (r'a(?P<foo>.+)b(?P<bar>.+)c' ==
            t.format_to_regex('a%(foo)s%(bar)sbarc'))


# Generated at 2022-06-24 14:17:55.152037
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    import unittest
    from .common import FakeYDL
    from .extractor import gen_extractors

    # Correct format string
    def test_fmt_str(fmt, expected_regex):
        test = MetadataFromTitlePP(FakeYDL(), fmt)
        assert test._titleregex == expected_regex

    # Incorrect format string
    def test_fmt_str_error(fmt):
        with unittest.assertRaises(SystemExit) as e:
            MetadataFromTitlePP(FakeYDL(), fmt)
        assert e.exception.code == 1

    test_fmt_str('%(title)s', '(?P<title>.+)')

# Generated at 2022-06-24 14:18:02.202127
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pp = MetadataFromTitlePP(None, '%(test1)s - %(test2)s - %(test3)s')

    info = {'title': 'title1 - title2 - title3'}
    assert pp.run(info) == ([], {'title': 'title1 - title2 - title3',
                                 'test1': 'title1',
                                 'test2': 'title2',
                                 'test3': 'title3'})

    # missing title
    info = {}
    assert pp.run(info) == ([], {'title': ''})

    # missing test3
    info = {'title': 'title1 - title2 -'}

# Generated at 2022-06-24 14:18:09.816327
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    import sys
    import unittest

    class MyTest(unittest.TestCase):
        def runTest(self):
            titleformat = '%(title)s - %(artist)s'
            regex = '(?P<title>.+)\ \-\ (?P<artist>.+)'
            mypp = MetadataFromTitlePP(None, titleformat)
            self.assertEqual(mypp.format_to_regex(titleformat), regex)

    mytest = MyTest()
    mytest.runTest()
    if mytest.wasSuccessful():
        sys.exit(0)
    else:
        sys.exit(1)

# Generated at 2022-06-24 14:18:19.161898
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    class FakeDownloader:
        def __init__(self):
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)

    # title format "%(title)s - %(artist)s"
    titleformat = r'%\(title\)s - %\(artist\)s'
    # title regex '(?P<title>.+)\ \-\ (?P<artist>.+)'
    titleregex = r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    # test case 1
    info = {'title': 'Under the bridge - Red Hot Chili Peppers'}
    downloader = FakeDownloader()
    pp = MetadataFromTitlePP(downloader, titleformat)
    # check regex


# Generated at 2022-06-24 14:18:28.495042
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    meta = MetadataFromTitlePP(None, None)
    assert meta.format_to_regex("%(title)s") == r'(?P<title>.+)'
    assert meta.format_to_regex("%(title)s - %(artist)s") == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert meta.format_to_regex("Date: %(date)s") == r'Date\:\ (?P<date>.+)'
    assert meta.format_to_regex("%(date)s_Artist:%(artist)s_Title:%(title)s") == r'(?P<date>.+)_Artist\:(?P<artist>.+)_Title\:(?P<title>.+)'

# Generated at 2022-06-24 14:18:35.462768
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP('dummy', '%(title)s')
    regex = pp.format_to_regex('%(title)s - %(artist)s')
    m = re.match(regex, 'I saw you - Gregor')
    assert m.group('title') == 'I saw you'
    assert m.group('artist') == 'Gregor'

    pp = MetadataFromTitlePP('dummy', ' - ')
    regex = pp.format_to_regex(' - ')
    m = re.match(regex, ' - ')
    assert (not m.groupdict())

# Generated at 2022-06-24 14:18:39.826592
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor.youtube import YoutubeIE

# Generated at 2022-06-24 14:18:40.925049
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp



# Generated at 2022-06-24 14:18:48.432317
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader

    f = FileDownloader(None, None)  # hack to get a proper logger
    pp = MetadataFromTitlePP(f, '%(title)s [some]')

    # Test normal behaviour
    info = {
        'title': 'some title [some]'
    }
    assert pp.run(info) == ([], {'title': 'some title', 'title_from_fmt': 'some title'})

    # Test behaviour with %-escaped title
    info = {
        'title': 'some title %% [some]'
    }
    assert pp.run(info) == ([], {'title': 'some title %', 'title_from_fmt': 'some title %'})

    # Test behaviour with a wrong title

# Generated at 2022-06-24 14:18:56.671514
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl.YoutubeDL import YoutubeDL
    ytdl = YoutubeDL()
    ytdl.add_default_info_extractors()
    ytdl.add_post_processor(
        MetadataFromTitlePP(ytdl, '%(artist)s - %(title)s'))
    with ytdl:
        info = ytdl.extract_info('https://www.youtube.com/watch?v=jNQXAC9IVRw',
                                 download=False)
        assert info['title'] == 'Justin Timberlake - Mirrors'
        assert info['artist'] == 'Justin Timberlake'
        ytdl.to_screen = True
        ytdl.download(['http://www.youtube.com/watch?v=BaW_jenozKc'])

# Generated at 2022-06-24 14:18:58.105759
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # TODO implement this
    raise NotImplementedError()


# Generated at 2022-06-24 14:19:02.771429
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from ytdl.postprocessor import MetadataFromTitlePP
    mpp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert mpp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert mpp.format_to_regex('%(title)s - %(artist)s - %(year)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<year>.+)'
    assert mpp.format_to_regex('%(title)s') == r'(?P<title>.+)'

# Generated at 2022-06-24 14:19:12.196274
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    """Unit test for constructor of class MetadataFromTitlePP."""
    from youtube_dl.YoutubeDL import YoutubeDL
    dl = YoutubeDL({})
    assert MetadataFromTitlePP(dl, '%(title)s')
    assert MetadataFromTitlePP(dl, '%(title)s - %(artist)s')
    assert MetadataFromTitlePP(dl, 'foo %(title)s - %(artist)s')
    assert MetadataFromTitlePP(dl, 'foo %(title)s - %(artist)s bar')
    assert MetadataFromTitlePP(dl, 'foo %(artist)s bar')
    assert MetadataFromTitlePP(dl, '%(title)s')


# Generated at 2022-06-24 14:19:15.703416
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import ydl_opts

    titleformat = '%(artist)s - %(title)s'
    title = 'Eminem - My name is'

    pp = MetadataFromTitlePP(None, titleformat)
    _, info = pp.run({'title' : title})

    assert ydl_opts.match_entry_title(info, 'My name is')
    assert ydl_opts.match_entry_artist(info, 'Eminem')

# Generated at 2022-06-24 14:19:26.085434
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    downloader = object()
    pp = MetadataFromTitlePP(downloader, '%(artist)s - %(song)s')
    # Test if 'artist' and 'song' are extracted from the title string
    info = {'title': 'Foo Fighters - Learn To Fly'}
    pp.run(info)
    assert(info['artist'] == 'Foo Fighters')
    assert(info['song'] == 'Learn To Fly')
    # Test if 'artist', 'song' and 'album' are extracted from the title string
    pp = MetadataFromTitlePP(downloader, '%(artist)s - %(song)s - %(album)s')
    info = {'title': 'Foo Fighters - Learn To Fly - One By One'}
    pp.run(info)

# Generated at 2022-06-24 14:19:32.157368
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class DummyYDL(object):
        def to_screen(self, msg):
            print(msg)

    class FakeInfo(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfo, self).__init__(*args, **kwargs)
            self['title'] = None

    ydl = DummyYDL()
    ydl.to_screen = lambda msg: None
    i = FakeInfo()
    pp = MetadataFromTitlePP(ydl, '%(artist)s - %(title)s')
    i['title'] = 'test artist - test title'
    pp.run(i)
    assert i['artist'] == 'test artist' and i['title'] == 'test title'

# Generated at 2022-06-24 14:19:39.156501
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert(MetadataFromTitlePP.format_to_regex(r'%(title)s - %(artist)s')
           == r'(?P<title>.+)\ \-\ (?P<artist>.+)')
    assert(MetadataFromTitlePP.format_to_regex(r'%(title)s')
           == r'(?P<title>.+)')
    assert(MetadataFromTitlePP.format_to_regex(r'%(title)s -')
           == r'(?P<title>.+)\ \-')
    assert(MetadataFromTitlePP.format_to_regex(r'(%(title)s)')
           == r'\((?P<title>.+)\)')

# Generated at 2022-06-24 14:19:49.506476
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    def test(titleformat, title, expected_regexp):
        pp = MetadataFromTitlePP(None, titleformat)
        assert pp._titleformat == titleformat
        assert pp._titleregex == expected_regexp
        assert re.match(pp._titleregex, title) is not None
    assert MetadataFromTitlePP(None, '%(title)s')
    test('%(title)s', 'Kittens are a lie', r'(?P<title>.+)')
    test('%(title)s - %(artist)s', 'Rock & Roll - AC/DC', r'(?P<title>.+)\ \-\ (?P<artist>.+)')

if __name__ == '__main__':
    test_MetadataFromTitlePP()

# Generated at 2022-06-24 14:19:56.973828
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert(pp.format_to_regex('%(title)s - %(artist)s')
           == '(?P<title>.+)\ \-\ (?P<artist>.+)')
    pp = MetadataFromTitlePP(None, '%(title)s')
    assert(pp.format_to_regex('%(title)s') == '(?P<title>.+)')
    pp = MetadataFromTitlePP(None, '%(a)s - %(b)s - %(c)s')

# Generated at 2022-06-24 14:20:07.088509
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import pytube
    from pytube import PostProcessor
    from pytube.compat import compat_str

    test_obj = MetadataFromTitlePP(None, '%(title)s')
    test_obj.format_to_regex = MetadataFromTitlePP.format_to_regex.im_func
    test_obj.run({"title" : "pytube Test"})
    assert test_obj._titleformat == '%(title)s'
    assert test_obj._titleregex == '(?P<title>.+)'

    test_obj = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    test_obj.format_to_regex = MetadataFromTitlePP.format_to_regex.im_func

# Generated at 2022-06-24 14:20:10.824127
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    m = MetadataFromTitlePP(None, 'bla %(foo)s bla %(bar)s')
    assert m.format_to_regex('bla %(foo)s bla %(bar)s') == r'bla\ (?P<foo>.+)\ bla\ (?P<bar>.+)'



# Generated at 2022-06-24 14:20:17.365680
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftpp = MetadataFromTitlePP(None, '%(artist)s - %(song)s - %(album)s')
    assert mftpp.format_to_regex('%(artist)s - %(song)s - %(album)s') == \
            r'(?P<artist>.+)\ \-\ (?P<song>.+)\ \-\ (?P<album>.+)'
    assert mftpp.format_to_regex('%(artist)s - %(song)s') == \
            r'(?P<artist>.+)\ \-\ (?P<song>.+)'
    assert mftpp.format_to_regex('%(artist)s') == r'(?P<artist>.+)'

# Generated at 2022-06-24 14:20:27.390628
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-24 14:20:37.714258
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .test import get_test_downloader
    from .compat import compat_configparser
    import os

    config = compat_configparser()
    config.add_section('general')
    config.set('general', 'titleformat', '%(artist)s-%(title)s.%(ext)s')

    temp_dir = None

# Generated at 2022-06-24 14:20:44.666947
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from ..extractor.common import InfoExtractor
    from ..utils import compat_urllib_error
    from .common import DownloaderMock

    # Initialize a dummy downloader for testing

# Generated at 2022-06-24 14:20:53.863754
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FFmpegPostProcessor
    import tempfile
    with tempfile.NamedTemporaryFile(mode='w+b', prefix='ytdl_pp_test') \
             as f:
        f.write(b'This is a title')
        f.seek(0)
        pp = MetadataFromTitlePP(None, '%(title)s')
        info = pp.run({'title': 'title', 'filepath': f.name})
        assert b'This is a title' == FFmpegPostProcessor(None).run(info)[1]['title']
        pp = MetadataFromTitlePP(None, 'One%(title)sTwo%(title)sThree')
        info = pp.run({'title': 'title', 'filepath': f.name})
        assert b'Oneonetwothree'