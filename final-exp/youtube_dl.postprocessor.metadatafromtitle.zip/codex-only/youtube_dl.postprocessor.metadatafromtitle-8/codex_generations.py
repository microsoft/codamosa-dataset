

# Generated at 2022-06-24 14:10:58.153119
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.YoutubeDL import YoutubeDL

    ydl = YoutubeDL()
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    pp = MetadataFromTitlePP(ydl, '%(upload_date)s - %(title)s')
    assert pp._titleregex == r'(?P<upload_date>.+)\ \-\ (?P<title>.+)'

    pp = MetadataFromTitlePP(ydl, '%(upload_date)s - %(title)s - %(artist)s')

# Generated at 2022-06-24 14:11:00.406794
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    print(MetadataFromTitlePP.format_to_regex('%(title)s - %(artist)s'))


# Generated at 2022-06-24 14:11:04.613966
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert mp.format_to_regex(mp._titleformat) == '(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-24 14:11:12.738896
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    pp = MetadataFromTitlePP(None, 'some fixed format')
    assert pp._titleregex == 'some fixed format'
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(album)s')
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'


# Generated at 2022-06-24 14:11:17.899732
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mft = MetadataFromTitlePP(None, '')
    assert mft.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert mft.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-24 14:11:24.568976
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '')
    assert pp.format_to_regex('%(title)s - %(artist)s') == (
        r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    )
    assert pp.format_to_regex(r'%(title)s - \%\%(artist)s') == (
        r'(?P<title>.+)\ \-\ \\%\(artist\)s'
    )

# Generated at 2022-06-24 14:11:29.180501
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl
    downloader = youtube_dl.YoutubeDL({})
    pp = MetadataFromTitlePP(downloader, '%(artist)s - %(title)s')
    info, new_info = pp.run({
        'title': 'MetadataFromTitlePP_run test - artist'})
    assert new_info['artist'] == 'MetadataFromTitlePP_run test'
    assert new_info['title'] == 'artist'
    assert len(info) == 0


# Generated at 2022-06-24 14:11:39.459309
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # In Python 2.6, dict.iteritems() is removed. Its equivalent is:
    # >>> dict(dictA).items()
    # [('one', 1), ('two', 2), ('three', 3)]

    import youtube_dl.postprocessor.common

    from PyPDF2.utils import PdfReadError
    from youtube_dl.utils import PdfReadWarning

    class DummyYoutubeDL(object):
        def to_screen(self, *args, **kargs):
            pass

    ydl = DummyYoutubeDL()


# Generated at 2022-06-24 14:11:47.969401
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    postprocessor = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert postprocessor._titleformat == '%(title)s - %(artist)s'
    assert postprocessor._titleregex == (
        '(?P<title>.+)\ \-\ (?P<artist>.+)')

    postprocessor = MetadataFromTitlePP(None, '%(title)s - %(unknown)s')
    assert postprocessor._titleformat == '%(title)s - %(unknown)s'
    assert postprocessor._titleregex == (
        '(?P<title>.+)\ \-\ (?P<unknown>.+)')

    postprocessor = MetadataFromTitlePP(None, '%(title)s - %(artist)s %(unknown)s')

# Generated at 2022-06-24 14:11:57.544429
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, '').format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert MetadataFromTitlePP(None, '').format_to_regex('foo') == r'foo'
    assert MetadataFromTitlePP(None, '').format_to_regex('foo %(title)s') == r'foo\ (?P<title>.+)'
    assert MetadataFromTitlePP(None, '').format_to_regex('foo %(title)s bar') == r'foo\ (?P<title>.+)\ bar'

# Generated at 2022-06-24 14:12:07.942787
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp._titleformat == '%(artist)s - %(title)s'
    assert pp._titleregex == r'(?P<artist>.+)\ \-\ (?P<title>.+)'

    pp = MetadataFromTitlePP(None, '%(title)s by %(artist)s')
    assert pp._titleformat == '%(title)s by %(artist)s'
    assert pp._titleregex == r'(?P<title>.+)\ by\ (?P<artist>.+)'

    pp = MetadataFromTitlePP(None, '%(title)s [%(artist)s]')
    assert pp._titleformat == '%(title)s [%(artist)s]'
   

# Generated at 2022-06-24 14:12:10.879938
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    m = MetadataFromTitlePP(None, None)
    assert m.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'

# Generated at 2022-06-24 14:12:18.248325
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    def format_to_regex(titleformat):
        r"""
        Converts a string like
           '%(title)s - %(artist)s'
        to a regex like
           '(?P<title>.+)\ \-\ (?P<artist>.+)'
        """
        lastpos = 0
        regex = ''
        # replace %(..)s with regex group and escape other string parts
        for match in re.finditer(r'%\((\w+)\)s', titleformat):
            regex += re.escape(titleformat[lastpos:match.start()])
            regex += r'(?P<' + match.group(1) + '>.+)'
            lastpos = match.end()
        if lastpos < len(titleformat):
            regex += re.escape(titleformat[lastpos:])


# Generated at 2022-06-24 14:12:25.849353
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import youtube_dl.YoutubeDL as YtDL
    from .test_utils import FakeYDL, FakeInfoExtractor, FakeDownloader

    class FakeInfo(dict):
        def __init__(self, **kwargs):
            super(FakeInfo, self).__init__(**kwargs)

    ydl = FakeYDL()
    ie = FakeInfoExtractor()
    ydl.add_info_extractor(ie)
    ie._downloader = FakeDownloader(ydl)
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s'))
    ie.set_info(FakeInfo(title='Title - Artist - Album'))

    ret = ydl.process_ie_result(ie.result, ie, False)

# Generated at 2022-06-24 14:12:35.991359
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor.youtube import YoutubeIE
    # Test data (Youtube)
    # Video title: "Eminem - Not Afraid"
    yt_filename = 'Eminem - Not Afraid'
    yt_title = 'Eminem - Not Afraid'
    yt_url = 'http://www.youtube.com/watch?v=j5-yKhDd64s'
    yt_info = {
        'id': 'j5-yKhDd64s',
        'ext': 'flv',
        'uploader': 'EminemVEVO',
        'title': yt_title,
    }

    # Test class
    pp = MetadataFromTitlePP(FileDownloader(), '%(artist)s - %(title)s')
    result

# Generated at 2022-06-24 14:12:38.433973
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-24 14:12:46.371343
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Test case 1
    titleformat = '%(title)s - %(artist)s'
    titleregex = r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    mftpp = MetadataFromTitlePP(None, titleformat)
    assert(mftpp._titleformat == titleformat)
    assert(mftpp._titleregex == titleregex)

    # Test case 2
    titleformat = '%(title)s %(artist)s'
    titleregex = titleformat
    mftpp = MetadataFromTitlePP(None, titleformat)
    assert(mftpp._titleformat == titleformat)
    assert(mftpp._titleregex == titleregex)


# Generated at 2022-06-24 14:12:56.504673
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    def test_with_titleformat(titleformat):
        print('Testing with format "%s":' % titleformat)
        rf = MetadataFromTitlePP(None, titleformat)
        regex = rf._titleregex
        print('    -> regex has been generated: %s' % regex)
        print('    -> regex compiles: %s' % bool(re.compile(regex)))

    test_with_titleformat('%(title)s - %(artist)s')
    test_with_titleformat('%(title)s - %(uploader)s - %(artist)s')
    test_with_titleformat('%(artist)s - %(title)s')
    test_with_titleformat('%(artist)s - %(title)s - %(uploader)s')


# Generated at 2022-06-24 14:13:05.941874
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Define test objects
    class Downloader:
        def __init__(self):
            self.to_screen_result = []
        def to_screen(self, message):
            self.to_screen_result.append(message)
    downloader = Downloader()

    info = {'title': 'test title'}
    metadata_from_title_pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')

    # Run method run with not matching title format
    downloader.to_screen_result = []
    metadata_from_title_pp.run(info)
    assert downloader.to_screen_result == ['[fromtitle] Could not interpret title of video as "%(title)s - %(artist)s"']
    assert info == {'title': 'test title'}



# Generated at 2022-06-24 14:13:15.195629
# Unit test for constructor of class MetadataFromTitlePP

# Generated at 2022-06-24 14:13:25.210737
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    downloader = None
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')

    # Title is matched by regex and converted to metadata
    info = {'title': 'The Title - The Artist'}
    pp.run(info)
    assert info['title'] == 'The Title'
    assert info['artist'] == 'The Artist'

    # Title of wrong format is ignored
    info = {'title': 'The Title - The Artist - Extra'}
    pp.run(info)
    assert info['title'] == 'The Title - The Artist - Extra'
    assert 'artist' not in info

    # %(..)s not at beginning nor end of format
    pp = MetadataFromTitlePP(downloader, 'The Title - %(date)s')

# Generated at 2022-06-24 14:13:35.504686
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import FileDownloader
    mft = MetadataFromTitlePP(FileDownloader({}), '')

    assert mft.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert mft.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert mft.format_to_regex('%(title)s - %(artist)s - %(album)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'

# Generated at 2022-06-24 14:13:44.287212
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import sys; sys.modules['__main__'].pytube.common.FileDownloader = object

    # Check that constructor raises an exception
    # if titleformat is None or empty
    assert_raises(ValueError, MetadataFromTitlePP, None, None)
    assert_raises(ValueError, MetadataFromTitlePP, None, '')
    assert_raises(ValueError, MetadataFromTitlePP, None, '   ')

    # Check that constructor does not generate regex if
    # titleformat does not contain %(...)s field
    # (e.g. titleformat == 'Artist - Title')
    mp4 = MetadataFromTitlePP(None, 'Artist - Title')
    assert_equal(mp4._titleformat, 'Artist - Title')
    assert_equal(mp4._titleregex,  'Artist - Title')



# Generated at 2022-06-24 14:13:54.523456
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    mtt = MetadataFromTitlePP('', '')
    # this won't match, but it shouldn't crash either
    mtt.format_to_regex('%(title)s - %(artist)s')
    assert mtt.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'
    # this will match, but we don't care
    mtt.format_to_regex('%(title)s')
    assert mtt.format_to_regex('%(title)s') == '(?P<title>.+)'

if __name__ == '__main__':
    test_MetadataFromTitlePP()

# Generated at 2022-06-24 14:14:03.314787
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import tempfile
    if sys.version_info < (3,):
        from urllib2 import HTTPError
    else:
        from urllib.error import HTTPError

    import json

    # Save stdout / stderr
    oldout, olderr = sys.stdout, sys.stderr
    sys.stdout = sys.__stdout__ = tempfile.TemporaryFile()
    sys.stderr = sys.__stderr__ = tempfile.TemporaryFile()


# Generated at 2022-06-24 14:14:12.213038
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    downloader = YoutubeDL({'format': 'bestaudio/best', 'quiet': True})
    titleformat = '%(title)s - %(artist)s - %(track)s'
    pp = MetadataFromTitlePP(downloader, titleformat)
    # Test a title with all three fields
    info = {'title': 'Borders - M.I.A. - 7'}
    expected_info = {
        'title': 'Borders',
        'artist': 'M.I.A.',
        'track': '7'
    }
    returned_list, returned_info = pp.run(info)
    assert returned_list == []
    assert returned_info == expected_info
    # Test a title without the track field (optional)

# Generated at 2022-06-24 14:14:20.938784
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    fmt = ['%(title)s', '%(title)s - %(artist)s', '%(title)s by %(artist)s']
    expected_regex = [
        '(?P<title>.+)',
        '(?P<title>.+)\ \-\ (?P<artist>.+)',
        '(?P<title>.+)\ by\ (?P<artist>.+)'
    ]
    mftpp = MetadataFromTitlePP(None, None)
    for i in range(len(expected_regex)):
        regex = mftpp.format_to_regex(fmt[i])
        assert regex == expected_regex[i]

# Generated at 2022-06-24 14:14:29.598080
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .common import FileDownloader

    downloader = FileDownloader({})
    assert MetadataFromTitlePP(downloader, '%(a)s')({'title': '1'})[1] == {'a': '1'}
    assert MetadataFromTitlePP(downloader, '%(a)s')({'title': '0'})[1] == {'a': '0'}
    assert MetadataFromTitlePP(downloader, '%(a)s')({'title': '-1'})[1] == {'a': '-1'}
    assert MetadataFromTitlePP(downloader, '%(a)s')({'title': 'c'})[1] == {'a': 'c'}


# Generated at 2022-06-24 14:14:38.503142
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    """Tests that format_to_regex works correctly"""
    # pylint: disable=protected-access
    teststrings = [('%(title)s', '(?P<title>.+)'),
                   ('%(title)s-%(artist)s', '(?P<title>.+)-(?P<artist>.+)'),
                   ('%(artist)s-%(title)s', '(?P<artist>.+)-(?P<title>.+)'),
                   ('%(artist)s-%(notfound)s-%(title)s',
                    '(?P<artist>.+)-%\(notfound\)s-(?P<title>.+)'),
                   ('%(artist)s-%%-(?P<title>)s',
                    '(?P<artist>.+)-%%-(?P<title>)s')]

    pp = Met

# Generated at 2022-06-24 14:14:44.446432
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    filename = 'test_MetadataFromTitlePP_run.txt'
    test_input = open(filename, 'w')
    test_input.write('title=Who Am I')
    test_input.close()
    test_input = open(filename, 'r')

    info = {'title': 'Who Am I', 'artist': 'The Who'}
    p = MetadataFromTitlePP(None, '%(title)s')
    assert p.run(info) == ([], {'title': 'Who Am I', 'artist': 'The Who'})
    assert p._titleformat == '%(title)s'
    assert p._titleregex == '(?P<title>.+)'

    p = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert p.run(info)

# Generated at 2022-06-24 14:14:50.689999
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys

    class FakeDownloader:
        def __init__(self):
            self.to_screen_list = []

        def to_screen(self, msg):
            self.to_screen_list.append(msg)

    fake_downloader = FakeDownloader()
    titleformat = '%(title)s - %(artist)s'
    title_from_title_pp = MetadataFromTitlePP(fake_downloader, titleformat)
    # Title has no match for format
    title = 'Artist - Title'
    info = {'title': title}
    files, metadata = title_from_title_pp.run(info)
    assert files == []
    assert metadata == info
    assert len(fake_downloader.to_screen_list) == 1

# Generated at 2022-06-24 14:15:00.949341
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    ydl.params['logger'] = ydl
    def write(s):
        pass
    ydl.to_screen = write

    titleformat = "%(title)s %(upload_date)s"
    title = "Höllelujah !"
    upload_date = "2017-01-02"

    my_metadata = {
        "title": title + ' - ' + upload_date,
        "upload_date": upload_date
    }
    mftpp = MetadataFromTitlePP(ydl, titleformat)
    [], metadata = mftpp.run(my_metadata)

    assert metadata['title'] == title
    assert metadata['upload_date'] == upload_date

# Generated at 2022-06-24 14:15:11.042525
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-24 14:15:19.220449
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    titleformat = '%(artist)s - %(title)s [%(year)s]'
    metainstance = MetadataFromTitlePP(titleformat)
    regex = metainstance._titleregex

    title = 'Saltatio Mortis - Sturm aufs Paradies [2013]'
    match = re.match(regex, title)
    assert match is not None
    for attribute, value in match.groupdict().items():
        assert value is not None
        assert value != ''
    assert match.groupdict() == {'artist': 'Saltatio Mortis',
                                 'title': 'Sturm aufs Paradies',
                                 'year': '2013'}

    # let's test some edge cases
    title = 'Frei.Wild - Öl ins Feuer (2017)'

# Generated at 2022-06-24 14:15:30.385214
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    mft = MetadataFromTitlePP(None, '%(title)s')
    info = {"title": "A"}
    res = mft.run(info)
    assert res == ([], {"title": "A"})

    mft = MetadataFromTitlePP(None, '%(title)s %(kind)s')
    info = {"title": "A B"}
    res = mft.run(info)
    assert res == ([], {"title": "A", "kind": "B"})

    mft = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    info = {"title": "A - B"}
    res = mft.run(info)
    assert res == ([], {"title": "A", "artist": "B"})

    mft = MetadataFromTitle

# Generated at 2022-06-24 14:15:39.657143
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import mock
    from .extractor import YoutubeIE
    from .test import mock_postprocessor_run

    def run_test(titleformat, expect):
        downloader = mock.Mock(YoutubeIE())
        downloader.postprocessors = {}
        mftpp = MetadataFromTitlePP(downloader, titleformat)
        mixed = expect[0]
        mixexpect = expect[1]
        if mixed:
            regex = mftpp.format_to_regex(titleformat)
            assert regex == mixexpect
        else:
            regex = mftpp._titleregex
            assert regex == mixexpect


# Generated at 2022-06-24 14:15:51.668795
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-24 14:15:56.982241
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, '%(artist)s - %(title)s').format_to_regex(
               '%(title)s - %(artist)s') == \
               '(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-24 14:16:02.103433
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-24 14:16:11.022109
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    def assert_regex(expected_regex, fmt):
        mft = MetadataFromTitlePP(None, fmt)
        actual_regex = mft.format_to_regex(fmt)
        assert actual_regex == expected_regex, \
            '%s != %s' % (actual_regex, expected_regex)

    assert_regex('abc', 'abc')
    assert_regex('abc\ \-\ def', 'abc - def')
    assert_regex('abc\ \-\ def', '%(foo)s - def')
    assert_regex('abc\ \-\ (?P<bar>.+)', 'abc - %(bar)s')

# Generated at 2022-06-24 14:16:17.198347
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    m = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert m.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert m.format_to_regex('%(title)s - %(artist)s - %(year)d') == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<year>.+)'

# Generated at 2022-06-24 14:16:25.875321
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, '<title> - <artist>').format_to_regex('<title> - <artist>') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, '<title> - <artist>').format_to_regex('<title> - <artist> - <genre>') == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<genre>.+)'
    assert MetadataFromTitlePP(None, '<title> - <artist>').format_to_regex('<title> - <artist> - (Bonus)') == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ \(Bonus\)'

# Generated at 2022-06-24 14:16:34.190544
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    r"""
    Tests for method run of class MetadataFromTitlePP.
    """
    # we need a downloader instance for the test
    # (we don't care about the name of the file)
    from .downloader import FileDownloader
    from .YoutubeDL import YoutubeDL
    import os

    tmpfilename = 'test.tmp'
    try:
        os.remove(tmpfilename)
    except OSError:
        pass

    ydl = YoutubeDL({'outtmpl': tmpfilename})
    fdl = FileDownloader(ydl, {'test': 'abcde'})

    # testing MetadataFromTitlePP class
    video = {'title': 'abcde - fghjkl'}
    metadata_title = '%(title)s - %(test)s'

# Generated at 2022-06-24 14:16:44.178890
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from youtube_dl.postprocessor import MetadataFromTitlePP
    mftpp = MetadataFromTitlePP(None, None)
    assert mftpp.format_to_regex('test') == 'test'
    assert mftpp.format_to_regex('test %(title)s test2') == 'test (?P<title>.+) test2'
    assert mftpp.format_to_regex('test%(title)s%(artist)stest2') == 'test(?P<title>.+)(?P<artist>.+)test2'
    assert mftpp.format_to_regex(r'test%\(title\)s%(artist)stest2') == r'test%\(title\)s(?P<artist>.+)test2'

# Generated at 2022-06-24 14:16:49.455742
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    class FakeDownloader():
        def to_screen(self, value):
            print('>> ' + str(value))

    downloader = FakeDownloader()

    info = {'title': 'Title [1280x720] [720p] [123:45]',
            'width': '640', 'height': '360', 'duration': '360',
            'simulate': True}

    pp = MetadataFromTitlePP(downloader, '%(title)s [%(duration)s] '
                                          '[%(width)sx%(height)s]')

    pp.run(info)

    print('\nTest 2: check merging')

# Generated at 2022-06-24 14:16:57.932168
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    # From which video shall we get the Title
    # to use as test here
    video_id = "6ZZC0yeppo8" # "Amazing Grace: Trumpet Solo" on youtube
    titleformat = "%(title)s - %(artist)s"
    mp_obj = MetadataFromTitlePP(None, titleformat)
    info = {u'site': u'youtube', u'title': u'Amazing Grace: Trumpet Solo - James Last'}
    assert mp_obj.run(info) == ([], info)
    info = {u'site': u'youtube', u'title': u'Amazing Grace: Trumpet Solo - James Last (Trompetenst\xfcrme)'}
    assert mp_obj.run(info) == ([], info)

# Generated at 2022-06-24 14:17:08.500756
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .extractor import info_dict
    from .downloader import Downloader
    from .compat import compat_str

    def my_downloader_to_screen(msg):
        print(msg)

    video_id = compat_str(12345)
    title = 'Test Video - Test Title'
    video_info = info_dict(title, video_id)

    # Initialize Downloader object and add MetadataFromTitlePP
    dl = Downloader(params={})
    dl.add_post_processor(MetadataFromTitlePP(dl, '%(title)s - %(artist)s'))
    dl.to_screen = my_downloader_to_screen

    # Test fisrt case
    # Check MetadataFromTitlePP.run method when the title matches the pattern

# Generated at 2022-06-24 14:17:16.150636
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    """
    Method format_to_regex of class MetadataFromTitlePP should return the
    correct regular expression.
    """
    # Given the following format string
    fmt = '%(title)s - %(artist)s'

    # And a MetadataFromTitlePP instance
    pp = MetadataFromTitlePP(None, fmt)

    # The method format_to_regex should return the following regex
    # (?P<title>.+)\ \-\ (?P<artist>.+)
    expected_regex = r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    regex = pp.format_to_regex(fmt)
    assert regex == expected_regex


# Generated at 2022-06-24 14:17:23.384602
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    testcases = (('This is a %(test)s', r'This\ is\ a\ (?P<test>.+)'),
                 ('Foo %(bar)s-%(baz)s', r'Foo\ (?P<bar>.+)\-(?P<baz>.+)'),
                 ('Foo%(bar)s-%(baz)s', r'Foo(?P<bar>.+)-(?P<baz>.+)'))

    for inp, out in testcases:
        pp = MetadataFromTitlePP(None, inp)
        result = pp.format_to_regex(inp)
        assert result == out

# Generated at 2022-06-24 14:17:33.717397
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    class DummyInfo(dict):
        pass

    class DummyDownloader():
        def to_screen(self, message):
            pass
    info = DummyInfo()
    downloader = DummyDownloader()
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    info['title'] = 'Test Parse Title - Test Artist'
    (files, metadata) = pp.run(info)
    assert metadata['title'] == 'Test Parse Title'
    assert metadata['artist'] == 'Test Artist'
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    info['title'] = 'Test Parse Title'
    (files, metadata) = pp.run(info)

# Generated at 2022-06-24 14:17:42.765863
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest
    class TestMetadataFromTitlePP_run(unittest.TestCase):
        def setUp(self):
            self.pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
            self.info = {'title': 'title - artist'}

        def test_run(self):
            self.pp.run(self.info)
            self.assertEqual(self.info['title'], 'title')
            self.assertEqual(self.info['artist'], 'artist')

        def test_regex_simple(self):
            self.pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')

# Generated at 2022-06-24 14:17:54.340471
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    # test a simple string
    assert ydl._format_to_regex('hello') == 'hello'
    # test a string with a single percentage format
    assert ydl._format_to_regex('%(title)s') == '(?P<title>.+)'
    # test a string with two percentage formats
    assert ydl._format_to_regex('%(title)s-%(artist)s') == '(?P<title>.+)-(?P<artist>.+)'
    # test a string with two percentage formats and text in between
    assert ydl._format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+) - (?P<artist>.+)'
    # test a string with two escapes

# Generated at 2022-06-24 14:18:04.908746
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Initialize PostProcessor object
    import youtube_dl
    ydl_opts = {
            'writethumbnail': False,
            'writeautomaticsub': True,
            'sublangs': ['en'],
            'postprocessors': [{
                'key': 'MetadataFromTitlePP',
                'titleformat': '%(title)s - %(artist)s',
            }],
            'skip_download': True,
            }
    ydl = youtube_dl.YoutubeDL(ydl_opts)

    # Test 1: valid title
    info = {'title': 'abc - def'}
    mftpp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    result = mftpp.run(info)

# Generated at 2022-06-24 14:18:14.750670
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    testee = MetadataFromTitlePP(None, "")

    assert testee.format_to_regex("test") == "test"
    assert testee.format_to_regex("%(a)s") == "(?P<a>.+)"
    assert testee.format_to_regex("%(a)s%(b)s") == "(?P<a>.+)(?P<b>.+)"
    assert testee.format_to_regex("%(a)s-%(b)s") == r"(?P<a>.+)\-(?P<b>.+)"

# Generated at 2022-06-24 14:18:24.668603
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class FakeInfo:
        def __init__(self, title):
            self.title = title
    class FakeDownloader:
        def to_screen(self, msg):
            print(msg)

    # Test matching of regex %(title)s - %(artist)s
    metadata_from_title = MetadataFromTitlePP(FakeDownloader(), '%(title)s - %(artist)s')
    info = FakeInfo('title - artist')
    metadata_from_title.run(info)
    assert(info['title'] == 'title')
    assert(info['artist'] == 'artist')

    # Test matching of regex %(title)s - %(artist)s
    metadata_from_title = MetadataFromTitlePP(FakeDownloader(), '%(title)s - %(artist)s')

# Generated at 2022-06-24 14:18:32.639285
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    mp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert mp._titleformat == '%(artist)s - %(title)s'
    assert mp._titleregex == r'(?P<artist>.+)\ \-\ (?P<title>.+)'
    mp = MetadataFromTitlePP(None, '%(artist)s - %(title)s \\(%(year)s\\)')
    assert mp._titleregex == r'(?P<artist>.+)\ \-\ (?P<title>.+)\ \((?P<year>.+)\)'
    mp = MetadataFromTitlePP(None, r'%(artist)s - \%(title)s')
    assert mp._titleformat == r'%(artist)s - \%(title)s'

# Generated at 2022-06-24 14:18:42.984723
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl.YoutubeDL
    import youtube_dl.downloader.http
    ydl = youtube_dl.YoutubeDL({})
    ydl.add_post_processor(MetadataFromTitlePP(
        youtube_dl.downloader.http.HttpFD(ydl),
        '%(uploader)s - %(title)s.%(ext)s'))
    info = {}

    def add_format(fmt):
        fmt['format'] = fmt['format_id']
        info['formats'].append(fmt)

    # test basic functionality
    info['formats'] = []
    add_format({'format_id': '1', 'ext': 'webm'})
    info['extractor'] = 'YouTube'
    info['title'] = 'Uploader - Title.webm'
    info

# Generated at 2022-06-24 14:18:47.694927
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    m = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert m._titleformat == '%(title)s - %(artist)s'
    assert m._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-24 14:18:56.161608
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '%(title)s'
    pp = MetadataFromTitlePP(None, '[%(uploader)s] %(title)s')
    assert pp._titleformat == '[%(uploader)s] %(title)s'

# Generated at 2022-06-24 14:19:02.658858
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import unittest
    import sys
    class MockDownloader():
        def to_screen(self, msg):
            pass

    dl = MockDownloader()
    class TestMetadataFromTitlePP(unittest.TestCase):
        def runTest(self):
            mftpp = MetadataFromTitlePP(dl, '%(title)s - %(artist)s')
            self.assertEqual(mftpp._titleformat, '%(title)s - %(artist)s')
            self.assertEqual(mftpp._titleregex,
                             '(?P<title>.+)\ \-\ (?P<artist>.+)')

    TestMetadataFromTitlePP().runTest()


# Generated at 2022-06-24 14:19:13.020139
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, 'Some - %(artist)s')
    assert pp._titleformat == 'Some - %(artist)s'
    assert pp._titleregex == '(?P<artist>.+)'

    # test conversion of %(..)s to (?P<..>.)
    pp = MetadataFromTitlePP(None, 'Some - %(artist)s - %(title)s - wooh')
    assert pp._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)\ \-\ wooh'
    pp = MetadataFromTitlePP(None, 'Some - %(artist)s - %(title)s - ')
    assert pp._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)\ \-'
    pp

# Generated at 2022-06-24 14:19:19.012058
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor

    # initialize a downloader instance with embedded postprocessors

# Generated at 2022-06-24 14:19:27.543029
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-24 14:19:30.738412
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .common import FileDownloader
    pp = MetadataFromTitlePP(FileDownloader({}), '%(artist)s - %(title)s')
    assert pp._titleformat == '%(artist)s - %(title)s'
    assert pp._titleregex == r'(?P<artist>.+)\ \-\ (?P<title>.+)'



# Generated at 2022-06-24 14:19:34.725584
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    assert (MetadataFromTitlePP(None, "%(title)s - %(artist)s")._titleregex
            == r'(?P<title>.+)\ \-\ (?P<artist>.+)')
    assert (MetadataFromTitlePP(None, "Do not match me")._titleregex
            == r'Do not match me')


# Generated at 2022-06-24 14:19:44.266662
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)sok') == '(?P<title>.+)ok'
    cp1252_str = '%(title)s - 12" Mix'
    assert pp.format_to_regex(cp1252_str) == '(?P<title>.+)\ \-\ 12\\"\ Mix'
    assert pp.format_to_regex(cp1252_str.encode('cp1252'))

# Generated at 2022-06-24 14:19:54.557941
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # NOTE: This unittest only tests if an exception is raised,
    #       not if the regex is correct.
    from ydl.YDLHttpClient import YDLHttpClient
    from ydl.YDLDownloader import YDLDownloader
    from ydl.PostProcessors.common import PostProcessor
    from ydl.PostProcessors.MetadataFromTitlePP import MetadataFromTitlePP

    pp = MetadataFromTitlePP(YDLDownloader(YDLHttpClient()), '%(title)s - %(artist)s')
    info = {'title': 'Title'}

# Generated at 2022-06-24 14:20:00.940251
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    regex = pp.format_to_regex('%(title)s - %(artist)s')
    assert regex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'


from .compat import (
    compat_str,
    compat_urlparse,
)



# Generated at 2022-06-24 14:20:10.196365
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # create a test object
    postprocessor = MetadataFromTitlePP(None, '%(title)s - %(artist)s')

    # create a mockup downloader object
    class MockYDL:
        def to_screen(x, y):
            pass

    downloader = MockYDL()
    postprocessor.set_downloader(downloader)

    # test 1
    info = {'title' : 'My video - My artist'}
    postprocessor.run(info)

    assert info['title'] == 'My video'
    assert info['artist'] == 'My artist'

    # test 2
    info = {'title' : 'My video'}
    postprocessor.run(info)

    assert info['title'] == 'My video'
    assert 'artist' not in info.keys()


# Generated at 2022-06-24 14:20:18.495884
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftpp = MetadataFromTitlePP(None, None)
    tf = '%(title)s - %(artist)s'
    tr = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert tr == mftpp.format_to_regex(tf)
    tf = '%(title)s - %(artist)s - %(album)s'
    tr = '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'
    assert tr == mftpp.format_to_regex(tf)
    tf = '%(foo)s'
    tr = '(?P<foo>.+)'
    assert tr == mftpp.format_to_regex(tf)

# Generated at 2022-06-24 14:20:27.982332
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mft = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert mft.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert mft.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert mft.format_to_regex('%(title)s %(artist)s') == '(?P<title>.+)\ (?P<artist>.+)'
    assert mft.format_to_regex('%(title)s_%(artist)s') == '(?P<title>.+)\_(?P<artist>.+)'

# Generated at 2022-06-24 14:20:38.272699
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftpp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert mftpp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert mftpp.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert mftpp.format_to_regex('%(title)s -') == r'(?P<title>.+)\ \-'
    assert mftpp.format_to_regex('- %(title)s') == r'-\ (?P<title>.+)'

# Generated at 2022-06-24 14:20:44.067387
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    class Downloader:
        def to_screen(self, message):
            print(message)
    dl = Downloader()
    pp = MetadataFromTitlePP(dl, '%(artist)s - %(title)s')
    info = {
        'title': 'Adele - Hello',
    }
    expected_match = re.match(pp._titleregex, info['title'])
    actual_match = None
    assert expected_match.groupdict()['artist'] == 'Adele'
    assert expected_match.groupdict()['title'] == 'Hello'

    pp.run(info)
    assert info['artist'] == 'Adele'
    assert info['title'] == 'Hello'

# Generated at 2022-06-24 14:20:50.034314
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    for fmt in ['%(title)s - %(artist)s', 'The %(title)s - %(artist)s', 'The %(title)s - %(artist)s [%(asdf)s]']:
        assert pp._titleregex == pp.format_to_regex(fmt)
