

# Generated at 2022-06-24 14:10:54.663040
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from youtube_dl.YoutubeDL import YoutubeDL

# Generated at 2022-06-24 14:11:05.298015
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    processor = MetadataFromTitlePP(None, None)
    assert processor.format_to_regex(
        '%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert processor.format_to_regex(
        '%(title)s - %(artist)s %(title)s') == '(?P<title>.+)\ \-\ (?P<artist>.+) (?P<title>.+)'
    assert processor.format_to_regex(
        '%(title)s') == '(?P<title>.+)'
    assert processor.format_to_regex(
        '%(title)s - ') == '(?P<title>.+)\ \-'

# Generated at 2022-06-24 14:11:15.579011
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from collections import namedtuple
    import youtube_dl
    import unittest
    import sys

    class FakeYDL(youtube_dl.YoutubeDL):
        def __init__(self, *args, **kwargs):
            self.ydl_opts = kwargs.get('ydl_opts', {})
            self.to_screen_value = ''
            self.dicts = [{} for _ in args]

        def to_screen(self, text):
            self.to_screen_value += text

        def add_default_info_extractors(self):
            pass

        def add_info_extractor(self, ie):
            pass

    def w(*a, **kw):
        sys.stderr.write(str(a) + str(kw) + '\n')


# Generated at 2022-06-24 14:11:22.612156
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp._titleformat == '%(artist)s - %(title)s'
    assert pp._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'
    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '%(title)s'


# Generated at 2022-06-24 14:11:27.302586
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    """unit test for constructor of class MetadataFromTitlePP"""
    downloader = None
    titleformat = '%(artist)s - %(title)s'
    mft = MetadataFromTitlePP(downloader, titleformat)
    assert mft._titleformat == titleformat
    assert mft._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'


# Generated at 2022-06-24 14:11:38.151594
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    assert MetadataFromTitlePP(None, '%(title)s').format_to_regex('%(title)s') == '(?P<title>.+)'
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s').format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s').run({'title': 'chimpanzee - zoo'})[1] == {'title': 'chimpanzee', 'artist': 'zoo'}

# Generated at 2022-06-24 14:11:46.767829
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp._titleformat == '%(artist)s - %(title)s'
    assert pp._titleregex == r'(?P<artist>.+)\ \-\ (?P<title>.+)'
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s - %(album)s')
    assert pp._titleformat == '%(artist)s - %(title)s - %(album)s'
    assert pp._titleregex == r'(?P<artist>.+)\ \-\ (?P<title>.+)\ \-\ (?P<album>.+)'

# Generated at 2022-06-24 14:11:51.634421
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # prepare
    pp = MetadataFromTitlePP(None, None)

    # execute
    regex = pp.format_to_regex(r'%(title)s by %(artist)s')

    # verify
    assert regex.strip() == '(?P<title>.+)\\ by\\ (?P<artist>.+)', \
        'regex not as expected'

# Generated at 2022-06-24 14:11:59.272435
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    #### Set up a downloader mock
    def to_screen(text):
        screen.append(text)

    screen = []
    downloader = {'to_screen': to_screen}

    #### Test MetadataFromTitlePP
    titleformat = '%(title)s - %(artist)s'
    postprocessor = MetadataFromTitlePP(downloader, titleformat)

    # Formats that should be parsed correctly

# Generated at 2022-06-24 14:12:05.376547
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import youtube_dl
    ydl = youtube_dl.YoutubeDL({})
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    # check for parsing of regex
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'


if __name__ == '__main__':
    test_MetadataFromTitlePP()

# Generated at 2022-06-24 14:12:13.365940
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)

    assert pp.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert pp.format_to_regex('%(title)s%(artist)s') == r'(?P<title>.+)(?P<artist>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s-%(artist)s') == r'(?P<title>.+)-(?P<artist>.+)'


# Generated at 2022-06-24 14:12:23.441931
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # test empty format
    mft = MetadataFromTitlePP(None, '')
    assert '' == mft.format_to_regex('')

    # test a format without group
    mft = MetadataFromTitlePP(None, 'test %(something)s test')
    assert 'test\ test' == mft.format_to_regex('test %(something)s test')

    # test a simple format with a group
    mft = MetadataFromTitlePP(None, 'test %(something)s test')
    assert r'test\ (?P<something>.+)\ test' == mft.format_to_regex('test %(something)s test')

    # test a format with two groups
    mft = MetadataFromTitlePP(None, '%(a)s test %(something)s test')


# Generated at 2022-06-24 14:12:34.095753
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import unittest

    class MetadataFromTitlePPTestCase(unittest.TestCase):
        def test_MetadataFromTitlePP_format_to_regex(self):
            self.assertEqual(
                MetadataFromTitlePP(None, '%(title)s - %(artist)s')._titleregex,
                '(?P<title>.+)\ \-\ (?P<artist>.+)')
        def test_MetadataFromTitlePP_constructor_with_regex(self):
            self.assertEqual(
                MetadataFromTitlePP(None, '(?P<title>.+)\ \-\ (?P<artist>.+)')._titleregex,
                '(?P<title>.+)\ \-\ (?P<artist>.+)')

    suite = unittest.TestLoader().loadTestsFrom

# Generated at 2022-06-24 14:12:42.187620
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import youtube_dl
    ydl = youtube_dl.YoutubeDL(dict(quiet=True))
    postprocessor = MetadataFromTitlePP(ydl, '%(track)s - %(artist)s')
    assert postprocessor._titleregex == '(?P<track>.+)\ \-\ (?P<artist>.+)'
    postprocessor = MetadataFromTitlePP(ydl, '%(track)s')
    assert postprocessor._titleregex == '(?P<track>.+)'
    postprocessor = MetadataFromTitlePP(ydl, '%(track)s -')
    assert postprocessor._titleregex == '(?P<track>.+)\ \-'


# Generated at 2022-06-24 14:12:53.658478
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .youtube_dl_test import YoutubeDLTest
    from .downloader_test import FakeYDL
    test = YoutubeDLTest()
    test.setUp()
    ydl = FakeYDL()
    ydl.add_info_extractor(test.IE_NAME)
    ie = ydl._ies[test.IE_NAME]

    # One regex group
    pp = MetadataFromTitlePP(ydl, '%(id)s')
    # Matching title
    info = {'title': '3dg837e', 'id': 'video_ID'}
    ie._real_extract(test.playlist_url, info)
    test.assertEqual(pp.run(info)[1]['id'], '3dg837e')
    # Non-matching title

# Generated at 2022-06-24 14:12:59.863500
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .extractor import gen_extractors
    provider = 'generic'

    def _filter(e):
        """
        Only the 'generic' provider.
        """
        return e.IE_NAME == provider

    extractors = list(filter(_filter, gen_extractors()))
    assert len(extractors) == 1
    extractor = extractors[0]
    assert isinstance(extractor, PostProcessor)

    try:
        extractor = MetadataFromTitlePP(object(), '')
    except TypeError:
        pass


if __name__ == '__main__':
    test_MetadataFromTitlePP()

# Generated at 2022-06-24 14:13:08.046681
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    _test_cases = [
        ('%(title)s', '(?P<title>.+)'),
        ('%(title)s - %(artist)s', '(?P<title>.+)\ \-\ (?P<artist>.+)'),
        ('%(artist)s - %(title)s', '(?P<artist>.+)\ \-\ (?P<title>.+)'),
        ('%(artist)s and %(friends)s - %(title)s', '(?P<artist>.+)\ and\ (?P<friends>.+)\ \-\ (?P<title>.+)'),
        ('%(episode)d - %(title)s', '(?P<episode>\d+)\ \-\ (?P<title>.+)'),
    ]


# Generated at 2022-06-24 14:13:16.551617
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-24 14:13:23.036117
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    def test(fmt, regex):
        assert MetadataFromTitlePP(None, 'abcd').format_to_regex(
            fmt) == regex

    test('', '')
    test('%(title)s', r'(?P<title>.+)')
    test('%(title)s-%(artist)s', r'(?P<title>.+)-(?P<artist>.+)')
    test('  %(title)s\t- %(artist)s  ', r'  (?P<title>.+)\t- (?P<artist>.+)  ')

# Generated at 2022-06-24 14:13:28.229531
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Arrange
    arg1 = 'title'
    arg2 = '%(title)s - %(artist)s'
    expected = (
        r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    )

    # Act
    pp = MetadataFromTitlePP(arg1, arg2)

    # Assert
    assert pp._titleregex == expected


# Generated at 2022-06-24 14:13:37.778228
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    import nose.tools as nt
    pp = MetadataFromTitlePP(None, '')

    nt.assert_equal(pp.format_to_regex('%(title)s'), r'(?P<title>.+)')
    nt.assert_equal(pp.format_to_regex('%(title)s %(artist)s'),
                    r'(?P<title>.+)\ (?P<artist>.+)')
    nt.assert_equal(pp.format_to_regex(r'bla \%(title)s bla'),
                    r'bla\ \%\(title\)s\ bla')

# Generated at 2022-06-24 14:13:45.929452
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Don't run the test in parallel
    # https://github.com/rg3/youtube-dl/pull/2386#issuecomment-235146856
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert MetadataFromTitlePP(None, '%(title)s')
    assert MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert MetadataFromTitlePP(None, '%(artist)s - %(title)s - %(id)s')
    assert MetadataFromTitlePP(None, '%(id)s. %(id)s')

# Generated at 2022-06-24 14:13:56.666892
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import FileDownloader
    from .extractor.youtube import YoutubeIE

    class DummyYoutubeIE(YoutubeIE):
        def __init__(self, downloader):
            YoutubeIE.__init__(self, downloader)
            self.ie_key = 'dummy'

# Generated at 2022-06-24 14:14:00.696877
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Construct an instance of MetadataFromTitlePP
    mdftpp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    # Test the format_to_regex method in the constructor
    re.match(mdftpp._titleregex, 'Song Title - Artist Name')


# Generated at 2022-06-24 14:14:11.952414
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys

    class MockDownloader:
        def __init__(self):
            self.to_screen_out = []

        def to_screen(self, msg):
            self.to_screen_out.append(msg)

    downloader = MockDownloader()
    postprocessor = MetadataFromTitlePP(downloader, "%(artist)s - %(song)s")

    info = {'artist': 'Roni Size', 'song': 'It\'s Jazzy', 'title': 'TEST'}
    result = postprocessor.run(info)
    assert result == ([], info)
    assert downloader.to_screen_out == []

    info = {'artist': 'Roni Size', 'song': 'It\'s Jazzy', 'title': 'Roni Size - It\'s Jazzy'}

# Generated at 2022-06-24 14:14:22.221755
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import FileDownloader
    downloader = FileDownloader({})
    mft = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    assert mft.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert mft.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert mft.format_to_regex('%(title)s a %(title)s') == r'(?P<title>.+)\ a\ \1'

# Generated at 2022-06-24 14:14:25.252887
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    fmt = r'%(title)s - %(artist)s'
    fmt = MetadataFromTitlePP._MetadataFromTitlePP__format_to_regex(fmt)
    assert fmt == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-24 14:14:34.676465
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():

    from .common import Downloader
    from .YoutubeDL import YoutubeDL
    pp = MetadataFromTitlePP(
        Downloader(YoutubeDL())
    )

    def assert_regex(title_format, regex_expected):

        regex = pp.format_to_regex(title_format)
        assert regex == regex_expected, "error while converting" + \
            " '" + title_format + "' to regex:\n" + \
            "expected '" + regex_expected + "'\n" + \
            "got '" + regex + "'"

    assert_regex(r'%(title)s', r'(?P<title>.+)')

# Generated at 2022-06-24 14:14:42.149881
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '%(title)s'

    pp = MetadataFromTitlePP(None, 'foo bar')
    assert pp._titleformat == 'foo bar'
    assert pp._titleregex == 'foo bar'


# Generated at 2022-06-24 14:14:49.462983
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    import os
    import tempfile

    # create test object
    downloader = object()
    titleformat = '%(title)s - %(artist)s'
    test_obj = MetadataFromTitlePP(downloader, titleformat)
    # get method and test it
    fmt2regex = test_obj.format_to_regex
    assert fmt2regex(titleformat) == '(?P<title>.+)\ \\-\ (?P<artist>.+)'

    titleformat = '%(title)s - %(artist)s.%(ext)s'
    assert fmt2regex(titleformat) == (
        '(?P<title>.+)\ \\-\ '
        '(?P<artist>.+)\.(?P<ext>.+)')


# Generated at 2022-06-24 14:14:59.871308
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import pytest
    titleformat = '%(artist)s - %(title)s %(track)s'
    title_to_regex = '{} - {} {}'.format(r'(?P<artist>.+)', r'(?P<title>.+)', r'(?P<track>.+)')
    info = {'title': 'Michael Jackson - Earth Song 13'}

    def to_screen(msg):
        print(msg)

    pp = MetadataFromTitlePP(to_screen, titleformat)
    assert pp._titleregex == title_to_regex
    metadata, info_new = pp.run(info)
    assert metadata == []
    assert 'artist' in info_new
    assert 'title' in info_new
    assert 'track' in info_new

# Generated at 2022-06-24 14:15:09.743326
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # pylint: disable=protected-access
    test_info = {'title': 'Test title - Test artist - 1999'}

    uut = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(year)s')
    uut._titleregex = r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<year>\d{4})'

    # Test case: test_info is empty and values match title format
    [actual_videos, actual_info] = uut.run(test_info)

    assert 1 == len(actual_videos)
    assert {} == actual_videos[0]

# Generated at 2022-06-24 14:15:18.561464
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .downloader import Downloader
    from .extractor import YoutubeIE

    titleformat = '%(title)s - %(artist)s'
    fileinfos = [
        {'title': 'Song#1 - The Artist'},
        {'title': 'Song#2 - The Artist - The Album'},
        {'title': 'Song#3 Artist'},
        {'title': 'Song#4 - The Artist/The Album'},
    ]

    pp = MetadataFromTitlePP(Downloader(), titleformat)
    fileinfos_new = list(map(MetadataFromTitlePP.run, [pp] * len(fileinfos), fileinfos))


# Generated at 2022-06-24 14:15:29.834140
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class Info(dict):
        pass
    class Downloader(object):
        def to_screen(self, msg):
            pass

    title = 'TITLE_TITLE - ARTIST_ARTIST - YEAR_YEAR - ALBUM_ALBUM'
    info = Info(title=title)
    fmt = '%(title)s - %(artist)s - %(album)s - %(year)s - %(other)s'
    pp = MetadataFromTitlePP(Downloader(), fmt)

    pp.run(info)
    assert info['title'] == 'TITLE_TITLE'
    assert info['artist'] == 'ARTIST_ARTIST'
    assert info['album'] == 'ALBUM_ALBUM'
    assert info['year'] == 'YEAR_YEAR'

# Generated at 2022-06-24 14:15:36.254870
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.FileDownloader import FileDownloader
    fileDownloader = FileDownloader({}, YoutubeDL({}))
    l = MetadataFromTitlePP(fileDownloader, "%(title)s - %(artist)s")
    assert l._titleformat == "%(title)s - %(artist)s"
    assert l._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-24 14:15:42.785631
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, "")
    assert '%(title)s' == pp.format_to_regex(r'(?P<title>.+)')
    assert '%(title)s' == pp.format_to_regex('%(title)s')
    assert '%(title)s' == pp.format_to_regex('prefix-%(title)s')
    assert '%(title)s' == pp.format_to_regex('%(title)s-suffix')
    assert '%(title)s' == pp.format_to_regex('prefix-%(title)s-suffix')
    assert '%(title)s' == pp.format_to_regex('prefix-%(title)s-%(title)s')

# Generated at 2022-06-24 14:15:54.157548
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.compat import compat_kwargs
    from youtube_dl import YoutubeDL

    class FakeInfoDict(dict):
        def __getitem__(self, key):
            if key not in self:
                self[key] = None

            return self.get(key)

        def __setitem__(self, key, value):
            self[key] = value

    # Test MetadataFromTitlePP parses title OK and passes through info object unchanged
    fake_ydl = YoutubeDL(params={})
    fake_info = FakeInfoDict({
            'id': '12345',
            'title': 'test - random',
            'upload_date': 'random',
            'description': 'random'
        })


# Generated at 2022-06-24 14:16:03.582788
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl
    import os

    # dummy downloader
    class DummyDownloader():
        def __init__(self):
            self.to_screen_trace = ''
        def to_screen(self, text):
            self.to_screen_trace += text

    # dummy filename
    class DummyFile():
        def __init__(self, filename):
            self.filename = filename

    # test cases

# Generated at 2022-06-24 14:16:13.235360
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    downloader = None
    titleformat = '%(title)s - %(artist)s'
    metadata_from_title_pp = MetadataFromTitlePP(downloader, titleformat)
    # verify conversion of formatting string to regex is correct
    assert metadata_from_title_pp._titleregex == \
        r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    title = 'The title - The artist'
    # verify that regex pattern matches string
    match = re.match(metadata_from_title_pp._titleregex, title)
    assert match is not None
    # verify that regex pattern does not match None
    assert re.match(metadata_from_title_pp._titleregex, None) is None
    # verify that regex pattern does not match different string

# Generated at 2022-06-24 14:16:23.507560
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '')

    assert pp.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s') == \
        '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(artist)s - %(title)s') == \
        '(?P<artist>.+)\ \-\ (?P<title>.+)'
    assert pp.format_to_regex('%(artist)s - %(artist)s') == \
        '(?P<artist>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-24 14:16:29.792946
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.downloader import Downloader
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl_opts = {
        'outtmpl': '%(id)s.%(ext)s',
        'verbose': True,
        'quiet': True,
        'simulate': True,
        'nooverwrites': True,
        'writethumbnail': True,
        'writeinfojson': True,
        'writedescription': True,
        'writeannotations': True,
        'writeautomaticsub': True,
        'subtitleslangs': ['en', 'es', 'fr']}

# Generated at 2022-06-24 14:16:33.050516
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from pytube.postprocessor import MetadataFromTitlePP
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp.format_to_regex('%(artist)s - %(title)s') == '(?P<artist>.+)\\ \-\\ (?P<title>.+)'

# Generated at 2022-06-24 14:16:35.965188
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    PP = MetadataFromTitlePP(None, '%(artist)s - %(track)s')
    assert PP._titleformat == '%(artist)s - %(track)s'
    assert PP._titleregex == '(?P<artist>.+)\ \-\ (?P<track>.+)'

# Generated at 2022-06-24 14:16:44.594202
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class test_downloader():
        def to_screen(self, message):
            pass
    test_downloader = test_downloader()
    test_titleformat = '%(title)s - %(artist)s'
    test_info = {'title': 'Title - Artist', 'extractor': 'Video'}
    test_metadataFromTitlePP = MetadataFromTitlePP(test_downloader, test_titleformat)
    metadata = test_metadataFromTitlePP.run(test_info)
    if metadata[0] == []:
       print('Test MetadataFromTitlePP::run() is passed')
    else:
       print('Test MetadataFromTitlePP::run() is failed')


# Generated at 2022-06-24 14:16:49.903413
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Testing regex with keywords '%(title)s' and '%(artist)s'
    titleformat = '%(title)s - %(artist)s'
    test_data = [
        ('Test title - Test artist',
         {'title': 'Test title', 'artist': 'Test artist'})
    ]
    _test_run(titleformat, test_data)

    # Testing regex with keyword '%(title)s'
    titleformat = '%(title)s - %(artist)s'
    test_data = [
        ('Test title - Test artist - test album',
         {'title': 'Test title - Test artist - test album',
          'artist': None})]
    _test_run(titleformat, test_data)

    # Testing regex without keywords
    titleformat = '^test data'
    test

# Generated at 2022-06-24 14:16:58.295314
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    import unittest

    class TestMetadataFromTitlePPFormatToRegex(unittest.TestCase):

        def setUp(self):
            self.mftpp = MetadataFromTitlePP(None, None)

        def test_format_to_regex(self):
            self.assertEqual(self.mftpp.format_to_regex('%(title)s'), '(?P<title>.+)')
            self.assertEqual(self.mftpp.format_to_regex('%(title)s - %(artist)s'), '(?P<title>.+)\ \-\ (?P<artist>.+)')

# Generated at 2022-06-24 14:17:08.790639
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    mpp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert mpp._titleformat == '%(title)s - %(artist)s'
    assert mpp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert mpp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert mpp.format_to_regex('%(title)s - %(artist)s - %(album)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'


# Generated at 2022-06-24 14:17:16.960585
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    # Testing basic functionality of method run
    from .common import FileDownloader
    from .extractor import YoutubeIE

    class FakeInfoExtractor(YoutubeIE):

        def _real_extract(self, url):
            return {'id': 'mocked'}

    ydl = FileDownloader()
    ie = FakeInfoExtractor(ydl)
    ie.add_info_extractor(ie)

    # Testing basic functionality
    info = {'title': 'Mocked title - Mocked artist',
            'ext': 'mp4'}
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    pp.run(info)

    assert info == {'title': 'Mocked title',
                    'artist': 'Mocked artist',
                    'ext': 'mp4'}



# Generated at 2022-06-24 14:17:27.536717
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from ytdl.extractor import common
    from ytdl.jsinterp import JSInterpreter
    from ytdl.postprocessor import MetadataFromTitlePP

    # This is the downloader object which is used for all the calls in
    # this unit test.

# Generated at 2022-06-24 14:17:36.709243
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Given
    data = {
        'title': 'Title - Artist',
        'ext': 'mp4',
    }
    titleformat = '%(title)s - %(artist)s'
    fromtitle = MetadataFromTitlePP(None, titleformat)

    # When
    actual = fromtitle.run(data)[1]

    # Then
    expected = {
        'title': 'Title',
        'artist': 'Artist',
        'ext': 'mp4',
    }
    assert actual == expected


# Generated at 2022-06-24 14:17:43.540784
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    inst = MetadataFromTitlePP('downloader', '%(title)s - %(artist)s')
    assert inst._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    inst = MetadataFromTitlePP('downloader', '%(title)s')
    assert inst._titleregex == '%(title)s'



# Generated at 2022-06-24 14:17:54.848425
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftpp = MetadataFromTitlePP(None, None)
    # Test with a basic format string
    regex = mftpp.format_to_regex('%(title)s - %(artist)s')
    assert regex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    # Test with a format string with backslashes (\\)
    regex = mftpp.format_to_regex(r'%(title)s \\ %(artist)s')
    assert regex == r'(?P<title>.+)\ \\\\\ (?P<artist>.+)'

    # Test with a format string with dots (.)
    regex = mftpp.format_to_regex('%(title)s - %(artist)s - %(album)s')
    assert regex == r

# Generated at 2022-06-24 14:18:00.880464
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    regex = ''.join([
        '(?P<title>.+)',
        ' \- ',
        '(?P<artist>.+)'
    ])
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == regex


# Generated at 2022-06-24 14:18:03.128549
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from ytdl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(artist)s - %(title)s'))

if __name__ == '__main__':
    test_MetadataFromTitlePP()

# Generated at 2022-06-24 14:18:06.677776
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    fmt = '%(title)s - %(artist)s'
    regex = '(?P<title>.+)\\ \-\\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, fmt).format_to_regex(fmt) == regex

# Generated at 2022-06-24 14:18:15.965253
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor import FFmpegMetadataPP

    ydl = YoutubeDL({'writethumbnail': True, 'skip_download': True,
                     'simulate': True, 'quiet': True, 'forcejson': True,
                     'format': 'bestaudio/best', 'noplaylist': True,
                     'postprocessors': [{
                         'key': 'FFmpegMetadata'}],
                     'logger': FileDownloader()})

    def _add_video(title):
        ydl.add_default_info_extractors()

# Generated at 2022-06-24 14:18:20.912180
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    assert(MetadataFromTitlePP(None, '%(title)s - %(artist)s')
        ._titleregex == '\(?P<title>.+\)\ \-\ \(?P<artist>.+\)')
    assert(MetadataFromTitlePP(None, '%(title)s')._titleregex == '%(title)s')
    assert(MetadataFromTitlePP(None, '(?P<title>.+)')._titleregex == '\(?P<title>.+\)')



# Generated at 2022-06-24 14:18:30.121272
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import tempfile
    import unittest

    if sys.version_info[0] > 2:
        import io as io_module
    else:
        import io as io_module
    try:
        from unittest import mock
    except ImportError:
        import mock
    import youtube_dl.downloader


# Generated at 2022-06-24 14:18:36.442215
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    downloader = None
    titleformat = '%(title)s - %(artist)s'
    metadata_from_title_pp = MetadataFromTitlePP(downloader, titleformat)
    regex_expected = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert regex_expected == metadata_from_title_pp._titleregex

    title_test = 'Title - Artist'
    attributes_expected = {'title': 'Title', 'artist': 'Artist'}
    info_input = {'title': title_test}
    info_expected = {'title': title_test}
    info_expected.update(attributes_expected)
    info_output = metadata_from_title_pp.run(info_input)[1]
    assert info_expected == info_output

# Generated at 2022-06-24 14:18:45.522462
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import cli

    downloader = cli.YoutubeDL({'forcemetadata': False})
    class FakeInfo:
        def __init__(self, title):
            self.title = title
        def __contains__(self, key):
            return key in ['title']
        def __getitem__(self, key):
            return self.title

# Generated at 2022-06-24 14:18:54.930518
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(name)s')
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<name>.+)'

    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(name)s - %(category)s')

# Generated at 2022-06-24 14:18:56.310190
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s')


# Generated at 2022-06-24 14:19:03.582850
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    tests = [
        ('%(title)s',          "(?P<title>.+)"),
        ('%(title)s%(artist)s', "(?P<title>.+)(?P<artist>.+)"),
        ('%(title)s - %(artist)s', "(?P<title>.+)\ \-\ (?P<artist>.+)"),
        ('(3D)%(title)s - %(artist)s', "(?P<title>.+)\ \-\ (?P<artist>.+)"),
        ('%(title)s %(artist)s', "(?P<title>.+)\ (?P<artist>.+)"),
    ]
    pp = MetadataFromTitlePP(None, '')
    for test, expected in tests:
        assert(pp.format_to_regex(test) == expected)



# Generated at 2022-06-24 14:19:08.080791
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(title)s - %(album)s')
    assert pp.format_to_regex('%(title)s - %(album)s') == r'(?P<title>.+)\ \-\ (?P<album>.+)'

# Generated at 2022-06-24 14:19:16.447926
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    sys.modules['__main__'].to_screen = lambda x: x

    def testMetadataFromTitlePP_run(titleformat, title, expected_result):
        obj = MetadataFromTitlePP(None, titleformat)
        info = {'title': title}
        (result, info) = obj.run(info)
        if result != expected_result:
            print('ERROR: MetadataFromTitlePP.run:')
            print('Title format:   %s' % titleformat)
            print('Title:          %s' % title)
            print('Expected result:')
            print(expected_result)
            print('Actual result:')
            print(result)
            return False
        return True


# Generated at 2022-06-24 14:19:24.997042
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class FakeInfo(dict):
        def __init__(self, *args, **kwargs):
            self['title'] = 'Test - Title - 1'
            self['description'] = 'Description'

    mftpp = MetadataFromTitlePP(None, '%(artist)s - %(title)s - %(track)s')
    (_, info) = mftpp.run(FakeInfo())

    assert info['artist'] == 'Test'
    assert info['title'] == 'Title'
    assert info['track'] == '1'
    assert info['description'] == 'Description'


# Generated at 2022-06-24 14:19:33.329394
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    import unittest
    class Test(unittest.TestCase):
        def test_format_to_regex(self):
            mft = MetadataFromTitlePP(None, None)
            self.assertEqual(mft.format_to_regex('%(title)s - %(artist)s'),
                             '(?P<title>.+)\ \-\ (?P<artist>.+)')
            self.assertEqual(mft.format_to_regex('%(title)s'),
                             '(?P<title>.+)')
            self.assertEqual(mft.format_to_regex('%(title)s [%(artist)s]'),
                             '(?P<title>.+)\ \[(?P<artist>.+)\]')

# Generated at 2022-06-24 14:19:39.342476
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    assert MetadataFromTitlePP(
        None, '%(title)s - %(artist)s').format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-24 14:19:50.031605
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .common import FileDownloader
    from .extractor import YoutubeIE

    info = {
        'id': 'JY9qk-Dq_tQ',
        'upload_date': '20141128',
        'extractor': 'youtube:playlist',
        'title': 'Steffen',
        'description': 'This is just a test',
        'thumbnail': 'https://i.ytimg.com/vi/JY9qk-Dq_tQ/maxresdefault.jpg',
        'duration': 1234,
        'uploader': 'test',
        'uploader_url': 'https://www.youtube.com/user/test',
        'uploader_id': 'test',
        'view_count': 32452,
    }

# Generated at 2022-06-24 14:19:55.129298
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    import pytest

    from .common import PostProcessor

    class MetadataFromTitlePP_test(MetadataFromTitlePP):
        def __init__(self, downloader, titleformat):
            super(MetadataFromTitlePP_test, self).__init__(downloader, titleformat)

    test_formatter = MetadataFromTitlePP_test('downloader', '%(a)s - %(b)s')
    assert test_formatter.format_to_regex('%(a)s') == '(?P<a>.+)'
    assert test_formatter.format_to_regex('%(a)s - %(b)s') == '(?P<a>.+)\ \-\ (?P<b>.+)'

# Generated at 2022-06-24 14:20:06.187072
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    import unittest

    class Test(unittest.TestCase):
        def test(self):
            from .postprocessor import MetadataFromTitlePP

            pp = MetadataFromTitlePP(None, "")

            self.assertEqual(pp.format_to_regex("test"), "test")
            self.assertEqual(pp.format_to_regex("test%(one)s"), r"test(?P<one>.+)")
            self.assertEqual(pp.format_to_regex("test%(one)s%(two)s"), r"test(?P<one>.+)(?P<two>.+)")

# Generated at 2022-06-24 14:20:14.167946
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import _common
    downloader = _common.FakeYDL()
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    info = {'title': 'On top of old smokey - True artist'}
    info_after = {'title': 'On top of old smokey - True artist',
                  'artist': 'True artist'}
    pp.run(info)
    assert pp._titleregex == 'On top of old smokey\ \-\ (?P<artist>.+)'
    assert info == info_after
    info = {'title': 'On top of old smokey - True artist', 'artist': '-'}
    info_after = {'title': 'On top of old smokey - True artist',
                  'artist': 'True artist'}

# Generated at 2022-06-24 14:20:25.378359
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    def test(fmt, expected_regex):
        regex = MetadataFromTitlePP(None, fmt)._titleregex
        if regex != expected_regex:
            print(('FAIL: MetadataFromTitlePP(None, "%s")._titleregex != "%s"'
                   % (fmt, expected_regex)))
            print('     but "%s"\n' % regex)

    test('', '^$')
    test('abc', 'abc')
    test('%(title)s', r'(?P<title>.+)')
    test('%(artist)s - %(title)s - %(album)s',
         r'(?P<artist>.+)\ \-\ (?P<title>.+)\ \-\ (?P<album>.+)')

# Generated at 2022-06-24 14:20:35.470239
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ..common import FileDownloader
    pp = MetadataFromTitlePP(FileDownloader(None, None), '%(title)s')
    assert pp.run(dict(title='title')) == ([], {'title': 'title'})
    pp = MetadataFromTitlePP(FileDownloader(None, None), '%(title)s-%(year)s')
    assert pp.run(dict(title='title-year')) == ([], {'title': 'title', 'year': 'year'})
    pp = MetadataFromTitlePP(FileDownloader(None, None), '%(title)s-%(foo)s')
    assert pp.run(dict(title='title-foo')) == ([], {'title': 'title', 'foo': 'foo'})

# Generated at 2022-06-24 14:20:41.263324
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class MockYDL:
        def to_screen(self, str):
            print(str)

    ydl = MockYDL()
    pp = MetadataFromTitlePP(ydl, titleformat='%(title)s - %(artist)s')
    info = dict()
    info['title'] = 'mytitle - myartist'
    pp.run(info)
    assert info['title'] == 'mytitle - myartist'
    assert info['artist'] == 'myartist'
    assert info['title'] != 'myartist'


# Generated at 2022-06-24 14:20:51.155175
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    metadata = {'title':'some title with spaces - some artist'}
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    _, result = pp.run(metadata)
    assert result['title'] == 'some title with spaces'
    assert result['artist'] == 'some artist'

    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(album)s')
    _, result = pp.run(metadata)
    assert 'album' not in result
    assert result['title'] == 'some title with spaces'
    assert result['artist'] == 'some artist'

    metadata = {'title':'some title with spaces - some artist - some album'}