

# Generated at 2022-06-24 14:10:56.929883
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-24 14:11:04.373182
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():

    mpp = MetadataFromTitlePP(None, 'test')

    tests = [
        ('%(title)s - %(artist)s', r'(?P<title>.+)\ \-\ (?P<artist>.+)'),
        ('%(title)s', r'(?P<title>.+)'),
        ('%(title)s -', r'(?P<title>.+)\ \-')]

    for test in tests:
        assert mpp.format_to_regex(test[0]) == test[1]

# Generated at 2022-06-24 14:11:14.707122
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP.format_to_regex(
        '%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP.format_to_regex(
        '%(title)s') == r'(?P<title>.+)'
    assert MetadataFromTitlePP.format_to_regex(
        '%(title)s - %(artist)s - %(album)s') == (r'(?P<title>.+)\ \-\ '
                                                 r'(?P<artist>.+)\ \-\ '
                                                 r'(?P<album>.+)')

# Generated at 2022-06-24 14:11:25.081277
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    def get_info(title):
        return {
            'title': title
        }

    import sys
    import pytest

    ###########################################################################
    # Normal usage with %(title)s
    ###########################################################################
    info = get_info(
        'video title - artist name [path/to/video.mp4] [1080p] [hd] [1.6GB]'
    )

    downloader = FakeDownloader({'titleformat': '%(title)s'})
    pp = MetadataFromTitlePP(downloader, '%(title)s')
    (new_info, ) = pp.run(info)

    assert new_info['title'] == 'video title'

    ###########################################################################
    # Error case with %(title)s
    ###########################################################################
    downloader = FakeDownload

# Generated at 2022-06-24 14:11:31.122612
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    metadatapp = MetadataFromTitlePP(None, None)
    assert metadatapp.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert metadatapp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-24 14:11:40.898873
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.Downloader import Downloader
    from youtube_dl import FileDownloader
    titleformat = '%(title)s - %(artist)s'
    fromtitle = MetadataFromTitlePP(Downloader(YoutubeDL(), FileDownloader()), titleformat)
    # test for titleformat without named groups
    titleformat = '%(title)s - %(artist)s'
    title = 'L\'orgue de barbarie - Mireille'
    expected = {'title':"L'orgue de barbarie", 'artist':"Mireille"}
    # test for titleformat with named groups
    titleformat = '(?P<title>.*)\ \-\ (?P<artist>.*)'
    title = 'L\'orgue de barbarie - Mireille'

# Generated at 2022-06-24 14:11:49.161804
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    """
    Unit test for constructor of class MetadataFromTitlePP
    """
    # Check that the constructor of class MetadataFromTitlePP raises
    # an Exception if neither a format nor a regex is passed as
    # parameter #titleformat
    assert_raises(
        TypeError,
        MetadataFromTitlePP,
        None, None
    )
    # Check that the constructor of class MetadataFromTitlePP raises
    # an Exception if the parameter #titleformat is unchanged
    # and only whitespaces are passed
    assert_raises(
        ValueError,
        MetadataFromTitlePP,
        None, '   '
    )
    # Check that the constructor of class MetadataFromTitlePP raises
    # an Exception if the parameter #titleformat is unchanged
    # and an empty string is passed

# Generated at 2022-06-24 14:11:58.991293
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    regex = MetadataFromTitlePP(None, None).format_to_regex
    assert regex('') == ''
    assert regex('#') == '#'
    assert regex('##') == '##'
    assert regex('# #') == '#\\ #'
    assert regex('#1#2#') == '#1#2#'
    assert regex('%(abc)s#%(def)s') == '(?P<abc>.+)#(?P<def>.+)'
    assert regex(
        '%(#(?P<abc>123)%(def)s') == '(?P<abc>123)(?P<def>.+)'

# Generated at 2022-06-24 14:12:05.470446
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    """Tests that MetadataFromTitlePP initializes _titleregex to the expected
    value when titleformat has only literals
    """
    downloader = None
    titleformat = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(downloader, titleformat)
    expected_regex = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp._titleregex == expected_regex


# Generated at 2022-06-24 14:12:14.013711
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pp = MetadataFromTitlePP(None, "%(title)s - %(artist)s")
    info = {"title": "Hello - World"}
    pp.run(info)
    assert info.get("title") == "Hello"
    assert info.get("artist") == "World"
    pp = MetadataFromTitlePP(None, "%(title)s - %(artist)s")
    info = {"title": "Hello - World NNN"}
    pp.run(info)
    assert info.get("title") == "Hello"
    assert info.get("artist") == "World"
    pp = MetadataFromTitlePP(None, "%(title)s - %(artist)s")
    info = {"title": "Hello"}
    pp.run(info)
    assert info.get("title") == "Hello"

# Generated at 2022-06-24 14:12:18.911864
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    test_str = r'%(title)s - %(artist)s'
    exp_str = r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    pp = MetadataFromTitlePP(None, test_str)
    assert pp.format_to_regex(test_str) == exp_str

# Generated at 2022-06-24 14:12:26.234180
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl
    downloader = youtube_dl.YoutubeDL()

    mft_pp = MetadataFromTitlePP(downloader, '%(artist)s - %(title)s')
    assert mft_pp.format_to_regex('%(artist)s - %(title)s') == '(?P<artist>.+)\ \-\ (?P<title>.+)'

    assert mft_pp.run({'title': 'foo'}) == ([], {'title': 'foo'})

    assert mft_pp.run({'title': 'Bar - Baz - bzz'}) == ([], {'title': 'Bar - Baz - bzz'})
    assert mft_pp.run({'title': 'Bar - Baz - bzz'}) == ([], {'title': 'Bar - Baz - bzz'})



# Generated at 2022-06-24 14:12:36.271626
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ..YoutubeDL import YoutubeDL
    from ..utils import DateRange

    def test(titleformat, video_title, expected_result):
        downloader = YoutubeDL(params={'writethumbnail': True,
                                       'skip_download': True,
                                       'noplaylist': True,
                                       'usenetrc': True,
                                       'forcetitle': True,
                                       'matchtitle': titleformat,
                                       'outtmpl': '%(title)s.%(ext)s'})
        downloader.add_info_extractor(DummyIE(title=video_title))
        video = DummyIE.result()
        video['title'] = video_title

        # The expected result can be a string, in which case
        # we check if the title is set to this value, or it
       

# Generated at 2022-06-24 14:12:45.236813
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    Test method MetadataFromTitlePP.run
    """
    # Imports inside method so it is not testable with 'python -m unittest'
    from youtube_dl.downloader import HttpFD

    class FakeYDL(object):
        def to_screen(self, msg):
            pass


# Generated at 2022-06-24 14:12:54.437332
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .test import get_test_default_downloader
    from .test import get_test_video_result
    from .test import make_result_object
    downloader = get_test_default_downloader()
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    results = [get_test_video_result()]
    title = 'Test Title - Test Artist'
    results[0]['title'] = title
    results = pp.run(make_result_object(downloader, results, expected_status=True))
    assert results.title == title
    assert results.artist == 'Test Artist'
    assert results.title == title

# Generated at 2022-06-24 14:12:57.798064
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    info = {'title': 'test - sample'}
    pp = MetadataFromTitlePP(None, '%(test)s - %(sample)s')
    pp.run(info)
    assert info['test'] == 'test'
    assert info['sample'] == 'sample'


# Generated at 2022-06-24 14:13:03.776729
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, 'A%(number)02dB').format_to_regex('A%(number)02dB') == 'A(?P<number>\\d{2})B'
    assert MetadataFromTitlePP(None, '**%(title)s - %(artist)s').format_to_regex('**%(title)s - %(artist)s') == '\\*\\*(?P<title>.+)\\ \\\-\\ (?P<artist>.+)'

# Generated at 2022-06-24 14:13:14.045455
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .common import FakeYDL
    downloader = FakeYDL()
    pp = MetadataFromTitlePP(downloader, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '(?P<title>.+)'
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    pp = MetadataFromTitlePP(downloader, 'ABC%(title)sXYZ')
    assert pp._titleformat == 'ABC%(title)sXYZ'

# Generated at 2022-06-24 14:13:23.208629
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    youtube_dl = FakeYDL()
    youtube_dl.params['writethumbnail'] = True

    # Test simple case
    pp = MetadataFromTitlePP(youtube_dl, '%(artist)s - %(title)s')
    assert pp._titleregex == r'(?P<artist>.+)\ \-\ (?P<title>.+)'

    # Test with more complex cases
    pp = MetadataFromTitlePP(youtube_dl, '%(artist)s - [%(title)s]')
    assert pp._titleregex == r'(?P<artist>.+)\ \-\ \[(?P<title>.+)\]'

    pp = MetadataFromTitlePP(youtube_dl, 'tag=%(tag)s')
    assert pp._titleregex == r'(?P<tag>.+)'



# Generated at 2022-06-24 14:13:33.774122
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Test for regular case
    pp = MetadataFromTitlePP('yt', '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    # Test for invalid input
    pp = MetadataFromTitlePP('yt', '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    # Test for no metadatas in video title

# Generated at 2022-06-24 14:13:41.118572
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL()

    # Test a simple string not containing a format string
    titleformat = "SomeString"
    titleregex = re.compile(titleformat)
    assert MetadataFromTitlePP(ydl, titleformat)._titleregex == titleregex

    # Test the conversion of a format string to a regex string
    titleformat = '%(title)s - %(artist)s'
    titleregex = re.compile(r'(?P<title>.+)\ \-\ (?P<artist>.+)')
    assert MetadataFromTitlePP(ydl, titleformat)._titleregex == titleregex

# Generated at 2022-06-24 14:13:47.147773
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import io
    from youtube_dl.YoutubeDL import YoutubeDL
    import unittest

    class MockLogger():
        def to_screen(msg):
            print(msg)

    mock_downloader = YoutubeDL({})
    mock_downloader.to_screen = MockLogger.to_screen
    mock_downloader.params = {}
    info = {}
    ff = MetadataFromTitlePP(mock_downloader, '%(title)s - %(artist)s')
    test_res, test_info = ff.run(info)

    ref_res = []
    ref_info = {}
    assert test_res == ref_res
    assert test_info == ref_info

# Generated at 2022-06-24 14:13:58.742191
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import Downloader
    from .extractor import YoutubeIE
    from .utils import DateRange

    fmt = '%(artist)s - %(song)s'
    regex = '.*'

# Generated at 2022-06-24 14:14:02.966764
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    mftpp = MetadataFromTitlePP(None,'%(title)s')
    assert mftpp._titleformat == '%(title)s'
    assert mftpp._titleregex == '(?P<title>.+)'
    mftpp = MetadataFromTitlePP(None,'%(title)s - %(artist)s')
    assert mftpp._titleformat == '%(title)s - %(artist)s'
    assert mftpp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-24 14:14:12.085580
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor.youtube import YoutubeIE
    downloader = FileDownloader({})
    downloader.add_info_extractor(YoutubeIE())
    downloader.add_post_processor(MetadataFromTitlePP(downloader, '%(artist)s - %(title)s'))
    downloader.add_post_processor(MetadataFromTitlePP(downloader, '%(title)s'))
    downloader.add_post_processor(MetadataFromTitlePP(downloader, '%(artist)s - %(title)s - %(ext)s'))
    downloader.add_post_processor(MetadataFromTitlePP(downloader, 'Unknown'))

# Generated at 2022-06-24 14:14:22.363084
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-24 14:14:31.273932
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from youtube_dl.utils import make_HTTPServer
    server = make_HTTPServer()
    server.add_handler('/watch', lambda r: r.ok(b'<title>%(title)s</title>'))
    server.add_handler('/watch', lambda r: r.ok(b'<title>%(artist)s - %(title)s</title>'))
    server.start()

# Generated at 2022-06-24 14:14:39.670084
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest
    testfmt = '%(title)s - %(artist)s'
    testtitle = 'Funny clip - Some Artist'
    exp_match = {'title': 'Funny clip', 'artist': 'Some Artist'}

    class FakeInfoDict(dict):
        def __init__(self, title):
            self['title'] = title

    class FakeDownloader(object):
        def __init__(self):
            self._screen_messages = []

        def to_screen(self, msg):
            self._screen_messages.append(msg)

        def get_screen_messages(self):
            return self._screen_messages

    class TestCase(unittest.TestCase):
        def test_MetadataFromTitlePP_run(self):
            fake_downloader = FakeDownload

# Generated at 2022-06-24 14:14:47.597748
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # create an instance of YoutubeDL
    class _InfoDict():
        pass

    class _Downloader():
        to_screen_called = ''
        def to_screen(self, text):
            self.to_screen_called += text + '\n'

    ydl = _Downloader()

    # create an instance of MetadataFromTitlePP
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')

    # test the method run
    info = _InfoDict()
    info.title = 'Wrecking Ball - Miley Cyrus'
    infos, _ = pp.run(info)
    assert ydl.to_screen_called == '[fromtitle] parsed title: Wrecking Ball\n[fromtitle] parsed artist: Miley Cyrus\n'
    assert infos == []

# Generated at 2022-06-24 14:14:58.062129
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ydl.postprocessor.run import run_post_processors
    from ydl.YoutubeDL import YoutubeDL
    postprocessors = run_post_processors({}, [{
        'key': 'MetadataFromTitle',
        'format': '(?P<artist>.+?) - (?P<title>.+)',
    }], True)
    assert len(postprocessors) == 1
    postprocessor = postprocessors[0]
    assert postprocessor.__class__ == MetadataFromTitlePP
    assert postprocessor._titleformat == '(?P<artist>.+?) - (?P<title>.+)'
    assert postprocessor._titleregex == '(?P<artist>.+?) - (?P<title>.+)'

# Generated at 2022-06-24 14:15:08.118522
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .test import get_test_descriptors

    # test format without groups
    titleformat = '%(title)s - %(artist)s'
    title = 'Piece of video title - A video artist'
    info = {'title': title}
    descs = get_test_descriptors(title)
    mftpp = MetadataFromTitlePP(None, titleformat)
    descs_out, info_out = mftpp.run(info)
    assert descs_out == descs
    assert info_out['title'] == 'Piece of video title'
    assert info_out['artist'] == 'A video artist'

    # test format with groups
    titleformat = '%(title)s - %(artist)s - %(album)s'

# Generated at 2022-06-24 14:15:17.158628
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import FileDownloader

    pp = MetadataFromTitlePP(FileDownloader(), '%(title)s - %(artist)s')
    assert pp.format_to_regex('%(title)s - %(artist)s') == (
        r'(?P<title>.+)\ \-\ (?P<artist>.+)')
    assert pp.format_to_regex('Foo Bar - %(artist)s') == (
        r'Foo\ Bar\ \-\ (?P<artist>.+)')
    assert pp.format_to_regex('%(title)s vs %(artist)s') == (
        r'(?P<title>.+)\ vs\ (?P<artist>.+)')

# Generated at 2022-06-24 14:15:27.564086
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    from youtube_dl.extractor.generic import GenericIE
    import urllib2
    from youtube_dl.compat import compat_str
    from youtube_dl.utils import DateRange

    downloader = urllib2.build_opener().open

    fromtitle = MetadataFromTitlePP(downloader,
                                    '%(artist)s - %(title)s')
    infomethod = lambda i: i

    # test run
    info = {'title': 'Michael Jackson - Thriller'}
    info_out = {'artist': 'Michael Jackson', 'title': 'Thriller'}
    assert infomethod(fromtitle.run(info)) == info_out

    # test run_downloader
    # GenericIE
    ie_gen = GenericIE({'forcejson': True})
    # GenericIE
    ie_

# Generated at 2022-06-24 14:15:37.201634
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from collections import namedtuple
    from ydl.YDL import YDL
    from ydl.postprocessor.metadata_from_title import MetadataFromTitlePP
    downloader = YDL()
    pp = MetadataFromTitlePP(downloader,
                             '%(title)s - %(artist)s - %(track)s')
    Info = namedtuple('Info', ['title'])
    info = {'title': 't1 - a1 - 1'}
    expected = {'title': 't1', 'artist': 'a1', 'track': '1'}
    downloader.process_info = lambda i: i
    downloader.to_screen = lambda *args: None
    assert pp.run(info)[1] == expected

# Generated at 2022-06-24 14:15:40.710716
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    """
    Converts a string like
       '%(title)s - %(artist)s'
    to a regex like
       '(?P<title>.+)\ \-\ (?P<artist>.+)'
    """
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s')._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-24 14:15:52.103087
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Test case 1: Normal usage
    test_fmt = "%(title)s - %(album)s"
    test_fmt_regex =  "(?P<title>.+)\ \-\ (?P<album>.+)"
    mftpp = MetadataFromTitlePP(None, test_fmt)
    assert mftpp._titleformat == test_fmt
    assert mftpp._titleregex == test_fmt_regex
    # Test case 2: No %(tag)s r'there
    test_fmt = "Title: %(title)s"
    test_fmt_regex = test_fmt
    mftpp = MetadataFromTitlePP(None, test_fmt)
    assert mftpp._titleformat == test_fmt
    assert mftpp._titleregex == test

# Generated at 2022-06-24 14:16:00.396414
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    from .YoutubeDL import YoutubeDL
    from .extractor import gen_extractors

    # build fake downloader
    class FakeYDL(YoutubeDL):
        def to_screen(self, msg):
            self.msg = msg

    # build fake extractor

# Generated at 2022-06-24 14:16:10.057165
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unittest
    import unittest.mock
    if sys.version_info < (3, 0):
        import urllib
        import urlparse
        unicode = unicode
        parse_qs = urlparse.parse_qs
    else:
        import urllib.parse as urllib
        unicode = str
        parse_qs = urllib.parse_qs
    if sys.version_info < (3, 3):
        unittest.mock.patch.object = unittest.mock.patch.__get__


# Generated at 2022-06-24 14:16:19.690498
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(
        None, '%(artist)s - %(title)s')
    if pp._titleformat != '%(artist)s - %(title)s':
        raise ValueError('artist and title are not being set correctly')
    if pp._titleregex != '(?P<artist>.+)\ \-\ (?P<title>.+)':
        raise ValueError('regex is not being set correctly')

    pp = MetadataFromTitlePP(
        None, 'not(')
    if pp._titleformat != 'not(':
        raise ValueError('titleformat is not being set correctly')
    if pp._titleregex != 'not\(':
        raise ValueError('regex is not being set correctly')

# Generated at 2022-06-24 14:16:23.791431
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert metadata_from_title_pp.run({'title': 'my title - my artist'})[1] == {
        'title': 'my title',
        'artist': 'my artist',
    }

# Generated at 2022-06-24 14:16:30.061967
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class DummyDl():
        def __init__(self):
            self.to_screen = print
            self.to_stdout = print
            self.to_stderr = print

    class DummyYdl():
        def __init__(self):
            self.downloader = DummyDl()

    ydl = DummyYdl()
    info = {}
    metadata_from_title = MetadataFromTitlePP(ydl,
                                              '(?P<title>.+) - '
                                              '(?P<artist>.+?) - '
                                              '(?P<album>.+)')
    info['title'] = 'Test video - Artist - Album'
    info2 = {}
    metadata_from_title.run(info)
    assert 'title' in info
    assert info['title'] == 'Test video'

# Generated at 2022-06-24 14:16:32.984950
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    fmt = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(None, fmt)
    assert re.match(r'(?P<title>.+)\ \-\ (?P<artist>.+)', pp._titleregex) is not None


# Generated at 2022-06-24 14:16:36.832432
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    mp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert mp.format_to_regex(mp._titleformat) == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert mp.run({'title': 'Crazy - Gnarls Barkley'}) == ([], {'title': 'Crazy', 'artist': 'Gnarls Barkley'})

# Generated at 2022-06-24 14:16:46.979823
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test error case with non-matching title
    downloader = DummyYoutubeDl()
    pp = MetadataFromTitlePP(downloader, '%(title)s')
    info = {'title': 'Non-matching'}
    pp.run(info)
    assert info == {'title': 'Non-matching'}
    assert downloader.msgs == ['[fromtitle] Could not interpret title of video as "%(title)s"']
    # Test case with matching title
    downloader = DummyYoutubeDl()
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    info = {'title': 'Correct title - Correct artist'}
    pp.run(info)

# Generated at 2022-06-24 14:16:52.532421
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, '').format_to_regex('') == ''
    assert MetadataFromTitlePP(None, 'foo').format_to_regex('foo') == 'foo'
    assert MetadataFromTitlePP(None, r'\%()s').format_to_regex(r'\%()s') == r'\\%\(\)\s'
    assert MetadataFromTitlePP(None, '%(title)s').format_to_regex('(?P<title>.+)')
    assert MetadataFromTitlePP(None, '%(title)s -').format_to_regex(r'(?P<title>.+)\ \-')

# Generated at 2022-06-24 14:16:55.976616
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftpp = MetadataFromTitlePP(None, None)
    assert mftpp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-24 14:17:05.987479
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, '').format_to_regex('') == ''
    assert MetadataFromTitlePP(None, '').format_to_regex('text') == 'text'
    assert MetadataFromTitlePP(None, '').format_to_regex('text %(name)s') == 'text (?P<name>.+)'
    assert MetadataFromTitlePP(None, '').format_to_regex('text %(name)s %(surname)s') == 'text (?P<name>.+) (?P<surname>.+)'
    assert MetadataFromTitlePP(None, '').format_to_regex('text %(name)s text') == 'text (?P<name>.+) text'

# Generated at 2022-06-24 14:17:11.673932
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    titleformat = '%(title)s - %(artist)s'
    expected_regex = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    titlepp = MetadataFromTitlePP(None, titleformat)
    actual_regex = titlepp.format_to_regex(titleformat)
    assert actual_regex == expected_regex, (
        'Expected regex "%s", got "%s"' % (expected_regex, actual_regex))


# Generated at 2022-06-24 14:17:18.921626
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    mftpp = MetadataFromTitlePP(
        None, "user defined title %(artist)s - %(title)s [%(id)s]")
    # regular expression for transformation of "%(title)s - %(artist)s"
    # into "(?P<title>.+)\ \-\ (?P<artist>.+)"
    assert mftpp._titleregex == (
        'user\ defined\ title\ '
        '(?P<artist>.+)\ \-\ (?P<title>.+)\ \[(?P<id>.+)\]')

# Generated at 2022-06-24 14:17:27.749945
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():

    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')

    assert(pp.format_to_regex('%(artist)s - %(title)s')
           == '(?P<artist>.+)\ \-\ (?P<title>.+)')
    assert(pp.format_to_regex('%(artist)s - %(title)s')
           == pp._titleregex)

    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s with %(other)s')

    assert(pp.format_to_regex('%(artist)s - %(title)s with %(other)s')
           == '(?P<artist>.+)\ \-\ (?P<title>.+)\ with\ (?P<other>.+)')

# Generated at 2022-06-24 14:17:38.629421
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test for class MetaDataFromTitlePP
    from ydl.YdlUtils import DictUtils

    class FakeDownloader:
        def to_screen(self, message):
            print(message)
    downloader = FakeDownloader()


# Generated at 2022-06-24 14:17:43.099142
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    expected = r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex(pp._titleformat) == expected


# Generated at 2022-06-24 14:17:54.340266
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import unittest
    import sys

    class TestTestCase(unittest.TestCase):
        def setUp(self):
            self.pp = MetadataFromTitlePP(None, "%(something)s - %(ok)s")

        def test(self):
            self.assertEqual(
                "(?P<something>.+)\ \-\ (?P<ok>.+)",
                self.pp._titleregex)
    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(TestTestCase))
    unittest.TextTestRunner(verbosity=2).run(suite)
    return 0


if __name__ == '__main__':
    sys.exit(test_MetadataFromTitlePP())

# Generated at 2022-06-24 14:18:04.905150
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert pp.format_to_regex('%(title)s ') == '(?P<title>.+)\ '
    assert pp.format_to_regex('%(title)s-%(artist)s') == '(?P<title>.+)-(?P<artist>.+)'
    assert pp.format_to_regex('%(title)s%(artist)s') == '(?P<title>.+)(?P<artist>.+)'

# Generated at 2022-06-24 14:18:14.386490
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({'writedescription': True,
                     'writeinfojson': True,
                     'writethumbnail': True})
    ydl.add_info_extractor(MetadataFromTitlePP(ydl, '%(track)s - %(artist)s'))
    ydl.download(['http://www.youtube.com/watch?v=BaW_jenozKc'])
    # Check if info dict has all required keys
    assert(os.path.isfile('BaW_jenozKc.info.json'))
    info = json.load(open('BaW_jenozKc.info.json'))
    assert('track' in info)
    assert(info['track'] == 'Astronaut')
    assert('artist' in info)

# Generated at 2022-06-24 14:18:18.133830
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    titleformat = '%(title)s - %(artist)s'
    titleregex = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    pp = MetadataFromTitlePP(None, titleformat)
    assert pp._titleregex == titleregex

# Generated at 2022-06-24 14:18:28.084202
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class DummyDownloader:
        def to_screen(self, *args, **kw):
            pass
    downloader = DummyDownloader()
    titleformat = '%(title)s - %(artist)s'
    titleformat_regex = '.*\ \-\ .*'
    pp = MetadataFromTitlePP(downloader, titleformat)
    assert pp._titleformat == titleformat
    assert pp._titleregex == titleformat_regex
    info = {}

    # Test case 1:
    # - titleformat regex with named groups
    # - title is None
    # - expected: no change to info
    info = {}
    info['title'] = None
    result = pp.run(info)
    assert result == ([], {})

    # Test case 2:
    # - titleformat regex with named groups


# Generated at 2022-06-24 14:18:32.328146
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert (MetadataFromTitlePP(None, None).format_to_regex(
        '%(a)s - %(b)s') == '(?P<a>.+)\ \-\ (?P<b>.+)')
    assert (MetadataFromTitlePP(None, None).format_to_regex(
        '%(a)s') == '(?P<a>.+)')



# Generated at 2022-06-24 14:18:36.339092
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert ('(?P<title>.+)\ \-\ (?P<artist>.+)'
            == MetadataFromTitlePP(None, '%(title)s - %(artist)s'
                                   ).format_to_regex(''))



# Generated at 2022-06-24 14:18:44.346438
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from . import YoutubeDL
    ydl = YoutubeDL()
    ydl.add_default_info_extractors()
    # ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(artist)s - %(title)s'))
    # info = {}
    # info['title'] = 'Track Title - Artist Name'
    # ydl.process_info(info)
    # assert info['title'] == 'Track Title'
    # assert info['artist'] == 'Artist Name'
    # info = {}
    # info['title'] = 'Track Title'
    # ydl.process_info(info)
    # assert info['title'] == 'Track Title'

# Generated at 2022-06-24 14:18:49.218745
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert(MetadataFromTitlePP._format_to_regex(
        r'%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)')

if __name__ == '__main__':
    test_MetadataFromTitlePP_format_to_regex()

# Generated at 2022-06-24 14:18:57.178231
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, 'test: %(test1)s - %(test2)s')
    assert pp._titleregex == '(?P<test1>.+)\ \-\ (?P<test2>.+)'

    pp = MetadataFromTitlePP(None, 'test: %(test1)s - %(test2)s title')
    assert pp._titleregex == 'test:\ (?P<test1>.+)\ \-\ (?P<test2>.+)\ title'

    pp = MetadataFromTitlePP(None, '%(test1)s - %(test2)s title')
    assert pp._titleregex == '(?P<test1>.+)\ \-\ (?P<test2>.+)\ title'

# Generated at 2022-06-24 14:19:04.200505
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.utils import YoutubeDL

    downloader = YoutubeDL({'titleformat': '%(title)s - %(artist)s'})
    postprocessor = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')

    exp = {
        'title': 'test title',
        'artist': 'test artist',
    }

    assert postprocessor.run({'title': 'test title - test artist'}) == ([], exp)
    assert postprocessor.run({'title': ' Test Title - Test Artist'}) == ([], exp)
    assert postprocessor.run({'title': ' Test Title - Test Artist '}) == ([], exp)

    # Test nonexisting video
    assert postprocessor.run({'title': 'unknown'}) == ([], {'title': 'unknown'})


# Generated at 2022-06-24 14:19:14.192773
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import tempfile
    import os
    import youtube_dl.YoutubeDL

    dir = tempfile.mkdtemp(prefix='%s-' % __name__)
    fd, fn = tempfile.mkstemp('.info', '%s-' % __name__, dir)
    os.close(fd)


# Generated at 2022-06-24 14:19:16.167125
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    """
    Unit test for the class MetadataFromTitlePP.
    """
    return [None, None]

# Generated at 2022-06-24 14:19:24.726770
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    metadata = MetadataFromTitlePP(None, '%(title)s')
    assert metadata._titleformat == '%(title)s'
    assert metadata._titleregex == '(?P<title>.+)'

    metadata = MetadataFromTitlePP(None, '%(title)s-%(artist)s')
    assert metadata._titleformat == '%(title)s-%(artist)s'
    assert metadata._titleregex == '(?P<title>.+)\-(?P<artist>.+)'

if __name__ == '__main__':
    test_MetadataFromTitlePP()

# Generated at 2022-06-24 14:19:33.049395
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import FileDownloader
    downloader = FileDownloader({})
    pp = MetadataFromTitlePP(downloader, '%(artist)s - %(title)s')
    assert pp.format_to_regex('%(artist)s - %(title)s') == (
        r'(?P<artist>.+)\ \-\ (?P<title>.+)')
    assert pp.format_to_regex('%(artist)s - %(title)s') == (
        r'(?P<artist>.+)\ \-\ (?P<title>.+)')
    assert pp.format_to_regex('%(id)s - %(title)s') == (
        r'(?P<id>.+)\ \-\ (?P<title>.+)')
    assert pp.format_to

# Generated at 2022-06-24 14:19:41.310875
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert pp._titleformat == '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(None, 'abc')
    assert pp._titleregex == r'abc'
    assert pp._titleformat == 'abc'


# Generated at 2022-06-24 14:19:51.994643
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    tst = MetadataFromTitlePP(None, None)
    # one group
    assert tst.format_to_regex('%(title)s') == r'(?P<title>.+)'
    # escape char
    assert tst.format_to_regex(r'foo\%(title)s') == r'foo\\%\(title\)s'
    # group with escape char
    assert tst.format_to_regex(r'foo%(t\i\t\l\e)s') == r'foo(?P<t\\i\\t\\l\\e>.+)'
    # two groups
    assert (tst.format_to_regex('%(title)s-%(artist)s') ==
            r'(?P<title>.+)\-(?P<artist>.+)')

# Generated at 2022-06-24 14:20:01.659984
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    testcases = [
        ['%(title)s - %(artist)s',
         r'(?P<title>.+)\ \-\ (?P<artist>.+)'],
        ['%(title)s - %(artist)s (%(year)s)',
         r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \((?P<year>.+)\)'],
    ]

    for pattern, expected_regex in testcases:
        mftpp = MetadataFromTitlePP(None, pattern)
        regex = mftpp.format_to_regex(pattern)
        assert regex == expected_regex, 'Pattern "%s" does not match "%s"' % (regex, expected_regex)

# Generated at 2022-06-24 14:20:07.333867
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class FakeInfoDict(dict):
        pass
    class FakeDownloader():
        def to_screen(self, msg):
            pass
    titleformat = "%(title)s"
    title = "The Title"
    info = FakeInfoDict({'title': title})
    downloader = FakeDownloader()
    pp = MetadataFromTitlePP(downloader, titleformat)
    pp.run(info)
    assert info['title'] == title

# Generated at 2022-06-24 14:20:14.937257
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .downloader import YoutubeDL
    from .extractor import gen_extractors

    for fmt in ('%(title)s', '%(artist)s - %(title)s'):
        pp = MetadataFromTitlePP(YoutubeDL({}), fmt)
        regex = pp.format_to_regex(fmt)
        # check if the regex contains a group named after each format specifier
        for spec in re.findall(r'%\((\w+)\)s', fmt):
            assert(re.match(regex, ' ') is None)
            assert(re.match(regex, 'test').groupdict().get(spec) == 'test')

    # check that a regex is not compiled if no format specifiers are found
    for fmt in ('test', 'Foo - Bar'):
        pp = Met

# Generated at 2022-06-24 14:20:26.087183
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.utils import DateRange
    from youtube_dl.downloader import Downloader
    from youtube_dl.extractor.youtube import YoutubeIE
    from tests.test_downloader_http import FakeYDL

    # Create a mock downloader and a mock youtube IE
    ydl = FakeYDL()
    def download_mock_wrapper(self, *a, **k):
        pass
    Downloader.download = download_mock_wrapper

    ie = YoutubeIE(ydl)
    ie.extract_id('http://www.youtube.com/watch?v=BaW_jenozKc')
    title = ie._get_title()

# Generated at 2022-06-24 14:20:36.294054
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pp = MetadataFromTitlePP("dummy", "%(artist)s - %(title)s")
    input_info = {
        'title': 'foo - bar',
        'webpage_url': 'https://www.youtube.com/watch?v=XXX',
    }
    expected_info = {
        'title': 'bar',
        'webpage_url': 'https://www.youtube.com/watch?v=XXX',
        'artist': 'foo'
    }
    expected_msgs = []
    messages = []

    def _to_screen(msg):
        messages.append(msg)

    pp._downloader = type("dummy_downloader", (object,), {
        'to_screen': _to_screen,
    })()

    errors, info = pp.run(input_info)
   

# Generated at 2022-06-24 14:20:43.952802
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    def eq_info(info1, info2):
        # checks if two info dictionaries contain the same information
        keys1 = set(info1.keys())
        keys2 = set(info2.keys())
        assert keys1 == keys2, \
            'different keys: %r != %r' % (keys1, keys2)
        for key in keys1:
            assert info1[key] == info2[key]

    # empty format: no metadata
    pp = MetadataFromTitlePP(None, '')
    eq_info(pp.run({'title': 'abc'})[1], {'title': 'abc'})

    # format without %(...)s: no metadata
    pp = MetadataFromTitlePP(None, '%s - %s')

# Generated at 2022-06-24 14:20:53.449678
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest
    import sys
    from collections import namedtuple
    SpoofDownloader = namedtuple('SpoofDownloader', ['to_screen'])

    downloader = SpoofDownloader(to_screen=lambda *args, **kwargs: None)
