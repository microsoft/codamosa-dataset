

# Generated at 2022-06-24 14:10:53.852920
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(artist)s=%(title)s')
    assert isinstance(pp, MetadataFromTitlePP)
    assert pp._titleformat == '%(artist)s=%(title)s'
    assert pp._titleregex == '(?P<artist>.+)\=(?P<title>.+)'


# Generated at 2022-06-24 14:11:00.786910
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mf = MetadataFromTitlePP(None, None)
    assert mf.format_to_regex(r'%(title)s') == r'(?P<title>.+)'
    assert mf.format_to_regex(r'foo') == r'foo'
    assert mf.format_to_regex(r'%(title)s - %(artist)s') == \
        r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert mf.format_to_regex(r'%(title)s - %(artist)s - %(album)s') == \
        r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'
    assert mf.format_to_

# Generated at 2022-06-24 14:11:05.760081
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    mft = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert mft._titleformat == '%(artist)s - %(title)s'
    assert mft._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'

# Generated at 2022-06-24 14:11:16.076019
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.utils import DateRange
    from .common import FileDownloader
    class FakeInfo:
        pass
    dl = FileDownloader({
        'quiet': True,
        'forcejson': True})
    pp = MetadataFromTitlePP(dl, '%(title)s')
    info = FakeInfo()
    info.title = 'Video Title'
    info.id = 'Video ID'
    info.age_limit = None
    info.upload_date = None
    info.uploader = None
    info.uploader_id = None
    info.uploader_url = None
    info.license = None
    info.creator = None
    info.location = None
    info.categories = None
    info.tags = None
    info.duration = None
    info.view_count = None
    info

# Generated at 2022-06-24 14:11:26.044319
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import io
    import unittest
    from ..compat import compat_kwargs

    class MockYDL(object):
        def __init__(self):
            self.to_screen_buffer = io.StringIO()

        def to_screen(self, message, **kwargs):
            print(message, file=self.to_screen_buffer, **compat_kwargs(kwargs))

    class TestMetadataFromTitlePP_run(unittest.TestCase):
        def setUp(self):
            self.ydl = MockYDL()
            self.pp = MetadataFromTitlePP(self.ydl, '%(title)s - %(artist)s')

        def test_basic(self):
            info = {'title': 'test'}
            infos, info = self.pp.run

# Generated at 2022-06-24 14:11:33.920323
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    assert (pp.format_to_regex('%(title)s - %(artist)s') ==
            '(?P<title>.+)\\ \\-\\ (?P<artist>.+)')
    assert (pp.format_to_regex('%(title)s') ==
            '(?P<title>.+)')
    assert (pp.format_to_regex('%(title)s %(artist)s') ==
            '(?P<title>.+)\\ (?P<artist>.+)')

# Generated at 2022-06-24 14:11:34.523860
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass

# Generated at 2022-06-24 14:11:40.557693
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Tests run method of MetadataFromTitlePP
    # class with special vars

    # Arrange
    info = {'title': 'Test - Title'}
    downloader = None
    titleformat = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(downloader, titleformat)

    # Act
    results = pp.run(info)

    # Assert
    assert results[1]['title'] == 'Test'
    assert results[1]['artist'] == 'Title'


# Generated at 2022-06-24 14:11:48.862164
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor import gen_extractors
    from .youtube_dl.utils import DateRange, match_filter_func
    from .youtube_dl.postprocessor import FFmpegMetadataPP
    from .compat import compat_str

    extractors = gen_extractors()
    fd = FileDownloader({'format': 'best', 'outtmpl': '%(id)s-%(title)s.%(ext)s'})
    fd.add_info_extractor(extractors[0])
    fd.add_post_processor(MetadataFromTitlePP(fd, '%(title)s.%(ext)s'))
    fd.add_post_processor(FFmpegMetadataPP())
    fd.params['writethumbnail'] = True
    f

# Generated at 2022-06-24 14:11:58.695131
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    def run(titleformat, title, expected_regex):
        pp = MetadataFromTitlePP(None, titleformat)
        assert pp._titleregex == expected_regex
        match = re.match(pp._titleregex, title)
        assert match.groupdict()
        return match.groupdict()

    # test non-regex string
    result = run('foo bar', 'foo bar', 'foo bar')
    assert len(result) == 0

    # test regex string
    result = run('(?P<a>b)', 'b', '(?P<a>b)')
    assert result['a'] == 'b'

    # test string with %(name)s
    result = run('%(a)s', 'b', r'(?P<a>.+)')

# Generated at 2022-06-24 14:12:02.747743
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(song)s - %(artist)s')
    regex = pp._titleregex
    assert regex == r'(?P<song>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-24 14:12:07.303346
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%()s'))
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s'))
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s - %(artist)s'))

# Generated at 2022-06-24 14:12:07.894562
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pass

# Generated at 2022-06-24 14:12:15.802173
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .downloader import YoutubeDL
    from .compat import compat_str

    ydl = YoutubeDL()
    titleformat = '%(title)s - %(artist)s'
    title = 'Sia - Chandelier'
    regex = '''(?P<title>.+)\ \-\ (?P<artist>.+)'''
    ydl.add_post_processor(MetadataFromTitlePP(ydl, titleformat))
    assert ydl.post_processors[0]._titleformat == titleformat
    assert ydl.post_processors[0]._titleregex == regex
    assert ydl.post_processors[0].format_to_regex(titleformat) == regex
    assert ydl.post_processors[0].format_to_regex(title) == title


# Generated at 2022-06-24 14:12:23.917328
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from . import FakeYDL

    ydl = FakeYDL()

    # Test regex interpretation
    fmt = r'%(title)s - %(artist)s'
    regex = r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    mpp = MetadataFromTitlePP(ydl, fmt)
    assert mpp._titleregex == regex

    # Test run method
    fmt = r'%(title)s - %(artist)s'
    info = {'title': 'test - test'}
    mpp = MetadataFromTitlePP(ydl, fmt)
    mpp.run(info)
    assert info['title'] == 'test'
    assert info['artist'] == 'test'

# Generated at 2022-06-24 14:12:34.623175
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    mp3_info = {
        'title': 'Eminem - Lose Yourself',
        'url': 'http://www.youtube.com/watch?v=YVkUvmDQ3HY',
    }

    mp3_output = {
        'title': 'Eminem - Lose Yourself',
        'url': 'http://www.youtube.com/watch?v=YVkUvmDQ3HY',
        'artist': 'Eminem',
    }

    mp4_info = {
        'title': 'Katy Perry - Roar (Official)',
        'url': 'http://www.youtube.com/watch?v=CevxZvSJLk8',
    }


# Generated at 2022-06-24 14:12:43.757358
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import os
    import tempfile
    import shutil

    # Set up test directories
    # tmp_dir = tempfile.mkdtemp()
    tmp_dir = 'temp' # to ease debugging
    os.makedirs(os.path.join(tmp_dir, 'formats'))
    os.makedirs(os.path.join(tmp_dir, 'config'))
    with open(os.path.join(tmp_dir, 'config', 'youtube-dl.conf'), 'w') as f:
        f.write('--download-archive "%archive%"')
    with open(os.path.join(tmp_dir, 'config', 'ytdl.conf'), 'w') as f:
        f.write('--download-archive "%archive%"')
    os.chdir(tmp_dir)

   

# Generated at 2022-06-24 14:12:51.892714
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    """Tests the method format_to_regex of class MetadataFromTitlePP."""
    test_data = (('%(title)s - %(artist)s', r'(?P<title>.+)\ \-\ (?P<artist>.+)'), 
                 ('%(title)s.extension', r'(?P<title>.+)\.extension'))
    for format, regex in test_data: 
        assert MetadataFromTitlePP(None, format).format_to_regex(format) == regex


# Generated at 2022-06-24 14:12:58.009450
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    Unit test for MetadataFromTitlePP.run
    """
    import unittest
    from collections import namedtuple
    import sys

    # fake downloader
    class FakeDownloader:
        def __init__(self, to_screen_value):
            self.to_screen_value = to_screen_value

        def to_screen(self, value):
            self.to_screen_value.append(value)

    # Unit test class
    class Test_MetadataFromTitlePP(unittest.TestCase):

        def setUp(self):
            self.to_screen_value = []
            self.downloader = FakeDownloader(self.to_screen_value)


# Generated at 2022-06-24 14:13:04.564114
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s').format_to_regex(
        '%(title)s - %(artist)s') == '(?P<title>.+)\\ \-\\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s').format_to_regex(
        '(%(title)s - %(artist)s)') == '\\((?P<title>.+)\\ \-\\ (?P<artist>.+)\\)'

# Generated at 2022-06-24 14:13:08.955498
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert MetadataFromTitlePP(None, '%(artist)s - %(title)s').run({
        'title': 'test title',
        'artist': 'test artist'
    }) == ([], {
        'title': 'test title',
        'artist': 'test artist'
    })



# Generated at 2022-06-24 14:13:16.793655
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # test regex format
    regex = MetadataFromTitlePP(None, '%(title)s').format_to_regex('%(title)s')
    assert re.match(regex, 'mytitle')
    assert re.match(regex, 'mytitle - myalbum') # no match group -> no match
    # test non-empty string
    regex = MetadataFromTitlePP(None, 'mytitle - %(album)s').format_to_regex('mytitle - %(album)s')
    assert re.match(regex, 'mytitle - myalbum')
    assert not re.match(regex, 'mytitle') # does not end with album
    # test empty string
    assert MetadataFromTitlePP(None, '').format_to_regex('') == ''

# Generated at 2022-06-24 14:13:26.962296
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Test validate format
    def run(input, expected_output):
        if input != expected_output:
            raise AssertionError('Input %s != expected output %s'
                                 % (input, expected_output))

    run(MetadataFromTitlePP(None, '%(title)s')._titleformat, '%(title)s')

    # Test validate regex
    run(MetadataFromTitlePP(None, '%(title)s - %(artist)s')._titleregex,
        '(?P<title>.+)\ \-\ (?P<artist>.+)')

    run(MetadataFromTitlePP(None, '%(title)s')._titleregex,
        '(?P<title>.+)')


# Generated at 2022-06-24 14:13:32.840583
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    metadata_pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert metadata_pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# vim: tabstop=8 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-24 14:13:40.029520
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    class Dummy(object):

        def __init__(self, to_screen_string_list):
            self.to_screen_string_list = to_screen_string_list

        def to_screen(self, *args):
            self.to_screen_string_list.append(args[0])

    # Create a test instance of class PostProcessor
    test_instance = MetadataFromTitlePP(Dummy([]), '%(title)s')

    # Create input
    input_info = dict()
    input_info['title'] = 'Title of video - Artist'
    input_info['creator'] = 'Artist'
    input_info['album'] = 'Album'

    # Call method run and verify that this is correct
    output_info = test_instance.run(input_info)[1]
    assert output_info

# Generated at 2022-06-24 14:13:47.579529
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    """
    Test constructor of class MetadataFromTitlePP.
    """
    titleformat = '%(artist)s - %(title)s [%(id)s]'
    format_to_regex = MetadataFromTitlePP('Dummy downloader', titleformat).format_to_regex
    # Test normal case
    assert format_to_regex('%(artist)s - %(title)s [%(id)s]') == r'(?P<artist>.+)\ \-\ (?P<title>.+)\ \[(?P<id>.+)\]'
    # Test that it escapes string parts
    assert format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert format_to_re

# Generated at 2022-06-24 14:13:59.005115
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-24 14:14:03.948815
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    mftpp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert mftpp._titleregex == r'(?P<artist>.+)\ \-\ (?P<title>.+)'

# Generated at 2022-06-24 14:14:12.637073
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader

    downloader = FileDownloader({})
    metadatafromtitlepp = MetadataFromTitlePP(downloader,
        '%(artist)s - %(title)s [%(genre)s]')

    assert metadatafromtitlepp.run({'title': 'Hellow World!'})[1] == \
        {'title': 'Hellow World!'}

    assert metadatafromtitlepp.run({'title': 'Lil Nas X - Old Town Road [Country]'})[1] == \
        {'title': 'Lil Nas X - Old Town Road [Country]',
         'artist': 'Lil Nas X',
         'genre': 'Country'}


# Generated at 2022-06-24 14:14:16.414626
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftpp = MetadataFromTitlePP(None,'')

    expected = '(?P<title>.+)\\ \-\\ (?P<artist>.+)'
    actual = mftpp.format_to_regex('%(title)s - %(artist)s')
    assert expected == actual

# Generated at 2022-06-24 14:14:26.255536
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .compat import compat_urllib_parse_unquote


# Generated at 2022-06-24 14:14:35.680725
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    foo = MetadataFromTitlePP(None, None)
    # assertEqual is depreciated in python3. Use assertEqual instead
    assertEqual = foo._test_assertEqual
    assertTrue = foo._test_assertTrue
    assertFalse = foo._test_assertFalse
    assertEqual(foo.format_to_regex('%(title)s - %(artist)s'),
                r'(?P<title>.+)\ \-\ (?P<artist>.+)')
    assertEqual(foo.format_to_regex('%(ab)s'), r'(?P<ab>.+)')
    assertEqual(foo.format_to_regex('ab%(ab)s'), r'ab(?P<ab>.+)')

# Generated at 2022-06-24 14:14:39.675088
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from ytdl_server.decoder import MetadataFromTitlePP
    decoder = MetadataFromTitlePP(None, None)
    regex = '%(title)s - %(artist)s'
    expected = '(?P<title>.+)\\ \-\\ (?P<artist>.+)'
    assert expected == decoder.format_to_regex(regex)



# Generated at 2022-06-24 14:14:47.598257
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .compat import compat_urllib_request

    url = 'http://example.org/'

    # If a title is not passed, the download is not made,
    # and the method run does not have effect
    dl = FileDownloader({'format': 'bestaudio/best',
                         'outtmpl': '%(id)s.%(ext)s'})

    dl.add_info_extractor(
        lambda *a, **k: ({'abr': '96'}, {}, [], [], []))

    with compat_urllib_request.urlopen(url) as f:
        result = dl.process_ie_result({'url': url}, f, True)

    assert result is None

    # If a title is passed, the download is simulated,

# Generated at 2022-06-24 14:14:58.062599
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '(?P<title>.+)'

    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(album)s')
    assert pp._titleformat == '%(title)s - %(artist)s - %(album)s'

# Generated at 2022-06-24 14:15:08.075766
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    mfpp = MetadataFromTitlePP(ydl, None)
    assert mfpp.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert mfpp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert mfpp.format_to_regex('%(artist)s - %(title)s') == '(?P<artist>.+)\ \-\ (?P<title>.+)'

# Generated at 2022-06-24 14:15:17.119477
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest
    import sys
    sys.path.insert(0, '../../')

    from youtube_dl.options import _add_default_logger
    from youtube_dl.downloader import YoutubeDL

    class MockYoutubeDL(YoutubeDL):
        def to_screen(self, msg):
            pass
        def to_stderr(self, msg):
            pass

    class MockInfoDict(dict):
        pass

    class MockOptionDict(dict):
        pass

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.options = MockOptionDict()
            self.ydl = MockYoutubeDL(self.options)
            self.ydl.params = {}
            self.ydl.add_default_info_extractors()
            self.yd

# Generated at 2022-06-24 14:15:27.521204
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # test cases which should succeed:
    # format string with '%(..)s'
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s')._titleregex == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'
    # format string without '%(..)s'
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s')._titleregex == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'
    # mismatching parentheses are not handled. Format string is treated as whole
    assert MetadataFromTitlePP(None, '%(title - %(artist)s')._titleregex == '%\\(title\\ \\-\\ %\\(artist\\)s'

    # test cases which should fail:

# Generated at 2022-06-24 14:15:32.139198
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    test_titleformat = '%(title)s - %(artist)s'
    regex = MetadataFromTitlePP(None, test_titleformat)._titleregex
    assert regex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'



# Generated at 2022-06-24 14:15:40.687412
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    class InfoDict(dict):
        pass

    def run_postprocessor(info):
        return []

    # Test basic behavior of class MetadataFromTitlePP
    # 1 with %(key)s format and
    # 1 without %(key)s format
    title_format = '%(artist)s - %(title)s'
    title = 'Metallica - Hardwired'
    info = InfoDict({'title': title})
    pp_1 = MetadataFromTitlePP(None, title_format)
    assert pp_1._titleformat == title_format
    assert pp_1._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'
    _, info = pp_1.run(info)
    assert info['title'] == title

# Generated at 2022-06-24 14:15:52.120750
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .common import FileDownloader
    from .YoutubeDL import YoutubeDL
    from .extractor.common import InfoExtractor

    # This instantiates FileDownloader and passes all its arguments (YoutubeDL and InfoExtractor) to
    # the constructor of PostProcessor.
    pp = MetadataFromTitlePP(YoutubeDL(FileDownloader({}, InfoExtractor(None))), '%(uploader)s')
    regex = pp._titleregex
    assert regex == r'(?P<uploader>.+)'

    # and the same with a more complicated pattern
    pp = MetadataFromTitlePP(YoutubeDL(FileDownloader({}, InfoExtractor(None))), '%(uploader)s - %(title)s')
    regex = pp._titleregex

# Generated at 2022-06-24 14:16:00.396329
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    class DummyDownloader(object):
        def to_screen(self, message):
            print(message)

    import unittest

    class FromTitleTestCase(unittest.TestCase):
        def setUp(self):
            self.pp = MetadataFromTitlePP(DummyDownloader(), '')

        def test_regular_string(self):
            self.assertEqual(self.pp.format_to_regex('v1.23'), 'v1\.23')

        def test_regular_regex(self):
            self.assertEqual(self.pp.format_to_regex('v(.+)'), 'v(.+)')


# Generated at 2022-06-24 14:16:10.050885
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-24 14:16:20.314589
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp.format_to_regex('%(artist)s - %(title)s') == r'(?P<artist>.+)\ \-\ (?P<title>.+)'

    # no groups
    pp = MetadataFromTitlePP(None, 'No groups')
    assert pp.format_to_regex('No groups') == r'No\ groups'

    # no groups, therefore no escaping will be done
    pp = MetadataFromTitlePP(None, r'No groups (do not escape)')
    assert pp.format_to_regex(r'No groups (do not escape)') == r'No\ groups\ \(do\ not\ escape\)'

    # missing closing bracket
    pp = MetadataFromTitlePP

# Generated at 2022-06-24 14:16:28.519677
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # testcase 1: return value from only title is parsed from info dict
    tmdtitle = 'Video title'
    downloader = type('DummyDownloader', (object,), {'to_screen': lambda *args, **kwargs: 1})
    instance = MetadataFromTitlePP(downloader, '%(title)s')
    info = {'title': tmdtitle}
    assert instance.run(info) == ([], {'title': tmdtitle})

    # testcase 2: return value from all title's info parsed from info dict
    tmdtitle = 'Video title - Artist name'
    instance = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    info = {'title': tmdtitle}

# Generated at 2022-06-24 14:16:35.110422
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.utils import DateRange
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')

    # Test 1: Title of video matches titleformat
    info = {
        'title': 'My Video Title - by my artist'
    }
    metadata, final_info = pp.run(info)
    assert len(metadata) == 0
    assert 'title' in final_info
    assert 'artist' in final_info
    assert final_info['title'] == 'My Video Title'
    assert final_info['artist'] == 'by my artist'

    # Test 2: Title of video doesn't match titleformat
    info = {
        'title': 'My Video Title - by my artist - how do I even do this'
    }
    metadata, final_info = pp.run(info)

# Generated at 2022-06-24 14:16:44.797162
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert (MetadataFromTitlePP(None, '%(title)s1%(title)s2')
            ._titleregex == '(?P<title>.+)1(?P<title>.+)2')
    assert (MetadataFromTitlePP(None, 'x%(title)s1%(title)s2y')
            ._titleregex == 'x(?P<title>.+)1(?P<title>.+)2y')
    assert (MetadataFromTitlePP(None, '%(title)s1%(title)s2y')
            ._titleregex == '(?P<title>.+)1(?P<title>.+)2y')

# Generated at 2022-06-24 14:16:50.058746
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)

# Generated at 2022-06-24 14:16:58.294419
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    p = MetadataFromTitlePP('dummy_downloader', '%(title)s - %(artist)s')
    assert p.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert p.format_to_regex('%(title)s -') == r'(?P<title>.+)\ \-'
    assert p.format_to_regex('%(title)s - %(artist)s - %(year)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<year>.+)'

# Generated at 2022-06-24 14:17:08.829888
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    if not MetadataFromTitlePP.format_to_regex('%(uploader)s - %(title)s') == '(?P<uploader>.+)\ \-\ (?P<title>.+)':
        return False
    if not MetadataFromTitlePP.format_to_regex('%(title)s') == '(?P<title>.+)':
        return False
    if not MetadataFromTitlePP.format_to_regex('%(title)s%(uploader)s') == '(?P<title>.+)(?P<uploader>.+)':
        return False
    if not MetadataFromTitlePP.format_to_regex('%(title)s and %(uploader)s') == '(?P<title>.+)\ and\ (?P<uploader>.+)':
        return False
    return True

# Generated at 2022-06-24 14:17:11.518255
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-24 14:17:19.567603
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    mftpp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    info = {'title': 'mephisto - abby'}
    mftpp.run(info)
    assert (info == {
        'title': 'mephisto',
        'artist': 'abby',
    })

    mftpp = MetadataFromTitlePP(None, '%(title)s')
    info = {'title': 'mephisto\t-abby'}
    mftpp.run(info)
    assert (info == {
        'title': 'mephisto\t-abby',
    })

    mftpp = MetadataFromTitlePP(None, '%(title)s - [%(h]s - %(artist)s')

# Generated at 2022-06-24 14:17:28.040367
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    ydl = object()
    pp = MetadataFromTitlePP(ydl, '%(artist)s - %(title)s')
    assert '%(artist)s - %(title)s' == pp._titleformat
    assert '(?P<artist>.+)\ \-\ (?P<title>.+)' == pp._titleregex

    # Test title matches format
    info = {
        'title': 'artist - title',
    }
    res, info = pp.run(info)
    assert 0 == len(res)
    assert 'artist' == info['artist']
    assert 'title' == info['title']

    # Test title does not match format
    info = {
        'title': 'title - artist',
    }
    res, info = pp.run(info)
    assert 0 == len(res)
   

# Generated at 2022-06-24 14:17:38.680081
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Check if no error occurs when no %(..)s is found in titleformat
    titleformat = '%(title)s'
    pp = MetadataFromTitlePP(None, titleformat)
    assert pp._titleformat == titleformat
    assert pp._titleregex == titleformat

    # Check if no error occurs when a %(..)s is found in titleformat
    titleformat = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(None, titleformat)
    assert pp._titleformat == titleformat
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    # Check if no error occurs when a %(..)s is found in titleformat and
    # not at beginning of titleformat

# Generated at 2022-06-24 14:17:48.043037
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class MockYdl(object):
        def to_screen(self, text):
            pass
    formats = [('%(artist)s - %(title)s', 'Radiohead - Karma Police',
                {'artist': 'Radiohead', 'title': 'Karma Police'}),
               ('%(artist)s - %(title)s' , 'Radiohead - Fake Song', None),
               ('%(tracknumber)s/%(trackcount)s %(artist)s - %(title)s',
                '2/10 Radiohead - Karma Police',
                {'tracknumber': '2', 'trackcount': '10',
                 'artist': 'Radiohead', 'title': 'Karma Police'})]
    for titleformat, title, info in formats:
        p = MetadataFromTitlePP(MockYdl(), titleformat)


# Generated at 2022-06-24 14:17:57.201225
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .extractor import gen_extractor
    from .downloader import gen_downloader
    try:
        from urllib.parse import urlencode
    except ImportError:
        from urllib import urlencode
    try:
        import json
    except ImportError:
        import simplejson as json
    pp = MetadataFromTitlePP(gen_downloader(params={}),
            '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\\ \-\\ (?P<artist>.+)'
    pp = MetadataFromTitlePP(gen_downloader(params={}),
            '%(title)s')

# Generated at 2022-06-24 14:18:02.516125
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP.format_to_regex(
        '%(title)s - %(artist)s - %(album)s') == \
        '(?P<title>.+)\\ \\-\\ (?P<artist>.+)\\ \\-\\ (?P<album>.+)'

# Generated at 2022-06-24 14:18:11.918205
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    downloader = lambda: None
    downloader.to_screen = lambda x: None

    import sys
    if sys.version_info < (3, 0):
        from io import BytesIO as StringIO
    else:
        from io import StringIO

    info = dict(title='this is a title')

    pp = MetadataFromTitlePP(downloader, '%(title)s')
    streams, info = pp.run(info)
    assert info['title'] == 'this is a title'

    info = dict(title='This Is A Title')

    pp = MetadataFromTitlePP(downloader, '%(title)s')
    streams, info = pp.run(info)
    assert info['title'] == 'This Is A Title'

    info = dict(title='This Is A Title')

    pp = MetadataFromTitle

# Generated at 2022-06-24 14:18:17.288717
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, "%(title)s")
    regex_1 = pp._titleregex
    pp = MetadataFromTitlePP(None, "%(title)s - %(artist)s")
    regex_2 = pp._titleregex
    assert regex_1 == '(?P<title>.+)'
    assert regex_2 == '(?P<title>.+)\ \-\ (?P<artist>.+)'



# Generated at 2022-06-24 14:18:27.390101
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftpp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert mftpp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert mftpp.format_to_regex('%(title)s - %(artist)s - %(year)s - %(album)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<year>.+)\ \-\ (?P<album>.+)'

# Generated at 2022-06-24 14:18:32.056331
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # test for a simple string format
    mftpp = MetadataFromTitlePP(None, '%(title)s')
    assert '%(title)s' == mftpp._titleformat
    assert '%(title)s' == mftpp._titleregex

    # test for format that uses regex groups
    mftpp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert '%(title)s - %(artist)s' == mftpp._titleformat
    assert '(?P<title>.+)\ \-\ (?P<artist>.+)' == mftpp._titleregex


# Generated at 2022-06-24 14:18:42.828165
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Create object
    titles = ['Titanic', 'Titanic - The Epic Music Video (2012)',
              'Titanic - The Epic Music Video (2012) - HD 720p']
    formats = ['%(title)s', '%(title)s - %(artist)s (%(year)s)',
               '%(title)s - %(artist)s (%(year)s) - %(quality)s']
    attributes = [['title'],
                  ['title', 'artist', 'year'],
                  ['title', 'artist', 'year', 'quality']]
    results = [['Titanic'],
               ['Titanic', 'The Epic Music Video', '2012'],
               ['Titanic', 'The Epic Music Video', '2012', 'HD 720p']]

# Generated at 2022-06-24 14:18:52.849775
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.downloader import common as ytdl
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    # when title contains title and artist
    info = {'title': 'Title - Artist',
            'artist': 'Old Artist'}
    _, info2 = pp.run(info)
    assert info2['artist'] == 'Artist'
    # when title contains only title
    info = {'title': 'Title',
            'artist': 'Old Artist'}
    _, info2 = pp.run(info)
    print("info2['artist']='%s'" % info2['artist'])
    assert info2['artist'] == 'Old Artist'
    # when title does not match format
    info = {'title': 'Title'}

# Generated at 2022-06-24 14:18:56.662644
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import sys
    if sys.version_info < (3,0):
        from types import ClassType
    else:
        ClassType = type
    assert (isinstance(MetadataFromTitlePP, type))
    assert (issubclass(MetadataFromTitlePP, PostProcessor))


if __name__ == '__main__':
    import doctest
    doctest.testmod()
    test_MetadataFromTitlePP()

# Generated at 2022-06-24 14:19:03.764685
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    format_regex_pairs = [
        ('%(title)s - %(artist)s', '(?P<title>.+)\ \-\ (?P<artist>.+)'),
        ('x - %(title)s - y', 'x\ \-\ (?P<title>.+)\ \-\ y'),
        ('abc%(title)s', 'abc(?P<title>.+)'),
        ('%(title)sxyz', '(?P<title>.+)xyz'),
        ('%(title)s', '(?P<title>.+)'),
    ]
    pp = MetadataFromTitlePP('', '')
    for format, regex in format_regex_pairs:
        assert pp.format_to_regex(format) == regex
        pp._titleformat = format
        assert pp._titleregex == regex

# Generated at 2022-06-24 14:19:14.084029
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class MockYDL:
        def to_screen(self, msg):
            print('\t%s' % msg)

    class MockInfo:
        def __init__(self, title):
            self['title'] = title

    downloader = MockYDL()

    # Test: format string without group regex
    pattern = 'JoJo%20no%20Kimyouna%20Bouken'
    title = 'JoJo no Kimyouna Bouken'
    info = MockInfo(title)
    pp = MetadataFromTitlePP(downloader, pattern)
    assert len(pp.run(info)[1]) == 2, 'Missing metadata'
    assert pp.run(info)[1]['title'] == title, 'Incorrect metadata'

    # Test: format string with group regex

# Generated at 2022-06-24 14:19:25.034088
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    Tests the run method of class MetadataFromTitlePP.
    Especially, the behaviour of the method in case that
    the title in info is not matched by the titleformat.
    """

    # set up a fake downloader
    class FakeDownloader:
        def __init__(self):
            self.to_screen_message = None

        def to_screen(self, message):
            self.to_screen_message = message

    # set up a fake info
    info = {'title': 'Kraftwerk - Radioactivity'}

    # create a new postprocessor
    pp = MetadataFromTitlePP(FakeDownloader(),
                             '%(artist)s - %(title)s')

    # get the results
    files, info = pp.run(info)

    # check the results
    assert files == []
   

# Generated at 2022-06-24 14:19:31.774263
# Unit test for method run of class MetadataFromTitlePP

# Generated at 2022-06-24 14:19:37.799689
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.YoutubeDL import YoutubeDL
    info_dict = {'id': 'AYIiviZMnfM', 'ext': 'mp4', 'title': 'Eminem - The Real Slim Shady (Edited) (Official Video)'}
    ydl = YoutubeDL()
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(artist)s - %(title)s'))
    from youtube_dl.PostProcessor import run_post_processors
    info_dict = run_post_processors(ydl, info_dict)
    assert info_dict['artist'] == 'Eminem'

# Generated at 2022-06-24 14:19:42.952354
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ..YoutubeDL import YDL
    mp = MetadataFromTitlePP(YDL(), '%(title)s - %(artist)s')
    result = mp.run({
        'title': 'Some title - Some artist',
        'url': 'http://test.org/video.mp4',
    })
    assert result == ([], {
        'title': 'Some title - Some artist',
        'url': 'http://test.org/video.mp4',
        'title': 'Some title',
        'artist': 'Some artist'
    })

# Generated at 2022-06-24 14:19:52.852471
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, '').format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert MetadataFromTitlePP(None, '').format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, '').format_to_regex('%(title)s | %(artist)s') == r'(?P<title>.+)\ \|\ (?P<artist>.+)'

# Generated at 2022-06-24 14:20:03.749441
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from collections import OrderedDict
    from .common import FileDownloader

    downloader = FileDownloader(params={})
    info = OrderedDict()
    info['title'] = 'testing - test'
    info['artist'] = 'Artist'
    metadata_from_title_pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    metadata_from_title_pp.run(info)
    assert info['title'] == 'testing'
    assert info['artist'] == 'test'

    info['title'] = 'testing - '

    from .common import ExtractorError

    class FakeYDL:
        _ydl = FileDownloader
        params = {}
        ie = None

    ydl = FakeYDL()

# Generated at 2022-06-24 14:20:12.323470
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pp = MetadataFromTitlePP(None, '%(title)s')
    # Test with title like "%(title)s"
    info = {
        'title': 'FooTitle'
    }
    assert pp.run(info) == ([], {
        'title': 'FooTitle',
    })
    # Test with title like "FooTitle - FooArtist"
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    info = {
        'title': 'FooTitle - FooArtist'
    }
    assert pp.run(info) == ([], {
        'title': 'FooTitle',
        'artist': 'FooArtist',
    })
    # Test with title like "FooTitle - FooArtist - FooAlbum - FooGenre"

# Generated at 2022-06-24 14:20:22.081659
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP('dummy', '%(title)s - %(artist)s')
    assert (pp._titleformat == '%(title)s - %(artist)s' and
            pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)')
    pp = MetadataFromTitlePP('dummy', '%(title)s - %(artist)s - %(year)d')
    assert (pp._titleformat == '%(title)s - %(artist)s - %(year)d' and
            pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<year>\d+)')


# Generated at 2022-06-24 14:20:29.061701
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class FakeInfo(object):
        def __init__(self, title):
            self.title = title
    class FakeYoutubeDL(object):
        def __init__(self):
            self.to_screen = print
    class FakeYoutubeDLEngine(object):
        def __init__(self):
            self.postprocessor = MetadataFromTitlePP(
                FakeYoutubeDL(), '%(title)s - %(artist)s [%(id)s]')

    info = FakeInfo('Closer - Tegan and Sara [abcd1234]')

    FakeYoutubeDLEngine().postprocessor.run(info)

    assert info['title'] == 'Closer'
    assert info['artist'] == 'Tegan and Sara'
    assert info['id'] == 'abcd1234'

    info = FakeInfo

# Generated at 2022-06-24 14:20:33.430742
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    metadatafromtitle = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert metadatafromtitle.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-24 14:20:38.115880
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .common import FileDownloader
    pp = MetadataFromTitlePP(FileDownloader(None), '%(title)s - %(artist)s')

    # very basic tests
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-24 14:20:44.599428
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')

    # Test that simple string is not modified
    assert pp.format_to_regex('simple string') == 'simple string'

    # Test that %(..)s is converted to group
    assert pp.format_to_regex('%(artist)s') == '(?P<artist>.+)'

    # Test that everything is escaped
    assert pp.format_to_regex('% \- \\') == r'%\ \-\\'

    # Test that everything is converted
    assert pp.format_to_regex('%(a)s%(b)s') == r'(?P<a>.+)(?P<b>.+)'

# Generated at 2022-06-24 14:20:51.665231
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class FakeDownloader(object):
        def to_screen(self, msg):
            pass
    class FakeInfo(dict):
        pass
    pp = MetadataFromTitlePP(FakeDownloader(), '%(title)s - %(artist)s')
    info = FakeInfo()
    info['title'] = 'In the Belly of a Shark - Gallows'
    info['ext'] = 'flv'
    pp.run(info)
    assert info['title'] == 'In the Belly of a Shark'
    assert info['artist'] == 'Gallows'

