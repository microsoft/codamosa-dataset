

# Generated at 2022-06-24 14:10:56.486287
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Test regex generator
    regex = MetadataFromTitlePP(None, '%(title)s')._titleregex
    assert regex == '(?P<title>.+)'

    regex = MetadataFromTitlePP(None, '%(title)s - %(artist)s')._titleregex
    assert regex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    regex = MetadataFromTitlePP(None, '%(title)s').format_to_regex('%(title)s - %(artist)s')
    assert regex == '(?P<title>.+)\ \-\ %\(artist\)s'

    regex = MetadataFromTitlePP(None, '%(title)s').format_to_regex('%(title)s - %(artist)s')

# Generated at 2022-06-24 14:11:06.825690
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    titleformat = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(None, titleformat)

# Generated at 2022-06-24 14:11:13.703184
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    title = 'Foo - Bar'
    info = {'title': title}
    fromtitle = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    [], info = fromtitle.run(info)
    assert 'title' in info, 'title is missing'
    assert 'artist' in info, 'artist is missing'
    assert info['title'] == 'Foo', 'title is wrong'
    assert info['artist'] == 'Bar', 'artist is wrong'


# Generated at 2022-06-24 14:11:18.050945
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-24 14:11:21.107585
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-24 14:11:28.800002
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp._titleformat == '%(artist)s - %(title)s'
    assert pp._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'
    assert pp.format_to_regex(
        '%(artist)s - %(title)s\\%(unk1)s') == '(?P<artist>.+)\ \-\ ' \
        '(?P<title>.+)(?:\\)(?P<unk1>.+)'

# Generated at 2022-06-24 14:11:39.259161
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-24 14:11:45.985491
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    """
    Sample testing function
    """
    metadatapostprocessor = MetadataFromTitlePP(None, "%(title)s")
    assert metadatapostprocessor._titleformat == "%(title)s"
    assert metadatapostprocessor._titleregex == "(?P<title>.+)"

    metadatapostprocessor = MetadataFromTitlePP(None, "%(title)s - %(artist)s")
    assert metadatapostprocessor._titleformat == "%(title)s - %(artist)s"
    assert metadatapostprocessor._titleregex == "(?P<title>.+)\ \-\ (?P<artist>.+)"

    metadatapostprocessor = MetadataFromTitlePP(None, "AllAboutThatBass - Meghan Trainor")
    assert metadatapostprocessor

# Generated at 2022-06-24 14:11:53.458434
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    titles = {
        # fmt: title
        '%(title)s - %(artist)s':                    'the title - the artist',
        '%(artist)s - %(title)s':                    'the artist - the title',
        '%(artist)s - %(title)s [%(aspect)s]':       'the artist - the title [16:9]',
        '%(artist)s - %(title)s - %(aspect)s':       'the artist - the title - 16:9',
        '%(title)s':                                 'the title',
        '%(title)s %(artist)s':                      'the title the artist',
        '%(artist)s %(title)s':                      'the artist the title',
    }

# Generated at 2022-06-24 14:12:03.652802
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl import YoutubeDL
    from youtube_dl.downloader import Downloader
    from youtube_dl.utils import YoutubeDLHandler
    import logging
    import io

    class FakeInfoDict:
        def __init__(self, title):
            self.name = 'title'
            self.title = title

    logger = logging.getLogger('youtube-dl')
    logger.addHandler(YoutubeDLHandler(io.BytesIO()))
    dl = YoutubeDL({'logger': logger})
    d = Downloader(dl, {'logger': logger})
    i = FakeInfoDict('Test - Title')
    pp = MetadataFromTitlePP(d, '%(artist)s - %(title)s')
    res_i, res_info = pp.run(i)

    assert res_i == []

# Generated at 2022-06-24 14:12:10.738628
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader

    dl = FileDownloader({'from_title': '%(artist)s - %(title)s'})
    pp = MetadataFromTitlePP(dl, dl.params['from_title'])

    # Test 1.
    # Case: valid title format and video title
    info = {'title': 'Artist Name - Video Title',
            'description': ''}
    pp.run(info)

    assert info['artist'] == 'Artist Name'
    assert info['title'] == 'Video Title'

    # Test 2.
    # Case: invalid title format
    info = {'title': 'Title',
            'description': ''}
    pp.run(info)

    assert info['artist'] == 'NA'
    assert info['title'] == 'NA'

    # Test 3.
   

# Generated at 2022-06-24 14:12:21.615591
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    ydl.add_default_info_extractors()
    class DummyDownloader:
        def to_screen(self, s):
            pass
    proc = MetadataFromTitlePP(DummyDownloader(), '%(title)s - %(artist)s')
    assert proc._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    # test all attributes are parsed correctly
    info = {'title': 'Test title - Test artist',
            'ext': 'mp4',
            'format': '720p',
            'format_id': '720p'}
    ydl.process_ie_result(proc.run(info))
    assert info['title'] == 'Test title'


# Generated at 2022-06-24 14:12:26.050915
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    m = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert m.format_to_regex(m._titleformat) == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert m._titleformat == '%(title)s - %(artist)s'



# Generated at 2022-06-24 14:12:31.464076
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from ytdl_handler import YtdlHandler
    ytdlh = YtdlHandler()
    pp = MetadataFromTitlePP(ytdlh, "%(title)s - %(artist)s")

# Generated at 2022-06-24 14:12:41.224276
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-24 14:12:52.626507
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mpp = MetadataFromTitlePP(None, '%(title)s')
    assert mpp.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert mpp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert mpp.format_to_regex('%(title)s - %(artist)s []') == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \[\]'
    # test if unused groups are ignored and escaped correctly

# Generated at 2022-06-24 14:13:01.701923
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import unittest
    from youtube_dl.YoutubeDL import YoutubeDL
    from mock import patch

    class TestMetadataFromTitlePP(unittest.TestCase):
        @patch('youtube_dl.postprocessor.common.PostProcessor._downloader')
        def test_format_to_regex(self, downloader_mock):
            ydl = YoutubeDL(params={})
            pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
            self.assertEqual(pp._titleregex, '(?P<title>.+)\ \-\ (?P<artist>.+)')

    unittest.main()

# Generated at 2022-06-24 14:13:12.858091
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import unittest
    import sys
    import __main__

    class NoOpDownloader(object):
        def to_screen(self, *_):
            pass
    class FakeInfoDict(dict):
        def __getitem__(self, key):
            if key == 'title':
                return 'The title of the video'
            elif key == 'artist':
                return None
            else:
                raise KeyError
        def get(self, key):
            if key == 'title':
                return 'The title of the video'
            elif key == 'artist':
                return None
            else:
                return None


# Generated at 2022-06-24 14:13:21.294311
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    res = pp.format_to_regex('%(title)s - %(artist)s')
    assert res == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    pp = MetadataFromTitlePP(None, 'Video title')
    res = pp.format_to_regex('Video title')
    assert res == 'Video title'

    pp = MetadataFromTitlePP(None, 'Video title - Description')
    res = pp.format_to_regex('Video title - Description')
    assert res == 'Video title - Description'

# Generated at 2022-06-24 14:13:28.153477
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Test MetadataFromTitlePP.__init__()
    format_string = '%(artist)s - %(title)s'
    regex_string = '(?P<artist>.+)\ \-\ (?P<title>.+)'
    MetadataFromTitlePP(None, format_string)
    MetadataFromTitlePP(None, regex_string)
    try:
        format_string = '%(artist)s - %(title)s - %(malformed)s' # malformed
        MetadataFromTitlePP(None, format_string)
    except ValueError as e:
        error = 'Malformed metadata format string'
        if not e.args[0].startswith(error):
            raise ValueError(
                'Exception does not start with expected error message.')


# Generated at 2022-06-24 14:13:37.711620
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Test to verify that the regex is generated as expected
    assert MetadataFromTitlePP(None, '%(title)s')._titleregex == '(?P<title>.+)'
    assert (MetadataFromTitlePP(None, 'a%(title)s')._titleregex
            == 'a(?P<title>.+)')
    assert (MetadataFromTitlePP(None, 'a%(title)sf')._titleregex
            == 'a(?P<title>.+)f')
    assert (MetadataFromTitlePP(None, 'a%(title)sb')._titleregex
            == 'a(?P<title>.+)b')
    assert (MetadataFromTitlePP(None, 'a%(title)s-b')._titleregex
            == 'a(?P<title>.+)-b')
   

# Generated at 2022-06-24 14:13:45.894802
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.extractor.common import InfoExtractor

    class DummyIE(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': '10',
                'title': 'xx - foo bar - yy',
                'ext': 'mp4',
                'url': 'hxxps://example.com/v.mp4',
            }

    info_dict = DummyIE('http://www.youtube.com/watch?v=BaW_jenozKc').extract()
    titleformat = '%(artist)s - %(title)s'

    # Test whether constructor of class MetadataFromTitlePP works as expected
    pp = MetadataFromTitlePP(None, titleformat)
    assert pp._titleformat == titleformat

# Generated at 2022-06-24 14:13:55.096242
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftpp = MetadataFromTitlePP(None, None)
    assert mftpp.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert mftpp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert mftpp.format_to_regex('%(title)s - %(artist)s - %(year)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<year>.+)'

# Generated at 2022-06-24 14:14:03.712949
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # sample data
    fmt = '%(title)s - %(artist)s'
    # expected output
    output = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    # result of function to be tested
    result = MetadataFromTitlePP(None, None).format_to_regex(fmt)
    # assertion
    assert result == output

    # sample data
    fmt = '%(test)s - %(test2)s'
    # expected output
    output = '(?P<test>.+)\ \-\ (?P<test2>.+)'
    # result of function to be tested
    result = MetadataFromTitlePP(None, None).format_to_regex(fmt)
    # assertion
    assert result == output

    # sample data

# Generated at 2022-06-24 14:14:11.984685
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    from . import YoutubeDL

    ytdl = YoutubeDL()

    # Create instance of class MetadataFromTitlePP
    titleformat = '%(title)s-[%(creator)s]'
    pp = MetadataFromTitlePP(ytdl, titleformat)

    info = {}
    info['title'] = 'mytitle -[mycreator]'

    # Call method run of class MetadataFromTitlePP
    pp.run(info)

    # Check results
    print('YoutubeDL info dictionary: ' + str(ytdl.info), file=sys.stderr)
    assert(ytdl.info['title'] == 'mytitle')
    assert(ytdl.info['creator'] == 'mycreator')


# Generated at 2022-06-24 14:14:22.267547
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    class DummyDownloader():
        def to_screen(self, text):
            print(text)
    dl = DummyDownloader()
    mp = MetadataFromTitlePP(dl, '%(title)s - %(artist)s')
    print(mp._titleformat)
    print(mp._titleregex)
    mp.run({'title': 'Smells Like Teen Spirit - Nirvana'})
    mp.run({'title': 'Nevermind - Nirvana'})
    mp.run({'title': 'Smells Like Teen Spirit - Nirvana'})
    try:
        mp.run({'title': 'Smells Like Teen Spirit - Nirvana - Foo'})
        assert False, 'Should fail'
    except:
        pass

# Generated at 2022-06-24 14:14:28.624251
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')

    titleformat_regex_expected = (
        '^(?P<title>.+)\\ \-\\ (?P<artist>.+)\s*$')
    assert pp._titleformat == '%(title)s - %(artist)s', pp._titleformat
    assert pp._titleregex == titleformat_regex_expected, pp._titleregex


# Generated at 2022-06-24 14:14:34.427838
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    m = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert m._titleregex == r'(?P<artist>.+)\ \-\ (?P<title>.+)'
    m = MetadataFromTitlePP(None, 'Eminem - Rap God')
    assert m._titleregex == 'Eminem - Rap God'


if __name__ == '__main__':
    test_MetadataFromTitlePP()

# Generated at 2022-06-24 14:14:42.967790
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .YoutubeDL import YoutubeDL
    from .extractor.youtube import YoutubeIE

    class MockInfoDict(dict):
        def __init__(self, title):
            super(MockInfoDict, self).__init__({
                'title': title,
            })

        def __getitem__(self, key):
            return super(MockInfoDict, self).__getitem__(key)

        def __setitem__(self, key, value):
            super(MockInfoDict, self).__setitem__(key, value)

    class MockYoutubeDL(YoutubeDL):
        def to_screen(self, s):
            print(s)

        def report_warning(self, s):
            print(s)

    # Example 1 - simple
    ydl = MockYoutubeDL()
   

# Generated at 2022-06-24 14:14:48.944703
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp._titleregex == r'(?P<artist>.+)\ \-\ (?P<title>.+)'


# Generated at 2022-06-24 14:14:59.295624
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    assert re.match(MetadataFromTitlePP(None, "%(title)s")._titleregex, "Foo")
    assert re.match(MetadataFromTitlePP(None, "%(title)s")._titleregex, "Bar") is None
    assert re.match(MetadataFromTitlePP(None, "%(title)s - %(artist)s")._titleregex, "Foo - Bar")
    assert re.match(MetadataFromTitlePP(None, "%(title)s - %(artist)s")._titleregex, "Foo - Bar - Baz")
    assert re.match(MetadataFromTitlePP(None, "%(title)s - %(artist)s - Baz")._titleregex, "Foo - Bar - Baz")


# Generated at 2022-06-24 14:15:09.223417
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ..jsinterp import JSInterpreter
    from ..extractor import YoutubeIE
    from ..utils import ExtractorError

    def extract_info(url, **kwargs):
        ie = YoutubeIE(JSInterpreter(), downloader=None)
        return ie.extract(url, **kwargs)['_type']

    # Empty title
    assert extract_info(
        url='https://www.youtube.com/watch?v=BaW_jenozKc',
        ie_key='Youtube',
        expected_title='') == 'url'

    # Missing metadata tag in title

# Generated at 2022-06-24 14:15:18.135277
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import tempfile
    from youtube_dl.compat import compat_OpenMode
    from youtube_dl.downloader.YoutubeDL import YoutubeDL

    with tempfile.NamedTemporaryFile(mode=compat_OpenMode(mode='w+t')) as f:
        f.write('dummy')
        f.seek(0)
        ydl = YoutubeDL({'downloader': 'dummy', 'quiet': True,
                        'outtmpl': f.name, 'ignoreerrors': True,
                        'simulate': True})

        # Test vod titleformat
        fmt='%(title)s-%(episode_number)s-%(episode_id)s'
        title='Mumbo Jumbo - 106 - Redstone Mechanic!'

# Generated at 2022-06-24 14:15:28.739576
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .youtube_dl.downloader.common import FileDownloader

    fmt1 = '%(artist)s - %(title)s'
    c_attrs = {'title': 'Video Title'}
    info1 = {'title': 'Artist Name - Video Title'}
    exp_info1 = {
        'title': info1['title'],
        'artist': 'Artist Name',
    }
    fmt2 = '%(title)s'
    info2 = {'title': 'Video Title'}
    exp_info2 = c_attrs
    fmt3 = '%(title)s - %(artist)s'
    info3 = {'title': 'Video Title'}
    exp_info3 = {
        'title': info3['title'],
        'artist': 'NA',
    }
    fmt

# Generated at 2022-06-24 14:15:38.809267
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    class FakeDL(object):
        @staticmethod
        def to_screen(s):
            print(s)

    fromtitle = MetadataFromTitlePP(FakeDL, '%(title)s - %(artist)s')
    assert re.search(r'%\(\w+\)s', fromtitle._titleformat), \
        'Titleformat should have %(..)s style notation'
    assert isinstance(fromtitle._titleregex, str), \
        'Titleregex should be a string'
    assert isinstance(fromtitle.format_to_regex(fromtitle._titleformat), str), \
        'Titleregex should be a string'

# Generated at 2022-06-24 14:15:51.029908
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .compat import compat_str
    from .extractor import gen_extractors
    from .utils import prepend_extension

    class FakeYDL(object):

        def __init__(self, params):
            self._params = params

        @property
        def params(self):
            return self._params

    ydl = FakeYDL({'writethumbnail': False})

    # plural forms of captions
    def plural(s):
        return s if '%(' in s else s + 's'

    def pluralize(s):
        return plural(s) if '%(' in s else (
            s + ' (%(upload_date)s)' if '%(upload_date)s' in s else s)

    def mkdict(**kwargs):
        return kwargs

    extractors = gen_extract

# Generated at 2022-06-24 14:15:57.879822
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftpp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    fmt = '%(title)s - %(artist)s'
    regex = mftpp.format_to_regex(fmt)
    assert regex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    regex_match = re.match(regex, 'Test - Me')
    assert regex_match is not None
    assert regex_match.groupdict() == {'title': 'Test', 'artist': 'Me'}

# Generated at 2022-06-24 14:16:08.156481
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from tests.test_postprocessor import MockYoutubeDL

    def _run_method(formatstring):
        ydl = MockYoutubeDL()
        metadatapp = MetadataFromTitlePP(ydl, formatstring)
        return metadatapp.format_to_regex(formatstring)

    assert _run_method('%(title)s') == r'(?P<title>.+)'
    assert _run_method('this is a %(title)s') == r'this\ is\ a\ (?P<title>.+)'
    assert _run_method('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-24 14:16:13.175889
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.InfoExtractors import YoutubeIE
    ydl = YoutubeDL({})
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'


# Generated at 2022-06-24 14:16:23.467950
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FakeYDL

    # Given a string with metadata tags %(title)s and %(artist)s
    # And a video title in a predefined format matching the metadata tags
    downloader = FakeYDL()
    format = '%(title)s - %(artist)s'
    title = 'ThisIsATitle - ThisIsAnArtist'
    title_processor = MetadataFromTitlePP(downloader, format)

    # When the title is parsed
    title_processor.run({'title': title})

    # Then the title is parsed as expected
    assert downloader.title == 'ThisIsATitle'
    assert downloader.artist == 'ThisIsAnArtist'

    # Given another string with metadata tags %(title)s and %(artist)s
    # And a video title having metadata already

# Generated at 2022-06-24 14:16:29.357215
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    fmt = '%(id)s-%(title)s.%(ext)s'
    regex = '%\(id\)s-(?P<title>.+)\.(?P<ext>[^.]+)'
    assert MetadataFromTitlePP(None, fmt)._titleregex == regex

    fmt = '(%(title)s) - %(artist)s.%(ext)s'
    regex = '\((?P<title>.+)\)\ \-\ (?P<artist>.+)\.(?P<ext>[^.]+)'
    assert MetadataFromTitlePP(None, fmt)._titleregex == regex


# Generated at 2022-06-24 14:16:34.512377
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(album)s - %(title)s')
    assert pp._titleformat == '%(artist)s - %(album)s - %(title)s'
    assert pp._titleregex == '(?P<artist>.+)\ \-\ (?P<album>.+)\ \-\ (?P<title>.+)'

    pp = MetadataFromTitlePP(None, 'just the title')
    assert pp._titleformat == 'just the title'
    assert pp._titleregex == 'just the title'


# Generated at 2022-06-24 14:16:38.216702
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s').format_to_regex(
            '%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-24 14:16:38.782422
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass

# Generated at 2022-06-24 14:16:49.295880
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    downloader = object()
    result_info = {'title': 'Lady Gaga - Alejandro'}
    result_info_target = {'title': 'Lady Gaga - Alejandro',
                          'artist': 'Lady Gaga',
                          'track': 'Alejandro'}
    pp = MetadataFromTitlePP(downloader, '%(artist)s - %(track)s')
    assert pp.run(result_info) == ([], result_info_target)
    result_info = {'title': 'Lady Gaga - Alejandro'}
    result_info_target = {'title': 'Lady Gaga - Alejandro',
                          'artist': 'Lady Gaga',
                          'track': 'Alejandro',
                          'other': '1'}

# Generated at 2022-06-24 14:16:57.715981
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '%(title)s'
    pp = MetadataFromTitlePP(None, 'abcd')
    assert pp._titleformat == 'abcd'
    assert pp._titleregex == 'abcd'

# Generated at 2022-06-24 14:17:04.333988
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '%(year)s %(artist)s - %(album)s - %(track)s - %(title)s')
    regex = pp.format_to_regex(pp._titleformat)
    assert regex == '(?P<year>.+)\ (?P<artist>.+)\ \-\ (?P<album>.+)\ \-\ (?P<track>.+)\ \-\ (?P<title>.+)'

# Generated at 2022-06-24 14:17:13.042237
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    import sys
    sys.path.append('..')
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.PostProcessor import PostProcessor
    from youtube_dl.compat import compat_str

    ydl = YoutubeDL({'quiet': True})
    pp = PostProcessor(ydl)
    mft = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s - %(year)s [%(id)s]')

    res, info = mft.run({'title': 'Video Title - Video Artist - 2012 [ABCDEF12]'})
    assert res == []
    assert info['title'] == 'Video Title'
    assert info['artist'] == 'Video Artist'
    assert info['year'] == '2012'
    assert info['id'] == 'ABCDEF12'

# Generated at 2022-06-24 14:17:16.102313
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    """Test constructor of class MetadataFromTitlePP."""
    test_format = '%(title)s - %(artist)s'
    test_regex = '(?P<title>.+) - (?P<artist>.+)'
    st = MetadataFromTitlePP(None, test_format)._titleregex
    assert st == test_regex, 'Wrong title regex: %s' % st


# Generated at 2022-06-24 14:17:24.518859
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    # test format_to_regex
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    # test run
    info = {'title': 'Red Hot Chilli Pipers - Scotland The Brave'}
    assert pp.run(info) == ( [], {'title': 'Red Hot Chilli Pipers - Scotland The Brave', 'artist': 'Red Hot Chilli Pipers'} )
    info = {'title': 'Red Hot Chilli Pipers - Scotland The Brave - Bagpipes'}
    assert pp.run(info) == ( [], {'title': 'Red Hot Chilli Pipers - Scotland The Brave', 'artist': 'Red Hot Chilli Pipers'} )
   

# Generated at 2022-06-24 14:17:29.526180
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, '%(title)s').format_to_regex('%(title)s') == '(?P<title>.+)'
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s').format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-24 14:17:39.671566
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    cases = (
        ('%(title)s', r'(?P<title>.+)'),
        ('%(title)s - %(artist)s', r'(?P<title>.+)\ \-\ (?P<artist>.+)'),
        ('%(title)s - %(artist)s - %(album)s',
         r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'),
    )
    for input, expected in cases:
        print('case: %r' % [input, expected])
        regex = MetadataFromTitlePP(None, input).format_to_regex(input)
        print('result: %r' % regex)
        assert regex == expected


# Generated at 2022-06-24 14:17:42.517638
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-24 14:17:48.349597
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s.%(ext)s')
    
    # Test with no substitutions
    assert pp.format_to_regex('foo') == 'foo', 'Unmodified string'
    
    # Test with a single substitution
    assert pp.format_to_regex('%(foo)s') == '(?P<foo>.+)', 'Single substitution'
    
    # Test with a combination of substitutions and non-substitutions
    assert pp.format_to_regex('foo%(foo)s') == 'foo(?P<foo>.+)', 'Multiple mixed string parts'
    
    # Test with multiple substitutions

# Generated at 2022-06-24 14:17:57.409213
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from mock import Mock

    def my_writeinfo(title, info_dict):
        assert len(info_dict) == 4
        assert info_dict['title'] == 'test title'
        assert info_dict['artist'] == 'test artist'
        assert info_dict['track'] == 'test track'
        assert info_dict['album'] == 'test album'

    ydl = YoutubeDL({'writedescription':False, 'writeinfojson':False, 'writethumbnail':False, 'writeannotations':False})
    ydl.add_info_extractor = Mock()
    ydl.postprocessors = [
        MetadataFromTitlePP(ydl, '%(title)s - %(artist)s - %(track)s - %(album)s')
    ]


# Generated at 2022-06-24 14:18:03.656794
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    mftpp = MetadataFromTitlePP('dummy', '%(title)s - %(artist)s')
    assert mftpp._titleformat == '%(title)s - %(artist)s'
    assert mftpp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    mftpp = MetadataFromTitlePP('dummy', '%(title)s %(artist)s')
    assert mftpp._titleformat == '%(title)s %(artist)s'
    assert mftpp._titleregex == r'(?P<title>.+)\ (?P<artist>.+)'

    mftpp = MetadataFromTitlePP('dummy', '%(title)s')
    assert mftpp._titleformat == '%(title)s'

# Generated at 2022-06-24 14:18:08.915172
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    METADATA_FROM_TITLE_TEST_DATA = [
        # test format without replacement fields
        {'format': 'foo', 'regex': 'foo'},
        # test format with one replacement field
        {'format': '%(title)s', 'regex': '(?P<title>.+)'},
        # test format with two replacement fields
        {'format': 'foo%(title)sbar%(artist)s', 'regex': 'foo(?P<title>.+)bar(?P<artist>.+)'},
        # test format with mixed replacement and ordinary fields
        {'format': '%(title)s youtube-dl test%(artist)s', 'regex': '(?P<title>.+) youtube-dl test(?P<artist>.+)'},
    ]

# Generated at 2022-06-24 14:18:18.863928
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Test regex
    assert (MetadataFromTitlePP(None, '%(title)s - %(artist)s')._titleregex ==
            r'(?P<title>.+)\ \-\ (?P<artist>.+)')
    assert (MetadataFromTitlePP(None, '%(title)s')._titleregex ==
            r'(?P<title>.+)')
    assert (MetadataFromTitlePP(None, '%(title)s - %(artist)s').
            format_to_regex('%(title)s - %(artist)s') ==
            r'(?P<title>.+)\ \-\ (?P<artist>.+)')

# Generated at 2022-06-24 14:18:28.495167
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ydl.downloader import Downloader
    from ydl.postprocessor import PostProcessor
    from ydl.extractor import InfoExtractor

    class MockIE(InfoExtractor):
        def __init__(self):
            pass

    class MockPP(PostProcessor):
        def __init__(self):
            pass

    ie = MockIE()
    ie.title = r'some title'
    ie.extra = {
        'title': 'some title',
        'artist': 'some artist',
        'track': 'some track'
    }
    ie.filename = 'some filename'

    pp = MetadataFromTitlePP(Downloader(), '%(title)s - %(artist)s - %(track)s')
    pp.add_info_extractor(MockIE)
    pp.run([ie])



# Generated at 2022-06-24 14:18:38.128127
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    from .ytdl_utils import match_filter_func
    stream = lambda arg: arg
    ydl = type('YoutubeDL', (object,), {'params': {'usetitle': True},
                                        'to_screen': stream,
                                        'set_filename': stream,
                                        'match_filter': match_filter_func})()

    title = 'Meet the Spy - Team Fortress 2'
    pp = MetadataFromTitlePP(ydl, '%(artist)s - %(title)s')
    info = {'title': title}
    pp.run(info)
    assert info['artist'] == 'Team Fortress 2' and info['title'] == 'Meet the Spy'

    pp = MetadataFromTitlePP(ydl, '%(title)s')
    info = {'title': title}

# Generated at 2022-06-24 14:18:46.440558
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp._titleformat == '%(artist)s - %(title)s'
    assert pp._titleregex == '%(artist)s\ \-\ %(title)s'

    pp = MetadataFromTitlePP(None, '%(title)s [%(artist)s]')
    assert pp._titleformat == '%(title)s [%(artist)s]'
    assert pp._titleregex == '(?P<title>.+)\ [\(?P<artist>.+\]?)'

    pp = MetadataFromTitlePP(None, '%(artist)s [%(title)s]')
    assert pp._titleformat == '%(artist)s [%(title)s]'
    assert pp._

# Generated at 2022-06-24 14:18:55.488809
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # test 1
    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp.format_to_regex('%(title)s') == '(?P<title>.+)'

    # test 2
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    # test 3
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s.mp4')

# Generated at 2022-06-24 14:18:59.389761
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.extractor.common import YoutubeIE
    from youtube_dl.YoutubeDL import YoutubeDL
    class FakeYDL:
        def __init__(self):
            self.ies = [YoutubeIE()]
    ydl = YoutubeDL(FakeYDL())
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(title)s'))


# Generated at 2022-06-24 14:19:05.716204
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class Fake_downloader():
        def to_screen(self, *args, **kwargs):
            pass
    downloader = Fake_downloader()

    # No match
    titleformat = r'%(title)s'
    pp = MetadataFromTitlePP(downloader, titleformat)
    assert pp.run({'title': 'no match'}) == ([], {'title': 'no match'})

    # Match but no groups
    titleformat = r'Hello World'
    pp = MetadataFromTitlePP(downloader, titleformat)
    assert pp.run({'title': 'Hello World'}) == ([], {'title': 'Hello World'})

    # Match with groups and with info
    titleformat = r'%(title)s - %(album)s'

# Generated at 2022-06-24 14:19:15.225235
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ..YoutubeDL import YoutubeDL
    from .common import TitlePPTestCase, FakeYDL

    class TestMetadataFromTitlePP(MetadataFromTitlePP, TitlePPTestCase):
        def __init__(self, ydl):
            MetadataFromTitlePP.__init__(self, ydl)
            TitlePPTestCase.__init__(self)

    ydl = FakeYDL()
    ydl.add_default_info_extractors()
    p = TestMetadataFromTitlePP(ydl)
    p.run(dict(title='Música do Felipe Neto'))
    assert p.get_metadata() == dict(artist=None, title='Música do Felipe Neto',
                                    track=None, track_number=None)


# Generated at 2022-06-24 14:19:21.079257
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    downloader = None
    titleformat = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(downloader, titleformat)
    regex = pp.format_to_regex(titleformat)
    assert regex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-24 14:19:30.886120
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # format_to_regex
    obj = MetadataFromTitlePP(None, '%(artist)s - %(song-name)s')
    assert obj._titleformat == '%(artist)s - %(song-name)s'
    assert obj._titleregex == '(?P<artist>.+)\ \-\ (?P<song-name>.+)'

    # format_to_regex
    obj = MetadataFromTitlePP(None, '%(artist)s - %(song-name)s [%(year)s]')
    assert obj._titleformat == '%(artist)s - %(song-name)s [%(year)s]'

# Generated at 2022-06-24 14:19:38.358443
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    downloader = YoutubeDL()


# Generated at 2022-06-24 14:19:48.976089
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    m = MetadataFromTitlePP(None, None)

    # basic test
    test_format = '%(title)s - %(artist)s'
    test_output = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert m.format_to_regex(test_format) == test_output

    # test that parts of string without %(..)s are escaped
    test_format = '%(title)s - %(artist)s - %(year)s'
    test_output = '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<year>.+)'
    assert m.format_to_regex(test_format) == test_output

    # test that parts of string without %(..)s are escaped
    test_

# Generated at 2022-06-24 14:19:56.698085
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    def test_pass(titleformat):
        MetadataFromTitlePP(None, titleformat)
    def test_fail(titleformat):
        try:
            MetadataFromTitlePP(None, titleformat)
            assert 0
        except AssertionError:
            pass

    test_pass('%(title)s')
    test_pass('%(title)s-%(ext)s')
    test_pass('%(title)s %(title)s')
    test_pass('%(title)s -%(title)s-')
    test_fail('%(title)s%(title)s')
    test_fail('%(title)s - %(title')
    test_fail('%(title)s -%(title)s')



# Generated at 2022-06-24 14:19:57.310714
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pass

# Generated at 2022-06-24 14:20:07.424722
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.downloader import Downloader
    from youtube_dl import FileDownloader
    from youtube_dl.YoutubeDL import YoutubeDL
    import tempfile

    def _download(ydl, *args, **kwargs):
        youtube_dl_opts = {'outtmpl': tempfile.NamedTemporaryFile().name,
                           'quiet': True}
        output = {'title': ''}
        fd = FileDownloader(ydl, youtube_dl_opts)
        mp = MetadataFromTitlePP(fd, '%(title)s')
        mp.run(output)

    # Test standard input
    _download(YoutubeDL(),
              'https://www.youtube.com/watch?v=BaW_jenozKc')

    # Test regular expression input

# Generated at 2022-06-24 14:20:11.078119
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    title = 'Pink Floyd - Another Brick in the Wall'
    info = {'title': title}
    pp.run(info)
    assert info['title'] == title
    assert info['artist'] == 'Pink Floyd'



# Generated at 2022-06-24 14:20:20.850660
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # assert MetadataFromTitlePP(None, '%(title)s')
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    # assert MetadataFromTitlePP(None, '%(title)s - %(artist)s [%(resolution)s]')
    # assert MetadataFromTitlePP(None, '%(uploader)s/%(title)s')
    # assert MetadataFromTitlePP(None, '[%(upload_date)s] %(title)s')
    # assert MetadataFromTitlePP(None, '%(uploader)s''/''%(title)s')
    # assert MetadataFromTitlePP(None, '%(uploader)s''/''%(title)s'' [%(resolution)s]')
    # assert MetadataFromTitle

# Generated at 2022-06-24 14:20:28.565340
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # create title post processor and test with two test cases:
    # 1. test case: title matches regex
    title_pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    # create test title
    title = 'Foo Fighters - Learn to Fly'
    # create test info dictionary
    info = {
        'title': title,
        'artist': '',
        'title_parser': title_pp
    }
    # run title post processor
    title_pp.run(info)
    # assertion
    assert info['artist'] == 'Foo Fighters'
    assert info['title'] == 'Learn to Fly'
    
    # 2. test case: title does not match regex
    title_pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')


# Generated at 2022-06-24 14:20:37.505669
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '')
    assert pp.format_to_regex('a%(A)s%(B)sa') == r'a(?P<A>.+)(?P<B>.+)a'
    assert pp.format_to_regex('%%(A)s') == r'%(?P<A>.+)s'
    assert pp.format_to_regex('%%(A)s%%') == r'%(?P<A>.+)s%'
    assert pp.format_to_regex('%%(A)s%(B)s') == r'%(?P<A>.+)s(?P<B>.+)'


# Generated at 2022-06-24 14:20:44.406811
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class AttrDict(dict):
        def __init__(self, *args, **kwargs):
            super(AttrDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    titleFormat = '%(title)s - %(artist)s'
    title = 'some title - artist name'
    info = AttrDict({'title':title})

    pp = MetadataFromTitlePP(None, titleFormat)
    pp.format_to_regex(titleFormat)

    assert pp.run(info)[1].title == 'some title'
    assert pp.run(info)[1].artist == 'artist name'

if __name__ == '__main__':
    test_MetadataFromTitlePP_run()

# Generated at 2022-06-24 14:20:53.429746
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl import YoutubeDL
    from youtube_dl.utils import DateRange

    class MyYoutubeDL(YoutubeDL):
        def process_video_result(self, *args, **kwargs):
            pass

    myytdl = MyYoutubeDL(params={'debug_printtraffic': True})
    myytdl.add_default_info_extractors()

    # Testing when no regex is specified, i.e., straight title match
    pp = MetadataFromTitlePP(myytdl, 'Jazz and Blues Experience')
    info = {'id': 'kwyjibo', 'title': 'Jazz and Blues Experience'}
    try:
        pp.run(info)
    except:
        assert False, 'Expected no exception.'

    # Testing when regex is specified
    pp = MetadataFromTitle