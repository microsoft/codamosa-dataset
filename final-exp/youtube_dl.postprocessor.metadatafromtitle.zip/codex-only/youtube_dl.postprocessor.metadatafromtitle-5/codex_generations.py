

# Generated at 2022-06-24 14:10:59.290117
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    """
    Simple unit test to see if we are getting the right regex for
    different formats
    """
    pp = MetadataFromTitlePP(None, 'ABC%(title)sCDE')
    assert pp._titleformat == 'ABC%(title)sCDE'
    assert pp._titleregex == 'ABC(?P<title>.+)CDE'

    pp = MetadataFromTitlePP(None, 'ABC%(title)sCDE%(id)sEFG')
    assert pp._titleformat == 'ABC%(title)sCDE%(id)sEFG'
    assert pp._titleregex == 'ABC(?P<title>.+)CDE(?P<id>.+)EFG'

    pp = MetadataFromTitlePP(None, 'ABC%(title)sCDE%(id)s')

# Generated at 2022-06-24 14:11:09.233249
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP._test_fmt_to_regex('%(title)s - %(artist)s') == \
        '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP._test_fmt_to_regex('%(title)s -- %(artist)s') == \
        '(?P<title>.+)\ \-\-\ (?P<artist>.+)'
    assert MetadataFromTitlePP._test_fmt_to_regex('%(title)s - %(artist)s - %(album)s') == \
        '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'

# Generated at 2022-06-24 14:11:13.900761
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    test = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert test._titleformat == '%(title)s - %(artist)s'
    assert test._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-24 14:11:23.999491
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    import sys
    import unittest
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    # from_to is a tuple: (expected format_to_regex result, input format)
    from_to = [
        ('%\(title\)s\ \-\ %\(artist\)s', '%(title)s - %(artist)s'),
        ('myFooUnique1 - myFooUnique2 - myFooUnique3',
         'my%%(fooUnique1)s - my%%(fooUnique2)s - my%%(fooUnique3)s')]
    for ft in from_to:
        assert pp.format_to_regex(ft[1]) == ft[0], ft[1]



# Generated at 2022-06-24 14:11:35.403993
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    """
    Unit test for MetadataFromTitlePP constructor; expects that some string
    formats are converted to the expected regex.
    """

    ffmpeg_metadata_formats = [
        '%(title)s',
        '%(artist)s - %(title)s',
        '%(track)s - %(artist)s - %(title)s',
        '%(artist)s - %(title)s [%(track)s]',
        '%(artist)s - %(title)s [%(track)s] [%(year)s]',
        '%(artist)s - %(title)s [%(track)s] [%(year)s] [%(genre)s]'
    ]

# Generated at 2022-06-24 14:11:43.394916
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest
    from ..compat import compat_urlparse

    class MockInfoDict(dict):
        def __init__(self, url):
            dict.__init__(self)
            self['url'] = url
            self['ext'] = 'flv'
            self['title'] = 'BlaBlaBla'
            self['artist'] = None
            self['track'] = None
            self['track_number'] = 42
            self['album'] = None
            self['album_artist'] = None
            self['genre'] = None
            self['date'] = None
            self['creator'] = None
            self['release_date'] = None
            self['upload_date'] = None

    class MockYDL():
        def to_screen(self, msg):
            print('msg: "%s"' % msg)

# Generated at 2022-06-24 14:11:49.646303
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import pytest
    from ytdl.downloader import Downloader
    downloader = Downloader(downloader_opts={})
    postprocessor = MetadataFromTitlePP(downloader, '%(artist)s - %(title)s')
    info = {'title': 'Kaleo - Way Down We Go'}
    _, new_info = postprocessor.run(info)
    assert new_info['artist'] == 'Kaleo'
    assert new_info['title'] == 'Way Down We Go'

# Generated at 2022-06-24 14:11:59.410909
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .compat import compat_str
    from .downloader import Downloader

    dl = Downloader(0, None)
    pp = MetadataFromTitlePP(dl, '%(title)s - %(artist)s')
    info = {'title': 'Some song - Some band'}
    pp.run(info)
    assert info['title'] == 'Some song'
    assert info['artist'] == 'Some band'
    errmsg = 'Could not interpret title of video as "%s"' % '%(title)s - %(artist)s'
    assert errmsg in dl._outcome.count(errmsg)
    assert 'parsed title: Some song' in dl._outcome
    assert 'parsed artist: Some band' in dl._outcome

# Generated at 2022-06-24 14:12:09.530591
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import unit
    import gdata.youtube
    youtube = unit.MockYoutubeDL({'verbose': True})

    # Set muted value to avoid printing to screen and shut down stderr
    youtube.params['muted'] = True
    stderr = sys.stderr
    sys.stderr = open(os.devnull, 'w')

    # Initialize
    metadataPP = MetadataFromTitlePP(youtube, '%(title)s - %(artist)s')
    result = metadataPP.run({'title': 'title - artist'})
    assert result[1]['title'] == 'title'
    assert result[1]['artist'] == 'artist'

    # Regex parsing

# Generated at 2022-06-24 14:12:20.296335
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-24 14:12:27.041243
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.downloader import Downloader
    from youtube_dl.utils import DateRange, std_headers
    dl = Downloader({'extract_flat': 'invalid'}, std_headers=std_headers, params={'debug_printtraffic': True},
                    format_limit='-1', test=True)

    pp1 = MetadataFromTitlePP(dl, '%(title)s - %(artist)s')
    assert pp1._titleformat == '%(title)s - %(artist)s'
    assert pp1._titleregex == '(?P<title>.+)\ \\-\ (?P<artist>.+)'

    pp2 = MetadataFromTitlePP(dl, '%(title)s')
    assert pp2._titleformat == '%(title)s'
    assert pp2._titleregex

# Generated at 2022-06-24 14:12:36.885099
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    info = {'title': 'The Title - An Artist'}
    titleformat = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(None, titleformat)
    (formats, info) = pp.run(info)
    assert formats == []
    assert info['title'] == 'The Title'
    assert info['artist'] == 'An Artist'

    # test if the regex works as expected
    titleformat = 'the (?P<artist>.) artist'
    pp = MetadataFromTitlePP(None, titleformat)
    (formats, info) = pp.run(info)
    assert formats == []
    assert info['artist'] == 'A'

    # test negative case
    titleformat = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP

# Generated at 2022-06-24 14:12:45.763494
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys

    # Simple test to check if MetadataFromTitlePP correctly parses the string
    # and returns the right values.

    test_downloader = sys.modules['__main__']
    test_downloader.to_screen = print
    test_title_format = '%(title)s - %(artist)s'
    test_title_regex = '%(title)s - %(artist)s'
    test_title = 'title - artist'

    test = MetadataFromTitlePP(test_downloader, test_title_format)

    test_title_expected_output = [{'title': 'title', 'artist': 'artist'}]
    test_title_result = test.run({'title': test_title})

# Generated at 2022-06-24 14:12:55.986097
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import json

    # the code under test
    sut = MetadataFromTitlePP(None, '%(title)s - %(artist)s')

    test_cases = [
        {
            'title': '',
            'expected': [],
            'info': {
                'title': ''
            }
        },
        {
            'title': 'Artist123 - Title123',
            'expected': [],
            'info': {
                'title': 'Artist123 - Title123',
                'artist': None
            }
        },
        {
            'title': 'Artist123 - Title123',
            'expected': [],
            'info': {
                'title': 'Artist123 - Title123',
                'artist': 'MyOldArtist',
                'whatever': 'Value'
            }
        }
    ]

   

# Generated at 2022-06-24 14:13:04.796558
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor.common import InfoExtractor

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self):
            pass

        def _real_extract(self, url):
            return {'id': '123',
                    'title': 'Foo - Bar',
                    'uploader': 'John Doe',
                    'thumbnail': 'http://example.com/thumbnail.jpg',
                    'duration': 'About 9 minutes'}

    downloader = FileDownloader({})
    ie = FakeInfoExtractor()
    ie.add_info_extractor(ie)
    downloader.add_info_extractor(ie)
    downloader.params = {}
    downloader.params['writethumbnail'] = True
    downloader.params['writeinfojson'] = True
   

# Generated at 2022-06-24 14:13:14.619033
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '(?P<title>.+)'

    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    pp = MetadataFromTitlePP(None, '%(title)s-%(artist)s')
    assert pp._titleformat == '%(title)s-%(artist)s'
    assert pp._titleregex == '(?P<title>.+)\-(?P<artist>.+)'

# Generated at 2022-06-24 14:13:23.671070
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # Test for empty string
    assert MetadataFromTitlePP(None, '').format_to_regex('') == ''
    # Test for string without replacements
    assert MetadataFromTitlePP(None, 'abc123').format_to_regex('abc123') == 'abc123'
    # Test for string with a single replacement
    assert MetadataFromTitlePP(None, '%(one)s').format_to_regex('%(one)s') == r'(?P<one>.+)'
    # Test for string with multiple replacements
    assert MetadataFromTitlePP(None, '%(one)s - %(two)s').format_to_regex('%(one)s - %(two)s') == r'(?P<one>.+)\ \-\ (?P<two>.+)'
    # Test for

# Generated at 2022-06-24 14:13:31.313914
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s').format_to_regex(
        '%(title)s - %(artist)s') == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, '%(title)s-%(artist)s').format_to_regex(
        '%(title)s-%(artist)s') == '(?P<title>.+)\\-(?P<artist>.+)'


# Generated at 2022-06-24 14:13:41.701975
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest
    import sys

    class FakeDownloader:
        def to_screen(self, msg):
            print(msg)

    class FakeInfo:
        def __init__(self, title):
            self.title = title

    class FakeDict(dict):
        pass

    class TestMetadataFromTitlePP(
        unittest.TestCase,
        MetadataFromTitlePP,
        FakeDownloader,
        ):
        def _run(self, format, title, expected):
            info = FakeInfo(title)
            expected = FakeDict(expected)
            self.assertEqual(
                self.run(format, info),
                (None, expected)
                )


# Generated at 2022-06-24 14:13:48.777913
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    test_videos = [
        {'url': 'https://www.youtube.com/watch?v=vwD7oRgTKhs', 'title': 'TEST - TITLE', 'description': 'TEST - DESCRIPTION'},
        {'url': 'https://www.youtube.com/watch?v=vwD7oRgTKhs', 'title': 'TEST', 'description': 'TEST - DESCRIPTION'}
    ]

    metadata = MetadataFromTitlePP('', '%(title)s - %(artist)s')

    for v in test_videos:
        data, info = metadata.run(v)
        assert(data == [])

        assert(info['artist'] == 'TITLE')
        assert(info['title'] == 'TEST')


# Generated at 2022-06-24 14:13:59.961363
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    import sys
    from .common import youtube_dl
    from .extractor.youtube import YoutubeIE

    class FakeDl:
        def to_screen(self, *args, **kargs):
            pass

    class FakeYoutubeDl:
        def __init__(self):
            self.params = {
                'simulate': True,
                'format': 'best',
                'outtmpl': '%(id)s',
                'ignoreerrors': False,
                'forceurl': False,
            }
            self.cache = None
            self.progress_hooks = []

        def add_info_extractor(self, ie):
            pass

        def download(self, info_dict):
            pass

    pp = MetadataFromTitlePP(FakeDl(), '%(title)s - %(artist)s')


# Generated at 2022-06-24 14:14:11.515333
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mft = MetadataFromTitlePP(None, None)
    assert mft.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+) \\- (?P<artist>.+)'
    assert mft.format_to_regex('%(author)s') == '(?P<author>.+)'
    assert mft.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert mft.format_to_regex('%(title)s - %(author)s - %(author)s') == '(?P<title>.+) \\- (?P<author>.+) \\- (?P<author>.+)'

# Generated at 2022-06-24 14:14:21.744652
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    instance = MetadataFromTitlePP(None, None)
    assert instance.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert instance.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert instance.format_to_regex('(?P<title>.+) - (?P<artist>.+)') == r'\(?P<title>.+\)\ \-\ \(?P<artist>.+\)'

# Generated at 2022-06-24 14:14:24.356796
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, None)
    assert pp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-24 14:14:33.673033
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor import YoutubeIE

    downloader = FileDownloader({'outtmpl': '%(id)s.%(ext)s'})
    downloader.add_info_extractor(YoutubeIE())

    # This is what a valid result should look like
    info = {
        'id': 'abc',
        'ext': 'mp4',
        'title': 'This is a youtube video - with a title and a format',
        'format': 'This is the format'
    }
    # Construct our pretty input
    result = [], info
    # This is our test object with a specific format
    test_obj = MetadataFromTitlePP(downloader, '%(title)s - %(format)s')
    # Execute the method

# Generated at 2022-06-24 14:14:42.501621
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor import gen_extractors
    from .extractor.generic import YoutubeIE
    from .__main__ import parseOpts

    class MockInfo:
        def __init__(self, title):
            self.title = title

    class MockYoutubeIE(YoutubeIE):
        def _real_extract(self, url):
            return MockInfo(title='"Test" - Youtube')

    # Register fake youtube extractor
    YoutubeIE.__bases__ = (MockYoutubeIE,) + YoutubeIE.__bases__
    extractors = gen_extractors()

    # Init everything
    args, _ = parseOpts(['http://www.youtube.com/watch?v=BaW_jenozKc'])

# Generated at 2022-06-24 14:14:52.046067
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    mftpp = MetadataFromTitlePP(None, 'test%(abc)sdef')
    assert mftpp._titleformat == 'test%(abc)sdef'
    assert mftpp._titleregex == '(?P<abc>.+)'
    mftpp = MetadataFromTitlePP(None, 'test%(abc)sdef%(123)s45')
    assert mftpp._titleformat == 'test%(abc)sdef%(123)s45'
    assert mftpp._titleregex == '(?P<abc>.+)(?P<123>.+)'
    mftpp = MetadataFromTitlePP(None, 'test%(abc)sdef%(123)s')
    assert mftpp._titleformat == 'test%(abc)sdef%(123)s'
    assert mftpp._

# Generated at 2022-06-24 14:15:02.892734
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    def avail(name):
        return name

    ydl = YoutubeDL({'postprocessors': [{'key': 'MetadataFromTitlePP',
                                         'titleformat': '%(title)s [%(id)s]',
                                         'format': 'bestvideo[width<=1920][height<=1080]'}]})
    ydl.add_info_extractor(avail)
    ydl.set_infos([{'title': 'Test title [AVywYbk_Qos]'}])
    ydl.build_video_result()
    assert ydl.result['title'] == 'Test title [AVywYbk_Qos]'
    assert ydl.result['id'] == 'AVywYbk_Qos'


# Unit

# Generated at 2022-06-24 14:15:12.613154
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    import json
    from collections import OrderedDict

    # Test whether metadata is not inserted into info when
    # title does not match pattern
    title = 'Lions on the Run'
    titleformat = '%(title)s - %(artist)s'
    regex = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    match = re.match(regex, title)
    assert match is None
    pp = MetadataFromTitlePP(sys, titleformat)
    info = {'title':title}
    titles, info = pp.run(info)
    assert titles == []
    json_info = json.dumps(info)
    assert 'title' in json_info and 'artist' not in json_info

    # Test whether metadata is inserted into info when
    # title does match

# Generated at 2022-06-24 14:15:19.418073
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .extractor import gen_extractors, list_extractors
    from .downloader import gen_downloader
    from collections import defaultdict
    from .compat import compat_str

    d = gen_downloader(defaultdict)
    ex = gen_extractors(d, list_extractors())
    pp = MetadataFromTitlePP(d, '%(title)s - %(artist)s')

    test_cases = [
        # Attributes and corresponding value
        {'_type': 'url', 'url': 'http://www.youtube.com/blah', 'title': 'Song name - Artist'},
        {'_type': 'url', 'url': 'http://www.youtube.com/blah', 'title': 'Song name - Artist - Album'}
        # TODO: Add more test cases
    ]

# Generated at 2022-06-24 14:15:30.661810
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ..YoutubeDL import YoutubeDL
    from ..YoutubeDL import FileDownloader
    from ..compat import compat_str
    from .common import InfoExtractor

    def test_fmt(ydl, fmt, expected_results):
        # Select our new downloader
        ydl = YoutubeDL(ydl.params)
        ydl.add_post_processor(MetadataFromTitlePP(ydl, fmt))
        # Fake download
        info = {'url': 'http://localhost/video.html',
                            'title': 'My title - youtube'}
        ydl.process_ie_result(InfoExtractor().suitable(None, info), info)
        # Check results

# Generated at 2022-06-24 14:15:39.826218
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    import unittest
    class TestMetadataFromTitlePP(unittest.TestCase):
        def setUp(self):
            self.metadata_from_title_pp = MetadataFromTitlePP(
                None, None)

        def test_format_to_regex(self):
            self.assertEqual(
                self.metadata_from_title_pp.format_to_regex(
                    '%(title)s - %(artist)s'),
                '(?P<title>.+)\ \-\ (?P<artist>.+)')
            self.assertEqual(
                self.metadata_from_title_pp.format_to_regex(
                    '%(title)s'),
                '(?P<title>.+)')

# Generated at 2022-06-24 14:15:51.492972
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest

    class TestMetadataFromTitlePP_run(unittest.TestCase):
        def test_converts_MetadataFromTitlePP_format_to_regex(self):
            class Downloader(object):
                def to_screen(*args):
                    pass
            fmt = '%(attribute)s - %(other)s'
            input_fmt = MetadataFromTitlePP(Downloader, fmt)
            expected_reg_ex = r'(?P<attribute>.+)\ \-\ (?P<other>.+)'
            self.assertEqual(input_fmt._titleregex, expected_reg_ex)

    return unittest.TestLoader().loadTestsFromTestCase(TestMetadataFromTitlePP_run)


# Generated at 2022-06-24 14:16:02.403387
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Test 1: %(title)s - %(artist)s
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    regex = pp._titleregex
    assert regex == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)', '%s != %s' % (regex, '(?P<title>.+)\\ \\-\\ (?P<artist>.+)')

    # Test 2: %(title)s - %(artist)s - %(album)s
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(album)s')
    regex = pp._titleregex

# Generated at 2022-06-24 14:16:07.988468
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from test.test_utils import FakeYDL
    from test.test_utils import FakeInfoDict
    from ytdl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    title_format = '%(artist)s - %(title)s'
    video_title = 'Ed Sheeran - Shape of You [Official Video]'
    ydl = FakeYDL()
    info = FakeInfoDict()
    info['title'] = video_title
    metadata = MetadataFromTitlePP(ydl, title_format)
    metadata.run(info)
    assert info == {
        'artist': 'Ed Sheeran',
        'title': 'Shape of You [Official Video]',
        'webpage_url': 'https://example.com',
    }

# Generated at 2022-06-24 14:16:17.806567
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import sys
    import types

    # class Downloader has a function to_screen()
    class Downloader():
        def to_screen(self, msg):
            print(msg)

    # class Info is not needed
    class Info():
        pass

    # create a Downloader
    mydl = Downloader()

    # create an instance of MetadataFromTitlePP
    pp = MetadataFromTitlePP(mydl, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    # create an instance of MetadataFromTitlePP
    pp = MetadataFromTitlePP(mydl, '(?P<title>.*)')
    assert pp

# Generated at 2022-06-24 14:16:26.476623
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s').format_to_regex(
            '%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s').format_to_regex(
            '%(title)s and %(artist)s - %(title)s') == '(?P<title>.+)\ and\ (?P<artist>.+)\ \-\ (?P<title>.+)'

# Generated at 2022-06-24 14:16:34.612428
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import ydl_config

    title = 'Miley Cyrus - Wrecking Ball - Parodia'
    info = {
        'title': title,
        'url': 'http://www.youtube.com',
        'ext': 'mp4'
    }
    downloader = object()
    downloader.params = {'noplaylist': True}

    pp = MetadataFromTitlePP(downloader, '%(author)s - %(title)s')
    expected_info = {
        'title': 'Wrecking Ball - Parodia',
        'url': 'http://www.youtube.com',
        'ext': 'mp4',
        'author': 'Miley Cyrus'
    }
    assert expected_info == pp.run(info)[1]


# Generated at 2022-06-24 14:16:44.473770
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    a = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    b = MetadataFromTitlePP(None, '%(\w+)s - %(artist)s')
    c = MetadataFromTitlePP(None, '%(title)s - %(\w+)s')
    d = MetadataFromTitlePP(None, '%(\w+)s - %(\w+)s')
    e = MetadataFromTitlePP(None, '%(\w+)s - x - %(\w+)s')
    f = MetadataFromTitlePP(None, '%(title)s')
    g = MetadataFromTitlePP(None, '%(title)s -')
    h = MetadataFromTitlePP(None, '%(title)s by %(artist)s')
    i = MetadataFromTitlePP

# Generated at 2022-06-24 14:16:46.527424
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    regex = pp._titleregex
    assert regex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-24 14:16:55.187587
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """
    Test run method of MetadataFromTitlePP
    """
    from youtube_dl.utils import parse_codecs

    class Mock(object):
        def to_screen(self, msg):
            print(msg)

    dl = Mock()
    pp = MetadataFromTitlePP(dl, '%(title)s - %(artist)s')
    print(pp.format_to_regex('%(title)s - %(artist)s'))
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    print(pp.format_to_regex('%(title)s'))

# Generated at 2022-06-24 14:17:05.480651
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # I'm not sure if it's a good idea to use a unit test
    # for this, as it's basically a test of the regular
    # expression building code in MetadataFromTitlePP.

    from ytdl.YoutubeDL import YoutubeDL
    from .expected import expected_formats
    pp = MetadataFromTitlePP(YoutubeDL(),
                             '%(title)s - %(artist)s')

    # youtube
    info = {'title': 'Old man\'s best friend - Weird Al Yankovic'}
    ret, info = pp.run(info)
    assert (info['title'] == "Old man's best friend"
            and info['artist'] == 'Weird Al Yankovic')
    # youtube with more complex title

# Generated at 2022-06-24 14:17:13.803374
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .extractor_proxy import YoutubeIE
    titleformat = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(None, titleformat)
    assert pp._titleformat == titleformat
    assert pp._titleregex == ('(?P<title>.+)\ \-\ (?P<artist>.+)')

    titleformat = '%(title)s: %(artist)s'
    pp = MetadataFromTitlePP(None, titleformat)
    assert pp._titleformat == titleformat
    assert pp._titleregex == ('(?P<title>.+)\:\ (?P<artist>.+)')

    titleformat = '%(title)s'
    pp = MetadataFromTitlePP(None, titleformat)
    assert pp._titleformat == titleformat

# Generated at 2022-06-24 14:17:16.435147
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    assert MetadataFromTitlePP.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'



# Generated at 2022-06-24 14:17:27.424509
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    try:
        from collections import namedtuple
        downloader_data = namedtuple('FakeDownloader', ['to_screen'])
    except ImportError:
        def downloader_data(name, fields):
            from collections import namedtuple
            return namedtuple(name, fields)

    class FakeDownloader:
        def __init__(self, future_output):
            self._future_output = future_output

        def to_screen(self, message):
            self._future_output.append(message)

    future_output = []
    downloader = FakeDownloader(future_output)
    pp = MetadataFromTitlePP(downloader, '%(artist)s - %(title)s - %(album)s')

    info = {'title': 'John Lennon - Imagine - Imagine'}

# Generated at 2022-06-24 14:17:37.781226
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    obj = MetadataFromTitlePP(None, None)
    tests = [
        ['%(title)s - %(artist)s', '(?P<title>.+)\ \-\ (?P<artist>.+)'],
        ['%(title)s', '(?P<title>.+)'],
        ['%(title)s%(artist)s', '(?P<title>.+)(?P<artist>.+)'],
        ['%(ab)s%(A)s', '(?P<ab>.+)(?P<A>.+)'],
        ['%%(ab)s%(A)s', '%%(ab)s(?P<A>.+)'],
    ]
    for test in tests:
        assert obj.format_to_regex(test[0]) == test[1]

# Generated at 2022-06-24 14:17:43.613754
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # result from input (in, out)
    tests = {
        '%(artist)s - %(title)s':
            r'(?P<artist>.+)\ \-\ (?P<title>.+)'
    }
    for inp, out in tests.items():
        assert MetadataFromTitlePP(None, inp)._titleregex == out

# Generated at 2022-06-24 14:17:49.048876
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    instance = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert instance._titleformat == '%(artist)s - %(title)s'
    assert instance._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'


# Generated at 2022-06-24 14:17:57.911465
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    downloader = FileDownloader(None, None)
    metadata_from_title_pp = MetadataFromTitlePP(downloader,
                                                 '%(title)s - %(artist)s')

    # test passing case
    info = {'title': 'The Title - The Artist'}
    metadata_from_title_pp.run(info)
    assert info['title'] == 'The Title'
    assert info['artist'] == 'The Artist'

    # test %(foo)s escaping
    info = {'title': 'The Title - The Artist'}
    metadata_from_title_pp.run(info)
    assert info['title'] == 'The Title'
    assert info['artist'] == 'The Artist'

    # test %(foo)s escaping
    metadata_from_title_

# Generated at 2022-06-24 14:18:04.985830
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .YoutubeDL import YoutubeDL
    ydl = YoutubeDL(dict())
    ydl.add_default_info_extractors()
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-24 14:18:08.373790
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    instance = MetadataFromTitlePP(None, None)
    assert instance.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-24 14:18:12.404822
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, '%(title)s')._titleregex == '(?P<title>.+)'
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s')._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'



# Generated at 2022-06-24 14:18:20.857313
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '(?P<title>.+)'

    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(id)s')
    assert pp._titleformat == '%(title)s - %(artist)s - %(id)s'

# Generated at 2022-06-24 14:18:30.086174
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class DownloaderMock:
        def __init__(self):
            self._screen = ''
        def to_screen(self, message):
            self._screen += message + '\n'

    downloader = DownloaderMock()
    processor = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')

    # Successful case
    processor.run({'title': 'foobar - hello world'})
    assert ('[fromtitle] parsed title: foobar\n'
            '[fromtitle] parsed artist: hello world\n'
            == downloader._screen)

    # Failed case
    downloader._screen = ''
    processor.run({'title': 'foobar'})

# Generated at 2022-06-24 14:18:34.457842
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mft = MetadataFromTitlePP(None, '')
    # Test positive case
    assert mft.format_to_regex('%(title)s - %(artist)s') \
        == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    # Test negative case (the string format is wrong)
    assert mft.format_to_regex('%(title)s - %(artist') \
        == r'%\(title\)s\ \-\ %\(artist'

# Generated at 2022-06-24 14:18:43.822837
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    # Need to fake downloader
    class FakeDownloader():
        def to_screen(self, s):
            print(s)
    # Create a PostProcessor instance and a fake info dict
    pp = MetadataFromTitlePP(FakeDownloader(), '%(creator)s-%(title)s-%(tracknumber)s-%(year)s')
    info = dict(
        title = 'a-b-c-d',
        tracknumber = '1',
    )
    # assert that run() sets the info dict correctly
    pp.run(info)
    assert info['creator'] == 'a-b'
    assert info['title'] == 'c'
    assert info['tracknumber'] == 'd'
    assert info['year'] == '1'

# Generated at 2022-06-24 14:18:52.248808
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    test_obj = MetadataFromTitlePP(
        downloader=None,
        titleformat='%(artist)s - %(title)s')
    assert test_obj._titleformat == '%(artist)s - %(title)s'
    assert test_obj._titleregex == '(?P<artist>.+) \\- (?P<title>.+)'
    test_obj = MetadataFromTitlePP(
        downloader=None,
        titleformat='%(artist)s')
    assert test_obj._titleformat == '%(artist)s'
    assert test_obj._titleregex == '%(artist)s'


# Generated at 2022-06-24 14:18:55.995423
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    obj = MetadataFromTitlePP(None, None)
    test_frm = '%(test1)s - %(test2)s'
    expected_regex = '(?P<test1>.+)\ \-\ (?P<test2>.+)'
    assert obj.format_to_regex(test_frm) == expected_regex


# Generated at 2022-06-24 14:19:01.376296
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, '%(a)s - %(b)s')._titleregex == \
        r'(?P<a>.+)\ \-\ (?P<b>.+)'
    assert MetadataFromTitlePP(None, '(?P<a>\w+) - (?P<b>\w+)')._titleregex == \
        r'(?P<a>\w+) - (?P<b>\w+)'
    assert MetadataFromTitlePP(None, 'abc')._titleregex == r'abc'

# Generated at 2022-06-24 14:19:07.997258
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.YoutubeDL import YoutubeDL
    pp = MetadataFromTitlePP(YoutubeDL(), '%(title)s - %(artist)s')
    regex = pp.format_to_regex('%(title)s - %(artist)s')
    print('regex: %s' % regex)
    assert regex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-24 14:19:14.447592
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    obj = MetadataFromTitlePP(None, None)
    fmt = '%(explicit)s - %(artist)s - %(title)s.%(ext)s'
    exp = r'(?P<explicit>\w+)\ \-\ (?P<artist>.+)\ \-\ (?P<title>.+)\.(?P<ext>\w+)'
    regex = obj.format_to_regex(fmt)
    #print(regex)
    assert(regex == exp)


# Generated at 2022-06-24 14:19:25.185062
# Unit test for constructor of class MetadataFromTitlePP

# Generated at 2022-06-24 14:19:33.520291
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    def assert_properly_formatted(titleformat):
        pp = MetadataFromTitlePP(None, titleformat)
        regex = pp.format_to_regex(titleformat)
        assert isinstance(regex, type('')),\
               "Expected string, got %s" % type(regex)

    # ok
    yield assert_properly_formatted, '%(artist)s - %(title)s'

    # all special chars escaped (except ')
    yield assert_properly_formatted, r'%(foo)s - %(bar)s: \bar\\\foo'

    # some special chars escaped
    yield assert_properly_formatted, r'%(foo)s: \' - %(bar)s'

    # test a title

# Generated at 2022-06-24 14:19:43.826896
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    if sys.version_info >= (3, 0):
        from io import StringIO
    else:
        from StringIO import StringIO
    import unittest
    from collections import namedtuple
    from youtube_dl.postprocessor import MetadataFromTitlePP

    # Test data, one dict per video. Format:
    #   video file name, video title, expected video metadata, expected output

# Generated at 2022-06-24 14:19:50.400119
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .common import FileDownloader
    dl = FileDownloader({})
    # blank string should not match
    pp = MetadataFromTitlePP(dl, '')
    assert pp._titleformat == ''
    assert pp._titleregex == ''

    # exact string should match
    pp = MetadataFromTitlePP(dl, 'this is my string')
    assert pp._titleformat == 'this is my string'
    assert pp._titleregex == 'this is my string'

    # exact string with % should match
    pp = MetadataFromTitlePP(dl, '%20%')
    assert pp._titleformat == '%20%'
    assert pp._titleregex == '%20%'

    # string with %(..)s should expand

# Generated at 2022-06-24 14:19:55.480406
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.common import PostProcessor
    p = PostProcessor(FileDownloader())
    pp = MetadataFromTitlePP(p.ydl, '%(title)s - %(artist)s')

    info = {'title': 'Track Number One - Artist Name'}
    pp.run(info)
    assert info['title'] == 'Track Number One - Artist Name'
    assert info['artist'] == 'Artist Name'
    assert len(info) == 2

    pp = MetadataFromTitlePP(p.ydl, '%(artist)s - %(title)s')
    pp.run(info)
    assert info['title'] == 'Track Number One'
    assert info['artist'] == 'Artist Name'
    assert len(info)

# Generated at 2022-06-24 14:20:06.286487
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    obj = MetadataFromTitlePP('', '%(title)s - %(artist)s')
    assert obj._titleformat == '%(title)s - %(artist)s'
    assert obj._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    info = {'title': 'The title - The artist'}
    assert obj.run(info) == ([], {'title': 'The title', 'artist': 'The artist'})

    obj = MetadataFromTitlePP('', '%(title)s - notitle - %(artist)s')
    assert obj._titleregex == r'(?P<title>.+)\ \-\ notitle\ \-\ (?P<artist>.+)'

    obj = MetadataFromTitlePP('', '%(title)s')

# Generated at 2022-06-24 14:20:14.238503
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import unittest
    import sys
    import youtube_dl

    class TestClass(unittest.TestCase):
        def setUp(self):
            self.downloader = youtube_dl.YoutubeDL({})
            self.regex = '(?P<title>.+) \- (?P<artist>.+)'
            self.regex_format = '%(title)s - %(artist)s'
            self.format = '%s - %s'
            self.title = 'title - artist'

        def test_init_regex(self):
            pp = MetadataFromTitlePP(self.downloader, self.regex)
            self.assertEqual(pp._titleregex, self.regex)
            self.assertIsNone(pp._titleformat)


# Generated at 2022-06-24 14:20:25.452180
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import youtube_dl
    import tempfile
    import os

    fmt1 = '%(artist)s - %(title)s'
    fmt2 = '%(track)s - %(title)s'

    fmt1_regex = '(?P<artist>.+)\ \-\ (?P<title>.+)'
    fmt2_regex = '(?P<track>.+)\ \-\ (?P<title>.+)'

    title = 'Dire Straits - Brothers in Arms'
    title_wrong = 'Brothers in Arms - Dire Straits'

    # Create a temporary youtube-dl downloader
    downloader = youtube_dl.YoutubeDL({'title': 'dummy'})

    # Create a temporary output file
    output_file = tempfile.NamedTemporaryFile(delete=False)

# Generated at 2022-06-24 14:20:35.552320
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .__main__ import parseOpts
    import sys
    import os

    args = [u'-f', u'%(title)s - %(artist)s', u'https://www.youtube.com/watch?v=BaW_jenozKc']
    _, ydl = parseOpts(args)
    fd = FileDownloader(ydl)
    # Initialize the postprocessor
    fd.add_post_processor(MetadataFromTitlePP(fd, ydl.params['fromtitle']))
    # Test postprocessor
    info = {'id': 1, 'title': 'THE BEST OF BACH'}
    pp, info = fd.post_processors[0].run(info)
    assert info['artist'] == 'Classic Man'

    # Test method format_

# Generated at 2022-06-24 14:20:41.038824
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP('', '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert not pp._titleregex

    pp = MetadataFromTitlePP('', '%(x)s - %(y)s')
    assert pp._titleformat == '%(x)s - %(y)s'
    assert pp._titleregex == '(?P<x>.+)\ \-\ (?P<y>.+)'


# Generated at 2022-06-24 14:20:46.627461
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.youtube import YoutubeIE
    from youtube_dl.downloader.common import FileDownloader

    ydl = YoutubeDL({'outtmpl': '%(upload_date)s-%(id)s-%(title)s.%(ext)s'})
    ydl.add_info_extractor(YoutubeIE())

    ydl.download(['https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert (ydl.get_filename(
        'https://www.youtube.com/watch?v=BaW_jenozKc') ==
            '2013-08-13-BaW_jenozKc-Google-I/O-101: The Next Billion.mp4')


# Generated at 2022-06-24 14:20:56.720945
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    def assert_format_to_regex(titleformat, regex):
        m = MetadataFromTitlePP(None, titleformat)
        assert m._titleregex == regex

    assert_format_to_regex('%(title)s - %(artist)s', '(?P<title>.+)\\ \\-\\ (?P<artist>.+)')
    assert_format_to_regex('%(title)s', '(?P<title>.+)')
    assert_format_to_regex('%(title)s - %(artist)s - %(album)s', '(?P<title>.+)\\ \\-\\ (?P<artist>.+)\\ \\-\\ (?P<album>.+)')