

# Generated at 2022-06-24 14:10:56.969497
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    def check_for_pattern(name, pattern, expected):
        if pattern != expected:
            print('%s: pattern %r != expected %r' % (name, pattern, expected))
    pp = MetadataFromTitlePP(None, '')
    check_for_pattern('title', pp.format_to_regex('%(title)s'),
                      '(?P<title>.+)')
    check_for_pattern('author', pp.format_to_regex('%(author)s'),
                      '(?P<author>.+)')
    check_for_pattern('title-author', pp.format_to_regex('%(title)s - %(author)s'),
                      '(?P<title>.+)\ \-\ (?P<author>.+)')

# Generated at 2022-06-24 14:11:07.311470
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    """Ensure MetadataFromTitlePP can parse regexes"""

    test_strs = [
        # regex, format, expect_okay
        # (expect_okay == False => expect exception on instantiation)
        # first regex is obviously not going to work
        (r'''This\ is\ %\(title\)s''', 'This is %(title)s', False),
        # next one should be fine
        (r'''This\(?P<title>.*)\.txt''', 'This%(title)s.txt', True),
        # this one too
        (r'''This-is-(%\(title\)s)''', 'This-is-%(title)s', True),
        ]


# Generated at 2022-06-24 14:11:18.103322
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test for case without regexp
    # Test when title corresponds to format
    mpp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    info = {'title': 'A song - An artist'}
    result, info = mpp.run(info)
    assert len(result) == 0
    assert info['title'] == 'A song'
    assert info['artist'] == 'An artist'
    # Test when title does not corresponds to format
    info = {'title': 'A song - An artist (feat. Another artist & Someone Another)'}
    result, info = mpp.run(info)
    assert len(result) == 0
    assert info['title'] == 'A song - An artist (feat. Another artist & Someone Another)'
    assert 'artist' not in info.keys()
   

# Generated at 2022-06-24 14:11:25.732647
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s')
    regex = pp.format_to_regex('%(title)s')
    assert regex == '(?P<title>.+)'

    regex = pp.format_to_regex('%(title)s - %(artist)s')
    assert regex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    regex = pp.format_to_regex('%(title)s (?:artist)')
    assert regex == '(?P<title>.+)\ \(\\?\\:artist\)'


# Generated at 2022-06-24 14:11:36.586640
# Unit test for constructor of class MetadataFromTitlePP

# Generated at 2022-06-24 14:11:44.239577
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-24 14:11:51.454440
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():

    class FakeYDL:
        def to_screen(self, message):
            pass

    mpp = MetadataFromTitlePP(FakeYDL(), '%(title)s - %(artist)s')
    regex = mpp.format_to_regex('%(title)s - %(artist)s')
    assert regex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    match = re.match(regex, 'Test title - Test artist')
    assert match is not None, (
        'MPP_FTTR: error in the regex expression')

# Generated at 2022-06-24 14:11:59.730886
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp1 = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp1._titleregex == '(?P<title>.+)\\ -\\ (?P<artist>.+)'
    pp2 = MetadataFromTitlePP(None, '%(title)s')
    assert pp2._titleregex == '%\\(title\\)s'
    pp3 = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(album)s')
    assert pp3._titleregex == '(?P<title>.+)\\ -\\ (?P<artist>.+)\\ -\\ (?P<album>.+)'

# Generated at 2022-06-24 14:12:03.417588
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, '').format_to_regex(
        '%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-24 14:12:08.066484
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    mp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert '%(title)s - %(artist)s' == mp._titleformat
    assert '(?P<title>.+)\ \-\ (?P<artist>.+)' == mp._titleregex
    mp = MetadataFromTitlePP(None, 'test title for unit test')
    assert 'test title for unit test' == mp._titleregex
    assert 'test title for unit test' == mp._titleformat

# Generated at 2022-06-24 14:12:12.853741
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftpp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert mftpp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'


if __name__ == '__main__':
    test_MetadataFromTitlePP_format_to_regex()

# Generated at 2022-06-24 14:12:21.126709
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    test_data = [
        ("", ""),
        ("abcd", "abcd"),
        ("%(title)s abcd", "(?P<title>.+) abcd"),
        ("abcd %(artist)s", "abcd (?P<artist>.+)"),
        ("%(composer)s %(artist)s", "(?P<composer>.+) (?P<artist>.+)"),
    ]
    for title, expected in test_data:
        pp = MetadataFromTitlePP(None, title)
        assert pp._titleregex == expected

# Generated at 2022-06-24 14:12:31.007529
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from ..downloader import DummyYoutubeDL

    # Test regex conversion of titleformat
    for titleformat, regex in (
        ('%(title)s', r'(?P<title>.+)'),
        ('[%(title)s]', r'\[(?P<title>.+)\]'),
        ('%(title)s - %(artist)s', r'(?P<title>.+)\ \-\ (?P<artist>.+)'),
        ('%(title)s - %(artist)s - %(album)s', r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)')
    ):
        assert MetadataFromTitlePP(DummyYoutubeDL(), titleformat
            )._titleregex == regex



# Generated at 2022-06-24 14:12:39.068836
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    class Downloader():
        def to_screen(self, message):
            pass
    pp = MetadataFromTitlePP(Downloader(), '%(title)s-%(artist)s')
    assert pp.format_to_regex('%(title)s-%(artist)s') == r'(?P<title>.+)-(?P<artist>.+)'
    assert pp.format_to_regex('%(title)s-%(artist)s(%(year)s)') == r'(?P<title>.+)-(?P<artist>.+)\((?P<year>.+)\)'
    pp = MetadataFromTitlePP(Downloader(), '%(title)s')
    assert pp.format_to_regex('%(title)s') == r'(?P<title>.+)'
    pp

# Generated at 2022-06-24 14:12:44.267022
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    args = {'titleformat': '%(title)s - %(artist)s'}
    ydl = None
    pp = MetadataFromTitlePP(ydl, args['titleformat'])

    info = {'title': 'Keep It Long - Busted'}
    assert pp.run(info)[1] == {'title': 'Keep It Long',
                               'artist': 'Busted'}


# Generated at 2022-06-24 14:12:49.755623
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp._titleformat == '%(artist)s - %(title)s'
    assert pp._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'

# Generated at 2022-06-24 14:12:58.512526
# Unit test for constructor of class MetadataFromTitlePP

# Generated at 2022-06-24 14:13:07.310690
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Test 1
    downloader = type('', (), {})
    info = {
        'title': 'foo - bar'
    }
    pp = MetadataFromTitlePP(downloader, '[%(title)s]')
    assert pp.run(info) == ([], {
        'title': 'foo - bar',
        'title': 'foo'
    })

    # Test 2
    downloader = type('', (), {})
    info = {
        'title': 'foo'
    }
    pp = MetadataFromTitlePP(downloader, '[%(title)s]')
    assert pp.run(info) == ([], {
        'title': 'foo',
        'title': 'foo'
    })

    # Test 3
    downloader = type('', (), {})

# Generated at 2022-06-24 14:13:16.000649
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ..YoutubeDL import YoutubeDL
    import sys
    import os

    def _print(*args):
        print(*args, end=' ')
        print()

    class MockYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYoutubeDL, self).__init__(*args, **kwargs)
            self._screen_file = open(os.devnull, 'w')

        def to_screen(self, msg):
            self._screen_file.write(repr(msg) + '\n')
            self._screen_file.flush()

    ydl = MockYoutubeDL()
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    ydl.add_post_processor(pp)
   

# Generated at 2022-06-24 14:13:24.492874
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    title_MetadataFromTitlePP = MetadataFromTitlePP(None, 'anything')
    assert title_MetadataFromTitlePP.format_to_regex(
        '%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert title_MetadataFromTitlePP.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert title_MetadataFromTitlePP.format_to_regex('nothing special') == 'nothing special'

# Generated at 2022-06-24 14:13:30.642306
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, '')

# Generated at 2022-06-24 14:13:37.153517
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    pp = MetadataFromTitlePP(None, "%(artist)s - %(title)s")
    regex = pp.format_to_regex("%(artist)s - %(title)s")
    result = re.findall(regex, "some artist - some title")
    assert result == [('some artist', 'some title')]

# Generated at 2022-06-24 14:13:45.357810
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    """Test for MetadataFromTitlePP."""
    import unittest

    class TestMetadataFromTitlePP_run(unittest.TestCase):
        def test_case1(self):
            titleformat = '%(title)s by %(artist)s'
            title = '"Audioslave - Like a Stone" by AudioslaveVEVO'
            info = {'title': title}
            titleregex = '(?P<title>.+) by (?P<artist>.+)'
            match = re.match(titleregex, title)
            for attribute, value in match.groupdict().items():
                info[attribute] = value
            self.assertEqual(info, {'title': '"Audioslave - Like a Stone"',
                                    'artist': 'AudioslaveVEVO'})

    un

# Generated at 2022-06-24 14:13:55.951900
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    """
    Unit test for constructor of class MetadataFromTitlePP

    """
    # construct regex from format
    fmt_pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    regex = fmt_pp.format_to_regex('%(title)s - %(artist)s')
    assert regex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    # construct regex from format
    fmt_pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert fmt_pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    # construct regex from format

# Generated at 2022-06-24 14:13:59.272421
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, '%(title)s').format_to_regex(
        '%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-24 14:14:10.764786
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Initialize a Downloader object
    from youtube_dl.downloader.common import Downloader
    d = Downloader(params={})
    title_format = '%(title)s - %(artist)s'
    metadata_from_title = MetadataFromTitlePP(d, title_format)
    # Initialize an info dictionary with a non-matching title
    info = {'title': 'title - artist'}
    # Method run should return the same info dictionary unchanged
    info_output, info_expected = metadata_from_title.run(info)
    assert info_output == info_expected == []
    assert info == {'title': 'title - artist'}
    # Method run should parse the title and add the corresponding metadata
    info = {'title': 'title - artist (feat. Bob)'}
    info_output, info_

# Generated at 2022-06-24 14:14:19.858018
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    assert MetadataFromTitlePP(None, '%(uploader)s - %(title)s')._titleregex == '(?P<uploader>.+)\ \-\ (?P<title>.+)'
    assert MetadataFromTitlePP(None, '%(title)s - %(id)s')._titleregex == '(?P<title>.+)\ \-\ (?P<id>.+)'
    assert MetadataFromTitlePP(None, '%(title)s')._titleregex == '%\(title\)s'
    assert MetadataFromTitlePP(None, '%(title)s - %(id)s')._titleformat == '%(title)s - %(id)s'

# Generated at 2022-06-24 14:14:28.804160
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import unittest
    import sys
    if sys.version_info >= (3, 3):
        from unittest.mock import Mock
    else:
        from mock import Mock
    from youtube_dl.downloader.postprocessor import PostProcessor
    from youtube_dl.extractor import common
    from youtube_dl.utils import encode_compat_str

    class MockInfo:
        pass

    class MockYdl:
        def to_screen(self, *args, **kwargs):
            pass

    class MockCommon:
        @staticmethod
        def find_description(webpage):
            return 'description'

    def encode(s):
        return encode_compat_str(s, 'utf-8')


# Generated at 2022-06-24 14:14:34.300737
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    metadata_from_title_pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')

    info = {}
    info['title'] = 'Leprous - The Price'
    expected_info = {}
    expected_info['title'] = 'Leprous - The Price'
    expected_info['artist'] = 'Leprous'
    metadata_from_title_pp.run(info)
    assert info == expected_info

# Generated at 2022-06-24 14:14:41.472367
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Test with regex
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp._titleformat == '%(artist)s - %(title)s'
    assert pp._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'
    # Test without regex
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s'[::-1])
    assert pp._titleregex == '%(artist)s - %(title)s'[::-1]
    # Test with regex and char class
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s\t')

# Generated at 2022-06-24 14:14:44.972477
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    instance = MetadataFromTitlePP(None, None)
    assert 'title' in instance.format_to_regex(r'%(title)s - %(artist)s')
    assert 'artist' in instance.format_to_regex(r'%(title)s - %(artist)s')


# Generated at 2022-06-24 14:14:51.203481
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .common import FileDownloader
    from .extractor import gen_extractors

    # Simulate downloader
    downloader = FileDownloader({
        'format': 'bestaudio/best',
        'outtmpl': '%(title)s.%(ext)s',
        'postprocessors': [{
            'key': 'MetadataFromTitle',
            'titleformat': '%(artist)s - BLAH BLAH BLAH - %(title)s'
        }],
    }, None, None)
    downloader.add_info_extractor(gen_extractors(downloader))

    # Test conversion of string format to regex

# Generated at 2022-06-24 14:14:56.419934
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .test import ANY
    downloader = ANY # doesn't matter for this test
    processor = MetadataFromTitlePP(downloader, '%(artist)s - %(title)s')
    a = 1, [], {'title': 'Test', 'artist': 'Test2'}
    b = 1, [], {'title': 'Test2 - Test'}
    assert(processor.run(b) == a)
    processor = MetadataFromTitlePP(downloader, '%(artist)s - %(title)s - %(album)s')
    a = 1, [], {'title': 'Test', 'artist': 'Test2'}
    b = 1, [], {'title': 'Test2 - Test - %(album)s'}
    assert(processor.run(b) == a)

    processor = Metadata

# Generated at 2022-06-24 14:15:00.213967
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import sys

    # Format for song: "%(artist)s - %(title)s"
    mft = MetadataFromTitlePP(system = sys, titleformat = '%(artist)s - %(title)s')
    regex = '^(?P<artist>.+)\\\ \-\ (?P<title>.+)$'
    assert mft._titleregex == regex, "Wrong regex: %s" % mft._titleregex
    assert mft._titleformat == '%(artist)s - %(title)s', "Wrong format: %s" % mft._titleformat

    # Format for video: "%(uploader)s, %(title)s [%(id)s]"

# Generated at 2022-06-24 14:15:06.594012
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    class Fake_Downloader:
        def to_screen(self, message):
            pass

    d = Fake_Downloader()
    pp = MetadataFromTitlePP(d, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-24 14:15:16.015238
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .common import FakeYDL

    class FakeYdl:
        def to_screen(self, msg):
            print('[debug] %s'%msg)

    ydl = FakeYdl()
    p = MetadataFromTitlePP(ydl, r'%(artist)s - %(title)s')
    assert p._titleformat == '%(artist)s - %(title)s'
    assert p._titleregex == '(?P<artist>.+)\\ \\-\\ (?P<title>.+)'

    p = MetadataFromTitlePP(ydl, r'%(artist)s - %(title)s - %(album)s')
    assert p._titleformat == '%(artist)s - %(title)s - %(album)s'

# Generated at 2022-06-24 14:15:24.610983
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    reader = MetadataFromTitlePP(None, '')

    assert reader.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert reader.format_to_regex(
        '%(uploader)s - %(title)s') == '(?P<uploader>.+)\ \-\ (?P<title>.+)'
    assert reader.format_to_regex('%(series)s - Episode %(ep_num)s') == (
        '(?P<series>.+)\ \-\ Episode\ (?P<ep_num>.+)')



# Generated at 2022-06-24 14:15:34.759402
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s').format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s').format_to_regex('%(title)s - %(artist)s  ') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s  ').format_to_regex('%(title)s - %(artist)s  ') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert Metadata

# Generated at 2022-06-24 14:15:41.890379
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    def test(titleformat):
        pp = MetadataFromTitlePP(None, titleformat)
        assert pp._titleformat == titleformat, \
            'title format mismatch:\n%s\n---\n%s' \
            % (pp._titleformat, titleformat)

    formattests = [
        '%(title)s',
        '%(title)s - %(artist)s',
        '%(title)s - %(artist)s - %(sitename)s',
        '%(title)s - %(sitename)s',
        '%(title)s - %(sitename)s - %(artist)s',
    ]
    for format in formattests:
        yield test, format


# Generated at 2022-06-24 14:15:45.190803
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    MetadataFromTitlePP(None, '%(title)s - %(artist)s')


if __name__ == '__main__':
    test_MetadataFromTitlePP()

# Generated at 2022-06-24 14:15:55.865284
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    obj = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert obj._titleformat == '%(artist)s - %(title)s'
    assert obj._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'

    obj = MetadataFromTitlePP(None, '%(artist)s - %(title)s [%(resolution)s]')
    assert obj._titleformat == '%(artist)s - %(title)s [%(resolution)s]'
    assert obj._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)\ \[(?P<resolution>.+)\]'


# Generated at 2022-06-24 14:16:04.334186
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ydl.YDL import YDL

    def mock_downloader_instance():
        instance = YDL()
        instance.to_screen = lambda x: ''
        return instance

    class MockInfoDict():
        def __init__(self, title):
            self.__title = title
            self.get = self.__getitem__

        def __getitem__(self, key):
            if key == 'title':
                return self.__title
            return None

    class MockArgs():
        def __init__(self, titleformat):
            self.titleformat = titleformat

    # Empty title
    info = MockInfoDict('')
    args = MockArgs('%(title)s - %(artist)s')
    pp = MetadataFromTitlePP(mock_downloader_instance(), args.titleformat)


# Generated at 2022-06-24 14:16:07.955473
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    fmt = '%(title)s - %(artist)s'
    regex = '''(?P<title>.+)\ \-\ (?P<artist>.+)'''
    assert(MetadataFromTitlePP(None, fmt).format_to_regex(fmt) == regex)


# Generated at 2022-06-24 14:16:17.809442
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .downloader import FileDownloader
    from .extractor import get_info_extractor
    from .compat import compat_str

    downloader = FileDownloader({})
    ie = get_info_extractor(downloader, u'youtube')
    video_id = compat_str(ie._match_id(u'http://youtube.com/v/BaW_jenozKc'))
    video_info = ie.extract(video_id)

    pp = MetadataFromTitlePP(downloader, '%(uploader)s - %(title)s')
    entry = pp.run(video_info)

# Generated at 2022-06-24 14:16:25.220295
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mft = MetadataFromTitlePP(None, None)
    # method format_to_regex should convert a string like
    #   '%(title)s - %(artist)s'
    # to a regex like
    #   '(?P<title>.+)\ \-\ (?P<artist>.+)'
    fmt = '%(title)s - %(artist)s'
    regex = mft.format_to_regex(fmt)
    match = re.match(regex, 'Some title - Some artist')
    assert match is not None
    assert match.groupdict() == {'title': 'Some title', 'artist': 'Some artist'}

# Generated at 2022-06-24 14:16:31.052401
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp._titleformat == '%(artist)s - %(title)s'
    assert pp._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+?)'

    pp = MetadataFromTitlePP(None, 'bla')
    assert pp._titleformat == 'bla'
    assert pp._titleregex == 'bla'


# Generated at 2022-06-24 14:16:35.378452
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    ff_mock = lambda x: x
    intr_mock = lambda x: x
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s', ff_mock, intr_mock)
    info = {'title': 'YoutubeDl Test - Test Artist'}
    pp.run(info)
    assert info['title'] == 'YoutubeDl Test'
    assert info['artist'] == 'Test Artist'

# Generated at 2022-06-24 14:16:42.343829
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    assert MetadataFromTitlePP(None, '%(songtitle)s - %(artist)s')._titleregex == '(?P<songtitle>.+)\\ \\-\\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, '%(songtitle)s')\
        ._titleregex == '(?P<songtitle>.+)'
    assert MetadataFromTitlePP(None, r'%\(songtitle\)s')._titleregex \
        == r'%\(songtitle\)s'


# Generated at 2022-06-24 14:16:46.935384
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    pp = MetadataFromTitlePP(None, 'foo')
    assert pp._titleregex == r'foo'

# Generated at 2022-06-24 14:16:52.999144
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from_title = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert from_title._titleformat == '%(artist)s - %(title)s'
    assert from_title._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'

    simple_title = MetadataFromTitlePP(None, 'Simple Title')
    assert simple_title._titleformat == 'Simple Title'
    assert simple_title._titleregex == 'Simple Title'


# Generated at 2022-06-24 14:16:58.616225
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    fmt = '%(title)s - %(artist)s'
    expected_regex = r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    actual_regex = MetadataFromTitlePP(None, fmt).format_to_regex(fmt)
    assert(re.match(actual_regex, 'A - B'))
    assert(re.match(actual_regex, 'A - B').groupdict() == {
        'title': 'A',
        'artist': 'B',
    })



# Generated at 2022-06-24 14:17:09.061273
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    class MockYDL():
        def __init__(self):
            self.to_screen_called = False

        def to_screen(self, msg):
            self.to_screen_called = True

    ydl = MockYDL()
    # Test string with no %(..)s
    pp = MetadataFromTitlePP(ydl, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '%\\(title\\)s'

    # Test string with %(..)s
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'

# Generated at 2022-06-24 14:17:12.896390
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mpp = MetadataFromTitlePP(None, None)
    assert mpp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'
    assert mpp.format_to_regex('Test - (test)') == 'Test\\ \\-\\ \\(test\\)'

# Generated at 2022-06-24 14:17:21.212874
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .common import FileDownloader
    from .compat import compat_urllib_request
    import os
    import shutil
    import tempfile

    # Prepare fake downloader and fake urllib2.urlopen
    downloader = FileDownloader(params={})
    downloader.to_screen = lambda _: None
    downloader.params['outtmpl'] = '%(id)s.%(ext)s'
    downloader.params['forcetitle'] = True
    urlopen = compat_urllib_request.urlopen
    compat_urllib_request.urlopen = lambda _: None

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test.mp3')
    test_title = 'Mr.Shadow - The World Is Mine'

# Generated at 2022-06-24 14:17:28.768810
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .extractor import get_info_extractor

    ie = get_info_extractor('Youtube')
    # test titleformat that does not require parsing %(..)s
    fmt = '%(title)s - %(uploader)s'
    postprocessor = MetadataFromTitlePP('youtube_dl', fmt)
    title = 'Foo - Bar'
    result = postprocessor.run({'title': title, 'extractor': ie.ie_key()})
    assert result == ([], {'title': 'Foo', 'uploader': 'Bar'})
    # test titleformat that requires parsing %(..)s
    fmt = '%(title)s - %(uploader)s - %(upload_date)s'
    postprocessor = MetadataFromTitlePP('youtube_dl', fmt)

# Generated at 2022-06-24 14:17:38.836965
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ..jsinterp import JsInterpreter

    url = 'http://www.example.com/video-1'
    formats = [
        {'format_id': '18', 'url': url, 'ext': 'mp4', 'format': 'mp4'},
        {'format_id': '43', 'url': url, 'ext': 'webm', 'format': 'webm'},
    ]
    info = {
        'id': '1',
        'formats': formats,
        'title': 'Video 1 – FooBar',
        'url': url,
    }

    # downloader is needed to handle some deep methods
    downloader = JsInterpreter('http://www.example.com/video-1')
    downloader.process_info(info)

    # title format without field names
    title

# Generated at 2022-06-24 14:17:44.035028
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s')._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, '%(title)s')._titleregex == r'(?P<title>.+)'
    assert MetadataFromTitlePP(None, '%(\w+)s')._titleregex == r'(?P<\w+>.+)'
    assert MetadataFromTitlePP(None, '\w+')._titleregex == r'\w+'


# Generated at 2022-06-24 14:17:55.151817
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Test if titleformat is properly converted to regex
    titleformat = '%(title)s'
    titleregex = '%\(title\)s'
    mftpp = MetadataFromTitlePP(None, titleformat)
    assert mftpp._titleformat == titleformat
    assert mftpp._titleregex == titleregex

    titleformat = '%(title)s - %(artist)s'
    titleregex = '%\(title\)s\ \-\ %\(artist\)s'
    mftpp = MetadataFromTitlePP(None, titleformat)
    assert mftpp._titleformat == titleformat
    assert mftpp._titleregex == titleregex

    titleformat = '%(title)s - %(artist)s - %(album)s'

# Generated at 2022-06-24 14:17:58.466747
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    titleformat = '%(title)s by %(artist)s'
    downloader = object()
    instance = MetadataFromTitlePP(downloader, titleformat)
    assert instance._downloader is downloader
    assert instance._titleformat == titleformat
    assert instance._titleregex == '(?P<title>.+) by (?P<artist>.+)'


# Generated at 2022-06-24 14:18:09.569318
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .YoutubeDL import YoutubeDL
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_parse_urlparse
    # Test if the title format parser works
    url = 'http://example.org/video.mp4'
    title = "%(a)s - %(b)s-%(a)s - %(c)s"
    # matching title
    info = {'title': title}
    pp = MetadataFromTitlePP(YoutubeDL({}), title)
    assert pp.run(info) == ([],
        {'title': title, 'a': '%(a)s', 'b': '%(b)s-%(a)s', 'c': '%(c)s'})
    # non-matching title

# Generated at 2022-06-24 14:18:18.939105
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import test

    def run_test(title_format, title, expected_info):
        downloader = test.FakeYDL()
        metadata_pp = MetadataFromTitlePP(downloader, title_format)

        info_dict = {
            'id': 'abc',
            'display_id': 'abc',
            'title': title,
            'url': 'http://example.com',
            'ext': 'mp4',
            'format': '720',
            'player_url': None,
        }
        expected_info_dict = info_dict.copy()
        expected_info_dict.update(expected_info)

        # run postprocessor and assert
        _, info = metadata_pp.run(info_dict)
        assert info.items() <= expected_info_dict.items()

    # Test cases
    run

# Generated at 2022-06-24 14:18:28.569903
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    import unittest
    class TestMetadataFromTitlePPFormatToRegex(unittest.TestCase):
        def test_format_to_regex_basic(self):
            self.assertEqual(
                MetadataFromTitlePP(None, '%(title)s').format_to_regex('%(title)s'),
                '(?P<title>.+)')

        def test_format_to_regex_multiple_fields(self):
            self.assertEqual(
                MetadataFromTitlePP(None, '%(title)s - %(artist)s').format_to_regex('%(title)s - %(artist)s'),
                '(?P<title>.+)\ \-\ (?P<artist>.+)')


# Generated at 2022-06-24 14:18:35.131776
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    videoformat = '%(title)s - %(artist)s'
    videoformat_regex = r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, videoformat)._titleregex == videoformat_regex
    # Test escaped string
    assert MetadataFromTitlePP(None, '%%(title)s')._titleregex == '%(title)s'
    # Test without groups
    assert MetadataFromTitlePP(None, 'test')._titleregex == 'test'


# Generated at 2022-06-24 14:18:42.266892
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == \
        r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '%(title)s'


# Generated at 2022-06-24 14:18:51.319994
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from youtube_dl.downloader import YoutubeDL
    mftpp = MetadataFromTitlePP(YoutubeDL(), '%(title)s')
    assert mftpp.format_to_regex('abcd') == 'abcd'
    assert mftpp.format_to_regex('a%(b)s') == 'a(?P<b>.+)'
    assert mftpp.format_to_regex('a%(b)s%(c)s') == 'a(?P<b>.+)(?P<c>.+)'
    assert mftpp.format_to_regex('a%(b)s - %(c)s') == 'a(?P<b>.+)\ \-\ (?P<c>.+)'

# Generated at 2022-06-24 14:18:51.729336
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    pass

# Generated at 2022-06-24 14:18:57.322370
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    """ Test constructor of class MetadataFromTitlePP. """
    from youtube_dl.YoutubeDL import YoutubeDL

    class Options:
        """ Options class that only returns a empty dict for params. """
        def __getitem__(self, _):
            return {}

    ydl = YoutubeDL(Options())
    regex = '%(title)s - %(artist)s'
    pp = MetadataFromTitlePP(ydl, regex)
    assert pp._titleformat == regex
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-24 14:19:02.558192
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    instance = MetadataFromTitlePP(None, None)
    assert instance.format_to_regex(
        '%(title)s - %(artist)s - %(album)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'
    assert instance.format_to_regex(
        '%(title)s-%(artist)s-%(album)s') == '(?P<title>.+)-(?P<artist>.+)-(?P<album>.+)'


# Generated at 2022-06-24 14:19:12.941778
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from youtube_dl.YoutubeDL import YoutubeDL as YDL
    ydl = YDL()
    ydl.params.update({
        'quiet': True,
        'noprogress': True,
    })

    pp = MetadataFromTitlePP(ydl, '%(artist)s - %(track)s')
    assert pp.format_to_regex(
        '%(artist)s - %(track)s') == r'(?P<artist>.+)\ \-\ (?P<track>.+)'

    # Metadata information found in the title
    info = {
        'title': 'My Artist - My Track'
    }
    pp.run(info)

# Generated at 2022-06-24 14:19:18.312856
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # pylint: disable=protected-access, missing-docstring

    class MockInfo(dict):
        def __init__(self, title, **kwargs):
            self['title'] = title
            for k, v in kwargs.items():
                self[k] = v

    class MockDownloader(object):
        def __init__(self):
            self.to_screen_log = []

        def to_screen(self, msg):
            self.to_screen_log.append(msg)

    class MockYDL(object):
        def __init__(self):
            self.info = None

        def process_ie_result(self, ie_result, download=False):
            self.info = ie_result

    ydl = MockYDL()

# Generated at 2022-06-24 14:19:27.183924
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import sys
    from ytdl_wrapper import YoutubeDL
    from metadata_from_title import MetadataFromTitlePP

    print("\nTest of method run of class MetadataFromTitlePP")

    info = {'title': 'abc'}
    pp = MetadataFromTitlePP(YoutubeDL(), '%(title)s')
    pp_result = pp.run(info)
    assert info['title'] == 'abc'
    assert pp_result == ([], info)

    info = {'title': 'abc - 123'}
    pp = MetadataFromTitlePP(YoutubeDL(), '%(title)s - %(artist)s')
    pp_result = pp.run(info)
    assert info['title'] == 'abc'
    assert info['artist'] == '123'
    assert pp_result == ([], info)

# Generated at 2022-06-24 14:19:35.471459
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(songtitle)s')
    assert pp._titleformat == '%(artist)s - %(songtitle)s'
    assert pp._titleregex == '(?P<artist>.+)\ \-\ (?P<songtitle>.+)'

    pp = MetadataFromTitlePP(None, '%(artist)s - %(songtitle)s ')
    assert pp._titleformat == '%(artist)s - %(songtitle)s '
    assert pp._titleregex == '(?P<artist>.+)\ \-\ (?P<songtitle>.+)\ '

    pp = MetadataFromTitlePP(None, ' %(artist)s - %(songtitle)s ')

# Generated at 2022-06-24 14:19:39.042002
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'

    pp = MetadataFromTitlePP(None, '%(title)s')
    assert pp._titleformat == '%(title)s'
    assert pp._titleregex == '%(title)s'


# Generated at 2022-06-24 14:19:49.726167
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import youtube_dl
    class MyDummyYoutubeDL(object):
        def __init__(self, *args, **kwargs):
            self.to_screen_result = []
        def to_screen(self, message):
            assert type(message) is str
            self.to_screen_result.append(message)
    ydl = MyDummyYoutubeDL()
    mftpp = MetadataFromTitlePP(ydl, '%(artist)s - %(title)s [%(id)s]')
    assert mftpp._titleformat == '%(artist)s - %(title)s [%(id)s]'
    assert mftpp._titleregex == r'(?P<artist>.+)\ \-\ (?P<title>.+)\ \[(?P<id>.+)\]'
   

# Generated at 2022-06-24 14:19:57.329435
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import tempfile
    import shutil
    import os
    import sys
    import pytest
    import locale

    def filename_to_linelist(filename):
        with open(filename) as f:
            return [line.rstrip('\n') for line in f]

    def assert_linelist_match(list1, list2):
        assert len(list1) == len(list2)
        for item1, item2 in zip(list1, list2):
            assert item1 == item2

    # prepare tempdir and datadir
    tempdir = tempfile.mkdtemp()
    testdir = os.path.dirname(os.path.realpath(__file__))
    datadir = os.path.join(testdir, 'data')

    sys.path.append(testdir)

# Generated at 2022-06-24 14:20:07.487770
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, 'single string')
    assert pp._titleformat == 'single string'
    assert pp._titleregex == 'single string'

    pp = MetadataFromTitlePP(None, '... %(one)s ...')
    assert pp._titleformat == '... %(one)s ...'
    assert pp._titleregex == r'\.\.\.\ (?P<one>.+)\ \.\.\.'

    pp = MetadataFromTitlePP(None, '%(one)s ... %(two)s')
    assert pp._titleformat == '%(one)s ... %(two)s'
    assert pp._titleregex == r'(?P<one>.+)\ \.\.\.\ (?P<two>.+)'


# Generated at 2022-06-24 14:20:10.528899
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    my_downloader = object()
    pp = MetadataFromTitlePP(my_downloader, '%(title)s - %(artist)s')
    assert pp.downloader is my_downloader
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-24 14:20:18.637463
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import PostProcessor


# Generated at 2022-06-24 14:20:23.493559
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    obj = MetadataFromTitlePP('dummy', None)
    assert obj.format_to_regex('%(artist)s - %(title)s') == r'(?P<artist>.+)\ \-\ (?P<title>.+)'

# Generated at 2022-06-24 14:20:33.214902
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from os import path

    testargs = ['http://youtube.com/watch?v=BaW_jenozKc']
    # testargs = ['http://youtube.com/watch?v=BaW_jenozKc', '--no-warnings']

    # We catch stdout and stderr temporarily to avoid them from being displayed
    # while running the unit tests
    import sys
    import StringIO

    # This is a function that returns a custom downloader class that uses the
    # designated 'outtmpl' format string

# Generated at 2022-06-24 14:20:41.855225
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from_title = MetadataFromTitlePP(None, None)
    assert from_title.format_to_regex('%(artist)s') == r'(?P<artist>.+)'
    assert from_title.format_to_regex('%(artist)s - %(title)s') == r'(?P<artist>.+)\ \-\ (?P<title>.+)'
    assert from_title.format_to_regex('%(artist)s-%(title)s') == r'(?P<artist>.+)-(?P<title>.+)'

# Generated at 2022-06-24 14:20:46.321652
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleformat == '%(title)s - %(artist)s'
    assert pp._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-24 14:20:56.294113
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import tempfile
    import shutil
    import sys
    import os

    from ydl.util import FileDownloader, encode_compat_str

    def mkdtemp(suffix='', prefix='tmp', dir=None):
        """A function like tempfile.mkdtemp but does not cause unicode
        encode errors on Windows with Python 2."""
        assert prefix
        if dir is None:
            dir = os.getcwd()
        dir = encode_compat_str(dir, sys.getfilesystemencoding())
        return tempfile.mkdtemp(suffix, prefix, dir)

    # Create a temporary directory
    tmp_dir = mkdtemp()

    # Change current directory so ffmpeg can find the file
    old_cwd = os.getcwd()
    os.chdir(tmp_dir)
