

# Generated at 2022-06-24 14:10:59.910015
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mpp = MetadataFromTitlePP(None, None)

    assert mpp.format_to_regex("%(title)s - %(artist)s") == \
        r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert mpp.format_to_regex("title: %(title)s") == r'title\:\ (?P<title>.+)'
    assert mpp.format_to_regex("title: %(title)s - artist: %(artist)s") == \
        r'title\:\ (?P<title>.+)\ \-\ artist\:\ (?P<artist>.+)'

# Generated at 2022-06-24 14:11:09.701371
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Create a mock youtube_dl object to use for testing.
    class MockYoutubeDL(object):
        def __init__(self):
            self.to_screen_calls = []
        def to_screen(self, msg):
            self.to_screen_calls.append(msg)
    ydl = MockYoutubeDL()
    pp = MetadataFromTitlePP(ydl, 'title - artist')
    assert pp
    assert pp._titleformat == 'title - artist'
    assert pp._titleregex == r'.+\ \-\ .+'

    pp = MetadataFromTitlePP(ydl, 'title - artist -- %(year)s')
    assert pp
    assert pp._titleformat == 'title - artist -- %(year)s'

# Generated at 2022-06-24 14:11:18.766675
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mpp = MetadataFromTitlePP(downloader=None, titleformat=None)
    fmt = '%(title)s - %(artist)s'
    print(mpp.format_to_regex(fmt))
    fmt = '%(title)s - %(artist)s [%(test)s]'
    print(mpp.format_to_regex(fmt))
    fmt = '%(num)03d/%(den)03d'
    print(mpp.format_to_regex(fmt))

if __name__ == '__main__':
    test_MetadataFromTitlePP_format_to_regex()

# Generated at 2022-06-24 14:11:27.861685
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    ## Initialization of the class with a title format pattern
    _titleformat = '%(title)s - %(artist)s'
    _pp = MetadataFromTitlePP(None, _titleformat)

    ## Title format pattern is correctly converted to regex
    _pattern = '%(title)s\ \-\ %(artist)s'
    assert _pp.format_to_regex(_pattern) == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    ## Title format with only one group is correctly converted to regex
    _pattern = '%(title)s'
    assert _pp.format_to_regex(_pattern) == '(?P<title>.+)'

    ## Title format with multiple groups is correctly converted to regex

# Generated at 2022-06-24 14:11:34.571775
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    DOWNLOADER_OBJECT = object()
    from_title = MetadataFromTitlePP(DOWNLOADER_OBJECT, '%(title)s')

    info = {
        'title': 'title of video'
    }
    returnedValue = from_title.run(info)

    assert returnedValue == ([ ], {
        'title': 'title of video',
        'title': 'title of video'
    }), returnedValue


# Generated at 2022-06-24 14:11:39.336926
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    mft = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert mft._titleformat == '%(artist)s - %(title)s'
    assert mft._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'

# Check that the MetadataFromTitlePP successfully matches the regular
# expression generated to group metadata fields.

# Generated at 2022-06-24 14:11:44.223777
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .common import FakeYDL
    from .hooks import Hook

    ydl = FakeYDL()

    hook = Hook(ydl)
    hook.download_finished(None, {'title': 'baz - foo - bar'})
    assert hook.info['title'] == 'baz'
    assert hook.info['artist'] == 'foo'
    assert hook.info['album'] == 'bar'

# Generated at 2022-06-24 14:11:54.123828
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .downloader import Downloader
    import os.path

    info = {'title': 'ABC - DEF - GHI', 'artist': 'Unknown', 'album': None}
    titleformat = '%(title)s - %(artist)s'
    config = {'general': {'fromtitle': {titleformat: {}}},
              'output_template': os.path.join(os.path.dirname(__file__),
                                              'output_template.json')}
    downloader = Downloader(config)
    pp = MetadataFromTitlePP(downloader, titleformat)
    pp_result, info_result = pp.run(info)
    assert(info_result['title'] == 'ABC - DEF')
    assert(info_result['artist'] == 'GHI')

# Generated at 2022-06-24 14:11:58.201978
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp._titleformat == '%(artist)s - %(title)s'
    assert pp._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'


# Generated at 2022-06-24 14:12:08.404654
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    def test(titleformat, expected_titleregex):
        pp = MetadataFromTitlePP(object, titleformat)
        assert (pp._titleformat, pp._titleregex) == (titleformat, expected_titleregex)

    yield test, '%(title)s - %(artist)s', r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    yield test, '%(artist)s - %(title)s', r'(?P<artist>.+)\ \-\ (?P<title>.+)'
    yield test, '%(title)s', '(?P<title>.+)'
    yield test, '%(title)s%(title)s%(title)s', r'(?P<title>.+)(?P<title>.+)(?P<title>.+)'


# Generated at 2022-06-24 14:12:11.722600
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-24 14:12:22.655605
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    ydl = type('YDL', (object,), {'to_screen': lambda *args: None})()
    # Test with regex format
    pp = MetadataFromTitlePP(ydl, r'(?P<title>.+)')
    assert pp._titleformat == r'(?P<title>.+)'
    assert pp._titleregex == r'(?P<title>.+)'
    pp = MetadataFromTitlePP(ydl, r'%(title)s')
    assert pp._titleformat == r'%(title)s'
    assert pp._titleregex == r'(?P<title>.+)'
    pp = MetadataFromTitlePP(ydl, r'%(title)s - %(artist)s')
    assert pp._titleformat == r'%(title)s - %(artist)s'


# Generated at 2022-06-24 14:12:27.183322
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Sample strings and the expected regexes they are converted to
    tests = [
        # Title which contains more than one - because of the regex
        (r'%(title)s - %(artist)s', r'(?P<title>.+)\ \-\ (?P<artist>.+)'),
        # Title which contains only one -
        (r'%(title)s - %(artist)s', r'(?P<title>.+)\ \-\ (?P<artist>.+)')
    ]
    for titleformat, expected_regex in tests:
        test_obj = MetadataFromTitlePP(None, titleformat)
        assert test_obj._titleregex == expected_regex


# Unit tests for function format_to_regex

# Generated at 2022-06-24 14:12:36.982671
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class DummyYoutubeDL(object):
        def __init__(self):
            self.to_screen_value = ''

        def to_screen(self, msg):
            self.to_screen_value += msg + '\n'

    class DummyInfo(object):
        def __init__(self, title):
            self.title = title
            self.title_attribute = ''
            self.artist_attribute = ''

    # Test case 1
    dummy_downloader = DummyYoutubeDL()
    titleformat = '%(title)s - %(artist)s'
    metadata_from_title_pp = MetadataFromTitlePP(
        dummy_downloader, titleformat)
    info = DummyInfo('Title - Artist')
    _, result = metadata_from_title_pp.run(info)
    assert result

# Generated at 2022-06-24 14:12:45.814248
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class FakeDownloader:
        def to_screen(self, a):
            pass

    def fill_info(s):
        info = {'title': s}
        return info

    def check_info(info, title, artist=None, album=None, year=None):
        assert info.get('title') == title
        assert info.get('artist') == artist
        assert info.get('album') == album
        assert info.get('year') == year

    pp = MetadataFromTitlePP(FakeDownloader(), '%(title)s - %(artist)s')
    info = fill_info('The Title - The Artist')
    pp.run(info)
    check_info(info, 'The Title', 'The Artist')

    info = fill_info('The Title - The Artist (The Album)')

# Generated at 2022-06-24 14:12:52.578126
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    metadataFromTitlePP = MetadataFromTitlePP(None, '')
    assert metadataFromTitlePP.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert metadataFromTitlePP.format_to_regex('%(artist)s - %(title)s') == '(?P<artist>.+)\ \-\ (?P<title>.+)'



# Generated at 2022-06-24 14:12:57.044410
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    fmt = '%(title)s - %(artist)s'
    regex = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert regex == MetadataFromTitlePP(None, fmt).format_to_regex(fmt)


# Generated at 2022-06-24 14:13:04.863978
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    P = MetadataFromTitlePP(None, '')
    vals = [
        ('%(title)s - %(artist)s',
         '(?P<title>.+)\ \-\ (?P<artist>.+)'),
        ('%(a)s - %(b)s - %(c)s',
         '(?P<a>.+)\ \-\ (?P<b>.+)\ \-\ (?P<c>.+)'),
        ('%(abc)s',
         '(?P<abc>.+)'),
        ('',
         ''),
    ]
    for v in vals:
        assert v[1] == P.format_to_regex(v[0])

# Generated at 2022-06-24 14:13:14.655393
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-24 14:13:23.704881
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # Test for correct conversion of titleformat strings to title regex
    class DummyDowner(object):
        def to_screen(self, msg):
            pass
    fmt = '%(foo)s %(bar)s %(baz)s'
    regex = r'(?P<foo>.+)\ (?P<bar>.+)\ (?P<baz>.+)'
    pp = MetadataFromTitlePP(DummyDowner(), fmt)
    assert pp._titleregex == regex

    fmt = '%(foo)s%(bar)s%(baz)s'
    regex = r'(?P<foo>.+)(?P<bar>.+)(?P<baz>.+)'
    pp = MetadataFromTitlePP(DummyDowner(), fmt)
    assert pp._titleregex == regex


# Generated at 2022-06-24 14:13:30.005121
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    u"""
    Checks if method format_to_regex() converts a string like
           '%(title)s - %(artist)s'
    to a regex like
           '(?P<title>.+)\ \-\ (?P<artist>.+)'
    """
    pp = MetadataFromTitlePP(None, "")
    assert pp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+) - (?P<artist>.+)'
    assert pp.format_to_regex('%(title)s - %(artist)s - %(bla)s') == '(?P<title>.+) - (?P<artist>.+) - (?P<bla>.+)'

# Generated at 2022-06-24 14:13:38.846887
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor.common import InfoExtractor

    class FakeExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {'id': 'video_id',
                    'title': 'Video Title'}

    class FakeInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {'id': 'video_id',
                    'title': 'Video Title',
                    'extractor': 'fake'}

    info = {'id': 'video_id',
            'title': 'Video Title',
            'extractor': 'fake'}

    # Test without %(..)s token in format.
    ie = FakeInfoExtractor()

# Generated at 2022-06-24 14:13:46.696983
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftpp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert mftpp.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    mftpp = MetadataFromTitlePP(None, '''%(title)s - %(artist)s
                                        %(foo)s - %(baz)s''')

# Generated at 2022-06-24 14:13:57.896978
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # TODO: find out a better way to test this class
    actual = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert actual.format_to_regex('%(title)s - %(artist)s') == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert actual.format_to_regex('%(title)s') == r'(?P<title>.+)'
    assert actual.format_to_regex('%(title)s %(artist)s') == r'(?P<title>.+)\ (?P<artist>.+)'
    assert actual.format_to_regex('%( title  )s') == r'(?P<\ title\ \ \ \ ).+'
    assert actual.format_to

# Generated at 2022-06-24 14:14:05.532095
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():

    import pytube.extract
    pytube.extract.title = lambda x: 'foo'

    from pytube import Downloader
    from pytube.postprocessor import MetadataFromTitlePP

    downloader = Downloader({})
    pp = MetadataFromTitlePP(downloader, '%(id)s - %(title)s')
    assert pp.run({'title': 'foo'}) == ([], {'title': 'foo', 'id': 'foo'})

    pp = MetadataFromTitlePP(downloader, '- %(title)s - %(id)s')
    assert pp.run({'title': 'foo'}) == ([], {'title': 'foo', 'id': 'foo'})

    pp = MetadataFromTitlePP(downloader, '%(title)s')

# Generated at 2022-06-24 14:14:09.581362
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    obj = MetadataFromTitlePP(None, None)
    assert obj.format_to_regex('%(title)s-%(artist)s') \
        == '(?P<title>.+)\\-(?P<artist>.+)'
    assert obj.format_to_regex('No metadata') == 'No metadata'

# Generated at 2022-06-24 14:14:20.150903
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .compat import compat_urllib_parse

    def _check_output(titleformat, input, expected_output):
        downloader = DummyDownloader()
        _ = MetadataFromTitlePP(downloader, titleformat).run(input)
        # compat_urllib_parse.quote_plus() is used to encode special characters
        # in filenames, for example the ' ' (space) character is encoded to '+'.
        # However, '+' does not need to be encoded and is therefore decoded by
        # using compat_urllib_parse.unquote_plus().
        expected_output.update({key: compat_urllib_parse.unquote_plus(value)
                                for key, value in expected_output.items()})

# Generated at 2022-06-24 14:14:29.030292
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    """
    Test for method format_to_regex()
    """

    def _test(fmt, expected):
        mftpp = MetadataFromTitlePP(None, fmt)
        return mftpp.format_to_regex(fmt)

    assert _test('%(title)s - %(artist)s',
                 r'(?P<title>.+)\ \-\ (?P<artist>.+)') == \
           '(?P<title>.+)\\ \\-\\ (?P<artist>.+)'
    assert _test('%(title)s - %(artist)s - %(album)s',
                 r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)')

# Generated at 2022-06-24 14:14:38.037849
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    import ydl_core
    youtube_dl_obj = ydl_core.YoutubeDL({'writethumbnail': True, 'nooverwrites': True})
    pp = MetadataFromTitlePP(youtube_dl_obj, '%(track)s - %(artist)s - %(title)s')
    info = {'title': '1 - Artist - Title', 'filename': 'filename'}
    assert pp.run(info) == ([], {'title': '1 - Artist - Title', 'filename': 'filename', 'track': '1', 'artist': 'Artist', 'title': 'Title'})

    pp = MetadataFromTitlePP(youtube_dl_obj, '%(track)s - %(artist)s - %(title)s')

# Generated at 2022-06-24 14:14:45.591217
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    # Check that format_to_regex converts a string format as specified
    # in the docstring of the method
    mfpp = MetadataFromTitlePP(object, '')
    fmt = '%(title)s - %(artist)s'
    regex = mfpp.format_to_regex(fmt)
    assert regex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    fmt = '%(title)s - %(artist)s - %(album)s'
    regex = mfpp.format_to_regex(fmt)
    assert regex == r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ (?P<album>.+)'


# Generated at 2022-06-24 14:14:46.902765
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # TODO: Test this function
    return


# Generated at 2022-06-24 14:14:57.379848
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .compat import compat_http_client
    from .compat import compat_urllib_error
    from .compat import compat_urllib_request
    from .compat import compat_urllib_response
    import io
    import shutil
    import tempfile
    import unittest


# Generated at 2022-06-24 14:15:07.508339
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    class FakeInfo:
        def __init__(self):
            self.title = 'PyCon 2010 - Tarek Ziadé - Writing a Python package'

    # Test a simple format
    format = '%(title)s'
    pp = MetadataFromTitlePP(None, format)
    info = FakeInfo()
    # 'title' field must contain the original value
    assert info.title == 'PyCon 2010 - Tarek Ziadé - Writing a Python package'
    assert pp._titleformat == format
    assert pp._titleregex == '(?P<title>.+)'
    # 'title' field must be modified (extracted value)
    pp.run(info)
    assert info.title == 'PyCon 2010 - Tarek Ziadé - Writing a Python package'
    # 'title' field must contain the extracted value
   

# Generated at 2022-06-24 14:15:16.546023
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class DownloaderMockup:
        def __init__(self):
            self.to_screen_str = ''

        def to_screen(self, msg):
            self.to_screen_str += msg + '\n'

    class Result:
        pass

    result_dict = {}
    result = Result()
    result.result_dict = result_dict
    downloader = DownloaderMockup()
    postprocessor = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')

    # Test 1: Successful match
    result.result_dict['title'] = 'Title - Artist'
    postprocessor.run(result.result_dict)
    assert result.result_dict['title'] == 'Title'
    assert result.result_dict['artist'] == 'Artist'

# Generated at 2022-06-24 14:15:23.397902
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    # Arrange
    info = {
        'title':
            'One Direction - Best Song Ever [Studio Version] Best Song Ever'
            '[Studio Version] Best Song Ever'
    }
    pp = MetadataFromTitlePP('dummy_downloader',
                             '%(artist)s - %(title)s')

    # Act
    info = pp.run(info)[1]

    # Assert
    assert info['artist'] == 'One Direction'
    assert info['title'] == 'Best Song Ever [Studio Version] Best Song Ever'



# Generated at 2022-06-24 14:15:31.673663
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    info = { 'title': 'Hello - World' }
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s').run(info) == ([], {'title': 'Hello - World', 'artist': 'World'})
    assert MetadataFromTitlePP(None, '%(artist)s - %(title)s').run(info) == ([], {'title': 'Hello - World', 'artist': 'Hello'})
    assert MetadataFromTitlePP(None, '%(artist)').run(info) == ([], {'title': 'Hello - World'})

# Generated at 2022-06-24 14:15:40.377270
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    test_format_to_regex = MetadataFromTitlePP.format_to_regex

    # %(...)s patterns in fmt are turned into (?P<...>.+) regex group with
    # greedy quantifier. Whatever string is between %(...)s patterns is escaped
    # with re.escape.
    assert test_format_to_regex('%(title)s') == '(?P<title>.+)'
    assert test_format_to_regex('%(title)s - %(artist)s') == (
        r'(?P<title>.+)\ \-\ (?P<artist>.+)')

    # fmt is returned unmodified if it doesn't contain any %(...)s pattern.

# Generated at 2022-06-24 14:15:52.060968
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    m = MetadataFromTitlePP(None, '[%(itag)s] %(title)s')
    assert m._titleformat == '[%(itag)s] %(title)s'
    assert m._titleregex == r'(?P<itag>.+)\ (?P<title>.+)'

    m = MetadataFromTitlePP(None, '%(title)s')
    assert m._titleformat == '%(title)s'
    assert m._titleregex == '%(title)s'

    m = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert m._titleformat == '%(title)s - %(artist)s'

# Generated at 2022-06-24 14:15:56.641035
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert pp._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-24 14:16:07.509157
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp._titleformat == '%(artist)s - %(title)s'
    assert pp._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'

    # Strings that will be matched by the regex
    teststrs = [
        'AC - DC - Highway to hell',
        'artist - title',
        'The Beatles - I Want To Hold Your Hand',
        'John Lennon with Yoko Ono - Give Peace A Chance',
        'Eagles - Hotel California',
        'Bob Marley - No Women No Cry']
    for teststr in teststrs:
        match = re.match(pp._titleregex, teststr)
        assert match is not None

# Generated at 2022-06-24 14:16:17.358922
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    ydl.params['outtmpl'] = '%(title)s-%(artist)s.%(ext)s'
    postprocessor = MetadataFromTitlePP(ydl, '%(artist)s: %(title)s')
    assert postprocessor._titleregex == '(?P<artist>.+): (?P<title>.+)'

    ydl.params['outtmpl'] = '%(title)s.%(ext)s'
    postprocessor = MetadataFromTitlePP(ydl, '%(title)s')
    assert postprocessor._titleregex == '(?P<title>.+)'

    ydl.params['outtmpl'] = '%(title)s-%(artist)s.%(ext)s'

# Generated at 2022-06-24 14:16:26.027278
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    class TestExtractor(object):
        @staticmethod
        def get_title(self, video_id):
            return 'mytitle - myartist'

    class TestDownloader(object):
        def __init__(self):
            self.to_screen_list = []
            self.to_screen = lambda x: self.to_screen_list.append(x)

    extractor = TestExtractor()
    info = {'title': extractor.get_title(None, 'dummyid')}

    downloader = TestDownloader()
    pp = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    pp.run(info)

    assert info['artist'] == 'myartist'
    assert info['title'] == 'mytitle'


# Generated at 2022-06-24 14:16:34.086741
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    downloader = 'downloader'
    pp_str = 'MetadataFromTitlePP("%(uploader)s", "%(title)s")'
    mft_pp = MetadataFromTitlePP(downloader, pp_str)
    title = 'Test Title'
    info = {'title': title, 'uploader': 'Test Uploader',
            'password': 'pass123', 'format': 'mp4'}
    assert(mft_pp.format_to_regex(pp_str) ==
           '(?P<uploader>.+)\ (?P<title>.+)')
    assert(mft_pp.run(info) == ([], info))
    assert(info['uploader'] == 'Test Uploader')
    assert(info['title'] == 'Test Title')



# Generated at 2022-06-24 14:16:39.327798
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    def test(title, titleformat, expected_dict):
        info = {'title': title}
        pp = MetadataFromTitlePP(None, titleformat)
        _, out_dict = pp.run(info)
        assert out_dict == expected_dict, \
            'Expected "%s" but got "%s"' % (expected_dict, out_dict)

    # case 1: simple title
    test('foo', '%(title)s', {'title': 'foo'})
    test('foo - bar', '%(title)s - %(artist)s', {'title': 'foo', 'artist': 'bar'})
    test('foo - bar', '%(artist)s - %(title)s', {'title': 'bar', 'artist': 'foo'})

    # case 2: trailing separator

# Generated at 2022-06-24 14:16:49.341865
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    class FakeInfoDict(dict):
        def __str__(self):
            return self.get('title', '')

    TITLEFORMAT = '%(release_year)s - %(release_month)s - %(release_day)s - %(album)s - %(track)s - %(artist)s'
    TITLE = '2003 - 01 - 01 - Greatest Hits - 01 - The Band'
    downloader = FakeYDL()
    f = MetadataFromTitlePP(downloader, TITLEFORMAT)
    info = FakeInfoDict()
    info['title'] = TITLE
    f.run(info)
    print(info['release_year'])

if __name__ == '__main__':
    test_MetadataFromTitlePP()

# Generated at 2022-06-24 14:16:55.001821
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    def test(fmt, regex):
        pp = MetadataFromTitlePP(None, fmt)
        assert pp._titleformat == fmt, (pp._titleformat, fmt)
        assert pp._titleregex == regex, (pp._titleregex, regex)

    yield test, '%(title)s', '(?P<title>.+)'
    yield test, '%(title)s - %(artist)s', '(?P<title>.+)\ \-\ (?P<artist>.+)'

# Generated at 2022-06-24 14:16:59.894092
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    tfp = MetadataFromTitlePP(None, '') # Test with a dummy
    assert tfp.format_to_regex('abc%(test)sd') == r'abc(?P<test>.+)d'
    assert tfp.format_to_regex('abc%(test1)sd%(test2)s') == r'abc(?P<test1>.+)(?P<test2>.+)'

# Generated at 2022-06-24 14:17:10.073084
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    tests = [
        ('%(artist)s - %(title)s', '(?P<artist>.+)\ \-\ (?P<title>.+)'),
        ('%(title)s', '(?P<title>.+)'),
        ('video %(title)s - %(artist)s', 'video\ (?P<title>.+)\ \-\ (?P<artist>.+)'),
        ('[%(title)s]', '\[(?P<title>.+)\]'),
    ]
    for test, expected in tests:
        actual = MetadataFromTitlePP.format_to_regex(MetadataFromTitlePP, test)
        assert_equal(actual, expected, 'format_to_regex(%r) should be %r but is %r.'
                     % (test, expected, actual))

# Generated at 2022-06-24 14:17:16.216444
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    m = MetadataFromTitlePP(None, '%(title)s - %(artist)s - %(album)s')
    assert m._titleformat == '%(title)s - %(artist)s - %(album)s'
    assert m._titleregex == '(?P<title>.+)\\ \\-\\ (?P<artist>.+)\\ \\-\\ (?P<album>.+)'
    m = MetadataFromTitlePP(None, '%(title)s')
    assert m._titleformat == '%(title)s'
    assert m._titleregex == '(?P<title>.+)'

# Generated at 2022-06-24 14:17:24.632306
# Unit test for constructor of class MetadataFromTitlePP

# Generated at 2022-06-24 14:17:30.113617
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    mft = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert mft._titleformat == '%(title)s - %(artist)s'
    assert mft._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    mft = MetadataFromTitlePP(None, '%(title)s')
    assert mft._titleformat == '%(title)s'
    assert mft._titleregex == '%(title)s'

    mft = MetadataFromTitlePP(None, 'Title - Artist')
    assert mft._titleformat == 'Title - Artist'
    assert mft._titleregex == 'Title\ \-\ Artist'


# Generated at 2022-06-24 14:17:35.873369
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    test_titleformat = "%(title)s - %(artist)s"
    test_title = "Wham! - Last Christmas"
    pp = MetadataFromTitlePP({}, test_titleformat)
    assert pp._titleregex == '(?P<title>.+?)\ \-\ (?P<artist>.+)'


# Generated at 2022-06-24 14:17:41.185109
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    class DummyInfo:
        def __init__(self, title):
            self.title = title
    class DummyDownloader:
        verbose = True
        def to_screen(self, str):
            print(str)
    mpd = MetadataFromTitlePP(DummyDownloader(), '%(title)s - %(artist)s')
    mpd.run(DummyInfo('Test - artist'))

if __name__ == '__main__':
    test_MetadataFromTitlePP()

# Generated at 2022-06-24 14:17:44.949215
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    mft = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    mft.format_to_regex('"%(title)s" by %(artist)s')

# Generated at 2022-06-24 14:17:55.189789
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    import unittest
    from .testcases import PPOutputTestCase

    class TestFormatToRegex(PPOutputTestCase):
        def test_format_to_regex(self):
            from .postprocessor import MetadataFromTitlePP

            pp = MetadataFromTitlePP(None, '')
            self.assertEqual(pp.format_to_regex('%(title)s - %(artist)s'),
                             r'(?P<title>.+)\ \-\ (?P<artist>.+)')
            self.assertEqual(pp.format_to_regex('%(title)%'),
                             r'(?P<title>.+)%')
            self.assertEqual(pp.format_to_regex('%(title)'),
                             r'%(title)')
            self.assertEqual

# Generated at 2022-06-24 14:17:55.910682
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pass #TODO


# Generated at 2022-06-24 14:18:02.819629
# Unit test for method format_to_regex of class MetadataFromTitlePP

# Generated at 2022-06-24 14:18:07.438397
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    from .test import get_test_desc, MockYDL
    test_desc = get_test_desc(__name__, 'test_MetadataFromTitlePP_format_to_regex')

# Generated at 2022-06-24 14:18:16.482603
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # YouTube test cases
    if MetadataFromTitlePP(None, '%(title)s - %(artist)s').format_to_regex('%(title)s - %(artist)s') != '(?P<title>.+)\ \-\ (?P<artist>.+)':
        return False
    if MetadataFromTitlePP(None, '%(title)s').format_to_regex('%(title)s') != '(?P<title>.+)':
        return False

# Generated at 2022-06-24 14:18:26.414351
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import InfoExtractor
    from .extractor.generic import GenericIE
    class TestIE(InfoExtractor):
        IE_NAME = 'test'
        IE_DESC = 'Test'
        _VALID_URL = r'https?://.*'
        _TEST = {
            'url': 'http://www.youtube.com/watch?v=BaW_jenozKc',
            'title': 'test - test',
            'ie_key': 'Test',
            'info_dict': {
                'title': 'test',
                'artist': 'test'
            }
        }

        def _real_extract(self, url):
            return {
                'id': 'BaW_jenozKc',
                'url': url,
                'title': 'test - test'
            }

   

# Generated at 2022-06-24 14:18:33.679332
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # test for literal strings
    obj = MetadataFromTitlePP(None, '%(title)s - %(artist)s')
    assert obj._titleformat == '%(title)s - %(artist)s'
    assert obj._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    # test for literal strings (2)
    obj = MetadataFromTitlePP(None, '%(title)s')
    assert obj._titleformat == '%(title)s'
    assert obj._titleregex == '(?P<title>.+)'

    # test for literal strings (3)
    obj = MetadataFromTitlePP(None, '%(title)s - ')
    assert obj._titleformat == '%(title)s - '

# Generated at 2022-06-24 14:18:43.823478
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    downloader = lambda x: None
    downloader.to_screen = lambda x: None
    fromtitle = MetadataFromTitlePP(downloader, '%(title)s-%(artist)s')
    assert fromtitle.format_to_regex('%(title)s-%(artist)s') == '(?P<title>.+)-(?P<artist>.+)'
    info = {'title': 'mytitle-myartist'}
    assert[], fromtitle.run(info) == ([], {'title': 'mytitle-myartist', 'artist': 'myartist'})
    info = {'title': 'mytitle-myartist-myalbum'}
    assert[], fromtitle.run(info) == ([], {'title': 'mytitle-myartist-myalbum', 'artist': 'myartist'})

# Generated at 2022-06-24 14:18:51.925001
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s') is not None
    assert MetadataFromTitlePP(None, '%(title)s - myvideo.mp4')
    assert MetadataFromTitlePP(None, '%(title)s - %(artist)s')._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert MetadataFromTitlePP(None, '%(title)s - myvideo.mp4')._titleregex == '%\(title\)s\ \-\ myvideo.mp4'

# Generated at 2022-06-24 14:18:53.702670
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    test_format_to_regex(
        MetadataFromTitlePP(None, None).format_to_regex
    )


# Generated at 2022-06-24 14:18:57.113467
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP(None, '%(artist)s - %(title)s')
    assert pp._titleformat == '%(artist)s - %(title)s'
    assert pp._titleregex == '(?P<artist>.+)\ \-\ (?P<title>.+)'



# Generated at 2022-06-24 14:19:04.145103
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    from .downloader import YoutubeDL
    from .extractor import VideoExtractor
    from .common import FileDownloader
    from .utils import __     # Localization placeholder

    class FakeExtractor(VideoExtractor):
        """Fake VideoExtractor object to be returned by gen_extractor()."""
        IE_NAME = 'Fake Extractor'
        _VALID_URL = r'(?i)https?://(?:www\.)?(fakeurl)\.com/'
        @staticmethod
        def _extract_info(url):
            return {
                'id': '123456',
                'url': url,
                'upload_date': '20110101',
                'uploader': 'Some One',
                'title': 'Original title'
            }

# Generated at 2022-06-24 14:19:09.891613
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    titleformat = '%(title)s - %(artist)s'
    regex_result = '(?P<title>.+)\ \-\ (?P<artist>.+)'
    mftpp = MetadataFromTitlePP(None, titleformat)
    regex = mftpp.format_to_regex(titleformat)
    assert regex == regex_result


# Generated at 2022-06-24 14:19:13.751222
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ytdl_youtube_dl.extractor.youtube import YoutubeIE
    from ytdl_youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    # input data
    video_url = 'https://www.youtube.com/watch?v=IgEckstYK-g'
    title = 'Title - Artist'

    # test data
    mftpp = MetadataFromTitlePP(YoutubeIE(), '%(title)s - %(artist)s')
    info = {'id': 'IgEckstYK-g', 'title': title}

    # run unit test

# Generated at 2022-06-24 14:19:20.192182
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    pp = MetadataFromTitlePP('dummy', '%(title)s - %(artist)s')
    if pp._titleformat != '%(title)s - %(artist)s':
        raise AssertionError('_titleformat')
    if pp._titleregex != '(?P<title>.+) - (?P<artist>.+)':
        raise AssertionError('_titleregex')


# Generated at 2022-06-24 14:19:29.905592
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    """
    Tests regex compilation in constructor
    """
    # simple regex 1
    regex = 'Video\s+(?P<title>.+):\s+(?P<artist>.+)\s+\((?P<year>\d+)\)'
    inst = MetadataFromTitlePP(None, regex)
    assert inst._titleregex == regex
    # simple regex 2
    regex = '^(?P<title>.*)\ \-\ (?P<artist>.*)$'
    inst = MetadataFromTitlePP(None, regex)
    assert inst._titleregex == regex
    # regex with format string
    fmt = '%(title)s - %(artist)s'
    inst = MetadataFromTitlePP(None, fmt)

# Generated at 2022-06-24 14:19:37.643052
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import youtube_dl
    # Mocked video info
    videoInfo = {
        "id": 'test',
        "title": None,
    }
    # Mocked downloader
    ydl = youtube_dl.YoutubeDL({})
    # Metadata from title
    pp = MetadataFromTitlePP(ydl, '%(title)s')
    assert '%(title)s' == pp._titleregex
    pp = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    assert '(?P<title>.+)\ \-\ (?P<artist>.+)' == pp._titleregex
    # Let's see if the postprocessor works...
    videoInfo['title'] = 'test'
    info = pp.run(videoInfo)[1]

# Generated at 2022-06-24 14:19:42.174559
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    class FakeTLogger(object):
        def to_screen(self, msg):
            print(msg)

    item = {'title': 'The title - with artist'}
    tlog = FakeTLogger()
    tpp = MetadataFromTitlePP(tlog, '%(title)s - %(artist)s')
    tpp.run(item)

if __name__ == '__main__':
    test_MetadataFromTitlePP()

# Generated at 2022-06-24 14:19:52.816304
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    import types
    import unittest

    # Prepare test objects
    sut = MetadataFromTitlePP.MetadataFromTitlePP(None, None)
    if type(sut) is not types.TypeType:
        raise AssertionError("sut is not a class")
    if not hasattr(sut, 'format_to_regex'):
        raise AssertionError("sut does not have attribute 'format_to_regex'")
    if not callable(sut.format_to_regex):
        raise AssertionError("sut.format_to_regex is not callable")

    # Prepare test suite
    suite = unittest.TestSuite()
    suite.addTest(MetadataFromTitlePPTestCase(sut))

    # Prepare test runner
    runner = unittest.TextTest

# Generated at 2022-06-24 14:20:03.663277
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import unittest

    class MetadataFromTitlePPTest(unittest.TestCase):
        def test_format_to_regex(self):
            self.assertEqual(MetadataFromTitlePP.format_to_regex(
                r'%(title)s - %(artist)s'),
                r'(?P<title>.+)\ \-\ (?P<artist>.+)')

        def test_format_to_regex_non_group(self):
            self.assertEqual(MetadataFromTitlePP.format_to_regex(
                r'%(title)s - %(artist)s - here'),
                r'(?P<title>.+)\ \-\ (?P<artist>.+)\ \-\ here')


# Generated at 2022-06-24 14:20:07.917821
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    m = MetadataFromTitlePP(None, '%(artis)s - %(title)s')
    regex = m.format_to_regex('%(artis)s - %(title)s')
    assert regex == r'(?P<artis>.+)\ \-\ (?P<title>.+)'


# Generated at 2022-06-24 14:20:15.348459
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from ydl.downloader import YoutubeDL
    from ydl.extractor.common import InfoExtractor
    from ydl.extractor import YoutubeIE
    from ydl.utils import encode_data_uri
    ydl = YoutubeDL()
    ydl.add_info_extractor(YoutubeIE())
    ydl.add_post_processor(MetadataFromTitlePP(ydl, '%(artist)s - %(title)s'))

    def test(url, info):
        ies = ydl.extract_info(url, download=False)
        assert ies != []
        assert ies[0]['__type'] == 'Info'
        assert ies[0]['__info']
        assert ies[0]['__info']['formats']

# Generated at 2022-06-24 14:20:26.346764
# Unit test for method run of class MetadataFromTitlePP
def test_MetadataFromTitlePP_run():
    from .common import FileDownloader
    from .extractor.generic import YoutubeIE


# Generated at 2022-06-24 14:20:36.377318
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    assert (MetadataFromTitlePP(None, '%(title)s - %(artist)s')
            ._titleregex == '(?P<title>.+) - (?P<artist>.+)')
    assert (MetadataFromTitlePP(None, '%(title)s')
            ._titleregex == '(?P<title>.+)')
    assert (MetadataFromTitlePP(None, '%(artist)s - %(title)s')
            ._titleregex == '(?P<artist>.+) - (?P<title>.+)')
    assert (MetadataFromTitlePP(None, '%(artist)s - %(title)s - foo')
            ._titleregex == '(?P<artist>.+) - (?P<title>.+) - foo')
    # if the title format contains no format specifier,
    # the title

# Generated at 2022-06-24 14:20:41.472041
# Unit test for method format_to_regex of class MetadataFromTitlePP
def test_MetadataFromTitlePP_format_to_regex():
    mftpp = MetadataFromTitlePP(None, None)
    assert mftpp.format_to_regex('%(title)s - %(artist)s') == '(?P<title>.+)\ \-\ (?P<artist>.+)'
    assert mftpp.format_to_regex('%(title)s') == '(?P<title>.+)'
    assert mftpp.format_to_regex('') == ''



# Generated at 2022-06-24 14:20:47.086628
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    # pylint: disable=protected-access
    from .common import FileDownloader
    from .euronews import EuronewsIE

    downloader = FileDownloader({})
    downloader._ies = [EuronewsIE()]
    processor = MetadataFromTitlePP(downloader, '%(title)s - %(artist)s')
    assert processor._titleregex == '(?P<title>.+)\ \-\ (?P<artist>.+)'

    processor = MetadataFromTitlePP(
        downloader, '%(upload_date)s - %(title)s - %(artist)s')
    assert processor._titleregex == '(?P<upload_date>.+)\ \-\ ' + \
                                    '(?P<title>.+)\ \-\ ' + \
                                    '(?P<artist>.+)'

# Generated at 2022-06-24 14:20:54.134897
# Unit test for constructor of class MetadataFromTitlePP
def test_MetadataFromTitlePP():
    import youtube_dl
    ydl = youtube_dl.YoutubeDL({})
    mt = MetadataFromTitlePP(ydl, '%(title)s')
    assert mt._titleformat == '%(title)s'
    assert mt._titleregex == r'(?P<title>.+)'
    mt = MetadataFromTitlePP(ydl, '%(title)s - %(artist)s')
    assert mt._titleformat == '%(title)s - %(artist)s'
    assert mt._titleregex == r'(?P<title>.+)\ \-\ (?P<artist>.+)'
