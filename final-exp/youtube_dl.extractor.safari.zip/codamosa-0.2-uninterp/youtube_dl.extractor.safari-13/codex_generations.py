

# Generated at 2022-06-18 14:35:14.420493
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-18 14:35:18.126132
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    safari_course_ie = SafariCourseIE(url)
    assert safari_course_ie.suitable(url)

# Generated at 2022-06-18 14:35:18.711218
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-18 14:35:21.274231
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    SafariCourseIE(url)

# Generated at 2022-06-18 14:35:31.133284
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test for SafariCourseIE constructor
    # Test for SafariCourseIE.suitable
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert SafariCourseIE.suitable('http://techbus.safaribooksonline.com/9780134426365')
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314')

# Generated at 2022-06-18 14:35:40.286009
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:35:51.736450
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test that SafariCourseIE is not suitable for SafariIE and SafariApiIE
    assert not SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert not SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html')

    # Test that SafariCourseIE is suitable for SafariCourseIE
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')

# Generated at 2022-06-18 14:35:53.354260
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test that SafariBaseIE is an instance of InfoExtractor
    assert isinstance(SafariBaseIE(), InfoExtractor)

# Generated at 2022-06-18 14:35:59.780759
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari = SafariBaseIE()
    assert safari.IE_NAME == 'safari'
    assert safari.IE_DESC == 'safaribooksonline.com online video'
    assert safari._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''

# Generated at 2022-06-18 14:36:04.092768
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.LOGGED_IN == False
    assert ie._NETRC_MACHINE == 'safari'
    assert ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'

# Generated at 2022-06-18 14:36:38.786743
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test constructor of class SafariBaseIE
    # Test case 1:
    #   - username and password are None
    #   - LOGGED_IN is False
    #   - LOGIN_URL is 'https://learning.oreilly.com/accounts/login/'
    #   - NETRC_MACHINE is 'safari'
    #   - API_BASE is 'https://learning.oreilly.com/api/v1'
    #   - API_FORMAT is 'json'
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie.LOGGED_IN is False
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'

# Generated at 2022-06-18 14:36:40.444788
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.LOGGED_IN == False

# Generated at 2022-06-18 14:36:53.333329
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test for SafariIE.__init__
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False
    assert safari_ie._PARTNER_ID == '1926081'
    assert safari_ie._UICONF_ID == '29375172'
    assert safari_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_ie._API_FORMAT == 'json'

# Generated at 2022-06-18 14:36:55.441818
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:37:04.133043
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test constructor of class SafariApiIE
    ie = SafariApiIE()
    assert ie.IE_NAME == 'safari:api'
    assert ie.IE_DESC == 'safaribooksonline.com online video'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Generated at 2022-06-18 14:37:04.807013
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-18 14:37:05.415397
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-18 14:37:06.400351
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()

# Generated at 2022-06-18 14:37:07.039042
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()

# Generated at 2022-06-18 14:37:16.629726
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """
    Test the constructor of class SafariCourseIE.
    """
    safari_course_ie = SafariCourseIE()
    assert safari_course_ie.IE_NAME == 'safari:course'
    assert safari_course_ie.IE_DESC == 'safaribooksonline.com online courses'
    assert safari_course_ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'

# Generated at 2022-06-18 14:38:15.385927
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .test_utils import FakeYDL
    ydl = FakeYDL()
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(SafariApiIE)
    ydl.add_info_extractor(SafariIE)
    ydl.add_info_extractor(SafariCourseIE)
    ydl.extract_info(
        'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html',
        download=False)
    assert ydl.extractors[0]._downloader.params.get('username') is None
    assert ydl.extractors[0]._downloader.params.get('password') is None

# Generated at 2022-06-18 14:38:16.327305
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('SafariApiIE')

# Generated at 2022-06-18 14:38:25.379418
# Unit test for constructor of class SafariBaseIE

# Generated at 2022-06-18 14:38:30.225475
# Unit test for constructor of class SafariBaseIE

# Generated at 2022-06-18 14:38:31.963909
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:38:38.413573
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_ie._NETRC_MACHINE == 'safari'
    assert safari_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_ie._API_FORMAT == 'json'
    assert safari_ie.LOGGED_IN == False


# Generated at 2022-06-18 14:38:50.179214
# Unit test for constructor of class SafariIE

# Generated at 2022-06-18 14:38:56.038735
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:39:02.841245
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test with wrong credentials
    safari_base_ie = SafariBaseIE()
    safari_base_ie.username = 'wrong_username'
    safari_base_ie.password = 'wrong_password'
    safari_base_ie._real_initialize()
    assert safari_base_ie.LOGGED_IN is False

    # Test with correct credentials
    safari_base_ie = SafariBaseIE()
    safari_base_ie._real_initialize()
    assert safari_base_ie.LOGGED_IN is True

# Generated at 2022-06-18 14:39:10.255513
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie.LOGGED_IN == False


# Generated at 2022-06-18 14:41:07.357921
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'
    assert ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert ie._NETRC_MACHINE == 'safari'
    assert ie._VALID_URL == ''
    assert ie._TESTS == []
    assert ie.IE_NAME == 'safari'
    assert ie.IE_DESC == 'safaribooksonline.com online video'
    assert ie.LOGGED_IN == False
    assert ie.SUCCESS == True
    assert ie.FAILURE == False
    assert ie.SUCCESS == True
    assert ie.FAILURE == False
    assert ie

# Generated at 2022-06-18 14:41:15.429426
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()
    assert safari_api_ie.IE_NAME == 'safari:api'
    assert safari_api_ie.IE_DESC == 'safaribooksonline.com online courses'
    assert safari_api_ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Generated at 2022-06-18 14:41:25.620162
# Unit test for constructor of class SafariApiIE

# Generated at 2022-06-18 14:41:33.080523
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    mobj = re.match(SafariApiIE._VALID_URL, url)
    course_id = mobj.group('course_id')
    part = mobj.group('part')
    video_id = '%s/%s' % (course_id, part)
    urlh = compat_urllib_request.urlopen(url)
    webpage = urlh.read().decode('utf-8')
    part = json.loads(webpage)
    assert part['web_url'] == 'https://www.safaribooksonline.com/library/view/python-cookbook-3rd/9781449396459/part00.html'

# Generated at 2022-06-18 14:41:43.786854
# Unit test for constructor of class SafariCourseIE

# Generated at 2022-06-18 14:41:52.666946
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    assert ie.IE_NAME == 'safari:course'
    assert ie.IE_DESC == 'safaribooksonline.com online courses'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'

# Generated at 2022-06-18 14:42:01.164636
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test SafariApiIE constructor
    safari_api_ie = SafariApiIE()
    assert safari_api_ie.IE_NAME == 'safari:api'
    assert safari_api_ie.IE_DESC == 'safaribooksonline.com online courses'
    assert safari_api_ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Generated at 2022-06-18 14:42:08.028722
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert SafariCourseIE.suitable('http://techbus.safaribooksonline.com/9780134426365')
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314')
    assert SafariCourseIE.suitable('https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838')
   

# Generated at 2022-06-18 14:42:17.336925
# Unit test for constructor of class SafariIE

# Generated at 2022-06-18 14:42:18.688581
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test that SafariIE can be instantiated
    SafariIE()