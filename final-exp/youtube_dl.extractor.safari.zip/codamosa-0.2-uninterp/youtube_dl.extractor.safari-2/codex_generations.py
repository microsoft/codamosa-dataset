

# Generated at 2022-06-18 14:35:19.629898
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari = SafariBaseIE()
    assert safari._NETRC_MACHINE == 'safari'
    assert safari._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari._API_FORMAT == 'json'
    assert not safari.LOGGED_IN

# Generated at 2022-06-18 14:35:22.376174
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test that SafariBaseIE is a subclass of InfoExtractor
    assert issubclass(SafariBaseIE, InfoExtractor)

# Generated at 2022-06-18 14:35:23.038447
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()

# Generated at 2022-06-18 14:35:27.645809
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test with no credentials
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie.LOGGED_IN == False

    # Test with credentials
    safari_base_ie = SafariBaseIE(username='test', password='test')
    assert safari_base_ie.LOGGED_IN == True

# Generated at 2022-06-18 14:35:30.250667
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test for SafariApiIE.__init__()
    # Test for SafariApiIE.suitable()
    # Test for SafariApiIE._real_extract()
    pass


# Generated at 2022-06-18 14:35:38.909035
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_ie._NETRC_MACHINE == 'safari'
    assert safari_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_ie._API_FORMAT == 'json'
    assert safari_ie.LOGGED_IN == False


# Generated at 2022-06-18 14:35:39.589360
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-18 14:35:40.212272
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-18 14:35:40.845822
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-18 14:35:52.286974
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()
    assert safari_api_ie.IE_NAME == 'safari:api'
    assert safari_api_ie.IE_DESC == 'safaribooksonline.com online courses'
    assert safari_api_ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Generated at 2022-06-18 14:36:07.546007
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert SafariBaseIE(SafariBaseIE.ie_key())._API_BASE == 'https://learning.oreilly.com/api/v1'

# Generated at 2022-06-18 14:36:08.476756
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()

# Generated at 2022-06-18 14:36:18.575619
# Unit test for constructor of class SafariBaseIE

# Generated at 2022-06-18 14:36:19.032335
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-18 14:36:23.248739
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    SafariCourseIE(url)

# Generated at 2022-06-18 14:36:25.802700
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()
    assert safari_api_ie.IE_NAME == 'safari:api'

# Generated at 2022-06-18 14:36:36.226228
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test constructor of class SafariApiIE
    # Test case:
    #   Input:
    #       url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    #   Expected output:
    #       SafariApiIE instance
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    safari_api_ie = SafariApiIE(SafariApiIE.ie_key())
    safari_api_ie.suitable(url)
    safari_api_ie.extract(url)
    assert isinstance(safari_api_ie, SafariApiIE)

# Generated at 2022-06-18 14:36:41.370265
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:36:54.221375
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test that SafariBaseIE.__init__() raises an error if no username and password are provided
    # in the environment variables SAFARI_USERNAME and SAFARI_PASSWORD
    from ..utils import get_testcases
    from ..compat import compat_os_environ
    from ..extractor import gen_extractors
    from ..downloader import gen_downloaders

    # Get the testcases
    testcases = get_testcases()

    # Get the extractors
    extractors = gen_extractors()

    # Get the downloaders
    downloaders = gen_downloaders()

    # Get the SafariBaseIE extractor
    safari_base_ie = extractors['safari']

    # Get the SafariBaseIE downloader
    safari_base_downloader = downloaders['safari']

    # Get the testcase for Safari

# Generated at 2022-06-18 14:36:55.161631
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('SafariApiIE')

# Generated at 2022-06-18 14:37:22.062082
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-18 14:37:32.897569
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test for SafariCourseIE
    # Test for SafariCourseIE.suitable
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert SafariCourseIE.suitable('http://techbus.safaribooksonline.com/9780134426365')
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314')

# Generated at 2022-06-18 14:37:33.582113
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()

# Generated at 2022-06-18 14:37:35.388384
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:37:44.222867
# Unit test for constructor of class SafariIE

# Generated at 2022-06-18 14:37:53.547455
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.IE_NAME == 'safari'
    assert safari_ie.IE_DESC == 'safaribooksonline.com online video'
    assert safari_ie._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''
    assert safari_ie._PART

# Generated at 2022-06-18 14:38:01.267222
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False
    assert safari_ie._NETRC_MACHINE == 'safari'
    assert safari_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_ie._API_FORMAT == 'json'
    assert safari_ie._PARTNER_ID == '1926081'
    assert safari_ie._UICONF_ID == '29375172'

# Generated at 2022-06-18 14:38:08.978675
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:38:20.623113
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test SafariCourseIE.__init__()
    ie = SafariCourseIE()
    assert ie.IE_NAME == 'safari:course'
    assert ie.IE_DESC == 'safaribooksonline.com online courses'
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+|
                                api/v1/book|
                                videos/[^/]+
                            )|
                            techbus\.safaribooksonline\.com
                        )
                        /(?P<id>[^/]+)
                    '''

# Generated at 2022-06-18 14:38:32.739513
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test that SafariCourseIE is not suitable for SafariIE and SafariApiIE
    assert not SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert not SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html')

    # Test that SafariCourseIE is suitable for SafariCourseIE
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')

# Generated at 2022-06-18 14:39:35.808172
# Unit test for constructor of class SafariBaseIE

# Generated at 2022-06-18 14:39:46.153212
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test that SafariBaseIE.__init__() raises an error if neither username
    # nor password is specified
    safari_base_ie = SafariBaseIE()
    safari_base_ie._downloader = None
    safari_base_ie._downloader_params = {}
    safari_base_ie._LOGIN_URL = 'https://learning.oreilly.com/accounts/login/'
    safari_base_ie._NETRC_MACHINE = 'safari'
    safari_base_ie._API_BASE = 'https://learning.oreilly.com/api/v1'
    safari_base_ie._API_FORMAT = 'json'
    safari_base_ie.LOGGED_IN = False
    safari_base_ie._real_initialize()

# Generated at 2022-06-18 14:39:55.787054
# Unit test for constructor of class SafariBaseIE

# Generated at 2022-06-18 14:40:01.309949
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test that SafariApiIE is a subclass of SafariBaseIE
    assert issubclass(SafariApiIE, SafariBaseIE)
    # Test that SafariApiIE is a subclass of InfoExtractor
    assert issubclass(SafariApiIE, InfoExtractor)
    # Test that SafariApiIE is an instance of SafariBaseIE
    assert isinstance(SafariApiIE(), SafariBaseIE)
    # Test that SafariApiIE is an instance of InfoExtractor
    assert isinstance(SafariApiIE(), InfoExtractor)
    # Test that SafariApiIE is an instance of SafariApiIE
    assert isinstance(SafariApiIE(), SafariApiIE)


# Generated at 2022-06-18 14:40:01.729149
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()

# Generated at 2022-06-18 14:40:02.702566
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('SafariApiIE', 'safaribooksonline.com online courses')

# Generated at 2022-06-18 14:40:03.513744
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.LOGGED_IN == False

# Generated at 2022-06-18 14:40:08.825119
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert SafariCourseIE.suitable('http://techbus.safaribooksonline.com/9780134426365')
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314')
    assert SafariCourseIE.suitable('https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838')
   

# Generated at 2022-06-18 14:40:12.937066
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:40:13.843947
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE._VALID_URL == SafariBaseIE._VALID_URL

# Generated at 2022-06-18 14:42:26.745119
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test that SafariBaseIE is a subclass of InfoExtractor
    assert issubclass(SafariBaseIE, InfoExtractor)

# Generated at 2022-06-18 14:42:31.722578
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test that SafariCourseIE is not suitable for SafariIE and SafariApiIE
    assert not SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert not SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html')

# Generated at 2022-06-18 14:42:40.197471
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.IE_NAME == 'safari'
    assert safari_ie.IE_DESC == 'safaribooksonline.com online video'
    assert safari_ie._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''
    assert safari_ie._PART

# Generated at 2022-06-18 14:42:45.527193
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    course_id = '9780133392838'
    course_title = 'Hadoop Fundamentals LiveLessons'

# Generated at 2022-06-18 14:42:52.854297
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.IE_NAME == 'safari'
    assert safari_ie.IE_DESC == 'safaribooksonline.com online video'
    assert safari_ie._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''
    assert safari_ie._PART

# Generated at 2022-06-18 14:42:53.307514
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-18 14:42:55.517848
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test for SafariIE constructor
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:42:57.254488
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test that SafariBaseIE can be constructed
    SafariBaseIE()

# Generated at 2022-06-18 14:43:05.376219
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert SafariApiIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert not SafariApiIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert not SafariApiIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert not SafariApiIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314/9780134217314-PYMC_13_00')

# Generated at 2022-06-18 14:43:06.108105
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE('safari:course')