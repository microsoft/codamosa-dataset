

# Generated at 2022-06-18 14:35:16.744373
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-18 14:35:24.212079
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:35:31.716217
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test that SafariCourseIE is not suitable for SafariIE and SafariApiIE
    assert not SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert not SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')

# Generated at 2022-06-18 14:35:44.613227
# Unit test for constructor of class SafariBaseIE

# Generated at 2022-06-18 14:35:54.930286
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.IE_NAME == 'safari'
    assert ie.IE_DESC == 'safaribooksonline.com online video'
    assert ie._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''

# Generated at 2022-06-18 14:35:55.750554
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie

# Generated at 2022-06-18 14:35:56.623208
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE('SafariCourseIE', 'safaribooksonline.com')

# Generated at 2022-06-18 14:35:57.055595
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()

# Generated at 2022-06-18 14:36:05.698163
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test for SafariCourseIE
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert SafariCourseIE.suitable('http://techbus.safaribooksonline.com/9780134426365')
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314')

# Generated at 2022-06-18 14:36:06.333541
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()

# Generated at 2022-06-18 14:36:34.815124
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test SafariIE constructor
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:36:42.710148
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()
    assert safari_api_ie.IE_NAME == 'safari:api'
    assert safari_api_ie.IE_DESC == 'safaribooksonline.com online video'
    assert safari_api_ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Generated at 2022-06-18 14:36:55.162184
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .test_utils import get_testcases
    from .common import InfoExtractor
    from .common import unescapeHTML

    testcases = get_testcases(SafariIE)

    for testcase in testcases:
        testcase['url'] = unescapeHTML(testcase['url'])
        testcase['expected_info'] = unescapeHTML(testcase['expected_info'])
        testcase['expected_info']['url'] = unescapeHTML(testcase['expected_info']['url'])
        testcase['expected_info']['id'] = unescapeHTML(testcase['expected_info']['id'])
        testcase['expected_info']['title'] = unescapeHTML(testcase['expected_info']['title'])

        # Test constructor

# Generated at 2022-06-18 14:37:02.245331
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test for SafariBaseIE constructor
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie.LOGGED_IN == False


# Generated at 2022-06-18 14:37:08.767915
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert SafariApiIE._VALID_URL == 'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'


# Generated at 2022-06-18 14:37:09.723565
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE('Safari')

# Generated at 2022-06-18 14:37:18.216767
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test with a valid url
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    safari_api_ie = SafariApiIE(url)
    assert safari_api_ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'
    assert safari_api_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_api_ie._API_FORMAT == 'json'
    assert saf

# Generated at 2022-06-18 14:37:26.026458
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False
    assert safari_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_ie._API_FORMAT == 'json'
    assert safari_ie._NETRC_MACHINE == 'safari'
    assert safari_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'

# Generated at 2022-06-18 14:37:36.095766
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    safari_course_ie = SafariCourseIE(SafariCourseIE.suitable(url))
    assert safari_course_ie.IE_NAME == 'safari:course'
    assert safari_course_ie.IE_DESC == 'safaribooksonline.com online courses'

# Generated at 2022-06-18 14:37:42.387507
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:38:22.294900
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert ie.IE_NAME == 'safari:api'
    assert ie.IE_DESC == 'safaribooksonline.com online video'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Generated at 2022-06-18 14:38:33.661712
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """
    Test for constructor of class SafariCourseIE
    """
    safari_course_ie = SafariCourseIE()
    assert safari_course_ie.IE_NAME == 'safari:course'
    assert safari_course_ie.IE_DESC == 'safaribooksonline.com online courses'
    assert safari_course_ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'

# Generated at 2022-06-18 14:38:40.309222
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie.LOGGED_IN == False


# Generated at 2022-06-18 14:38:42.933358
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    SafariApiIE(SafariApiIE.suitable(url), url)

# Generated at 2022-06-18 14:38:53.323972
# Unit test for constructor of class SafariBaseIE

# Generated at 2022-06-18 14:38:58.404687
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:39:04.035805
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie.IE_NAME == 'safari'
    assert safari_base_ie.IE_DESC == 'safaribooksonline.com online video'
    assert safari_base_ie._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''

# Generated at 2022-06-18 14:39:14.767477
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.IE_NAME == 'safari'
    assert ie.IE_DESC == 'safaribooksonline.com online video'
    assert ie._VALID_URL == r'''(?x)
                                https?://
                                    (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                                    (?:
                                        library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                        videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                                    )
                                '''

# Generated at 2022-06-18 14:39:15.492777
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()

# Generated at 2022-06-18 14:39:16.062621
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()

# Generated at 2022-06-18 14:40:21.100396
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:40:31.567351
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test with valid url
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    safari_ie = SafariIE(url)
    assert safari_ie.url == url
    assert safari_ie.video_id == '0_qbqx90ic'
    assert safari_ie.reference_id == '0_qbqx90ic'
    assert safari_ie.partner_id == '1926081'
    assert safari_ie.ui_id == '29375172'
    assert safari_ie.course_id == '9780133392838'
    assert safari_ie.part == 'part00'
    assert safari_ie.LOGGED

# Generated at 2022-06-18 14:40:33.464147
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert SafariApiIE._VALID_URL == 'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Generated at 2022-06-18 14:40:37.781077
# Unit test for constructor of class SafariBaseIE

# Generated at 2022-06-18 14:40:42.190242
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test with no login info
    safari_base_ie = SafariBaseIE()
    safari_base_ie._login()
    assert safari_base_ie.LOGGED_IN == False

    # Test with login info
    safari_base_ie = SafariBaseIE()
    safari_base_ie._login()
    assert safari_base_ie.LOGGED_IN == True

# Generated at 2022-06-18 14:40:49.361652
# Unit test for constructor of class SafariBaseIE

# Generated at 2022-06-18 14:40:51.654018
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test that SafariBaseIE is a subclass of InfoExtractor
    assert issubclass(SafariBaseIE, InfoExtractor)


# Generated at 2022-06-18 14:40:54.457513
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    SafariCourseIE(url)

# Generated at 2022-06-18 14:41:00.067031
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test with valid credentials
    safari_base_ie = SafariBaseIE(None)
    safari_base_ie._login_info = lambda: ('valid_username', 'valid_password')
    safari_base_ie._real_initialize()
    assert safari_base_ie.LOGGED_IN

    # Test with invalid credentials
    safari_base_ie = SafariBaseIE(None)
    safari_base_ie._login_info = lambda: ('invalid_username', 'invalid_password')
    safari_base_ie._real_initialize()
    assert not safari_base_ie.LOGGED_IN

# Generated at 2022-06-18 14:41:03.556162
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test with no login credentials
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie.LOGGED_IN == False

    # Test with login credentials
    safari_base_ie = SafariBaseIE(username='username', password='password')
    assert safari_base_ie.LOGGED_IN == True

# Generated at 2022-06-18 14:43:37.653015
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie.LOGGED_IN == False


# Generated at 2022-06-18 14:43:45.007893
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test that SafariCourseIE is not suitable for SafariIE and SafariApiIE
    assert not SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert not SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html')
    # Test that SafariCourseIE is suitable for SafariCourseIE
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')

# Generated at 2022-06-18 14:43:47.792623
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE('SafariBaseIE', 'safaribooksonline.com')
    assert ie.IE_NAME == 'SafariBaseIE'
    assert ie.IE_DESC == 'safaribooksonline.com online video'

# Generated at 2022-06-18 14:43:48.467282
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-18 14:43:50.750624
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test for SafariIE
    SafariIE()


# Generated at 2022-06-18 14:43:59.528637
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test with a valid url
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    safari_api_ie = SafariApiIE(SafariApiIE.suitable(url))
    assert safari_api_ie.suitable(url)
    assert safari_api_ie.IE_NAME == 'safari:api'
    assert safari_api_ie.IE_DESC == 'safaribooksonline.com online video'

# Generated at 2022-06-18 14:44:07.325908
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    test_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    test_course_id = '9780133392838'
    test_course_title = 'Hadoop Fundamentals LiveLessons'

# Generated at 2022-06-18 14:44:12.116129
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:44:16.140221
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:44:25.579578
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test for SafariApiIE
    safari_api_ie = SafariApiIE()
    assert safari_api_ie.IE_NAME == 'safari:api'
    assert safari_api_ie.IE_DESC == 'safaribooksonline.com online courses'
    assert safari_api_ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'