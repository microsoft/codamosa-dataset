

# Generated at 2022-06-18 14:35:23.165519
# Unit test for constructor of class SafariBaseIE

# Generated at 2022-06-18 14:35:32.265226
# Unit test for constructor of class SafariCourseIE

# Generated at 2022-06-18 14:35:33.479132
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test SafariApiIE constructor
    SafariApiIE()

# Generated at 2022-06-18 14:35:46.196888
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test SafariIE constructor
    safari_ie = SafariIE()
    assert safari_ie.__class__.__name__ == 'SafariIE'
    assert safari_ie.IE_NAME == 'safari'
    assert safari_ie.IE_DESC == 'safaribooksonline.com online video'

# Generated at 2022-06-18 14:35:47.134230
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test SafariIE constructor
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:35:51.271745
# Unit test for constructor of class SafariIE
def test_SafariIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    SafariIE(url)

# Generated at 2022-06-18 14:35:58.592360
# Unit test for constructor of class SafariIE

# Generated at 2022-06-18 14:36:04.264418
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test with valid credentials
    safari_base_ie = SafariBaseIE()
    safari_base_ie._login_info = ('username', 'password')
    safari_base_ie._real_initialize()
    assert safari_base_ie.LOGGED_IN == True

    # Test with invalid credentials
    safari_base_ie = SafariBaseIE()
    safari_base_ie._login_info = ('username', 'wrong_password')
    safari_base_ie._real_initialize()
    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:36:06.097708
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('SafariApiIE')

# Generated at 2022-06-18 14:36:07.968301
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test that SafariBaseIE is an instance of InfoExtractor
    assert isinstance(SafariBaseIE(), InfoExtractor)

# Generated at 2022-06-18 14:36:40.092652
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test that SafariCourseIE is not suitable for SafariIE and SafariApiIE
    assert not SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert not SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html')
    # Test that SafariCourseIE is suitable for SafariCourseIE
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')

# Generated at 2022-06-18 14:36:53.006473
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert SafariCourseIE.suitable('http://techbus.safaribooksonline.com/9780134426365')
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314')
    assert SafariCourseIE.suitable('https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838')
   

# Generated at 2022-06-18 14:36:54.741245
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test if SafariCourseIE can be constructed
    SafariCourseIE('SafariCourseIE')

# Generated at 2022-06-18 14:37:00.640064
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_ie._NETRC_MACHINE == 'safari'
    assert safari_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_ie._API_FORMAT == 'json'
    assert safari_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:37:05.135173
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    SafariCourseIE(url)

# Generated at 2022-06-18 14:37:05.799992
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-18 14:37:08.241592
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:37:10.979424
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test with a valid url
    SafariIE('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    # Test with an invalid url
    SafariIE('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')

# Generated at 2022-06-18 14:37:18.931824
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert ie.IE_NAME == 'safari:api'
    assert ie.IE_DESC == 'safaribooksonline.com online courses'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Generated at 2022-06-18 14:37:19.756945
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()

# Generated at 2022-06-18 14:38:08.723694
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test that SafariCourseIE can be instantiated
    SafariCourseIE()

# Generated at 2022-06-18 14:38:20.348290
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.IE_NAME == 'safari'
    assert safari_ie.IE_DESC == 'safaribooksonline.com online video'
    assert safari_ie._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''
    assert safari_ie._PART

# Generated at 2022-06-18 14:38:20.959113
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()

# Generated at 2022-06-18 14:38:33.385555
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari = SafariBaseIE()
    assert safari.IE_NAME == 'safari'
    assert safari.IE_DESC == 'safaribooksonline.com online video'
    assert safari._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''

# Generated at 2022-06-18 14:38:35.370441
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:38:38.932757
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test SafariBaseIE constructor
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'

# Generated at 2022-06-18 14:38:47.497065
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie.LOGGED_IN == False


# Generated at 2022-06-18 14:38:49.624630
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .test_safari import test_SafariCourseIE
    test_SafariCourseIE(SafariCourseIE)

# Generated at 2022-06-18 14:38:50.235202
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-18 14:38:58.181435
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False
    assert safari_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_ie._API_FORMAT == 'json'
    assert safari_ie._NETRC_MACHINE == 'safari'
    assert safari_ie._PARTNER_ID == '1926081'
    assert safari_ie._UICONF_ID == '29375172'

# Generated at 2022-06-18 14:40:48.099107
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.IE_NAME == 'safari'
    assert safari_ie.IE_DESC == 'safaribooksonline.com online video'
    assert safari_ie._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''
    assert safari_ie._PART

# Generated at 2022-06-18 14:40:48.958092
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()

# Generated at 2022-06-18 14:40:51.275631
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test for SafariBaseIE._login()
    safari_base_ie = SafariBaseIE()
    safari_base_ie._login()

# Generated at 2022-06-18 14:40:55.372450
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test constructor of class SafariBaseIE
    # Test case 1:
    #   Test if the constructor can be called with no arguments
    # Expected result:
    #   The constructor should be called successfully
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie is not None


# Generated at 2022-06-18 14:41:01.918462
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()
    assert safari_api_ie.IE_NAME == 'safari:api'
    assert safari_api_ie.IE_DESC == 'safaribooksonline.com online courses'
    assert safari_api_ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Generated at 2022-06-18 14:41:02.318097
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-18 14:41:07.522385
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    course_id = '9780133392838'
    course_title = 'Hadoop Fundamentals LiveLessons'

# Generated at 2022-06-18 14:41:15.476470
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_ie = SafariCourseIE()
    assert safari_course_ie.IE_NAME == 'safari:course'
    assert safari_course_ie.IE_DESC == 'safaribooksonline.com online courses'
    assert safari_course_ie._VALID_URL == r'''(?x)
                    https?://
                        (?:
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+|
                                api/v1/book|
                                videos/[^/]+
                            )|
                            techbus\.safaribooksonline\.com
                        )
                        /(?P<id>[^/]+)
                    '''
    assert saf

# Generated at 2022-06-18 14:41:25.697157
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert SafariIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert SafariIE.suitable('https://www.safaribooksonline.com/library/view/create-a-nodejs/100000006A0210/part00.html')
    assert SafariIE.suitable('https://www.safaribooksonline.com/library/view/learning-path-red/9780134664057/RHCE_Introduction.html')
    assert SafariIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314/9780134217314-PYMC_13_00')
    assert SafariIE.suitable

# Generated at 2022-06-18 14:41:31.633166
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test with valid credentials
    safari_base_ie = SafariBaseIE()
    safari_base_ie._login_info = ('test@test.com', 'test')
    safari_base_ie._real_initialize()
    assert safari_base_ie.LOGGED_IN

    # Test with invalid credentials
    safari_base_ie = SafariBaseIE()
    safari_base_ie._login_info = ('test@test.com', 'invalid')
    safari_base_ie._real_initialize()
    assert not safari_base_ie.LOGGED_IN