

# Generated at 2022-06-18 14:35:14.142428
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-18 14:35:25.047856
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test for SafariIE
    assert SafariIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert SafariIE.suitable('https://www.safaribooksonline.com/library/view/create-a-nodejs/100000006A0210/part00.html')
    assert SafariIE.suitable('https://www.safaribooksonline.com/library/view/learning-path-red/9780134664057/RHCE_Introduction.html')
    assert SafariIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314/9780134217314-PYMC_13_00')


# Generated at 2022-06-18 14:35:33.398021
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.IE_NAME == 'safari'
    assert ie.IE_DESC == 'safaribooksonline.com online video'
    assert ie._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''

# Generated at 2022-06-18 14:35:46.106952
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test for SafariCourseIE
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert SafariCourseIE.suitable('http://techbus.safaribooksonline.com/9780134426365')
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314')

# Generated at 2022-06-18 14:35:56.108531
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test for SafariCourseIE
    # Test for SafariCourseIE.suitable
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert SafariCourseIE.suitable('http://techbus.safaribooksonline.com/9780134426365')
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314')

# Generated at 2022-06-18 14:35:56.575727
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-18 14:35:57.028604
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-18 14:35:58.784803
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test with no login
    SafariBaseIE()

    # Test with login
    SafariBaseIE(username='test', password='test')

# Generated at 2022-06-18 14:36:08.068228
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.IE_NAME == 'safari'
    assert ie.IE_DESC == 'safaribooksonline.com online video'
    assert ie._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''

# Generated at 2022-06-18 14:36:12.477300
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test for SafariIE
    # Test for SafariIE.__init__
    # Test for SafariIE._login
    # Test for SafariIE._real_extract
    # Test for SafariIE._real_initialize
    # Test for SafariIE.suitable
    # Test for SafariIE.url_result
    pass

# Generated at 2022-06-18 14:36:35.776613
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test SafariIE constructor
    ie = SafariIE()
    # Test SafariIE._real_initialize()
    ie._real_initialize()
    # Test SafariIE._login()
    ie._login()
    # Test SafariIE._real_extract()
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    ie._real_extract(url)
    # Test SafariIE.suitable()
    assert SafariIE.suitable(url)
    # Test SafariIE.ie_key()
    assert SafariIE.ie_key() == 'Safari'


# Generated at 2022-06-18 14:36:43.995327
# Unit test for constructor of class SafariIE

# Generated at 2022-06-18 14:36:45.708713
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.LOGGED_IN == False

# Generated at 2022-06-18 14:36:55.069985
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .test_utils import FakeYDL
    ydl = FakeYDL()
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(SafariApiIE)
    ydl.add_info_extractor(SafariIE)
    ydl.add_info_extractor(SafariCourseIE)
    ydl.extract_info(
        'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html',
        download=False)

# Generated at 2022-06-18 14:37:03.910023
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()
    assert safari_api_ie.IE_NAME == 'safari:api'
    assert safari_api_ie.IE_DESC == 'safaribooksonline.com online courses'
    assert safari_api_ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Generated at 2022-06-18 14:37:04.645357
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-18 14:37:15.159093
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test that SafariCourseIE is not suitable for SafariIE and SafariApiIE URLs
    assert not SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert not SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html')
    # Test that SafariCourseIE is suitable for other URLs
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')

# Generated at 2022-06-18 14:37:27.859499
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert SafariApiIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert SafariApiIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html')
    assert SafariApiIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter-content/part00.html')
    assert SafariApiIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html?override_format=json')

# Generated at 2022-06-18 14:37:35.088082
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:37:43.959197
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.IE_NAME == 'safari'
    assert ie.IE_DESC == 'safaribooksonline.com online video'
    assert ie._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''

# Generated at 2022-06-18 14:38:18.972346
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie.LOGGED_IN == False


# Generated at 2022-06-18 14:38:20.254845
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:38:25.325119
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:38:30.187160
# Unit test for constructor of class SafariIE

# Generated at 2022-06-18 14:38:33.748075
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test that SafariApiIE is a subclass of SafariBaseIE
    assert issubclass(SafariApiIE, SafariBaseIE)
    # Test that SafariApiIE is a subclass of InfoExtractor
    assert issubclass(SafariApiIE, InfoExtractor)

# Generated at 2022-06-18 14:38:34.365364
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-18 14:38:36.407701
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:38:42.340638
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:38:45.115379
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:38:45.800760
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-18 14:39:45.309986
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:39:55.422407
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.IE_NAME == 'safari'
    assert safari_ie.IE_DESC == 'safaribooksonline.com online video'
    assert safari_ie._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''
    assert safari_ie._PART

# Generated at 2022-06-18 14:39:59.506995
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_ie = SafariCourseIE()
    assert safari_course_ie.IE_NAME == 'safari:course'
    assert safari_course_ie.IE_DESC == 'safaribooksonline.com online courses'
    assert safari_course_ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'
    assert safari_course_ie._TESTS[0]['url'] == 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'

# Generated at 2022-06-18 14:40:04.582313
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test for SafariCourseIE.suitable()
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert SafariCourseIE.suitable('http://techbus.safaribooksonline.com/9780134426365')
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314')

# Generated at 2022-06-18 14:40:04.980634
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-18 14:40:05.387816
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-18 14:40:10.793233
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert SafariCourseIE.suitable('http://techbus.safaribooksonline.com/9780134426365')
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314')
    assert SafariCourseIE.suitable('https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838')
   

# Generated at 2022-06-18 14:40:19.208087
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test with a valid url
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    safari_api_ie = SafariApiIE(url)
    assert safari_api_ie.url == url
    assert safari_api_ie.course_id == '9781449396459'
    assert safari_api_ie.part == 'part00'
    assert safari_api_ie.reference_id == '9781449396459-part00'
    assert safari_api_ie.partner_id == '1926081'
    assert safari_api_ie.ui_id == '29375172'

    # Test with a valid url

# Generated at 2022-06-18 14:40:22.227581
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test for SafariBaseIE constructor
    # This test is not a real test, it just checks that SafariBaseIE
    # constructor does not raise any exception
    safari_base_ie = SafariBaseIE()

# Generated at 2022-06-18 14:40:22.728369
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()

# Generated at 2022-06-18 14:42:40.597084
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()
    assert safari_api_ie.IE_NAME == 'safari:api'
    assert safari_api_ie.IE_DESC == 'safaribooksonline.com online video'
    assert safari_api_ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Generated at 2022-06-18 14:42:46.107908
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()
    assert safari_api_ie.IE_NAME == 'safari:api'
    assert safari_api_ie.IE_DESC == 'safaribooksonline.com online courses'
    assert safari_api_ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Generated at 2022-06-18 14:42:51.294452
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:42:57.547460
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie.LOGGED_IN == False


# Generated at 2022-06-18 14:43:03.138580
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:43:11.227436
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test for SafariBaseIE constructor
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie.IE_NAME == 'safari'
    assert safari_base_ie.IE_DESC == 'safaribooksonline.com online video'

# Generated at 2022-06-18 14:43:17.334560
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert SafariApiIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert SafariApiIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert not SafariApiIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/')
    assert not SafariApiIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json&')

# Generated at 2022-06-18 14:43:18.131322
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-18 14:43:23.367235
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test SafariIE constructor
    ie = SafariIE()
    assert ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert ie._NETRC_MACHINE == 'safari'
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'
    assert ie.LOGGED_IN == False


# Generated at 2022-06-18 14:43:28.762626
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test that SafariBaseIE.__init__() raises an error if no username is provided
    # and no netrc file is found
    with open('/dev/null', 'w') as devnull:
        # Redirect stderr to /dev/null to avoid printing error messages
        # when no netrc file is found
        safari_base_ie = SafariBaseIE(devnull)
        safari_base_ie.to_screen = lambda *args, **kwargs: None
        safari_base_ie._login()