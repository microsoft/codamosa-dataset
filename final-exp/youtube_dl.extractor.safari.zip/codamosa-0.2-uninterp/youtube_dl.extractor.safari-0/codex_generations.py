

# Generated at 2022-06-18 14:35:14.946736
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test that SafariApiIE can be instantiated
    SafariApiIE()

# Generated at 2022-06-18 14:35:23.337263
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test with a valid username and password
    safari_base_ie = SafariBaseIE()
    safari_base_ie._login_info = ('username', 'password')
    safari_base_ie._real_initialize()
    assert safari_base_ie.LOGGED_IN is True

    # Test with an invalid username and password
    safari_base_ie = SafariBaseIE()
    safari_base_ie._login_info = ('username', 'password')
    safari_base_ie._download_json = lambda *args, **kwargs: {'logged_in': False, 'credentials': 'Invalid username or password'}
    safari_base_ie._real_initialize()
    assert safari_base_ie.LOGGED_IN is False

    # Test with no username and password
    saf

# Generated at 2022-06-18 14:35:25.568716
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test that SafariBaseIE.__init__() does not raise an exception
    # when called with valid parameters
    SafariBaseIE('username', 'password')

# Generated at 2022-06-18 14:35:26.216844
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-18 14:35:26.832723
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-18 14:35:27.894473
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:35:28.295611
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-18 14:35:40.196598
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.LOGGED_IN == False
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'
    assert ie._PARTNER_ID == '1926081'
    assert ie._UICONF_ID == '29375172'

# Generated at 2022-06-18 14:35:40.597351
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-18 14:35:45.248866
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test with no login info
    safari_base = SafariBaseIE()
    assert safari_base.LOGGED_IN == False

    # Test with login info
    safari_base = SafariBaseIE(username='test', password='test')
    assert safari_base.LOGGED_IN == True

# Generated at 2022-06-18 14:36:20.171282
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_ie = SafariCourseIE()
    assert safari_course_ie.IE_NAME == 'safari:course'
    assert safari_course_ie.IE_DESC == 'safaribooksonline.com online courses'
    assert safari_course_ie._VALID_URL == r'''(?x)
                    https?://
                        (?:
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+|
                                api/v1/book|
                                videos/[^/]+
                            )|
                            techbus\.safaribooksonline\.com
                        )
                        /(?P<id>[^/]+)
                    '''
    assert saf

# Generated at 2022-06-18 14:36:31.848879
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test for SafariIE
    assert SafariIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert SafariIE.suitable('https://www.safaribooksonline.com/library/view/create-a-nodejs/100000006A0210/part00.html')
    assert SafariIE.suitable('https://www.safaribooksonline.com/library/view/learning-path-red/9780134664057/RHCE_Introduction.html')
    assert SafariIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314/9780134217314-PYMC_13_00')


# Generated at 2022-06-18 14:36:38.024022
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test that SafariCourseIE is not suitable for SafariIE and SafariApiIE
    # URLs
    assert not SafariCourseIE.suitable(
        'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert not SafariCourseIE.suitable(
        'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html')

# Generated at 2022-06-18 14:36:44.616653
# Unit test for constructor of class SafariBaseIE

# Generated at 2022-06-18 14:36:56.994762
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    assert ie.IE_NAME == 'safari:course'
    assert ie.IE_DESC == 'safaribooksonline.com online courses'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'

# Generated at 2022-06-18 14:37:08.592675
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test with a valid url
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    safari_base_ie = SafariBaseIE(url)
    assert safari_base_ie.url == url
    assert safari_base_ie.video_id == '9780133392838-part00'
    assert safari_base_ie.ie_key() == 'Safari'

    # Test with an invalid url
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    safari_base_ie = SafariBaseIE(url)
    assert saf

# Generated at 2022-06-18 14:37:09.196070
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-18 14:37:09.778943
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-18 14:37:18.246273
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test with a valid url
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    safari_course_ie = SafariCourseIE(url)
    assert safari_course_ie.suitable(url)
    assert safari_course_ie.IE_NAME == 'safari:course'
    assert safari_course_ie.IE_DESC == 'safaribooksonline.com online courses'

# Generated at 2022-06-18 14:37:21.225591
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """
    Test for constructor of class SafariIE
    """
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:38:11.246518
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-18 14:38:22.587108
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test for SafariIE
    assert SafariIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert SafariIE.suitable('https://www.safaribooksonline.com/library/view/create-a-nodejs/100000006A0210/part00.html')
    assert SafariIE.suitable('https://www.safaribooksonline.com/library/view/learning-path-red/9780134664057/RHCE_Introduction.html')
    assert SafariIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314/9780134217314-PYMC_13_00')


# Generated at 2022-06-18 14:38:30.041905
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()
    assert safari.LOGGED_IN == False
    assert safari._NETRC_MACHINE == 'safari'
    assert safari._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari._API_FORMAT == 'json'
    assert safari._PARTNER_ID == '1926081'
    assert safari._UICONF_ID == '29375172'

# Generated at 2022-06-18 14:38:39.745956
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api = SafariApiIE()
    assert safari_api.IE_NAME == 'safari:api'
    assert safari_api.IE_DESC == 'safaribooksonline.com online video'
    assert safari_api._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Generated at 2022-06-18 14:38:41.207066
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:38:52.348392
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()
    assert safari_api_ie.IE_NAME == 'safari:api'
    assert safari_api_ie.IE_DESC == 'safaribooksonline.com online courses'
    assert safari_api_ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Generated at 2022-06-18 14:38:52.917299
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-18 14:38:53.451707
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-18 14:38:58.497629
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import unittest
    from .test_common import TestSafariBaseIE

    class TestSafariApiIE(TestSafariBaseIE):
        def test_constructor(self):
            self.assertEqual(SafariApiIE.__name__, 'SafariApiIE')
            self.assertEqual(SafariApiIE.IE_NAME, 'safari:api')
            self.assertEqual(SafariApiIE.IE_DESC, 'safaribooksonline.com online courses')

# Generated at 2022-06-18 14:38:59.586406
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE('SafariCourseIE', 'safaribooksonline.com')

# Generated at 2022-06-18 14:40:49.026664
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-18 14:40:49.609365
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-18 14:40:50.530131
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()

# Generated at 2022-06-18 14:40:52.715575
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test SafariCourseIE constructor
    # Test SafariCourseIE.suitable()
    # Test SafariCourseIE._real_extract()
    pass

# Generated at 2022-06-18 14:40:54.187346
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:40:59.757154
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test SafariBaseIE.__init__()
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:41:10.912152
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test SafariCourseIE constructor
    # This test checks if SafariCourseIE constructor works correctly
    # by checking if the class variables are correctly initialized
    # and if the class variables are correctly assigned to the object
    # created by the constructor.
    safari_course_ie = SafariCourseIE()
    assert safari_course_ie.IE_NAME == 'safari:course'
    assert safari_course_ie.IE_DESC == 'safaribooksonline.com online courses'

# Generated at 2022-06-18 14:41:19.533232
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert ie.IE_NAME == 'safari'
    assert ie.IE_DESC == 'safaribooksonline.com online video'

# Generated at 2022-06-18 14:41:28.839821
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie.IE_NAME == 'safari'
    assert safari_base_ie.IE_DESC == 'safaribooksonline.com online video'
    assert safari_base_ie._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''

# Generated at 2022-06-18 14:41:39.435437
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test constructor of class SafariApiIE
    # Test case 1:
    #   - url: https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html
    #   - expected: SafariApiIE
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    assert SafariApiIE.suitable(url)
    assert isinstance(SafariApiIE(SafariApiIE.ie_key()), SafariApiIE)
    # Test case 2:
    #   - url: https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part

# Generated at 2022-06-18 14:44:11.248496
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test constructor of SafariApiIE
    # Test case:
    #   SafariApiIE(SafariBaseIE)
    # Expected result:
    #   SafariApiIE object
    assert isinstance(SafariApiIE(SafariBaseIE), SafariApiIE)

# Generated at 2022-06-18 14:44:15.694622
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test constructor of class SafariBaseIE
    # Test case 1: Login with valid credentials
    # Expected result: LOGGED_IN is True
    safari_base_ie = SafariBaseIE()
    safari_base_ie._login()
    assert safari_base_ie.LOGGED_IN == True
    # Test case 2: Login with invalid credentials
    # Expected result: LOGGED_IN is False
    safari_base_ie = SafariBaseIE()
    safari_base_ie._login()
    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:44:17.052533
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:44:26.887590
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    assert ie.IE_NAME == 'safari:course'
    assert ie.IE_DESC == 'safaribooksonline.com online courses'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'

# Generated at 2022-06-18 14:44:31.121237
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False
    assert safari_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_ie._API_FORMAT == 'json'
    assert safari_ie._PARTNER_ID == '1926081'
    assert safari_ie._UICONF_ID == '29375172'


# Generated at 2022-06-18 14:44:32.659167
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()
    assert safari_api_ie.IE_NAME == 'safari:api'

# Generated at 2022-06-18 14:44:42.593304
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test SafariIE constructor
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False
    assert safari_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_ie._API_FORMAT == 'json'
    assert safari_ie._PARTNER_ID == '1926081'
    assert safari_ie._UICONF_ID == '29375172'

# Generated at 2022-06-18 14:44:45.277387
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test SafariBaseIE.__init__()
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:44:45.773263
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-18 14:44:46.969786
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False
