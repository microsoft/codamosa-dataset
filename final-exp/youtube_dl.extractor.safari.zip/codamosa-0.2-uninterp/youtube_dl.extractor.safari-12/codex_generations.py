

# Generated at 2022-06-18 14:35:26.494082
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test that SafariBaseIE.__init__() raises an error if no username and password are provided
    # in the configuration file
    from ..utils import ExtractorError
    from ..compat import compat_urllib_request
    from ..compat import compat_urllib_error
    from ..compat import compat_urllib_parse
    from ..compat import compat_http_client
    from ..compat import compat_cookiejar
    from ..compat import compat_str
    from ..compat import compat_struct_pack
    from ..compat import compat_struct_unpack
    from ..compat import compat_chr
    from ..compat import compat_ord
    from ..compat import compat_urlparse
    from ..compat import compat_parse_qs
    from ..compat import compat_urllib_parse_urlparse

# Generated at 2022-06-18 14:35:27.042352
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test constructor
    SafariApiIE()

# Generated at 2022-06-18 14:35:32.669400
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:35:45.342830
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()
    assert safari.IE_NAME == 'safari'
    assert safari.IE_DESC == 'safaribooksonline.com online video'
    assert safari._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''

# Generated at 2022-06-18 14:35:46.992223
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .test_safari import test_SafariApiIE
    test_SafariApiIE()

# Generated at 2022-06-18 14:35:48.994413
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.LOGGED_IN == False

# Generated at 2022-06-18 14:35:50.162463
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()

# Generated at 2022-06-18 14:35:52.552903
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test that SafariBaseIE raises an error when trying to login
    # with invalid credentials
    safari_base_ie = SafariBaseIE()
    safari_base_ie._login_info = ('invalid_username', 'invalid_password')
    safari_base_ie._real_initialize()
    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:35:56.507170
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test with a valid url
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    SafariApiIE(SafariApiIE.suitable(url), url)

    # Test with an invalid url
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html?test=test'
    SafariApiIE(SafariApiIE.suitable(url), url)

# Generated at 2022-06-18 14:35:56.968441
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-18 14:36:10.715273
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-18 14:36:11.582780
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-18 14:36:20.517129
# Unit test for constructor of class SafariBaseIE

# Generated at 2022-06-18 14:36:32.227802
# Unit test for constructor of class SafariBaseIE

# Generated at 2022-06-18 14:36:34.379585
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test that SafariBaseIE is a subclass of InfoExtractor
    assert issubclass(SafariBaseIE, InfoExtractor)

# Generated at 2022-06-18 14:36:40.299860
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()
    assert safari_api_ie.IE_NAME == 'safari:api'
    assert safari_api_ie.IE_DESC == 'safaribooksonline.com online courses'
    assert safari_api_ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Generated at 2022-06-18 14:36:53.145513
# Unit test for constructor of class SafariCourseIE

# Generated at 2022-06-18 14:36:58.593063
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    assert ie.IE_NAME == 'safari:course'
    assert ie.IE_DESC == 'safaribooksonline.com online courses'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'

# Generated at 2022-06-18 14:37:05.993602
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.IE_NAME == 'safari'
    assert ie.IE_DESC == 'safaribooksonline.com online video'
    assert ie._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''

# Generated at 2022-06-18 14:37:07.428849
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test for SafariCourseIE.__init__()
    # Test for SafariCourseIE.suitable()
    # Test for SafariCourseIE._real_extract()
    pass

# Generated at 2022-06-18 14:37:41.985534
# Unit test for constructor of class SafariBaseIE

# Generated at 2022-06-18 14:37:50.255831
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test constructor of class SafariApiIE
    ie = SafariApiIE()
    assert ie.IE_NAME == 'safari:api'
    assert ie.IE_DESC == 'safaribooksonline.com online courses'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Generated at 2022-06-18 14:37:52.202084
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test that SafariBaseIE constructor does not raise an exception
    SafariBaseIE()

# Generated at 2022-06-18 14:38:00.421437
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert ie.IE_NAME == 'safari:api'
    assert ie.IE_DESC == 'safaribooksonline.com online video'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Generated at 2022-06-18 14:38:02.234258
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:38:12.958516
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.IE_NAME == 'safari'
    assert safari_ie.IE_DESC == 'safaribooksonline.com online video'
    assert safari_ie._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''
    assert safari_ie._PART

# Generated at 2022-06-18 14:38:13.934353
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()

# Generated at 2022-06-18 14:38:16.326850
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .test_safari import test_SafariApiIE
    test_SafariApiIE(SafariApiIE)

# Generated at 2022-06-18 14:38:19.026208
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .test_safari import test_SafariApiIE
    test_SafariApiIE()

# Generated at 2022-06-18 14:38:26.360133
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert SafariCourseIE.suitable('http://techbus.safaribooksonline.com/9780134426365')
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314')
    assert SafariCourseIE.suitable('https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838')
   

# Generated at 2022-06-18 14:39:25.104560
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert SafariApiIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert SafariApiIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html')
    assert SafariApiIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter-content/part00.html')
    assert not SafariApiIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter-content/part00.html?override_format=json')

# Generated at 2022-06-18 14:39:26.281567
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-18 14:39:27.106751
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-18 14:39:36.409641
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test for SafariIE.__init__
    # Test for SafariIE.suitable
    assert SafariIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert SafariIE.suitable('https://www.safaribooksonline.com/library/view/create-a-nodejs/100000006A0210/part00.html')
    assert SafariIE.suitable('https://www.safaribooksonline.com/library/view/learning-path-red/9780134664057/RHCE_Introduction.html')

# Generated at 2022-06-18 14:39:46.796121
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test for SafariIE
    safari_ie = SafariIE()
    assert safari_ie.IE_NAME == 'safari'
    assert safari_ie.IE_DESC == 'safaribooksonline.com online video'
    assert safari_ie._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''
   

# Generated at 2022-06-18 14:39:49.596285
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test that SafariIE is constructed correctly
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:39:58.007212
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert ie.IE_NAME == 'safari:api'
    assert ie.IE_DESC == 'safaribooksonline.com online video'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Generated at 2022-06-18 14:40:01.779277
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie.LOGGED_IN == False


# Generated at 2022-06-18 14:40:05.477586
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test SafariBaseIE.__init__()
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie.LOGGED_IN == False
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'

# Generated at 2022-06-18 14:40:06.318872
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert SafariIE()._VALID_URL == SafariBaseIE._VALID_URL

# Generated at 2022-06-18 14:42:21.164926
# Unit test for constructor of class SafariApiIE

# Generated at 2022-06-18 14:42:23.928439
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False
    assert safari_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_ie._API_FORMAT == 'json'

# Generated at 2022-06-18 14:42:31.565415
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie.IE_NAME == 'safari'
    assert safari_base_ie.IE_DESC == 'safaribooksonline.com online video'
    assert safari_base_ie._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''

# Generated at 2022-06-18 14:42:40.052413
# Unit test for constructor of class SafariIE

# Generated at 2022-06-18 14:42:41.435792
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .test_safari import test_SafariApiIE
    test_SafariApiIE()

# Generated at 2022-06-18 14:42:45.359677
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:42:50.710884
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test with a valid url
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    safari_api_ie = SafariApiIE(url)
    assert safari_api_ie.url == url
    assert safari_api_ie.course_id == '9781449396459'
    assert safari_api_ie.part == 'part00'
    assert safari_api_ie.reference_id == '9781449396459-part00'

    # Test with an invalid url
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00'
    safari_api_ie = SafariApiIE(url)
    assert saf

# Generated at 2022-06-18 14:42:52.357821
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test that SafariApiIE is a subclass of SafariBaseIE
    assert issubclass(SafariApiIE, SafariBaseIE)

# Generated at 2022-06-18 14:42:53.584316
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test that SafariBaseIE is not instantiable
    with pytest.raises(TypeError):
        SafariBaseIE()

# Generated at 2022-06-18 14:43:00.155555
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test that SafariCourseIE is not suitable for SafariIE and SafariApiIE
    assert not SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert not SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html')