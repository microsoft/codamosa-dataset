

# Generated at 2022-06-18 14:35:22.468830
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    ie = SafariApiIE()
    assert ie.suitable(url)
    assert ie.IE_NAME == 'safari:api'
    assert ie.IE_DESC == 'safaribooksonline.com online video'
    assert ie.LOGGED_IN == False

# Generated at 2022-06-18 14:35:23.646020
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE('Safari')

# Generated at 2022-06-18 14:35:25.804082
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test for SafariCourseIE
    # Test for SafariCourseIE.suitable()
    # Test for SafariCourseIE._real_extract()
    pass

# Generated at 2022-06-18 14:35:33.860427
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert SafariCourseIE.suitable('http://techbus.safaribooksonline.com/9780134426365')
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314')
    assert SafariCourseIE.suitable('https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838')
   

# Generated at 2022-06-18 14:35:38.050864
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test SafariIE constructor
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:35:49.718700
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.IE_NAME == 'safari'
    assert ie.IE_DESC == 'safaribooksonline.com online video'
    assert ie._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''

# Generated at 2022-06-18 14:35:52.592709
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    SafariCourseIE(url)

# Generated at 2022-06-18 14:35:58.602645
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .test_common import make_mock_extractor
    from .test_common import make_mock_url_result
    from .test_common import make_mock_url_result_json
    from .test_common import make_mock_url_result_json_handle
    from .test_common import make_mock_url_result_webpage
    from .test_common import make_mock_url_result_webpage_handle
    from .test_common import make_mock_url_result_webpage_handle_json
    from .test_common import make_mock_url_result_webpage_handle_json_handle
    from .test_common import make_mock_url_result_webpage_handle_json_handle_no_download
    from .test_common import make_mock_url

# Generated at 2022-06-18 14:36:07.544108
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()
    assert safari_api_ie.IE_NAME == 'safari:api'
    assert safari_api_ie.IE_DESC == 'safaribooksonline.com online courses'
    assert safari_api_ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Generated at 2022-06-18 14:36:09.229201
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert SafariApiIE()._VALID_URL == SafariApiIE._VALID_URL

# Generated at 2022-06-18 14:36:29.392372
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test that SafariApiIE is not constructed when SafariIE is suitable
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    assert not SafariApiIE.suitable(url)
    assert SafariIE.suitable(url)
    assert SafariApiIE.ie_key() not in globals()['_ies']

# Generated at 2022-06-18 14:36:30.028045
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()

# Generated at 2022-06-18 14:36:32.410322
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:36:35.731163
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    SafariApiIE(SafariApiIE.suitable(url), url)

# Generated at 2022-06-18 14:36:43.240625
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    ie = SafariApiIE()
    assert ie.suitable(url)
    assert ie.IE_NAME == 'safari:api'
    assert ie.IE_DESC == 'safaribooksonline.com online video'
    assert ie.VALID_URL == 'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Generated at 2022-06-18 14:36:55.663062
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test with a valid url
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    safari_api_ie = SafariApiIE(url)
    assert safari_api_ie.url == url
    assert safari_api_ie.course_id == '9781449396459'
    assert safari_api_ie.part == 'part00.html'

    # Test with an invalid url
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html?test=test'
    safari_api_ie = SafariApiIE(url)
    assert safari_api_ie.url == url
    assert safari_api

# Generated at 2022-06-18 14:37:01.084122
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_ie._API_FORMAT == 'json'
    assert safari_ie.LOGGED_IN == False
    assert safari_ie._PARTNER_ID == '1926081'
    assert safari_ie._UICONF_ID == '29375172'

# Generated at 2022-06-18 14:37:10.081750
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie.LOGGED_IN == False


# Generated at 2022-06-18 14:37:18.447206
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert not SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert not SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html')
    assert not SafariCourseIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314/9780134217314-PYMC_13_00')

# Generated at 2022-06-18 14:37:29.880896
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_ie = SafariCourseIE()
    assert safari_course_ie.IE_NAME == 'safari:course'
    assert safari_course_ie.IE_DESC == 'safaribooksonline.com online courses'
    assert safari_course_ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'

# Generated at 2022-06-18 14:37:56.455363
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-18 14:38:04.746873
# Unit test for constructor of class SafariCourseIE

# Generated at 2022-06-18 14:38:15.520073
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test constructor of SafariApiIE
    assert SafariApiIE.__name__ == 'SafariApiIE'
    assert SafariApiIE.__doc__ == 'safaribooksonline.com online video'
    assert SafariApiIE._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Generated at 2022-06-18 14:38:24.879506
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert ie.IE_NAME == 'safari:api'
    assert ie.IE_DESC == 'safaribooksonline.com online courses'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Generated at 2022-06-18 14:38:35.890378
# Unit test for constructor of class SafariCourseIE

# Generated at 2022-06-18 14:38:44.081464
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test that SafariApiIE is a subclass of SafariBaseIE
    assert issubclass(SafariApiIE, SafariBaseIE)
    # Test that SafariApiIE is a subclass of InfoExtractor
    assert issubclass(SafariApiIE, InfoExtractor)
    # Test that SafariApiIE is a subclass of object
    assert issubclass(SafariApiIE, object)
    # Test that SafariApiIE is an instance of SafariBaseIE
    assert isinstance(SafariApiIE, SafariBaseIE)
    # Test that SafariApiIE is an instance of InfoExtractor
    assert isinstance(SafariApiIE, InfoExtractor)
    # Test that SafariApiIE is an instance of object
    assert isinstance(SafariApiIE, object)

# Generated at 2022-06-18 14:38:53.827195
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.IE_NAME == 'safari'
    assert ie.IE_DESC == 'safaribooksonline.com online video'
    assert ie._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''

# Generated at 2022-06-18 14:38:57.214037
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:39:06.294236
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test for SafariCourseIE
    # This test is for checking constructor of class SafariCourseIE
    # Input:
    #       None
    # Expected result:
    #       SafariCourseIE object
    #
    # Procedure:
    #       1. Create SafariCourseIE object
    #       2. Check if the object is created successfully
    #
    # Return value:
    #       None
    #
    # Note:
    #       None
    #
    ################################################################################

    # Create SafariCourseIE object
    safari_course_ie = SafariCourseIE()

    # Check if the object is created successfully
    assert safari_course_ie is not None

# Generated at 2022-06-18 14:39:16.225697
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.IE_NAME == 'safari'
    assert ie.IE_DESC == 'safaribooksonline.com online video'
    assert ie._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''

# Generated at 2022-06-18 14:40:13.204149
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:40:20.401585
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test SafariBaseIE constructor
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie.LOGGED_IN == False


# Generated at 2022-06-18 14:40:26.935909
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:40:29.327175
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari = SafariBaseIE()
    assert safari.LOGGED_IN == False

# Generated at 2022-06-18 14:40:37.278880
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.LOGGED_IN == False
    assert ie._NETRC_MACHINE == 'safari'
    assert ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'
    assert ie._PARTNER_ID == '1926081'
    assert ie._UICONF_ID == '29375172'

# Generated at 2022-06-18 14:40:38.695103
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-18 14:40:46.853710
# Unit test for constructor of class SafariIE

# Generated at 2022-06-18 14:40:47.355070
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-18 14:40:56.787213
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test for SafariIE
    safari_ie = SafariIE()
    assert safari_ie.IE_NAME == 'safari'
    assert safari_ie.IE_DESC == 'safaribooksonline.com online video'
    assert safari_ie._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''
   

# Generated at 2022-06-18 14:41:01.173528
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:43:28.529992
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:43:29.219227
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-18 14:43:37.652517
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()
    assert safari.IE_NAME == 'safari'
    assert safari.IE_DESC == 'safaribooksonline.com online video'
    assert safari._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''

# Generated at 2022-06-18 14:43:38.719194
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE('Safari', 'safaribooksonline.com online video')


# Generated at 2022-06-18 14:43:46.996871
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    assert ie.IE_NAME == 'safari:course'
    assert ie.IE_DESC == 'safaribooksonline.com online courses'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'

# Generated at 2022-06-18 14:43:57.378148
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_ie = SafariCourseIE()
    assert safari_course_ie.IE_NAME == 'safari:course'
    assert safari_course_ie.IE_DESC == 'safaribooksonline.com online courses'
    assert safari_course_ie._VALID_URL == r'''(?x)
                    https?://
                        (?:
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+|
                                api/v1/book|
                                videos/[^/]+
                            )|
                            techbus\.safaribooksonline\.com
                        )
                        /(?P<id>[^/]+)
                    '''

# Generated at 2022-06-18 14:43:59.349317
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test for SafariApiIE.__init__()
    # Test for SafariApiIE.suitable()
    # Test for SafariApiIE._real_extract()
    pass

# Generated at 2022-06-18 14:44:00.759234
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .test_safari import test_SafariCourseIE
    test_SafariCourseIE()

# Generated at 2022-06-18 14:44:08.455894
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test for SafariIE
    safari = SafariIE()
    assert safari.IE_NAME == 'safari'
    assert safari.IE_DESC == 'safaribooksonline.com online video'
    assert safari._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''

# Generated at 2022-06-18 14:44:15.025899
# Unit test for constructor of class SafariBaseIE