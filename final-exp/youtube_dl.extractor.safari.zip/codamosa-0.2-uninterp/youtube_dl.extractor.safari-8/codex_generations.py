

# Generated at 2022-06-18 14:35:26.822893
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course_id = '9780133392838'
    course_title = 'Hadoop Fundamentals LiveLessons'
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'

# Generated at 2022-06-18 14:35:28.494047
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:35:40.602777
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert SafariCourseIE.suitable('http://techbus.safaribooksonline.com/9780134426365')
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314')
    assert SafariCourseIE.suitable('https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838')
   

# Generated at 2022-06-18 14:35:43.749088
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test constructor of class SafariApiIE
    # Test case:
    #   SafariApiIE()
    # Expected:
    #   No exception
    SafariApiIE()

# Generated at 2022-06-18 14:35:44.344774
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-18 14:35:46.376357
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .test_safari import test_SafariApiIE
    test_SafariApiIE(SafariApiIE)

# Generated at 2022-06-18 14:35:53.996107
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:36:00.091727
# Unit test for constructor of class SafariBaseIE

# Generated at 2022-06-18 14:36:05.076470
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False
    assert safari_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_ie._API_FORMAT == 'json'
    assert safari_ie._PARTNER_ID == '1926081'
    assert safari_ie._UICONF_ID == '29375172'

# Generated at 2022-06-18 14:36:08.144644
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test for SafariCourseIE.__init__()
    # Test for SafariCourseIE.suitable()
    # Test for SafariCourseIE._real_extract()
    pass

# Generated at 2022-06-18 14:36:25.091614
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test for SafariCourseIE.__init__()
    # Test for SafariCourseIE.suitable()
    # Test for SafariCourseIE._real_extract()
    pass

# Generated at 2022-06-18 14:36:34.028984
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test constructor of class SafariApiIE
    #
    # Input:
    #     url: url of the webpage
    #
    # Expected result:
    #     An instance of SafariApiIE
    #
    # Assertion:
    #     The instance should be an instance of SafariApiIE
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    ie = SafariApiIE(SafariApiIE.create_ie(url))
    assert isinstance(ie, SafariApiIE)


# Generated at 2022-06-18 14:36:42.249803
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test SafariApiIE constructor
    ie = SafariApiIE()
    assert ie.IE_NAME == 'safari:api'
    assert ie.IE_DESC == 'safaribooksonline.com online video'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Generated at 2022-06-18 14:36:44.631862
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .test_safari import test_SafariApiIE
    test_SafariApiIE(SafariApiIE)

# Generated at 2022-06-18 14:36:56.949788
# Unit test for constructor of class SafariApiIE

# Generated at 2022-06-18 14:37:08.547215
# Unit test for constructor of class SafariBaseIE

# Generated at 2022-06-18 14:37:17.407729
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test SafariIE constructor
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False
    assert safari_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_ie._API_FORMAT == 'json'
    assert safari_ie._PARTNER_ID == '1926081'
    assert safari_ie._UICONF_ID == '29375172'

# Generated at 2022-06-18 14:37:29.105991
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test constructor of class SafariBaseIE
    # Test case 1:
    #   Input:
    #       url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    #   Expected output:
    #       SafariBaseIE(url, 'safari')
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    assert SafariBaseIE(url, 'safari')

    # Test case 2:
    #   Input:
    #       url = 'https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter

# Generated at 2022-06-18 14:37:29.757061
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-18 14:37:39.782207
# Unit test for constructor of class SafariBaseIE

# Generated at 2022-06-18 14:38:19.074678
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/') == True
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json') == False
    assert SafariCourseIE.suitable('http://techbus.safaribooksonline.com/9780134426365') == True
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314') == True

# Generated at 2022-06-18 14:38:25.948685
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test that SafariCourseIE is not suitable for SafariIE and SafariApiIE
    assert not SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert not SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html')
    # Test that SafariCourseIE is suitable for SafariCourseIE
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')

# Generated at 2022-06-18 14:38:32.968837
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie._VALID_URL == 'https?://(?:www\\.)?(?:safaribooksonline|(?:learning\\.)?oreilly)\\.com/library/view/[^/]+/[^/]+/[^/?#&]+\\.html'
    assert safari_ie._PARTNER_ID == '1926081'
    assert safari_ie._UICONF_ID == '29375172'


# Generated at 2022-06-18 14:38:42.236829
# Unit test for constructor of class SafariBaseIE

# Generated at 2022-06-18 14:38:44.031369
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-18 14:38:53.797238
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test constructor of SafariApiIE
    ie = SafariApiIE()
    assert ie.IE_NAME == 'safari:api'
    assert ie.IE_DESC == 'safaribooksonline.com online courses'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Generated at 2022-06-18 14:38:56.515161
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-18 14:39:02.555214
# Unit test for constructor of class SafariApiIE

# Generated at 2022-06-18 14:39:03.781179
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test that SafariBaseIE constructor doesn't fail
    SafariBaseIE()

# Generated at 2022-06-18 14:39:14.727387
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """
    Test the constructor of class SafariCourseIE
    """
    safari_course_ie = SafariCourseIE()
    assert safari_course_ie.IE_NAME == 'safari:course'
    assert safari_course_ie.IE_DESC == 'safaribooksonline.com online courses'

# Generated at 2022-06-18 14:40:11.291801
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-18 14:40:20.135369
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_ie = SafariCourseIE()
    assert safari_course_ie.IE_NAME == 'safari:course'
    assert safari_course_ie.IE_DESC == 'safaribooksonline.com online courses'
    assert safari_course_ie._VALID_URL == r'''(?x)
                    https?://
                        (?:
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+|
                                api/v1/book|
                                videos/[^/]+
                            )|
                            techbus\.safaribooksonline\.com
                        )
                        /(?P<id>[^/]+)
                    '''
    assert saf

# Generated at 2022-06-18 14:40:21.807696
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .test_safari import test_SafariCourseIE
    test_SafariCourseIE()

# Generated at 2022-06-18 14:40:32.250764
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course_id = '9780133392838'
    course_title = 'Hadoop Fundamentals LiveLessons'

# Generated at 2022-06-18 14:40:33.438916
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.LOGGED_IN == False

# Generated at 2022-06-18 14:40:38.265711
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie.LOGGED_IN == False


# Generated at 2022-06-18 14:40:46.474490
# Unit test for constructor of class SafariBaseIE

# Generated at 2022-06-18 14:40:55.652713
# Unit test for constructor of class SafariBaseIE

# Generated at 2022-06-18 14:41:00.323605
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:41:00.765620
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-18 14:43:27.311760
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-18 14:43:35.992292
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert SafariCourseIE.suitable('http://techbus.safaribooksonline.com/9780134426365')
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314')
    assert SafariCourseIE.suitable('https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838')
   

# Generated at 2022-06-18 14:43:36.767988
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test SafariIE constructor
    SafariIE()

# Generated at 2022-06-18 14:43:42.405619
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False
    assert safari_ie._NETRC_MACHINE == 'safari'
    assert safari_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_ie._API_FORMAT == 'json'
    assert safari_ie._PARTNER_ID == '1926081'
    assert safari_ie._UICONF_ID == '29375172'

# Generated at 2022-06-18 14:43:48.063963
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:43:48.751254
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-18 14:43:50.880380
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE('Safari', 'safaribooksonline.com')

# Generated at 2022-06-18 14:43:52.688018
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test the constructor of SafariBaseIE
    # The constructor should not raise an exception
    SafariBaseIE(None)

# Generated at 2022-06-18 14:44:01.004464
# Unit test for constructor of class SafariBaseIE

# Generated at 2022-06-18 14:44:01.331827
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()