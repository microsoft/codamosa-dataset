

# Generated at 2022-06-18 14:35:16.476258
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test for SafariIE.__init__()
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:35:24.407007
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie.IE_NAME == 'safari'
    assert safari_base_ie.IE_DESC == 'safaribooksonline.com online video'
    assert safari_base_ie._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''

# Generated at 2022-06-18 14:35:32.956240
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert SafariCourseIE.suitable('http://techbus.safaribooksonline.com/9780134426365')
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314')
    assert SafariCourseIE.suitable('https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838')
   

# Generated at 2022-06-18 14:35:35.961017
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:35:38.579958
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test that SafariBaseIE.__init__() doesn't raise an exception
    SafariBaseIE(None)

# Generated at 2022-06-18 14:35:40.507429
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:35:41.587963
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-18 14:35:52.506335
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert SafariApiIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert not SafariApiIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert not SafariApiIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert not SafariApiIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314/9780134217314-PYMC_13_00')

# Generated at 2022-06-18 14:35:59.313165
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    ie = SafariCourseIE(url)
    assert ie.IE_NAME == 'safari:course'
    assert ie.IE_DESC == 'safaribooksonline.com online courses'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'

# Generated at 2022-06-18 14:36:08.944696
# Unit test for constructor of class SafariApiIE

# Generated at 2022-06-18 14:36:39.032407
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    assert ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert ie._NETRC_MACHINE == 'safari'
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'
    assert ie.LOGGED_IN == False

# Generated at 2022-06-18 14:36:40.163656
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test if SafariBaseIE can be instantiated
    SafariBaseIE()

# Generated at 2022-06-18 14:36:40.770336
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-18 14:36:49.443201
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:36:56.852815
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test with a valid login
    safari = SafariBaseIE({'username': 'test', 'password': 'test'})
    assert safari.LOGGED_IN

    # Test with an invalid login
    safari = SafariBaseIE({'username': 'test', 'password': 'invalid'})
    assert not safari.LOGGED_IN

    # Test without a login
    safari = SafariBaseIE({})
    assert not safari.LOGGED_IN

# Generated at 2022-06-18 14:37:01.750952
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.LOGGED_IN == False
    assert ie._NETRC_MACHINE == 'safari'
    assert ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'

# Generated at 2022-06-18 14:37:05.676183
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """
    Unit test for constructor of class SafariApiIE
    """
    safari_api_ie = SafariApiIE()
    assert safari_api_ie.IE_NAME == 'safari:api'

# Generated at 2022-06-18 14:37:08.951855
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test login
    safari_base_ie = SafariBaseIE()
    safari_base_ie._login()
    assert safari_base_ie.LOGGED_IN == True

# Generated at 2022-06-18 14:37:17.690553
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    assert ie.IE_NAME == 'safari:course'
    assert ie.IE_DESC == 'safaribooksonline.com online courses'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'

# Generated at 2022-06-18 14:37:29.182970
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert ie.IE_NAME == 'safari:api'
    assert ie.IE_DESC == 'safaribooksonline.com online video'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Generated at 2022-06-18 14:38:25.285901
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:38:26.906997
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.LOGGED_IN == False

# Generated at 2022-06-18 14:38:29.420830
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('SafariApiIE', 'safaribooksonline.com')

# Generated at 2022-06-18 14:38:30.457713
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('SafariApiIE')

# Generated at 2022-06-18 14:38:40.109795
# Unit test for constructor of class SafariBaseIE

# Generated at 2022-06-18 14:38:45.072750
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:38:46.679828
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test constructor of class SafariApiIE
    # Test case:
    #   SafariApiIE()
    # Expected:
    #   No exception
    SafariApiIE()

# Generated at 2022-06-18 14:38:55.746569
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    ie = SafariApiIE()
    assert ie.suitable(url)
    assert ie.IE_NAME == 'safari:api'
    assert ie.IE_DESC == 'safaribooksonline.com online courses'
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Generated at 2022-06-18 14:39:06.955777
# Unit test for constructor of class SafariCourseIE

# Generated at 2022-06-18 14:39:16.674502
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False
    assert safari_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_ie._API_FORMAT == 'json'
    assert safari_ie._NETRC_MACHINE == 'safari'
    assert safari_ie._PARTNER_ID == '1926081'
    assert safari_ie._UICONF_ID == '29375172'

# Generated at 2022-06-18 14:41:06.099174
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-18 14:41:14.869316
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test for SafariIE
    ie = SafariIE()
    assert ie.IE_NAME == 'safari'
    assert ie.IE_DESC == 'safaribooksonline.com online video'
    assert ie._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''

# Generated at 2022-06-18 14:41:16.280384
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('SafariApiIE', 'safaribooksonline.com')

# Generated at 2022-06-18 14:41:20.789172
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test for SafariIE constructor
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False
    assert safari_ie._PARTNER_ID == '1926081'
    assert safari_ie._UICONF_ID == '29375172'

# Generated at 2022-06-18 14:41:29.708740
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()
    assert safari.IE_NAME == 'safari'
    assert safari.IE_DESC == 'safaribooksonline.com online video'
    assert safari._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''

# Generated at 2022-06-18 14:41:35.757305
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-18 14:41:46.532450
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()
    assert safari.IE_NAME == 'safari'
    assert safari.IE_DESC == 'safaribooksonline.com online video'
    assert safari._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''

# Generated at 2022-06-18 14:41:50.815162
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """
    Test for constructor of class SafariCourseIE
    """
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    safari_course_ie = SafariCourseIE(url)
    assert safari_course_ie.suitable(url)

# Generated at 2022-06-18 14:41:52.045332
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test that the constructor of SafariCourseIE class doesn't raise an exception
    SafariCourseIE()

# Generated at 2022-06-18 14:41:52.567180
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()