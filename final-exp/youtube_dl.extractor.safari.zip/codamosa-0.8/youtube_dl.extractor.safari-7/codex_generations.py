

# Generated at 2022-06-12 18:07:04.813803
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    assert isinstance(ie, SafariBaseIE)

# Generated at 2022-06-12 18:07:07.183854
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    for url in SafariCourseIE._TESTS:
        safaricourse = SafariCourseIE(url["url"])
        assert safaricourse is not None

# Generated at 2022-06-12 18:07:11.315877
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    try:
        course = SafariCourseIE(url)
    except:
        print('An error is raised in line {}'.format(sys.exc_info()[-1].tb_lineno))
        raise

# Generated at 2022-06-12 18:07:16.138579
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    class TestSafariApiIE(SafariApiIE):
        pass

    # check if SafariApiIE has been properly constructed
    # from SafariBaseIE
    assert (SafariBaseIE.suitable(None) ==
            TestSafariApiIE.suitable(None))



# Generated at 2022-06-12 18:07:20.943285
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # check if an instance of SafariIE(InfoExtractor) is created
    ie = SafariIE(InfoExtractor())

    # check if it can be used to extract info
    info = ie.extract('https://www.safaribooksonline.com/library/view/python-programming-language/9780137000344/part01.html')
    assert(info['id'] == '0_wg8kdzth')

# Generated at 2022-06-12 18:07:29.309205
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import os
    import unittest

    user = os.environ.get('SAFARI_USER') or os.environ.get('SAFARI_USERNAME')
    password = os.environ.get('SAFARI_PASSWORD')

    @unittest.skipUnless(user and password, 'A account is required')
    def test(self):
        safari = SafariApiIE(self.site_info)
        safari._login(user, password)
        self.assertTrue(safari._LOGGED_IN)

    unittest.TestCase.test = test

    test.__name__ = 'test'
    unittest.main()

# Generated at 2022-06-12 18:07:30.107870
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    test_SafariBaseIE = SafariBaseIE()

# Generated at 2022-06-12 18:07:32.974269
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # SafariBaseIE should require login
    ie = SafariIE()
    assert ie.LOGGED_IN == False

    # SafariBaseIE should require login
    ie = SafariCourseIE()
    assert ie.LOGGED_IN == False

    # SafariBaseIE should require login
    ie = SafariApiIE()
    assert ie.LOGGED_IN == False

# Generated at 2022-06-12 18:07:40.869436
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    page = 'This is a test'
    url = 'https://www.safaribooksonline.com/'
    # class SafariBaseIE's __init__() must not throw any errors
    IE = SafariBaseIE(SafariBaseIE._build_urlh(url, page, 'http://localhost:3128'))
    try:
        # class SafariBaseIE's _login() must not throw any errors
        IE._login()
    except (ExtractorError, compat_urllib_error.URLError):
        pass

# Generated at 2022-06-12 18:07:43.338363
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.LOGGED_IN == False
    assert ie._NETRC_MACHINE == 'safari'

# Generated at 2022-06-12 18:07:58.712638
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie._VALID_URL == SafariIE._VALID_URL

# Generated at 2022-06-12 18:08:06.004055
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    mocker = Mocker()
    klass = mocker.mock()
    klass._get_login_info()
    klass._download_webpage_handle(
        'https://learning.oreilly.com/accounts/login-check/', None,
        'Downloading login page')
    klass._download_webpage_handle(
        'https://api.oreilly.com/auth/login', None, 'Logging in')
    klass._apply_first_set_cookie_header(ANY, 'groot_sessionid')
    klass._apply_first_set_cookie_header(ANY, 'orm-jwt')
    klass._apply_first_set_cookie_header(ANY, 'orm-rt')

# Generated at 2022-06-12 18:08:11.469729
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE('SafariBase')
    assert ie.IE_NAME == 'SafariBase'
    assert ie.IE_DESC is None
    assert ie._VALID_URL is None
    assert ie._TESTS is None
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'
    assert ie.LOGGED_IN == False

# Generated at 2022-06-12 18:08:13.178320
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """
    Unit test for constructor class SafariApiIE
    """
    pass


# Generated at 2022-06-12 18:08:14.448507
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE('SafariCourse', 'safaribooksonline.com')

# Generated at 2022-06-12 18:08:20.250908
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import doctest
    doctest.testmod(
        verbose=True,
        optionflags=doctest.NORMALIZE_WHITESPACE,
        extraglobs={'safari_ie_module': __import__('youtube_dl.extractor.safari')})

# Generated at 2022-06-12 18:08:24.044349
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    return SafariCourseIE().suitable(url)

# Generated at 2022-06-12 18:08:28.527315
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safariIE1 = SafariIE('tt123456789',{
        'id': 'tt123456789',
        'title': 'title',
        'uploader': 'Safari',
        'ext': 'mp4',
        'thumbnail': 'thumbnail.jpg'
    })
    assert safariIE1.ie_key() == 'Kaltura'

# Generated at 2022-06-12 18:08:31.127548
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    raise NotImplementedError('Test not implemented yet')



# Generated at 2022-06-12 18:08:42.711159
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    if not hasattr(SafariBaseIE, '_download_webpage'):
        SafariBaseIE._download_webpage = lambda *a, **kw: None
    if not hasattr(SafariBaseIE, '_download_webpage_handle'):
        SafariBaseIE._download_webpage_handle = lambda *a, **kw: None
    if not hasattr(SafariBaseIE, '_download_json'):
        SafariBaseIE._download_json = lambda *a, **kw: None
    if not hasattr(SafariBaseIE, '_download_json_handle'):
        SafariBaseIE._download_json_handle = lambda *a, **kw: None
    if not hasattr(SafariBaseIE, '_apply_first_set_cookie_header'):
        SafariBaseIE._apply_first_

# Generated at 2022-06-12 18:08:56.535379
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert 'safaribooksonline.com' in safariie.SafariIE._VALID_URL

# Generated at 2022-06-12 18:08:58.186901
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE("YouTubeVideoUrl")

if __name__ == '__main__':
    test_SafariIE()

# Generated at 2022-06-12 18:09:05.847450
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class test_IE(SafariBaseIE):
        _LOGIN_URL = 'http://example.com/login'

    import requests
    from ..utils import MockRequest


# Generated at 2022-06-12 18:09:06.642540
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE('safari', {})


# Generated at 2022-06-12 18:09:08.982077
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html'
    SafariApiIE(test_SafariApiIE, url)._download_json(url, '9780133392838/part00',
                                                 'Downloading part JSON')

# Generated at 2022-06-12 18:09:11.058575
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import unittest

    class TestSafariApiIE(unittest.TestCase):
        def test_constructor(self):
            safari_ie = SafariApiIE()
            self.assertEqual(safari_ie.LOGGED_IN, False)

    unittest.main()

# Generated at 2022-06-12 18:09:15.528592
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    """Test if SafariBaseIE is properly constructed."""
    test_cases = (
        (SafariIE, 'SafariBaseIE.SafariIE'),
        (SafariCourseIE, 'SafariBaseIE.SafariCourseIE'),
        (SafariApiIE, 'SafariBaseIE.SafariApiIE'),
    )

    for constr, ie_key in test_cases:
        safari_base_ie = constr()
        assert safari_base_ie.ie_key() == ie_key, \
            '%s inconsistent with %s' % (safari_base_ie.ie_key(), ie_key)

# Generated at 2022-06-12 18:09:26.414587
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    test_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    inst = SafariCourseIE(contexts.Context(test_url))

    assert inst.IE_NAME  == 'safari:course'
    assert inst.IE_DESC  == 'safaribooksonline.com online courses'

# Generated at 2022-06-12 18:09:27.391811
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE('Safari')

# Generated at 2022-06-12 18:09:30.325553
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariBaseIE()
    assert safari_ie.LOGGED_IN == False
    safari_ie._login()
    assert safari_ie.LOGGED_IN == True

# Generated at 2022-06-12 18:09:50.236922
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert not SafariCourseIE.suitable(SafariIE._VALID_URL)
    assert not SafariCourseIE.suitable(SafariApiIE._VALID_URL)
    assert SafariCourseIE.suitable(SafariCourseIE._VALID_URL)

# Generated at 2022-06-12 18:09:52.234795
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Call method to test constructor
    test_object = SafariCourseIE()
    return test_object

# Generated at 2022-06-12 18:09:53.254618
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()

# Generated at 2022-06-12 18:09:58.033844
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """Unit test for SafariCourseIE class."""
    extracted_entries = SafariCourseIE._real_extract(None, 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert(extracted_entries['_type'] == 'playlist')
    assert(extracted_entries['id'] == '9780133392838')
    assert(len(extracted_entries['entries']) == 22)
    assert(extracted_entries['title'] == 'Hadoop Fundamentals LiveLessons')

# Generated at 2022-06-12 18:10:01.099538
# Unit test for constructor of class SafariIE
def test_SafariIE():
    unit_test("https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838/9780133392838-00_SeriesIntro", "")

# Generated at 2022-06-12 18:10:11.129340
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari = SafariBaseIE()
    assert safari.LOGGED_IN is False
    assert safari._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari._API_FORMAT == 'json'
    assert safari._NETRC_MACHINE == 'safari'
    assert safari._TESTS == []
    assert safari._VALID_URL == None
    assert safari.IE_NAME == 'safari'
    assert safari.IE_DESC == 'Safari base extractor'

# Generated at 2022-06-12 18:10:13.941851
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_ie = SafariCourseIE()
    assert(safari_course_ie.IE_NAME == 'safari:course')

# Generated at 2022-06-12 18:10:15.540708
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert SafariApiIE('SafariApiIE')._VALID_URL == SafariApiIE._VALID_URL

# Generated at 2022-06-12 18:10:17.169419
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie is not None


# Generated at 2022-06-12 18:10:28.294807
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    valid_urls = [
        'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html?override_format=json',
        'https://learning.oreilly.com/videos/introduction-to/9780134217314/9780134217314-video2_1',
        'https://www.oreilly.com/library/view/hadoop-fundamentals-livelessons/9780133392838/RHCE_Introduction.html',
        'https://www.safaribooksonline.com/library/view/introduction-to/9780134217314/9780134217314-video2_1.html',
    ]
    for url in valid_urls:
        SafariBaseIE._match_id(url)
       

# Generated at 2022-06-12 18:11:03.847455
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-12 18:11:08.534571
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    IE = SafariBaseIE(None)

    assert not IE.LOGGED_IN  # default value

    # check it is not possible to change protected member
    # in inherited classes

    class Inherited(SafariBaseIE):
        _LOGIN_URL = 'http://login'
        LOGGED_IN = True

    IE = Inherited(None)

    assert not IE.LOGGED_IN  # not affected!

# Generated at 2022-06-12 18:11:10.708927
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .test_safari import test_SafariApiIE as safari_api_test
    safari_api_test()

# Generated at 2022-06-12 18:11:15.601326
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    """
    This test case is to test constructor of class SafariBaseIE.
    """
    safari_url = "https://learning.oreilly.com/videos/ruby-on-rails/9780134774444/9780134774444-001_01_01"
    safari_ie = SafariBaseIE()
    safari_ie._login()
    assert safari_ie._download_webpage_handle
    assert safari_ie._download_json_handle

# Generated at 2022-06-12 18:11:18.561355
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class TestSafariBaseIE(SafariBaseIE):
        IE_NAME = 'test'
    ie = TestSafariBaseIE()
    assert ie.logged_in == False

# Generated at 2022-06-12 18:11:26.419125
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course = SafariCourseIE()
    courseID = '9780134664048'
    url = "https://www.safaribooksonline.com/library/view/mysql-high-availability/9780134768813/"
    # information we expect to be extracted

# Generated at 2022-06-12 18:11:35.066035
# Unit test for constructor of class SafariIE
def test_SafariIE():
    def test_constructor_with_parameter_none(self):
        try:
            SafariIE(None)
            assert False
        except ValueError:
            pass

    def test_constructor_with_parameter_empty_string(self):
        try:
            SafariIE('')
            assert False
        except ValueError:
            pass

    def test_constructor_with_parameter_url(self):
        from .common import InfoExtractor
        from .safari import SafariIE
        SafariIE('http://www.youtube.com/')
        assert InfoExtractor is not None



# Generated at 2022-06-12 18:11:36.081854
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE(dict())

# Generated at 2022-06-12 18:11:39.109510
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    if not hasattr(SafariApiIE, 'suitable') or not hasattr(SafariApiIE, '_real_extract'):
        assert False, 'One of needed methods is not implemented'
    else:
        assert True

# Generated at 2022-06-12 18:11:46.562784
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Check if SafariApiIE fails with a non-implemented method of InfoExtractor
    with open('test/test_data/safariie/playlist', 'r') as f:
        try:
            SafariApiIE().extract_info(f.read())
        except NotImplementedError:
            pass
        else:
            raise AssertionError('SafariApiIE failed to raise NotImplementedError')

# Generated at 2022-06-12 18:13:04.809803
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
	url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
	ie = SafariApiIE(url)
	assert ie.get_title() == '9781449396459/part00'


# Generated at 2022-06-12 18:13:10.517962
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from ..test.test_common import get_testdata_file_path

    class SafariBaseTestIE(SafariBaseIE):
        """
            Class to test SafariBaseIE via logging in.

            Note:
            The login test is skipped if the username or password fields
            are None.
        """
        def __init__(self):
            super(SafariBaseTestIE, self).__init__(self)

        def _login(self):
            # Setting the filename path
            filename = get_testdata_file_path('safari_login_credentials.json')

            # Reading the JSON file
            with open(filename, 'r') as login_file:
                login_credentials = json.load(login_file)

            username = login_credentials['username']

# Generated at 2022-06-12 18:13:12.179528
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert isinstance(SafariIE(), SafariIE)

# Generated at 2022-06-12 18:13:19.458047
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from ..jsinterp import JSInterpreter
    from ..socks import Connection

    class TestSafariIE(SafariBaseIE):
        def _download_webpage_handle(self, url_or_request, video_id, note=None, errnote=None, fatal=True, tries=1,
                                     request_conn=Connection, request=None, resource_size=None,
                                     redirect_allowed=True, redirect_count=0):
            class MockResponse:
                def __init__(self, url, info):
                    self.url = url
                    self.info = info


# Generated at 2022-06-12 18:13:22.886349
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Code for unit test.
    pass


# Generated at 2022-06-12 18:13:27.420238
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    wp = 'https://www.safaribooksonline.com/library/view/python-cookbook-2nd/9781449370675/part00.html'
    # it should not be accepted by SafariApiIE
    assert not SafariApiIE.suitable(wp)
    # but it should be accepted by SafariIE
    assert SafariIE.suitable(wp)
    # nor it should be accepted by SafariCourseIE
    assert not SafariCourseIE.suitable(wp)
    # but it should be accepted by SafariIE
    assert SafariIE.suitable(wp)

# Generated at 2022-06-12 18:13:28.347278
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    s = SafariApiIE()
    assert s

# Generated at 2022-06-12 18:13:33.447663
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    extractor = SafariCourseIE()
    assert extractor._VALID_URL == 'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'

# Generated at 2022-06-12 18:13:35.071709
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    try:
        ie = SafariBaseIE()
        ie = 1
    except NameError:
        assert(False)

# Generated at 2022-06-12 18:13:42.267419
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .test_playlist import PlaylistBaseTest
    from .test_login import FakeLoginSession
    test = PlaylistBaseTest()
    test.add_info_extractor('safaribooksonline.com', SafariCourseIE)

    def _test_id(self, url, expect_id):
        ie = SafariCourseIE(FakeLoginSession())
        id = ie._match_id(url)
        self.assertEqual(id, expect_id)

    def test_course_id(self):
        _test_id = lambda self, url, expect_id: self.assertEqual(
            SafariCourseIE._match_id(url), expect_id)

        test_course_id = lambda self, url, expect_id: _test_id(
            self, url, expect_id)


# Generated at 2022-06-12 18:16:50.267619
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert ie._NETRC_MACHINE == 'safari'
    assert ie._PARTNER_ID == '1926081'
    assert ie._UICONF_ID == '29375172'

    assert ie._API_FORMAT == 'json'
