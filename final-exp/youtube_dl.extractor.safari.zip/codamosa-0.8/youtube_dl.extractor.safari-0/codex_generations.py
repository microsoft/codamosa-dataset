

# Generated at 2022-06-12 18:07:10.273917
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    mocker = Mocker()

    ie = SafariBaseIE({})
    assert ie.username is None
    assert ie.password is None
    assert not ie.LOGGED_IN

    # test case: login info is provided
    mocker.replay()
    ie = SafariBaseIE({'username': 'test_user', 'password': 'test_pass'})
    mocker.verify()

    assert ie.username == 'test_user'
    assert ie.password == 'test_pass'
    assert not ie.LOGGED_IN

# Generated at 2022-06-12 18:07:16.741518
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course_id = '9780133392838'
    url = 'https://www.safaribooksonline.com/api/v1/book/%s/?override_format=json' % course_id

# Generated at 2022-06-12 18:07:19.121974
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    instance = SafariCourseIE('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert instance.IE_NAME == 'SafariCourseIE'
    assert instance.IE_DESC == 'safaribooksonline.com online courses'

# Generated at 2022-06-12 18:07:22.417708
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')


# Generated at 2022-06-12 18:07:25.312684
# Unit test for constructor of class SafariIE
def test_SafariIE():
    downloader = SafariIE()
    print(downloader.download('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'))

# Generated at 2022-06-12 18:07:26.657527
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Construtor does not raise an exception
    SafariBaseIE('username', 'password')

# Generated at 2022-06-12 18:07:29.024746
# Unit test for constructor of class SafariIE
def test_SafariIE():
    t = SafariIE()
    assert t.IE_NAME == 'safari'
    assert t.IE_DESC == 'safaribooksonline.com online video'

# Generated at 2022-06-12 18:07:31.858265
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from ..__main__ import _test_html_ie, _test_json_ie
    ie = SafariIE()
    return _test_json_ie(ie, 'SafariIE')
test_SafariIE.__doc__ = SafariIE.__doc__


# Generated at 2022-06-12 18:07:43.598043
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari = SafariApiIE()
    assert safari._NETRC_MACHINE == 'safari'

    # Needed for login
    safari._download_webpage = lambda *a, **k: (None, None)
    safari._download_json = lambda *a, **k: (None, None)

    # Needed for JSON extraction
    safari._download_webpage_handle = lambda *a, **k: (None, None)
    safari._search_regex = lambda *a, **k: None

    # Needed for _real_extract
    safari._download_json = lambda *a, **k: {'web_url': None}
    safari.url_result = lambda *a, **k: None

    # Needed for SafariBaseIE

# Generated at 2022-06-12 18:07:46.397313
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .common import InfoExtractor

    ie = InfoExtractor(
        'safari', 'safaribooksonline.com online courses')
    assert isinstance(ie, SafariCourseIE)

# Generated at 2022-06-12 18:08:18.239484
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .test_safari import _download_json
    safari_api_ie = SafariApiIE()
    safari_api_ie._download_json = _download_json
    safari_api_ie._login()
    url = 'https://www.safaribooksonline.com/library/view/python-text-processing/9781491933213/ch02.html'
    safari_url = safari_api_ie.extract(url)

# Generated at 2022-06-12 18:08:23.729847
# Unit test for constructor of class SafariIE
def test_SafariIE():
    df = SafariIE()._download_json_handle('https://www.oreilly.com/member/auth/login/', 'login test')

    if (not df[0].get('logged_in')):
        raise Exception('Unable to login')


# Generated at 2022-06-12 18:08:26.479594
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()
    # Asserts if safari.ie_key is not equal to 'Safari'
    assert safari.ie_key() == 'Safari'

# Generated at 2022-06-12 18:08:28.197404
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """
    Verify that SafariCourseIE class is initialized properly.
    """
    assert SafariCourseIE()

# Generated at 2022-06-12 18:08:41.231501
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import urllib2, urllib
    opener = urllib2.build_opener()
    request = urllib2.Request('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    request.add_header('Connection', 'keep-alive')
    request.add_header('Accept', 'application/json')
    request.add_header('User-Agent','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.106 Safari/537.36')

# Generated at 2022-06-12 18:08:42.456615
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert isinstance(SafariApiIE(), SafariApiIE)

# Generated at 2022-06-12 18:08:42.973818
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-12 18:08:45.290709
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    s = SafariCourseIE()
    assert s._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert s._API_FORMAT == 'json'

# Generated at 2022-06-12 18:08:51.181351
# Unit test for constructor of class SafariBaseIE

# Generated at 2022-06-12 18:08:52.311509
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE('safari:course')

# Generated at 2022-06-12 18:09:50.287304
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()
    # Check that _VALID_URL and _TEST is still set
    assert safari._VALID_URL is not None
    assert safari._TESTS is not None
    safari._VALID_URL = None
    # Check that it raises ExtractorError when _VALID_URL is empty
    try:
        safari._real_extract(None)
    except ExtractorError:
        pass

# Generated at 2022-06-12 18:09:54.627921
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    obj = SafariCourseIE(url)
    assert obj._match_id(url) == '9780133392838'

# Generated at 2022-06-12 18:09:56.218114
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Simple sanity check to make sure that SafariBaseIE is built correctly
    ie = SafariBaseIE()
    ie = SafariBaseIE(None)
    ie = SafariBaseIE({})

# Generated at 2022-06-12 18:09:57.817584
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    s = SafariApiIE()
    assert type(s) == SafariBaseIE

# Generated at 2022-06-12 18:10:05.302369
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import pytest
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    class MockHeaders():
        def __init__(self, headers_dict = {}):
            self.headers = headers_dict

        def __setitem__(self, key, value):
            self.headers[key] = value

        def get_all(self, key, failobj = None):
            return self.headers.get(key, [])

    class MockUrlHandle():
        def __init__(self, headers=None):
            self.headers = headers

        def getheaders(self):
            return self.headers.header_items()


# Generated at 2022-06-12 18:10:07.161827
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert SafariBaseIE({})._api_base() == 'https://learning.oreilly.com/api/v1'

# Generated at 2022-06-12 18:10:17.213459
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()

    assert safari_ie._VALID_URL == 'https?://(?:www\\.)?(?:safaribooksonline|(?:learning\\.)?oreilly)\\.com/library/view/[^/]+/[^/]+/[^/?#&\\.]+\\.html'
    assert safari_ie._TESTS[0]['url'] == 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    assert safari_ie._TESTS[0]['id'] == '0_qbqx90ic'
    assert safari_ie._TESTS[0]['title'] == 'Introduction to Hadoop Fundamentals LiveLessons'

# Generated at 2022-06-12 18:10:18.783541
# Unit test for constructor of class SafariIE
def test_SafariIE():
    saf = SafariIE()
    assert saf._VALID_URL == saf.VALID_URL

# Generated at 2022-06-12 18:10:22.197585
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE('SafariCourseIE')
    assert ie.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314')

# Generated at 2022-06-12 18:10:24.305788
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    try:
        SafariCourseIE()
    except:
        raise

# Generated at 2022-06-12 18:11:27.590814
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    assert 'safari:api' == ie.ie_key()
    assert 'safaribooksonline.com online courses' == ie.ie_desc()

# Generated at 2022-06-12 18:11:31.581825
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    c = SafariCourseIE()
    c._download_json('http://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json', '9781449396459')

# Generated at 2022-06-12 18:11:40.812118
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test with a valid url that actually exists
    valid_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    SafariIE().suitable(valid_url)
    # Test with a non-existant url
    non_existant_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livele/9780133392838/part00.html'
    SafariIE().suitable(non_existant_url)
    # Test with an invalid url

# Generated at 2022-06-12 18:11:43.375271
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # create a new instance of SafariIE
    SafariIE()


# Generated at 2022-06-12 18:11:46.825616
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Verify no credentials
    class UnitSafariBaseIE(SafariBaseIE):
        def _real_initialize(self):
            pass

    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    UnitSafariBaseIE(url)._initialize_geo_bypass({})

# Generated at 2022-06-12 18:11:53.677167
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class TIE(SafariBaseIE):
        _VALID_URL = r'test_url'
        ie_key = 'test_key'
    ie = TIE()
    assert ie.IE_NAME == 'safari'
    assert ie.IE_DESC == 'safaribooksonline.com online video'
    assert ie.ie_key() == 'test_key'

# Generated at 2022-06-12 18:11:59.407188
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert SafariIE(SafariBaseIE())._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''

# Generated at 2022-06-12 18:12:00.937198
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.LOGGED_IN == False

# Generated at 2022-06-12 18:12:09.381035
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE.suitable('') == False
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/') == True
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json') == False
    assert SafariCourseIE.suitable('http://techbus.safaribooksonline.com/9780134426365') == True
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314') == False

# Generated at 2022-06-12 18:12:13.173175
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    try:
        from ..__main__ import get_testcases
    except ImportError:
        return

    for url, _, _, username, password in get_testcases():
        if SafariBaseIE.suitable(url):
            try:
                SafariBaseIE(None, {'username': username, 'password': password})
            except ExtractorError:
                pass

# Generated at 2022-06-12 18:14:44.905241
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()

# Generated at 2022-06-12 18:14:46.835420
# Unit test for constructor of class SafariIE
def test_SafariIE():
    #class safari_ie(SafariIE):
    #   def _real_initialize(self):
    #       self._login()
    # test = safari_ie()
    assert False

# Generated at 2022-06-12 18:14:55.766180
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    import safari_api
    ies = safari_api.IES
    for ie_name in safari_api.IE_NAME_MAP:
        ie = ies[ie_name]()
        assert ie.get_api_base_url() == 'https://learning.oreilly.com/api/v1'
        assert ie.get_api_format() == 'json'

        # test for special cases
        if ie.get_api_base_url() != 'https://www.safaribooksonline.com/api/v1':
            assert ie.get_api_base_url() != 'http://www.safaribooksonline.com/api/v1'
            assert ie.get_api_base_url() != 'http://www.safaribooksonline.com/api/v1/'


# Generated at 2022-06-12 18:14:57.439019
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    test_utils.initialize_kaltura_jwt()
    test_utils.initialize_oauth2()
    test_utils.initialize_csrf_token()

# Generated at 2022-06-12 18:15:06.434896
# Unit test for constructor of class SafariApiIE

# Generated at 2022-06-12 18:15:13.280342
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    """Unit test for class SafariBaseIE."""
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._VALID_URL == SafariBaseIE._VALID_URL

# Generated at 2022-06-12 18:15:21.599381
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test if class SafariCourseIE is recognised by safari:course
    info_extractor = SafariCourseIE()
    assert info_extractor.IE_NAME == 'safari:course' and info_extractor.IE_DESC == 'safaribooksonline.com online courses'

    # Test if class SafariCourseIE is suitable for URL
    assert info_extractor.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')

    # Test if class SafariCourseIE is not suitable for URLs that are suitable for SafariIE or SafariApiIE
    assert not info_extractor.suitable('https://www.safaribooksonline.com/library/view/configuration-management-best/9781491924358/ch02.html')

# Generated at 2022-06-12 18:15:31.389287
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # The class variable 'LOGGED_IN' of SafariBaseIE is static in
    # inheritance and thus has to be set to True from the outer scope
    SafariBaseIE.LOGGED_IN = True

# Generated at 2022-06-12 18:15:40.623564
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # SafariBooksonline.com switched to https, which could be problematic,
    # see https://github.com/rg3/youtube-dl/issues/2430
    safari_api = SafariApiIE

# Generated at 2022-06-12 18:15:43.106998
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    try:
        # Check that class SafariApiIE works properly
        IE = SafariApiIE()
        assert isinstance(IE, SafariApiIE)
    except Exception as e:
        # If instance of class SafariApiIE hasn't been created
        raise e
