

# Generated at 2022-06-12 18:07:12.525636
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    course_id = '9780133392838'
    part = 'part00'

    class MockApiIE(SafariApiIE):
        def _real_initialize(self):
            return

        def _real_extract(self, url):
            return

        def to_screen(self, s):
            return

    course_url = 'https://www.safaribooksonline.com/library/view/%s/' % course_id
    course_page = MockApiIE()
    course_page.download_webpage = lambda course_url: '<%s>' % part

    part_url = 'https://www.safaribooksonline.com/api/v1/book/%s/chapter/%s.html?override_format=json' % (course_id, part)

# Generated at 2022-06-12 18:07:14.636605
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    api = SafariApiIE()
    assert api == SafariApiIE

# Generated at 2022-06-12 18:07:16.540297
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test call to class constructor
    SafariCourseIE('SafariCourse', 'safaribooksonline.com')

# Generated at 2022-06-12 18:07:18.308038
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    safari_base_ie._real_initialize()

# Generated at 2022-06-12 18:07:19.940879
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    _ = SafariCourseIE({})

# Generated at 2022-06-12 18:07:26.378388
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    course_id = '9780134426365'
    test_url = 'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838'
    ie = SafariBaseIE._build_ie(test_url)(SafariBaseIE)
    obj = ie(course_id)
    assert obj.course_id == course_id
    assert obj.url == test_url

# Generated at 2022-06-12 18:07:31.240789
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE("SafariApiIE")
    print(safari_api_ie)
    safari_api_ie.login()
    safari_api_ie.real_initialize()
    safari_api_ie.real_extract("https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html")

# Generated at 2022-06-12 18:07:35.619359
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    try:
        safari_ie = SafariBaseIE()
        raise AssertionError('An exception was expected to be raised')
    except ExtractorError as e:
        assert e.msg == 'In order to use safaribooksonline module, the safaribooksonline username and password must be set'

# Generated at 2022-06-12 18:07:47.176708
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """
    Unit tests for constructor of class SafariCourseIE
    """
    video_id_1 = '9780133392838'
    video_id_2 = '9780134426365'
    url_1 = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    url_2 = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    url_3 = 'http://techbus.safaribooksonline.com/9780134426365'

    # Test for method suitable
    assert SafariCourseIE.suitable(url_1)
    assert SafariCourseIE.suitable(url_2)
    assert SafariCourseIE

# Generated at 2022-06-12 18:07:53.910042
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    obj = SafariApiIE('https://www.safaribooksonline.com/api/v1/book/9781449396459/chaptercontent/part01.html')

    assert(obj._VALID_URL == 'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html')
    assert(obj._API_BASE == 'https://www.safaribooksonline.com/api/v1')
    assert(obj._API_FORMAT == 'json')



# Generated at 2022-06-12 18:08:28.429197
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://learning.oreilly.com/videos/python-for-the-lab/9780128113813'
    safari_course_IE = SafariCourseIE()
    if not safari_course_IE.suitable(url):
        print("The unit test for SafariCourseIE doesn’t work")
    #print(safari_course_IE.IE_NAME)
    #print(safari_course_IE.IE_DESC)
    #print(safari_course_IE._VALID_URL)
    #print(safari_course_IE._TESTS)

if __name__ == '__main__':
    test_SafariCourseIE()

# Generated at 2022-06-12 18:08:32.255252
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Successful import of SafariIE
    from ..SafariIE import SafariIE
    # Successful import of InfoExtractor
    from ..InfoExtractor import InfoExtractor


# Generated at 2022-06-12 18:08:43.565471
# Unit test for constructor of class SafariBaseIE

# Generated at 2022-06-12 18:08:50.080030
# Unit test for constructor of class SafariIE

# Generated at 2022-06-12 18:08:55.446883
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test class constructor
    SafariBaseIE(None)
    # Call any non-abstract method of this class (i.e. not implemented in
    # superclass InfoExtractor)
    assert SafariBaseIE(None).LOGGED_IN == False

if __name__ == '__main__':
    test_SafariBaseIE()

# Generated at 2022-06-12 18:09:04.156639
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .common import unescapeHTML
    from .aenetworks import AEVideoIE
    from .generic import GenericIE
    from .brightcove import BrightcoveLegacyIE
    from .udemy import UdemyIE
    from .kaltura import KalturaIE
    from .vimeo import VimeoIE
    from .youtube import YoutubeIE
    from .soundcloud import SoundcloudIE
    from .ted import TEDIE
    from .udemy import UdemyIE
    from .vimeo import VimeoIE
    from .wistia import WistiaIE
    from .youtube import YoutubeIE
    from .mncast import MNCastIE
    from .packtpub import PacktPubIE
    from .canvas import CanvasIE
    from .cisco import CiscoConnectIE
    from .coursera import CourseraIE

# Generated at 2022-06-12 18:09:04.547097
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()

# Generated at 2022-06-12 18:09:06.301782
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """Test class constructor."""
    instance = SafariCourseIE()
    assert instance.IE_NAME == 'safari:course'
    assert instance.IE_DESC == 'safaribooksonline.com online courses'

# Generated at 2022-06-12 18:09:13.678910
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    def _test_login(self, username, password):
        return True

    # Create temporary class that inherits from SafariBaseIE
    class Cls(SafariBaseIE):
        IE_NAME = 'test'
        _LOGIN_URL = 'unused_login_url'
        _NETRC_MACHINE = 'unused_netrc_machine'
        _API_BASE = 'unused_api_base'
        _API_FORMAT = 'unused_api_format'
        _login = _test_login

    # Initialize instance of temporary class
    ie = Cls(params={})
    # Assert that login was performed
    assert ie.LOGGED_IN


# Generated at 2022-06-12 18:09:16.381243
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    test_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    SafariCourseIE()._real_extract(test_url)

# Generated at 2022-06-12 18:09:56.109097
# Unit test for constructor of class SafariIE
def test_SafariIE():
    _, urlh = test_handle.download_webpage_handle('https://theopendata.safaribooksonline.com/library/view/Scala+Cookbook+Second/9781491905450/assets/B05150_07_22.html',None,'Downloading login page')

    redirect_url = urlh.geturl()
    parsed_url = compat_urlparse.urlparse(redirect_url)
    qs = compat_parse_qs(parsed_url.query)
    next_uri = compat_urlparse.urljoin('https://api.oreilly.com', qs['next'][0])

    username = 'test@test.test'
    password = 'testtest'

# Generated at 2022-06-12 18:10:01.648446
# Unit test for constructor of class SafariCourseIE

# Generated at 2022-06-12 18:10:05.616826
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    try:
        ie = SafariApiIE()
        assert ie.LOGGED_IN == False
    except:
        assert False

# Generated at 2022-06-12 18:10:10.159635
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE(SafariIE())
    safari_api_ie.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json');

# Generated at 2022-06-12 18:10:11.696460
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # SafariCourseIE is a new IE and has not been unit tested yet
    assert(False)

# Generated at 2022-06-12 18:10:17.323558
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import unittest
    class TestSafariApiIE(unittest.TestCase):
        def test_constructor(self):
            # pylint: disable=protected-access
            # Check if SafariApiIE.__init__() required parameters
            self.assertRaises(TypeError, SafariApiIE)
            # Check if SafariApiIE.__init__() only accept 1 required parameter
            self.assertRaises(TypeError, SafariApiIE,
                expected=True)

    unittest.main()

# Generated at 2022-06-12 18:10:28.341898
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """
    Unit test case for SafariCourseIE constructor
    """
    safari_course = SafariCourseIE()
    assert safari_course._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_course._API_FORMAT == 'json'

    actual_match = safari_course._VALID_URL
    expected_match = r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'
    assert re.match(expected_match, actual_match) != None

    test_cases = []
    test_case = {}

# Generated at 2022-06-12 18:10:30.901110
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safariIE = SafariIE("")
    assert safariIE.LOGGED_IN == False

# Generated at 2022-06-12 18:10:39.703096
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from .test_downloader import option, FakeYDL
    from .test_utils import get_testcases

    def get_extractor(url):
        ydl = FakeYDL()
        ydl.add_info_extractor(SafariBaseIE)
        ydl.add_info_extractor(SafariIE)
        ydl.add_info_extractor(SafariCourseIE)
        ydl.add_info_extractor(SafariApiIE)
        return ydl.build_extractor(url)

    testcase_list = get_testcases(option.test, SafariIE._TESTS)
    for testcase in testcase_list:
        extractor = get_extractor(testcase['url'])

# Generated at 2022-06-12 18:10:40.461734
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE() # should not raise exception

# Generated at 2022-06-12 18:11:36.885176
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()

# Generated at 2022-06-12 18:11:43.852304
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # For The constructor of SafariBaseIE, we shall try to parse the parameters passed to it.

    # Create an instance of SafariBaseIE using the constructor which will be used to test it.
    safari_base_ie = SafariBaseIE()

    # We shall check if the value of attributes is the same as what the construct expects to assign.
    assert safari_base_ie.IE_NAME == "safari:base"
    assert safari_base_ie.IE_DESC == 'safaribooksonline.com online courses'

# Generated at 2022-06-12 18:11:49.308427
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    s = SafariApiIE()
    s.initialize()

# Generated at 2022-06-12 18:11:59.182981
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'
    assert SafariCourseIE.IE_NAME == 'safari:course'
    assert SafariCourseIE.IE_DESC == 'safaribooksonline.com online courses'

# Generated at 2022-06-12 18:12:05.158645
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import unittest
    class TestSafariApiIE(unittest.TestCase):
        def test_constructor(self):
            safariApi_ie = SafariApiIE()
            self.assertEqual(safariApi_ie.IE_NAME, 'safari:api')
            self.assertEqual(safariApi_ie.IE_DESC, None)
    unittest.main()

# Generated at 2022-06-12 18:12:07.659682
# Unit test for constructor of class SafariIE
def test_SafariIE():
    len(SafariIE()._VALID_URL)
    # also tests safaribooksonline.com extraction

# Generated at 2022-06-12 18:12:16.240273
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    SafariIE.suitable('https://www.safaribooksonline.com/library/view/create-a-nodejs/100000006A0210/part00.html')
    SafariIE.suitable('https://www.safaribooksonline.com/library/view/learning-path-red/9780134664057/RHCE_Introduction.html')
    SafariIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314/9780134217314-PYMC_13_00')

# Generated at 2022-06-12 18:12:26.097953
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .test_info_extractor import ie_tests
    def test_safari_function(self):
        course_id = '9781119087084'
        course_title = 'Python Pocket Reference'
        chapter_id = 'part01'
        chapter_title = 'Strings'
        chapter_no = 1
        web_url = 'https://www.safaribooksonline.com/library/view/%s/%s.html' % (course_id, chapter_id)

        # Test initialize()
        SafariBaseIE.initialize()

        # Test SafariApiIE.suitable
        self.assertTrue(SafariApiIE.suitable(web_url))

        # Test SafariCourseIE.suitable
        self.assertTrue(SafariCourseIE.suitable(web_url))

        #

# Generated at 2022-06-12 18:12:33.786211
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    obj = SafariApiIE("https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json")
    assert obj._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

if __name__ == '__main__':
    test_SafariApiIE()

# Generated at 2022-06-12 18:12:37.434015
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part01.html'
    assert(SafariApiIE._VALID_URL == re.compile(SafariApiIE._VALID_URL).match(url).re)

# Generated at 2022-06-12 18:15:20.456291
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()


# Generated at 2022-06-12 18:15:23.383121
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    """
    Basic use of login logic
    """
    safari_base_ie = SafariBaseIE()
    safari_base_ie._login()

# Generated at 2022-06-12 18:15:29.313456
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import os
    import unittest
    import StringIO

    class RedirectHandler(object):
        def http_error_302(self, req, fp, code, msg, hdrs):
            return fp

    class MockOpener(object):
        def open(self, request):
            filename = re.sub(r'.*[?&]file=(.*?)[&$]',r'\1',request.full_url)
            if not os.path.exists(filename):
                raise IOError(os.errno.ENOENT, os.strerror(os.errno.ENOENT), filename)
            return StringIO.StringIO(open(filename).read())

        def addheaders(self, headers):
            pass


# Generated at 2022-06-12 18:15:32.957449
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html'
    SafariApiIE(SafariApiIE.ie_key())._real_extract(url)
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter-content/ch01.html'
    SafariApiIE(SafariApiIE.ie_key())._real_extract(url)

# Generated at 2022-06-12 18:15:34.477612
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE('', '')

# Generated at 2022-06-12 18:15:42.134318
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .test_html import get_testcases_from_file
    import os
    import re
    import unittest
    import pprint
    testcase_files = (
        'test_safaribooksonline_com.py',
        'test_oreilly_com.py',
        'test_learning_oreilly_com.py')
    testsuite = unittest.TestSuite()
    for testcase_file in testcase_files:
        testcase_file_path = os.path.join(
            os.path.dirname(__file__), testcase_file)
        assert os.path.exists(testcase_file_path), 'file not found: %s' % testcase_file_path
        testcase_data = get_testcases_from_file(testcase_file_path)

# Generated at 2022-06-12 18:15:44.393768
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # TODO
    return None



# Generated at 2022-06-12 18:15:47.309936
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE('http://www.safaribooksonline.com/library/view/learning-path-red/9780134664057/')

# Generated at 2022-06-12 18:15:51.464351
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie_test = SafariIE()
    assert ie_test.name == 'safari'

    assert ie_test.ie_key() == 'Kaltura'


# Generated at 2022-06-12 18:16:01.456188
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .test_downloads import fake_response

    def _get_webpage(url, video_id):
        return fake_response(url, text=(u"<script>var platypus = {'video':{'title':'foo', 'id': 'bar'}};</script>"))

    monkeypatch = {
        'SafariIE._download_webpage': _get_webpage,
    }

    with build_options({
        'unit_test': True,
        'force-generic-extractor': True,
    }, monkeypatch):
        ie = SafariIE('http://myurl/')
        info = ie._real_extract({})
        assert info['id'] == 'bar'
        assert info['title'] == 'foo'
