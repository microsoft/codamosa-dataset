

# Generated at 2022-06-12 18:07:12.119615
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()
    safari.suitable("https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html")
    safari.suitable("https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json")
    safari.suitable("http://techbus.safaribooksonline.com/9780134426365")
    safari.suitable("https://www.safaribooksonline.com/videos/python-programming-language/9780134217314")
    safari.suitable("https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838")

# Generated at 2022-06-12 18:07:17.392509
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    cls = globals().get(SafariBaseIE.__name__)
    ie = cls()
    if ie.IE_NAME == 'safari' and ie.IE_DESC == 'safaribooksonline.com online video':
        pass
    else:
        raise AssertionError('Invalid SafariBaseIE initialization')

# Generated at 2022-06-12 18:07:24.176176
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    try:
        import http.cookiejar
        SafariBaseIE._login_methods = ['_login_safaribooksonline']
        SafariBaseIE._downloader = None
        ie = SafariBaseIE()
    finally:
        ie._downloader = None
        ie.username = ie.password = None
        http.cookiejar.MozillaCookieJar._really_load = safaribooks_old_load

# Generated at 2022-06-12 18:07:25.749998
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert("safaribooksonline.com" in list(i.IE_NAME for i in SafariBaseIE.generate_ie_instances()))

# Generated at 2022-06-12 18:07:30.538218
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    url = "https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838"
    ie = SafariBaseIE(url)
    assert ie.IE_NAME == "safari:course"
    assert ie.IE_DESC == "safaribooksonline.com online courses"
    assert ie._VALID_URL == SafariCourseIE._VALID_URL
    assert ie._TESTS == SafariCourseIE._TESTS


# Generated at 2022-06-12 18:07:42.138466
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    safari_api_ie = SafariApiIE()
    safari_api_ie._real_initialize()
    # Extract the course id
    match = re.match(r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/([^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html', url)
    course_id = match.group(1)
    part = match

# Generated at 2022-06-12 18:07:43.650115
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert not ie.LOGGED_IN

# Generated at 2022-06-12 18:07:44.806427
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-12 18:07:52.292879
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import nose.tools

    # urls to test with
    test_url = 'https://learning.oreilly.com/api/v1/book/9780596520303/chapter/ch06.html'

    # create an instance of SafariApiIE with _SafariApiIE.suitable() as a param
    # this will use the constructor of _SafariApiIE to check that the url is
    # valid for the class
    test_SafariApiIE = SafariApiIE._SafariApiIE.suitable(test_url)

    # assert that the url is valid for the class
    nose.tools.assert_true(test_SafariApiIE)

# Generated at 2022-06-12 18:07:54.505688
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie._NETRC_MACHINE == 'safari'


# Generated at 2022-06-12 18:08:15.389395
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .common import FakeYDL
    from .utils import make_extractor

    def test_SafariIE_constructor(self):
        video_id = '9780133392838-part00'
        test_SafariIE = make_extractor(SafariIE)
        test_SafariIE = test_SafariIE(
            FakeYDL(),
            'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
        assert test_SafariIE.video_id == video_id


if __name__ == '__main__':
    test_SafariIE()

# Generated at 2022-06-12 18:08:17.220902
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('SafariApiIE')

# Generated at 2022-06-12 18:08:23.304605
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    non_existent_course_id = 'non-existent-course-id'
    assert not SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/' + non_existent_course_id)
    SafariCourseIE('SafariCourseIE', non_existent_course_id)

# Generated at 2022-06-12 18:08:26.130433
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert_SafariCourseIE('https://www.safaribooksonline.com/api/v1/book/9781449396459/',
                          '9781449396459')

# Generated at 2022-06-12 18:08:28.197938
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert isinstance(
        SafariCourseIE('http://techbus.safaribooksonline.com/9780134426365'),
        SafariCourseIE)

# Generated at 2022-06-12 18:08:35.646858
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()

    assert ie.IE_NAME != None
    assert ie.IE_DESC != None
    assert ie.IE_DESC_KEY != None
    assert ie._VALID_URL != None
    assert ie._TESTS != None
    assert ie.ie_key() != None
    assert ie.suitable() != None
    assert ie._real_extract() != None

# Generated at 2022-06-12 18:08:43.127818
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test safaribooksonline
    TestSafariBaseIE = type('TestSafariBaseIE',
                          (SafariBaseIE,),
                          dict(_NETRC_MACHINE='safaribooksonline'))
    TestSafariBaseIE()

    # Test oreilly
    TestSafariBaseIE = type('TestSafariBaseIE',
                          (SafariBaseIE,),
                          dict(_NETRC_MACHINE='oreilly'))
    TestSafariBaseIE()

# Generated at 2022-06-12 18:08:45.689464
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    assert ie.IE_DESC == 'safaribooksonline.com online courses'
    assert ie.IE_NAME == 'safari:course'
    assert ie.IE_VERSION == 'test'

# Generated at 2022-06-12 18:08:52.471377
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE('username', 'password')
    assert ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert ie._NETRC_MACHINE == 'safari'
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'
    assert ie.LOGGED_IN == False

# Generated at 2022-06-12 18:09:02.259166
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import inspect
    import os

    safari_ie = SafariIE()
    assert safari_ie.IE_NAME == 'safari'
    assert safari_ie.IE_DESC == 'safaribooksonline.com online video'
    assert safari_ie._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''



# Generated at 2022-06-12 18:09:35.633699
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE('https://techbus.safaribooksonline.com/9780134426365')
    ie._real_extract('https://techbus.safaribooksonline.com/9780134426365')

# Generated at 2022-06-12 18:09:42.580807
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .common import FakeLoginIE

    # Create a fake instance of class SafariIE
    #
    # Make sure that the following conditions are true:
    #   1. This fake instance is an instance of class SafariIE
    #   2. This fake instance is an instance of class FakeLoginIE
    #   3. This fake instance is not an instance of class InfoExtractor
    ie = FakeLoginIE('Safari', 'safaribooksonline.com online video')
    assert isinstance(ie, SafariIE)
    assert isinstance(ie, FakeLoginIE)
    assert not isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 18:09:47.961559
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE('http://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert ie._match_id('http://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json') == '9781449396459'
    assert ie._match_id('http://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html') == '9780133392838-part00'

# Generated at 2022-06-12 18:09:58.859401
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    import pytest
    # pytest.skip("This test can't be run without credentials.")

    class MockSafariIE(SafariIE):
        _TEST = True
        _LOGIN_URL = None
        _NETRC_MACHINE = None
        _API_BASE = None
        _API_FORMAT = None

    old_SafariIE = SafariIE
    SafariIE = MockSafariIE


# Generated at 2022-06-12 18:10:01.814891
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    import pytest
    with pytest.raises(ExtractorError):
        SafariCourseIE()._real_extract('http://techbus.safaribooksonline.com/9780134426365')

# Generated at 2022-06-12 18:10:11.369411
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():

    # Assert that SafariApiIE._real_extract returns a video url.
    # The value of the video url is not tested, since it is a private method
    # and should not be called outside the class.
    course_id = 'test_Course_id'
    part = 'test_Part'
    url = 'https://www.safaribooksonline.com/api/v1/book/' + course_id + '/chapter/' + part + '.html'
    ie = SafariApiIE()
    assert ie._real_extract(url).get('url')

# Generated at 2022-06-12 18:10:13.327258
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari = SafariApiIE()
    assert isinstance(safari, SafariBaseIE)

# Generated at 2022-06-12 18:10:15.182259
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE(None)
    assert safari_base_ie._api_base() == 'https://learning.oreilly.com/api/v1'

# Generated at 2022-06-12 18:10:18.582003
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    import YDLToKaltura
    YDLToKaltura.SafariCourseIE("https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json")

# Generated at 2022-06-12 18:10:20.041962
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert(SafariCourseIE._VALID_URL == SafariCourseIE.VALID_URL)
    assert(SafariCourseIE._TESTS == SafariCourseIE.TESTS)

# Generated at 2022-06-12 18:10:58.219549
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE(None)
    assert safari_ie.IE_NAME == 'safari'
    assert safari_ie.IE_DESC == 'safaribooksonline.com online video'
    assert safari_ie._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''

# Generated at 2022-06-12 18:11:08.230169
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """Test constructor of class SafariApiIE"""
    safari_api = SafariApiIE()
    assert safari_api.IE_NAME == 'safari:api'
    assert safari_api.IE_DESC == None
    assert safari_api._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Generated at 2022-06-12 18:11:09.187498
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE('', '')

# Generated at 2022-06-12 18:11:17.259803
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    test_fixtures = (
        {
            'username': 'fake_username',
            'password': 'fake_password',
            'expect_loggedout': True
        },
        {
            'username': '',
            'password': '',
            'expect_loggedout': True
        },
        {
            'username': 'fake_username',
            'password': '',
            'expect_loggedout': True
        },
        {
            'username': '',
            'password': 'fake_password',
            'expect_loggedout': True
        },
        {
            'username': '',
            'password': '',
            'expect_loggedout': False
        },
    )
    for test_fixture in test_fixtures:
        ie = SafariBaseIE()


# Generated at 2022-06-12 18:11:19.985645
# Unit test for constructor of class SafariIE
def test_SafariIE():
  test_SafariIE = SafariIE()
  assert(test_SafariIE == 'SafariIE')


# Generated at 2022-06-12 18:11:21.662971
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert SafariApiIE(None)._API_BASE
    assert SafariApiIE(None)._API_FORMAT

# Generated at 2022-06-12 18:11:34.975050
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    assert ie.IE_NAME == 'safari:course'
    assert ie.IE_DESC == 'safaribooksonline.com online courses'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'

# Generated at 2022-06-12 18:11:39.146751
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from ytdl.extractor import list_extractors
    safari_ie = SafariIE(list_extractors()[SafariIE.IE_NAME])
    assert safari_ie.LOGGED_IN == False
    safari_ie._login()
    assert safari_ie.LOGGED_IN == True

# Generated at 2022-06-12 18:11:47.510139
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    course_id = '9780134664057'
    part_id = 'RHCE_Introduction'
    hadoop_fundamentals = SafariApiIE(None)
    hadoop_fundamentals.course_id = course_id
    hadoop_fundamentals.part_id = part_id
    hadoop_fundamentals.part_url = 'https://www.safaribooksonline.com/api/v1/book/%s/chapter/%s.html' % (course_id, part_id)
    return

# Generated at 2022-06-12 18:11:49.520142
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()
    assert safari._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'

# Generated at 2022-06-12 18:13:07.449862
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    code = 200
    data = ''
    headers = {}
    url = 'https://learning.oreilly.com/accounts/login/'
    e = ExtractorError('msg', expected=True)

    def _login(*args, **kwargs):
        return True

    def _download_webpage(*args, **kwargs):
        return data, headers

    safari = SafariBaseIE()
    safari.LOGGED_IN = True
    safari._login = _login
    safari._download_webpage = _download_webpage
    safari._download_webpage_handle(url, None, 'msg1')
    safari._download_json(url, 'video_id', 'msg2')
    safari._download_json_handle(url, 'video_id', 'msg2')
    safari._download_

# Generated at 2022-06-12 18:13:14.799495
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    url = "https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html"
    test_class = SafariBaseIE
    assert test_class.suitable(url)
    test_instance = test_class()
    assert test_instance is not None


# Generated at 2022-06-12 18:13:16.568784
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safaribase = SafariBaseIE()
    assert safaribase._NETRC_MACHINE == 'safari'


# Generated at 2022-06-12 18:13:17.971235
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safarie = SafariIE(None)
    assert safarie is not None

# Generated at 2022-06-12 18:13:19.435466
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('safari');

# Generated at 2022-06-12 18:13:27.813948
# Unit test for constructor of class SafariIE
def test_SafariIE():
    def do_test(url, match):
        """
        Checks that a SafariIE object can be created for the given url.
        If match==True, url is expected to match SafariIE, otherwise url is expected not to match SafariIE.
        """
        if match:
            SafariIE(url)
        else:
            with pytest.raises(TypeError):
                SafariIE(url)

    # Test a URL that doesn't match the SafariIE url regex.
    do_test('http://example.com/', False)

    # Test a URL that does match the SafariIE url regex, but fails
    # the _real_initialize method.
    do_test('http://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838', False)

# Generated at 2022-06-12 18:13:29.249345
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safariIE = SafariIE()
    assert safariIE.ie_key() == 'Kaltura'


# Generated at 2022-06-12 18:13:33.881701
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    #assert not SafariApiIE.suitable("http://safaribooksonline.com/accounts/login/")
    assert SafariApiIE.suitable("https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json")

# Generated at 2022-06-12 18:13:37.951071
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course_ie = SafariCourseIE('http://techbus.safaribooksonline.com/9780134426365')
    assert type(course_ie) is SafariCourseIE
    course_ie = SafariCourseIE('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert type(course_ie) is SafariCourseIE

# Generated at 2022-06-12 18:13:38.708564
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    i = SafariCourseIE()

# Generated at 2022-06-12 18:16:32.985783
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie_instance = SafariCourseIE()
    assert ie_instance.IE_NAME == 'safari:course'
    assert ie_instance.IE_DESC == 'safaribooksonline.com online courses'
    assert ie_instance._VALID_URL == 'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'
    assert len(ie_instance._TESTS) == 6

# Generated at 2022-06-12 18:16:38.878728
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''

# Generated at 2022-06-12 18:16:41.841588
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    x = SafariCourseIE();
    assert_equal(x.__class__.__name__, 'SafariCourseIE');
    assert_equal(x.IE_NAME, 'safari:course');

# Generated at 2022-06-12 18:16:46.514634
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    obj = SafariApiIE('wwww.safaribooksonline.com/videos/learning-path-red-hat/9780134664057/chapter/RHCE_Introduction.html', {}, '9780134664057')
    assert isinstance(obj, SafariApiIE)
    assert isinstance(obj, InfoExtractor)
