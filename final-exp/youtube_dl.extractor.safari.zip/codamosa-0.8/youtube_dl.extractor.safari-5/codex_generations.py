

# Generated at 2022-06-12 18:07:07.925398
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'
    assert ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert ie._NETRC_MACHINE == 'safari'

# Generated at 2022-06-12 18:07:11.647803
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.timestamp is None
    assert safari_ie.reference_id == '9780134217314-PYMC_13_00'
    assert safari_ie.partner_id == '1926081'
    assert safari_ie.ui_id == '29375172'

# Generated at 2022-06-12 18:07:21.218237
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # A LoginError is raised if the login credentials are wrong
    import os
    import shutil
    import tempfile
    from resources.lib.aes import aes_decrypt
    from resources.lib.exceptions import LoginError

    def test(credentials):
        with tempfile.NamedTemporaryFile('w', delete=False) as netrc:
            netrc.write(credentials)

        netrc_path = netrc.name


# Generated at 2022-06-12 18:07:28.519993
# Unit test for constructor of class SafariIE
def test_SafariIE():
    url = 'http://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838'
    s = SafariBaseIE()
    s._LOGGED_IN= True

    course_id = s._match_id(url)

    url_result = s.url_result(url, SafariIE.ie_key())
    result = s._real_extract(url_result)

    assert '9780133392838' in course_id
    assert 'kaltura' in result
    assert 'Downloading kaltura session JSON' in result

# Generated at 2022-06-12 18:07:38.946727
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    course_id = '9781449396459'

# Generated at 2022-06-12 18:07:40.421820
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert isinstance(SafariCourseIE(), SafariCourseIE)

# Generated at 2022-06-12 18:07:50.578157
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course_id = '9781449396459'
    # URL of first chapter
    chapter_url = 'https://api.safaribooksonline.com/api/v1/book/9781449396459/chapter/chapter-1/'
    # URL of a chapter
    chapter_url2 = chapter_url + 'part00.html'
    # URL of a video
    video_url = 'https://learning.oreilly.com/videos/python-programming-language/9780134217314/9780134217314-PYTC_00_00'
    
    # Test 1: URL of the first chapter of a course
    course = SafariCourseIE(chapter_url)
    # It should be true that
    course_id == course.course_id
    
    # Test 2: URL of a chapter of a course
   

# Generated at 2022-06-12 18:07:53.046478
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class TestSafariBaseIE(SafariBaseIE):
        IE_NAME = 'test'

    safari = TestSafariBaseIE(None)
    assert safari._API_BASE == 'https://learning.oreilly.com/api/v1'

# Generated at 2022-06-12 18:07:54.311345
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    obj = SafariBaseIE()
    assert obj._VALID_URL == None

# Generated at 2022-06-12 18:07:56.818239
# Unit test for constructor of class SafariIE
def test_SafariIE():
    x = SafariIE()
    x._real_initialize()

# Generated at 2022-06-12 18:08:11.234553
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert not SafariBaseIE().LOGGED_IN

# Generated at 2022-06-12 18:08:18.652408
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # It is not possible to use the constructor without url, because url is
    # required in the constructor of the parent class.
    # So this test does not have a test for the constructor of the IExtractor.
    if not hasattr(SafariApiIE, '_download_json'):
        # Test was called from download_test
        return

    # Test the constructor of SafariApiIE
    course_id = '9780133392838'
    part_id = 'part00'

    download_json_old = SafariBaseIE._download_json
    def _download_json(url, course_id, note, errnote, fatal, data=None, headers=None):
        assert('override_format=json' in url)

# Generated at 2022-06-12 18:08:21.235854
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE(SafariCourseIE.ie_key())

# Generated at 2022-06-12 18:08:30.605569
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """Test constructor of class SafariCourseIE."""
    nsuitable = 0
    # Test with url not suitable for any sub-class of SafariBaseIE
    url = 'https://www.safaribooksonline.com/library/view/title/'
    sub_ie = SafariCourseIE(url)
    if sub_ie.suitable(url):
        nsuitable += 1
    url = 'https://www.safaribooksonline.com/api/v1/book/title/?override_format=json'
    sub_ie = SafariCourseIE(url)
    if sub_ie.suitable(url):
        nsuitable += 1
    # Test with url suitable for SafariCourseIE

# Generated at 2022-06-12 18:08:32.023368
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # issue #4906, raises a TypeError: int() argument must be a string or a number, not 'NoneType'
    obj = SafariCourseIE()
    assert obj is not None

# Generated at 2022-06-12 18:08:37.123768
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    api = SafariApiIE(SafariApiIE.suitable(url))
    print(api.extract(url))


# Generated at 2022-06-12 18:08:41.873965
# Unit test for constructor of class SafariIE
def test_SafariIE():
    class TestSafariIE(SafariIE):
        def __init__(self, *args, **kwargs):
            super(SafariIE, self).__init__(*args, **kwargs)

    ie = TestSafariIE()
    assert isinstance(ie, SafariIE)

# Generated at 2022-06-12 18:08:45.940439
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import os
    import sys
    import unittest

    def mock_download_json(saie, url, course_id, message, err_note, fatal, headers):
        json_path = os.path.join(sys._MEIPASS, 'safari-api-json', '%s.json' % course_id)
        with open(json_path, 'rb') as f:
            return json.loads(f.read().decode('utf-8'))

    pkg_path = os.path.join(os.path.dirname(__file__), 'safari-api-json')
    sys._MEIPASS = pkg_path

    import youtube_dl.extractor.safari as safari


# Generated at 2022-06-12 18:08:47.171404
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    try:
        SafariApiIE()
    except TypeError:
        pass

# Generated at 2022-06-12 18:08:52.191899
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert ie._VALID_URL is SafariApiIE._VALID_URL
    assert ie.IE_NAME is SafariApiIE.IE_NAME
    assert ie.IE_DESC is SafariApiIE.IE_DESC

# Generated at 2022-06-12 18:09:19.265248
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE('id')
    assert ie.LOGGED_IN == False

# Generated at 2022-06-12 18:09:30.468211
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # test SafariCourseIE.suitable()
    # to confirm that SafariCourseIE.suitable() correctly
    # returns whether SafariCourseIE is suitable for url or not
    assert SafariCourseIE.suitable(
        'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    ) == True, 'SafariCourseIE.suitable(url) is True for valid url'

    assert SafariCourseIE.suitable(
        'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part01.html'
    ) == False, 'SafariCourseIE.suitable(url) is False for SafariIE.suitable(url)'

    assert Safari

# Generated at 2022-06-12 18:09:32.489742
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert(isinstance(SafariApiIE.ie_key(), type(SafariBaseIE.ie_key())))

# Generated at 2022-06-12 18:09:42.408408
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    assert safari_api_ie.suitable(url), 'SafariApiIE does not support "%s"' %url
    assert safari_api_ie._VALID_URL == 'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html', 'SafariApiIE._VALID_URL is invalid'

# Generated at 2022-06-12 18:09:45.001614
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    """
    Test case for constructor of SafariBaseIE
    """
    safari = SafariBaseIE('test', 'test', 'test')
    try:
        safari._real_initialize()
    except Exception as e:
        assert e.__class__ == ExtractorError

# Generated at 2022-06-12 18:09:53.687164
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import json
    import os
    import unittest
    from io import BytesIO
    from io import StringIO
    from pycurl import Curl
    assert isinstance(BytesIO, object)
    assert isinstance(Curl, object)
    assert isinstance(StringIO, object)
    assert isinstance(os, object)
    assert isinstance(json, object)
    assert isinstance(unittest, object)
    inst = SafariApiIE()
    assert isinstance(inst, SafariBaseIE)



# Generated at 2022-06-12 18:09:55.125146
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    try:
        SafariCourseIE('', {})
    except Exception as e:
        raise AssertionError(repr(e))

# Generated at 2022-06-12 18:10:01.891692
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test case for SafariBaseIE constructor
    assert SafariBaseIE(None)._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert SafariBaseIE(None)._API_FORMAT == 'json'
    assert SafariBaseIE(None)._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert SafariBaseIE(None)._NETRC_MACHINE == 'safari'
    assert SafariBaseIE(None).LOGGED_IN == False

# Generated at 2022-06-12 18:10:03.377534
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert SafariCourseIE({})

# Generated at 2022-06-12 18:10:07.111026
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    if not has_login_info():
        raise SkipTest

    ie = SafariBaseIE()
    ie._init_cookies()
    ie._login()


# Test for function login

# Generated at 2022-06-12 18:11:07.939777
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()

# Generated at 2022-06-12 18:11:14.327295
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    import os
    from ..compat import compat_cookies

    netrc_path = os.path.join(os.path.dirname(__file__), 'netrc')
    username, _, password = compat_cookies._parse_netrc(netrc_path)
    if username is None:
        return 'Skipping SafariBaseIE test, you need to put your safaribooksonline account in tests/netrc'
    safari_base = SafariBaseIE()
    safari_base._initialize_geo_bypass({})
    safari_base._login()

# Generated at 2022-06-12 18:11:14.852149
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert SafariBaseIE()

# Generated at 2022-06-12 18:11:19.506470
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api = SafariApiIE('safariapi', 'safeari api')
    assert safari_api.IE_NAME == 'safari:api'
    assert safari_api.IE_DESC == 'safaribooksonline.com online video'

# Generated at 2022-06-12 18:11:26.866665
# Unit test for constructor of class SafariIE
def test_SafariIE():
    username, password = SafariBaseIE._get_login_info()
    kaltura_session = '/api/v1/player/kaltura_session/?reference_id=1'
    url = 'https://cdnapisec.kaltura.com/html5/html5lib/v2.37.1/mwEmbedFrame.php'
    class_safari_ie = SafariIE()
    query = class_safari_ie._login()
    url_result = class_safari_ie.url_result(url, query)
    course_id = "1"
    part = '2'
    url = 'https://www.safaribooksonline.com/library/view/%s/%s/part00.html' % (course_id, part)

# Generated at 2022-06-12 18:11:30.807304
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """Unit test for constructor of class SafariApiIE."""
    safari_api_ie = SafariApiIE()
    try:
        assert safari_api_ie
    except Exception:
        print("Test for construct of class SafariApiIE failed")

# Generated at 2022-06-12 18:11:35.856259
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html')._real_extract(
        'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html')

# Generated at 2022-06-12 18:11:37.528183
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari = SafariBaseIE(None)
    assert safari.IE_NAME == 'safari:course'

# Generated at 2022-06-12 18:11:41.986925
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base = SafariBaseIE()
    assert safari_base._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base._NETRC_MACHINE == 'safari'
    assert safari_base._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base._API_FORMAT == 'json'
    assert safari_base.LOGGED_IN == False

# Generated at 2022-06-12 18:11:45.902472
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    u = "https://www.safaribooksonline.com/videos/python-programming-language/9780134217314"
    result = SafariCourseIE().extract(u)
    assert result["id"] == "9780134217314"

# Generated at 2022-06-12 18:14:04.538846
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert re.match(SafariBaseIE._VALID_URL, 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html')

# Generated at 2022-06-12 18:14:09.477247
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .test_safari import _TEST_COURSES
    for course in _TEST_COURSES:
        url = 'https://www.safaribooksonline.com/library/view/%s/' % course
        extractor = SafariCourseIE(url).IE_NAME
        assert extractor == SafariCourseIE.ie_key()

# Generated at 2022-06-12 18:14:16.056498
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Note: In this test, SafariIE.logged_in == False, but it's difficult to turn
    # SafariIE.logged_in into True, so this test uses assert functions rather
    # than assertEqual functions.
    import os
    import io
    import json
    import unittest
    import tempfile

    from .common import HttpTestDataServer
    from .test_kaltura import _get_kaltura_info_dict
    from .test_kaltura import _get_kaltura_config_xml
    from .test_kaltura import _kaltura_videos_xml
    from .test_kaltura import _get_kaltura_video_info


# Generated at 2022-06-12 18:14:22.297686
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test no password and username
    class TestSafariBaseIE(SafariBaseIE):
        IE_NAME = 'test'
    t = TestSafariBaseIE()
    t._real_initialize()

    # Test username
    t._downloader.username = 'a'
    t._real_initialize()

    # Test password
    t._downloader.username = None
    t._downloader.password = 'a'
    t._real_initialize()

    # Test username and password
    t._downloader.username = 'a'
    t._real_initialize()

# Generated at 2022-06-12 18:14:25.306212
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    test = SafariApiIE()
    assert test._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert test._API_FORMAT == 'json'

# Generated at 2022-06-12 18:14:27.164176
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE(object)


# Generated at 2022-06-12 18:14:32.757053
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """Test constructor of class SafariCourseIE"""
    course_url="https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/"
    course_id="9780133392838"
    expected_title="Hadoop Fundamentals LiveLessons"
    expected_entries=22

    safari_course_ie=SafariCourseIE()
    safari_course_ie._login=lambda x: None
    info_dict=safari_course_ie._real_extract(course_url)

    assert course_id in info_dict['id']
    assert expected_title in info_dict['title']
    assert expected_entries == len(info_dict['entries'])


# Generated at 2022-06-12 18:14:36.241034
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-12 18:14:42.120018
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.IE_NAME == 'safari'
    assert safari_ie.IE_DESC == 'safaribooksonline.com online video'
    assert safari_ie._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''

# Generated at 2022-06-12 18:14:48.153718
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    i = SafariBaseIE()
    assert (i._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/')
    assert (i._NETRC_MACHINE == 'safari')
    assert (i._API_BASE == 'https://learning.oreilly.com/api/v1')
    assert (i._API_FORMAT == 'json')
    assert (not i.LOGGED_IN)