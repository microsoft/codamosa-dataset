

# Generated at 2022-06-12 18:07:06.230269
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # SafariApiIE has no __init__() method, but we want to ensure that it
    # correctly inherits the same constructor as the parent class
    assert SafariApiIE('test') == InfoExtractor('test')

# Generated at 2022-06-12 18:07:08.225201
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    username, password = SafariBaseIE._get_login_info()
    if not username or not password:
        raise Exception('Safari username or password not set')

# Generated at 2022-06-12 18:07:10.232897
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_IE = SafariBaseIE('SafariBaseIE')
    return safari_IE


# Generated at 2022-06-12 18:07:20.398205
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    course_id = '9780134664057'
    course_url = 'https://www.safaribooksonline.com/library/view/learning-path-red/9780134664057/'

    safari_course = SafariCourseIE(
        SafariCourseIE._create_ie(
            'safari:course', course_url))

    assert safari_course.IE_NAME == 'safari:course'
    assert safari_course._VALID_URL == SafariCourseIE._VALID_URL
    assert safari_course._NETRC_MACHINE == 'safari'
    assert safari_course._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_course._API_FORMAT == 'json'

# Generated at 2022-06-12 18:07:30.376556
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .test_utils import fake_urlopen
    from youtube_dl.compat import compat_HTTPError

    def _fake_urlopen(request):
        if request.get_full_url() == 'https://api.oreilly.com/api/v1/login':
            raise compat_HTTPError(
                request.get_full_url(), 401, 'Unauthorized',
                {}, None)
        elif request.get_full_url() == 'https://cdnapisec.kaltura.com/html5/html5lib/v2.37.1/mwEmbedFrame.php':
            return True
        return None

    with fake_urlopen(_fake_urlopen) as urlopen:
        safari_ie = SafariIE()
        safari_ie.urlopen = urlopen
        safari_ie._

# Generated at 2022-06-12 18:07:32.145091
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()
    assert safari.LOGGED_IN == False


# Generated at 2022-06-12 18:07:33.857147
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert hasattr(SafariApiIE, 'ie_key')


# Generated at 2022-06-12 18:07:39.824715
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """Basic test for constructor of class SafariApiIE"""

    IE = SafariApiIE()
    test_url = IE.IE_NAME + ':' + SafariApiIE._VALID_URL
    assert IE._VALID_URL == test_url
    assert IE.IE_NAME == 'safari:api'
    assert IE.IE_DESC == 'safaribooksonline.com online courses'


# Generated at 2022-06-12 18:07:41.236120
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test code goes here
    return

# Generated at 2022-06-12 18:07:42.832229
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test empty arg parse
    # No exception expected
    SafariApiIE()

# Generated at 2022-06-12 18:07:58.758853
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE().download()
    SafariApiIE().download()
    SafariCourseIE().download()

# Generated at 2022-06-12 18:08:04.928840
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    if __name__ == '__main__':
        test_url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part01.html'
        api = SafariApiIE()
        api._download = lambda url, *a, **k: url

        # test if SafariApi's base url is correctly derived from
        # test url
        assert api._API_BASE in test_url

        # test if Safari's base url is correctly derived from
        # test url
        safari = SafariIE()
        assert safari._API_BASE in test_url

# Generated at 2022-06-12 18:08:11.300032
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert ie.IE_NAME == 'safari:api'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'
    assert ie.IE_DESC == 'safaribooksonline.com online video'

# Generated at 2022-06-12 18:08:12.019170
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE({})

# Generated at 2022-06-12 18:08:13.449420
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert SafariBaseIE.__name__ == 'SafariBaseIE'

# Generated at 2022-06-12 18:08:19.044268
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    expected = 'https://cdnapisec.kaltura.com/html5/html5lib/v2.37.1/mwEmbedFrame.php'
    query = {
        'wid': '_1926081',
        'uiconf_id': '29375172',
        'flashvars[referenceId]': '9780133392838-00_SeriesIntro',
    }
    assert update_url_query(
        'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html',
        query) == expected

# Generated at 2022-06-12 18:08:22.163452
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    safari_base_ie_test = SafariBaseIE()
    if safari_base_ie_test is not None:
        assert safari_base_ie_test._match_id(url) == '9780133392838'

# Generated at 2022-06-12 18:08:23.941910
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test that SafariApiIE is able to construct object
    SafariApiIE()

# Generated at 2022-06-12 18:08:25.949647
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    res = safari_ie._real_initialize()
    assert res == None

# Generated at 2022-06-12 18:08:38.481240
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test empty(?) constructor
    obj = SafariIE()
    assert obj.IE_NAME == 'safari'
    assert obj.IE_DESC == 'safaribooksonline.com online video'
    assert obj._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''
    # Test constructor with values of instance variables
    obj

# Generated at 2022-06-12 18:09:07.606267
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # This test is for this issue: https://github.com/ytdl-org/youtube-dl/issues/17705
    # When this issue is fixed, this unit test would fail
    url = 'https://www.safaribooksonline.com/videos/python-programming-language/9780134217314'
    # If the test fails, an exception will be thrown
    SafariCourseIE().suitable(url)

# Generated at 2022-06-12 18:09:08.585324
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert(SafariApiIE()._VALID_URL == SafariApiIE._VALID_URL)

# Generated at 2022-06-12 18:09:10.657894
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safaribase_obj = SafariBaseIE('extractor', 'url', 'ie_key')
    assert safaribase_obj.ie_key() == 'ie_key'

# Generated at 2022-06-12 18:09:18.360051
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    common_test_cases = [
        {
            'netrc_machine': 'safari',
            'username': 'myusername',
            'password': 'mypassword',
            'expected': True,
        },
        {
            'netrc_machine': 'safari',
            'expected': False,
        },
        {
            'expected': False,
        },
    ]

    for test_case in common_test_cases:
        ie = SafariBaseIE(test_case['netrc_machine'])
        assert ie.LOGGED_IN == test_case['expected']



# Generated at 2022-06-12 18:09:19.900903
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert(SafariApiIE('SafariApiIE').ie_key() == 'SafariApiIE')

# Generated at 2022-06-12 18:09:30.095043
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    import contextlib
    from .test_utils import FakeHomeDirectory, FakeLoginNetrcAuthenticator

    # We need an authenticated request for the unit test
    with contextlib.ExitStack() as stack:
        stack.enter_context(FakeHomeDirectory('test'))
        stack.enter_context(FakeLoginNetrcAuthenticator())

        # If a user is logged in we get his data
        safari_base_ie = SafariBaseIE()
        result = safari_base_ie._login()
        assert 'user' in result

        # If no user is logged in we get False
        safari_base_ie = SafariBaseIE()
        result = safari_base_ie._login()
        assert result == None

# Generated at 2022-06-12 18:09:33.089094
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class FakeSafariBaseIE(SafariBaseIE):
        pass
    FakeSafariBaseIE(FakeSafariBaseIE.ie_key(), 'FakeSafariBaseIE')

# Generated at 2022-06-12 18:09:34.598982
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """Checks that the SafariIE constructor is working"""
    SafariIE()

# Generated at 2022-06-12 18:09:42.119178
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """
    Checks that SafariCourseIE class constructor is correct
    """
    instance = SafariCourseIE()
    assert instance.IE_NAME == 'safari:course'
    assert instance.IE_DESC == 'safaribooksonline.com online courses'
    assert instance._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'


# Generated at 2022-06-12 18:09:44.533300
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safariApi = SafariApiIE('https://learning.oreilly.com/api/v1/book/9781449396459/chapter/part00.html')
    assert safariApi is not None


# Generated at 2022-06-12 18:10:44.318777
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    _ = SafariApiIE(SafariBaseIE.IE_NAME, 'Safari books online')

# Generated at 2022-06-12 18:10:47.066696
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE('safari', 'safaribooksonline.com')
    assert(safari_ie.ie_key() == 'Kaltura')
    assert(safari_ie.LOGGED_IN is False)
    assert(safari_ie._API_FORMAT == 'json')
    assert(safari_ie._API_BASE == 'https://learning.oreilly.com/api/v1')

# Generated at 2022-06-12 18:10:49.688930
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # given
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    safariCourseIE = SafariCourseIE()

    # when
    extracted = safariCourseIE.extract(url)

    # then
    assert ('id' in extracted)
    assert ('title' in extracted)

# Generated at 2022-06-12 18:10:51.592407
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie_object = SafariIE()
    assert type(safari_ie_object) == SafariIE


# Generated at 2022-06-12 18:10:52.946154
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    if not hasattr(SafariApiIE, '_LOGIN_URL'):
        raise TypeError('SafariApiIE not yet initialized')

# Generated at 2022-06-12 18:11:03.051573
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import requests

    class ResponseMockup(object):
        _content = ''

        def read(self):
            return self._content

    course_id = '9780134217314'
    part = '9780134217314-PYMC_10_03'

    url = SafariIE._VALID_URL % {'course_id': course_id, 'part': part}

    # Case of a logged in safaribooks account
    # First requests returns the login page and second requests returns the video
    bla = ResponseMockup()
    with requests.Session() as session:
        session.cookies = requests.cookies.RequestsCookieJar()
        session.cookies.set('groot_sessionid', 'bla', domain='.oreilly.com', path='/')

# Generated at 2022-06-12 18:11:06.943829
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    import pytest

    with pytest.raises(TypeError) as excinfo:
        SafariCourseIE('SafariCourseIE', 'SafariCourseIE', 'SafariCourseIE')
    assert 'super(type, obj): obj must be an instance or subtype of type' in str(excinfo.value)

# Generated at 2022-06-12 18:11:08.107180
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert SafariIE()._VALID_URL == SafariBaseIE._VALID_URL

# Generated at 2022-06-12 18:11:13.242943
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    # Test both __init__ and _real_extract
    ie_api = SafariApiIE(SafariApiIE.ie_key())
    course = ie_api.extract(url)
    assert course['id'] == '9781449396459-part00'


# Generated at 2022-06-12 18:11:16.958215
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .kaltura import KalturaIE

    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    obj = SafariIE._build_kaltura_url(url)
    assert obj.entries[0].__class__ == KalturaIE

# Generated at 2022-06-12 18:13:37.741658
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    try:
        from sys import getrefcount as grc
    except ImportError:
        from warnings import warn
        warn('Unable to import getrefcount')
    else:
        SafariCourseIE._download_webpage = lambda *a: (
            '<html><head></head><body></body></html>', None)
        old_grc = grc(SafariCourseIE)
        course_id = SafariCourseIE._VALID_URL[3:-1].split('/')[-1]
        SafariCourseIE()
        assert old_grc == grc(SafariCourseIE)

# Generated at 2022-06-12 18:13:38.715163
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert isinstance(SafariBaseIE(), SafariBaseIE)

# Generated at 2022-06-12 18:13:45.145651
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .test_safari import (
        test_SafariCourseIE,
        test_SafariIE,
    )
    actual_SafariApiIE = SafariApiIE()
    actual_SafariApiIE._LOGIN_URL == test_SafariCourseIE._LOGIN_URL
    actual_SafariApiIE._NETRC_MACHINE == test_SafariCourseIE._NETRC_MACHINE
    actual_SafariApiIE._API_BASE == test_SafariCourseIE._API_BASE
    actual_SafariApiIE._API_FORMAT == test_SafariCourseIE._API_FORMAT
    actual_SafariApiIE._VALID_URL == test_SafariApiIE._VALID_URL
    actual_Safari

# Generated at 2022-06-12 18:13:46.857636
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    assert issubclass(SafariCourseIE, InfoExtractor)
    assert isinstance(ie, SafariCourseIE)


# Generated at 2022-06-12 18:13:48.098589
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE("test")
    assert ie.LOGGED_IN == False

# Generated at 2022-06-12 18:13:52.411522
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    base_ie = SafariBaseIE()
    assert base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert base_ie._NETRC_MACHINE == 'safari'
    assert base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert base_ie._API_FORMAT == 'json'
    assert base_ie.LOGGED_IN == False

# Generated at 2022-06-12 18:14:01.873095
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    import unittest

    class SafariCourseIETestCase(unittest.TestCase):
        """
        Unit test for constructor of class SafariCourseIE
        """
        def test_constructor(self):
            url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
            safari_course = SafariCourseIE(url)
            self.assertEqual(url, safari_course.url)
            self.assertEqual('safaribooksonline', safari_course.host)
            self.assertEqual('https://learning.oreilly.com/accounts/login/', safari_course._LOGIN_URL)
            self.assertEqual(False, safari_course.LOGGED_IN)

   

# Generated at 2022-06-12 18:14:03.626530
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE(None) # pylint:disable=no-value-for-parameter

# Generated at 2022-06-12 18:14:10.671361
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    inst = SafariCourseIE('http://techbus.safaribooksonline.com/9780134426365')
    inst._setup_class()
    inst._LOGIN_URL = 'https://learning.oreilly.com/accounts/login/'
    inst._NETRC_MACHINE = 'safari'
    inst._API_BASE = 'https://learning.oreilly.com/api/v1'
    inst._API_FORMAT = 'json'
    inst.LOGGED_IN = False
    inst._real_initialize()

# Generated at 2022-06-12 18:14:17.162846
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    ie._real_initialize()
    expected_uas = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36'
    assert ie._downloader.user_agent == expected_uas