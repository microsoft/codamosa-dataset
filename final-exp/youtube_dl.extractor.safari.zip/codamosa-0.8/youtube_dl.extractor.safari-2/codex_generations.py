

# Generated at 2022-06-12 18:07:04.556671
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()

# Generated at 2022-06-12 18:07:05.501252
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safariIE = SafariIE()
    safariIE.initialize()

# Generated at 2022-06-12 18:07:08.858601
# Unit test for constructor of class SafariIE
def test_SafariIE():
    instance_safari_ie = SafariIE()
    assert instance_safari_ie.IE_NAME == 'safari'


# Generated at 2022-06-12 18:07:10.348121
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """Unit test requires safaribooksonline account credentials."""
    SafariCourseIE()._login()

# Generated at 2022-06-12 18:07:18.725734
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    resp, urlh = {}, compat_urllib_request.addinfourl({}, '', '')
    resp['url'] = 'http://techbus.safaribooksonline.com/9780134426365'
    urlh.code = 200
    urlh.msg = 'OK'
    urlh.fileno = lambda: -1
    urlh.close = lambda: None
    urlh.info = lambda: resp
    urlh.geturl = lambda: resp['url']

    safariIE = SafariApiIE()
    safariIE._real_extract(urlh.geturl())

# Generated at 2022-06-12 18:07:23.083252
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    data = ie.extract('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part01.html')

# Generated at 2022-06-12 18:07:31.641198
# Unit test for constructor of class SafariIE
def test_SafariIE():

    # Test to see if SafariIE could be instantiated
    safari_ie = SafariIE()

    # Check to see if SafariIE.suitable() could identify a valid Safari URL
    valid_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    assert safari_ie.suitable(valid_url) == True

    # Check to see if SafariIE.suitable() could identify a invalid Safari URL
    valid_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838'
    assert safari_ie.suitable(valid_url) == False

# Generated at 2022-06-12 18:07:35.324588
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    base = SafariBaseIE()
    assert base._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert base._API_FORMAT == 'json'
    assert base.LOGGED_IN == False


# Generated at 2022-06-12 18:07:43.183006
# Unit test for constructor of class SafariIE
def test_SafariIE():
    try:
        import selenium.webdriver.phantomjs
        class FakeDriver(object):
            def __init__(self, *args, **kwargs):
                pass
            def quit(self):
                pass
        selenium.webdriver.phantomjs.webdriver.WebDriver = FakeDriver
    except ImportError:
        pass
    # Set up an instance of the SafariIE
    ie = SafariIE({})
    # Make sure the import of phantomjs succeeded
    assert ie._DRIVER_PATH is None

# Generated at 2022-06-12 18:07:47.849318
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    constructor_test(SafariApiIE, ['https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/chapter2.html'], {
        'id': '9781449396459/chapter/chapter2',
        'title': 'Getting Started with Spring Framework'
    })

# Generated at 2022-06-12 18:08:17.015538
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert(not SafariIE().LOGGED_IN)
    assert(SafariIE(SafariIE, 'testusername', 'testpassword').LOGGED_IN)

# Generated at 2022-06-12 18:08:27.088502
# Unit test for constructor of class SafariIE
def test_SafariIE():
    '''Test SafariIE constructor
    '''

    # init SafariIE
    safari = SafariIE()

    # validate safariIE's members
    assert safari._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari._NETRC_MACHINE == 'safari'

    assert safari._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari._API_FORMAT == 'json'

    assert safari.LOGGED_IN == False


if __name__ == '__main__':
    test_SafariIE()

# Generated at 2022-06-12 18:08:30.598448
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    s = SafariCourseIE(SafariCourseIE.ie_key())
    assert s.IE_NAME == 'safari:course'

# Generated at 2022-06-12 18:08:40.092329
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class MockSafariBaseIE(SafariBaseIE):
        def __init__(self, *args, **kwargs):
            super(MockSafariBaseIE, self).__init__(*args, **kwargs)
            self.tp = None
        def _real_initialize(self):
            self.tp = True
    # test constructor without login
    ie = MockSafariBaseIE(dict())
    assert not ie.LOGGED_IN
    # test constructor with login
    ie = MockSafariBaseIE(dict(username='user', password='pass'))
    assert not ie.tp
    assert ie.LOGGED_IN

# Generated at 2022-06-12 18:08:43.036853
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert issubclass(SafariIE, InfoExtractor)


SafariBaseIE.register_module(SafariApiIE)
SafariBaseIE.register_module(SafariCourseIE)

# Generated at 2022-06-12 18:08:43.573492
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    pass

# Generated at 2022-06-12 18:08:44.797977
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    s = SafariApiIE()

# Generated at 2022-06-12 18:08:55.548798
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
        # test for https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    SafariApiIE().url_result(url,None).url
    # test for https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter-content/part00.html'
    SafariApiIE().url_result(url,None).url

# Generated at 2022-06-12 18:08:56.244281
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-12 18:08:56.858916
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()

# Generated at 2022-06-12 18:09:37.057760
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    m_urlopen, m_Request = mocker.patch('urllib2.urlopen'), mocker.patch('urllib2.Request')
    m_urlopen.return_value.geturl.return_value = 'https://learning.oreilly.com/accounts/login-check/'

    # Test "non-logged" account
    m_urlopen.return_value.read.return_value = '{"logged_in": false, "redirect_uri": "https://api.oreilly.com/"}'

    mocker.patch('jwt.decode')

    safarie = SafariBaseIE()
    safarie._login()
    assert safarie.LOGGED_IN == False
    assert m_Request.call_count == 2

    # Test "logged" account
    m_urlopen.return_value

# Generated at 2022-06-12 18:09:39.721271
# Unit test for constructor of class SafariIE
def test_SafariIE():
    try:
        SafariIE()
    except Exception as e:
        assert False, "Could not instantiate SafariIE()."


# Generated at 2022-06-12 18:09:41.560713
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_apiIE = SafariApiIE()
    assert safari_apiIE.IE_NAME == 'safari:api'

# Generated at 2022-06-12 18:09:53.212442
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():

    with open('test/test_data/safari_course_output.json') as f:
        course_json = json.load(f)

    safari_course_ie = SafariCourseIE()

    assert safari_course_ie.IE_NAME == 'safari:course'
    assert safari_course_ie.IE_DESC == 'safaribooksonline.com online courses'

# Generated at 2022-06-12 18:09:58.409923
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()
    assert safari.IE_NAME == 'safari'
    assert safari.IE_DESC == 'safaribooksonline.com online video'
    assert safari._VALID_URL == 'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+))'


# Generated at 2022-06-12 18:10:05.597195
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    obj = SafariCourseIE('http://techbus.safaribooksonline.com/9780134426365')

    assert obj._VALID_URL == r'''(?x)
                    https?://
                        (?:
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+|
                                api/v1/book|
                                videos/[^/]+
                            )|
                            techbus\.safaribooksonline\.com
                        )
                        /(?P<id>[^/]+)
                    '''

    assert obj._real_initialize._callback_args == (None,)
    assert obj._real_initialize._callback_kwargs == {'_expected_status': None}

# Generated at 2022-06-12 18:10:07.111006
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    print(ie.ie_key())

# Generated at 2022-06-12 18:10:11.105770
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    assert SafariCourseIE(SafariCourseIE.suitable(url), url)

# Generated at 2022-06-12 18:10:16.219283
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test with login
    username = 'dummy'
    password = 'dummy'
    ie = SafariBaseIE({
        'username': username,
        'password': password,
    })
    assert ie._get_login_info() == (username, password)
    # Test without login
    ie = SafariBaseIE({})
    assert ie._get_login_info() == (None, None)

# Generated at 2022-06-12 18:10:20.442109
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_ie = SafariCourseIE()
    assert safari_course_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_course_ie._API_FORMAT == 'json'

# Generated at 2022-06-12 18:11:37.092824
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    test_dict={
        'kaltura_session': {
            'session': '1_qhb0uw5f',
            'status': 'ok'
        }
    }
    class TestClass(SafariBaseIE):
        def __init__(self):
            pass
        def _download_json_handle(self, *args, **kwargs):
            return (test_dict,
                '<html><head><meta http-equiv="Set-Cookie" content="kaltura_session=1_qhb0uw5f; kaltura_session2=1_qhb0uw5f; kaltura_session=1_qhb0uw5f; kaltura_session2=1_qhb0uw5f"></head></html>'
                )

# Generated at 2022-06-12 18:11:39.029467
# Unit test for constructor of class SafariIE
def test_SafariIE():
    c = SafariIE()
    assert c._PARTNER_ID == '1926081'
    assert c._UICONF_ID == '29375172'

# Generated at 2022-06-12 18:11:39.858562
# Unit test for constructor of class SafariIE
def test_SafariIE():
    s = SafariIE()

# Generated at 2022-06-12 18:11:51.124057
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    course_id = '9780133392838'
    part = 'part00'
    safari_api_ie = SafariApiIE()
    safari_api_ie._login()
    url = 'https://www.safaribooksonline.com/api/v1/book/%s/chapter/%s.html' % (course_id, part)
    web_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/%s.html' % part

# Generated at 2022-06-12 18:11:59.860189
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test login failure
    course_id = '9781449369735'
    safari_ie = SafariBaseIE()
    safari_ie.login = lambda: 1/0
    safari_ie.LOGGED_IN = True
    safari_ie._download_json(
        '%s/book/%s/?override_format=%s' % (safari_ie._API_BASE, course_id, safari_ie._API_FORMAT),
        course_id, 'Downloading course JSON')
    assert not safari_ie.LOGGED_IN
    # Test login success
    login_password = ('safari', 'safari')
    safari_ie.login = lambda: 0
    safari_ie.LOGGED_IN = False

# Generated at 2022-06-12 18:12:01.688586
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE(SafariBaseIE._downloader, SafariBaseIE._downloader.params)
    assert ie.IE_NAME == 'safari:course'
    assert ie.IE_DESC == 'safaribooksonline.com online courses'

# Generated at 2022-06-12 18:12:07.082498
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # login
    instance = SafariBaseIE({})
    assert(not instance.LOGGED_IN)

    # without login info
    instance = SafariBaseIE({})
    assert(not instance.LOGGED_IN)

    # with login info
    instance = SafariBaseIE({
        'username': 'SafariBaseIE_username',
        'password': 'SafariBaseIE_password'
    })
    assert(instance.LOGGED_IN)

# Generated at 2022-06-12 18:12:15.698938
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import unittest
    from sys import version_info
    from tempfile import NamedTemporaryFile
    from .common import BaseTest

    def setUp(self):
        filename = NamedTemporaryFile(prefix='%s-' % self.id(), suffix='.txt').name
        self.filename = filename
        if version_info[0] >= 3:
            self.filename = self.filename.encode('utf-8')

    class SafariIE(unittest.TestCase, BaseTest):
        setUp = setUp

        def test_constructor(self):
            safari_ie = SafariIE(SafariBaseIE._NETRC_MACHINE)
            safari_ie.LOGGED_IN = True
            self.assertTrue(isinstance(safari_ie, InfoExtractor))

# Generated at 2022-06-12 18:12:17.173492
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE('test')

# Generated at 2022-06-12 18:12:19.842969
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE('https://www.safaribooksonline.com/library/view/python-crash-course/9780133128848/')

# Generated at 2022-06-12 18:15:14.573766
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """Unit test for constructor of class SafariCourseIE"""
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert SafariCourseIE.suitable('http://techbus.safaribooksonline.com/9780134426365')
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314')

# Generated at 2022-06-12 18:15:22.608160
# Unit test for constructor of class SafariBaseIE

# Generated at 2022-06-12 18:15:25.075621
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    oe = SafariApiIE()
    ret = oe.extract("https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html")
    assert ret['id'] == '0_qbqx90ic'

# Generated at 2022-06-12 18:15:26.190667
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert_raises(TypeError, SafariApiIE)

# Generated at 2022-06-12 18:15:27.695072
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    ie._real_initialize()

# Generated at 2022-06-12 18:15:30.372995
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    try:
        ied = SafariApiIE('')
    except:
        print('Unexpected exception happened while creating instance of SafariApiIE')

# Generated at 2022-06-12 18:15:32.799832
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()


# Generated at 2022-06-12 18:15:35.469673
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE('safari:api')
    assert ie._VALID_URL == SafariApiIE._VALID_URL

# Generated at 2022-06-12 18:15:41.965408
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # SafariIE requires authentication.
    # If authentication fails, it should throw an exception.
    from safari_test import SafariTest
    safari_test = SafariTest()
    safari_test.setUp()
    url = 'https://www.safaribooksonline.com/api/v1/book/9780134664057/chapter/RHCE_Introduction.html'
    safariIE = SafariIE()
    safariIE.login()
    safariIE.url_result(url, 'Safari')
    safariIE.real_extract(url)
    safari_test.tearDown()

# Generated at 2022-06-12 18:15:47.180138
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    import json
    with open("test/test1.json") as f:
        test_response1 = json.load(f.read())
    with open("test/test2.json") as f:
        test_response2 = json.load(f.read())
    with open("test/real_response.json") as f:
        real_response = json.load(f.read())