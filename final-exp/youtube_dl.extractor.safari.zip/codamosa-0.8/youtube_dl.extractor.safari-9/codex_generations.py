

# Generated at 2022-06-12 18:07:04.470857
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    test_class_instance = SafariBaseIE()
    assert test_class_instance.IE_NAME == 'safari'

# Generated at 2022-06-12 18:07:06.229773
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE(None)
    SafariApiIE(None, SafariBaseIE)

# Generated at 2022-06-12 18:07:09.829911
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert SafariBaseIE()


if __name__ == '__main__':
    from . import _test_functions
    _test_functions.run_tests(globals())

# Generated at 2022-06-12 18:07:15.762711
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """
    It is required to check that constructor of class
    SafariCourseIE loads all subclasses of InfoExtractor.
    """
    from .common import InfoExtractor

    safari_courses = SafariCourseIE()
    for ie in InfoExtractor._ies:
        if ie.suitable(ie.working_as_of):
            assert(ie.ie_key() in safari_courses._ies)

# Generated at 2022-06-12 18:07:17.209683
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    ie._login()

# Generated at 2022-06-12 18:07:17.648338
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()

# Generated at 2022-06-12 18:07:21.024402
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    ie.suitable = lambda x: True
    ie.extract('https://example.com/foo')

# Generated at 2022-06-12 18:07:21.726329
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    pass

# Generated at 2022-06-12 18:07:30.524153
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test with a valid input
    obj = SafariBaseIE()
    assert obj._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert obj._NETRC_MACHINE == 'safari'
    assert obj._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert obj._API_FORMAT == 'json'
    assert obj.LOGGED_IN == False
    # Test with a invalid input
    assert obj._LOGIN_URL != None
    assert obj._NETRC_MACHINE != None
    assert obj._API_BASE != None
    assert obj._API_FORMAT != None
    assert obj.LOGGED_IN != None


# Generated at 2022-06-12 18:07:36.164838
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    import SafariCourseIE
    fetcher = SafariCourseIE.SafariCourseIE()

# Generated at 2022-06-12 18:07:52.007347
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Arrange
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    expected_title = 'Hadoop Fundamentals LiveLessons'

    # Act
    result = SafariCourseIE.suitable(url)

    # Assert
    assert result

# Generated at 2022-06-12 18:07:57.056077
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    args = [
        'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/',
        'safari:course',
        'safaribooksonline.com online courses',
        'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/',
        '9780133392838',
    ]
    course = SafariCourseIE(*args)

# Generated at 2022-06-12 18:08:05.413765
# Unit test for constructor of class SafariIE
def test_SafariIE():
    IE = SafariIE('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert IE.get_id() == '0_qbqx90ic'
    assert IE.get_title() == 'Introduction to Hadoop Fundamentals LiveLessons'
    assert ((IE.get_field('timestamp') == 1437758058) or
            (IE.get_field('timestamp') == 1437748121))
    assert IE.get_field('uploader_id') == 'stork'
    assert IE.get_field('uploader') == 'Mr. John W. Stork'

# Generated at 2022-06-12 18:08:10.510457
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safariIE = SafariCourseIE()
    assert(safariIE._VALID_URL == 'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)')

# Generated at 2022-06-12 18:08:12.082710
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    assert isinstance(ie, SafariBaseIE)
    assert ie.IE_NAME == 'safari:course'

# Generated at 2022-06-12 18:08:13.496222
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Run a trivial test just to verify that the constructor works
    ie = SafariApiIE()

# Generated at 2022-06-12 18:08:14.408463
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE("")

# Generated at 2022-06-12 18:08:20.143353
# Unit test for constructor of class SafariIE
def test_SafariIE():
    _SafariIE = getattr(SafariCourseIE, 'suitable')('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert _SafariIE

# Generated at 2022-06-12 18:08:29.792002
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Existing URL, expected metadata
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    expected_metadata = {
        'id': '0_qbqx90ic',
        'ext': 'mp4',
        'title': 'Introduction to Hadoop Fundamentals LiveLessons',
        'timestamp': 1437758058,
        'upload_date': '20150724',
        'uploader_id': 'stork',
    }

    # Instantiate class and run tests
    safariIE = SafariIE()
    safariIE.init(url)
    metadata = safariIE.get_metadata()

    # Check that all expected metadata is present in actual metadata

# Generated at 2022-06-12 18:08:32.111281
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    extractor = SafariApiIE('safari')
    assert isinstance(extractor, SafariApiIE)

# Generated at 2022-06-12 18:09:04.249339
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from safaribooksonline.compat import compat_unittest_text
    from safaribooksonline.tests import test_SafariBaseIE

    # create instance of class SafariIE and test it's properties
    safari = SafariIE('Downloading login page')
    assert safari._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari._NETRC_MACHINE == 'safari'
    assert safari._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari._API_FORMAT == 'json'
    assert not safari.LOGGED_IN

    # create instance of class SafariIE with inheriting class's _LOGIN_URL
    # and test it's properties

# Generated at 2022-06-12 18:09:05.401952
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert bool(safari_ie) == bool(safari_ie._login())

# Generated at 2022-06-12 18:09:06.223513
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE({})
    assert ie.LOGGED_IN == False

# Generated at 2022-06-12 18:09:11.168899
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    if __name__ == '__main__':
        import sys
        if not len(sys.argv[1:]):
            print('[url]\n[url] ...')
            sys.exit()
    sys.argv.pop(0)

    ie = SafariCourseIE()
    ie.set_downloader(None)
    ie.add_default_info_extractors()

    for url in sys.argv:
        print('Extracting url %s' % url)
        try:
            info = ie.extract(url)
        except Exception as e:
            print('%s: ERROR: %s' % (type(e).__name__, e), file=sys.stderr)
            continue
        if info.get('_type', None) == 'url_transparent':
            continue
        print

# Generated at 2022-06-12 18:09:16.189855
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN is False
    assert safari_ie._API_BASE is 'https://learning.oreilly.com/api/v1'
    assert safari_ie._PARTNER_ID is '1926081'
    assert safari_ie._UICONF_ID is '29375172'

# Generated at 2022-06-12 18:09:18.907560
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    obj = SafariBaseIE('username', 'password', 'safari')
    assert obj._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert obj._API_FORMAT == 'json'

# Generated at 2022-06-12 18:09:25.320826
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    test_SafariBaseIE.instance = SafariBaseIE()
    assert (test_SafariBaseIE.instance._NETRC_MACHINE == "safari")
    assert (test_SafariBaseIE.instance._LOGIN_URL == "https://learning.oreilly.com/accounts/login/")
    assert (test_SafariBaseIE.instance.LOGGED_IN == False)

# Generated at 2022-06-12 18:09:36.357353
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    course_id = '9780134664057'
    techbus_url = 'http://techbus.safaribooksonline.com/%s' % course_id
    course_url = 'https://learning.oreilly.com/videos/%s' % course_id
    video_url = 'https://www.safaribooksonline.com/library/view/%s/part00.html' % course_id

    # No username/password set, neither `SafariCourseIE` nor `SafariIE` can be
    # instantiated.
    assert SafariCourseIE.suitable(techbus_url)
    assert SafariCourseIE.suitable(course_url)
    assert not SafariCourseIE.suitable(video_url)

    assert not SafariIE.suitable(techbus_url)
    assert not Safari

# Generated at 2022-06-12 18:09:37.532568
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()

# Generated at 2022-06-12 18:09:38.873927
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Constructor of class SafariBaseIE takes no arguments
    SafariBaseIE()

# Generated at 2022-06-12 18:10:29.674280
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('safari:api')

# Generated at 2022-06-12 18:10:30.532157
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-12 18:10:31.213020
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    assert ie.__class__ == SafariCourseIE

# Generated at 2022-06-12 18:10:32.134628
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    instance = SafariBaseIE()
    instance._login()

# Generated at 2022-06-12 18:10:38.028851
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    obj = SafariBaseIE()
    assert obj._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert obj._NETRC_MACHINE == 'safari'
    assert obj._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert obj._API_FORMAT == 'json'
    assert obj.LOGGED_IN == False
    assert obj._real_initialize() == None
    assert obj._login() == None

# Generated at 2022-06-12 18:10:38.878248
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    x = SafariBaseIE()

# Generated at 2022-06-12 18:10:41.215973
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test the constructor
    obj = SafariBaseIE()

    # TODO: Do more testing here.
    # For example, testing the _real_initialize()
    # method to see if it correctly sets the
    # LOGGED_IN class variable

# Generated at 2022-06-12 18:10:41.871832
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()

# Generated at 2022-06-12 18:10:42.654482
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE(SafariCourseIE._downloader, 'safaribooksonline')



# Generated at 2022-06-12 18:10:47.242443
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert SafariIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert SafariIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314/9780134217314-PYMC_13_00')
    assert SafariIE.suitable('https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838/9780133392838-00_SeriesIntro')

# Generated at 2022-06-12 18:12:44.269992
# Unit test for constructor of class SafariIE
def test_SafariIE():
    with open("test.html", "r") as myfile:
        webpage = myfile.read()
    video_id = '0_qbqx90ic'
    ui_id = '29375172'
    partner_id = '1926081'
    reference_id = '9780133392838-0_qbqx90ic'
    query = {
        'wid': '_%s' % partner_id,
        'uiconf_id': ui_id,
        'flashvars[referenceId]': reference_id,
    }
    url = update_url_query(
        'https://cdnapisec.kaltura.com/html5/html5lib/v2.37.1/mwEmbedFrame.php', query)
    expected = None

# Generated at 2022-06-12 18:12:47.660834
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'

# Generated at 2022-06-12 18:12:50.362066
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    account_credentials = {'login': 'account_login', 'password': 'account_password'}
    safari_base_ie = SafariBaseIE(account_credentials)

    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-12 18:12:56.985036
# Unit test for constructor of class SafariIE
def test_SafariIE():
    obj = SafariIE()
    assert obj.IE_NAME == 'safari'
    assert obj.IE_DESC == 'safaribooksonline.com online video'
    assert obj._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''
    assert obj._PARTNER_ID == '1926081'
    assert obj._U

# Generated at 2022-06-12 18:12:57.415963
# Unit test for constructor of class SafariIE
def test_SafariIE():
    instance = SafariIE()

# Generated at 2022-06-12 18:12:59.832794
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .test_utils import TestSafaribooksonlineIE
    TestSafaribooksonlineIE.IE = SafariIE
    TestSafaribooksonlineIE('safari').test()

# Generated at 2022-06-12 18:13:10.942024
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    test_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    test_course_id = '9780133392838'
    test_course_title = 'Hadoop Fundamentals LiveLessons'
    test_course_description = '''With more than four hours of instruction, these LiveLessons take you from the basics of Hadoop to advanced concepts.

    '''

# Generated at 2022-06-12 18:13:19.153124
# Unit test for constructor of class SafariIE

# Generated at 2022-06-12 18:13:23.406010
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .common import test_example_urls
    test_example_urls(SafariIE, safari_ie=True)

# Generated at 2022-06-12 18:13:24.575502
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert SafariIE('http://foo.example.com/video')