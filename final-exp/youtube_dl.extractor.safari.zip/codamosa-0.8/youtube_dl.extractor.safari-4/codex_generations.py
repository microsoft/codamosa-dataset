

# Generated at 2022-06-12 18:07:11.590297
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert 'SafariBaseIE' not in globals()
    # This test used to fail because we did not create a new
    # _downloader_pool for each InfoExtractor

    class SafariBaseIE(SafariBaseIE):
        IE_NAME = 'test'
        IE_DESC = False
        _VALID_URL = r'https?://.+'

    ie = SafariBaseIE(SafariBaseIE._create_get_downloader())
    ie.initialize()

# Generated at 2022-06-12 18:07:13.614777
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .test_safari import test_SafariCourseIE
    test_SafariCourseIE(SafariCourseIE)


# Generated at 2022-06-12 18:07:24.568921
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    def extract_entries(self, course_id, course_title, playlist_count):
        entries = [
            self.url_result(chapter, SafariApiIE.ie_key())
            for chapter in course_json['chapters']]
        return self.playlist_result(entries, course_id, course_title)

    def _real_extract(self, url):
        course_id = self._match_id(url)

        course_json = self._download_json(
            '%s/book/%s/?override_format=%s' % (self._API_BASE, course_id, self._API_FORMAT),
            course_id, 'Downloading course JSON')


# Generated at 2022-06-12 18:07:26.775705
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test SafariBaseIE
    # Test SafariBaseIE.__init__
    o = SafariBaseIE()
    # Verify that IE_NAME is the name of the instance
    assert o._WORKING_IE.IE_NAME == 'safari'

# Generated at 2022-06-12 18:07:27.365090
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-12 18:07:28.657607
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    instance = SafariBaseIE()
    instance._real_initialize()

# Generated at 2022-06-12 18:07:29.934585
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    sbAPI = SafariApiIE()
    sbAPI._real_initialize()

# Generated at 2022-06-12 18:07:31.311777
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert SafariApiIE('safari:api')._VALID_URL == SafariApiIE._VALID_URL

# Generated at 2022-06-12 18:07:35.711207
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Just making sure SafariBase IE works
    url = 'https://learning.oreilly.com/videos/ruby-fundamentals-livelessons/9780134383265/9780134383265-RUBY_01_00'
    SafariBaseIE()._real_extract(url)


# Generated at 2022-06-12 18:07:47.216855
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .common import id2url, url2id

# Generated at 2022-06-12 18:08:01.376421
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-12 18:08:12.362114
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class TestSafariBaseIE(SafariBaseIE):
        _LOGIN_URL = 'https://learning.oreilly.com/accounts/login/'
        _NETRC_MACHINE = 'safari'

        _API_BASE = 'https://learning.oreilly.com/api/v1'
        _API_FORMAT = 'json'

        LOGGED_IN = False

    url = 'https://www.safaribooksonline.com/library/view/python-cookbook-3rd/9781449357337/part00.html'
    safari_ie = TestSafariBaseIE()
    safari_ie.login = lambda: None
    safari_ie._real_initialize()
    info_dict = safari_ie.extract(url)

# Generated at 2022-06-12 18:08:13.450609
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()

# Generated at 2022-06-12 18:08:21.031209
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    safari_course_ie = SafariCourseIE()
    safari_course_ie.suitable(url) == True
    safari_course_ie._real_initialize()
    safari_course_ie._VALID_URL

# Generated at 2022-06-12 18:08:28.232932
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Invalid cases
    with pytest.raises(ExtractorError):
        SafariBaseIE('test')
    with pytest.raises(ExtractorError):
        SafariBaseIE('test', 'test', None)
    with pytest.raises(ExtractorError):
        SafariBaseIE('test', 'test', 'test', LoginError=True)
    with pytest.raises(ExtractorError):
        SafariBaseIE('test', 'test', 'test', LoginError=False)
    # Valid cases
    SafariBaseIE('test', 'test', 'test')

# Generated at 2022-06-12 18:08:30.917075
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('www.safaribooksonline.com')


# Generated at 2022-06-12 18:08:42.508122
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """Test for extractor"""

    # Test instantiation of SafariCourseIE class
    # SafariCourseIE only uses override_format in its URI
    ie = SafariCourseIE('safari:course')

    # Test overridden _API_BASE
    ie._API_BASE = 'https://learning.oreilly.com/api/v1'
    # Test overridden _API_FORMAT
    ie._API_FORMAT = 'json'

    # Test method _real_extract
    uri = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    course_id = '9780133392838'
    expected_title = 'Hadoop Fundamentals LiveLessons'

# Generated at 2022-06-12 18:08:43.056326
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-12 18:08:50.232987
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    _, urlh = SafariApiIE._download_webpage_handle(None, url,
                                                   'Downloading api JSON')
    assert urlh.geturl() == 'https://www.safaribooksonline.com/library/view/learning-node-2nd-edition/9781449396459/', 'URL was not modified'
    return urlh.geturl()

# Generated at 2022-06-12 18:08:52.818762
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # this tests whether SafariIE can be instantiated
    # this test is not intended to be run
    SafariIE()


# Generated at 2022-06-12 18:09:32.269572
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from ..compat import compat_urllib_error

    url = 'http://techbus.safaribooksonline.com/9780134426365'
    safari = SafariBaseIE(url)

    assert safari.LOGGED_IN is False

    username, password = safari._get_login_info()
    if username is None:
        return

    safari._login()

    assert safari.LOGGED_IN is True

    safari._real_initialize()

    assert safari._download_webpage('http://www.safaribooksonline.com', None) is not None

# Generated at 2022-06-12 18:09:34.689294
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari = SafariApiIE()
    safari._login()
    assert safari.LOGGED_IN is True

# Generated at 2022-06-12 18:09:36.863007
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = "https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html"
    try:
        SafariApiIE(url)._real_extract(url)
    except:
        raise

# Generated at 2022-06-12 18:09:42.045243
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import json
    import requests
    req = requests.get('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    course_json = json.loads(req.text)
    assert course_json['chapters'][0] == 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'

# Generated at 2022-06-12 18:09:44.004615
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')

# Generated at 2022-06-12 18:09:45.380134
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    cls = SafariCourseIE()
    assert cls.suitable()

# Generated at 2022-06-12 18:09:57.861575
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test protocol agnostic URL
    # Safaribooksonline returns HTTPS URL by redirecting HTTP URL
    # And YoutubeIE also returns HTTPS URL by converting HTTP URL
    ex = SafariIE('http://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')

# Generated at 2022-06-12 18:10:00.227588
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safariBaseIE = SafariBaseIE()
    assert safariBaseIE is not None
    # TODO(jimmcgrath): test class constructor
    return

# Generated at 2022-06-12 18:10:00.606608
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    pass

# Generated at 2022-06-12 18:10:03.062425
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE('http://techbus.safaribooksonline.com/9780134426365')
    SafariCourseIE('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314')


# Generated at 2022-06-12 18:11:12.952189
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    class SafariApiIE_Test(SafariApiIE):
        def __init__(self, course_id):
            super(SafariApiIE_Test, self).__init__({
                'course_id': course_id
            })

    course_id = '9780134664057'
    test = SafariApiIE_Test(course_id)
    assert test.course_id == course_id

# Generated at 2022-06-12 18:11:23.338411
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from ..compat import html_to_clean_dict


# Generated at 2022-06-12 18:11:35.183514
# Unit test for constructor of class SafariIE
def test_SafariIE():
    course_id = '9780133392838'
    reference_id = '9780133392838-00_SeriesIntro'
    video_id = '9780133392838-00_Setup'
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'

# Generated at 2022-06-12 18:11:35.771738
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-12 18:11:41.011117
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    url = 'https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html'
    ie_url = ie._SafariApiIE__real_extract(url)
    assert ie_url.url == 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'

# Generated at 2022-06-12 18:11:49.730010
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from youtube_dl.utils import parse_duration
    from youtube_dl.YoutubeDL import YoutubeDL

    ydl = YoutubeDL({'forcejson': True, 'logger': YoutubeDL.logger.error})
    ie = ydl.extract_info('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html', download=False)
    assert(ie['id'] == ie['ie_key'])
    assert(ie['title'] == ie['display_id'])
    assert(ie['duration'] == parse_duration(ie['duration']))

# Generated at 2022-06-12 18:11:51.233917
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    _obj = SafariBaseIE(None)
    assert isinstance(_obj, SafariBaseIE)

# Generated at 2022-06-12 18:11:54.728641
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .test_utils import check_ie_instance
    ie = SafariIE()
    check_ie_instance(ie, 'safaribooksonline.com')


# Generated at 2022-06-12 18:12:06.345974
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .common import MockIE
    from .test_api import TestApiIE
    import youtube_dl.extractor.safari as safari

    # Mock SafariApiIE._download_json to avoid calling a real API
    # (for example: https://learning.oreilly.com/api/v1/book/9780134664057/)

# Generated at 2022-06-12 18:12:08.570378
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safariApi = SafariApiIE()
    assert type(safariApi) == SafariApiIE

# Generated at 2022-06-12 18:14:58.578314
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    assert SafariApiIE._VALID_URL == SafariApiIE._TESTS[0]['url']
    assert SafariApiIE.suitable(url)

# Generated at 2022-06-12 18:15:00.521910
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE('/')
    return safari_ie.LOGGED_IN


# Generated at 2022-06-12 18:15:07.723849
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    try:
        SafariApiIE(url)
        print("Successfully passed 1st test")
    except:
        print("Failed 1st test")
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    try:
        SafariApiIE(url)
        print("Failed 2nd test")
    except:
        print("Successfully passed 2nd test")

test_SafariApiIE()

# Generated at 2022-06-12 18:15:08.510377
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .safari import SafariIE
    return SafariIE()

# Generated at 2022-06-12 18:15:17.814566
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariBaseIE()

    def my_download_json(*args, **kwargs):
        return 'test.json'
    ie._download_json = my_download_json

    def my_download_webpage(*args, **kwargs):
        return 'test.html', None
    ie._download_webpage = my_download_webpage

    def my_apply_first_set_cookie_header(*args, **kwargs):
        pass
    ie._apply_first_set_cookie_header = my_apply_first_set_cookie_header

    def my_update_url_query(*args, **kwargs):
        return 'test.url'
    ie.url_result = lambda url, ie_key: url
    ie.update_url_query = my_update_url_query


# Generated at 2022-06-12 18:15:22.935542
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    obj = SafariApiIE()
    assert obj._TESTS == [{
        'url': 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json',
        'only_matching': True,
    }], obj._TESTS

# Generated at 2022-06-12 18:15:23.417806
# Unit test for constructor of class SafariIE
def test_SafariIE():
    pass

# Generated at 2022-06-12 18:15:28.507726
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    Course_id = "9780134664057"
    class_SafariBaseIE = SafariBaseIE("SafariBaseIE")
    assert not class_SafariBaseIE.LOGGED_IN
    class_SafariBaseIE._real_initialize()
    assert class_SafariBaseIE.LOGGED_IN


# Generated at 2022-06-12 18:15:31.581326
# Unit test for constructor of class SafariIE
def test_SafariIE():
    with open('safari/test_data/test_download_auth.html', 'rb') as f:
        test_html = f.read().decode()
    r = SafariIE._get_auth_form_data(test_html)
    assert r == {
        'csrfmiddlewaretoken': 'X...0',
        'login': 'qwerty',
        'password': 'qwerty',
    }

# Generated at 2022-06-12 18:15:35.676808
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    inst = SafariApiIE('safari')
    assert isinstance(inst, SafariApiIE)
    assert inst.ie_key() == 'Safari:api'
    assert inst._VALID_URL == SafariApiIE._VALID_URL