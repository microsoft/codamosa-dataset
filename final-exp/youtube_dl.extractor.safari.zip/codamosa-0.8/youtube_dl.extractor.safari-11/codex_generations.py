

# Generated at 2022-06-12 18:07:08.092994
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert SafariApiIE()._VALID_URL == 'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Generated at 2022-06-12 18:07:10.490698
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert isinstance(SafariIE()._login_info(), tuple)

# Test case for constructing SafariCourseIE with URL of SafariIE

# Generated at 2022-06-12 18:07:20.596387
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """
    Method used to run the test cases of the unit test class.
    """
    import sys
    from tests.test_utils import Py2to3TestCase

    # Py2to3TestCase is not used here because it provides the wrong behaviour
    # as SafariCourseIE is supposed to have the same constructor as SafariBaseIE
    # but it also provides some useful tests
    unit_test_class = type(
        'UnitTestClass',
        (Py2to3TestCase,),
        {'concrete_class': SafariCourseIE})
    suite = unittest.TestLoader().loadTestsFromTestCase(unit_test_class)
    results = unittest.TextTestRunner().run(suite)

    if results.wasSuccessful():
        sys.exit(0)
    else:
        sys.exit(1)

# Generated at 2022-06-12 18:07:30.451147
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .test_common import mock_get_files

    with mock_get_files({
        '9781449396459.json': '{"chapters": ["c1", "c2"], "title": "t"}',
    }):
        safari_course_ie = SafariCourseIE()
        test_url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
        test_resp = safari_course_ie._real_extract(test_url)

# Generated at 2022-06-12 18:07:32.333509
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    try:
        # Ensure class has been defined
        SafariBaseIE
    except NameError as e:
        assert False, e

# Generated at 2022-06-12 18:07:36.447533
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    """Test if SafariBaseIE is constructed correctly."""
    ie = SafariBaseIE('SafariBaseIE')
    assert ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert ie._NETRC_MACHINE == 'safari'

# Generated at 2022-06-12 18:07:42.521196
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    SafariCourseIE().suitable(url)
    assert False == SafariIE.suitable(url)
    assert False == SafariApiIE.suitable(url)
    assert True == SafariCourseIE.suitable(url)

# Generated at 2022-06-12 18:07:51.774618
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .test_downloader import FakeYoutubeDL
    from .test_utils import test_playlist_result
    from .kaltura import KalturaIE
    instance = KalturaIE()
    fake_youtube_dl = FakeYoutubeDL({'titles': [
        'Introduction to Hadoop Fundamentals LiveLessons',
        'Hadoop Overview',
        'Working with HDFS',
    ]})
    result = test_playlist_result(
        instance, 'https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html',
        fake_youtube_dl)
    assert result['id'] == '9780133392838'
    assert result['title'] == 'Hadoop Fundamentals LiveLessons'

# Generated at 2022-06-12 18:08:02.958897
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    SafariCourseIE('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    SafariCourseIE('http://techbus.safaribooksonline.com/9780134426365')
    SafariCourseIE('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314')
    SafariCourseIE('https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838')

# Generated at 2022-06-12 18:08:06.535997
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE('www.safaribooksonline.com')
    if ie.IE_NAME != 'safari:course':
        raise AssertionError('IE_NAME has not the expected value')

# Generated at 2022-06-12 18:08:20.810960
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE('Safari')

# Generated at 2022-06-12 18:08:28.078035
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ies = []
    for ie in globals().values():
        if not ie.__bases__:
            continue
        if not SafariBaseIE in ie.__bases__:
            continue
        if ie == SafariBaseIE:
            continue
        ies.append(ie)
    ies.remove(SafariIE)
    ies.remove(SafariApiIE)
    ies.remove(SafariCourseIE)
    for ie in ies:
        ie(SafariBaseIE.ie_key(), {})

# Generated at 2022-06-12 18:08:30.329558
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE('SafariBaseIE')

# Generated at 2022-06-12 18:08:31.855312
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # We can't create SafariBaseIE
    assert SafariBaseIE is not None

# Generated at 2022-06-12 18:08:35.596955
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    SafariApiIE()._real_extract(url)

# Generated at 2022-06-12 18:08:39.127240
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
  assert re.search(SafariCourseIE._VALID_URL, 'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838')

# Generated at 2022-06-12 18:08:40.354917
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    obj = SafariBaseIE()
    assert isinstance(obj, SafariBaseIE)

# Generated at 2022-06-12 18:08:48.167729
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import base64
    import binascii
    import random

    _random_gen = random.Random(5)

    for _ in range(10):
        course_id = 'course-%d' % _random_gen.randint(0, 1000000)
        part = 'part-%x' % _random_gen.randint(0, 1000000)

        url = 'https://www.safaribooksonline.com/api/v1/book/%s/chapter/%s.html' % (course_id, part)
        ie = SafariApiIE(SafariApiIE.IE_NAME, url, {})

        r = _random_gen.randint(0, 2 ** 64 - 1)
        ie._json_ld_cache[course_id] = r

        # check that the cache is used

# Generated at 2022-06-12 18:08:58.604810
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    url = 'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838'
    info = {
        'url': url,
        'md5': 'c7b82ab21c1a9a9a7a0e8dfb75dc5c14',
        'info_dict': {
            'id': '9780133392838',
            'title': 'Hadoop Fundamentals LiveLessons',
        },
        'playlist_count': 22,
        'skip': 'Requires safaribooksonline account credentials',
    }
    instance = SafariCourseIE()
    instance.suitable(url)
    instance.extract(url)

# Generated at 2022-06-12 18:09:03.043289
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    def test_extract_url(url, expected):
        info_dict = {'_type': 'url'}
        safari_base_ie = SafariBaseIE(SafariBaseIE.ie_key())
        safari_base_ie._login = lambda: None
        safari_base_ie.LOGGED_IN = True  # avoid calling safari_base_ie._login

        assert safari_base_ie._real_extract(url) == info_dict
        url_with_token = safari_base_ie._add_skip_wall(url)
        assert url_with_token == expected


# Generated at 2022-06-12 18:09:24.060918
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .common import InfoExtractor

    cls = type('SafariApiIE', (SafariApiIE, InfoExtractor), {})
    obj = cls({})

# Generated at 2022-06-12 18:09:34.777097
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert hasattr(SafariApiIE, 'suitable')
    assert hasattr(SafariApiIE, '_real_extract')
    assert hasattr(SafariApiIE, '_download_webpage_handle')
    assert hasattr(SafariApiIE, '_download_json')
    assert hasattr(SafariApiIE, '_search_regex')
    assert hasattr(SafariApiIE, '_login')
    assert hasattr(SafariApiIE, '_real_initialize')
    assert hasattr(SafariApiIE, '_get_login_info')
    safari_api_ie_instance = SafariApiIE(SafariApiIE.ie_key())

# Generated at 2022-06-12 18:09:36.558256
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert isinstance(SafariCourseIE('SafariCourse'), SafariCourseIE)

# Generated at 2022-06-12 18:09:38.148497
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Constructor shouldn't raise any errors
    SafariApiIE()

# Generated at 2022-06-12 18:09:45.741932
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import io
    import json
    import pycurl

    class MockMultiCurl(object):
        def __init__(self):
            self.buf = io.BytesIO()
            self.resp_headers = []
        def add_handle(self, handle):
            pass
        def remove_handle(self, handle):
            pass
        def getinfo(self, info):
            if info == pycurl.INFO_RESPONSE_CODE:
                return 302
            if info == pycurl.INFO_REDIRECT_URL:
                return 'https://www.oreilly.com/library/view/hadoop-fundamentals-livelessons/9780133392838/00_SeriesIntro.html'
            return None
        def close(self):
            pass
        def perform(self):
            pass


# Generated at 2022-06-12 18:09:47.782932
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-12 18:09:52.652093
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safariIE = SafariCourseIE()
    assert 'safaribooksonline' in safariIE.IE_NAME
    assert 'safaribooksonline.com' in safariIE.IE_DESC
    assert safariIE._VALID_URL
    assert safariIE._TESTS

# Generated at 2022-06-12 18:09:53.358593
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    obj = SafariBaseIE
    SafariBaseIE._login()

# Generated at 2022-06-12 18:10:00.969497
# Unit test for constructor of class SafariIE
def test_SafariIE():
    class_ = SafariIE()
    assert class_._TEMPLATE_URL == 'https://cdnapisec.kaltura.com/html5/html5lib/v2.37.1/mwEmbedFrame.php?wid=_%(partner_id)s&uiconf_id=%(uiconf_id)s&flashvars[referenceId]=%(reference_id)s'
    assert class_._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert class_._API_FORMAT == 'json'

# Generated at 2022-06-12 18:10:03.658124
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_ie = SafariCourseIE(SafariBaseIE)

# Generated at 2022-06-12 18:10:31.926284
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    ie._real_initialize()

# Generated at 2022-06-12 18:10:38.477915
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .. import safari
    part = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    assert(SafariApiIE.suitable(part) is True)
    actual = safari.SafariApiIE()._real_extract(part)
    expected = 'https://www.safaribooksonline.com/library/view/learning-d3js-mapping/9781449339739/part00.html'
    assert(actual['url'] == expected)

# Generated at 2022-06-12 18:10:40.674726
# Unit test for constructor of class SafariIE
def test_SafariIE():
    course_id = 'course_id'
    part = 'part'
    url = 'https://www.safaribooksonline.com/library/view/' + course_id + '/' + part + '.html'

# Generated at 2022-06-12 18:10:43.746131
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class TestSafariIE(SafariBaseIE):
        _VALID_URL = 'http://safaribooksonline.com/some/video/id'
    assert TestSafariIE.suitable('http://safaribooksonline.com/some/video/id')
    assert not TestSafariIE.suitable('http://othrsite.net/some/video/id')

# Generated at 2022-06-12 18:10:47.385569
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from ytdl_safari import SafariBaseIE

    assert hasattr(SafariBaseIE, '_LOGIN_URL')
    assert hasattr(SafariBaseIE, '_NETRC_MACHINE')
    assert hasattr(SafariBaseIE, '_API_BASE')
    assert hasattr(SafariBaseIE, '_API_FORMAT')

    assert hasattr(SafariBaseIE, 'LOGGED_IN')
    assert hasattr(SafariBaseIE, '_real_initialize')
    assert hasattr(SafariBaseIE, '_login')

# Generated at 2022-06-12 18:10:50.379732
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()
    assert isinstance(safari, SafariBaseIE)
    assert isinstance(safari, SafariIE)

# Generated at 2022-06-12 18:10:51.587063
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # make sure that the import doesn't fail
    import safaricompat

# Generated at 2022-06-12 18:10:53.877697
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')

# Generated at 2022-06-12 18:10:56.069697
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    instance = SafariCourseIE('test', 'http://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert instance.name == 'safari:course'

# Generated at 2022-06-12 18:10:57.999421
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert SafariBaseIE(None)._API_BASE == 'https://learning.oreilly.com/api/v1'

# Generated at 2022-06-12 18:11:51.914949
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    # check that there is no exception raised in the constructor
    pass

# Generated at 2022-06-12 18:11:52.819737
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE(None)

# Generated at 2022-06-12 18:11:53.565616
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safariIE = SafariBaseIE(None)

# Generated at 2022-06-12 18:11:54.789652
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """
    Construct an instance of SafariCourseIE and call its test() method.
    """
    SafariCourseIE().test()

# Generated at 2022-06-12 18:11:58.884819
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    try:
        SafariBaseIE._login()
        raise Exception("SafariBaseIE_test: test failed")
    except AssertionError:
        pass
    SafariBaseIE._real_initialize()

# Generated at 2022-06-12 18:12:02.986085
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari = SafariBaseIE()
    assert safari._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari._API_FORMAT == 'json'


# Generated at 2022-06-12 18:12:04.150164
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    pass


# Generated at 2022-06-12 18:12:04.939848
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE('SafariCourse')

# Generated at 2022-06-12 18:12:14.681102
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    test_cases = [
        invalid,
        valid_no_override,
        valid_override,
        valid_no_query,
        valid_override_no_query,
    ]

    for test in test_cases:
        url = test[0]
        mobj = re.match(SafariCourseIE._VALID_URL, url)
        id = mobj.group('id')

        course_json = test[1]

        info_dict = test[2]

        course_url = SafariCourseIE._real_extract(
            SafariCourseIE(), url)

        assert course_url['id'] == info_dict['id']
        assert course_url['title'] == info_dict['title']
        assert len(course_url['entries']) == len(course_json)

# Generated at 2022-06-12 18:12:24.223841
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import os.path

    if not os.path.exists(os.path.join(os.path.dirname(__file__), 'test', 'test.mp4')):
        print('WARNING: Skipping unit test for SafariIE due to missing test video')
        return

    safari = SafariIE()
    course = safari._download_json(
        'https://learning.oreilly.com/api/v1/book/9780134664057/?override_format=json',
        None, 'Downloading course JSON')
    chapter = course['chapters'][0]
    safari._real_extract(chapter['web_url'])

# Generated at 2022-06-12 18:15:05.025179
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Note: SafariIE does not allow direct instantiation,
    #       but only by superclass InfoExtractor.
    ie = InfoExtractor(SafariIE.ie_key())

    # Assert method '_real_initialize' which is called
    # by method '__init__' of superclass InfoExtractor
    # has been overridden.
    if not hasattr(ie, '_real_initialize'):
        assert False

# Generated at 2022-06-12 18:15:05.535336
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    pass

# Generated at 2022-06-12 18:15:09.771232
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safariApiIE = SafariApiIE('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert safariApiIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')



# Generated at 2022-06-12 18:15:12.641371
# Unit test for constructor of class SafariIE
def test_SafariIE():
    is_succeed = True
    try:
        tester = SafariIE()
    except Exception:
        is_succeed = False
    assert is_succeed

# Generated at 2022-06-12 18:15:17.309112
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # test SafariBaseIE constructor
    safari_base_instance = SafariBaseIE(None)
    # assert that safari_base_instance is not None
    assert safari_base_instance is not None
    # assert that safari_base_instance is a subclass of InfoExtractor
    assert safari_base_instance.__class__.__bases__[0] == InfoExtractor


# Generated at 2022-06-12 18:15:18.218892
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()

# Generated at 2022-06-12 18:15:23.180398
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert ie.IE_NAME == 'safari:api'
    assert ie.IE_DESC == 'safaribooksonline.com online video'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'


# Generated at 2022-06-12 18:15:29.132281
# Unit test for constructor of class SafariIE

# Generated at 2022-06-12 18:15:30.020886
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()

# Generated at 2022-06-12 18:15:33.818903
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    obj = SafariBaseIE({})
    if (obj._API_BASE != 'https://learning.oreilly.com/api/v1'):
        raise Exception('SafariBaseIE._API_BASE should be https://learning.oreilly.com/api/v1, but it is %s' % obj._API_BASE)

    if (obj._API_FORMAT != 'json'):
        raise Exception('SafariBaseIE._API_FORMAT should be json, but it is %s' % obj._API_FORMAT)