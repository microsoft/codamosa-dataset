

# Generated at 2022-06-12 18:07:15.146077
# Unit test for constructor of class SafariCourseIE

# Generated at 2022-06-12 18:07:16.249542
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari = SafariApiIE()
    assert safari

# Generated at 2022-06-12 18:07:19.039772
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    try:
        safari = SafariCourseIE()
        safari.to_screen('SafariCourseIE was initialized successfully')
    except Exception:
        raise ExtractorError('SafariCourseIE was not initialized successfully')

# Generated at 2022-06-12 18:07:23.247166
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Initializing SafariBaseIE
    SafariBaseIE(SafariCourseIE)._real_initialize()
    SafariBaseIE(SafariApiIE)._real_initialize()
    SafariBaseIE(SafariIE)._real_initialize()

# Generated at 2022-06-12 18:07:29.839664
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import json
    # this test can be removed when https://github.com/ytdl-org/youtube-dl/pull/15299 is merged
    html_to_parse = '<html><head></head><body><div data-reference-id="e7c145b8-aa84-11e6-b49d-8e8bebe06f7d" data-partner-id="1926081" data-ui-id="29375172" class="kaltura-embed"></div></body></html>'
    tree = json.loads(SafariApiIE._parse_html_webpage(html_to_parse))
    # assert that the parsed json dict is not empty
    assert(tree != {})

# Generated at 2022-06-12 18:07:31.327816
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test if instance can be created
    SafariApiIE()

# Generated at 2022-06-12 18:07:38.323744
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test for valid URL
    instance = SafariApiIE('safari:api', { 'reference_id': '9780134664057-RHCE_Introduction' })
    assert(instance.reference_id == '9780134664057-RHCE_Introduction')

    # Test for invalid URL
    instance = SafariApiIE('safari:api', { 'reference_id': '::1' })
    assert(instance.reference_id == '::1')


# Generated at 2022-06-12 18:07:42.842780
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    course_ie = SafariCourseIE()
    course_ie._real_extract(url)

# Generated at 2022-06-12 18:07:51.701061
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://techbus.safaribooksonline.com/9780134301890'
    course = SafariCourseIE()._real_extract(url)
    assert course['id'] == '9780134301890'
    url = 'https://learning.oreilly.com/library/view/python-programming-language/9780134301890/'
    course = SafariCourseIE()._real_extract(url)
    assert course['id'] == '9780134301890'
    url = 'https://www.safaribooksonline.com/videos/python-programming-language/9780134301890'
    course = SafariCourseIE()._real_extract(url)
    assert course['id'] == '9780134301890'

# Generated at 2022-06-12 18:07:53.706794
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert isinstance(
        SafariCourseIE(
            'SafariCourse',
            'https://www.safaribooksonline.com/api/v1/book/9780134426365'),
        SafariCourseIE)

# Generated at 2022-06-12 18:08:15.321947
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """
    Create instance of SafariApiIE, then check if its value is valid.

    check if its value is valid by accessing some fields
    """
    obj = SafariApiIE()
    assert obj.IE_NAME == 'safari:api'
    assert obj.IE_DESC == 'safaribooksonline.com online courses'
    assert obj._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Generated at 2022-06-12 18:08:22.320222
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    class DummySafariApiIE(SafariApiIE):
        IE_NAME = 'safari:api:dummy'
        _VALID_URL = SafariApiIE._VALID_URL

    ie = DummySafariApiIE()
    assert ie._VALID_URL == SafariApiIE._VALID_URL

# Generated at 2022-06-12 18:08:23.822167
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    sb = SafariBaseIE('safari:course')
    assert sb.LOGGED_IN == False

# Generated at 2022-06-12 18:08:26.890182
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """ Unit test for constructor of class SafariCourseIE """

    inst = SafariCourseIE()
    assert inst._API_BASE == 'https://learning.oreilly.com/api/v1'
    return

# Generated at 2022-06-12 18:08:29.897924
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._NETRC_MACHINE == 'safari'

# Generated at 2022-06-12 18:08:41.910988
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Build a DummyOpener
    from .common import DummyHeaders
    from .common import http_server
    from .common import test_template_url
    from .common import ThreadedHTTPServer
    server = ThreadedHTTPServer(('127.0.0.1', 0), http_server.MyHTTPRequestHandler)

# Generated at 2022-06-12 18:08:52.523255
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    import sys
    import os.path

    assert os.path.isfile(sys.modules[__name__].__file__), 'Test must be run from the directory containing the safari IE module.'

    # Unset HOME environment variable to test the 'Missing login information' error case
    del os.environ['HOME']

    ie = SafariBaseIE()
    ie._real_initialize()
    assert ie.LOGGED_IN == False, 'safari: The test should have failed to log in.'

    os.environ['HOME'] = os.path.dirname(sys.modules[__name__].__file__)
    ie = SafariBaseIE()
    ie._real_initialize()
    assert ie.LOGGED_IN == True, 'safari: The test failed to log in with a netrc file present.'

# Generated at 2022-06-12 18:08:55.108191
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .test_safari import test_SafariCourseIE
    test_SafariCourseIE(SafariCourseIE)

# Generated at 2022-06-12 18:08:55.759171
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-12 18:09:03.561266
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # test_course_id = '9780133392838'
    test_course_id = '9781449396459'
    # test_course_id = '9781449396459'  # Try with actual course_id
    # test_course_id = '9780134217314'  # Try with actual course_id
    # test_course_id = '9780134664057'  # Try with actual course_id
    from . import YDL
    ydl = YDL()
    results = ydl.extract_info('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314', download=False)
    print(results)

# Generated at 2022-06-12 18:09:33.885420
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE("https://www.safaribooksonline.com/videos/python-programming-language/9780134217314")


# Generated at 2022-06-12 18:09:38.923596
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    test_url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    assert resolve_id(test_url) == SafariCourseIE.ie_key()
    assert 'title' in SafariCourseIE()._real_extract(test_url)

# Generated at 2022-06-12 18:09:46.255503
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .common import fake_headers

    safari_course_IE = SafariCourseIE()
    safari_course_IE._request_webpage = lambda url, video_id, note, errnote, fatal=True, headers=None, query={}, data=None: (
        safari_course_IE._download_webpage(url, video_id, note, errnote, fatal=fatal, data=data, query=query, headers=headers), None)

    safari_course_IE._request_json = lambda *a, **kw: (
        safari_course_IE._download_json(*a, **kw), None)

    safari_course_IE._download_json = lambda *a, **kw: (
        '{}', None)
    safari_course_IE._login = lambda: True

    safari_course_IE

# Generated at 2022-06-12 18:09:51.793744
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
# End of unit test for constructor of class SafariBaseIE


# Generated at 2022-06-12 18:10:01.890810
# Unit test for constructor of class SafariIE

# Generated at 2022-06-12 18:10:09.985935
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    parsed_url = compat_urlparse.urlparse(url)
    assert SafariCourseIE.suitable(url)
    test_obj = SafariCourseIE(parsed_url)
    assert test_obj.get_course_id() == '9780133392838'

# Generated at 2022-06-12 18:10:18.331356
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE(None, {})

    ie = SafariCourseIE(None, {
        'start_time': '', 'end_time': '', 'media_type': '', 'thumbnail_url': '',
        'blurb': '', 'alternate_url': '', 'duration': 0, 'transcripts': '',
        'title': '', 'id': '', 'playlist_count': 0,
    })


# Generated at 2022-06-12 18:10:26.740783
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    url = ''
    i = SafariBaseIE()
    assert i._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert i._NETRC_MACHINE == 'safari'
    assert i._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert i._API_FORMAT == 'json'
    assert i.LOGGED_IN is False
    i._real_initialize()
    i._login()
    i._real_extract(url)

# Generated at 2022-06-12 18:10:34.924876
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    test_url = 'https://www.safaribooksonline.com/home/books/9781119061257/chapter-10/ch10lev1sec15_html'
    actual_url = SafariApiIE._build_url(test_url)
    actual_expected_url = 'https://www.safaribooksonline.com/api/v1/book/9781119061257/chapter-content/ch10lev1sec15.html'
    assert actual_url == actual_expected_url

# Generated at 2022-06-12 18:10:36.631040
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert isinstance(SafariCourseIE(), SafariBaseIE)
    assert isinstance(SafariCourseIE(), InfoExtractor)

# Generated at 2022-06-12 18:11:12.061482
# Unit test for constructor of class SafariIE
def test_SafariIE():
    x = SafariIE()
    assert x.IE_DESC == 'safaribooksonline.com online video'
    assert x.IE_NAME == 'safari'

# Generated at 2022-06-12 18:11:19.343210
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from youtube_dl.compat import unittest
    from youtube_dl.extractor import get_info_extractor

    class SafariApiTestCase(unittest.TestCase):

        def setUp(self):
            self.safari_api_ie = get_info_extractor('SafariApi')
            self.safari_api_ie._download_webpage_handle = lambda *args, **kwargs: (None, None)
            self.safari_api_ie._download_json = lambda *args, **kwargs: {'web_url': 'http://web.url'}
            self.safari_api_ie.LOGGED_IN = False


# Generated at 2022-06-12 18:11:23.940647
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    mobj = re.match(SafariApiIE._VALID_URL, url)
    assert mobj.group('course_id') == '9781449396459'
    assert mobj.group('part') == 'part00.html'

# Generated at 2022-06-12 18:11:35.490133
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    def test(url, expected):
        assert SafariCourseIE.suitable(url) == expected

    test('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/', True)
    test('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html', False)
    test('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json', False)
    test('http://techbus.safaribooksonline.com/9780134426365', True)

# Generated at 2022-06-12 18:11:38.989798
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .test_common_ex import _test_generic_ex
    test_SafariApiIE.__doc__ = _test_generic_ex.__doc__
    test_SafariApiIE('safari:api', SafariApiIE, count=1)

# Generated at 2022-06-12 18:11:42.742307
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    config = {}
    config['username'] = "username"
    config['password'] = "password"
    safari_base = SafariBaseIE(config)

# Generated at 2022-06-12 18:11:46.602476
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    '''
    Unit test for constructor of class SafariApiIE.
    '''
    instance = SafariApiIE()
    expected_result = 'safari (safaribooksonline.com online courses)'
    assert instance.IE_DESC == expected_result

# Generated at 2022-06-12 18:11:53.356037
# Unit test for constructor of class SafariIE
def test_SafariIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    x = SafariIE(url)
    assert x.ie_key() == 'SafariIE'
    assert x.ie_name == 'safaribooksonline.com online video'
    assert x.ie_desc == 'safaribooksonline.com online video'
    assert re.match('^' + x._VALID_URL + '$', url)
    return True


# Generated at 2022-06-12 18:11:59.520449
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    import sys
    import platform
    import os

    if 'linux' in platform.system().lower():
        # in case of a linux system
        if sys.version_info[0] < 3:
            # in case of a python 2.x
            try:
                from xdg import BaseDirectory
            except ImportError:
                from xdg.BaseDirectory import save_config_path
                BaseDirectory = save_config_path
        else:
            try:
                from xdg import BaseDirectory
            except ImportError:
                from xdg.BaseDirectory import xdg_config_home
                BaseDirectory = xdg_config_home

        # finding location of netrc
        NETRC = os.path.join(BaseDirectory.save_config_path('safari-dl'), 'netrc')

# Generated at 2022-06-12 18:12:00.272144
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()

# Generated at 2022-06-12 18:12:36.808793
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    module = 'safari'
    config = {
        'extractors': '%s:%s' % (module, SafariApiIE.ie_key())
    }
    ie = get_info_extractor(config=config, ie=module)
    assert isinstance(ie, SafariApiIE)

# Generated at 2022-06-12 18:12:40.473242
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    courseIE = SafariCourseIE('safari', {})
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    courseIE._real_extract(url)

# Generated at 2022-06-12 18:12:41.121919
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-12 18:12:41.979064
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
	SafariApiIE('test')

# Generated at 2022-06-12 18:12:43.150443
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

test_SafariApiIE()

# Generated at 2022-06-12 18:12:52.056218
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .test_safari import test_SafariIE
    testSafariIE = test_SafariIE()
    # testing for SafariIE._real_initialize()
    # testing for SafariIE._login()
    testSafariIE._test_login('test_SafariIE.py', 'test_SafariIE_') # test for SafariIE._test_login()
    assert testSafariIE.LOGGED_IN == True # test for SafariIE.LOGGED_IN
    # test for SafariIE._real_extract()
    testSafariIE._test_real_extract('test_SafariIE.py', 'test_SafariIE_')
    # testing for SafariApiIE._real_extract()

# Generated at 2022-06-12 18:12:53.337306
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    obj = object.__new__(ie.__class__)
    ie.__init__(obj)
    return True

# Generated at 2022-06-12 18:12:57.006591
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    try:
        SafariBaseIE('username', 'password')
    except (AttributeError, TypeError):
        pass

# Generated at 2022-06-12 18:13:03.626654
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test constructor with one valid and one invalid URL
    course_info_extractor = SafariCourseIE(
        [
            'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/',
            'https://www.safaribooksonline.com/library/view/something/9780133392838/'
        ])
    assert course_info_extractor.SUCCESS == 2
    assert course_info_extractor.FAILED == 0
    assert course_info_extractor.EXCEPTION == 0
    assert course_info_extractor.total_items == 2

    # Test constructor with one valid and one invalid URL

# Generated at 2022-06-12 18:13:09.825862
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE(SafariIE._create_ie_instance())
    assert ie._VALID_URL == r'''
                            https?://
                                (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                                (?:
                                    library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                    videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                                )
                        '''.strip()
    assert ie.IE_NAME == 'safari'
    assert ie.IE_DESC == 'safaribooksonline.com online video'


# Generated at 2022-06-12 18:14:35.969061
# Unit test for constructor of class SafariIE
def test_SafariIE():
    url = "https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html"
    expected = {
        'id': '0_qbqx90ic',
        'ext': 'mp4',
        'title': 'Introduction to Hadoop Fundamentals LiveLessons',
        'timestamp': 1437758058,
        'upload_date': '20150724',
        'uploader_id': 'stork',
    }
    _, ie = SafariIE._download_webpage_handle(url, None)
    assert ie.extract(url) == expected

# Generated at 2022-06-12 18:14:37.811510
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    # Assert that _real_initialize() has been called exactly once
    assert ie.LOGGED_IN is True

# Generated at 2022-06-12 18:14:39.276798
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.ie_key() == 'Kaltura'
    assert ie.LOGGED_IN == False


# Generated at 2022-06-12 18:14:50.656747
# Unit test for constructor of class SafariIE

# Generated at 2022-06-12 18:14:53.281920
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    ie._real_extract('https://www.safaribooksonline.com/api/v1/book/9781449396459')

# Generated at 2022-06-12 18:14:59.127096
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .test_SafariIE import SafariTest
    e = SafariApiIE()
    test = SafariTest()
    test.initialize()
    e.initialize()
    assert e._LOGIN_URL == test._LOGIN_URL
    assert e._NETRC_MACHINE == test._NETRC_MACHINE
    assert e._API_BASE == test._API_BASE
    assert e._API_FORMAT == test._API_FORMAT
    assert e.LOGGED_IN == test.LOGGED_IN

# Generated at 2022-06-12 18:15:07.933916
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert SafariIE._VALID_URL == r'(?x)https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/library/view/[^/]+/[^/]+/(?P<part>[^/?#&]+)\.html'

    # instance of class SafariIE
    safari = SafariIE()

    assert safari._VALID_URL == SafariIE._VALID_URL

    # instance of class SafariApiIE
    safariApi = SafariApiIE()

    assert safariApi._VALID_URL == SafariApiIE._VALID_URL

    # instance of class SafariCourseIE
    safariCourse = SafariCourseIE()

    assert safariCourse._VALID_URL == SafariCourseIE._VALID_URL


# Generated at 2022-06-12 18:15:09.508811
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/sql-antipatterns/9781449311452/'
    SafariCourseIE(url, {})

# Generated at 2022-06-12 18:15:10.088828
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-12 18:15:14.333492
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """
    Unit test for constructor of class SafariApiIE
    """
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    SafariApiIE(url, 'SafariApiIE')
