

# Generated at 2022-06-12 18:07:13.442547
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    yt_src = (
        '{"web_url": "https://www.safaribooksonline.com/library/view/javascript-patterns/9781449331818/part00.html", '
        '"titl": "Javascript Patterns", '
        '"chapte": "part00", '
        '"part_id": "9781449331818-part00"}')
    ie_src = SafariApiIE()
    expected_pl = {
        'id': '9781449331818/part00',
        '_type': 'url',
        'ie_key': 'Safari',
        'url': 'https://www.safaribooksonline.com/library/view/javascript-patterns/9781449331818/part00.html'
    }

# Generated at 2022-06-12 18:07:19.610220
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert(SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json') == False)
    assert(SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/') == False)

# Generated at 2022-06-12 18:07:26.145664
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    safari_ie._TEST = True
    safari_ie._login()
    safari_ie._real_extract('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314/9780134217314-PYMC_13_00')

if __name__ == '__main__':
    test_SafariIE()

# Generated at 2022-06-12 18:07:28.903474
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .test_common import TestCommon
    from .test_safari import safari_test
    TestCommon.test_SafariCourseIE(SafariCourseIE, safari_test)

# Generated at 2022-06-12 18:07:31.766668
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = "https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json"
    SafariCourseIE()._real_initialize()
    SafariCourseIE()._real_extract(url)

# Generated at 2022-06-12 18:07:33.947605
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    target = SafariApiIE()
    assert target.IE_NAME == 'safari:api'

# Generated at 2022-06-12 18:07:39.934025
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert ('https://learning.oreilly.com/accounts/login/'
            == SafariBaseIE._LOGIN_URL)
    assert ('https://learning.oreilly.com/api/v1'
            == SafariBaseIE._API_BASE)
    assert ('json' == SafariBaseIE._API_FORMAT)
    assert (False == SafariBaseIE.LOGGED_IN)
    return True

# Generated at 2022-06-12 18:07:47.981445
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    s_course = SafariCourseIE()
    assert not s_course.LOGGED_IN
    assert s_course._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'
    assert s_course.IE_NAME == 'safari:course'
    assert s_course.IE_DESC == 'safaribooksonline.com online courses'

# Generated at 2022-06-12 18:07:50.008017
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_ie = SafariCourseIE()
    assert safari_course_ie.IE_NAME == 'safari:course'
    assert safari_course_ie.IE_DESC == 'safaribooksonline.com online courses'

# Generated at 2022-06-12 18:07:50.943049
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    api_instance = SafariApiIE()
    assert(api_instance.IE_NAME)

# Generated at 2022-06-12 18:08:17.131632
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-12 18:08:28.625187
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'

    # empty expected_entries
    expected_entries = []
    expected_result = {
        '_type': 'url_transparent',
        'id': '9781449396459/01.01',
        'url': 'https://www.safaribooksonline.com/library/view/scala-by-example/9781449396459/01_01.html',
        'ie_key': 'SafariIE'
    }
    safari_api_ie = SafariApiIE(expected_entries)
    SafariApiIE.ie_key()
    SafariApiIE._VALID_URL
    result = safari_api_ie.ext

# Generated at 2022-06-12 18:08:35.536122
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE("https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/ch01.html")
    safari_api_ie.extract("https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/ch01.html")

# Generated at 2022-06-12 18:08:45.856638
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    import os
    import tempfile
    import unittest
    import urllib.parse

    from ..utils import (
        is_hidden_path,
        url_basename,
    )

    def _urlslashjoin(*args):
        return urllib.parse.urljoin('/', '/'.join(args))

    class TestSafariCourseIE(unittest.TestCase):
        def test_safari_course_ie_constructor(self):
            with tempfile.TemporaryDirectory() as temp_dir:
                safari_course_ie = SafariCourseIE(temp_dir)

                self.assertEqual(safari_course_ie.ie_key(), 'SafariCourse')
                self.assertEqual(safari_course_ie.ie_name, 'safari:course')

# Generated at 2022-06-12 18:08:47.089902
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()
    SafariApiIE()
    SafariCourseIE()

# Generated at 2022-06-12 18:08:49.728971
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert SafariCourseIE.suitable(SafariIE(None)._VALID_URL) is False

# Generated at 2022-06-12 18:08:59.588347
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safarie = SafariIE()
    assert safarie.IE_NAME == 'safari'
    assert safarie.IE_DESC == 'safaribooksonline.com online video'
    assert safarie._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''

# Generated at 2022-06-12 18:09:00.865138
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Check if constructor is ok
    try:
        SafariBaseIE()
    except:
        raise AssertionError('SafariBaseIE constructor failed')


# Generated at 2022-06-12 18:09:01.412479
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    e = SafariBaseIE()

# Generated at 2022-06-12 18:09:03.195701
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE('')
    assert ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'

# Generated at 2022-06-12 18:09:58.556155
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'

# Generated at 2022-06-12 18:10:01.855282
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """
    Run constructor test of class SafariIE
    """
    try:
        # Create object
        test_object = SafariIE()
    except:
        assert False, "Test of constructor of SafariIE failed"


# Generated at 2022-06-12 18:10:04.895853
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_ie = SafariBaseIE()
    assert safari_ie._NETRC_MACHINE == "safari"

# Generated at 2022-06-12 18:10:11.151942
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part01.html'
    ie = SafariApiIE()
    new_url = ie.url_result(url, 'Safari', 'Part 1 of Hadoop Fundamentals LiveLessons')
    assert new_url.geturl() is not None, 'Pass'

# Generated at 2022-06-12 18:10:12.778548
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE(SafariBaseIE(), '')

# Generated at 2022-06-12 18:10:13.817206
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE("__main__")

# Generated at 2022-06-12 18:10:24.989279
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .test_kaltura import KalturaIE_TEST
    from .cached_webkit import SafariMiniBrowser

    safari = SafariApiIE(SafariMiniBrowser)
    kaltura = KalturaIE_TEST()

    # Because SafariMiniBrowser is not real browser, it cannot do GET/POST requests
    # So we have to override _download_json to make it behave like SafariApiIE
    # (we use _real_download_json to save original behavior)
    safari._download_json = lambda *args, **kwargs: safari._real_download_json(
        *args, transform_source=safari._convert_source, **kwargs)

    # We need one more hack to fool KalturaIE
    # It expects to get 'ks' (kaltura session) from _download_json
   

# Generated at 2022-06-12 18:10:27.403447
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():

    raise SkipTest(
        'The SafariApiIE is not tested and it can only get resources that'
        ' require account credentials. Therefore, we skip.'
    )

# Generated at 2022-06-12 18:10:33.646527
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    try:
        with open(os.devnull, 'w') as devnull:
            subprocess.check_call(['which', 'ffmpeg'], stdout=devnull, stderr=devnull)
    except subprocess.CalledProcessError:
        document_object_model = 'https://www.safaribooksonline.com/library/view/unix-and-linux/0596009659/part00.html'
        # ffmpeg is required to download safaribooksonline.com online video
        assert SafariCourseIE(document_object_model) != None
    else:
        document_object_model = 'https://www.safaribooksonline.com/library/view/unix-and-linux/0596009659/part00.html'

# Generated at 2022-06-12 18:10:36.482403
# Unit test for constructor of class SafariIE
def test_SafariIE():
    url = "https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html"
    SafariIE()._real_extract(url)

# Generated at 2022-06-12 18:11:39.623720
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    a = SafariApiIE()
    assert a._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert a._NETRC_MACHINE == 'safari'
    assert a._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert a._API_FORMAT == 'json'

# Generated at 2022-06-12 18:11:46.842773
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    assert ie.get_output_dir()
    assert ie.get_device_capabilities()
    assert ie.get_device_settings(None)
    assert ie.get_device_settings('http://techbus.safaribooksonline.com/9780134426365')
    assert ie.get_player_settings()
    assert ie.get_player_type()
    assert ie.get_player_info()

# Generated at 2022-06-12 18:11:57.371783
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    test_cases = [
        ('https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html',
         '9781449396459', 'part00'),
        ('https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter-content/part01.html',
         '9781449396459', 'part01'),
    ]
    for input_url, expected_course_id, expected_part_name in test_cases:
        course_id, part_name = SafariApiIE._extract_url(input_url)
        assert course_id == expected_course_id
        assert part_name == expected_part_name

# Generated at 2022-06-12 18:12:08.289881
# Unit test for constructor of class SafariIE
def test_SafariIE():
    url = 'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838/9780133392838-00_SeriesIntro'
    course_id = '9780133392838'
    part = '9780133392838-00_SeriesIntro'

# Generated at 2022-06-12 18:12:10.949848
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    course_id = '9781449396459'
    course = SafariCourseIE(url)
    assert course.course_id == course_id

# Generated at 2022-06-12 18:12:12.004437
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE('safari:api')
    assert ie.ie_key() == 'safari'

# Generated at 2022-06-12 18:12:13.673434
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    s = SafariCourseIE()
    s._real_initialize()
    assert isinstance(s, SafariCourseIE)

# Generated at 2022-06-12 18:12:24.844355
# Unit test for constructor of class SafariApiIE

# Generated at 2022-06-12 18:12:25.865712
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    ie._real_initialize()

# Generated at 2022-06-12 18:12:30.153283
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    kaltura = safari.extract()

    print(kaltura)
    print('Test passed')


# Generated at 2022-06-12 18:15:07.724511
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    safari_ie._login()
    # assert safari_ie.LOGGED_IN is True



# Generated at 2022-06-12 18:15:12.808974
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    info_extractor = SafariCourseIE('SafariCourse')

    assert info_extractor.IE_NAME == 'safari:course'
    assert info_extractor.IE_DESC == 'safaribooksonline.com online courses'
    assert info_extractor._VALID_URL == r'''(?x)
                    https?://
                        (?:
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+|
                                api/v1/book|
                                videos/[^/]+
                            )|
                            techbus\.safaribooksonline\.com
                        )
                        /(?P<id>[^/]+)
                    '''
    assert info_extractor

# Generated at 2022-06-12 18:15:14.374477
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safariIE = SafariIE(None)
    assert safariIE.LOGGED_IN == False

# Generated at 2022-06-12 18:15:16.284838
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    """
    >>> SafariBaseIE._LOGIN_URL
    'https://learning.oreilly.com/accounts/login/'
    """
    pass

# Generated at 2022-06-12 18:15:17.460692
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()


# Generated at 2022-06-12 18:15:19.586067
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """Unit test for constructor of SafariCourseIE"""
    safari_course_ie = SafariCourseIE()
    assert safari_course_ie.IE_NAME == "safari:course"

# Generated at 2022-06-12 18:15:26.198963
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert SafariApiIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert SafariApiIE.suitable('https://techbus.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert SafariApiIE.suitable('https://learning.oreilly.com/api/v1/book/9781449396459/?override_format=json')
    assert not SafariApiIE.suitable('https://www.safaribooksonline.com')
    assert not SafariApiIE.suitable('https://www.safaribooksonline.com/')

# Generated at 2022-06-12 18:15:27.597701
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    assert ie.ie_key() == 'Safari'


# Generated at 2022-06-12 18:15:32.520413
# Unit test for constructor of class SafariIE
def test_SafariIE():
    class MockSafariIE(SafariIE):
        def _download_webpage_handle(self, url_or_request, video_id, note, errnote, fatal=True, query={}, headers={}, data=None, retries=0, follow_redirect=True, expected_status=None, timeout=None):
            return compat_urllib_request.urlopen(url_or_request), url_or_request

    MockSafariIE('', {})._real_initialize()


# Generated at 2022-06-12 18:15:41.233903
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import unittest
    import sys

    class TestSafariIE(unittest.TestCase):
        def test_class_creation_with_valid_url(self):
            """
            Validate that creating instance of class with valid URL doesn't throw exceptions
            """
            valid_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
            try:
                parser = SafariIE(valid_url)
            except Exception:
                self.fail('Wrong exception was thrown while creating instance of class with valid URL')
            else:
                self.assertIsInstance(parser, SafariIE)
