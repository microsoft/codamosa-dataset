

# Generated at 2022-06-12 18:07:15.146129
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE('http://techbus.safaribooksonline.com/sample/9780134426365/9780134426365-00_SeriesIntro_clip2/')
    assert safari_ie._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''
    assert safari_ie._NETRC_M

# Generated at 2022-06-12 18:07:16.565645
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    print (ie.IE_DESC)

# Generated at 2022-06-12 18:07:22.898684
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .. import main
    from .common import test_ie_count, test_template_extraction, test_extractor_invalid_url
    test_ie_count(SafariIE.ie_key())
    test_template_extraction(SafariIE.ie_key())
    test_template_extraction(SafariApiIE.ie_key())
    test_extractor_invalid_url(main, SafariIE.ie_key(), 'SafariIE')
    test_extractor_invalid_url(main, SafariCourseIE.ie_key(), 'SafariCourseIE')

# Generated at 2022-06-12 18:07:24.763547
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    s = SafariBaseIE()
    assert isinstance(s, SafariBaseIE)

# Unit tests for class SafariIE

# Generated at 2022-06-12 18:07:26.844528
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert SafariBaseIE('username', 'password')

test_SafariBaseIE.skip = 'Requires safaribooksonline account credentials'

# Generated at 2022-06-12 18:07:29.644568
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """
    test_SafariIE class

    """

    # Given

    # When
    safari_instance = SafariBaseIE()

    # Then

    # Verify
    assert safari_instance.ie_key() == 'Safari:API'

# Generated at 2022-06-12 18:07:33.781122
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    SafariApiIE().suitable(url) is True
    # SafaruCourseIE is not suitable, so it shouldn't be able to create an instance
    SafariCourseIE().suitable(url) is False
    # SafariIE is suitable, so it should be able to create an instance
    SafariIE().suitable(url) is True

# Generated at 2022-06-12 18:07:34.401081
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert SafariIE()

# Generated at 2022-06-12 18:07:44.593898
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    test_url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    obj = SafariCourseIE()
    assert obj.IE_NAME == 'safari:course'
    assert obj._VALID_URL == 'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'
    assert obj.suitable(test_url) == True
    assert obj.IE_DESC == 'safaribooksonline.com online courses'

# Generated at 2022-06-12 18:07:46.946019
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    try:
        test_Login = SafariBaseIE('test', 'test')
        assert test_Login is not None
    except:
        assert False

# Generated at 2022-06-12 18:08:19.877283
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # test unkown url
    with pytest.raises(ExtractorError):
        ie = SafariIE('http://www.safaribooksonline.com/library/view/hp-ux-certification/0201712300/part00.html')
    # test file url
    with pytest.raises(ExtractorError):
        ie = SafariIE('/tmp/test.mp4')
    # test http(s) url
    ie = SafariIE('https://www.safaribooksonline.com/library/view/hp-ux-certification/0201712300/part00.html')
    assert ie.SUFFIX == ' (safaribooksonline)'
    assert ie.IE_NAME == 'safari'
    assert ie.IE_DESC == 'safaribooksonline.com online video'


# Generated at 2022-06-12 18:08:22.880278
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # If it is not a subclass of InfoExtractor then test will fail
    assert issubclass(SafariCourseIE, InfoExtractor)

# Generated at 2022-06-12 18:08:23.876468
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE('safari')
    assert ie is not None

# Generated at 2022-06-12 18:08:25.134984
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie_obj = SafariCourseIE()

# Generated at 2022-06-12 18:08:28.442769
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.IE_NAME == 'safari'
    assert ie.IE_DESC == 'safaribooksonline.com online video'


# Generated at 2022-06-12 18:08:34.977464
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = "https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part05.html"
    # Create the instance 
    safari_api_ie = SafariApiIE()
    safari_api_ie.url_result(url, 'SafariIE.ie_key()')

# Generated at 2022-06-12 18:08:45.500375
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_apiie = SafariApiIE("http://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json")
    course_id = safari_apiie._match_id("http://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json")
    assert course_id == "9781449396459"
    course_json = safari_apiie._download_json(
            '%s/book/%s/?override_format=%s' % (safari_apiie._API_BASE, course_id, safari_apiie._API_FORMAT),
            course_id, 'Downloading course JSON')
    assert course_json['title'] == 'Impact Mapping'

# Generated at 2022-06-12 18:08:46.633142
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert isinstance(SafariApiIE(), SafariBaseIE)

# Generated at 2022-06-12 18:08:52.061253
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    url = 'https://www.safaribooksonline.com/library/view/agile-web-development/9781937785567/'
    safari_base_ie = SafariBaseIE()
    # The following calls two methods
    safari_base_ie._real_extract(url)

# Generated at 2022-06-12 18:08:53.504669
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.IE_NAME == 'safari'

# Generated at 2022-06-12 18:09:51.507812
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import unittest

    class SafariIETest(unittest.TestCase):
        def setUp(self):
            self.ie = SafariIE()
            self.ie.LOGGED_IN = False

    return SafariIETest

# Generated at 2022-06-12 18:09:53.846605
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari = SafariApiIE()
    assert safari._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari._API_FORMAT == 'json'

# Generated at 2022-06-12 18:10:01.099790
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'

    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'

    assert safari_base_ie.LOGGED_IN == False



# Generated at 2022-06-12 18:10:04.000886
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    obj = SafariBaseIE()
    assert type(obj) == SafariBaseIE

# Generated at 2022-06-12 18:10:15.534698
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    try:
        from ytdl.extractor.safari import (
            SafariCourseIE,
            SafariIE,
            SafariApiIE,
        )
    except ImportError:
        return
    # Test that instances of SafariCourseIE are created
    # when the class is called with a suitable url
    SafariCourseIE(
        {
            'ie_key': 'SafariCourse',
            'url':
                'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/',
        })
    # Test that instances of SafariCourseIE are _not_ created
    # when the class is called with a URL that is not suitable
    # for SafariCourseIE

# Generated at 2022-06-12 18:10:27.004233
# Unit test for constructor of class SafariIE

# Generated at 2022-06-12 18:10:30.160368
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # First test with credentials in settings
    ie = SafariIE()
    assert ie.username == 'a'
    assert ie.password == 'b'

    # Second test with credentials as input
    ie = SafariIE(username='c', password='d')
    assert ie.username == 'c'
    assert ie.password == 'd'

# Generated at 2022-06-12 18:10:39.462913
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    try:
        from ..utils import cache
        from ..utils import fake_httpd
    except Exception as ex:
        raise ValueError("Failed to import test fixtures: %s" % ex)
    fake_httpd.start_server()
    course_id = "mock-course"

# Generated at 2022-06-12 18:10:40.904314
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Instance construction test
    ie = SafariApiIE()
    assert ie.IE_NAME == 'safari:api'
    assert ie.IE_DESC == 'safaribooksonline.com online courses'

# Generated at 2022-06-12 18:10:41.880834
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # No need to login to test SafariApiIE
    login = False
    ie = SafariApiIE(login)



# Generated at 2022-06-12 18:11:47.967991
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'

    expected = (
        'https://www.safaribooksonline.com/library/view/practical-data-science/9781449396459/part00.html',
        'Kaltura'
    )

    assert expected == SafariApiIE()._real_extract(url)

# Generated at 2022-06-12 18:11:49.730476
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('/api/v1/book/9781449396459/chapter-content/ch01.html')

# Generated at 2022-06-12 18:11:50.624371
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE(None)

# Generated at 2022-06-12 18:11:51.984442
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Has login info in _NETRC_MACHINE, so no error raised
    assert not SafariBaseIE._login()

# Generated at 2022-06-12 18:11:53.179438
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    instance = SafariBaseIE()
    assert isinstance(instance, SafariBaseIE)

# Generated at 2022-06-12 18:11:54.692774
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test that SafariIE can be instantiated
    try:
        SafariIE()
    except:
        assert False, 'Failed to instantiate SafariIE'

# Generated at 2022-06-12 18:12:00.030573
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?#&]+)|videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?#&]))'
    assert ie._PARTNER_ID == '1926081'
    assert ie._UICONF_ID == '29375172'


# Generated at 2022-06-12 18:12:01.359740
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    a = SafariCourseIE()
    # Should not raise an error
    pass

# Generated at 2022-06-12 18:12:05.272738
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    c = SafariBaseIE(None)
    assert c.LOGGED_IN is False
    assert c.username is None
    assert c.password is None
    assert c._login_token is None
    assert c._login_form is None

# Generated at 2022-06-12 18:12:09.980418
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # url given in constructor must agree with path given in extractor
    assert SafariBaseIE._VALID_URL is None
    extractor = SafariBaseIE('SafariBaseIE', 'SafariBaseIE.ie_key')
    assert 'http://www.safaribooksonline.com/' in extractor._VALID_URL

# Generated at 2022-06-12 18:14:51.104429
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/data-science-from/9781491901410/') # test suitable function
    SafariCourseIE('https://www.safaribooksonline.com/library/view/data-science-from/9781491901410/') # test constructor

# Generated at 2022-06-12 18:14:52.260621
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """test SafariApiIE's constructor"""
    SafariApiIE(SafariIE())

# Generated at 2022-06-12 18:14:54.984593
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    #  test with an invalid url in constructor
    #  test with a valid url but with wrong credentials
    #  test with a valid url and valid credentials
    pass

# Generated at 2022-06-12 18:15:03.982114
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import json

    class SampleSafariIE(SafariApiIE):
        def _real_extract(self, url):
            return self._download_json(url, '', 'Downloading JSON')

    sample = (
        'https://www.safaribooksonline.com/api/v1/book/'
        '9780133392838/chapter/part00.html')
    expected = {
        'web_url': 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html',
        'description': '',
        'id': '0_qbqx90ic',
    }

# Generated at 2022-06-12 18:15:10.786526
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from safari_tests import valid_user

    (username, password) = valid_user()

    # nothing should happen
    safari_base_ie = SafariBaseIE()
    safari_base_ie._login()

    # should throw an error
    from safari_tests import valid_invalid_user
    (username, password) = valid_invalid_user()

    safari_base_ie = SafariBaseIE()
    safari_base_ie._downloader.params['username'] = username
    safari_base_ie._downloader.params['password'] = password

    try:
        safari_base_ie._login()
    except ExtractorError as e:
        return
    assert False

# Generated at 2022-06-12 18:15:13.156557
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()
    assert safari_api_ie is not None


# Generated at 2022-06-12 18:15:19.768662
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """Unit test for __init__"""
    safari_ie = SafariIE("https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html")
    assert 'SafariIE' == safari_ie.name
    assert 'safaribooksonline.com online video' == safari_ie.description
    assert 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html' == safari_ie.url

# Generated at 2022-06-12 18:15:31.158802
# Unit test for constructor of class SafariIE
def test_SafariIE():
    get_testcases_SafariIE = [
        {
            'in': 'https://www.safaribooksonline.com/library/view/python-playground/9781491923159/ch04.html',
            'out': True
        }, {
            'in': 'https://www.safaribooksonline.com/library/view/machine-learning-with/9781787285686/',
            'out': True
        }, {
            'in': 'https://www.safaribooksonline.com/library/view/python-2-3/9780134128894/',
            'out': False
        }
    ]
    for testcase in get_testcases_SafariIE:
        assert test_SafariIE(testcase['in']) == testcase['out']



# Generated at 2022-06-12 18:15:40.593760
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course_id = "12345"
    course_title = "A Sample Course"
    course_json = {
        'title': course_title,
        'chapters': [
            '%s/api/v1/book/%s/chapter/part01.html' % (SafariBaseIE._API_BASE, course_id),
            '%s/api/v1/book/%s/chapter/part02.html' % (SafariBaseIE._API_BASE, course_id),
            '%s/api/v1/book/%s/chapter/part03.html' % (SafariBaseIE._API_BASE, course_id),
        ]
    }

    # Mock up an extractor object.

# Generated at 2022-06-12 18:15:43.595836
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    # SafariApiIE(url) should be called by SafariCourseIE(url)
    instance = SafariCourseIE(url)
    assert isinstance(instance, SafariApiIE)