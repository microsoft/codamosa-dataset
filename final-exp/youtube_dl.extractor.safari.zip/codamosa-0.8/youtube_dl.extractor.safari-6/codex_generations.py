

# Generated at 2022-06-12 18:07:13.400152
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    test = SafariCourseIE(url)
    assert test.IE_NAME == 'safari:course'
    assert test.IE_DESC == 'safaribooksonline.com online courses'

# Generated at 2022-06-12 18:07:22.621975
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    if not getattr(SafariBaseIE, '_download_webpage_handle', None):
        return
    with open('tests/resources/safaribooksonline/safari-login-page.html', 'rb') as f:
        login_page_html = f.read()
    with open('tests/resources/safaribooksonline/safari-login-response.html', 'rb') as f:
        login_response_html = f.read()
    with open('tests/resources/safaribooksonline/safari-kaltura-session-json.json', 'rb') as f:
        kaltura_session_json = f.read()
    webpage_url = 'https://www.safaribooksonline.com/accounts/login/'

# Generated at 2022-06-12 18:07:23.684301
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()

# Generated at 2022-06-12 18:07:25.478328
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """Test constructor of class SafariApiIE"""

    assert issubclass(SafariApiIE, SafariBaseIE)

# Generated at 2022-06-12 18:07:29.267996
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    try:
        import netrc
        netrc.netrc().get_host_and_login(SafariBaseIE._NETRC_MACHINE)
    except (OSError, IOError):
        raise Exception('Must provide a .netrc file.')
    ie = SafariBaseIE()
    ie._login()

# Generated at 2022-06-12 18:07:34.437186
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test for the case when username and password is not provided
    safari_base_ie = SafariBaseIE({})
    safari_base_ie.LOGGED_IN is False

    # Test for the case when username and password is provided
    safari_base_ie = SafariBaseIE({'username': 'abcd', 'password': 'efgh'})
    safari_base_ie.LOGGED_IN is True

# Generated at 2022-06-12 18:07:38.377612
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838'
    # Instantiate with URL only
    SafariCourseIE(url)


# Generated at 2022-06-12 18:07:49.066574
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE(SafariApiIE.ie_key())

    assert ie.IE_NAME == 'safari:api'
    assert ie.IE_DESC == 'safaribooksonline.com online video'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Generated at 2022-06-12 18:07:54.426871
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    try:
        SafariBaseIE()
        assert False, 'Expected not having credentials'
    except ExtractorError as e:
        assert 'No login info available' in str(e)
    try:
        SafariBaseIE(username='user')
        assert False, 'Expected not having credentials'
    except ExtractorError as e:
        assert 'No password available' in str(e)

    try:
        SafariBaseIE(username='user', password='pass')
        assert False, 'Expected not having credentials'
    except ExtractorError as e:
        assert 'Unable to log in' in str(e)

# Generated at 2022-06-12 18:08:00.109584
# Unit test for constructor of class SafariIE
def test_SafariIE():
    inst = SafariIE("")
    assert inst.LOGGED_IN == False
    assert inst._LOGIN_URL == "https://learning.oreilly.com/accounts/login/"
    assert inst._NETRC_MACHINE == "safari"

if __name__ == '__main__':
    test_SafariIE()

# Generated at 2022-06-12 18:08:19.044549
# Unit test for constructor of class SafariIE
def test_SafariIE():
    expected_ie_key_value = 'safari'
    expected_ie_desc_value = 'safaribooksonline.com online video'
    expected_valid_url_value = r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/library/view/[^/]+/[^/]+/(?P<part>[^/?\#&]+)\.html'

    assert SafariIE.ie_key() == expected_ie_key_value
    assert SafariIE.ie_desc() == expected_ie_desc_value
    assert SafariIE._VALID_URL == expected_valid_url_value


# Generated at 2022-06-12 18:08:25.300408
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    assert SafariCourseIE.suitable(url)
    safaricourse_ie = SafariCourseIE(url)
    assert isinstance(safaricourse_ie, SafariCourseIE)

# Generated at 2022-06-12 18:08:26.273146
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()


# Generated at 2022-06-12 18:08:39.025992
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """Unit test for constructor of class SafariIE"""
    # Setup parameters
    url = 'https://www.safaribooksonline.com/library/view/learning-path-red/9780134664057/RHCE_Introduction.html'
    # Get instance of SafariIE
    safari = SafariIE()
    # Asserts
    assert safari._VALID_URL == 'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?#&]+)\.(?:html|xhtml)|videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?#&]+))'
    assert safari.su

# Generated at 2022-06-12 18:08:39.974960
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('safari:api')

# Generated at 2022-06-12 18:08:42.014116
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE('test')
    assert safari_ie.LOGGED_IN == False

# Generated at 2022-06-12 18:08:46.614902
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert SafariApiIE.__name__ == 'SafariApiIE'
    assert SafariApiIE.ie_key() == 'SafariApi'
    assert SafariApiIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json') is True
    assert SafariApiIE.suitable('http://techbus.safaribooksonline.com/9780134426365') is False

# Generated at 2022-06-12 18:08:50.437388
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari = SafariBaseIE()
    assert safari._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari._API_FORMAT == 'json'

# Generated at 2022-06-12 18:08:53.696892
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .invalid_ie import DummyIE
    ie = DummyIE(SafariIE.IE_NAME, SafariIE.IE_DESC, {})
    assert ie.__class__ == SafariIE


# Generated at 2022-06-12 18:08:56.328682
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()
    assert safari_api_ie.ie_key() == "SafariApi"

# Generated at 2022-06-12 18:09:34.688929
# Unit test for constructor of class SafariCourseIE

# Generated at 2022-06-12 18:09:40.657071
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from .test_utils import FakeLoginIE

    ie = FakeLoginIE()
    ie._real_initialize()
    assert ie.LOGGED_IN
    assert ie.username == 'username'
    assert ie.password == 'password'

    ie = FakeLoginIE()
    ie._real_initialize()
    assert ie.LOGGED_IN
    assert ie.username == 'username'
    assert ie.password == 'password'

# Generated at 2022-06-12 18:09:45.671823
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    assert url == SafariCourseIE._VALID_URL
    assert 'SafariCourseIE' == SafariCourseIE.ie_key()
    assert 'safaribooksonline.com online courses' == SafariCourseIE.IE_DESC
    assert 'safari:course' == SafariCourseIE.IE_NAME
    assert 'hadoop-fundamentals-livelessons' == SafariCourseIE._match_id(url)

# Generated at 2022-06-12 18:09:52.467901
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    inst = SafariApiIE()
    assert not inst._LOGIN_URL
    assert not inst._NETRC_MACHINE
    assert inst._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert inst._API_FORMAT == 'json'
    assert inst.LOGGED_IN == False

# Generated at 2022-06-12 18:09:54.628039
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from python.tests.test_safari import test_SafariApiIE
    test_SafariApiIE('safari:api')

# Generated at 2022-06-12 18:09:55.760986
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert not SafariIE(None).LOGGED_IN

# Generated at 2022-06-12 18:09:58.136014
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    ie._uploader_id = None
    ie._real_initialize()
    assert ie._uploader_id is None

# Generated at 2022-06-12 18:10:05.465646
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    with open('./youtube_dl/extractor/testdata/safari.json') as safari_api:
        root = json.loads(safari_api.read())
        assert(root['course_id'] == '9780133392838')
        assert(root['homepage'] == 'https://www.safaribooksonline.com/home/')
        assert(root['reference_id'] == '0_qbqx90ic')
        assert(root['partner_id'] == '1926081')
        assert(root['ui_id'] == '29375172')
        assert(root['part'] == '00_SeriesIntro')
        assert(root['book']['title'] == 'Hadoop Fundamentals LiveLessons')

# Generated at 2022-06-12 18:10:09.690028
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safariBaseIE = SafariBaseIE()
    assert safariBaseIE._NETRC_MACHINE == 'safari'
    assert safariBaseIE._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'

# Generated at 2022-06-12 18:10:18.163968
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import youtube_dl
    count=0
    for url in [
        'https://www.safaribooksonline.com/library/view/microsoft-azure-for/9780134686046/part00.html',
        'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838/9780133392838-00_SeriesIntro'
    ]:
        print(url)
        ydl = youtube_dl.YoutubeDL({'username': 'xxx','password':'xxx','quiet':True, 'outtmpl': '%(id)s.%(ext)s'})
        with ydl:
            count+=1
            ydl.download([url])
            print('\n')
            if count > 1:
                break

# Generated at 2022-06-12 18:10:54.646151
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """Test class SafariCourseIE"""
    try:
        cls_SafariCourseIE = SafariCourseIE
    except NameError as ex:
        msg = "Test of SafariCourseIE is skipped. Cause: {}".format(ex.__str__())
        raise unittest.SkipTest(msg)
    else:
        assert issubclass(cls_SafariCourseIE, InfoExtractor)

# Generated at 2022-06-12 18:10:58.204747
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_courseIE = SafariCourseIE()
    assert "safari:course" == safari_courseIE.ie_key()
    assert "safaribooksonline.com online courses" == safari_courseIE.IE_DESC

# Generated at 2022-06-12 18:11:00.840911
# Unit test for constructor of class SafariIE
def test_SafariIE():
    i = SafariIE('http://techbus.safaribooksonline.com/9780134426365', 'id', 'title')
    assert i.LOGGED_IN == False

# Generated at 2022-06-12 18:11:10.750594
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safariCourseIE = SafariCourseIE()

    # test SafariCourseIE.suitable()
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    assert safariCourseIE.suitable(url) == True

    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    assert safariCourseIE.suitable(url) == False

    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/part00.html?override_format=json'
    assert safariCourseIE.suitable(url) == False

# Generated at 2022-06-12 18:11:18.379287
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    info_dict = {
        'id': '9780134664057',
        'title': 'Red Hat Certified Engineer (RHCE) Complete Video Course',
    }
    result = SafariCourseIE()._real_extract('https://www.safaribooksonline.com/library/view/red-hat-certified/9780134664057/')

# Generated at 2022-06-12 18:11:25.658245
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .test_utils import fake_webpage

    url = 'http://techbus.safaribooksonline.com/9780134426365'
    webpage = fake_webpage(url)
    safari_course = SafariCourseIE(webpage)
    # Test course_id extracted by _match_id
    course_id = safari_course._match_id(url)
    assert course_id == '9780134426365'

    # Test course_id extracted by _search_regex
    course_id2 = safari_course._search_regex(
        r'book/(?P<id>[^/]+)', webpage, 'course_id', group='id')
    assert course_id == course_id2

# Generated at 2022-06-12 18:11:30.259007
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    try:
        ie = SafariApiIE()
    except Exception:
        assert False, 'SafariApiIE(): exception during construction'
    assert ie.IE_NAME == 'safari:api'
    assert ie.IE_DESC == 'safaribooksonline.com online courses'


# Generated at 2022-06-12 18:11:36.827380
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safariIE = SafariIE()
    safariCourseIE = SafariCourseIE()
    safariApiIE = SafariApiIE()

    # The tests are not using actual safaribooksonline credentials so it should not be able to login
    # and the LOGGED_IN class member should remain False
    assert safariIE.LOGGED_IN == False
    assert safariCourseIE.LOGGED_IN == False
    assert safariApiIE.LOGGED_IN == False

# Generated at 2022-06-12 18:11:43.184245
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    i = SafariBaseIE(SafariIE(), 'username', 'password')
    assert i._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert i._NETRC_MACHINE == 'safari'
    assert i._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert i._API_FORMAT == 'json'

# Generated at 2022-06-12 18:11:46.879217
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """
    Function that checks the constructor of class SafariApiIE
    """
    from .test_static import TestStaticHtmlSafariApiIE
    safari_api = SafariApiIE()
    assert safari_api == TestStaticHtmlSafariApiIE

# Generated at 2022-06-12 18:12:55.436466
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_ie = SafariBaseIE()
    _, urlh = safari_ie._download_webpage_handle(
        'https://learning.oreilly.com/accounts/login-check/', None,
        'Downloading login page')

    # test _apply_first_set_cookie_header function
    safari_ie._apply_first_set_cookie_header(urlh, 'groot_sessionid')
    safari_ie._apply_first_set_cookie_header(urlh, 'orm-jwt')
    safari_ie._apply_first_set_cookie_header(urlh, 'orm-rt')

# Generated at 2022-06-12 18:12:57.211357
# Unit test for constructor of class SafariApiIE

# Generated at 2022-06-12 18:13:03.815756
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE("https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html")
    assert(safari_api_ie.suitable("https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html") == True)
    assert(safari_api_ie.suitable("https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter-content/part00.html") == True)

# Generated at 2022-06-12 18:13:04.743110
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # TODO
    return

# Generated at 2022-06-12 18:13:10.475371
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from unittest import TestCase, main

    from . import content

    class SafariApiIETest(TestCase):
        def setUp(self):
            self.url = content.extract_content(__file__, 'safari_part1_json')
            self.extractor = SafariApiIE(self.url)

        def test_title(self):
            self.assertEqual(self.extractor.title, 'Introduction to Hadoop Fundamentals LiveLessons')

        def test_get_content_url(self):
            self.assertEqual(
                self.extractor.get_content_url(),
                'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')

    main()

# Generated at 2022-06-12 18:13:12.138385
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()

# Generated at 2022-06-12 18:13:16.512802
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """Test constructor of class SafariIE."""
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    ie = SafariIE(SafariBaseIE())
    obj = ie._real_initialize()
    assert obj is None

# Generated at 2022-06-12 18:13:22.347927
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class MockIE(SafariBaseIE):
        @classmethod
        def _html_search_meta(cls, name, html, fatal=True):
            return '1'

    ie = MockIE('MockIE')
    assert ie._login_info

# Generated at 2022-06-12 18:13:23.361112
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('safari')

# Generated at 2022-06-12 18:13:32.253405
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():

    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    extractor = SafariApiIE()
    test_course_id = '9781449396459'
    assert extractor.suitable(url)
    mobj = re.match(extractor._VALID_URL, url)
    assert 'part00' == mobj.group('part')
    assert test_course_id == mobj.group('course_id')
    # Test to make sure the right SafariIE extractor is being invoked
    assert SafariIE().IE_NAME == extractor._real_extract(url)._type

# Generated at 2022-06-12 18:15:01.006954
# Unit test for constructor of class SafariIE
def test_SafariIE():
    testOptions = {
        'username': 'user',
        'password': 'pass',
        'extract-subtitles': 'True'
    }
    testArgs = {
        '--username': 'user',
        '--password': 'pass',
        '--write-sub': True,
        '--extract-subtitles': 'True'
    }
    safariIE = SafariIE(testOptions, testArgs)
    assert safariIE._api_base == 'https://learning.oreilly.com/api/v1'
    assert safariIE._api_format == 'json'
    assert safariIE._partner_id == '1926081'
    assert safariIE._uiconf_id == '29375172'

# Generated at 2022-06-12 18:15:03.902113
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = "https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/"
    assert SafariCourseIE.suitable(url)

# Generated at 2022-06-12 18:15:05.027017
# Unit test for constructor of class SafariIE
def test_SafariIE():
    try:
        SafariIE()
    except:
        pass



# Generated at 2022-06-12 18:15:10.968130
# Unit test for constructor of class SafariIE
def test_SafariIE():
    with open('tests/testdata/safaribooksonline/techbus.safaribooksonline.com-9780134664057.json', 'r') as f:
        json_data = json.load(f)
        metadata_url = 'http://techbus.safaribooksonline.com/9780134664057'
        safari_ie = SafariIE(metadata_url)

        assert safari_ie.ie_key() == 'Safari'
        assert safari_ie.ie_name() == 'safaribooksonline.com online video'
        assert safari_ie.ie_desc() == 'safaribooksonline.com online video'
        assert safari_ie._get_login_info() == ('', '')
        assert safari_ie.metadata_url == metadata_url

# Generated at 2022-06-12 18:15:12.469426
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
        c1 = SafariBaseIE()

# Generated at 2022-06-12 18:15:14.374665
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test that SafariApiIE can be instantiated
    b = SafariApiIE()
    assert b is not None


# Generated at 2022-06-12 18:15:18.945012
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test unauthenticated access
    mocker = ExtractorMocker()
    mocker.mock_extractor(SafariBaseIE)
    safari_base_ie = SafariBaseIE(mocker.context('SafariBaseIE'))
    safari_base_ie._real_initialize()
    assert not safari_base_ie.LOGGED_IN

    # Test authenticated access
    mocker = ExtractorMocker()
    mocker.set_mock('authenticated', True)
    mocker.mock_extractor(SafariBaseIE)
    safari_base_ie = SafariBaseIE(mocker.context('SafariBaseIE'))
    safari_base_ie._real_initialize()
    assert safari_base_ie.LOGGED_IN
    assert safari_base_

# Generated at 2022-06-12 18:15:20.349246
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test class constructor of SafariBaseIE
    obj = SafariBaseIE()
    assert obj is not None


# Generated at 2022-06-12 18:15:21.155985
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safariCourse = SafariCourseIE()


# Generated at 2022-06-12 18:15:22.107452
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    pass