

# Generated at 2022-06-12 18:07:05.748379
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # This test was added for #4470.
    # Testing the constructor is just a side effect
    # since the test is run when constructing the class.
    SafariCourseIE(None)

# Generated at 2022-06-12 18:07:07.496142
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE('safari')
    assert ie.ie_key() == 'safari:api'

# Generated at 2022-06-12 18:07:11.576841
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # The actual course is chosen at random (among the ones that happen to be
    # present on the day of the test).  We could use any other course instead.
    url = 'https://www.safaribooksonline.com/library/view/the-c-library/9780133818781/'
    klass = SafariCourseIE()
    assert isinstance(klass, SafariBaseIE)

# Generated at 2022-06-12 18:07:18.262681
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safaribaseIE = SafariBaseIE()
    assert 'safari' == safaribaseIE._NETRC_MACHINE
    assert 'https://learning.oreilly.com/accounts/login/' == safaribaseIE._LOGIN_URL
    assert 'https://learning.oreilly.com/api/v1' == safaribaseIE._API_BASE
    assert 'json' == safaribaseIE._API_FORMAT
    assert False == safaribaseIE.LOGGED_IN

# Generated at 2022-06-12 18:07:27.627386
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """Unit test for constructor of class SafariCourseIE"""

    test_url = 'http://techbus.safaribooksonline.com/9780134426365'
    test_url_result = 'http://techbus.safaribooksonline.com/9780134426365'

    def test_suitable(url):
        suitable = SafariCourseIE.suitable(url)
        return suitable

    fetch_unit_test_data(test_url)

    instance = SafariCourseIE()
    instance.suitable = test_suitable
    instance._real_extract(test_url)
    assert instance.real_url == test_url_result

# Generated at 2022-06-12 18:07:28.807332
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safariCourseIE = SafariCourseIE()
    safariCourseIE.initialize()

# Generated at 2022-06-12 18:07:29.644375
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safariIE = SafariIE()

# Generated at 2022-06-12 18:07:30.872907
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE(SafariBaseIE.context)

# Generated at 2022-06-12 18:07:39.602033
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # positive test case
    url = "https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html"
    safari_api_ie = SafariApiIE()
    safari_api_ie.extract(url)
    # negative test case
    url = "https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.htm"
    safari_api_ie = SafariApiIE()
    safari_api_ie.extract(url)

# Generated at 2022-06-12 18:07:46.946358
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safariIE = SafariIE('SafariIE')
    assert safariIE._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safariIE._NETRC_MACHINE == 'safari'
    assert safariIE._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safariIE._API_FORMAT == 'json'
    assert safariIE.LOGGED_IN == False


# Generated at 2022-06-12 18:08:13.936084
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari = SafariApiIE()
    assert safari.IE_NAME == 'safari:api'
    assert safari.IE_DESC == 'safaribooksonline.com online video'

# Generated at 2022-06-12 18:08:25.543101
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL(params={
        'outtmpl': '%(id)s',
        'username': 'foobar',
        'password': 'helloworld',
    })
    ydl.add_info_extractor(SafariIE)
    result = ydl.extract_info(
        'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838/9780133392838-00_SeriesIntro',
        download=False)
    assert result['title'] == 'Introduction to Hadoop Fundamentals LiveLessons'

# Generated at 2022-06-12 18:08:38.434949
# Unit test for constructor of class SafariIE

# Generated at 2022-06-12 18:08:40.694180
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    inst = SafariApiIE('SomeUser', 'SomePass')
    assert isinstance(inst, SafariApiIE)


# Generated at 2022-06-12 18:08:41.798343
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('SafariApiIE')

# Generated at 2022-06-12 18:08:43.224939
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    obj = SafariBaseIE()
    assert obj._NETRC_MACHINE == 'safari'

# Generated at 2022-06-12 18:08:44.747281
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert (SafariApiIE.__name__ == "SafariApiIE")

# Generated at 2022-06-12 18:08:46.752600
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    x = SafariBaseIE(SafariBaseIE._downloader)
    try:
        x._real_initialize()
    except ExtractorError:
        pass

# Generated at 2022-06-12 18:08:47.367547
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()

# Generated at 2022-06-12 18:08:50.083725
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    base_ie = SafariBaseIE()
    assert base_ie.LOGGED_IN is False

# Generated at 2022-06-12 18:09:22.969084
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE('http://www.safaribooksonline.com/api/v1/book/9781449396459/chapter-content/ch01s02.html')
    assert safari_api_ie.IE_NAME == 'safari:api'

# Generated at 2022-06-12 18:09:33.710957
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    input_url_1 = 'https://www.safaribooksonline.com/library/view/python-for-beginners/9781789535734/'
    input_url_2 = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    input_url_3 = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/writing-and-sending-emails.html'

    # SafariIE
    safariie = SafariIE()

    # test suitable
    assert safariie.suitable(input_url_1) == True
    assert safariie.suitable(input_url_2) == False

# Generated at 2022-06-12 18:09:37.777574
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test that SafariIE accepts URLs which are not accepted by SafariCourseIE
    for test in SafariCourseIE._TESTS:
        if test['only_matching']:
            continue
        assert SafariIE.suitable(test['url'])

# Generated at 2022-06-12 18:09:42.863965
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safaribase = SafariBaseIE()
    assert safaribase.LOGGED_IN == False
    assert safaribase._NETRC_MACHINE == 'safari'

    assert safaribase._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safaribase._API_FORMAT == 'json'

    assert safaribase._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'

# Generated at 2022-06-12 18:09:45.320473
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    test_instance = SafariBaseIE()

    obj = test_instance._api_call(
        {'method': 'test', 'params': {'query': 'v'}})

    assert('test' in obj.get('method'))
    assert('params' in obj.get('method'))

# Generated at 2022-06-12 18:09:57.817727
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.IE_NAME == 'safari'
    assert ie._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''

# Generated at 2022-06-12 18:09:58.641705
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('safari:api')


# Generated at 2022-06-12 18:10:00.969625
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .test_safaribooksonline import test_check_valid_url
    test_check_valid_url(SafariIE)

# Generated at 2022-06-12 18:10:03.333467
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    SafariApiIE()._real_extract(url)


# Generated at 2022-06-12 18:10:06.662052
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    obj = SafariBaseIE(None)
    assert obj._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'

# Generated at 2022-06-12 18:11:12.186680
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    username = 'test'
    password = 'test'
    keyring = None
    safari = SafariBaseIE()
    info = safari.extract(url)
    assert info['id'] == '0_qbqx90ic'
    assert info['title'] == 'Introduction to Hadoop Fundamentals LiveLessons'

# Generated at 2022-06-12 18:11:14.794722
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test constructor which doesn't have to call API
    ie_safari = SafariIE()
    assert ie_safari.LOGGED_IN == False

# Generated at 2022-06-12 18:11:15.565664
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    ie._login()

# Generated at 2022-06-12 18:11:21.930779
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import copy
    from .common import InfoExtractor

    from .safari import SafariIE

    test_case = {
        'url': 'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838',
        'info_dict': {
            'id': '9780133392838',
            'title': 'Hadoop Fundamentals LiveLessons',
        },
        'playlist_count': 22,
        'skip': 'Requires safaribooksonline account credentials',
    }
    ie2 = SafariIE(copy.copy(InfoExtractor._WORKING_CLASSES[test_case['ie_key']]))
    ie2._downloader = InfoExtractor._WORKING_CLASSES[test_case['ie_key']]._downloader
    ie2

# Generated at 2022-06-12 18:11:30.533639
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Confirm that SafariCourseIE does NOT inherit from SafariIE.
    instance = SafariCourseIE()
    assert not issubclass(SafariCourseIE, SafariIE)
    # Confirm that SafariCourseIE does NOT inherit from SafariApiIE.
    assert not issubclass(SafariCourseIE, SafariApiIE)
    # Confirm that SafariCourseIE does NOT inherit from YoutubeBaseInfoExtractor.
    assert not issubclass(SafariCourseIE, YoutubeBaseInfoExtractor)

# Generated at 2022-06-12 18:11:40.252317
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import unittest
    import sys
    import urllib.request

    class TestSafariApiIE(unittest.TestCase):
        def setUp(self):
            self.url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
            self.part_id = '9781449396459-ch01'
            self.course_title = 'Python Crash Course'
            self.chapter_title = 'Chapter 1: Getting Started'
            self.web_url = 'https://learning.oreilly.com/videos/python-crash-course/9781449396459-00-00/9781449396459-00-00-00-01'

# Generated at 2022-06-12 18:11:43.375460
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api = SafariApiIE()
    assert isinstance(safari_api, SafariApiIE)

# Generated at 2022-06-12 18:11:44.982286
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE('SafariIE', 'safaribooksonline.com')

# Generated at 2022-06-12 18:11:45.900127
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()

# Generated at 2022-06-12 18:11:46.450239
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-12 18:14:14.189938
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    info_dict = {
        'id': '9781449396459',
        'title': 'Learn Android Studio',
    }
    playlist_count = 3
    skip = 'Requires safaribooksonline account credentials'
    assertSafariCourse(url, info_dict, playlist_count, skip)

    url = 'https://learning.oreilly.com/videos/python-programming-language/9780134217314'
    safari = SafariCourseIE(url)
    assert safari.IE_NAME == 'safari:course'
    assert safari.IE_DESC == 'safaribooksonline.com online courses'
    assert safari._VALID_

# Generated at 2022-06-12 18:14:16.734760
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    without_login = SafariBaseIE()
    assert without_login.LOGGED_IN == False

# Generated at 2022-06-12 18:14:17.875853
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    ie._real_initialize()

# Generated at 2022-06-12 18:14:22.714778
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    url = "https://learning.oreilly.com/videos/python-programming-language/9780134217314/9780134217314-01_Python_01_2"
    safari = SafariBaseIE()
    safari.initialize()
    safari._real_initialize()
    urlh = safari._download_webpage_handle(url, None, 'Downloading login page')
    print(urlh.geturl())

# Generated at 2022-06-12 18:14:26.100368
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    test_url = SafariCourseIE.suitable(url)
    instance = SafariCourseIE(url)
    assert instance.url == url
    assert instance.title == ''
    assert test_url is True

# Generated at 2022-06-12 18:14:27.281948
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Instantiate class SafariCourseIE
    courseIE = SafariCourseIE('SafariCourseIE')


# Generated at 2022-06-12 18:14:27.849266
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()

# Generated at 2022-06-12 18:14:33.944991
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    inst = SafariApiIE()
    assert inst._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Unit tests for suitable method of class SafariApiIE

# Generated at 2022-06-12 18:14:40.771674
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test with login/password and valid url
    SafariBaseIE._LOGIN_URL = 'http://localhost:9000/login/'
    SafariBaseIE._TEST = {
        'username': 'test',
        'password': '1234',
        'check': {
            'expected_status': 200,
            'expected_content': 'Successful login'
            }
        }
    test = SafariBaseIE()
    test._login()
    assert  test.LOGGED_IN is True

    SafariBaseIE._TEST = {
        'username': 'test',
        'password': '4321',
        'check': {
            'expected_status': 401,
            'expected_content': 'Wrong password'
            }
        }
    test = SafariBaseIE()
    test._login()

# Generated at 2022-06-12 18:14:47.543088
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    cls = SafariBaseIE
    # This is not a real URL
    url = 'https://www.safaribooksonline.com/?book=B00F6ZDU6M'
    ie = cls(cls.create_ie(), url)
    # If the auth succeeds, _login will be called again
    # in the process of extracting the downloader
    assert hasattr(ie, '_login')