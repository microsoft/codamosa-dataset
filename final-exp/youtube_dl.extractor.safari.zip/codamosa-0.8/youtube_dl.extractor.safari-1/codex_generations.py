

# Generated at 2022-06-12 18:07:05.239913
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE(None)

# Generated at 2022-06-12 18:07:13.555829
# Unit test for constructor of class SafariCourseIE

# Generated at 2022-06-12 18:07:18.438437
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE._VALID_URL == 'https?://(?:www\\.)?(?:safaribooksonline|(?:learning\\.)?oreilly)\\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'

# Generated at 2022-06-12 18:07:22.626668
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    for url in SafariIE._TESTS + SafariCourseIE._TESTS:
        if 'only_matching' in url:
            continue
        SafariApiIE(urls=[url['url']])

# Generated at 2022-06-12 18:07:30.226322
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from youtube_dl.compat import compat_str
    ie = SafariIE()

    match = re.match(ie._VALID_URL, 'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838/9780133392838-00_SeriesIntro')
    course_id = match.group('course_id')
    part = match.group('part')
    assert course_id
    assert part

    video_id = '%s-%s' % (course_id, part)

    webpage_url = 'https://learning.oreilly.com/library/view/hadoop-fundamentals-livelessons/9780133392838/%s.html' % part

# Generated at 2022-06-12 18:07:36.144137
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # local import to avoid any runtime dependency
    from ..utils import check_test_cases

    # test case validation with dummy login and password
    credentials = dict(test_SafariBaseIE='test_SafariBaseIE')


# Generated at 2022-06-12 18:07:39.355519
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from .common import FakeLoginIE
    ie = FakeLoginIE(SafariBaseIE)
    assert ie.login_required
    assert ie.username
    assert ie.password

# Generated at 2022-06-12 18:07:49.820993
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """test of SafariIE constructor
       Intended to check the construction of SafariIE with SafariApiIE.
       Verifies that SafariApiIE is not a standalone browser"""
    from . import get_testcases
    # build list of testcases that have a compatible test case in safariapi
    compat_testcases_idx = []
    for idx, test in enumerate(get_testcases(SafariIE)):
        url = test['url']
        api_url = url.replace('/library/view/', '/api/v1/book/')
        api_url = api_url.replace('/part', '/chapter-content')
        api_url = api_url.replace('.html', '.html')

# Generated at 2022-06-12 18:07:50.724639
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE('safari', 'safaribooksonline.com')

# Generated at 2022-06-12 18:07:52.288340
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Check that course_id is extracted from url
    assert SafariCourseIE._match_id(SafariCourseIE._VALID_URL) == '9780133392838'

# Generated at 2022-06-12 18:08:14.931842
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .test_common import TestCommon
    from .common import cmd_extract_info
    from .extractor.common import std_headers
    from .utils import *

    # If you change one of these, also make the same change in test_SafariCourseIE.test_SafariCourseIE
    url='https://www.safaribooksonline.com/library/view/practical-android-projects/9781430243813/part00.html'

    mobj = re.match(SafariIE._VALID_URL, url)
    course_id = mobj.group('course_id')
    part = mobj.group('part')


# Generated at 2022-06-12 18:08:24.304156
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    """Test constructor of class SafariBaseIE"""

    ie = SafariBaseIE(None)
    if ie.IE_NAME != 'safari':
        assert(False)

    if ie.IE_DESC != 'safaribooksonline.com online video':
        assert(False)

    if ie._LOGIN_URL != 'https://learning.oreilly.com/accounts/login/':
        assert(False)

    if ie._NETRC_MACHINE != 'safari':
        assert(False)

# Generated at 2022-06-12 18:08:25.488086
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert SafariBaseIE() is not None

# Generated at 2022-06-12 18:08:28.258847
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    instance = SafariBaseIE()
    instance._login()

    # logout
    instance._download_webpage_handle(
        'https://learning.oreilly.com/accounts/logout/', None,
        'Logging out')

# Generated at 2022-06-12 18:08:32.560704
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """Unit test for constructor of class SafariIE."""
    youtube_ie = SafariIE('Safari', 'safaribooksonline.com')
    assert not youtube_ie.LOGGED_IN

# Generated at 2022-06-12 18:08:43.828377
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie_class = SafariIE
    ie_object = ie_class()
    # Test for _LOGIN_URL
    assert ie_object._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/', 'Fail to get _LOGIN_URL'
    # Test for _NETRC_MACHINE
    assert ie_object._NETRC_MACHINE == 'safari', 'Fail to get _NETRC_MACHINE'
    # Test for _API_BASE
    assert ie_object._API_BASE == 'https://learning.oreilly.com/api/v1', 'Fail to get _API_BASE'
    # Test for _API_FORMAT
    assert ie_object._API_FORMAT == 'json', 'Fail to get _API_FORMAT'
    # Test for LOGGED_IN

# Generated at 2022-06-12 18:08:46.903969
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """
    The test checks that SafariApiIE doesn't fail with unregistered users.
    """
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter-content/ch01.html'
    SafariApiIE()._real_extract(url)

# Generated at 2022-06-12 18:08:58.563793
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    # Check for consistency of id field
    assert ie.id == 'safari', ('id field of class SafariIE is inconsistent')
    # Check for existence of IE_NAME and IE_DESC constants
    assert ie.IE_NAME == 'safari', ('IE_NAME constant of class SafariIE is inconsistent')
    assert ie.IE_DESC == 'safaribooksonline.com online video', ('IE_DESC constant of class SafariIE is inconsistent')
    # Test validity of _VALID_URL
    _VALID_URL = r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/'\
    'library/view/[^/]+/[^/]+/(?P<part>[^/?\#&]+)\.html'
   

# Generated at 2022-06-12 18:09:01.551468
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    test_class = SafariBaseIE()
    test_class._download_webpage = lambda *a, **kw: (None, 'url_handle')
    test_class._download_json = lambda *a, **kw: {'logged_in': False, 'redirect_uri': 'https://www.safaribooksonline.com/login'}
    test_class._apply_first_set_cookie_header = lambda *a, **kw: None
    test_class._real_initialize()

# Generated at 2022-06-12 18:09:03.341108
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    inst = SafariBaseIE()
    instanceType = inst.__class__.__name__
    assert instanceType == "SafariBaseIE"

# Generated at 2022-06-12 18:09:33.665128
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    """Test constructors of SafariBaseIE class."""
    SafariBaseIE()

# Generated at 2022-06-12 18:09:35.530137
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Invalid URL
    SafariApiIE(SafariBaseIE())

# Generated at 2022-06-12 18:09:44.130539
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/introduction_to_cloud_foundry.html'
    kaltura_url = 'https://cdnapisec.kaltura.com/html5/html5lib/v2.37.1/mwEmbedFrame.php?wid=_1926081&uiconf_id=29375172&flashvars[referenceId]=9781449396459-I1'
    kaltura_video_id = '9781449396459-I1'

    def assert_urls(url, url_to_compare):
        config = {
            '_download_webpage_handle': lambda *args, **kwargs: (None, compat_urlparse.urlparse(url))
        }
       

# Generated at 2022-06-12 18:09:51.056434
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from .test_safaribooks import fake_login
    from .test_safaribooks import fake_login_user, fake_login_password
    with fake_login(SafariBaseIE):
        ie = SafariBaseIE(None)
        username, password = ie._get_login_info()
        assert username == fake_login_user
        assert password == fake_login_password

# Generated at 2022-06-12 18:09:51.906684
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert SafariIE([])

# Generated at 2022-06-12 18:09:54.797697
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    # Check that redundant 's' in https is removed
    assert ie._API_BASE == 'http://learning.oreilly.com/api/v1'


# Generated at 2022-06-12 18:10:03.840267
# Unit test for constructor of class SafariCourseIE

# Generated at 2022-06-12 18:10:12.779829
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test SafariBaseIE.suitable
    assert SafariBaseIE.suitable('http://techbus.safaribooksonline.com/9780134426365')
    assert SafariBaseIE.suitable('http://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838')

    # Test SafariBaseIE.__init__
    # SafariBaseIE.__init__(username=None, password=None)
    SafariBaseIE(username=None)
    SafariBaseIE(username=None, password=None)

# Generated at 2022-06-12 18:10:16.981781
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    inst = SafariApiIE()
    inst._download_json = lambda _1, _2, _3: {
        'web_url': 'http://test.com/test.html'
    }
    inst._login = lambda: None
    inst.url_result = lambda url, ie: url
    url = 'http://test.com'
    result = inst.url_result(url, inst.ie_key())
    assert result == url

# Generated at 2022-06-12 18:10:28.182430
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE.suitable(
        'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838')
    assert SafariCourseIE.suitable(
        'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert SafariCourseIE.suitable(
        'https://www.safaribooksonline.com/library/view/calculus-early-transcendentals/9780133795046/')
    assert SafariCourseIE.suitable(
        'https://www.safaribooksonline.com/videos/python-programming-language/9780134217314')

# Generated at 2022-06-12 18:11:33.016872
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    video_id = '0_qbqx90ic'
    expected_url = ('https://www.safaribooksonline.com/'
                    'library/view/hadoop-fundamentals-livelessons/9780133392838/'
                    'part00.html')
    assert SafariApiIE._build_url(video_id) == expected_url

# Generated at 2022-06-12 18:11:34.578315
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safariBase = SafariBaseIE()
    assert safariBase is not None

# Generated at 2022-06-12 18:11:42.535742
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .test import make_test_cases
    from .test_samples import safari_samples
    from .test import learn_to_code_samples
    from .test import cs101_samples

    # .test_samples.safari_samples is a list of SafariCourseIE urls
    for safari_sample in safari_samples:
        test_case = {
            'url': safari_sample,
            # SafariCourseIE is only an extractor, and it doesn't download
            # the webpage to get the title.
            # So it doesn't need the webpage to do the test.
            # Set webpage to None
            'webpage': None,
        }
        # For example, test_case is:
        # {
        #     'url': u'https://learning.oreilly.com/videos/h

# Generated at 2022-06-12 18:11:52.083957
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'
    assert SafariCourseIE('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/').playlist_count == 22

# Generated at 2022-06-12 18:11:53.004821
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE('safari')

# Generated at 2022-06-12 18:12:00.289253
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'

# Generated at 2022-06-12 18:12:09.446375
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    testargs = ['-u', 'user', '-p', 'pass', '--noplaylist', 'safariapi:9780133392838']


# Generated at 2022-06-12 18:12:19.336593
# Unit test for constructor of class SafariIE
def test_SafariIE():
    inst = SafariIE('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert inst.get_IE_NAME() == 'safari'
    assert inst.get_IE_DESC() == 'safaribooksonline.com online video'
    assert inst.get_LOG_TEMPLATE() == 'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/'
    assert inst.has_working_url() == True

# Generated at 2022-06-12 18:12:27.823183
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course_url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/'
    course_id = '9781449396459'
    course_title = 'Python Cookbook'

    # Constructor
    safari_course = SafariCourseIE()

    # call method suitable() to test the result of method suitable()
    result = SafariCourseIE.suitable(course_url)
    assert result == True, 'Course_ii suitable() returned False'

    # call method _match_id() to test the result of method _match_id()
    result = safari_course._match_id(course_url)
    assert result == course_id, '_match_id() failed to match the course id'

    # call method _real_extract() to test the method
    result = saf

# Generated at 2022-06-12 18:12:28.802608
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert(SafariCourseIE() is not None)

# Generated at 2022-06-12 18:15:15.170474
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    print ('\nTesting class SafariCourseIE')
    config_json = '''{"username":"johndoe","password":"123456"}'''
    online_course_id = '9780134664057'
    online_course_title = 'Learning Path: Red Hat Certified Engineer (RHCE) Certification'
    example_uri = 'https://www.safaribooksonline.com/library/view/learning-path-red/9780134664057/'
    print ('\n\tTEST CASE 1\n\tTesting constructor with valid config and valid course')
    safari_course_obj = SafariCourseIE(example_uri, config_json)
    print ('\n\t\tExpecting: \n\t\t\tTrue')

# Generated at 2022-06-12 18:15:16.206155
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE(SafariCourseIE.name)

# Generated at 2022-06-12 18:15:17.167902
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE("", "", "")

# Generated at 2022-06-12 18:15:19.986934
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    test_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    SafariCourseIE().suitable(test_url)

# Generated at 2022-06-12 18:15:21.369365
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert 'safaribooksonline.com' in ie._VALID_URL

# Generated at 2022-06-12 18:15:31.331245
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from ytdl.extractor.common import InfoExtractor
    from ..utils import fake_webpage
    test_case = '<a href="https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html?override_format=json"'

    webpage = fake_webpage(test_case)
    info_extractor = InfoExtractor()
    info_extractor.add_info_extractor(SafariApiIE)

# Generated at 2022-06-12 18:15:36.496710
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    try:
        # SafariApiIE can only be instanciated with safaribooksonline credentials
        SafariApiIE(None, None, None)
    except ExtractorError:
        pass
    else:
        raise Exception('Able to instanciate SafariApiIE without safaribooksonline credentials')

# Generated at 2022-06-12 18:15:38.810591
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    IE = SafariApiIE('https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html')
    assert IE.LOGGED_IN == False

# Generated at 2022-06-12 18:15:39.535917
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    pass

# Generated at 2022-06-12 18:15:43.170913
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    test_case = (
        ('username1', 'password1', None),
        ('username2', 'password2', None)
    )
    ie = SafariBaseIE()

    ie._login = lambda self: None
    ie._download_webpage_handle = lambda *args, **kwargs: (None, None)
    ie._download_json_handle = lambda *args, **kwargs: (None, None)