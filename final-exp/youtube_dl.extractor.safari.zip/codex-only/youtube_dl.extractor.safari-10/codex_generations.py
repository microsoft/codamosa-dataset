

# Generated at 2022-06-24 12:58:01.281778
# Unit test for constructor of class SafariIE
def test_SafariIE():
    try:
        URL = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
        ie = SafariIE(URL)
        assert type(ie) == SafariIE
    except:
        print("Failed to construct SafariIE")


# Generated at 2022-06-24 12:58:03.062830
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()._login()

# Generated at 2022-06-24 12:58:11.716139
# Unit test for constructor of class SafariIE

# Generated at 2022-06-24 12:58:13.374628
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    new_ie = SafariCourseIE()
    assert new_ie.IE_NAME == 'safari:course'

# Generated at 2022-06-24 12:58:16.132152
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    ie._download_webpage = lambda url, video_id: (url, None)
    ie._real_initialize()

# Generated at 2022-06-24 12:58:28.070707
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safariIE = SafariIE('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert safariIE.IE_NAME == 'safari'

# Generated at 2022-06-24 12:58:29.564777
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert isinstance(SafariCourseIE(None, None, None), SafariBaseIE)

# Generated at 2022-06-24 12:58:38.287493
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    api_url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    # We need to "de-abstract" the class
    api_ie = SafariApiIE('safari:api')
    # And construct a SafariIE instance "manually", using the same _downloader
    web_ie = SafariIE('safari')
    web_ie._downloader = api_ie._downloader
    # Now we call the same method for both instances
    api_info = api_ie._real_extract(api_url)
    web_info = web_ie._real_extract(api_info['url'])
    # And compare their results
    assert(api_info['id'] == web_info['id'])

# Generated at 2022-06-24 12:58:45.439816
# Unit test for constructor of class SafariApiIE

# Generated at 2022-06-24 12:58:48.852742
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    c = SafariCourseIE()
    c._login()
    c._download_json('http://techbus.safaribooksonline.com/9780133392838/?override_format=json', '9780133392838', 'Downloading course JSON')

# Generated at 2022-06-24 12:58:50.700658
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safariBaseIE = SafariBaseIE(SafariBaseIE)
    safariBaseIE._real_initialize()

# Generated at 2022-06-24 12:59:02.557639
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """Test if SafariIE is initialised correctly"""
    # Test that the SafariIE is initialised with the correct URL,
    # and that it returns the output from the download in the
    # _download_webpage method
    from .common import FakeYDL
    ydl = FakeYDL()
    ie = SafariIE(ydl=ydl)
    ie._download_webpage = lambda *args, **kwargs: b'output'
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    result = ie._real_extract(url)
    assert result['id'] == '0_qbqx90ic'

# Generated at 2022-06-24 12:59:10.932260
# Unit test for constructor of class SafariCourseIE

# Generated at 2022-06-24 12:59:14.365797
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # check that safari:api works as expected
    # (i.e. creates an instance of SafariBaseIE)
    assert SafariBaseIE is SafariApiIE('safari:api')

# Generated at 2022-06-24 12:59:17.151170
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')

# Generated at 2022-06-24 12:59:18.933090
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safariBaseIE = SafariBaseIE()
    assert safariBaseIE

# Generated at 2022-06-24 12:59:26.399773
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test SafariIE constructor by calling on SafariIE class
    # NOTE: The following test is NOT expected to fail as long as
    #       course-id and part number/name are correct and the video
    #       is available to the account used (creds)
    course_id = '9780133392838'
    part = 'part19.html'
    url = 'https://www.safaribooksonline.com/library/view/%s/%s' % (course_id, part)
    SafariIE().suitable(url)

# Generated at 2022-06-24 12:59:32.800653
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    self = SafariCourseIE(url, {}, {}, None, None)

    # method suitable to remove this test in future
    assert self.suitable(url) == False

    data = self.extract(url)

    assert data['_type'] == 'playlist'
    assert data['id'] == '9780133392838'
    assert data['title'] == 'Hadoop Fundamentals LiveLessons'
    assert len(data['entries']) == 22

    for e in data['entries']:
        assert e['_type'] == 'url'
        assert e['ie_key'] == 'SafariApi'

# Generated at 2022-06-24 12:59:37.632143
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter-content/kpbi_02_01.html'
    safari_api_ie = SafariApiIE(SafariApiIE.suitable(url))
    return safari_api_ie._real_extract(url)

# Generated at 2022-06-24 12:59:39.694318
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    expected_class = 'SafariCourseIE'
    result_class = SafariCourseIE.__name__

    assert result_class == expected_class

# Generated at 2022-06-24 12:59:44.825343
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Unit test to pass initialisation of SafariCourseIE
    # Used as a workaround to solve the problem
    # in __init__ of SafariCourseIE which creates an object of
    # class SafariBaseIE which has abstract method _download_webpage
    youtube_ie = SafariCourseIE("https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838")



# Generated at 2022-06-24 12:59:45.369452
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-24 12:59:47.665065
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://learning.oreilly.com/api/v1/book/9781449396459/chapter-content/CH00.html'
    assertSafariApiIE(url, '9daa8a2c20f1a1a1e0c3e3f79a3e3d77')



# Generated at 2022-06-24 12:59:49.932716
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    def constructor(**options):
        # Note we dont really care about the created object in this test
        return SafariBaseIE(**options)

    constructor()
    constructor(username='soumik')
    constructor(password='sopass')
    constructor(username='soumik', password='sopass')

# Generated at 2022-06-24 13:00:02.877152
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test if SafariIE and SafariApiIE share the same constructor.
    # SafariApiIE is a subclass of SafariBaseIE so uses `super(self)`
    # to get the same constructor as SafariIE.
    safari_api_ie_constructor = SafariApiIE.__init__

    safari_ie_constructor = SafariIE.__init__.__func__
    safari_ie_constructor_code = compile(
        safari_ie_constructor.__code__,
        safari_ie_constructor.__name__, 'exec')

    safari_api_ie_constructor_code = compile(
        safari_api_ie_constructor.__code__,
        safari_api_ie_constructor.__name__, 'exec')

    # Remove the first line which contains the `exec`

# Generated at 2022-06-24 13:00:05.522959
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert isinstance(SafariIE(), SafariBaseIE)
    assert isinstance(SafariIE(), SafariIE)


# Generated at 2022-06-24 13:00:07.057746
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class TestSafariBaseIE(SafariBaseIE):
        IE_NAME = 'test'

    instance = TestSafariBaseIE('username', 'password')
    assert instance.username == 'username'
    assert instance.password == 'password'

# Generated at 2022-06-24 13:00:12.622773
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    proj_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    proj_obj = SafariCourseIE().url_result(proj_url)
    assert proj_obj.ie != None
    assert proj_obj.ie.IE_NAME == proj_obj.ie_key()



# Generated at 2022-06-24 13:00:23.473081
# Unit test for constructor of class SafariIE
def test_SafariIE():
    testcase = {
        'url' : 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html',
        'info_dict' : {
            'id' : '0_qbqx90ic',
            'ext' : 'mp4',
            'title' : 'Introduction to Hadoop Fundamentals LiveLessons',
            'timestamp' : 1437758058,
            'upload_date' : '20150724',
            'uploader_id' : 'stork'
        },
        'params' : {
            'skip_download' : 'true'
        }
    }

    bs = SafariIE()._build_signature(testcase['info_dict']['id'])

# Generated at 2022-06-24 13:00:34.988348
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safariCourseIE = SafariCourseIE()
    assert safariCourseIE.ie_key() == 'Safari:Course'
    assert safariCourseIE.suitable('https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838') == True
    assert safariCourseIE.suitable('https://www.safaribooksonline.com/library/view/create-a-nodejs/100000006A0210/part00.html') == False
    assert safariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json') == False

# Generated at 2022-06-24 13:00:43.525262
# Unit test for constructor of class SafariIE
def test_SafariIE():
    i = SafariIE()
    assert i.IE_NAME == 'safari'
    assert i.IE_DESC == 'safaribooksonline.com online video'
    assert i._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''

# Generated at 2022-06-24 13:00:49.858702
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """Test constructor of class SafariCourseIE.
    """
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    safari_course_ie = SafariCourseIE(url)
    assert safari_course_ie.suitable(url)

# Generated at 2022-06-24 13:01:02.154834
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course = SafariCourseIE('safari')
    assert course._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert course._API_FORMAT == 'json'

    course = SafariCourseIE('safari', book_url='https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert course._API_BASE == 'https://www.safaribooksonline.com/api/v1'
    assert course._API_FORMAT == 'json'

    course = SafariCourseIE('safari', book_url='https://learning.oreilly.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')

# Generated at 2022-06-24 13:01:06.320585
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    SafariCourseIE.suitable(url)

# Generated at 2022-06-24 13:01:16.115385
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    course_id = '9780133392838'
    chapter_id = 'part00'
    url = 'https://www.safaribooksonline.com/api/v1/book/%s/chapter/%s.html' % (course_id, chapter_id)
    safari_api_ie = SafariApiIE()
    safari_api_ie._download_json = lambda url, video_id, note, errnote: {'web_url': url}
    assert safari_api_ie._real_extract(url) == safari_api_ie.url_result(url, SafariIE.ie_key())

# Generated at 2022-06-24 13:01:18.111262
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safariBase = SafariBaseIE()
    assert safariBase._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safariBase._API_FORMAT == 'json'

# Generated at 2022-06-24 13:01:28.240475
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE('Safaribooksonline', 'safari')

    assert ie._VALID_URL == SafariIE._VALID_URL

    SafariBaseIE._LOGIN_URL = 'https://learning.oreilly.com/accounts/login/'
    assert ie._LOGIN_URL == SafariBaseIE._LOGIN_URL

    SafariBaseIE._NETRC_MACHINE = 'safari'
    assert ie._NETRC_MACHINE == SafariBaseIE._NETRC_MACHINE

    SafariBaseIE._API_BASE = 'https://learning.oreilly.com/api/v1'
    assert ie._API_BASE == SafariBaseIE._API_BASE

    SafariBaseIE._API_FORMAT = 'json'
    assert ie._API_FORMAT == SafariBaseIE._API_FORMAT

    SafariBase

# Generated at 2022-06-24 13:01:29.482615
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()
    raise NotImplementedError

# Generated at 2022-06-24 13:01:34.426843
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    try:
        from .test_common import load_testdata
        from .test_common import test_safari_login
        test_safari_login(SafariBaseIE)
    except ImportError:
        pass

test_SafariBaseIE.todo = 'Test fails atm'

# Generated at 2022-06-24 13:01:47.705031
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # type: () -> None
    """Test the constructors of SafariBaseIE"""
    from ..compat import compat_urllib_request, compat_http_client

    import re
    import unittest

    class MockRequest(object):
        def __init__(self, url):
            self.url = url

    class MockResponse(object):
        def __init__(self, geturl, status):
            self.geturl = geturl
            self.status = status

    class MockHTTPRedirectHandler(compat_urllib_request.HTTPRedirectHandler):
        def redirect_request(self, req, fp, code, msg, headers, new_url):
            return MockRequest(new_url)


# Generated at 2022-06-24 13:01:48.825560
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert not SafariApiIE(SafariBaseIE())._LOGIN_URL is None


# Generated at 2022-06-24 13:02:01.325858
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # test_unit_for_multiple_instance_of_same_header_exists
    # test_unit_for_headers_with_multiple_values
    class TestSafariIE(SafariIE):
        def _download_webpage_handle(self, *args, **kwargs):
            response = super(TestSafariIE, self)._download_webpage_handle(
                *args, **kwargs)
            if response and response[1].geturl() == 'https://learning.oreilly.com/accounts/login-check/':
                headers_dict = dict(response[1].headers)

# Generated at 2022-06-24 13:02:09.215157
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    import os.path
    import yaml
    from .common import yaml_load
    from .common import make_absolute_url

    test_data_filename = os.path.join(os.path.dirname(__file__), 'test', 'safari-courses.yml')
    with open(test_data_filename, 'rb') as test_data_file:
        test_data = yaml_load(test_data_file)

    safari_course_ie = SafariCourseIE()

    def get_test_data_url(url):
        return make_absolute_url(safari_course_ie._TESTS[0]['url'], url)


# Generated at 2022-06-24 13:02:10.815222
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """
    Simple unit test to make sure that constructor of class SafariCourseIE
    can be instantiated.
    """
    SafariCourseIE()

# Generated at 2022-06-24 13:02:12.331248
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    obj = SafariApiIE()
    assert obj.IE_NAME == 'safari:api'

# Generated at 2022-06-24 13:02:16.441667
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html'
    try:
        test = SafariApiIE(SafariBaseIE)
    except:
        assert False, "Unit test failed"
    assert test.suitable(url)

# Generated at 2022-06-24 13:02:29.805933
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    test_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    (course_id, course_title) = ('9780133392838', 'Hadoop Fundamentals LiveLessons')

# Generated at 2022-06-24 13:02:42.425618
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import unittest
    import sys
    import os

    os.chdir(os.path.dirname(__file__))
    sys.path.insert(0, os.path.dirname(__file__))

    class ConstructorTest(unittest.TestCase):
        def test_create_instance(self):
            # Create a mock object for urlopen
            urlopen_mock = unittest.mock.MagicMock()

            # Set return value for request 1, which is the request for login page
            urlopen_mock.return_value = unittest.mock.MagicMock()

# Generated at 2022-06-24 13:02:44.010230
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    r = type(ie).__name__
    assert r == 'SafariBaseIE'

# Generated at 2022-06-24 13:02:46.583575
# Unit test for constructor of class SafariIE
def test_SafariIE():
    try:
        safari_ie = SafariIE()
        assert safari_ie.__class__.__name__ == "SafariIE"
    except:
        raise


# Generated at 2022-06-24 13:02:47.167811
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    raise ExtractorError

# Generated at 2022-06-24 13:02:48.060490
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('Safari')

# Generated at 2022-06-24 13:02:50.122132
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    i = SafariApiIE('https://learning.oreilly.com/api/v1/book/9780134664057/chapter/RHCE_Introduction.html')


# Generated at 2022-06-24 13:02:53.226686
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """Test SafariApiIE constructor"""
    url = 'https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html'
    inst = SafariApiIE.suitable(url)
    assert inst



# Generated at 2022-06-24 13:03:04.512505
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE("https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html")

    assert ie.video_id=='0_qbqx90ic', "Wrong Video ID: %s" % ie.video_id

    #assert ie.url=="https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html", "Wrong URL: %s" % ie.url
    #assert ie.video_url=="https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838/9780133392838-00_SeriesIntro", "Wr

# Generated at 2022-06-24 13:03:12.371364
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    import os
    import sys
    test_dir = os.path.dirname(os.path.realpath(__file__))
    safari_dir = os.path.join(os.path.dirname(test_dir), "youtube_dl", "extractor", "safari.py")
    sys.path.insert(0, test_dir)
    sys.path.insert(0, safari_dir)
    from test_safari import test_SafariCourseIE
    sys.path.remove(test_dir)
    sys.path.remove(safari_dir)
    test_SafariCourseIE()

# Generated at 2022-06-24 13:03:24.993221
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # 1. Check that this class can be instantiated
    ie = SafariCourseIE()

    # 2. Check that url passed as a parameter is appropriate for this class
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    assert ie.suitable(url)

    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    assert ie.suitable(url)

    url = 'http://techbus.safaribooksonline.com/9780134426365'
    assert ie.suitable(url)


# Generated at 2022-06-24 13:03:27.244573
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_apiIE = SafariApiIE()

    assert safari_apiIE is not None

# Generated at 2022-06-24 13:03:28.644840
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('SafariApiIE', True)


# Generated at 2022-06-24 13:03:30.890589
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.__class__.__name__ == 'SafariIE'

# Generated at 2022-06-24 13:03:31.502632
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-24 13:03:34.286350
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api = SafariApiIE("SafariApiIE")
    assert safari_api is not None


# Generated at 2022-06-24 13:03:43.914918
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    import unittest
    from .test_utils import TestSafariBaseIE
    class TestSafariCourseIE(TestSafariBaseIE):
        IE = SafariCourseIE
        _TESTS = [{
            'url': 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/',
            'info_dict': {
                'id': '9780133392838',
                'title': 'Hadoop Fundamentals LiveLessons',
            },
            'playlist_count': 22,
            'skip': 'Requires safaribooksonline account credentials',
        }]
    unittest.main()

# Generated at 2022-06-24 13:03:46.300879
# Unit test for constructor of class SafariIE
def test_SafariIE():
    inst = SafariIE("")
    assert_equal(str(inst), "SafariIE (safaribooksonline.com online video)")

# Generated at 2022-06-24 13:03:51.305904
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    for url in ['https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json',
                'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=xml']:
        assert type(SafariApiIE()._real_initialize()) == SafariApiIE

# Generated at 2022-06-24 13:03:59.938476
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # URL of the page where is the video.
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'

    # Instantiation of the class.
    safariIE = SafariIE(url)

    # Content of the test video.

# Generated at 2022-06-24 13:04:04.594898
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE(None)
    assert_equal(ie._NETRC_MACHINE, 'safari')
    try:
        ie._login()
    except ExtractorError as e:
        if not e.exc_info[1].args[0].startswith('Unable to login: '):
            raise
        assert_equal(ie.LOGGED_IN, False)
    else:
        assert_equal(ie.LOGGED_IN, True)

SafariBaseIE._login()

# Generated at 2022-06-24 13:04:14.139948
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE("https://www.safaribooksonline.com/library/view/python-cookbook-3rd/9781449357337/ch01s08.html")
    SafariIE("https://www.safaribooksonline.com/library/view/python-cookbook-3rd/9781449357337/ch01s08.html", download=True)
    SafariIE("https://www.safaribooksonline.com/library/view/python-cookbook-3rd/9781449357337/ch01s08.html").download('test.mp4', None)
    SafariIE("https://www.safaribooksonline.com/library/view/python-cookbook-3rd/9781449357337/ch01s08.html", '~/.sbpy/test.mp4')
    SafariIE

# Generated at 2022-06-24 13:04:14.673562
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()

# Generated at 2022-06-24 13:04:17.942701
# Unit test for constructor of class SafariIE
def test_SafariIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    SafariIE(url)

# Generated at 2022-06-24 13:04:30.962161
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    _, urlh = ie = SafariApiIE()._download_webpage_handle('url1', None)
    assert ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert ie._NETRC_MACHINE == 'safari'
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'
    assert not ie.LOGGED_IN

    x = SafariBaseIE()
    assert x._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert x._NETRC_MACHINE == 'safari'
    assert x._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert x._API_

# Generated at 2022-06-24 13:04:31.788880
# Unit test for constructor of class SafariIE
def test_SafariIE():
    s = SafariIE()
    assert s.LOGGED_IN == False


# Generated at 2022-06-24 13:04:36.331898
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    a = safariIE()
    assert(a.LOGGED_IN == False)
    assert(a.IE_NAME == None)
    assert(a.IE_DESC == None)
    assert(a.NETRC_MACHINE == safariIE._NETRC_MACHINE)

# Generated at 2022-06-24 13:04:39.490414
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari = SafariBaseIE()

    assert safari._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari._API_FORMAT == 'json'

# Generated at 2022-06-24 13:04:42.009765
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert not SafariBaseIE.LOGGED_IN

    SafariBaseIE._login()

    assert not SafariBaseIE.LOGGED_IN

# Generated at 2022-06-24 13:04:42.665067
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()

# Generated at 2022-06-24 13:04:55.248833
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE("videoId")
    assert ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert ie._NETRC_MACHINE == 'safari'
    assert ie.LOGGED_IN == False
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'

# Generated at 2022-06-24 13:05:05.223670
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # test for basic class `SafariBaseIE`
    obj = SafariBaseIE()
    assert obj._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert obj._NETRC_MACHINE == 'safari'
    assert obj._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert obj._API_FORMAT == 'json'
    assert obj.LOGGED_IN == False

    # test for method `_real_initialize`
    obj._real_initialize()

    # test for method `_login`
    obj._login()

    # test for method `_real_extract`

# Generated at 2022-06-24 13:05:07.730112
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    i = SafariApiIE('https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html')
    print(i)

# Generated at 2022-06-24 13:05:11.846890
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    try:
        SafariCourseIE('safaribooksonline.com', 'safaribooksonline.com/api/v1/book/');
    except TypeError as e:
        assert(e.message == '__init__() takes at least 2 arguments (1 given)');

# Generated at 2022-06-24 13:05:13.986256
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from .common import test_login

    test_login(SafariBaseIE)

# Generated at 2022-06-24 13:05:16.905921
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE('https://www.safaribooksonline.com/library/view/data-science-from/9780133902837/part00.html', {'login_username': 'login_username', 'login_password': 'login_password'})

# Generated at 2022-06-24 13:05:28.831115
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # a URL for an actual video
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/00_SeriesIntro.html'
    course_id = '9780133392838'
    extractor = SafariIE(SafariIE.ie_key())
    webpage = extractor._download_webpage(url, course_id)

    mobj = re.match(extractor._VALID_URL, url)

    reference_id = extractor._search_regex(
        r'data-reference-id=(["\'])(?P<id>(?:(?!\1).)+)\1',
        webpage, 'kaltura reference id', group='id')


# Generated at 2022-06-24 13:05:30.125454
# Unit test for constructor of class SafariIE
def test_SafariIE():
    instance = SafariIE()
    assert isinstance(instance, SafariIE)


# Generated at 2022-06-24 13:05:40.068025
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    expected_chapter_url = 'https://learning.oreilly.com/library/view/artificial-intelligence-for/9780133659657/AI_for_Robots_MOOC_Week_2_Part_2.html'
    expected_chapter_id = '9780133659657/AI_for_Robots_MOOC_Week_2_Part_2'
    safari_api_ie = SafariApiIE(SafariApiIE.ie_key())
    safari_api_ie.extract(expected_chapter_url)
    assert safari_api_ie._download_json(None, None)[1] == expected_chapter_id

# Generated at 2022-06-24 13:05:41.266948
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()

# Generated at 2022-06-24 13:05:44.960992
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # The expected result- if self._get_login_info() works
    result = (r"username", r"password")
    # Not implemented since _get_login_info() seems to require netrc
    return None

# Generated at 2022-06-24 13:05:45.699008
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    instance = SafariCourseIE('test')

# Generated at 2022-06-24 13:05:46.746200
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE("test-safari-base")

# Generated at 2022-06-24 13:06:00.072010
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    fields = ('username', 'password')

    assert hasattr(ie, '_download_json')
    assert hasattr(ie, '_download_webpage')
    assert hasattr(ie, '_download_webpage_handle')
    assert hasattr(ie, '_LOGIN_URL')
    assert hasattr(ie, '_NETRC_MACHINE')
    assert hasattr(ie, '_login')
    assert hasattr(ie, '_real_initialize')
    assert hasattr(ie, '_real_extract')
    assert hasattr(ie, '_search_regex')
    assert hasattr(ie, 'add_default_headers')
    assert hasattr(ie, 'add_ie')
    assert hasattr(ie, 'add_info_extractor')
    assert has

# Generated at 2022-06-24 13:06:03.519049
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course = SafariCourseIE(SafariCourseIE.name())
    assert course.IE_NAME == 'safari:course'
    assert course.IE_DESC == 'safaribooksonline.com online courses'

# Generated at 2022-06-24 13:06:07.463115
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url='https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter-content/part01.html'
    IE = SafariApiIE()
    IE = IE.suitable(url)
    assert IE == True

# Generated at 2022-06-24 13:06:15.687335
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    import os

    assert hasattr(SafariBaseIE(), '_download_webpage')
    assert hasattr(SafariBaseIE(), '_download_json')
    assert hasattr(SafariBaseIE(), '_download_json_handle')
    assert hasattr(SafariBaseIE(), '_apply_first_set_cookie_header')
    assert hasattr(SafariBaseIE(), '_search_regex')
    assert hasattr(SafariBaseIE(), '_real_initialize')


# Generated at 2022-06-24 13:06:19.396454
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from .testcommon import FakeLoginSession

    inst = SafariBaseIE()
    inst._login()
    assert inst.LOGGED_IN

    inst = SafariBaseIE(FakeLoginSession())
    inst._login()
    assert inst.LOGGED_IN

# Generated at 2022-06-24 13:06:30.587721
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .youtube import YoutubeIE
    from .common import InfoExtractor
    from .compat import compat_urlparse

    def test_safari_url_constructor(url, course_id, part):
        parsed_url = compat_urlparse.urlparse(url)
        safari_ie = SafariIE(InfoExtractor())
        course_id_ = safari_ie._match_id(parsed_url)
        course_part_ = safari_ie._match_id(parsed_url, "part")

        assert course_id_ == course_id
        assert course_part_ == part

    def test_is_safari_url(url):
        from .compat import compat_urlparse
        from .common import InfoExtractor
        parsed_url = compat_urlparse.urlparse(url)
        info_

# Generated at 2022-06-24 13:06:33.934245
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    try:
        safaribooks = SafariBaseIE()
    except TypeError:
        return False
    # Safari service requires a login.
    # Check that _login() method is implemented
    _ = safaribooks.LOGGED_IN
    return True

# Generated at 2022-06-24 13:06:40.972719
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """
    Unit test for constructor of class SafariCourseIE.
    This is a module-level function, not a method of unittest.TestCase.
    """
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')

# Generated at 2022-06-24 13:06:43.210749
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    print("I've got some coffee for you.")
    print("But, no tea right now.")
    #assert False, 'Test for SafariCourseIE'

# Generated at 2022-06-24 13:06:48.983740
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base = SafariBaseIE()

    assert safari_base._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base._NETRC_MACHINE == 'safari'

    assert safari_base._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base._API_FORMAT == 'json'

    assert safari_base.LOGGED_IN == False

# Generated at 2022-06-24 13:06:53.538951
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    safari_api_ie = SafariApiIE(url)
    assert isinstance(safari_api_ie, SafariApiIE)

# Generated at 2022-06-24 13:06:54.138456
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE

# Generated at 2022-06-24 13:06:57.457728
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9780134664057/chapter/RHCE_Introduction.html'
    SafariApiIE().suitable(url)
    

# Generated at 2022-06-24 13:06:58.039428
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    pass

# Generated at 2022-06-24 13:06:59.758657
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    try:
        SafariBaseIE()
    except:
        assert False

# Generated at 2022-06-24 13:07:01.124936
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie._NETRC_MACHINE == 'safari'

# Generated at 2022-06-24 13:07:03.128064
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE(SafariCourseIE.ie_key())

# Generated at 2022-06-24 13:07:07.543236
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    ie = SafariApiIE()
    web_url = ie._real_extract(url)
    assert web_url is not None

# Generated at 2022-06-24 13:07:09.095375
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from . import safari
    safari.SafariIE()



# Generated at 2022-06-24 13:07:15.087757
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Fake classes for Login mixin to work
    class FakeInfoExtractor(SafariBaseIE):
        IE_NAME = 'Fake'
    class FakeExtractorError(ExtractorError):
        pass

    # Uncomment the following section to print out errors in _login method
    """
    def print_error(error):
        print(error)

    SafariBaseIE.add_ie(FakeInfoExtractor)
    ie = FakeInfoExtractor({})
    ie.add_default_error_handler(print_error)
    ie._real_initialize()
    SafariBaseIE._ies.remove(FakeInfoExtractor)
    """

    # Test cases with correct credentials
    username = 'safari_test'
    password = 'safari_test'

    # Test cases with incorrect credentials
    # username = 'safari_incorrect'


# Generated at 2022-06-24 13:07:25.289461
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    base_url = 'https://www.safaribooksonline.com/api/v1/'
    url = base_url + 'book/9781449396459/?override_format=json'
    obj = SafariApiIE(SafariBaseIE)
    info = obj._call_api(url,'9781449396459')
    assert info['title'] =='Learning Python'
    assert info['author'] == 'Mark Lutz'
    assert info['publisher'] == 'O\'Reilly Media'
    assert info['ISBN'] == '9781449396459'
    assert info['book_id'] == '9781449396459'
    url = base_url + 'book/9781449396459/?override_format=%s' % obj._API_FORMAT

# Generated at 2022-06-24 13:07:29.997076
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # test for issue #4207
    SafariApiIE('https://www.safaribooksonline.com/api/v1/book/9780134085923/chapter/part01.html')

# Generated at 2022-06-24 13:07:34.720264
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """
    Unit test for constructor of class SafariCourseIE
    """
    safari_course_test_instance = SafariCourseIE()
    assert safari_course_test_instance.IE_NAME == 'safari:course'
    assert safari_course_test_instance.IE_DESC == 'safaribooksonline.com online courses'

# Generated at 2022-06-24 13:07:36.714012
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE('safari', None)
    assert ie.IE_DESC is None

# Generated at 2022-06-24 13:07:38.027546
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Check that constructor doesn't crash
    m = SafariCourseIE()

# Generated at 2022-06-24 13:07:39.723883
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    pass

if __name__ == '__main__':
    test_SafariBaseIE()

# Generated at 2022-06-24 13:07:40.279523
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-24 13:07:47.432147
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from ytdl.utils import locate_executable

    ytdl = locate_executable('youtube-dl', opt_dirs=['.'])
    test_url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    cmd = [ytdl, '-i', '--ignore-config', '--no-color', '--no-warnings', '--dump-json', '--', test_url]
    out = subprocess.check_output(cmd, stderr=subprocess.STDOUT)
    json_out = json.loads(out)
    assert 'webpage_url' in json_out
    assert 'entry_url' in json_out

# Generated at 2022-06-24 13:07:50.083736
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE("https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json")

# Generated at 2022-06-24 13:08:00.481750
# Unit test for constructor of class SafariIE