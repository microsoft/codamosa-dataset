

# Generated at 2022-06-24 12:58:07.114782
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from .common import FakeDomainTestCase
    from ..utils import TEST_HTTP_HEADERS

    test_object = SafariBaseIE({}, None, '')

    # test the case when authentication has failed
    with FakeDomainTestCase(test_object, 'www.oreilly.com', 'learning.oreilly.com'):
        test_object._download_webpage = lambda *args, **kwargs: (None, None)
        test_object._login()

    # test the case when authentication has succeeded

# Generated at 2022-06-24 12:58:13.974926
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    course_id = '9780134664057'
    url = 'https://www.safaribooksonline.com/library/view/learning-path-red/9780134664057/'
    info_dict = {
        'title': 'Learning Path: Red Hat Enterprise Linux',
    }
    assert SafariCourseIE().suitable(url)
    # assert SafariCourseIE()._real_extract(url) == info_dict
    assert SafariCourseIE()._real_extract(url)['id'] == course_id

# Generated at 2022-06-24 12:58:17.724319
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Initialize a SafariBaseIE: that's all we can test at the moment
    # (no login, no logged-in)
    try:
        i = SafariBaseIE()
    except:
        assert(False)

# Generated at 2022-06-24 12:58:23.819719
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .test_extractors import get_testcases
    from .test_extractors import get_testcases_by_name
    from .common import TEST_ID

    for case in get_testcases(SafariApiIE, 'SafariApiIE'):
        if case.get('expected_status'):
            # These are expected to fail
            continue

        url = case['url']
        urlh = get_testcases_by_name(
            SafariCourseIE, url.split('/')[-1], url)[0]

        obj = SafariApiIE(urlh)

        assert obj.LOGGED_IN is False
        assert obj.TEST_ID == TEST_ID
        assert obj._NETRC_MACHINE == 'safari'

# Generated at 2022-06-24 12:58:26.497264
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    safari_base_ie.IE_NAME = 'test_safari_base_ie'
    safari_base_ie.IE_DESC = 'test_safari_base_ie description'

# Generated at 2022-06-24 12:58:28.890637
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safariapi = SafariApiIE(SafariApiIE.ie_key())
    return safariapi

# Generated at 2022-06-24 12:58:33.599198
# Unit test for constructor of class SafariIE
def test_SafariIE():
    m = re.search(SafariIE._VALID_URL, 'http://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838/9780133392838-00_SeriesIntro')
    if m is None:
        raise AssertionError('SafariIE constructor failed')

# Generated at 2022-06-24 12:58:35.393065
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE('test@email.com', 'testPassword', 'test_instance')


# Generated at 2022-06-24 12:58:44.812109
# Unit test for constructor of class SafariIE

# Generated at 2022-06-24 12:58:49.259524
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """
    Test class constructor.
    """
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    ie = SafariCourseIE(url)
    course = ie.extract(url)
    assert course['id'] == '9780133392838'

# Generated at 2022-06-24 12:58:50.691538
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .. import SafaribooksonlineIE
    assert issubclass(SafaribooksonlineIE, SafariIE)

# Generated at 2022-06-24 12:58:52.432338
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    assert isinstance(ie, SafariCourseIE)

# Generated at 2022-06-24 12:58:54.393392
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert isinstance(SafariCourseIE('safari:course'), SafariCourseIE)
    assert isinstance(SafariCourseIE('safari:api'), SafariCourseIE)
    assert isinstance(SafariCourseIE('safari'), SafariCourseIE)

# Generated at 2022-06-24 12:58:56.095296
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    cls = SafariCourseIE()
    cls._initialize()

# Generated at 2022-06-24 12:58:58.514370
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari = SafariApiIE()
    assert safari.IE_NAME == 'safari:api'



# Generated at 2022-06-24 12:59:00.420332
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()

# Generated at 2022-06-24 12:59:05.657591
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    import sys
    import os
    sys.path.insert(0, os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', '..', 'ytdl')))
    from ytdl.extractor import SafariCourseIE as testSafariCourseIE
    testSafariCourseIE.suitable

# Generated at 2022-06-24 12:59:08.099790
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course = SafariCourseIE()
    assert safari_course._API_BASE == 'https://learning.oreilly.com/api/v1'

# Generated at 2022-06-24 12:59:15.756171
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    u = 'https://learning.oreilly.com/library/view/puppet-default/9781617292435/testing_encoding_utf8.html'
    ie = SafariBaseIE(u)
    # check that SafariBaseIE.__init__ takes account of the url scheme
    assert (ie.url == 'https://learning.oreilly.com/library/view/puppet-default/9781617292435/testing_encoding_utf8.html')

# Generated at 2022-06-24 12:59:16.272880
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE('SafariBaseIE', True)

# Generated at 2022-06-24 12:59:19.072688
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE(SafariBaseIE._downloader, "http://notaurl")
    assert ie.url == "http://notaurl", "Unit test for login of SafariBaseIE"


# Generated at 2022-06-24 12:59:29.758092
# Unit test for constructor of class SafariCourseIE

# Generated at 2022-06-24 12:59:31.221876
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    safari_ie._real_initialize()

# Generated at 2022-06-24 12:59:33.838838
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    """Constructor for SafariBaseIE"""
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-24 12:59:34.492959
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    pass

# Generated at 2022-06-24 12:59:40.345293
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test the constructor of class SafariBaseIE.
    # url: url of the webpage that embedding the video.
    # video_id: video-id of the video.
    url = 'https://www.safaribooksonline.com/library/view/the-python-classic/9781565922259/ch02s05.html'
    video_id = '9780133392838-00_SeriesIntro'
    SafariBaseIE()._real_extract(url)
    return

# Generated at 2022-06-24 12:59:48.340525
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # test attributes of SafariIE
    safari = SafariIE()
    assert safari.LOGGED_IN == False
    assert safari.IE_NAME == 'safari'
    assert safari.IE_DESC == 'safaribooksonline.com online video'
    assert safari._VALID_URL == 'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html'
    assert safari._PARTNER_ID == '1926081'
    assert safari._UICONF_ID == '29375172'


# Generated at 2022-06-24 12:59:51.293707
# Unit test for constructor of class SafariIE
def test_SafariIE():
    test_url = object()
    test_ie = object()
    instance = SafariIE(test_ie)
    assert instance._ie == test_ie
    assert instance._url == test_url

# Generated at 2022-06-24 12:59:52.952754
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_ie = SafariCourseIE()
    assert safari_course_ie is not None

# Generated at 2022-06-24 12:59:55.260313
# Unit test for constructor of class SafariIE
def test_SafariIE():
    class TestSafariIE(SafariIE):
        def _login(self):
            pass

    TestSafariIE()

# Generated at 2022-06-24 13:00:03.787156
# Unit test for constructor of class SafariIE
def test_SafariIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    safariIE = SafariIE()
    safariIE._real_initialize()
    safariIE.url_result(url, 'Safari')
    safariIE.real_extract(url)

# Generated at 2022-06-24 13:00:08.160740
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.__class__.__name__ == 'SafariIE'
    # verify the type of some attributes
    assert isinstance(ie._downloader, type(None))
    assert isinstance(ie._working_dir, type(None))
    assert isinstance(ie._output_template, type(''))
    assert isinstance(ie._progress_hooks, type([]))
    assert isinstance(ie._num_downloads, type(0))
    assert isinstance(ie._ie_key, type(''))
    assert isinstance(ie._LOGIN_URL, type(''))
    assert isinstance(ie._NETRC_MACHINE, type(''))
    # verify the value of some attributes
    assert ie._ie_key == 'Safari'
    assert ie._NETRC_M

# Generated at 2022-06-24 13:00:10.724063
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # TODO: fix this because it's not a real unit test.
    # We use it as a check that no exception is raised by the constructor.
    safari = SafariBaseIE()

# Generated at 2022-06-24 13:00:15.257578
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE('Safari')
    assert safari_ie.LOGGED_IN == False
    assert safari_ie._partner_id == '1926081'
    assert safari_ie._uiconf_id == '29375172'

# Generated at 2022-06-24 13:00:17.184965
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    assert ie.IE_NAME == 'safari'

# Generated at 2022-06-24 13:00:28.890863
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # This can be used to test a broken implementation
    # (for instance when the extractor has disabled private videos support)
    safari_test_broken = type('test_safari_broken', (SafariBaseIE,), {})
    with safari_test_broken._build_request('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html') as req:
        assert req.headers['Referer'] == 'https://learning.oreilly.com/accounts/login/'
        # TODO remove when cookie is fixed on oreilly,
        # atm there are 2 orm-jwt cookies set
        assert 'orm-jwt' not in req.headers['Cookie']

# Generated at 2022-06-24 13:00:30.843615
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari = SafariCourseIE()
    instance = safari._real_initialize()
    assert(instance == SafariCourseIE)

# Generated at 2022-06-24 13:00:37.034148
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from safari.safari import SafariApiIE
    from .common import FakeYDL
    ydl = FakeYDL()
    ydl.add_info_extractor(SafariApiIE)
    ydl.extract_info('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json', download=False)

# Generated at 2022-06-24 13:00:38.074794
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()

# Generated at 2022-06-24 13:00:39.786913
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE('www.safaribooksonline.com', {})
    assert ie.IE_NAME == 'safari:course'

# Generated at 2022-06-24 13:00:41.143000
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """Unit test for constructor of class SafariCourseIE"""
    c = SafariCourseIE()

# Generated at 2022-06-24 13:00:53.990702
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import unittest

    class TestCase(unittest.TestCase):
        def test_extract_chapter(self):
            import safari
            ie = safari.SafariIE()

            def assert_chapter(chapter, expected_id, expected_title):
                self.assertEqual(chapter['entry_id'], expected_id)
                self.assertEqual(chapter['chapter_title'], expected_title)
                self.assertTrue(chapter['url'].endswith(expected_title + '.html'))

            assert_chapter(
                ie._extract_chapter(
                    'What is Hadoop?',
                    {'chapter_index': '1', 'chapter_id': '00'}),
                '00', 'What is Hadoop?')


# Generated at 2022-06-24 13:01:07.167858
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.IE_NAME == 'safari'
    assert ie.IE_DESC == 'safaribooksonline.com online video'
    assert ie._VALID_URL == r'''(?x)
                               https?://
                                   (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                                   (?:
                                       library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                       videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                                   )
                               '''

# Generated at 2022-06-24 13:01:19.163436
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # super class test
    assert SafariApiIE.IE_NAME == 'safari:api'
    assert SafariApiIE.IE_DESC == 'safaribooksonline.com online courses'
    assert SafariApiIE._VALID_URL == 'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'
    # base class test
    assert SafariApiIE._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert SafariApiIE._API_FORMAT == 'json'
    assert SafariApiIE.LOGGED_IN == False

# Generated at 2022-06-24 13:01:21.374014
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # this should raise an error if SafariBaseIE isn't a class
    instance = SafariBaseIE()
    assert instance is not None

# Generated at 2022-06-24 13:01:28.240476
# Unit test for constructor of class SafariIE
def test_SafariIE():
    url = 'https://www.safaribooksonline.com/library/view/' \
        'hadoop-fundamentals-livelessons/9780133392838/part00.html'
    safariIE = SafariIE(SafariBaseIE)
    assert safariIE._VALID_URL == \
        'https?://(?:www\\.)?(?:safaribooksonline|(?:learning\\.)?oreilly)\\.com/library/view/[^/]+/[^/]+/(?P<part>[^/?\\#&]+)\\.html'

# Generated at 2022-06-24 13:01:34.342464
# Unit test for constructor of class SafariIE
def test_SafariIE():
    test_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    assert SafariIE.suitable(test_url)
    assert re.match(SafariIE._VALID_URL, test_url)
    assert SafariIE.ie_key() == 'Safari'
    assert SafariIE.ie_name() == 'safaribooksonline.com online video'



# Generated at 2022-06-24 13:01:36.300540
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE(SafariIE.IE_NAME)
    assert ie.__class__.__name__ == 'SafariIE'


# Generated at 2022-06-24 13:01:37.057614
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    obj = SafariBaseIE()
    assert (not obj.LOGGED_IN)

# Generated at 2022-06-24 13:01:49.635129
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # this test requires a safaribooksonline.com account
    from .test_utils import get_testdata_file
    import netrc

    def fake_download_webpage(*args, **kwargs):
        return args[0], compat_urllib_request.urlopen(args[0])

    safari_ie = SafariIE()
    safari_ie.download_webpage = fake_download_webpage

    # test authorized download
    safari_ie._login_info = netrc.netrc(get_testdata_file('netrc')).authenticators(safari_ie._NETRC_MACHINE)
    url = 'http://techbus.safaribooksonline.com/9780134426365'
    safari_ie._real_initialize()
    assert safari_ie.suitable(url)

# Generated at 2022-06-24 13:02:01.760996
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    class test_SafariCourseIE_Fetch_mock(object):
        def __init__(self, course_id):
            self.course_id = course_id
            self.result = {
                'chapters': [
                    'https://safaribooksonline.com/api/v1/book/9781449396459/chapter-content/0_0udzkfzr.html',
                    'https://safaribooksonline.com/api/v1/book/9781449396459/chapter-content/0_eapc35hu.html'
                ],
                'title': 'Test Course'
            }

        def text(self):
            return json.dumps(self.result)

    import inspect
    import io
    import json
    import pytest

    from .common import InfoExt

# Generated at 2022-06-24 13:02:08.906366
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .common import InfoExtractor
    from .utils import ExtractorError

    def mock_suitable(url):
        if url.startswith('http://www.safaribooksonline.com/api/v1/book/9781449396459'):
            return True
        else:
            return False

    InfoExtractor.suitable = mock_suitable

    def mock_download_json(url, video_id, message, errnote, fatal=True, query={}, headers={}, data=None, expected_status=None, transform_source=None):
        if url.startswith('http://www.safaribooksonline.com/api/v1/book/9781449396459'):
            return {
                'chapters': [],
                'title': 'TestTitle'
            }

# Generated at 2022-06-24 13:02:10.480985
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()
    assert isinstance(safari_api_ie, SafariApiIE)


# Generated at 2022-06-24 13:02:11.248194
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert type(SafariCourseIE) == SafariCourseIE

# Generated at 2022-06-24 13:02:17.215871
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()

    assert ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)|videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+))'
    assert ie._NETRC_MACHINE == 'safari'
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'
    assert ie.LOGGED_IN == False
    assert ie.IE_NAME == 'safari'
    assert ie.IE_

# Generated at 2022-06-24 13:02:27.798573
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    class _SafariApiIE(SafariApiIE):
        def _download_json(self, url_or_request, video_id, note, errnote, fatal, headers=None):
            return json.loads('{"web_url":"https://www.safaribooksonline.com/library/view/file.html"}')
    safari_api_ie = _SafariApiIE()
    assert 'safari' in safari_api_ie.suitable(
        'https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html')

# Generated at 2022-06-24 13:02:32.869219
# Unit test for constructor of class SafariIE
def test_SafariIE():
    web_page_url = 'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838'
    info = {}
    SafariIE()
    return web_page_url, info


# Generated at 2022-06-24 13:02:34.906608
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE(SafariBaseIE)

# Generated at 2022-06-24 13:02:45.579418
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    mobj = re.match(SafariApiIE._VALID_URL, url)
    course_id = mobj.group('course_id')
    part = mobj.group('part')
    # Expected construction
    safari = SafariApiIE()
    safari._download_json(url, '%s/%s' % (course_id, part), 'Downloading part JSON')
    # Unexpected construction to check if it fails as expected
    try:
        safari = SafariApiIE(None)
        safari.report_warning('Expected constructor failure')
        assert False
    except TypeError:
        pass

# Generated at 2022-06-24 13:02:49.995811
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .test_search import MockIE
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    safariIE = SafariIE()
    safariIE.add_ie(MockIE())
    # checking that constructor of SafariIE class works
    safariIE.extract(url)

# Generated at 2022-06-24 13:02:50.892543
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie_ = SafariBaseIE('SafariBaseIE')

# Generated at 2022-06-24 13:02:52.003942
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    _ = lambda x: x
    _(SafariCourseIE)


# Generated at 2022-06-24 13:02:52.601499
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-24 13:02:54.186146
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safariBaseIE = SafariBaseIE()
    safariBaseIE.login()


# Generated at 2022-06-24 13:02:55.679617
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .common import TestSafariIE
    TestSafariIE.test()


# Generated at 2022-06-24 13:02:58.302174
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE('https://learning.oreilly.com/api/v1/book/9781118975425/')
    assert isinstance(ie, SafariCourseIE)

# Generated at 2022-06-24 13:03:03.256139
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .test_safari import SafariTestCase

    test = SafariTestCase()
    test._test_base_class_and_functions(SafariApiIE)
    test._test_recommended_video(SafariApiIE)

# Generated at 2022-06-24 13:03:05.201289
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    course = SafariCourseIE(url)
    assert course._VALID_URL == SafariCourseIE._VALID_URL

# Generated at 2022-06-24 13:03:05.948225
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    obj = SafariBaseIE('safari')
    assert obj.LOGGED_IN == False

# Generated at 2022-06-24 13:03:06.329518
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    pass

# Generated at 2022-06-24 13:03:12.538531
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    api_ie = SafariApiIE('safari:api')
    assert api_ie._VALID_URL == 'https?://(?:www\\.)?(?:safaribooksonline|(?:learning\\.)?oreilly)\\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\\.html'

# Generated at 2022-06-24 13:03:18.138990
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    tester = SafariApiIE('SafariApiIE')
    print(tester)
    assert('SafariApiIE' == tester.IE_NAME)
    assert('safaribooksonline.com online courses' == tester.IE_DESC)


# Generated at 2022-06-24 13:03:22.851844
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """ Test extraction of chapter url from SafariApiIE """
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/ch12.html'
    expected = 'https://www.safaribooksonline.com/library/view/introduction-to-data/9781449396459/ch12.html'

    ie = SafariApiIE()
    chapter = ie._real_extract(url)
    assert chapter['url'] == expected

# Generated at 2022-06-24 13:03:32.679776
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    class DummySafariCourseIE(SafariCourseIE):
        def _download_json(self, url, video_id, note, errnote, fatal=True, headers=None):
            keys = [
                'creators', 'description', 'modification_date', 'chapters', 'title',
                'cover_image', 'publication_date', 'book_format', 'authors', 'categories',
                'isbn_13', 'publisher', 'table_of_contents_url', 'length', 'isbn_10',
                'web_url'
            ]
            return [{k: k for k in keys} for _ in range(3)]

    course_id = '9780133392838'

# Generated at 2022-06-24 13:03:34.091791
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    init_Class_SafariApiIE = SafariApiIE()

# Generated at 2022-06-24 13:03:44.103187
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Note for developers: please do a dry-run for the unit test every time you add a test case
    # and check for any error messages in the log.
    ie = SafariIE()
    assert ie._VALID_URL == SafariIE._VALID_URL
    assert ie._TESTS == SafariIE._TESTS
    assert ie._PARTNER_ID == SafariIE._PARTNER_ID
    assert ie._UICONF_ID == SafariIE._UICONF_ID
    assert ie.ie_key() == 'Kaltura'
    assert ie.suitable(ie._VALID_URL) is True
    assert ie.suitable(
        'http://www.example.com/index.php?page=video_page') is False

# Generated at 2022-06-24 13:03:49.106531
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """Test case for constructor of class SafariApiIE."""
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/' \
          'chapter/part00.html'
    safari_api_ie = SafariApiIE(url)
    assert safari_api_ie._VALID_URL == url

# Generated at 2022-06-24 13:03:58.150999
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Assume SafariApiIE is used for extracting video URL from
    # https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html
    # and construct a fake SafariApiIE object.
    test_handler = SafariBaseIE._make_test_handler({
        'json': {
            'web_url': 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
        },
        'webpage': '<html><head></head><body><div>'
    })
    safari_api_ie = SafariApiIE(test_handler)
    safari_api_ie._test_result_extensions = ['mp4']

   

# Generated at 2022-06-24 13:04:09.004817
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import os
    from .kaltura import KalturaIE
    from .common import InfoExtractor
    from ..conf import __version__


# Generated at 2022-06-24 13:04:10.797677
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    _ebook_ie = SafariApiIE()
    assert 'safari:api' == _ebook_ie.IE_NAME
    assert 'safaribooksonline.com online video' in _ebook_ie.IE_DESC

# Generated at 2022-06-24 13:04:12.409872
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    instance = SafariApiIE()
    print(instance)

# Generated at 2022-06-24 13:04:14.866270
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    a = SafariApiIE(SafariBaseIE._downloader, 'http://example.com/api')
    assert a.__class__.__name__ == 'SafariApiIE', '__class__ attribute of class was not set properly'

# Generated at 2022-06-24 13:04:16.593978
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    assert isinstance(ie, SafariCourseIE)
    assert isinstance(ie, SafariBaseIE)
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 13:04:18.695445
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert hasattr(ie, '_download_webpage_handle')

# Generated at 2022-06-24 13:04:19.618129
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-24 13:04:24.142188
# Unit test for constructor of class SafariIE
def test_SafariIE():
    expected = SafariIE

    class TestSafariIE(SafariIE):
        pass

    assert TestSafariIE.suitable(expected._VALID_URL)
    assert expected == TestSafariIE('safari')



# Generated at 2022-06-24 13:04:29.380648
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    ie.initialize()
    username, password = ie._get_login_info()
    if username and password:
        ie._login()
        assert(ie.LOGGED_IN)
    else:
        assert(not ie.LOGGED_IN)
    del ie

# Generated at 2022-06-24 13:04:31.942517
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # set variable to check
    safaribooksonline = SafariCourseIE

    # check variable
    assert isinstance(safaribooksonline, type)

# Generated at 2022-06-24 13:04:33.462667
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    obj = SafariCourseIE()
    assert obj.IE_NAME == "safari:course"

# Generated at 2022-06-24 13:04:41.250989
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    inst = SafariCourseIE()
    inst.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    inst.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314')
    inst.suitable('https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838')
    inst.suitable('https://www.oreilly.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')

# Generated at 2022-06-24 13:04:42.400152
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    t = SafariBaseIE()

# Generated at 2022-06-24 13:04:44.393118
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # try to create an instance of SafariCourseIE
    SafariCourseIE()


# Generated at 2022-06-24 13:04:46.470245
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    class MockSafariCourseIE(SafariCourseIE):
        _download_json = lambda self, *args, **kwargs: {}
    assert isinstance(MockSafariCourseIE('url')._downloader, InfoExtractor)
    assert isinstance(MockSafariCourseIE._downloader('url')._downloader, InfoExtractor)

# Generated at 2022-06-24 13:04:50.000244
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from .test.test_utils import PytestTester

    tester = PytestTester(SafariBaseIE)
    tester.test_class(SafariBaseIE, needs_webdriver=True)

# Generated at 2022-06-24 13:04:55.595841
# Unit test for constructor of class SafariIE
def test_SafariIE():
    module = sys.modules[__name__]
    _function = getattr(module, 'test_SafariIE')
    _class = getattr(module, 'SafariIE')

    # Try to build a SafariIE object
    safari = _class()

    print("SafariIE: " + str(safari))


# Generated at 2022-06-24 13:04:56.275237
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie_instance = SafariCourseIE()

# Generated at 2022-06-24 13:04:59.284969
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    assert ie._downloader is not None
    assert ie._api_base == 'https://learning.oreilly.com/api/v1'
    assert ie._api_fmt == 'json'

# Generated at 2022-06-24 13:05:00.514181
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('safari')

# Generated at 2022-06-24 13:05:09.273611
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test SafariCourseIE.suitable()
    video_ie = SafariIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert video_ie == True

    video_api_ie = SafariApiIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert video_api_ie == True

    course_ie = SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert course_ie == True

# Generated at 2022-06-24 13:05:12.494315
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """
    When SafariIE is constructed, it should set LOGGED_IN value as boolean
    """
    safari = SafariIE()
    assert isinstance(
        safari.LOGGED_IN, bool), 'LOGGED_IN value should be boolean'

# Generated at 2022-06-24 13:05:13.984712
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE(None)
    assert ie.LOGGED_IN == False

# Generated at 2022-06-24 13:05:15.660423
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE.suitable("http://techbus.safaribooksonline.com/9780134664057")

# Generated at 2022-06-24 13:05:28.094775
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()
    # Class instance asserts
    assert safari_api_ie.ie_key() == 'SafariApiIE'
    assert safari_api_ie.ie_name() == 'safari:api'
    assert safari_api_ie.ie_desc() == 'safaribooksonline.com online courses'
    assert safari_api_ie.VALID_URL == safari_api_ie._VALID_URL
    assert safari_api_ie.TEST == safari_api_ie._TESTS
    assert safari_api_ie._API_FORMAT == 'json'
    assert safari_api_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    # Class instance methods asserts
    safari_

# Generated at 2022-06-24 13:05:31.761946
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # In this test, we're assuming that config.py is set up to contain
    # valid username and password for safaribooksonline.com. This
    # will allow the test to run without user interaction.
    test_SafariBaseIE = SafariBaseIE()

# Generated at 2022-06-24 13:05:37.221428
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from .accounts import safaribooksonline
    cfg = {'username': safaribooksonline.username,
           'password': safaribooksonline.password}
    i = SafariBaseIE(cfg)
    assert i is not None

# Generated at 2022-06-24 13:05:38.311408
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    _ = SafariApiIE({})

# Generated at 2022-06-24 13:05:41.898048
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_apiIE = SafariApiIE()
    assert safari_apiIE._VALID_URL
    assert safari_apiIE.IE_NAME
    assert safari_apiIE._TESTS

# Generated at 2022-06-24 13:05:43.421808
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    ie._login()

# Generated at 2022-06-24 13:05:46.361040
# Unit test for constructor of class SafariIE
def test_SafariIE():
    oe = SafariIE()
    assert oe.IE_NAME == 'safari'
    assert oe.IE_DESC == 'safaribooksonline.com online video'


# Generated at 2022-06-24 13:05:48.793383
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class TestSafariBaseIE(SafariBaseIE):
        def _real_initialize(self):
            assert sel

# Generated at 2022-06-24 13:05:53.154587
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .common import FakeDL, InfoExtractor
    from .mock import MagicMock
    assert SafariCourseIE(InfoExtractor())._login == SafariBaseIE.login
    assert SafariCourseIE(InfoExtractor(), lambda _: None)._login is None

# Generated at 2022-06-24 13:05:55.367084
# Unit test for constructor of class SafariIE
def test_SafariIE():
    _check_ie_class(SafariIE)

# Generated at 2022-06-24 13:05:58.950208
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()
    # Create an entry for safari.com for testing purposes
    safari.to_screen('Safari Bookshelf is not yet tested')

# Generated at 2022-06-24 13:06:08.719023
# Unit test for constructor of class SafariCourseIE

# Generated at 2022-06-24 13:06:10.158977
# Unit test for constructor of class SafariIE
def test_SafariIE():
    constructor = SafariBaseIE.ie_key()
    instance = constructor('safaribooksonline.com')
    assert isinstance(instance, SafariIE)

test_SafariIE()

# Generated at 2022-06-24 13:06:14.955800
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()
    assert safari_api_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_api_ie._API_FORMAT == 'json'

# Generated at 2022-06-24 13:06:26.838006
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safariApiIE = SafariApiIE()
    safariApiIE._LOGIN_URL = u'https://learning.oreilly.com/accounts/login/'
    safariApiIE._NETRC_MACHINE = u'safari'
    safariApiIE._API_BASE = u'https://learning.oreilly.com/api/v1'
    safariApiIE._API_FORMAT = u'json'
    safariApiIE.LOGGED_IN = False
    safariApiIE._login()
    safariApiIE._real_extract("https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html")

# Generated at 2022-06-24 13:06:28.543504
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():

    SafariApiIE(SafariApiIE.ie_key(), SafariApiIE._VALID_URL)

# Generated at 2022-06-24 13:06:33.075099
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course = SafariCourseIE('https://www.safaribooksonline.com/api/v1/book/9781449396459')
    assert course._TESTS[0]['url'] == 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'

# Generated at 2022-06-24 13:06:45.850362
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    klass = SafariBaseIE
    klass.suitable().__call__(object)
    klass.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    klass.suitable('http://techbus.safaribooksonline.com/9780134426365')
    klass.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314')
    klass.suitable('https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838')

# Generated at 2022-06-24 13:06:54.513838
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    dl = SafariApiIE()
    url = "https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json"
    mobj = re.match(dl._VALID_URL, url)
    part = dl._download_json(url, '%s/%s' % (mobj.group('course_id'), 'chapter-content'), 'Downloading part JSON')
    assert part['web_url'].endswith('0001.html')


# Generated at 2022-06-24 13:06:57.856729
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    saf = SafariApiIE()
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    saf.url_result(url, 'Safari')

# Generated at 2022-06-24 13:07:03.638162
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    class_ = SafariApiIE
    expected_attributes = ['_API_BASE', '_API_FORMAT']
    # Ensure that each attribute exists in the class as a property object
    for attribute in expected_attributes:
        assert hasattr(class_, attribute)
        # Ensure that attribute is a property
        assert isinstance(getattr(class_, attribute), property)

if __name__ == '__main__':
    test_SafariApiIE()

# Generated at 2022-06-24 13:07:15.462630
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test for kwargs that shouldn't change how the extractor behaves
    # in any way
    for spurious_kwargs in [{}, {'ie': 'some_ie'}, {'fmt': 'some_fmt'},
                            {'fmt': 'some_fmt', 'extra_info': {}},
                            {'ie': 'some_ie', 'extra_info': {}},
                            {'extra_info': {}}]:
        # Test that nothing breaks if an unexpected keyword arg is passed
        ie = SafariBaseIE(**spurious_kwargs)
        # Test that the extra info and formats aren't changing
        assert ie._downloader.cache.extra_info_dict == {}
        assert ie._downloader.cache.formats == {}
        # Test that the extractor is working properly

# Generated at 2022-06-24 13:07:16.442580
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
  pass


# Generated at 2022-06-24 13:07:18.199035
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    try:
        SafariApiIE()
        assert False
    except ValueError:
        pass

# Generated at 2022-06-24 13:07:27.659892
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test with machine present in netrc
    machine = 'safari'
    test_data = [
        ('machine %s login a@a.com password p' % machine, 'a@a.com', 'p'),
        ('machine %s login a@a.com password p\nlogin a@a.com password q' % machine, 'a@a.com', 'p'),
    ]
    for content, username, password in test_data:
        with open('test.netrc', 'w') as f:
            f.write(content)
        obj = SafariBaseIE(None)
        assert obj._get_login_info() == (username, password)

    # Test with machine absent in netrc

# Generated at 2022-06-24 13:07:37.496651
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from ..test.test_html import FakeHtmlParser
    url = 'https://www.safaribooksonline.com/api/v1/book/9780134664057/chapter/RHCE_Introduction.html'
    mobj = re.match(SafariApiIE._VALID_URL, url)
    course_id = mobj.group('course_id')
    part = mobj.group('part')
    video_id = '%s/%s' % (course_id, part)
    webpage_mock = FakeHtmlParser.create_page(url, video_id)
    webpage_mock.add_headers({
        'Content-Type': 'application/json',
        'Content-Length': '105',
    })

# Generated at 2022-06-24 13:07:38.339029
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
	SafariApiIE("SafariApiIE")

# Generated at 2022-06-24 13:07:40.727529
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # SafariApiIE only exist to convert old-style reference_id URLs to new URL format.
    # New URL format already coverted by SafariIE, so SafariApiIE unit test is not needed.
    pass

# Generated at 2022-06-24 13:07:47.203180
# Unit test for constructor of class SafariIE
def test_SafariIE():
    global SafariIE
    import inspect
    import oauth2
    import oauthlib
    import cookielib
    assert (inspect.getfullargspec(SafariIE.__init__).args ==
            inspect.getfullargspec(oauth2.Client.__init__).args)
    assert (inspect.getfullargspec(SafariIE._real_extract).args ==
            inspect.getfullargspec(oauthlib.oauth2.Client._real_extract).args)
    assert (inspect.getfullargspec(SafariIE._download_webpage_handle).args ==
            inspect.getfullargspec(cookielib.LWPCookieJar._download_webpage_handle).args)

# Generated at 2022-06-24 13:07:57.473919
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .test_common import load_tests
    path = 'test/data/safari'
    fixture = load_tests(path)

    for test in fixture.get('tests', []):
        # test course completely
        test_url = 'https://www.safaribooksonline.com/api/v1/book/%s/?override_format=json' % test.get('title')
        ies = SafariCourseIE._get_ies()
        for ie in ies:
            if ie.suitable(test_url):
                ie_result = ie.extract(test_url)
                assert len(ie_result['entries']) == len(test['entries'])
        break