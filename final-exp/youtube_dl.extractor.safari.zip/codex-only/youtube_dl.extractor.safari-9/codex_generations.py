

# Generated at 2022-06-24 12:58:00.772307
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    constr = SafariApiIE
    ie = constr('http://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')

# Generated at 2022-06-24 12:58:03.337242
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_IE = SafariBaseIE()
    assert isinstance(safari_base_IE, InfoExtractor)

# Generated at 2022-06-24 12:58:05.006914
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert SafariBaseIE.suitable('http://safaribooksonline.com/some/url')



# Generated at 2022-06-24 12:58:07.836702
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .modules import safari

    ie = safari.SafariCourseIE(None)
    assert ie.ie_key() == 'Safari'
    assert ie.ie_name == 'safari'



# Generated at 2022-06-24 12:58:12.280220
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    o = SafariBaseIE()
    o._download_json(
        'https://learning.oreilly.com/api/v1/book/9781449396459/chapter-content/ch01.html/?override_format=json',
        '9781449396459/ch01', 'Downloading chapter JSON')

# Generated at 2022-06-24 12:58:16.484742
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()
    assert safari_api_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_api_ie._API_FORMAT == 'json'



# Generated at 2022-06-24 12:58:21.321754
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    cls = SafariApiIE
    # This import is intended to test lazy import of
    # class without having to initialize session.
    # Since it is a top level import, it also prevent
    # defining class in conditionals above
    from .safari import SafariApiIE as SafariApiIETest
    assert cls == SafariApiIETest

# Generated at 2022-06-24 12:58:33.288670
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    with open('test/data/safaribooksonline.json') as fp:
        json_data = json.load(fp)

    instance = SafariCourseIE()

    for testcase in json_data:
        # create the URL based on testcase id
        url = 'https://www.safaribooksonline.com/api/v1/book/%s/' % testcase['id']

        webpage = None
        urlh = None

        if 'webpage' in testcase:
            webpage = testcase['webpage']

        if 'urlh' in testcase:
            urlh = testcase['urlh']

        # call the SafariCourseIE class with url and url handle

# Generated at 2022-06-24 12:58:42.722751
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE.suitable('http://techbus.safaribooksonline.com/9780134426365')
    SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    SafariCourseIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314')
    SafariCourseIE.suitable('https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838')
    SafariCourseIE.su

# Generated at 2022-06-24 12:58:49.415712
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from ..utils import test_login_info, extract_attributes
    # Test that it's not an instance of InfoExtractor
    assert not isinstance(SafariBaseIE(), InfoExtractor)
    # Test login support
    site = 'safari'
    (username, password) = test_login_info(site) if site in test_login_info() else (None, None)
    # When username and password is None, it raises an error while calling _login()
    with extract_attributes(SafariBaseIE):
        assert SafariBaseIE(username, password).LOGGED_IN

# Generated at 2022-06-24 12:58:50.699104
# Unit test for constructor of class SafariIE
def test_SafariIE():
    inst = SafariIE()
    assert inst.ie_key() == 'Safari'

# Generated at 2022-06-24 12:58:55.729264
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test SafariBaseIE.__init__()
    assert SafariBaseIE(SafariIE()).LOGGED_IN is False
    assert SafariBaseIE(SafariApiIE()).LOGGED_IN is False
    assert SafariBaseIE(SafariCourseIE()).LOGGED_IN is False

# Generated at 2022-06-24 12:59:02.405428
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """Test constructor of class SafariCourseIE"""
    # Initialization
    safari_course_ie = SafariCourseIE()
    # Tests
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    safari_course_ie.suitable(url)



# Generated at 2022-06-24 12:59:03.068275
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-24 12:59:06.532775
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    # Force creating SafariApiIE instance
    ie.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')

# Generated at 2022-06-24 12:59:07.845432
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE('safari:course')

# Generated at 2022-06-24 12:59:09.622033
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from .test_utils import fake_login
    with fake_login('test', 'pass'):
        SafariBaseIE()

# Generated at 2022-06-24 12:59:12.902509
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()
    assert(isinstance(safari_api_ie, SafariApiIE))

# Generated at 2022-06-24 12:59:24.446852
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # assert SafariCourseIE('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')._VALID_URL.match('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json').group('id') == '9781449396459'
    assert SafariCourseIE('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')._VALID_URL.match('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json').group('id') == '9781449396459'

# Generated at 2022-06-24 12:59:29.144717
# Unit test for constructor of class SafariIE
def test_SafariIE():
    class UnitTestSafariIE(SafariIE):
        _NETRC_MACHINE = 'safari'
        _LOGIN_URL = 'https://learning.oreilly.com/accounts/login/'

        def _login(self):
            pass

        def _real_extract(self, url):
            pass

    tester = UnitTestSafariIE()
    tester.initialize()
    assert tester.LOGGED_IN == False

# Generated at 2022-06-24 12:59:35.065079
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    info = SafariApiIE().download(url)
    urls = [vid['url'] for vid in info['entries']]

# Generated at 2022-06-24 12:59:37.193285
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert ie.ie_key() == 'SafariApi'
    assert ie.LOGGED_IN is False

# Generated at 2022-06-24 12:59:39.652462
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    try:
        SafariCourseIE({})
    except Exception as e :
        if "super" not in str(e):
            raise Exception("Unexpected Exception : " + str(e))

# Generated at 2022-06-24 12:59:48.371994
# Unit test for constructor of class SafariIE

# Generated at 2022-06-24 12:59:51.294751
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    info = SafariCourseIE._info_dict()
    assert info['name'] == 'safari:course'
    assert info['title'] == 'safaribooksonline.com online courses'

# Generated at 2022-06-24 12:59:52.228763
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    instance = SafariCourseIE()

# Generated at 2022-06-24 12:59:53.907085
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safariIE = SafariIE()

    assert safariIE.get_login_info() is None

# Generated at 2022-06-24 12:59:56.615971
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE("")
    assert ie.SUCCESS == 0
    assert ie.FAILED == 1
    assert ie.SKIPPED == 2


# Generated at 2022-06-24 12:59:59.932572
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert SafariIE(None).LOGGED_IN == False



# Generated at 2022-06-24 13:00:02.034383
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()._login()

# Generated at 2022-06-24 13:00:03.568973
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    assert ie.LOGGED_IN == False

# Generated at 2022-06-24 13:00:08.427429
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import io
    import sys

    original_argv = sys.argv
    sys.argv = sys.argv[:1]

    try:
        # Test constructor without arguments
        assert hasattr(
            SafariIE(),
            '_download_webpage_handle')

    finally:
        sys.argv = original_argv

# Generated at 2022-06-24 13:00:09.758322
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariBaseIE()
    ie._real_initialize()

# Generated at 2022-06-24 13:00:19.098414
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    test_cases = [
        {'video_id': '9781484214322-G_000001_0.1'},
        {'video_id': '9781558608828-Chapter_00'}
    ]
    for test_case in test_cases:
        actual = SafariApiIE._build_url(**test_case)
        expected = 'https://www.safaribooksonline.com/api/v1/book/9781484214322/chapter/G_000001_0.1.html'
        assert actual == expected

from .common import update_url_query


# Generated at 2022-06-24 13:00:31.520932
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.__class__.__name__ == 'SafariIE'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/library/view/[^/]+/[^/]+/(?P<part>[^/?\#&]+)\.html'
    assert ie._NETRC_MACHINE == 'safari'
    assert ie._PARTNER_ID == '1926081'
    assert ie._UICONF_ID == '29375172'

# Generated at 2022-06-24 13:00:38.737488
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from .test_safari import FakeIE

    safari = SafariBaseIE(FakeIE())
    assert safari._NETRC_MACHINE == 'safari'
    assert safari._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari._API_FORMAT == 'json'
    assert safari.LOGGED_IN == False

# Generated at 2022-06-24 13:00:39.991971
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safaribase = SafariBaseIE()
    assert safaribase is not None

# Generated at 2022-06-24 13:00:52.734574
# Unit test for constructor of class SafariBaseIE

# Generated at 2022-06-24 13:01:05.860311
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .test_utils import get_testcases
    from .common import InfoExtractor

    # Contains tests for the constructor of class SafariApiIE
    # It extracts urls that can be used to construct a SafariApiIE
    # Then it extracts them using SafariApiIE
    def _test_constructor(self, safari_api_ie, testcase):
        safari_api_ie_initialized = SafariApiIE(InfoExtractor())._real_initialize()
        safari_api_ie_extract_urls = getattr(safari_api_ie_initialized, '_EXTRACT_URLS', [])

        for ie_url in safari_api_ie_extract_urls:
            self.assertIsInstance(ie_url, str)
            self.assertTrue(ie_url)

            ie_

# Generated at 2022-06-24 13:01:18.300550
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """
    Unit test for constructor of class SafariCourseIE
    """
    import unittest
    import yaml

    # Setup test
    test_url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459'
    test_dict = {
        'id': '9781449396459',
        'url': test_url + '/',
        'playlist_mincount': 1,
    }

    # Create test case
    class TestSafariCourseIE(unittest.TestCase):
        def setUp(self):
            self.c = SafariCourseIE()

        def test_safari_course_ie_constructor(self):
            """
            Test construction of the SafariCourseIE class
            """
            # Verify URL

# Generated at 2022-06-24 13:01:22.575199
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    import unittest
    suite = unittest.TestSuite()
    suite.addTest(unittest.TestLoader().loadTestsFromTestCase(TestSafariCourseIE))
    unittest.TextTestRunner().run(suite)


# Generated at 2022-06-24 13:01:27.396279
# Unit test for constructor of class SafariIE
def test_SafariIE():
    test = SafariIE('http://techbus.safaribooksonline.com/9780134426365/part00.html')
    assert(test.partner_id == '1926081')
    assert(test.uiconf_id == '29375172')
    test = SafariIE('https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html')
    assert(test.partner_id == '1926081')

# Generated at 2022-06-24 13:01:35.467608
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.__class__.__name__ == 'SafariIE'
    assert ie._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''

# Generated at 2022-06-24 13:01:37.355991
# Unit test for constructor of class SafariIE
def test_SafariIE():
    obj = SafariIE()
    assert obj.LOGGED_IN == False

# Generated at 2022-06-24 13:01:39.415990
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE(SafariCourseIE._create_ie_instance({}))

# Generated at 2022-06-24 13:01:45.446762
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Timestamp needs to be a valid integer
    try:
        SafariCourseIE(None)._real_extract('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    except ExtractorError:
        assert False

# Generated at 2022-06-24 13:01:54.529708
# Unit test for constructor of class SafariIE
def test_SafariIE():
    test = type('test', (object,), {'LEARNING_OREILLY_COM_CURRENT_URL': 'learning.oreilly.com/home/'})

    ie = SafariIE({})
    ie.LOGGED_IN = True
    assert ie._download_webpage_handle('https://learning.oreilly.com/accounts/login/', None, 'DWH') == (test(), test.LEARNING_OREILLY_COM_CURRENT_URL)

    ie = SafariIE({})
    ie.LOGGED_IN = False
    assert ie._download_webpage_handle('https://learning.oreilly.com/accounts/login/', None, 'DWH') == (test(), 'https://learning.oreilly.com/home/')

# Generated at 2022-06-24 13:01:57.712699
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """
    Construct an instance of SafariApiIE.
    """
    SafariApiIE("AnyString")

# Generated at 2022-06-24 13:02:05.248420
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .test_search import _BASE_SELENIUM_CLS
    class SeleniumSafariApiIE(_BASE_SELENIUM_CLS):
        IE_NAME = 'safari:api'
        _TEST = {
            'url': 'https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html',
            'info_dict': {
                'id': '0_qbqx90ic',
                'ext': 'mp4',
                'title': 'Introduction to Hadoop Fundamentals LiveLessons',
                'timestamp': 1437758058,
                'upload_date': '20150724',
                'uploader_id': 'stork',
            },
        }
    SeleniumSafari

# Generated at 2022-06-24 13:02:07.512464
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE.suitable('http://www.safaribooksonline.com/library/view/learning-path-red/9780134664057/RHCE_Introduction.html')

# Generated at 2022-06-24 13:02:12.722479
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ydl = YoutubeDL({})
    ydl.add_info_extractor(SafariApiIE)
    ydl.add_info_extractor(SafariIE)
    result = ydl.extract_info(
        'https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html',
        download=False)
    assert result['id'] == "Hadoop Fundamentals LiveLessons - Introduction to Hadoop Fundamentals LiveLessons (Part 0)"


# Generated at 2022-06-24 13:02:15.761467
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    course = SafariCourseIE(url)
    assert course.suitable(url)

# Generated at 2022-06-24 13:02:28.841389
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """Test for the SafariApiIE constructors."""
    # invalid URL
    invalid_test_cases = [
        'http://other.test.com/test/test.html',
        'http://www.safaribooksonline.com/',
        'http://www.safaribooksonline.com/library/view/test/test/1.html',
    ]

    for invalid_test_case in invalid_test_cases:
        with pytest.raises(ExtractorError):
            SafariApiIE.suitable(invalid_test_case)

    # valid URL

# Generated at 2022-06-24 13:02:41.217364
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """basic test case for SafariCourseIE constructor"""
    SafariCourseIE('http://techbus.safaribooksonline.com/9780134426365')
    SafariCourseIE('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    SafariCourseIE('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314')
    SafariCourseIE('https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838')
    SafariCourseIE('https://www.oreilly.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')

# Generated at 2022-06-24 13:02:50.413131
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    import pytest
    invalid_urls = [
        'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html',
        'https://www.safaribooksonline.com/videos/python-programming-language/9780134217314/9780134217314-PYMC_13_00',
        'https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html',
    ]
    for url in invalid_urls:
        with pytest.raises(ExtractorError) as e:
            SafariCourseIE().suitable(url)
        assert e.value.args[0] == 'Invalid URL: ' + url

# Generated at 2022-06-24 13:02:51.828318
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Simple check to see if SafariCourseIE's constructor can be called
    SafariCourseIE('Safari')

# Generated at 2022-06-24 13:02:53.464805
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    inst = SafariBaseIE()
    assert type(inst) == SafariBaseIE


# Generated at 2022-06-24 13:02:55.992437
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()
    assert safari.IE_NAME == 'safari'
    assert safari.IE_DESC == 'safaribooksonline.com online video'


# Generated at 2022-06-24 13:02:58.616170
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """
    Simple test for constructor of class SafariIE.
    Invoke constructor without arguments, if no Exception is raised
    then all is ok.
    """
    SafariIE()

# Generated at 2022-06-24 13:03:01.023632
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE(SafariBaseIE.suitable)
    assert isinstance(ie, SafariBaseIE)

# Generated at 2022-06-24 13:03:04.220704
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """Unit test for SafariIE."""
    ie = SafariIE()
    assert ie.LOGGED_IN == False

# Generated at 2022-06-24 13:03:06.060555
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    obj = SafariApiIE()
    assert obj.name == 'safari:api'



# Generated at 2022-06-24 13:03:18.335075
# Unit test for constructor of class SafariIE
def test_SafariIE():
    course_id = '9781449396459'
    course_title = 'JavaScript'
    course_url = ('https://www.safaribooksonline.com/library/view/%s/' % course_id)
    class_obj = SafariIE()

    # Testing fields overwrite
    assert(class_obj._NETRC_MACHINE == 'safari')
    assert(class_obj._API_BASE == 'https://learning.oreilly.com/api/v1')

# Generated at 2022-06-24 13:03:19.530112
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE('safari', 'safaribooksonline.com online video')

# Generated at 2022-06-24 13:03:24.663018
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import safaribooksonline as sb
    assert sb.SafariApiIE.__name__ == sb.SafariBaseIE.__name__
    assert sb.SafariApiIE.ie_is_valid_url(None, 'http://example.com') == 'SafariApiIE'
    assert sb.SafariApiIE.ie_is_valid_url(None, 'http://safaribooksonline.com/api/v1/book/9781449396459/?override_format=json') == 'SafariApiIE'

# Generated at 2022-06-24 13:03:27.794605
# Unit test for constructor of class SafariIE
def test_SafariIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    SafariIE(SafariIE).suitable(url)

# Generated at 2022-06-24 13:03:30.301638
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # If a SafariCourseIE object is created, no error should be reported.
    SafariCourseIE(SafariBaseIE)

# Generated at 2022-06-24 13:03:41.380997
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    nt = SafariBaseIE._netrc_machine
    SafariBaseIE._netrc_machine = None

    ie = SafariBaseIE(SafariBaseIE._download_webpage)
    assert ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert ie._NETRC_MACHINE is None
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'

    ie = SafariBaseIE({
        'login_url': 'https://example.com/login'
    }, object())
    assert ie._LOGIN_URL == 'https://example.com/login'
    assert ie._NETRC_MACHINE is None


# Generated at 2022-06-24 13:03:51.612744
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert ie.IE_NAME == 'safari:course'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'
    # assert ie._TESTS is not None
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'
    assert ie.LOGGED_IN == False

# Generated at 2022-06-24 13:03:53.369777
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    safari_base_ie._real_initialize()

# Generated at 2022-06-24 13:03:56.206917
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course = SafariCourseIE('http://any_url')
    assert course._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert course._API_FORMAT == 'json'

# Generated at 2022-06-24 13:04:08.000060
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    import copy
    import responses
    import tempfile
    import unittest
    from ..compat import compat_cookies
    from ..utils import netrc

    class TestSafariBaseIE(SafariBaseIE):
        _NETRC_MACHINE = 'safari_test'

        def _real_extract(self, url):
            return {
                'url': url,
                'id': '%s_%s' % (self._NETRC_MACHINE, self.LOGGED_IN),
            }


# Generated at 2022-06-24 13:04:10.141455
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_IE = SafariIE()
    assert safari_IE.ie_key() == 'Kaltura'


# Generated at 2022-06-24 13:04:14.440971
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # The SafariBaseIE object can be created with a valid url.
    for url in SafariCourseIE._TESTS[0]['url'], SafariCourseIE._TESTS[1]['url']:
        SafariCourseIE(compat_urllib_request.Request(url))
    # The SafariBaseIE object can also be created without a url.
    SafariCourseIE()

# Generated at 2022-06-24 13:04:26.916083
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    try:
        from youtube_dl.downloader import YoutubeDL
    except:
        from youtube_dl.YoutubeDL import YoutubeDL
    try:
        from youtube_dl.YoutubeDL import DownloadError
    except:
        from youtube_dl.downloader.common import DownloadError

    ydl = YoutubeDL({'username': 'user', 'password': 'password'})

    # Bad or missing login info
    try:
        ydl.extract_info(
            'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter-content/part00.html',
            download=False)
        assert False
    except ExtractorError as e:
        assert e.args == ('Please provide username and password',)


# Generated at 2022-06-24 13:04:32.758382
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert isinstance(SafariIE('http://safaribooksonline.com/')._download_webpage_handle,
                      type(SafariBaseIE._download_webpage_handle))
    assert isinstance(SafariIE('http://safaribooksonline.com/')._download_json_handle,
                      type(SafariBaseIE._download_json_handle))

# Generated at 2022-06-24 13:04:36.774428
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE('https://www.safaribooksonline.com/library/view/HADOOP/9780133392838')
    assert ie.__class__.__name__  == 'SafariCourseIE'

# Generated at 2022-06-24 13:04:48.953519
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    name = 'SafariApiIE'
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    course_id = '9781449396459'
    part = 'part00'
    course_title = 'Hadoop Fundamentals LiveLessons'
    session = ''

# Generated at 2022-06-24 13:04:51.299474
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    if not SafariApiIE._downloader:
        SafariApiIE._downloader = Downloader({})


# Generated at 2022-06-24 13:04:55.698009
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert SafariApiIE().IE_NAME == 'SafariApi'

test_cases = [
    test_SafariApiIE,
]

if __name__ == '__main__':
    for test_case in test_cases:
        test_case()

# Generated at 2022-06-24 13:04:58.691340
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test for constructor
    ie = SafariApiIE()
    # Test for returning empty result in case of wrong credentials
    pw = ie._get_login_info()
    assert pw == (None, None)

# Generated at 2022-06-24 13:05:00.315558
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert SafariBaseIE('dummy username', 'dummy password')

# Generated at 2022-06-24 13:05:06.826011
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api = SafariApiIE()

    # Test '_real_initialize'
    safari_api._real_initialize()
    assert safari_api.LOGGED_IN == False

    # Test '_login'
    safari_api._login()
    assert safari_api.LOGGED_IN == False

    # Test '_build_url'
    assert safari_api._build_url("/test") == "https://learning.oreilly.com/api/v1/test"

# Generated at 2022-06-24 13:05:08.061239
# Unit test for constructor of class SafariIE
def test_SafariIE():
    s = SafariIE()
    # Check if we didn't throw an exception
    pass

# Generated at 2022-06-24 13:05:17.994428
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    import unittest
    from .test_html5 import MockIEHTML5


    class DummyIE(MockIEHTML5, SafariCourseIE):
        pass

    d = DummyIE('Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36')
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'

# Generated at 2022-06-24 13:05:18.477044
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()

# Generated at 2022-06-24 13:05:23.183818
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test Data
    url = "https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838"
    SafariIE(SafariBaseIE).suitable(url)

# Generated at 2022-06-24 13:05:25.152196
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    """
    Construct an instance of IE for testing
    """
    ie = SafariBaseIE()
    return ie

# Generated at 2022-06-24 13:05:33.598900
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    if not (1==1):
        username, password = SafariBaseIE._get_login_info(site=SafariBaseIE._NETRC_MACHINE)
        if username is None:
            return
        _, urlh = SafariBaseIE._download_webpage_handle(
            SafariBaseIE._LOGIN_URL, None, 'Downloading login page')
        def is_logged(urlh):
            return 'learning.oreilly.com/home/' in urlh.geturl()
        if is_logged(urlh):
            print("LOGGED_IN = True")
            return
        redirect_url = urlh.geturl()
        parsed_url = compat_urlparse.urlparse(redirect_url)
        qs = compat_parse_qs(parsed_url.query)
        next_uri

# Generated at 2022-06-24 13:05:36.985106
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459')

# Generated at 2022-06-24 13:05:47.884957
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import sys
    import logging
    import unittest

    class TestSafariIE(unittest.TestCase):

        def setUp(self):
            self._SafariIE = SafariIE(
                {
                    'protocol': 'https',
                    'hostname': 'www.safaribooksonline.com'
                },
                {
                    'username': 'foo@gmail.com',
                    'password': 'bar'
                },
                logging.getLogger(),
                compat_str)
            self._SafariIE.http.to_screen = sys.stdout

        def test_login(self):
            self._SafariIE._login()
            self.assertTrue(self._SafariIE.LOGGED_IN)
        #    self.assertTrue(self._SafariIE._real_

# Generated at 2022-06-24 13:05:54.071824
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Check if the SafariIE constructor is ok
    # It must not crash with a given URL
    safariIE = SafariIE("https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html")
    assert safariIE.IE_NAME == "safari"

# Generated at 2022-06-24 13:06:05.947340
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from ..compat import (
        compat_urllib_request,
        compat_urlopen,
    )
    from .common import mock_webpage
    from .youtube import YoutubeBaseInfoExtractor
    yt_ie = YoutubeBaseInfoExtractor()
    yt_ie.ie_key()
    yt_ie.suitable(None)
    yt_ie.add_ie(None)

    safari_test_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'


# Generated at 2022-06-24 13:06:09.281329
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Check to make sure the constructor of class SafariIE does not raise an exception
    try:
        SafaribooksonlineIE()
    except:
        raise AssertionError("SafaribooksonlineIE() failed to construct")


# Generated at 2022-06-24 13:06:12.829424
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    IE = SafariCourseIE()
    provided_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    assert IE.suitable(provided_url)

# Generated at 2022-06-24 13:06:24.902422
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE('SafariApiIE', 'SafariApiIE.ie_key', 'SafariApiIE.suitable')
    IE_NAME = 'safari:api'
    IE_DESC = 'safaribooksonline.com online video'
    VALID_URL = r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'
    assert ie.IE_NAME == IE_NAME
    assert ie.IE_DESC == IE_DESC
    assert ie._VALID_URL == VALID_URL

# Generated at 2022-06-24 13:06:27.406069
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    try:
        SafariCourseIE
    except NameError:
        raise AssertionError("Class SafariCourseIE not created")

# Generated at 2022-06-24 13:06:36.282156
# Unit test for constructor of class SafariIE
def test_SafariIE():
    obj = SafariIE()

    # These tests can be removed once safaribooksonline.com
    # accounts are publicly available
    assert isinstance(obj, SafariIE)
    assert obj._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert obj._NETRC_MACHINE == 'safari'
    assert obj._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert obj._API_FORMAT == 'json'
    assert obj.IE_DESC == 'safaribooksonline.com online video'
    assert obj.IE_NAME == 'safari'
    assert obj.LOGGED_IN == False

    # Test for function _real_initialize
    def test_SafariIE_real_initialize():
        obj = Safari

# Generated at 2022-06-24 13:06:37.694824
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-24 13:06:41.172840
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    ie._real_extract("https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json")

# Generated at 2022-06-24 13:06:45.087444
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/photoshop-elements-13/9780133954726/'
    course = SafariCourseIE().from_url(url)
    assert course.course_id == '9780133954726'

# Generated at 2022-06-24 13:06:50.477007
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safaribase = SafariBaseIE()
    course_id = '9780133392838'
    part = 'part00'
    url = 'https://www.safaribooksonline.com/api/v1/book/%s/chapter-content/%s.html' % (course_id, part)
    safaribase._download_json(url, '%s/%s' % (course_id, part),
        'Downloading part JSON')

# Generated at 2022-06-24 13:06:51.536832
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE('safari', {}, True, False)

# Generated at 2022-06-24 13:07:02.006617
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert not SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html')
    assert not SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/00_SeriesIntro.html')
    assert not SafariCourseIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314/9780134217314-PYMC_13_00')
    assert not Safari

# Generated at 2022-06-24 13:07:05.979256
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    instance = SafariCourseIE('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert isinstance(instance, SafariCourseIE)

# Generated at 2022-06-24 13:07:11.227955
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert SafariApiIE()._VALID_URL == 'https?:\/\/(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com\/api\/v1\/book\/[^\/]+\/chapter(?:-content)?\/[^/?#&]+\.html'



# Generated at 2022-06-24 13:07:15.595501
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = "https://learning.oreilly.com/api/v1/book/9781491973769/chapter/part00.html"
    course = SafariApiIE._build_course(SafariApiIE,url)
    assert course == None


# Generated at 2022-06-24 13:07:25.641498
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    t = SafariApiIE()
    t._real_initialize()

    myvars = {'course_id': 'test_course', 'part': 'test_part'}
    url = 'http://something.com/api/v1/book/%(course_id)s/chapter/%(part)s.html' % myvars
    course_id = myvars['course_id']
    part = myvars['part']

    # test _real_extract
    result = t._real_extract(url)
    assert result['id'] == '%s/%s' % (course_id, part)
    asset_id = result['url']

# Generated at 2022-06-24 13:07:29.105723
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_ie = SafariCourseIE()
    assert isinstance(safari_course_ie, SafariCourseIE)

# Generated at 2022-06-24 13:07:30.932434
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    username = 'username'
    password = 'password'
    safari = SafariBaseIE('safari', username, password)

# Generated at 2022-06-24 13:07:31.577145
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()

# Generated at 2022-06-24 13:07:32.614525
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE(None)

# Generated at 2022-06-24 13:07:35.597474
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'

# Generated at 2022-06-24 13:07:37.122403
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert issubclass(SafariIE, KalturaIE)

# Generated at 2022-06-24 13:07:40.872619
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safariIE = SafariIE()
    assert safariIE.__class__.__name__ == 'SafariIE'
    assert safariIE.IE_NAME == 'safari'
    assert safariIE.IE_DESC == 'safaribooksonline.com online video'


# Generated at 2022-06-24 13:07:42.736918
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import unittest
    extractor = SafariApiIE()
    assert isinstance(extractor, SafariApiIE)


# Generated at 2022-06-24 13:07:44.247504
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    # This tests that the IE's _real_initialize() is not broken
    ie._real_initialize()

# Generated at 2022-06-24 13:07:50.956843
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    safari_course_ie = SafariCourseIE()
    safari_course_ie._initialize_geo_bypass({})
    assert safari_course_ie._is_suitable(course_url)

# Generated at 2022-06-24 13:07:55.289130
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = ('https://www.safaribooksonline.com/library/view/python-for-data/'
           '9780133902837/part00.html')
    safari_api = SafariApiIE()
    safari_api.extract(url)

# Generated at 2022-06-24 13:08:01.476798
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    mobj = re.match(SafariApiIE._VALID_URL, url)
    video_id = '%s-%s' % (mobj.group('course_id'), mobj.group('part'))

    webpage, urlh = SafariApiIE._download_webpage_handle(url, video_id)
    assert 'course_id' in mobj.groupdict()