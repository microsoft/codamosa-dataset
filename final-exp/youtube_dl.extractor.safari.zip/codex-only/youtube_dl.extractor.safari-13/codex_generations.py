

# Generated at 2022-06-24 12:57:59.526866
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import unittest
    test_class = unittest.makeSuite(SafariIE)
    return test_class

# Generated at 2022-06-24 12:58:09.851738
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    c = SafariCourseIE()
    c.url
    c.suitable("http://techbus.safaribooksonline.com/9780134426365")
    c.suitable("https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/")
    c.suitable("https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html")
    c.suitable("https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json")

# Generated at 2022-06-24 12:58:12.864747
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    try:
        IE = SafariApiIE('', '')
        assert True
    except Exception as e:
        print(e)
        assert False

# Generated at 2022-06-24 12:58:24.540117
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from ..compat import unittest

    class SafariApiIETest(unittest.TestCase):
        def test_login(self):
            def login_raise_extractorerror(self):
                raise ExtractorError(
                    'Unable to login', expected=True)
            def login_raise_exception(self):
                raise Exception()
            def login_return_none(self):
                return
            def login(self):
                return

            safariApiIE = SafariApiIE()

            # test 1
            safariApiIE._login = login_raise_extractorerror
            self.assertIsNone(safariApiIE._login())

            # test 2
            safariApiIE._login = login_raise_exception
            with self.assertRaises(Exception):
                safariApi

# Generated at 2022-06-24 12:58:30.201415
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    v1 = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    v2 = 'https://techbus.safaribooksonline.com/9780134426365'

    assert SafariCourseIE._VALID_URL == v1 or SafariCourseIE._VALID_URL == v2

# Generated at 2022-06-24 12:58:30.842293
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-24 12:58:39.976287
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course_id = '9780133392838'
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/' + course_id + '/'
    assert SafariCourseIE.suitable(url) == True

    url = 'https://www.safaribooksonline.com/api/v1/book/9780133392838/'
    assert SafariCourseIE.suitable(url) == False

    url = 'https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html'
    assert SafariCourseIE.suitable(url) == False

# Generated at 2022-06-24 12:58:44.863488
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    try:
        for ie in [SafariCourseIE(),
                   SafariIE(),
                   SafariApiIE()]:
            ie.extract(ie._VALID_URL)
            assert ie._VALID_URL =='https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    except AssertionError:
        print('Error: constructor of class SafariCourseIE not working properly')
    

# Generated at 2022-06-24 12:58:57.668744
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # all these urls are here just to make sure they don't raise an error
    SafariCourseIE._VALID_URL = r'''(?x)
                                    https?://
                                        (?:
                                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                                            (?:
                                                library/view/[^/]+|
                                                api/v1/book|
                                                videos/[^/]+
                                            )|
                                            techbus\.safaribooksonline\.com
                                        )
                                        /(?P<id>[^/]+)
                                    '''
    assert SafariCourseIE.suitable(
        'http://techbus.safaribooksonline.com/9780134426365') == True
   

# Generated at 2022-06-24 12:59:01.024545
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert not safari_ie.LOGGED_IN
    return safari_ie


# Generated at 2022-06-24 12:59:10.107172
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safaribooksonline = SafariBaseIE()
    safaribooksonline._LOGIN_URL = 'https://learning.oreilly.com/accounts/login/'
    safaribooksonline._NETRC_MACHINE = 'safari'
    safaribooksonline._API_BASE = 'https://learning.oreilly.com/api/v1'
    safaribooksonline._API_FORMAT = 'json'
    safaribooksonline.LOGGED_IN = False

    # test values of initialized attributes
    assert safaribooksonline._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safaribooksonline._NETRC_MACHINE == 'safari'

# Generated at 2022-06-24 12:59:20.790050
# Unit test for constructor of class SafariIE
def test_SafariIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    r = SafariIE()
    assert r.suitable(url)
    assert r._VALID_URL == 'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/library/view/[^/]+/[^/]+/part[^/?#&]+\.html'
    assert r.IE_NAME == 'safari'
    assert r.IE_DESC == 'safaribooksonline.com online video'

# Generated at 2022-06-24 12:59:21.452881
# Unit test for constructor of class SafariIE
def test_SafariIE():
    obj = SafariIE()

# Generated at 2022-06-24 12:59:22.756456
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    a1 = SafariApiIE()


# Generated at 2022-06-24 12:59:28.854470
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    object1 = SafariBaseIE(SafariBaseIE.IE_NAME,
                           SafariBaseIE.IE_DESC,
                           'http://www.example.com',
                           'http://www.example.com/watch')
    assert object1.IE_NAME == 'safari'
    assert object1.IE_DESC == 'safaribooksonline.com online video'

# Generated at 2022-06-24 12:59:35.913734
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert SafariIE._build_url_result('http://techbus.safaribooksonline.com/9780134426365/chapter/part00.html',
                                      '_partner_id', '_uiconf_id', '_reference_id') == \
           'https://cdnapisec.kaltura.com/html5/html5lib/v2.37.1/mwEmbedFrame.php?wid=_partner_id&uiconf_id=_uiconf_id&flashvars[referenceId]=_reference_id'

# Generated at 2022-06-24 12:59:36.906414
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('safari.api')

# Generated at 2022-06-24 12:59:42.565467
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .test_common import yt_result
    assert yt_result(SafariApiIE, 'http://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/htmlcss_01.html?override_format=json', 'https://www.safaribooksonline.com/library/view/html-css/9781449396300/htmlcss_01.html')

# Generated at 2022-06-24 12:59:43.083531
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE('Safari')

# Generated at 2022-06-24 12:59:50.329411
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    app = dict()
    app['app'] = dict()
    app['app']['app_domains'] = ['learning.oreilly.com']
    app['app']['app_key'] = '-H0RxwW_0MtXL2quHlEeqQ'
    app['app']['app_secret'] = '-jK5w8S5y5D_U6EfU6aDAuhPmYUZ7M-nJ2dPQrI6rI'
    app['app']['app_config'] = {'organization': 'safaribooksonline',
                                'admin_email': 'engineering@safaribooksonline.com'}
    app['app']['app_config']['comment_systems'] = []

# Generated at 2022-06-24 13:00:03.357746
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from ..utils import ExtractorError
    from ..compat import compat_urllib_request
    from ..test.test_safari import FakeLoginResponse

    test_obj = SafariBaseIE(FakeLoginResponse('url'))
    assert test_obj.LOGGED_IN == False
    assert test_obj.username == None
    assert test_obj.password == None

    test_obj = SafariBaseIE(FakeLoginResponse('url', 'username', 'password'))
    assert test_obj.LOGGED_IN == False
    assert test_obj.username == 'username'
    assert test_obj.password == 'password'

    test_obj = SafariBaseIE(FakeLoginResponse('url', 'username', 'password'))
    test_obj._login()
    assert test_obj.LOGGED_IN == True
    assert test_obj

# Generated at 2022-06-24 13:00:13.199353
# Unit test for constructor of class SafariIE

# Generated at 2022-06-24 13:00:16.944331
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # test credentials retrieval
    assert SafariBaseIE._login_info('safari').password is None
    assert SafariBaseIE._login_info('safari').username is None

    # test constructor
    SafariBaseIE._real_initialize(SafariBaseIE())

# Generated at 2022-06-24 13:00:17.879342
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safariIE = SafariIE()
    assert safariIE.LOGGED_IN == False

# Generated at 2022-06-24 13:00:18.499177
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-24 13:00:28.673881
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():

    # from .test_downloader import FakeYDL
    # from .test_downloader import FakeHttpDl
    from .test_downloader import FakeHttpDl

    # ydl = FakeYDL()
    # ydl.add_default_info_extractors()

    # ie = ydl._ies[SafariIE.ie_key()](ydl)
    # ie.http_dl = FakeHttpDl()
    ie = SafariBaseIE()
    ie.http_dl = FakeHttpDl()
    assert not ie.LOGGED_IN

    ie.initialize()
    assert ie.LOGGED_IN

# Generated at 2022-06-24 13:00:34.216331
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()
    for url in ('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json',):
        # Check if url returns a info dict
        safari_api_ie._real_extract(url)

# Generated at 2022-06-24 13:00:38.256183
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test for True
    base_ie = SafariBaseIE(SafariBaseIE._downloader)
    assert True == base_ie.LOGGED_IN
    # Test for False
    base_ie.LOGGED_IN = False
    assert False == base_ie.LOGGED_IN

# Generated at 2022-06-24 13:00:47.173202
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    f = getattr(ie, '_download_json')
    setattr(ie, '_download_json', lambda _1, _2, _3: {})
    try:
        ie.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
        ie.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    finally:
        setattr(ie, '_download_json', f)

# Generated at 2022-06-24 13:00:50.606826
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert(SafariApiIE()._API_BASE == 'https://learning.oreilly.com/api/v1')

# Generated at 2022-06-24 13:00:52.167286
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert 'SafariCourseIE' == SafariCourseIE.ie_key()
    ie = SafariCourseIE(None)
    assert 'SafariBaseIE' in ie.__class__.__bases__

# Generated at 2022-06-24 13:00:53.260967
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE('safari')

# Generated at 2022-06-24 13:01:00.625987
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    so = SafariApiIE()
    url = "https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html"
    expected = "https://www.safaribooksonline.com/library/view/programming-the-internet/9781449396459/part00.html"
    actual = so._real_extract(url)
    assert expected == actual

# Generated at 2022-06-24 13:01:03.745095
# Unit test for constructor of class SafariIE
def test_SafariIE():
    foo = SafariIE('http://www.safaribooksonline.com/library/view/learning-path-red/9780134664057/RHCE_Introduction.html')

# Generated at 2022-06-24 13:01:04.562669
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course = SafariCourseIE()
    assert isinstance(safari_course, SafariBaseIE)

# Generated at 2022-06-24 13:01:06.834689
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test that SafariBaseIE constructor doesn't crash
    SafariBaseIE()


# Generated at 2022-06-24 13:01:08.480148
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """Ensure that SafariCourseIE does not crash when importing."""
    pass

# Generated at 2022-06-24 13:01:20.506268
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # See https://regex101.com/r/iQ2tE5/2
    valid_cookies_regex = r'Set-Cookie: (?P<cookie>[^=]+=[^;]+; expires=[^;]+; Path=/)'
    invalid_cookies_regex = r'Set-Cookie: (?P<cookie>[^=]+=[^;]+);'
    # See https://regex101.com/r/xF1fL8/1
    html_regex = r'<html [^>]*>'

    # Test that at least one valid cookie was set
    def set_valid_cookie(content):
        return valid_cookies_regex in content
    # Test that at least one invalid cookie was not set
    def set_invalid_cookie(content):
        return not invalid_cook

# Generated at 2022-06-24 13:01:26.946039
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()

    assert ie.IE_DESC == 'safaribooksonline.com online courses'
    assert ie.IE_NAME == 'safari:course'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'

# Generated at 2022-06-24 13:01:33.083446
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test if SafariIE constructor can be called with no arguments
    ie = SafariIE()

    assert ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert ie._NETRC_MACHINE == 'safari'

    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'

    assert ie.LOGGED_IN == False

# Unit test of method _login of class SafariIE

# Generated at 2022-06-24 13:01:41.120499
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_ie = SafariCourseIE()
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    mobj = re.match(safari_course_ie._VALID_URL, url)
    course_id = mobj.group('id')
    safari_course_ie._real_extract(url)

# Generated at 2022-06-24 13:01:45.980546
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # SafariIE class expected to raise error as credentials are required
    ie = SafariIE('testing', 'testing')

    # If credentials are not specified then error is not raised
    # in constructor of SafariIE class
    assert ie.username == 'testing'
    assert ie.password == 'testing'

# Generated at 2022-06-24 13:01:48.930867
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # This test is not supposed to be executed outside of unit test
    # environment thus there is no proper way to initialize
    # ExtractorError.
    assert SafariCourseIE.suitable(
        'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')

# Generated at 2022-06-24 13:01:50.523084
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course = SafariCourseIE()

# Generated at 2022-06-24 13:02:02.293710
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    import unittest

    class TestSafariCourseIE(unittest.TestCase):
        def test_safari(self):
            # test initialization
            ie = SafariCourseIE()

            # test course_id extraction
            valid = re.compile(ie._VALID_URL)


# Generated at 2022-06-24 13:02:06.622672
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # test for initialization of SafariCourseIE
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    sb = SafariCourseIE()
    assert isinstance(sb, SafariBaseIE)
    assert sb.suitable(url)
    assert not sb.IE_NAME == 'safari'
    assert not sb.IE_NAME == 'safari:api'

# Generated at 2022-06-24 13:02:07.297751
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert isinstance(ie, SafariApiIE)

# Generated at 2022-06-24 13:02:13.417194
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import os
    import re
    try:
        import netrc
    except ImportError:
        netrc = None
    import unittest.mock
    from os.path import expanduser
    from yarl import URL

    class MockUrlHandle:
        def __init__(self, url_mock):
            self._url_mock = url_mock
        def geturl(self):
            return self._url_mock

    class MockUrlHandleContent:
        def __init__(self, url_mock, content_mock):
            self._url_mock = url_mock
            self._content_mock = content_mock
        def geturl(self):
            return self._url_mock
        def read(self):
            return self._content_mock

# Generated at 2022-06-24 13:02:25.259597
# Unit test for constructor of class SafariCourseIE

# Generated at 2022-06-24 13:02:27.205349
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.LOGGED_IN is False

# Generated at 2022-06-24 13:02:27.963340
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-24 13:02:41.068212
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari = SafariApiIE()
    assert safari._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'
    assert safari._TESTS == [{'url': 'https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html', 'only_matching': True}, {'url': 'https://www.safaribooksonline.com/api/v1/book/9780134664057/chapter/RHCE_Introduction.html', 'only_matching': True}]

# Generated at 2022-06-24 13:02:43.898387
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safariApiIE = SafariApiIE()
    assert safariApiIE.ie_key() == 'safari:api'

# Generated at 2022-06-24 13:02:45.178032
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE(info_dict={ 'id': '123456' })

# Generated at 2022-06-24 13:02:46.381963
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE('safaribooksonline')


# Generated at 2022-06-24 13:02:48.318992
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safariIE = SafariIE('http://techbus.safaribooksonline.com/9780134426365')
    safariIE.extract()

# Generated at 2022-06-24 13:02:53.224763
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    if __name__ == '__main__':
        t = SafariApiIE()
        assert t.__class__.__name__ == 'SafariApiIE'
        assert t._VALID_URL == 'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'


# Generated at 2022-06-24 13:02:59.359905
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    video_url = 'https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html'
    ie = SafariApiIE(None)
    assert ie.suitable(video_url)
    info_dict = ie.extract(video_url)
    assert info_dict['url'] == 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    assert info_dict['_type'] == 'url'
    assert info_dict['ie_key'] == 'Safari'

# Generated at 2022-06-24 13:03:04.367788
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    inst = SafariApiIE()
    assert inst is not None
    assert inst._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert inst._API_FORMAT == 'json'


# Generated at 2022-06-24 13:03:06.195305
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('safari:api')
    SafariApiIE('safari:course')

# Generated at 2022-06-24 13:03:10.199702
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
	from .common import InfoExtractor
	from .safari import SafariCourseIE
	from .youtube import YoutubeIE
	
	assert isinstance(InfoExtractor.for_ie(SafariCourseIE.ie_key()), SafariCourseIE)
	
	assert isinstance(InfoExtractor.for_ie(YoutubeIE.ie_key()), YoutubeIE)

# Generated at 2022-06-24 13:03:17.232803
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    assert ie._NETRC_MACHINE == 'safari'
    assert ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'

# Generated at 2022-06-24 13:03:24.489450
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert(SafariIE._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/')
    assert(SafariIE._NETRC_MACHINE == 'safari')

    assert(SafariIE._API_BASE == 'https://learning.oreilly.com/api/v1')
    assert(SafariIE._API_FORMAT == 'json')

    assert(SafariIE.LOGGED_IN == False)


# Generated at 2022-06-24 13:03:28.742891
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert 'safari:course' not in globals()
    assert 'safari:api' not in globals()
    assert 'safari' not in globals()

    assert 'SafariCourseIE' in globals()
    assert 'SafariApiIE' in globals()
    assert 'SafariIE' in globals()

    assert SafariCourseIE.__name__ == 'SafariCourseIE'
    assert SafariApiIE.__name__ == 'SafariApiIE'
    assert SafariIE.__name__ == 'SafariIE'

# Generated at 2022-06-24 13:03:31.050578
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    instance = SafariApiIE()
    assert instance.IE_NAME == 'safari:api'

# Generated at 2022-06-24 13:03:42.139505
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Should not raise AssertionError
    SafariCourseIE('abc')
    # Should raise AssertionError
    try:
        SafariCourseIE('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    except AssertionError as e:
        if str(e) == "'Empty ID, but class inherits from SearchInfoExtractor': SafariCourseIE('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')":
            pass
        else:
            raise AssertionError("Unexpected AssertionError")
    else:
        raise AssertionError("AssertionError not raised")

# Generated at 2022-06-24 13:03:46.837713
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    SafariCourseIE._downloader.cache.disable()
    ie = SafariCourseIE(SafariCourseIE._downloader)

# Generated at 2022-06-24 13:03:49.743810
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    t = SafariCourseIE()
assert t.ie_key() == 'SafariIE', '%s should have key of %s, but instead has %s' % (t.__class__, 'SafariIE', t.ie_key())

# Generated at 2022-06-24 13:03:58.633850
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    course_id = '9780134664057'
    lib_json = 'library_%s.json' % course_id

    class FakeToHaveInstance(object):
        _download_json = staticmethod(lambda x, y, z, headers=None: {})

    course = FakeToHaveInstance()
    part_id = 'test_part_id'
    url = 'https://www.safaribooksonline.com/api/v1/book/%s/chapter/%s.html' % (course_id, part_id)

    # Make sure there is no exception when construct an instance of SafariApiIE
    assert SafariApiIE(course)._real_extract(url) == None

    # Make sure the _download_json method of the course is called correctly

# Generated at 2022-06-24 13:04:00.274208
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test whether initializing an instance of SafariIE will trigger an error
    try:
        SafariIE()
    except:
        return -1
    return 0

# Generated at 2022-06-24 13:04:02.051393
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    obj = SafariApiIE()
    assert obj.IE_NAME == "safari:api"


# Generated at 2022-06-24 13:04:07.574127
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    a = SafariCourseIE()
    assert a.IE_NAME == 'safari:course'
    assert a.IE_DESC == 'safaribooksonline.com online courses'
    assert a._VALID_URL =='(?x)\n                    https?://\n                        (?:\n                            (?:www\\.)?(?:safaribooksonline|(?:learning\\.)?oreilly)\\.com/\n                            (?:\n                                library/view/[^/]+|\n                                api/v1/book|\n                                videos/[^/]+\n                            )|\n                            techbus\\.safaribooksonline\\.com\n                        )\n                        /(?P<id>[^/]+)\n                    '
    assert a._TESTS[0]['url']

# Generated at 2022-06-24 13:04:14.810488
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """
    Unit test for constructor of class SafariCourseIE
    """
    inst = SafariCourseIE()
    assert inst.IE_NAME == 'safari:course'
    assert inst.IE_DESC == 'safaribooksonline.com online courses'
    assert inst._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'
    assert inst._VALID_URL.startswith(r'http')

# Generated at 2022-06-24 13:04:20.283583
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    ie1 = SafariIE()
    # We simulate a real process of video extraction
    ie1._cache['cookies'] = {}

# Generated at 2022-06-24 13:04:22.744175
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    import doctest
    doctest.run_docstring_examples(SafariCourseIE.__init__, globals())

# Generated at 2022-06-24 13:04:23.925042
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    t = SafariBaseIE()

# Generated at 2022-06-24 13:04:25.768540
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE('SafariBaseIE', 'safaribooksonline.com')

# Generated at 2022-06-24 13:04:27.504230
# Unit test for constructor of class SafariIE
def test_SafariIE():
    temp = SafariIE()
    assert (temp.ie_key() == 'Safari')

# Generated at 2022-06-24 13:04:37.486338
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    constructor = SafariCourseIE

    # This is a string, not a dict
    result = constructor.suitable("")
    assert result, "Test 1: Failed to detect that url is a string, not a dict"

    # This is invalid url
    result = constructor.suitable("abc")
    assert not result, "Test 2: Unsuitable url is passed through"

    # This is a valid URL, but not for the course
    result = constructor.suitable("https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part01.html")
    assert not result, "Test 3: Valid course url is passed through"

# Generated at 2022-06-24 13:04:49.730162
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from ..utils import urljoin
    from ..compat import compat_urlparse

    safari_base_ie = SafariBaseIE('SafariBaseIE', 'safaribooksonline.com', 'safari')

    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'

    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'

    assert not safari_base_ie.LOGGED_IN

    # testing of _login()

# Generated at 2022-06-24 13:05:01.018510
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """Test if safaribooksonline.com extractor works."""
    course_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    course = SafariCourseIE(course_url)
    assert course.IE_NAME == 'safari:course'
    assert course.IE_DESC == 'safaribooksonline.com online courses'
    assert course._VALID_URL == re.compile(r'https?\://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)')

# Generated at 2022-06-24 13:05:02.833628
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # SafariBaseIE is abstract class, can't initialize it directly
    # use SafariIE instead
    base = SafariIE('safari', 'safaribooksonline.com online video')
    base

# Generated at 2022-06-24 13:05:08.950489
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert ie._VALID_URL == "https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html"
    assert ie._LOGIN_URL == "https://learning.oreilly.com/accounts/login/"
    assert ie._NETRC_MACHINE == "safari"
    assert ie._API_BASE == "https://learning.oreilly.com/api/v1"
    assert ie._API_FORMAT == "json"
    assert ie.LOGGED_IN == False


# Generated at 2022-06-24 13:05:15.480581
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    test_url = 'https://learning.oreilly.com/api/v1/book/9781449396459/?override_format=json'
    safari = SafariBaseIE()

    safari_api_ie = SafariApiIE()

    result = safari_api_ie._real_extract(test_url)
    assert result == safari_api_ie.url_result(safari_api_ie._download_json(test_url, '9781449396459',
        'Downloading part JSON')['web_url'], SafariIE.ie_key())

# Generated at 2022-06-24 13:05:17.361227
# Unit test for constructor of class SafariIE
def test_SafariIE():
	ie = SafariIE("")
	assert len(ie.ie_key()) > 0

# Generated at 2022-06-24 13:05:21.065481
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE(None)
    # test for _call_api
    safari_base_ie._call_api('users', '')

# Generated at 2022-06-24 13:05:22.214417
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    object = SafariBaseIE()

# Generated at 2022-06-24 13:05:23.878427
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.IE_NAME == 'safari'

# Generated at 2022-06-24 13:05:25.053848
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()

# Generated at 2022-06-24 13:05:33.539606
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """Unit test to test constructor"""
    ie = SafariIE('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert ie.REFERENCE_ID is None
    assert ie.PARTNER_ID == '1926081'
    assert ie.UICONF_ID == '29375172'

    ie = SafariIE('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314/9780134217314-PYMC_13_00')
    assert ie.REFERENCE_ID is not None
    assert ie.PARTNER_ID == '1926081'
    assert ie.UICONF_ID == '29375172'

# Generated at 2022-06-24 13:05:44.260639
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    arg = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter-content/index.html'
    obj = SafariApiIE(arg)
    # The url can be converted to a url_result
    res = obj.url_result(arg)
    assert res['id'] == '9781449396459-index.html'
    # The url_result has the correct format from SafariIE
    assert res['ie_key'] == 'Kaltura'
    # The function matches the correct urls
    assert re.match(SafariApiIE._VALID_URL, arg)

# Generated at 2022-06-24 13:05:49.503567
# Unit test for constructor of class SafariCourseIE

# Generated at 2022-06-24 13:05:51.346581
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    ie._download_webpage

# Generated at 2022-06-24 13:06:04.168432
# Unit test for constructor of class SafariIE
def test_SafariIE():
    video_id = '9780133392838-Part00'
    safari = SafariIE()
    assert safari.IE_NAME == 'safari'
    assert safari.IE_DESC == 'safaribooksonline.com online video'
    assert safari._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''

# Generated at 2022-06-24 13:06:05.320717
# Unit test for constructor of class SafariIE
def test_SafariIE():
    myIns = SafariIE()

# Generated at 2022-06-24 13:06:11.083302
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    course_id = '9780134664057'
    part = 'RHCE_Introduction'
    url = 'https://www.safaribooksonline.com/api/v1/book/%s/chapter/%s.html' % (course_id, part)
    info_dict = SafariApiIE()._real_extract(url)
    assert info_dict['id'] == '%s-%s' % (course_id, part)

# Generated at 2022-06-24 13:06:23.185354
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html
    url = 'https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html'
    # url = 'https://www.safaribooksonline.com/api/v1/book/9780134664057/chapter/RHCE_Introduction.html'
    mobj = re.match(SafariApiIE._VALID_URL, url)
    assert mobj is not None, 'invalid URL'
    # part = mobj.group('part')
    course_id = mobj.group('course_id')
    # reference_id = '%s-%

# Generated at 2022-06-24 13:06:25.957624
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE(None)
    assert ie._VALID_URL == SafariApiIE._VALID_URL

# Generated at 2022-06-24 13:06:28.187272
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert issubclass(SafariBaseIE, InfoExtractor)
    assert issubclass(SafariBaseIE, object)


# Generated at 2022-06-24 13:06:29.516487
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE('SafariAPI', None, None)
    assert ie.IE_NAME == 'safari:api'

# Generated at 2022-06-24 13:06:32.233919
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    try:
        SafariApiIE()
    except Exception as e:
        print('constructor of class SafariApiIE raised an exception: ' + str(e))


# Generated at 2022-06-24 13:06:33.851579
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert_equal(type(ie), SafariApiIE)

# Generated at 2022-06-24 13:06:36.779761
# Unit test for constructor of class SafariIE
def test_SafariIE():
    inst = SafariIE()
    assert inst



# Generated at 2022-06-24 13:06:43.411685
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    IE_NAME_SafariCourseIE='safari:course'
    IE_DESC_SafariCourseIE='safaribooksonline.com online courses'
    _VALID_URL = r'''(?x)
                    https?://
                        (?:
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+|
                                api/v1/book|
                                videos/[^/]+
                            )|
                            techbus\.safaribooksonline\.com
                        )
                        /(?P<id>[^/]+)
                    '''

# Generated at 2022-06-24 13:06:44.701665
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .test_safari import SafariBaseTest

    test = SafariBaseTest(SafariIE, [])

    test.run()

# Generated at 2022-06-24 13:06:50.662663
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .common import test_html_content
    safariapi_test = SafariApiIE(SafariApiIE.test_resources.values(), {})
    test_html_content(safariapi_test, 'https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html')

# Generated at 2022-06-24 13:06:51.935335
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()


# Generated at 2022-06-24 13:07:00.003272
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import platform
    import sys
    import safari
    import youtube_dl

    # create a mock
    if platform.system() != 'Windows':
        sys.modules['youtube_dl.extractor.safari'] = safari
    sys.modules['youtube_dl.extractor.safari:SafariBaseIE'] = safari.SafariBaseIE
    sys.modules['youtube_dl.extractor.safari:safariIE'] = safari.SafariIE
    sys.modules['youtube_dl.extractor.safari:SafariApiIE'] = safari.SafariApiIE
    sa = safari.SafariApiIE(youtube_dl.YoutubeDL({}))
    assert sa.ie_key() == 'SafariApiIE'

# Generated at 2022-06-24 13:07:01.643962
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    result = SafariCourseIE()
    assert result.name == 'safari:course'

# Generated at 2022-06-24 13:07:03.679912
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()
    assert isinstance(safari, InfoExtractor)

# Generated at 2022-06-24 13:07:06.395710
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE(None)
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, SafariBaseIE)

# Generated at 2022-06-24 13:07:17.958605
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    import io

    try:
        import pycurl
    except ImportError:
        pytest.skip('pycurl is not installed')
    try:
        import http.cookiejar

        http.cookiejar.DefaultCookiePolicy
    except (AttributeError, ImportError):
        pytest.skip('http.cookiejar is not available')
    try:
        from .common import mock_httpd
    except ImportError:
        pytest.skip('mock_httpd is not available')

    course_id = '9780133392838'
    course_title = 'Hadoop Fundamentals LiveLessons'
    course_url = 'http://www.safaribooksonline.com/course/%s' % course_id

# Generated at 2022-06-24 13:07:19.749615
# Unit test for constructor of class SafariIE
def test_SafariIE():
    test_constructor = SafariIE.suitable('http://test.test')
    assert test_constructor == True

# Generated at 2022-06-24 13:07:21.507025
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert isinstance(SafariCourseIE(None) , SafariBaseIE)

# Generated at 2022-06-24 13:07:23.240337
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()
    # TODO: fill in the assert
    # assert safari.


# Generated at 2022-06-24 13:07:28.736214
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """
    Unit test for constructor of class SafariIE
    """
    url = 'https://learning.oreilly.com/videos/python-fundamentals/9780134668903'
    safari_video = SafariIE(url)
    assert safari_video

# Generated at 2022-06-24 13:07:30.218016
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    if safari_ie.LOGGED_IN == False:
        print("Test Failed. Script unable to login")
    else:
        print("Test Successful. Script logged in")

# Generated at 2022-06-24 13:07:32.025377
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert ie.IE_NAME == 'safari:api'

# Generated at 2022-06-24 13:07:35.816414
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """
    Test case for the SafariCourseIE constructor, it has been added due to a
    warning:
    "Warning: 'IE_DESC' is not defined in class SafariCourseIE"
    """
    test_class = SafariCourseIE()
    assert not(test_class is None)

# Generated at 2022-06-24 13:07:37.939691
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from ..test import get_testcases
    for key, course in get_testcases().items():
        SafariApiIE(key, course)

# Generated at 2022-06-24 13:07:44.668839
# Unit test for constructor of class SafariIE
def test_SafariIE():
    global SafariIE
    from .common import run_test_cases
    run_test_cases(SafariIE, [
        {
            'name': 'safaribooksonline login',
            'warning': 'login credentials are not provided',
            'expected_warnings': [
                'Login data is not available',
            ],
            'skip': 'Requires safaribooksonline account credentials',
        },
        {
            'name': 'safaribooksonline passing',
            'passing': True,
            'expected_warnings': [
                'Login data is not available',
            ],
            'skip': 'Requires safaribooksonline account credentials',
        },
    ])

# Generated at 2022-06-24 13:07:48.345787
# Unit test for constructor of class SafariIE
def test_SafariIE():
    inst = SafariIE()
    assert inst.LOGGED_IN == False
    assert inst._NETRC_MACHINE == 'safari'

# Generated at 2022-06-24 13:07:53.291489
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class TestSafariBaseIE(SafariBaseIE):
        IE_DESC = ''
        _LOGIN_URL = 'http://example.org/login.html'

        def _real_initialize(self):
            assert (self._login_info() ==
                    (None, None))

    tsb = TestSafariBaseIE()
    assert tsb.IE_NAME == 'SafariBase'
    assert tsb.IE_DESC == ''
    assert tsb._LOGIN_URL == 'http://example.org/login.html'
    assert tsb._NETRC_MACHINE == 'safari'
    assert tsb.LOGGED_IN == False

# Generated at 2022-06-24 13:07:55.168756
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE('safari:course')._real_initialize()