

# Generated at 2022-06-24 12:57:58.367061
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-24 12:58:02.577850
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # This unit test checks that the constructor of class SafariApiIE is
    # not declared dead code

    extractor = SafariApiIE()
    assert isinstance(extractor, SafariApiIE)

# Generated at 2022-06-24 12:58:05.663238
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    g = globals()
    g['test_SafariCourseIE'] = 'test'
    url = 'http://techbus.safaribooksonline.com/9780134426365'
    SafariCourseIE().suitable(url)
    assert True

# Generated at 2022-06-24 12:58:06.203187
# Unit test for constructor of class SafariIE
def test_SafariIE():
    pass

# Generated at 2022-06-24 12:58:11.057855
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class SafariBaseIEMock(SafariBaseIE):
        def _real_initialize(self):
            pass
    safari_base_ie = SafariBaseIEMock(None, 'safari:exercise')
    assert safari_base_ie.LOGGED_IN == False
    safari_base_ie.LOGGED_IN = True
    assert safari_base_ie.LOGGED_IN == True

# Generated at 2022-06-24 12:58:11.854690
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE(SafariBaseIE())

# Generated at 2022-06-24 12:58:13.502142
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert ie.IE_NAME == 'safari:api'

# Generated at 2022-06-24 12:58:18.668922
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Using safari_ie_1.py input URL
    test_url = "https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838/9780133392838-00_SeriesIntro"
    # Testing constructor
    assert SafariIE().suitable(test_url)

# Generated at 2022-06-24 12:58:24.763340
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    """Test SafariBaseIE Constructor"""
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie.LOGGED_IN is False

# Generated at 2022-06-24 12:58:25.487375
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE(None)

# Generated at 2022-06-24 12:58:36.079293
# Unit test for constructor of class SafariIE

# Generated at 2022-06-24 12:58:39.685114
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE._download_json('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json', '9781449396459', 'Downloading course JSON', 'Couldn\'t download JSON data')

# Generated at 2022-06-24 12:58:42.491403
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    obj = SafariCourseIE('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert obj.IE_NAME == 'safari:course'

# Generated at 2022-06-24 12:58:45.337076
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from ..compat import mock

    mock.patch('youtube_dl.downloader.http.cookiesjar.CookieJar').start()

    SafariApiIE('safari:api')

    mock.patch.stopall()

# Generated at 2022-06-24 12:58:48.764976
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class TestSafariBaseIE(SafariBaseIE):
        IE_NAME = 'test_SafariBaseIE'
        _VALID_URL = r'https://test.com/.*'
    assert TestSafariBaseIE.suitable("https://test.com/")

# Generated at 2022-06-24 12:58:51.109315
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert ie.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html')

# Generated at 2022-06-24 12:58:51.864489
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()

# Generated at 2022-06-24 12:58:58.404380
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    class UnitTestSafariApiIE(SafariApiIE):
        def _download_json(self, *args, **kwargs):
            return None

        def _search_regex(self, *args, **kwargs):
            return None

    safari_api_ie = UnitTestSafariApiIE()
    assert safari_api_ie.get_url_suitable()

# Generated at 2022-06-24 12:59:07.805926
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    assert SafariApiIE.suitable(url)
    instance = SafariApiIE()
    output = instance.extract(url)
    assert output['id'] == '0_qbqx90ic'
    assert output['title'] == 'Introduction to Hadoop Fundamentals LiveLessons'
    assert output['timestamp'] == 1437758058
    assert output['upload_date'] == '20150724'
    assert output['uploader_id'] == 'stork'
    assert output['ext'] == 'mp4'

# Generated at 2022-06-24 12:59:11.528542
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert(SafariBaseIE.IE_DESC)
    assert(SafariBaseIE.ie_key)
    assert(SafariBaseIE.ie_key())


# Generated at 2022-06-24 12:59:19.710793
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    """Test constructor of class SafariBaseIE"""
    # It's not possible to test any actual login because this requires
    # an actual username and password registered at Safari Books Online.
    # The best that can be done is to test for the presence of an
    # error message if the username/password is not provided

    try:
        # Attempt to log in without providing any authentication information.
        # This should burn a hole in the ground and raise an error
        SafariBaseIE(None)
    except ExtractorError as ex:
        assert "Unable to log in" in str(ex)

# Generated at 2022-06-24 12:59:23.655618
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert ie.IE_NAME == 'safari'

# Generated at 2022-06-24 12:59:34.964194
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    subclass_index = {
        'safari': SafariIE,
        'safari:api': SafariApiIE,
        'safari:course': SafariCourseIE,
    }
    assert SafariBaseIE.ie_key() == 'safari'
    assert SafariBaseIE.ie_key() in subclass_index
    assert not hasattr(SafariBaseIE, '_LOGIN_HOST')
    assert hasattr(SafariBaseIE, '_LOGIN_URL')

    # Check static member function
    class_ = subclass_index.get(SafariBaseIE.ie_key())
    assert class_.ie_key() == SafariBaseIE.ie_key()

    # Check constructor
    instance = subclass_index.get(SafariBaseIE.ie_key())(SafariBaseIE())._SafariBase__

# Generated at 2022-06-24 12:59:44.615426
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from ..utils import DEFAULT_HEADERS
    from .common import FakeReq
    import requests

    fake_req = FakeReq(requests.HTTPError, message='error', response=requests.Response(), src='')
    safari_ie = SafariIE()
    safari_ie.http_request = requests.get
    safari_ie.http_request_args = DEFAULT_HEADERS

    # error in the request
    safari_ie.http_request = lambda url, **kwargs: fake_req

    with pytest.raises(ExtractorError):
        # test login
        safari_ie._login()

    fake_req.response.status_code = 200
    fake_url = safari_ie._login_url()

# Generated at 2022-06-24 12:59:45.600240
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Accessing _API_PATH value should not invoke initialization
    assert not hasattr(SafariBaseIE(), '_LOGIN_FORM_STRING')

# Generated at 2022-06-24 12:59:46.063448
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-24 12:59:49.933545
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """
    Test SafariIE constructor
    """
    safari_ie = SafariIE()
    assert safari_ie._PARTNER_ID == '1926081'
    assert safari_ie._UICONF_ID == '29375172'
    assert safari_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_ie._API_FORMAT == 'json'
    assert safari_ie._NETRC_MACHINE == 'safari'


# Generated at 2022-06-24 12:59:52.268051
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    test_obj = SafariApiIE(SafariApiIE.ie_key())
    assert isinstance(test_obj, SafariApiIE)

# Generated at 2022-06-24 12:59:53.952158
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()
    assert isinstance(safari_api_ie, SafariBaseIE)

# Generated at 2022-06-24 13:00:07.723261
# Unit test for constructor of class SafariCourseIE

# Generated at 2022-06-24 13:00:12.400500
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    i = SafariBaseIE()
    assert i._NETRC_MACHINE == 'safari'
    assert i._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert i._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert i._API_FORMAT == 'json'

# Generated at 2022-06-24 13:00:14.454825
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    obj = SafariCourseIE()
    assert obj.ie_key() == 'Safari:Course'

# Generated at 2022-06-24 13:00:15.444733
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    test = SafariBaseIE()
    test.initialize()

# Generated at 2022-06-24 13:00:17.383070
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE(None)
    assert(ie.__class__.__name__ == 'SafariIE')

# Generated at 2022-06-24 13:00:29.546470
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE('http://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part01.html')
    SafariIE('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part01.html')
    SafariIE('https://www.safaribooksonline.com/library/view/create-a-nodejs/100000006A0210/part00.html')
    SafariIE('https://www.safaribooksonline.com/library/view/learning-path-red/9780134664057/RHCE_Introduction.html')

# Generated at 2022-06-24 13:00:40.187753
# Unit test for constructor of class SafariIE
def test_SafariIE():
    test_cases = [
        {
            'description': 'login required',
            'url': 'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838/9780133392838-00_SeriesIntro',
            'expected': True,
        },
        {
            'description': 'already logged in',
            'url': 'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838/9780133392838-00_SeriesIntro',
            'config': '-u <user> -p <pwd>',
            'expected': False,
        },
    ]
    for test_case in test_cases:
        description = test_case['description']
        url = test_case

# Generated at 2022-06-24 13:00:41.188042
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safariIE = SafariIE()

# Generated at 2022-06-24 13:00:43.583119
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    ie._download_webpage = lambda *a, **k: (None, None)

# Generated at 2022-06-24 13:00:44.311530
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-24 13:00:45.591069
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE('SafariBaseIE')

# Generated at 2022-06-24 13:00:58.380280
# Unit test for constructor of class SafariIE

# Generated at 2022-06-24 13:01:07.629375
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """Unit test for constructor of class SafariCourseIE."""
    course_id = '9780133392838'
    course_title = 'Hadoop Fundamentals LiveLessons'
    test_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'

    course = SafariCourseIE(SafariCourseIE.ie_key())
    course.extract(test_url)
    assert course.title == course_title
    assert course.id == course_id

# Generated at 2022-06-24 13:01:09.249223
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE(None)

# Generated at 2022-06-24 13:01:10.068818
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-24 13:01:12.808727
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert SafariApiIE.suitable('http://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json') is not None

# Generated at 2022-06-24 13:01:15.450089
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    m = str(SafariCourseIE)
    assert m == 'safaribooksonline.com online courses'


# Generated at 2022-06-24 13:01:21.713431
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from .. import compat_urllib_request, compat_urllib_error

    class FakeUrlHandleTest(object):
        class headers(object):
            def get(self):
                return 'groot_sessionid=groot; orm-rt=groot; orm-jwt=groot; orm-rt=groot; orm-jwt=groot'
    class FakeUrlHandle(FakeUrlHandleTest):
        class headers(FakeUrlHandleTest.headers):
            def __init__(self):
                pass

# Generated at 2022-06-24 13:01:22.878141
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    ie.initialize()
    assert ie._NETRC_MACHINE == "safari"

# Generated at 2022-06-24 13:01:23.828646
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safariIE = SafariBaseIE()
    assert safariIE is not None

# Generated at 2022-06-24 13:01:28.652395
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert safari_ie._PARTNER_ID == '1926081'
    assert safari_ie._UICONF_ID == '29375172'
    assert safari_ie._API_BASE == 'https://learning.oreilly.com/api/v1'

# Generated at 2022-06-24 13:01:29.921518
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE('SafariCourse', 'safaribooksonline.com online courses')

# Generated at 2022-06-24 13:01:36.229925
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """Test class constructor"""
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    test_safaribooksonline_downloader = SafariApiIE(lambda x: True)
    info_dict = test_safaribooksonline_downloader._real_extract(url)
    assert info_dict is not None and isinstance(info_dict, dict)
    assert 'entries' in info_dict

# Generated at 2022-06-24 13:01:44.009359
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari = SafariBaseIE()
    assert safari._download_json_handle('https://learning.oreilly.com/accounts/login-check/', None, 'Downloading login page') != None
    assert safari._download_webpage_handle('https://learning.oreilly.com/accounts/login-check/', None, 'Downloading login page') != None
    assert safari._real_initialize() == None

# Generated at 2022-06-24 13:01:48.183753
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = "https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html"
    downloadable = SafariApiIE._real_initialize()
    assert downloadable.suitable(url) is True

# Generated at 2022-06-24 13:01:58.439465
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    course_id = '9780133392838'
    api_base = 'https://learning.oreilly.com/api/v1'
    api_format = 'json'
    s = SafariBaseIE()
    assert s._API_BASE == api_base
    assert s._API_FORMAT == api_format

    s = SafariBaseIE(course_id, api_base, api_format)
    assert s._API_BASE == api_base
    assert s._API_FORMAT == api_format
    assert s._course_id == course_id
    assert isinstance(s, SafariCourseIE)

# Generated at 2022-06-24 13:02:03.291248
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    x = SafariBaseIE()
    assert x.LOGGED_IN == False
    assert x._NETRC_MACHINE == 'safari'
    assert x._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert x._API_FORMAT == 'json'
    assert x.LOGGED_IN == False

# Generated at 2022-06-24 13:02:04.545022
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    try:
        print(SafariCourseIE())
    except:
        print('Not implemented')


# Generated at 2022-06-24 13:02:06.326494
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Tests for subclass of InfoExtractor
    assert issubclass(SafariCourseIE, InfoExtractor)


# Generated at 2022-06-24 13:02:13.575198
# Unit test for constructor of class SafariIE
def test_SafariIE():
    class _TmpSafariIE(SafariIE):
        def _real_initialize(self):
            self._downloader.params.update(
                {
                    'username': 'user',
                    'password': 'pass'
                })
            SafariIE._real_initialize(self)

    tmp = _TmpSafariIE()

    # Assert safariErrMsg
    assert tmp._TEST['safariErrMsg'] == 'Log in to https://learning.oreilly.com/accounts/login/ with your account to download'

    # Assert login_info
    assert tmp._TEST['login_info'] == ('user', 'pass')

    # Assert url

# Generated at 2022-06-24 13:02:17.789036
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari = SafariBaseIE()

    assert safari._NETRC_MACHINE == 'safari'
    assert safari._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari._API_FORMAT == 'json'
    assert safari.LOGGED_IN == False

# Generated at 2022-06-24 13:02:24.816360
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    obj = SafariCourseIE(SafariBaseIE.IE_NAME)
    print(isinstance(obj, SafariBaseIE))
    obj = SafariCourseIE(SafariBaseIE.IE_NAME, None)
    print(isinstance(obj, SafariBaseIE))
    obj = SafariCourseIE(SafariBaseIE.IE_NAME, None, None)
    print(isinstance(obj, SafariBaseIE))

# Generated at 2022-06-24 13:02:26.104643
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert(SafariBaseIE() != None)

# Generated at 2022-06-24 13:02:32.356976
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # The purpose of this test is to verify that SafariBaseIE raises ExtractorError
    # if the credentials are not provided by the user via --username and --password
    # arguments or .netrc.
    safari_ie = SafariIE()
    safari_ie._PARAMS_REGEX = None
    with safari_ie:
        safari_ie._login()

# Generated at 2022-06-24 13:02:41.879587
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class MainClass(SafariBaseIE):
        def _real_extract(self, url):
            return None

    assert(MainClass.suitable('https://techbus.safaribooksonline.com/9781449396459') == True)
    assert(MainClass.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/') == False)
    assert(MainClass.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json') == False)

# Generated at 2022-06-24 13:02:45.312344
# Unit test for constructor of class SafariIE
def test_SafariIE():
    try:
        SafariIE(SafariBaseIE._downloader)
        assert False, 'SafariIE constructor does not require any arguments'
    except TypeError:
        pass


# Generated at 2022-06-24 13:02:48.570975
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert ie.suitable("https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html") == True


# Generated at 2022-06-24 13:02:50.352275
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Create instance of class SafariBaseIE
    safari_ie = SafariBaseIE()

    # Check if instance was created successfully
    safari_ie


# Generated at 2022-06-24 13:02:52.051140
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    instance = SafariCourseIE("", "http://techbus.safaribooksonline.com/9780134426365")
    assert instance is not None

# Generated at 2022-06-24 13:03:03.148522
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    x = SafariCourseIE()

    assert x.suitable("http://test.test.test/test.test") == False
    assert x.suitable("https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/") == True
    assert x.suitable("https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json") == False
    assert x.suitable("http://techbus.safaribooksonline.com/9780134426365") == True
    assert x.suitable("https://www.safaribooksonline.com/videos/python-programming-language/9780134217314") == True

# Generated at 2022-06-24 13:03:05.082005
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    if safari_ie._NETRC_MACHINE not in safari_ie._downloader.netrc().hosts:
        raise Exception('SafariIE unit test needs %s in netrc' % safari_ie._NETRC_MACHINE)

# Generated at 2022-06-24 13:03:08.272618
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test without safaribooks account credentials
    SafariApiIE()

    # Test for constructor with safaribooks account credentials
    SafariApiIE(params={
        'username': 'fake-username',
        'password': 'fake-password',
    })

# Generated at 2022-06-24 13:03:10.372327
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """
    Check that constructor of class SafariIE is working
    """
    safari_ie = SafariIE()
    assert(safari_ie.LOGGED_IN == False)

# Generated at 2022-06-24 13:03:13.573785
# Unit test for constructor of class SafariIE
def test_SafariIE():
	user = "zaizai00002@gmail.com"
	password = "020213zj"
	SafariIE(user, password)



# Generated at 2022-06-24 13:03:20.549830
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    course_id = '9781449396459'
    url = 'https://www.safaribooksonline.com/api/v1/book/%s/?override_format=json' % course_id
    course_json = SafariApiIE()._download_json(url, course_id, 'Downloading course JSON')
    assert 'chapters' in course_json

# Generated at 2022-06-24 13:03:22.141684
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert SafariApiIE('SafariApi')._API_FORMAT == 'json'

# Generated at 2022-06-24 13:03:24.945119
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert 'SafariApiIE' in globals()
    SafariApiIE('http://techbus.safaribooksonline.com/9780134426365')

# Generated at 2022-06-24 13:03:26.955627
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    fetcher = SafariBaseIE()
    assert fetcher is not None

# Generated at 2022-06-24 13:03:36.099206
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    import os.path
    import tempfile
    import netrc

    _, netrc_filename = tempfile.mkstemp(text=True)

    with open(netrc_filename, 'w') as temp_netrc_contents:
        temp_netrc_contents.write('machine %s login test password test' %
                                  SafariBaseIE._NETRC_MACHINE)

    netrc.netrc = lambda: netrc.netrc(os.path.abspath(netrc_filename))
    assert SafariBaseIE._get_login_info() == ('test', 'test')

    os.remove(netrc_filename)

# Generated at 2022-06-24 13:03:37.975876
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """
    Make sure SafariIE is constructed properly
    """
    SafariIE()


# Generated at 2022-06-24 13:03:39.832889
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    ie.extract(SafariCourseIE._TESTS[0]['url'])

# Generated at 2022-06-24 13:03:42.835779
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('SafariApiIE', 'www.safaribooksonline.com', '9780134664057/RHCE_Introduction.html')

# Generated at 2022-06-24 13:03:45.534162
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    inst = SafariApiIE()
    assert isinstance(inst, InfoExtractor)
    assert isinstance(inst, SafariBaseIE)

# Generated at 2022-06-24 13:03:50.593173
# Unit test for constructor of class SafariIE
def test_SafariIE():
    s = SafariIE()
    assert s.LOGGED_IN == False
    assert s._NETRC_MACHINE == 'safari'
    assert s._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert s._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert s._API_FORMAT == 'json'

# Generated at 2022-06-24 13:03:56.031093
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    courseIE = SafariCourseIE()

    course_id = "9780134217314"
    api_url = "%s/book/%s/?override_format=json" % (courseIE._API_BASE, course_id)
    course_json = courseIE._download_json(api_url, course_id, 'Downloading course JSON')

    assert course_json['title'] is not None

    assert len(course_json['chapters']) > 0

# Generated at 2022-06-24 13:04:07.803151
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.compat import compat_socket
    from .test_safari import _fake_idna
    from .test_kaltura import _widget_info
    from .utils import MockTracebackContentHandler, _mock_youtube_dl

    # perform a dummy login to Safaribooks service
    with _mock_youtube_dl() as ytdl:
        url = 'https://www.safaribooksonline.com/library/view/test-course/9780000000000/'
        ytdl.params['username'] = 'dummyuser'
        ytdl.params['password'] = 'dummypass'
        ytdl.params['safaribooks_session'] = None
        ytdl.params['safaribooks_auth']

# Generated at 2022-06-24 13:04:16.410335
# Unit test for constructor of class SafariIE

# Generated at 2022-06-24 13:04:28.787296
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # SafariCourseIE should not throw an error for urls that are already handled by SafariIE and SafariApiIE
    for url in (
            'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html',
            'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    ):
        assert(SafariBaseIE.suitable(url) == False)
        assert(SafariIE.suitable(url) == True)
        assert(SafariApiIE.suitable(url) == True)
        assert(SafariCourseIE.suitable(url) == False)

# Generated at 2022-06-24 13:04:29.615109
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    instance = SafariBaseIE()
    assert isinstance(instance, SafariBaseIE)


# Generated at 2022-06-24 13:04:31.653733
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    safari_base_ie.initialize()

# Generated at 2022-06-24 13:04:35.815204
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    baseIe = SafariApiIE()
    assert (baseIe.IE_NAME == 'safari:api')
    assert (baseIe.IE_DESC == 'safaribooksonline.com online courses (API)')

# Generated at 2022-06-24 13:04:37.627880
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert SafariApiIE(None).IE_NAME == 'safari:api'


# Generated at 2022-06-24 13:04:41.441975
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safariApiIE = SafariApiIE()
    assert safariApiIE._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safariApiIE._API_FORMAT == 'json'

# Generated at 2022-06-24 13:04:43.831048
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert ie._assert_not_implemented() == None

# Generated at 2022-06-24 13:04:45.612603
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    try:
        SafariCourseIE()
    except:
        assert(False)

# Generated at 2022-06-24 13:04:49.570465
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE('https://www.safaribooksonline.com/api/v1/book/9780134664057/chapter/RHCE_Introduction.html')
    assert ie.LOGGED_IN == False

# Generated at 2022-06-24 13:05:00.861153
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .common import get_testdata_file
    from .safari import (
        _extract_config, _extract_flashvars, _kaltura_result,
        _media_result, _search_js_var,
    )
    import json
    import os.path

    filename = '92_series_intro-prod-1-6-h264.mp4'
    filepath = get_testdata_file(filename)

# Generated at 2022-06-24 13:05:04.404232
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert isinstance(safari_ie, SafariIE)
    assert safari_ie.IE_NAME == 'safari'
    assert safari_ie.IE_DESC == 'safaribooksonline.com online video'

# Generated at 2022-06-24 13:05:10.101096
# Unit test for constructor of class SafariIE
def test_SafariIE():
    extracted_info = SafariIE._extract_info(SafariIE, '9780133392838', 'part00')
    assert extracted_info['title'] == 'Introduction to Hadoop Fundamentals LiveLessons'
    assert extracted_info['uploader_id'] == 'stork'
    assert extracted_info['part'] == '00'
    assert extracted_info['course_id'] == '9780133392838'
    assert extracted_info['id'] == '0_qbqx90ic'

# Generated at 2022-06-24 13:05:19.527354
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from ..test.test_safaribooksonline import mock_http_response

    response = mock_http_response('https://learning.oreilly.com/accounts/login/')
    mock_urlopen_responses = [response]

    response = mock_http_response('https://api.oreilly.com/')
    response.geturl = lambda: 'https://api.oreilly.com/?next=https%3A%2F%2Flearning.oreilly.com%2Fhome%2F'
    mock_urlopen_responses.append(response)

    # This test should fail on login
    response = mock_http_response('https://www.oreilly.com/member/auth/login/')
    mock_urlopen_responses.append(response)


# Generated at 2022-06-24 13:05:30.426417
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import unittest
    class SafariApiIETest(unittest.TestCase):
        def test_safariapiIE(self):
            url = SafariApiIE._VALID_URL
            mobj = re.match(url, 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html')
            self.assertEqual(mobj.group('course_id'), '9781449396459')
            self.assertEqual(mobj.group('part'), 'part00')
            mobj = re.match(url, 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter-content/part00.html')

# Generated at 2022-06-24 13:05:31.975762
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE('safari_api')
    assert ie.IE_NAME == 'safari:api'

# Generated at 2022-06-24 13:05:32.901629
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safariApiIE = SafariApiIE()

# Generated at 2022-06-24 13:05:38.152856
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # SafariBaseIE appears to require an authenticated session
    # which is not trivial to set up in a unit test. The test
    # below at least verifies the existence of the constructor
    try:
        SafariBaseIE()
    except ExtractorError:
        pass

# Generated at 2022-06-24 13:05:48.585225
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import logging
    logging.basicConfig(level=logging.DEBUG)

    test_video_url = "https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html"
    test_course_url = "https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/"
    test_session_url = "https://learning.oreilly.com/player/kaltura_session/?reference_id=9780596529321-0002_8_00"

    safari_video = SafariIE()
    safari_video.suitable(test_video_url)
    res = safari_video.extract(test_video_url)

# Generated at 2022-06-24 13:06:01.737753
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course_url = "https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838"

    # This course has no chapters
    no_chapters_course_url = "https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838"

    # This course is not available
    not_available_course_url = "https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838"

    # This course is no longer available
    no_longer_available_course_url = "https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838"

# Generated at 2022-06-24 13:06:05.112291
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    obj = SafariApiIE()
    assert obj.IE_DESC == 'safaribooksonline.com API'

# Generated at 2022-06-24 13:06:10.088750
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test constructor with no authentication data
    safari_base = SafariBaseIE('SafariBaseIE', None, None)
    assert safari_base.LOGGED_IN == False

    # Test constructor with file ".netrc"
    safari_base = SafariBaseIE('SafariBaseIE', None, '.netrc')
    assert safari_base.LOGGED_IN == True

# Generated at 2022-06-24 13:06:12.547619
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    info_extractor = SafariBaseIE()
    assert info_extractor._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'

# Generated at 2022-06-24 13:06:16.935768
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/python-for-beginners/9781430260585/'
    SafariCourseIE().suitable(url)

# Generated at 2022-06-24 13:06:18.499809
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import safari_book
    safari_book.SafariIE()

# Generated at 2022-06-24 13:06:22.916232
# Unit test for constructor of class SafariIE
def test_SafariIE():
    def safariie_test_method(self):
        pass
    safari_ie = SafariIE()
    safari_ie.safariie_test_method = safariie_test_method.__get__(safari_ie, SafariIE)
    safari_ie.safariie_test_method()

# Generated at 2022-06-24 13:06:25.585023
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE('safari:course')
    assert isinstance(ie, SafariCourseIE)

# Generated at 2022-06-24 13:06:35.241592
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course_id = '9780134217314'
    course_json = '{"chapters": ["https://www.safaribooksonline.com/api/v1/book/9780134217314/chapter/Python_01.html"], "title": "some title"}'
    course_title = 'some title'
    entries = [{'id': '9780134217314/Python_01', 'url': 'https://www.safaribooksonline.com/api/v1/book/9780134217314/chapter/Python_01.html', 'ie_key': 'SafariApi', 'title': '9780134217314/Python_01', '_type': 'url'}]

    safari_ie = SafariCourseIE()
    # test value returned by _download_json method
    safari_ie._

# Generated at 2022-06-24 13:06:40.114904
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    i = SafariCourseIE('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    i.initialize()

# Generated at 2022-06-24 13:06:43.942079
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    ie.initialize()
    assert isinstance(ie, SafariBaseIE)
    assert ie.IE_DESC == 'safaribooksonline.com online courses'
    assert ie.IE_NAME == 'safari:course'

# Generated at 2022-06-24 13:06:50.402983
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    ie._LOGIN_URL = "https://learning.oreilly.com/accounts/login/"
    ie._NETRC_MACHINE = 'safari'
    ie._API_BASE = "https://learning.oreilly.com/api/v1"
    ie._API_FORMAT = "json"
    ie._real_initialize()
    assert ie._NETRC_MACHINE == 'safari'

# Generated at 2022-06-24 13:06:56.993562
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+|
                                api/v1/book|
                                videos/[^/]+
                            )|
                            techbus\.safaribooksonline\.com
                        )
                        /(?P<id>[^/]+)
                    '''


# Generated at 2022-06-24 13:06:58.437048
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    api = SafariApiIE('safari')
    assert api is not None


# Generated at 2022-06-24 13:07:01.565545
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    SafariApiIE.suitable(url)



# Generated at 2022-06-24 13:07:08.615003
# Unit test for constructor of class SafariIE
def test_SafariIE():
    instance = SafariIE(object)
    assert not instance.LOGGED_IN

    # test case: without login
    instance._login = lambda: None
    instance._real_initialize()
    assert not instance.LOGGED_IN

    # test case: with login
    def logged_in():
        instance.LOGGED_IN = True
    instance._login = logged_in
    instance._real_initialize()
    assert instance.LOGGED_IN

# Generated at 2022-06-24 13:07:09.786365
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert hasattr(SafariIE, 'suitable')

# Generated at 2022-06-24 13:07:14.245457
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Normal constructor
    safariBase = SafariBaseIE()
    assert safariBase.LOGGED_IN is False

    # Constructor with logged in flag
    safariBase = SafariBaseIE(logged_in = True)
    assert safariBase.LOGGED_IN is True

# Generated at 2022-06-24 13:07:16.725067
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    i = SafariApiIE(SafariApiIE.ie_key())
    assert i.ie_key() == 'Safari'

# Generated at 2022-06-24 13:07:25.001270
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    url = 'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838'
    safaribaseie = SafariBaseIE()
    mobj = re.match(safaribaseie._VALID_URL, url)
    course_id = mobj.group('id')
    safaribaseie._download_json(
            '%s/book/%s/?override_format=%s' % (safaribaseie._API_BASE, course_id, safaribaseie._API_FORMAT),
            course_id, 'Downloading course JSON')

# Generated at 2022-06-24 13:07:25.734541
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-24 13:07:28.580961
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    import os
    os.environ["LOGIN"] = "login"
    os.environ["PASSWORD"] = "password"
    test = SafariBaseIE()

    assert(test._download_webpage_handle('https://learning.oreilly.com/accounts/login-check/', None,
            'Downloading login page')[1].geturl() == "https://learning.oreilly.com/home/")


# Generated at 2022-06-24 13:07:38.059566
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    class FakeSafariBaseIE(SafariBaseIE):
        IE_NAME = 'safari:api_fake'
        _VALID_URL = r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Generated at 2022-06-24 13:07:45.831214
# Unit test for constructor of class SafariBaseIE

# Generated at 2022-06-24 13:07:48.583005
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    assert isinstance(ie, SafariCourseIE)

# Generated at 2022-06-24 13:07:58.099677
# Unit test for constructor of class SafariIE
def test_SafariIE():
    course_id = '9780133392838'
    part = 'part02'
    course_part_url = ('https://www.safaribooksonline.com/library/view/' +
                       course_id + '/' + part + '.html')
    assert SafariIE._match_id(course_part_url) == part

    course_id = '9780134664057'
    part = 'RHCE_Introduction'
    course_part_url = ('https://www.safaribooksonline.com/library/view/' +
                       course_id + '/' + part + '.html')
    assert SafariIE._match_id(course_part_url) == part