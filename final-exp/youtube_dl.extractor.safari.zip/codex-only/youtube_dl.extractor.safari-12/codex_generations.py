

# Generated at 2022-06-24 12:58:00.740918
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    instance = SafariCourseIE()
    assert isinstance(instance, SafariCourseIE)

# Generated at 2022-06-24 12:58:10.391788
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    inst = SafariCourseIE('http://safariCourse.com/')
    assert inst.IE_NAME == 'safari:course'
    assert inst.IE_DESC == 'safaribooksonline.com online courses'
    assert inst._VALID_URL == '''(?x)
                    https?://
                        (?:
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+|
                                api/v1/book|
                                videos/[^/]+
                            )|
                            techbus\.safaribooksonline\.com
                        )
                        /(?P<id>[^/]+)
                    '''
    assert isinstance(inst.IE_NAME, str)
   

# Generated at 2022-06-24 12:58:21.277857
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from ..compat import compat_etree_fromstring
    from ..utils import HeaderDict

    HTML_BODY = '<html><head><title>test</title></head><body>test</body></html>'
    url = 'https://www.oreilly.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    safari_base_ie = SafariBaseIE()

    # Testing _apply_first_set_cookie_header
    # 1
    headers = HeaderDict({'set-cookie': 'a=1;'})
    safari_base_ie._apply_first_set_cookie_header(headers, 'a')
    assert 'a=1' in headers['Cookie']

    # 2

# Generated at 2022-06-24 12:58:22.591529
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    t = SafariCourseIE()
    assert t


# Generated at 2022-06-24 12:58:26.011927
# Unit test for constructor of class SafariIE
def test_SafariIE():
    url = 'http://techbus.safaribooksonline.com/9780133392838'
    SafariIE(url)


# Generated at 2022-06-24 12:58:30.879193
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    ie = SafariCourseIE.construct(url)
    ie_name = ie.IE_NAME
    assert ie_name == 'safari:course'

# Generated at 2022-06-24 12:58:41.073144
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """Check the constructor of SafariCourseIE.

    Adapted from "test_youtube_channel.py"
    """
    # Get the class object which is the constructor
    reporter = lambda results: None
    safariIE = SafariCourseIE(reporter)
    # Check that the constructor is a subclass of InfoExtractor
    assert issubclass(safariIE.__class__, InfoExtractor)
    # Check that the constructor is a subclass of OptionsBase
    assert issubclass(safariIE.__class__, OptionsBase)
    # Check that the constructor is an instance of SafariCourseIE
    assert isinstance(safariIE, SafariCourseIE)
    # Check that the constructor is an instance of InfoExtractor
    assert isinstance(safariIE, InfoExtractor)
    # Check that the constructor is an instance of OptionsBase

# Generated at 2022-06-24 12:58:43.542460
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course = SafariCourseIE('http://techbus.safaribooksonline.com/9780134426365')
    if course.suitable('http://techbus.safaribooksonline.com/9780134426365'):
        print(course)

# Generated at 2022-06-24 12:58:52.080166
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    import json
    import tempfile

    from .common import fake_urlopen

    from ..utils import (
        compat_http_server,
        compat_urllib_request,
    )

    def request_handler(request):
        handler = compat_http_server.SimpleHTTPRequestHandler
        request.send_response = lambda code: handler.log_request(handler, code, '-', '-', False)
        request.send_header = lambda name, value: handler.log_message(handler, '%s: %s', name, value)

        if request.path == '/accounts/login/':
            return handler.do_GET(handler)
        elif request.path.startswith('/accounts/login-check/'):
            request.get_full_url = lambda: request.path
            return handler.do_

# Generated at 2022-06-24 12:58:54.095229
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """
    Unit test for constructor of class SafariIE
    """

    test_video = SafariIE()

# Generated at 2022-06-24 12:59:06.265884
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE.suitable('https://learning.oreilly.com/api/v1/book/9781449396459/?override_format=json') == True
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json') == True
    assert SafariCourseIE.suitable('http://techbus.safaribooksonline.com/9780134426365') == True
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314') == True
    assert SafariCourseIE.suitable('https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838') == True

# Generated at 2022-06-24 12:59:15.704215
# Unit test for constructor of class SafariIE
def test_SafariIE():
    fixture = {
        'username': 'test_username',
        'password': 'test_password',
    }

    # create an instance of SafariIE()
    safari_ie = SafariIE(SafariIE._downloader, 'http://www.safaribooksonline.com/')

    # verify initialization of _downloader
    assert safari_ie._downloader == SafariIE._downloader

    # verify initialization of _username
    assert safari_ie._username == fixture['username']

    # verify initialization of _password
    assert safari_ie._password == fixture['password']


# Generated at 2022-06-24 12:59:19.316539
# Unit test for constructor of class SafariIE
def test_SafariIE():
    obj = SafariIE('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    print(obj.__dict__)

# Generated at 2022-06-24 12:59:24.846988
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE(None)

    assert ie.parameters['api_base'] == 'https://learning.oreilly.com/api/v1'
    assert ie.parameters['api_format'] == 'json'
    assert ie.parameters['partner_id'] == '1926081'
    assert ie.parameters['ui_id'] == '29375172'

# Generated at 2022-06-24 12:59:31.669383
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import sys
    # The constructor of SafariApiIE tries to download
    # 'https://www.safaribooksonline.com/accounts/login/'
    # without a cookie jar, so the test fails.
    for arg in sys.argv:
        if arg.startswith('--test-safari'):
            break
    else:
        return None
    return SafariApiIE(SafariBaseIE())._VALID_URL

# Generated at 2022-06-24 12:59:38.828806
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course_id = '9781449396459'
    info_dict = {
            'id': '9781449396459',
            'title': 'Hadoop Fundamentals LiveLessons',
        }
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    course = SafariCourseIE._build_course(url, course_id)
    course._login = lambda: None
    course._real_initialize()
    assert info_dict == course._INFO_DICT

# Generated at 2022-06-24 12:59:44.356084
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    test_url = 'https://www.safaribooksonline.com/api/v1/book/9780134664057/chapter/RHCE_Introduction.html'
    mobj = re.match(SafariApiIE._VALID_URL, test_url)
    assert mobj.group('course_id') == '9780134664057'
    assert mobj.group('part') == 'RHCE_Introduction'

# Generated at 2022-06-24 12:59:45.559455
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    courseIE = SafariCourseIE()
    assert courseIE is not None

# Generated at 2022-06-24 12:59:47.933301
# Unit test for constructor of class SafariIE
def test_SafariIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    instance = SafariIE()
    instance._real_initialize()

    print(instance._download_webpage_handle(url ,None, 'Test'))

# Generated at 2022-06-24 12:59:51.825964
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    constructor = SafariBaseIE._build_video_result(SafariApiIE.ie_key(), SafariApiIE.TAB_TITLE, SafariApiIE.ie_key())
    assert('SafariApiIE' == constructor.__name__)

# Generated at 2022-06-24 12:59:56.762501
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    constructor_test(SafariBaseIE, [
        # Extra arguments for SafariBaseIE
        ('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html', {
            'http_chunk_size': 10485760,
        }),
    ])


# Generated at 2022-06-24 13:00:04.888871
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    """Unit test for constructor of class SafariBaseIE."""
    safariBaseIE = SafariBaseIE(None)
    assert safariBaseIE.LOGGED_IN is False
    assert safariBaseIE._api_base == 'https://learning.oreilly.com/api/v1'
    assert safariBaseIE._api_format == 'json'

# Generated at 2022-06-24 13:00:13.498350
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """Unit test for constructor of class SafariCourseIE.
    """
    assert not SafariCourseIE.suitable("https://learning.oreilly.com/library/view/hadoop-fundamentals-livelessons/9780133392838/")
    assert not SafariCourseIE.suitable("https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/")
    assert not SafariCourseIE.suitable("https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json")
    assert SafariCourseIE.suitable("http://techbus.safaribooksonline.com/9780134426365")

# Generated at 2022-06-24 13:00:15.164233
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert SafariIE('SafariBooksonline') is not None

# Generated at 2022-06-24 13:00:16.263522
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    ie._login()

# Generated at 2022-06-24 13:00:18.026474
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class TestSafariBaseIE(SafariBaseIE):
        pass
    TestSafariBaseIE()

# Generated at 2022-06-24 13:00:30.316894
# Unit test for constructor of class SafariCourseIE

# Generated at 2022-06-24 13:00:36.184729
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # to instantiate the constructor, the url scheme must be http or https, otherwise
    # there will be error:
    #   Exception: URL scheme '' not supported
    # Here the prefix 'http://' is used for the url
    SafariCourseIE('http://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')

# Generated at 2022-06-24 13:00:37.377509
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE({'username': 'USERNAME', 'password': 'PASSWORD'})

# Generated at 2022-06-24 13:00:44.032495
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert re.match(SafariCourseIE._VALID_URL, 'https://www.safaribooksonline.com/videos/python-programming-language/9780134217314')
    assert re.match(SafariCourseIE._VALID_URL, 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert re.match(SafariCourseIE._VALID_URL, 'https://techbus.safaribooksonline.com/9780133392838')
    assert not re.match(SafariCourseIE._VALID_URL, 'https://www.youtube.com')

# Generated at 2022-06-24 13:00:46.201657
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert not safari_ie.LOGGED_IN


# Generated at 2022-06-24 13:00:49.624976
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
   safariapi = SafariApiIE()
   class_tests = safariapi.workingInstance()
   assert class_tests == True

# Generated at 2022-06-24 13:00:55.038883
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test a variant of URL to test the regex
    test_url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    safari_api_ie = SafariApiIE(None)
    assert safari_api_ie._match_id(test_url) == '9781449396459'

# Generated at 2022-06-24 13:00:56.215008
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    print(SafariApiIE())

# Generated at 2022-06-24 13:00:58.963590
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE('http://www.example.com')
    assert ie.LOGGED_IN is False

# Generated at 2022-06-24 13:01:03.901591
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    ie = SafariApiIE(SafariApiIE.ie_key())
    ie.extract(url)

# Generated at 2022-06-24 13:01:08.762775
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert(isinstance(ie, type(SafariCourseIE)))


# Generated at 2022-06-24 13:01:20.606049
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/') == True
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json') == False
    assert SafariCourseIE.suitable('http://techbus.safaribooksonline.com/9780134426365') == True
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314') == True

# Generated at 2022-06-24 13:01:25.807832
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    course_id = '9780134664057'
    url = 'https://learning.oreilly.com/videos/red-hat-enterprise/9780134664057/9780134664057-RHCE_Introduction'
    # ExtractorError: Unsupported URL:
    SafariBaseIE(None)._real_extract(url)
    url = url.replace('learning', 'www')
    SafariBaseIE(None)._real_extract(url)
    url = url.replace('videos', 'library/view/%s' % course_id)
    SafariBaseIE(None)._real_extract(url)

# Generated at 2022-06-24 13:01:34.875668
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """
        Unit test for SafariIE.
    """
    import unittest

    if unittest.TestCase.__dict__['assertNotRegexpMatches']:
        # python 2.6
        unittest.TestCase.assertNotRegexpMatches = unittest.TestCase.assertRegexpDoesNotMatch

    class TestSafariIE(unittest.TestCase):
        def test_parse_urls(self):
            expected_result = {'reference_id': None, 'course_id': '9780133392838', 'part': 'part00', 'webpage': None}
            test_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
            result

# Generated at 2022-06-24 13:01:40.686813
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course = SafariCourseIE(SafariBaseIE._downloader,
                            'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert course._VALID_URL == r'''(?x)
                    https?://
                        (?:
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+|
                                api/v1/book|
                                videos/[^/]+
                            )|
                            techbus\.safaribooksonline\.com
                        )
                        /(?P<id>[^/]+)'''

# Generated at 2022-06-24 13:01:45.033673
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    ie._LOGIN_URL = ''
    ie._netrc_machine = ''
    ie._API_BASE = ''
    ie._API_FORMAT = ''
    ie._real_initialize()

# Generated at 2022-06-24 13:01:46.141080
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('Safari');

# Generated at 2022-06-24 13:01:51.771064
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safapi_ie = SafariBaseIE._build_extractor(SafariApiIE)
    assert safapi_ie.__name__ == 'SafariApiIE'
    assert safapi_ie.ie_key() == 'Safari:api'
    assert safapi_ie.IE_NAME == 'safari:api'
    assert safapi_ie.IE_DESC == None
    assert safapi_ie._WORKING == True
    assert safapi_ie.IE_DESC == 'safaribooksonline.com online courses'

# Generated at 2022-06-24 13:01:57.173111
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # We just check for the presence of the constructor,
    # the functionality is tested by the tests for the general extractor

    safari = SafariIE(SafariIE.IE_NAME, SafariIE.IE_DESC)
    assert safari.__class__.__name__ == 'SafariIE'

# Generated at 2022-06-24 13:02:01.321384
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from . import ytdl
    yt = ytdl.YoutubeDL({})
    safari = SafariIE(yt)
    assert safari.LOGGED_IN == False
    safari._real_initialize()

test_SafariIE()

# Generated at 2022-06-24 13:02:05.288858
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class TestSafariBaseIE(SafariBaseIE):
        pass

    test_instance = TestSafariBaseIE()

    assert test_instance._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert test_instance._NETRC_MACHINE == 'safari'
    assert test_instance._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert test_instance._API_FORMAT == 'json'

# Generated at 2022-06-24 13:02:12.809514
# Unit test for constructor of class SafariIE
def test_SafariIE():
    raise Exception('This test does not work.')
    from .common import FakeLoginSession

    object_under_test = SafariIE()
    assert isinstance(object_under_test._login_session, FakeLoginSession)

    login_session = object_under_test._login_session
    # No credentials are provided
    assert 'safari' not in login_session._cookies
    assert 'safari' not in login_session.headers

    # intercept _download_webpage method
    called_urls = []

    _download_webpage = object_under_test._download_webpage

    def download_webpage(url, video_id, note=None, errnote=None, fatal=True, headers=None):
        called_urls.append(url)

# Generated at 2022-06-24 13:02:14.427665
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safariIE = SafariIE()
    assert safariIE.ie_key() == 'Safari'


# Generated at 2022-06-24 13:02:26.912207
# Unit test for constructor of class SafariIE
def test_SafariIE():
    '''
    This unittest will test constructer of class SafariIE
    '''
    safari_ie_obj = SafariIE()
    assert safari_ie_obj.LOGGED_IN == False
    assert safari_ie_obj._NETRC_MACHINE == 'safari'
    assert safari_ie_obj._API_FORMAT == 'json'
    assert safari_ie_obj._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_ie_obj._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'

# Generated at 2022-06-24 13:02:40.229685
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    def test_SafariBaseIE(fake_url):
        ie = SafariBaseIE(fetcher=DummyFetcher())._real_initialize()
        ie.url = fake_url
        assert ie.url == fake_url

    test_SafariBaseIE(
        "https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html"
    )
    test_SafariBaseIE("https://www.safaribooksonline.com/videos/python-programming-language/9780134217314/9780134217314-PYMC_13_00")

# Generated at 2022-06-24 13:02:49.793314
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from .common import FakeLoginTest

    class FakeSafariBaseIE(SafariBaseIE):
        IE_NAME = 'safari:base'
        _TESTS = [{
            'url': 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html',
            'md5': 'dcc5a425e79f2564148652616af1f2a3',
            'info_dict': {
                'id': '0_qbqx90ic',
            },
        }]

    class _FakeSafariBaseLoginTest(FakeLoginTest):
        def _test_login(self, username, password):
            ie = FakeSafariBaseIE()

# Generated at 2022-06-24 13:02:53.485594
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'

# Generated at 2022-06-24 13:02:55.412033
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari = SafariApiIE(SafariBaseIE.ie_key(), {})
    assert safari.name == 'safari:api'

# Generated at 2022-06-24 13:02:57.037807
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    ie._LOGIN_URL = None
    ie._login()

# Generated at 2022-06-24 13:02:59.506322
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    try:
        safari = SafariBaseIE()

        username, password = safari._get_login_info()
        assert username and password
        safari._login()
    except ExtractorError:
        # Expected error, but not critical enough
        pass


# Generated at 2022-06-24 13:03:04.920480
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    inst = SafariCourseIE('https://www.safaribooksonline.com/api/v1/book/9781449396459/')
    assert inst.course_id == '9781449396459'
    assert inst.course_title == '9781449396459'

# Generated at 2022-06-24 13:03:09.582024
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Basic unit test for SafariIE
    ie = SafariIE()
    assert ie.IE_NAME == 'safari'
    assert ie.IE_DESC == 'safaribooksonline.com online video'
    assert ie._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''

# Generated at 2022-06-24 13:03:11.170436
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert(SafariIE() != None)

# Generated at 2022-06-24 13:03:11.856533
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    pass

# Generated at 2022-06-24 13:03:21.026894
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()

    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'

    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'

    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-24 13:03:23.116437
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # TODO: add a test for SafariBaseIE
    # test_SafariBaseIE()
    return

# Generated at 2022-06-24 13:03:24.168605
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    pass


# Generated at 2022-06-24 13:03:32.596631
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    assert ie.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert not ie.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert ie.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert ie.suitable('http://techbus.safaribooksonline.com/9780134426365')

# Generated at 2022-06-24 13:03:38.696101
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # There are no tests for this class
    # it is only a function that calls constructor of SafariBaseIE class
    # So I am creating a test to check if SafariBaseIE is called and
    # if SafariBaseIE is called login method is called
    safariapi = SafariApiIE()

    # if login method is not called safariapi.LOGGED_IN will be False
    # check if login method is called
    assert(safariapi.LOGGED_IN == True)

# Generated at 2022-06-24 13:03:45.385634
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    course_id = '9780134664057'
    part = 'RHCE_Introduction'
    safari_api_url = 'https://www.safaribooksonline.com/api/v1/book/%s/chapter/%s.html' % (course_id, part)
    safari_api_ie = SafariApiIE()
    safari_api_ie._real_extract(safari_api_url)

# Generated at 2022-06-24 13:03:49.392998
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    assert ie.LOGGED_IN == False
    assert ie._NETRC_MACHINE == 'safari'
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'

# Generated at 2022-06-24 13:03:51.697682
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .test_safari import test_SafariCourseIE
    test_SafariCourseIE.test_SafariCourseIE(SafariCourseIE)

# Generated at 2022-06-24 13:03:53.472394
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE('SafariBaseIE')
    assert ie.get_testcases_dir() == 'safari'

# Generated at 2022-06-24 13:03:55.228587
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """
    Constructor test
    """
    SafariApiIE('SafariApi')

# Generated at 2022-06-24 13:03:58.496119
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()
    assert isinstance(safari_api_ie, SafariBaseIE) == True

# Generated at 2022-06-24 13:04:00.455053
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    return SafariCourseIE(InfoExtractor()).suitable('http://safaribooksonline.com/library/view/python-essential-reference/0596002815/')

# Generated at 2022-06-24 13:04:07.456749
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test try_login and not logged in
    safari = SafariBaseIE()
    safari._download_webpage = lambda url, video_id: (None, None)
    safari._login()
    # Test try_login and logged in
    safari = SafariBaseIE()
    safari.LOGGED_IN = True
    safari._download_webpage = lambda url, video_id: (None, None)
    safari._login()
    # Test try_login and failed to login
    safari = SafariBaseIE()
    safari._download_webpage = lambda url, video_id: (None, None)
    safari._download_json = lambda url, video_id, note, errnote, fatal=True, headers=None: {'logged_in': False}
    safari._login()

# Generated at 2022-06-24 13:04:16.173121
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import determine_ext
    from youtube_dl.options import match_filter_func

    # Create a test instance of InfoExtractor for {{{class}}}
    ie = InfoExtractor({}, {}, YoutubeDL, {}, match_filter_func({}))
    video_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    # Get the result of the _real_initialize() method
    res = ie._real_initialize()
    # Check if the _real_initialize() method has returned None

# Generated at 2022-06-24 13:04:18.236540
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    x = SafariApiIE()
    assert x.name == 'SafariApiIE'

# Generated at 2022-06-24 13:04:19.224654
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()

# Generated at 2022-06-24 13:04:31.989937
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    x = SafariBaseIE()
    assert x._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert x._NETRC_MACHINE == 'safari'
    assert x._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert x._API_FORMAT == 'json'
    assert x.LOGGED_IN == False

    x._real_initialize()
    _, login_page = x._download_webpage_handle(
        'https://learning.oreilly.com/accounts/login/', None,
        'Downloading login page')

    def is_logged(urlh):
        return 'learning.oreilly.com/home/' in urlh.geturl()

# Generated at 2022-06-24 13:04:38.699810
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from ..compat import compat_urllib_request
    from ..utils import get_testdata_file
    test_urllib_request = compat_urllib_request.Request
    testfile = get_testdata_file("test_safari_login.bin")
    test_urllib_request.side_effect = [testfile]
    test_obj = SafariBaseIE()
    test_obj.LOGGED_IN
    test_obj._login()

# Generated at 2022-06-24 13:04:44.703967
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    instance = SafariCourseIE._build_url_result(url, SafariApiIE)
    entry = instance.result['id']
    assert entry == '9781449396459/9781449396459-part00'

# Generated at 2022-06-24 13:04:56.540991
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .common import InfoExtractor
    from .safari import SafariApiIE
    import platform

    # SafariApiIE.__init__() needs to execute
    # InfoExtractor.__init__(), which will check `_downloader`.
    # Because SafariApiIE.__init__() is not invoked directly in
    # unit test code, we need to set `_downloader` of InfoExtractor
    # object here.
    # Note: In real life, we do not need to call this method in
    # unit test code.
    info_extractor = InfoExtractor(None)

# Generated at 2022-06-24 13:05:00.914767
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE(None)
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'
    assert ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'

# Generated at 2022-06-24 13:05:04.446208
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE('http://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838/9780133392838-00_SeriesIntro')
    assert safari_ie.LOGGED_IN == False

# Generated at 2022-06-24 13:05:08.145349
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Creation without proper credentials
    safariie = SafariIE()
    assert safariie.LOGGED_IN is False
    # Creation with proper credentials
    safariie = SafariIE(username='email@example.com', password='password')
    assert safariie.LOGGED_IN is True

# Generated at 2022-06-24 13:05:17.841533
# Unit test for constructor of class SafariIE
def test_SafariIE():
    server_url, authentication_url, raw_ticket, ks = parse_token('https://learning.oreilly.com/videos/learning-path-angular/9780134773902/9780134773902-LPAN_1_00')
    assert server_url == 'https://cdnapisec.kaltura.com'
    assert authentication_url == '/p/1926081/sp/192608100/playManifest/entryId/12221161/format/url/protocol/https'

# Generated at 2022-06-24 13:05:29.552175
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .safari import SafariApiIE
    from .safari import SafariBaseIE
    from .common import InfoExtractor
    from .common import compat_urlparse
    from .common import compat_parse_qs
    from .common import ExtractorError
    from .common import update_url_query
    import re
    import json

    # Test URL and valid ID
    testUrl = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    testId = '9781449396459'

    # Mocked methods
    def _real_initialize(self):
        pass

    def _login(self):
        pass


# Generated at 2022-06-24 13:05:35.418197
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert SafariIE(None)._PARTNER_ID == '1926081'
    assert SafariIE(None)._UICONF_ID == '29375172'
    assert SafariCourseIE(None)._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert SafariCourseIE(None)._API_FORMAT == 'json'

# Generated at 2022-06-24 13:05:40.370365
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariBaseIE._LOGIN_URL = lambda self: None
    SafariBaseIE.LOGGED_IN = True
    SafariCourseIE('Safari', 'safaribooksonline.com')
    SafariCourseIE('Safari', 'safaribooksonline.com', 'SafariCourseIE')

# Generated at 2022-06-24 13:05:42.019763
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert isinstance(SafariBaseIE(), InfoExtractor)

# Generated at 2022-06-24 13:05:44.814636
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """
    Test if SafariIE can be instantiated
    """
    ie = SafariIE('test','test')
    assert ie.__class__ == SafariIE

# Generated at 2022-06-24 13:05:50.407125
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # this test only verifies that SafariIE constructor doesn't crash
    # with the expected input parameters
    safari = SafariIE('safari', 'safaribooksonline.com')
    try:
        assert safari.IE_NAME == 'safari'
        assert safari.IE_DESC == 'safaribooksonline.com online video'
    except:
        print("Class SafariIE constructed incorrectly")

# Generated at 2022-06-24 13:06:03.566576
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    input_url = 'http://techbus.safaribooksonline.com/9780134426365'
    ie = SafariCourseIE(SafariCourseIE.ie_key())
    assert ie.suitable(input_url), 'SafariCourseIE.suitable should return True'
    assert ie.IE_DESC == 'safaribooksonline.com online courses', 'SafariCourseIE.IE_DESC is not as expected'
    assert ie.IE_NAME == 'safari:course', 'SafariCourseIE.IE_NAME is not as expected'

# Generated at 2022-06-24 13:06:10.856771
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    import unittest

    class TestSafariBaseIE(unittest.TestCase):
        def test_success(self):
            safaribase = SafariBaseIE()

        def test_error(self):
            safaribase = SafariBaseIE()
            safaribase._api_base = 'http://safaribooksonline.com/api/v1/'
            with self.assertRaisesRegexp(ExtractorError, 'Unable to log in'):
                safaribase._login()

    unittest.main()
    return

# Generated at 2022-06-24 13:06:22.959479
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    assert hasattr(ie, '_download_webpage_handle')
    assert hasattr(ie, '_download_json_handle')
    assert hasattr(ie, '_download_json')
    assert hasattr(ie, '_apply_first_set_cookie_header')
    assert hasattr(ie, '_get_login_info')
    assert hasattr(ie, '_real_initialize')
    assert hasattr(ie, '_real_extract')
    assert hasattr(ie, '_login')
    assert hasattr(ie, '_real_initialize')
    assert hasattr(ie, '_LOGIN_URL')
    assert hasattr(ie, '_NETRC_MACHINE')
    assert hasattr(ie, '_API_BASE')
    assert hasattr

# Generated at 2022-06-24 13:06:25.625627
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # TODO
    # we should add unit test of constructor of class SafariApiIE
    pass

# Generated at 2022-06-24 13:06:35.277060
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import unittest
    from extractor_test import ExtractorTestCase, MockHttpServer, TestServerHandler

    class SafariApiTestCase(unittest.TestCase, ExtractorTestCase):
        def setUp(self):
            self.server_handler = TestServerHandler

            self.test_server = MockHttpServer(ip=self.server_handler)
            self.test_server.start()

            self.server_handler.test_handler = {
                'method': 'GET',
                'query': (r'.*/api/v1/book/*',),
                'response': '{"chapters": [{"parts": [{"title": "title", "web_url": "/web_url/part00.html"}]}]}',
            }

        def tearDown(self):
            self.test_server.stop()


# Generated at 2022-06-24 13:06:38.145805
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert not isinstance(SafariBaseIE(), SafariBaseIE)

# Generated at 2022-06-24 13:06:41.049488
# Unit test for constructor of class SafariIE
def test_SafariIE():
    with open('test_data/safari/01_api_config.json', encoding='utf-8') as json_file:
        json_config = json.load(json_file)
    for item in json_config:
        url = item['url']
        if SafariIE.suitable(url):
            aIE = SafariIE()
            break

# Generated at 2022-06-24 13:06:46.450049
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE('safari', 'safaribooksonline.com')

    # check is_logged function
    ie.LOGGED_IN = True # force logged in
    assert ie.is_logged()

    ie.LOGGED_IN = False # force logged out
    assert not ie.is_logged()

    # check _real_initialize
    ie._real_initialize()

# Generated at 2022-06-24 13:06:52.497889
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """
    This unit test tests the constructor of class SafariIE
    """
    # Test with valid book_id
    book_id = "9780133392838"
    safari = SafariIE()
    safari.book_id = book_id
    assert safari.book_id == book_id


# Generated at 2022-06-24 13:07:02.314978
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()
    assert(safari_api_ie.IE_NAME == 'safari:api')
    assert(safari_api_ie.IE_DESC == 'safaribooksonline.com online course chapters')
    assert(safari_api_ie._VALID_URL == 'https?://(?:www\\.)?(?:safaribooksonline|(?:learning\\.)?oreilly)\\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\\.html')
    assert(safari_api_ie._NETRC_MACHINE == 'safari')
    assert(safari_api_ie._API_FORMAT == 'json')

# Generated at 2022-06-24 13:07:04.367929
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    """Check construction of SafariBaseIE"""
    parent = SafariBaseIE()

    assert parent.LOGGED_IN == False

# Generated at 2022-06-24 13:07:05.015966
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()

# Generated at 2022-06-24 13:07:10.516591
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE('www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')._real_extract(
        'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')

# Generated at 2022-06-24 13:07:14.379112
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    course_id = '9781449396459'
    book_url = 'https://www.safaribooksonline.com/api/v1/book/{0}/?override_format=json'.format(course_id)
    output_safariApiIE = SafariApiIE()
    output_safariApiIE.url = book_url
    output_safariApiIE._real_extract(output_safariApiIE.url)

# Generated at 2022-06-24 13:07:24.599754
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safaribooksonline = SafariBaseIE._build_url(
        'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838',
        {})
    assert safaribooksonline == 'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838'

    safaribooksonline = SafariBaseIE._build_url(
        'https://learning.safaribooksonline.com/videos/hadoop-fundamentals-livelessons/9780133392838',
        {})
    assert safaribooksonline == 'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838'

    safaribook

# Generated at 2022-06-24 13:07:30.096655
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Initialize unit test
    import unittest

    class TestSafariIE(unittest.TestCase):
        def setUp(self):
            self.safaribooksonline = SafariIE()

    # Run unit test
    unittest.main()

# Generated at 2022-06-24 13:07:33.458793
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    inst = SafariApiIE()
    inst.to_screen = lambda *a, **k: None

# Generated at 2022-06-24 13:07:34.076511
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()

# Generated at 2022-06-24 13:07:37.756013
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Check constructor calls _login() method
    class TestSafariBaseIE(SafariBaseIE):
        def _login(self):
            self.LOGIN_CALLED = True
    ie = TestSafariBaseIE()
    assert ie.LOGIN_CALLED

# Generated at 2022-06-24 13:07:40.653001
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    extractor = SafariApiIE()
    assert extractor._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Generated at 2022-06-24 13:07:41.824562
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safariBase = SafariBaseIE()
    assert safariBase is not None

# Generated at 2022-06-24 13:07:45.069973
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    safari_base_ie = SafariBaseIE()
    safari_base_ie.extract(url)


# Generated at 2022-06-24 13:07:56.229079
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    test_SafariCourseIE.SafariCourseIE = SafariCourseIE

    # Test valid url
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    url_obj = SafariCourseIE(SafariCourseIE.suitable(url))
    assert url_obj.ie_key() == 'SafariCourse'

    # Test wrong url
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    assert SafariCourseIE.suitable(url) == False

# Generated at 2022-06-24 13:08:03.644921
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .common import HEADRequest, FakeHttpServer
