

# Generated at 2022-06-24 12:57:58.730650
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    a = SafariApiIE({})
    assert a

# Generated at 2022-06-24 12:58:02.577873
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/network-programming-in/9781593272988/'
    SafariCourseIE().suitable(url)

# Generated at 2022-06-24 12:58:08.973111
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    import os.path
    # test with the test data set
    test_filename = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'test_data', 'safari_constructor.json')
    with open(test_filename, 'r') as f:
        test_input = f.read()
    ie = SafariCourseIE()
    ie.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    ie.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')

# Generated at 2022-06-24 12:58:11.205683
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_object = SafariCourseIE()
    # Assert the object is created sucessfully or not
    assert safari_course_object

# Generated at 2022-06-24 12:58:21.996976
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # pylint: disable=import-error
    from .common import update_url_query
    from .compat import compat_parse_qs
    from .compat import compat_urlparse
    from .compat import compat_urllib_error_URLError

    safari_api_ie = SafariApiIE()
    index_page_url = 'https://www.safaribooksonline.com/library/view/nifi-in-action/9781491980506/'
    mobj = re.match(SafariCourseIE._VALID_URL, index_page_url)
    course_id = mobj.group('id')
    web_page_url = 'https://www.safaribooksonline.com/api/v1/book/%s/chapter/part00.html' % course_id

# Generated at 2022-06-24 12:58:34.054661
# Unit test for constructor of class SafariIE
def test_SafariIE():
    test_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    test_initialization_error = 'object has no attribute \'_download_webpage\''
    test_video_id = '0_qbqx90ic'

    # Check for SafariIE object constructor
    try:
        SafariIE(test_url)
    except AttributeError as attribute_error:
        assert str(attribute_error) == test_initialization_error, 'Unexpected error message: %s' % attribute_error

    # Check for SafariIE._real_extract()
    safari_obj = SafariIE(test_url)
    video_id = safari_obj._real_extract(test_url)
   

# Generated at 2022-06-24 12:58:38.058931
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE(InfoExtractor())
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie is not None

# Generated at 2022-06-24 12:58:39.826094
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    klass = SafariCourseIE
    instance = klass()
    assert instance.IE_NAME == 'safari:course'

# Generated at 2022-06-24 12:58:45.839055
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Make sure that SafariBaseIE has some methods implemented
    from .common import BaseIE

    at_least_one_implemented = False
    for name, obj in BaseIE.__dict__.items():
        if (not name.startswith('__')
                and callable(obj)
                and obj.__module__ == 'youtube_dl.extractor.safari'):
            at_least_one_implemented = True
            break

    assert at_least_one_implemented

# Generated at 2022-06-24 12:58:48.685543
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    return SafariBaseIE(SafariBaseIE._create_ie_instance(SafariBaseIE))

# Generated at 2022-06-24 12:58:52.479609
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    """Unit test for SafariBaseIE constructor."""
    u = SafariBaseIE()
    assert u.ie_key() == 'SafariBaseIE'
    assert u._VALID_URL == ''
    assert u._TESTS == []

# Generated at 2022-06-24 12:58:56.839974
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    assert SafariCourseIE.suitable(url) == True
    #assert SafariCourseIE(url)



# Generated at 2022-06-24 12:58:58.197381
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert SafariApiIE()

# Generated at 2022-06-24 12:58:58.773333
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    test_case = SafariBaseIE()

# Generated at 2022-06-24 12:59:02.404637
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """
    Unit test for constructor of class SafariCourseIE
    """
    test_class = SafariCourseIE()
    assert type(test_class) is SafariCourseIE


# Generated at 2022-06-24 12:59:10.858375
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .generic import youtube_dl as yt
    # unit test for SafariIE doesn't require an active internet connection
    saf = yt.extractors.safari.SafariIE(yt.YoutubeDL())
    # check that our mocks work
    assert saf._download_webpage_handle.call_count == 0
    url = saf._APIS['kaltura']
    assert saf._download_json_handle(url, None, "test_SafariIE")
    assert saf._download_webpage_handle.call_count == 1
    assert saf._download_json_handle.call_count == 1
    assert saf._download_webpage_handle.call_count == 1
    assert saf._download_json.call_count == 1
    assert saf._apply_first_set_cookie_header.call_count == 2
   

# Generated at 2022-06-24 12:59:11.731019
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    x = SafariApiIE()
    x._real_initialize()

# Generated at 2022-06-24 12:59:13.895091
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    instance = SafariBaseIE()
    assert 'SafariBaseIE._LOGIN_URL' in dir(instance)

# Generated at 2022-06-24 12:59:25.373442
# Unit test for constructor of class SafariIE
def test_SafariIE():
    get_testcases_SafariIE = lambda self :test_SafariIE.testcases
    test_SafariIE.testcases = [{
        'url': 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html',
        'only_matching': True,
    }]
    test_SafariIE.testcases = []
    safari = SafariIE()
    safari.suitable(test_SafariIE.testcases[0]['url'])
    safari._real_extract(test_SafariIE.testcases[0]['url'])
    test_SafariIE.testcases = get_testcases_SafariIE(None)
    return

# Generated at 2022-06-24 12:59:30.547153
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """Unit test for constructor of class SafariApiIE"""
    ie = SafariApiIE('http://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json', {})
    assert ie.IE_NAME == 'safari:api'

# Generated at 2022-06-24 12:59:33.985547
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    s = SafariBaseIE(None)
    assert s._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert s._API_FORMAT == 'json'
    assert s.LOGGED_IN == False

# Generated at 2022-06-24 12:59:35.771080
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # test SafariCourseIE constructor
    SafariCourseIE(downloader=None)
    SafariCourseIE()

# Generated at 2022-06-24 12:59:37.540536
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    class_object = SafariApiIE()
    assert class_object.IE_NAME == 'safari:api'

# Generated at 2022-06-24 12:59:39.974227
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    constructor_test(SafariBaseIE, {
        'LOGGED_IN': False
    }, {
        'username': 'test',
        'password': 'testpass'
    })

# Generated at 2022-06-24 12:59:48.583392
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import safaribooksonline
    safaribooksonline.SafariApiIE.__module__ = 'safaribooksonline'
    safaribooksonline.SafariApiIE.__name__ = 'SafariApiIE'
    safaribooksonline.SafariApiIE.suitable = lambda self,url:True
    safaribooksonline.SafariApiIE.ie_key = lambda self:None
    safaribooksonline.SafariApiIE.ie = lambda self:None
    safaribooksonline.SafariApiIE.test = None

    # test registries
    import sys

# Generated at 2022-06-24 12:59:53.509513
# Unit test for constructor of class SafariIE
def test_SafariIE():
    u = "https://learning.oreilly.com/videos/java-8-lambdas/9781491947163/9781491947163-JAVA8_01_01_01"
    w = SafariIE()._real_extract(u)
    assert w is not None

if __name__ == '__main__':
    test_SafariIE()

# Generated at 2022-06-24 13:00:07.232789
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ''' Test case for constructor of class SafariIE
    '''
    safari_ie = SafariIE()
    assert safari_ie.IE_NAME == 'safari'
    assert safari_ie.IE_DESC == 'safaribooksonline.com online video'

# Generated at 2022-06-24 13:00:07.874576
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-24 13:00:17.185000
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://learning.oreilly.com/videos/testing-javascript/9780135263692'
    course = SafariCourseIE(url)
    assert course == SafariCourseIE(url)
    assert isinstance(course, SafariCourseIE)
    assert course == SafariCourseIE(url)
    assert course._login == SafariBaseIE._login
    assert course.ie_key() == 'SafariCourseIE'
    assert course.suitable(url)
    assert course._match_id == SafariBaseIE._match_id
    assert course._real_extract == SafariCourseIE._real_extract

# Generated at 2022-06-24 13:00:18.166201
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert isinstance(SafariIE(), SafariIE)

# Generated at 2022-06-24 13:00:20.567050
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE('safari:api')
    assert safari_api_ie.IE_NAME == 'safari:api'

# Generated at 2022-06-24 13:00:28.997779
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from .test_utils import MockIE

    # get video url
    assert_raises_regex(
        ExtractorError, 'Incorrect safaribooksonline credentials', MockIE.new,
        'SafariBaseIE', {'username': '', 'password': ''}).\
        download_webpage(
            'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')

# Generated at 2022-06-24 13:00:29.661524
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-24 13:00:31.153507
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safariIE = SafariIE()
    print(safariIE)


# Generated at 2022-06-24 13:00:41.321912
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    i = SafariCourseIE()
    assert i.suitable('safari:course') == False
    assert i.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/') == True
    assert i.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json') == False
    assert i.suitable('http://techbus.safaribooksonline.com/9780134426365') == True
    assert i.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314') == True

# Generated at 2022-06-24 13:00:45.829410
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Basic initialization, checking that calling _real_extract doesn't raise an exception
    safariapiie = SafariApiIE()
    safariapiie._real_extract(SafariApiIE._TESTS[0]['url'])

# Generated at 2022-06-24 13:00:47.487101
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safariBase = SafariBaseIE()
    safariBase._real_initialize()

# Generated at 2022-06-24 13:01:00.625343
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    #The class SafariApiIE has only one constructor, the function _real_extract.
    #We unit test for the following attributes in this function:
    #1. the url have to match the url format
    url1 = 'https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html'
    url2 = 'https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html/?override_format=json'
    url3 = 'https://www.safaribooksonline.com/api/v1/book/9780134664057/chapter/RHCE_Introduction.html'

# Generated at 2022-06-24 13:01:01.271269
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()

# Generated at 2022-06-24 13:01:07.538427
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Create instance of class SafariCourseIE
    safari_course_IE = SafariCourseIE()
    # Call function suitable()
    safari_course_IE.suitable(None)

    # Create instance of class InfoExtractor
    info_extractor = InfoExtractor()
    # Call method _match_id()
    info_extractor._match_id(None)


# Generated at 2022-06-24 13:01:16.004150
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course = SafariCourseIE()
    print(course)
    print(course.__dict__)
    print(course.IE_NAME)
    print(course.IE_DESC)
    print(course.valid_url('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'))
    print(course.valid_url('https://learning.oreilly.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'))

# Generated at 2022-06-24 13:01:18.518940
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """
    If a constructor for SafariApiIE is defined, the unit test framework is not able
    to detect the SafariIE class.
    """
    return

# Generated at 2022-06-24 13:01:24.800685
# Unit test for constructor of class SafariIE

# Generated at 2022-06-24 13:01:28.997159
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    course_id = '9781449396459'
    course_title = 'Learning Spark: Lightning-Fast Big Data Analysis'
    try:
        assert SafariBaseIE(course_id, course_title) is not None
    except:
        import sys
        import traceback
        exc_info = sys.exc_info()
        traceback.print_exception(*exc_info)



# Generated at 2022-06-24 13:01:34.562917
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    with open('test_data/safaribooksonline.json') as file_:
        test_json = json.load(file_)

    class FakeUrl(object):
        def __init__(self, parts):
            self.parts = parts

        def geturl(self):
            return self.parts

    safari_api = SafariApiIE()
    safari_api._download_webpage_handle = lambda *a, **kw: (None, FakeUrl('http://localhost:8000/api/v1/book/9781449396459/chapter/part1.html'))
    safari_api._download_json = lambda *a, **kw: test_json

    assert(safari_api._download_webpage('http://localhost:8000/book/9781449396459/chapter/part1.html'))
   

# Generated at 2022-06-24 13:01:47.800977
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = "https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/0322427488.html"
    course_id = "9781449396459"
    part = "0322427488"
    expected_url = "https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/" \
                   "9780133392838/part00.html"
    ie = SafariApiIE()
    mobj = re.match(ie._VALID_URL, url)
    part = ie._download_json(url, '%s/%s' % (mobj.group('course_id'), mobj.group('part')),
                             'Downloading part JSON')
    assert part['web_url'] == expected

# Generated at 2022-06-24 13:02:00.789258
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert (SafariIE.__module__) == 'youtube_dl.extractor.safari'
    assert (SafariIE.__name__) == 'SafariIE'
    assert (SafariIE.__doc__) == 'safaribooksonline.com online video'
    assert (SafariIE._VALID_URL) == 'https?://(?:www\\.)?(?:safaribooksonline|(?:learning\\.)?oreilly)\\.com/library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\\#&]+)\\.html'

# Generated at 2022-06-24 13:02:04.673427
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .ie import GenericIE
    GenericIE._WORKING = lambda x: False
    GenericIE.working = lambda x: False
    safariapiie = SafariApiIE()
    assert isinstance(safariapiie, SafariApiIE)
    assert safariapiie.LOGGED_IN is False


# Generated at 2022-06-24 13:02:06.830338
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')

# Generated at 2022-06-24 13:02:08.279065
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()
    constructor_test1(safari)
    constructor_test2(safari)

# Generated at 2022-06-24 13:02:09.672482
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    foo = SafariCourseIE()
    assert(foo.IE_NAME == 'safari:course')


# Generated at 2022-06-24 13:02:10.734981
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert isinstance(SafariCourseIE().IE_DESC, str)

# Generated at 2022-06-24 13:02:14.248339
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    safaricourse_ie = SafariCourseIE(url)
    assert safaricourse_ie.course_id == '9780133392838'

# Generated at 2022-06-24 13:02:19.547576
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # This test will fail unless safaribooksonline account credentials
    # are entered in youtube-dl's netrc file
    # See https://github.com/rg3/youtube-dl#netrc-authentication
    SafariBaseIE._download_webpage_handle('https://www.safaribooksonline.com/', None, 'Downloading test webpage')

# Generated at 2022-06-24 13:02:21.306931
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    return SafariBaseIE('safari', 'safaribooksonline.com online video')

# Generated at 2022-06-24 13:02:35.370442
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # _download_json returns an empty json dictionary
    empty_json = {}

    # _download_json returns a json dictionary containing a 'web_url' key that
    # points to a YouTube video
    video_url = 'https://www.youtube.com/watch?v=9bZkp7q19f0'
    video_json = {'web_url': video_url}

    # Create a SafariApiIE object
    safari = SafariApiIE()

    # Since the safari object is initialized with an empty json dictionary,
    # an error is raised
    resp = safari._real_extract('https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html', empty_json)
    assert(resp is None)

    # Since the safari

# Generated at 2022-06-24 13:02:42.472479
# Unit test for constructor of class SafariIE
def test_SafariIE():
    for url in ['https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838/9780133392838-01_Lesson01_03',
        'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838/9780133392838-01_Lesson01_03/']:
        SafariIE().suitable(url)
        SafariIE()._real_extract(url)



# Generated at 2022-06-24 13:02:50.966358
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert not SafariCourseIE.suitable(
        'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert not SafariCourseIE.suitable('https://techbus.safaribooksonline.com/9780134426365')
    assert not SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert not SafariCourseIE.suitable('https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838')

# Generated at 2022-06-24 13:02:51.529573
# Unit test for constructor of class SafariIE
def test_SafariIE():
    client = SafariIE()

# Generated at 2022-06-24 13:02:57.888315
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    class TestDownloader(object):
        def __init__(self, result):
            self.result = result

        def to_screen(self, *args, **kwargs):
            pass

        def to_stdout(self, *args, **kwargs):
            pass

        def report_error(self, msg):
            pass

        def report_warning(self, msg):
            pass

        def trouble(self, *args, **kwargs):
            pass

        def report_info(self, msg):
            pass

        def report_file_already_downloaded(self, file_name):
            pass


# Generated at 2022-06-24 13:03:00.104106
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE('safari')
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'

# Generated at 2022-06-24 13:03:02.523499
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE("SafariBaseIE")

# Generated at 2022-06-24 13:03:06.788694
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    try:
        import netrc
        username, password = netrc.netrc().authenticators(SafariBaseIE._NETRC_MACHINE)
    except (IOError, ImportError):
        return
    safari = SafariBaseIE(username=username, password=password)
    assert safari.LOGGED_IN

# Generated at 2022-06-24 13:03:10.867485
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Dummy SafariBaseIE with class variable LOGGED_IN set to True
    class LoggedIn(SafariBaseIE):
        LOGGED_IN = True
    # Dummy SafariBaseIE with class variable LOGGED_IN set to False
    class NotLoggedIn(SafariBaseIE):
        LOGGED_IN = False

    LoggedIn()
    NotLoggedIn()

# Generated at 2022-06-24 13:03:16.648237
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()
    assert safari.LOGGED_IN is False
    # The call to _real_initialize has to be protected from
    # being called twice in a single test.
    safari._real_initialize()
    return safari

# Unit tests for method _login of class SafariBaseIE

# Generated at 2022-06-24 13:03:27.283992
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    course_url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json&%s'

    # No username or password
    params = {'partner_id': '20283', 'uiconf_id': '34926052', 'reference_id': '9781449396459_2773'}
    url = course_url % compat_urllib_parse_urlencode(params)

    safari = SafariApiIE(SafariBaseIE)
    info = safari._real_extract(url)
    assert info['url'] == 'https://cdnapisec.kaltura.com/html5/html5lib/v2.37.1/mwEmbedFrame.php?'

# Generated at 2022-06-24 13:03:30.054868
# Unit test for constructor of class SafariIE
def test_SafariIE():
    if not hasattr(SafariIE, '_login'):
        SafariIE._login = lambda self: None
    SafariIE('', {}, True)

# Generated at 2022-06-24 13:03:40.037248
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    sb = SafariBaseIE()
    test_url  = "https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html"
    course_id = "9780133392838-part00"
    test_json = sb._download_json(
        "https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html",
        course_id ,
        'Downloading part JSON')
    assert(test_url == test_json['web_url'])
    assert("Hadoop Fundamentals LiveLessons" == test_json['title'])



# Generated at 2022-06-24 13:03:44.504551
# Unit test for constructor of class SafariIE
def test_SafariIE():
    x = SafariIE()
    SafariIE._login()
    if not x.LOGGED_IN: # This line causes an exception if it is removed.
        raise AssertionError("SafariIE._login() did not set 'LOGGED_IN' flag to True!")

# Generated at 2022-06-24 13:03:51.954193
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    try:
        from .test_common import TEST_USERNAME, TEST_PASSWORD
    except ImportError:
        raise ImportError(
            'Please download "test_common.py" from https://github.com/ytdl-org/youtube-dl/blob/master/test/test_common.py and save it in ytdl-org/youtube_dl/test/test_common.py')

    safari_course_ie = SafariCourseIE({
        'username': TEST_USERNAME,
        'password': TEST_PASSWORD,
    })
    assert safari_course_ie.LOGGED_IN

# Generated at 2022-06-24 13:03:54.161869
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert SafariApiIE(SafariApiIE.ie_key()).ie_key() == SafariApiIE.ie_key()

# Generated at 2022-06-24 13:04:01.984567
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test construction of SafariIE
    m = SafariIE()
    import os.path
    import tempfile

# Generated at 2022-06-24 13:04:03.751760
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_ie = SafariBaseIE()
    assert isinstance(safari_ie, object)

# Generated at 2022-06-24 13:04:05.889581
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_ie = SafariCourseIE()
    safari_course_ie._real_initialize()

# Generated at 2022-06-24 13:04:14.982081
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import json
    import random
    import string


# Generated at 2022-06-24 13:04:18.397538
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safariIE = SafariIE()
    assert safariIE.LOGGED_IN == False
    safariIE._real_initialize()
    assert safariIE.LOGGED_IN == False

# Generated at 2022-06-24 13:04:30.962230
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .common import test_url_result
    from .common import test_smuggle_url

    test_smuggle_url(SafariApiIE, 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html', 'https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html', {})
    test_url_result(SafariApiIE, 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html', 'Kaltura', 'mp4')


# Generated at 2022-06-24 13:04:34.040555
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """Compatibility test for constructor of class SafariApiIE"""
    assert SafariApiIE(SafariApiIE.ie_key(), SafariBaseIE._NETRC_MACHINE)

# Generated at 2022-06-24 13:04:39.128836
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """
    Constructor for class SafariApiIE should set correct _API_BASE and _API_FORMAT
    """
    ife = SafariApiIE('safaribooksonline', True)
    assert ife._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ife._API_FORMAT == 'json'

# Generated at 2022-06-24 13:04:40.685159
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert_raises(TypeError, SafariIE, 'SafariIE')

# Generated at 2022-06-24 13:04:51.720667
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    if not hasattr(SafariApiIE, 'IE_NAME'):
        # If the instance does not have IE_NAME attribute, it means that
        # the class is not able to download anything on its own.
        # In this case, the constructor is useless for unit test, so we
        # just return here.
        return

    instance = SafariApiIE()

    # Check if _VALID_URL attribute exists.
    assert hasattr(instance, '_VALID_URL')

    # Check if _TEST attribute exists.
    assert hasattr(instance, '_TESTS')

    # Check if IE_NAME is the same as the class name.
    assert instance.IE_NAME == instance.__class__.__name__

# Generated at 2022-06-24 13:05:00.615279
# Unit test for constructor of class SafariIE
def test_SafariIE():
    url = "https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838/9780133392838-00_SeriesIntro"
    safari = SafariIE()
    safari.expected_warnings = []
    safari.extract(url)
    safari.report_warning.assert_called_once_with(
        'This video is only available to registered users. '
        'Please login with safaribooksonline account credentials '
        '(see https://github.com/rg3/youtube-dl/blob/master/README.md#username-password)')

# Generated at 2022-06-24 13:05:09.689970
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # pylint: disable=protected-access
    # Assert that SafariIE._VALID_URL starts with SafariIE.VALID_URL
    assert SafariIE._VALID_URL.startswith(SafariIE.VALID_URL)
    # Assert that SafariIE._VALID_URL, when split by slashes,
    # contains only at most 1 asterisk
    assert sum(1 for x in SafariIE._VALID_URL.split('/') if x == '*') <= 1
    # Assert that SafariIE._TESTS contains at least 1 entry
    assert SafariIE._TESTS
    # Assert that all entries in SafariIE._TESTS contain keys
    # 'url' and 'only_matching'
    for test in SafariIE._TESTS:
        assert 'url' in test

# Generated at 2022-06-24 13:05:19.007284
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url_base = 'https://www.safaribooksonline.com/api/v1/book/'
    url_id = '9781449396459'
    url = url_base + url_id + '/?override_format=json'

    assert SafariCourseIE.suitable(url)
    result = SafariCourseIE()._real_extract(url)

    assert result['_type'] == 'playlist'
    assert result['id'] == url_id

    entries = result['entries']

    if entries:
        entry_single = entries[0]

        assert entry_single['ie_key'] == 'SafariApi'
        assert entry_single['url'] == url_base + url_id + '/chapter/part00.html'


# Generated at 2022-06-24 13:05:30.298364
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safariBaseIE = SafariBaseIE()  # creating object for the class
    safariBaseIE._get_login_info = lambda : ("username", "password")

    from .test_common import dynamic_testcases
    # create testcases dynamically
    # _login calls _download_webpage_handle and _download_json functions
    # we need to mock these functions
    # both have a similar signature and return a similar object
    def call_mocked_func(funcName, *args, **kwargs):
        return {'code':200, 'url':"https://learning.oreilly.com/accounts/login-check/", 'text':"I have logged in"}, "https://learning.oreilly.com/accounts/login-check/"

    safariBaseIE._download_webpage_handle = lambda x, y, z: call_mocked

# Generated at 2022-06-24 13:05:31.985946
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    if ie.LOGGED_IN:
        print("Extractor is logged-in")
    else:
        print("Extractor is not logged-in")

# Generated at 2022-06-24 13:05:42.142263
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Testing the constructor of class SafariIE
    cls = SafariIE
    mobj = re.match(cls._VALID_URL,
            'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    # Testing _real_extract
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    cls._real_extract(cls, url)

# Generated at 2022-06-24 13:05:44.912973
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """
    Simple unit test to check availability of instance of class SafariApiIE
    """
    SafariApiIE()


# Generated at 2022-06-24 13:05:46.306785
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .test_safari import test as safari_test
    safari_test(SafariApiIE)

# Generated at 2022-06-24 13:05:47.848164
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('SafariApiIE', 'safari')

# Generated at 2022-06-24 13:05:48.651596
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    pass

# Generated at 2022-06-24 13:06:02.234358
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test that the proper course_id is extracted from url
    url = "https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json"
    course_id = SafariCourseIE._match_id(url)
    assert course_id == '9781449396459'

    url = 'http://techbus.safaribooksonline.com/9780134426365'
    course_id = SafariCourseIE._match_id(url)
    assert course_id == '9780134426365'

    url = 'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838'
    course_id = SafariCourseIE._match_id(url)

# Generated at 2022-06-24 13:06:07.692344
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Constructor and method assert_login()
    dl = SafariApiIE()
    assert dl._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert dl._API_FORMAT == 'json'
    assert dl.LOGGED_IN == False



# Generated at 2022-06-24 13:06:09.079820
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ydl = SafariBaseIE()
    assert ydl.LOGGED_IN == False

# Generated at 2022-06-24 13:06:10.396963
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('safaribooksonline.com')

# Generated at 2022-06-24 13:06:11.405389
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert ie

# Generated at 2022-06-24 13:06:12.731763
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safariIE = SafariIE()
    safariIE._real_initialize()

# Generated at 2022-06-24 13:06:13.830296
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """
    Simple test case to check if the Safari IE constructor works.
    """
    ie = SafariIE()

# Generated at 2022-06-24 13:06:15.156643
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Constructor should not raise an exception
    try:
        SafariBaseIE('test')
        assert True
    except:
        assert False

# Generated at 2022-06-24 13:06:20.307272
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    class MockSafariCourseIE(SafariCourseIE):
        def _real_extract(self, url):
            return

        @classmethod
        def suitable(cls, url):
            return True

    assert MockSafariCourseIE.suitable('http://www.safaribooksonline.com/library/view/title/')



# Generated at 2022-06-24 13:06:21.698034
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    test_base_constructor(SafariApiIE)

# Generated at 2022-06-24 13:06:24.770481
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safariApiIE = SafariApiIE();
    safariApiIE._download_webpage = lambda url: True;
    safariApiIE._real_initialize();

# Generated at 2022-06-24 13:06:28.096845
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE("https://techbus.safaribooksonline.com/9781785287898")
    assert ie._real_initialize() is None

# Generated at 2022-06-24 13:06:31.346830
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/'
    course_id = SafariBaseIE._match_id(url)
    course_title = 'Python Programming Language'

# Generated at 2022-06-24 13:06:36.665352
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # ensure that SafariApiIE.__init__ constructs expected URL without performing request
    class ReturnNoneRequestIE(SafariApiIE):
        def _download_webpage(self, *args, **kwargs):
            return None
    test_url = 'http://www.safari.oreilly.com/api/v1/book/9781449396459/chapter/part00.html'
    ReturnNoneRequestIE(test_url)
    assert test_url == ReturnNoneRequestIE(test_url).url

# Generated at 2022-06-24 13:06:47.606688
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert ('https://www.safaribooksonline.com/library/view/python-programming-language/9780134217314/'
            + '9780134217314-PYMC_13_00.html') == SafariIE._build_video_url(
                '9780134217314', 'PYMC_13_00')

    assert ('part00.html', '9780133392838') == SafariIE._get_course_part_info(
        'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838'
        + '/part00.html')


# Generated at 2022-06-24 13:06:50.155305
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    """
    Test for constructor of class SafariBaseIE.
    """
    instance = SafariBaseIE()
    assert instance.LOGGED_IN is False

# Generated at 2022-06-24 13:07:00.802258
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test case #1
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    # meta data
    course_id = '9781449396459'
    part = 'part00'
    course_id_part = course_id + '/' + part
    # expected API links
    expected_part_url = 'https://www.safaribooksonline.com/api/v1/book/' + course_id_part + '.html'
    expected_url = 'https://www.safaribooksonline.com/library/view/' + course_id_part + '.html'
    # object creation
    api_ie = SafariApiIE(SafariBaseIE())
    # extraction

# Generated at 2022-06-24 13:07:04.814536
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    """
    Ensure that the SafariBaseIE object constructor doesn't fail when
    called without arguments. This is the preferable way of initializing
    the class, because it allows to test the downloader without needing
    an active internet connection.
    """
    SafariBaseIE()

# Generated at 2022-06-24 13:07:16.519372
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    test_url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    test_course_id = '9781449396459'
    test_part = '1'
    mock_downloader = None
    result = SafariApiIE(mock_downloader)
    assert(result.ie_key() == 'SafariApi')
    assert(result.ie_name() == 'safari:api')
    assert(result.ie_desc() == 'safaribooksonline.com online courses')

# Generated at 2022-06-24 13:07:18.299377
# Unit test for constructor of class SafariIE
def test_SafariIE():
    inst = SafariIE('https://www.safaribooksonline.com/api/v1/book/')

# Generated at 2022-06-24 13:07:18.946328
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE

# Generated at 2022-06-24 13:07:22.580527
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_ie._API_FORMAT == 'json'

# Generated at 2022-06-24 13:07:30.399684
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_url = 'https://www.safaribooksonline.com/videos/python-programming-language/9780134217314'
    safari_ie = SafariBaseIE(SafariIE._downloader)
    safari_ie._real_initialize()
    assert safari_ie.LOGGED_IN

    safari_ie = SafariBaseIE(SafariIE._downloader)
    safari_ie.to_screen = lambda *args, **kwargs: None
    safari_ie._real_initialize()
    assert not safari_ie.LOGGED_IN

    safari_ie = SafariBaseIE(SafariIE._downloader)
    safari_ie._login()
    assert safari_ie.LOGGED_IN

    # Test to ensure that SafariBaseIE._login returns without

# Generated at 2022-06-24 13:07:31.048331
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-24 13:07:33.597506
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test that SafariBaseIE can be constructed
    try:
        SafariBaseIE()
    except:
        assert False, 'Constructor of SafariBaseIE raised an exception'

# Generated at 2022-06-24 13:07:35.001940
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from safari import SafariIE
    safari = SafariIE()
    assert safari



# Generated at 2022-06-24 13:07:39.593491
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    public_api = SafariBaseIE()
    valid_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    # constructor should not be called for this url
    if valid_url:
        public_api._real_initialize()

# Generated at 2022-06-24 13:07:40.157478
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    pass

# Generated at 2022-06-24 13:07:41.108066
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    base = SafariBaseIE()
    assert base.LOGGED_IN == False

# Generated at 2022-06-24 13:07:42.121347
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    module = type('test', (object,), {'__doc__': 'foo'})()
    SafariBaseIE(module)

# Generated at 2022-06-24 13:07:44.374887
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
        safari_base_ie = SafariBaseIE()
        instance_attrs = ["_downloader", "IE_NAME", "IE_DESC"]
        assert all(hasattr(safari_base_ie, attr) for attr in instance_attrs)

# Generated at 2022-06-24 13:07:50.246749
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE('http://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert safari_ie.LOGGED_IN == False

test_SafariIE()

# Generated at 2022-06-24 13:07:52.132370
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # This should not raise an `AttributeError`
    assert SafariCourseIE()._VALID_URL

# Generated at 2022-06-24 13:07:55.289697
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    inst = SafariApiIE('SafariApiIE', 'safaribooksonline.com online video')
    assert inst.name == 'safari:api'

# Generated at 2022-06-24 13:08:03.253132
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course_id = '9780133392838'
    course_title = 'Hadoop Fundamentals LiveLessons'
    course_url = 'https://www.safaribooksonline.com/library/view/' + \
                 course_id + '/'
    course_ie = SafariCourseIE()
    course_ie.suitable(course_url)
    course_ie.extract(course_url)
    assert(course_ie._match_id(course_url) == course_id)
    assert(course_ie.IE_NAME == 'safari:course')
    assert(course_ie.IE_DESC == 'safaribooksonline.com online courses')