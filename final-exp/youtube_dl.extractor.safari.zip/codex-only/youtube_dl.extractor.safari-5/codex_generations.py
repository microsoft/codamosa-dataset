

# Generated at 2022-06-24 12:57:59.597690
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    """
    Basic test to check that SafariBaseIE constructor is working
    """
    safari_base_ie = SafariBaseIE()

# Generated at 2022-06-24 12:58:07.413334
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    test_url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    expected_video_id = '9781449396459-part00'
    expected_partner_id = '1926081'
    expected_uiconf_id = '29375172'
    expected_query_parms = {
        'wid': '_%s' % expected_partner_id,
        'uiconf_id': expected_uiconf_id,
        'flashvars[referenceId]': expected_video_id,
    }


# Generated at 2022-06-24 12:58:14.897141
# Unit test for constructor of class SafariIE
def test_SafariIE():
    'Test the constructor of SafariIE'
    oa_user = 'safari_test'
    oa_pass = 'safari_test'
    """
    safari = SafariIE()
    safari.username = oa_user
    safari.password = oa_pass
    safari._login()
    """
    safari2 = SafariIE(username=oa_user, password=oa_pass)
    assert safari2.LOGGED_IN

# Generated at 2022-06-24 12:58:16.308200
# Unit test for constructor of class SafariIE
def test_SafariIE():
    tmp = SafariIE()
    assert tmp.ie_key() == 'Safari'

# Generated at 2022-06-24 12:58:20.402627
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    assert len(re.findall(SafariCourseIE._VALID_URL, url)) > 0

# Generated at 2022-06-24 12:58:26.942400
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from unittest import TestCase
    from .test_download_json import MockHttpRequest

    class TestSafariBaseIE(TestCase):
        SUCCESS_CASES = (
            TestCase(user='none', pass_=None, logged_in=False),
            TestCase(user='test_user', pass_='test_pass', logged_in=True),
        )

        def test_login(self):
            for i in range(len(self.SUCCESS_CASES)):
                case = self.SUCCESS_CASES[i]
                with self.subTest(i=i):
                    safari_base = SafariBaseIE(MockHttpRequest())
                    safari_base._login()


# Generated at 2022-06-24 12:58:27.368233
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-24 12:58:32.686472
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class TestSafariBaseIE(SafariBaseIE):
        _VALID_URL = r'test_url'
    test_url = 'test_url'
    ie_instance = TestSafariBaseIE(ie=None, downloader=None, ie_key=None)
    ie_instance._real_initialize()
    # No error raised, the test is passed

# Generated at 2022-06-24 12:58:35.304253
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """
    Simple test to ensure that SafariApiIE() function is working properly.
    """
    assert SafariApiIE().ie_key() == 'Safari:api'

# Generated at 2022-06-24 12:58:44.707639
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    import os
    book_id = '9781449396459'
    book_title = 'Ansible for DevOps'
    # test constructor with real data
    safari_course = SafariCourseIE()
    course_json = safari_course._download_json(
            'https://learning.oreilly.com/api/v1/book/{}/?override_format=json'.format(book_id),
            book_id, 'Downloading course JSON')
    assert course_json['id'] == book_id
    assert course_json['title'] == book_title
    # test constructor with simulated data

# Generated at 2022-06-24 12:58:52.899425
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    o = SafariBaseIE()
    assert o.IE_NAME == 'safari'
    assert o.IE_DESC == 'safaribooksonline.com online video'
    assert o._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''

# Generated at 2022-06-24 12:58:54.484777
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # test for __init__ method of class SafariApiIE
    SafariApiIE()

# Generated at 2022-06-24 12:59:02.557953
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import unittest
    import sys
    sys.modules['safari'] = sys.modules['__main__']

    class ExtractorTestCase(unittest.TestCase):
        def test_safari_api_ie(self):
            from .safari import SafariApiIE
            SafariApiIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')

    unittest.main()

# Generated at 2022-06-24 12:59:06.444339
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """Unit test for constructor of class SafariApiIE"""
    from .test_safari import test_SafariApiIE_constructor
    test_SafariApiIE_constructor()

if __name__ == '__main__':
    test_SafariApiIE()

# Generated at 2022-06-24 12:59:15.099215
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE('http://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html')
    assert ie._VALID_URL == 'https?://(?:www\\.)?(?:safaribooksonline|(?:learning\\.)?oreilly)\\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\\.html'


# Generated at 2022-06-24 12:59:26.168371
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """ Not a real test : just check if extracting some videos doesn't crash """

# Generated at 2022-06-24 12:59:27.756407
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safariIE = SafariIE()

# Generated at 2022-06-24 12:59:30.800969
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari = SafariBaseIE()

    assert 'safaribooksonline' in safari.IE_DESC
    assert 'safaribooksonline' in safari._VALID_URL

# Generated at 2022-06-24 12:59:32.668557
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class testerIE(SafariBaseIE):
        pass
    a = testerIE()

# Generated at 2022-06-24 12:59:36.383972
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE._build_url_result(
        'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html',
        'SafariIE')

# Generated at 2022-06-24 12:59:37.012684
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()

# Generated at 2022-06-24 12:59:39.100543
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safaribase = SafariBaseIE()
    assert safaribase.get_login_info() == (None, None, None)


# Generated at 2022-06-24 12:59:40.066371
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert SafariApiIE()

# Generated at 2022-06-24 12:59:44.138835
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    assert ie._NETRC_MACHINE == 'safari'
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'
    assert ie.LOGGED_IN == False

# Generated at 2022-06-24 12:59:50.026791
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    course_id = '9781449396459'
    course_title = 'JavaScript for Web Designers'


# Generated at 2022-06-24 13:00:02.980531
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # test Safari course extractor
    safari_course = SafariCourseIE()
    SafCourseIE = SafariCourseIE.suitable('http://techbus.safaribooksonline.com/9780134426365')
    # this course url should be OK
    assert SafCourseIE == True
    # test _real_extract method
    SafCourseRE = safari_course._real_extract('http://techbus.safaribooksonline.com/9780134426365')
    # this is for check playlist_result method with expected value
    # this is for check result of playlist_result method
    assert SafCourseRE.get('_type', None) == 'playlist'
    # this is for check course_id with expected value
    assert SafCourseRE.get('id', None) == '9780134426365'
    # this is

# Generated at 2022-06-24 13:00:04.776490
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE('test_username', 'test_password')


# Generated at 2022-06-24 13:00:07.035273
# Unit test for constructor of class SafariIE
def test_SafariIE():  # pylint: disable=redefined-outer-name
    safari = SafariIE()
    safari._login()

# Generated at 2022-06-24 13:00:13.596801
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+|
                                api/v1/book|
                                videos/[^/]+
                            )|
                            techbus\.safaribooksonline\.com
                        )
                        /(?P<id>[^/]+)
                    '''

# Generated at 2022-06-24 13:00:17.231779
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE({})
    assert not safari_api_ie.LOGGED_IN
    safari_api_ie._login()
    assert safari_api_ie.LOGGED_IN

# Generated at 2022-06-24 13:00:29.380569
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    import requests
    import pycurl

    class MockCurlMulti(object):
        def __init__(self, sorted_urls):
            self.curls = [MockCurl(url) for url in sorted_urls]

        def add_handle(self, curl):
            self.curls.append(curl)

        def remove_handle(self, curl):
            self.curls.remove(curl)

        def select(self):
            return None

        def perform(self):
            for curl in self.curls:
                curl.perform()

        def close(self):
            return None

    class MockCurl(object):
        def __init__(self, url):
            self.url = url

# Generated at 2022-06-24 13:00:33.221386
# Unit test for constructor of class SafariIE
def test_SafariIE():
    '''
    Constructor test
    '''
    obj = SafariIE('safari', 'safaribooksonline.com online video')
    assert obj.ie_key() == 'Safari'


# Generated at 2022-06-24 13:00:34.273279
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE('SafariBaseIE')

# Generated at 2022-06-24 13:00:39.382471
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    obj = SafariCourseIE()
    assert obj.suitable(None) is False
    assert obj.suitable('http://techbus.safaribooksonline.com/9780134426365') is True
    assert obj.suitable('http://techbus.safaribooksonline.com/9780134426365/9780134426365-CC02_HTML_Color') is False


# Generated at 2022-06-24 13:00:50.209362
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from .common import FakeLoginIE
    # FakeLoginIE, a subclass of SafariBaseIE, is used to test initialization
    # of SafariBaseIE, because SafariBaseIE is an abstract class.
    inst = FakeLoginIE('test')
    assert inst.LOGGED_IN == False
    assert inst._login_required == True
    assert inst._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert inst._NETRC_MACHINE == 'safari'
    assert inst._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert inst._API_FORMAT == 'json'
    assert inst._login() == None

# Generated at 2022-06-24 13:00:51.362923
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE("safari", True, None)

# Generated at 2022-06-24 13:00:52.895870
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    a = SafariBaseIE()
    a._real_initialize()
    return True

# Generated at 2022-06-24 13:00:54.627502
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """
    Test constructor for SafariApiIE class
    """
    assert SafariApiIE(SafariBaseIE)
    assert SafariApiIE(SafariBaseIE)._VALID_URL == SafariApiIE._VALID_URL

# Generated at 2022-06-24 13:00:59.258132
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test without parameter
    a = SafariIE()
    assert (isinstance(a, SafariIE))

    # Test with parameter
    b = SafariIE('class')
    assert (isinstance(b, SafariIE)), "AssertionError"


# Generated at 2022-06-24 13:01:02.937711
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # If you do not enter parameters, SafarCourseIE give an error
    try:
        SafariCourseIE()
    except TypeError as e:
        print('The following error happened: {}'.format(e))

# Generated at 2022-06-24 13:01:06.584229
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # It's just a simple test to check if SafariBaseIE's constructor '__init__'
    # is complete.
    SafariBaseIE('SafariBaseIE')

# Generated at 2022-06-24 13:01:14.255491
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safariBaseIE = SafariBaseIE()
    safariCourseIE = SafariCourseIE()
    assert safariBaseIE.IE_NAME == 'safari'
    assert safariBaseIE.IE_DESC == 'safaribooksonline.com online video'
    assert safariCourseIE.IE_NAME == 'safari:course'
    assert safariCourseIE.IE_DESC == 'safaribooksonline.com online courses'
    assert safariCourseIE.LOGGED_IN == False

# Generated at 2022-06-24 13:01:16.170023
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()
    assert(safari.IE_NAME == 'safari')

# Generated at 2022-06-24 13:01:26.817678
# Unit test for constructor of class SafariIE
def test_SafariIE():
    try:
        from urlparse import urlparse
    except:
        from urllib.parse import urlparse

    # Test for case when login and password is not provided.
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False
    assert safari_ie._NETRC_MACHINE == 'safari'
    assert safari_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'

    # Test for case when login and password is provided.
    safari_ie = SafariIE('Login', 'Password')
    assert safari_ie.LOGGED_IN == True
    assert safari_ie._NETRC_MACHINE == 'safari'

# Generated at 2022-06-24 13:01:36.647836
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    try:
        assert re.match(SafariCourseIE._VALID_URL, 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    except AssertionError as e:
        print("Failed pattern matching test: %s" % str(e))
    try:
        assert re.match(SafariCourseIE._VALID_URL, 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    except AssertionError as e:
        print("Failed pattern matching test: %s" % str(e))

# Generated at 2022-06-24 13:01:41.340874
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_ie = SafariCourseIE()
    assert safari_course_ie.name == 'safari:course'
    assert safari_course_ie.ie_key() == 'SafariCourse'

# Generated at 2022-06-24 13:01:45.717274
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ins = SafariCourseIE()
    # You can test your result here
    ins._real_extract('https://www.safaribooksonline.com/library/view/data-wrangling-with-r/9781449317082/')

# Generated at 2022-06-24 13:01:54.377718
# Unit test for constructor of class SafariIE

# Generated at 2022-06-24 13:02:02.675396
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test with 0 parameters
    obj = SafariBaseIE()
    assert obj._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert obj._NETRC_MACHINE == 'safari'

    # Test with all parameters specified
    obj2 = SafariBaseIE(login_url='http://example.com/')
    assert obj2._LOGIN_URL == 'http://example.com/'
    assert obj2._NETRC_MACHINE == 'safari'

# Generated at 2022-06-24 13:02:07.285045
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()
    # safari_api_ie.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    safari_api_ie._download_webpage('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json', None, None)


# Generated at 2022-06-24 13:02:11.823200
# Unit test for constructor of class SafariIE
def test_SafariIE():
    return '0_qbqx90ic', {
        'id': '0_qbqx90ic',
        'ext': 'mp4',
        'title': 'Introduction to Hadoop Fundamentals LiveLessons',
        'duration': 613,
        'timestamp': 1437758058,
        'upload_date': '20150724',
        'creator': "d'Arcy J.M. Cain, et al.",
        'uploader_id': 'stork',
    }


# Generated at 2022-06-24 13:02:22.867104
# Unit test for constructor of class SafariBaseIE

# Generated at 2022-06-24 13:02:25.091902
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    obj = SafariCourseIE()
    if obj == None:
        raise Exception('Constructor test failed')

# Generated at 2022-06-24 13:02:38.903757
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    test_url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter-content/sec_unit_testing_intro_test.html'
    test_part = 'sec_unit_testing_intro_test.html'
    test_course = '9781449396459'
    
    test_real_extract_mock_download_json = SafariApiIE._download_json
    test_real_extract_mock_download_json.return_value = {
        'web_url': test_url
    }

    test_real_extract_mock_url_result = SafariApiIE.url_result
    test_real_extract_mock_url_result.return_value = None

    t_SafariApiIE = Safari

# Generated at 2022-06-24 13:02:41.509073
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    username, password = SafariBaseIE._get_login_info()
    if username is not None and password is not None:
        assert type(username) == type(password) == compat_str

# Generated at 2022-06-24 13:02:43.946013
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from . import  SafariIE

    assert SafariIE.__name__ == "SafariIE"
    

# Generated at 2022-06-24 13:02:52.194517
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import unittest

    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'


# Generated at 2022-06-24 13:02:53.509903
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert(not SafariApiIE(123).LOGGED_IN)



# Generated at 2022-06-24 13:02:54.598295
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()
    SafariBaseIE

# Generated at 2022-06-24 13:02:58.214759
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safariie=SafariIE()
    safariie._initialize()

# Generated at 2022-06-24 13:03:09.527669
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from ..test_utils import FakeExtractor

    safari = SafariCourseIE()
    assert safari.name == 'safari:course'
    assert safari.description is None
    assert safari.ie_key() == 'Safari:course'

    # Unit test for method suitable
    # True case
    assert safari.suitable('http://techbus.safaribooksonline.com/9780134426365')

    # False case
    assert not safari.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert not safari.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')

   

# Generated at 2022-06-24 13:03:10.068013
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-24 13:03:15.196947
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # I was just curious (re: Python's new class syntax)
    assert (
        type(SafariCourseIE(None)).__name__ == 'SafariCourseIE' and
        type(SafariCourseIE).__name__ == 'type'
    )

# Generated at 2022-06-24 13:03:15.868189
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE('safari:course')

# Generated at 2022-06-24 13:03:27.197974
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()

    # Testing cookie implementation
    with open("test.html", "r") as f:
        html_content = f.read()


# Generated at 2022-06-24 13:03:28.117773
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    return not SafariApiIE()._login()

# Generated at 2022-06-24 13:03:39.531738
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()
    assert safari.IE_NAME == 'safari'
    assert safari.IE_DESC == 'safaribooksonline.com online video'
    assert safari._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''
    assert safari._PARTNER_ID == '1926081'


# Generated at 2022-06-24 13:03:40.878789
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE('safari')

# Generated at 2022-06-24 13:03:41.936888
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    assert(ie)

# Generated at 2022-06-24 13:03:46.254713
# Unit test for constructor of class SafariIE
def test_SafariIE():
    inst = SafariIE()
    assert inst._VALID_URL == SafariIE._VALID_URL
    assert inst._NETRC_MACHINE == SafariIE._NETRC_MACHINE
    assert inst.LOGGED_IN == SafariIE.LOGGED_IN

# Generated at 2022-06-24 13:03:49.845717
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    class_name = 'SafariApiIE'
    parameter = 'self'
    safari_api_ie = globals()[class_name](parameter)
    assert safari_api_ie.IE_NAME == 'safari:api'


# Generated at 2022-06-24 13:03:58.735958
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    import os
    import unittest

    class SafariCourseIETest(unittest.TestCase):
        @classmethod
        def setUpClass(cls):
            cls.ie = SafariCourseIE({})
            cls.safari_course_ie = cls.ie._JSON_LD(
                os.path.join(
                    os.path.dirname(__file__),
                    '__files__',
                    'safari_course_ie.json'
                )
            )


# Generated at 2022-06-24 13:04:09.097382
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Tests for SafariApiIE in its constructor.
    instance = SafariApiIE()

    # Unit test for _real_extract function of class SafariApiIE, with course
    # that exists.
    def test_SafariApiIE_real_extract():
        url = 'https://www.safaribooksonline.com/api/v1/book/9781338099133/chapter/01-00.html'
        course_id = '9781338099133'
        part = '01-00.html'
        webpage = self._download_webpage(url, video_id=part)
        self.assertIn('course_id', webpage)
        self.assertIn('part', webpage)
        self.assertIn('webpage', webpage)

    # Unit test for _real_extract function of class SafariA

# Generated at 2022-06-24 13:04:15.061955
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    constr = SafariApiIE._build_constructor()
    assert constr('https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html') == {
        'web_url': 'https://www.safaribooksonline.com/library/view/programming-concurrency-on/9781449396459/part00.html',
        'type': 'chapter',
        'title': 'Programming Concurrency on the JVM',
        'number': '00',
        'identifier': '9781449396459-00'
    }

# Generated at 2022-06-24 13:04:19.214304
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    i = SafariBaseIE('safari')
    i._download_webpage = lambda url: url
    url = i._real_initialize()
    assert url in ('https://learning.oreilly.com/accounts/login/', None)

# Generated at 2022-06-24 13:04:24.194155
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Download the page using SafariIE.
    page = SafariIE()._real_extract('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert page

# Generated at 2022-06-24 13:04:27.503550
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter-content/part01.html')

# Generated at 2022-06-24 13:04:38.873871
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    ie._get_login_info = lambda: [None, None]
    ie._download_json = lambda *args, **kwargs: {'session': 'dummy'}
    ie._apply_first_set_cookie_header = lambda *args, **kwargs: None
    ie._download_webpage_handle = lambda *args, **kwargs: ('webpage', 'urlh')
    ie._download_json_handle = lambda *args, **kwargs: (
        {'logged_in': False, 'redirect_uri': 'http://dummy.url'}, 'urlh')

    # _real_initialize calls _login which has been mocked
    ie._login = lambda : None
    ie._real_initialize()

    assert ie.LOGGED_IN == False

# Generated at 2022-06-24 13:04:50.433500
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()
    assert safari._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''
    assert safari._PARTNER_ID == '1926081'
    assert safari._UICONF_ID == '29375172'



# Generated at 2022-06-24 13:04:56.390136
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_ie = SafariCourseIE()
    assert safari_course_ie.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert safari_course_ie.suitable('http://techbus.safaribooksonline.com/9780134426365')

# Generated at 2022-06-24 13:05:06.246343
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    assert ie.ie_key() == 'SafariCourse'
    assert ie.name() == 'safaribooksonline.com online courses'
    assert ie.description() == 'safaribooksonline.com online courses'
    assert ie.suitable(SafariCourseIE._VALID_URL) == 1
    assert SafariCourseIE.suitable(SafariCourseIE._VALID_URL) == 1
    assert ie.can_extract('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/') == 'SafariCourse'

# Generated at 2022-06-24 13:05:11.121455
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert ie._NETRC_MACHINE == 'safari'
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'


# Generated at 2022-06-24 13:05:12.929350
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    s = SafariCourseIE()
    assert s.IE_NAME == 'safari:course'

# Generated at 2022-06-24 13:05:20.065557
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from . import _test_credentials
    from . import _test_credentials_safari
    ie = SafariIE('aa', 'bb', _test_credentials, _test_credentials_safari)
    assert ie._username == _test_credentials_safari[0]
    assert ie._password == _test_credentials_safari[1]
    assert ie._META_BASE == 'https://techbus.safaribooksonline.com/'

# Generated at 2022-06-24 13:05:20.833934
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()

# Generated at 2022-06-24 13:05:31.175622
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from unit import compat_urllib_request as urllib_request
    from unit import compat_urllib_error as urllib_error
    from unit import compat_http_cookiejar as http_cookiejar
    from unit import compat_http_cookiejar_as_lwp_cookiejar as lwp_cookiejar

    cookiejar = http_cookiejar.CookieJar()
    opener = urllib_request.build_opener(urllib_request.HTTPCookieProcessor(cookiejar))
    opener.addheaders = [('User-agent', 'Mozilla/5.0 (X11; Linux x86_64; rv:58.0) Gecko/20100101 Firefox/58.0')]

    url = 'https://learning.oreilly.com/accounts/login/'

# Generated at 2022-06-24 13:05:44.205993
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    ie.urls = ['http://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838/9780133392838-00_SeriesIntro']
    assert ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert ie._NETRC_MACHINE == 'safari'
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'
    #assert len(ie._TESTS) == 5

# Generated at 2022-06-24 13:05:45.245180
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE(SafariBaseIE)

# Generated at 2022-06-24 13:05:47.797443
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    i = SafariApiIE()
    assert i._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert i._API_FORMAT == 'json'

# Generated at 2022-06-24 13:05:51.742237
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    assert SafariCourseIE.suitable(url)

# Generated at 2022-06-24 13:05:53.390549
# Unit test for constructor of class SafariIE
def test_SafariIE():
    obj = SafariIE()
    assert isinstance(obj, SafariBaseIE)

# Generated at 2022-06-24 13:05:56.762025
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import inspect
    import sys
    # Test constructor
    x = SafariCourseIE()
    assert hasattr(x, '_download_json')

# Generated at 2022-06-24 13:05:57.685537
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test that SafariIE constructor doesn't crash
    safari_ie = SafariIE()

# Generated at 2022-06-24 13:05:59.362238
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    s = SafariApiIE()
    assert s


# Generated at 2022-06-24 13:06:03.660413
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Constructor of class SafariBaseIE should throw ExtractorError if
    # account credentials are missing
    ie = SafariBaseIE()
    ie.login = False
    ie.username = None
    ie.password = None
    with pytest.raises(ExtractorError):
        ie._login()

# Generated at 2022-06-24 13:06:05.154233
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    extractor = SafariBaseIE()
    extractor._real_initialize()



# Generated at 2022-06-24 13:06:05.708123
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    pass

# Generated at 2022-06-24 13:06:17.355925
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # These methods and properties of SafariApiIE are called or
    # accessed by other methods and properties:
    # *_VALID_URL
    # *_download_json
    # *url_result
    #   SafariIE.ie_key
    # The following will test those methods and properties,
    # please add more if necessary.
    # Note: Currently SafariApiIE does not have unit tests for its
    # constructor.
    ie = SafariApiIE(SafariCourseIE.ie_key())
    course_id = '9780133392838'
    url = 'https://www.safaribooksonline.com/api/v1/book/' + course_id + '/chapter/part00.html'
    expected_title = '%s-part00' % course_id
    result = ie._real_ext

# Generated at 2022-06-24 13:06:28.859298
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert 'SafariCourseIE' in globals()
    course_ie = SafariCourseIE('SafariCourseIE')
    assert course_ie.IE_NAME == 'safari:course'
    assert course_ie.IE_DESC == 'safaribooksonline.com online courses'

# Generated at 2022-06-24 13:06:37.341017
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from utils import parse_sig_js_funcs
    safariCourseIE = SafariCourseIE()
    # test constructors and starting of extracting
    # The following is a unit test to see if the class is working correctly.
    test_course = "https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/"
    test_course_id = "9780133392838"
    test_course_title = "Hadoop Fundamentals LiveLessons"
    test_if_login()
    test_if_download_json()
    test_if_suitable()
    test_if_real_extract()
    test_if_url_result()
    test_if_playlist_result()
    # Above is a unit test to

# Generated at 2022-06-24 13:06:41.221684
# Unit test for constructor of class SafariIE
def test_SafariIE():
    uic = SafariIE()
    assert uic.UICONF_ID == '29375172'

    uic = SafariIE(UICONF_ID='1337')
    assert uic.UICONF_ID == '1337'

# Generated at 2022-06-24 13:06:42.668276
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.IE_NAME == 'safari'

# Generated at 2022-06-24 13:06:43.700692
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    i = SafariApiIE()

# Generated at 2022-06-24 13:06:51.869866
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .test_downloader import get_testcases
    from .common import story_id_from_url
    for testcase in get_testcases('safari').values():
        url = testcase['url']
        mobj = re.match(SafariCourseIE._VALID_URL, url)
        if not mobj:
            continue
        course_id = mobj.group('id')
        if not course_id or story_id_from_url(url):
            continue
        if not SafariCourseIE._is_valid_url(url, course_id):
            continue
        assert SafariCourseIE.suitable(url)
        ie = SafariCourseIE(url)
        assert ie.IE_NAME == 'safari:course'

# Generated at 2022-06-24 13:06:56.224911
# Unit test for constructor of class SafariIE
def test_SafariIE():
    url='https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    safari_ie = SafariIE()
    url_res = safari_ie.url_result(url,'Kaltura')
    ent_res = safari_ie._real_extract(url)
    assert url_res == ent_res

# Generated at 2022-06-24 13:07:02.276863
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Tests whether the downloader can download a video with 'query'
    # in its URL
    # Expectation: No error is raised
    course_id = "9780133392838"
    part = "part00"
    url = "https://www.safaribooksonline.com/api/v1/book/%s/chapter/%s.html" % (course_id,part)
    test_obj = SafariApiIE()
    test_obj.extract(url)

# Generated at 2022-06-24 13:07:14.144334
# Unit test for constructor of class SafariCourseIE

# Generated at 2022-06-24 13:07:20.456733
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test for __init__() of SafariApiIE
    course_id = "9780134426365"
    SafariApiIE.suitable(course_id)
    # Test for result() of SafariApiIE
    url = "http://techbus.safaribooksonline.com/"+course_id
    SafariApiIE._real_extract(SafariApiIE(), url)
    print('Test for SafariApiIE tested')
    return

# Generated at 2022-06-24 13:07:29.146496
# Unit test for constructor of class SafariIE
def test_SafariIE():
    web_page = '<html><head></head><body><div data-reference-id="9780133392838-part00"></div></body></html>'

    # Constructor of SafariIE class takes in parameter ie, name and ie_key
    # ie is an instance of IE_NAME
    # name is a string that represents type of info extractor
    # ie_key is used for storing info extractor object in dictionary
    safari_ie = SafariIE(SafariIE, 'Safari', 'Safari')

    # Test _search_regex function
    mobj = safari_ie._search_regex(safari_ie._VALID_URL, web_page, 'reference id', 'reference_id')
    assert mobj.group('course_id') == "9780133392838"

    # Test _real

# Generated at 2022-06-24 13:07:32.432255
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.IE_NAME == 'safari'
    assert ie.IE_DESC == 'safaribooksonline.com online video'
    assert ie._VALID_URL == r'''(?x)https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?#&]+)\.html'''


# Generated at 2022-06-24 13:07:33.184491
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    assert ie is not None

# Generated at 2022-06-24 13:07:38.071065
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from .. import YoutubeIE, DailymotionIE

    YoutubeIE = YoutubeIE()
    DailymotionIE = DailymotionIE()
    base_IE = SafariBaseIE(
        YoutubeIE, DailymotionIE,
        'Copy constructor fail')
    assert(base_IE.IE_NAME == 'safari')
    assert('Youtube' in base_IE.ie_key())
    assert('Dailymotion' in base_IE.ie_key())

# Generated at 2022-06-24 13:07:45.863151
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/') == True
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json') == False
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json') == False
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json') == False

# Generated at 2022-06-24 13:07:58.332110
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/videos/python-programming-language/9780134217314'
    SafariCourseIE()._real_initialize()
    info_dict = SafariCourseIE()._real_extract(url)
    print(info_dict.keys())
    print(info_dict['id'])
    print(info_dict['title'])
    print(info_dict['description'])
    print(info_dict['thumbnail'])
    print(info_dict['uploader'])
    print(info_dict['upload_date'])
    print(info_dict['timestamp'])
    print(info_dict['uploader_id'])
    print(len(info_dict['entries']))
    print(info_dict['entries'])