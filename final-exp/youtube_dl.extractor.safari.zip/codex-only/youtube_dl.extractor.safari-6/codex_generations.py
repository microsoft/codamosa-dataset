

# Generated at 2022-06-24 12:58:07.182950
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .test_common import _TESTS, get_testcases
    from .generic import update_url_query

    # Lower the HTTP connection timeout from 20 seconds (test default) to 5 to speed up tests
    import socket
    for conn_class in (socket.create_connection, socket._socketobject):
        if hasattr(conn_class, '_GLOBAL_DEFAULT_TIMEOUT'):
            conn_class._GLOBAL_DEFAULT_TIMEOUT = 5

    # Avoid creating the InfoExtractor instances
    def new_saie_for_test(url):
        class TestSafariApiIE(SafariApiIE):
            def _real_extract(self, url):
                return url
        return TestSafariApiIE(url)


# Generated at 2022-06-24 12:58:13.029424
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Check that without declaring class variables, the constructor of SafariCourseIE
    # is not able to create the class
    instance = SafariCourseIE()
    assert '_VALID_URL' not in instance.__dict__.keys()
    assert '_TESTS' not in instance.__dict__.keys()
    assert 'suitable' not in instance.__dict__.keys()
    assert '_real_extract' not in instance.__dict__.keys()

# Generated at 2022-06-24 12:58:15.398241
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie._VALID_URL == SafariIE._VALID_URL

# Generated at 2022-06-24 12:58:23.140921
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    unittest.TestCase().assertEqual(SafariBaseIE._API_BASE, 'https://learning.oreilly.com/api/v1');
    unittest.TestCase().assertEqual(SafariBaseIE._API_FORMAT, 'json');
    unittest.TestCase().assertEqual(SafariBaseIE._LOGIN_URL, 'https://learning.oreilly.com/accounts/login/');
    unittest.TestCase().assertEqual(SafariBaseIE._NETRC_MACHINE, 'safari');
    pass;



# Generated at 2022-06-24 12:58:35.210952
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()

# Generated at 2022-06-24 12:58:36.512392
# Unit test for constructor of class SafariIE
def test_SafariIE():
    obj = SafariIE()
    assert obj.LOGGED_IN == False

# Generated at 2022-06-24 12:58:37.491561
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()

# Generated at 2022-06-24 12:58:38.866237
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert isinstance(SafariCourseIE(), SafariBaseIE)

# Generated at 2022-06-24 12:58:40.604741
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert ie.__class__.__name__ == 'SafariApiIE'

# Generated at 2022-06-24 12:58:42.229014
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    obj = SafariApiIE()
    assert obj.IE_NAME == 'safari:api'

# Generated at 2022-06-24 12:58:42.781699
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    pass

# Generated at 2022-06-24 12:58:47.723618
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    try:
        import netrc
        netrc.netrc().authenticators(SafariBaseIE._NETRC_MACHINE)
    except (ImportError, IOError, netrc.NetrcParseError):
        username = password = None
    else:
        username = password = 'login'
    safari_base_test = SafariBaseIE(
        username, password
    )
    return safari_base_test

# Generated at 2022-06-24 12:58:52.771107
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class TestSafariIE(SafariBaseIE):
        IE_NAME = 'test'
        _VALID_URL = 'http://example.com'

        def _real_extract(self, url):
            return self.url_result(url, 'test')

    args = ['--username', 'test', '--password', 'test', 'http://example.com']
    ie = TestSafariIE()
    if ie.suitable(args[-1]):
        assert ie.working()

# Generated at 2022-06-24 12:59:05.130243
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()


# Generated at 2022-06-24 12:59:09.670026
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    me = SafariApiIE('http://www.safaribooksonline.com/api/v1/book/9781449396459/chapter-content/lpp001.html')
    assert me.IE_NAME == 'safari:api'
    assert me.IE_DESC == 'safaribooksonline.com online courses'

# Generated at 2022-06-24 12:59:15.361964
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    if ie.LOGGED_IN:
        raise ValueError('SafariIE should not be logged in by default')

    ie.LOGGED_IN = True
    if not ie.LOGGED_IN:
        raise ValueError('SafariIE should be logged in')

# Generated at 2022-06-24 12:59:17.766275
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    try:
        ie = SafariApiIE()
    except:
        assert False, "Unable to create SafariApiIE with method SafariApiIE"

# Generated at 2022-06-24 12:59:18.533375
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()

# Generated at 2022-06-24 12:59:24.550960
# Unit test for constructor of class SafariIE
def test_SafariIE():
    if True:
        # we may want to test the constructor of SafariIE,
        # but we need to pass the classmethod 'suitable' to do that,
        # which is not possible with the unittest module
        # -> print a warning instead of failing the test
        from sys import stderr
        stderr.write("Warning: test for constructor of class SafariIE not run.\n")


# Generated at 2022-06-24 12:59:28.796530
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """Test SafariIE constructor and its properties."""
    safari_instance = SafariIE()
    assert isinstance(safari_instance.username, compat_str)
    assert isinstance(safari_instance.password, compat_str)

# Generated at 2022-06-24 12:59:34.728745
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    import os

    fname = os.path.join(os.path.dirname(__file__), 'test', 'safaribooksonline.json')
    f = open(fname, 'r')
    data = f.read()
    course_json = json.JSONDecoder().decode(data)
    f.close()

    course_id = course_json['id']

    s = SafariCourseIE()

    if 'chapters' not in course_json:
        raise ExtractorError(
                'No chapters found for course %s' % course_id, expected=True)

    for chapter in course_json['chapters']:
        result = s.url_result(chapter, SafariApiIE.ie_key())
        assert 'entries' not in result
        assert result['id'] == chapter

# Generated at 2022-06-24 12:59:36.020113
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE(): # unit test for SafariCourseIE
    dl = SafariCourseIE()
    from .safari import SafariCourseIE
    dl = SafariCourseIE()

# Generated at 2022-06-24 12:59:41.633409
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781785887653/chapter/part00.html'
    safari_api = SafariApiIE(
        compat_urllib_request.Request(url),
        compat_urllib_request.urlopen(url))
    safari_api._real_initialize()
    safari_api._real_extract(url)

# Generated at 2022-06-24 12:59:44.990049
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from .test_utils import get_testcases
    from ..utils import unescapeHTML

    testcases = get_testcases()
    for testcase in testcases:
        ie = SafariBaseIE()
        ie.login()


# vim:sw=4:ts=4:et:

# Generated at 2022-06-24 12:59:45.524766
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    x = SafariCourseIE()

# Generated at 2022-06-24 12:59:47.579321
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE(InfoExtractor())
    safari_base_ie._real_initialize()
    safari_base_ie._login()

# Generated at 2022-06-24 12:59:52.772313
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE("http://learning.oreilly.com/api/v1/book/9781449396459/?override_format=json")
    assert("https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json" == safari_api_ie._VALID_URL)

# Generated at 2022-06-24 12:59:54.450156
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safariIE = SafariIE("", "")
    assert safariIE.ie_key() == 'Safari'

# Generated at 2022-06-24 12:59:55.322864
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE(None)

# Generated at 2022-06-24 13:00:08.853805
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Example url used in test_real_extract of class SafariIE
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'

    # Constructor of class SafariIE
    safari = SafariIE(SafariIE.ie_key())

    # Test constructor
    assert safari.LOGGED_IN == False
    assert safari._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari._NETRC_MACHINE == 'safari'
    assert safari._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari._API_FORMAT == 'json'

    # Test method _real_initial

# Generated at 2022-06-24 13:00:14.517092
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE._download_json = lambda *a, **kw: {
        'web_url': 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html',
    }
    SafariApiIE._real_extract(SafariApiIE(), 'https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html')

# Generated at 2022-06-24 13:00:21.884373
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-24 13:00:24.174576
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE('safari')
    assert isinstance(ie, SafariBaseIE)
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 13:00:36.896457
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    test_cases = (
        ('safari-login-test-user', '5d5d5d5d5d5d5d5d5d5d5d5d5d5d5d5d', True),  # valid login
        ('safari-login-test-user', 'f' * 32, False),                             # invalid password
        ('safari-login-test-user', None, False),                                 # no password
        (None, None, False),                                                     # no login information
    )

    for user, password, should_login in test_cases:
        class test_login(SafariBaseIE):
            _NETRC_MACHINE = 'safari'

            def _real_initialize(self):
                self._login()

        test_obj = test_login()

# Generated at 2022-06-24 13:00:45.184678
# Unit test for constructor of class SafariIE
def test_SafariIE():
    obj = SafariIE('https://www.safaribooksonline.com/library/view/learning-path-red/9780134664057/RHCE_Introduction.html')
    assert obj._VALID_URL == 'https?://(?:www\\.)?(?:safaribooksonline|(?:learning\\.)?oreilly)\\.com/library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?#&]+)\\.html'
    assert obj._PARTNER_ID == '1926081'
    assert obj._UICONF_ID == '29375172'



# Generated at 2022-06-24 13:00:46.828683
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    try:
        SafariApiIE(None)
    except TypeError:
        # safari_api expects a downloader
        # It will fail if we construct SafariApiIE without a downloader
        pass

# Generated at 2022-06-24 13:00:59.762898
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    assert ie.IE_NAME == 'safari:course'
    assert ie.IE_DESC == 'safaribooksonline.com online courses'
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+|
                                api/v1/book|
                                videos/[^/]+
                            )|
                            techbus\.safaribooksonline\.com
                        )
                        /(?P<id>[^/]+)
                    '''

# Generated at 2022-06-24 13:01:02.513188
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    c = SafariCourseIE()._real_initialize()
    assert isinstance(c, SafariBaseIE)
    assert c.LOGGED_IN

# Generated at 2022-06-24 13:01:04.141478
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert(SafariCourseIE('SafariCourseIE'))

# Generated at 2022-06-24 13:01:04.901208
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()

# Generated at 2022-06-24 13:01:18.074140
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    course_id = '9780134664057'
    mobj = re.match(SafariApiIE._VALID_URL, 'https://www.safaribooksonline.com/api/v1/book/9780134664057/chapter/RHCE_Introduction.html')
    video_id = '%s-%s' % (mobj.group('course_id'), mobj.group('part'))
    course_title = 'Red Hat RHCSA/RHCE 7 Cert Guide'

# Generated at 2022-06-24 13:01:20.255734
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    context = {}
    safaricourseie = SafariCourseIE(context)
    assert safaricourseie is not None

# Generated at 2022-06-24 13:01:22.781483
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safaribaseie = SafariBaseIE()
    # ensure that login was not called
    assert safaribaseie.LOGGED_IN is False
    # check that login has been called
    safaribaseie._real_initialize()
    assert safaribaseie.LOGGED_IN is True

# Generated at 2022-06-24 13:01:26.481525
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import unittest
    class ConstructorTest(unittest.TestCase):
        def setUp(self):
            pass

        def test_constructor(self):
            expected = SafariBaseIE._VALID_URL
            actual = SafariApiIE._VALID_URL
            self.assertEqual(expected, actual)
    unittest.main(exit=False)


# Generated at 2022-06-24 13:01:27.708772
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE(SafariBaseIE._downloader, None)

# Generated at 2022-06-24 13:01:29.108829
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert isinstance(SafariApiIE("SafariApiIE"), SafariBaseIE)


# Generated at 2022-06-24 13:01:34.955198
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .common import global_id_map
    from .dispatch import wrapper
    for extractor_id, extractor_class in wrapper.extractors.items():
        if not extractor_class:
            continue
        if extractor_class.IE_NAME == 'safari':
            global_id_map[extractor_id] = extractor_class.ie_key()

# Generated at 2022-06-24 13:01:36.361171
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    obj = SafariApiIE()
    assert obj.IE_NAME == 'safari:api'

# Generated at 2022-06-24 13:01:41.070442
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    test_course_url = 'http://techbus.safaribooksonline.com/9780134426365'
    assert re.match(SafariCourseIE._VALID_URL, test_course_url)

# Generated at 2022-06-24 13:01:49.373098
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    user = SafariBaseIE._SafariBaseIE__login_user
    password = SafariBaseIE._SafariBaseIE__login_password

    SafariBaseIE._SafariBaseIE__login_user = ''
    SafariBaseIE._SafariBaseIE__login_password = ''
    ie = SafariBaseIE()
    assert ie.LOGGED_IN is False

    SafariBaseIE._SafariBaseIE__login_user = user
    SafariBaseIE._SafariBaseIE__login_password = password
    ie = SafariBaseIE()
    assert ie.LOGGED_IN is True

# Generated at 2022-06-24 13:01:50.856739
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    c = SafariCourseIE()

# Generated at 2022-06-24 13:01:59.685544
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    for ie_class in [SafariCourseIE, SafariApiIE, SafariIE]:
        ie = ie_class('SafariBaseIE', 'safaribooksonline')
        assert ie.IE_NAME == 'safaribooksonline'
        assert ie.IE_DESC == 'safaribooksonline.com online video'
        assert ie._API_FORMAT == 'json'
        assert ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
        assert ie._NETRC_MACHINE == 'safari'

# Generated at 2022-06-24 13:02:04.142566
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # test SafariBaseIE constructor
    try:
        safari = SafariBaseIE('SafariBase')
        assert safari.IE_NAME == 'SafariBase'
        assert safari._NETRC_MACHINE == 'safari'
    except AssertionError:
        print('test_SafariBaseIE failed')

# Generated at 2022-06-24 13:02:05.477857
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .test_common import TestSafariCourseIE
    TestSafariCourseIE('safari:course').test()

# Generated at 2022-06-24 13:02:08.579859
# Unit test for constructor of class SafariIE
def test_SafariIE():
    url = 'https://learning.oreilly.com/videos/office-365-and/9780133961778/9780133961778-O365V_01_01'
    safariIE = SafariIE(url)
    assert safariIE.LOGGED_IN == False

# Generated at 2022-06-24 13:02:09.066078
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()

# Generated at 2022-06-24 13:02:09.833285
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE('Kaltura')

# Generated at 2022-06-24 13:02:15.214431
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE('https://www.safaribooksonline.com/api/v1/book/9781449396459/')
    assert ie.name == 'safari:course'
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+|
                                api/v1/book|
                                videos/[^/]+
                            )|
                            techbus\.safaribooksonline\.com
                        )
                        /(?P<id>[^/]+)
                    '''
    
    # Test _real_extract

# Generated at 2022-06-24 13:02:23.747079
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """
    Adapted from test_SafariCourseIE in test_SafariIE
    """
    expected = '<SafariApiIE:(?P<url>https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html)>'
    assert SafariApiIE._VALID_URL == expected

# Generated at 2022-06-24 13:02:35.424720
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    t = SafariBaseIE()
    assert t._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert t._API_FORMAT == 'json'
    assert t.LOGGED_IN == False


# Integration test for constructor of class SafariApiIE with valid account credentials.
# Note, it can be run only with real account credentials.
#def test_SafariApiIE_integration():
#    # login with valid account credentials and check that LOGGED_IN is True.
#    t = SafariApiIE()
#    t._login()
#    assert t.LOGGED_IN == True

# Generated at 2022-06-24 13:02:40.172020
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # test constructor
    safari_course_ie = SafariCourseIE()
    # test suitable method
    assert safari_course_ie.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert not safari_course_ie.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert not safari_course_ie.suitable('http://techbus.safaribooksonline.com/9780134426365')
    assert not safari_course_ie.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314')

# Generated at 2022-06-24 13:02:45.268048
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    ies = list(SafariApiIE._extract_matches(url))
    assert len(ies) == 1
    assert type(ies[0]) == SafariApiIE

# Generated at 2022-06-24 13:02:48.866851
# Unit test for constructor of class SafariIE
def test_SafariIE():
    try:
        s = SafariIE()
        assert(s.IE_NAME == 'safari')
        assert(s.IE_DESC == 'safaribooksonline.com online video')
    except:
        print("Test failed")
        return False
    return True


# Generated at 2022-06-24 13:02:52.296612
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Check existence of constructor
    pass

# Generated at 2022-06-24 13:03:03.417361
# Unit test for constructor of class SafariIE
def test_SafariIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    expected_course_id = '9780133392838'
    expected_part = 'part00'

    mobj = re.match(SafariIE._VALID_URL, url)

    safari_ie = SafariIE()

    assert safari_ie._VALID_URL == SafariIE._VALID_URL
    assert safari_ie._LOGIN_URL == SafariIE._LOGIN_URL
    assert safari_ie._NETRC_MACHINE == SafariIE._NETRC_MACHINE
    assert safari_ie._API_BASE == SafariIE._API_BASE

# Generated at 2022-06-24 13:03:06.057371
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari = SafariBaseIE()
    assert safari._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari._API_FORMAT == 'json'
    assert safari._NETRC_MACHINE == 'safari'
    assert safari.LOGGED_IN == False

# Generated at 2022-06-24 13:03:13.539021
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    course_id  = '9780133392838'
    course_title = 'Hadoop Fundamentals LiveLessons'

# Generated at 2022-06-24 13:03:16.977856
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .kaltura import KalturaIE
    assert KalturaIE == SafariIE('kaltura:123')._TARGET_CLASS

# Generated at 2022-06-24 13:03:20.732003
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert isinstance(SafariCourseIE('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'), SafariBaseIE)

# Generated at 2022-06-24 13:03:24.031758
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test SafariIE webplayer.
    webplayer = SafariIE()
    print(webplayer)

    # Test SafariApiIE
    api = SafariApiIE()
    print(api)

    # Test SafariCourseIE
    course = SafariCourseIE()
    print(course)


if __name__ == '__main__':
    test_SafariIE()

# Generated at 2022-06-24 13:03:26.973886
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """
    Test case to check if SafariCourseIE is a valid
    InfoExtractor class.
    """
    ie = SafariCourseIE(None)
    assert ie.IE_NAME == 'safari:course'

# Generated at 2022-06-24 13:03:38.167743
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    import re
    from ..compat import compat_urlparse

    safari_subclass = type('TestSafariBaseIE', (SafariBaseIE,), {})
    safari_subclass._UICONF_ID = '29375172'
    safari_subclass._PARTNER_ID = '1926081'
    safari_subclass._LOGIN_URL = 'https://learning.oreilly.com/accounts/login/'
    safari_subclass._API_BASE = 'https://learning.oreilly.com/api/v1/'
    safari_subclass._API_FORMAT = 'json'
    safari_subclass._NETRC_MACHINE = 'safari'

# Generated at 2022-06-24 13:03:40.036122
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE(None, 'http://techbus.safaribooksonline.com/9780134426365')

# Generated at 2022-06-24 13:03:50.683818
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .common import fake_file
    fields = {
        'chapters': [
            'http://www.safaribooksonline.com/test-chapter-1/',
            'http://www.safaribooksonline.com/test-chapter-2/',
        ]
    }
    course_json_json = json.dumps(fields).encode('utf-8')
    with fake_file(course_json_json, 'safaribooksonline.com/course/'):
        course_id = 'test-course'
        course_url = 'http://www.safaribooksonline.com/test-course/'
        course_ie = SafariCourseIE._build_ie(course_url)

# Generated at 2022-06-24 13:03:51.953874
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    test = SafariBaseIE()
    test._real_initialize()

# Generated at 2022-06-24 13:03:54.905735
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    if __name__ == '__main__':
        safari_api_ie = SafariApiIE()
        safari_api_ie._login()
        safari_api_ie._real_initialize()

# Generated at 2022-06-24 13:03:55.344398
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()

# Generated at 2022-06-24 13:04:07.133357
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Scenario 1: when user inputs username and password
    test_instance = SafariIE(1, {'username': 'sipu.mishra', 'password': 'xyz'})
    assert test_instance.username == 'sipu.mishra'
    assert test_instance.password == 'xyz'
    assert test_instance.LOGGED_IN is True

    # Scenario 2: when user inputs only username
    test_instance1 = SafariIE(1, {'username': 'sipu.mishra'})
    assert test_instance1.username == 'sipu.mishra'
    assert test_instance1.password == ''
    assert test_instance1.LOGGED_IN is True

    # Scenario 3: when user inputs incorrect/empty username and password

# Generated at 2022-06-24 13:04:08.957943
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course = SafariCourseIE('test')
    assert(course.LOGGED_IN == False)

# Generated at 2022-06-24 13:04:12.790145
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE('Safari', {'username': 'foo'}, {})
    assert ie.username == 'foo'
    assert ie._password is None
    ie = SafariBaseIE('Safari', {}, {})
    assert ie.username is None
    assert ie._password is None



# Generated at 2022-06-24 13:04:14.040817
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    tst = SafariBaseIE()
    assert tst._NETRC_MACHINE == 'safari'
    return

# Generated at 2022-06-24 13:04:18.013978
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE('dummy:extractor', 'safari')
    assert ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert ie._NETRC_MACHINE == 'safari'
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'
    assert ie.LOGGED_IN == False

# Generated at 2022-06-24 13:04:19.872045
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert SafariApiIE()._VALID_URL == SafariApiIE._VALID_URL

# Generated at 2022-06-24 13:04:21.341972
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test constructor
    SafariCourseIE()

# Generated at 2022-06-24 13:04:26.069425
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    SafariCourseIE.suitable(url) is True
    SafariCourseIE()



# Generated at 2022-06-24 13:04:29.204298
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class TestSafariBaseIE(SafariBaseIE):
        def _real_initialize(self):
            pass

    TestSafariBaseIE()._login()

# Generated at 2022-06-24 13:04:29.780536
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    _ = SafariCourseIE(None)

# Generated at 2022-06-24 13:04:30.962058
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert SafariApiIE() is not None

# Generated at 2022-06-24 13:04:32.102068
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariCourseIE('SafariIE')

# Generated at 2022-06-24 13:04:33.191604
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()


# Generated at 2022-06-24 13:04:35.609657
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    safari_base_ie.ie_key()

# Generated at 2022-06-24 13:04:37.813460
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """test constructor of class SafariApiIE"""
    instance = SafariApiIE()
    assert instance.ie_key() == 'Safari:api'

# Generated at 2022-06-24 13:04:49.796258
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    url = 'https://techbus.safaribooksonline.com/9780133392838'
    expected_url = 'https://cdnapisec.kaltura.com/html5/html5lib/v2.37.1/mwEmbedFrame.php?wid=_1926081&uiconf_id=29375172&flashvars[referenceId]=9780133392838'
    safari = SafariBaseIE()
    safari._login()
    assert SafariBaseIE.LOGGED_IN == True
    expected_url = 'https://cdnapisec.kaltura.com/html5/html5lib/v2.37.1/mwEmbedFrame.php?wid=_1926081&uiconf_id=29375172&flashvars[referenceId]=9780133392838'

# Generated at 2022-06-24 13:04:55.395041
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = "https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/"

    _, course_id = SafariCourseIE._extract_url_list(url)

    assert course_id == "9780133392838"

# Generated at 2022-06-24 13:04:59.187323
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """
    Test the constructor
    """
    test_instance = SafariCourseIE()
    assert test_instance.IE_NAME == 'safari:course'
    assert test_instance.IE_DESC == 'safaribooksonline.com online courses'


# Generated at 2022-06-24 13:05:08.632173
# Unit test for constructor of class SafariCourseIE

# Generated at 2022-06-24 13:05:10.826472
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test whether constructor of class SafariCourseIE works
    assert isinstance(SafariCourseIE(), SafariCourseIE)

# Generated at 2022-06-24 13:05:14.373798
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('%s/book/%s/?override_format=%s' % ('https://www.safaribooksonline.com/api/v1', '9781449396459', 'json'))

# Generated at 2022-06-24 13:05:16.509873
# Unit test for constructor of class SafariIE
def test_SafariIE():
    mess = 'Unit test for the class ' + SafariIE.__name__ + '.'
    return mess

# Generated at 2022-06-24 13:05:28.552327
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    expected_session_cookie_name = 'groot_sessionid'

# Generated at 2022-06-24 13:05:40.726655
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    """ Unit test for SafariBaseIE constructor """
    ie = SafariBaseIE('%s/%s.html' % (
        SafariBaseIE._API_BASE, SafariBaseIE._API_FORMAT), {})
    assert ie._API_BASE == ie.SafariBaseIE._API_BASE
    assert ie._API_FORMAT == ie.SafariBaseIE._API_FORMAT
    assert ie.SafariBaseIE.SafariBaseIE.SafariBaseIE.SafariBaseIE.SafariBaseIE.SafariBaseIE.SafariBaseIE.SafariBaseIE.SafariBaseIE.SafariBaseIE.SafariBaseIE.SafariBaseIE.SafariBaseIE.SafariBaseIE.SafariBaseIE.SafariBaseIE.SafariBase

# Generated at 2022-06-24 13:05:42.833548
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE('', {}, {})
    assert isinstance(ie.age_limit, int)

# Generated at 2022-06-24 13:05:45.104296
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    inst = SafariBaseIE()
    assert inst is not None
    assert inst.IE_NAME == "safari"

# Generated at 2022-06-24 13:05:53.765558
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # check that logging in to site works and we get a valid response
    safari_base_ie = SafariBaseIE()
    safari_base_ie._real_initialize()

    homepage_json = safari_base_ie._download_json(
        'https://learning.oreilly.com/homepage.json',
        None, 'Downloading Homepage JSON',
        'Unable to download Homepage JSON',
        headers={
            'Accept': 'application/json'})

    assert(homepage_json['user_details']['current_user'] is not None)

# Generated at 2022-06-24 13:05:55.655942
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE(SafariBaseIE.ie_key())

# Generated at 2022-06-24 13:06:06.860952
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .test_utils import make_mock_config
    from .test_utils import MockIE
    from .test_utils import RtmpMockIE
    from .test_utils import skip_if_pycryptodomex_missing

    skip_if_pycryptodomex_missing()

    safari_ie = SafariIE(make_mock_config())
    assert safari_ie.IE_NAME == 'Safari'
    assert safari_ie.IE_DESC == 'safaribooksonline.com online video'

    # To test SafariIE._real_initialize()

# Generated at 2022-06-24 13:06:08.267774
# Unit test for constructor of class SafariIE
def test_SafariIE():
	ie = SafariIE()
	assert(ie) is not None

# Generated at 2022-06-24 13:06:12.593968
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """Test SafariCourseIE class constructor"""
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    SafariCourseIE(info_extractors=[SafariIE.ie_key()]).suitable(url)

# Generated at 2022-06-24 13:06:15.552090
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert SafariApiIE() is not None


# Generated at 2022-06-24 13:06:17.544254
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie._VALID_URL == SafariIE._VALID_URL

# Generated at 2022-06-24 13:06:29.036553
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from unittest import TestCase
    from ..compat import mock
    from .test_common import make_test_cases_from_test_cases_and_test_code

    def test_code(test_case):
        # pylint: disable=protected-access
        instance = test_case.test_instance
        try:
            instance._login()
        except ExtractorError:
            pass

        test_case.assertEqual(instance.LOGGED_IN, test_case.expected_LOGGED_IN)

    class TestSafariIE(TestCase):
        test_cases = [
            mock.Mock(),
            mock.Mock(),
        ]

        def setUp(self):
            self.username = 'username'
            self.password = 'password'

            self.test_cases[0].test_

# Generated at 2022-06-24 13:06:34.234060
# Unit test for constructor of class SafariIE
def test_SafariIE():
    attrs = {
        '_VALID_URL': 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html',
        'IE_NAME': 'safari',
    }
    safariIE = SafariIE(attrs)
    safariIE._real_initialize()


# Generated at 2022-06-24 13:06:42.865872
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    api_ie = SafariApiIE(SafariBaseIE)
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    mobj = re.match(api_ie._VALID_URL, url)
    assert mobj.group('course_id') == '9781449396459'
    assert mobj.group('part') == 'part00'
    return

# Generated at 2022-06-24 13:06:51.835351
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base = SafariBaseIE()
    result = safari_base.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert result == False
    result = safari_base.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert result == False
    result = safari_base.suitable('http://techbus.safaribooksonline.com/9780134426365')
    assert result == False
    result = safari_base.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314')

# Generated at 2022-06-24 13:06:54.654289
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Initialize a SafariBaseIE object
    obj = SafariBaseIE()
    # Check the _real_initialize function
    assert obj._real_initialize() is None
    # Check the _login function
    assert obj._login() is None

# Generated at 2022-06-24 13:06:55.093770
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-24 13:06:56.255295
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course = SafariCourseIE()
    assert course is not None

# Generated at 2022-06-24 13:07:05.169722
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """
    Test SafariCourseIE constructor (Course URL)
    """
    SITE_URL = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    course_id = '9780133392838'

# Generated at 2022-06-24 13:07:16.705629
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    m = SafariBaseIE()

    assert m.LOGGED_IN == False
    assert m._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert m._API_FORMAT == 'json'
    assert m._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert m._NETRC_MACHINE == 'safari'
    assert m._PARTNER_ID == '1926081'
    assert m._UICONF_ID == '29375172'


# Generated at 2022-06-24 13:07:23.181413
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import unittest
    class TestSafariIE(unittest.TestCase):
        def test_SafariIE(self):
            self.assertTrue(SafariIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'))

if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-24 13:07:25.641987
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    print(ie.LOGGED_IN)


if __name__ == '__main__':
    test_SafariIE()

# Generated at 2022-06-24 13:07:36.166365
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    course_id = '9780133392838'
    course_part_id = 'part00'
    correct_url = 'https://www.safaribooksonline.com/api/v1/book/%s/chapter/%s.html' % (course_id, course_part_id)
    test_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    ie = SafariApiIE()
    test_url = ie._real_initialize()
    test_url = ie._real_extract(test_url)
    assert test_url == correct_url

# Generated at 2022-06-24 13:07:44.507092
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import unittest
    import os
    #TODO: Try to use mock instead of monkeypatch
    from _pytest.monkeypatch import MonkeyPatch
    from .common import _SafariTestCase

    class TestSafariApiIEConstructor(unittest.TestCase):
        def test_login_invalid_credentials(self):
            url = 'https://www.safaribooksonline.com/library/view/python-2-7-programming/9780133387435/chapter00.html'
            with _SafariTestCase() as case:
                with MonkeyPatch(case.safari_ie, '_get_login_info', return_value=(None, None)):
                    case.safari_ie._login()

# Generated at 2022-06-24 13:07:47.620975
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    try:
        x = SafariApiIE()
    except Exception as ex:
        assert False
    assert True

# Generated at 2022-06-24 13:07:48.716223
# Unit test for constructor of class SafariIE
def test_SafariIE():
    test_SafariIE.instance = SafariIE()
    assert test_SafariIE.instance.LOGGED_IN == False

test_SafariIE()

# Generated at 2022-06-24 13:07:54.313769
# Unit test for constructor of class SafariIE
def test_SafariIE():
    obj = SafariIE()
    assert obj.IE_NAME == 'safari'
    assert obj.IE_DESC == 'safaribooksonline.com online video'
    assert obj._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''
    assert obj._PARTNER_ID == '1926081'
    assert obj._U

# Generated at 2022-06-24 13:08:02.855908
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """
    This function is a unit test for SafariIE, part of the safaribooksonline-dl project.

    Args:
        None.

    Returns:
        None.

    Raises:
        None.
    """
    doc_path = os.path.join(os.path.dirname(__file__), 'doc')
    with open(doc_path + '/README.rst') as f:
        README = f.read()
        license = re.search(r'^License(.*)^```', README, re.M | re.S).group(1)
        description = re.search(r'^Description(.*)^```', README, re.M | re.S).group(1)
    test = ydl.YoutubeDL(SafariIE())
    test.add