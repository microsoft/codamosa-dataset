

# Generated at 2022-06-24 12:58:09.074782
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    base_ie = SafariBaseIE(SafariIE.ie_key(), {})
    assert hasattr(base_ie, '_download_webpage_handle')
    assert hasattr(base_ie, '_download_json')
    assert hasattr(base_ie, '_get_login_info')
    assert hasattr(base_ie, '_real_initialize')
    assert hasattr(base_ie, '_login')
    assert hasattr(base_ie, '_search_regex')
    assert hasattr(base_ie, '_parse_json')
    assert hasattr(base_ie, '_apply_first_set_cookie_header')
    assert hasattr(base_ie, '_download_webpage')

# Generated at 2022-06-24 12:58:12.236733
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    SafariCourseIE().suitable(url)

# Generated at 2022-06-24 12:58:20.254590
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    original_constructor = SafariApiIE._real_initialize
    try:
        SafariApiIE._real_initialize = lambda x: None
        safari_api = SafariApiIE(None)
        assert safari_api.LOGGED_IN
        SafariApiIE._real_initialize = lambda x: None
        SafariApiIE.LOGGED_IN = False
        safari_api = SafariApiIE(None)
        assert not safari_api.LOGGED_IN
    finally:
        SafariApiIE._real_initialize = original_constructor

# Generated at 2022-06-24 12:58:26.899736
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    def test_class_constructor(cls, *args):
        """
        Test class constructor
        """
        # Test when the class is instanced with a single argument which is
        # actually the url to be tested (e.g. in the case of the
        # SafariCourseIE class)
        if len(args) == 1:
            url = args[0]
            ie = cls(url)
            if (ie.suitable(url) and (
                    len(ie._TESTS) > 0 or
                    hasattr(ie, '_TEST') and ie._TEST is not None)):
                _, ie_test = ie.suitable(url)
                if ie_test is None:
                    ie_test = ie._TESTS[0]
                ie._real_extract(url)
        # Test when the

# Generated at 2022-06-24 12:58:29.395377
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari = SafariApiIE()
    assert safari._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari._API_FORMAT == 'json'

# Generated at 2022-06-24 12:58:32.215986
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    obj = SafariBaseIE()
    if not isinstance(obj, SafariBaseIE):
        raise AssertionError('Constructor of class SafariBaseIE must return class SafariBaseIE')

# Generated at 2022-06-24 12:58:32.810035
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-24 12:58:35.932257
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    assert SafariCourseIE(SafariCourseIE._downloader).suitable(url)

# Generated at 2022-06-24 12:58:36.866342
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    a = SafariBaseIE()
    a._initialize()

# Generated at 2022-06-24 12:58:40.885292
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ieInst = SafariApiIE()
    sth = ieInst._download_webpage_handle
    ieInst._download_webpage_handle = lambda *args: (None, None)
    try:
        ieInst._login()
    finally:
        ieInst._download_webpage_handle = sth

# Generated at 2022-06-24 12:58:47.008237
# Unit test for constructor of class SafariIE
def test_SafariIE():
    test_info = {'id': 'test_id', 'ext': 'test_ext', 'title': 'test_title',
        'timestamp': 1234567890, 'upload_date': '20100203', 'uploader_id': 'test_uploader_id'}

    i = SafariIE()
    assert(i.IE_NAME == 'safari')
    assert(i.IE_DESC == 'safaribooksonline.com online video')

# Generated at 2022-06-24 12:58:58.978123
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    class_ = SafariApiIE
    c = class_(None)
    assert (c.ie_key() == "Safari")
    assert (c._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html')
    assert (c._API_BASE == 'https://learning.oreilly.com/api/v1')
    assert (c._API_FORMAT == 'json')
    assert (c._NETRC_MACHINE == 'safari')
    assert (c._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/')

# Generated at 2022-06-24 12:59:00.748054
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE._html_search_regex_meta('course_id')
    assert ie is not None

# Generated at 2022-06-24 12:59:05.806662
# Unit test for constructor of class SafariIE
def test_SafariIE():
    result = SafariIE('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert result._VALID_URL == 'https?://(?:www\\.)?(?:safaribooksonline|(?:learning\\.)?oreilly)\\.com/library/view/[^/]+/[^/]+/(?P<part>[^/?#&]+)\\.html'

# Generated at 2022-06-24 12:59:06.480836
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    pass

# Generated at 2022-06-24 12:59:08.564230
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert not SafariApiIE._build_url_result(None, None, None)



# Generated at 2022-06-24 12:59:09.567511
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    
    SafariApiIE()
    pass

# Generated at 2022-06-24 12:59:15.205504
# Unit test for constructor of class SafariIE
def test_SafariIE():
    class_1 = SafariIE('SafariIE', 'safaribooksonline.com')
    class_2 = SafariBaseIE('SafariIE', 'safaribooksonline.com')
    assert class_1 is not class_2
    assert class_1.__class__ is class_2.__class__

# Generated at 2022-06-24 12:59:23.608237
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie._netrc_machine == 'safari'
    # check for class SafariBaseIE
    assert safari_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_ie._NETRC_MACHINE == 'safari'
    assert safari_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_ie._API_FORMAT == 'json'
    assert safari_ie.LOGGED_IN == False

# Generated at 2022-06-24 12:59:28.794506
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """Make sure SafariCourseIE can be instantiated."""
    obj = SafariCourseIE({})
    # HACK: Make sure we have a working get_element_by_attribute for testing
    # Safaribooksonline.
    obj._get_element_by_attribute = lambda x, y: None

# Generated at 2022-06-24 12:59:33.446186
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course_id = '9780133392838'
    course_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    course_url_api = 'https://www.safaribooksonline.com/api/v1/book/9780133392838/?override_format=json'
    course_title = 'Hadoop Fundamentals LiveLessons'
    
    m = re.search(SafariCourseIE._VALID_URL, course_url)
    course_id_found = m.group('id')
    
    # test course id matching
    assert course_id_found == course_id

# Generated at 2022-06-24 12:59:39.380589
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    obj = SafariBaseIE(None)
    expected = 'safari'
    actual = obj._NETRC_MACHINE
    assert actual == expected, 'Expected %s, but got %s for instance attribute "NETRC_MACHINE"' % (expected, actual)
    expected = False
    actual = obj.LOGGED_IN
    assert actual == expected, 'Expected %s, but got %s for instance attribute "LOGGED_IN"' % (expected, actual)

# Generated at 2022-06-24 12:59:43.133197
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from youtube_dl.utils import ExtractorError
    SafariApiIE()
    # raises ExtractorError if exceptions disabled
    # https://github.com/rg3/youtube-dl/issues/6128
    with ExtractorError.ignore_errors():
        SafariApiIE()

# Generated at 2022-06-24 12:59:45.219210
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class TestSafariBaseIE(SafariBaseIE):
        IE_NAME = 'safari:base'

    ie = TestSafariBaseIE()
    ie._real_initialize()

# Generated at 2022-06-24 12:59:50.965621
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    obj = SafariBaseIE()
    assert hasattr(obj, '_LOGIN_URL'), 'There is no _LOGIN_URL property in class SafariBaseIE'
    assert hasattr(obj, '_NETRC_MACHINE'), 'There is no _NETRC_MACHINE property in class SafariBaseIE'
    assert hasattr(obj, '_API_BASE'), 'There is no _API_BASE property in class SafariBaseIE'
    assert hasattr(obj, '_API_FORMAT'), 'There is no _API_FORMAT property in class SafariBaseIE'
    assert hasattr(obj, 'LOGGED_IN'), 'There is no LOGGED_IN property in class SafariBaseIE'



# Generated at 2022-06-24 12:59:52.636676
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE('SafariBaseIE')
    assert ie.LOGGED_IN is False

# Generated at 2022-06-24 13:00:06.312637
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """Test the constructor of SafariIE"""
    webIE = SafariIE()
    webIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    webIE.suitable('https://www.safaribooksonline.com/api/v1/book/9780134664057/chapter/RHCE_Introduction.html')
    webIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314/9780134217314-PYMC_13_00')

# Generated at 2022-06-24 13:00:14.816386
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()
    assert safari.IE_NAME == 'safari'
    assert safari.IE_DESC == 'safaribooksonline.com online video'
    assert safari._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''
    assert safari._PARTNER_ID == '1926081'


# Generated at 2022-06-24 13:00:19.782858
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()
    testdict1 = {
            'id': 'safaribooksonline',
            'password': 'onlinebook',
            'username': 'safari'
            }

    assert(testdict1["username"] == safari._get_login_info()[0])
    assert(testdict1["password"] == safari._get_login_info()[1])

# Generated at 2022-06-24 13:00:32.212045
# Unit test for constructor of class SafariIE
def test_SafariIE():
    unit_test = SafariIE()
    assert unit_test._PARTNER_ID == '1926081'
    assert unit_test._UICONF_ID == '29375172'
    assert unit_test._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert unit_test._API_FORMAT == 'json'

# Generated at 2022-06-24 13:00:42.036677
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')

    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    video_id = '100000006A0210-part00'
    urlh = ''
    webpage = ''
    kaltura_session = ''
    session = ''
    query = {'wid': '_1926081', 'uiconf_id': '29375172', 'flashvars[referenceId]': '100000006A0210-part00'}

    def _real_initialize(self):
        self._login()

# Generated at 2022-06-24 13:00:44.353625
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    extractor = SafariApiIE()
    assert extractor.ie_key() == 'Safari'

# Generated at 2022-06-24 13:00:56.968771
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    a = SafariCourseIE()
    assert a.IE_NAME == "safari:course"
    assert a.IE_DESC == "safaribooksonline.com online courses"
    assert a._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'

# Generated at 2022-06-24 13:00:58.605726
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    obj = SafariBaseIE()



# Generated at 2022-06-24 13:01:03.691088
# Unit test for constructor of class SafariIE
def test_SafariIE():
    testurl = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    SafariIE('SafariIE', testurl, {'username': 'test', 'password': 'test'})

# Generated at 2022-06-24 13:01:13.393825
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    import hashlib
    unittest.main()
    def test_constructor(self):
        url = 'http://techbus.safaribooksonline.com/9780134426365'
        self.assertEqual(SafariCourseIE.suitable(url), True, 'URL is suitable')
        try:
            info_extractor = SafariCourseIE(url)
            self.assertEqual(info_extractor.IE_NAME, 'safari:course', 'Name of info extractor is safari:course')
            self.assertEqual(info_extractor.IE_DESC, 'safaribooksonline.com online courses', 'Description is safaribooksonline.com online courses')
        except:
            self.fail('Constructor raised an exception')

# Generated at 2022-06-24 13:01:24.766141
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """Unit test constructor of class SafariApiIE"""
    def do_test(expected_message, *args):
        """Check that constructor of class SafariApiIE raises expected error message"""
        try:
            SafariApiIE(*args)
        except ExtractorError as error:
            if str(error) != expected_message:
                raise Exception(
                    'SafariApiIE does not raise the expected error message: '
                    '"%s" expected but "%s" returned' %
                    (expected_message, str(error)))
            return
        raise Exception(
            'SafariApiIE does not raise an ExtractorError: "%s" expected' %
            expected_message)


# Generated at 2022-06-24 13:01:27.357952
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .test import get_testcases

    instance = SafariIE()
    for _, url, expected_canonical_url in get_testcases():
        if instance.suitable(url):
            assert instance.suitable(expected_canonical_url)

# Generated at 2022-06-24 13:01:28.625318
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert hasattr(SafariBaseIE, '_real_initialize')

# Generated at 2022-06-24 13:01:39.791011
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Args for SafariCourseIE's constructor
    input_args = {
        'url': 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    }
    # Expected output from constructor

# Generated at 2022-06-24 13:01:41.842208
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base = SafariBaseIE()
    assert safari_base._NETRC_MACHINE == 'safari'
    assert safari_base._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base._API_FORMAT == 'json'

# Generated at 2022-06-24 13:01:50.017987
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    test_url = "https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html"
    expected_result = 'https://cdnapisec.kaltura.com/html5/html5lib/v2.37.1/mwEmbedFrame.php?wid=_1926081&uiconf_id=29375172&flashvars[referenceId]=9781449396459-0010'
    assert expected_result == SafariApiIE()._real_extract(test_url).url

# Generated at 2022-06-24 13:02:01.174692
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    try:
        import netrc
    except ImportError:
        return

    # Test that no error occurs
    SafariBaseIE(None)._login()

    info = (None, None)
    f = netrc.netrc()
    try:
        info = f.authenticators(SafariBaseIE._NETRC_MACHINE)
    except (IOError, netrc.NetrcParseError):
        pass

    if info[0] is None:
        return

    # Test error message for bad login
    error = False
    try:
        SafariBaseIE(None)._login()
    except ExtractorError as ee:
        error = ee.msg
    assert error == 'Unable to login: Incorrect username or password.'

# Generated at 2022-06-24 13:02:02.619122
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Tested in SafariCourseIE
    pass


# Generated at 2022-06-24 13:02:08.516664
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_ie = SafariBaseIE()
    assert safari_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_ie._NETRC_MACHINE == 'safari'
    assert safari_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_ie._API_FORMAT == 'json'
    assert safari_ie.LOGGED_IN == False
    assert safari_ie._login() == None
    #assert safari_ie._real_initialize() == None

# Generated at 2022-06-24 13:02:15.166257
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import json
    import re
    from ..utils import (
        compat_parse_qs,
        compat_urlparse,
    )
    from ..compat import (compat_urllib_error, compat_urllib_request)
    from ..compat import (compat_urllib_parse_urlencode, compat_urllib_request)
    from ..utils import (DownloadWebpageException, ExtractorError, update_url_query)
    from ..utils import (ExtractorError, falsify_http_headers, int_or_none, js_to_json, std_headers)
    from ..utils import (ExtractorError, NO_DEFAULT, remove_end, remove_quotes)
    from ..utils import (ExtractorError, remove_end, url_or_none)

# Generated at 2022-06-24 13:02:16.536383
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE.suitable(SafariIE._VALID_URL)


# Generated at 2022-06-24 13:02:27.089436
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """Test if the SafariApiIE constructor doesn't crash the program.

    The SafariApiIE class is a subclass of SafariBaseIE, but the SafariBaseIE
    constructor requires an URL, which is not needed for the SafariApiIE
    class. Therefore an error was logged in the constructor of the SafariApiIE
    class.
    """
    from ..extractor import gen_extractors
    extractors = gen_extractors()
    for ie_class in extractors:
        if ie_class.__name__ == "SafariApiIE":
            ie_instance = ie_class()
            return
    raise Exception("SafariApiIE not found")

# Generated at 2022-06-24 13:02:30.032530
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert not SafariBaseIE.LOGGED_IN
    SafariBaseIE(None)._login()
    assert SafariBaseIE.LOGGED_IN

# Generated at 2022-06-24 13:02:31.008339
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    pass

# Generated at 2022-06-24 13:02:31.787287
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE({})

# Generated at 2022-06-24 13:02:34.030112
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    instance = SafariBaseIE()
    return instance.IE_NAME


# Generated at 2022-06-24 13:02:35.541015
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE

# Generated at 2022-06-24 13:02:40.467600
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # check constructor with default parameters
    safariIE = SafariIE()
    assert safariIE.LOGGED_IN is False
    # check constructor with invalid parameter
    try:
        safariIE = SafariIE(x='x')
    except TypeError:
        pass # ignore exception
    else:
        raise ValueError('constructor not checking invalid parameters')

# Generated at 2022-06-24 13:02:41.461309
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE('lambda', 'url', 'title')

# Generated at 2022-06-24 13:02:50.313929
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_page = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    safari_api_page_data = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/'
    safari_api_page_data_json = json.loads(SafariApiIE._download_webpage(
        safari_api_page_data, None, note=False, errnote=False).decode('utf-8'))
    safari_api_page_data_json['web_url'] = safari_api_page

    # create SafariApiIE object

# Generated at 2022-06-24 13:02:52.461891
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    return SafariBaseIE().LOGGED_IN

# Generated at 2022-06-24 13:02:56.103225
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    t = SafariBaseIE()
    assert not t._LOGIN_URL
    assert not t._NETRC_MACHINE
    assert t._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert t._API_FORMAT == 'json'
    assert not t.LOGGED_IN

# Generated at 2022-06-24 13:03:07.743805
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import unittest
    class TestSafariApiIE(unittest.TestCase):
        def setUp(self):
            self.class_instance = SafariApiIE()
        def test_urls_filtering(self):
            self.assertTrue(
                self.class_instance.suitable(
                    'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'))
            self.assertTrue(
                self.class_instance.suitable(
                    'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838/9780133392838-00_SeriesIntro'))

# Generated at 2022-06-24 13:03:18.915620
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE.suitable('http://techbus.safaribooksonline.com/9780134426365')
    assert not SafariCourseIE.suitable('http://www.oreilly.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert not SafariCourseIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314')
    assert not SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')

# Generated at 2022-06-24 13:03:19.924616
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    t = SafariBaseIE()
    assert t.LOGGED_IN == False

# Generated at 2022-06-24 13:03:20.685970
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE(SafariBaseIE())

# Generated at 2022-06-24 13:03:23.039088
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """Test fetching of a Safari IE with a dummy URL"""
    safari_IE = SafariIE()
    safari_IE._download_webpage = lambda something, something2: None
    safari_IE.extract('http://localhost')

# Generated at 2022-06-24 13:03:28.128712
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert not SafariCourseIE.suitable(
        'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert SafariCourseIE.suitable(
        'https://www.safaribooksonline.com/library/view/learning-path-red/9780134664057/')

# Generated at 2022-06-24 13:03:30.990228
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from . import test_SafariIE
    test_SafariCourseIE = test_SafariIE.test_SafariIE



# Generated at 2022-06-24 13:03:33.455635
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """ Check if SafariCourseIE can be instantiated """
    ie = SafariCourseIE()
    assert ie is not None

# Generated at 2022-06-24 13:03:36.005530
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class DummySafariBaseIE(SafariBaseIE):
        def _login(self):
            return

    DummySafariBaseIE(None)._real_initialize()

# Generated at 2022-06-24 13:03:37.479861
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    """Test constructor of class SafariBaseIE"""
    SafariBaseIE = SafariBaseIE()

# Generated at 2022-06-24 13:03:45.728896
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part02.html'
    safariApiIE = SafariApiIE(SafariIE(), url)
    assert safariApiIE.extract(url) == 'https://cdnapisec.kaltura.com/html5/html5lib/v2.37.1/mwEmbedFrame.php?wid=_1926081&uiconf_id=29375172&flashvars[referenceId]=9781449396459-part02'

# Generated at 2022-06-24 13:03:51.315834
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    import os
    os.environ['NETRC_MACHINE'] = 'safari'
    url = "https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html"
    safari_base_IE = SafariBaseIE()
    safari_base_IE._real_initialize()
    IE = safari_base_IE._real_extract(url)
    assert IE is not None

# Generated at 2022-06-24 13:03:59.938747
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    test_cases = [{
        'url': 'https://learning.oreilly.com/library/view/learning-path-red/9780134664057/RHCE_Introduction.html',
        'partner_id': '1926081',
        'ui_id': '29375172',
        'reference_id': '9780134664057-RHCE_Introduction',
        'widget_id': '_1926081',
    }]

    for test_case in test_cases:
        safarie = SafariBaseIE(test_case['url'])
        assert safarie._PARTNER_ID == test_case['partner_id']
        assert safarie._UICONF_ID == test_case['ui_id']
        assert safarie._reference_id == test_case['reference_id']
        assert safarie

# Generated at 2022-06-24 13:04:02.490570
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    inst = SafariBaseIE()
    assert inst.IE_NAME == 'safari'
    assert inst.LOGGED_IN
    assert inst._NETRC_MACHINE == 'safari'

# Generated at 2022-06-24 13:04:07.987320
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from ..utils import tests_get_last_batch, tests_get_last_batch_url

    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    course_id = '9781449396459'
    part = 'part00'
    safari_api_ie = SafariApiIE()
    mobile_webpage, urlh = safari_api_ie._download_webpage_handle(url, course_id + '/' + part, 'Downloading part JSON')
    test_part = safari_api_ie._download_json(
            url, course_id + '/' + part,
            'Downloading part JSON')
    assert tests_get_last_batch() == [test_part]
    assert tests_get_last

# Generated at 2022-06-24 13:04:09.005045
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    return


# Generated at 2022-06-24 13:04:17.172244
# Unit test for constructor of class SafariCourseIE

# Generated at 2022-06-24 13:04:22.038804
# Unit test for constructor of class SafariIE
def test_SafariIE():
    i = SafariIE('Kaltura', ie_key='Kaltura', ie_url_key='Kaltura')
    assert i.name == 'Kaltura'
    assert i.ie_key == 'Kaltura'
    assert i.ie_url_key == 'Kaltura'

# Generated at 2022-06-24 13:04:25.828443
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE() 
    assert isinstance(safari_base_ie, SafariBaseIE)
    assert issubclass(SafariBaseIE, InfoExtractor)

# Generated at 2022-06-24 13:04:28.974443
# Unit test for constructor of class SafariIE
def test_SafariIE():
    test = SafariIE()
    assert test.IE_NAME == 'safari'
    assert test.IE_DESC == 'safaribooksonline.com online video'

# Generated at 2022-06-24 13:04:39.256661
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    course_id, part = re.match(SafariApiIE._VALID_URL, url).groups()
    api_url = 'https://www.safaribooksonline.com/api/v1/book/%s/chapter/%s.html' % (course_id, part)
    ie = SafariApiIE(SafariApiIE.ie_key())
    # Call _real_extract
    part_json = ie._real_extract(url)
    assert part_json == {'web_url': api_url}

# Generated at 2022-06-24 13:04:51.669407
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # The course "Hadoop Fundamentals LiveLessons" only has a single chapter
    # (part00.html) which is used to initialize a SafariApiIE object and
    # subsequently validate that its video_id (kaltura reference id) matches the
    # course id of the parent course.
    webpage, urlh = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html', None
    mobj = re.match(SafariIE._VALID_URL, urlh.geturl())
    reference_id = mobj.group('reference_id')

# Generated at 2022-06-24 13:04:52.835969
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE('Kaltura')

# Generated at 2022-06-24 13:04:54.200889
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert ie.__class__.__name__ == 'SafariApiIE'


# Generated at 2022-06-24 13:05:00.615250
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE._LOGIN_URL = 'https://learning.oreilly.com/accounts/login/'
    SafariApiIE._NETRC_MACHINE = 'safari'

    SafariApiIE._API_BASE = 'https://learning.oreilly.com/api/v1'
    SafariApiIE._API_FORMAT = 'json'

    SafariApiIE.LOGGED_IN = False

    SafariApiIE()._real_initialize()

# Generated at 2022-06-24 13:05:04.571243
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test default values
    ie = SafariBaseIE()
    assert ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert ie._NETRC_MACHINE == 'safari'
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'
    assert ie.LOGGED_IN == False


# Generated at 2022-06-24 13:05:05.184664
# Unit test for constructor of class SafariIE
def test_SafariIE():
    pass

# Generated at 2022-06-24 13:05:06.099945
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ci = SafariApiIE()
    assert ci

# Generated at 2022-06-24 13:05:10.959285
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    valid_url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part03.html'
    instance = SafariApiIE(SafariApiIE.ie_key())
    instance.suitable(valid_url)
    instance.url_result(valid_url, SafariIE.ie_key())

# Generated at 2022-06-24 13:05:12.088263
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-24 13:05:20.404365
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .test_valid_urls import test_data
    for attempt in test_data:
        # Force to check constructor of class SafariCourseIE
        s = SafariCourseIE(attempt['url'], attempt['ie'])

        # Does webpage exists?
        webpage = s.extract()
        assert webpage is not None

        # Does it contain info_dict?
        info_dict = s.extract_info(webpage, download=False)
        assert info_dict is not None

        # Does it contain url_result?
        url_result = s.extract_info(webpage, download=False)
        assert url_result is not None

        # Does it contain playlist_count?
        playlist_count = s.extract_info(webpage, download=False)
        assert playlist_count is not None

# Generated at 2022-06-24 13:05:27.358933
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE(None)._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert SafariCourseIE(None)._NETRC_MACHINE == 'safari'
    assert SafariCourseIE(None)._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert SafariCourseIE(None)._API_FORMAT == 'json'
    assert SafariCourseIE(None).LOGGED_IN == False

# Generated at 2022-06-24 13:05:31.438355
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = "http://techbus.safaribooksonline.com/9780134426365"
    safari_course_ie = SafariCourseIE(url)
    assert safari_course_ie.suitable(url) == True
    url = "https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/"
    assert safari_course_ie.suitable(url) == False

# Generated at 2022-06-24 13:05:35.760110
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    """Test class constructor for SafariBaseIE"""

    foo = SafariBaseIE() # PyflakesNotice
    assert isinstance(foo, InfoExtractor)
    #assert foo._NETRC_MACHINE == 'safari'

# Generated at 2022-06-24 13:05:42.142614
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    part = 'part00.html'
    ApiExtractor = SafariApiIE(SafariBaseIE,url,part)
    assert ApiExtractor._match_id(url) == '9780133392838'

# Generated at 2022-06-24 13:05:42.891814
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE
    assert ie.suitable(ie._VALID_URL)

# Generated at 2022-06-24 13:05:45.521464
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .test_safari import test_SafariCourseIE
    test_SafariCourseIE(SafariCourseIE)

# Generated at 2022-06-24 13:05:47.462134
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False

# Generated at 2022-06-24 13:06:01.032915
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from ..utils import load_json, HEADRequest
    from ..compat import (
        compat_HTTPError,
        compat_str,
        compat_urllib_error,
        compat_urllib_request,
    )

    class FakeSafariBaseIE(SafariBaseIE):
        def _real_extract(self, url):
            return self.url_result(url, 'Generic')

        def _download_json(self, url_or_request, video_id, note='', errnote='', fatal=True, headers={}):
            return json.loads(self._download_webpage(url_or_request, video_id, note=note, errnote=errnote, fatal=fatal, headers=headers))

        def _real_initialize(self):
            pass


# Generated at 2022-06-24 13:06:05.902201
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    if __name__ == "__main__":
        class TestSafariBaseIE(SafariBaseIE):
            IE_NAME = "test"
        test_instance = TestSafariBaseIE()
        test_instance.IE_NAME = 'test'
        # Test the method real_initialize() without any exception
        test_instance._real_initialize()

# Generated at 2022-06-24 13:06:07.691426
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    obj = SafariBaseIE()
    assert type(obj).__name__ == SafariBaseIE.__name__

# Generated at 2022-06-24 13:06:09.092102
# Unit test for constructor of class SafariIE
def test_SafariIE():
    a = SafariIE()
    assert isinstance(a, SafariIE)

# Generated at 2022-06-24 13:06:10.768294
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Create a new instance of class SafariIE
    safari_ie = SafariIE()
    return safari_ie

# Generated at 2022-06-24 13:06:22.916794
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safariBase = SafariBaseIE()
    assert(safariBase._API_BASE == 'https://learning.oreilly.com/api/v1')
    assert(safariBase._API_FORMAT == 'json')
    assert(safariBase._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/')
    assert(safariBase._NETRC_MACHINE == 'safari')
    assert(safariBase._PARTNER_ID == '1926081')
    assert(safariBase._UICONF_ID == '29375172')

# Generated at 2022-06-24 13:06:28.902620
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from pytube import YouTube
    assert YouTube('https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838').is_age_restricted
    assert YouTube('https://www.oreilly.com/library/view/hadoop-fundamentals-livelessons/9780133392838/').is_age_restricted

# Generated at 2022-06-24 13:06:30.198007
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    assert ie.__class__ == SafariBaseIE

# Generated at 2022-06-24 13:06:32.591949
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE("model")
    SafariBaseIE("model", "extractor")
    SafariBaseIE("model", "extractor", "target")

# Generated at 2022-06-24 13:06:34.375343
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class TestClass(SafariBaseIE):
        pass

    TestClass('safari')._real_initialize()

# Generated at 2022-06-24 13:06:39.031410
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    instance = SafariBaseIE('a username', 'a password')
    assert instance.username == 'a username'
    assert instance.password == 'a password'

# Generated at 2022-06-24 13:06:39.502950
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()

# Generated at 2022-06-24 13:06:46.105402
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()

    assert safari_base_ie._NETRC_MACHINE == 'safari', 'Unit test for _NETRC_MACHINE failed'
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/', 'Unit test for _LOGIN_URL failed'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1', 'Unit test for _API_BASE failed'
    assert safari_base_ie._API_FORMAT == 'json', 'Unit test for _API_FORMAT failed'
    assert safari_base_ie.LOGGED_IN == False, 'Unit test for LOGGED_IN failed'

# Generated at 2022-06-24 13:06:49.457286
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    safari_base_ie._real_initialize()

# Generated at 2022-06-24 13:06:52.583904
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class TestSafariBaseIE(SafariBaseIE):
        _API_BASE = 'http://example.com'

    TestSafariBaseIE()



# Generated at 2022-06-24 13:06:58.532914
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/C_4_1_Introduction_to_the_Hello_World_Application.html'
    try:
        SafariBaseIE._download_webpage_handle(url, None, None)
    except ExtractorError as e:
        if str(e) == 'Unable to log in':
            raise SkipTest()
        raise e
    SafariApiIE()

# Generated at 2022-06-24 13:07:03.525438
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safariIE = SafariIE('http://techbus.safaribooksonline.com/9780134426365')
    assert safariIE._NETRC_MACHINE == 'safari'
    assert safariIE._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'

# Generated at 2022-06-24 13:07:05.607789
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safariBase = SafariBaseIE()
    assert safariBase._NETRC_MACHINE == 'safari'

# Generated at 2022-06-24 13:07:08.082963
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari = SafariCourseIE()
    # access private field _VALID_URL
    assert safari._VALID_URL is not None

# Generated at 2022-06-24 13:07:08.783608
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()

# Generated at 2022-06-24 13:07:14.199258
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    print("Test for constructor of class SafariCourseIE")
    url = "https://www.oreilly.com/library/view/hadoop-fundamentals-livelessons/9780133392838/"
    course = SafariCourseIE()
    assert course.suitable(url) == True
    
test_SafariCourseIE()

# Generated at 2022-06-24 13:07:24.754816
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    t = SafariApiIE()
    t._API_BASE = 'https://learning.oreilly.com/api/v1'
    t._API_FORMAT = 'json'
    t._VALID_URL = r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter-content/0001.html'
    course_id = '9781449396459'
    part = '0001.html'

# Generated at 2022-06-24 13:07:36.501396
# Unit test for constructor of class SafariIE
def test_SafariIE():
    test = SafariIE()
    assert test.IE_NAME == 'safari'
    assert test.IE_DESC == 'safaribooksonline.com online video'
    assert test._VALID_URL == '''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''
    assert test._PARTNER_ID == '1926081'
    assert test._UIC

# Generated at 2022-06-24 13:07:44.754766
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Use the same test page as in tests of YoutubeIE
    video_id = 'KlyXNRrsk4A'
    url = 'https://www.youtube.com/watch?v=%s' % video_id
    safari = SafariIE(url)
    safari_result = safari.extract()
    assert safari_result['id'] == video_id
    assert safari_result['title'] == 'The New iPad'
    assert safari_result['description']
    assert safari_result['thumbnail']
    assert safari_result['duration']
    assert safari_result['timestamp']
    assert safari_result['upload_date']
    assert safari_result['uploader']
    assert safari_result['webpage_url'] == url
    # The following fields are not available for this video


# Generated at 2022-06-24 13:07:45.964366
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()



# Generated at 2022-06-24 13:07:53.140074
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    ie._LOGIN_URL = 'https://learning.oreilly.com/accounts/login/'
    ie._NETRC_MACHINE = 'safari'
    ie._API_BASE = 'https://learning.oreilly.com/api/v1'
    ie._API_FORMAT = 'json'
    assert ie.LOGGED_IN is False

# Generated at 2022-06-24 13:07:59.655016
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # This is test case for successful path of constructor
    # Arrange
    url = 'https://www.safaribooksonline.com/api/v1/book/9780134677913/chapter/part00.html'
    # Act
    obj = SafariApiIE(url)

    # Assert
    assert isinstance(obj, SafariApiIE)
    assert isinstance(obj, InfoExtractor)
    assert isinstance(obj, SafariBaseIE)

