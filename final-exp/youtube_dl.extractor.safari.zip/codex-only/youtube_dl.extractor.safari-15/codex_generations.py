

# Generated at 2022-06-24 12:58:02.839964
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # SafariBaseIE should not raise an exception
    safari_base_ie = SafariBaseIE('fake_user', 'fake_password')
    safari_base_ie = SafariBaseIE('fake_user', 'fake_password', 'http://fake_login_url.com')

# Generated at 2022-06-24 12:58:08.651795
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """Test SafariCourseIE constructor"""
    from .test_utils import make_mocked_request
    webpage = make_mocked_request('http://techbus.safaribooksonline.com/9780134426365', 'test_SafariCourseIE.txt')
    safari = SafariCourseIE(SafariCourseIE._create_ie_instance())
    # Method _real_extract() is called
    safari._real_extract(webpage.url)
    # Segmentation fault if error

# Generated at 2022-06-24 12:58:17.241846
# Unit test for constructor of class SafariCourseIE

# Generated at 2022-06-24 12:58:26.303468
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    course_id = '9780133392838'
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/' + course_id + '/'
    course = SafariCourseIE._real_extract(SafariCourseIE(), url)
    assert course['id'] == course_id
    assert 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/' + course_id + '/part00.html' in course['entries'][0]['url']

# Generated at 2022-06-24 12:58:32.118358
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test constructor of class SafariIE
    ie = SafariIE()

    assert ie._NETRC_MACHINE == 'safari'
    assert ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert ie.IE_NAME == 'safari'
    assert ie.IE_DESC == 'safaribooksonline.com online video'

# Generated at 2022-06-24 12:58:33.869383
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Tests for SafariBaseIE constructor
    SafariBaseIE('safaribooksonline.com')

# Generated at 2022-06-24 12:58:35.664972
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE('', 'http://safari.com')
    SafariIE('', 'http://learning.oreilly.com')

# Generated at 2022-06-24 12:58:41.504358
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    res = SafariBaseIE._build_kaltura_config(
        "http://www.example.com/", "e6415", "29375172",
        "uiconf_id=29375072&flashvars[referenceId]=t2_")
    assert res == ("http://www.example.com/?wid=_e6415"
                   "&uiconf_id=29375172"
                   "&flashvars[referenceId]=t2_")



# Generated at 2022-06-24 12:58:44.261097
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """Unit test for constructor of class SafariCourseIE."""
    # not assertRaises context manager to support python 2.6
    try:
        SafariCourseIE()
        raise AssertionError('SafariCourseIE constructor does not raise expected exception.')
    except TypeError:
        pass

# Generated at 2022-06-24 12:58:45.929912
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE(None)
    assert ie.IE_NAME == 'safari:api'


# Generated at 2022-06-24 12:58:51.854227
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course = SafariCourseIE(None)
    assert course._VALID_URL == 'https?://(?:www\\.)?(?:safaribooksonline|(?:learning\\.)?oreilly)\\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'

# Generated at 2022-06-24 12:58:53.420120
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert(new().__class__.__name__ == 'SafariCourseIE')

# Generated at 2022-06-24 12:59:05.705769
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    kaltura_reference_id = '1_h2xs3zwq'
    webpage = '<div id="entry_id_{}"'.format(kaltura_reference_id)
    url = 'http://example.com/video.html'
    m = re.match(SafariIE._VALID_URL, url)
    course_id = '9780133392838'
    part = 'part00'
    video_id = '{}/{}'.format(course_id, part)

    def _download_webpage_handle(url, video_id, note, errnote):
        assert url == 'https://www.safaribooksonline.com/library/view/{}/{}/{}.html'.format(
            course_id, course_id, part)
        return webpage, None



# Generated at 2022-06-24 12:59:07.012368
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie_class = SafariBaseIE(None)
    assert ie_class



# Generated at 2022-06-24 12:59:09.116086
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    info_extractor = SafariBaseIE(None)
    assert info_extractor.FINAL_URL == 'https://learning.oreilly.com/accounts/login-check/'

# Generated at 2022-06-24 12:59:15.211557
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from ..test.test_downloader import FakeYDL

    ydl = FakeYDL()
    with ydl:
        ydl.params['usenetrc'] = False
        SafariApiIE()._download_webpage_handle(
            'https://learning.oreilly.com/accounts/login/', None, None)

# Generated at 2022-06-24 12:59:26.287751
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Tests for case when this class is not suspected
    for url in (SafariIE._TESTS[0]['url'], SafariApiIE._TESTS[0]['url']):
        ie = SafariCourseIE.suitable(url)
        assert ie is False, "URL '%s' is supposed not to be a suitable URL" % url

    # Tests for case when this class is suspected, but it is another class
    for url in (SafariIE._TESTS[0]['url'], SafariApiIE._TESTS[0]['url']):
        ie = SafariCourseIE.suitable(url)
        assert ie is False, "URL '%s' is suspected to be a SafariCourseIE instance, but it's another class" % url

    # Tests for case when this class is suitable

# Generated at 2022-06-24 12:59:28.690652
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course_ie = SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert course_ie is True

# Generated at 2022-06-24 12:59:29.155081
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()

# Generated at 2022-06-24 12:59:34.136118
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # unit test for SafariIE class
    for url in ['https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html',
                'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838/9780133392838-00_SeriesIntro']:
        _SafariIE = SafariIE(url)
        # test _real_initialize()
        _SafariIE._real_initialize()
        # test _real_extract()
        _SafariIE._real_extract(url)
        # test _real_extract()
        _SafariIE._real_extract(url)
    # unit test for SafariCourseIE class


# Generated at 2022-06-24 12:59:35.154248
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()._real_initialize()

# Generated at 2022-06-24 12:59:36.906493
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    base_ie = SafariBaseIE()
    # test _real_initialize
    base_ie._real_initialize()

# Generated at 2022-06-24 12:59:38.648611
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .common import TestSafariIE
    TestSafariIE.test_SafariCourseIE()

# Generated at 2022-06-24 12:59:39.249221
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-24 12:59:41.497150
# Unit test for constructor of class SafariIE
def test_SafariIE():
    instance = SafariIE()
    assert isinstance(instance, SafariIE)
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-24 12:59:42.919699
# Unit test for constructor of class SafariIE
def test_SafariIE():
        safari_ie = SafariIE()
        assert isinstance(safari_ie, SafariIE)
        assert isinstance(safari_ie, InfoExtractor)

# Generated at 2022-06-24 12:59:44.190515
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """Verify the SafariApiIE constructor doesn't crash."""
    assert SafariApiIE()

# Generated at 2022-06-24 12:59:46.205995
# Unit test for constructor of class SafariIE
def test_SafariIE():
    try:
        SafariIE('test')
    except TypeError as e:
        if e.args[0] != '__init__() takes from 1 to 2 positional arguments but 3 were given':
            raise

# Generated at 2022-06-24 12:59:49.408908
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari = SafariBaseIE()
    assert safari._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari._NETRC_MACHINE == 'safari'
    assert safari._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari._API_FORMAT == 'json'
    assert safari.LOGGED_IN == False

# Generated at 2022-06-24 12:59:51.336986
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert hasattr(SafariCourseIE, '_download_json')
    assert (SafariCourseIE.__module__ == 'safari')

# Generated at 2022-06-24 12:59:55.073829
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari = SafariCourseIE('', '')
    assert safari.IE_NAME == 'safari:course'
    assert safari.IE_DESC == 'safaribooksonline.com online courses'
    assert safari.LOGGED_IN == False


# Generated at 2022-06-24 13:00:05.523932
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert ie.IE_NAME == 'safari:api'

    course_url = 'https://www.safaribooksonline.com/library/view/full-stack-javascript/9781785887510/'
    part_url = 'https://www.safaribooksonline.com/api/v1/book/9781785887510/chapter/part00.html'
    try:
        ie.url_result(part_url)
    except ValueError:
        pass
    else:
        assert False

# Generated at 2022-06-24 13:00:14.374123
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = "https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html"
    video_id = '9781449396459'
    title = 'book'

    webpage = "page content"
    expected_url = 'http://url.com'
    video_data = {"web_url": expected_url}

    ie = SafariApiIE()
    assert ie.IE_NAME == 'safari:api'
    assert ie.IE_DESC == 'safaribooksonline.com online courses'

    # test _real_extract
    ie.extract = lambda url: video_data
    assert ie._real_extract(url) == ie.url_result(expected_url, 'Safari')
  
    # test _real_initial

# Generated at 2022-06-24 13:00:15.731865
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()
    SafariApiIE()
    SafariCourseIE()

# Generated at 2022-06-24 13:00:22.758617
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # The request for following url would require a login
    # https://www.safaribooksonline.com/library/view/sed-and-awk-2nd/9781491978546/
    url = 'https://www.safaribooksonline.com/library/view/sed-and-awk-2nd/9781491978546/'
    safari_course = SafariCourseIE(url, 'sed-and-awk-2nd/9781491978546')
    assert safari_course.LOGGED_IN == False

# Generated at 2022-06-24 13:00:30.689590
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .common import test_module_for_IE

    course_id = '9780134664057'
    part = 'RHCE_Introduction'

    url = 'https://www.safaribooksonline.com/api/v1/book/%s/chapter/%s.html' % (course_id, part)
    part_json = json.loads(test_module_for_IE(SafariApiIE, url))
    assert part_json['web_url']

# Generated at 2022-06-24 13:00:31.373415
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    obj = SafariBaseIE

# Generated at 2022-06-24 13:00:33.969152
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE(SafariBaseIE._downloader, 'http://www.safaribooksonline.com')

# Generated at 2022-06-24 13:00:42.688879
# Unit test for constructor of class SafariIE
def test_SafariIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    webpage, urlh = InfoExtractor._download_webpage_handle(url, None, 'Downloading login page')

    # is_logged is not defined here but should be defined in SafariBaseIE
    def is_logged(urlh):
        return 'learning.oreilly.com/home/' in urlh.geturl()

    # urlh should be logged
    assert is_logged(urlh)

    redirect_url = urlh.geturl()
    parsed_url = compat_urlparse.urlparse(redirect_url)
    qs = compat_parse_qs(parsed_url.query)

# Generated at 2022-06-24 13:00:51.259358
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .test_module import TestModule
    from .test_module import TestTask
    from .test_module import errinfo

    task = TestTask(TestModule('SafariIE', 'SafariIE', 'SafariIE'),
                    'SafariIE', '1')

    output_data = task.run()

    if not output_data.success:
        print("output_data: %s" % output_data)

    errinfo.assert_success(output_data)

test_SafariIE()

# Generated at 2022-06-24 13:00:54.940385
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    SafariApiIE(SafariApiIE.IE_NAME, url)

# Generated at 2022-06-24 13:01:07.944800
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import time
    import random
    import unittest

    random.seed(time.time())
    #print(hex(random.randint(0,900000000000000)))
    class TestSafariIE(unittest.TestCase):

        def test_SafariIE(self):
            from .common import list_courses

            url="https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html"
            list_courses(url)

            s=SafariIE()
            s.url=url
            course_id,part_id=s.extract_ids(url)
            course_id=s.unit_test_course_id
            part_id=s.unit_test_part_id


# Generated at 2022-06-24 13:01:10.884102
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    t = SafariCourseIE()
    t = SafariCourseIE()
    t = SafariCourseIE()
    t = SafariCourseIE()

# Generated at 2022-06-24 13:01:22.575917
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test with dummy method: download_webpage
    real_download_webpage = SafariApiIE._download_webpage
    def _download_webpage(*args, **kwargs):
        return real_download_webpage(
            'https://www.safaribooksonline.com/api/v1/book/9781449396459/'
            'chapter/part00.html', '9781449396459/part00', 'Downloading part '
            'JSON', 'Unable to download part JSON', fatal=False)
    SafariApiIE._download_webpage = _download_webpage
    # Test with dummy method: kaltura_session
    real_kaltura_session = SafariApiIE._download_json

# Generated at 2022-06-24 13:01:24.342686
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie is not None


# Generated at 2022-06-24 13:01:28.432048
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    """
    Test constructor of class SafariBaseIE
    """
    SafariBaseIE('safari', 'safaribooksonline.com online video')
    SafariBaseIE('safari:api', 'safaribooksonline.com online video')
    SafariBaseIE('safari:course', 'safaribooksonline.com online courses')

# Generated at 2022-06-24 13:01:34.164054
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()
    mobj = re.match(safari_api_ie._VALID_URL, 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html')
    course_id = mobj.group('course_id')
    part = mobj.group('part')
    url = 'https://www.safaribooksonline.com/api/v1/book/{}/chapter/{}.html'.format(course_id, part)
    part = safari_api_ie._download_json(url, '{}/{}'.format(course_id, part), 'Downloading part JSON')

# Generated at 2022-06-24 13:01:36.161278
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    inst = SafariApiIE()
    assert 'safaribooksonline' in inst._API_BASE
    assert inst._API_FORMAT == 'json'

# Generated at 2022-06-24 13:01:37.592213
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    f = SafariApiIE("test")
    return f

# Generated at 2022-06-24 13:01:45.388476
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    inf = SafariCourseIE('safari:course')
    assert inf.ie_key() == 'safari:course'
    assert inf.suitable('https://techbus.safaribooksonline.com/9780134426365') == True
    assert inf.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json') == False

# Generated at 2022-06-24 13:01:46.881830
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    IE = SafariCourseIE()
    assert isinstance(IE, SafariCourseIE)

# Generated at 2022-06-24 13:01:47.728555
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert SafariBaseIE('Safari') is not None

# Generated at 2022-06-24 13:01:56.103089
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()
    assert safari_api_ie.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert re.match(safari_api_ie._VALID_URL, 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')

# Generated at 2022-06-24 13:01:57.764491
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE('Safari', 'Hadoop Fundamentals LiveLessons')

# Generated at 2022-06-24 13:02:04.709543
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """
    Check that SafariCourseIE object is constructed correctly
    """
    from .test_common import assertIEObject
    assertIEObject(SafariBaseIE(), {
        'id': 'foo',
        'title': 'bar',
        'url': 'https://www.safaribooksonline.com/foo/',
        '_type': 'playlist',
        'entries': [{
            'id': 'baz',
            'width': 1280,
            'height': 720,
        }],
    })

# Generated at 2022-06-24 13:02:06.539252
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """Test constructor of class SafariApiIE."""
    i = SafariApiIE()
    assert isinstance(i, SafariBaseIE)

# Generated at 2022-06-24 13:02:07.730805
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Init the extractor and attempt to extract a url
    SafariCourseIE()

# Generated at 2022-06-24 13:02:10.696744
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    info = SafariCourseIE()._real_extract(url)
    assert info['id'] == '9780133392838'

# Generated at 2022-06-24 13:02:21.181346
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """
    Unit test for class SafariIE.

    """
    from . import expected_results
    from .common import expected_warnings
    from .test_kaltura import KalturaIE

    safari_ie = SafariIE()

    # Test a simple case
    kaltura_id = '1_t9rhn0pf'
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    download_url = safari_ie.result_from_url(url)['url']

# Generated at 2022-06-24 13:02:35.256363
# Unit test for constructor of class SafariApiIE

# Generated at 2022-06-24 13:02:40.265060
# Unit test for constructor of class SafariIE
def test_SafariIE():
    try:
        SafariIE()
        raise AssertionError('Excepted exception MissingPassword')
    except ExtractorError as e:
        assert isinstance(e.cause, ExtractorError)
        assert str(e.cause) == 'Missing account credentials'
        assert str(e) == 'Unable to log in: Missing account credentials'

# Generated at 2022-06-24 13:02:41.700349
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    class T(SafariApiIE):
        pass

    assert T() is not None

# Generated at 2022-06-24 13:02:43.024949
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    info_extract_instance = SafariCourseIE()
    assert info_extract_instance

# Generated at 2022-06-24 13:02:44.589188
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert isinstance(SafariBaseIE(), SafariBaseIE)

# Generated at 2022-06-24 13:02:52.661651
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    if not hasattr(SafariBaseIE, '_login'):
        print('Skipped')
        return

    def my_clone_viewers(y, z):
        print('clone_viewers')
        return {'x': y, 'y': z}

    class TestSafariBaseIE(SafariBaseIE):
        _LOGIN_URL = 'https://learning.oreilly.com/accounts/login/'
        _NETRC_MACHINE = 'safari'

        _API_BASE = 'https://learning.oreilly.com/api/v1'
        _API_FORMAT = 'json'

        def _clone_viewers(self, x, y, z):
            return my_clone_viewers(y, z)


# Generated at 2022-06-24 13:03:03.875522
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    import os
    from os.path import isfile
    from .safari import SafariBaseIE
    from ..utils import (
        match_filter_func,
        prepend_extension,
        sanitize_filename,
        sanitized_Request,
    )
    import random
    import shutil
    import tempfile
    from ..compat import (
        compat_urlparse,
    )
    from ..downloader import (
        FileDownloader,
        MultiFileDownloader,
    )
    from ..postprocessor import (
        FFmpegExtractAudioPP,
        FFmpegMetadataPP,
    )
    from ..utils import (
        DateRange,
        GeoRestriction,
        OnDemandPagedList,
    )

# Generated at 2022-06-24 13:03:11.452064
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Arguments to safari_book_online constructor
    url = 'https://www.safaribooksonline.com/library/view/cbse-class-10/9789311125542/'
    video_id = '9789311125542'
    title = 'Computer Science with Python'
    profile_name = 'safari'
    password = '12345'

    sbo = SafariIE(
        url, video_id, title, profile_name, password)

    # If password is not provided
    sbo = SafariIE(url, video_id, title, profile_name)
    assert(sbo.password is None)

# Generated at 2022-06-24 13:03:14.029249
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    ie._real_initialize()
    assert ie.LOGGED_IN == False
    assert ie._login() == None

# Generated at 2022-06-24 13:03:21.260412
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert hasattr(SafariIE, 'ie_key')
    assert isinstance(SafariIE.ie_key(), str)
    assert SafariIE.ie_key() == 'Safari'
    assert hasattr(SafariIE, 'ie_key')
    assert isinstance(SafariIE.ie_key(), str)
    assert SafariIE.ie_key() == 'Safari'

# Generated at 2022-06-24 13:03:22.106130
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    return SafariCourseIE

# Generated at 2022-06-24 13:03:27.794530
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    u = 'https://www.safaribooksonline.com/video/introduction-to-hadoop-fundamentals-livelessons/9780133392838/9780133392838-00_SeriesIntro/introduction-to-hadoop-fundamentals-livelessons-9780133392838-9780133392838-00_seriesintro'
    s = SafariBaseIE()._real_initialize()

# Generated at 2022-06-24 13:03:30.652371
# Unit test for constructor of class SafariIE
def test_SafariIE():
    print('\n------------------ test constructor of class SafariIE')
    result = SafariIE()
    print(result)


# Generated at 2022-06-24 13:03:35.053641
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    ie = SafariApiIE(InfoExtractor())
    ie.extract(url)
    assert ie.url == url

# Generated at 2022-06-24 13:03:39.678460
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Arrange
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter-content/kraken_c01_00.html?access=sso'

    # Act
    safari_api = SafariApiIE()

    # Assert
    assert safari_api is not None

# Generated at 2022-06-24 13:03:45.530216
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    dl = 'https://learning.safaribooksonline.com/api/v1/book/9781449396459/chapter-content/vi001.html'
    mobj = re.match(SafariApiIE._VALID_URL, dl)
    course_id = mobj.group('course_id')
    assert course_id == '9781449396459'

# Generated at 2022-06-24 13:03:46.922460
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert isinstance(SafariBaseIE(), InfoExtractor)

# Generated at 2022-06-24 13:03:48.635945
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE('abc', 'abc')
    assert ie.LOGGED_IN == False


# Generated at 2022-06-24 13:03:49.914515
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    instance = SafariBaseIE()
    assert instance.LOGGED_IN is False



# Generated at 2022-06-24 13:03:51.523472
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari = SafariBaseIE('username', 'password')
    assert safari.LOGGED_IN == False

# Generated at 2022-06-24 13:03:52.104365
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-24 13:03:55.765561
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert re.match(SafariApiIE._VALID_URL, 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter-content/sect0.html')
    a = SafariApiIE()

# Generated at 2022-06-24 13:03:57.200359
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    instance = SafariApiIE("SafariApiIE")


# Generated at 2022-06-24 13:04:00.355872
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # TODO: No URLs with test cases
    assert_raises(AssertionError, SafariIE, None)

# Generated at 2022-06-24 13:04:01.365018
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safariCourseIE = SafariCourseIE()

# Generated at 2022-06-24 13:04:04.486726
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """
    Test constructing SafariCourseIE.
    """
    safaricourse = SafariCourseIE()
    assert safaricourse is not None

from ..compat import parse_qs


# Generated at 2022-06-24 13:04:06.313114
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test an extended class of SafariBaseIE
    ie = SafariIE('', {}, False)
    ie.initialize()
    assert ie.LOGGED_IN

# Generated at 2022-06-24 13:04:11.473595
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from ..youtube import YoutubeIE

    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    ie = YoutubeIE()
    ie.extract(url)
    ie = SafariApiIE()
    ie.extract(url)
    ie = SafariCourseIE()
    ie.extract(url)

# Generated at 2022-06-24 13:04:12.610168
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    obj = SafariApiIE()
    assert obj.ie_key() == 'SafariApi'

# Generated at 2022-06-24 13:04:15.432672
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class TestSafariBaseIE(SafariBaseIE):
        _VALID_URL = r'^whatever$'

        def _real_extract(self, url):
            return

    t = TestSafariBaseIE('web')
    t._login()

# Generated at 2022-06-24 13:04:16.945134
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # method exist in constructor of class SafariIE
    #self.assertTrue(SafariIE is True)
    assert(SafariIE)


# Generated at 2022-06-24 13:04:22.379626
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # create the class
    ie = SafariBaseIE()
    assert ie.LOGGED_IN == False
    ie._login()
    assert ie.LOGGED_IN == False
    # it doesn't check for username and password

    print('SafariBaseIE constructor works')



# Generated at 2022-06-24 13:04:34.932939
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from .common import get_testdatapath
    from ..utils import read_json_file

    test_safari_base_json = read_json_file(get_testdatapath(
        'test_safari_base_ie.json'))
    safari_base_instance = SafariBaseIE()

    assert isinstance(safari_base_instance, SafariBaseIE)
    assert safari_base_instance._download_webpage_handle(
        'https://learning.oreilly.com/accounts/login-check/', None,
        'Downloading login page') == test_safari_base_json['download_webpage_handle']

# Generated at 2022-06-24 13:04:37.253698
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    ie.extract('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')

# Generated at 2022-06-24 13:04:39.936637
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    try:
        # Check the constructor is not empty
        SafariCourseIE()
    except TypeError:
        # The constructor is empty
        pass

# Generated at 2022-06-24 13:04:40.806250
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()

# Generated at 2022-06-24 13:04:53.417407
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test for video
    url = "http://lifehacker.com/i-mentored-under-a-great-manager-for-years-and-took-mental-1797347419"
    video_url = 'https://www.safaribooksonline.com/library/view/learning-path-red/9780134664057/RHCE_Introduction.html'
    video_info = {
        'id': '9780134664057/RHCE_Introduction',
        'ext': 'mp4',
        'title': 'RHCE_Introduction',
        'uploader': 'jeremy',
    }
    #Test for course
    course_url = 'https://www.safaribooksonline.com/library/view/oracle-data-guard/9781449317003/'
    course_

# Generated at 2022-06-24 13:04:54.616881
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()._initialize_geo_bypass()

# Generated at 2022-06-24 13:05:04.627139
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test that you can find the course by a valid course ID
    course = SafariCourseIE()
    course.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/')
    assert course._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'
    course.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')

# Generated at 2022-06-24 13:05:06.361596
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert isinstance(ie, SafariApiIE)

# Generated at 2022-06-24 13:05:11.269222
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .test_download import get_testcases
    testcases = get_testcases()
    for test in testcases:
        if SafariCourseIE.suitable(test['url']) and not SafariIE.suitable(test['url']) and not SafariApiIE.suitable(test['url']):
            SafariCourseIE()._real_extract(test['url'])

# Generated at 2022-06-24 13:05:15.007075
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert ie.course_id == '9781449396459'

# Generated at 2022-06-24 13:05:17.707865
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()
    SafariBaseIE('safari youtube-dl')
    SafariBaseIE('safari youtube-dl', 'safari')

# Generated at 2022-06-24 13:05:29.464238
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from ..utils import parse_age_limit
    from ..compat import parse_qs

    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    course_id = '9781449396459'
    web_url = 'https://www.safaribooksonline.com/library/view/introduction-to-machine/9781449396459/'
    chapter_url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter-content/0_chp.html?override_format=json'

# Generated at 2022-06-24 13:05:32.377547
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from .common import FakeLogin

    try:
        with FakeLogin('user', 'pass'):
            SafariBaseIE()
    except ExtractorError as e:
        assert e.args[0] == 'Unable to log in'

# Generated at 2022-06-24 13:05:35.145495
# Unit test for constructor of class SafariIE
def test_SafariIE():
    inst = SafariIE()
    assert inst.ie_key() == 'Safari'

# Generated at 2022-06-24 13:05:37.335345
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    inst = SafariCourseIE()
    assert inst.key_prefix in ('SafariApi', 'Safari')

# Generated at 2022-06-24 13:05:41.724407
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'

# Generated at 2022-06-24 13:05:50.232054
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """
    Test class SafariIE.
    """
    eg = SafariIE()
    # test of variable _VALID_URL
    match = re.match(eg._VALID_URL, 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert match is not None
    assert match.group('reference_id') is None
    assert match.group('course_id') is not None
    assert match.group('course_id') == '9780133392838'
    assert match.group('part') is not None
    assert match.group('part') == 'part00'
    # test of variable _TESTS
    assert eg._TESTS is not None
    assert len(eg._TESTS)

# Generated at 2022-06-24 13:05:58.830959
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from ..test.test_downloader import FakeYDL
    from unittest.case import TestCase

    class SafariBaseIETestCase(TestCase):
        def setUp(self):
            self.ydl = FakeYDL()
            self.ie = SafariBaseIE(self.ydl)
            self.ie._login()

    # This test only makes sure that the _login method does not throw an exception
    SafariBaseIETestCase('test_SafariBaseIE').runTest()

# Generated at 2022-06-24 13:06:02.437637
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE('Safari', 'safaribooksonline')
    if safari_ie is None:
        print ('Test failed. safari_ie is None!')


# Generated at 2022-06-24 13:06:14.870098
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .generic_extractor import GenericIE
    from .common import FakeIE

    class MockSafariApiIE(SafariApiIE):
        def _real_extract(self, url):
            pass

    MockSafariApiIE('MockSafariApiIE', 'safaribooksonline.com')

    try:
        MockSafariApiIE('MockSafariApiIE', 'safaribooksonline.de')
    except ExtractorError:
        pass
    else:
        assert False, 'Should have raised'

    try:
        SafariApiIE('MockSafariApiIE', 'safaribooksonline.de')
    except ExtractorError:
        pass
    else:
        assert False, 'Should have raised'


# Generated at 2022-06-24 13:06:15.515562
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-24 13:06:17.120434
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE('')
    assert ie.LOGGED_IN is False

# Generated at 2022-06-24 13:06:18.692504
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # No-op just to call constructor
    SafariBaseIE()

# Generated at 2022-06-24 13:06:29.938129
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test document
    try:
        from bs4 import BeautifulSoup
    except ImportError:
        raise ImportError('To run these tests, you need to install BeautifulSoup4 from requirements.txt')
    assert isinstance(BeautifulSoup, object)

    assert isinstance(SafariCourseIE, object)

    assert hasattr(SafariCourseIE, 'suitable')
    assert callable(getattr(SafariCourseIE, 'suitable'))

    assert not hasattr(SafariCourseIE, '_real_extract')
    assert not hasattr(SafariCourseIE, '_real_initialize')
    assert not hasattr(SafariCourseIE, '_login')

    assert not hasattr(SafariCourseIE, 'IE_NAME')

# Generated at 2022-06-24 13:06:36.018467
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url_with_course_id = 'http://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    course_id = '9780133392838'
    assert SafariCourseIE.suitable(url_with_course_id)
    SafariCourseIE(SafariCourseIE.ie_key(), url_with_course_id)
    assert SafariCourseIE._VALID_URL.match(url_with_course_id).group('id') == course_id

# Generated at 2022-06-24 13:06:42.718476
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # test success
    SafariBaseIE('safaribooksonline', {
            'email': 'my@email.com',
            'password': 'mypassword',
        })

    # test error handling
    try:
        SafariBaseIE('safaribooksonline', {
            'email': 'my@email.com',
        })
    except ExtractorError:
        pass
    else:
        assert False

# Generated at 2022-06-24 13:06:44.216187
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course = SafariCourseIE('SafariCourseIE')
    assert course is not None

# Generated at 2022-06-24 13:06:52.615155
# Unit test for constructor of class SafariCourseIE

# Generated at 2022-06-24 13:07:01.450893
# Unit test for constructor of class SafariApiIE

# Generated at 2022-06-24 13:07:11.327014
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    mobj = re.match(SafariApiIE._VALID_URL, url)
    expected_url = 'https://www.safaribooksonline.com/library/view/learning-javascript-data/9781449396459/part00.html'
    _, urlh = SafariApiIE()._download_webpage_handle(
        url, '9781449396459/chapter/part00.html')
    assert urlh.geturl() == expected_url

# Generated at 2022-06-24 13:07:21.744964
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE._download_webpage = lambda x: '<a href="http://www.safaribooksonline.com/home/">some text</a>'
    SafariBaseIE._download_json = lambda x, y, z, a, b, headers: {'logged_in': True, 'redirect_uri': 'http://some-redirect-url.com/'}
    SafariBaseIE._apply_first_set_cookie_header = lambda x, y: None
    SafariBaseIE.url_result = lambda x, y, z: None

# Generated at 2022-06-24 13:07:24.089316
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safariBaseTest = SafariBaseIE('SafariBaseIE')
    assert safariBaseTest._NETRC_MACHINE == 'safari'

# Generated at 2022-06-24 13:07:31.306147
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Constructor safari.SafariIE takes two params:
    # The first param is the URL of the page containing the page and the second param is the course_id
    # The course_id is optional and if it is not provided, it will be extracted from the URL
    safari_ie = SafariIE('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert safari_ie.IE_NAME == 'safari'
    assert safari_ie.IE_DESC == 'safaribooksonline.com online video'

# Generated at 2022-06-24 13:07:39.161579
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    TEST_CASE = 'https://www.safaribooksonline.com/library/view/python-in-a/9781789531620/'
    SafariCourseIE._login = lambda _: (None, None)
    SafariCourseIE._download_json = lambda _, url: {'chapters': [{'web_url': TEST_CASE}]}
    SafariCourseIE._real_initialize = lambda _: (None, None)
    SafariCourseIE._real_extract = SafariCourseIE._download_json
    SafariCourseIE.suitable = lambda _: True
    extractor = SafariCourseIE()
    assert extractor.playlist_count == 1
    assert extractor.playlist[0] == TEST_CASE

# Generated at 2022-06-24 13:07:46.744033
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://learning.oreilly.com/library/view/php-cookbook-3rd/9781449393102/'
    # calling constructor of SafariCourseIE class
    instance = SafariCourseIE()
    # info_dict = instance._real_extract(url)
    # Extracting info_dict
    course_id = instance._match_id(url)
    course_json = instance._download_json(
        '%s/book/%s/?override_format=%s' % (instance._API_BASE, course_id, instance._API_FORMAT),
        course_id, 'Downloading course JSON')
    if 'chapters' not in course_json:
        raise ExtractorError(
            'No chapters found for course %s' % course_id, expected=True)

# Generated at 2022-06-24 13:07:50.357241
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert SafariApiIE('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')

# Generated at 2022-06-24 13:08:00.656533
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .test_common import results_json


    html_file = 'SafariBook/part00.html'
    safari_api_ie = SafariApiIE()
    safari_api_ie.to_screen = lambda *args, **kargs: None

    # The following function doesn't exist
    safari_api_ie._download_json = lambda url, video_id, msg, exception_msg, fatal: results_json

    # This is what we're testing
    result = safari_api_ie._real_extract(html_file)

    # The result should be a SafariIE.url_result
    assert result['ie_key'] == SafariIE.ie_key()

    # It should have a Kaltura url
    #  which contains the JSON from results_json