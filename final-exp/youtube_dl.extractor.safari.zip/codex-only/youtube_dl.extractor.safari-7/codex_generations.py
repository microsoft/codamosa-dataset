

# Generated at 2022-06-24 12:58:07.241871
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import hashlib
    from .common import unescapeHTML
    from .test_youtube_dl import YoutubeDLGz

    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    ie = SafariIE()
    downloader = YoutubeDLGz(ie, params={'skip_download': True})
    course = downloader.extract(url)
    assert course['id'] == '0_qbqx90ic'
    assert unescapeHTML(course['title']) == 'Introduction to Hadoop Fundamentals LiveLessons'

# Generated at 2022-06-24 12:58:12.457297
# Unit test for constructor of class SafariIE
def test_SafariIE():
    x = SafariIE()
    assert x._VALID_URL == 'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?#&]+)\.html|videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?#&]+))'

# Generated at 2022-06-24 12:58:19.701445
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    sb = SafariBaseIE()
    assert sb._NETRC_MACHINE == 'safari'
    assert sb._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert sb._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert sb._API_FORMAT == 'json'
    assert sb.LOGGED_IN == False

# Test _TESTS in SafariCourseIE

# Generated at 2022-06-24 12:58:23.316401
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    i = SafariApiIE()
    video_url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    i.extract(video_url)


# Generated at 2022-06-24 12:58:30.931709
# Unit test for constructor of class SafariIE
def test_SafariIE():
    def test_fails_without_login(self, url):
        self.assertRaises(ExtractorError, lambda: self.url_result(url))

    safari_ie = SafariIE()
    test_fails_without_login(safari_ie, 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')

# Generated at 2022-06-24 12:58:33.949328
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE('abc', 'def')
    assert safari_ie._API_BASE == 'https://learning.oreilly.com/api/v1'



# Generated at 2022-06-24 12:58:43.413241
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import subprocess
    # check whether the constructor is still good (e.g. doesn't add any extra arguments)
    test_code = str(SafariIE.__init__)
    assert 'def __init__(self' in test_code, 'SafariIE class does not have a constructor'
    test_code = re.sub(r'\s*def\s+__init__\s*\(.*', '', test_code)
    # remove all docstrings
    test_code = re.sub(r'(\'\'\'|"""|\'|")[\s\S]*?\1', '', test_code)
    # remove all annotatations
    test_code = re.sub(r'@.*', '', test_code)
    # remove all try/except

# Generated at 2022-06-24 12:58:47.296798
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .common import test_url_result_class
    test_url_result_class('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json', SafariApiIE, 'safari:api')


# Generated at 2022-06-24 12:58:48.290902
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    _ = SafariBaseIE()

# Generated at 2022-06-24 12:58:50.743342
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    """Unit test for SafariBaseIE testing if the constructor is working correctly."""
    safariBase = SafariBaseIE()
    assert safariBase is not None

# Generated at 2022-06-24 12:58:52.932224
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safariBaseIE = SafariBaseIE()
    assert safariBaseIE.LOGGED_IN == False

# Generated at 2022-06-24 12:58:55.501046
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert SafariApiIE()._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert SafariApiIE()._NETRC_MACHINE == 'safari'
    assert SafariApiIE()._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert SafariApiIE()._API_FORMAT == 'json'

# Generated at 2022-06-24 12:59:00.525801
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    i = SafariApiIE()
    i._real_extract(url)

# Generated at 2022-06-24 12:59:02.807801
# Unit test for constructor of class SafariIE
def test_SafariIE():
    test_SafariIE_instance = SafariIE()
    assert( isinstance(test_SafariIE_instance, SafariIE))

# Generated at 2022-06-24 12:59:07.012629
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Goal: test that SafariBaseIE._real_initialize sets SafariBaseIE.LOGGED_IN to True
    safari_baseie_instance = SafariBaseIE()
    safari_baseie_instance._real_initialize()
    assert safari_baseie_instance.LOGGED_IN == True

# Generated at 2022-06-24 12:59:13.895070
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    assert ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert ie._NETRC_MACHINE == 'safari'
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'
    assert ie.LOGGED_IN == False


# Generated at 2022-06-24 12:59:15.651419
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    IE = SafariBaseIE(None)
    assert not IE.LOGGED_IN

# Generated at 2022-06-24 12:59:18.980717
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course = SafariCourseIE()
    assert safari_course._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_course._API_FORMAT == 'json'

# Generated at 2022-06-24 12:59:28.595922
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from .youtube_dl.YoutubeDL import YoutubeDL
    import os
    import shutil
    import tempfile

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-24 12:59:38.737656
# Unit test for constructor of class SafariIE
def test_SafariIE():

    # Test constructor of class SafariIE
    # Tested constructor:
    # def __init__(self, username, password, *args, **kwargs):
    #
    # Tested init:
    # def _login(self):
    # def _real_initialize(self):
    #
    # Tested methods:
    # def _real_extract(self, url):
    #

    # throw error when username and password are not provided
    # to the constructor of the class SafariIE
    # assuming it is a case where user has not logged in
    # to safaribooksonline.com
    #
    # (1) Test credentials are not provided
    # (2) Test credentials are provided as None

    # (1) Test credentials are not provided
    safari_ie = SafariIE()
    # Test _real_initialize

# Generated at 2022-06-24 12:59:47.715993
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test for SafariBaseIE._build_json_request
    url = 'http://localhost/?a=b'
    json_data = None
    headers = None
    method = None
    result = {}
    result['url'] = url
    result['data'] = json_data
    result['headers'] = headers
    result['method'] = method
    result['expected_status'] = None
    test_result = SafariBaseIE._build_json_request(url, json_data, headers, method)
    assert test_result == result

    # Test for SafariBaseIE._build_json_request
    url = 'http://localhost/?a=b'
    json_data = {'a': 'b'}
    headers = None
    method = None
    result = {}
    result['url'] = url

# Generated at 2022-06-24 12:59:49.409149
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test creating an instance of SafariIE
    SafariIE()

# Generated at 2022-06-24 13:00:02.148026
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test bad title
    with open("tests/title_re.json") as f:
        data = json.loads(f.read())
    for t in data:
        assert SafariIE._VALID_URL.search(t)

    # Test bad title without https
    for t in data:
        assert SafariIE._VALID_URL.search(t.replace('https', 'http'))

    # Test bad title with learning.oreilly.com and .html
    for t in data:
        assert SafariIE._VALID_URL.search(t.replace('.com/', '.com/learning.'))

    # Test bad title with www.oreilly.com and .html
    for t in data:
        assert SafariIE._VALID_URL.search(t.replace('.com/', '.com/www.'))

    # Test bad title

# Generated at 2022-06-24 13:00:03.061812
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safaribaseie = SafariBaseIE()
    assert safaribaseie.LOGGED_IN == False

# Generated at 2022-06-24 13:00:06.069916
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert(safari_ie.LOGGED_IN is True) or (safari_ie.LOGGED_IN is False)
    pass

# Generated at 2022-06-24 13:00:07.863886
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    obj = SafariApiIE
    assert obj(1, 'safari')



# Generated at 2022-06-24 13:00:19.432095
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from . import run_testcases

# Generated at 2022-06-24 13:00:21.726009
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    info_extractor = SafariBaseIE()
    assert info_extractor.IE_NAME == 'safari'

# Generated at 2022-06-24 13:00:23.980195
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """Unit test for constructor of class SafariIE"""
    safari = SafariIE()
    assert type(safari) == SafariIE
    return

# Generated at 2022-06-24 13:00:27.650000
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE("%s/book/3_3BIv/?override_format=json" % SafariBaseIE._API_BASE)

# Generated at 2022-06-24 13:00:36.515578
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import sys
    mod = sys.modules[__name__]
    instance = mod.SafariApiIE('workaround', 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html')
    assert instance._VALID_URL == 'https?://(?:www\\.)?(?:safaribooksonline|(?:learning\\.)?oreilly)\\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\\.html'

# Generated at 2022-06-24 13:00:44.208756
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    fetch_url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    test_json = '{"book_id": "9781449396459", "title": "Learning Python, 5th Edition"}'
    test_dict = {
            'book_id': '9781449396459',
            'title': 'Learning Python, 5th Edition',
    }

    # Arrange
    ie = SafariApiIE(SafariApiIE.ie_key())
    ie._download_webpage = lambda *args, **kargs: test_json

    # Act
    ie._real_extract(fetch_url)
    result = ie.result

    # Assert
    assert result == test_dict


# Generated at 2022-06-24 13:00:52.226067
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course_ie = SafariCourseIE('SafariCourse')
    assert course_ie._VALID_URL == (
        r'https?://(?:www\.)?'
        r'(?:safaribooksonline|(?:learning\.)?oreilly)\.com/'
        r'(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/'
        r'(?P<id>[^/]+)')

# Generated at 2022-06-24 13:01:00.270683
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Tests that if SafariCourseIE.suitable() returns FALSE, then SafariCourseIE is not called
    # by gen_extractors() to produce an extractor
    import sys
    sys.modules['safaricourseie'] = sys.modules['__main__']
    import safari
    with safari.SafariCourseIE._build_extractor() as extractor:
        assert isinstance(extractor, safari.SafariCourseIE)

    del safari.SafariCourseIE._build_extractor

# Generated at 2022-06-24 13:01:11.726987
# Unit test for constructor of class SafariIE
def test_SafariIE():
    input_url = 'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838/9780133392838-00_SeriesIntro'
    expected_output_url = 'https://cdnapisec.kaltura.com/html5/html5lib/v2.37.1/mwEmbedFrame.php?wid=_1926081&uiconf_id=29375172&flashvars%%5BreferenceId%%5D=9780133392838-00_SeriesIntro'
    result = SafariIE()._real_extract(input_url)
    assert type(result) is dict
    assert result['url'] == expected_output_url
    assert result['ie_key'] == 'Kaltura'


# Generated at 2022-06-24 13:01:18.466645
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import unittest
    from .test_common import TestCommon

    class TestSafariIE(unittest.TestCase, TestCommon):
        IE = SafariIE
        _VALID_URL = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'

    unittest.main(argv=[''])

# Generated at 2022-06-24 13:01:23.490266
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import time
    import os
    url = 'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838/9780133392838-00_SeriesIntro'
    safari = SafariApiIE()
    safari.download(url, 'part01')


# Generated at 2022-06-24 13:01:25.547821
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314/9780134217314-PYMC_13_00')

# Generated at 2022-06-24 13:01:27.869556
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie._VALID_URL
    assert ie._TESTS
    assert ie._LOGIN_URL
    assert ie._NETRC_MACHINE


# Generated at 2022-06-24 13:01:31.536711
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    class MockSafariCourseIE(SafariCourseIE):
        # mock _download_json to avoid making HTTP requests
        def _download_json(self, *args, **kwargs):
            pass

    mock_ie = MockSafariCourseIE()
    assert isinstance(mock_ie, SafariCourseIE)

# Generated at 2022-06-24 13:01:36.262875
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE(None)
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'

    ie = SafariBaseIE(None, {'username': 'test_username'})
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'

# Generated at 2022-06-24 13:01:36.821901
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()


# Generated at 2022-06-24 13:01:49.518224
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    course_id = '9780133392838'
    url = 'https://www.safaribooksonline.com/api/v1/book/' + course_id + '/chapter/part00.html'
    safari_api_ie = SafariApiIE(SafariBaseIE)
    chapter = safari_api_ie._real_extract(url)
    assert chapter['id'] == '0_qbqx90ic'

# Generated at 2022-06-24 13:01:52.793987
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari = SafariApiIE()
    assert safari.IE_NAME == 'safari:api'
    assert safari.IE_DESC == 'safaribooksonline.com online video'

# Generated at 2022-06-24 13:02:04.377515
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import platform
    import sys

    if not platform.platform().startswith('Linux') or sys.version_info < (2, 6):
        raise ValueError('class SafariIE can only be tested in linux, python 2.6+')

    import os
    import subprocess

    def test_utils_get_netrc_auth_tuple():
        if os.path.exists(os.path.expanduser('~/.netrc')):
            open(os.path.expanduser('~/.netrc'), 'w').write("""
machine www.safaribooksonline.com
    login safaritest
    password safaritest
""")
        else:
            raise ValueError('no .netrc file, ignore')


# Generated at 2022-06-24 13:02:05.142289
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    obj = SafariBaseIE()
    assert obj is not None

# Generated at 2022-06-24 13:02:08.580906
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # unit test for _get_login_info()
    IE = SafariCourseIE("http://techbus.safaribooksonline.com/9780134426365")
    login_info = IE._get_login_info()
    assert login_info == ('username', 'password')


# Generated at 2022-06-24 13:02:09.070953
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()

# Generated at 2022-06-24 13:02:12.572029
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # TODO: This test is not really testing anything, it just checks if it
    # doesn't crash if you don't have cookies
    SafariCourseIE()._download_json('https://www.safaribooksonline.com/api/v1/book/9781565922259/', None, 'Downloading course JSON')

# Generated at 2022-06-24 13:02:14.473016
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    class_name = 'SafariCourseIE'
    obj = globals()[class_name]()
    assert obj.__name__ == class_name

# Generated at 2022-06-24 13:02:17.150565
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE('http://techbus.safari', 'techbus.safari')
    assert safari_ie._TEST == False


# Generated at 2022-06-24 13:02:17.863475
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    pass

# Generated at 2022-06-24 13:02:24.929551
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE('Test', 'Unit test video', 'https://cdnapisec.kaltura.com/html5/html5lib/v2.37.1/mwEmbedFrame.php?wid=_1926081&uiconf_id=29375172&flashvars[referenceId]=9c94c4d4c68ae8ddb93255b97f54b61d&flashvars[ks]=')

# Generated at 2022-06-24 13:02:26.223615
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE({})

# Generated at 2022-06-24 13:02:39.675951
# Unit test for constructor of class SafariIE

# Generated at 2022-06-24 13:02:49.178251
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class TestSafariBaseIE(SafariBaseIE):
        IE_NAME = 'TestSafariBaseIE'

    inst = TestSafariBaseIE(fake_url='http://www.safaribooksonline.com/test.html')
    assert inst.ie_key() == 'SafariBaseIE'
    assert inst._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert inst._NETRC_MACHINE == 'safari'
    assert inst.IE_NAME == 'TestSafariBaseIE'
    assert inst._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert inst._API_FORMAT == 'json'
    assert not inst.LOGGED_IN

# Generated at 2022-06-24 13:02:56.860249
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # TODO: Required because of https://github.com/rg3/youtube-dl/issues/9715
    from .test_m3u8_variants import M3U8_URL, M3U8_FORMATS
    from .test_common import FakeHttpServer
    from .test_youtube_dl import YoutubeDL
    from .test_parser import parse_json
    from .test_m3u8_variants import get_m3u8_formats

    import requests
    import sys
    import threading
    import time

    # As the http server needs to be running
    # on default port, we need to start a separate
    # http server thread, which will be shutdown
    # by test_main
    httpd = None
    httpd = FakeHttpServer()
    httpd.serve_content('ok')
    thread

# Generated at 2022-06-24 13:03:01.270942
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import pytest


# Generated at 2022-06-24 13:03:03.090795
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    test_class = SafariCourseIE()

# Generated at 2022-06-24 13:03:11.763012
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/') is True
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/') is True
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314') is True
    assert SafariCourseIE.suitable('http://techbus.safaribooksonline.com/9780134426365') is True
    assert SafariCourseIE.suitable('https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838')

# Generated at 2022-06-24 13:03:15.193545
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # type: () -> None
    # assert SafariCourseIE is not None
    # print('safari', IE_NAME, IE_DESC)
    print(SafariCourseIE)

# Generated at 2022-06-24 13:03:22.851487
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safaribooksonline_netrc_machine = 'safaribooksonline'
    safari_netrc_machine = 'safari'
    ie = SafariBaseIE(safaribooksonline_netrc_machine)
    assert ie._NETRC_MACHINE == safaribooksonline_netrc_machine
    ie = SafariBaseIE(safari_netrc_machine)
    assert ie._NETRC_MACHINE == safari_netrc_machine

# Generated at 2022-06-24 13:03:24.011505
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api = SafariApiIE('safari:api')
    assert(safari_api.IE_NAME == 'safari:api')

# Generated at 2022-06-24 13:03:24.694044
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test empty input
    SafariApiIE()

# Generated at 2022-06-24 13:03:30.108398
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Smoke test
    s = SafariApiIE()
    assert isinstance(s.IE_DESC, basestring)
    assert isinstance(s.IE_NAME, basestring)
    assert hasattr(s, 'suitable')
    assert hasattr(s, '_real_extract')

# Generated at 2022-06-24 13:03:34.140011
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Arrange
    username = 'test'
    password = 'test'
    test_obj = SafariBaseIE(None)

    # Act
    test_obj._login(username, password)

# Unit test class SafariIE

# Generated at 2022-06-24 13:03:37.532667
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    try:
        return SafariApiIE(None, 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    except TypeError as e:
        return False

# Generated at 2022-06-24 13:03:41.280434
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .. import monkey
    with monkey.monkey_patch():
        SafariApiIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')


# Generated at 2022-06-24 13:03:42.365122
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('safari')

# Generated at 2022-06-24 13:03:44.053520
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE({})
    assert not ie.LOGGED_IN

# Generated at 2022-06-24 13:03:46.782239
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert ie.IE_NAME == 'safari:api'
    assert ie.IE_DESC == 'safaribooksonline.com API'

# Generated at 2022-06-24 13:03:51.042685
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/c10-00.html'
    safariApiIE = SafariApiIE()
    safariApiIE.suitable(url)
    safariApiIE._real_extract(url)

# Generated at 2022-06-24 13:03:59.729387
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test the constructor. The code that tries to login is not tested here
    # as it depends on the netrc_machine setting.
    safari_api_ie = SafariApiIE('safari:api')

    # Test the method _real_extract(). This method downloads the JSON
    # representation of a course part and just returns the web_url field.
    # The web_url field is then passed on to SafariIE which handles the
    # actual video extraction.
    # Extracting video information from the web_url is tested in test_SafariIE.
    web_url = safari_api_ie._real_extract('https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part01.html')

# Generated at 2022-06-24 13:04:01.866428
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()
    assert safari_api_ie.ie_key() == 'SafariApiIE'

# Generated at 2022-06-24 13:04:11.959845
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    def inspect_login(self):
        inspection = {
            'LOGGED_IN': self.LOGGED_IN,
            'url': self._downloader.urlopen.call_args_list[0][0][0]
        }
        return inspection

    class DummySafariBaseIE(SafariBaseIE):
        _LOGIN_URL = 'login'

        def __init__(self, downloader=None):
            super(DummySafariBaseIE, self).__init__(downloader=downloader)
            self.inspect_login = inspect_login.__get__(self)

        def _login(self):
            pass

    class DummyDownloader():
        def __init__(self, username=None, password=None):
            self.username = username
            self.password = password

       

# Generated at 2022-06-24 13:04:16.395385
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """
    Unit test for class SafariCourseIE
    """
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    safari = SafariCourseIE(url = url)
    assert safari.ie_key() == 'Safari'
    assert safari.suitable(url = url)
    assert safari.IE_DESC == 'safaribooksonline.com online courses'
    assert safari.IE_NAME == 'safari:course'

# Generated at 2022-06-24 13:04:29.206323
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from utils import make_HTTPServer, test_cases
    from pytest import raises

    Video = object()

    class MockSafariIE(SafariIE):
        _TESTS = test_cases.copy()

        @classmethod
        def ie_key(cls):
            return 'safari'

        def _real_extract(self, url):
            return Video

    class MockSafariApiIE(SafariApiIE):
        _TESTS = test_cases.copy()

        @classmethod
        def ie_key(cls):
            return 'safari:api'

        def _real_extract(self, url):
            return Video

    safarie = MockSafariIE()
    safarie_api = MockSafariApiIE()


# Generated at 2022-06-24 13:04:35.709311
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    test_credentials = (
        (None, None),
        ('user@safaribooksonline.com', 'password'),
        ('user', 'password@safaribooksonline.com'),
    )
    for username, password in test_credentials:
        safari_base = SafariBaseIE()
        safari_base._login_info = (username, password)
        safari_base._login()

# Generated at 2022-06-24 13:04:37.905185
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test of non-digits course_id
    SafariApiIE('non-digits')  # this should not raise an error

# Generated at 2022-06-24 13:04:41.897799
# Unit test for constructor of class SafariIE
def test_SafariIE():
    '''Unit Test: Test constructor of class SafariIE'''
    # Constructor of class SafariIE creates an object.
    ie = SafariIE("", "")
    # SafariIE object is instance of class InfoExtractor
    assert ie.__class__ == InfoExtractor


# Generated at 2022-06-24 13:04:54.505448
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # pylint: disable=protected-access
    constructor = SafariApiIE._build_youtube_url
    class youtube_url:
        query = {}
    # test url with valid url
    url = "https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html"
    youtube_url.url = url
    test_url = constructor(youtube_url)
    assert test_url == "https://cdnapisec.kaltura.com/html5/html5lib/v2.37.1/mwEmbedFrame.php?wid=_1926081&uiconf_id=29375172&flashvars[referenceId]=221897"
    # test url with inavlid url

# Generated at 2022-06-24 13:04:55.946946
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    ie._real_initialize()

# Generated at 2022-06-24 13:05:05.841589
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safe_eval = getattr(__import__('ast'), 'literal_eval', lambda s: s)
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'

# Generated at 2022-06-24 13:05:16.159210
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE('safari:course')
    assert isinstance(ie, SafariCourseIE)
    assert ie.ie_key() == 'safari:course'
    assert ie.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/') == True
    assert ie.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json') == False
    assert ie.suitable('http://techbus.safaribooksonline.com/9780134426365') == True
    assert ie.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314') == True


# Generated at 2022-06-24 13:05:17.895693
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert SafariIE().ie_key() == 'Safari'


# Generated at 2022-06-24 13:05:19.611627
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    result = SafariBaseIE()
    assert result

# Generated at 2022-06-24 13:05:30.467084
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from selenium import webdriver
    from .test.test_download_common import (
        get_testcases_by_list, get_testcases_by_md5, file_test, md5_test)

# Generated at 2022-06-24 13:05:31.315208
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()



# Generated at 2022-06-24 13:05:32.594218
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE(None)
    assert ie.IE_NAME == 'safari'

# Generated at 2022-06-24 13:05:36.926400
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()
    assert(safari.LOGGED_IN == False)

    safari._login()
    assert(safari.LOGGED_IN == True)

# Generated at 2022-06-24 13:05:42.723742
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE.suitable('http://techbus.safaribooksonline.com/9780134426365')
    assert not SafariCourseIE.suitable('http://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838/9780133392838-00_SeriesIntro')


# Generated at 2022-06-24 13:05:44.617822
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert not ie.LOGGED_IN

# Generated at 2022-06-24 13:05:45.052058
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-24 13:05:47.942275
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .test import get_testcases
    instance = SafariIE()
    for inputs, expected in get_testcases(__name__, 'test').items():
        assert instance._real_extract(inputs) == expected

# Generated at 2022-06-24 13:05:49.832152
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert 'safaribooksonline.com' in SafariApiIE._VALID_URL

# Generated at 2022-06-24 13:05:53.944970
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    constructor = SafariApiIE.suitable("https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json")
    assert constructor

# Generated at 2022-06-24 13:05:55.832336
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    test = SafariApiIE()
    assert test

# Generated at 2022-06-24 13:06:06.892420
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """Test the constructor of class SafariCourseIE."""
    # Test URL of the form
    # https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/
    SafariCourseIE().suitable(
        'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')

    # Test URL of the form
    # https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json
    SafariCourseIE().suitable(
        'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')

    #

# Generated at 2022-06-24 13:06:08.725065
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie._VALID_URL == SafariIE._VALID_URL

# Generated at 2022-06-24 13:06:13.272879
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_courseIE = SafariCourseIE()

    assert(not safari_courseIE.suitable(
        'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'))

    assert(not safari_courseIE.suitable(
        'http://techbus.safaribooksonline.com/9780134426365'))

    assert(not safari_courseIE.suitable(
        'https://www.safaribooksonline.com/videos/python-programming-language/9780134217314'))

    assert(not safari_courseIE.suitable(
        'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838'))


# Generated at 2022-06-24 13:06:17.870256
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.IE_NAME == 'safari'
    assert safari_ie.IE_DESC == 'safaribooksonline.com online video'



# Generated at 2022-06-24 13:06:26.387628
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    course_id = '9781449396459'
    course_name = 'playbook-for-developers-and-operators'
    part = 'part02'
    url = 'https://www.safaribooksonline.com/api/v1/book/' + course_id + '/chapter/' + part + '.html'
    ie = SafariApiIE()
    mobj = ie._VALID_URL_RE.match(url)
    assert(mobj)
    assert(mobj.group('id') == course_id)

# Generated at 2022-06-24 13:06:32.838845
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import mwclient
    import requests
    from mock import patch

    class fake_Session:

        def __init__(self, test_username, test_password, test_site_url):
            self.username = test_username
            self.password = test_password
            self.site_url = test_site_url

        def login(self):
            pass

        def request(self, test_req_type, test_req_url, test_data=None, test_headers=None):
            class fake_Response():
                ok = True
                text = ""
                def json(self):
                    return {
                        'logged_in': True,
                        'redirect_uri': test_url
                    }
            return fake_Response()

        def call(self, test_method, test_data):
            return None


# Generated at 2022-06-24 13:06:34.932563
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    my_SafariBase = SafariBaseIE()
    my_SafariBase.initialize()

# Generated at 2022-06-24 13:06:38.095988
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE('safari:api')

# Generated at 2022-06-24 13:06:41.073443
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    obj = SafariBaseIE('http://techbus.safaribookonline.com/9780134664057')
    assert obj.__module__ == 'safari'

# Generated at 2022-06-24 13:06:42.524447
# Unit test for constructor of class SafariIE
def test_SafariIE():
    x = SafariIE()
    assert x._NETRC_MACHINE == 'safari'

# Generated at 2022-06-24 13:06:43.172878
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-24 13:06:43.808897
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-24 13:06:44.447247
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE(None)

# Generated at 2022-06-24 13:06:50.838103
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    t = SafariBaseIE(SafariCourseIE, SafariCourseIE._VALID_URL)
    assert t.LOGGED_IN == False
    assert t.username == None
    assert t.password == None
    t.username = "test@test.com"
    t.password = "test"
    assert t.username == "test@test.com"
    assert t.password == "test"

# Generated at 2022-06-24 13:06:59.614060
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .test_suites.safari import ctx
    ctx.info_dict['classes'] = SafariCourseIE.__name__
    ctx.suite.run_from_cli = True
    ctx.suite.run()

from collections import namedtuple

from ..utils import (
    parse_duration,
    qualities,
)

from .common import InfoExtractor

from ..compat import (
    compat_HTTPError,
    compat_str,
)
from ..utils import (
    ExtractorError,
    float_or_none,
    parse_filesize,
    sanitized_Request,
)



# Generated at 2022-06-24 13:07:07.102123
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import tempfile
    from .common import USER_AGENT
    from .utils import fake_http_headers

    (http_server, http_port) = test_http_server()

    class _FakeServerHandler(RequestHandler):
        def do_GET(self):
            request_path = self.path


# Generated at 2022-06-24 13:07:18.473342
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    Constructor = SafariCourseIE.IE_CLASS(SafariCourseIE.ie_key())
    ie = Constructor()
    assert ie.IE_NAME == 'safari:course'
    assert ie.IE_DESC == 'safaribooksonline.com online courses'
    assert ie.SUCCEEDED == 0
    assert ie.FAILED == 0
    assert ie.SUCCEEDED == 0
    assert ie._VALID_URL == cls._VALID_URL
    assert ie._TESTS == cls._TESTS
    assert ie._TEST == {}
    assert ie._downloader is None
    assert ie._download_webpage

# Generated at 2022-06-24 13:07:26.087390
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    ext = SafariCourseIE().suitable(url)
    assert ext != False

    # Add a new class variable to this class.
    SafariCourseIE.LOGGED_IN = True

    ext = SafariCourseIE().suitable(url)
    # This should return false because we're logged in but it's a course page.
    assert ext == False

    # Remove the class variable from class SafariCourseIE
    del SafariCourseIE.LOGGED_IN

# Generated at 2022-06-24 13:07:27.190713
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Functionality somewhat tested in test_safari.py
    pass

# Generated at 2022-06-24 13:07:37.422150
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert SafariIE.suitable("https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html") == True
    assert SafariIE.suitable("https://www.safaribooksonline.com/library/view/create-a-nodejs/100000006A0210/part00.html") == True
    assert SafariIE.suitable("https://www.safaribooksonline.com/library/view/learning-path-red/9780134664057/RHCE_Introduction.html") == True
    assert SafariIE.suitable("https://www.safaribooksonline.com/videos/python-programming-language/9780134217314/9780134217314-PYMC_13_00") == True

# Generated at 2022-06-24 13:07:39.154161
# Unit test for constructor of class SafariIE
def test_SafariIE():
    i = SafariIE()
    assert(i.__class__.__name__ == 'SafariIE')

# Generated at 2022-06-24 13:07:39.741141
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-24 13:07:45.265387
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    expect_true = [('netrc', True), ('username', 'myuser'), ('password', 'mypassword'), ('login_form', None)]
    expect_false = [('netrc', False), ('username', 'myuser'), ('password', 'mypassword'), ('login_form', None)]

    # Expect True because of netrc
    sb = SafariBaseIE(expect_true)
    assert(sb.LOGGED_IN == True)

    # Expect False because of incorrect password
    sb = SafariBaseIE(expect_false)
    assert(sb.LOGGED_IN == False)

# Generated at 2022-06-24 13:07:48.229435
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    IE = SafariApiIE()
    assert IE.LOGGED_IN is False

# Generated at 2022-06-24 13:07:49.112190
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    t = SafariBaseIE()
    assert not t.LOGGED_IN

# Generated at 2022-06-24 13:07:59.957199
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from youtube_dl.cipher import (
        js_to_json,
        to_js,
        loads_json,
    )
    from json.scanner import JSONDecodeError

    # Old JSON is provided as an argument in eval method of the javascript code
    # thus, it's required to prepare the first argument for eval method
    def prepare_json(json_str):
        return json_str.replace('"', '\\"')

    # Loads JSON from the javascript code
    def loads_json_from_js(js_code):
        # Prepare the javascript code to be executed in a safe way
        js_code = js_to_json(js_code)
        # Try to get the first argument passed in the eval call