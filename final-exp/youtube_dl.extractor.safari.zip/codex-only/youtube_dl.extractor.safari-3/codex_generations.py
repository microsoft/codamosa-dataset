

# Generated at 2022-06-24 12:58:00.483035
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE('safari:course')
    assert ie.IE_NAME == ie.get_ie_key()
    assert ie.IE_DESC == ie.get_ie_description()
    assert ie.valid_url == ie._VALID_URL

# Generated at 2022-06-24 12:58:02.629016
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    i = SafariBaseIE()
    assert i._NETRC_MACHINE

# Generated at 2022-06-24 12:58:08.815318
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    try:
        # pylint: disable=attribute-defined-outside-init
        class _SafariApiIE(SafariApiIE):
            def __init__(self, *args, **kwargs):
                super(_SafariApiIE, self).__init__(*args, **kwargs)
                self._downloader = None
    except TypeError:
        raise

    SafariApiIE('http://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')

# Generated at 2022-06-24 12:58:11.382567
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    '''
    Test whether a SafariCourseIE class is created
    '''
    safari = SafariCourseIE()
    assert isinstance(safari, SafariCourseIE)

# Generated at 2022-06-24 12:58:19.146147
# Unit test for constructor of class SafariIE
def test_SafariIE():
    try:
        SafariBaseIE('')
    except:
        assert False, 'constructor of  SafariBaseIE throw error'
    try:
        SafariIE('')
    except:
        assert False, 'constructor of  SafariIE throw error'
    try:
        SafariApiIE('')
    except:
        assert False, 'constructor of  SafariApiIE throw error'
    try:
        SafariCourseIE('')
    except:
        assert False, 'constructor of  SafariCourseIE throw error'

# Generated at 2022-06-24 12:58:30.981237
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    httpretty.HTTPretty.allow_net_connect = False

    # Mocking oreilly login page
    url = 'https://learning.oreilly.com/accounts/login/'
    body = '{"status":"failure","html":"Login form html"}'
    httpretty.HTTPRetty.register_uri(
        httpretty.HTTPRetty.GET, url, body=body)

    # Mocking oreilly login attempt
    url = 'https://www.oreilly.com/member/auth/login/'
    body = ''
    httpretty.HTTPRetty.register_uri(
        httpretty.HTTPRetty.POST, url, body=body)

    # Mocking oreilly home page
    url = 'https://learning.oreilly.com/home/'

# Generated at 2022-06-24 12:58:34.538595
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safariCourseIE = SafariCourseIE()
    assert safariCourseIE.IE_NAME == 'safari:course'
    assert safariCourseIE.IE_DESC == 'safaribooksonline.com online courses'


# Generated at 2022-06-24 12:58:39.590745
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from ..test import get_testcases
    from .common import BaseIE

    INSTANCES = {
        'SafariApiIE': SafariApiIE,
    }

    for name, class_ in INSTANCES.items():
        for test_case in get_testcases(name, [class_]):
            BaseIE._build_match_pattern(test_case[0], test_case[1])

# Generated at 2022-06-24 12:58:45.649629
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from ..test_utils import make_mocked_request

    course_id = '9780134664057' # course_id for RHEL-8-System-Administrators-Guide-Preview
    webpage = make_mocked_request(SafariCourseIE._TESTS[0]['url'], content=None).text

    safari_course_ie = SafariCourseIE(make_mocked_request(None, webpage=webpage))

    assert safari_course_ie._download_json(
               'https://www.safaribooksonline.com/api/v1/book/9780134664057',
               course_id, 'Downloading course JSON') is not None

# Generated at 2022-06-24 12:58:53.583000
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    if __name__ == '__main__':
        print('Test SafariCourseIE')
        safari_course_ie = SafariCourseIE()
        safari_course_ie._real_initialize()
        # TODO: find a good way to unit test this constructor
        # without testing here gives the error:
        # unittest.case.SkipTest: Skipping safari.safari_course.test_SafariCourseIE.<lambda> (reason: 'Requires safaribooksonline account credentials')

# Generated at 2022-06-24 12:58:58.839207
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/') == True
    assert SafariCourseIE.suitable('https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838') == True
    assert SafariCourseIE.suitable('https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838/9780133392838-BK_RHCE_1_02') == False
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json') == False
    return

# Generated at 2022-06-24 12:59:09.323897
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    course_id = '9781449396459'
    mobj = re.match('^https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/([^/]+)/chapter/([^/?#&]+)\.html$', 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/A_Matter_of_Time.html')

# Generated at 2022-06-24 12:59:12.099266
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert(ie.IE_NAME == 'safari:api')

# Generated at 2022-06-24 12:59:15.204830
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .test_main_page import test_main_page
    test_main_page(SafariIE.suitable, SafariIE.IE_NAME, __file__)

# Generated at 2022-06-24 12:59:25.694751
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course = SafariCourseIE('/library/view/test/test/')
    assert course.course_id == 'test'
    assert course._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert course._API_FORMAT == 'json'
    assert course._VALID_URL == r'''(?x)
                    https?://
                        (?:
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+|
                                api/v1/book|
                                videos/[^/]+
                            )|
                            techbus\.safaribooksonline\.com
                        )
                        /(?P<id>[^/]+)
                    '''

# Generated at 2022-06-24 12:59:36.382290
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .test_safari import FakeSafariCourseIE

    # Test constructor
    safari_course = FakeSafariCourseIE()

    # Test get_chapter_url method
    assert safari_course.get_chapter_url('9780133392838/part00.html') == \
        'https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html?override_format=json'

    # Test get_chapter_url method
    assert safari_course.get_course_url('9780133392838') == \
        'https://www.safaribooksonline.com/api/v1/book/9780133392838?override_format=json'

# Generated at 2022-06-24 12:59:37.776938
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course = SafariCourseIE()
    assert course.IE_NAME == 'safari:course'

# Generated at 2022-06-24 12:59:42.652881
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Intentionally use URL with no course ID, which should raise an Exception
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/111.html'
    with pytest.raises(ExtractorError):
        SafariCourseIE()._real_extract(url)

# Generated at 2022-06-24 12:59:43.651718
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    assert isinstance(ie, SafariCourseIE)

# Generated at 2022-06-24 12:59:45.706379
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE('test')
    assert ie.IE_NAME == 'safari:api'
    assert ie.IE_DESC == 'safaribooksonline.com online video'

# Generated at 2022-06-24 12:59:53.996008
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """
    Unit test for constructor of class SafariIE.
    """

    # Create a SafariIE object
    safari_ie = SafariIE()

    # Assert method defined for SafariIE
    assert safari_ie.extract_from_url is not None
    assert safari_ie.suitable is not None

    # Assert method defined
    assert safari_ie._callback is not None
    assert safari_ie._extract_urls is not None
    assert safari_ie._extract_count is not None
    assert safari_ie._real_extract is not None

    # Assert method defined
    assert safari_ie._download_json is not None
    assert safari_ie._download_json_handle is not None
    assert safari_ie._download_webpage is not None
    assert safari_ie._

# Generated at 2022-06-24 12:59:58.627467
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari = SafariBaseIE()
    assert safari.get_testcases() == []
    assert safari.suitable('https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838')

# Generated at 2022-06-24 13:00:00.430478
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-24 13:00:11.532082
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .test_html5 import FakeLoginTestCase
    from .npo import NPORadioIE
    from .funimation import FunimationIE
    from .vimeo import VimeoIE
    from .youtube import YouTubeIE
    from .pornhub import PornHubIE
    from .adobepass import AdobePassIE
    from .academicearth import AcademicEarthCourseIE
    from .svt import SVTIE
    from .twitch import TwitchIE
    from .keezmovies import KeezMoviesIE
    from .escapist import EscapistIE
    from .generic import SearchInfoExtractor
    from .openload import OpenloadIE
    from .rtve import RTVEALaCartaIE
    from .viu import ViuIE
    from .verizon import VerizonIE
    from .discoverynetworks import DiscoveryNetworksIE

# Generated at 2022-06-24 13:00:18.256603
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from safari.safari import SafariIE
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    safari = SafariIE()
    safari_iee = safari._real_extract(url)
    log_in_param = safari._LOGIN_URL
    assert(log_in_param == 'https://learning.oreilly.com/accounts/login/')

# Generated at 2022-06-24 13:00:27.972777
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'

    safari_course_test = SafariCourseIE() # instantiate SafariCourseIE
    assert safari_course_test.suitable(url) # test for SafariCourseIE.suitable()
    assert safari_course_test._match_id(url) == '9780133392838' # test for SafariCourseIE._match_id()
    assert safari_course_test._real_extract(url) # test for SafariCourseIE._real_extract()

# Generated at 2022-06-24 13:00:30.843609
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test SafariIE constructor
    safariIE = SafariIE()
    assert safariIE.login_url == "https://learning.oreilly.com/accounts/login/"


# Generated at 2022-06-24 13:00:33.441259
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert SafariApiIE().ie_key() == 'Safari:api'


# Generated at 2022-06-24 13:00:34.131373
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-24 13:00:37.493398
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """ Test the constructor of SafariIE class """
    p = SafariIE('SafariIE', 'Safari Online Video')

    assert p.ie_key() == 'SafariIE'
    assert p.ie_desc() == 'Safari Online Video'

# Generated at 2022-06-24 13:00:39.456212
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    c = SafariApiIE("safari:api")
    assert c.constructor.name == "SafariApiIE"

# Generated at 2022-06-24 13:00:40.375498
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('safari:api')

# Generated at 2022-06-24 13:00:41.951612
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    sbaseie=SafariBaseIE()
    assert sbaseie

# Generated at 2022-06-24 13:00:54.671925
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test main case
    main_case = SafariCourseIE(None)
    assert main_case.IE_NAME == 'safari:course'
    assert main_case.IE_DESC == 'safaribooksonline.com online courses'
    assert main_case._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'

# Generated at 2022-06-24 13:00:55.809880
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    tester = SafariCourseIE()

# Generated at 2022-06-24 13:00:57.150975
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    a = SafariCourseIE()

# Generated at 2022-06-24 13:00:58.792089
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE('safari:course')

# Generated at 2022-06-24 13:01:01.465600
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safariCourseIE = SafariCourseIE()
    url = "http://techbus.safaribooksonline.com/9780134426365"
    assert safariCourseIE._real_extract(url)

# Generated at 2022-06-24 13:01:12.311499
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """ Unit test for constructor of class SafariIE """
    safari_ie = SafariIE()
    assert safari_ie.IE_NAME == 'safari'
    assert safari_ie.IE_DESC == 'safaribooksonline.com online video'

# Generated at 2022-06-24 13:01:23.776490
# Unit test for constructor of class SafariIE
def test_SafariIE():
    class_ = globals()['SafariIE']
    inst = class_()
    assert inst._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/library/view/[^/]+/[^/]+/(?P<part>[^/?\#&]+)\.html'
    assert inst._NETRC_MACHINE == 'safari'
    assert inst._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert inst._API_FORMAT == 'json'
    assert inst.LOGGED_IN == False
    inst._real_initialize();
    assert inst.LOGGED_IN == False
    inst._login();
    assert inst.LOGGED_IN == True

# Generated at 2022-06-24 13:01:25.885029
# Unit test for constructor of class SafariIE
def test_SafariIE():
    s = SafariIE()
    assert not s.LOGGED_IN
    assert not s.suitable('https://www.safaribooksonline.com')

# Generated at 2022-06-24 13:01:34.978425
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api = SafariApiIE('safari:api')
    assert safari_api.IE_NAME == 'safari:api'
    assert safari_api.IE_DESC == 'safaribooksonline.com online courses'
    assert safari_api._VALID_URL == 'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Generated at 2022-06-24 13:01:39.627581
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # This test is meaningless, but we need it to cover SafariIE
    # instantiation for complete code coverage.
    kie1 = SafariIE()
    kie2 = SafariIE()
    assert kie1 == kie2

# Generated at 2022-06-24 13:01:46.089666
# Unit test for constructor of class SafariIE
def test_SafariIE():
    print(SafariIE._VALID_URL)
    # Make sure that SafariIE do no accept SafariCourseIE urls
    assert not SafariIE._VALID_URL.match('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')

# Generated at 2022-06-24 13:01:48.200863
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class MockIE(SafariBaseIE):
        pass
    assert MockIE(MockIE.ie_key())._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'

# Generated at 2022-06-24 13:01:58.022690
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    ie = SafariApiIE(url)
    course_id = ie._match_id(url)
    course_json = ie._download_json(
        '%s/book/%s/?override_format=%s' % (ie._API_BASE, course_id, ie._API_FORMAT),
        course_id, 'Downloading course JSON')
    ie._real_extract(url)

# Generated at 2022-06-24 13:01:58.645006
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-24 13:02:05.325498
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # instantiate class directly
    ie = SafariApiIE()
    # check that it is instance of base class InfoExtractor
    assert ie is not None and isinstance(ie, InfoExtractor)
    # check that it can be instantiated
    obj = ie._real_extract(ie._VALID_URL)
    assert obj is not None and 'web_url' in obj
    # check that it gives back a valid SafariIE url
    assert obj['web_url'] is not None and SafariIE.suitable(obj['web_url'])

# Generated at 2022-06-24 13:02:07.589306
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    args = 'username=TEST&password=TEST&csrfmiddlewaretoken=TEST'
    SafariBaseIE._login_from_form(None, args.encode())

# Generated at 2022-06-24 13:02:09.025738
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    base_ie = SafariBaseIE()
    assert base_ie._API_FORMAT == 'json'



# Generated at 2022-06-24 13:02:16.395796
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """This test makes sure that the
        constructor of class SafariApiIE
        is actually working.
    """

    # Url to test on
    URL = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'

    # Initialize the test
    test_safari_api = SafariApiIE(SafariApiIE.ie_key())
    test_safari_api.initialize()

    # Attempt parsing the url, if this doesn't work,
    # the test has failed
    try:
        test_safari_api._real_extract(URL)
    except:
        assert(False)

# Generated at 2022-06-24 13:02:17.212815
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()

# Generated at 2022-06-24 13:02:17.904454
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-24 13:02:20.922599
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE("example")
    assert safari_api_ie is not None


# Generated at 2022-06-24 13:02:35.024711
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    _, urlh = SafariBaseIE._download_webpage_handle(
        SafariBaseIE._LOGIN_URL, None, 'Downloading login page')
    redirect_url = urlh.geturl()
    parsed_url = compat_urlparse.urlparse(redirect_url)
    qs = compat_parse_qs(parsed_url.query)
    next_uri = compat_urlparse.urljoin(
        'https://api.oreilly.com', qs['next'][0])

    auth, urlh = SafariBaseIE._download_json_handle(
        'https://www.oreilly.com/member/auth/login/', None, None,
        data=b'{}', headers={'Content-Type': 'application/json'},
        expected_status=400)


# Generated at 2022-06-24 13:02:42.159237
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_ie._NETRC_MACHINE == 'safari'
    assert safari_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_ie._API_FORMAT == 'json'
    assert not safari_ie.LOGGED_IN


# Generated at 2022-06-24 13:02:44.043902
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    m_SafariApiIE = SafariApiIE(None)
    assert m_SafariApiIE is not None

# Generated at 2022-06-24 13:02:52.296262
# Unit test for constructor of class SafariCourseIE

# Generated at 2022-06-24 13:02:55.133194
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = dict(SafariIE._download_webpage_handle.func_globals)
    assert safari['SafariIE']._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari['SafariIE']._API_FORMAT == 'json'



# Generated at 2022-06-24 13:02:55.724813
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-24 13:02:58.538106
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # When SafariIE instance is created, SafariIE's _login function
    # is called automatically
    # SafariIE._login function will call safari_book_online.util._get_cookies_for_url
    # to get cookies
    safariIE = SafariIE(SafariIE.ie_key())

# Generated at 2022-06-24 13:03:09.792204
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    if not SafariBaseIE._LOGIN_URL:
        return

    # Test when the auth cookie is already present
    credentials = {
        'name': 'groot_sessionid',
        'value': 'test',
    }
    info_dict = {
        '_type': 'url_transparent',
        'url': 'http://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html',
    }
    instance = SafariBaseIE({}, info_dict, True)
    instance.session.cookies.set(**credentials)
    instance._login()
    assert instance.LOGGED_IN

    # Test when the auth cookie is not present
    instance = SafariBaseIE({}, info_dict, True)
    instance

# Generated at 2022-06-24 13:03:11.790591
# Unit test for constructor of class SafariIE
def test_SafariIE():
    newIE = SafariIE(None)
    assert isinstance(newIE, SafariIE)

# Generated at 2022-06-24 13:03:15.954814
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.IE_NAME == 'safari'

    ie = SafariCourseIE()
    assert ie.IE_NAME == 'safari:course'


# Generated at 2022-06-24 13:03:22.599955
# Unit test for constructor of class SafariIE
def test_SafariIE():
    i = SafariIE()
    assert i._NETRC_MACHINE == 'safari'
    assert i.IE_NAME == 'safari'
    assert i.IE_DESC == 'safaribooksonline.com online video'
    assert i._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''
    assert i._

# Generated at 2022-06-24 13:03:31.633969
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    def check_object(ie, expected_class, expected_logged_in):
        assert isinstance(ie, expected_class)
        assert ie.LOGGED_IN == expected_logged_in

    # Mock object class with a few methods
    class MockSafariBaseIE(SafariBaseIE):
        def _download_webpage_handle(self, *args, **kwargs):
            pass

        def _download_json_handle(self, *args, **kwargs):
            pass

        @classmethod
        def _apply_first_set_cookie_header(cls, *args, **kwargs):
            pass

        def _download_json(self, *args, **kwargs):
            pass

    # Check constructor with a True parameter

# Generated at 2022-06-24 13:03:36.367396
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """
    Test constructor of class SafariCourseIE
    """
    ie = SafariCourseIE()
    ie.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    ie.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    ie.suitable('http://techbus.safaribooksonline.com/9780134426365')
    ie.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314')

# Generated at 2022-06-24 13:03:40.238167
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from unittest import TestCase as _TestCase
    class TestCase(_TestCase):
        def test1(self):
            instance = SafariCourseIE()
            instance._login()
    # Check if has login function
    test = TestCase()
    test.test1()

# Generated at 2022-06-24 13:03:49.057784
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # The constructor of class SafariBaseIE accepts two arguments:
    # self and ie_key. ie_key is assigned to instance attribute ie_key
    # in the constructor, so if it is called with ie_key=None, instance
    # attribute ie_key should be None.
    ie_key = 'test'
    my_SafariBaseIE = SafariBaseIE(ie_key=ie_key)
    assert(my_SafariBaseIE.ie_key() == ie_key)
    my_SafariBaseIE = SafariBaseIE(ie_key=None)
    assert(my_SafariBaseIE.ie_key() == None)

# Generated at 2022-06-24 13:03:49.663774
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    pass

# Generated at 2022-06-24 13:03:56.843955
# Unit test for constructor of class SafariIE
def test_SafariIE():
    if compat_has_attr(SafariIE, 'convert_url_to_id'):
        # class SafariIE has attribute convert_url_to_id,
        # this means the test SafariIE has not been created by constructor.
        # We need to raise an error to exit the unit test.
        raise Exception("Class SafariIE should not have convert_url_to_id")

    if not hasattr(SafariIE, '_SafariIE__convert_url_to_id'):
        raise Exception("SafariIE._SafariIE__convert_url_to_id not found")

# Generated at 2022-06-24 13:04:08.566663
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert ie.LOGGED_IN is False # pylint: disable=E1101
    assert ie._login() is None

    ie._login_info = lambda: (None, None)
    assert ie._login() is None

    ie._login_info = lambda: ('username', 'password')
    ie._download_webpage = lambda *args: ({'url': 'https://example.com/'}, 'urlh')
    ie._download_json = lambda *args: {
        'auth': {
            'credentials': 'Unable to log in',
            'logged_in': False,
            'redirect_uri': None,
        }
    }
    assert ie._login() is None

    ie._login_info = lambda: ('username', 'password')
    ie._download_

# Generated at 2022-06-24 13:04:16.896219
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from unittest import TestCase, main, skipUnless
    from sys import version_info

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    class TestSafariCourseIE(TestCase):
        @skipUnless(version_info.major == 3, 'run this test with python3')
        @patch('youtube_dl.utils.is_outdated', return_value=False)
        @patch('youtube_dl.utils.has_external_program', return_value=False)
        @patch('youtube_dl.SafariBaseIE._login') # to avoid logging in
        def test_suitable(self, mock_login, mock_has_external_program,
        mock_is_outdated):
            from youtube_dl.extractor.safari import SafariCourseIE

           

# Generated at 2022-06-24 13:04:20.115625
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # unit test for SafariApiIE, see https://github.com/rg3/youtube-dl/issues/1686
    obj_SafariApiIE = SafariApiIE('http')

# Generated at 2022-06-24 13:04:21.721702
# Unit test for constructor of class SafariIE
def test_SafariIE():
    print(SafariIE())

# Generated at 2022-06-24 13:04:24.437022
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from . import safari

    assert issubclass(safari.SafariApiIE, safari.SafariBaseIE)

# Generated at 2022-06-24 13:04:31.596351
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()
    url = "https://www.safaribooksonline.com/api/v1/book/9780134664057/chapter/RHCE_Introduction.html"
    expected_id = '9780134664057/RHCE_Introduction'

    actual = re.match(safari_api_ie._VALID_URL, url)

    assert expected_id == actual.group('id')

# Generated at 2022-06-24 13:04:36.133913
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class MockSafariBaseIE(SafariBaseIE):
        def _download_webpage(self, *args, **kwargs):
            pass

        def _download_json(self, *args, **kwargs):
            pass

    MockSafariBaseIE()
    assert True

# Generated at 2022-06-24 13:04:40.152656
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """Unit test for constructor of class SafariApiIE
    """
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    sapi = SafariApiIE(SafariApiIE.suitable(url))
    assert sapi is not None

# Generated at 2022-06-24 13:04:42.401383
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    inst = SafariApiIE()
    assert inst._get_login_info() == (None, None)

# Generated at 2022-06-24 13:04:47.858833
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    import safaribooksonline
    safari = safaribooksonline.SafariCourseIE(SafariCourseIE.ie_key())
    assert safari.IE_NAME == 'safari:course'
    assert safari.IE_DESC == 'safaribooksonline.com online courses'

# Generated at 2022-06-24 13:04:58.788931
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    if not hasattr(InfoExtractor, '_downloader'):
        return

    # Test:
    # 1. SafariBaseIE.__init__() should not raise any exception if
    #    username is not provided.
    # 2. SafariBaseIE.__init__() should raise an exception if
    #    usernaame is provided but password is not provided.
    # 3. SafariBaseIE.__init__() should not raise any exception if
    #    username and password is provided.
    for username, password in [(None, None), (1, None), (1, 2)]:
        try:
            SafariBaseIE._downloader = InfoExtractor._downloader
            ie = SafariBaseIE(username=username, password=password)
        finally:
            ie._downloader = None

# Generated at 2022-06-24 13:05:02.718765
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """
    Unit test for constructor of class SafariIE
    """
    safari_ie = SafariIE(SafariBaseIE())
    assert safari_ie._NETRC_MACHINE == 'safari'
    assert safari_ie.LOGGED_IN == False


# Generated at 2022-06-24 13:05:04.723664
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    E = SafariApiIE(SafariBaseIE)
    E._make_valid_url('foo')  # should not raise

# Generated at 2022-06-24 13:05:09.665338
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari = SafariBaseIE()
    assert safari._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari._NETRC_MACHINE == 'safari'
    assert safari._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari._API_FORMAT ==  'json'
    assert safari.LOGGED_IN == False

# Generated at 2022-06-24 13:05:12.928638
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE(None)
    assert isinstance(safari_api_ie, SafariApiIE)


# Generated at 2022-06-24 13:05:15.142090
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    """
    Class constructor test.
    """
    assert isinstance(SafariBaseIE("test_SafariBaseIE"), SafariBaseIE)


# Generated at 2022-06-24 13:05:27.553657
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    if not SafariBaseIE.LOGGED_IN:
        return('Skipped until SafariApiIE will have credentials as an optional parameter')

    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'

    expected = {
        'md5': 'dcc5a425e79f2564148652616af1f2a3',
        'id': '0_qbqx90ic',
        'ext': 'mp4',
        'title': 'Introduction to Hadoop Fundamentals LiveLessons',
        'timestamp': 1437758058,
        'upload_date': '20150724',
        'uploader_id': 'stork',
    }


# Generated at 2022-06-24 13:05:33.858932
# Unit test for constructor of class SafariCourseIE

# Generated at 2022-06-24 13:05:37.843964
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import sys
    from pytube3 import __main__ as main
    from types import ModuleType
    from unittest.mock import patch

    safari_api = SafariApiIE()

    with patch.object(sys, 'modules', {
            'pytube': ModuleType('pytube'),
            'pytube.__main__': main,
            'pytube.__main__.SafariApiIE': safari_api}):
        sys.argv = [
            __file__, 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part01.html']
        main.main()

# Generated at 2022-06-24 13:05:48.401492
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    class MockSafariBaseIE(SafariBaseIE):
        def _download_json(self, url, video_id, note='', errnote='',
                           fatal=True, headers={}, query={}):
            return {
                'chapters': [
                    'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html',
                    'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part02.html',
                    'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part03.html',
                ]
            }

    info_extractor = MockSafariBaseIE()


# Generated at 2022-06-24 13:05:50.662184
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_ie = SafariCourseIE()
    assert isinstance(safari_course_ie, SafariBaseIE)

# Generated at 2022-06-24 13:05:51.920621
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ex = SafariIE()
    assert ex is not None

# Generated at 2022-06-24 13:05:56.761517
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    inst = SafariBaseIE()
    assert inst._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert inst._API_FORMAT == 'json'
    assert inst.LOGGED_IN == False

# Generated at 2022-06-24 13:05:58.397400
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test case for construction of class SafariBaseIE and its member variables
    safari_base_ie = SafariBaseIE()

    # Test case for member _LOGIN_URL
    assert safari_base_ie._LOGIN_URL


# Generated at 2022-06-24 13:06:04.397726
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """
    Unit test for constructor of class SafariApiIE.
    """
    test_url = (
        "https://learning.oreilly.com/library/view/security-and-privacy/9780133444852/part00.html?ar="
        "1&client=oreilly")

    ie = SafariApiIE(SafariIE())
    assert_true(ie.suitable(test_url))

# Generated at 2022-06-24 13:06:07.748909
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    info = SafariCourseIE.suitable('https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838')
    assert info[0] == 'safari:course'

# Generated at 2022-06-24 13:06:15.996980
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Success
    api = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    SafariApiIE(api)

    # Failure
    api = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter'
    try:
        SafariApiIE(api)
    except ExtractorError as e:
        assert(e.msg == 'Invalid safaribooksonline URL: %s' % api)

# Generated at 2022-06-24 13:06:24.680203
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()

# Generated at 2022-06-24 13:06:25.772520
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-24 13:06:27.405746
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    assert ie.LOGGED_IN

# Generated at 2022-06-24 13:06:28.724245
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safariIE = SafariIE('', '')
    assert safariIE is not None

# Generated at 2022-06-24 13:06:30.884279
# Unit test for constructor of class SafariIE
def test_SafariIE():
    try:
        SafariIE()
        raise Exception('expected SafariIE to fail without info extractor')
    except TypeError:
        pass

# Generated at 2022-06-24 13:06:38.747493
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    t = SafariCourseIE()
    test_cases = [
        {
            "url": 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/',
            "expected_output": {
                'id': '9780133392838',
                'title': 'Hadoop Fundamentals LiveLessons',
            }
        },
        {
            "url": 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json',
            "expected_output": {
                'id': '9781449396459',
                'title': 'Raspberry Pi Hacks',
            }
        }
    ]


# Generated at 2022-06-24 13:06:48.679333
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .common import FakeLoginIE
    from .test_utils import _get_mock_system
    from .utils import Mock
    import os

    class MockedSafariIE(SafariIE):
        def _download_webpage_handle(self, url_or_request, *args, **kwargs):
            return (
                '<html>'
                '<head>'
                '<script>'
                'var next_uri = "https://next/uri";'
                '</script>'
                '</head>'
                '</html>',
                compat_urllib_response.addinfourl(
                    compat_urllib_request.Request(url_or_request), '', 'https://learning.oreilly.com/accounts/login/')
            )


# Generated at 2022-06-24 13:06:57.055805
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.IE_NAME == 'safari'
    assert ie._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''

# Generated at 2022-06-24 13:07:07.752484
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """Create an instance of SafariCourseIE and verify the course_id and title are
    correctly extracted.
    """
    url = 'http://techbus.safaribooksonline.com/9780134426365'
    obj = SafariCourseIE()
    result = obj.suitable(url)
    assert result is True
    course_id = obj._match_id(url)
    assert course_id == '9780134426365'
    course_title = obj._download_json(
        '%s/book/%s/?override_format=%s' % (obj._API_BASE, course_id, obj._API_FORMAT),
        course_id, 'Downloading course JSON')['title']
    assert course_title == 'Python: Getting Started'

# Generated at 2022-06-24 13:07:10.832537
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    print(__file__)
    print(SafariApiIE)
    print(SafariApiIE._real_extract)



# Generated at 2022-06-24 13:07:19.658965
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Non-logged in session
    (SafariIE
        ._build_request('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
        ._run(download=False, resource_size=None))

    # Logged in session
    (SafariIE
        ._build_request('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
        ._run(download=False, resource_size=None))

# Generated at 2022-06-24 13:07:28.685159
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE(None)
    assert ie.IE_NAME == 'safari'
    assert ie.IE_DESC == 'safaribooksonline.com online video'
    assert ie._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?#&]+)
                            )
                        '''

# Generated at 2022-06-24 13:07:38.136188
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE(None)
    assert safari.IE_NAME == 'safari'
    assert safari.IE_DESC == 'safaribooksonline.com online video'
    assert safari._VALID_URL == '''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''
    # Unit test for method _real_extract()
    saf

# Generated at 2022-06-24 13:07:44.261279
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test that the safaribooksonline.com user credentials
    # can be used to login to safari.
    safari = SafariBaseIE()
    safari.IE_NAME = 'safari'
    safari._real_initialize()
    safari.login.assert_called_once()

    # Test that the constructor will not attempt to login
    # if safaribooksonline.com pulls in the google videoie
    safari = SafariBaseIE()
    safari.IE_NAME = 'google:video'
    safari._real_initialize()
    safari.login.assert_not_called()

# Generated at 2022-06-24 13:07:49.483216
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/python-201/9780130908654/'
    SafariCourseIE(SafariCourseIE._create_ie(SafariCourseIE.ie_key()), url)
    return

# Generated at 2022-06-24 13:07:51.579337
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert ie.IE_NAME == 'safari:api'

# Generated at 2022-06-24 13:07:53.502292
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()
    assert safari._NETRC_MACHINE == 'safari'

# Generated at 2022-06-24 13:07:56.178827
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    if ie._download_json('', None, '')[0] == False:
        print("Invalid URL or network error")

# Generated at 2022-06-24 13:07:58.003093
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie._VALID_URL == SafariIE._VALID_URL