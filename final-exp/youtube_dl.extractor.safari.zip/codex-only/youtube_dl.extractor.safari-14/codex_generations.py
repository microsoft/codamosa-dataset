

# Generated at 2022-06-24 12:57:58.582510
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    t1 = SafariApiIE(None)

# Generated at 2022-06-24 12:58:01.193240
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    SafariCourseIE.suitable(url)
    ie = SafariCourseIE()
    ie.extract(url)

# Generated at 2022-06-24 12:58:04.532280
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from ..test import get_testcases
    testcases = get_testcases(SafariCourseIE, ['url'], ['id', 'title'])
    return testcases

# Generated at 2022-06-24 12:58:05.740734
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE.ie_key() == 'SafariCourse'

# Generated at 2022-06-24 12:58:12.193397
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    _LOGIN_URL = 'https://learning.oreilly.com/accounts/login/'
    _NETRC_MACHINE = 'safari'

    _API_BASE = 'https://learning.oreilly.com/api/v1'
    _API_FORMAT = 'json'

    assert SafariBaseIE._LOGIN_URL == _LOGIN_URL
    assert SafariBaseIE._NETRC_MACHINE == _NETRC_MACHINE
    assert SafariBaseIE._API_BASE == _API_BASE
    assert SafariBaseIE._API_FORMAT == _API_FORMAT

# Generated at 2022-06-24 12:58:17.724267
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    test_func = lambda x: (SafariBaseIE.suitable(x) and not SafariIE.suitable(x))
    assert test_func(url)
    assert not SafariApiIE.suitable(url)

# Generated at 2022-06-24 12:58:29.618967
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    obj = SafariCourseIE('SafariCourse', 'safaribooksonline.com online courses')
    # Test if instance has correct values

# Generated at 2022-06-24 12:58:33.510865
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    b_safari_ie = SafariBaseIE()
    assert b_safari_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert b_safari_ie._API_FORMAT == 'json'



# Generated at 2022-06-24 12:58:38.630575
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test proper constructor
    with SafariBaseIE(None) as ie:
        assert isinstance(ie, SafariBaseIE)
        assert ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
        assert ie._NETRC_MACHINE == 'safari'
        assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'

# Generated at 2022-06-24 12:58:42.815226
# Unit test for constructor of class SafariIE
def test_SafariIE():
    test_instance_one = SafariIE({})
    assert test_instance_one.LOGGED_IN == False
    assert (test_instance_one._NETRC_MACHINE == 'safari')
    assert (test_instance_one._LOGIN_URL ==
        'https://learning.oreilly.com/accounts/login/')

# Generated at 2022-06-24 12:58:51.574658
# Unit test for constructor of class SafariIE
def test_SafariIE():
    data_url = 'https://cdnapisec.kaltura.com/html5/html5lib/v2.37.1/mwEmbedFrame.php'
    query = {
        'wid': '_1926081',
        'uiconf_id': '29375172',
        'flashvars[referenceId]': '9780133392838-01_SL_01',
        'iframeembed': 'true',
        'entry_id': '0_4erxfu4k',
    }
    course_url = r'https?://(?:www\.|learning\.)?oreilly\.com/videos/hadoop-fundamentals-livelessons/9780133392838/9780133392838-01_SL_01'

# Generated at 2022-06-24 12:58:55.881310
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE("%s/book/123" % SafariApiIE._API_BASE)
    assert ie.ie_key() == 'Safari'
    assert ie.ie_name() == 'safaribooksonline.com online video'

# Generated at 2022-06-24 12:59:07.559358
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Class attributes, common for all instances
    assert SafariCourseIE._TESTS, "Failed to complete unit test for SafariCourseIE. Class attribute _TESTS is not populated."
    # Instance attributes, every call will trigger instantiation of a new instance
    assert bool(SafariCourseIE("https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/")._LOGIN_URL), "Failed to complete unit test for SafariCourseIE. Instance attribute _LOGIN_URL is not populated."

# Generated at 2022-06-24 12:59:19.664445
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test using the examples in the program comments
    safariCourseIE = SafariCourseIE()
    examples = [
        'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json',
        'http://techbus.safaribooksonline.com/9780134426365',
        'https://www.safaribooksonline.com/videos/python-programming-language/9780134217314',
        'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838',
        'https://www.oreilly.com/library/view/hadoop-fundamentals-livelessons/9780133392838/',
    ]

# Generated at 2022-06-24 12:59:26.247404
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    def _create_ie(course_id):
        return SafariCourseIE('https://www.safaribooksonline.com/library/view/%s/' % course_id)

    assert _create_ie('9780133392838')._course_id == '9780133392838'
    assert _create_ie('https://www.safaribooksonline.com/library/view/9781449396459/')._course_id == '9781449396459'

# Generated at 2022-06-24 12:59:37.342761
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838'
    safari_course_ie = SafariCourseIE()
    _, course_id = safari_course_ie._extract_course_id(url)
    assert course_id == '9780133392838'
    assert isinstance(safari_course_ie, InfoExtractor)

# Generated at 2022-06-24 12:59:41.899450
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():

    assert SafariCourseIE(None)._VALID_URL == 'https?://(?:www\\.)?(?:safaribooksonline|(?:learning\\.)?oreilly)\\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'

# Generated at 2022-06-24 12:59:45.244314
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    with open('vagrant_safari_cookies.txt') as f:
        for line in f.readlines():
            if line:
                ie._apply_first_set_cookie_header(None, line)
    ie._login()

# Generated at 2022-06-24 12:59:49.091237
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    '''create SafariBaseIE object'''
    dummy_url = 'http://example.com/'
    dummy_id = 'example-id'
    assert not SafariBaseIE._LOGGED_IN
    SafariBaseIE(dummy_id, dummy_url)._download_webpage_handle(
        dummy_url, dummy_id, 'SafariBaseIE test')
    assert SafariBaseIE._LOGGED_IN

# Generated at 2022-06-24 12:59:49.711383
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()

# Generated at 2022-06-24 12:59:50.938956
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Notice: no login assertion here.
    assert SafariCourseIE(SafariBaseIE)

# Generated at 2022-06-24 12:59:58.433462
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert SafariApiIE.suitable('http://www.safaribooksonline.com/videos/python-programming-language/9780134217314') == False
    assert SafariApiIE.suitable('http://techbus.safaribooksonline.com/9780134426365') == False
    assert SafariApiIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json') == True


# Generated at 2022-06-24 13:00:10.871881
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    inst = SafariBaseIE("SafariBaseIE", "safari:base")
    assert inst.name == "SafariBaseIE"
    assert inst.ie_key() == "SafariBaseIE"
    assert inst.ie_key() != "SafariIE"
    assert inst.ie_key() != "SafariApiIE"
    assert inst.ie_key() != "SafariCourseIE"

    assert inst.IE_NAME == "safari:base"
    inst.IE_NAME = "safari:base:modified"
    assert inst.IE_NAME == "safari:base:modified"
    inst.IE_NAME = "safari:base"

    assert inst.IE_DESC == "safaribooksonline.com online video base class"

# Generated at 2022-06-24 13:00:15.998158
# Unit test for constructor of class SafariIE
def test_SafariIE():
    data = '<param name="movie" value="https://www.safaribooksonline.com/api/v1/book/9781449396459/videos/9781449396466/9781449396466_0A_0_0_1.mp4/HLS_rendition/content.m3u8"/>'
    from ..utils import parse_location_info
    result = parse_location_info(data)
    print("result:", result)
    SafariIE().extract(result['url'])


if __name__ == '__main__':
    test_SafariIE()

# Generated at 2022-06-24 13:00:17.045010
# Unit test for constructor of class SafariIE
def test_SafariIE():
    instance = SafariIE()
    assert instance

# Generated at 2022-06-24 13:00:21.615099
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE('safari', 'safaribooksonline.com online video')
    assert ie._VALID_URL == '''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''

# Generated at 2022-06-24 13:00:25.145749
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Cannot use self.assertIsInstance since it will use the overridden
    # assertIsInstance method
    object.__getattribute__(
        SafariApiIE, 'assertIsInstance')(
            SafariApiIE, SafariBaseIE)


# Generated at 2022-06-24 13:00:37.675742
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    import os
    from ..testcases import FakeLoginIE
    from ..test_utils import TEST_HOME_DIR

    # login credentials
    (username, _) = SafariBaseIE._get_login_info()

    # if username is not set, IE does not support login
    if username is None:
        return

    # password not available
    password = None
    ie = FakeLoginIE(SafariBaseIE, password)

    # when no netrc, try again
    if not ie._downloader.params.get('usenetrc'):
        ie = FakeLoginIE(SafariBaseIE, password, usenetrc=True)

    # when no login info, try again
    if not ie._downloader.params.get('username'):
        ie = FakeLoginIE(SafariBaseIE, password, username=username)



# Generated at 2022-06-24 13:00:44.900635
# Unit test for constructor of class SafariCourseIE

# Generated at 2022-06-24 13:00:50.739292
# Unit test for constructor of class SafariIE
def test_SafariIE():
    course_id = '9780133392838'
    part = 'part00'
    w = SafariIE()
    url = 'https://www.safaribooksonline.com/library/view/' + course_id + '/' + part + '.html'
    w._real_extract(url)

# Generated at 2022-06-24 13:00:52.278709
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test for constructor of class SafariBaseIE
    SafariBaseIE()

# Generated at 2022-06-24 13:00:55.477644
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE.SafariCourseIE(SafariCourseIE.SafariCourseIE.ie_key(), SafariCourseIE.SafariCourseIE._VALID_URL, {})
    assert ie

# Generated at 2022-06-24 13:00:59.653600
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    url = SafariBaseIE._LOGIN_URL
    urlh = SafariBaseIE._download_webpage_handle(url, None, 'Downloading login page')
    assert(urlh.geturl() == url)

# Generated at 2022-06-24 13:01:00.432500
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()

# Generated at 2022-06-24 13:01:02.629664
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Can't test anything here as this extractor requires a safaribooksonline account
    pass

# Generated at 2022-06-24 13:01:10.638091
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    initializer = SafariBaseIE()
    safari_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    info_dict = info_extractor.InfoExtractor.suitable(safari_url)
    redirect_url = initializer.suitable(safari_url)
    extractor = info_dict(redirect_url)
    url_result = extractor.suitable(safari_url)

# Generated at 2022-06-24 13:01:11.335598
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()

# Generated at 2022-06-24 13:01:17.103119
# Unit test for constructor of class SafariIE
def test_SafariIE():
    default_options = SafariIE.get_default_options()
    # Test that the default username and password values
    # are set to None
    assert default_options['username'] is None
    assert default_options['password'] is None
    # Test that the default return_data attribute value
    # is set to False
    assert default_options['return_data'] is False


# Generated at 2022-06-24 13:01:18.793039
# Unit test for constructor of class SafariIE
def test_SafariIE():
    instance = SafariIE()
    assert(instance)


# Generated at 2022-06-24 13:01:28.681509
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()
    course_id = '9781449396459'
    part = 'ch01.html'
    url = '%s/book/%s/chapter-content/%s' % (safari_api_ie._API_BASE, course_id, part)
    mobj = re.match(safari_api_ie._VALID_URL, url)
    course_id = mobj.group('course_id')
    part = mobj.group('part')
    video_id = '%s/%s' % (course_id, part)
    part = safari_api_ie._download_json(url, video_id, 'Downloading part JSON')

# Generated at 2022-06-24 13:01:33.013394
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    assert SafariBaseIE._VALID_URL == SafariIE._VALID_URL
    assert not SafariBaseIE.suitable(url)
    assert SafariIE.suitable(url)
    assert not SafariApiIE.suitable(url)
    assert not SafariCourseIE.suitable(url)

    # Run the constructor of class SafariBaseIE.
    SafariBaseIE(SafariIE.ie_key())

# Generated at 2022-06-24 13:01:36.802792
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class TestSafariBaseIE(SafariBaseIE):
        _API_BASE = 'http://localhost'

        def _real_initialize(self):
            pass

    try:
        TestSafariBaseIE()
    except ExtractorError as e:
        assert False, 'TestSafariBaseIE constructor should not raise ExtractorError: %r' % e

# Generated at 2022-06-24 13:01:41.459126
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE(InfoExtractor()).suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')

# Generated at 2022-06-24 13:01:45.824688
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from pytube import YouTube
    yt = YouTube('https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838')
    assert yt.title == 'Hadoop Fundamentals LiveLessons'

# Generated at 2022-06-24 13:01:46.832241
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE('SafariBaseIE')


# Generated at 2022-06-24 13:01:47.957309
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert isinstance(SafariApiIE(), SafariApiIE)

# Generated at 2022-06-24 13:01:51.888884
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert SafariApiIE._VALID_URL == SafariApiIE.VALID_URL
    assert SafariApiIE._TESTS == SafariApiIE.TESTS

# Generated at 2022-06-24 13:01:53.613060
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test with simple input
    test_instance = SafariCourseIE()
    assert test_instance is not None

# Generated at 2022-06-24 13:02:02.734087
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # this is a test code to test SafariApiIE, not to test SafariIE.
    # construction of SafariApiIE instance may fail due to missing SafariIE.
    # this will not happen in real case.

    # SafariBaseIE.ie_key() returns 'SafariIE'
    # this is imported above.
    # SafariIE is not necessary to be installed to build this extractor.
    # thus, it's better to check the test of this method by using
    # `unittest.mock` to simulate the return value of SafariBaseIE.ie_key()
    # to be 'SafariIE'.
    # so, the code below follows:

    from unittest.mock import patch

    with patch('safari.SafariBaseIE.ie_key', lambda x: 'SafariIE'):
        safari_

# Generated at 2022-06-24 13:02:03.397416
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE(SafariCourseIE)


# Generated at 2022-06-24 13:02:09.645775
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    try:
        from .testlib import expect_login_failure
    except ImportError:
        # Import skipped in setup.py
        class expect_login_failure(object):
            def __enter__(self):
                return self

            def __exit__(self, exc_type, exc_val, exc_tb):
                return None

    ie = SafariBaseIE()

    ie._downloader = None
    ie._login()

    with expect_login_failure():
        ie._login()

    # TODO: use mock
    # input('Press "Enter" to continue, "Ctrl-C" to abort')
    # ie._login()

# Generated at 2022-06-24 13:02:10.143749
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    return SafariCourseIE

# Generated at 2022-06-24 13:02:16.384539
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test with a regular URL
    test_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    safari = SafariIE(test_url)
    assert safari.course_id == '9780133392838'
    assert safari.reference_id == '0885ca8e-afe1-45e2-be9e-c8b48e1af136'
    assert safari.part == '0_qbqx90ic'
    assert safari.partner_id == '1926081'
    assert safari.ui_id == '29375172'
    assert safari.url == test_url

    # Test with URL from SafariApiIE

# Generated at 2022-06-24 13:02:29.129575
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_test = SafariIE()
    assert safari_test.IE_DESC == 'safaribooksonline.com online video'
    assert safari_test.IE_NAME == 'safari'
    assert safari_test._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''

# Generated at 2022-06-24 13:02:39.869172
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test constructors of derived classes
    obj = SafariCourseIE()
    if not obj.suitable('https://learning.oreilly.com/library/view/introducing-azure/9781789341969/9781789341969-00_intro.html'):
        raise Exception('Constructor of derived class failed to check url')

    # Test constructors of base class
    obj = SafariBaseIE()
    if obj.suitable('https://learning.oreilly.com/library/view/introducing-azure/9781789341969/9781789341969-00_intro.html'):
        raise Exception('Constructor of base class failed to check url')

# Generated at 2022-06-24 13:02:49.572521
# Unit test for constructor of class SafariBaseIE

# Generated at 2022-06-24 13:02:52.461498
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE('Kaltura')

# Generated at 2022-06-24 13:02:59.618366
# Unit test for constructor of class SafariIE
def test_SafariIE():
    test_cases = (
        ('https://www.oreilly.com/library/view/hadoop-fundamentals-livelessons/9780133392838/', None),
        ('https://www.oreilly.com/library/view/hadoop-fundamentals-livelessons/9780133392838/00_SeriesIntro.html', 'SafariIE'),
        ('https://learning.oreilly.com/library/view/hadoop-fundamentals-livelessons/9780133392838/00_SeriesIntro.html', 'SafariIE')
    )
    for url, expected_IE_NAME in test_cases:
        test_case = re.match(SafariIE._VALID_URL, url)

# Generated at 2022-06-24 13:03:10.269870
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # The following is extracted from the url
    # https://www.safaribooksonline.com/library/view/google-apps-script/9781782169769/part00.html
    course_id = '9781782169769'
    part = 'part00'

    url = 'https://www.safaribooksonline.com/library/view/%s/%s.html' % (course_id, part)

    safari = SafariIE()
    safari.url = url
    safari.course_id = course_id
    safari.part = part
    safari._real_initialize()

    assert safari.url == url
    assert safari.course_id == course_id
    assert safari.part == part

# Generated at 2022-06-24 13:03:12.259708
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()

# Generated at 2022-06-24 13:03:15.194673
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE('SafariBase', SafariBaseIE.IE_NAME)
    assert ie.IE_NAME == SafariBaseIE.IE_NAME

# Generated at 2022-06-24 13:03:21.654113
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    x = SafariBaseIE()
    assert x._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert x._NETRC_MACHINE == 'safari'
    assert x._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert x._API_FORMAT == 'json'
    assert x.LOGGED_IN == False

# Generated at 2022-06-24 13:03:22.492198
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Base class should have no tests.
    assert(SafariIE()._TESTS == [])

# Generated at 2022-06-24 13:03:27.110339
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    ie = SafariApiIE(url)
    assert ie.url == url
    assert ie.course_id == '9781449396459'
    assert ie.part == 'part00.html'

# Generated at 2022-06-24 13:03:28.335366
# Unit test for constructor of class SafariIE
def test_SafariIE():
    obj = SafariIE()
    assert(obj.ie_key() == 'Kaltura')

# Generated at 2022-06-24 13:03:30.747669
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert SafariIE(None)._VALID_URL == SafariIE.VALID_URL

# Generated at 2022-06-24 13:03:41.837409
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    ie = SafariIE('https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838/9780133392838-00_SeriesIntro')
    ie = SafariIE('https://www.oreilly.com/library/view/hadoop-fundamentals-livelessons/9780133392838/00_SeriesIntro.html')
    ie = SafariIE('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314/9780134217314-PYMC_13_00')

# Generated at 2022-06-24 13:03:50.594134
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    test_cases = [
        {
            'url': 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/',
            'playlist_count': 22,
        }
    ]
    course_ie = SafariCourseIE()
    for i, testcase in enumerate(test_cases):
        url = testcase['url']
        course_id = course_ie._match_id(url)
        course = course_ie._real_extract(url)
        assert course['id'] == course_id
        assert len(course['entries']) == testcase['playlist_count']

# Generated at 2022-06-24 13:03:52.533929
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Running the constructor might help us in the future
    # In case we need to do any checks
    SafariApiIE('youtube', 'youtube.com')

# Generated at 2022-06-24 13:03:53.150606
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-24 13:03:54.905701
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert ie.IE_NAME == 'safari:api'


# Generated at 2022-06-24 13:03:56.401369
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safariIE = SafariIE()
    assert isinstance(safariIE, SafariIE)


# Generated at 2022-06-24 13:03:58.988225
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE('safari')

# Generated at 2022-06-24 13:04:00.445510
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """
    This function tests class SafariApiIE
    """
    assert SafariApiIE

# Generated at 2022-06-24 13:04:06.852381
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/library/view/apache-camel-developers/9781784398770/part00.html'
    _, urlh = (SafariApiIE())._download_webpage_handle(url, None, 'Downloading login page')
    redirect_url = urlh.geturl()
    assert redirect_url.startswith('https://learning.oreilly.com/accounts/login')

# Generated at 2022-06-24 13:04:07.586769
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safariIEUnitTest = SafariIE();

# Generated at 2022-06-24 13:04:08.703750
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    _ = SafariApiIE('http://example.com/')

# Generated at 2022-06-24 13:04:11.986935
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assertSafariApiIE('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assertSafariApiIE('https://learning.oreilly.com/api/v1/book/9780134664057/?override_format=json')


# Generated at 2022-06-24 13:04:15.537357
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test valid URL
    SafariCourseIE().suitable('http://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    safari_course_ie = SafariCourseIE()
    # Test invalid URL
    assert not safari_course_ie.suitable('http://www.safaribooksonline.com/api/v1/book/9781449396459')

# Generated at 2022-06-24 13:04:18.185273
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.IE_NAME is not None
    assert ie.LOGGED_IN is False


# Generated at 2022-06-24 13:04:29.790347
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.IE_NAME == 'safari'
    assert ie.IE_DESC == 'safaribooksonline.com online video'
    assert ie._VALID_URL == r'''(?x)https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )'''

# Generated at 2022-06-24 13:04:31.244592
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()
    assert_equal(safari.IE_NAME,'safari')
    assert_equal(safari.IE_DESC, 'safaribooksonline.com online video')


# Generated at 2022-06-24 13:04:33.245126
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Ensure that SafariBaseIE.__init__() doesn't raise an exception on
    # instantiation
    SafariBaseIE()

# Generated at 2022-06-24 13:04:37.580947
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()
    safari_api_ie._download_webpage = lambda a, b, c, d: ('', None)
    safari_api_ie._login()
test_SafariApiIE.IGNORE_EXCEPTION = True

# Generated at 2022-06-24 13:04:45.990542
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    test_urls = [
        'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/',
        'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
        ]
    for t_url in test_urls:
        t = SafariCourseIE(t_url)
        assert t.suitable(t_url) == True
    return

# Generated at 2022-06-24 13:04:47.209409
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    s = SafariBaseIE()
    s._login()

# Generated at 2022-06-24 13:04:50.160211
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert ie.suitable('https://learning.oreilly.com/api/v1/book/9781449396459/chapter/part-1.html')

# Generated at 2022-06-24 13:05:01.413754
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """Test whether constructor of class SafariIE works properly."""
    video_id = '0_qbqx90ic'
    course_id = '9780133392838'
    part = 'part00'
    reference_id = '9780133392838-4'

    # Test with a book video URL
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    course_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    test_data = [
        (url, video_id, course_id, part, reference_id, course_url)
    ]

# Generated at 2022-06-24 13:05:02.050252
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE({})

# Generated at 2022-06-24 13:05:11.846883
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    username = 'test_username'
    password = 'test_password'
    username2 = 'test_username2'
    password2 = 'test_password2'
    username3 = 'test_username3'
    password3 = 'test_password3'
    url = 'http://test.com'

    class Test1BaseClass(SafariBaseIE):
        IE_NAME = 'test1'
    Test1BaseClass(username, password)._login()
    test1 = Test1BaseClass(username2, password2)
    test1._login()

    class Test2BaseClass(SafariBaseIE):
        IE_NAME = 'test2'
    Test2BaseClass(username3, password3)._login()
    test2 = Test2BaseClass(username, password)
    test2._login()


# Generated at 2022-06-24 13:05:15.480730
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    k = SafariCourseIE()
    assert k._VALID_URL == 'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'

# Generated at 2022-06-24 13:05:17.362374
# Unit test for constructor of class SafariIE
def test_SafariIE():
    t = SafariIE()
    assert t is not None


# Generated at 2022-06-24 13:05:18.517010
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()



# Generated at 2022-06-24 13:05:24.605676
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test constructor with valid params and then perform login
    safariBaseIE = SafariBaseIE(SafariBaseIE._LOGIN_URL, {})
    safariBaseIE._login()

    # Test constructor with invalid params and then perform login
    safariBaseIE = SafariBaseIE(_LOGIN_URL, {})
    safariBaseIE._login()

# Generated at 2022-06-24 13:05:31.285750
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.IE_NAME == 'safari'
    assert ie.IE_DESC == 'safaribooksonline.com online video'
    assert ie._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''

# Generated at 2022-06-24 13:05:40.785076
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class TestSafariBaseIE(SafariBaseIE):
        _VALID_URL = 'valid_url'
        IE_NAME = 'test'

    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    safariBase = TestSafariBaseIE()
    safariBase.get_info(url)
    assert safariBase.LOGGED_IN == True
    safariBase.LOGGED_IN = False


# Generated at 2022-06-24 13:05:49.827016
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE('safari')
    assert ie.IE_NAME == 'safari'
    assert ie.IE_DESC == 'safaribooksonline.com online video'
    assert ie._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''

# Generated at 2022-06-24 13:06:03.073759
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    assert isinstance(ie, SafariBaseIE)
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_NAME == 'safari:course'
    assert ie.IE_DESC == 'safaribooksonline.com online courses'
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+|
                                api/v1/book|
                                videos/[^/]+
                            )|
                            techbus\.safaribooksonline\.com
                        )
                        /(?P<id>[^/]+)
                    '''

# Generated at 2022-06-24 13:06:04.445913
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE(None)
    assert isinstance(ie, SafariBaseIE)

# Generated at 2022-06-24 13:06:07.837726
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    try:
        assert(isinstance(SafariCourseIE(), SafariCourseIE))
    except AssertionError:
        print("constructor of class SafariCourseIE failed!")

# end class SafariCourseIE

# Generated at 2022-06-24 13:06:10.304390
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from . import safari as safari_module
    from ..converter import ffmpeg
    safari_module.SafariIE(ffmpeg)


# Generated at 2022-06-24 13:06:10.793154
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()

# Generated at 2022-06-24 13:06:15.195629
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """
    Unit test for constructor of class SafariIE
    """
    safari_ie = SafariIE()
    assert safari_ie.ie_key() == 'Kaltura'


# Generated at 2022-06-24 13:06:20.366876
# Unit test for constructor of class SafariIE
def test_SafariIE():
    info_extractor = SafariIE()
    assert info_extractor.IE_NAME == 'safari'
    assert info_extractor.IE_DESC == 'safaribooksonline.com online video'
    assert info_extractor._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''
    assert info_extractor._T

# Generated at 2022-06-24 13:06:28.409803
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie.LOGGED_IN == False


# Generated at 2022-06-24 13:06:36.976565
# Unit test for constructor of class SafariIE
def test_SafariIE():
    course = 'hadoop-fundamentals-livelessons'
    course_id_default = '9780133392838'
    course_id_1 = '9780133392838-1'
    course_id_2 = '9780133392838-2'
    course_id_3 = '9780133392838-3'
    course_id_4 = '9780133392838-4'
    course_id_5 = '9780133392838-5'
    course_id_6 = '9780133392838-6'
    course_id_7 = '9780133392838-7'
    course_id_8 = '9780133392838-8'
    course_id_9 = '9780133392838-9'
    course_id

# Generated at 2022-06-24 13:06:41.484355
# Unit test for constructor of class SafariIE
def test_SafariIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    SafariIE._download_webpage = lambda self, url, video_id: \
        (None, update_url_query(url, {'test_entry_tok_id':'safari_test_token'}))

    test_obj = SafariIE(url)

    assert test_obj.LOGGED_IN == False



# Generated at 2022-06-24 13:06:43.517877
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    with open('test/testdata/safari-accounts.json', 'r') as f:
        accounts = json.load(f)

    for account in accounts:
        SafariBaseIE(account) # it doesn't throw exception

# Generated at 2022-06-24 13:06:52.253079
# Unit test for constructor of class SafariCourseIE

# Generated at 2022-06-24 13:06:57.009117
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import unittest
    class TestSafariIE(unittest.TestCase):
        def test_SafariIE_instantiation(self):
            obj = SafariIE(None)
            self.assertTrue(hasattr(obj, '_LOGIN_URL'))
    unittest.main(argv=['ignored', '-v'], exit=False)

# Generated at 2022-06-24 13:07:07.699479
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api = SafariApiIE()
    assert 'safari:api' == safari_api.IE_NAME
    assert 'safaribooksonline.com online courses' == safari_api.IE_DESC
    assert 'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html' == safari_api._VALID_URL
    assert 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json' == safari_api._TESTS[1]['url']

# Generated at 2022-06-24 13:07:19.019868
# Unit test for constructor of class SafariIE
def test_SafariIE():
    course_url = 'https://www.safaribooksonline.com/library/view/python-programming-language/9780134217314/'
    ie = SafariIE().url_result(course_url, 'SafariCourse')
    assert isinstance(ie, SafariCourseIE)
    assert not ie.LOGGED_IN

    login_url = 'https://learning.oreilly.com/accounts/login/'
    ie = SafariIE().url_result(login_url, 'Safari')
    assert isinstance(ie, SafariIE)
    assert not ie.LOGGED_IN

    course_api_url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/'

# Generated at 2022-06-24 13:07:20.037735
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert SafariApiIE()._real_initialize()

# Generated at 2022-06-24 13:07:28.953372
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Part id seems to be generated in case of course with custom url.
    # it is not stored in query params or meta tags.
    url = 'https://www.safaribooksonline.com/library/view/design-patterns-in/9781491904040/'
    particular_part_url = 'https://www.safaribooksonline.com/library/view/design-patterns-in/9781491904040/chapter_part00.html'
    webpage, _ = get_testdata_and_parse_url(url, SafariApiIE.ie_key())
    mobj = re.match(SafariApiIE._VALID_URL, particular_part_url)
    expected_reference_id = mobj.group('course_id') + '-' + mobj.group('part')
    SafariA

# Generated at 2022-06-24 13:07:33.505689
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    assert ie.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert not ie.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert not ie.suitable('https://www.safaribooksonline.com/library/view/create-a-nodejs/100000006A0210/part00.html')
    assert not ie.suitable('https://www.safaribooksonline.com/library/view/learning-path-red/9780134664057/RHCE_Introduction.html')

# Generated at 2022-06-24 13:07:41.931623
# Unit test for constructor of class SafariIE
def test_SafariIE():
    test_cases = [
        # i.e. "part01.html"
        {
            'param': 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part01.html',
            'expected_url': 'https://cdnapisec.kaltura.com/html5/html5lib/v2.37.1/mwEmbedFrame.php?wid=_1926081&amp;uiconf_id=29375172&amp;flashvars[referenceId]=0_qbqx90ic',
        },
    ]
    for test_case in test_cases:
        video_url = test_case['param']
        expected_url = test_case['expected_url']
        safari_ie = Safari

# Generated at 2022-06-24 13:07:43.118269
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie._NETRC_MACHINE == 'safari'

# Generated at 2022-06-24 13:07:44.835974
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .common import TestSafariCourseIE
    TestSafariCourseIE('SafariCourseIE')


# Generated at 2022-06-24 13:07:48.633905
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # a concrete class is not checked in and the constructor do nothing
    assert (SafariIE('safariIE') is not None)

# Generated at 2022-06-24 13:07:52.019852
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .kaltura import KalturaIE
    url = "https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html"
    safariie = SafariIE()
    assert isinstance(safariie, SafariIE)
    assert isinstance(safariie, InfoExtractor)
    assert safariie.suitable(url)


# Generated at 2022-06-24 13:08:01.747429
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Try with a valid url
    example_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    expected_webpage = '<!doctype html>\n<html lang="en">\n  <head>\n    <meta charset="utf-8">\n    <meta name="mobile-web-app-capable" content="yes">\n\n'
    expected_webpage += '    <meta name="description" content="Hadoop Fundamentals LiveLessons (Video Training)">\n'