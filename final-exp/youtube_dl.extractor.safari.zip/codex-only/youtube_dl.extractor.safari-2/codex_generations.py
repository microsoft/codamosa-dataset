

# Generated at 2022-06-24 12:58:02.414751
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE('safari:api')
    assert ie.ie_key() == 'safari:api'
    assert ie.ie_key() == SafariApiIE.ie_key()



# Generated at 2022-06-24 12:58:07.309141
# Unit test for constructor of class SafariIE
def test_SafariIE():
    inst = SafariIE("https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html")
    assert inst.constructor() == "https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html"


# Generated at 2022-06-24 12:58:09.959688
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    test_instance = SafariBaseIE()

# Generated at 2022-06-24 12:58:17.467042
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """
    Test submitting a SafariApiIE instance to safaribooksonline.com.

    This test is designed to execute the constructor of an instance of the
    SafariApiIE class
    """
    url = "https://www.safaribooksonline.com/library/view/python-crash-course/9781491912058/"
    safaribooks = SafariApiIE()
    safaribooks.suitable(url)
    safaribooks.url_result(url)
    assert safaribooks.IE_NAME == 'safaribooksonline'
    assert safaribooks.IE_DESC == 'safaribooksonline.com online video'

# Generated at 2022-06-24 12:58:23.602793
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # The constructor of this class should throw an exception
    # if it determines that the user is not logged in
    from .test_common import FakeLoginIE

    course_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'

    course_id = '9780133392838'

    # Check with a logged in user
    fake_login_ie = FakeLoginIE(SafariApiIE(FakeLoginIE.TEST_URL))
    assert isinstance(fake_login_ie, SafariApiIE)

    # Check when the user is not logged in
    fake_login_ie = FakeLoginIE(SafariApiIE(course_url))

    # Check that it throws an exception if the user is not logged in
   

# Generated at 2022-06-24 12:58:35.325091
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # This function may not be part of unit tests
    # since it is supposed to be only called by
    # __init__ methods of subclasses of SafariBaseIE
    # and this is not supported by unit tests.
    class SafariBaseIE_subclass(SafariBaseIE):
        IE_NAME = 'SafariBaseIE_subclass'
        _VALID_URL = r'(https?://)?(?:www\.)?safaribooksonline\.com'
    ie_instance = SafariBaseIE_subclass()

    with open('test/test_data/safari_credentials.json') as credfile:
        f = json.load(credfile)
        username = f['username']
        password = f['password']

# Generated at 2022-06-24 12:58:37.204941
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')

# Generated at 2022-06-24 12:58:46.601310
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Here only testing the creation of the class, not the real extraction
    test_html_page = '<html><body></body></html>'
    # Test with malformed url
    SafariApiIE('https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html')
    # Test for SafariApiIE
    safari_api = SafariApiIE('https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html', 'SafariApiIE')
    # Test for ConfigUrlMixin

# Generated at 2022-06-24 12:58:54.030600
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    API_BASE = 'http://localhost:9000/api/v1'
    API_FORMAT = 'json'
    API_URL = '%s/book/9781449396459/?override_format=%s' % (API_BASE, API_FORMAT)

    class MockSafariApiIE(SafariApiIE):
        mobj = re.match(SafariApiIE._VALID_URL, API_URL)
        part = 'part01'
        download_url = API_URL
        course_id = mobj.group('id')
        video_id = '%s/%s' % (course_id, part)
        download_json = {'web_url': 'mock_json'}


# Generated at 2022-06-24 12:59:00.029434
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE(None)
    assert ie.ie_key() == "Safari"
    assert ie.ie_key() in ie.working_ies
    assert ie.name == "safari"
    assert ie.description == "safaribooksonline.com online video"
    assert ie.working_ies

# Generated at 2022-06-24 12:59:09.543138
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    data = {
        'title': 'title',
        'type': 'course',
        'chapters': [
            {
                'title': 'chapter 1',
                'type': 'chapter',
                'web_url': 'http://localhost/chapter_1.html',
            },
            {
                'title': 'chapter 2',
                'type': 'chapter',
                'web_url': 'http://localhost/chapter_2.html',
            },
        ]
    }
    e = SafariCourseIE()
    e._download_json = lambda *args, **kwargs: data
    info = e._real_extract('http://localhost/part.html')

# Generated at 2022-06-24 12:59:21.929722
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():

    assert SafariCourseIE.suitable('http://techbus.safaribooksonline.com/9780134426365')
    assert not SafariCourseIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314')
    assert not SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert not SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')

# Generated at 2022-06-24 12:59:25.161889
# Unit test for constructor of class SafariIE
def test_SafariIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    SafariIE(url)

# Generated at 2022-06-24 12:59:27.285303
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE('test')
    assert ie.LOGGED_IN == False
    assert ie.username == None

# Generated at 2022-06-24 12:59:29.584171
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test for existence of constructor of class SafariCourseIE
    assert('SafariCourse' in globals())


# Generated at 2022-06-24 12:59:31.074171
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE('SafariBaseIE')
    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-24 12:59:32.521261
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    instance = SafariBaseIE('unit test')
    assert not instance.LOGGED_IN

# Generated at 2022-06-24 12:59:34.721278
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()
    assert safari is not None
    assert safari.ie_key() == 'Safari'

# Generated at 2022-06-24 12:59:42.299860
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE('SafariBaseIE')
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'
    assert safari_base_ie.LOGGED_IN == False

# test for the return of the method _login()

# Generated at 2022-06-24 12:59:46.843207
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from ytdl.tests import get_testcases
    testcases = get_testcases(__file__, 'test_')
    for testcase in testcases:
        url = testcase[0]
        if not SafariCourseIE.suitable(url):
            continue
        if 'Only matching' in testcase[3]:
            continue
        # test constructor with parameters
        SafariCourseIE(url)

# Generated at 2022-06-24 12:59:48.198090
# Unit test for constructor of class SafariIE
def test_SafariIE():
    class TestSafariIE(SafariIE):
        def _login(self):
            pass

    TestSafariIE(None)


# Generated at 2022-06-24 12:59:54.175257
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False
    safari_ie._login()
    assert safari_ie.LOGGED_IN == False

    safari_ie = SafariIE({'username': 'test', 'password': 'test'})
    assert safari_ie.LOGGED_IN == True
    safari_ie._login()
    assert safari_ie.LOGGED_IN == True

# Generated at 2022-06-24 13:00:07.960413
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    if True:
        # pylint: disable=no-member
        # Can't be used until PR https://github.com/rg3/youtube-dl/pull/13962
        # lands on stable branch
        from youtube_dl.utils import ExtractorError
        raise ExtractorError('Test not defined', expected=True)


# Generated at 2022-06-24 13:00:11.970575
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    test = SafariCourseIE()
    test.match(url)
    ie = test.suitable(url)
    assert ie

# Generated at 2022-06-24 13:00:18.026704
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test whether constructor raise error for url
    url = "https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html"
    ie = SafariBaseIE(SafariBaseIE.create_ie(), url)
    if not isinstance(ie.url, compat_str):
        raise AssertionError("url is not compatible str")

# Generated at 2022-06-24 13:00:28.128542
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class MockSafariBaseIE(SafariBaseIE):
        def _login(self):
            pass

    a = MockSafariBaseIE(None)
    assert a.IE_DESC == 'safaribooksonline.com online video'
    assert a._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert a._NETRC_MACHINE == 'safari'
    assert a._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert a._API_FORMAT == 'json'
    assert a.LOGGED_IN == False

# Generated at 2022-06-24 13:00:28.789383
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE(None)

# Generated at 2022-06-24 13:00:31.604859
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    '''
    Test for constructor of SafariCourseIE
    '''
    obj = SafariCourseIE()
    assert obj.IE_NAME == 'safari:course'

# Generated at 2022-06-24 13:00:34.216728
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from ..utils import ExtractorError

    with ExtractorError('Unable to log in'):
        SafariBaseIE._login()

# Generated at 2022-06-24 13:00:35.238506
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE.suitable(SafariCourseIE._VALID_URL)

# Generated at 2022-06-24 13:00:40.259312
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class TestSafariBaseIE(SafariBaseIE):
        _LOGIN_URL = 'https://learning.oreilly.com/accounts/login/'

    try:
        TestSafariBaseIE()._login()
    except ExtractorError as e:
        if e.exc_info[0] is not ExtractorError:
            raise
        assert isinstance(e.exc_info[1], ExtractorError)
        assert e.exc_info[1].args == (
            'Unable to download login page',)

# Generated at 2022-06-24 13:00:41.592649
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
	safari_course = SafariCourseIE()
	assert 1 == 1

# Generated at 2022-06-24 13:00:46.036205
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Dummy SafariBaseIE instance
    safari_base_ie = SafariBaseIE(SafariBaseIE.ie_key())

    # Test _real_initialize()
    safari_base_ie._real_initialize()

# Generated at 2022-06-24 13:00:47.644487
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE("")
    assert ie.LOGGED_IN == False

# Generated at 2022-06-24 13:01:00.798050
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import sys
    import os
    import pprint
    from dl_extractors import __main__ as main
    from utils import get_testcases_from_regex, get_testcases_from_regex_and_exclude
    from dl_extractors.common import InfoExtractor

    # do not log to stdout/stderr
    main.logger.addHandler(main.NullHandler())
    main.logger.propagate = False

    ie = InfoExtractor()

    regex = SafariIE._VALID_URL
    testcases = get_testcases_from_regex(regex)
    failed = []
    for index, tc in enumerate(testcases):
        print('\n{0}/{1}: testing {2}'.format(index + 1, len(testcases), tc))
       

# Generated at 2022-06-24 13:01:10.726682
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = SafariIE._VALID_URL
    mobj = re.match(url, 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    course_id = mobj.group('course_id')
    part = mobj.group('part')
    url = SafariApiIE._VALID_URL % (course_id, part)
    assert_true(re.match(url, 'https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html') != None)

# Generated at 2022-06-24 13:01:12.760566
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    IE = SafariBaseIE()
    assert IE.LOGGED_IN == False
test_SafariBaseIE()

# Generated at 2022-06-24 13:01:13.453944
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-24 13:01:18.655718
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    safari_course_ie = SafariCourseIE(SafariCourseIE.suitable(url))
    assert safari_course_ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'

# Generated at 2022-06-24 13:01:21.733099
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE("https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json")

# Generated at 2022-06-24 13:01:30.292274
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .common import InfoExtractor
    from ..jsinterp import JSInterpreter
    from ..compat import update_url_query
    from ..utils import (
        parse_json,
        ExtractorError,
    )
    from .common import InfoExtractor
    from ..compat import (
        compat_parse_qs,
        compat_urlparse,
        )
    from ..utils import (
        ExtractorError,
        update_url_query,
    )
    from .common import InfoExtractor
    from ..jsinterp import JSInterpreter
    from ..compat import update_url_query
    from ..utils import (
        parse_json,
        ExtractorError,
    )

# Generated at 2022-06-24 13:01:32.726109
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course = SafariCourseIE()
    assert course._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert course._API_FORMAT == 'json'

# Generated at 2022-06-24 13:01:39.423607
# Unit test for constructor of class SafariIE
def test_SafariIE():
    a = SafariIE()
    assert a._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''
    assert a.update_url_query == update_url_query
    assert a.IE_NAME == 'safari'
    assert a.IE_DESC == 'safaribooksonline.com online video'

# Generated at 2022-06-24 13:01:43.681298
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert ie.IE_NAME == 'safari:api'
    assert ie.IE_DESC == 'safaribooksonline.com online video'


# Generated at 2022-06-24 13:01:45.213775
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE(None)

# Generated at 2022-06-24 13:01:48.228358
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert(re.match(SafariBaseIE._VALID_URL, 'https://www.safaribooksonline.com/api/v1/book/9781449396459/'))

# Generated at 2022-06-24 13:01:49.663979
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-24 13:01:58.868216
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from unittest import TestCase
    from ..compat import cmp

    class TestSafariIE(TestCase):
        def __init__(self, *args, **kwargs):
            TestCase.__init__(self, *args, **kwargs)

# Generated at 2022-06-24 13:02:02.510297
# Unit test for constructor of class SafariIE
def test_SafariIE():
    url = 'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838/9780133392838-00_SeriesIntro'
    result = SafariIE()._real_extract(url)
    assert result['id'] == '0_qbqx90ic'

# Generated at 2022-06-24 13:02:03.126223
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE

# Generated at 2022-06-24 13:02:04.121852
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # test call of constructor
    SafariApiIE()


# Generated at 2022-06-24 13:02:06.107614
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # test if SafariIE can instantiate an object of class SafariBaseIE
    # Assumption: Class SafariBaseIE contains no abstract method
    assert type(SafariIE()) == SafariBaseIE

# Generated at 2022-06-24 13:02:13.421543
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from urlparse import urljoin

    # URL that should work by construction
    url = urljoin(
        'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/',
        'hello_world.html')
    ie = SafariApiIE(url)
    assert ie.suitable(url)
    assert ie.IE_NAME == 'safari:api'

    # URL that should work by construction
    url = urljoin(
        'https://learning.oreilly.com/api/v1/book/9781449396459/chapter/',
        'hello_world.html')
    ie = SafariApiIE(url)
    assert ie.suitable(url)
    assert ie.IE_NAME == 'safari:api'

    # URL that should work by construction


# Generated at 2022-06-24 13:02:25.259983
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import datetime
    def assert_timestamp_equal(a, b):
        assert abs((a - datetime.datetime.strptime(b, '%Y%m%d%H%M%S')).total_seconds()) < 1


# Generated at 2022-06-24 13:02:28.168367
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    try:
        SafariBaseIE('')
    except TypeError:
        pass
    else:
        raise AssertionError('TypeError expected')

# Generated at 2022-06-24 13:02:41.216626
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """ Unit test derived from the test code of YouTubePlaylistIE and YoutubePlaylistBaseIE """
    playlist_re = r'<ol[^>]+class="playlist-tracks"[^>]*>(.+?)</ol>'
    ie = SafariCourseIE()
    playlist_url = 'https://www.safaribooksonline.com/library/view/c-plus-plus/9780133374233/'

# Generated at 2022-06-24 13:02:43.431187
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert hasattr(SafariIE, '_real_initialize')


# Generated at 2022-06-24 13:02:46.261713
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test the constructor
    safari_base_ie=SafariBaseIE()
    # Test the value of _API_FORMAT
    assert safari_base_ie._API_FORMAT=='json'


# Generated at 2022-06-24 13:02:49.730037
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .test_common import skip_if_offline
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    skip_if_offline(url)
    SafariApiIE()._real_extract(url)

# Generated at 2022-06-24 13:02:50.927716
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari = SafariBaseIE('SafariBase')
    assert safari != None

# Generated at 2022-06-24 13:02:56.873152
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    import unittest

    class TestSafariCourseIE(SafariCourseIE):
        _API_BASE = None

        def _download_json(self, *args, **kwargs):
            return {
                'chapters': ['%s/chapter/part00.html' % args[0]]
            }

    course_ie = TestSafariCourseIE()

    class TestCase(unittest.TestCase):
        def test_course_ie(self):
            self.assertTrue(isinstance(course_ie, SafariBaseIE))
            self.assertTrue(isinstance(course_ie, InfoExtractor))

    unittest.main(argv=[''])


# Generated at 2022-06-24 13:03:02.054153
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = "https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/"
    obj = SafariCourseIE(None, url)
    assert obj._VALID_URL == 'https?://(?:www\\.)?(?:safaribooksonline|(?:learning\\.)?oreilly)\\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'
    assert obj._TESTS[0]['url'] == url
    assert obj._TESTS[0]['info_dict']['id'] == "9780133392838"

# Generated at 2022-06-24 13:03:02.616215
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()

# Generated at 2022-06-24 13:03:03.230204
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert type(SafariIE()) == SafariIE

# Generated at 2022-06-24 13:03:09.445492
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Asserts if attributes are available in class
    assert hasattr(SafariBaseIE, "_API_BASE"), "._API_BASE not defined"
    assert hasattr(SafariBaseIE, "_API_FORMAT"), "._API_FORMAT not defined"
    assert hasattr(SafariBaseIE, "_LOGIN_URL"), "._LOGIN_URL not defined"
    assert hasattr(SafariBaseIE, "_NETRC_MACHINE"), "._NETRC_MACHINE not defined"

# Generated at 2022-06-24 13:03:17.437814
# Unit test for constructor of class SafariIE
def test_SafariIE():
    url = "https://learning.oreilly.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html"
    test_Safari = SafariIE(SafariIE._downloader)
    test_Safari._real_initialize()
    test_Safari.url = url
    #test_Safari._login()
    test_Safari._real_extract(url)

# Generated at 2022-06-24 13:03:19.277724
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    test = SafariApiIE("test")
    assert test.name == 'safari:api'

# Generated at 2022-06-24 13:03:20.553364
# Unit test for constructor of class SafariIE
def test_SafariIE():
    obj = SafariIE()
    assert obj.LOGGED_IN == False


# Generated at 2022-06-24 13:03:23.885253
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safariApiIE = SafariApiIE()
    assert safariApiIE.name == "safari:api"
    assert safariApiIE.description == "safaribooksonline.com online courses"

# Generated at 2022-06-24 13:03:24.992692
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    c = SafariApiIE()

# Generated at 2022-06-24 13:03:36.586021
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():

    ie = SafariApiIE()
    assert ie.IE_NAME == 'safari:api'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

    mobj = re.match(ie._VALID_URL, 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html')
    assert mobj.group('course_id') == '9781449396459'
    assert mobj.group('part') == 'part00'


# Generated at 2022-06-24 13:03:47.208874
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    test_object = SafariCourseIE()

    assert test_object._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert test_object._API_FORMAT == 'json'

    assert test_object._VALID_URL == r'''(?x)
                    https?://
                        (?:
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+|
                                api/v1/book|
                                videos/[^/]+
                            )|
                            techbus\.safaribooksonline\.com
                        )
                        /(?P<id>[^/]+)
                    '''

# Generated at 2022-06-24 13:03:55.311955
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import sys, os, inspect
    currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    parentdir = os.path.dirname(currentdir)
    sys.path.insert(0, parentdir)
    from ydl import safariextractor
    tmp = safariextractor.SafariApiIE()
    assert isinstance(tmp, safariextractor.SafariApiIE)
    assert len(re.findall(r'Book = (.*);', tmp.SafariCourseIE._BOOK, flags=re.MULTILINE)) == 1

# Generated at 2022-06-24 13:03:55.964641
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    pass

# Generated at 2022-06-24 13:04:07.709696
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    ie = SafariCourseIE(SafariCourseIE.suitable(url))
    assert ie.IE_NAME == 'safari:course'
    assert ie.IE_DESC == 'safaribooksonline.com online courses'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'
    assert ie.__name__ == 'SafariCourseIE'



# Generated at 2022-06-24 13:04:10.976678
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE(None)._download_webpage(
        'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html', None, 'stork')

# Generated at 2022-06-24 13:04:16.253477
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test with safaribooksonline.com
    SafariBaseIE._NETRC_MACHINE = 'safaribooksonline'
    ie = SafariBaseIE()
    # Test with learning.safaribooksonline.com
    SafariBaseIE._NETRC_MACHINE = 'learning.safaribooksonline'
    ie = SafariBaseIE()
    # Test with oreilly.com
    SafariBaseIE._NETRC_MACHINE = 'oreilly'
    ie = SafariBaseIE()

# Generated at 2022-06-24 13:04:24.142685
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    """
    Ensure correct constructor class for safari IE.
    """
    try:
        credentials = {'username': 'foo', 'password': 'bar'}
        safari_base_ie = SafariBaseIE(credentials)
    except ValueError as exception:
        assert False, ('SafariBaseIE constructor class for safari IE is not correct', exception)
    except Exception:
        assert False, ('SafariBaseIE constructor class for safari IE is not correct')

# Generated at 2022-06-24 13:04:26.973755
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    obj = SafariBaseIE()
    assert obj.__class__.__name__ == 'SafariBaseIE'


# Generated at 2022-06-24 13:04:27.687140
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert Safa

# Generated at 2022-06-24 13:04:28.396393
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()

# Generated at 2022-06-24 13:04:31.941552
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE('safari:api')
    assert ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert ie._NETRC_MACHINE == 'safari'

# Generated at 2022-06-24 13:04:32.604759
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    pass

# Generated at 2022-06-24 13:04:35.457671
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari = SafariBaseIE()
    safari._initialize()
    assert safari.LOGGED_IN is True


# Generated at 2022-06-24 13:04:42.947840
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    test_SafariCourseIE.course_url = 'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838'
    test_SafariCourseIE.course_id = '9780133392838'
    test_SafariCourseIE.course_title = 'Hadoop Fundamentals LiveLessons'
    test_SafariCourseIE.course_mock = {
        'chapters': ['https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html']
    }
    
    safari_course = SafariCourseIE()
    safari_course.to_screen = lambda x: x  # disable printing
    safari_course.url = test_SafariCourseIE

# Generated at 2022-06-24 13:04:45.771807
# Unit test for constructor of class SafariIE
def test_SafariIE():
    instance = SafariIE()
    assert instance.ie_key() == "Kaltura"
    assert instance.LOGGED_IN == False

# Generated at 2022-06-24 13:04:49.284118
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    try:
        SafariApiIE('email', 'pwd')
    except TypeError as e:
        assert "__init__() takes exactly 3 arguments (1 given)" in str(e)
    else:
        assert False

# Generated at 2022-06-24 13:04:55.297256
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    inst = SafariApiIE()
    assert inst._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Generated at 2022-06-24 13:05:05.266588
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """Unit test for constructor of class SafariIE"""
    inst = SafariIE()

    assert(inst.ie_key() == 'Safari')
    assert(inst.ie_name() == 'safari')

    # Test the suitability of SafariIE class to handle
    # various URLs
    assert(inst.suitable('http://techbus.safaribooksonline.com/9780134664057') == True)
    assert(inst.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html') == True)

# Generated at 2022-06-24 13:05:07.887320
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Initialize the class and ensures that is a subclass of InfoExtractor
    safari_base_ie = SafariBaseIE()
    assert isinstance(safari_base_ie, InfoExtractor)



# Generated at 2022-06-24 13:05:17.830188
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    import socket
    from .common import mock

    class MockSocket(object):
        def __init__(self, *args, **kwargs):
            pass

        def makefile(self, *args, **kwargs):
            return None

    class MockSafariBaseIE(SafariBaseIE):
        def _download_webpage_handle(self, *args, **kwargs):
            return '', ''

        def _get_login_info(self):
            return '', ''

        def _apply_first_set_cookie_header(self, *args, **kwargs):
            pass

        def _download_json(self, *args, **kwargs):
            return {}

    # test case #1: socket.create_connection should be called with expected arguments

# Generated at 2022-06-24 13:05:22.101712
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert SafariApiIE.__name__ == 'SafariApiIE'
    assert SafariApiIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html') is True
    assert SafariApiIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html') is False


# Generated at 2022-06-24 13:05:22.784194
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    _ = SafariBaseIE(None)

# Generated at 2022-06-24 13:05:25.116048
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter-content/ch01.html'
    assert SafariApiIE(SafariIE()).suitable(url)



# Generated at 2022-06-24 13:05:31.588974
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import unittest
    import sys
    import os

    IE_NAME = "safari"
    IE_CLASS_NAME = "SafariIE"

    # Getting class
    klass = globals().get(IE_CLASS_NAME)

    # Instantiation of class
    instance = klass()

    # Testing values
    if instance.IE_NAME != IE_NAME:
        print('***Error: instance.IE_NAME != IE_NAME')
        sys.exit(-1)

    assert instance.IE_NAME == IE_NAME

# Generated at 2022-06-24 13:05:37.944119
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    # check that it is an instance of BaseInfoExtractor
    result = SafariCourseIE().suitable(url)
    assert(isinstance(SafariCourseIE(), SafariBaseIE))

# Generated at 2022-06-24 13:05:41.025906
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base = SafariBaseIE()
    assert isinstance(safari_base, InfoExtractor)
    assert isinstance(safari_base, SafariBaseIE)


# Generated at 2022-06-24 13:05:41.953479
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE(None)
    safari_base_ie._login()



# Generated at 2022-06-24 13:05:43.488973
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('Safari')

# Generated at 2022-06-24 13:05:45.339351
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    safari_ie._real_initialize()
    safari_ie._login()

# Generated at 2022-06-24 13:05:48.898530
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """Unit test for class SafariCourseIE

    See https://github.com/rg3/youtube-dl/issues/1953
    """

    # This test concerns import of class SafariCourseIE
    from youtube_dl.extractor import SafariCourseIE


# Generated at 2022-06-24 13:05:49.724012
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-24 13:06:03.027334
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    mobj = re.match(SafariIE._VALID_URL, url)
    reference_id = mobj.group('reference_id') if mobj.group('reference_id') is not None else '9780133392838-part00'
    video_id = '%s-%s' % (mobj.group('course_id'), mobj.group('part')) if mobj.group('part') else reference_id

# Generated at 2022-06-24 13:06:05.278277
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariBaseIE()
    safari_ie._real_initialize()
    return safari_ie

# Generated at 2022-06-24 13:06:06.904877
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safariBaseIE = SafariBaseIE()
    assert safariBaseIE is not None

# Generated at 2022-06-24 13:06:12.035235
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():

    class FakeSafariIE(SafariBaseIE):
        IE_NAME = 'Fake Safari IE'

        _VALID_URL = 'fake safari url'

        _TESTS = [{
            'url': 'fake safari url',
            'only_matching': True,
        }]
    inst = FakeSafariIE()
    assert isinstance(inst, SafariBaseIE)

# Generated at 2022-06-24 13:06:16.183268
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    # we want to make sure that we don't hit any errors when _real_initialize method is called
    ie._real_initialize()

# Generated at 2022-06-24 13:06:21.650630
# Unit test for constructor of class SafariIE
def test_SafariIE():
    test = SafariIE()
    assert test.LOGGED_IN == False
    assert test._API_BASE == "https://learning.oreilly.com/api/v1"
    assert test._API_FORMAT == "json"
    assert test._PARTNER_ID == "1926081"
    assert test._UICONF_ID == "29375172"

# Generated at 2022-06-24 13:06:23.513518
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    s_base_ie = SafariBaseIE()
    assert s_base_ie.IE_NAME == 'safariBase'

# Generated at 2022-06-24 13:06:29.505451
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    SafariCourseIE.suitable(url)
    inst = SafariCourseIE()
    inst.suitable(url)
    res = inst._real_extract(url)


# Generated at 2022-06-24 13:06:33.637827
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE("SafariIE", "safaribooksonline.com")


test = test_SafariIE()
if(test):
    print("All tests passed: ", test)
    print("SafariIE class created successfully")
else:
    print("Error creating SafariIE, error: ", test)

# Generated at 2022-06-24 13:06:37.945085
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api = SafariApiIE()
    assert safari_api.extractor.__class__.__name__ == 'SafariIE'

# Generated at 2022-06-24 13:06:48.323326
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import os
    import getpass

    username = ''
    password = ''
    safari_ie = SafariIE()
    assert getpass.getpass == getpass._fallback_getpass
    assert safari_ie._downloader._downloader.password_mgr.passwd == {}
    assert not safari_ie.LOGGED_IN

    def _get_pass(netrc_machine):
        return (username, password)

    safari_ie = SafariIE()
    assert not getpass._fallback_getpass

    with open(os.devnull, 'w') as devnull:
        safari_ie.to_screen = devnull.write

        username = 'safari_test_user'
        password = 'safari_test_password'
        safari_ie._get_pass = _get_pass

        saf

# Generated at 2022-06-24 13:06:58.868937
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from ..compat import compat_urllib_request, compat_cookiejar
    from ..utils import NO_DEFAULT

    class DummySafariBaseIE(SafariBaseIE):
        def _login(self):
            pass

        def _real_extract(self, url):
            pass

        def _real_initialize(self):
            pass

        @classmethod
        def ie_key(cls):
            return 'test'

    ied = DummySafariBaseIE()
    ied._downloader = compat_urllib_request.OpenerDirector()
    ied._downloader.cookiejar = compat_cookiejar.CookieJar()

    # Test overriding _downloader
    new_downloader = compat_urllib_request.OpenerDirector()

# Generated at 2022-06-24 13:07:06.667893
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariBaseIE()
    ie._login()

    mobj = re.match(ie._VALID_URL, "https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter-content/part00.html")
    part = ie._download_json("https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter-content/part00.html", '%s/%s' % (mobj.group('course_id'), mobj.group('part')), 'Downloading part JSON')
    url = part['web_url']

    url = url.replace('learning.oreilly', 'www.safaribooksonline')
    assert url

    print(url)

    #print(entries)
    #assert

# Generated at 2022-06-24 13:07:10.466682
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari = SafariApiIE()
    assert safari.IE_NAME.find('api') != -1
    assert safari.IE_DESC.find('api') != -1
    assert safari.LOGGED_IN == False



# Generated at 2022-06-24 13:07:11.395921
# Unit test for constructor of class SafariIE
def test_SafariIE():
    temp = SafariIE()
    temp = SafariApiIE()

# Generated at 2022-06-24 13:07:13.617585
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE('http://techbus.safaribooksonline.com/9780134426365')

# Generated at 2022-06-24 13:07:14.334475
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    a = SafariApiIE({})

# Generated at 2022-06-24 13:07:24.786477
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course = SafariCourseIE()
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    id = '9780133392838'
    title = 'Hadoop Fundamentals LiveLessons'
    info_dict = {
        'id': '9780133392838',
        'title': 'Hadoop Fundamentals LiveLessons',
    }
    playlist_count = 22
    skip = 'Requires safaribooksonline account credentials'
    assert safari_course.ie_key() == 'SafariBaseIE'
    assert safari_course.suitable(url) == False
    assert safari_course._match_id(url) == id
    assert safari_course._

# Generated at 2022-06-24 13:07:25.478889
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE

# Generated at 2022-06-24 13:07:28.952032
# Unit test for constructor of class SafariIE
def test_SafariIE():
    video_id = '9780133392838-Part00'
    SafariIE()
    return video_id

# Generated at 2022-06-24 13:07:33.505789
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # test SafariApiIE constructor without kargs
    SafariApiIE()

    # test SafariApiIE constructor with default kargs
    SafariApiIE(default_ages={"test": 0})

    # test SafariApiIE constructor with unexpected kargs
    with pytest.raises(TypeError):
        SafariApiIE("test")

# Generated at 2022-06-24 13:07:34.025868
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()

# Generated at 2022-06-24 13:07:34.855561
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-24 13:07:43.779977
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # This is an example URL provided by safaribooksonline()
    url = 'https://www.safaribooksonline.com/library/view/learning-python/9781449355722/'
    ie = SafariCourseIE()

    video_urls = []
    video_titles = []
    video_entries = ie.extract(url)

    for entry in video_entries.get('entries', []):
        url = entry['url']
        title = entry['title']
        video_urls.append(url)
        video_titles.append(title)

    expected_number_of_chapters = 22


# Generated at 2022-06-24 13:07:48.285555
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/something/123/'
    assert not SafariCourseIE.suitable(url)
    SafariCourseIE(SafariCourseIE.ie_key(), url)

# Generated at 2022-06-24 13:07:53.399723
# Unit test for constructor of class SafariIE
def test_SafariIE():
        test_credentials = {
            'username': 'testuser',
            'password': 'testpassword'
        }
        safari_extractor = SafariIE(test_credentials)
        assert safari_extractor._NETRC_MACHINE == 'safari'
        assert safari_extractor.LOGGED_IN == False

# Generated at 2022-06-24 13:07:54.101975
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-24 13:07:57.473239
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    inst = SafariCourseIE()
    inst.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')