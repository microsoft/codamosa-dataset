

# Generated at 2022-06-24 12:58:07.304572
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    m = re.match(SafariApiIE._VALID_URL,
                 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter-content/ch02.html')
    e = SafariApiIE()
    e.url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter-content/ch02.html'
    e.course_id = m.group('course_id')
    e.part = m.group('part')

    # Part JSON

# Generated at 2022-06-24 12:58:15.606236
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ins = SafariCourseIE('safari:course', {})
    assert ins.IE_NAME == 'safari:course'
    assert ins.ie_key() == 'safari:course'
    assert ins._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert ins._NETRC_MACHINE == 'safari'
    assert ins._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ins._API_FORMAT == 'json'
    assert ins.LOGGED_IN == False

# Generated at 2022-06-24 12:58:21.861668
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.IE_NAME == SafariIE.IE_NAME
    assert ie.IE_DESC == SafariIE.IE_DESC
    assert ie._VALID_URL == SafariIE._VALID_URL
    assert ie._TESTS == SafariIE._TESTS
    assert ie._PARTNER_ID == SafariIE._PARTNER_ID
    assert ie._UICONF_ID == SafariIE._UICONF_ID


# Generated at 2022-06-24 12:58:22.509461
# Unit test for constructor of class SafariIE
def test_SafariIE():
    pass

# Generated at 2022-06-24 12:58:34.641011
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Check SafariIE for following conditions:
    # 1. Check for the base class (InfoExtractor)
    # 2. Check for the class variables
    # 3. Check for class methods

    # Check for the base class
    assert issubclass(SafariIE, InfoExtractor)

    # Check for class variables

# Generated at 2022-06-24 12:58:43.288772
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """This function tests constructor of SafariApiIE"""
    inst_obj = SafariApiIE()
    assert inst_obj.ie_key() == 'safari:api'
    assert inst_obj.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert not inst_obj.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert not inst_obj.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html')

# Generated at 2022-06-24 12:58:45.017867
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert SafariCourseIE._VALID_URL == SafariIE._VALID_URL


# Generated at 2022-06-24 12:58:53.104550
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    URL_TEST = 'https://www.safaribooksonline.com/library/view/the-definitive-antlr/9781449342913/'
    assert SafariCourseIE._VALID_URL == SafariCourseIE._TESTS[0]['url']
    assert SafariCourseIE._TESTS[0]['url'] == SafariCourseIE._TESTS[1]['url']
    assert SafariCourseIE._TESTS[2]['url'] == SafariCourseIE._TESTS[3]['url']
    assert SafariCourseIE._TESTS[4]['url'] == SafariCourseIE._TESTS[5]['url']
    assert SafariCourseIE._TESTS[0]['url'] == SafariCourseIE._TESTS[5]['url']

# Generated at 2022-06-24 12:58:57.088867
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_IE = SafariIE()
    assert safari_IE.IE_NAME == 'safari'
    assert safari_IE.IE_DESC == 'safaribooksonline.com online video'



# Generated at 2022-06-24 12:59:03.548296
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'


# Generated at 2022-06-24 12:59:05.129460
# Unit test for constructor of class SafariIE
def test_SafariIE():
    s = SafariIE('', '', '')
    assert not s.LOGGED_IN

# Generated at 2022-06-24 12:59:16.768511
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """
    Unit test for SafariCourseIE
    """

    # Simulate IE
    class safariAPI(SafariCourseIE):
        def _real_extract(self, url):
            course_id = self._match_id(url)
            return course_id
    # Test SafariCourseIE construction
    course_id = safariAPI()._real_extract("https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json")
    assert course_id == '9781449396459'
    course_id = safariAPI()._real_extract("https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838")
    assert course_id == '9780133392838'
   

# Generated at 2022-06-24 12:59:19.243270
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class ConstructorTest(SafariBaseIE):
        IE_NAME = 'test'
        _VALID_URL = r'https?://.+'

        def test(self):
            pass

    ConstructorTest()

# Generated at 2022-06-24 12:59:20.788136
# Unit test for constructor of class SafariIE
def test_SafariIE():
    t_ = SafariIE()
    assert t_ != None


# Generated at 2022-06-24 12:59:32.424254
# Unit test for constructor of class SafariIE

# Generated at 2022-06-24 12:59:39.877213
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """
    Basic test case for SafariIE.
    """
    info = SafariIE()._real_extract('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')

    assert info["_type"] == "url_transparent"
    assert info["url"].startswith("https://cdnapisec.kaltura.com/html5/html5lib/")
    assert info["url"].endswith("mwEmbedFrame.php")
    assert info["ie_key"] == "Kaltura"

# Generated at 2022-06-24 12:59:48.527638
# Unit test for constructor of class SafariIE
def test_SafariIE():
    try:
        import requests
    except ImportError:
        import os
        if os.environ.get('TRAVIS', None) == 'true':
            return
        else:
            import sys
            sys.exit('ERROR: "requests" Python package is missing')

    try:
        import requests_ntlm
    except ImportError:
        import requests_kerberos
        requests_kerberos.HttpNegotiateProcessor.REQUEST_HEADER = 'Authorization'
        requests_kerberos.GSSAPI.REQUEST_HEADER = 'Authorization'

    import requests_mock
    from youtube_dl.utils import compat_cookielib
    from youtube_dl.compat import cookielib


# Generated at 2022-06-24 12:59:53.129337
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ''' Test for constructor of class SafariApiIE '''

    obj = SafariApiIE()
    assert obj.ie_name == 'safari:api'
    assert obj.ie_key() == 'SafariApi'
    assert obj.ie_description == 'safaribooksonline.com online courses'


# Generated at 2022-06-24 13:00:06.846368
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    '''
    Since this constructor does not use _download_json and does not check for response
    code for the URL, we need to test for this. Since _VALID_URL does not allow for
    invalid URLs, for this test, we alter the _VALID_URL temporarily.
    '''
    old_valid_url = SafariCourseIE._VALID_URL
    SafariCourseIE._VALID_URL = r'.+'
    test_url = 'http://techbus.safaribooksonline.com/9780134426365'

# Generated at 2022-06-24 13:00:07.862815
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()


# Generated at 2022-06-24 13:00:08.853861
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    inst = SafariApiIE()

# Generated at 2022-06-24 13:00:10.628605
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Constructor of class SafariBaseIE shouldn't require any external resource
    assert SafariBaseIE(None)._LOGIN_URL

# Generated at 2022-06-24 13:00:13.694137
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert issubclass(SafariBaseIE, InfoExtractor)
    assert issubclass(SafariIE, SafariBaseIE)
    assert issubclass(SafariApiIE, SafariBaseIE)
    assert issubclass(SafariCourseIE, SafariBaseIE)

# Generated at 2022-06-24 13:00:14.630252
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE(SafariCourseIE.ie_key())

# Generated at 2022-06-24 13:00:25.339288
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safariCourseIE = SafariCourseIE()
    assert safariCourseIE._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'
    assert safariCourseIE._NETRC_MACHINE == 'safari'
    assert safariCourseIE._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safariCourseIE._API_FORMAT == 'json'
    assert safariCourseIE.LOGGED_IN == False
    assert safariCourseIE.IE_NAME == 'safari:course'

# Generated at 2022-06-24 13:00:36.655479
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """
    Unit test for the constructor of the class SafariCourseIE
    """
    # String representing a valid URL
    valid_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    test_class = SafariCourseIE(valid_url)
    expected = '9780133392838'
    assert test_class._match_id(valid_url) == expected, "Expected: '%s', but got '%s'" % (expected, test_class._match_id(valid_url))

# Generated at 2022-06-24 13:00:41.190289
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert ie._NETRC_MACHINE == 'safari'
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'
    assert ie.LOGGED_IN == False

# Generated at 2022-06-24 13:00:44.140485
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert isinstance(ie, InfoExtractor)
# test_SafariApiIE()


# Generated at 2022-06-24 13:00:46.673076
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    assert ie._TESTS[0]['skip'] == 'Requires safaribooksonline account credentials'

# Generated at 2022-06-24 13:00:51.889816
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/head-first-java/0596009208/'
    assert SafariCourseIE._VALID_URL == SafariCourseIE._VALID_URL
    assert SafariCourseIE.suitable(url)

# Generated at 2022-06-24 13:00:53.415731
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE('www.safaribooksonline.com', 'safari')

# Generated at 2022-06-24 13:00:55.866254
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    assert ie.IE_NAME == 'safari-base'
    assert not ie.LOGGED_IN

# Generated at 2022-06-24 13:00:58.769030
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    IE_name = 'safari:api'
    if not globals()[IE_name]['IE_DESC']:
        globals()[IE_name]['IE_DESC'] = 'safaribooksonline.com online API'
    instance = globals()[IE_name + 'IE']()
    assert isinstance(instance, SafariBaseIE)

# Generated at 2022-06-24 13:01:00.958137
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class TestSafariIE(SafariBaseIE):
        pass

    TestSafariIE()

# Generated at 2022-06-24 13:01:03.116176
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert isinstance(ie, SafariApiIE)


# Generated at 2022-06-24 13:01:13.294572
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    mocker = Mocker()
    username_and_password = mocker.mock()
    username_and_password.__iter__().return_value = ['user', 'password']
    ie = SafariBaseIE()
    ie._get_login_info = lambda: username_and_password
    ie._download_webpage_handle = mocker.mock()
    def download_webpage_handle(url, *args):
        if url == ie._LOGIN_URL:
            return {'response': 'login_response'}, url
        else:
            assert url == 'https://learning.oreilly.com/accounts/login-check/'
            return {'response': 'login_check_response'}, url
    ie._download_webpage_handle.side_effect = download_webpage_handle
    ie._apply_first_set

# Generated at 2022-06-24 13:01:14.790708
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    try:
        SafariBaseIE._login()
    except ImportError:
        return

# Generated at 2022-06-24 13:01:25.967839
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    obj = SafariBaseIE()
    assert obj._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert obj._API_FORMAT == 'json'
    assert obj._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert obj._NETRC_MACHINE == 'safari'
    assert obj.LOGGED_IN == False
    assert obj._PARTNER_ID == '1926081'
    assert obj._UICONF_ID == '29375172'

# Generated at 2022-06-24 13:01:27.978097
# Unit test for constructor of class SafariIE
def test_SafariIE():
    s = SafariIE()
    assert s.__class__.__name__ == "SafariIE"
    assert s.IE_NAME == 'safari'


# Generated at 2022-06-24 13:01:28.781204
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE(SafariBaseIE())

# Generated at 2022-06-24 13:01:40.685857
# Unit test for constructor of class SafariCourseIE

# Generated at 2022-06-24 13:01:45.930267
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safaribase = SafariBaseIE()
    assert safaribase.IE_NAME == 'safari'
    assert safaribase.IE_DESC == 'safaribooksonline.com online video'
    assert safaribase.LOGGED_IN == False


# Generated at 2022-06-24 13:01:52.569979
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    cls = type('SafariBaseIE', (SafariBaseIE,), {})
    cls.IE_NAME = 'safari'
    cls._LOGIN_URL = 'https://learning.oreilly.com/accounts/login/'
    cls._NETRC_MACHINE = 'safari'
    assert cls._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert cls._NETRC_MACHINE == 'safari'
    assert cls.ie_key() == 'SafariBaseIE'

# Generated at 2022-06-24 13:01:53.561191
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    sapie = SafariApiIE()

# Generated at 2022-06-24 13:01:54.160678
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-24 13:02:04.795958
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """Test the constructor of class SafariIE."""
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'

    if not len(SafariIE._VALID_URL) == len(url):
        print(SafariIE._VALID_URL)
        print(len(SafariIE._VALID_URL))
        print(len(url))
        print(url)
           
    assert len(SafariIE._VALID_URL) == len(url)
    assert url == SafariIE._VALID_URL

if __name__ == "__main__":
    test_SafariIE()

# Generated at 2022-06-24 13:02:05.968062
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()
    assert safari.IE_NAME == 'safari'

# Generated at 2022-06-24 13:02:06.870998
# Unit test for constructor of class SafariIE
def test_SafariIE():
    inst = SafariIE()
    print(inst)

# Generated at 2022-06-24 13:02:13.987924
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariBaseIE._login = lambda self: None
    SafariBaseIE.LOGGED_IN = True

    course_id = '9780133392838'
    part = '0_qbqx90ic'
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    chapter = 'https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html'

# Generated at 2022-06-24 13:02:14.577882
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()

# Generated at 2022-06-24 13:02:15.529215
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()


# Generated at 2022-06-24 13:02:17.519449
# Unit test for constructor of class SafariIE
def test_SafariIE():
    s = SafariIE()
    assert s is not None
    print('Constructor test for class SafariIE: OK')

# Generated at 2022-06-24 13:02:23.921783
# Unit test for constructor of class SafariIE
def test_SafariIE():
    currentEnvironment = os.environ.get('ENVIRONMENT')
    os.environ['ENVIRONMENT'] = 'DEV'
    try:
        SafariIE()
    finally:
        if currentEnvironment == None:
            del os.environ['ENVIRONMENT']
        else:
            os.environ['ENVIRONMENT'] = currentEnvironment

# Generated at 2022-06-24 13:02:26.913510
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Calls _login on initialization
    safarie = SafariBaseIE()
    assert safarie.LOGGED_IN == False

# Generated at 2022-06-24 13:02:40.169105
# Unit test for constructor of class SafariIE

# Generated at 2022-06-24 13:02:45.267761
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class SafariBaseIETest(SafariBaseIE):
        _API_BASE = 'http://my_api/'
        _VALID_URL = r'https?://my\.site/(?P<id>[^/]+)'

    SafariBaseIETest({
        'username': 'abc',
        'password': 'def',
    })

# Generated at 2022-06-24 13:02:46.461276
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Can't unit test SafariIE because it requires actual credentials
    pass

# Generated at 2022-06-24 13:02:49.314201
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE('safari', 'safaribooksonline.com online video')
    assert ie.ie_name == 'safari'
    assert ie.ie_desc == 'safaribooksonline.com online video'

# Generated at 2022-06-24 13:02:56.989380
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .youtube import YoutubeIE
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838')
    assert SafariCourseIE.suitable('https://learning.oreilly.com/library/view/hadoop-fundamentals-livelessons/9780133392838')
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314')
    assert SafariCourseIE.suitable('https://learning.oreilly.com/videos/python-programming-language/9780134217314')

# Generated at 2022-06-24 13:03:03.255813
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_ie = SafariCourseIE()
    assert(safari_course_ie.IE_NAME == 'safari:course')
    assert(safari_course_ie.IE_DESC == 'safaribooksonline.com online courses')
    assert('safari:api' == safari_course_ie.ie_key())

# Generated at 2022-06-24 13:03:04.679995
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie._UICONF_ID == '29375172'
    assert ie._PARTNER_ID == '1926081'



# Generated at 2022-06-24 13:03:05.632699
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert isinstance(
        SafariCourseIE('safaribooksonline'), type(SafariBaseIE))

# Generated at 2022-06-24 13:03:10.045566
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    import inspect
    from .common import url_basename
    assert url_basename(SafariCourseIE._VALID_URL) == 'safari:course'
    for name, obj in inspect.getmembers(SafariCourseIE):
        if inspect.ismethod(obj) and name.startswith('_'):
            obj()



# Generated at 2022-06-24 13:03:23.212256
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import os
    import sys
    import pytest

    def get_test_data_file(filename):
        return os.path.join(os.path.dirname(__file__), 'test_data', filename)

    # Mock the getpass method in the Python getpass module
    class GetpassMock(object):

        def __init__(self):
            self.password = None

        def __call__(self, prompt):
            if self.password:
                return self.password
            raise Exception('getpass called but no password set!')

        def set_password(self, password):
            self.password = password

        def clear_password(self):
            self.password = None

    # The testcase class

# Generated at 2022-06-24 13:03:24.743014
# Unit test for constructor of class SafariIE
def test_SafariIE():
    sIE = SafariIE()
    assert (sIE.LOGGED_IN is False)

# Generated at 2022-06-24 13:03:27.892259
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    assert(isinstance(ie, SafariCourseIE))
    assert(isinstance(ie, SafariBaseIE))
    assert(isinstance(ie, InfoExtractor))

# Generated at 2022-06-24 13:03:32.970775
# Unit test for constructor of class SafariIE
def test_SafariIE():
    url = 'http://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    assert SafariIE(SafariIE.ie_key()).suitable(url)

# Generated at 2022-06-24 13:03:39.095422
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    with open('test/testdata/safaribooksonline/credentials.json') as credentials_file:
        credentials = json.load(credentials_file)
    if credentials.get('name') is None or credentials.get('password') is None:
        return
    c = SafariBaseIE({})
    c._download_webpage = lambda *args, **kwargs: None
    c._submit_form = lambda *args, **kwargs: None
    c._login()

# Generated at 2022-06-24 13:03:40.141886
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    ie.initialize()

# Generated at 2022-06-24 13:03:50.771872
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .test_utils import MockedTestCase

    class MockSafariBaseIE(SafariBaseIE):
        def _login(self):
            pass

    class MockSafariIE(MockSafariBaseIE, SafariIE):
        pass

    # Create mocks
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    video_id = '0_qbqx90ic'
    webpage = '<div data-reference-id="%s"></div>' % video_id

    # Execute unit test
    with MockedTestCase():
        assert 'Kaltura' == MockSafariIE.suitable(url)
        assert MockSafariIE.ie_key

# Generated at 2022-06-24 13:03:56.918675
# Unit test for constructor of class SafariIE
def test_SafariIE():
    course_title = 'Hadoop Fundamentals LiveLessons'
    course_id = '9780133392838'
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    sIE = SafariIE(
        {},
        {
            'url': url,
            'course_title': course_title,
            'course_id': course_id
        }
    )
    assert(sIE.get_title() == course_title)
    assert(sIE.get_course_id() == course_id)
    assert(sIE.get_url() == url)

# Generated at 2022-06-24 13:04:00.171825
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE('http://techbus.safaribooksonline.com/9780134426365')

# Generated at 2022-06-24 13:04:10.367363
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.IE_NAME == 'safari'
    assert ie._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''
    assert 'class SafariApiIE' in repr(SafariApiIE())
    assert 'class SafariIE' in repr(SafariIE())

# Generated at 2022-06-24 13:04:18.074994
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html'
    mobj = re.match(SafariApiIE._VALID_URL, url)
    urlh = compat_urllib_request.Request(url, headers={
        'Accept': 'application/json'
    })
    urlh.add_header(
        'Referer',
        'https://cdnapisec.kaltura.com/html5/html5lib/v2.37.1/mwEmbedFrame.php')
    urlh.add_header(
        'X-Requested-With',
        'XMLHttpRequest')

# Generated at 2022-06-24 13:04:28.152836
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    """
    Test the constructor of SafariBaseIE.

    This function should not make any requests.
    """
    ie = SafariBaseIE()
    assert ie.IE_NAME == 'safari'
    assert ie.IE_DESC == 'safaribooksonline.com online video'
    assert ie._VALID_URL is None
    assert ie._NETRC_MACHINE == 'safari'
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'
    assert ie.LOGGED_IN == False

# Generated at 2022-06-24 13:04:33.030810
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    ie = SafariCourseIE()
    ie.suitable(url)
    assert ie.IE_NAME == 'safari:course'


# Generated at 2022-06-24 13:04:34.385449
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie

# Generated at 2022-06-24 13:04:37.090086
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    # should not through an exception
    ie.suitable(ie._VALID_URL)
    assert ie.IE_NAME == 'safari:course'
    assert ie.IE_DESC == 'safaribooksonline.com online courses'

# Generated at 2022-06-24 13:04:39.014571
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.LOGGED_IN == False

# Generated at 2022-06-24 13:04:51.349746
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    s = SafariCourseIE()
    assert s.IE_NAME == 'safari:course'
    assert s._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'
    assert s._TESTS[0]['url'] == 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    assert s._TESTS[0]['info_dict']['id'] == '9780133392838'

# Generated at 2022-06-24 13:04:55.404796
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Check that the login info is missing by default.
    ie = SafariBaseIE()
    assert ie._get_login_info() == (None, None)

    # Check that an anonymous login is performed.
    ie = SafariBaseIE(username='anonymous')
    assert ie._get_login_info() == ('anonymous', '')

    # Check that an anonymous login is performed with a non-empty password.
    ie = SafariBaseIE(username='anonymous', password='anonymous')
    assert ie._get_login_info() == ('anonymous', '')

# Generated at 2022-06-24 13:04:58.779773
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    obj = SafariApiIE()._real_extract(url)
    assert obj['url'] == 'https://www.safaribooksonline.com/library/view/python-cookbook-3rd/9781449396459/'

# Generated at 2022-06-24 13:05:00.813259
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()
    assert safari_api_ie is not None

# Generated at 2022-06-24 13:05:04.007823
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    SafariCourseIE.suitable(url)
    return SafariCourseIE(url)

# Generated at 2022-06-24 13:05:12.885441
# Unit test for constructor of class SafariIE
def test_SafariIE():
    test_cases = [
        # test constructor
        dict(
            url='https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html',
            expected_id='0_qbqx90ic',
            expected_title='Introduction to Hadoop Fundamentals LiveLessons'
        ),
    ]
    for test_case in test_cases:
        url = test_case['url']
        # test constructor
        safarie = SafariIE(SafariBaseIE())
        info = safarie._extract_info(url=url)
        # test id
        assert info['id'] == test_case['expected_id']
        # test title
        assert info['title'] == test_case['expected_title']

# Generated at 2022-06-24 13:05:16.681142
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    not_logged_in_ie = SafariBaseIE()
    assert not_logged_in_ie.LOGGED_IN is False

    logged_in_ie = SafariBaseIE()
    logged_in_ie.LOGGED_IN = True
    assert logged_in_ie.LOGGED_IN is True

# Generated at 2022-06-24 13:05:17.895956
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE(None)


# Generated at 2022-06-24 13:05:20.646606
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    e = SafariCourseIE()
    assert e._VALID_URL == SafariCourseIE._VALID_URL

# Generated at 2022-06-24 13:05:21.363715
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-24 13:05:31.508786
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from . import safari

    input_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    instance = safari.SafariIE()
    instance._real_initialize()

    assert instance.LOGGED_IN
    assert instance.IE_NAME == 'safari'
    assert instance.IE_DESC == 'safaribooksonline.com online video'

# Generated at 2022-06-24 13:05:32.768714
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari = SafariCourseIE()
    assert isinstance(safari, SafariCourseIE)

# Generated at 2022-06-24 13:05:38.048145
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test with no login information available
    object = SafariBaseIE()
    object._real_initialize()

    # Test with login information available
    object = SafariBaseIE(username='email', password='password')
    object._real_initialize()

# Generated at 2022-06-24 13:05:47.744883
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    """Test the __init__ method of the SafariBaseIE class."""
    from .safari import SafariBaseIE

    sbie = SafariBaseIE()

    assert sbie._API_FORMAT == 'json'
    assert sbie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert sbie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert sbie._NETRC_MACHINE == 'safari'

    assert sbie.LOGGED_IN == False
    assert sbie._TEST == {'result': False, 'try_next': False}
    assert sbie._downloader == None

# Generated at 2022-06-24 13:05:48.548646
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE(None)

# Generated at 2022-06-24 13:06:02.132415
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    url = "https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json"
    course_id = '9781449396459'

# Generated at 2022-06-24 13:06:14.870040
# Unit test for constructor of class SafariIE
def test_SafariIE():
    def objWalk(obj, objPath):
        """
        
        :param obj: 
        :param objPath: 
        :return: 
        """
        if hasattr(obj, "__dict__"):
            for k,v in list(obj.__dict__.items()):
                yield (objPath, k)
                for s in objWalk(v, objPath + "/" + k):
                    yield s
        elif isinstance(obj, dict):
            for k,v in list(obj.items()):
                yield (objPath, k)
                for s in objWalk(v, objPath + "/" + k):
                    yield s
        elif isinstance(obj, list):
            for k in range(len(obj)):
                yield (objPath, str(k))

# Generated at 2022-06-24 13:06:17.688622
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    instance = ie(url='http://techbus.safaribooksonline.com/9780134426365')
    assert instance.extract()

# Generated at 2022-06-24 13:06:19.239918
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    t = SafariBaseIE()
    t._real_initialize()

# Generated at 2022-06-24 13:06:29.417816
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/00_SeriesIntro.html'
    inst = SafariBaseIE()
    inst.initialize()
    webpage, urlh = inst._download_webpage_handle(url, None)
    redirect_url = urlh.geturl()
    parsed_url = compat_urlparse.urlparse(redirect_url)
    qs = compat_parse_qs(parsed_url.query)
    assert qs['next'][0] == 'http://www.safaribooksonline.com/accounts/login/?next=' + url

# Generated at 2022-06-24 13:06:31.492256
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    test = SafariBaseIE('SafariBaseIE')
    assert isinstance(test, SafariBaseIE)

if __name__ == '__main__':
    import sys
    sys.exit(pytest.main(sys.argv[1:]))

# Generated at 2022-06-24 13:06:33.337411
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    return SafariApiIE().suitable(SafariApiIE._VALID_URL)

# Generated at 2022-06-24 13:06:41.788632
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course = SafariCourseIE('SafariCourseIE','https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    course._download_json('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json', '9781449396459', 'Downloading course JSON')


# Generated at 2022-06-24 13:06:44.897028
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    obj = SafariCourseIE()
    assert obj.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')

# Generated at 2022-06-24 13:06:48.556385
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Unit test is only meaningful if safaribooksonline.com is available
    api_ie = SafariApiIE()
    assert api_ie._check_auth()
    return

# Generated at 2022-06-24 13:06:50.251565
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .test_safari import test_SafariApiIE
    test_SafariApiIE()

# Generated at 2022-06-24 13:07:00.894903
# Unit test for constructor of class SafariIE

# Generated at 2022-06-24 13:07:10.152151
# Unit test for constructor of class SafariIE
def test_SafariIE():
    s = SafariIE()
    assert s._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''

# Generated at 2022-06-24 13:07:20.954080
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    obj = SafariApiIE()
    assert isinstance(obj, SafariBaseIE)
    assert hasattr(obj, '_real_initialize')
    assert hasattr(obj, '_real_extract')
    assert hasattr(obj, '_download_webpage_handle')
    assert hasattr(obj, '_download_json')
    assert hasattr(obj, '_download_json_handle')
    assert hasattr(obj, '_download_webpage')
    assert hasattr(obj, '_login')
    assert hasattr(obj, 'url_result')
    assert hasattr(obj, '_match_id')
    assert hasattr(obj, '_search_regex')
    assert hasattr(obj, '_API_BASE')
    assert hasattr(obj, '_API_FORMAT')

# Generated at 2022-06-24 13:07:32.807532
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Constructor of class SafariApiIE requires safaribooksonline account credentials
    # Add your credentials here to run the unit test
    username = None
    password = None
    if username is None or password is None:
        raise ValueError('Add your safaribooksonline credentials to run the unit test')

    ie = SafariApiIE()
    ie.add_default_headers({})
    ie.to_screen('Running the unit test for the constructor of class SafariApiIE')
    ie._downloader.username = username
    ie._downloader.password = password
    course_id = '9781789533358'
    part = '0_jd4j4cap'

# Generated at 2022-06-24 13:07:41.709304
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # pylint: disable=redefined-outer-name,invalid-name
    import unittest
    class TestSafariCourseIE(unittest.TestCase):
        def test_suitable_without_args(self):
            _suitable = SafariCourseIE.suitable
            SafariCourseIE.suitable = lambda url: True
            suitable = SafariCourseIE.suitable()
            SafariCourseIE.suitable = _suitable
            self.assertFalse(suitable)

        def test_suitable_with_args(self):
            suitable = SafariCourseIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314')
            self.assertTrue(suitable)
    unittest.main()
    # pylint: enable=redefined-outer-

# Generated at 2022-06-24 13:07:48.473657
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    if ie._VALID_URL is None:
        print('SafariApiIE.VALID_URL is None')
        return
    if re.match(ie._VALID_URL, 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json') is None:
        print('bad pattern of SafariApiIE.VALID_URL')
        return
    if SafariApiIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json') is False:
        print('SafariApiIE.suitable() return False for SafariApiIE')
        return

# Generated at 2022-06-24 13:07:50.675841
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    ie._login()
    assert(ie.LOGGED_IN == True)

# Generated at 2022-06-24 13:07:55.445760
# Unit test for constructor of class SafariIE
def test_SafariIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    inst = SafariIE(url)
    assert inst.title == 'Introduction to Hadoop Fundamentals LiveLessons'

# Generated at 2022-06-24 13:07:56.137537
# Unit test for constructor of class SafariIE
def test_SafariIE():
    pass

# Generated at 2022-06-24 13:07:59.741866
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Verify safari api url with json format
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    test_SafariCourseIE(url)
