

# Generated at 2022-06-22 08:08:29.702070
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    instance = SafariApiIE()
    assert (instance.IE_DESC == 'safaribooksonline.com online video')

# Generated at 2022-06-22 08:08:31.803814
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Initializing object with kwargs
    assert SafariBaseIE(course_id='9781449396459').IE_NAME == 'safari'

# Generated at 2022-06-22 08:08:32.856627
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE('safari')

# Generated at 2022-06-22 08:08:36.080792
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    coursera = SafariBaseIE()
    # Invalid URL
    with coursera.assertRaisesRegexp(ExtractorError, 'Invalid URL'):
        coursera.url_result('http://www.invalid-website.com', 'Kaltura')

# Generated at 2022-06-22 08:08:36.970945
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE('', False)


# Generated at 2022-06-22 08:08:38.692694
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # This should not fail
    SafariCourseIE()

# Generated at 2022-06-22 08:08:43.009640
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    SafariApiIE(SafariBaseIE())._real_extract(url)

# Generated at 2022-06-22 08:08:45.677149
# Unit test for constructor of class SafariIE
def test_SafariIE():
    device_id = 'test_device_id'
    entry = SafariBaseIE(device_id=device_id)
    assert device_id == entry._device_id

# Generated at 2022-06-22 08:08:47.594649
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    instance = SafariBaseIE(None)
    assert not instance.LOGGED_IN

# Generated at 2022-06-22 08:08:51.374097
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.IE_NAME == 'safari'
    assert safari_ie.IE_DESC == 'safaribooksonline.com online video'

# Generated at 2022-06-22 08:09:18.269536
# Unit test for constructor of class SafariIE
def test_SafariIE():
    sa = SafariIE()
    sa = SafariApiIE()
    sa = SafariCourseIE()

# Generated at 2022-06-22 08:09:30.908957
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    mocker = getattr(pytest, 'mocker', None)
    if mocker is None:
        pytest.skip('pytest-mock is not available')

    _call_with_kwargs = mocker.patch('youtube_dl.downloader.http.HttpFD._call_with_kwargs')
    _resolve_redirects = mocker.patch('youtube_dl.downloader.http.HttpFD._resolve_redirects')

    ie = SafariBaseIE()
    ie._download_webpage_handle('http://example.com', 'test')

    _resolve_redirects.assert_called_once()
    _resolve_redirects.reset_mock()

    _call_with_kwargs.assert_called_once()
    _call_with_kwargs.reset_mock()



# Generated at 2022-06-22 08:09:32.708141
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    site = SafariBaseIE()
    print(site)
    assert site is not None

# Generated at 2022-06-22 08:09:41.863674
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .common import fake_urlopen

    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    course_id = '9781449396459'
    part = 'part00'


# Generated at 2022-06-22 08:09:46.237110
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    parse_me = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    base_ie_type = SafariCourseIE.suitable(parse_me)
    assert(base_ie_type == 'SafariCourse')

# Generated at 2022-06-22 08:09:58.739636
# Unit test for constructor of class SafariCourseIE

# Generated at 2022-06-22 08:10:04.885826
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class safariBaseIE(SafariBaseIE):
        _API_BASE = '%s/test'
        _API_FORMAT = 'json'
    sb = safariBaseIE()
    assert sb._API_BASE == '%s/test'
    assert sb._API_FORMAT == 'json'

# Generated at 2022-06-22 08:10:07.629708
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE();
    assert(safari is not None)
    assert(safari.__class__.__name__ == 'SafariIE')
# Test function: test_SafariIE

# Generated at 2022-06-22 08:10:11.578407
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    try:
        class TestClass(SafariBaseIE):
            pass

        safari = TestClass()
    except Exception as e:
        raise

    assert(isinstance(safari, InfoExtractor))

# Generated at 2022-06-22 08:10:22.075749
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # pylint: disable=protected-access
    assert hasattr(SafariBaseIE, '_download_json')
    assert hasattr(SafariBaseIE, '_download_webpage_handle')
    assert hasattr(SafariBaseIE, '_LOGIN_URL')
    assert hasattr(SafariBaseIE, '_NETRC_MACHINE')
    assert hasattr(SafariBaseIE, '_API_BASE')
    assert hasattr(SafariBaseIE, '_API_FORMAT')
    assert hasattr(SafariBaseIE, 'LOGGED_IN')
    assert hasattr(SafariBaseIE, '_login')


# Generated at 2022-06-22 08:11:01.568239
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    """
    This test is designed to check whether the SafariBaseIE() constructor
    can be used to construct an object. This may be a good indication
    that the SafariBaseIE() constructor is not broken by any change to
    the code.
    """
    SafariBaseIE(SafariIE.IE_NAME,SafariIE.IE_DESC)

# Generated at 2022-06-22 08:11:04.603499
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .test_tools import instance_test
    assert instance_test(SafariApiIE)


# Generated at 2022-06-22 08:11:12.246120
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """
    Unit test for constructor of class SafariIE
    """

    # Case: It is not safari courses or chapters.
    course_url = "https://www.safaribooksonline.com/library/view/python-programming-language/9780134217314"
    video_url = "https://www.safaribooksonline.com/library/view/python-programming-language/9780134217314/9780134217314-PYMC_1_3"
    chapter_url = "https://www.safaribooksonline.com/api/v1/book/9780134664057/chapter/RHCE_Introduction.html"
    safari_ie = SafariIE()
    # Case: url is not a safari course or chapter
    assert safari_ie.suitable(course_url)

# Generated at 2022-06-22 08:11:15.073879
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Check what happens when none of login info is present
    # SafariBaseIE should not fail on it
    SafariBaseIE()

# Generated at 2022-06-22 08:11:26.228305
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import pytest
    from .common import compat_etree_fromstring
    from .common import unescapeHTML
    from .common import xpath_text
    credentials = {'username': 'filmsbykris.com'}
    safari_ie = SafariIE('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html', credentials=credentials)

    assert safari_ie._download_webpage_handle == safari_ie.ie._download_webpage_handle
    assert safari_ie._download_json_handle == safari_ie.ie._download_json_handle
    assert safari_ie._download_xml_handle == safari_ie.ie._download_xml_handle
    assert safari_ie._

# Generated at 2022-06-22 08:11:33.101899
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    """
    If a safaribooksonline user credentials are present,
    do not trigger an oauth2 login.
    """
    import os.path
    import tempfile
    import json
    from ..utils import sanitize_open
    from ..downloader import read_netrc

    netrc_contents = r"""
            machine safari
                login <login_1>
                password <password_1>
            machine learning.oreilly.com
                login <login_2>
                password <password_2>
    """

    with tempfile.NamedTemporaryFile(mode='wt') as netrc_contents_f:
        netrc_contents_f.write(netrc_contents)
        netrc_contents_f.flush()
        netrc_filename = netrc_contents_f.name


# Generated at 2022-06-22 08:11:34.175536
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE('test')
    assert True

# Generated at 2022-06-22 08:11:35.296338
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()


# Generated at 2022-06-22 08:11:37.281330
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE('SafariBaseIE', 'Safari Online')
    assert ie.login

# Generated at 2022-06-22 08:11:42.528697
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # construct SafariIE using SafariIE.suitable() and SafariIE.ie_key()
    # and check if it is instance of SafariIE
    assert isinstance(SafariIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')[0](), SafariIE)

# Generated at 2022-06-22 08:12:54.427050
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()

    assert ie._NETRC_MACHINE == 'safari'

# Generated at 2022-06-22 08:13:06.326843
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://techbus.safaribooksonline.com/9781449396459'
    course_id = '9781449396459'
    json_url = 'http://learning.oreilly.com/api/v1/book/9781449396459/?override_format=json'
    course_title = 'Learning Python, 3rd Edition'

# Generated at 2022-06-22 08:13:16.259330
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    import sys
    import os.path

    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
    from youtube_dl.YoutubeDL import safe_eval
    from youtube_dl.utils import match_filter_func
    from youtube_dl.extractor.safari import SafariCourseIE

    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    match_filter = safe_eval('''
        lambda url: url.startswith('https://www.safaribooksonline.com/library/view/')
    ''')
    assert match_filter(url)
    match_filter_func.append(match_filter)
    info_dicts

# Generated at 2022-06-22 08:13:17.805988
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    testSafariBaseIE = SafariBaseIE()
    testSafariBaseIE._get_login_info()

# Generated at 2022-06-22 08:13:20.874989
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert isinstance(
        SafariApiIE(
            compat_urllib_request.Request(
                'http://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html?override_format=json')),
        SafariApiIE)

# Generated at 2022-06-22 08:13:22.897245
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert isinstance(SafariBaseIE(None)._login(), bool)

# Generated at 2022-06-22 08:13:32.427155
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Check that an exception is raised if there is no URL
    assert SafariCourseIE()._VALID_URL == r'''(?x)
                    https?://
                        (?:
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+|
                                api/v1/book|
                                videos/[^/]+
                            )|
                            techbus\.safaribooksonline\.com
                        )
                        /(?P<id>[^/]+)
                    '''

# Generated at 2022-06-22 08:13:34.851680
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    IE = SafariBaseIE('Safari')
    IE._real_initialize()
    assert (IE.LOGGED_IN)

# Generated at 2022-06-22 08:13:44.600622
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE(None, None)
    ie.LOGGED_IN = False
    assert ie.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/', None)
    assert not ie.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html', None)
    assert not ie.suitable('https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html', None)

# Generated at 2022-06-22 08:13:54.277801
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    """Unit tests for SafariBaseIE class constructor."""
    from ..compat import mock
    from io import StringIO
    import httpretty
    from ..cache import compat_etree_fromstring

    class TestSafariBaseIE(SafariBaseIE):
        _LOGIN_URL = 'https://www.test.com/accounts/login/'
        _NETRC_MACHINE = 'testmachine'

        def _real_initialize(self):
            pass

    ie = TestSafariBaseIE()


# Generated at 2022-06-22 08:14:58.624924
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    t = SafariCourseIE()
    t = SafariCourseIE()

# Generated at 2022-06-22 08:15:10.141032
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_IE = SafariApiIE(
        'http://www.safaribooksonline.com/videos/python-programming-language/9780134217314/9780134217314-PYMC_13_00/python-programming-language-9780134217314-PYMC_13_00',
        'safari')
    assert safari_api_IE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/') is True
    assert safari_api_IE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/') is True

# Generated at 2022-06-22 08:15:12.064008
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    (SafariBaseIE())

# Generated at 2022-06-22 08:15:13.030023
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE({})


# Generated at 2022-06-22 08:15:17.040559
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    TestSafariApiIE = SafariApiIE('SafariApiIE', 'http://example.com')
    assert isinstance(TestSafariApiIE, SafariApiIE)


# Generated at 2022-06-22 08:15:17.664961
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()


# Generated at 2022-06-22 08:15:29.134593
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    obj = SafariApiIE()

    # test the constructor only
    assert obj._VALID_URL == 'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Generated at 2022-06-22 08:15:30.952318
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    youtube_ie = SafariCourseIE()
    assert youtube_ie is not None
    

# Generated at 2022-06-22 08:15:33.301032
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    test_instance = SafariBaseIE()
    return (test_instance.IE_NAME and test_instance.IE_DESC
            and test_instance.LOGGED_IN == False)

# Generated at 2022-06-22 08:15:40.475080
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    class MockIE(SafariBaseIE):
        pass
    assert SafariCourseIE.suitable('http://techbus.safaribooksonline.com/9780134426365')
    assert not SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert not SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert not SafariCourseIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314')