

# Generated at 2022-06-22 08:08:30.976130
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Ignore these import warnings caused by 'safari' module
    # They should not be logged as ERROR
    from ..compat import unittest
    import warnings
    class NullHandler(logging.Handler):
        def emit(self, record):
            pass
    logging.getLogger('youtube_dl').addHandler(NullHandler())

    warnings.simplefilter('ignore', compatibility.CompatibilityWarning)
    warnings.simplefilter('ignore', SubjectAltNameWarning)

    test = unittest.TestCase()

    # Instantiating safari class
    assert SafariIE

# Generated at 2022-06-22 08:08:34.540990
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class TestSafariBaseIE(SafariBaseIE):
        _API_BASE = 'http://test_api'

    ie = TestSafariBaseIE({})
    ie._login()

    assert TestSafariBaseIE._API_BASE == 'http://test_api'

# Generated at 2022-06-22 08:08:35.245011
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert type(SafariIE()) is SafariIE


# Generated at 2022-06-22 08:08:39.589032
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from io import StringIO
    from tests.test_dev_simple import test_description
    from safari import SafariIE
    from urllib.error import HTTPError
    from urllib.response import addinfourl

    class DummyURLHandle:
        def geturl(self):
            return 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'

    class DummyURLHandle2:
        def geturl(self):
            return 'https://learning.oreilly.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'


# Generated at 2022-06-22 08:08:42.007514
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    obj = SafariApiIE()
    obj._login()
    assert obj.LOGGED_IN

# Generated at 2022-06-22 08:08:43.059993
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE('safari')

# Generated at 2022-06-22 08:08:44.103500
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    v = SafariCourseIE()

# Generated at 2022-06-22 08:08:55.834099
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    mobj = re.match(SafariApiIE._VALID_URL, url)
    course_id = mobj.group('course_id')
    # Test SafariApiIE._real_extract
    # Downloading part JSON
    part = 'part01'
    url = 'https://www.safaribooksonline.com/api/v1/book/{0}/chapter/{1}.html'.format(course_id, part)
    SafariApiIE()._download_json(url, '%s/%s' % (course_id, part), 'Downloading part JSON')
    # Check SafariApiIE()._download_json: title, query

# Generated at 2022-06-22 08:09:03.929544
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE.suitable("http://techbus.safaribooksonline.com/9780596001433")
    SafariCourseIE.suitable("https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/")
    SafariCourseIE.suitable("https://www.safaribooksonline.com/api/v1/book/9780132350884/?override_format=json")
    SafariCourseIE.suitable("https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838")

# Generated at 2022-06-22 08:09:08.787508
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Create a test for SafariCourseIE
    course = SafariCourseIE('test', 'Safari Course Test')

    # Check that the class of course is SafariCourseIE
    assert isinstance(course, SafariCourseIE)

    # Check that the name of the course is 'test'
    assert course._NAME == 'test'

# Generated at 2022-06-22 08:09:23.582878
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE('SafariIE downloader', '')

# Generated at 2022-06-22 08:09:24.619118
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE('Kaltura')

# Generated at 2022-06-22 08:09:33.987200
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """Test if constructor of SafariIE class is working properly"""
    # Set up a Mock object
    mock_response = [{'baseurl': 'http://baseurl.json'}, {'baseurl2': 'http://baseurl2.json'}, {'baseurl3': 'http://baseurl3.json'}]
    # Create an instance of InfoExtractor
    mock_instance = InfoExtractor({'_download_json': lambda x: mock_response, '_download_json_handle': lambda x, y: (y, x)})

    # Create an instance of SafariIE class using InfoExtractor instance so that overridden method _download_json_handle can be tested
    safariIE = SafariIE(mock_instance) # pylint: disable=abstract-class-instantiated
    # Call _real_initialize method with the mock object

# Generated at 2022-06-22 08:09:35.503580
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()
    assert safari.LOGGED_IN

# Generated at 2022-06-22 08:09:41.321796
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test login succeeds with correct credentials
    test_ie = SafariBaseIE('username', 'password')
    test_ie._login()
    assert test_ie.LOGGED_IN
    # Test login fails with incorrect credentials
    test_ie = SafariBaseIE('username', 'incorrect_password')
    test_ie._login()
    assert not test_ie.LOGGED_IN

# Generated at 2022-06-22 08:09:43.205858
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()
    assert isinstance(safari, SafariIE)


# Generated at 2022-06-22 08:09:45.093864
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert isinstance(SafariApiIE()._downloader, InfoExtractor)


# Generated at 2022-06-22 08:09:52.454752
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .test_safari import _create_mock_urlopen


# Generated at 2022-06-22 08:10:02.951314
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert 'safaribooksonline' in SafaribooksonlineIE.__doc__
    assert 'safaribooksonline' in SafaribooksonlineIE.ie_key()
    assert 'safaribooksonline' in SafariApiIE.ie_key()

    assert hasattr(SafaribooksonlineIE, "suitable")
    assert hasattr(SafaribooksonlineIE, "_real_extract")
    assert hasattr(SafaribooksonlineIE, "_login")
    assert hasattr(SafaribooksonlineIE, "ie_key")
    assert hasattr(SafaribooksonlineIE, "ie")

    course = SafaribooksonlineIE(SafariCourseIE(), None)
    assert current_video == course._real_extract(url)

# Generated at 2022-06-22 08:10:03.495848
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    pass


# Generated at 2022-06-22 08:10:39.581242
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()



# Generated at 2022-06-22 08:10:40.684933
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE(SafariBaseIE)

# Generated at 2022-06-22 08:10:43.235023
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    i = SafariBaseIE()
    assert i.__class__.__name__ == 'SafariBaseIE'


# Generated at 2022-06-22 08:10:47.573581
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()

    assert safari_api_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_api_ie._API_FORMAT == 'json'
    assert safari_api_ie.LOGGED_IN == False

# Generated at 2022-06-22 08:10:51.046611
# Unit test for constructor of class SafariIE
def test_SafariIE():
    course_id = '9780133392838'
    assert not SafariIE(SafariCourseIE({'id': course_id}), course_id).LOGGED_IN

# Generated at 2022-06-22 08:10:53.877628
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    print(ie)


if __name__ == '__main__':
    test_SafariApiIE()

# Generated at 2022-06-22 08:10:57.350982
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .test_downloader import get_testcases

    testcases = get_testcases(SafariIE, ie=SafariIE.ie_key())

    for testcase in testcases:
        testcase(SafariIE)



# Generated at 2022-06-22 08:10:59.874098
# Unit test for constructor of class SafariIE
def test_SafariIE():
    unit_test = SafariIE()
    unit_test._login()
    assert unit_test.LOGGED_IN is not False

# Generated at 2022-06-22 08:11:11.522986
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    parsed = urlparse('https://learning.oreilly.com/videos/serverless-bootcamp/9781492055449-00-1')
    entry = SafariBaseIE().url_result(parsed.geturl())
    assert entry['_type'] == 'url_transparent'
    assert entry['ie_key'] == 'Kaltura'

    parsed = urlparse('https://learning.oreilly.com/videos/serverless-bootcamp/9781492055449-00-1')
    entry = SafariBaseIE().url_result(parsed.geturl())
    assert entry['_type'] == 'url_transparent'
    assert entry['ie_key'] == 'Kaltura'


# Generated at 2022-06-22 08:11:14.169566
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE.suitable('https://learning.oreilly.com/videos/microsoft-azure-fundamentals/9780135264919') == True



# Generated at 2022-06-22 08:12:09.757566
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert isinstance(SafariCourseIE(), InfoExtractor)


# Generated at 2022-06-22 08:12:20.564612
# Unit test for constructor of class SafariIE
def test_SafariIE():
    hostname = 'cdnapisec.kaltura.com'
    user_agent = 'Test'
    url = 'https://cdnapisec.kaltura.com/html5/html5lib/v2.37.1/mwEmbedFrame.php'\
          '?wid=_1926081&uiconf_id=29375172&entry_id=0_qbqx90ic'
    netrc_machine = SafariBaseIE._NETRC_MACHINE

    opentab_ytdl_installed_check = True

# Generated at 2022-06-22 08:12:21.821116
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api = SafariApiIE()
    assert safari_api.ie_key() == 'SafariApiIE'

# Generated at 2022-06-22 08:12:23.588561
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # No credential provided
    safariBaseIE = SafariBaseIE(None)

    assert safariBaseIE.LOGGED_IN == False


# Generated at 2022-06-22 08:12:24.602672
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    constructor = SafariCourseIE.ie_key()

    assert constructor is not None

# Generated at 2022-06-22 08:12:27.042936
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert SafariApiIE('SafariApi')._API_BASE == 'https://learning.oreilly.com/api/v1'

# Generated at 2022-06-22 08:12:28.965131
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE({'ie': 'safari:api'})
    assert ie.IE_NAME == 'safari:api'
    assert ie.LOGGED_IN == False

# Generated at 2022-06-22 08:12:34.607153
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    print ("\nRunning test_SafariBaseIE...")
    pl_id = '9780133392838'
    ent_id = '1bafcff7-11a0-418b-a93b-e92fe7fc0034'
    e = SafariBaseIE()

    # Test _real_initialize
    e._real_initialize()
    assert e.LOGGED_IN == False
    assert e.username == 'safari'
    assert e._password == 'password'

    # Test _real_extract
    assert e._real_extract('https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838/') == None

# Generated at 2022-06-22 08:12:35.890281
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()


# Generated at 2022-06-22 08:12:42.496129
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # These tests should be last because they perform real account login
    # with given username and password.

    # Test login with incorrect email/username
    for url in ('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json',
                'https://www.safaribooksonline.com/videos/python-programming-language/9780134217314'):
        course_id = re.match(SafariCourseIE._VALID_URL, url).group('id')

        for username, password in (
                ('incorrect@example.org', 'incorrect'),
                ('incorrect', 'incorrect'),
                (None, 'incorrect'),
                ('incorrect', None)):
            ie = SafariCourseIE(username=username, password=password)

# Generated at 2022-06-22 08:14:57.289943
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'
    assert ie.LOGGED_IN == False
    assert ie.ie_key() == 'SafariApi'

# Generated at 2022-06-22 08:15:02.868622
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert ie._VALID_URL == 'https?://(?:www\\.)?(?:safaribooksonline|(?:learning\\.)?oreilly)\\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\\.html'

# Generated at 2022-06-22 08:15:05.149450
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safaricourse_ie = SafariCourseIE()
    assert safaricourse_ie.suitable(SafariCourseIE._VALID_URL)

# Generated at 2022-06-22 08:15:06.540790
# Unit test for constructor of class SafariIE
def test_SafariIE():
    obj = SafariIE('http://techbus.safaribooksonline.com/9780134426365')
    assert obj.__class__.__name__ == 'SafariIE'

# Generated at 2022-06-22 08:15:14.215165
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from ..compat import compat_urllib_request
    from ..downloader.common import E

    class MockOpenerDirector(compat_urllib_request.OpenerDirector):
        def open(self, *args, **kwargs):
            return compat_urllib_request.OpenerDirector.open(self, *args, **kwargs)
    compat_urllib_request.OpenerDirector = MockOpenerDirector

    class MockCookieProcessor(compat_urllib_request.HTTPCookieProcessor):
        def __init__(self, *args, **kwargs):
            self.cookiejar = compat_urllib_request.CookieJar()
        def http_request(self, *args, **kwargs):
            return compat_urllib_request.HTTPCookieProcessor.http_request

# Generated at 2022-06-22 08:15:26.404954
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    a=SafariApiIE(SafariBaseIE)
    a.ie_name = 'safari:api'
    a.username = 'longdangle'
    a.password = 'longdangle'
    a.video_password = 'hello'
    a._session_id = 'id'
    a._access_token = 'token'
    a._initialize_geo_bypass()
    a.report_warning('warning')
    a.report_age_confirmation()
    a.report_download_webpage(None)
    a.to_screen('test')
    a.to_stdout('test')
    a.to_stderr('test')
    a._download_webpage(None, None, None)
    a._download_json(None, None, None)
    a._download

# Generated at 2022-06-22 08:15:27.913069
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    return SafariApiIE('SafariApiIE', test = True)

# Generated at 2022-06-22 08:15:29.778341
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_baseie = SafariBaseIE()
    safari_baseie._real_initialize()

# Generated at 2022-06-22 08:15:37.984477
# Unit test for constructor of class SafariIE
def test_SafariIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'

    # Mock _download_webpage_handle to return page content
    def _download_webpage_handle(request_data, *args, **kwargs):
        with open('test/data/hadoop.html', 'rb') as f:
            page_content = f.read()
        return page_content, None

    # Mock _download_json_handle to return login data
    def _download_json_handle(request_data, *args, **kwargs):
        with open('test/data/oreilly.json', 'rb') as f:
            login_json = f.read()
        return json.loads(login_json), None



# Generated at 2022-06-22 08:15:50.106856
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    course_id = SafariCourseIE._match_id(url)
    course_json = SafariCourseIE._download_json(
        'https://learning.oreilly.com/api/v1/book/9780133392838/?override_format=json',
        course_id, 'Downloading course JSON')
    assert course_id == '9780133392838'
    assert course_json['title'] == 'Hadoop Fundamentals LiveLessons'
    assert course_json['publisher'] == 'Pearson Education'
    assert course_json['authorDisplayNames'] == ['Chris Richardson', 'Michael Noll']