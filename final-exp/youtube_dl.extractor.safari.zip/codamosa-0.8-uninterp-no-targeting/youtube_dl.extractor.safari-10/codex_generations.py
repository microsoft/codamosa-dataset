

# Generated at 2022-06-22 08:08:36.853727
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from ..testcases import IE_TEST


# Generated at 2022-06-22 08:08:41.597183
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safariBaseIE = SafariBaseIE("testing")
    if safariBaseIE is None:
        raise AssertionError("Failed to construct SafariBaseIE")
    return safariBaseIE


# Generated at 2022-06-22 08:08:52.783388
# Unit test for constructor of class SafariBaseIE

# Generated at 2022-06-22 08:08:56.607849
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import unittest

    class TestSafariIE(unittest.TestCase):
        def test_safariIE(self):
            self.assertTrue(SafariIE())

    unittest.main(argv=['rerun: -v'])

# Generated at 2022-06-22 08:08:57.989143
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    k = SafariApiIE()

# Generated at 2022-06-22 08:09:01.267302
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safariBase = SafariBaseIE()
    assert hasattr(safariBase, '_login')
    assert hasattr(safariBase, '_real_initialize')
    assert hasattr(safariBase, '_get_login_info')

# Generated at 2022-06-22 08:09:12.481122
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    cls = SafariCourseIE
    assert cls.suitable('https://techbus.safaribooksonline.com/9780134426365')
    assert cls.suitable('https://www.oreilly.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert not cls.suitable('https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838')
    assert not cls.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')

# Generated at 2022-06-22 08:09:15.101310
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    constructor_test(SafariBaseIE, [])

# Generated at 2022-06-22 08:09:20.626409
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import requests
    import requests_mock
    import requests_mock_test

    m = requests_mock.Mocker()
    with m:
        url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
        m.get(url)
        r = requests.get(url)

    #
    # Test: Downloading part JSON
    #
    with requests_mock_test.mock(m):
        SafariApiIE()._real_extract(url)

    assert r.request.url == url

# Generated at 2022-06-22 08:09:28.247210
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    try:
        from urllib.request import build_opener, HTTPCookieProcessor
        from http.cookiejar import CookieJar
    except ImportError:
        from urllib2 import build_opener, HTTPCookieProcessor
        from cookielib import CookieJar
    opener = build_opener(HTTPCookieProcessor(CookieJar()))
    safari = SafariApiIE()
    safari.http = lambda *args, **kargs: opener.open(*args, **kargs)

# Generated at 2022-06-22 08:09:50.883168
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    test = {
        'url': 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/',
        'info_dict': {
            'id': '9780133392838',
            'title': 'Hadoop Fundamentals LiveLessons',
        },
        'playlist_count': 22,
        'skip': 'Requires safaribooksonline account credentials',
    }
    # constructor of class SafariCourseIE
    SafariCourseIE().suitable(test['url'])

# Generated at 2022-06-22 08:09:53.948696
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    url = "http://learning.oreilly.com/library/view/ruby-on-rails/9780596153836/"
    obj = SafariBaseIE()
    obj._login()

# Generated at 2022-06-22 08:09:58.270603
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    test_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    safari_course = SafariCourseIE(test_url, 0)
    assert safari_course



# Generated at 2022-06-22 08:09:59.589128
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()
    safari.initialize()
    return

# Generated at 2022-06-22 08:10:01.389021
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    safari_ie.IE_DESC


# Generated at 2022-06-22 08:10:05.938084
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    obj = SafariCourseIE()
    assert obj.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')

# Generated at 2022-06-22 08:10:14.483227
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """Unit test for constructor of class SafariApiIE."""
    import safari.SafariApiIE
    expected_instance_type = safari.SafariApiIE.SafariApiIE
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    ie_instance = expected_instance_type.suitable(url)
    assert(isinstance(ie_instance, expected_instance_type))



# Generated at 2022-06-22 08:10:17.845002
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    def test_SafariCourseIE(instance):
        instance._real_initialize()
        assert instance.LOGGED_IN is False or instance.LOGGED_IN == True

# Generated at 2022-06-22 08:10:19.886148
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # type: () -> None
    """Unit test for constructor of class SafariIE"""
    SafariIE('Safari')

# Generated at 2022-06-22 08:10:22.851372
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test is not implemented, but we check if it is not empty
    test_safari_ie = SafariIE()
    assert test_safari_ie.__dict__ != {}



# Generated at 2022-06-22 08:11:03.545983
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie is not None

# Generated at 2022-06-22 08:11:04.753478
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE(SafariBaseIE)

# Generated at 2022-06-22 08:11:09.546553
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert not SafariIE.suitable(SafariCourseIE.suitable)
    assert SafariIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838')
    assert SafariIE.suitable('https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html')

# Generated at 2022-06-22 08:11:11.083876
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    inst = SafariApiIE()
    assert inst.LOGGED_IN == False

# Generated at 2022-06-22 08:11:14.367433
# Unit test for constructor of class SafariIE
def test_SafariIE():
    mocker.patch(
        'youtube_dl.extractor.common.InfoExtractor._set_cookie',
        lambda *_, **__: None)

    SafariIE('SafariIE', 'safaribooksonline.com')

# Generated at 2022-06-22 08:11:25.677197
# Unit test for constructor of class SafariIE
def test_SafariIE():
    try:
        assert(SafariIE._API_BASE == 'https://learning.oreilly.com/api/v1')
    except AssertionError:
        print("Assertion Error: the _API_BASE value should be 'https://learning.oreilly.com/api/v1'")
        exit(1)
    try:
        assert(SafariIE._API_FORMAT == 'json')
    except AssertionError:
        print("Assertion Error: the _API_FORMAT value should be 'json'")
        exit(1)

# Generated at 2022-06-22 08:11:28.703407
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    IE_SafariBase = SafariBaseIE._build_ie('SafariBase')
    IE_SafariBase.set_user_agent('test')
    assert IE_SafariBase._VALID_URL == ''

# Generated at 2022-06-22 08:11:33.249473
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert SafariApiIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')

# Generated at 2022-06-22 08:11:36.620693
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    assert ie.__class__.__bases__[0] == SafariBaseIE
    assert ie.__class__.__bases__[1] == InfoExtractor



# Generated at 2022-06-22 08:11:46.933817
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    import sys
    from contextlib import contextmanager
    from io import StringIO
    from ntlm import ntlm

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    ie = SafariBaseIE()
    ie.methods = {'_login': lambda: ie._print('login')}
    ie._real_initialize()
    assert len(ntlm.HTTPNtlmAuthHandler.passwd) == 0

# Generated at 2022-06-22 08:13:06.655764
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()
    url = "https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html"
    safari_api_ie.extract(url)

# Generated at 2022-06-22 08:13:15.689908
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    def test_true_on_suitable(url):
        assert SafariCourseIE.suitable(url)
    test_true_on_suitable('https://www.safaribooksonline.com/library/view/python-in-a/1369343374/')
    test_true_on_suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/')
    test_true_on_suitable('https://techbus.safaribooksonline.com/9780134426365')

# Generated at 2022-06-22 08:13:22.774285
# Unit test for constructor of class SafariIE
def test_SafariIE():  # pylint: disable=invalid-name
    safari_chapter = SafariIE()
    test_urllist = [
        'https://www.safaribooksonline.com/videos/python-programming-language/9780134217314/9780134217314-PYMC_13_00',
        'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html']
    for url in test_urllist:
        safari_chapter._match_id(url)

    safari_course = SafariCourseIE()

# Generated at 2022-06-22 08:13:32.257056
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .common import _prepare_url_result_set
    from .kaltura import KalturaIE

    safari_url_set = _prepare_url_result_set(SafariIE)
    kaltura_url_set = _prepare_url_result_set(KalturaIE)

    url_set = safari_url_set.difference(kaltura_url_set)

    assert len(safari_url_set) > len(url_set)
    assert safari_url_set.isdisjoint(kaltura_url_set)

# Generated at 2022-06-22 08:13:42.646575
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Verifies that a missing cookie raises an ExtractorError
    try:
        SafariBaseIE._apply_first_set_cookie_header(None, 'anycookie')
        assert False
    except ExtractorError as e:
        assert e.message == 'Cannot find cookie'
    except:
        assert False

    # Verifies that an unexpected cookie raises an ExtractorError

# Generated at 2022-06-22 08:13:47.686356
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    il = SafariBaseIE()
    il.initialize()
    il.login()

# Generated at 2022-06-22 08:13:53.366083
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safariApi = SafariBaseIE(None)
    safariApi._API_BASE = 'https://learning.oreilly.com/api/v1'
    safariApi._API_FORMAT = 'json'
    safariApi._NETRC_MACHINE = 'safari'

# Generated at 2022-06-22 08:13:54.381943
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    t = SafariCourseIE()

# Generated at 2022-06-22 08:13:55.814707
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE(SafariCourseIE.ie_key(), {})

# Generated at 2022-06-22 08:13:57.234970
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari = SafariBaseIE()
    assert safari.IE_DESC is not None
    assert safari.LOGGED_IN is False

# Generated at 2022-06-22 08:16:29.658024
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE(object())

# Generated at 2022-06-22 08:16:31.888432
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'

# Generated at 2022-06-22 08:16:36.459771
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course = SafariCourseIE('SafariCourseIE')
    assert course == SafariCourseIE('SafariCourseIE')
    assert course != SafariCourseIE('SafariApiIE')

# Generated at 2022-06-22 08:16:45.264098
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .test import get_testcases
    from .common import merge_dicts

    class MockSafariIE(SafariIE):

        @classmethod
        def _build_request(cls, _url):
            return {'method': 'POST', 'url': _url}

    cases = get_testcases(SafariCourseIE, {'ie': MockSafariIE})
    return [
        merge_dicts({'expected': {'method': 'POST'}}, case)
        for case in cases
        if case['expected'].get('method') == 'GET'
    ]

# Generated at 2022-06-22 08:16:49.553293
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    import unittest
    suite = unittest.TestSuite()
    safariCourseObj = SafariCourseIE()
    suite.addTest(unittest.makeSuite(safariCourseObj))
    runner = unittest.TextTestRunner()
    runner.run(suite)
# ----------------------------------------------------------------------------------------------------------------------

# Generated at 2022-06-22 08:16:53.807042
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_ie = SafariCourseIE()
    assert safari_course_ie.IE_NAME == 'safari:course'
    assert safari_course_ie.IE_DESC == 'safaribooksonline.com online courses'

if __name__ == '__main__':
    test_SafariCourseIE()

# Generated at 2022-06-22 08:16:54.420796
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    pass


# Generated at 2022-06-22 08:16:55.313244
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE('Kaltura', None)

# Generated at 2022-06-22 08:16:58.041215
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safariBase = SafariBaseIE()

# Generated at 2022-06-22 08:17:07.056214
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    import sys
    import os
    import argparse
    from HTMLParser import HTMLParser

    sys.path.append(os.path.dirname(os.path.realpath(__file__)))

    from youtube_dl.utils import match_filter_func
    from safaribooksonline.compat import (
        compat_etree_fromstring,
        compat_parse_qs,
        compat_urllib_parse_urlparse,
        compat_urllib_request,
        compat_urllib_error,
        compat_urllib_error_HTTPError,
        compat_urllib_request_build_opener,
    )

    class ExtractorError(Exception):
        """Error during info extraction."""
