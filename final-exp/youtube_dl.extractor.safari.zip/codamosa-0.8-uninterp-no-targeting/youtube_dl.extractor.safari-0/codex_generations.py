

# Generated at 2022-06-22 08:08:28.619697
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .common import test_construtor
    test_construtor(SafariCourseIE)

# Generated at 2022-06-22 08:08:29.217808
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    raise



# Generated at 2022-06-22 08:08:33.205858
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    base_ie = SafariBaseIE('SafariIE', 'safaribooksonline.com', {})
    assert 'SafariIE' == base_ie.ie_key()
    assert 'safaribooksonline.com' == base_ie.ie_name
    assert {} == base_ie.info_dict

# Generated at 2022-06-22 08:08:37.148262
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # as constructor of classes inherited from SafariBaseIE
    # calls _real_initialize method we need to override it
    # in order to avoid real downloading (which needs access to web)
    class FakeSafariBaseIE(SafariBaseIE):
        def _real_initialize(self):
            pass

    FakeSafariBaseIE()

# Generated at 2022-06-22 08:08:41.364584
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()
    assert safari._NETRC_MACHINE == 'safari'
    assert safari.LOGGED_IN == False



# Generated at 2022-06-22 08:08:44.965688
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE('', '', {})
    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-22 08:08:46.821677
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    ie.suitable('')


# Generated at 2022-06-22 08:08:48.022746
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert SafariIE()



# Generated at 2022-06-22 08:08:55.157444
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Given a URL
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'

    # Constructing a SafariApiIE by calling its constructor
    ie = SafariApiIE()

    # Asserting that the SafariApiIE is decorated with SafariBaseIE
    assert ie.__class__.__bases__[0].__name__ == 'SafariBaseIE'

# Generated at 2022-06-22 08:08:57.737884
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari = SafariBaseIE()

# Generated at 2022-06-22 08:09:12.951953
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    inst = SafariCourseIE()
    assert(inst.IE_NAME == SafariCourseIE.IE_NAME)

# Generated at 2022-06-22 08:09:15.699476
# Unit test for constructor of class SafariIE
def test_SafariIE():
    x = SafariIE()
    assert x.username is None
    assert x.password is None

# Generated at 2022-06-22 08:09:16.684141
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE('safari:course')

# Generated at 2022-06-22 08:09:17.715056
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariIE()._login()

# Generated at 2022-06-22 08:09:18.210821
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-22 08:09:22.149442
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert str(SafariCourseIE('safari')) == 'safari:course safaribooksonline.com online courses'

# Generated at 2022-06-22 08:09:25.332120
# Unit test for constructor of class SafariIE
def test_SafariIE():
    inst = SafariIE()
    assert inst.LOGGED_IN == False
    # Assert that the base class for SafariIE is InfoExtractor
    assert isinstance(inst, InfoExtractor)


# Generated at 2022-06-22 08:09:25.991628
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    pass

# Generated at 2022-06-22 08:09:27.820398
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    import datetime

    s = SafariBaseIE(None)
    print(s.LOGGED_IN)

# Generated at 2022-06-22 08:09:28.430777
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()

# Generated at 2022-06-22 08:10:01.192451
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    import json

    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'

    (webpage, urlh) = SafariCourseIE(None)._download_webpage_handle(
        url, '9781449396459', 'Downloading course JSON')

    course_json = json.loads(webpage)
    
    assert(course_json['title'] == 'Python Programming Language')

# Generated at 2022-06-22 08:10:11.040608
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()
    safariCourse = SafariCourseIE()
    safariApi = SafariApiIE()
    assert safari.IE_NAME == 'safari', 'SafariIE.IE_NAME should be safari'
    assert safari.IE_DESC == 'safaribooksonline.com online video', 'SafariIE.IE_DESC should be safaribooksonline.com online video'
    assert safariCourse.IE_NAME == 'safari:course', 'SafariCourseIE.IE_NAME should be safari:course'
    assert safariCourse.IE_DESC == 'safaribooksonline.com online courses', 'SafariCourseIE.IE_DESC should be safaribooksonline.com online courses'

# Generated at 2022-06-22 08:10:18.883016
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    try:
        from urllib.request import build_opener
    except ImportError:
        from urllib2 import build_opener
    op = build_opener()
    op.addheaders = [('Cookie', 'session=1231231')]
    opener = SafariBaseIE._build_opener(op)
    assert(opener.addheaders[0][0] == 'Cookie')
    assert(opener.addheaders[1][0] == 'Cookie')

# Generated at 2022-06-22 08:10:20.484474
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.real_initialize() is None

# Generated at 2022-06-22 08:10:29.295752
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """Unit test for constructor of class SafariApiIE"""
    safari_api_ie = SafariApiIE()
    assert safari_api_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_api_ie._API_FORMAT == 'json'
    assert safari_api_ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Generated at 2022-06-22 08:10:29.755179
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-22 08:10:30.162680
# Unit test for constructor of class SafariIE
def test_SafariIE():
    pass

# Generated at 2022-06-22 08:10:31.081695
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari = SafariApiIE()

# Generated at 2022-06-22 08:10:32.761731
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE._setup_class()
    instance = SafariBaseIE()
    assert instance.LOGGED_IN == False

# Generated at 2022-06-22 08:10:41.590764
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    test_cases = [
        {
            'params': [
                {'_NETRC_MACHINE': 'safari'},
                {'username': '', 'password': ''},
                ]
        },
        {
            'params': [
                {'_NETRC_MACHINE': 'safari'},
                {'username': 'test', 'password': 'test'},
                ]
        },
    ]
    for case_params in test_cases:
        ie = SafariBaseIE(*case_params['params'])
        assert ie is not None

# Generated at 2022-06-22 08:11:43.502808
# Unit test for constructor of class SafariIE
def test_SafariIE():
    obj = SafariIE()
    obj.initialize()
    assert obj._download_json(
        'https://www.safaribooksonline.com/member/auth/login/', None, 'Logging in',
        data=json.dumps({
            'email': 'dummy@dummy.com',
            'password': 'dummy',
            'redirect_uri': 'https://api.oreilly.com/federation',
        }).encode(), headers={
            'Content-Type': 'application/json',
            'Referer': 'https://learning.oreilly.com/accounts/login-check/'
        }, expected_status=400) != None


# Generated at 2022-06-22 08:11:51.762726
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    with open('test/test_safari.json', 'r') as f:
        test_safari_json = f.read()
    test_safari_json = json.loads(test_safari_json)
    test_safari_json = test_safari_json['entries']['#text']
    test_safari_json = test_safari_json[0]

    # Testing constructor can handle JSON response from website
    safari_test = SafariBaseIE(test_safari_json)

    # Testing constructor can handle JSON response from local file
    safari_test.test_safari_json(test_safari_json)

# Generated at 2022-06-22 08:12:02.205270
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """Test construction of class SafariCourseIE"""
    obj = SafariCourseIE('http://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert obj.IE_NAME is 'safari:course'
    assert obj.IE_DESC is 'safaribooksonline.com online courses'
    assert obj._VALID_URL is 'https?://(?:www\\.)?(?:safaribooksonline|(?:learning\\.)?oreilly)\\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/.+'

# Generated at 2022-06-22 08:12:07.530930
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    try:
        safari = SafariCourseIE()
    except RuntimeError as e:
        # Test passed if the raised exception is correct
        if str(e) == 'The safari extractor requires a session cookie to access the course' + \
                ' content. Please set up safaribooksonline.com in your .netrc file.':
            return
        raise e
    raise Exception('The safari object was instantiated without using a .netrc file')

# Generated at 2022-06-22 08:12:09.098192
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    try:
        SafariApiIE()
        assert True
    except TypeError:
        assert False

# Generated at 2022-06-22 08:12:14.026487
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import sys
    import unittest
    suite = unittest.TestSuite()

    class TestSafariIE(SafariIE):
        def _real_extract(self, url):
            return

    sys.argv.insert(1, '--noplaylist')


# Generated at 2022-06-22 08:12:15.334903
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert 'SafariCourseIE' in globals()



# Generated at 2022-06-22 08:12:16.750029
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE('safaricourse', {}, {}, {})

# Generated at 2022-06-22 08:12:20.727964
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .common import make_extractor
    from .common import make_query

    url = "https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html"
    query = make_query(url)
    make_extractor(SafariApiIE, url, query)

# Generated at 2022-06-22 08:12:21.192357
# Unit test for constructor of class SafariIE
def test_SafariIE():
    pass

# Generated at 2022-06-22 08:14:41.797292
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    IE_NAME = 'safari:api'
    IE_DESC = 'safaribooksonline.com online video api'
    url = 'https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html'
    obj  = SafariApiIE(IE_NAME)
    assert obj.ie_key() == IE_NAME
    assert obj.ie_desc() == IE_DESC
    assert obj.suitable(url) == True

# Generated at 2022-06-22 08:14:43.184500
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE(None)

# Generated at 2022-06-22 08:14:45.014324
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 08:14:46.067688
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()


# Generated at 2022-06-22 08:14:51.839806
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    course_url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459'
    api_ie = SafariApiIE(SafariApiIE.suitable(course_url))

    # verify passing a course url to SafariApiIE does not
    # construct a SafariApiIE object
    assert api_ie is None



# Generated at 2022-06-22 08:14:54.489548
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    instance = SafariApiIE()
    instance._real_initialize()

# Generated at 2022-06-22 08:14:56.865221
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    try:
        SafariBaseIE._login()
    except IOError:
        raise AssertionError("login attempt failed, but should succeed")

# Generated at 2022-06-22 08:15:04.547801
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    class TestSafariCourseIE(SafariCourseIE):
        _TEST = {
            'url': 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/',
            'info_dict': {
                'id': '9780133392838',
                'title': 'Hadoop Fundamentals LiveLessons',
            },
            'playlist_count': 22,
        }

    TestSafariCourseIE()

# Generated at 2022-06-22 08:15:05.608596
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from ...utils import test_required
    test_required(SafariApiIE)

# Generated at 2022-06-22 08:15:06.416169
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safariApiIE = SafariApiIE();