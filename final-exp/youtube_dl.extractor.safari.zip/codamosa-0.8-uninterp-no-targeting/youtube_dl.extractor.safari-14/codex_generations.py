

# Generated at 2022-06-22 08:08:30.058099
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'

# Generated at 2022-06-22 08:08:30.634279
# Unit test for constructor of class SafariIE
def test_SafariIE():
    pass

# Generated at 2022-06-22 08:08:31.630759
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # smoke test
    SafariIE()

# Generated at 2022-06-22 08:08:38.055227
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Testing login with invalid credentials
    username = 'invalid'
    password = 'invalid'
    safari_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'

    safari = SafariBaseIE()
    safari.username = username
    safari.password = password

    # Testing with invalid credentials
    with safari.raise_login_required(safari_url):
        pass

# Generated at 2022-06-22 08:08:50.361634
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE.suitable("https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838")
    assert SafariCourseIE.suitable("https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html")
    assert SafariCourseIE.suitable("https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json")
    assert SafariCourseIE.suitable("http://techbus.safaribooksonline.com/9780134426365")

# Generated at 2022-06-22 08:08:52.170228
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()
    safari._real_initialize()

# Generated at 2022-06-22 08:08:53.216007
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test constructing SafariCourseIE
    SafariCourseIE()

# Generated at 2022-06-22 08:09:04.371139
# Unit test for constructor of class SafariIE
def test_SafariIE():
    course_id = "9781449396459"
    course_title = "Learning Node.js"
    part_id = "9781449396459-LPUNJS_08_01"
    part_title = "Introduction to Node.js Development"
    part_url = "https://www.safaribooksonline.com/library/view/learning-nodejs/9781449396459/part01.html"
    # Part id is formatted like this
    part = "%s-%s" % (course_id, part_id)
    # Download URL is formatted like this
    url = "https://learning.oreilly.com/videos/%s/%s/%s" % (course_title.lower().replace(' ', '-').replace(':', ''), course_id, part)
    # Simulate SafariIE instance
    saf

# Generated at 2022-06-22 08:09:06.459655
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert SafariIE().ie_key() in IE_DESC

# Generated at 2022-06-22 08:09:14.647105
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Testing an URL for SafariBookOnline video
    safari_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    safari_video = SafariIE()
    safari_video.url = safari_url
    assert safari_video.url == safari_url

    # Testing an URL for SafariBookOnline course
    safari_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    safari_course = SafariCourseIE()
    safari_course.url = safari_url
    assert safari_course.url == safari_url


# Generated at 2022-06-22 08:09:31.593060
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import unittest

    class SafariIETest(unittest.TestCase):
        def test_smoke(self):
            _ = SafariIE()

    unittest.main(warnings='ignore')

# Generated at 2022-06-22 08:09:33.298450
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    instance = SafariBaseIE()
    assert isinstance(instance, SafariBaseIE)

# Generated at 2022-06-22 08:09:34.584236
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safariApiIE = SafariApiIE()

# Generated at 2022-06-22 08:09:35.288034
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()

# Generated at 2022-06-22 08:09:41.478006
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari = SafariBaseIE()

    safari._download_json = lambda *args, **kwargs: {
        'redirect_uri': 'test_url',
        'logged_in': True,
    }
    safari._apply_first_set_cookie_header = lambda *args, **kwargs: None

    safari._real_initialize()
    assert safari.LOGGED_IN

# Generated at 2022-06-22 08:09:42.030525
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()

# Generated at 2022-06-22 08:09:50.801467
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .html5 import HTML5IE
    from .compat import compat_urllib_parse_urlparse

    fake_url = "https://cdnapisec.kaltura.com/html5/html5lib/v2.37.1/mwEmbedFrame.php?wid=_1926081"
    fake_url += "&uiconf_id=29375172&flashvars[referenceId]=9780133392838-0_qbqx90ic&flashvars[ks]=NTQ2ZTM3ODI3NjYzMjY1YmRmOWRjODBhZmE0NjgwZjIwOWMxYTViM30%3D"


# Generated at 2022-06-22 08:09:55.039190
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    test_dict = {
        'username':"OReillyUser",
        'password':"OReillyPass",
    }
    safari_base_ie = SafariBaseIE()
    safari_base_ie.downloader._downloader.params.update(test_dict)
    safari_base_ie.downloader._downloader.params['usenetrc'] = False
    safari_base_ie._login()
    this_dict = safari_base_ie.downloader._downloader.params
    assert test_dict == this_dict

# Generated at 2022-06-22 08:10:06.137506
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    import os
    import tempfile
    import unittest

    try:
        from ..utils import (
            compat_http_client,
            compat_urllib_request,
            compat_urllib_error,
            compat_urllib_parse,
        )
    except ImportError:
        # for Python < 2.6
        from ..utils import (
            compat_http_client,
            compat_urllib_request,
            compat_urllib_error,
            compat_urllib_parse,
        )

    from ..utils import (
        encode_dict,
    )

    from .common import InfoExtractor

    from .safari import SafariBaseIE

    class MockHeadRequest(compat_urllib_request.Request):
        RESPONSE_CODE = None


# Generated at 2022-06-22 08:10:10.830625
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # constructor of class SafariIE
    ie = SafariIE()
    # check whether the URL is recognized
    ie.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')

# Generated at 2022-06-22 08:11:00.804564
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safariAPI = SafariApiIE("http://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part01.html")
    assert safariAPI._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'


# Generated at 2022-06-22 08:11:10.241949
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE('test', {'test': 'value'})

    assert safari_base_ie.IE_NAME == 'test'
    assert safari_base_ie.IE_DESC == ''
    assert safari_base_ie._VALID_URL == ''
    assert safari_base_ie._TESTS == []

    assert safari_base_ie.test == 'value'
    assert safari_base_ie.LOGGED_IN is False
    assert safari_base_ie._API_FORMAT == 'json'

# Generated at 2022-06-22 08:11:20.471761
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test for SafariApiIE
    mo = re.match(SafariApiIE.ie_key(), "SafariApiIE")
    assert mo is not None, "SafariApiIE key is not matched."
    mo = re.match(SafariApiIE._VALID_URL, "https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json")
    assert mo is not None, "URL is not matched."
    ie = SafariApiIE(SafariApiIE.ie_key())
    ie.initialize()
    assert ie.LOGGED_IN == False, "LOGGED_IN is wrong value."


# Generated at 2022-06-22 08:11:30.190482
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test constructors with many different args
    website_url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    website_id = '9781449396459'
    course_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    course_id = '9780133392838'
    ie = SafariCourseIE(SafariCourseIE._create_generic_info_extractor())

    assert ie._VALID_URL == SafariCourseIE._VALID_URL
    assert ie.IE_NAME == SafariCourseIE.IE_NAME
    assert ie.IE_DESC == SafariCourseIE.IE_DESC
    assert ie

# Generated at 2022-06-22 08:11:38.726544
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safaribooksonline_ie = SafariBaseIE('SafariBaseIE', 'safaribooksonline')

    assert 'SafariBaseIE' == safaribooksonline_ie.ie_key()
    assert 'safaribooksonline' == safaribooksonline_ie.ie_desc()
    assert False == safaribooksonline_ie.LOGGED_IN

    assert isinstance(safaribooksonline_ie, InfoExtractor)

# Generated at 2022-06-22 08:11:40.092988
# Unit test for constructor of class SafariIE
def test_SafariIE():
    obj = SafariIE()
    assert obj.LOGGED_IN == False



# Generated at 2022-06-22 08:11:47.215924
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test for valid construction
    inst = SafariCourseIE('http://www.safaribooksonline.com/blah/blah/blah/blah/blah/blah')
    assert inst.IE_NAME == 'safari:course'
    assert inst.IE_DESC == 'safaribooksonline.com online courses'
    assert inst.VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'

# Generated at 2022-06-22 08:11:51.084726
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # No login
    ie = SafariIE('https://safaribooksonline.com/')
    assert not ie.LOGGED_IN
    assert ie.username == None
    assert ie.password == None

    # With login information
    ie = SafariIE('https://safaribooksonline.com/', 'user', 'pass')
    assert ie.username == 'user'
    assert ie.password == 'pass'

# Generated at 2022-06-22 08:11:53.025447
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    inst = SafariApiIE('safari:api')

# Generated at 2022-06-22 08:11:54.052699
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('SafariApiIE')

# Generated at 2022-06-22 08:13:16.317769
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
  assert(SafariApiIE()._API_BASE == 'https://learning.oreilly.com/api/v1')

# Generated at 2022-06-22 08:13:23.130374
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    m = SafariCourseIE()
    assert m.suitable("https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/") != True
    assert m.suitable("https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json") != True
    assert m.suitable("http://techbus.safaribooksonline.com/9780134426365") != True
    assert m.suitable("https://www.safaribooksonline.com/videos/python-programming-language/9780134217314") != True

# Generated at 2022-06-22 08:13:35.228187
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from youtube_dl.utils import get_js_to_py_type

    ie = get_js_to_py_type('SafariCourseIE')(SmuggleIE._youtube_ie.YTIE.YTIE._downloader) # pylint:disable=protected-access

    # Can't assume that it is actually logged in, so assume not.
    assert ie.LOGGED_IN == False

    # No login function
    assert ie._login == None

    # Function verify_partner_id exists
    assert ie._verify_partner_id != None

    # Function _real_initialize exists
    assert ie._real_initialize != None

    # Function _real_extract exists
    assert ie._real_extract != None

    # Function _partner_id exists
    assert ie._partner_id != None



# Generated at 2022-06-22 08:13:42.159107
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .common import setUp
    from .test_playlists_html import test_playlists_html
    from .test_playlists_html import test_playlists_html_url
    from .test_download_json import test_download_json

    setUp()
    test_playlists_html(SafariCourseIE, [], 'safari:course')
    test_playlists_html_url(SafariCourseIE, [], 'safari:course')
    test_download_json(SafariCourseIE, [], 'safari:course')

# Generated at 2022-06-22 08:13:47.600981
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safariie = SafariIE()
    assert safariie is not None


# Generated at 2022-06-22 08:13:54.523282
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    obj = SafariBaseIE()

    assert obj._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert obj._NETRC_MACHINE == 'safari'
    assert obj._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert obj._API_FORMAT == 'json'
    assert obj.LOGGED_IN == False

# Generated at 2022-06-22 08:14:01.437403
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    test_cases = [
        (r'https://learning.oreilly.com/user-experience-design/book/9780596520208',
         {'id': '9780596520208'}),
        (r'https://learning.oreilly.com/videos/redis-fundamentals/9781491983921',
         {'id': '9781491983921'}),
    ]
    for url, expected in test_cases:
        assert SafariCourseIE._match_id(url) == expected['id']

# Generated at 2022-06-22 08:14:09.812783
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    with open('tests/data/safari-part.html') as f:
        html = f.read()
    ie = SafariApiIE(None)
    course_id = '9781449396459'
    part_html = ie._extract_url(
        '%s/book/%s/chapter/part01.html' % (ie._API_BASE, course_id),
        course_id + '/part01', html=html)
    part_dict = json.loads(part_html)
    assert part_dict['web_url'] == 'https://learning.oreilly.com/videos/continuous-delivery-on/9781449396459/9781449396459-video1_7' + '?' + 'partner=' + ie._PARTNER_ID + '#playVideo'

# Generated at 2022-06-22 08:14:11.457901
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert type(SafariApiIE())

# Generated at 2022-06-22 08:14:13.546792
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert isinstance(SafariCourseIE(), InfoExtractor)

# Generated at 2022-06-22 08:16:54.661688
# Unit test for constructor of class SafariIE
def test_SafariIE():
    class FakeDownloader:
        def __init__(self):
            self.to_screen = lambda *x: None
        def to_stdout(self, *x):
            pass
        def to_stderr(self, *x):
            pass
        def trouble(self, *args, **kwargs):
            pass
        def report_warning(self, *args, **kwargs):
            pass
        def report_error(self, *args, **kwargs):
            pass
        def report_file_already_downloaded(self, *args, **kwargs):
            pass
        def report_destination(self, *args, **kwargs):
            pass
        def download(self, *args, **kwargs):
            pass
        def post_process(self, *args, **kwargs):
            pass

   

# Generated at 2022-06-22 08:16:57.415673
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    class T(SafariApiIE):
        def _real_initialize(self):
            pass
    t = T()
    assert t._API_BASE == 'https://www.safaribooksonline.com/api/v1'
    assert t._API_FORMAT == 'html'

# Generated at 2022-06-22 08:17:00.424944
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    example_url = 'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838/9780133392838-00_SeriesIntro'
    SafariBaseIE().suitable(example_url)

# Generated at 2022-06-22 08:17:04.576151
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE('safaribooksonline')
    assert safari.LOGGED_IN == False

# Generated at 2022-06-22 08:17:09.191111
# Unit test for constructor of class SafariIE
def test_SafariIE():
    url = 'https://www.safaribooksonline.com/library/view/cisco-asa-firepower/9780134295591/'
    real_video_id = '9780134295591'
    course_id = '9780134295591'
    part = '01_00'
    reference_id = '9780134295591-01_00'

    # Validate constructor of SafariIE
    safari_ie = SafariIE()
    assert safari_ie._VALID_URL == SafariIE.VALID_URL

# Generated at 2022-06-22 08:17:13.268192
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert SafariIE()._VALID_URL == SafariBaseIE._VALID_URL

# Generated at 2022-06-22 08:17:16.168777
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert (SafariIE(SafariIE._create_ie(SafariIE.ie_key())).IE_NAME
            == SafariIE.IE_NAME)

# Generated at 2022-06-22 08:17:16.811448
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()

# Generated at 2022-06-22 08:17:19.466108
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    if __name__ == '__main__':
        test_SafariApiIE()

    assert SafariApiIE.__name__ == 'SafariApiIE'

# Generated at 2022-06-22 08:17:22.393618
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    import unittest
    unittest.TextTestRunner()